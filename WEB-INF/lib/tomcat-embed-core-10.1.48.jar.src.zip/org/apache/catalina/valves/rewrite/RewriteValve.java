/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.RequestUtil;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.CharChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteValve
/*     */   extends ValveBase
/*     */ {
/*  80 */   private static final URLEncoder REWRITE_DEFAULT_ENCODER = (URLEncoder)URLEncoder.DEFAULT.clone(); static {
/*  81 */     REWRITE_DEFAULT_ENCODER.addSafeCharacter('%');
/*     */   }
/*  83 */   private static final URLEncoder REWRITE_QUERY_ENCODER = (URLEncoder)URLEncoder.QUERY.clone(); static {
/*  84 */     REWRITE_QUERY_ENCODER.addSafeCharacter('%');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   protected RewriteRule[] rules = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected ThreadLocal<Boolean> invoked = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   protected String resourcePath = "rewrite.config";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean context = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean enabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   protected Map<String, RewriteMap> maps = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   protected ArrayList<String> mapsConfiguration = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public RewriteValve() {
/* 130 */     super(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getEnabled() {
/* 135 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 139 */     this.enabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 145 */     super.initInternal();
/* 146 */     this.containerLog = LogFactory.getLog(getContainer().getLogName() + ".rewrite");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 153 */     super.startInternal();
/*     */     
/* 155 */     InputStream is = null;
/*     */ 
/*     */     
/* 158 */     if (getContainer() instanceof Context) {
/* 159 */       this.context = true;
/* 160 */       String webInfResourcePath = "/WEB-INF/" + this.resourcePath;
/* 161 */       is = ((Context)getContainer()).getServletContext().getResourceAsStream(webInfResourcePath);
/* 162 */       if (this.containerLog.isDebugEnabled()) {
/* 163 */         if (is == null) {
/* 164 */           this.containerLog.debug(sm.getString("rewriteValve.noConfiguration", new Object[] { webInfResourcePath }));
/*     */         } else {
/* 166 */           this.containerLog.debug(sm.getString("rewriteValve.readConfiguration", new Object[] { webInfResourcePath }));
/*     */         } 
/*     */       }
/*     */     } else {
/* 170 */       String resourceName = Container.getConfigPath(getContainer(), this.resourcePath);
/*     */       try {
/* 172 */         ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getResource(resourceName);
/* 173 */         is = resource.getInputStream();
/* 174 */       } catch (IOException ioe) {
/* 175 */         if (this.containerLog.isDebugEnabled()) {
/* 176 */           this.containerLog.debug(sm.getString("rewriteValve.noConfiguration", new Object[] { resourceName }), ioe);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     if (is == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 186 */     try { InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8); 
/* 187 */       try { BufferedReader reader = new BufferedReader(isr); 
/* 188 */         try { parse(reader);
/* 189 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  isr.close(); } catch (Throwable throwable) { try { isr.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 190 */     { this.containerLog.error(sm.getString("rewriteValve.closeError"), ioe); }
/*     */     finally
/*     */     { try {
/* 193 */         is.close();
/* 194 */       } catch (IOException ioe) {
/* 195 */         this.containerLog.error(sm.getString("rewriteValve.closeError"), ioe);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void setConfiguration(String configuration) throws Exception {
/* 202 */     if (this.containerLog == null) {
/* 203 */       this.containerLog = LogFactory.getLog(getContainer().getLogName() + ".rewrite");
/*     */     }
/* 205 */     for (RewriteMap map : this.maps.values()) {
/* 206 */       if (map instanceof Lifecycle) {
/* 207 */         ((Lifecycle)map).stop();
/*     */       }
/*     */     } 
/* 210 */     this.maps.clear();
/* 211 */     parse(new BufferedReader(new StringReader(configuration)));
/*     */   }
/*     */   
/*     */   public String getConfiguration() {
/* 215 */     StringBuilder buffer = new StringBuilder();
/* 216 */     for (String mapConfiguration : this.mapsConfiguration) {
/* 217 */       buffer.append(mapConfiguration).append("\r\n");
/*     */     }
/* 219 */     if (!this.mapsConfiguration.isEmpty()) {
/* 220 */       buffer.append("\r\n");
/*     */     }
/* 222 */     for (RewriteRule rule : this.rules) {
/* 223 */       for (int j = 0; j < (rule.getConditions()).length; j++) {
/* 224 */         buffer.append(rule.getConditions()[j].toString()).append("\r\n");
/*     */       }
/* 226 */       buffer.append(rule.toString()).append("\r\n").append("\r\n");
/*     */     } 
/* 228 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected void parse(BufferedReader reader) throws LifecycleException {
/* 232 */     List<RewriteRule> rules = new ArrayList<>();
/* 233 */     List<RewriteCond> conditions = new ArrayList<>();
/* 234 */     ArrayList<String> mapsConfiguration = new ArrayList<>();
/*     */     while (true) {
/*     */       try {
/* 237 */         String line = reader.readLine();
/* 238 */         if (line == null) {
/*     */           break;
/*     */         }
/* 241 */         Object result = parse(line);
/* 242 */         if (result instanceof RewriteRule) {
/* 243 */           RewriteRule rule = (RewriteRule)result;
/* 244 */           if (this.containerLog.isTraceEnabled()) {
/* 245 */             this.containerLog.trace("Add rule with pattern " + rule.getPatternString() + " and substitution " + rule
/* 246 */                 .getSubstitutionString());
/*     */           }
/* 248 */           for (int i = conditions.size() - 1; i > 0; i--) {
/* 249 */             if (((RewriteCond)conditions.get(i - 1)).isOrnext()) {
/* 250 */               ((RewriteCond)conditions.get(i)).setOrnext(true);
/*     */             }
/*     */           } 
/* 253 */           for (RewriteCond condition : conditions) {
/* 254 */             if (this.containerLog.isTraceEnabled()) {
/* 255 */               this.containerLog.trace("Add condition " + condition.getCondPattern() + " test " + condition
/* 256 */                   .getTestString() + " to rule with pattern " + rule.getPatternString() + " and substitution " + rule
/* 257 */                   .getSubstitutionString() + (
/* 258 */                   condition.isOrnext() ? " [OR]" : "") + (condition.isNocase() ? " [NC]" : ""));
/*     */             }
/* 260 */             rule.addCondition(condition);
/*     */           } 
/* 262 */           conditions.clear();
/* 263 */           rules.add(rule); continue;
/* 264 */         }  if (result instanceof RewriteCond) {
/* 265 */           conditions.add((RewriteCond)result); continue;
/* 266 */         }  if (result instanceof Object[]) {
/* 267 */           String mapName = (String)((Object[])result)[0];
/* 268 */           RewriteMap map = (RewriteMap)((Object[])result)[1];
/* 269 */           this.maps.put(mapName, map);
/*     */ 
/*     */           
/* 272 */           mapsConfiguration.add(line);
/* 273 */           if (map instanceof Lifecycle) {
/* 274 */             ((Lifecycle)map).start();
/*     */           }
/*     */         } 
/* 277 */       } catch (IOException ioe) {
/* 278 */         this.containerLog.error(sm.getString("rewriteValve.readError"), ioe);
/*     */       } 
/*     */     } 
/* 281 */     this.mapsConfiguration = mapsConfiguration;
/*     */ 
/*     */     
/* 284 */     for (RewriteRule rule : rules) {
/* 285 */       rule.parse(this.maps);
/*     */     }
/*     */     
/* 288 */     this.rules = rules.<RewriteRule>toArray(new RewriteRule[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 293 */     super.stopInternal();
/* 294 */     for (RewriteMap map : this.maps.values()) {
/* 295 */       if (map instanceof Lifecycle) {
/* 296 */         ((Lifecycle)map).stop();
/*     */       }
/*     */     } 
/* 299 */     this.maps.clear();
/* 300 */     this.rules = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 307 */     if (!getEnabled() || this.rules == null || this.rules.length == 0) {
/* 308 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/* 312 */     if (Boolean.TRUE.equals(this.invoked.get())) {
/*     */       try {
/* 314 */         getNext().invoke(request, response);
/*     */       } finally {
/* 316 */         this.invoked.set(null);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 323 */       Resolver resolver = new ResolverImpl(request, this.containerLog);
/*     */       
/* 325 */       this.invoked.set(Boolean.TRUE);
/*     */ 
/*     */       
/* 328 */       Charset uriCharset = request.getConnector().getURICharset();
/* 329 */       String queryStringOriginalEncoded = request.getQueryString();
/* 330 */       MessageBytes urlMB = this.context ? request.getRequestPathMB() : request.getDecodedRequestURIMB();
/* 331 */       urlMB.toChars();
/* 332 */       CharChunk charChunk = urlMB.getCharChunk();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 358 */       CharSequence urlRewriteEncoded = encodeForRewrite((CharSequence)charChunk);
/* 359 */       CharSequence host = request.getServerName();
/* 360 */       boolean rewritten = false;
/* 361 */       boolean done = false;
/* 362 */       boolean qsa = false;
/* 363 */       boolean qsd = false;
/* 364 */       boolean valveSkip = false;
/*     */ 
/*     */       
/* 367 */       for (int i = 0; i < this.rules.length; i++) {
/* 368 */         RewriteRule rule = this.rules[i];
/* 369 */         CharSequence test = rule.isHost() ? host : urlRewriteEncoded;
/* 370 */         CharSequence newtest = rule.evaluate(test, resolver);
/* 371 */         if (newtest != null && !Objects.equals(test.toString(), newtest.toString())) {
/* 372 */           if (this.containerLog.isTraceEnabled()) {
/* 373 */             this.containerLog.trace("Rewrote " + String.valueOf(test) + " as " + String.valueOf(newtest) + " with rule pattern " + rule
/* 374 */                 .getPatternString());
/*     */           }
/* 376 */           if (rule.isHost()) {
/* 377 */             host = newtest;
/*     */           } else {
/* 379 */             urlRewriteEncoded = newtest;
/*     */           } 
/* 381 */           rewritten = true;
/*     */         } 
/*     */ 
/*     */         
/* 385 */         if (!qsa && newtest != null && rule.isQsappend()) {
/* 386 */           qsa = true;
/*     */         }
/*     */         
/* 389 */         if (!qsd && newtest != null && rule.isQsdiscard()) {
/* 390 */           qsd = true;
/*     */         }
/*     */         
/* 393 */         if (!valveSkip && newtest != null && rule.isValveSkip()) {
/* 394 */           valveSkip = true;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 400 */         if (rule.isForbidden() && newtest != null) {
/* 401 */           response.sendError(403);
/* 402 */           done = true;
/*     */           
/*     */           break;
/*     */         } 
/* 406 */         if (rule.isGone() && newtest != null) {
/* 407 */           response.sendError(410);
/* 408 */           done = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 413 */         if (rule.isRedirect() && newtest != null) {
/*     */ 
/*     */           
/* 416 */           String rewrittenQueryStringRewriteEncoded, redirectPath, urlStringRewriteEncoded = urlRewriteEncoded.toString();
/* 417 */           int index = urlStringRewriteEncoded.indexOf('?');
/*     */           
/* 419 */           if (index == -1) {
/* 420 */             rewrittenQueryStringRewriteEncoded = null;
/*     */           } else {
/* 422 */             rewrittenQueryStringRewriteEncoded = urlStringRewriteEncoded.substring(index + 1);
/* 423 */             urlStringRewriteEncoded = urlStringRewriteEncoded.substring(0, index);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 428 */           StringBuilder urlStringEncoded = new StringBuilder(REWRITE_DEFAULT_ENCODER.encode(urlStringRewriteEncoded, uriCharset));
/*     */           
/* 430 */           if (!qsd && queryStringOriginalEncoded != null && !queryStringOriginalEncoded.isEmpty()) {
/* 431 */             if (rewrittenQueryStringRewriteEncoded == null) {
/* 432 */               urlStringEncoded.append('?');
/* 433 */               urlStringEncoded.append(queryStringOriginalEncoded);
/*     */             }
/* 435 */             else if (qsa) {
/*     */               
/* 437 */               urlStringEncoded.append('?');
/* 438 */               urlStringEncoded.append(REWRITE_QUERY_ENCODER
/* 439 */                   .encode(rewrittenQueryStringRewriteEncoded, uriCharset));
/* 440 */               urlStringEncoded.append('&');
/* 441 */               urlStringEncoded.append(queryStringOriginalEncoded);
/* 442 */             } else if (index == urlStringEncoded.length() - 1) {
/*     */ 
/*     */               
/* 445 */               urlStringEncoded.deleteCharAt(index);
/*     */             } else {
/* 447 */               urlStringEncoded.append('?');
/* 448 */               urlStringEncoded.append(REWRITE_QUERY_ENCODER
/* 449 */                   .encode(rewrittenQueryStringRewriteEncoded, uriCharset));
/*     */             }
/*     */           
/* 452 */           } else if (rewrittenQueryStringRewriteEncoded != null) {
/* 453 */             urlStringEncoded.append('?');
/* 454 */             urlStringEncoded
/* 455 */               .append(REWRITE_QUERY_ENCODER.encode(rewrittenQueryStringRewriteEncoded, uriCharset));
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 462 */           if (this.context && urlStringEncoded.charAt(0) == '/' && !UriUtil.hasScheme(urlStringEncoded)) {
/* 463 */             urlStringEncoded.insert(0, request.getContext().getEncodedPath());
/*     */           }
/*     */           
/* 466 */           if (rule.isNoescape()) {
/* 467 */             redirectPath = UDecoder.URLDecode(urlStringEncoded.toString(), uriCharset);
/*     */           } else {
/* 469 */             redirectPath = urlStringEncoded.toString();
/*     */           } 
/* 471 */           response.sendRedirect(response.encodeRedirectURL(redirectPath));
/* 472 */           response.setStatus(rule.getRedirectCode());
/* 473 */           done = true;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */ 
/*     */         
/* 480 */         if (rule.isCookie() && newtest != null) {
/* 481 */           Cookie cookie = new Cookie(rule.getCookieName(), rule.getCookieResult());
/* 482 */           cookie.setDomain(rule.getCookieDomain());
/* 483 */           cookie.setMaxAge(rule.getCookieLifetime());
/* 484 */           cookie.setPath(rule.getCookiePath());
/* 485 */           cookie.setSecure(rule.isCookieSecure());
/* 486 */           cookie.setHttpOnly(rule.isCookieHttpOnly());
/* 487 */           response.addCookie(cookie);
/*     */         } 
/*     */         
/* 490 */         if (rule.isEnv() && newtest != null) {
/* 491 */           for (int j = 0; j < rule.getEnvSize(); j++) {
/* 492 */             request.setAttribute(rule.getEnvName(j), rule.getEnvResult(j));
/*     */           }
/*     */         }
/*     */ 
/*     */         
/* 497 */         if (rule.isType() && newtest != null) {
/* 498 */           response.setContentType(rule.getTypeValue());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 504 */         if (rule.isChain() && newtest == null) {
/* 505 */           for (int j = i; j < this.rules.length; j++) {
/* 506 */             if (!this.rules[j].isChain()) {
/* 507 */               i = j;
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 514 */           if (rule.isLast() && newtest != null) {
/*     */             break;
/*     */           }
/*     */           
/* 518 */           if (rule.isNext() && newtest != null) {
/* 519 */             i = 0;
/*     */ 
/*     */           
/*     */           }
/* 523 */           else if (newtest != null) {
/* 524 */             i += rule.getSkip();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 529 */       if (rewritten) {
/* 530 */         if (!done) {
/*     */           
/* 532 */           String urlStringRewriteEncoded = urlRewriteEncoded.toString();
/* 533 */           String queryStringRewriteEncoded = null;
/* 534 */           int queryIndex = urlStringRewriteEncoded.indexOf('?');
/* 535 */           if (queryIndex != -1) {
/* 536 */             queryStringRewriteEncoded = urlStringRewriteEncoded.substring(queryIndex + 1);
/* 537 */             urlStringRewriteEncoded = urlStringRewriteEncoded.substring(0, queryIndex);
/*     */           } 
/*     */ 
/*     */           
/* 541 */           urlStringRewriteEncoded = RequestUtil.stripPathParams(urlStringRewriteEncoded, request);
/*     */           
/* 543 */           String contextPath = null;
/* 544 */           if (this.context) {
/* 545 */             contextPath = request.getContextPath();
/*     */           }
/*     */           
/* 548 */           request.getCoyoteRequest().requestURI().setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/* 549 */           CharChunk chunk = request.getCoyoteRequest().requestURI().getCharChunk();
/* 550 */           if (this.context)
/*     */           {
/* 552 */             chunk.append(contextPath);
/*     */           }
/*     */ 
/*     */           
/* 556 */           chunk.append(REWRITE_DEFAULT_ENCODER.encode(urlStringRewriteEncoded, uriCharset));
/*     */ 
/*     */           
/* 559 */           String urlStringRewriteDecoded = URLDecoder.decode(urlStringRewriteEncoded, uriCharset);
/* 560 */           urlStringRewriteDecoded = RequestUtil.normalize(urlStringRewriteDecoded);
/* 561 */           request.getCoyoteRequest().decodedURI().setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/* 562 */           chunk = request.getCoyoteRequest().decodedURI().getCharChunk();
/* 563 */           if (this.context)
/*     */           {
/* 565 */             chunk.append(request.getServletContext().getContextPath());
/*     */           }
/* 567 */           chunk.append(urlStringRewriteDecoded);
/*     */           
/* 569 */           if (queryStringRewriteEncoded == null) {
/*     */             
/* 571 */             if (qsd) {
/* 572 */               request.getCoyoteRequest().queryString().setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/*     */             }
/*     */           } else {
/*     */             
/* 576 */             request.getCoyoteRequest().queryString().setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/* 577 */             chunk = request.getCoyoteRequest().queryString().getCharChunk();
/* 578 */             chunk.append(REWRITE_QUERY_ENCODER.encode(queryStringRewriteEncoded, uriCharset));
/* 579 */             if (qsa && queryStringOriginalEncoded != null && !queryStringOriginalEncoded.isEmpty()) {
/* 580 */               chunk.append('&');
/* 581 */               chunk.append(queryStringOriginalEncoded);
/*     */             } 
/*     */           } 
/*     */           
/* 585 */           if (!host.equals(request.getServerName())) {
/* 586 */             request.getCoyoteRequest().serverName().setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/* 587 */             chunk = request.getCoyoteRequest().serverName().getCharChunk();
/* 588 */             chunk.append(host.toString());
/*     */           } 
/* 590 */           request.getMappingData().recycle();
/* 591 */           request.recycleSessionInfo();
/*     */           
/* 593 */           Connector connector = request.getConnector();
/*     */           try {
/* 595 */             if (!connector.getProtocolHandler().getAdapter().prepare(request.getCoyoteRequest(), response
/* 596 */                 .getCoyoteResponse())) {
/*     */               return;
/*     */             }
/* 599 */           } catch (Exception exception) {}
/*     */ 
/*     */           
/* 602 */           Pipeline pipeline = connector.getService().getContainer().getPipeline();
/* 603 */           request.setAsyncSupported(pipeline.isAsyncSupported());
/* 604 */           pipeline.getFirst().invoke(request, response);
/*     */         } 
/*     */       } else {
/* 607 */         Valve next = getNext();
/* 608 */         if (valveSkip) {
/* 609 */           next = next.getNext();
/* 610 */           if (next == null)
/*     */           {
/* 612 */             next = getNext();
/*     */           }
/*     */         } 
/* 615 */         next.invoke(request, response);
/*     */       } 
/*     */     } finally {
/*     */       
/* 619 */       this.invoked.set(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parse(String line) {
/* 635 */     QuotedStringTokenizer tokenizer = new QuotedStringTokenizer(line);
/* 636 */     if (tokenizer.hasMoreTokens()) {
/* 637 */       String token = tokenizer.nextToken();
/* 638 */       if (token.equals("RewriteCond")) {
/*     */         
/* 640 */         RewriteCond condition = new RewriteCond();
/* 641 */         if (tokenizer.countTokens() < 2) {
/* 642 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 644 */         condition.setTestString(tokenizer.nextToken());
/* 645 */         condition.setCondPattern(tokenizer.nextToken());
/* 646 */         if (tokenizer.hasMoreTokens()) {
/* 647 */           String flags = tokenizer.nextToken();
/* 648 */           condition.setFlagsString(flags);
/* 649 */           if (flags.startsWith("[") && flags.endsWith("]")) {
/* 650 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 652 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 653 */           while (flagsTokenizer.hasMoreElements()) {
/* 654 */             parseCondFlag(line, condition, flagsTokenizer.nextToken());
/*     */           }
/*     */         } 
/* 657 */         return condition;
/* 658 */       }  if (token.equals("RewriteRule")) {
/*     */         
/* 660 */         RewriteRule rule = new RewriteRule();
/* 661 */         if (tokenizer.countTokens() < 2) {
/* 662 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 664 */         rule.setPatternString(tokenizer.nextToken());
/* 665 */         rule.setSubstitutionString(tokenizer.nextToken());
/* 666 */         if (tokenizer.hasMoreTokens()) {
/* 667 */           String flags = tokenizer.nextToken();
/* 668 */           rule.setFlagsString(flags);
/* 669 */           if (flags.startsWith("[") && flags.endsWith("]")) {
/* 670 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 672 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 673 */           while (flagsTokenizer.hasMoreElements()) {
/* 674 */             parseRuleFlag(line, rule, flagsTokenizer.nextToken());
/*     */           }
/*     */           
/* 677 */           if (rule.isQsdiscard()) {
/* 678 */             rule.setQsappend(false);
/*     */           }
/*     */         } 
/* 681 */         return rule;
/* 682 */       }  if (token.equals("RewriteMap")) {
/*     */         
/* 684 */         if (tokenizer.countTokens() < 2) {
/* 685 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 687 */         String name = tokenizer.nextToken();
/* 688 */         String rewriteMapClassName = tokenizer.nextToken();
/* 689 */         RewriteMap map = null;
/* 690 */         if (rewriteMapClassName.startsWith("int:")) {
/* 691 */           map = InternalRewriteMap.toMap(rewriteMapClassName.substring("int:".length()));
/* 692 */         } else if (rewriteMapClassName.startsWith("txt:")) {
/* 693 */           map = new RandomizedTextRewriteMap(rewriteMapClassName.substring("txt:".length()), false);
/* 694 */         } else if (rewriteMapClassName.startsWith("rnd:")) {
/* 695 */           map = new RandomizedTextRewriteMap(rewriteMapClassName.substring("rnd:".length()), true);
/* 696 */         } else if (rewriteMapClassName.startsWith("prg:")) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 701 */           rewriteMapClassName = rewriteMapClassName.substring("prg:".length());
/* 702 */         } else if (!rewriteMapClassName.startsWith("dbm:")) {
/*     */ 
/*     */           
/* 705 */           if (rewriteMapClassName.startsWith("dbd:") || rewriteMapClassName.startsWith("fastdbd:"));
/*     */         } 
/*     */         
/* 708 */         if (map == null) {
/*     */           try {
/* 710 */             map = Class.forName(rewriteMapClassName).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 711 */           } catch (Exception e) {
/* 712 */             throw new IllegalArgumentException(sm.getString("rewriteValve.invalidMapClassName", new Object[] { line }));
/*     */           } 
/*     */         }
/* 715 */         if (tokenizer.hasMoreTokens()) {
/* 716 */           if (tokenizer.countTokens() == 1) {
/* 717 */             map.setParameters(tokenizer.nextToken());
/*     */           } else {
/* 719 */             List<String> params = new ArrayList<>();
/* 720 */             while (tokenizer.hasMoreTokens()) {
/* 721 */               params.add(tokenizer.nextToken());
/*     */             }
/* 723 */             map.setParameters(params.<String>toArray(new String[0]));
/*     */           } 
/*     */         }
/* 726 */         return new Object[] { name, map };
/* 727 */       }  if (!token.startsWith("#"))
/*     */       {
/*     */         
/* 730 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */       }
/*     */     } 
/* 733 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void parseCondFlag(String line, RewriteCond condition, String flag) {
/* 745 */     if (flag.equals("NC") || flag.equals("nocase")) {
/* 746 */       condition.setNocase(true);
/* 747 */     } else if (flag.equals("OR") || flag.equals("ornext")) {
/* 748 */       condition.setOrnext(true);
/*     */     } else {
/* 750 */       throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void parseRuleFlag(String line, RewriteRule rule, String flag) {
/* 763 */     if (flag.equals("B")) {
/* 764 */       rule.setEscapeBackReferences(true);
/* 765 */     } else if (flag.equals("chain") || flag.equals("C")) {
/* 766 */       rule.setChain(true);
/* 767 */     } else if (flag.startsWith("cookie=") || flag.startsWith("CO=")) {
/* 768 */       rule.setCookie(true);
/* 769 */       if (flag.startsWith("cookie")) {
/* 770 */         flag = flag.substring("cookie=".length());
/* 771 */       } else if (flag.startsWith("CO=")) {
/* 772 */         flag = flag.substring("CO=".length());
/*     */       } 
/* 774 */       StringTokenizer tokenizer = new StringTokenizer(flag, ":");
/* 775 */       if (tokenizer.countTokens() < 2) {
/* 776 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */       }
/* 778 */       rule.setCookieName(tokenizer.nextToken());
/* 779 */       rule.setCookieValue(tokenizer.nextToken());
/* 780 */       if (tokenizer.hasMoreTokens()) {
/* 781 */         rule.setCookieDomain(tokenizer.nextToken());
/*     */       }
/* 783 */       if (tokenizer.hasMoreTokens()) {
/*     */         try {
/* 785 */           rule.setCookieLifetime(Integer.parseInt(tokenizer.nextToken()));
/* 786 */         } catch (NumberFormatException e) {
/* 787 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }), e);
/*     */         } 
/*     */       }
/* 790 */       if (tokenizer.hasMoreTokens()) {
/* 791 */         rule.setCookiePath(tokenizer.nextToken());
/*     */       }
/* 793 */       if (tokenizer.hasMoreTokens()) {
/* 794 */         rule.setCookieSecure(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 796 */       if (tokenizer.hasMoreTokens()) {
/* 797 */         rule.setCookieHttpOnly(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 799 */     } else if (flag.startsWith("env=") || flag.startsWith("E=")) {
/* 800 */       rule.setEnv(true);
/* 801 */       if (flag.startsWith("env=")) {
/* 802 */         flag = flag.substring("env=".length());
/* 803 */       } else if (flag.startsWith("E=")) {
/* 804 */         flag = flag.substring("E=".length());
/*     */       } 
/* 806 */       int pos = flag.indexOf(':');
/* 807 */       if (pos == -1 || pos + 1 == flag.length()) {
/* 808 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */       }
/* 810 */       rule.addEnvName(flag.substring(0, pos));
/* 811 */       rule.addEnvValue(flag.substring(pos + 1));
/* 812 */     } else if (flag.startsWith("forbidden") || flag.startsWith("F")) {
/* 813 */       rule.setForbidden(true);
/* 814 */     } else if (flag.startsWith("gone") || flag.startsWith("G")) {
/* 815 */       rule.setGone(true);
/* 816 */     } else if (flag.startsWith("host") || flag.startsWith("H")) {
/* 817 */       rule.setHost(true);
/* 818 */     } else if (flag.startsWith("last") || flag.startsWith("L")) {
/* 819 */       rule.setLast(true);
/* 820 */     } else if (flag.startsWith("nocase") || flag.startsWith("NC")) {
/* 821 */       rule.setNocase(true);
/* 822 */     } else if (flag.startsWith("noescape") || flag.startsWith("NE")) {
/* 823 */       rule.setNoescape(true);
/* 824 */     } else if (flag.startsWith("next") || flag.startsWith("N")) {
/* 825 */       rule.setNext(true);
/*     */     
/*     */     }
/* 828 */     else if (flag.startsWith("qsappend") || flag.startsWith("QSA")) {
/* 829 */       rule.setQsappend(true);
/* 830 */     } else if (flag.startsWith("qsdiscard") || flag.startsWith("QSD")) {
/* 831 */       rule.setQsdiscard(true);
/* 832 */     } else if (flag.startsWith("redirect") || flag.startsWith("R")) {
/* 833 */       rule.setRedirect(true);
/* 834 */       int redirectCode = 302;
/* 835 */       if (flag.startsWith("redirect=") || flag.startsWith("R=")) {
/* 836 */         if (flag.startsWith("redirect=")) {
/* 837 */           flag = flag.substring("redirect=".length());
/* 838 */         } else if (flag.startsWith("R=")) {
/* 839 */           flag = flag.substring("R=".length());
/*     */         } 
/* 841 */         switch (flag) {
/*     */           case "temp":
/* 843 */             redirectCode = 302;
/*     */             break;
/*     */           case "permanent":
/* 846 */             redirectCode = 301;
/*     */             break;
/*     */           case "seeother":
/* 849 */             redirectCode = 303;
/*     */             break;
/*     */           default:
/* 852 */             redirectCode = Integer.parseInt(flag);
/*     */             break;
/*     */         } 
/*     */       } 
/* 856 */       rule.setRedirectCode(redirectCode);
/* 857 */     } else if (flag.startsWith("skip") || flag.startsWith("S")) {
/* 858 */       if (flag.startsWith("skip=")) {
/* 859 */         flag = flag.substring("skip=".length());
/* 860 */       } else if (flag.startsWith("S=")) {
/* 861 */         flag = flag.substring("S=".length());
/*     */       } 
/* 863 */       rule.setSkip(Integer.parseInt(flag));
/* 864 */     } else if (flag.startsWith("type") || flag.startsWith("T")) {
/* 865 */       if (flag.startsWith("type=")) {
/* 866 */         flag = flag.substring("type=".length());
/* 867 */       } else if (flag.startsWith("T=")) {
/* 868 */         flag = flag.substring("T=".length());
/*     */       } 
/* 870 */       rule.setType(true);
/* 871 */       rule.setTypeValue(flag);
/* 872 */     } else if (flag.startsWith("valveSkip") || flag.startsWith("VS")) {
/* 873 */       rule.setValveSkip(true);
/*     */     } else {
/* 875 */       throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private CharSequence encodeForRewrite(CharSequence input) {
/* 881 */     StringBuilder result = null;
/* 882 */     int pos = 0;
/* 883 */     int mark = 0;
/* 884 */     while (pos < input.length()) {
/* 885 */       char c = input.charAt(pos);
/* 886 */       if (c == '%' || c == ';' || c == '?') {
/* 887 */         if (result == null) {
/* 888 */           result = new StringBuilder((int)(input.length() * 1.1D));
/*     */         }
/* 890 */         result.append(input.subSequence(mark, pos));
/* 891 */         result.append('%');
/* 892 */         result.append(Character.forDigit(c >> 4 & 0xF, 16));
/* 893 */         result.append(Character.forDigit(c & 0xF, 16));
/* 894 */         mark = pos + 1;
/*     */       } 
/* 896 */       pos++;
/*     */     } 
/* 898 */     if (result != null) {
/* 899 */       result.append(input.subSequence(mark, input.length()));
/* 900 */       return result;
/*     */     } 
/* 902 */     return input;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\rewrite\RewriteValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */