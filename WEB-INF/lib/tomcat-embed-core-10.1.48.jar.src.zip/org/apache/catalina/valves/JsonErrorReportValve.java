package org.apache.catalina.valves;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;

public class JsonErrorReportValve extends ErrorReportValve {
  protected void report(Request request, Response response, Throwable throwable) {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual getStatus : ()I
    //   4: istore #4
    //   6: iload #4
    //   8: sipush #400
    //   11: if_icmplt -> 30
    //   14: aload_2
    //   15: invokevirtual getContentWritten : ()J
    //   18: lconst_0
    //   19: lcmp
    //   20: ifgt -> 30
    //   23: aload_2
    //   24: invokevirtual setErrorReported : ()Z
    //   27: ifne -> 31
    //   30: return
    //   31: new java/util/concurrent/atomic/AtomicBoolean
    //   34: dup
    //   35: iconst_0
    //   36: invokespecial <init> : (Z)V
    //   39: astore #5
    //   41: aload_2
    //   42: invokevirtual getCoyoteResponse : ()Lorg/apache/coyote/Response;
    //   45: getstatic org/apache/coyote/ActionCode.IS_IO_ALLOWED : Lorg/apache/coyote/ActionCode;
    //   48: aload #5
    //   50: invokevirtual action : (Lorg/apache/coyote/ActionCode;Ljava/lang/Object;)V
    //   53: aload #5
    //   55: invokevirtual get : ()Z
    //   58: ifne -> 62
    //   61: return
    //   62: ldc 'org.apache.catalina.valves'
    //   64: aload_1
    //   65: invokevirtual getLocales : ()Ljava/util/Enumeration;
    //   68: invokestatic getManager : (Ljava/lang/String;Ljava/util/Enumeration;)Lorg/apache/tomcat/util/res/StringManager;
    //   71: astore #6
    //   73: aload_2
    //   74: aload #6
    //   76: invokevirtual getLocale : ()Ljava/util/Locale;
    //   79: invokevirtual setLocale : (Ljava/util/Locale;)V
    //   82: aload_3
    //   83: ifnull -> 98
    //   86: aload #6
    //   88: ldc 'errorReportValve.exceptionReport'
    //   90: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   93: astore #7
    //   95: goto -> 107
    //   98: aload #6
    //   100: ldc 'errorReportValve.statusReport'
    //   102: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   105: astore #7
    //   107: aload_2
    //   108: invokevirtual getMessage : ()Ljava/lang/String;
    //   111: astore #8
    //   113: aload #8
    //   115: ifnonnull -> 128
    //   118: aload_3
    //   119: ifnull -> 128
    //   122: aload_3
    //   123: invokevirtual getMessage : ()Ljava/lang/String;
    //   126: astore #8
    //   128: aload #8
    //   130: ifnonnull -> 137
    //   133: ldc ''
    //   135: astore #8
    //   137: aload #6
    //   139: iload #4
    //   141: <illegal opcode> makeConcatWithConstants : (I)Ljava/lang/String;
    //   146: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   149: astore #9
    //   151: aload #9
    //   153: ifnonnull -> 174
    //   156: aload #8
    //   158: invokevirtual isEmpty : ()Z
    //   161: ifeq -> 165
    //   164: return
    //   165: aload #6
    //   167: ldc 'errorReportValve.noDescription'
    //   169: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   172: astore #9
    //   174: new java/lang/StringBuilder
    //   177: dup
    //   178: invokespecial <init> : ()V
    //   181: astore #10
    //   183: aload #10
    //   185: ldc '{\\n  "type": "'
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: aload #7
    //   192: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: ldc '",\\n'
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload #10
    //   206: ldc '  "status": '
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: iload #4
    //   213: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   216: ldc ',\\n'
    //   218: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   221: pop
    //   222: aload #10
    //   224: ldc '  "message": "'
    //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: aload #8
    //   231: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
    //   234: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   237: ldc '",\\n'
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload #10
    //   245: ldc '  "description": "'
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: aload #9
    //   252: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: pop
    //   259: aload_3
    //   260: ifnull -> 481
    //   263: aload #10
    //   265: ldc '",\\n'
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: pop
    //   271: aload #10
    //   273: ldc '  "throwable": ['
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: iconst_1
    //   280: istore #11
    //   282: iload #11
    //   284: ifne -> 298
    //   287: aload #10
    //   289: bipush #44
    //   291: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   294: pop
    //   295: goto -> 301
    //   298: iconst_0
    //   299: istore #11
    //   301: aload #10
    //   303: bipush #34
    //   305: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   308: aload_3
    //   309: invokevirtual toString : ()Ljava/lang/String;
    //   312: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
    //   315: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   318: bipush #34
    //   320: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   323: pop
    //   324: aload_3
    //   325: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   328: astore #12
    //   330: aload #12
    //   332: arraylength
    //   333: istore #13
    //   335: aload #12
    //   337: arraylength
    //   338: iconst_1
    //   339: isub
    //   340: istore #14
    //   342: iload #14
    //   344: iflt -> 392
    //   347: aload #12
    //   349: iload #14
    //   351: aaload
    //   352: invokevirtual getClassName : ()Ljava/lang/String;
    //   355: ldc 'org.apache.catalina.core.ApplicationFilterChain'
    //   357: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   360: ifeq -> 386
    //   363: aload #12
    //   365: iload #14
    //   367: aaload
    //   368: invokevirtual getMethodName : ()Ljava/lang/String;
    //   371: ldc 'internalDoFilter'
    //   373: invokevirtual equals : (Ljava/lang/Object;)Z
    //   376: ifeq -> 386
    //   379: iload #14
    //   381: istore #13
    //   383: goto -> 392
    //   386: iinc #14, -1
    //   389: goto -> 342
    //   392: iconst_0
    //   393: istore #14
    //   395: iload #14
    //   397: iload #13
    //   399: if_icmpge -> 461
    //   402: aload #12
    //   404: iload #14
    //   406: aaload
    //   407: invokevirtual getClassName : ()Ljava/lang/String;
    //   410: ldc 'org.apache.catalina.core.'
    //   412: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   415: ifne -> 455
    //   418: aload #10
    //   420: bipush #44
    //   422: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   425: bipush #34
    //   427: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   430: bipush #32
    //   432: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   435: aload #12
    //   437: iload #14
    //   439: aaload
    //   440: invokevirtual toString : ()Ljava/lang/String;
    //   443: invokestatic escape : (Ljava/lang/String;)Ljava/lang/String;
    //   446: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   449: bipush #34
    //   451: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   454: pop
    //   455: iinc #14, 1
    //   458: goto -> 395
    //   461: aload_3
    //   462: invokevirtual getCause : ()Ljava/lang/Throwable;
    //   465: astore_3
    //   466: aload_3
    //   467: ifnonnull -> 282
    //   470: aload #10
    //   472: ldc ']\\n}'
    //   474: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   477: pop
    //   478: goto -> 489
    //   481: aload #10
    //   483: ldc '"\\n}'
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: pop
    //   489: aload_2
    //   490: ldc 'application/json'
    //   492: invokevirtual setContentType : (Ljava/lang/String;)V
    //   495: aload_2
    //   496: ldc 'utf-8'
    //   498: invokevirtual setCharacterEncoding : (Ljava/lang/String;)V
    //   501: goto -> 552
    //   504: astore #11
    //   506: aload #11
    //   508: invokestatic handleThrowable : (Ljava/lang/Throwable;)V
    //   511: aload_0
    //   512: getfield container : Lorg/apache/catalina/Container;
    //   515: invokeinterface getLogger : ()Lorg/apache/juli/logging/Log;
    //   520: invokeinterface isDebugEnabled : ()Z
    //   525: ifeq -> 552
    //   528: aload_0
    //   529: getfield container : Lorg/apache/catalina/Container;
    //   532: invokeinterface getLogger : ()Lorg/apache/juli/logging/Log;
    //   537: getstatic org/apache/catalina/valves/JsonErrorReportValve.sm : Lorg/apache/tomcat/util/res/StringManager;
    //   540: ldc 'errorReportValve.contentTypeFail'
    //   542: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   545: aload #11
    //   547: invokeinterface debug : (Ljava/lang/Object;Ljava/lang/Throwable;)V
    //   552: aload_2
    //   553: invokevirtual getReporter : ()Ljava/io/PrintWriter;
    //   556: astore #11
    //   558: aload #11
    //   560: ifnull -> 577
    //   563: aload #11
    //   565: aload #10
    //   567: invokevirtual toString : ()Ljava/lang/String;
    //   570: invokevirtual write : (Ljava/lang/String;)V
    //   573: aload_2
    //   574: invokevirtual finishResponse : ()V
    //   577: goto -> 582
    //   580: astore #11
    //   582: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #43	-> 0
    //   #49	-> 6
    //   #50	-> 30
    //   #55	-> 31
    //   #56	-> 41
    //   #57	-> 53
    //   #58	-> 61
    //   #61	-> 62
    //   #62	-> 73
    //   #64	-> 82
    //   #65	-> 86
    //   #67	-> 98
    //   #69	-> 107
    //   #70	-> 113
    //   #71	-> 122
    //   #73	-> 128
    //   #74	-> 133
    //   #76	-> 137
    //   #77	-> 151
    //   #78	-> 156
    //   #79	-> 164
    //   #81	-> 165
    //   #84	-> 174
    //   #85	-> 183
    //   #86	-> 204
    //   #87	-> 222
    //   #88	-> 243
    //   #90	-> 259
    //   #91	-> 263
    //   #94	-> 271
    //   #95	-> 279
    //   #97	-> 282
    //   #98	-> 287
    //   #100	-> 298
    //   #102	-> 301
    //   #104	-> 324
    //   #105	-> 330
    //   #106	-> 335
    //   #107	-> 347
    //   #108	-> 368
    //   #109	-> 379
    //   #110	-> 383
    //   #106	-> 386
    //   #113	-> 392
    //   #114	-> 402
    //   #115	-> 418
    //   #116	-> 451
    //   #113	-> 455
    //   #120	-> 461
    //   #121	-> 466
    //   #122	-> 470
    //   #124	-> 478
    //   #125	-> 481
    //   #130	-> 489
    //   #131	-> 495
    //   #137	-> 501
    //   #132	-> 504
    //   #133	-> 506
    //   #134	-> 511
    //   #135	-> 528
    //   #138	-> 552
    //   #139	-> 558
    //   #140	-> 563
    //   #141	-> 573
    //   #145	-> 577
    //   #143	-> 580
    //   #146	-> 582
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   95	3	7	type	Ljava/lang/String;
    //   342	50	14	i	I
    //   395	66	14	i	I
    //   330	136	12	elements	[Ljava/lang/StackTraceElement;
    //   335	131	13	pos	I
    //   282	196	11	first	Z
    //   506	46	11	t	Ljava/lang/Throwable;
    //   558	19	11	writer	Ljava/io/Writer;
    //   0	583	0	this	Lorg/apache/catalina/valves/JsonErrorReportValve;
    //   0	583	1	request	Lorg/apache/catalina/connector/Request;
    //   0	583	2	response	Lorg/apache/catalina/connector/Response;
    //   0	583	3	throwable	Ljava/lang/Throwable;
    //   6	577	4	statusCode	I
    //   41	542	5	result	Ljava/util/concurrent/atomic/AtomicBoolean;
    //   73	510	6	smClient	Lorg/apache/tomcat/util/res/StringManager;
    //   107	476	7	type	Ljava/lang/String;
    //   113	470	8	message	Ljava/lang/String;
    //   151	432	9	description	Ljava/lang/String;
    //   183	400	10	sb	Ljava/lang/StringBuilder;
    // Exception table:
    //   from	to	target	type
    //   489	501	504	java/lang/Throwable
    //   489	577	580	java/io/IOException
    //   489	577	580	java/lang/IllegalStateException
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\JsonErrorReportValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */