/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValveBase
/*     */   extends LifecycleMBeanBase
/*     */   implements Contained, Valve
/*     */ {
/*  37 */   protected static final StringManager sm = StringManager.getManager(ValveBase.class);
/*     */   
/*     */   protected boolean asyncSupported;
/*     */   protected Container container;
/*     */   
/*     */   public ValveBase() {
/*  43 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log containerLog;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Valve next;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValveBase(boolean asyncSupported) {
/*  63 */     this.container = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.containerLog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.next = null;
/*     */     this.asyncSupported = asyncSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/*  82 */     return this.container;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Container container) {
/*  88 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsyncSupported() {
/*  94 */     return this.asyncSupported;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported) {
/*  99 */     this.asyncSupported = asyncSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Valve getNext() {
/* 105 */     return this.next;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNext(Valve valve) {
/* 111 */     this.next = valve;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void backgroundProcess() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 130 */     super.initInternal();
/* 131 */     this.containerLog = getContainer().getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 144 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 157 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return ToStringUtil.toString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getObjectNameKeyProperties() {
/* 171 */     StringBuilder name = new StringBuilder("type=Valve");
/*     */     
/* 173 */     Container container = getContainer();
/*     */     
/* 175 */     name.append(container.getMBeanKeyProperties());
/*     */     
/* 177 */     int seq = 0;
/*     */ 
/*     */     
/* 180 */     Pipeline p = container.getPipeline();
/* 181 */     if (p != null) {
/* 182 */       for (Valve valve : p.getValves()) {
/*     */         
/* 184 */         if (valve != null) {
/*     */ 
/*     */ 
/*     */           
/* 188 */           if (valve == this) {
/*     */             break;
/*     */           }
/* 191 */           if (valve.getClass() == getClass())
/*     */           {
/*     */             
/* 194 */             seq++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 199 */     if (seq > 0) {
/* 200 */       name.append(",seq=");
/* 201 */       name.append(seq);
/*     */     } 
/*     */     
/* 204 */     String className = getClass().getName();
/* 205 */     int period = className.lastIndexOf('.');
/* 206 */     if (period >= 0) {
/* 207 */       className = className.substring(period + 1);
/*     */     }
/* 209 */     name.append(",name=");
/* 210 */     name.append(className);
/*     */     
/* 212 */     return name.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDomainInternal() {
/* 218 */     Container c = getContainer();
/* 219 */     if (c == null) {
/* 220 */       return null;
/*     */     }
/* 222 */     return c.getDomain();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\ValveBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */