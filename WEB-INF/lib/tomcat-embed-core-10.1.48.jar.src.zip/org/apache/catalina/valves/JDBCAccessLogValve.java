/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import org.apache.catalina.AccessLog;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JDBCAccessLogValve
/*     */   extends ValveBase
/*     */   implements AccessLog
/*     */ {
/*     */   protected boolean useLongContentLength;
/*     */   protected String connectionName;
/*     */   protected String connectionPassword;
/*     */   protected Driver driver;
/*     */   protected String driverName;
/*     */   protected String connectionURL;
/*     */   protected String tableName;
/*     */   protected String remoteHostField;
/*     */   protected String userField;
/*     */   protected String timestampField;
/*     */   protected String virtualHostField;
/*     */   protected String methodField;
/*     */   protected String queryField;
/*     */   protected String statusField;
/*     */   protected String bytesField;
/*     */   protected String refererField;
/*     */   protected String userAgentField;
/*     */   protected String pattern;
/*     */   protected boolean resolveHosts;
/*     */   protected Connection conn;
/*     */   protected PreparedStatement ps;
/*     */   protected long currentTimeMillis;
/*     */   protected boolean requestAttributesEnabled;
/*     */   
/*     */   public JDBCAccessLogValve() {
/* 130 */     super(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     this.useLongContentLength = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     this.connectionName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     this.connectionPassword = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     this.driver = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     this.requestAttributesEnabled = true; this.driverName = null; this.connectionURL = null; this.tableName = "access"; this.remoteHostField = "remoteHost"; this.userField = "userName"; this.timestampField = "timestamp"; this.virtualHostField = "virtualHost"; this.methodField = "method";
/*     */     this.queryField = "query";
/*     */     this.statusField = "status";
/*     */     this.bytesField = "bytes";
/*     */     this.refererField = "referer";
/*     */     this.userAgentField = "userAgent";
/*     */     this.pattern = "common";
/*     */     this.resolveHosts = false;
/*     */     this.conn = null;
/*     */     this.ps = null;
/* 217 */     this.currentTimeMillis = (new Date()).getTime(); } public void setRequestAttributesEnabled(boolean requestAttributesEnabled) { this.requestAttributesEnabled = requestAttributesEnabled; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRequestAttributesEnabled() {
/* 222 */     return this.requestAttributesEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionName() {
/* 229 */     return this.connectionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionName(String connectionName) {
/* 238 */     this.connectionName = connectionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDriverName(String driverName) {
/* 247 */     this.driverName = driverName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionPassword() {
/* 254 */     return this.connectionPassword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionPassword(String connectionPassword) {
/* 263 */     this.connectionPassword = connectionPassword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionURL(String connectionURL) {
/* 272 */     this.connectionURL = connectionURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableName(String tableName) {
/* 282 */     this.tableName = tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteHostField(String remoteHostField) {
/* 292 */     this.remoteHostField = remoteHostField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserField(String userField) {
/* 302 */     this.userField = userField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimestampField(String timestampField) {
/* 312 */     this.timestampField = timestampField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVirtualHostField(String virtualHostField) {
/* 322 */     this.virtualHostField = virtualHostField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethodField(String methodField) {
/* 332 */     this.methodField = methodField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQueryField(String queryField) {
/* 342 */     this.queryField = queryField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusField(String statusField) {
/* 352 */     this.statusField = statusField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBytesField(String bytesField) {
/* 362 */     this.bytesField = bytesField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRefererField(String refererField) {
/* 372 */     this.refererField = refererField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserAgentField(String userAgentField) {
/* 382 */     this.userAgentField = userAgentField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern) {
/* 396 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolveHosts(String resolveHosts) {
/* 406 */     this.resolveHosts = Boolean.parseBoolean(resolveHosts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUseLongContentLength() {
/* 414 */     return this.useLongContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseLongContentLength(boolean useLongContentLength) {
/* 421 */     this.useLongContentLength = useLongContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 429 */     getNext().invoke(request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Request request, Response response, long time) {
/*     */     String remoteHost;
/* 435 */     if (!getState().isAvailable()) {
/*     */       return;
/*     */     }
/*     */     
/* 439 */     String EMPTY = "";
/*     */ 
/*     */     
/* 442 */     if (this.resolveHosts) {
/* 443 */       if (this.requestAttributesEnabled) {
/* 444 */         Object host = request.getAttribute("org.apache.catalina.AccessLog.RemoteHost");
/* 445 */         if (host == null) {
/* 446 */           remoteHost = request.getRemoteHost();
/*     */         } else {
/* 448 */           remoteHost = (String)host;
/*     */         } 
/*     */       } else {
/* 451 */         remoteHost = request.getRemoteHost();
/*     */       }
/*     */     
/* 454 */     } else if (this.requestAttributesEnabled) {
/* 455 */       Object addr = request.getAttribute("org.apache.catalina.AccessLog.RemoteAddr");
/* 456 */       if (addr == null) {
/* 457 */         remoteHost = request.getRemoteAddr();
/*     */       } else {
/* 459 */         remoteHost = (String)addr;
/*     */       } 
/*     */     } else {
/* 462 */       remoteHost = request.getRemoteAddr();
/*     */     } 
/*     */     
/* 465 */     String user = request.getRemoteUser();
/* 466 */     String query = request.getRequestURI();
/*     */     
/* 468 */     long bytes = response.getBytesWritten(true);
/* 469 */     if (bytes < 0L) {
/* 470 */       bytes = 0L;
/*     */     }
/* 472 */     int status = response.getStatus();
/* 473 */     String virtualHost = "";
/* 474 */     String method = "";
/* 475 */     String referer = "";
/* 476 */     String userAgent = "";
/* 477 */     String logPattern = this.pattern;
/* 478 */     if (logPattern.equals("combined")) {
/* 479 */       virtualHost = request.getServerName();
/* 480 */       method = request.getMethod();
/* 481 */       referer = request.getHeader("referer");
/* 482 */       userAgent = request.getHeader("user-agent");
/*     */     } 
/* 484 */     synchronized (this) {
/* 485 */       int numberOfTries = 2;
/* 486 */       while (numberOfTries > 0) {
/*     */         try {
/* 488 */           open();
/*     */           
/* 490 */           this.ps.setString(1, remoteHost);
/* 491 */           this.ps.setString(2, user);
/* 492 */           this.ps.setTimestamp(3, new Timestamp(getCurrentTimeMillis()));
/* 493 */           this.ps.setString(4, query);
/* 494 */           this.ps.setInt(5, status);
/*     */           
/* 496 */           if (this.useLongContentLength) {
/* 497 */             this.ps.setLong(6, bytes);
/*     */           } else {
/* 499 */             if (bytes > 2147483647L) {
/* 500 */               bytes = -1L;
/*     */             }
/* 502 */             this.ps.setInt(6, (int)bytes);
/*     */           } 
/* 504 */           if (logPattern.equals("combined")) {
/* 505 */             this.ps.setString(7, virtualHost);
/* 506 */             this.ps.setString(8, method);
/* 507 */             this.ps.setString(9, referer);
/* 508 */             this.ps.setString(10, userAgent);
/*     */           } 
/* 510 */           this.ps.executeUpdate();
/*     */           return;
/* 512 */         } catch (SQLException e) {
/*     */           
/* 514 */           this.container.getLogger().error(sm.getString("jdbcAccessLogValve.exception"), e);
/*     */ 
/*     */           
/* 517 */           if (this.conn != null) {
/* 518 */             close();
/*     */           }
/*     */           
/* 521 */           numberOfTries--;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void open() throws SQLException {
/* 536 */     if (this.conn != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 541 */     if (this.driver == null) {
/*     */       try {
/* 543 */         Class<?> clazz = Class.forName(this.driverName);
/* 544 */         this.driver = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 545 */       } catch (Throwable e) {
/* 546 */         ExceptionUtils.handleThrowable(e);
/* 547 */         throw new SQLException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 552 */     Properties props = new Properties();
/* 553 */     if (this.connectionName != null) {
/* 554 */       props.put("user", this.connectionName);
/*     */     }
/* 556 */     if (this.connectionPassword != null) {
/* 557 */       props.put("password", this.connectionPassword);
/*     */     }
/* 559 */     this.conn = this.driver.connect(this.connectionURL, props);
/* 560 */     this.conn.setAutoCommit(true);
/* 561 */     prepare();
/* 562 */     String logPattern = this.pattern;
/* 563 */     if (logPattern.equals("common")) {
/* 564 */       this.ps = this.conn.prepareStatement("INSERT INTO " + this.tableName + " (" + this.remoteHostField + ", " + this.userField + ", " + this.timestampField + ", " + this.queryField + ", " + this.statusField + ", " + this.bytesField + ") VALUES(?, ?, ?, ?, ?, ?)");
/*     */     
/*     */     }
/* 567 */     else if (logPattern.equals("combined")) {
/* 568 */       this.ps = this.conn.prepareStatement("INSERT INTO " + this.tableName + " (" + this.remoteHostField + ", " + this.userField + ", " + this.timestampField + ", " + this.queryField + ", " + this.statusField + ", " + this.bytesField + ", " + this.virtualHostField + ", " + this.methodField + ", " + this.refererField + ", " + this.userAgentField + ") VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepare() throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void close() {
/* 591 */     if (this.conn == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 597 */       this.ps.close();
/* 598 */     } catch (Throwable f) {
/* 599 */       ExceptionUtils.handleThrowable(f);
/*     */     } 
/* 601 */     this.ps = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 606 */       this.conn.close();
/* 607 */     } catch (SQLException e) {
/* 608 */       this.container.getLogger().error(sm.getString("jdbcAccessLogValve.close"), e);
/*     */     } finally {
/* 610 */       this.conn = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/*     */     try {
/* 626 */       open();
/* 627 */     } catch (SQLException e) {
/* 628 */       throw new LifecycleException(e);
/*     */     } 
/* 630 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 643 */     super.stopInternal();
/* 644 */     close();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCurrentTimeMillis() {
/* 649 */     long systime = System.currentTimeMillis();
/* 650 */     if (systime - this.currentTimeMillis > 1000L) {
/* 651 */       this.currentTimeMillis = (new Date(systime)).getTime();
/*     */     }
/* 653 */     return this.currentTimeMillis;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\JDBCAccessLogValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */