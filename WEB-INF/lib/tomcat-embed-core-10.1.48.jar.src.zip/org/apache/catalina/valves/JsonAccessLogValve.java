/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.tomcat.util.json.JSONFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonAccessLogValve
/*     */   extends AccessLogValve
/*     */ {
/*     */   private static final Map<Character, String> PATTERNS;
/*     */   private static final Map<Character, String> SUB_OBJECT_PATTERNS;
/*     */   
/*     */   static {
/*  78 */     Map<Character, String> pattern2AttributeName = new HashMap<>();
/*  79 */     pattern2AttributeName.put(Character.valueOf('a'), "remoteAddr");
/*  80 */     pattern2AttributeName.put(Character.valueOf('A'), "localAddr");
/*  81 */     pattern2AttributeName.put(Character.valueOf('b'), "size");
/*  82 */     pattern2AttributeName.put(Character.valueOf('B'), "byteSentNC");
/*  83 */     pattern2AttributeName.put(Character.valueOf('D'), "elapsedTime");
/*  84 */     pattern2AttributeName.put(Character.valueOf('F'), "firstByteTime");
/*  85 */     pattern2AttributeName.put(Character.valueOf('h'), "host");
/*  86 */     pattern2AttributeName.put(Character.valueOf('H'), "protocol");
/*  87 */     pattern2AttributeName.put(Character.valueOf('I'), "threadName");
/*  88 */     pattern2AttributeName.put(Character.valueOf('l'), "logicalUserName");
/*  89 */     pattern2AttributeName.put(Character.valueOf('m'), "method");
/*  90 */     pattern2AttributeName.put(Character.valueOf('p'), "port");
/*  91 */     pattern2AttributeName.put(Character.valueOf('q'), "query");
/*  92 */     pattern2AttributeName.put(Character.valueOf('r'), "request");
/*  93 */     pattern2AttributeName.put(Character.valueOf('s'), "statusCode");
/*  94 */     pattern2AttributeName.put(Character.valueOf('S'), "sessionId");
/*  95 */     pattern2AttributeName.put(Character.valueOf('t'), "time");
/*  96 */     pattern2AttributeName.put(Character.valueOf('T'), "elapsedTimeS");
/*  97 */     pattern2AttributeName.put(Character.valueOf('u'), "user");
/*  98 */     pattern2AttributeName.put(Character.valueOf('U'), "path");
/*  99 */     pattern2AttributeName.put(Character.valueOf('v'), "localServerName");
/* 100 */     pattern2AttributeName.put(Character.valueOf('X'), "connectionStatus");
/* 101 */     PATTERNS = Collections.unmodifiableMap(pattern2AttributeName);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     pattern2AttributeName = new HashMap<>();
/* 107 */     pattern2AttributeName.put(Character.valueOf('c'), "cookies");
/* 108 */     pattern2AttributeName.put(Character.valueOf('i'), "requestHeaders");
/* 109 */     pattern2AttributeName.put(Character.valueOf('o'), "responseHeaders");
/* 110 */     pattern2AttributeName.put(Character.valueOf('r'), "requestAttributes");
/* 111 */     pattern2AttributeName.put(Character.valueOf('s'), "sessionAttributes");
/* 112 */     pattern2AttributeName.put(Character.valueOf('L'), "identifier");
/* 113 */     SUB_OBJECT_PATTERNS = Collections.unmodifiableMap(pattern2AttributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class CharElement
/*     */     implements AbstractAccessLogValve.AccessLogElement
/*     */   {
/*     */     private final char ch;
/*     */     
/*     */     public CharElement(char ch) {
/* 123 */       this.ch = ch;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addElement(CharArrayWriter buf, Request request, Response response, long time) {
/* 128 */       buf.write(this.ch);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean addSubkeyedItems(ListIterator<AbstractAccessLogValve.AccessLogElement> iterator, List<JsonWrappedElement> elements, String patternAttribute) {
/* 134 */     if (!elements.isEmpty()) {
/* 135 */       iterator.add(new AbstractAccessLogValve.StringElement("\"" + patternAttribute + "\": {"));
/* 136 */       for (JsonWrappedElement element : elements) {
/* 137 */         iterator.add(element);
/* 138 */         iterator.add(new CharElement(','));
/*     */       } 
/* 140 */       iterator.previous();
/* 141 */       iterator.remove();
/* 142 */       iterator.add(new AbstractAccessLogValve.StringElement("},"));
/* 143 */       return true;
/*     */     } 
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractAccessLogValve.AccessLogElement[] createLogElements() {
/* 150 */     Map<Character, List<JsonWrappedElement>> subTypeLists = new HashMap<>();
/* 151 */     for (Character pattern : SUB_OBJECT_PATTERNS.keySet()) {
/* 152 */       subTypeLists.put(pattern, new ArrayList<>());
/*     */     }
/* 154 */     boolean hasSub = false;
/* 155 */     List<AbstractAccessLogValve.AccessLogElement> logElements = new ArrayList<>(Arrays.asList(super.createLogElements()));
/* 156 */     ListIterator<AbstractAccessLogValve.AccessLogElement> lit = logElements.listIterator();
/* 157 */     lit.add(new CharElement('{'));
/* 158 */     while (lit.hasNext()) {
/* 159 */       AbstractAccessLogValve.AccessLogElement logElement = lit.next();
/*     */       
/* 161 */       if (!(logElement instanceof JsonWrappedElement)) {
/* 162 */         lit.remove();
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 167 */       JsonWrappedElement wrappedLogElement = (JsonWrappedElement)logElement;
/* 168 */       AbstractAccessLogValve.AccessLogElement ale = wrappedLogElement.getDelegate();
/* 169 */       if (ale instanceof AbstractAccessLogValve.HeaderElement) {
/* 170 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('i'))).add(wrappedLogElement);
/* 171 */         lit.remove(); continue;
/* 172 */       }  if (ale instanceof AbstractAccessLogValve.ResponseHeaderElement) {
/* 173 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('o'))).add(wrappedLogElement);
/* 174 */         lit.remove(); continue;
/* 175 */       }  if (ale instanceof AbstractAccessLogValve.RequestAttributeElement) {
/* 176 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('r'))).add(wrappedLogElement);
/* 177 */         lit.remove(); continue;
/* 178 */       }  if (ale instanceof AbstractAccessLogValve.SessionAttributeElement) {
/* 179 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('s'))).add(wrappedLogElement);
/* 180 */         lit.remove(); continue;
/* 181 */       }  if (ale instanceof AbstractAccessLogValve.CookieElement) {
/* 182 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('c'))).add(wrappedLogElement);
/* 183 */         lit.remove(); continue;
/* 184 */       }  if (ale instanceof AbstractAccessLogValve.IdentifierElement) {
/* 185 */         ((List<JsonWrappedElement>)subTypeLists.get(Character.valueOf('L'))).add(wrappedLogElement);
/* 186 */         lit.remove();
/*     */         continue;
/*     */       } 
/* 189 */       lit.add(new CharElement(','));
/*     */     } 
/*     */ 
/*     */     
/* 193 */     for (Character pattern : SUB_OBJECT_PATTERNS.keySet()) {
/* 194 */       if (addSubkeyedItems(lit, subTypeLists.get(pattern), SUB_OBJECT_PATTERNS.get(pattern))) {
/* 195 */         hasSub = true;
/*     */       }
/*     */     } 
/*     */     
/* 199 */     lit.previous();
/* 200 */     lit.remove();
/*     */     
/* 202 */     if (hasSub) {
/* 203 */       lit.add(new AbstractAccessLogValve.StringElement("}}"));
/*     */     } else {
/* 205 */       lit.add(new CharElement('}'));
/*     */     } 
/* 207 */     return logElements.<AbstractAccessLogValve.AccessLogElement>toArray(new AbstractAccessLogValve.AccessLogElement[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractAccessLogValve.AccessLogElement createAccessLogElement(String name, char pattern) {
/* 212 */     AbstractAccessLogValve.AccessLogElement ale = super.createAccessLogElement(name, pattern);
/* 213 */     return new JsonWrappedElement(pattern, name, true, ale);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractAccessLogValve.AccessLogElement createAccessLogElement(char pattern) {
/* 218 */     AbstractAccessLogValve.AccessLogElement ale = super.createAccessLogElement(pattern);
/* 219 */     return new JsonWrappedElement(pattern, true, ale);
/*     */   }
/*     */   
/*     */   private static class JsonWrappedElement
/*     */     implements AbstractAccessLogValve.AccessLogElement, AbstractAccessLogValve.CachedElement {
/*     */     private final CharSequence attributeName;
/*     */     private final boolean quoteValue;
/*     */     private final AbstractAccessLogValve.AccessLogElement delegate;
/*     */     
/*     */     private CharSequence escapeJsonString(CharSequence nonEscaped) {
/* 229 */       return JSONFilter.escape(nonEscaped);
/*     */     }
/*     */     
/*     */     JsonWrappedElement(char pattern, String key, boolean quoteValue, AbstractAccessLogValve.AccessLogElement delegate) {
/* 233 */       this.quoteValue = quoteValue;
/* 234 */       this.delegate = delegate;
/* 235 */       String patternAttribute = JsonAccessLogValve.PATTERNS.get(Character.valueOf(pattern));
/* 236 */       if (patternAttribute == null) {
/* 237 */         patternAttribute = "other-" + Character.toString(pattern);
/*     */       }
/* 239 */       if (key != null && !key.isEmpty()) {
/* 240 */         if (JsonAccessLogValve.SUB_OBJECT_PATTERNS.containsKey(Character.valueOf(pattern))) {
/* 241 */           this.attributeName = escapeJsonString(key);
/*     */         } else {
/* 243 */           this.attributeName = escapeJsonString(patternAttribute + "-" + patternAttribute);
/*     */         } 
/*     */       } else {
/* 246 */         this.attributeName = escapeJsonString(patternAttribute);
/*     */       } 
/*     */     }
/*     */     
/*     */     JsonWrappedElement(char pattern, boolean quoteValue, AbstractAccessLogValve.AccessLogElement delegate) {
/* 251 */       this(pattern, null, quoteValue, delegate);
/*     */     }
/*     */     
/*     */     public AbstractAccessLogValve.AccessLogElement getDelegate() {
/* 255 */       return this.delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addElement(CharArrayWriter buf, Request request, Response response, long time) {
/* 260 */       buf.append('"').append(this.attributeName).append('"').append(':');
/* 261 */       if (this.quoteValue) {
/* 262 */         buf.append('"');
/*     */       }
/* 264 */       this.delegate.addElement(buf, request, response, time);
/* 265 */       if (this.quoteValue) {
/* 266 */         buf.append('"');
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cache(Request request) {
/* 272 */       if (this.delegate instanceof AbstractAccessLogValve.CachedElement)
/* 273 */         ((AbstractAccessLogValve.CachedElement)this.delegate).cache(request); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\JsonAccessLogValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */