/*    */ package org.apache.catalina.valves;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.io.IOException;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class RemoteAddrValve
/*    */   extends RequestFilterValve
/*    */ {
/* 39 */   private static final Log log = LogFactory.getLog(RemoteAddrValve.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*    */     String property;
/* 47 */     if (getUsePeerAddress()) {
/* 48 */       property = request.getPeerAddr();
/*    */     } else {
/* 50 */       property = request.getRequest().getRemoteAddr();
/*    */     } 
/* 52 */     if (getAddConnectorPort()) {
/* 53 */       property = property + ";" + property;
/*    */     }
/* 55 */     process(property, request, response);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 61 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\RemoteAddrValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */