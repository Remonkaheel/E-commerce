/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLValve
/*     */   extends ValveBase
/*     */ {
/*  66 */   private static final Log log = LogFactory.getLog(SSLValve.class);
/*     */   
/*  68 */   private String sslClientCertHeader = "ssl_client_cert";
/*  69 */   private String sslClientEscapedCertHeader = "ssl_client_escaped_cert";
/*  70 */   private String sslCipherHeader = "ssl_cipher";
/*  71 */   private String sslSessionIdHeader = "ssl_session_id";
/*  72 */   private String sslCipherUserKeySizeHeader = "ssl_cipher_usekeysize";
/*     */ 
/*     */   
/*     */   public SSLValve() {
/*  76 */     super(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSslClientCertHeader() {
/*  81 */     return this.sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public void setSslClientCertHeader(String sslClientCertHeader) {
/*  85 */     this.sslClientCertHeader = sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public String getSslClientEscapedCertHeader() {
/*  89 */     return this.sslClientEscapedCertHeader;
/*     */   }
/*     */   
/*     */   public void setSslClientEscapedCertHeader(String sslClientEscapedCertHeader) {
/*  93 */     this.sslClientEscapedCertHeader = sslClientEscapedCertHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherHeader() {
/*  97 */     return this.sslCipherHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherHeader(String sslCipherHeader) {
/* 101 */     this.sslCipherHeader = sslCipherHeader;
/*     */   }
/*     */   
/*     */   public String getSslSessionIdHeader() {
/* 105 */     return this.sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public void setSslSessionIdHeader(String sslSessionIdHeader) {
/* 109 */     this.sslSessionIdHeader = sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherUserKeySizeHeader() {
/* 113 */     return this.sslCipherUserKeySizeHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherUserKeySizeHeader(String sslCipherUserKeySizeHeader) {
/* 117 */     this.sslCipherUserKeySizeHeader = sslCipherUserKeySizeHeader;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mygetHeader(Request request, String header) {
/* 122 */     String strcert0 = request.getHeader(header);
/* 123 */     if (strcert0 == null) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     if ("(null)".equals(strcert0)) {
/* 128 */       return null;
/*     */     }
/* 130 */     return strcert0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 148 */     String headerEscapedValue = mygetHeader(request, this.sslClientEscapedCertHeader);
/* 149 */     if (headerEscapedValue != null) {
/* 150 */       headerValue = UDecoder.URLDecode(headerEscapedValue, null);
/*     */     } else {
/* 152 */       headerValue = mygetHeader(request, this.sslClientCertHeader);
/*     */     } 
/* 154 */     if (headerValue != null) {
/* 155 */       headerValue = headerValue.trim();
/* 156 */       if (headerValue.length() > 27) {
/* 157 */         String body = headerValue.substring(27);
/* 158 */         String header = "-----BEGIN CERTIFICATE-----\n";
/* 159 */         String strcerts = header.concat(body);
/* 160 */         ByteArrayInputStream bais = new ByteArrayInputStream(strcerts.getBytes(StandardCharsets.ISO_8859_1));
/* 161 */         X509Certificate[] jsseCerts = null;
/* 162 */         String providerName = (String)request.getConnector().getProperty("clientCertProvider");
/*     */         try {
/*     */           CertificateFactory cf;
/* 165 */           if (providerName == null) {
/* 166 */             cf = CertificateFactory.getInstance("X.509");
/*     */           } else {
/* 168 */             cf = CertificateFactory.getInstance("X.509", providerName);
/*     */           } 
/* 170 */           X509Certificate cert = (X509Certificate)cf.generateCertificate(bais);
/* 171 */           jsseCerts = new X509Certificate[1];
/* 172 */           jsseCerts[0] = cert;
/* 173 */         } catch (CertificateException e) {
/* 174 */           log.warn(sm.getString("sslValve.certError", new Object[] { strcerts }), e);
/* 175 */         } catch (NoSuchProviderException e) {
/* 176 */           log.error(sm.getString("sslValve.invalidProvider", new Object[] { providerName }), e);
/*     */         } 
/* 178 */         request.setAttribute("jakarta.servlet.request.X509Certificate", jsseCerts);
/*     */       } 
/*     */     } 
/* 181 */     String headerValue = mygetHeader(request, this.sslCipherHeader);
/* 182 */     if (headerValue != null) {
/* 183 */       request.setAttribute("jakarta.servlet.request.cipher_suite", headerValue);
/*     */     }
/* 185 */     headerValue = mygetHeader(request, this.sslSessionIdHeader);
/* 186 */     if (headerValue != null) {
/* 187 */       request.setAttribute("jakarta.servlet.request.ssl_session_id", headerValue);
/*     */     }
/* 189 */     headerValue = mygetHeader(request, this.sslCipherUserKeySizeHeader);
/* 190 */     if (headerValue != null) {
/* 191 */       request.setAttribute("jakarta.servlet.request.key_size", Integer.valueOf(headerValue));
/*     */     }
/* 193 */     getNext().invoke(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\SSLValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */