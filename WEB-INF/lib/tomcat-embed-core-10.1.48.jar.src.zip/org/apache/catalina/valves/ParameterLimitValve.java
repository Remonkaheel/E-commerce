/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterLimitValve
/*     */   extends ValveBase
/*     */ {
/*  92 */   private Map<Pattern, Integer[]> urlPatternLimits = (Map)new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private String resourcePath = "parameter_limit.config";
/*     */ 
/*     */   
/*     */   private boolean context = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterLimitValve() {
/* 106 */     super(true);
/*     */   }
/*     */   
/*     */   public String getResourcePath() {
/* 110 */     return this.resourcePath;
/*     */   }
/*     */   
/*     */   public void setResourcePath(String resourcePath) {
/* 114 */     this.resourcePath = resourcePath;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 119 */     super.initInternal();
/* 120 */     this.containerLog = LogFactory.getLog(getContainer().getLogName() + ".parameterLimit");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 126 */     super.startInternal();
/*     */     
/* 128 */     InputStream is = null;
/*     */ 
/*     */     
/* 131 */     if (getContainer() instanceof Context) {
/* 132 */       this.context = true;
/* 133 */       String webInfResourcePath = "/WEB-INF/" + this.resourcePath;
/* 134 */       is = ((Context)getContainer()).getServletContext().getResourceAsStream(webInfResourcePath);
/* 135 */       if (this.containerLog.isDebugEnabled()) {
/* 136 */         if (is == null) {
/* 137 */           this.containerLog.debug(sm.getString("parameterLimitValve.noConfiguration", new Object[] { webInfResourcePath }));
/*     */         } else {
/* 139 */           this.containerLog.debug(sm.getString("parameterLimitValve.readConfiguration", new Object[] { webInfResourcePath }));
/*     */         } 
/*     */       }
/*     */     } else {
/* 143 */       String resourceName = Container.getConfigPath(getContainer(), this.resourcePath);
/*     */       try {
/* 145 */         ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getResource(resourceName);
/* 146 */         is = resource.getInputStream();
/* 147 */       } catch (IOException ioe) {
/* 148 */         if (this.containerLog.isDebugEnabled()) {
/* 149 */           this.containerLog.debug(sm.getString("parameterLimitValve.noConfiguration", new Object[] { resourceName }), ioe);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     if (is == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 159 */     try { InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8); 
/* 160 */       try { BufferedReader reader = new BufferedReader(isr); 
/* 161 */         try { setUrlPatternLimits(reader);
/* 162 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  isr.close(); } catch (Throwable throwable) { try { isr.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 163 */     { this.containerLog.error(sm.getString("parameterLimitValve.closeError"), ioe); }
/*     */     finally
/*     */     { try {
/* 166 */         is.close();
/* 167 */       } catch (IOException ioe) {
/* 168 */         this.containerLog.error(sm.getString("parameterLimitValve.closeError"), ioe);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUrlPatternLimits(String urlPatternConfig) {
/* 175 */     this.urlPatternLimits.clear();
/* 176 */     setUrlPatternLimits(new BufferedReader(new StringReader(urlPatternConfig)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrlPatternLimits(BufferedReader reader) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   4: ifnonnull -> 35
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual getContainer : ()Lorg/apache/catalina/Container;
/*     */     //   11: ifnull -> 35
/*     */     //   14: aload_0
/*     */     //   15: aload_0
/*     */     //   16: invokevirtual getContainer : ()Lorg/apache/catalina/Container;
/*     */     //   19: invokeinterface getLogName : ()Ljava/lang/String;
/*     */     //   24: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   29: invokestatic getLog : (Ljava/lang/String;)Lorg/apache/juli/logging/Log;
/*     */     //   32: putfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   39: dup
/*     */     //   40: astore_2
/*     */     //   41: ifnull -> 317
/*     */     //   44: aload_2
/*     */     //   45: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   48: astore_2
/*     */     //   49: aload_2
/*     */     //   50: invokevirtual isEmpty : ()Z
/*     */     //   53: ifne -> 35
/*     */     //   56: aload_2
/*     */     //   57: ldc '#'
/*     */     //   59: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   62: ifeq -> 68
/*     */     //   65: goto -> 35
/*     */     //   68: aload_2
/*     */     //   69: bipush #61
/*     */     //   71: invokevirtual lastIndexOf : (I)I
/*     */     //   74: istore_3
/*     */     //   75: iload_3
/*     */     //   76: iconst_m1
/*     */     //   77: if_icmpne -> 104
/*     */     //   80: new java/lang/IllegalArgumentException
/*     */     //   83: dup
/*     */     //   84: getstatic org/apache/catalina/valves/ParameterLimitValve.sm : Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   87: ldc 'parameterLimitValve.invalidLine'
/*     */     //   89: iconst_1
/*     */     //   90: anewarray java/lang/Object
/*     */     //   93: dup
/*     */     //   94: iconst_0
/*     */     //   95: aload_2
/*     */     //   96: aastore
/*     */     //   97: invokevirtual getString : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   100: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   103: athrow
/*     */     //   104: aload_2
/*     */     //   105: iconst_0
/*     */     //   106: iload_3
/*     */     //   107: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   110: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   113: astore #4
/*     */     //   115: aload_2
/*     */     //   116: iload_3
/*     */     //   117: iconst_1
/*     */     //   118: iadd
/*     */     //   119: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   122: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   125: astore #5
/*     */     //   127: aload #4
/*     */     //   129: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
/*     */     //   132: invokestatic URLDecode : (Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   135: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
/*     */     //   138: astore #6
/*     */     //   140: aload #5
/*     */     //   142: ldc ','
/*     */     //   144: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   147: astore #7
/*     */     //   149: aload #7
/*     */     //   151: arraylength
/*     */     //   152: iconst_1
/*     */     //   153: if_icmpne -> 193
/*     */     //   156: aload_0
/*     */     //   157: getfield urlPatternLimits : Ljava/util/Map;
/*     */     //   160: aload #6
/*     */     //   162: iconst_3
/*     */     //   163: anewarray java/lang/Integer
/*     */     //   166: dup
/*     */     //   167: iconst_0
/*     */     //   168: aload #7
/*     */     //   170: iconst_0
/*     */     //   171: aaload
/*     */     //   172: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   175: aastore
/*     */     //   176: dup
/*     */     //   177: iconst_1
/*     */     //   178: aconst_null
/*     */     //   179: aastore
/*     */     //   180: dup
/*     */     //   181: iconst_2
/*     */     //   182: aconst_null
/*     */     //   183: aastore
/*     */     //   184: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   189: pop
/*     */     //   190: goto -> 274
/*     */     //   193: aload #7
/*     */     //   195: arraylength
/*     */     //   196: iconst_3
/*     */     //   197: if_icmpne -> 249
/*     */     //   200: aload_0
/*     */     //   201: getfield urlPatternLimits : Ljava/util/Map;
/*     */     //   204: aload #6
/*     */     //   206: iconst_3
/*     */     //   207: anewarray java/lang/Integer
/*     */     //   210: dup
/*     */     //   211: iconst_0
/*     */     //   212: aload #7
/*     */     //   214: iconst_0
/*     */     //   215: aaload
/*     */     //   216: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   219: aastore
/*     */     //   220: dup
/*     */     //   221: iconst_1
/*     */     //   222: aload #7
/*     */     //   224: iconst_1
/*     */     //   225: aaload
/*     */     //   226: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   229: aastore
/*     */     //   230: dup
/*     */     //   231: iconst_2
/*     */     //   232: aload #7
/*     */     //   234: iconst_2
/*     */     //   235: aaload
/*     */     //   236: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   239: aastore
/*     */     //   240: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   245: pop
/*     */     //   246: goto -> 274
/*     */     //   249: new java/lang/IllegalArgumentException
/*     */     //   252: dup
/*     */     //   253: getstatic org/apache/catalina/valves/ParameterLimitValve.sm : Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   256: ldc 'parameterLimitValve.invalidLimitsString'
/*     */     //   258: iconst_1
/*     */     //   259: anewarray java/lang/Object
/*     */     //   262: dup
/*     */     //   263: iconst_0
/*     */     //   264: aload #5
/*     */     //   266: aastore
/*     */     //   267: invokevirtual getString : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   270: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   273: athrow
/*     */     //   274: aload_0
/*     */     //   275: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   278: ifnull -> 314
/*     */     //   281: aload_0
/*     */     //   282: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   285: invokeinterface isTraceEnabled : ()Z
/*     */     //   290: ifeq -> 314
/*     */     //   293: aload_0
/*     */     //   294: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   297: aload #6
/*     */     //   299: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   302: aload #5
/*     */     //   304: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   309: invokeinterface trace : (Ljava/lang/Object;)V
/*     */     //   314: goto -> 35
/*     */     //   317: goto -> 346
/*     */     //   320: astore_2
/*     */     //   321: aload_0
/*     */     //   322: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   325: ifnull -> 346
/*     */     //   328: aload_0
/*     */     //   329: getfield containerLog : Lorg/apache/juli/logging/Log;
/*     */     //   332: getstatic org/apache/catalina/valves/ParameterLimitValve.sm : Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   335: ldc 'parameterLimitValve.readError'
/*     */     //   337: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   340: aload_2
/*     */     //   341: invokeinterface error : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   346: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #196	-> 0
/*     */     //   #197	-> 14
/*     */     //   #201	-> 35
/*     */     //   #203	-> 44
/*     */     //   #204	-> 49
/*     */     //   #206	-> 65
/*     */     //   #209	-> 68
/*     */     //   #210	-> 75
/*     */     //   #211	-> 80
/*     */     //   #214	-> 104
/*     */     //   #215	-> 115
/*     */     //   #217	-> 127
/*     */     //   #218	-> 140
/*     */     //   #219	-> 149
/*     */     //   #220	-> 156
/*     */     //   #221	-> 193
/*     */     //   #222	-> 200
/*     */     //   #223	-> 226
/*     */     //   #222	-> 240
/*     */     //   #225	-> 249
/*     */     //   #226	-> 267
/*     */     //   #228	-> 274
/*     */     //   #229	-> 293
/*     */     //   #231	-> 314
/*     */     //   #236	-> 317
/*     */     //   #232	-> 320
/*     */     //   #233	-> 321
/*     */     //   #234	-> 328
/*     */     //   #237	-> 346
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   75	239	3	lastEqualsIndex	I
/*     */     //   115	199	4	patternString	Ljava/lang/String;
/*     */     //   127	187	5	limitsString	Ljava/lang/String;
/*     */     //   140	174	6	pattern	Ljava/util/regex/Pattern;
/*     */     //   149	165	7	limits	[Ljava/lang/String;
/*     */     //   41	276	2	line	Ljava/lang/String;
/*     */     //   321	25	2	ioe	Ljava/io/IOException;
/*     */     //   0	347	0	this	Lorg/apache/catalina/valves/ParameterLimitValve;
/*     */     //   0	347	1	reader	Ljava/io/BufferedReader;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   35	317	320	java/io/IOException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 241 */     super.stopInternal();
/* 242 */     this.urlPatternLimits.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 258 */     if (this.urlPatternLimits.isEmpty()) {
/* 259 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/* 263 */     String requestURI = this.context ? request.getRequestPathMB().toString() : request.getDecodedRequestURI();
/*     */ 
/*     */     
/* 266 */     for (Map.Entry<Pattern, Integer[]> entry : this.urlPatternLimits.entrySet()) {
/* 267 */       if (((Pattern)entry.getKey()).matcher(requestURI).matches()) {
/* 268 */         Integer[] limits = entry.getValue();
/*     */         
/* 270 */         request.setMaxParameterCount(limits[0].intValue());
/* 271 */         if (limits[1] != null) {
/* 272 */           request.setMaxPartCount(limits[1].intValue());
/* 273 */           request.setMaxPartHeaderSize(limits[2].intValue());
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 280 */     getNext().invoke(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\ParameterLimitValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */