/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestFilterValve
/*     */   extends ValveBase
/*     */ {
/*     */   protected volatile Pattern allow;
/*     */   protected volatile String allowValue;
/*     */   protected volatile boolean allowValid;
/*     */   protected volatile Pattern deny;
/*     */   protected volatile String denyValue;
/*     */   protected volatile boolean denyValid;
/*     */   protected int denyStatus;
/*     */   private boolean invalidAuthenticationWhenDeny;
/*     */   private volatile boolean addConnectorPort;
/*     */   private volatile boolean usePeerAddress;
/*     */   
/*     */   public RequestFilterValve() {
/*  61 */     super(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.allow = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     this.allowValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     this.allowValid = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     this.deny = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.denyValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.denyValid = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.denyStatus = 403;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.invalidAuthenticationWhenDeny = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.addConnectorPort = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.usePeerAddress = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllow() {
/* 139 */     return this.allowValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllow(String allow) {
/* 149 */     if (allow == null || allow.isEmpty()) {
/* 150 */       this.allow = null;
/* 151 */       this.allowValue = null;
/* 152 */       this.allowValid = true;
/*     */     } else {
/* 154 */       boolean success = false;
/*     */       try {
/* 156 */         this.allowValue = allow;
/* 157 */         this.allow = Pattern.compile(allow);
/* 158 */         success = true;
/*     */       } finally {
/* 160 */         this.allowValid = success;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeny() {
/* 173 */     return this.denyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeny(String deny) {
/* 183 */     if (deny == null || deny.isEmpty()) {
/* 184 */       this.deny = null;
/* 185 */       this.denyValue = null;
/* 186 */       this.denyValid = true;
/*     */     } else {
/* 188 */       boolean success = false;
/*     */       try {
/* 190 */         this.denyValue = deny;
/* 191 */         this.deny = Pattern.compile(deny);
/* 192 */         success = true;
/*     */       } finally {
/* 194 */         this.denyValid = success;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAllowValid() {
/* 207 */     return this.allowValid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDenyValid() {
/* 218 */     return this.denyValid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDenyStatus() {
/* 226 */     return this.denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDenyStatus(int denyStatus) {
/* 236 */     this.denyStatus = denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getInvalidAuthenticationWhenDeny() {
/* 244 */     return this.invalidAuthenticationWhenDeny;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvalidAuthenticationWhenDeny(boolean value) {
/* 254 */     this.invalidAuthenticationWhenDeny = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAddConnectorPort() {
/* 265 */     return this.addConnectorPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAddConnectorPort(boolean addConnectorPort) {
/* 276 */     this.addConnectorPort = addConnectorPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUsePeerAddress() {
/* 287 */     return this.usePeerAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsePeerAddress(boolean usePeerAddress) {
/* 298 */     this.usePeerAddress = usePeerAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void invoke(Request paramRequest, Response paramResponse) throws IOException, ServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 323 */     super.initInternal();
/* 324 */     if (!this.allowValid || !this.denyValid) {
/* 325 */       throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 332 */     if (!this.allowValid || !this.denyValid) {
/* 333 */       throw new LifecycleException(sm.getString("requestFilterValve.configInvalid"));
/*     */     }
/* 335 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void process(String property, Request request, Response response) throws IOException, ServletException {
/* 351 */     if (isAllowed(property)) {
/* 352 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/* 356 */     if (getLog().isDebugEnabled()) {
/* 357 */       getLog().debug(sm.getString("requestFilterValve.deny", new Object[] { request.getRequestURI(), property }));
/*     */     }
/*     */ 
/*     */     
/* 361 */     denyRequest(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Log getLog();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void denyRequest(Request request, Response response) throws IOException, ServletException {
/* 381 */     if (this.invalidAuthenticationWhenDeny) {
/* 382 */       Context context = request.getContext();
/* 383 */       if (context != null && context.getPreemptiveAuthentication()) {
/* 384 */         if (request.getCoyoteRequest().getMimeHeaders().getValue("authorization") == null) {
/* 385 */           request.getCoyoteRequest().getMimeHeaders().addValue("authorization").setString("invalid");
/*     */         }
/* 387 */         getNext().invoke(request, response);
/*     */         return;
/*     */       } 
/*     */     } 
/* 391 */     response.sendError(this.denyStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String property) {
/* 406 */     Pattern deny = this.deny;
/* 407 */     Pattern allow = this.allow;
/*     */ 
/*     */     
/* 410 */     if (deny != null && deny.matcher(property).matches()) {
/* 411 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 415 */     if (allow != null && allow.matcher(property).matches()) {
/* 416 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 421 */     return (deny != null && allow == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\RequestFilterValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */