/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.Store;
/*     */ import org.apache.catalina.StoreManager;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentValve
/*     */   extends ValveBase
/*     */ {
/*  74 */   private static final ClassLoader MY_CLASSLOADER = PersistentValve.class.getClassLoader();
/*     */   
/*     */   private volatile boolean clBindRequired;
/*     */   
/*  78 */   protected Pattern filter = null;
/*     */   
/*  80 */   private final ConcurrentMap<String, UsageCountingSemaphore> sessionToSemaphoreMap = new ConcurrentHashMap<>();
/*     */   
/*     */   private boolean semaphoreFairness = true;
/*     */   
/*     */   private boolean semaphoreBlockOnAcquire = true;
/*     */   
/*     */   private boolean semaphoreAcquireUninterruptibly = true;
/*     */ 
/*     */   
/*     */   public PersistentValve() {
/*  90 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Container container) {
/*  96 */     super.setContainer(container);
/*  97 */     this.clBindRequired = (container instanceof org.apache.catalina.Engine || container instanceof org.apache.catalina.Host);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 105 */     if (isRequestWithoutSession(request.getDecodedRequestURI())) {
/* 106 */       if (this.containerLog.isTraceEnabled()) {
/* 107 */         this.containerLog.trace(sm.getString("persistentValve.requestIgnore", new Object[] { request.getDecodedRequestURI() }));
/*     */       }
/* 109 */       getNext().invoke(request, response); return;
/*     */     } 
/* 111 */     if (this.containerLog.isTraceEnabled()) {
/* 112 */       this.containerLog.trace(sm.getString("persistentValve.requestProcess", new Object[] { request.getDecodedRequestURI() }));
/*     */     }
/*     */ 
/*     */     
/* 116 */     Context context = request.getContext();
/* 117 */     if (context == null) {
/* 118 */       response.sendError(500, sm.getString("standardHost.noContext"));
/*     */       
/*     */       return;
/*     */     } 
/* 122 */     String sessionId = request.getRequestedSessionId();
/* 123 */     UsageCountingSemaphore semaphore = null;
/* 124 */     boolean mustReleaseSemaphore = true;
/*     */ 
/*     */     
/*     */     try {
/* 128 */       if (sessionId != null) {
/* 129 */         semaphore = this.sessionToSemaphoreMap.compute(sessionId, (k, v) -> (v == null) ? new UsageCountingSemaphore(this.semaphoreFairness) : v.incrementUsageCount());
/*     */         
/* 131 */         if (this.semaphoreBlockOnAcquire) {
/* 132 */           if (this.semaphoreAcquireUninterruptibly) {
/* 133 */             semaphore.acquireUninterruptibly();
/*     */           } else {
/*     */             try {
/* 136 */               semaphore.acquire();
/* 137 */             } catch (InterruptedException e) {
/* 138 */               mustReleaseSemaphore = false;
/* 139 */               onSemaphoreNotAcquired(request, response);
/* 140 */               if (this.containerLog.isDebugEnabled()) {
/* 141 */                 this.containerLog.debug(sm.getString("persistentValve.acquireInterrupted", new Object[] { request
/* 142 */                         .getDecodedRequestURI() }));
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 148 */         } else if (!semaphore.tryAcquire()) {
/* 149 */           onSemaphoreNotAcquired(request, response);
/* 150 */           if (this.containerLog.isDebugEnabled()) {
/* 151 */             this.containerLog.debug(sm
/* 152 */                 .getString("persistentValve.acquireFailed", new Object[] { request.getDecodedRequestURI() }));
/*     */           }
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 160 */       Manager manager = context.getManager();
/* 161 */       if (sessionId != null && manager instanceof StoreManager) {
/* 162 */         Store store = ((StoreManager)manager).getStore();
/* 163 */         if (store != null) {
/* 164 */           Session session = null;
/*     */           try {
/* 166 */             session = store.load(sessionId);
/* 167 */           } catch (Exception e) {
/* 168 */             this.containerLog.error(sm.getString("persistentValve.sessionLoadFail", new Object[] { sessionId }));
/*     */           } 
/* 170 */           if (session != null) {
/* 171 */             if (!session.isValid() || isSessionStale(session, System.currentTimeMillis())) {
/* 172 */               if (this.containerLog.isTraceEnabled()) {
/* 173 */                 this.containerLog.trace("session swapped in is invalid or expired");
/*     */               }
/* 175 */               session.expire();
/* 176 */               store.remove(sessionId);
/*     */             } else {
/* 178 */               session.setManager(manager);
/*     */               
/* 180 */               manager.add(session);
/*     */               
/* 182 */               session.access();
/* 183 */               session.endAccess();
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/* 188 */       if (this.containerLog.isTraceEnabled()) {
/* 189 */         this.containerLog.trace("sessionId: " + sessionId);
/*     */       }
/*     */ 
/*     */       
/* 193 */       getNext().invoke(request, response);
/*     */ 
/*     */       
/* 196 */       if (!request.isAsync()) {
/*     */         Session hsess;
/*     */ 
/*     */         
/*     */         try {
/* 201 */           hsess = request.getSessionInternal(false);
/* 202 */         } catch (Exception e) {
/* 203 */           hsess = null;
/*     */         } 
/* 205 */         String newsessionId = null;
/* 206 */         if (hsess != null) {
/* 207 */           newsessionId = hsess.getIdInternal();
/*     */         }
/*     */         
/* 210 */         if (this.containerLog.isTraceEnabled()) {
/* 211 */           this.containerLog.trace("newsessionId: " + newsessionId);
/*     */         }
/* 213 */         if (newsessionId != null) {
/*     */           try {
/* 215 */             bind(context);
/*     */ 
/*     */             
/* 218 */             if (manager instanceof StoreManager) {
/* 219 */               Session session = manager.findSession(newsessionId);
/* 220 */               Store store = ((StoreManager)manager).getStore();
/* 221 */               boolean stored = false;
/* 222 */               if (session != null && 
/* 223 */                 store != null && session.isValid() && 
/* 224 */                 !isSessionStale(session, System.currentTimeMillis())) {
/* 225 */                 store.save(session);
/* 226 */                 ((StoreManager)manager).removeSuper(session);
/* 227 */                 session.recycle();
/* 228 */                 stored = true;
/*     */               } 
/*     */               
/* 231 */               if (!stored && 
/* 232 */                 this.containerLog.isTraceEnabled()) {
/* 233 */                 this.containerLog.trace("newsessionId store: " + String.valueOf(store) + " session: " + String.valueOf(session) + " valid: " + (
/*     */                     
/* 235 */                     (session == null) ? "N/A" : Boolean.toString(session.isValid())) + " stale: " + 
/* 236 */                     isSessionStale(session, System.currentTimeMillis()));
/*     */               
/*     */               }
/*     */             }
/* 240 */             else if (this.containerLog.isTraceEnabled()) {
/* 241 */               this.containerLog.trace("newsessionId Manager: " + String.valueOf(manager));
/*     */             } 
/*     */           } finally {
/*     */             
/* 245 */             unbind(context);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } finally {
/* 250 */       if (semaphore != null) {
/* 251 */         if (mustReleaseSemaphore) {
/* 252 */           semaphore.release();
/*     */         }
/* 254 */         this.sessionToSemaphoreMap.computeIfPresent(sessionId, (k, v) -> (v.decrementAndGetUsageCount() == 0L) ? null : v);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onSemaphoreNotAcquired(Request request, Response response) throws IOException {
/* 271 */     response.sendError(429);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSessionStale(Session session, long timeNow) {
/* 285 */     if (session != null) {
/* 286 */       int maxInactiveInterval = session.getMaxInactiveInterval();
/* 287 */       if (maxInactiveInterval > 0) {
/* 288 */         int timeIdle = (int)(session.getIdleTimeInternal() / 1000L);
/* 289 */         return (timeIdle >= maxInactiveInterval);
/*     */       } 
/*     */     } 
/*     */     
/* 293 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void bind(Context context) {
/* 298 */     if (this.clBindRequired) {
/* 299 */       context.bind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void unbind(Context context) {
/* 305 */     if (this.clBindRequired) {
/* 306 */       context.unbind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isRequestWithoutSession(String uri) {
/* 311 */     Pattern f = this.filter;
/* 312 */     return (f != null && f.matcher(uri).matches());
/*     */   }
/*     */   
/*     */   public String getFilter() {
/* 316 */     if (this.filter == null) {
/* 317 */       return null;
/*     */     }
/* 319 */     return this.filter.toString();
/*     */   }
/*     */   
/*     */   public void setFilter(String filter) {
/* 323 */     if (filter == null || filter.isEmpty()) {
/* 324 */       this.filter = null;
/*     */     } else {
/*     */       try {
/* 327 */         this.filter = Pattern.compile(filter);
/* 328 */       } catch (PatternSyntaxException pse) {
/* 329 */         this.container.getLogger().error(sm.getString("persistentValve.filter.failure", new Object[] { filter }), pse);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSemaphoreFairness() {
/* 342 */     return this.semaphoreFairness;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSemaphoreFairness(boolean semaphoreFairness) {
/* 354 */     this.semaphoreFairness = semaphoreFairness;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSemaphoreBlockOnAcquire() {
/* 365 */     return this.semaphoreBlockOnAcquire;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSemaphoreBlockOnAcquire(boolean semaphoreBlockOnAcquire) {
/* 376 */     this.semaphoreBlockOnAcquire = semaphoreBlockOnAcquire;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSemaphoreAcquireUninterruptibly() {
/* 386 */     return this.semaphoreAcquireUninterruptibly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSemaphoreAcquireUninterruptibly(boolean semaphoreAcquireUninterruptibly) {
/* 397 */     this.semaphoreAcquireUninterruptibly = semaphoreAcquireUninterruptibly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class UsageCountingSemaphore
/*     */   {
/* 410 */     private final AtomicLong usageCount = new AtomicLong(1L);
/*     */     private final Semaphore semaphore;
/*     */     
/*     */     private UsageCountingSemaphore(boolean fairness) {
/* 414 */       this.semaphore = new Semaphore(1, fairness);
/*     */     }
/*     */     
/*     */     private UsageCountingSemaphore incrementUsageCount() {
/* 418 */       this.usageCount.incrementAndGet();
/* 419 */       return this;
/*     */     }
/*     */     
/*     */     private long decrementAndGetUsageCount() {
/* 423 */       return this.usageCount.decrementAndGet();
/*     */     }
/*     */     
/*     */     private void acquire() throws InterruptedException {
/* 427 */       this.semaphore.acquire();
/*     */     }
/*     */     
/*     */     private void acquireUninterruptibly() {
/* 431 */       this.semaphore.acquireUninterruptibly();
/*     */     }
/*     */     
/*     */     private boolean tryAcquire() {
/* 435 */       return this.semaphore.tryAcquire();
/*     */     }
/*     */     
/*     */     private void release() {
/* 439 */       this.semaphore.release();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\PersistentValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */