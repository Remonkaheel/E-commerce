/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Enumeration;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.http.parser.Host;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoteIpValve
/*     */   extends ValveBase
/*     */ {
/* 363 */   private static final Log log = LogFactory.getLog(RemoteIpValve.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings) {
/* 376 */     return StringUtils.splitCommaSeparated(commaDelimitedStrings);
/*     */   }
/*     */   
/* 379 */   private String hostHeader = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean changeLocalName = false;
/*     */ 
/*     */   
/* 386 */   private int httpServerPort = 80;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 391 */   private int httpsServerPort = 443;
/*     */   
/* 393 */   private String portHeader = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean changeLocalPort = false;
/*     */ 
/*     */   
/* 400 */   private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|100\\.6[4-9]{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.[7-9]{1}\\d{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.1[0-1]{1}\\d{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.12[0-7]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}|0:0:0:0:0:0:0:1|::1|fe[89ab]\\p{XDigit}:.*|f[cd]\\p{XDigit}{2}+:.*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 411 */   private String protocolHeader = "X-Forwarded-Proto";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 416 */   private String protocolHeaderHttpsValue = "https";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 421 */   private String proxiesHeader = "X-Forwarded-By";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 426 */   private String remoteIpHeader = "X-Forwarded-For";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean requestAttributesEnabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 436 */   private Pattern trustedProxies = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteIpValve() {
/* 444 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHostHeader() {
/* 454 */     return this.hostHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHostHeader(String hostHeader) {
/* 464 */     this.hostHeader = hostHeader;
/*     */   }
/*     */   
/*     */   public boolean isChangeLocalName() {
/* 468 */     return this.changeLocalName;
/*     */   }
/*     */   
/*     */   public void setChangeLocalName(boolean changeLocalName) {
/* 472 */     this.changeLocalName = changeLocalName;
/*     */   }
/*     */   
/*     */   public int getHttpServerPort() {
/* 476 */     return this.httpServerPort;
/*     */   }
/*     */   
/*     */   public int getHttpsServerPort() {
/* 480 */     return this.httpsServerPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPortHeader() {
/* 490 */     return this.portHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPortHeader(String portHeader) {
/* 500 */     this.portHeader = portHeader;
/*     */   }
/*     */   
/*     */   public boolean isChangeLocalPort() {
/* 504 */     return this.changeLocalPort;
/*     */   }
/*     */   
/*     */   public void setChangeLocalPort(boolean changeLocalPort) {
/* 508 */     this.changeLocalPort = changeLocalPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInternalProxies() {
/* 517 */     if (this.internalProxies == null) {
/* 518 */       return null;
/*     */     }
/* 520 */     return this.internalProxies.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProtocolHeader() {
/* 529 */     return this.protocolHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProtocolHeaderHttpsValue() {
/* 538 */     return this.protocolHeaderHttpsValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProxiesHeader() {
/* 547 */     return this.proxiesHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteIpHeader() {
/* 556 */     return this.remoteIpHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRequestAttributesEnabled() {
/* 565 */     return this.requestAttributesEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrustedProxies() {
/* 574 */     if (this.trustedProxies == null) {
/* 575 */       return null;
/*     */     }
/* 577 */     return this.trustedProxies.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 582 */     String originalRemoteAddr = request.getRemoteAddr();
/* 583 */     String originalRemoteHost = request.getRemoteHost();
/* 584 */     String originalScheme = request.getScheme();
/* 585 */     boolean originalSecure = request.isSecure();
/* 586 */     String originalServerName = request.getServerName();
/* 587 */     String originalLocalName = isChangeLocalName() ? request.getLocalName() : null;
/* 588 */     int originalServerPort = request.getServerPort();
/* 589 */     int originalLocalPort = request.getLocalPort();
/* 590 */     String originalProxiesHeader = request.getHeader(this.proxiesHeader);
/* 591 */     String originalRemoteIpHeader = request.getHeader(this.remoteIpHeader);
/* 592 */     boolean isInternal = (this.internalProxies != null && this.internalProxies.matcher(originalRemoteAddr).matches());
/*     */     
/* 594 */     if (isInternal || (this.trustedProxies != null && this.trustedProxies.matcher(originalRemoteAddr).matches())) {
/* 595 */       String remoteIp = null;
/* 596 */       Deque<String> proxiesHeaderValue = new ArrayDeque<>();
/* 597 */       StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
/*     */       
/* 599 */       for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements(); ) {
/* 600 */         if (concatRemoteIpHeaderValue.length() > 0) {
/* 601 */           concatRemoteIpHeaderValue.append(", ");
/*     */         }
/*     */         
/* 604 */         concatRemoteIpHeaderValue.append(e.nextElement());
/*     */       } 
/*     */       
/* 607 */       String[] remoteIpHeaderValue = StringUtils.splitCommaSeparated(concatRemoteIpHeaderValue.toString());
/*     */       
/* 609 */       if (!isInternal) {
/* 610 */         proxiesHeaderValue.addFirst(originalRemoteAddr);
/*     */       }
/*     */       int idx;
/* 613 */       for (idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--) {
/* 614 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/* 615 */         remoteIp = currentRemoteIp;
/* 616 */         if (this.internalProxies == null || !this.internalProxies.matcher(currentRemoteIp).matches())
/*     */         {
/* 618 */           if (this.trustedProxies != null && this.trustedProxies.matcher(currentRemoteIp).matches()) {
/* 619 */             proxiesHeaderValue.addFirst(currentRemoteIp);
/*     */           } else {
/* 621 */             idx--;
/*     */             break;
/*     */           } 
/*     */         }
/*     */       } 
/* 626 */       Deque<String> newRemoteIpHeaderValue = new ArrayDeque<>();
/* 627 */       for (; idx >= 0; idx--) {
/* 628 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/* 629 */         newRemoteIpHeaderValue.addFirst(currentRemoteIp);
/*     */       } 
/* 631 */       if (remoteIp != null) {
/*     */         
/* 633 */         request.setRemoteAddr(remoteIp);
/* 634 */         if (request.getConnector().getEnableLookups()) {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 640 */             InetAddress inetAddress = InetAddress.getByName(remoteIp);
/*     */             
/* 642 */             request.setRemoteHost(inetAddress.getCanonicalHostName());
/* 643 */           } catch (UnknownHostException unknownHostException) {
/* 644 */             if (log.isDebugEnabled()) {
/* 645 */               log.debug(sm.getString("remoteIpValve.invalidRemoteAddress", new Object[] { remoteIp }), unknownHostException);
/*     */             }
/* 647 */             request.setRemoteHost(remoteIp);
/*     */           } 
/*     */         } else {
/* 650 */           request.setRemoteHost(remoteIp);
/*     */         } 
/*     */         
/* 653 */         if (proxiesHeaderValue.isEmpty()) {
/* 654 */           request.getCoyoteRequest().getMimeHeaders().removeHeader(this.proxiesHeader);
/*     */         } else {
/* 656 */           String commaDelimitedListOfProxies = StringUtils.join(proxiesHeaderValue);
/* 657 */           request.getCoyoteRequest().getMimeHeaders().setValue(this.proxiesHeader)
/* 658 */             .setString(commaDelimitedListOfProxies);
/*     */         } 
/* 660 */         if (newRemoteIpHeaderValue.isEmpty()) {
/* 661 */           request.getCoyoteRequest().getMimeHeaders().removeHeader(this.remoteIpHeader);
/*     */         } else {
/* 663 */           String commaDelimitedRemoteIpHeaderValue = StringUtils.join(newRemoteIpHeaderValue);
/* 664 */           request.getCoyoteRequest().getMimeHeaders().setValue(this.remoteIpHeader)
/* 665 */             .setString(commaDelimitedRemoteIpHeaderValue);
/*     */         } 
/*     */       } 
/*     */       
/* 669 */       if (this.protocolHeader != null) {
/* 670 */         String protocolHeaderValue = request.getHeader(this.protocolHeader);
/* 671 */         if (protocolHeaderValue != null)
/*     */         {
/*     */           
/* 674 */           if (isForwardedProtoHeaderValueSecure(protocolHeaderValue)) {
/* 675 */             request.setSecure(true);
/* 676 */             request.getCoyoteRequest().scheme().setString("https");
/* 677 */             setPorts(request, this.httpsServerPort);
/*     */           } else {
/* 679 */             request.setSecure(false);
/* 680 */             request.getCoyoteRequest().scheme().setString("http");
/* 681 */             setPorts(request, this.httpServerPort);
/*     */           } 
/*     */         }
/*     */       } 
/* 685 */       if (this.hostHeader != null) {
/* 686 */         String hostHeaderValue = request.getHeader(this.hostHeader);
/* 687 */         if (hostHeaderValue != null) {
/*     */           try {
/* 689 */             int portIndex = Host.parse(hostHeaderValue);
/* 690 */             if (portIndex > -1) {
/* 691 */               log.debug(sm.getString("remoteIpValve.invalidHostWithPort", new Object[] { hostHeaderValue, this.hostHeader }));
/* 692 */               hostHeaderValue = hostHeaderValue.substring(0, portIndex);
/*     */             } 
/*     */             
/* 695 */             request.getCoyoteRequest().serverName().setString(hostHeaderValue);
/* 696 */             if (isChangeLocalName()) {
/* 697 */               request.getCoyoteRequest().localName().setString(hostHeaderValue);
/*     */             }
/*     */           }
/* 700 */           catch (IllegalArgumentException iae) {
/* 701 */             log.debug(sm.getString("remoteIpValve.invalidHostHeader", new Object[] { hostHeaderValue, this.hostHeader }), iae);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 706 */       request.setAttribute("org.apache.tomcat.request.forwarded", Boolean.TRUE);
/*     */       
/* 708 */       if (log.isTraceEnabled()) {
/* 709 */         log.trace("Incoming request " + request.getRequestURI() + " with originalRemoteAddr [" + originalRemoteAddr + "], originalRemoteHost=[" + originalRemoteHost + "], originalSecure=[" + originalSecure + "], originalScheme=[" + originalScheme + "], originalServerName=[" + originalServerName + "], originalServerPort=[" + originalServerPort + "] will be seen as newRemoteAddr=[" + request
/*     */ 
/*     */ 
/*     */             
/* 713 */             .getRemoteAddr() + "], newRemoteHost=[" + request
/* 714 */             .getRemoteHost() + "], newSecure=[" + request.isSecure() + "], newScheme=[" + request
/* 715 */             .getScheme() + "], newServerName=[" + request.getServerName() + "], newServerPort=[" + request
/* 716 */             .getServerPort() + "]");
/*     */       }
/*     */     }
/* 719 */     else if (log.isTraceEnabled()) {
/* 720 */       log.trace("Skip RemoteIpValve for request " + request.getRequestURI() + " with originalRemoteAddr '" + request
/* 721 */           .getRemoteAddr() + "'");
/*     */     } 
/*     */     
/* 724 */     if (this.requestAttributesEnabled) {
/* 725 */       request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", request.getRemoteAddr());
/* 726 */       request.setAttribute("org.apache.tomcat.remoteAddr", request.getRemoteAddr());
/* 727 */       request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", request.getRemoteHost());
/* 728 */       request.setAttribute("org.apache.catalina.AccessLog.Protocol", request.getProtocol());
/* 729 */       request.setAttribute("org.apache.catalina.AccessLog.ServerName", request.getServerName());
/* 730 */       request.setAttribute("org.apache.catalina.AccessLog.ServerPort", Integer.valueOf(request.getServerPort()));
/*     */     } 
/*     */     try {
/* 733 */       getNext().invoke(request, response);
/*     */     } finally {
/* 735 */       if (!request.isAsync()) {
/* 736 */         request.setRemoteAddr(originalRemoteAddr);
/* 737 */         request.setRemoteHost(originalRemoteHost);
/* 738 */         request.setSecure(originalSecure);
/* 739 */         request.getCoyoteRequest().scheme().setString(originalScheme);
/* 740 */         request.getCoyoteRequest().serverName().setString(originalServerName);
/* 741 */         if (isChangeLocalName()) {
/* 742 */           request.getCoyoteRequest().localName().setString(originalLocalName);
/*     */         }
/* 744 */         request.setServerPort(originalServerPort);
/* 745 */         request.setLocalPort(originalLocalPort);
/*     */         
/* 747 */         MimeHeaders headers = request.getCoyoteRequest().getMimeHeaders();
/* 748 */         if (originalProxiesHeader == null || originalProxiesHeader.isEmpty()) {
/* 749 */           headers.removeHeader(this.proxiesHeader);
/*     */         } else {
/* 751 */           headers.setValue(this.proxiesHeader).setString(originalProxiesHeader);
/*     */         } 
/*     */         
/* 754 */         if (originalRemoteIpHeader == null || originalRemoteIpHeader.isEmpty()) {
/* 755 */           headers.removeHeader(this.remoteIpHeader);
/*     */         } else {
/* 757 */           headers.setValue(this.remoteIpHeader).setString(originalRemoteIpHeader);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isForwardedProtoHeaderValueSecure(String protocolHeaderValue) {
/* 767 */     if (!protocolHeaderValue.contains(",")) {
/* 768 */       return this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue);
/*     */     }
/* 770 */     String[] forwardedProtocols = StringUtils.splitCommaSeparated(protocolHeaderValue);
/* 771 */     if (forwardedProtocols.length == 0) {
/* 772 */       return false;
/*     */     }
/* 774 */     for (String forwardedProtocol : forwardedProtocols) {
/* 775 */       if (!this.protocolHeaderHttpsValue.equalsIgnoreCase(forwardedProtocol)) {
/* 776 */         return false;
/*     */       }
/*     */     } 
/* 779 */     return true;
/*     */   }
/*     */   
/*     */   private void setPorts(Request request, int defaultPort) {
/* 783 */     int port = defaultPort;
/* 784 */     if (this.portHeader != null) {
/* 785 */       String portHeaderValue = request.getHeader(this.portHeader);
/* 786 */       if (portHeaderValue != null) {
/*     */         try {
/* 788 */           port = Integer.parseInt(portHeaderValue);
/* 789 */         } catch (NumberFormatException nfe) {
/* 790 */           if (log.isDebugEnabled()) {
/* 791 */             log.debug(sm.getString("remoteIpValve.invalidPortHeader", new Object[] { portHeaderValue, this.portHeader }), nfe);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 796 */     request.setServerPort(port);
/* 797 */     if (this.changeLocalPort) {
/* 798 */       request.setLocalPort(port);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpServerPort(int httpServerPort) {
/* 813 */     this.httpServerPort = httpServerPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpsServerPort(int httpsServerPort) {
/* 827 */     this.httpsServerPort = httpsServerPort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInternalProxies(String internalProxies) {
/* 842 */     if (internalProxies == null || internalProxies.isEmpty()) {
/* 843 */       this.internalProxies = null;
/*     */     } else {
/* 845 */       this.internalProxies = Pattern.compile(internalProxies);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocolHeader(String protocolHeader) {
/* 861 */     this.protocolHeader = protocolHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue) {
/* 875 */     this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxiesHeader(String proxiesHeader) {
/* 898 */     this.proxiesHeader = proxiesHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteIpHeader(String remoteIpHeader) {
/* 915 */     this.remoteIpHeader = remoteIpHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {
/* 934 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustedProxies(String trustedProxies) {
/* 948 */     if (trustedProxies == null || trustedProxies.isEmpty()) {
/* 949 */       this.trustedProxies = null;
/*     */     } else {
/* 951 */       this.trustedProxies = Pattern.compile(trustedProxies);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\RemoteIpValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */