/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessLogValve
/*     */   extends AbstractAccessLogValve
/*     */ {
/*  62 */   private static final Log log = LogFactory.getLog(AccessLogValve.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private volatile String dateStamp = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private String directory = "logs";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   protected volatile String prefix = "access_log";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean rotatable = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean renameOnRotate = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean buffered = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected volatile String suffix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   protected PrintWriter writer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   protected SimpleDateFormat fileDateFormatter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   protected File currentLogFile = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private volatile long rotationLastChecked = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkExists = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   protected String fileDateFormat = ".yyyy-MM-dd";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   protected volatile String encoding = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private int maxDays = -1;
/*     */ 
/*     */   
/*     */   private volatile boolean checkForOldLogs = false;
/*     */ 
/*     */   
/*     */   public int getMaxDays() {
/* 161 */     return this.maxDays;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxDays(int maxDays) {
/* 166 */     this.maxDays = maxDays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDirectory() {
/* 174 */     return this.directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectory(String directory) {
/* 184 */     this.directory = directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCheckExists() {
/* 194 */     return this.checkExists;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckExists(boolean checkExists) {
/* 206 */     this.checkExists = checkExists;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 215 */     return this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 225 */     this.prefix = prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRotatable() {
/* 235 */     return this.rotatable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotatable(boolean rotatable) {
/* 245 */     this.rotatable = rotatable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRenameOnRotate() {
/* 255 */     return this.renameOnRotate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenameOnRotate(boolean renameOnRotate) {
/* 265 */     this.renameOnRotate = renameOnRotate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBuffered() {
/* 275 */     return this.buffered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuffered(boolean buffered) {
/* 285 */     this.buffered = buffered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffix() {
/* 293 */     return this.suffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuffix(String suffix) {
/* 303 */     this.suffix = suffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileDateFormat() {
/* 310 */     return this.fileDateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileDateFormat(String fileDateFormat) {
/* 321 */     String newFormat = Objects.<String>requireNonNullElse(fileDateFormat, "");
/* 322 */     this.fileDateFormat = newFormat;
/*     */     
/* 324 */     synchronized (this) {
/* 325 */       this.fileDateFormatter = new SimpleDateFormat(newFormat, Locale.US);
/* 326 */       this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 336 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncoding(String encoding) {
/* 345 */     if (encoding != null && !encoding.isEmpty()) {
/* 346 */       this.encoding = encoding;
/*     */     } else {
/* 348 */       this.encoding = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void backgroundProcess() {
/* 359 */     if (getState().isAvailable() && getEnabled() && this.writer != null && this.buffered) {
/* 360 */       this.writer.flush();
/*     */     }
/*     */     
/* 363 */     int maxDays = this.maxDays;
/* 364 */     String prefix = this.prefix;
/* 365 */     String suffix = this.suffix;
/*     */     
/* 367 */     if (this.rotatable && this.checkForOldLogs && maxDays > 0) {
/* 368 */       long deleteIfLastModifiedBefore = System.currentTimeMillis() - maxDays * 24L * 60L * 60L * 1000L;
/* 369 */       File dir = getDirectoryFile();
/* 370 */       if (dir.isDirectory()) {
/* 371 */         String[] oldAccessLogs = dir.list();
/*     */         
/* 373 */         if (oldAccessLogs != null) {
/* 374 */           for (String oldAccessLog : oldAccessLogs) {
/* 375 */             boolean match = false;
/*     */             
/* 377 */             if (prefix != null && !prefix.isEmpty()) {
/* 378 */               if (!oldAccessLog.startsWith(prefix)) {
/*     */                 continue;
/*     */               }
/* 381 */               match = true;
/*     */             } 
/*     */             
/* 384 */             if (suffix != null && !suffix.isEmpty()) {
/* 385 */               if (!oldAccessLog.endsWith(suffix)) {
/*     */                 continue;
/*     */               }
/* 388 */               match = true;
/*     */             } 
/*     */             
/* 391 */             if (match) {
/* 392 */               File file = new File(dir, oldAccessLog);
/* 393 */               if (file.isFile() && file.lastModified() < deleteIfLastModifiedBefore && 
/* 394 */                 !file.delete()) {
/* 395 */                 log.warn(sm.getString("accessLogValve.deleteFail", new Object[] { file.getAbsolutePath() }));
/*     */               }
/*     */             } 
/*     */             continue;
/*     */           } 
/*     */         }
/*     */       } 
/* 402 */       this.checkForOldLogs = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rotate() {
/* 410 */     if (this.rotatable) {
/*     */       
/* 412 */       long systime = System.currentTimeMillis();
/* 413 */       if (systime - this.rotationLastChecked > 1000L) {
/* 414 */         synchronized (this) {
/* 415 */           if (systime - this.rotationLastChecked > 1000L) {
/* 416 */             this.rotationLastChecked = systime;
/*     */ 
/*     */ 
/*     */             
/* 420 */             String tsDate = this.fileDateFormatter.format(new Date(systime));
/*     */ 
/*     */             
/* 423 */             if (!this.dateStamp.equals(tsDate)) {
/* 424 */               close(true);
/* 425 */               this.dateStamp = tsDate;
/* 426 */               open();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean rotate(String newFileName) {
/* 444 */     if (this.currentLogFile != null) {
/* 445 */       File holder = this.currentLogFile;
/* 446 */       close(false);
/*     */       try {
/* 448 */         holder.renameTo(new File(newFileName));
/* 449 */       } catch (Throwable t) {
/* 450 */         ExceptionUtils.handleThrowable(t);
/* 451 */         log.error(sm.getString("accessLogValve.rotateFail"), t);
/*     */       } 
/*     */ 
/*     */       
/* 455 */       this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/*     */       
/* 457 */       open();
/* 458 */       return true;
/*     */     } 
/* 460 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getDirectoryFile() {
/* 469 */     File dir = new File(this.directory);
/* 470 */     if (!dir.isAbsolute()) {
/* 471 */       dir = new File(getContainer().getCatalinaBase(), this.directory);
/*     */     }
/* 473 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getLogFile(boolean useDateStamp) {
/* 487 */     File pathname, dir = getDirectoryFile();
/* 488 */     if (!dir.mkdirs() && !dir.isDirectory()) {
/* 489 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { dir }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 494 */     if (useDateStamp) {
/* 495 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.prefix + this.dateStamp);
/*     */     } else {
/* 497 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.prefix);
/*     */     } 
/* 499 */     File parent = pathname.getParentFile();
/* 500 */     if (!parent.mkdirs() && !parent.isDirectory()) {
/* 501 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { parent }));
/*     */     }
/* 503 */     return pathname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void restore() {
/* 511 */     File newLogFile = getLogFile(false);
/* 512 */     File rotatedLogFile = getLogFile(true);
/* 513 */     if (rotatedLogFile.exists() && !newLogFile.exists() && !rotatedLogFile.equals(newLogFile)) {
/*     */       try {
/* 515 */         if (!rotatedLogFile.renameTo(newLogFile)) {
/* 516 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }));
/*     */         }
/* 518 */       } catch (Throwable t) {
/* 519 */         ExceptionUtils.handleThrowable(t);
/* 520 */         log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }), t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void close(boolean rename) {
/* 532 */     if (this.writer == null) {
/*     */       return;
/*     */     }
/* 535 */     this.writer.flush();
/* 536 */     this.writer.close();
/* 537 */     if (rename && this.renameOnRotate) {
/* 538 */       File newLogFile = getLogFile(true);
/* 539 */       if (!newLogFile.exists()) {
/*     */         try {
/* 541 */           if (!this.currentLogFile.renameTo(newLogFile)) {
/* 542 */             log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }));
/*     */           }
/* 544 */         } catch (Throwable t) {
/* 545 */           ExceptionUtils.handleThrowable(t);
/* 546 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }), t);
/*     */         } 
/*     */       } else {
/* 549 */         log.error(sm.getString("accessLogValve.alreadyExists", new Object[] { this.currentLogFile, newLogFile }));
/*     */       } 
/*     */     } 
/* 552 */     this.writer = null;
/* 553 */     this.dateStamp = "";
/* 554 */     this.currentLogFile = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(CharArrayWriter message) {
/* 561 */     rotate();
/*     */ 
/*     */     
/* 564 */     if (this.checkExists) {
/* 565 */       synchronized (this) {
/* 566 */         if (this.currentLogFile != null && !this.currentLogFile.exists()) {
/*     */           try {
/* 568 */             close(false);
/* 569 */           } catch (Throwable t) {
/* 570 */             ExceptionUtils.handleThrowable(t);
/* 571 */             log.info(sm.getString("accessLogValve.closeFail"), t);
/*     */           } 
/*     */ 
/*     */           
/* 575 */           this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/*     */           
/* 577 */           open();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 584 */       message.write(System.lineSeparator());
/* 585 */       synchronized (this) {
/* 586 */         if (this.writer != null) {
/* 587 */           message.writeTo(this.writer);
/* 588 */           if (!this.buffered) {
/* 589 */             this.writer.flush();
/*     */           }
/*     */         } 
/*     */       } 
/* 593 */     } catch (IOException ioe) {
/* 594 */       log.warn(sm.getString("accessLogValve.writeFail", new Object[] { message.toString() }), ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void open() {
/* 605 */     File pathname = getLogFile((this.rotatable && !this.renameOnRotate));
/*     */     
/* 607 */     Charset charset = null;
/* 608 */     if (this.encoding != null) {
/*     */       try {
/* 610 */         charset = B2CConverter.getCharset(this.encoding);
/* 611 */       } catch (UnsupportedEncodingException ex) {
/* 612 */         log.error(sm.getString("accessLogValve.unsupportedEncoding", new Object[] { this.encoding }), ex);
/*     */       } 
/*     */     }
/* 615 */     if (charset == null) {
/* 616 */       charset = StandardCharsets.UTF_8;
/*     */     }
/*     */     
/*     */     try {
/* 620 */       this.writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pathname, true), charset), 128000), false);
/*     */ 
/*     */ 
/*     */       
/* 624 */       this.currentLogFile = pathname;
/* 625 */     } catch (IOException ioe) {
/* 626 */       this.writer = null;
/* 627 */       this.currentLogFile = null;
/* 628 */       log.error(sm.getString("accessLogValve.openFail", new Object[] { pathname, System.getProperty("user.name") }), ioe);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 633 */     this.checkForOldLogs = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 647 */     String format = getFileDateFormat();
/* 648 */     this.fileDateFormatter = new SimpleDateFormat(format, Locale.US);
/* 649 */     this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/* 650 */     this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/* 651 */     if (this.rotatable && this.renameOnRotate) {
/* 652 */       restore();
/*     */     }
/* 654 */     open();
/*     */     
/* 656 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 670 */     super.stopInternal();
/* 671 */     close(false);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\AccessLogValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */