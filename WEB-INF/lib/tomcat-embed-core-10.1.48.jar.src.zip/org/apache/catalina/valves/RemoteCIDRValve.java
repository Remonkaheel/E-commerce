/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.NetMask;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RemoteCIDRValve
/*     */   extends RequestFilterValve
/*     */ {
/*  40 */   private static final Log log = LogFactory.getLog(RemoteCIDRValve.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private final List<NetMask> allow = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final List<NetMask> deny = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllow() {
/*  64 */     return this.allow.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllow(String input) {
/*  77 */     List<String> messages = fillFromInput(input, this.allow);
/*     */     
/*  79 */     if (messages.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  83 */     this.allowValid = false;
/*  84 */     for (String message : messages) {
/*  85 */       log.error(message);
/*     */     }
/*     */     
/*  88 */     throw new IllegalArgumentException(sm.getString("remoteCidrValve.invalid", new Object[] { "allow" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeny() {
/*  99 */     return this.deny.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeny(String input) {
/* 112 */     List<String> messages = fillFromInput(input, this.deny);
/*     */     
/* 114 */     if (messages.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 118 */     this.denyValid = false;
/* 119 */     for (String message : messages) {
/* 120 */       log.error(message);
/*     */     }
/*     */     
/* 123 */     throw new IllegalArgumentException(sm.getString("remoteCidrValve.invalid", new Object[] { "deny" }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*     */     String property;
/* 130 */     if (getUsePeerAddress()) {
/* 131 */       property = request.getPeerAddr();
/*     */     } else {
/* 133 */       property = request.getRequest().getRemoteAddr();
/*     */     } 
/* 135 */     if (getAddConnectorPort()) {
/* 136 */       property = property + ";" + property;
/*     */     }
/* 138 */     process(property, request, response);
/*     */   }
/*     */   public boolean isAllowed(String property) {
/*     */     int port;
/*     */     String nonPortPart;
/*     */     InetAddress addr;
/* 144 */     int portIdx = property.indexOf(';');
/*     */ 
/*     */ 
/*     */     
/* 148 */     if (portIdx == -1) {
/* 149 */       if (getAddConnectorPort()) {
/* 150 */         log.error(sm.getString("remoteCidrValve.noPort"));
/* 151 */         return false;
/*     */       } 
/* 153 */       port = -1;
/* 154 */       nonPortPart = property;
/*     */     } else {
/* 156 */       if (!getAddConnectorPort()) {
/* 157 */         log.error(sm.getString("remoteCidrValve.unexpectedPort"));
/* 158 */         return false;
/*     */       } 
/* 160 */       nonPortPart = property.substring(0, portIdx);
/*     */       try {
/* 162 */         port = Integer.parseInt(property.substring(portIdx + 1));
/* 163 */       } catch (NumberFormatException e) {
/*     */ 
/*     */         
/* 166 */         log.error(sm.getString("remoteCidrValve.noPort"), e);
/* 167 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 173 */       addr = InetAddress.getByName(nonPortPart);
/* 174 */     } catch (UnknownHostException e) {
/*     */ 
/*     */       
/* 177 */       log.error(sm.getString("remoteCidrValve.noRemoteIp"), e);
/* 178 */       return false;
/*     */     } 
/*     */     
/* 181 */     for (NetMask nm : this.deny) {
/* 182 */       if (getAddConnectorPort()) {
/* 183 */         if (nm.matches(addr, port))
/* 184 */           return false; 
/*     */         continue;
/*     */       } 
/* 187 */       if (nm.matches(addr)) {
/* 188 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 193 */     for (NetMask nm : this.allow) {
/* 194 */       if (getAddConnectorPort()) {
/* 195 */         if (nm.matches(addr, port))
/* 196 */           return true; 
/*     */         continue;
/*     */       } 
/* 199 */       if (nm.matches(addr)) {
/* 200 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     return (!this.deny.isEmpty() && this.allow.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLog() {
/* 213 */     return log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> fillFromInput(String input, List<NetMask> target) {
/* 228 */     target.clear();
/* 229 */     if (input == null || input.isEmpty()) {
/* 230 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 233 */     List<String> messages = new ArrayList<>();
/*     */ 
/*     */     
/* 236 */     for (String s : StringUtils.splitCommaSeparated(input)) {
/*     */       try {
/* 238 */         NetMask nm = new NetMask(s);
/* 239 */         target.add(nm);
/* 240 */       } catch (IllegalArgumentException e) {
/* 241 */         messages.add(s + ": " + s);
/*     */       } 
/*     */     } 
/*     */     
/* 245 */     return Collections.unmodifiableList(messages);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\RemoteCIDRValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */