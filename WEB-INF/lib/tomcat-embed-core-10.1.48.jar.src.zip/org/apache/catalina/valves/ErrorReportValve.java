/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Scanner;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.ErrorPageSupport;
/*     */ import org.apache.catalina.util.IOTools;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorReportValve
/*     */   extends ValveBase
/*     */ {
/*     */   private boolean showReport = true;
/*     */   private boolean showServerInfo = true;
/*  57 */   private final ErrorPageSupport errorPageSupport = new ErrorPageSupport();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorReportValve() {
/*  63 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*  83 */     getNext().invoke(request, response);
/*     */     
/*  85 */     if (response.isCommitted()) {
/*  86 */       if (response.setErrorReported()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  91 */         AtomicBoolean ioAllowed = new AtomicBoolean(true);
/*  92 */         response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, ioAllowed);
/*     */         
/*  94 */         if (ioAllowed.get()) {
/*     */ 
/*     */           
/*     */           try {
/*  98 */             response.flushBuffer();
/*  99 */           } catch (Throwable t) {
/* 100 */             ExceptionUtils.handleThrowable(t);
/*     */           } 
/*     */ 
/*     */           
/* 104 */           response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, request
/* 105 */               .getAttribute("jakarta.servlet.error.exception"));
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 111 */     Throwable throwable = (Throwable)request.getAttribute("jakarta.servlet.error.exception");
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (request.isAsync() && !request.isAsyncCompleting()) {
/*     */       return;
/*     */     }
/*     */     
/* 119 */     if (throwable != null && !response.isError()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       response.reset();
/* 126 */       response.sendError(500);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     response.setSuspended(false);
/*     */     
/*     */     try {
/* 135 */       report(request, response, throwable);
/* 136 */     } catch (Throwable tt) {
/* 137 */       ExceptionUtils.handleThrowable(tt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ErrorPage findErrorPage(int statusCode, Throwable throwable) {
/* 154 */     ErrorPage errorPage = null;
/* 155 */     if (throwable != null) {
/* 156 */       errorPage = this.errorPageSupport.find(throwable);
/*     */     }
/* 158 */     if (errorPage == null) {
/* 159 */       errorPage = this.errorPageSupport.find(statusCode);
/*     */     }
/* 161 */     if (errorPage == null)
/*     */     {
/* 163 */       errorPage = this.errorPageSupport.find(0);
/*     */     }
/* 165 */     return errorPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void report(Request request, Response response, Throwable throwable) {
/* 178 */     int statusCode = response.getStatus();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     if (statusCode < 400 || response.getContentWritten() > 0L || !response.setErrorReported()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 190 */     AtomicBoolean result = new AtomicBoolean(false);
/* 191 */     response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/* 192 */     if (!result.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 196 */     ErrorPage errorPage = findErrorPage(statusCode, throwable);
/*     */     
/* 198 */     if (errorPage != null && 
/* 199 */       sendErrorPage(errorPage.getLocation(), response)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     String message = Escape.htmlElementContent(response.getMessage());
/* 207 */     if (message == null) {
/* 208 */       if (throwable != null) {
/* 209 */         String exceptionMessage = throwable.getMessage();
/* 210 */         if (exceptionMessage != null && !exceptionMessage.isEmpty()) {
/* 211 */           Scanner scanner = new Scanner(exceptionMessage); 
/* 212 */           try { message = Escape.htmlElementContent(scanner.nextLine());
/* 213 */             scanner.close(); } catch (Throwable throwable1) { try { scanner.close(); } catch (Throwable throwable2) { throwable1.addSuppressed(throwable2); }  throw throwable1; }
/*     */         
/*     */         } 
/* 216 */       }  if (message == null) {
/* 217 */         message = "";
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 223 */     String reason = null;
/* 224 */     String description = null;
/* 225 */     StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request.getLocales());
/* 226 */     response.setLocale(smClient.getLocale());
/*     */     try {
/* 228 */       reason = smClient.getString("http." + statusCode + ".reason");
/* 229 */       description = smClient.getString("http." + statusCode + ".desc");
/* 230 */     } catch (Throwable t) {
/* 231 */       ExceptionUtils.handleThrowable(t);
/*     */     } 
/* 233 */     if (reason == null || description == null) {
/* 234 */       if (message.isEmpty()) {
/*     */         return;
/*     */       }
/* 237 */       reason = smClient.getString("errorReportValve.unknownReason");
/* 238 */       description = smClient.getString("errorReportValve.noDescription");
/*     */     } 
/*     */ 
/*     */     
/* 242 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 244 */     sb.append("<!doctype html><html lang=\"");
/* 245 */     sb.append(smClient.getLocale().getLanguage()).append("\">");
/* 246 */     sb.append("<head>");
/* 247 */     sb.append("<title>");
/* 248 */     sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] { String.valueOf(statusCode), reason }));
/* 249 */     sb.append("</title>");
/* 250 */     sb.append("<style type=\"text/css\">");
/* 251 */     sb.append("body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}");
/* 252 */     sb.append("</style>");
/* 253 */     sb.append("</head><body>");
/* 254 */     sb.append("<h1>");
/* 255 */     sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] { String.valueOf(statusCode), reason
/* 256 */           })).append("</h1>");
/* 257 */     if (isShowReport()) {
/* 258 */       sb.append("<hr class=\"line\" />");
/* 259 */       sb.append("<p><b>");
/* 260 */       sb.append(smClient.getString("errorReportValve.type"));
/* 261 */       sb.append("</b> ");
/* 262 */       if (throwable != null) {
/* 263 */         sb.append(smClient.getString("errorReportValve.exceptionReport"));
/*     */       } else {
/* 265 */         sb.append(smClient.getString("errorReportValve.statusReport"));
/*     */       } 
/* 267 */       sb.append("</p>");
/* 268 */       if (!message.isEmpty()) {
/* 269 */         sb.append("<p><b>");
/* 270 */         sb.append(smClient.getString("errorReportValve.message"));
/* 271 */         sb.append("</b> ");
/* 272 */         sb.append(message).append("</p>");
/*     */       } 
/* 274 */       sb.append("<p><b>");
/* 275 */       sb.append(smClient.getString("errorReportValve.description"));
/* 276 */       sb.append("</b> ");
/* 277 */       sb.append(description);
/* 278 */       sb.append("</p>");
/* 279 */       if (throwable != null) {
/* 280 */         String stackTrace = getPartialServletStackTrace(throwable);
/* 281 */         sb.append("<p><b>");
/* 282 */         sb.append(smClient.getString("errorReportValve.exception"));
/* 283 */         sb.append("</b></p><pre>");
/* 284 */         sb.append(Escape.htmlElementContent(stackTrace));
/* 285 */         sb.append("</pre>");
/*     */         
/* 287 */         int loops = 0;
/* 288 */         Throwable rootCause = throwable.getCause();
/* 289 */         while (rootCause != null && loops < 10) {
/* 290 */           stackTrace = getPartialServletStackTrace(rootCause);
/* 291 */           sb.append("<p><b>");
/* 292 */           sb.append(smClient.getString("errorReportValve.rootCause"));
/* 293 */           sb.append("</b></p><pre>");
/* 294 */           sb.append(Escape.htmlElementContent(stackTrace));
/* 295 */           sb.append("</pre>");
/*     */           
/* 297 */           rootCause = rootCause.getCause();
/* 298 */           loops++;
/*     */         } 
/*     */         
/* 301 */         sb.append("<p><b>");
/* 302 */         sb.append(smClient.getString("errorReportValve.note"));
/* 303 */         sb.append("</b> ");
/* 304 */         sb.append(smClient.getString("errorReportValve.rootCauseInLogs"));
/* 305 */         sb.append("</p>");
/*     */       } 
/*     */       
/* 308 */       sb.append("<hr class=\"line\" />");
/*     */     } 
/* 310 */     if (isShowServerInfo()) {
/* 311 */       sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
/*     */     }
/* 313 */     sb.append("</body></html>");
/*     */     
/*     */     try {
/*     */       try {
/* 317 */         response.setContentType("text/html");
/* 318 */         response.setCharacterEncoding("utf-8");
/* 319 */       } catch (Throwable t) {
/* 320 */         ExceptionUtils.handleThrowable(t);
/* 321 */         if (this.container.getLogger().isDebugEnabled()) {
/* 322 */           this.container.getLogger().debug(sm.getString("errorReportValve.contentTypeFail"), t);
/*     */         }
/*     */       } 
/* 325 */       Writer writer = response.getReporter();
/* 326 */       if (writer != null) {
/*     */ 
/*     */         
/* 329 */         writer.write(sb.toString());
/* 330 */         response.finishResponse();
/*     */       } 
/* 332 */     } catch (IOException|IllegalStateException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPartialServletStackTrace(Throwable t) {
/* 347 */     StringBuilder trace = new StringBuilder();
/* 348 */     trace.append(t.toString()).append(System.lineSeparator());
/* 349 */     StackTraceElement[] elements = t.getStackTrace();
/* 350 */     int pos = elements.length; int i;
/* 351 */     for (i = elements.length - 1; i >= 0; i--) {
/* 352 */       if (elements[i].getClassName().startsWith("org.apache.catalina.core.ApplicationFilterChain") && elements[i]
/* 353 */         .getMethodName().equals("internalDoFilter")) {
/* 354 */         pos = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 358 */     for (i = 0; i < pos; i++) {
/* 359 */       if (!elements[i].getClassName().startsWith("org.apache.catalina.core.")) {
/* 360 */         trace.append('\t').append(elements[i].toString()).append(System.lineSeparator());
/*     */       }
/*     */     } 
/* 363 */     return trace.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean sendErrorPage(String location, Response response) {
/* 368 */     File file = new File(location);
/* 369 */     if (!file.isAbsolute()) {
/* 370 */       file = new File(getContainer().getCatalinaBase(), location);
/*     */     }
/* 372 */     if (!file.isFile() || !file.canRead()) {
/* 373 */       getContainer().getLogger().warn(sm.getString("errorReportValve.errorPageNotFound", new Object[] { location }));
/* 374 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 379 */     response.setContentType("text/html");
/* 380 */     response.setCharacterEncoding("UTF-8");
/*     */     
/* 382 */     try { ServletOutputStream servletOutputStream = response.getOutputStream(); try { InputStream is = new FileInputStream(file); 
/* 383 */         try { IOTools.flow(is, (OutputStream)servletOutputStream);
/* 384 */           is.close(); } catch (Throwable throwable) { try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (servletOutputStream != null) servletOutputStream.close();  } catch (Throwable throwable) { if (servletOutputStream != null) try { servletOutputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 385 */     { getContainer().getLogger().warn(sm.getString("errorReportValve.errorPageIOException", new Object[] { location }), ioe);
/* 386 */       return false; }
/*     */ 
/*     */     
/* 389 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowReport(boolean showReport) {
/* 399 */     this.showReport = showReport;
/*     */   }
/*     */   
/*     */   public boolean isShowReport() {
/* 403 */     return this.showReport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowServerInfo(boolean showServerInfo) {
/* 412 */     this.showServerInfo = showServerInfo;
/*     */   }
/*     */   
/*     */   public boolean isShowServerInfo() {
/* 416 */     return this.showServerInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setProperty(String name, String value) {
/* 421 */     if (name.startsWith("errorCode.")) {
/* 422 */       int code = Integer.parseInt(name.substring(10));
/* 423 */       ErrorPage ep = new ErrorPage();
/* 424 */       ep.setErrorCode(code);
/* 425 */       ep.setLocation(value);
/* 426 */       this.errorPageSupport.add(ep);
/* 427 */       return true;
/* 428 */     }  if (name.startsWith("exceptionType.")) {
/* 429 */       String className = name.substring(14);
/* 430 */       ErrorPage ep = new ErrorPage();
/* 431 */       ep.setExceptionType(className);
/* 432 */       ep.setLocation(value);
/* 433 */       this.errorPageSupport.add(ep);
/* 434 */       return true;
/*     */     } 
/* 436 */     return false;
/*     */   }
/*     */   
/*     */   public String getProperty(String name) {
/*     */     String result;
/* 441 */     if (name.startsWith("errorCode.")) {
/* 442 */       int code = Integer.parseInt(name.substring(10));
/* 443 */       ErrorPage ep = this.errorPageSupport.find(code);
/* 444 */       if (ep == null) {
/* 445 */         result = null;
/*     */       } else {
/* 447 */         result = ep.getLocation();
/*     */       } 
/* 449 */     } else if (name.startsWith("exceptionType.")) {
/* 450 */       String className = name.substring(14);
/* 451 */       ErrorPage ep = this.errorPageSupport.find(className);
/* 452 */       if (ep == null) {
/* 453 */         result = null;
/*     */       } else {
/* 455 */         result = ep.getLocation();
/*     */       } 
/*     */     } else {
/* 458 */       result = null;
/*     */     } 
/* 460 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\ErrorReportValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */