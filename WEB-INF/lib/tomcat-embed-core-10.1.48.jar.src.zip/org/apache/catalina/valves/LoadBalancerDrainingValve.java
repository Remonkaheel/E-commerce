/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.SessionCookieConfig;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.io.IOException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.SessionConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalancerDrainingValve
/*     */   extends ValveBase
/*     */ {
/*     */   public static final String ATTRIBUTE_KEY_JK_LB_ACTIVATION = "JK_LB_ACTIVATION";
/*  70 */   private int _redirectStatusCode = 307;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _ignoreCookieName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _ignoreCookieValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoadBalancerDrainingValve() {
/*  87 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRedirectStatusCode(int code) {
/* 101 */     this._redirectStatusCode = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIgnoreCookieName() {
/* 113 */     return this._ignoreCookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreCookieName(String cookieName) {
/* 126 */     this._ignoreCookieName = cookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIgnoreCookieValue() {
/* 138 */     return this._ignoreCookieValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreCookieValue(String cookieValue) {
/* 151 */     this._ignoreCookieValue = cookieValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 156 */     if ("DIS".equals(request.getAttribute("JK_LB_ACTIVATION")) && 
/* 157 */       !request.isRequestedSessionIdValid()) {
/*     */       
/* 159 */       if (this.containerLog.isDebugEnabled()) {
/* 160 */         this.containerLog.debug(sm.getString("loadBalancerDrainingValve.draining"));
/*     */       }
/*     */       
/* 163 */       boolean ignoreRebalance = false;
/* 164 */       Cookie sessionCookie = null;
/*     */       
/* 166 */       Cookie[] cookies = request.getCookies();
/*     */       
/* 168 */       String sessionCookieName = SessionConfig.getSessionCookieName(request.getContext());
/*     */       
/* 170 */       if (null != cookies) {
/* 171 */         for (Cookie cookie : cookies) {
/* 172 */           String cookieName = cookie.getName();
/* 173 */           if (this.containerLog.isTraceEnabled()) {
/* 174 */             this.containerLog.trace("Checking cookie " + cookieName + "=" + cookie.getValue());
/*     */           }
/*     */           
/* 177 */           if (sessionCookieName.equals(cookieName) && request
/* 178 */             .getRequestedSessionId().equals(cookie.getValue())) {
/* 179 */             sessionCookie = cookie;
/* 180 */           } else if (null != this._ignoreCookieName && this._ignoreCookieName.equals(cookieName) && null != this._ignoreCookieValue && this._ignoreCookieValue
/* 181 */             .equals(cookie.getValue())) {
/*     */             
/* 183 */             ignoreRebalance = true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 188 */       if (ignoreRebalance) {
/* 189 */         if (this.containerLog.isDebugEnabled()) {
/* 190 */           this.containerLog.debug(sm.getString("loadBalancerDrainingValve.skip", new Object[] { this._ignoreCookieName }));
/*     */         }
/*     */         
/* 193 */         getNext().invoke(request, response);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 200 */       if (null != sessionCookie) {
/* 201 */         sessionCookie.setPath(SessionConfig.getSessionCookiePath(request.getContext()));
/* 202 */         sessionCookie.setMaxAge(0);
/* 203 */         sessionCookie.setValue("");
/*     */ 
/*     */         
/* 206 */         SessionCookieConfig sessionCookieConfig = request.getContext().getServletContext().getSessionCookieConfig();
/* 207 */         sessionCookie.setSecure((request.isSecure() || sessionCookieConfig.isSecure()));
/* 208 */         response.addCookie(sessionCookie);
/*     */       } 
/*     */ 
/*     */       
/* 212 */       String uri = request.getRequestURI();
/* 213 */       String sessionURIParamName = SessionConfig.getSessionUriParamName(request.getContext());
/* 214 */       if (uri.contains(";" + sessionURIParamName + "=")) {
/* 215 */         uri = uri.replaceFirst(";" + sessionURIParamName + "=[^&?]*", "");
/*     */       }
/*     */       
/* 218 */       String queryString = request.getQueryString();
/*     */       
/* 220 */       if (null != queryString) {
/* 221 */         uri = uri + "?" + uri;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 226 */       response.setHeader("Location", uri);
/* 227 */       response.setStatus(this._redirectStatusCode);
/*     */     } else {
/* 229 */       getNext().invoke(request, response);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\LoadBalancerDrainingValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */