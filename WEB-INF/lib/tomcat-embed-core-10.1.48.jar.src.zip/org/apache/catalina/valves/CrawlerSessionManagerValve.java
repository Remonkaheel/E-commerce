/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.HttpSessionBindingEvent;
/*     */ import jakarta.servlet.http.HttpSessionBindingListener;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrawlerSessionManagerValve
/*     */   extends ValveBase
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(CrawlerSessionManagerValve.class);
/*     */   
/*  48 */   private final Map<String, String> clientIdSessionId = new ConcurrentHashMap<>();
/*     */   
/*  50 */   private String crawlerUserAgents = ".*[bB]ot.*|.*Yahoo! Slurp.*|.*Feedfetcher-Google.*";
/*  51 */   private Pattern uaPattern = null;
/*     */   
/*  53 */   private String crawlerIps = null;
/*  54 */   private Pattern ipPattern = null;
/*     */   
/*  56 */   private int sessionInactiveInterval = 60;
/*     */ 
/*     */   
/*     */   private boolean isHostAware = true;
/*     */ 
/*     */   
/*     */   private boolean isContextAware = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public CrawlerSessionManagerValve() {
/*  67 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCrawlerUserAgents(String crawlerUserAgents) {
/*  78 */     this.crawlerUserAgents = crawlerUserAgents;
/*  79 */     if (crawlerUserAgents == null || crawlerUserAgents.isEmpty()) {
/*  80 */       this.uaPattern = null;
/*     */     } else {
/*  82 */       this.uaPattern = Pattern.compile(crawlerUserAgents);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCrawlerUserAgents() {
/*  92 */     return this.crawlerUserAgents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCrawlerIps(String crawlerIps) {
/* 103 */     this.crawlerIps = crawlerIps;
/* 104 */     if (crawlerIps == null || crawlerIps.isEmpty()) {
/* 105 */       this.ipPattern = null;
/*     */     } else {
/* 107 */       this.ipPattern = Pattern.compile(crawlerIps);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCrawlerIps() {
/* 117 */     return this.crawlerIps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionInactiveInterval(int sessionInactiveInterval) {
/* 128 */     this.sessionInactiveInterval = sessionInactiveInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSessionInactiveInterval() {
/* 137 */     return this.sessionInactiveInterval;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getClientIpSessionId() {
/* 142 */     return this.clientIdSessionId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHostAware() {
/* 147 */     return this.isHostAware;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHostAware(boolean isHostAware) {
/* 152 */     this.isHostAware = isHostAware;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isContextAware() {
/* 157 */     return this.isContextAware;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContextAware(boolean isContextAware) {
/* 162 */     this.isContextAware = isContextAware;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 168 */     super.initInternal();
/*     */     
/* 170 */     this.uaPattern = Pattern.compile(this.crawlerUserAgents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 177 */     Host host = request.getHost();
/* 178 */     if (host == null) {
/*     */       
/* 180 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/* 184 */     boolean isBot = false;
/* 185 */     String sessionId = null;
/* 186 */     String clientIp = request.getRemoteAddr();
/* 187 */     String clientIdentifier = getClientIdentifier(host, request.getContext(), clientIp);
/*     */     
/* 189 */     if (log.isTraceEnabled()) {
/* 190 */       log.trace("" + request.hashCode() + ": ClientIdentifier=" + request.hashCode() + ", RequestedSessionId=" + clientIdentifier);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (request.getSession(false) == null) {
/*     */ 
/*     */       
/* 198 */       Enumeration<String> uaHeaders = request.getHeaders("user-agent");
/* 199 */       String uaHeader = null;
/* 200 */       if (uaHeaders.hasMoreElements()) {
/* 201 */         uaHeader = uaHeaders.nextElement();
/*     */       }
/*     */ 
/*     */       
/* 205 */       if (uaHeader != null && !uaHeaders.hasMoreElements()) {
/*     */         
/* 207 */         if (log.isTraceEnabled()) {
/* 208 */           log.trace("" + request.hashCode() + ": UserAgent=" + request.hashCode());
/*     */         }
/*     */         
/* 211 */         if (this.uaPattern.matcher(uaHeader).matches()) {
/* 212 */           isBot = true;
/*     */           
/* 214 */           if (log.isTraceEnabled()) {
/* 215 */             log.trace("" + request.hashCode() + ": Bot found. UserAgent=" + request.hashCode());
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 220 */       if (this.ipPattern != null && this.ipPattern.matcher(clientIp).matches()) {
/* 221 */         isBot = true;
/*     */         
/* 223 */         if (log.isTraceEnabled()) {
/* 224 */           log.trace("" + request.hashCode() + ": Bot found. IP=" + request.hashCode());
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 229 */       if (isBot) {
/* 230 */         sessionId = this.clientIdSessionId.get(clientIdentifier);
/* 231 */         if (sessionId != null) {
/* 232 */           request.setRequestedSessionId(sessionId);
/* 233 */           if (log.isTraceEnabled()) {
/* 234 */             log.trace("" + request.hashCode() + ": SessionID=" + request.hashCode());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 240 */     getNext().invoke(request, response);
/*     */     
/* 242 */     if (isBot) {
/* 243 */       if (sessionId == null) {
/*     */         
/* 245 */         HttpSession s = request.getSession(false);
/* 246 */         if (s != null) {
/* 247 */           this.clientIdSessionId.put(clientIdentifier, s.getId());
/*     */           
/* 249 */           s.setAttribute(getClass().getName(), new CrawlerHttpSessionBindingListener(this.clientIdSessionId, clientIdentifier));
/*     */           
/* 251 */           s.setMaxInactiveInterval(this.sessionInactiveInterval);
/*     */           
/* 253 */           if (log.isTraceEnabled()) {
/* 254 */             log.trace("" + request.hashCode() + ": New bot session. SessionID=" + request.hashCode());
/*     */           }
/*     */         }
/*     */       
/* 258 */       } else if (log.isTraceEnabled()) {
/* 259 */         log.trace("" + request.hashCode() + ": Bot session accessed. SessionID=" + request.hashCode());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getClientIdentifier(Host host, Context context, String clientIp) {
/* 267 */     StringBuilder result = new StringBuilder(clientIp);
/* 268 */     if (this.isHostAware) {
/* 269 */       result.append('-').append(host.getName());
/*     */     }
/* 271 */     if (this.isContextAware && context != null) {
/* 272 */       result.append(context.getName());
/*     */     }
/* 274 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static class CrawlerHttpSessionBindingListener
/*     */     implements HttpSessionBindingListener, Serializable {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final transient Map<String, String> clientIdSessionId;
/*     */     private final transient String clientIdentifier;
/*     */     
/*     */     private CrawlerHttpSessionBindingListener(Map<String, String> clientIdSessionId, String clientIdentifier) {
/* 284 */       this.clientIdSessionId = clientIdSessionId;
/* 285 */       this.clientIdentifier = clientIdentifier;
/*     */     }
/*     */ 
/*     */     
/*     */     public void valueUnbound(HttpSessionBindingEvent event) {
/* 290 */       if (this.clientIdentifier != null && this.clientIdSessionId != null)
/* 291 */         this.clientIdSessionId.remove(this.clientIdentifier, event.getSession().getId()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\CrawlerSessionManagerValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */