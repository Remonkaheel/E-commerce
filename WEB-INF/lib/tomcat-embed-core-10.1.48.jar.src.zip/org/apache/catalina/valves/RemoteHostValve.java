/*    */ package org.apache.catalina.valves;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.io.IOException;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RemoteHostValve
/*    */   extends RequestFilterValve
/*    */ {
/* 34 */   private static final Log log = LogFactory.getLog(RemoteHostValve.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*    */     String property;
/* 42 */     if (getAddConnectorPort()) {
/* 43 */       property = request.getRequest().getRemoteHost() + ";" + request.getRequest().getRemoteHost();
/*    */     } else {
/* 45 */       property = request.getRequest().getRemoteHost();
/*    */     } 
/* 47 */     process(property, request, response);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 53 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\valves\RemoteHostValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */