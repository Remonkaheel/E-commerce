/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UserConfig
/*     */   implements LifecycleListener
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(UserConfig.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private String configClass = "org.apache.catalina.startup.ContextConfig";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private String contextClass = "org.apache.catalina.core.StandardContext";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private String directoryName = "public_html";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private String homeBase = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private Host host = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private String userClass = "org.apache.catalina.startup.PasswdUserDatabase";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   Pattern allow = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   Pattern deny = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConfigClass() {
/* 111 */     return this.configClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigClass(String configClass) {
/* 121 */     this.configClass = configClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextClass() {
/* 129 */     return this.contextClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextClass(String contextClass) {
/* 139 */     this.contextClass = contextClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDirectoryName() {
/* 147 */     return this.directoryName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectoryName(String directoryName) {
/* 157 */     this.directoryName = directoryName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHomeBase() {
/* 165 */     return this.homeBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHomeBase(String homeBase) {
/* 175 */     this.homeBase = homeBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserClass() {
/* 183 */     return this.userClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserClass(String userClass) {
/* 193 */     this.userClass = userClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllow() {
/* 200 */     if (this.allow == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     return this.allow.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllow(String allow) {
/* 213 */     if (allow == null || allow.isEmpty()) {
/* 214 */       this.allow = null;
/*     */     } else {
/* 216 */       this.allow = Pattern.compile(allow);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeny() {
/* 225 */     if (this.deny == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     return this.deny.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeny(String deny) {
/* 238 */     if (deny == null || deny.isEmpty()) {
/* 239 */       this.deny = null;
/*     */     } else {
/* 241 */       this.deny = Pattern.compile(deny);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*     */     try {
/* 258 */       this.host = (Host)event.getLifecycle();
/* 259 */     } catch (ClassCastException e) {
/* 260 */       log.error(sm.getString("hostConfig.cce", new Object[] { event.getLifecycle() }), e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 265 */     if (event.getType().equals("start")) {
/* 266 */       start();
/* 267 */     } else if (event.getType().equals("stop")) {
/* 268 */       stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deploy() {
/*     */     UserDatabase database;
/* 283 */     if (this.host.getLogger().isTraceEnabled()) {
/* 284 */       this.host.getLogger().trace(sm.getString("userConfig.deploying"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 290 */       Class<?> clazz = Class.forName(this.userClass);
/* 291 */       database = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 292 */       database.setUserConfig(this);
/* 293 */     } catch (Exception e) {
/* 294 */       this.host.getLogger().error(sm.getString("userConfig.database"), e);
/*     */       
/*     */       return;
/*     */     } 
/* 298 */     ExecutorService executor = this.host.getStartStopExecutor();
/* 299 */     List<Future<?>> results = new ArrayList<>();
/*     */ 
/*     */     
/* 302 */     Enumeration<String> users = database.getUsers();
/* 303 */     while (users.hasMoreElements()) {
/* 304 */       String user = users.nextElement();
/* 305 */       if (!isDeployAllowed(user)) {
/*     */         continue;
/*     */       }
/* 308 */       String home = database.getHome(user);
/* 309 */       results.add(executor.submit(new DeployUserDirectory(this, user, home)));
/*     */     } 
/*     */     
/* 312 */     for (Future<?> result : results) {
/*     */       try {
/* 314 */         result.get();
/* 315 */       } catch (Exception e) {
/* 316 */         this.host.getLogger().error(sm.getString("userConfig.deploy.threaded.error"), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deploy(String user, String home) {
/* 332 */     String contextPath = "/~" + user;
/* 333 */     if (this.host.findChild(contextPath) != null) {
/*     */       return;
/*     */     }
/* 336 */     File app = new File(home, this.directoryName);
/* 337 */     if (!app.exists() || !app.isDirectory()) {
/*     */       return;
/*     */     }
/*     */     
/* 341 */     this.host.getLogger().info(sm.getString("userConfig.deploy", new Object[] { user }));
/*     */ 
/*     */     
/*     */     try {
/* 345 */       Class<?> clazz = Class.forName(this.contextClass);
/* 346 */       Context context = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 347 */       context.setPath(contextPath);
/* 348 */       context.setDocBase(app.toString());
/* 349 */       clazz = Class.forName(this.configClass);
/* 350 */       LifecycleListener listener = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 351 */       context.addLifecycleListener(listener);
/* 352 */       this.host.addChild((Container)context);
/* 353 */     } catch (Exception e) {
/* 354 */       this.host.getLogger().error(sm.getString("userConfig.error", new Object[] { user }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void start() {
/* 365 */     if (this.host.getLogger().isDebugEnabled()) {
/* 366 */       this.host.getLogger().debug(sm.getString("userConfig.start"));
/*     */     }
/*     */     
/* 369 */     deploy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void stop() {
/* 379 */     if (this.host.getLogger().isDebugEnabled()) {
/* 380 */       this.host.getLogger().debug(sm.getString("userConfig.stop"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDeployAllowed(String user) {
/* 391 */     if (this.deny != null && this.deny.matcher(user).matches()) {
/* 392 */       return false;
/*     */     }
/* 394 */     if (this.allow != null) {
/* 395 */       return this.allow.matcher(user).matches();
/*     */     }
/* 397 */     return true;
/*     */   }
/*     */   
/*     */   private static class DeployUserDirectory
/*     */     implements Runnable {
/*     */     private final UserConfig config;
/*     */     private final String user;
/*     */     private final String home;
/*     */     
/*     */     DeployUserDirectory(UserConfig config, String user, String home) {
/* 407 */       this.config = config;
/* 408 */       this.user = user;
/* 409 */       this.home = home;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 414 */       this.config.deploy(this.user, this.home);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\UserConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */