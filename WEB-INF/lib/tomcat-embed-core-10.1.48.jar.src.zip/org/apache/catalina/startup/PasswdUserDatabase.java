/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.FileReader;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.naming.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PasswdUserDatabase
/*    */   implements UserDatabase
/*    */ {
/* 36 */   private static final Log log = LogFactory.getLog(PasswdUserDatabase.class);
/* 37 */   private static final StringManager sm = StringManager.getManager(PasswdUserDatabase.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final String PASSWORD_FILE = "/etc/passwd";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   private final Map<String, String> homes = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   private UserConfig userConfig = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public UserConfig getUserConfig() {
/* 59 */     return this.userConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUserConfig(UserConfig userConfig) {
/* 65 */     this.userConfig = userConfig;
/* 66 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHome(String user) {
/* 72 */     return this.homes.get(user);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Enumeration<String> getUsers() {
/* 78 */     return Collections.enumeration(this.homes.keySet());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/*    */     
/* 86 */     try { BufferedReader reader = new BufferedReader(new FileReader("/etc/passwd")); 
/* 87 */       try { String line = reader.readLine();
/* 88 */         while (line != null) {
/* 89 */           String[] tokens = line.split(":");
/*    */           
/* 91 */           if (tokens.length > 5 && !tokens[0].isEmpty() && !tokens[5].isEmpty())
/*    */           {
/* 93 */             this.homes.put(tokens[0], tokens[5]);
/*    */           }
/* 95 */           line = reader.readLine();
/*    */         } 
/* 97 */         reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/* 98 */     { log.warn(sm.getString("passwdUserDatabase.readFail"), e); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\PasswdUserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */