/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetNextNamingRule
/*     */   extends Rule
/*     */ {
/*     */   protected final String methodName;
/*     */   protected final String paramType;
/*     */   
/*     */   public SetNextNamingRule(String methodName, String paramType) {
/*  49 */     this.methodName = methodName;
/*  50 */     this.paramType = paramType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end(String namespace, String name) throws Exception {
/*     */     NamingResourcesImpl namingResources;
/*  77 */     Object child = this.digester.peek(0);
/*  78 */     Object parent = this.digester.peek(1);
/*  79 */     boolean context = false;
/*     */ 
/*     */     
/*  82 */     if (parent instanceof Context) {
/*  83 */       namingResources = ((Context)parent).getNamingResources();
/*  84 */       context = true;
/*     */     } else {
/*  86 */       namingResources = (NamingResourcesImpl)parent;
/*     */     } 
/*     */ 
/*     */     
/*  90 */     IntrospectionUtils.callMethod1(namingResources, this.methodName, child, this.paramType, this.digester.getClassLoader());
/*     */     
/*  92 */     StringBuilder code = this.digester.getGeneratedCode();
/*  93 */     if (code != null) {
/*  94 */       if (context) {
/*  95 */         code.append(this.digester.toVariableName(parent)).append(".getNamingResources()");
/*     */       } else {
/*  97 */         code.append(this.digester.toVariableName(namingResources));
/*     */       } 
/*  99 */       code.append('.').append(this.methodName).append('(');
/* 100 */       code.append(this.digester.toVariableName(child)).append(");");
/* 101 */       code.append(System.lineSeparator());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "SetNextRule[methodName=" + this.methodName + ", paramType=" + this.paramType + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\SetNextNamingRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */