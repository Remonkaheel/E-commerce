/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EngineRuleSet
/*    */   implements RuleSet
/*    */ {
/*    */   protected final String prefix;
/*    */   
/*    */   public EngineRuleSet() {
/* 42 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EngineRuleSet(String prefix) {
/* 52 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRuleInstances(Digester digester) {
/* 61 */     digester.addObjectCreate(this.prefix + "Engine", "org.apache.catalina.core.StandardEngine", "className");
/* 62 */     digester.addSetProperties(this.prefix + "Engine");
/* 63 */     digester.addRule(this.prefix + "Engine", new LifecycleListenerRule("org.apache.catalina.startup.EngineConfig", "engineConfigClass"));
/*    */     
/* 65 */     digester.addSetNext(this.prefix + "Engine", "setContainer", "org.apache.catalina.Engine");
/*    */ 
/*    */     
/* 68 */     digester.addObjectCreate(this.prefix + "Engine/Cluster", null, "className");
/*    */     
/* 70 */     digester.addSetProperties(this.prefix + "Engine/Cluster");
/* 71 */     digester.addSetNext(this.prefix + "Engine/Cluster", "setCluster", "org.apache.catalina.Cluster");
/*    */ 
/*    */     
/* 74 */     digester.addObjectCreate(this.prefix + "Engine/Listener", null, "className");
/*    */     
/* 76 */     digester.addSetProperties(this.prefix + "Engine/Listener");
/* 77 */     digester.addSetNext(this.prefix + "Engine/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*    */ 
/*    */ 
/*    */     
/* 81 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Engine/"));
/*    */     
/* 83 */     digester.addObjectCreate(this.prefix + "Engine/Valve", null, "className");
/*    */     
/* 85 */     digester.addSetProperties(this.prefix + "Engine/Valve");
/* 86 */     digester.addSetNext(this.prefix + "Engine/Valve", "addValve", "org.apache.catalina.Valve");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\EngineRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */