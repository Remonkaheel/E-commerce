/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectorCreateRule
/*     */   extends Rule
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(ConnectorCreateRule.class);
/*  40 */   protected static final StringManager sm = StringManager.getManager(ConnectorCreateRule.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/*  46 */     Service svc = (Service)this.digester.peek();
/*  47 */     Executor ex = null;
/*  48 */     String executorName = attributes.getValue("executor");
/*  49 */     if (executorName != null) {
/*  50 */       ex = svc.getExecutor(executorName);
/*     */     }
/*  52 */     String protocolName = attributes.getValue("protocol");
/*  53 */     Connector con = new Connector(protocolName);
/*  54 */     if (ex != null) {
/*  55 */       setExecutor(con, ex);
/*     */     }
/*  57 */     String sslImplementationName = attributes.getValue("sslImplementationName");
/*  58 */     if (sslImplementationName != null) {
/*  59 */       setSSLImplementationName(con, sslImplementationName);
/*     */     }
/*  61 */     this.digester.push(con);
/*     */     
/*  63 */     StringBuilder code = this.digester.getGeneratedCode();
/*  64 */     if (code != null) {
/*  65 */       code.append(System.lineSeparator());
/*  66 */       code.append(Connector.class.getName()).append(' ').append(this.digester.toVariableName(con));
/*  67 */       code.append(" = new ").append(Connector.class.getName());
/*  68 */       code.append("(new ").append(con.getProtocolHandlerClassName()).append("());");
/*  69 */       code.append(System.lineSeparator());
/*  70 */       if (ex != null) {
/*  71 */         code.append(this.digester.toVariableName(con)).append(".getProtocolHandler().setExecutor(");
/*  72 */         code.append(this.digester.toVariableName(svc)).append(".getExecutor(\"").append(executorName);
/*  73 */         code.append("\"));");
/*  74 */         code.append(System.lineSeparator());
/*     */       } 
/*  76 */       if (sslImplementationName != null) {
/*  77 */         code.append("((").append(AbstractHttp11JsseProtocol.class.getName()).append("<?>) ");
/*  78 */         code.append(this.digester.toVariableName(con)).append(".getProtocolHandler()).setSslImplementationName(\"");
/*  79 */         code.append(sslImplementationName).append("\");");
/*  80 */         code.append(System.lineSeparator());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void setExecutor(Connector con, Executor ex) throws Exception {
/*  86 */     Method m = IntrospectionUtils.findMethod(con.getProtocolHandler().getClass(), "setExecutor", new Class[] { Executor.class });
/*     */     
/*  88 */     if (m != null) {
/*  89 */       m.invoke(con.getProtocolHandler(), new Object[] { ex });
/*     */     } else {
/*  91 */       log.warn(sm.getString("connector.noSetExecutor", new Object[] { con }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void setSSLImplementationName(Connector con, String sslImplementationName) throws Exception {
/*  96 */     Method m = IntrospectionUtils.findMethod(con.getProtocolHandler().getClass(), "setSslImplementationName", new Class[] { String.class });
/*     */     
/*  98 */     if (m != null) {
/*  99 */       m.invoke(con.getProtocolHandler(), new Object[] { sslImplementationName });
/*     */     } else {
/* 101 */       log.warn(sm.getString("connector.noSetSSLImplementationName", new Object[] { con }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void end(String namespace, String name) throws Exception {
/* 107 */     this.digester.pop();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\ConnectorCreateRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */