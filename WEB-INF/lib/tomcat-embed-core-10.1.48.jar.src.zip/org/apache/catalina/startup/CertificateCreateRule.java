/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Rule;
/*    */ import org.apache.tomcat.util.net.SSLHostConfig;
/*    */ import org.apache.tomcat.util.net.SSLHostConfigCertificate;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertificateCreateRule
/*    */   extends Rule
/*    */ {
/*    */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/*    */     SSLHostConfigCertificate.Type type;
/* 32 */     SSLHostConfig sslHostConfig = (SSLHostConfig)this.digester.peek();
/*    */ 
/*    */     
/* 35 */     String typeValue = attributes.getValue("type");
/* 36 */     if (typeValue == null || typeValue.isEmpty()) {
/* 37 */       type = SSLHostConfigCertificate.Type.UNDEFINED;
/*    */     } else {
/* 39 */       type = SSLHostConfigCertificate.Type.valueOf(typeValue);
/*    */     } 
/*    */     
/* 42 */     SSLHostConfigCertificate certificate = new SSLHostConfigCertificate(sslHostConfig, type);
/*    */     
/* 44 */     this.digester.push(certificate);
/*    */     
/* 46 */     StringBuilder code = this.digester.getGeneratedCode();
/* 47 */     if (code != null) {
/* 48 */       code.append(SSLHostConfigCertificate.class.getName()).append(' ')
/* 49 */         .append(this.digester.toVariableName(certificate));
/* 50 */       code.append(" = new ").append(SSLHostConfigCertificate.class.getName());
/* 51 */       code.append('(').append(this.digester.toVariableName(sslHostConfig));
/* 52 */       code.append(", ").append(SSLHostConfigCertificate.Type.class.getName().replace('$', '.')).append('.').append(type).append(");");
/* 53 */       code.append(System.lineSeparator());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void end(String namespace, String name) throws Exception {
/* 60 */     this.digester.pop();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\CertificateCreateRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */