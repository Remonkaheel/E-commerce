/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.tomcat.util.scan.JarFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebappServiceLoader<T>
/*     */ {
/*     */   private static final String CLASSES = "/WEB-INF/classes/";
/*     */   private static final String LIB = "/WEB-INF/lib/";
/*     */   private static final String SERVICES = "META-INF/services/";
/*     */   private final Context context;
/*     */   private final ServletContext servletContext;
/*     */   private final Pattern containerSciFilterPattern;
/*     */   
/*     */   public WebappServiceLoader(Context context) {
/*  75 */     this.context = context;
/*  76 */     this.servletContext = context.getServletContext();
/*  77 */     String containerSciFilter = context.getContainerSciFilter();
/*  78 */     if (containerSciFilter != null && !containerSciFilter.isEmpty()) {
/*  79 */       this.containerSciFilterPattern = Pattern.compile(containerSciFilter);
/*     */     } else {
/*  81 */       this.containerSciFilterPattern = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> load(Class<T> serviceType) throws IOException {
/*     */     Enumeration<URL> containerResources;
/*  99 */     String configFile = "META-INF/services/" + serviceType.getName();
/*     */ 
/*     */     
/* 102 */     ClassLoader loader = this.context.getParentClassLoader();
/*     */     
/* 104 */     if (loader == null) {
/* 105 */       containerResources = ClassLoader.getSystemResources(configFile);
/*     */     } else {
/* 107 */       containerResources = loader.getResources(configFile);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     LinkedHashSet<String> containerServiceClassNames = new LinkedHashSet<>();
/* 115 */     Set<URL> containerServiceConfigFiles = new HashSet<>();
/* 116 */     while (containerResources.hasMoreElements()) {
/* 117 */       URL containerServiceConfigFile = containerResources.nextElement();
/* 118 */       containerServiceConfigFiles.add(containerServiceConfigFile);
/* 119 */       parseConfigFile(containerServiceClassNames, containerServiceConfigFile);
/*     */     } 
/*     */ 
/*     */     
/* 123 */     if (this.containerSciFilterPattern != null) {
/* 124 */       containerServiceClassNames.removeIf(s -> this.containerSciFilterPattern.matcher(s).find());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     LinkedHashSet<String> applicationServiceClassNames = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */     
/* 141 */     List<String> orderedLibs = (List<String>)this.servletContext.getAttribute("jakarta.servlet.context.orderedLibs");
/*     */ 
/*     */     
/* 144 */     if (orderedLibs == null) {
/*     */ 
/*     */       
/* 147 */       Enumeration<URL> allResources = this.servletContext.getClassLoader().getResources(configFile);
/* 148 */       while (allResources.hasMoreElements()) {
/* 149 */         URL serviceConfigFile = allResources.nextElement();
/*     */ 
/*     */         
/* 152 */         if (!containerServiceConfigFiles.contains(serviceConfigFile)) {
/* 153 */           parseConfigFile(applicationServiceClassNames, serviceConfigFile);
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 159 */       URL unpacked = this.servletContext.getResource("/WEB-INF/classes/" + configFile);
/* 160 */       if (unpacked != null) {
/* 161 */         parseConfigFile(applicationServiceClassNames, unpacked);
/*     */       }
/*     */       
/* 164 */       for (String lib : orderedLibs) {
/* 165 */         URL url, jarUrl = this.servletContext.getResource("/WEB-INF/lib/" + lib);
/* 166 */         if (jarUrl == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 171 */         String base = jarUrl.toExternalForm();
/*     */         
/* 173 */         if (base.endsWith("/")) {
/*     */           URI uri;
/*     */           try {
/* 176 */             uri = new URI(base + base);
/* 177 */           } catch (URISyntaxException e) {
/*     */             
/* 179 */             throw new IOException(e);
/*     */           } 
/* 181 */           url = uri.toURL();
/*     */         } else {
/* 183 */           url = JarFactory.getJarEntryURL(jarUrl, configFile);
/*     */         } 
/*     */         try {
/* 186 */           parseConfigFile(applicationServiceClassNames, url);
/* 187 */         } catch (FileNotFoundException uri) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     containerServiceClassNames.addAll(applicationServiceClassNames);
/*     */ 
/*     */     
/* 198 */     if (containerServiceClassNames.isEmpty()) {
/* 199 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 202 */     return loadServices(serviceType, containerServiceClassNames);
/*     */   }
/*     */ 
/*     */   
/*     */   void parseConfigFile(LinkedHashSet<String> servicesFound, URL url) throws IOException {
/* 207 */     InputStream is = url.openStream(); 
/* 208 */     try { InputStreamReader in = new InputStreamReader(is, StandardCharsets.UTF_8); 
/* 209 */       try { BufferedReader reader = new BufferedReader(in); 
/*     */         try { String line;
/* 211 */           while ((line = reader.readLine()) != null) {
/* 212 */             int i = line.indexOf('#');
/* 213 */             if (i >= 0) {
/* 214 */               line = line.substring(0, i);
/*     */             }
/* 216 */             line = line.trim();
/* 217 */             if (line.isEmpty()) {
/*     */               continue;
/*     */             }
/* 220 */             servicesFound.add(line);
/*     */           } 
/* 222 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (is != null) is.close();  }
/*     */     catch (Throwable throwable) { if (is != null)
/*     */         try { is.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 227 */      } List<T> loadServices(Class<T> serviceType, LinkedHashSet<String> servicesFound) throws IOException { ClassLoader loader = this.servletContext.getClassLoader();
/* 228 */     List<T> services = new ArrayList<>(servicesFound.size());
/* 229 */     for (String serviceClass : servicesFound) {
/*     */       try {
/* 231 */         Class<?> clazz = Class.forName(serviceClass, true, loader);
/* 232 */         services.add(serviceType.cast(clazz.getConstructor(new Class[0]).newInstance(new Object[0])));
/* 233 */       } catch (ReflectiveOperationException|ClassCastException e) {
/* 234 */         throw new IOException(e);
/*     */       } 
/*     */     } 
/* 237 */     return Collections.unmodifiableList(services); }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\WebappServiceLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */