/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipException;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandWar
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(ExpandWar.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String expand(Host host, URL war, String pathname) throws IOException {
/*     */     long warLastModified;
/*  72 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/*  73 */     juc.setUseCaches(false);
/*  74 */     URL jarFileUrl = juc.getJarFileURL();
/*  75 */     URLConnection jfuc = jarFileUrl.openConnection();
/*     */     
/*  77 */     boolean success = false;
/*  78 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*  79 */     File warTracker = new File(host.getAppBaseFile(), pathname + "/META-INF/war-tracker");
/*     */ 
/*     */     
/*  82 */     InputStream is = jfuc.getInputStream();
/*     */     
/*  84 */     try { warLastModified = jfuc.getLastModified();
/*  85 */       if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/*     */         try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/*  88 */      if (docBase.exists()) {
/*     */ 
/*     */ 
/*     */       
/*  92 */       if (!warTracker.exists() || warTracker.lastModified() == warLastModified)
/*     */       {
/*     */         
/*  95 */         return docBase.getAbsolutePath();
/*     */       }
/*     */ 
/*     */       
/*  99 */       log.info(sm.getString("expandWar.deleteOld", new Object[] { docBase }));
/* 100 */       if (!delete(docBase)) {
/* 101 */         throw new IOException(sm.getString("expandWar.deleteFailed", new Object[] { docBase }));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 106 */     if (!docBase.mkdir() && !docBase.isDirectory()) {
/* 107 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { docBase }));
/*     */     }
/*     */ 
/*     */     
/* 111 */     Path canonicalDocBasePath = docBase.getCanonicalFile().toPath();
/*     */ 
/*     */     
/* 114 */     File warTrackerParent = warTracker.getParentFile();
/* 115 */     if (!warTrackerParent.isDirectory() && !warTrackerParent.mkdirs()) {
/* 116 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { warTrackerParent.getAbsolutePath() }));
/*     */     }
/*     */     
/* 119 */     try { JarFile jarFile = juc.getJarFile();
/*     */       
/* 121 */       try { Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 122 */         while (jarEntries.hasMoreElements()) {
/* 123 */           JarEntry jarEntry = jarEntries.nextElement();
/* 124 */           String name = jarEntry.getName();
/* 125 */           File expandedFile = new File(docBase, name);
/* 126 */           if (!expandedFile.getCanonicalFile().toPath().startsWith(canonicalDocBasePath))
/*     */           {
/*     */             
/* 129 */             throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile
/* 130 */                     .getCanonicalPath(), canonicalDocBasePath }));
/*     */           }
/* 132 */           int last = name.lastIndexOf('/');
/* 133 */           if (last >= 0) {
/* 134 */             File parent = new File(docBase, name.substring(0, last));
/* 135 */             if (!parent.mkdirs() && !parent.isDirectory()) {
/* 136 */               throw new IOException(sm.getString("expandWar.createFailed", new Object[] { parent }));
/*     */             }
/*     */           } 
/* 139 */           if (name.endsWith("/")) {
/*     */             continue;
/*     */           }
/*     */           
/* 143 */           InputStream input = jarFile.getInputStream(jarEntry); 
/* 144 */           try { if (null == input) {
/* 145 */               throw new ZipException(sm.getString("expandWar.missingJarEntry", new Object[] { jarEntry.getName() }));
/*     */             }
/*     */ 
/*     */             
/* 149 */             expand(input, expandedFile);
/* 150 */             long lastModified = jarEntry.getTime();
/* 151 */             if (lastModified != -1L && lastModified != 0L && 
/* 152 */               !expandedFile.setLastModified(lastModified)) {
/* 153 */               throw new IOException(sm.getString("expandWar.lastModifiedFailed", new Object[] { expandedFile }));
/*     */             }
/*     */             
/* 156 */             if (input != null) input.close();  } catch (Throwable throwable) { if (input != null)
/*     */               try { input.close(); }
/*     */               catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */                 throw throwable; }
/*     */         
/* 161 */         }  if (!warTracker.createNewFile()) {
/* 162 */           throw new IOException(sm.getString("expandWar.createFileFailed", new Object[] { warTracker }));
/*     */         }
/* 164 */         if (!warTracker.setLastModified(warLastModified)) {
/* 165 */           throw new IOException(sm.getString("expandWar.lastModifiedFailed", new Object[] { warTracker }));
/*     */         }
/*     */         
/* 168 */         success = true;
/* 169 */         if (jarFile != null) jarFile.close();  } catch (Throwable throwable) { if (jarFile != null)
/* 170 */           try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } finally { if (!success)
/*     */       {
/*     */         
/* 173 */         deleteDir(docBase);
/*     */       } }
/*     */ 
/*     */ 
/*     */     
/* 178 */     return docBase.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validate(Host host, URL war, String pathname) throws IOException {
/* 194 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*     */ 
/*     */     
/* 197 */     Path canonicalDocBasePath = docBase.getCanonicalFile().toPath();
/* 198 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/* 199 */     juc.setUseCaches(false);
/* 200 */     JarFile jarFile = juc.getJarFile(); try {
/* 201 */       Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 202 */       while (jarEntries.hasMoreElements()) {
/* 203 */         JarEntry jarEntry = jarEntries.nextElement();
/* 204 */         String name = jarEntry.getName();
/* 205 */         File expandedFile = new File(docBase, name);
/* 206 */         if (!expandedFile.getCanonicalFile().toPath().startsWith(canonicalDocBasePath))
/*     */         {
/*     */           
/* 209 */           throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile
/* 210 */                   .getCanonicalPath(), canonicalDocBasePath }));
/*     */         }
/*     */       } 
/* 213 */       if (jarFile != null) jarFile.close(); 
/*     */     } catch (Throwable throwable) {
/*     */       if (jarFile != null)
/*     */         try {
/*     */           jarFile.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean copy(File src, File dest) {
/*     */     String[] files;
/* 227 */     boolean result = true;
/*     */ 
/*     */     
/* 230 */     if (src.isDirectory()) {
/* 231 */       files = src.list();
/* 232 */       result = dest.mkdir();
/*     */     } else {
/* 234 */       files = new String[1];
/* 235 */       files[0] = "";
/*     */     } 
/* 237 */     if (files == null) {
/* 238 */       files = new String[0];
/*     */     }
/* 240 */     for (int i = 0; i < files.length && result; i++) {
/* 241 */       File fileSrc = new File(src, files[i]);
/* 242 */       File fileDest = new File(dest, files[i]);
/* 243 */       if (fileSrc.isDirectory())
/* 244 */       { result = copy(fileSrc, fileDest); }
/*     */       else { 
/* 246 */         try { FileInputStream fis = new FileInputStream(fileSrc); 
/* 247 */           try { FileChannel ic = fis.getChannel(); 
/* 248 */             try { FileOutputStream fos = new FileOutputStream(fileDest); 
/* 249 */               try { FileChannel oc = fos.getChannel(); 
/* 250 */                 try { long size = ic.size();
/* 251 */                   long position = 0L;
/* 252 */                   while (size > 0L) {
/* 253 */                     long count = ic.transferTo(position, size, oc);
/* 254 */                     if (count > 0L) {
/* 255 */                       position += count;
/* 256 */                       size -= count; continue;
/*     */                     } 
/* 258 */                     throw new EOFException();
/*     */                   } 
/*     */                   
/* 261 */                   if (oc != null) oc.close();  } catch (Throwable throwable) { if (oc != null) try { oc.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (ic != null) ic.close();  } catch (Throwable throwable) { if (ic != null) try { ic.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  fis.close(); } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 262 */         { log.error(sm.getString("expandWar.copy", new Object[] { fileSrc, fileDest }), ioe);
/* 263 */           result = false; }
/*     */          }
/*     */     
/*     */     } 
/* 267 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean delete(File dir) {
/* 281 */     return delete(dir, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean delete(File dir, boolean logFailure) {
/*     */     boolean result;
/* 295 */     if (dir.isDirectory()) {
/* 296 */       result = deleteDir(dir, logFailure);
/*     */     }
/* 298 */     else if (dir.exists()) {
/* 299 */       result = dir.delete();
/*     */     } else {
/* 301 */       result = true;
/*     */     } 
/*     */     
/* 304 */     if (logFailure && !result) {
/* 305 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] { dir.getAbsolutePath() }));
/*     */     }
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean deleteDir(File dir) {
/* 320 */     return deleteDir(dir, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean deleteDir(File dir, boolean logFailure) {
/*     */     boolean result;
/* 334 */     String[] files = dir.list();
/* 335 */     if (files == null) {
/* 336 */       files = new String[0];
/*     */     }
/* 338 */     for (String s : files) {
/* 339 */       File file = new File(dir, s);
/* 340 */       if (file.isDirectory()) {
/* 341 */         deleteDir(file, logFailure);
/*     */       } else {
/* 343 */         file.delete();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 348 */     if (dir.exists()) {
/* 349 */       result = dir.delete();
/*     */     } else {
/* 351 */       result = true;
/*     */     } 
/*     */     
/* 354 */     if (logFailure && !result) {
/* 355 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] { dir.getAbsolutePath() }));
/*     */     }
/*     */     
/* 358 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void expand(InputStream input, File file) throws IOException {
/* 371 */     BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file)); try {
/* 372 */       byte[] buffer = new byte[2048];
/*     */       while (true) {
/* 374 */         int n = input.read(buffer);
/* 375 */         if (n <= 0) {
/*     */           break;
/*     */         }
/* 378 */         output.write(buffer, 0, n);
/*     */       } 
/* 380 */       output.close();
/*     */     } catch (Throwable throwable) {
/*     */       try {
/*     */         output.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       } 
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\ExpandWar.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */