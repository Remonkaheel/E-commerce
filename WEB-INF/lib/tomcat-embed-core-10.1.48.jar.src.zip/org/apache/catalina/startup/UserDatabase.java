package org.apache.catalina.startup;

import java.util.Enumeration;

public interface UserDatabase {
  UserConfig getUserConfig();
  
  void setUserConfig(UserConfig paramUserConfig);
  
  String getHome(String paramString);
  
  Enumeration<String> getUsers();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\UserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */