/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HomesUserDatabase
/*    */   implements UserDatabase
/*    */ {
/* 34 */   private final Map<String, String> homes = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   private UserConfig userConfig = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public UserConfig getUserConfig() {
/* 44 */     return this.userConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUserConfig(UserConfig userConfig) {
/* 50 */     this.userConfig = userConfig;
/* 51 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHome(String user) {
/* 57 */     return this.homes.get(user);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Enumeration<String> getUsers() {
/* 63 */     return Collections.enumeration(this.homes.keySet());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 72 */     String homeBase = this.userConfig.getHomeBase();
/* 73 */     File homeBaseDir = new File(homeBase);
/* 74 */     if (!homeBaseDir.exists() || !homeBaseDir.isDirectory()) {
/*    */       return;
/*    */     }
/* 77 */     String[] homeBaseFiles = homeBaseDir.list();
/* 78 */     if (homeBaseFiles == null) {
/*    */       return;
/*    */     }
/*    */     
/* 82 */     for (String homeBaseFile : homeBaseFiles) {
/* 83 */       File homeDir = new File(homeBaseDir, homeBaseFile);
/* 84 */       if (homeDir.isDirectory() && homeDir.canRead())
/*    */       {
/*    */         
/* 87 */         this.homes.put(homeBaseFile, homeDir.toString());
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\HomesUserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */