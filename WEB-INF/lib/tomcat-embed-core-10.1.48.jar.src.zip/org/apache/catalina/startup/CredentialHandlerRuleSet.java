/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CredentialHandlerRuleSet
/*    */   implements RuleSet
/*    */ {
/* 31 */   private static final int MAX_NESTED_LEVELS = Integer.getInteger("org.apache.catalina.startup.CredentialHandlerRuleSet.MAX_NESTED_LEVELS", 3).intValue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final String prefix;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CredentialHandlerRuleSet() {
/* 49 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CredentialHandlerRuleSet(String prefix) {
/* 59 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRuleInstances(Digester digester) {
/* 68 */     StringBuilder pattern = new StringBuilder(this.prefix);
/* 69 */     for (int i = 0; i < MAX_NESTED_LEVELS; i++) {
/* 70 */       if (i > 0) {
/* 71 */         pattern.append('/');
/*    */       }
/* 73 */       pattern.append("CredentialHandler");
/* 74 */       addRuleInstances(digester, pattern.toString(), (i == 0) ? "setCredentialHandler" : "addCredentialHandler");
/*    */     } 
/*    */   }
/*    */   
/*    */   private void addRuleInstances(Digester digester, String pattern, String methodName) {
/* 79 */     digester.addObjectCreate(pattern, null, "className");
/* 80 */     digester.addSetProperties(pattern);
/* 81 */     digester.addSetNext(pattern, methodName, "org.apache.catalina.CredentialHandler");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\CredentialHandlerRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */