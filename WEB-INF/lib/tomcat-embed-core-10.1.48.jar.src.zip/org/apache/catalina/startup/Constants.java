package org.apache.catalina.startup;

public final class Constants {
  public static final String Package = "org.apache.catalina.startup";
  
  public static final String ApplicationContextXml = "META-INF/context.xml";
  
  public static final String ApplicationWebXml = "/WEB-INF/web.xml";
  
  public static final String TomcatWebXml = "/WEB-INF/tomcat-web.xml";
  
  public static final String DefaultContextXml = "conf/context.xml";
  
  public static final String DefaultWebXml = "conf/web.xml";
  
  public static final String HostContextXml = "context.xml.default";
  
  public static final String HostWebXml = "web.xml.default";
  
  public static final String WarTracker = "/META-INF/war-tracker";
  
  public static final String NoDefaultWebXml = "org/apache/catalina/startup/NO_DEFAULT_XML";
  
  public static final String CATALINA_HOME_PROP = "catalina.home";
  
  public static final String CATALINA_BASE_PROP = "catalina.base";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */