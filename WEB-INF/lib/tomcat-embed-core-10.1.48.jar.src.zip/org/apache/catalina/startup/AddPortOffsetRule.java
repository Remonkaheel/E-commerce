/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.catalina.Server;
/*    */ import org.apache.catalina.connector.Connector;
/*    */ import org.apache.tomcat.util.digester.Rule;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddPortOffsetRule
/*    */   extends Rule
/*    */ {
/*    */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/* 30 */     Connector conn = (Connector)this.digester.peek();
/* 31 */     Server server = (Server)this.digester.peek(2);
/*    */     
/* 33 */     int portOffset = server.getPortOffset();
/* 34 */     conn.setPortOffset(portOffset);
/*    */     
/* 36 */     StringBuilder code = this.digester.getGeneratedCode();
/* 37 */     if (code != null) {
/* 38 */       code.append(this.digester.toVariableName(conn)).append(".setPortOffset(");
/* 39 */       code.append(this.digester.toVariableName(server)).append(".getPortOffset());");
/* 40 */       code.append(System.lineSeparator());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\AddPortOffsetRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */