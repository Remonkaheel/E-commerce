/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalinaBaseConfigurationSource
/*     */   implements ConfigurationSource
/*     */ {
/*  34 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */   public static final String LEGACY_SERVER_EMBED_XML = "server-embed.xml";
/*     */   
/*     */   private final String serverXmlPath;
/*     */   private final File catalinaBaseFile;
/*     */   private final URI catalinaBaseUri;
/*     */   
/*     */   public CatalinaBaseConfigurationSource(File catalinaBaseFile, String serverXmlPath) {
/*  43 */     this.catalinaBaseFile = catalinaBaseFile;
/*  44 */     this.catalinaBaseUri = catalinaBaseFile.toURI();
/*  45 */     this.serverXmlPath = serverXmlPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationSource.Resource getServerXml() throws IOException {
/*  50 */     IOException ioException = null;
/*  51 */     ConfigurationSource.Resource result = null;
/*     */     try {
/*  53 */       if (this.serverXmlPath == null || this.serverXmlPath.equals("conf/server.xml")) {
/*  54 */         result = super.getServerXml();
/*     */       } else {
/*  56 */         result = getResource(this.serverXmlPath);
/*     */       } 
/*  58 */     } catch (IOException ioe) {
/*  59 */       ioException = ioe;
/*     */     } 
/*  61 */     if (result == null) {
/*     */       
/*  63 */       InputStream stream = getClass().getClassLoader().getResourceAsStream("server-embed.xml");
/*  64 */       if (stream != null) {
/*     */         
/*     */         try {
/*  67 */           result = new ConfigurationSource.Resource(stream, getClass().getClassLoader().getResource("server-embed.xml").toURI());
/*  68 */         } catch (URISyntaxException e) {
/*  69 */           stream.close();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  74 */     if (result == null && ioException != null) {
/*  75 */       throw ioException;
/*     */     }
/*  77 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationSource.Resource getResource(String name) throws IOException {
/*     */     URI uri;
/*  87 */     if (!UriUtil.isAbsoluteURI(name)) {
/*  88 */       File f = new File(name);
/*  89 */       if (!f.isAbsolute()) {
/*  90 */         f = new File(this.catalinaBaseFile, name);
/*     */       }
/*  92 */       if (f.isFile()) {
/*  93 */         FileInputStream fis = new FileInputStream(f);
/*  94 */         return new ConfigurationSource.Resource(fis, f.toURI());
/*     */       } 
/*     */ 
/*     */       
/*  98 */       InputStream stream = null;
/*     */       try {
/* 100 */         stream = getClass().getClassLoader().getResourceAsStream(name);
/* 101 */         if (stream != null) {
/* 102 */           return new ConfigurationSource.Resource(stream, getClass().getClassLoader().getResource(name).toURI());
/*     */         }
/* 104 */       } catch (URISyntaxException e) {
/* 105 */         stream.close();
/* 106 */         throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 113 */       uri = getURIInternal(name);
/* 114 */     } catch (IllegalArgumentException e) {
/* 115 */       throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }));
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 120 */       URL url = uri.toURL();
/* 121 */       return new ConfigurationSource.Resource(url.openConnection().getInputStream(), uri);
/* 122 */     } catch (MalformedURLException e) {
/* 123 */       throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getURI(String name) {
/* 133 */     if (!UriUtil.isAbsoluteURI(name)) {
/* 134 */       File f = new File(name);
/* 135 */       if (!f.isAbsolute()) {
/* 136 */         f = new File(this.catalinaBaseFile, name);
/*     */       }
/* 138 */       if (f.isFile()) {
/* 139 */         return f.toURI();
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 144 */         URL resource = getClass().getClassLoader().getResource(name);
/* 145 */         if (resource != null) {
/* 146 */           return resource.toURI();
/*     */         }
/* 148 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 153 */     return getURIInternal(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URI getURIInternal(String name) {
/*     */     URI uri;
/* 161 */     if (this.catalinaBaseUri != null) {
/* 162 */       uri = this.catalinaBaseUri.resolve(name);
/*     */     } else {
/* 164 */       uri = URI.create(name);
/*     */     } 
/* 166 */     return uri;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\CatalinaBaseConfigurationSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */