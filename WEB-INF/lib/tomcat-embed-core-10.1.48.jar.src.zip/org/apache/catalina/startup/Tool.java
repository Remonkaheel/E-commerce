/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tool
/*     */ {
/*  67 */   private static final Log log = LogFactory.getLog(Tool.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean ant = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static final String catalinaHome = System.getProperty("catalina.home");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean common = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean server = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean shared = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 114 */     if (catalinaHome == null) {
/* 115 */       log.error("Must set 'catalina.home' system property");
/* 116 */       System.exit(1);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     int index = 0;
/*     */     
/*     */     while (true) {
/* 123 */       if (index == args.length) {
/* 124 */         usage();
/* 125 */         System.exit(1);
/*     */       } 
/* 127 */       switch (args[index]) {
/*     */         case "-ant":
/* 129 */           ant = true;
/*     */           break;
/*     */         case "-common":
/* 132 */           common = true;
/*     */           break;
/*     */         case "-server":
/* 135 */           server = true;
/*     */           break;
/*     */         case "-shared":
/* 138 */           shared = true;
/*     */           break;
/*     */         default:
/*     */           break;
/*     */       } 
/* 143 */       index++;
/*     */     } 
/*     */ 
/*     */     
/* 147 */     if (ant) {
/* 148 */       System.setProperty("ant.home", catalinaHome);
/*     */     }
/*     */ 
/*     */     
/* 152 */     ClassLoader classLoader = null;
/*     */     try {
/* 154 */       List<File> packed = new ArrayList<>();
/* 155 */       List<File> unpacked = new ArrayList<>();
/* 156 */       unpacked.add(new File(catalinaHome, "classes"));
/* 157 */       packed.add(new File(catalinaHome, "lib"));
/* 158 */       if (common) {
/* 159 */         unpacked.add(new File(catalinaHome, "common" + File.separator + "classes"));
/* 160 */         packed.add(new File(catalinaHome, "common" + File.separator + "lib"));
/*     */       } 
/* 162 */       if (server) {
/* 163 */         unpacked.add(new File(catalinaHome, "server" + File.separator + "classes"));
/* 164 */         packed.add(new File(catalinaHome, "server" + File.separator + "lib"));
/*     */       } 
/* 166 */       if (shared) {
/* 167 */         unpacked.add(new File(catalinaHome, "shared" + File.separator + "classes"));
/* 168 */         packed.add(new File(catalinaHome, "shared" + File.separator + "lib"));
/*     */       } 
/* 170 */       classLoader = ClassLoaderFactory.createClassLoader(unpacked.<File>toArray(new File[0]), packed
/* 171 */           .<File>toArray(new File[0]), null);
/* 172 */     } catch (Throwable t) {
/* 173 */       Bootstrap.handleThrowable(t);
/* 174 */       log.error("Class loader creation threw exception", t);
/* 175 */       System.exit(1);
/*     */     } 
/* 177 */     Thread.currentThread().setContextClassLoader(classLoader);
/*     */ 
/*     */     
/* 180 */     Class<?> clazz = null;
/* 181 */     String className = args[index++];
/*     */     try {
/* 183 */       if (log.isDebugEnabled()) {
/* 184 */         log.debug("Loading application class " + className);
/*     */       }
/* 186 */       clazz = classLoader.loadClass(className);
/* 187 */     } catch (Throwable t) {
/* 188 */       Bootstrap.handleThrowable(t);
/* 189 */       log.error("Exception creating instance of " + className, t);
/* 190 */       System.exit(1);
/*     */     } 
/*     */     
/* 193 */     Method method = null;
/* 194 */     String[] params = new String[args.length - index];
/* 195 */     System.arraycopy(args, index, params, 0, params.length);
/*     */     try {
/* 197 */       if (log.isTraceEnabled()) {
/* 198 */         log.trace("Identifying main() method");
/*     */       }
/* 200 */       String methodName = "main";
/* 201 */       Class<?>[] paramTypes = new Class[1];
/* 202 */       paramTypes[0] = params.getClass();
/* 203 */       method = clazz.getMethod(methodName, paramTypes);
/* 204 */     } catch (Throwable t) {
/* 205 */       Bootstrap.handleThrowable(t);
/* 206 */       log.error("Exception locating main() method", t);
/* 207 */       System.exit(1);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 212 */       if (log.isTraceEnabled()) {
/* 213 */         log.trace("Calling main() method");
/*     */       }
/* 215 */       Object[] paramValues = new Object[1];
/* 216 */       paramValues[0] = params;
/* 217 */       method.invoke(null, paramValues);
/* 218 */     } catch (Throwable t) {
/* 219 */       Throwable throwable = Bootstrap.unwrapInvocationTargetException(t);
/* 220 */       Bootstrap.handleThrowable(throwable);
/* 221 */       log.error("Exception calling main() method", throwable);
/* 222 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void usage() {
/* 233 */     log.info("Usage:  java org.apache.catalina.startup.Tool [<options>] <class> [<arguments>]");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\Tool.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */