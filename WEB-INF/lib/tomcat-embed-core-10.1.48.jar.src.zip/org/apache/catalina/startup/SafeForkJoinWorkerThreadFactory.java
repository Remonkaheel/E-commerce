/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.util.concurrent.ForkJoinPool;
/*    */ import java.util.concurrent.ForkJoinWorkerThread;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafeForkJoinWorkerThreadFactory
/*    */   implements ForkJoinPool.ForkJoinWorkerThreadFactory
/*    */ {
/*    */   public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
/* 33 */     return new SafeForkJoinWorkerThread(pool);
/*    */   }
/*    */   
/*    */   private static class SafeForkJoinWorkerThread
/*    */     extends ForkJoinWorkerThread
/*    */   {
/*    */     protected SafeForkJoinWorkerThread(ForkJoinPool pool) {
/* 40 */       super(pool);
/* 41 */       setContextClassLoader(ForkJoinPool.class.getClassLoader());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\SafeForkJoinWorkerThreadFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */