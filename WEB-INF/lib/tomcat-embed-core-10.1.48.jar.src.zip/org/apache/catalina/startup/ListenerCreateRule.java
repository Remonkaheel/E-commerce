/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.ObjectCreateRule;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerCreateRule
/*     */   extends ObjectCreateRule
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(ListenerCreateRule.class);
/*  38 */   protected static final StringManager sm = StringManager.getManager(ListenerCreateRule.class);
/*     */   
/*     */   public ListenerCreateRule(String className, String attributeName) {
/*  41 */     super(className, attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/*  46 */     if ("true".equals(attributes.getValue("optional"))) {
/*     */       try {
/*  48 */         super.begin(namespace, name, attributes);
/*  49 */       } catch (Exception e) {
/*  50 */         String className = getRealClassName(attributes);
/*  51 */         if (log.isDebugEnabled()) {
/*  52 */           log.debug(sm.getString("listener.createFailed", new Object[] { className }), e);
/*     */         } else {
/*  54 */           log.info(sm.getString("listener.createFailed", new Object[] { className }));
/*     */         } 
/*  56 */         Object instance = new OptionalListener(className);
/*  57 */         this.digester.push(instance);
/*  58 */         StringBuilder code = this.digester.getGeneratedCode();
/*  59 */         if (code != null) {
/*  60 */           code.append(OptionalListener.class.getName().replace('$', '.')).append(' ');
/*  61 */           code.append(this.digester.toVariableName(instance)).append(" = new ");
/*  62 */           code.append(OptionalListener.class.getName().replace('$', '.')).append("(\"").append(className)
/*  63 */             .append("\");");
/*  64 */           code.append(System.lineSeparator());
/*     */         } 
/*     */       } 
/*     */     } else {
/*  68 */       super.begin(namespace, name, attributes);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class OptionalListener implements LifecycleListener {
/*     */     protected final String className;
/*  74 */     protected final HashMap<String, String> properties = new HashMap<>();
/*     */     
/*     */     public OptionalListener(String className) {
/*  77 */       this.className = className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getClassName() {
/*  84 */       return this.className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<String> getProperties() {
/*  98 */       return this.properties.keySet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getProperty(String name) {
/* 109 */       return this.properties.get(name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean setProperty(String name, String value) {
/* 121 */       this.properties.put(name, value);
/* 122 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\ListenerCreateRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */