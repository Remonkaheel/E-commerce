/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.security.SecurityClassLoad;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bootstrap
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(Bootstrap.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static final Object daemonLock = new Object();
/*  53 */   private static volatile Bootstrap daemon = null;
/*     */   
/*     */   private static final File catalinaBaseFile;
/*     */   
/*     */   private static final File catalinaHomeFile;
/*  58 */   private static final Pattern PATH_PATTERN = Pattern.compile("(\"[^\"]*\")|(([^,])*)");
/*     */ 
/*     */   
/*     */   static {
/*  62 */     String userDir = System.getProperty("user.dir");
/*     */ 
/*     */     
/*  65 */     String home = System.getProperty("catalina.home");
/*  66 */     File homeFile = null;
/*     */     
/*  68 */     if (home != null) {
/*  69 */       File f = new File(home);
/*     */       try {
/*  71 */         homeFile = f.getCanonicalFile();
/*  72 */       } catch (IOException ioe) {
/*  73 */         homeFile = f.getAbsoluteFile();
/*     */       } 
/*     */     } 
/*     */     
/*  77 */     if (homeFile == null) {
/*     */ 
/*     */       
/*  80 */       File bootstrapJar = new File(userDir, "bootstrap.jar");
/*     */       
/*  82 */       if (bootstrapJar.exists()) {
/*  83 */         File f = new File(userDir, "..");
/*     */         try {
/*  85 */           homeFile = f.getCanonicalFile();
/*  86 */         } catch (IOException ioe) {
/*  87 */           homeFile = f.getAbsoluteFile();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     if (homeFile == null) {
/*     */       
/*  94 */       File f = new File(userDir);
/*     */       try {
/*  96 */         homeFile = f.getCanonicalFile();
/*  97 */       } catch (IOException ioe) {
/*  98 */         homeFile = f.getAbsoluteFile();
/*     */       } 
/*     */     } 
/*     */     
/* 102 */     catalinaHomeFile = homeFile;
/* 103 */     System.setProperty("catalina.home", catalinaHomeFile.getPath());
/*     */ 
/*     */     
/* 106 */     String base = System.getProperty("catalina.base");
/* 107 */     if (base == null) {
/* 108 */       catalinaBaseFile = catalinaHomeFile;
/*     */     } else {
/* 110 */       File baseFile = new File(base);
/*     */       try {
/* 112 */         baseFile = baseFile.getCanonicalFile();
/* 113 */       } catch (IOException ioe) {
/* 114 */         baseFile = baseFile.getAbsoluteFile();
/*     */       } 
/* 116 */       catalinaBaseFile = baseFile;
/*     */     } 
/* 118 */     System.setProperty("catalina.base", catalinaBaseFile.getPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private Object catalinaDaemon = null;
/*     */   
/* 129 */   ClassLoader commonLoader = null;
/* 130 */   ClassLoader catalinaLoader = null;
/* 131 */   ClassLoader sharedLoader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initClassLoaders() {
/*     */     try {
/* 139 */       this.commonLoader = createClassLoader("common", null);
/* 140 */       if (this.commonLoader == null)
/*     */       {
/* 142 */         this.commonLoader = getClass().getClassLoader();
/*     */       }
/* 144 */       this.catalinaLoader = createClassLoader("server", this.commonLoader);
/* 145 */       this.sharedLoader = createClassLoader("shared", this.commonLoader);
/* 146 */     } catch (Throwable t) {
/* 147 */       handleThrowable(t);
/* 148 */       log.error("Class loader creation threw exception", t);
/* 149 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassLoader createClassLoader(String name, ClassLoader parent) throws Exception {
/* 156 */     String value = CatalinaProperties.getProperty(name + ".loader");
/* 157 */     if (value == null || value.isEmpty()) {
/* 158 */       return parent;
/*     */     }
/*     */     
/* 161 */     value = replace(value);
/*     */     
/* 163 */     List<ClassLoaderFactory.Repository> repositories = new ArrayList<>();
/*     */     
/* 165 */     String[] repositoryPaths = getPaths(value);
/*     */     
/* 167 */     for (String repository : repositoryPaths) {
/*     */       
/*     */       try {
/* 170 */         URI uri = new URI(repository);
/*     */         
/* 172 */         URL url = uri.toURL();
/* 173 */         repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.URL));
/*     */       }
/* 175 */       catch (IllegalArgumentException|java.net.MalformedURLException|java.net.URISyntaxException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         if (repository.endsWith("*.jar")) {
/* 181 */           repository = repository.substring(0, repository.length() - "*.jar".length());
/* 182 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.GLOB));
/* 183 */         } else if (repository.endsWith(".jar")) {
/* 184 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.JAR));
/*     */         } else {
/* 186 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.DIR));
/*     */         } 
/*     */       } 
/*     */     } 
/* 190 */     return ClassLoaderFactory.createClassLoader(repositories, parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String replace(String str) {
/* 204 */     String result = str;
/* 205 */     int pos_start = str.indexOf("${");
/* 206 */     if (pos_start >= 0) {
/* 207 */       StringBuilder builder = new StringBuilder();
/* 208 */       int pos_end = -1;
/* 209 */       while (pos_start >= 0) {
/* 210 */         String replacement; builder.append(str, pos_end + 1, pos_start);
/* 211 */         pos_end = str.indexOf('}', pos_start + 2);
/* 212 */         if (pos_end < 0) {
/* 213 */           pos_end = pos_start - 1;
/*     */           break;
/*     */         } 
/* 216 */         String propName = str.substring(pos_start + 2, pos_end);
/*     */         
/* 218 */         if (propName.isEmpty()) {
/* 219 */           replacement = null;
/* 220 */         } else if ("catalina.home".equals(propName)) {
/* 221 */           replacement = getCatalinaHome();
/* 222 */         } else if ("catalina.base".equals(propName)) {
/* 223 */           replacement = getCatalinaBase();
/*     */         } else {
/* 225 */           replacement = System.getProperty(propName);
/*     */         } 
/* 227 */         if (replacement != null) {
/* 228 */           builder.append(replacement);
/*     */         } else {
/* 230 */           builder.append(str, pos_start, pos_end + 1);
/*     */         } 
/* 232 */         pos_start = str.indexOf("${", pos_end + 1);
/*     */       } 
/* 234 */       builder.append(str, pos_end + 1, str.length());
/* 235 */       result = builder.toString();
/*     */     } 
/* 237 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws Exception {
/* 248 */     initClassLoaders();
/*     */     
/* 250 */     Thread.currentThread().setContextClassLoader(this.catalinaLoader);
/*     */     
/* 252 */     SecurityClassLoad.securityClassLoad(this.catalinaLoader);
/*     */ 
/*     */     
/* 255 */     if (log.isTraceEnabled()) {
/* 256 */       log.trace("Loading startup class");
/*     */     }
/* 258 */     Class<?> startupClass = this.catalinaLoader.loadClass("org.apache.catalina.startup.Catalina");
/* 259 */     Object startupInstance = startupClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */ 
/*     */     
/* 262 */     if (log.isTraceEnabled()) {
/* 263 */       log.trace("Setting startup class properties");
/*     */     }
/* 265 */     String methodName = "setParentClassLoader";
/* 266 */     Class<?>[] paramTypes = new Class[1];
/* 267 */     paramTypes[0] = Class.forName("java.lang.ClassLoader");
/* 268 */     Object[] paramValues = new Object[1];
/* 269 */     paramValues[0] = this.sharedLoader;
/* 270 */     Method method = startupInstance.getClass().getMethod(methodName, paramTypes);
/* 271 */     method.invoke(startupInstance, paramValues);
/*     */     
/* 273 */     this.catalinaDaemon = startupInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void load(String[] arguments) throws Exception {
/*     */     Object[] param;
/*     */     Class<?>[] paramTypes;
/* 283 */     String methodName = "load";
/*     */ 
/*     */     
/* 286 */     if (arguments == null || arguments.length == 0) {
/* 287 */       paramTypes = null;
/* 288 */       param = null;
/*     */     } else {
/* 290 */       paramTypes = new Class[1];
/* 291 */       paramTypes[0] = arguments.getClass();
/* 292 */       param = new Object[1];
/* 293 */       param[0] = arguments;
/*     */     } 
/* 295 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, paramTypes);
/* 296 */     if (log.isTraceEnabled()) {
/* 297 */       log.trace("Calling startup class " + String.valueOf(method));
/*     */     }
/* 299 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getServer() throws Exception {
/* 308 */     String methodName = "getServer";
/* 309 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, new Class[0]);
/* 310 */     return method.invoke(this.catalinaDaemon, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(String[] arguments) throws Exception {
/* 326 */     init();
/* 327 */     load(arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws Exception {
/* 337 */     if (this.catalinaDaemon == null) {
/* 338 */       init();
/*     */     }
/*     */     
/* 341 */     Method method = this.catalinaDaemon.getClass().getMethod("start", (Class[])null);
/* 342 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws Exception {
/* 352 */     Method method = this.catalinaDaemon.getClass().getMethod("stop", (Class[])null);
/* 353 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopServer() throws Exception {
/* 364 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", (Class[])null);
/* 365 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopServer(String[] arguments) throws Exception {
/*     */     Object[] param;
/*     */     Class<?>[] paramTypes;
/* 380 */     if (arguments == null || arguments.length == 0) {
/* 381 */       paramTypes = null;
/* 382 */       param = null;
/*     */     } else {
/* 384 */       paramTypes = new Class[1];
/* 385 */       paramTypes[0] = arguments.getClass();
/* 386 */       param = new Object[1];
/* 387 */       param[0] = arguments;
/*     */     } 
/* 389 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", paramTypes);
/* 390 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAwait(boolean await) throws Exception {
/* 403 */     Class<?>[] paramTypes = new Class[1];
/* 404 */     paramTypes[0] = boolean.class;
/* 405 */     Object[] paramValues = new Object[1];
/* 406 */     paramValues[0] = Boolean.valueOf(await);
/* 407 */     Method method = this.catalinaDaemon.getClass().getMethod("setAwait", paramTypes);
/* 408 */     method.invoke(this.catalinaDaemon, paramValues);
/*     */   }
/*     */   
/*     */   public boolean getAwait() throws Exception {
/* 412 */     Class<?>[] paramTypes = new Class[0];
/* 413 */     Object[] paramValues = new Object[0];
/* 414 */     Method method = this.catalinaDaemon.getClass().getMethod("getAwait", paramTypes);
/* 415 */     Boolean b = (Boolean)method.invoke(this.catalinaDaemon, paramValues);
/* 416 */     return b.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 434 */     synchronized (daemonLock) {
/* 435 */       if (daemon == null) {
/*     */         
/* 437 */         Bootstrap bootstrap = new Bootstrap();
/*     */         try {
/* 439 */           bootstrap.init();
/* 440 */         } catch (Throwable t) {
/* 441 */           handleThrowable(t);
/* 442 */           log.error("Init exception", t);
/*     */           return;
/*     */         } 
/* 445 */         daemon = bootstrap;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 450 */         Thread.currentThread().setContextClassLoader(daemon.catalinaLoader);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 455 */       String command = "start";
/* 456 */       if (args.length > 0) {
/* 457 */         command = args[args.length - 1];
/*     */       }
/*     */       
/* 460 */       switch (command) {
/*     */         case "startd":
/* 462 */           args[args.length - 1] = "start";
/* 463 */           daemon.load(args);
/* 464 */           daemon.start();
/*     */           return;
/*     */         case "stopd":
/* 467 */           args[args.length - 1] = "stop";
/* 468 */           daemon.stop();
/*     */           return;
/*     */         case "start":
/* 471 */           daemon.setAwait(true);
/* 472 */           daemon.load(args);
/* 473 */           daemon.start();
/* 474 */           if (null == daemon.getServer()) {
/* 475 */             System.exit(1);
/*     */           }
/*     */           return;
/*     */         case "stop":
/* 479 */           daemon.stopServer(args);
/*     */           return;
/*     */         case "configtest":
/* 482 */           daemon.load(args);
/* 483 */           if (null == daemon.getServer()) {
/* 484 */             System.exit(1);
/*     */           }
/* 486 */           System.exit(0);
/*     */           return;
/*     */       } 
/* 489 */       log.warn("Bootstrap: command \"" + command + "\" does not exist.");
/*     */     
/*     */     }
/* 492 */     catch (Throwable t) {
/*     */       
/* 494 */       Throwable throwable = t;
/* 495 */       if (throwable instanceof java.lang.reflect.InvocationTargetException && throwable.getCause() != null) {
/* 496 */         throwable = throwable.getCause();
/*     */       }
/* 498 */       handleThrowable(throwable);
/* 499 */       log.error("Error running command", throwable);
/* 500 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCatalinaHome() {
/* 512 */     return catalinaHomeFile.getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCatalinaBase() {
/* 523 */     return catalinaBaseFile.getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getCatalinaHomeFile() {
/* 533 */     return catalinaHomeFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getCatalinaBaseFile() {
/* 544 */     return catalinaBaseFile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleThrowable(Throwable t) {
/* 550 */     if (t instanceof ThreadDeath) {
/* 551 */       throw (ThreadDeath)t;
/*     */     }
/* 553 */     if (t instanceof StackOverflowError) {
/*     */       return;
/*     */     }
/*     */     
/* 557 */     if (t instanceof VirtualMachineError) {
/* 558 */       throw (VirtualMachineError)t;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Throwable unwrapInvocationTargetException(Throwable t) {
/* 565 */     if (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 566 */       return t.getCause();
/*     */     }
/* 568 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] getPaths(String value) {
/* 574 */     List<String> result = new ArrayList<>();
/* 575 */     Matcher matcher = PATH_PATTERN.matcher(value);
/*     */     
/* 577 */     while (matcher.find()) {
/* 578 */       String path = value.substring(matcher.start(), matcher.end());
/*     */       
/* 580 */       path = path.trim();
/* 581 */       if (path.isEmpty()) {
/*     */         continue;
/*     */       }
/*     */       
/* 585 */       char first = path.charAt(0);
/* 586 */       char last = path.charAt(path.length() - 1);
/*     */       
/* 588 */       if (first == '"' && last == '"' && path.length() > 1) {
/* 589 */         path = path.substring(1, path.length() - 1);
/* 590 */         path = path.trim();
/* 591 */         if (path.isEmpty()) {
/*     */           continue;
/*     */         }
/* 594 */       } else if (path.contains("\"")) {
/*     */ 
/*     */ 
/*     */         
/* 598 */         throw new IllegalArgumentException("The double quote [\"] character can only be used to quote paths. It must not appear in a path. This loader path is not valid: [" + value + "]");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       result.add(path);
/*     */     } 
/*     */     
/* 608 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\Bootstrap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */