/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LifecycleListenerRule
/*     */   extends Rule
/*     */ {
/*     */   private final String attributeName;
/*     */   private final String listenerClass;
/*     */   
/*     */   public LifecycleListenerRule(String listenerClass, String attributeName) {
/*  53 */     this.listenerClass = listenerClass;
/*  54 */     this.attributeName = attributeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/*  80 */     Container c = (Container)this.digester.peek();
/*  81 */     Container p = null;
/*  82 */     Object obj = this.digester.peek(1);
/*  83 */     if (obj instanceof Container) {
/*  84 */       p = (Container)obj;
/*     */     }
/*     */     
/*  87 */     String className = null;
/*     */ 
/*     */     
/*  90 */     if (this.attributeName != null) {
/*  91 */       String value = attributes.getValue(this.attributeName);
/*  92 */       if (value != null) {
/*  93 */         className = value;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  98 */     if (p != null && className == null) {
/*  99 */       String configClass = (String)IntrospectionUtils.getProperty(p, this.attributeName);
/* 100 */       if (configClass != null && !configClass.isEmpty()) {
/* 101 */         className = configClass;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 106 */     if (className == null) {
/* 107 */       className = this.listenerClass;
/*     */     }
/*     */ 
/*     */     
/* 111 */     Class<?> clazz = Class.forName(className);
/* 112 */     LifecycleListener listener = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */ 
/*     */     
/* 115 */     c.addLifecycleListener(listener);
/*     */     
/* 117 */     StringBuilder code = this.digester.getGeneratedCode();
/* 118 */     if (code != null) {
/* 119 */       code.append(this.digester.toVariableName(c)).append(".addLifecycleListener(");
/* 120 */       code.append("new ").append(className).append("());").append(System.lineSeparator());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\LifecycleListenerRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */