/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextRuleSet
/*     */   implements RuleSet
/*     */ {
/*     */   protected final String prefix;
/*     */   protected final boolean create;
/*     */   
/*     */   public ContextRuleSet() {
/*  47 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextRuleSet(String prefix) {
/*  57 */     this(prefix, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextRuleSet(String prefix, boolean create) {
/*  68 */     this.prefix = prefix;
/*  69 */     this.create = create;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRuleInstances(Digester digester) {
/*  78 */     if (this.create) {
/*  79 */       digester.addObjectCreate(this.prefix + "Context", "org.apache.catalina.core.StandardContext", "className");
/*  80 */       digester.addSetProperties(this.prefix + "Context");
/*     */     } else {
/*  82 */       digester.addSetProperties(this.prefix + "Context", new String[] { "path", "docBase" });
/*     */     } 
/*     */     
/*  85 */     if (this.create) {
/*  86 */       digester.addRule(this.prefix + "Context", new LifecycleListenerRule("org.apache.catalina.startup.ContextConfig", "configClass"));
/*     */       
/*  88 */       digester.addSetNext(this.prefix + "Context", "addChild", "org.apache.catalina.Container");
/*     */     } 
/*     */     
/*  91 */     digester.addObjectCreate(this.prefix + "Context/Listener", null, "className");
/*     */     
/*  93 */     digester.addSetProperties(this.prefix + "Context/Listener");
/*  94 */     digester.addSetNext(this.prefix + "Context/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */ 
/*     */     
/*  97 */     digester.addObjectCreate(this.prefix + "Context/Loader", "org.apache.catalina.loader.WebappLoader", "className");
/*  98 */     digester.addSetProperties(this.prefix + "Context/Loader");
/*  99 */     digester.addSetNext(this.prefix + "Context/Loader", "setLoader", "org.apache.catalina.Loader");
/*     */     
/* 101 */     digester.addObjectCreate(this.prefix + "Context/Manager", "org.apache.catalina.session.StandardManager", "className");
/*     */     
/* 103 */     digester.addSetProperties(this.prefix + "Context/Manager");
/* 104 */     digester.addSetNext(this.prefix + "Context/Manager", "setManager", "org.apache.catalina.Manager");
/*     */     
/* 106 */     digester.addObjectCreate(this.prefix + "Context/Manager/Store", null, "className");
/*     */     
/* 108 */     digester.addSetProperties(this.prefix + "Context/Manager/Store");
/* 109 */     digester.addSetNext(this.prefix + "Context/Manager/Store", "setStore", "org.apache.catalina.Store");
/*     */     
/* 111 */     digester.addObjectCreate(this.prefix + "Context/Manager/SessionIdGenerator", "org.apache.catalina.util.StandardSessionIdGenerator", "className");
/*     */     
/* 113 */     digester.addSetProperties(this.prefix + "Context/Manager/SessionIdGenerator");
/* 114 */     digester.addSetNext(this.prefix + "Context/Manager/SessionIdGenerator", "setSessionIdGenerator", "org.apache.catalina.SessionIdGenerator");
/*     */ 
/*     */     
/* 117 */     digester.addObjectCreate(this.prefix + "Context/Parameter", "org.apache.tomcat.util.descriptor.web.ApplicationParameter");
/*     */     
/* 119 */     digester.addSetProperties(this.prefix + "Context/Parameter");
/* 120 */     digester.addSetNext(this.prefix + "Context/Parameter", "addApplicationParameter", "org.apache.tomcat.util.descriptor.web.ApplicationParameter");
/*     */ 
/*     */     
/* 123 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Context/"));
/*     */     
/* 125 */     digester.addObjectCreate(this.prefix + "Context/Resources", "org.apache.catalina.webresources.StandardRoot", "className");
/*     */     
/* 127 */     digester.addSetProperties(this.prefix + "Context/Resources");
/* 128 */     digester.addSetNext(this.prefix + "Context/Resources", "setResources", "org.apache.catalina.WebResourceRoot");
/*     */     
/* 130 */     digester.addObjectCreate(this.prefix + "Context/Resources/CacheStrategy", null, "className");
/*     */     
/* 132 */     digester.addSetProperties(this.prefix + "Context/Resources/CacheStrategy");
/* 133 */     digester.addSetNext(this.prefix + "Context/Resources/CacheStrategy", "setCacheStrategy", "org.apache.catalina.WebResourceRoot$CacheStrategy");
/*     */ 
/*     */     
/* 136 */     digester.addObjectCreate(this.prefix + "Context/Resources/PreResources", null, "className");
/*     */     
/* 138 */     digester.addSetProperties(this.prefix + "Context/Resources/PreResources");
/* 139 */     digester.addSetNext(this.prefix + "Context/Resources/PreResources", "addPreResources", "org.apache.catalina.WebResourceSet");
/*     */ 
/*     */     
/* 142 */     digester.addObjectCreate(this.prefix + "Context/Resources/JarResources", null, "className");
/*     */     
/* 144 */     digester.addSetProperties(this.prefix + "Context/Resources/JarResources");
/* 145 */     digester.addSetNext(this.prefix + "Context/Resources/JarResources", "addJarResources", "org.apache.catalina.WebResourceSet");
/*     */ 
/*     */     
/* 148 */     digester.addObjectCreate(this.prefix + "Context/Resources/PostResources", null, "className");
/*     */     
/* 150 */     digester.addSetProperties(this.prefix + "Context/Resources/PostResources");
/* 151 */     digester.addSetNext(this.prefix + "Context/Resources/PostResources", "addPostResources", "org.apache.catalina.WebResourceSet");
/*     */ 
/*     */ 
/*     */     
/* 155 */     digester.addObjectCreate(this.prefix + "Context/ResourceLink", "org.apache.tomcat.util.descriptor.web.ContextResourceLink");
/*     */     
/* 157 */     digester.addSetProperties(this.prefix + "Context/ResourceLink");
/* 158 */     digester.addRule(this.prefix + "Context/ResourceLink", new SetNextNamingRule("addResourceLink", "org.apache.tomcat.util.descriptor.web.ContextResourceLink"));
/*     */ 
/*     */     
/* 161 */     digester.addObjectCreate(this.prefix + "Context/Valve", null, "className");
/*     */     
/* 163 */     digester.addSetProperties(this.prefix + "Context/Valve");
/* 164 */     digester.addSetNext(this.prefix + "Context/Valve", "addValve", "org.apache.catalina.Valve");
/*     */     
/* 166 */     digester.addCallMethod(this.prefix + "Context/WatchedResource", "addWatchedResource", 0);
/*     */     
/* 168 */     digester.addCallMethod(this.prefix + "Context/WrapperLifecycle", "addWrapperLifecycle", 0);
/*     */     
/* 170 */     digester.addCallMethod(this.prefix + "Context/WrapperListener", "addWrapperListener", 0);
/*     */     
/* 172 */     digester.addObjectCreate(this.prefix + "Context/JarScanner", "org.apache.tomcat.util.scan.StandardJarScanner", "className");
/*     */     
/* 174 */     digester.addSetProperties(this.prefix + "Context/JarScanner");
/* 175 */     digester.addSetNext(this.prefix + "Context/JarScanner", "setJarScanner", "org.apache.tomcat.JarScanner");
/*     */     
/* 177 */     digester.addObjectCreate(this.prefix + "Context/JarScanner/JarScanFilter", "org.apache.tomcat.util.scan.StandardJarScanFilter", "className");
/*     */     
/* 179 */     digester.addSetProperties(this.prefix + "Context/JarScanner/JarScanFilter");
/* 180 */     digester.addSetNext(this.prefix + "Context/JarScanner/JarScanFilter", "setJarScanFilter", "org.apache.tomcat.JarScanFilter");
/*     */ 
/*     */     
/* 183 */     digester.addObjectCreate(this.prefix + "Context/CookieProcessor", "org.apache.tomcat.util.http.Rfc6265CookieProcessor", "className");
/*     */     
/* 185 */     digester.addSetProperties(this.prefix + "Context/CookieProcessor");
/* 186 */     digester.addSetNext(this.prefix + "Context/CookieProcessor", "setCookieProcessor", "org.apache.tomcat.util.http.CookieProcessor");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\ContextRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */