/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RealmRuleSet
/*    */   implements RuleSet
/*    */ {
/* 29 */   private static final int MAX_NESTED_REALM_LEVELS = Integer.getInteger("org.apache.catalina.startup.RealmRuleSet.MAX_NESTED_REALM_LEVELS", 3).intValue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final String prefix;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RealmRuleSet() {
/* 46 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RealmRuleSet(String prefix) {
/* 56 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRuleInstances(Digester digester) {
/* 64 */     StringBuilder pattern = new StringBuilder(this.prefix);
/* 65 */     for (int i = 0; i < MAX_NESTED_REALM_LEVELS; i++) {
/* 66 */       if (i > 0) {
/* 67 */         pattern.append('/');
/*    */       }
/* 69 */       pattern.append("Realm");
/* 70 */       addRuleInstances(digester, pattern.toString(), (i == 0) ? "setRealm" : "addRealm");
/*    */     } 
/*    */   }
/*    */   
/*    */   private void addRuleInstances(Digester digester, String pattern, String methodName) {
/* 75 */     digester.addObjectCreate(pattern, null, "className");
/* 76 */     digester.addSetProperties(pattern);
/* 77 */     digester.addSetNext(pattern, methodName, "org.apache.catalina.Realm");
/* 78 */     digester.addRuleSet(new CredentialHandlerRuleSet(pattern + "/"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\RealmRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */