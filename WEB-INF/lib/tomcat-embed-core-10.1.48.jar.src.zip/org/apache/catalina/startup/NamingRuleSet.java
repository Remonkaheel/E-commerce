/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamingRuleSet
/*    */   implements RuleSet
/*    */ {
/*    */   protected final String prefix;
/*    */   
/*    */   public NamingRuleSet() {
/* 41 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NamingRuleSet(String prefix) {
/* 51 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRuleInstances(Digester digester) {
/* 60 */     digester.addObjectCreate(this.prefix + "Ejb", "org.apache.tomcat.util.descriptor.web.ContextEjb");
/* 61 */     digester.addSetProperties(this.prefix + "Ejb");
/* 62 */     digester.addRule(this.prefix + "Ejb", new SetNextNamingRule("addEjb", "org.apache.tomcat.util.descriptor.web.ContextEjb"));
/*    */ 
/*    */     
/* 65 */     digester.addObjectCreate(this.prefix + "Environment", "org.apache.tomcat.util.descriptor.web.ContextEnvironment");
/* 66 */     digester.addSetProperties(this.prefix + "Environment");
/* 67 */     digester.addRule(this.prefix + "Environment", new SetNextNamingRule("addEnvironment", "org.apache.tomcat.util.descriptor.web.ContextEnvironment"));
/*    */ 
/*    */     
/* 70 */     digester.addObjectCreate(this.prefix + "LocalEjb", "org.apache.tomcat.util.descriptor.web.ContextLocalEjb");
/* 71 */     digester.addSetProperties(this.prefix + "LocalEjb");
/* 72 */     digester.addRule(this.prefix + "LocalEjb", new SetNextNamingRule("addLocalEjb", "org.apache.tomcat.util.descriptor.web.ContextLocalEjb"));
/*    */ 
/*    */     
/* 75 */     digester.addObjectCreate(this.prefix + "Resource", "org.apache.tomcat.util.descriptor.web.ContextResource");
/* 76 */     digester.addSetProperties(this.prefix + "Resource");
/* 77 */     digester.addRule(this.prefix + "Resource", new SetNextNamingRule("addResource", "org.apache.tomcat.util.descriptor.web.ContextResource"));
/*    */ 
/*    */     
/* 80 */     digester.addObjectCreate(this.prefix + "ResourceEnvRef", "org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef");
/*    */     
/* 82 */     digester.addSetProperties(this.prefix + "ResourceEnvRef");
/* 83 */     digester.addRule(this.prefix + "ResourceEnvRef", new SetNextNamingRule("addResourceEnvRef", "org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef"));
/*    */ 
/*    */     
/* 86 */     digester.addObjectCreate(this.prefix + "ServiceRef", "org.apache.tomcat.util.descriptor.web.ContextService");
/* 87 */     digester.addSetProperties(this.prefix + "ServiceRef");
/* 88 */     digester.addRule(this.prefix + "ServiceRef", new SetNextNamingRule("addService", "org.apache.tomcat.util.descriptor.web.ContextService"));
/*    */ 
/*    */     
/* 91 */     digester.addObjectCreate(this.prefix + "Transaction", "org.apache.tomcat.util.descriptor.web.ContextTransaction");
/* 92 */     digester.addSetProperties(this.prefix + "Transaction");
/* 93 */     digester.addRule(this.prefix + "Transaction", new SetNextNamingRule("setTransaction", "org.apache.tomcat.util.descriptor.web.ContextTransaction"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\NamingRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */