/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import jakarta.annotation.Resource;
/*     */ import jakarta.annotation.Resources;
/*     */ import jakarta.annotation.security.DeclareRoles;
/*     */ import jakarta.annotation.security.RunAs;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import jakarta.servlet.ServletSecurityElement;
/*     */ import jakarta.servlet.annotation.ServletSecurity;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.ApplicationServletRegistration;
/*     */ import org.apache.catalina.util.Introspection;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAnnotationSet
/*     */ {
/*     */   private static final String SEPARATOR = "/";
/*     */   private static final String MAPPED_NAME_PROPERTY = "mappedName";
/*  56 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadApplicationAnnotations(Context context) {
/*  67 */     loadApplicationListenerAnnotations(context);
/*  68 */     loadApplicationFilterAnnotations(context);
/*  69 */     loadApplicationServletAnnotations(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadApplicationListenerAnnotations(Context context) {
/*  81 */     String[] applicationListeners = context.findApplicationListeners();
/*  82 */     for (String className : applicationListeners) {
/*  83 */       Class<?> clazz = Introspection.loadClass(context, className);
/*  84 */       if (clazz != null) {
/*     */ 
/*     */ 
/*     */         
/*  88 */         loadClassAnnotation(context, clazz);
/*  89 */         loadFieldsAnnotation(context, clazz);
/*  90 */         loadMethodsAnnotation(context, clazz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadApplicationFilterAnnotations(Context context) {
/* 101 */     FilterDef[] filterDefs = context.findFilterDefs();
/* 102 */     for (FilterDef filterDef : filterDefs) {
/* 103 */       Class<?> clazz = Introspection.loadClass(context, filterDef.getFilterClass());
/* 104 */       if (clazz != null) {
/*     */ 
/*     */ 
/*     */         
/* 108 */         loadClassAnnotation(context, clazz);
/* 109 */         loadFieldsAnnotation(context, clazz);
/* 110 */         loadMethodsAnnotation(context, clazz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadApplicationServletAnnotations(Context context) {
/* 122 */     Container[] children = context.findChildren();
/* 123 */     for (Container child : children) {
/* 124 */       if (child instanceof Wrapper) {
/*     */         
/* 126 */         Wrapper wrapper = (Wrapper)child;
/* 127 */         if (wrapper.getServletClass() != null) {
/*     */ 
/*     */ 
/*     */           
/* 131 */           Class<?> clazz = Introspection.loadClass(context, wrapper.getServletClass());
/* 132 */           if (clazz != null) {
/*     */ 
/*     */ 
/*     */             
/* 136 */             loadClassAnnotation(context, clazz);
/* 137 */             loadFieldsAnnotation(context, clazz);
/* 138 */             loadMethodsAnnotation(context, clazz);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 144 */             RunAs runAs = clazz.<RunAs>getAnnotation(RunAs.class);
/* 145 */             if (runAs != null) {
/* 146 */               wrapper.setRunAs(runAs.value());
/*     */             }
/*     */ 
/*     */             
/* 150 */             ServletSecurity servletSecurity = clazz.<ServletSecurity>getAnnotation(ServletSecurity.class);
/* 151 */             if (servletSecurity != null) {
/* 152 */               context.addServletSecurity((ServletRegistration.Dynamic)new ApplicationServletRegistration(wrapper, context), new ServletSecurityElement(servletSecurity));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadClassAnnotation(Context context, Class<?> clazz) {
/* 170 */     Resource resourceAnnotation = clazz.<Resource>getAnnotation(Resource.class);
/* 171 */     if (resourceAnnotation != null) {
/* 172 */       addResource(context, resourceAnnotation);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 177 */     Resources resourcesAnnotation = clazz.<Resources>getAnnotation(Resources.class);
/* 178 */     if (resourcesAnnotation != null && resourcesAnnotation.value() != null) {
/* 179 */       for (Resource resource : resourcesAnnotation.value()) {
/* 180 */         addResource(context, resource);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     DeclareRoles declareRolesAnnotation = clazz.<DeclareRoles>getAnnotation(DeclareRoles.class);
/* 188 */     if (declareRolesAnnotation != null && declareRolesAnnotation.value() != null) {
/* 189 */       for (String role : declareRolesAnnotation.value()) {
/* 190 */         context.addSecurityRole(role);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadFieldsAnnotation(Context context, Class<?> clazz) {
/* 198 */     Field[] fields = Introspection.getDeclaredFields(clazz);
/* 199 */     if (fields != null && fields.length > 0) {
/* 200 */       for (Field field : fields) {
/* 201 */         Resource annotation = field.<Resource>getAnnotation(Resource.class);
/* 202 */         if (annotation != null) {
/* 203 */           String defaultName = clazz.getName() + "/" + clazz.getName();
/* 204 */           Class<?> defaultType = field.getType();
/* 205 */           addResource(context, annotation, defaultName, defaultType);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadMethodsAnnotation(Context context, Class<?> clazz) {
/* 214 */     Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 215 */     if (methods != null && methods.length > 0) {
/* 216 */       for (Method method : methods) {
/* 217 */         Resource annotation = method.<Resource>getAnnotation(Resource.class);
/* 218 */         if (annotation != null) {
/* 219 */           if (!Introspection.isValidSetter(method)) {
/* 220 */             throw new IllegalArgumentException(sm.getString("webAnnotationSet.invalidInjection"));
/*     */           }
/*     */           
/* 223 */           String defaultName = clazz.getName() + "/" + clazz.getName();
/*     */           
/* 225 */           Class<?> defaultType = method.getParameterTypes()[0];
/* 226 */           addResource(context, annotation, defaultName, defaultType);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void addResource(Context context, Resource annotation) {
/* 241 */     addResource(context, annotation, null, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void addResource(Context context, Resource annotation, String defaultName, Class<?> defaultType) {
/* 246 */     String name = getName(annotation, defaultName);
/* 247 */     String type = getType(annotation, defaultType);
/*     */     
/* 249 */     if (type.equals("java.lang.String") || type.equals("java.lang.Character") || type.equals("java.lang.Integer") || type
/* 250 */       .equals("java.lang.Boolean") || type.equals("java.lang.Double") || type.equals("java.lang.Byte") || type
/* 251 */       .equals("java.lang.Short") || type.equals("java.lang.Long") || type.equals("java.lang.Float")) {
/*     */ 
/*     */       
/* 254 */       ContextEnvironment resource = new ContextEnvironment();
/*     */       
/* 256 */       resource.setName(name);
/* 257 */       resource.setType(type);
/* 258 */       resource.setDescription(annotation.description());
/* 259 */       resource.setProperty("mappedName", annotation.mappedName());
/* 260 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 262 */       context.getNamingResources().addEnvironment(resource);
/*     */     }
/* 264 */     else if (type.equals("javax.xml.rpc.Service")) {
/*     */ 
/*     */       
/* 267 */       ContextService service = new ContextService();
/*     */       
/* 269 */       service.setName(name);
/* 270 */       service.setWsdlfile(annotation.mappedName());
/* 271 */       service.setType(type);
/* 272 */       service.setDescription(annotation.description());
/* 273 */       service.setLookupName(annotation.lookup());
/*     */       
/* 275 */       context.getNamingResources().addService(service);
/*     */     }
/* 277 */     else if (type.equals("javax.sql.DataSource") || type.equals("javax.jms.ConnectionFactory") || type
/* 278 */       .equals("javax.jms.QueueConnectionFactory") || type.equals("javax.jms.TopicConnectionFactory") || type
/* 279 */       .equals("jakarta.mail.Session") || type.equals("java.net.URL") || type
/* 280 */       .equals("javax.resource.cci.ConnectionFactory") || type.equals("org.omg.CORBA_2_3.ORB") || type
/* 281 */       .endsWith("ConnectionFactory")) {
/*     */ 
/*     */       
/* 284 */       ContextResource resource = new ContextResource();
/*     */       
/* 286 */       resource.setName(name);
/* 287 */       resource.setType(type);
/*     */       
/* 289 */       if (annotation.authenticationType() == Resource.AuthenticationType.CONTAINER) {
/* 290 */         resource.setAuth("Container");
/* 291 */       } else if (annotation.authenticationType() == Resource.AuthenticationType.APPLICATION) {
/* 292 */         resource.setAuth("Application");
/*     */       } 
/*     */       
/* 295 */       resource.setScope(annotation.shareable() ? "Shareable" : "Unshareable");
/* 296 */       resource.setProperty("mappedName", annotation.mappedName());
/* 297 */       resource.setDescription(annotation.description());
/* 298 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 300 */       context.getNamingResources().addResource(resource);
/*     */     }
/* 302 */     else if (type.equals("javax.jms.Queue") || type.equals("javax.jms.Topic")) {
/*     */ 
/*     */       
/* 305 */       MessageDestinationRef resource = new MessageDestinationRef();
/*     */       
/* 307 */       resource.setName(name);
/* 308 */       resource.setType(type);
/* 309 */       resource.setUsage(annotation.mappedName());
/* 310 */       resource.setDescription(annotation.description());
/* 311 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 313 */       context.getNamingResources().addMessageDestinationRef(resource);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 321 */       ContextResourceEnvRef resource = new ContextResourceEnvRef();
/*     */       
/* 323 */       resource.setName(name);
/* 324 */       resource.setType(type);
/* 325 */       resource.setProperty("mappedName", annotation.mappedName());
/* 326 */       resource.setDescription(annotation.description());
/* 327 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 329 */       context.getNamingResources().addResourceEnvRef(resource);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getType(Resource annotation, Class<?> defaultType) {
/* 335 */     Class<?> type = annotation.type();
/* 336 */     if (type == null || type.equals(Object.class)) {
/* 337 */       type = Objects.<Class<?>>requireNonNullElse(defaultType, Object.class);
/*     */     }
/* 339 */     return Introspection.convertPrimitiveType(type).getCanonicalName();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getName(Resource annotation, String defaultName) {
/* 344 */     String name = annotation.name();
/* 345 */     if ((name == null || name.isEmpty()) && 
/* 346 */       defaultName != null) {
/* 347 */       name = defaultName;
/*     */     }
/*     */     
/* 350 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\WebAnnotationSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */