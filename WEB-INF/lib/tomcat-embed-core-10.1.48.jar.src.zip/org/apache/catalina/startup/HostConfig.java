/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.file.Files;
/*      */ import java.security.CodeSource;
/*      */ import java.security.Permission;
/*      */ import java.security.PermissionCollection;
/*      */ import java.security.Policy;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.security.DeployXmlPermission;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.jakartaee.Migration;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HostConfig
/*      */   implements LifecycleListener
/*      */ {
/*   83 */   private static final Log log = LogFactory.getLog(HostConfig.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   protected static final StringManager sm = StringManager.getManager(HostConfig.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final long FILE_MODIFICATION_RESOLUTION_MS = 1000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  101 */   protected String contextClass = "org.apache.catalina.core.StandardContext";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  107 */   protected Host host = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   protected ObjectName oname = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean deployXML = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean copyXML = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean unpackWARs = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   protected final Map<String, DeployedApplication> deployed = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  144 */   private final Set<String> servicedSet = ConcurrentHashMap.newKeySet();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   protected Digester digester = createDigester(this.contextClass);
/*  150 */   private final Object digesterLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   protected final Set<String> invalidWars = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContextClass() {
/*  164 */     return this.contextClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContextClass(String contextClass) {
/*  175 */     String oldContextClass = this.contextClass;
/*  176 */     this.contextClass = contextClass;
/*      */     
/*  178 */     if (!oldContextClass.equals(contextClass)) {
/*  179 */       synchronized (this.digesterLock) {
/*  180 */         this.digester = createDigester(getContextClass());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDeployXML() {
/*  190 */     return this.deployXML;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDeployXML(boolean deployXML) {
/*  200 */     this.deployXML = deployXML;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isDeployThisXML(File docBase, ContextName cn) {
/*  205 */     boolean deployThisXML = isDeployXML();
/*  206 */     if (Globals.IS_SECURITY_ENABLED && !deployThisXML) {
/*      */ 
/*      */       
/*  209 */       Policy currentPolicy = Policy.getPolicy();
/*  210 */       if (currentPolicy != null) {
/*      */         
/*      */         try {
/*  213 */           URL contextRootUrl = docBase.toURI().toURL();
/*  214 */           CodeSource cs = new CodeSource(contextRootUrl, (Certificate[])null);
/*  215 */           PermissionCollection pc = currentPolicy.getPermissions(cs);
/*  216 */           DeployXmlPermission deployXmlPermission = new DeployXmlPermission(cn.getBaseName());
/*  217 */           if (pc.implies((Permission)deployXmlPermission)) {
/*  218 */             deployThisXML = true;
/*      */           }
/*  220 */         } catch (MalformedURLException e) {
/*      */           
/*  222 */           log.warn(sm.getString("hostConfig.docBaseUrlInvalid"), e);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  227 */     return deployThisXML;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCopyXML() {
/*  235 */     return this.copyXML;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCopyXML(boolean copyXML) {
/*  246 */     this.copyXML = copyXML;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnpackWARs() {
/*  255 */     return this.unpackWARs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnpackWARs(boolean unpackWARs) {
/*  265 */     this.unpackWARs = unpackWARs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lifecycleEvent(LifecycleEvent event) {
/*      */     try {
/*  282 */       this.host = (Host)event.getLifecycle();
/*  283 */       if (this.host instanceof StandardHost) {
/*  284 */         setCopyXML(((StandardHost)this.host).isCopyXML());
/*  285 */         setDeployXML(((StandardHost)this.host).isDeployXML());
/*  286 */         setUnpackWARs(((StandardHost)this.host).isUnpackWARs());
/*  287 */         setContextClass(((StandardHost)this.host).getContextClass());
/*      */       } 
/*  289 */     } catch (ClassCastException e) {
/*  290 */       log.error(sm.getString("hostConfig.cce", new Object[] { event.getLifecycle() }), e);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  295 */     if (event.getType().equals("periodic")) {
/*  296 */       check();
/*  297 */     } else if (event.getType().equals("before_start")) {
/*  298 */       beforeStart();
/*  299 */     } else if (event.getType().equals("start")) {
/*  300 */       start();
/*  301 */     } else if (event.getType().equals("stop")) {
/*  302 */       stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean tryAddServiced(String name) {
/*  315 */     return this.servicedSet.add(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeServiced(String name) {
/*  325 */     this.servicedSet.remove(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getDeploymentTime(String name) {
/*  337 */     synchronized (this.host) {
/*  338 */       DeployedApplication app = this.deployed.get(name);
/*  339 */       if (app == null) {
/*  340 */         return 0L;
/*      */       }
/*      */       
/*  343 */       return app.timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDeployed(String name) {
/*  357 */     return this.deployed.containsKey(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Digester createDigester(String contextClassName) {
/*  372 */     Digester digester = new Digester();
/*  373 */     digester.setValidating(false);
/*      */     
/*  375 */     digester.addObjectCreate("Context", contextClassName, "className");
/*      */ 
/*      */     
/*  378 */     digester.addSetProperties("Context");
/*  379 */     return digester;
/*      */   }
/*      */   
/*      */   protected File returnCanonicalPath(String path) {
/*  383 */     File file = new File(path);
/*  384 */     if (!file.isAbsolute()) {
/*  385 */       file = new File(this.host.getCatalinaBase(), path);
/*      */     }
/*      */     try {
/*  388 */       return file.getCanonicalFile();
/*  389 */     } catch (IOException ioe) {
/*  390 */       return file;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConfigBaseName() {
/*  401 */     return this.host.getConfigBaseFile().getAbsolutePath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployApps() {
/*  410 */     migrateLegacyApps();
/*  411 */     File appBase = this.host.getAppBaseFile();
/*  412 */     File configBase = this.host.getConfigBaseFile();
/*  413 */     String[] filteredAppPaths = filterAppPaths(appBase.list());
/*      */     
/*  415 */     deployDescriptors(configBase, configBase.list());
/*      */     
/*  417 */     deployWARs(appBase, filteredAppPaths);
/*      */     
/*  419 */     deployDirectories(appBase, filteredAppPaths);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] filterAppPaths(String[] unfilteredAppPaths) {
/*  432 */     Pattern filter = this.host.getDeployIgnorePattern();
/*  433 */     if (filter == null || unfilteredAppPaths == null) {
/*  434 */       return unfilteredAppPaths;
/*      */     }
/*      */     
/*  437 */     List<String> filteredList = new ArrayList<>();
/*  438 */     Matcher matcher = null;
/*  439 */     for (String appPath : unfilteredAppPaths) {
/*  440 */       if (matcher == null) {
/*  441 */         matcher = filter.matcher(appPath);
/*      */       } else {
/*  443 */         matcher.reset(appPath);
/*      */       } 
/*  445 */       if (matcher.matches()) {
/*  446 */         if (log.isDebugEnabled()) {
/*  447 */           log.debug(sm.getString("hostConfig.ignorePath", new Object[] { appPath }));
/*      */         }
/*      */       } else {
/*  450 */         filteredList.add(appPath);
/*      */       } 
/*      */     } 
/*  453 */     return filteredList.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployApps(String name) {
/*  466 */     File appBase = this.host.getAppBaseFile();
/*  467 */     File configBase = this.host.getConfigBaseFile();
/*  468 */     ContextName cn = new ContextName(name, false);
/*  469 */     String baseName = cn.getBaseName();
/*      */     
/*  471 */     if (deploymentExists(cn.getName())) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  476 */     File xml = new File(configBase, baseName + ".xml");
/*  477 */     if (xml.exists()) {
/*  478 */       deployDescriptor(cn, xml);
/*      */       
/*      */       return;
/*      */     } 
/*  482 */     File war = new File(appBase, baseName + ".war");
/*  483 */     if (war.exists()) {
/*  484 */       deployWAR(cn, war);
/*      */       
/*      */       return;
/*      */     } 
/*  488 */     File dir = new File(appBase, baseName);
/*  489 */     if (dir.exists()) {
/*  490 */       deployDirectory(cn, dir);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployDescriptors(File configBase, String[] files) {
/*  503 */     if (files == null) {
/*      */       return;
/*      */     }
/*      */     
/*  507 */     ExecutorService es = this.host.getStartStopExecutor();
/*  508 */     List<Future<?>> results = new ArrayList<>();
/*      */     
/*  510 */     for (String file : files) {
/*  511 */       File contextXml = new File(configBase, file);
/*      */       
/*  513 */       if (file.toLowerCase(Locale.ENGLISH).endsWith(".xml")) {
/*  514 */         ContextName cn = new ContextName(file, true);
/*      */         
/*  516 */         if (tryAddServiced(cn.getName())) {
/*      */           try {
/*  518 */             if (deploymentExists(cn.getName()))
/*  519 */             { removeServiced(cn.getName());
/*      */                }
/*      */             
/*      */             else
/*      */             
/*  524 */             { results.add(es.submit(new DeployDescriptor(this, cn, contextXml))); } 
/*  525 */           } catch (Throwable t) {
/*  526 */             ExceptionUtils.handleThrowable(t);
/*  527 */             removeServiced(cn.getName());
/*  528 */             throw t;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  534 */     for (Future<?> result : results) {
/*      */       try {
/*  536 */         result.get();
/*  537 */       } catch (Exception e) {
/*  538 */         log.error(sm.getString("hostConfig.deployDescriptor.threaded.error"), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployDescriptor(ContextName cn, File contextXml) {
/*  555 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), true);
/*      */     
/*  557 */     long startTime = 0L;
/*      */     
/*  559 */     if (log.isInfoEnabled()) {
/*  560 */       startTime = System.currentTimeMillis();
/*  561 */       log.info(sm.getString("hostConfig.deployDescriptor", new Object[] { contextXml.getAbsolutePath() }));
/*      */     } 
/*      */     
/*  564 */     Context context = null;
/*  565 */     boolean isExternalWar = false;
/*  566 */     boolean isExternal = false;
/*      */ 
/*      */     
/*      */     try {
/*  570 */       synchronized (this.digesterLock) { 
/*  571 */         try { FileInputStream fis = new FileInputStream(contextXml); 
/*  572 */           try { context = (Context)this.digester.parse(fis);
/*  573 */             fis.close(); } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/*  574 */         { log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), e); }
/*      */         finally
/*  576 */         { this.digester.reset();
/*  577 */           if (context == null) {
/*  578 */             context = new FailedContext();
/*      */           } }
/*      */          }
/*      */ 
/*      */       
/*  583 */       if (context.getPath() != null) {
/*  584 */         log.warn(sm.getString("hostConfig.deployDescriptor.path", new Object[] { context.getPath(), contextXml
/*  585 */                 .getAbsolutePath() }));
/*      */       }
/*      */       
/*  588 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/*  589 */       LifecycleListener listener = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  590 */       context.addLifecycleListener(listener);
/*      */       
/*  592 */       context.setConfigFile(contextXml.toURI().toURL());
/*  593 */       context.setName(cn.getName());
/*  594 */       context.setPath(cn.getPath());
/*  595 */       context.setWebappVersion(cn.getVersion());
/*      */       
/*  597 */       if (context.getDocBase() != null) {
/*  598 */         File docBase = new File(context.getDocBase());
/*  599 */         if (!docBase.isAbsolute()) {
/*  600 */           docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */         }
/*      */         
/*  603 */         if (!docBase.getCanonicalFile().toPath().startsWith(this.host.getAppBaseFile().toPath())) {
/*  604 */           isExternal = true;
/*  605 */           deployedApp.redeployResources.put(contextXml.getAbsolutePath(), 
/*  606 */               Long.valueOf(contextXml.lastModified()));
/*  607 */           deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*  608 */           if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  609 */             isExternalWar = true;
/*      */           }
/*      */           
/*  612 */           File war = new File(this.host.getAppBaseFile(), cn.getBaseName() + ".war");
/*  613 */           if (war.exists()) {
/*  614 */             log.warn(sm.getString("hostConfig.deployDescriptor.hiddenWar", new Object[] { contextXml.getAbsolutePath(), war
/*  615 */                     .getAbsolutePath() }));
/*      */           }
/*  617 */           File dir = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  618 */           if (dir.exists()) {
/*  619 */             log.warn(sm.getString("hostConfig.deployDescriptor.hiddenDir", new Object[] { contextXml.getAbsolutePath(), dir
/*  620 */                     .getAbsolutePath() }));
/*      */           }
/*      */         } else {
/*  623 */           log.warn(sm.getString("hostConfig.deployDescriptor.localDocBaseSpecified", new Object[] { docBase }));
/*      */           
/*  625 */           context.setDocBase(null);
/*      */         } 
/*      */       } 
/*      */       
/*  629 */       this.host.addChild((Container)context);
/*  630 */     } catch (Throwable t) {
/*  631 */       ExceptionUtils.handleThrowable(t);
/*  632 */       log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), t);
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  637 */       File expandedDocBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  638 */       if (context != null && context.getDocBase() != null && 
/*  639 */         !context.getDocBase().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*      */         
/*  641 */         expandedDocBase = new File(context.getDocBase());
/*  642 */         if (!expandedDocBase.isAbsolute())
/*      */         {
/*  644 */           expandedDocBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */         }
/*      */       } 
/*      */       
/*  648 */       boolean unpackWAR = this.unpackWARs;
/*  649 */       if (unpackWAR && context instanceof StandardContext) {
/*  650 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  655 */       if (isExternalWar) {
/*  656 */         if (unpackWAR) {
/*  657 */           deployedApp.redeployResources.put(expandedDocBase.getAbsolutePath(), 
/*  658 */               Long.valueOf(expandedDocBase.lastModified()));
/*  659 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         } else {
/*  661 */           addWatchedResources(deployedApp, null, context);
/*      */         } 
/*      */       } else {
/*      */         
/*  665 */         if (!isExternal) {
/*  666 */           File warDocBase = new File(expandedDocBase.getAbsolutePath() + ".war");
/*  667 */           if (warDocBase.exists()) {
/*  668 */             deployedApp.redeployResources.put(warDocBase.getAbsolutePath(), 
/*  669 */                 Long.valueOf(warDocBase.lastModified()));
/*      */           } else {
/*      */             
/*  672 */             deployedApp.redeployResources.put(warDocBase.getAbsolutePath(), Long.valueOf(0L));
/*      */           } 
/*      */         } 
/*  675 */         if (unpackWAR) {
/*  676 */           deployedApp.redeployResources.put(expandedDocBase.getAbsolutePath(), 
/*  677 */               Long.valueOf(expandedDocBase.lastModified()));
/*  678 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         } else {
/*  680 */           addWatchedResources(deployedApp, null, context);
/*      */         } 
/*  682 */         if (!isExternal)
/*      */         {
/*      */           
/*  685 */           deployedApp.redeployResources.put(contextXml.getAbsolutePath(), 
/*  686 */               Long.valueOf(contextXml.lastModified()));
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  691 */       addGlobalRedeployResources(deployedApp);
/*      */     } 
/*      */     
/*  694 */     if (this.host.findChild(context.getName()) != null) {
/*  695 */       this.deployed.put(context.getName(), deployedApp);
/*      */     }
/*      */     
/*  698 */     if (log.isInfoEnabled()) {
/*  699 */       log.info(sm.getString("hostConfig.deployDescriptor.finished", new Object[] { contextXml.getAbsolutePath(), 
/*  700 */               Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployWARs(File appBase, String[] files) {
/*  713 */     if (files == null) {
/*      */       return;
/*      */     }
/*      */     
/*  717 */     ExecutorService es = this.host.getStartStopExecutor();
/*  718 */     List<Future<?>> results = new ArrayList<>();
/*      */     
/*  720 */     for (String file : files) {
/*  721 */       if (!file.equalsIgnoreCase("META-INF"))
/*      */       {
/*      */         
/*  724 */         if (!file.equalsIgnoreCase("WEB-INF")) {
/*      */ 
/*      */ 
/*      */           
/*  728 */           File war = new File(appBase, file);
/*  729 */           if (file.toLowerCase(Locale.ENGLISH).endsWith(".war") && war.isFile() && !this.invalidWars.contains(file)) {
/*  730 */             ContextName cn = new ContextName(file, true);
/*  731 */             if (tryAddServiced(cn.getName()))
/*      */               try {
/*  733 */                 if (deploymentExists(cn.getName()))
/*  734 */                 { DeployedApplication app = this.deployed.get(cn.getName());
/*  735 */                   boolean unpackWAR = this.unpackWARs;
/*  736 */                   if (unpackWAR && this.host.findChild(cn.getName()) instanceof StandardContext) {
/*  737 */                     unpackWAR = ((StandardContext)this.host.findChild(cn.getName())).getUnpackWAR();
/*      */                   }
/*  739 */                   if (!unpackWAR && app != null) {
/*      */ 
/*      */                     
/*  742 */                     File dir = new File(appBase, cn.getBaseName());
/*  743 */                     if (dir.exists()) {
/*  744 */                       if (!app.loggedDirWarning) {
/*  745 */                         log.warn(sm.getString("hostConfig.deployWar.hiddenDir", new Object[] { dir.getAbsoluteFile(), war
/*  746 */                                 .getAbsoluteFile() }));
/*  747 */                         app.loggedDirWarning = true;
/*      */                       } 
/*      */                     } else {
/*  750 */                       app.loggedDirWarning = false;
/*      */                     } 
/*      */                   } 
/*  753 */                   removeServiced(cn.getName());
/*      */ 
/*      */                   
/*      */                    }
/*      */                 
/*  758 */                 else if (!validateContextPath(appBase, cn.getBaseName()))
/*  759 */                 { log.error(sm.getString("hostConfig.illegalWarName", new Object[] { file }));
/*  760 */                   this.invalidWars.add(file);
/*  761 */                   removeServiced(cn.getName());
/*      */                    }
/*      */                 
/*      */                 else
/*      */                 
/*  766 */                 { results.add(es.submit(new DeployWar(this, cn, war))); } 
/*  767 */               } catch (Throwable t) {
/*  768 */                 ExceptionUtils.handleThrowable(t);
/*  769 */                 removeServiced(cn.getName());
/*  770 */                 throw t;
/*      */               }  
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*  776 */     for (Future<?> result : results) {
/*      */       try {
/*  778 */         result.get();
/*  779 */       } catch (Exception e) {
/*  780 */         log.error(sm.getString("hostConfig.deployWar.threaded.error"), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean validateContextPath(File appBase, String contextPath) {
/*      */     StringBuilder docBase;
/*      */     String canonicalDocBase;
/*      */     try {
/*  794 */       String canonicalAppBase = appBase.getCanonicalPath();
/*  795 */       docBase = new StringBuilder(canonicalAppBase);
/*  796 */       if (canonicalAppBase.endsWith(File.separator)) {
/*  797 */         docBase.append(contextPath.substring(1).replace('/', File.separatorChar));
/*      */       } else {
/*  799 */         docBase.append(contextPath.replace('/', File.separatorChar));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  804 */       canonicalDocBase = (new File(docBase.toString())).getCanonicalPath();
/*      */ 
/*      */ 
/*      */       
/*  808 */       if (canonicalDocBase.endsWith(File.separator)) {
/*  809 */         docBase.append(File.separator);
/*      */       }
/*  811 */     } catch (IOException ioe) {
/*  812 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  817 */     return canonicalDocBase.contentEquals(docBase);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployWAR(ContextName cn, File war) {
/*  830 */     File xml = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/META-INF/context.xml");
/*      */     
/*  832 */     File warTracker = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/META-INF/war-tracker");
/*      */     
/*  834 */     boolean xmlInWar = false; 
/*  835 */     try { JarFile jar = new JarFile(war); 
/*  836 */       try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  837 */         if (entry != null) {
/*  838 */           xmlInWar = true;
/*      */         }
/*  840 */         jar.close(); } catch (Throwable throwable) { try { jar.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  848 */     boolean useXml = (xml.exists() && this.unpackWARs && (!warTracker.exists() || warTracker.lastModified() == war.lastModified()));
/*      */ 
/*      */ 
/*      */     
/*  852 */     Context context = null;
/*  853 */     boolean deployThisXML = isDeployThisXML(war, cn);
/*      */     
/*      */     try {
/*  856 */       if (deployThisXML && useXml && !this.copyXML) {
/*  857 */         synchronized (this.digesterLock) {
/*      */           try {
/*  859 */             context = (Context)this.digester.parse(xml);
/*  860 */           } catch (Exception e) {
/*  861 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e);
/*      */           } finally {
/*  863 */             this.digester.reset();
/*  864 */             if (context == null) {
/*  865 */               context = new FailedContext();
/*      */             }
/*      */           } 
/*      */         } 
/*  869 */         context.setConfigFile(xml.toURI().toURL());
/*  870 */       } else if (deployThisXML && xmlInWar) {
/*  871 */         synchronized (this.digesterLock) { 
/*  872 */           try { JarFile jar = new JarFile(war); 
/*  873 */             try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  874 */               InputStream istream = jar.getInputStream(entry); 
/*  875 */               try { context = (Context)this.digester.parse(istream);
/*  876 */                 if (istream != null) istream.close();  } catch (Throwable throwable) { if (istream != null)
/*  877 */                   try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  jar.close(); } catch (Throwable throwable) { try { jar.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/*  878 */           { log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e); }
/*      */           finally
/*  880 */           { this.digester.reset();
/*  881 */             if (context == null) {
/*  882 */               context = new FailedContext();
/*      */             }
/*  884 */             context.setConfigFile(UriUtil.buildJarUrl(war, "META-INF/context.xml")); }
/*      */            }
/*      */       
/*  887 */       } else if (!deployThisXML && xmlInWar) {
/*      */ 
/*      */         
/*  890 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] { cn.getPath(), "META-INF/context.xml", new File(this.host
/*      */                   
/*  892 */                   .getConfigBaseFile(), cn.getBaseName() + ".xml") }));
/*      */       } else {
/*  894 */         context = Class.forName(this.contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } 
/*  896 */     } catch (Throwable t) {
/*  897 */       ExceptionUtils.handleThrowable(t);
/*  898 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     } finally {
/*  900 */       if (context == null) {
/*  901 */         context = new FailedContext();
/*      */       }
/*      */     } 
/*      */     
/*  905 */     boolean copyThisXml = false;
/*  906 */     if (deployThisXML) {
/*  907 */       if (this.host instanceof StandardHost) {
/*  908 */         copyThisXml = ((StandardHost)this.host).isCopyXML();
/*      */       }
/*      */ 
/*      */       
/*  912 */       if (!copyThisXml && context instanceof StandardContext) {
/*  913 */         copyThisXml = ((StandardContext)context).getCopyXML();
/*      */       }
/*      */       
/*  916 */       if (xmlInWar && copyThisXml) {
/*      */         
/*  918 */         xml = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml"); 
/*  919 */         try { JarFile jar = new JarFile(war); 
/*  920 */           try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  921 */             InputStream istream = jar.getInputStream(entry); 
/*  922 */             try { OutputStream ostream = new FileOutputStream(xml); 
/*  923 */               try { IOTools.flow(istream, ostream);
/*  924 */                 ostream.close(); } catch (Throwable throwable) { try { ostream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (istream != null) istream.close();  } catch (Throwable throwable) { if (istream != null)
/*  925 */                 try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  jar.close(); } catch (Throwable throwable) { try { jar.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException) {}
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  932 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), (xml.exists() && deployThisXML && copyThisXml));
/*      */     
/*  934 */     long startTime = 0L;
/*      */     
/*  936 */     if (log.isInfoEnabled()) {
/*  937 */       startTime = System.currentTimeMillis();
/*  938 */       log.info(sm.getString("hostConfig.deployWar", new Object[] { war.getAbsolutePath() }));
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  943 */       deployedApp.redeployResources.put(war.getAbsolutePath(), Long.valueOf(war.lastModified()));
/*      */       
/*  945 */       if (deployThisXML && xml.exists() && copyThisXml) {
/*  946 */         deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */       } else {
/*      */         
/*  949 */         deployedApp.redeployResources.put((new File(this.host
/*  950 */               .getConfigBaseFile(), cn.getBaseName() + ".xml")).getAbsolutePath(), 
/*  951 */             Long.valueOf(0L));
/*      */       } 
/*      */       
/*  954 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/*  955 */       LifecycleListener listener = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  956 */       context.addLifecycleListener(listener);
/*      */       
/*  958 */       context.setName(cn.getName());
/*  959 */       context.setPath(cn.getPath());
/*  960 */       context.setWebappVersion(cn.getVersion());
/*  961 */       context.setDocBase(cn.getBaseName() + ".war");
/*  962 */       this.host.addChild((Container)context);
/*  963 */     } catch (Throwable t) {
/*  964 */       ExceptionUtils.handleThrowable(t);
/*  965 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     }
/*      */     finally {
/*      */       
/*  969 */       boolean unpackWAR = this.unpackWARs;
/*  970 */       if (unpackWAR && context instanceof StandardContext) {
/*  971 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/*  973 */       if (unpackWAR && context.getDocBase() != null) {
/*  974 */         File docBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  975 */         deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*  976 */         addWatchedResources(deployedApp, docBase.getAbsolutePath(), context);
/*  977 */         if (deployThisXML && !copyThisXml && (xmlInWar || xml.exists())) {
/*  978 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  983 */         addWatchedResources(deployedApp, null, context);
/*      */       } 
/*      */ 
/*      */       
/*  987 */       addGlobalRedeployResources(deployedApp);
/*      */     } 
/*      */     
/*  990 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/*  992 */     if (log.isInfoEnabled()) {
/*  993 */       log.info(sm.getString("hostConfig.deployWar.finished", new Object[] { war.getAbsolutePath(), 
/*  994 */               Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployDirectories(File appBase, String[] files) {
/* 1007 */     if (files == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1011 */     ExecutorService es = this.host.getStartStopExecutor();
/* 1012 */     List<Future<?>> results = new ArrayList<>();
/*      */     
/* 1014 */     for (String file : files) {
/* 1015 */       if (!file.equalsIgnoreCase("META-INF"))
/*      */       {
/*      */         
/* 1018 */         if (!file.equalsIgnoreCase("WEB-INF")) {
/*      */ 
/*      */ 
/*      */           
/* 1022 */           File dir = new File(appBase, file);
/* 1023 */           if (dir.isDirectory()) {
/* 1024 */             ContextName cn = new ContextName(file, false);
/*      */             
/* 1026 */             if (tryAddServiced(cn.getName()))
/*      */               try {
/* 1028 */                 if (deploymentExists(cn.getName()))
/* 1029 */                 { removeServiced(cn.getName());
/*      */                    }
/*      */                 
/*      */                 else
/*      */                 
/* 1034 */                 { results.add(es.submit(new DeployDirectory(this, cn, dir))); } 
/* 1035 */               } catch (Throwable t) {
/* 1036 */                 ExceptionUtils.handleThrowable(t);
/* 1037 */                 removeServiced(cn.getName());
/* 1038 */                 throw t;
/*      */               }  
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/* 1044 */     for (Future<?> result : results) {
/*      */       try {
/* 1046 */         result.get();
/* 1047 */       } catch (Exception e) {
/* 1048 */         log.error(sm.getString("hostConfig.deployDir.threaded.error"), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deployDirectory(ContextName cn, File dir) {
/*      */     DeployedApplication deployedApp;
/* 1064 */     long startTime = 0L;
/*      */     
/* 1066 */     if (log.isInfoEnabled()) {
/* 1067 */       startTime = System.currentTimeMillis();
/* 1068 */       log.info(sm.getString("hostConfig.deployDir", new Object[] { dir.getAbsolutePath() }));
/*      */     } 
/*      */     
/* 1071 */     Context context = null;
/* 1072 */     File xml = new File(dir, "META-INF/context.xml");
/* 1073 */     File xmlCopy = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml");
/*      */ 
/*      */     
/* 1076 */     boolean copyThisXml = isCopyXML();
/* 1077 */     boolean deployThisXML = isDeployThisXML(dir, cn);
/*      */     
/*      */     try {
/* 1080 */       if (deployThisXML && xml.exists()) {
/* 1081 */         synchronized (this.digesterLock) {
/*      */           try {
/* 1083 */             context = (Context)this.digester.parse(xml);
/* 1084 */           } catch (Exception e) {
/* 1085 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { xml }), e);
/* 1086 */             context = new FailedContext();
/*      */           } finally {
/* 1088 */             this.digester.reset();
/* 1089 */             if (context == null) {
/* 1090 */               context = new FailedContext();
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1095 */         if (!copyThisXml && context instanceof StandardContext)
/*      */         {
/* 1097 */           copyThisXml = ((StandardContext)context).getCopyXML();
/*      */         }
/*      */         
/* 1100 */         if (copyThisXml) {
/* 1101 */           Files.copy(xml.toPath(), xmlCopy.toPath(), new java.nio.file.CopyOption[0]);
/* 1102 */           context.setConfigFile(xmlCopy.toURI().toURL());
/*      */         } else {
/* 1104 */           context.setConfigFile(xml.toURI().toURL());
/*      */         } 
/* 1106 */       } else if (!deployThisXML && xml.exists()) {
/*      */ 
/*      */         
/* 1109 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] { cn.getPath(), xml, xmlCopy }));
/* 1110 */         context = new FailedContext();
/*      */       } else {
/* 1112 */         context = Class.forName(this.contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } 
/*      */       
/* 1115 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/* 1116 */       LifecycleListener listener = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1117 */       context.addLifecycleListener(listener);
/*      */       
/* 1119 */       context.setName(cn.getName());
/* 1120 */       context.setPath(cn.getPath());
/* 1121 */       context.setWebappVersion(cn.getVersion());
/* 1122 */       context.setDocBase(cn.getBaseName());
/* 1123 */       this.host.addChild((Container)context);
/* 1124 */     } catch (Throwable t) {
/* 1125 */       ExceptionUtils.handleThrowable(t);
/* 1126 */       log.error(sm.getString("hostConfig.deployDir.error", new Object[] { dir.getAbsolutePath() }), t);
/*      */     } finally {
/* 1128 */       deployedApp = new DeployedApplication(cn.getName(), (xml.exists() && deployThisXML && copyThisXml));
/*      */ 
/*      */ 
/*      */       
/* 1132 */       deployedApp.redeployResources.put(dir.getAbsolutePath() + ".war", Long.valueOf(0L));
/* 1133 */       deployedApp.redeployResources.put(dir.getAbsolutePath(), Long.valueOf(dir.lastModified()));
/* 1134 */       if (deployThisXML && xml.exists()) {
/* 1135 */         if (copyThisXml) {
/* 1136 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(xmlCopy.lastModified()));
/*      */         } else {
/* 1138 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */ 
/*      */           
/* 1141 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1146 */         deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/* 1147 */         if (!xml.exists()) {
/* 1148 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */       } 
/* 1151 */       addWatchedResources(deployedApp, dir.getAbsolutePath(), context);
/*      */ 
/*      */       
/* 1154 */       addGlobalRedeployResources(deployedApp);
/*      */     } 
/*      */     
/* 1157 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/* 1159 */     if (log.isInfoEnabled()) {
/* 1160 */       log.info(sm.getString("hostConfig.deployDir.finished", new Object[] { dir.getAbsolutePath(), 
/* 1161 */               Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void migrateLegacyApps() {
/* 1167 */     File appBase = this.host.getAppBaseFile();
/* 1168 */     File legacyAppBase = this.host.getLegacyAppBaseFile();
/* 1169 */     if (!legacyAppBase.isDirectory()) {
/*      */       return;
/*      */     }
/*      */     
/* 1173 */     ExecutorService es = this.host.getStartStopExecutor();
/* 1174 */     List<Future<?>> results = new ArrayList<>();
/*      */ 
/*      */     
/* 1177 */     String[] migrationCandidates = legacyAppBase.list();
/* 1178 */     if (migrationCandidates == null) {
/*      */       return;
/*      */     }
/* 1181 */     for (String migrationCandidate : migrationCandidates) {
/* 1182 */       File source = new File(legacyAppBase, migrationCandidate);
/* 1183 */       File destination = new File(appBase, migrationCandidate);
/*      */ 
/*      */       
/* 1186 */       if (source.lastModified() > destination.lastModified()) {
/* 1187 */         ContextName cn; if (source.isFile() && source.getName().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/* 1188 */           cn = new ContextName(migrationCandidate, true);
/* 1189 */         } else if (source.isDirectory()) {
/* 1190 */           cn = new ContextName(migrationCandidate, false);
/*      */         } else {
/*      */           continue;
/*      */         } 
/*      */         
/* 1195 */         if (tryAddServiced(cn.getBaseName())) {
/*      */           
/*      */           try {
/* 1198 */             results.add(es.submit(new MigrateApp(this, cn, source, destination)));
/* 1199 */           } catch (Throwable t) {
/* 1200 */             ExceptionUtils.handleThrowable(t);
/* 1201 */             removeServiced(cn.getName());
/* 1202 */             throw t;
/*      */           } 
/*      */         }
/*      */       } 
/*      */       continue;
/*      */     } 
/* 1208 */     for (Future<?> result : results) {
/*      */       try {
/* 1210 */         result.get();
/* 1211 */       } catch (Exception e) {
/* 1212 */         log.error(sm.getString("hostConfig.migrateApp.threaded.error"), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void migrateLegacyApp(File source, File destination) {
/* 1219 */     File tempNew = null;
/*      */     
/*      */     try {
/* 1222 */       tempNew = File.createTempFile("new", null, this.host.getLegacyAppBaseFile());
/* 1223 */       File tempOld = File.createTempFile("old", null, this.host.getLegacyAppBaseFile());
/*      */       
/* 1225 */       Files.delete(tempNew.toPath());
/* 1226 */       Files.delete(tempOld.toPath());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1233 */       Migration migration = new Migration();
/* 1234 */       migration.setSource(source);
/* 1235 */       migration.setDestination(tempNew);
/* 1236 */       migration.execute();
/*      */ 
/*      */       
/* 1239 */       if (destination.exists()) {
/* 1240 */         Files.move(destination.toPath(), tempOld.toPath(), new java.nio.file.CopyOption[0]);
/*      */       }
/* 1242 */       Files.move(tempNew.toPath(), destination.toPath(), new java.nio.file.CopyOption[0]);
/* 1243 */       ExpandWar.delete(tempOld);
/*      */     }
/* 1245 */     catch (Throwable t) {
/* 1246 */       ExceptionUtils.handleThrowable(t);
/* 1247 */       log.warn(sm.getString("hostConfig.migrateError"), t);
/*      */     } finally {
/* 1249 */       if (tempNew != null && tempNew.exists()) {
/* 1250 */         ExpandWar.delete(tempNew);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean deploymentExists(String contextName) {
/* 1264 */     return (this.deployed.containsKey(contextName) || this.host.findChild(contextName) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addWatchedResources(DeployedApplication app, String docBase, Context context) {
/* 1279 */     File docBaseFile = null;
/* 1280 */     if (docBase != null) {
/* 1281 */       docBaseFile = new File(docBase);
/* 1282 */       if (!docBaseFile.isAbsolute()) {
/* 1283 */         docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */       }
/*      */     } 
/* 1286 */     String[] watchedResources = context.findWatchedResources();
/* 1287 */     String[] arrayOfString1 = watchedResources; int i = arrayOfString1.length; byte b = 0; while (true) { if (b < i) { String watchedResource = arrayOfString1[b];
/* 1288 */         File resource = new File(watchedResource);
/* 1289 */         if (!resource.isAbsolute()) {
/* 1290 */           if (docBase != null) {
/* 1291 */             resource = new File(docBaseFile, watchedResource);
/*      */           } else {
/* 1293 */             if (log.isTraceEnabled()) {
/* 1294 */               log.trace("Ignoring non-existent WatchedResource '" + resource.getAbsolutePath() + "'");
/*      */             }
/*      */             b++;
/*      */           } 
/*      */         }
/* 1299 */         if (log.isTraceEnabled()) {
/* 1300 */           log.trace("Watching WatchedResource '" + resource.getAbsolutePath() + "'");
/*      */         }
/* 1302 */         app.reloadResources.put(resource.getAbsolutePath(), Long.valueOf(resource.lastModified())); }
/*      */       else
/*      */       { break; }
/*      */       
/*      */       b++; }
/*      */   
/*      */   } protected void addGlobalRedeployResources(DeployedApplication app) {
/* 1309 */     File hostContextXml = new File(getConfigBaseName(), "context.xml.default");
/* 1310 */     if (hostContextXml.isFile()) {
/* 1311 */       app.redeployResources.put(hostContextXml.getAbsolutePath(), Long.valueOf(hostContextXml.lastModified()));
/*      */     }
/*      */ 
/*      */     
/* 1315 */     File globalContextXml = returnCanonicalPath("conf/context.xml");
/* 1316 */     if (globalContextXml.isFile()) {
/* 1317 */       app.redeployResources.put(globalContextXml.getAbsolutePath(), 
/* 1318 */           Long.valueOf(globalContextXml.lastModified()));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkResources(DeployedApplication app, boolean skipFileModificationResolutionCheck) {
/* 1332 */     String[] resources = (String[])app.redeployResources.keySet().toArray((Object[])new String[0]);
/*      */     
/* 1334 */     long currentTimeWithResolutionOffset = System.currentTimeMillis() - 1000L;
/* 1335 */     for (int i = 0; i < resources.length; i++) {
/* 1336 */       File resource = new File(resources[i]);
/* 1337 */       if (log.isTraceEnabled()) {
/* 1338 */         log.trace("Checking context[" + app.name + "] redeploy resource " + String.valueOf(resource));
/*      */       }
/* 1340 */       long lastModified = ((Long)app.redeployResources.get(resources[i])).longValue();
/* 1341 */       if (resource.exists() || lastModified == 0L) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1346 */         if (resource.lastModified() != lastModified && (
/* 1347 */           !this.host.getAutoDeploy() || resource.lastModified() < currentTimeWithResolutionOffset || skipFileModificationResolutionCheck))
/*      */         {
/* 1349 */           if (resource.isDirectory())
/*      */           
/* 1351 */           { app.redeployResources.put(resources[i], Long.valueOf(resource.lastModified())); }
/* 1352 */           else { if (app.hasDescriptor && resource.getName().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1357 */               Context context = (Context)this.host.findChild(app.name);
/* 1358 */               String docBase = context.getDocBase();
/* 1359 */               if (!docBase.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*      */                 
/* 1361 */                 File docBaseFile = new File(docBase);
/* 1362 */                 if (!docBaseFile.isAbsolute()) {
/* 1363 */                   docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */                 }
/* 1365 */                 reload(app, docBaseFile, resource.getAbsolutePath());
/*      */               } else {
/* 1367 */                 reload(app, null, null);
/*      */               } 
/*      */               
/* 1370 */               app.redeployResources.put(resources[i], Long.valueOf(resource.lastModified()));
/* 1371 */               app.timestamp = System.currentTimeMillis();
/* 1372 */               boolean unpackWAR = this.unpackWARs;
/* 1373 */               if (unpackWAR && context instanceof StandardContext) {
/* 1374 */                 unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */               }
/* 1376 */               if (unpackWAR) {
/* 1377 */                 addWatchedResources(app, context.getDocBase(), context);
/*      */               } else {
/* 1379 */                 addWatchedResources(app, null, context);
/*      */               } 
/*      */               
/*      */               return;
/*      */             } 
/*      */             
/* 1385 */             undeploy(app);
/* 1386 */             deleteRedeployResources(app, resources, i, false);
/*      */ 
/*      */             
/*      */             return; }
/*      */         
/*      */         }
/*      */       } else {
/* 1393 */         if (resource.exists() || !resource.getName().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*      */           try {
/* 1395 */             Thread.sleep(500L);
/* 1396 */           } catch (InterruptedException interruptedException) {}
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1401 */         if (!resource.exists()) {
/*      */ 
/*      */ 
/*      */           
/* 1405 */           undeploy(app);
/* 1406 */           deleteRedeployResources(app, resources, i, true); return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1410 */     resources = (String[])app.reloadResources.keySet().toArray((Object[])new String[0]);
/* 1411 */     boolean update = false;
/* 1412 */     for (String s : resources) {
/* 1413 */       File resource = new File(s);
/* 1414 */       if (log.isTraceEnabled()) {
/* 1415 */         log.trace("Checking context[" + app.name + "] reload resource " + String.valueOf(resource));
/*      */       }
/* 1417 */       long lastModified = ((Long)app.reloadResources.get(s)).longValue();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1422 */       if ((resource.lastModified() != lastModified && (
/* 1423 */         !this.host.getAutoDeploy() || resource.lastModified() < currentTimeWithResolutionOffset || skipFileModificationResolutionCheck)) || update) {
/*      */ 
/*      */         
/* 1426 */         if (!update) {
/*      */           
/* 1428 */           reload(app, null, null);
/* 1429 */           update = true;
/*      */         } 
/*      */ 
/*      */         
/* 1433 */         app.reloadResources.put(s, Long.valueOf(resource.lastModified()));
/*      */       } 
/* 1435 */       app.timestamp = System.currentTimeMillis();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void reload(DeployedApplication app, File fileToRemove, String newDocBase) {
/* 1444 */     if (log.isInfoEnabled()) {
/* 1445 */       log.info(sm.getString("hostConfig.reload", new Object[] { app.name }));
/*      */     }
/* 1447 */     Context context = (Context)this.host.findChild(app.name);
/* 1448 */     if (context.getState().isAvailable()) {
/* 1449 */       if (fileToRemove != null && newDocBase != null) {
/* 1450 */         context.addLifecycleListener(new ExpandedDirectoryRemovalListener(fileToRemove, newDocBase));
/*      */       }
/*      */       
/* 1453 */       context.reload();
/*      */     }
/*      */     else {
/*      */       
/* 1457 */       if (fileToRemove != null && newDocBase != null) {
/* 1458 */         ExpandWar.delete(fileToRemove);
/* 1459 */         context.setDocBase(newDocBase);
/*      */       } 
/*      */       try {
/* 1462 */         context.start();
/* 1463 */       } catch (Exception e) {
/* 1464 */         log.error(sm.getString("hostConfig.context.restart", new Object[] { app.name }), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void undeploy(DeployedApplication app) {
/* 1471 */     if (log.isInfoEnabled()) {
/* 1472 */       log.info(sm.getString("hostConfig.undeploy", new Object[] { app.name }));
/*      */     }
/* 1474 */     Container context = this.host.findChild(app.name);
/*      */     try {
/* 1476 */       this.host.removeChild(context);
/* 1477 */     } catch (Throwable t) {
/* 1478 */       ExceptionUtils.handleThrowable(t);
/* 1479 */       log.warn(sm.getString("hostConfig.context.remove", new Object[] { app.name }), t);
/*      */     } 
/* 1481 */     this.deployed.remove(app.name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void deleteRedeployResources(DeployedApplication app, String[] resources, int i, boolean deleteReloadResources) {
/* 1489 */     for (int j = i + 1; j < resources.length; j++) {
/* 1490 */       File current = new File(resources[j]);
/*      */       
/* 1492 */       if (!"context.xml.default".equals(current.getName()))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1497 */         if (isDeletableResource(app, current)) {
/* 1498 */           if (log.isDebugEnabled()) {
/* 1499 */             log.debug(sm.getString("hostConfig.delete", new Object[] { current }));
/*      */           }
/* 1501 */           ExpandWar.delete(current);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1506 */     if (deleteReloadResources) {
/* 1507 */       String[] resources2 = (String[])app.reloadResources.keySet().toArray((Object[])new String[0]);
/* 1508 */       for (String s : resources2) {
/* 1509 */         File current = new File(s);
/*      */         
/* 1511 */         if (!"context.xml.default".equals(current.getName()))
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1516 */           if (isDeletableResource(app, current)) {
/* 1517 */             if (log.isDebugEnabled()) {
/* 1518 */               log.debug(sm.getString("hostConfig.delete", new Object[] { current }));
/*      */             }
/* 1520 */             ExpandWar.delete(current);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isDeletableResource(DeployedApplication app, File resource) {
/*      */     String canonicalLocation;
/*      */     String canonicalAppBase;
/*      */     String canonicalConfigBase;
/* 1541 */     if (!resource.isAbsolute()) {
/* 1542 */       log.warn(sm.getString("hostConfig.resourceNotAbsolute", new Object[] { app.name, resource }));
/* 1543 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1549 */       canonicalLocation = resource.getParentFile().getCanonicalPath();
/* 1550 */     } catch (IOException ioe) {
/* 1551 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { resource.getParentFile(), app.name }), ioe);
/* 1552 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1557 */       canonicalAppBase = this.host.getAppBaseFile().getCanonicalPath();
/* 1558 */     } catch (IOException ioe) {
/* 1559 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { this.host.getAppBaseFile(), app.name }), ioe);
/* 1560 */       return false;
/*      */     } 
/*      */     
/* 1563 */     if (canonicalLocation.equals(canonicalAppBase))
/*      */     {
/* 1565 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1570 */       canonicalConfigBase = this.host.getConfigBaseFile().getCanonicalPath();
/* 1571 */     } catch (IOException ioe) {
/* 1572 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] { this.host.getConfigBaseFile(), app.name }), ioe);
/* 1573 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1577 */     return (canonicalLocation.equals(canonicalConfigBase) && resource.getName().endsWith(".xml"));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeStart() {
/* 1583 */     if (this.host.getCreateDirs()) {
/* 1584 */       File[] dirs = { this.host.getAppBaseFile(), this.host.getConfigBaseFile() };
/* 1585 */       for (File dir : dirs) {
/* 1586 */         if (!dir.mkdirs() && !dir.isDirectory()) {
/* 1587 */           log.error(sm.getString("hostConfig.createDirs", new Object[] { dir }));
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start() {
/* 1599 */     if (log.isTraceEnabled()) {
/* 1600 */       log.trace(sm.getString("hostConfig.start"));
/*      */     }
/*      */     
/*      */     try {
/* 1604 */       ObjectName hostON = this.host.getObjectName();
/* 1605 */       this.oname = new ObjectName(hostON.getDomain() + ":type=Deployer,host=" + hostON.getDomain());
/* 1606 */       Registry.getRegistry(null).registerComponent(this, this.oname, getClass().getName());
/* 1607 */     } catch (Exception e) {
/* 1608 */       log.warn(sm.getString("hostConfig.jmx.register", new Object[] { this.oname }), e);
/*      */     } 
/*      */     
/* 1611 */     if (!this.host.getAppBaseFile().isDirectory()) {
/* 1612 */       log.error(sm.getString("hostConfig.appBase", new Object[] { this.host.getName(), this.host.getAppBaseFile().getPath() }));
/* 1613 */       this.host.setDeployOnStartup(false);
/* 1614 */       this.host.setAutoDeploy(false);
/*      */     } 
/*      */     
/* 1617 */     if (this.host.getDeployOnStartup()) {
/* 1618 */       deployApps();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/* 1628 */     if (log.isTraceEnabled()) {
/* 1629 */       log.trace(sm.getString("hostConfig.stop"));
/*      */     }
/*      */     
/* 1632 */     if (this.oname != null) {
/*      */       try {
/* 1634 */         Registry.getRegistry(null).unregisterComponent(this.oname);
/* 1635 */       } catch (Exception e) {
/* 1636 */         log.warn(sm.getString("hostConfig.jmx.unregister", new Object[] { this.oname }), e);
/*      */       } 
/*      */     }
/* 1639 */     this.oname = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void check() {
/* 1648 */     if (this.host.getAutoDeploy()) {
/*      */       
/* 1650 */       DeployedApplication[] apps = (DeployedApplication[])this.deployed.values().toArray((Object[])new DeployedApplication[0]);
/* 1651 */       for (DeployedApplication app : apps) {
/* 1652 */         if (tryAddServiced(app.name)) {
/*      */           
/* 1654 */           try { checkResources(app, false);
/*      */             
/* 1656 */             removeServiced(app.name); } finally { removeServiced(app.name); }
/*      */         
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1662 */       if (this.host.getUndeployOldVersions()) {
/* 1663 */         checkUndeploy();
/*      */       }
/*      */ 
/*      */       
/* 1667 */       deployApps();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void check(String name) {
/* 1682 */     synchronized (this.host) {
/* 1683 */       if (!this.host.getState().isAvailable()) {
/*      */         return;
/*      */       }
/* 1686 */       if (tryAddServiced(name)) {
/*      */         try {
/* 1688 */           DeployedApplication app = this.deployed.get(name);
/* 1689 */           if (app != null) {
/* 1690 */             checkResources(app, true);
/*      */           }
/* 1692 */           deployApps(name);
/*      */         } finally {
/* 1694 */           removeServiced(name);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkUndeploy() {
/* 1705 */     synchronized (this.host) {
/* 1706 */       if (this.deployed.size() < 2) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1711 */       SortedSet<String> sortedAppNames = new TreeSet<>(this.deployed.keySet());
/*      */       
/* 1713 */       Iterator<String> iter = sortedAppNames.iterator();
/*      */       
/* 1715 */       ContextName previous = new ContextName(iter.next(), false);
/*      */       while (true) {
/* 1717 */         ContextName current = new ContextName(iter.next(), false);
/*      */         
/* 1719 */         if (current.getPath().equals(previous.getPath())) {
/*      */ 
/*      */           
/* 1722 */           Context previousContext = (Context)this.host.findChild(previous.getName());
/* 1723 */           Context currentContext = (Context)this.host.findChild(current.getName());
/* 1724 */           if (previousContext != null && currentContext != null && currentContext.getState().isAvailable() && 
/* 1725 */             tryAddServiced(previous.getName())) {
/*      */             try {
/* 1727 */               Manager manager = previousContext.getManager();
/* 1728 */               if (manager != null) {
/*      */                 int sessionCount;
/* 1730 */                 if (manager instanceof DistributedManager) {
/* 1731 */                   sessionCount = ((DistributedManager)manager).getActiveSessionsFull();
/*      */                 } else {
/* 1733 */                   sessionCount = manager.getActiveSessions();
/*      */                 } 
/* 1735 */                 if (sessionCount == 0) {
/* 1736 */                   if (log.isInfoEnabled()) {
/* 1737 */                     log.info(sm.getString("hostConfig.undeployVersion", new Object[] { previous.getName() }));
/*      */                   }
/* 1739 */                   DeployedApplication app = this.deployed.get(previous.getName());
/* 1740 */                   String[] resources = (String[])app.redeployResources.keySet().toArray((Object[])new String[0]);
/*      */ 
/*      */ 
/*      */                   
/* 1744 */                   undeploy(app);
/* 1745 */                   deleteRedeployResources(app, resources, -1, true);
/*      */                 } 
/*      */               } 
/*      */             } finally {
/* 1749 */               removeServiced(previous.getName());
/*      */             } 
/*      */           }
/*      */         } 
/* 1753 */         previous = current;
/* 1754 */         if (!iter.hasNext()) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void manageApp(Context context) {
/* 1765 */     String contextName = context.getName();
/*      */     
/* 1767 */     if (this.deployed.containsKey(contextName)) {
/*      */       return;
/*      */     }
/*      */     
/* 1771 */     DeployedApplication deployedApp = new DeployedApplication(contextName, false);
/*      */ 
/*      */     
/* 1774 */     boolean isWar = false;
/* 1775 */     if (context.getDocBase() != null) {
/* 1776 */       File docBase = new File(context.getDocBase());
/* 1777 */       if (!docBase.isAbsolute()) {
/* 1778 */         docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */       }
/* 1780 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/* 1781 */       if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/* 1782 */         isWar = true;
/*      */       }
/*      */     } 
/* 1785 */     this.host.addChild((Container)context);
/*      */ 
/*      */     
/* 1788 */     boolean unpackWAR = this.unpackWARs;
/* 1789 */     if (unpackWAR && context instanceof StandardContext) {
/* 1790 */       unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */     }
/* 1792 */     if (isWar && unpackWAR) {
/* 1793 */       File docBase = new File(this.host.getAppBaseFile(), context.getBaseName());
/* 1794 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/* 1795 */       addWatchedResources(deployedApp, docBase.getAbsolutePath(), context);
/*      */     } else {
/* 1797 */       addWatchedResources(deployedApp, null, context);
/*      */     } 
/* 1799 */     this.deployed.put(contextName, deployedApp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unmanageApp(String contextName) {
/* 1810 */     this.deployed.remove(contextName);
/* 1811 */     this.host.removeChild(this.host.findChild(contextName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class DeployedApplication
/*      */   {
/*      */     public final String name;
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean hasDescriptor;
/*      */ 
/*      */ 
/*      */     
/*      */     public final LinkedHashMap<String, Long> redeployResources;
/*      */ 
/*      */     
/*      */     public final HashMap<String, Long> reloadResources;
/*      */ 
/*      */     
/*      */     public long timestamp;
/*      */ 
/*      */     
/*      */     public boolean loggedDirWarning;
/*      */ 
/*      */ 
/*      */     
/*      */     public DeployedApplication(String name, boolean hasDescriptor) {
/* 1841 */       this.redeployResources = new LinkedHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1848 */       this.reloadResources = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1853 */       this.timestamp = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1860 */       this.loggedDirWarning = false;
/*      */       this.name = name;
/*      */       this.hasDescriptor = hasDescriptor;
/*      */     } }
/*      */   
/*      */   private static class DeployDescriptor implements Runnable { private final HostConfig config;
/*      */     private final ContextName cn;
/*      */     private final File descriptor;
/*      */     
/*      */     DeployDescriptor(HostConfig config, ContextName cn, File descriptor) {
/* 1870 */       this.config = config;
/* 1871 */       this.cn = cn;
/* 1872 */       this.descriptor = descriptor;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1878 */         this.config.deployDescriptor(this.cn, this.descriptor);
/*      */       } finally {
/* 1880 */         this.config.removeServiced(this.cn.getName());
/*      */       } 
/*      */     } }
/*      */ 
/*      */   
/*      */   private static class DeployWar
/*      */     implements Runnable {
/*      */     private final HostConfig config;
/*      */     private final ContextName cn;
/*      */     private final File war;
/*      */     
/*      */     DeployWar(HostConfig config, ContextName cn, File war) {
/* 1892 */       this.config = config;
/* 1893 */       this.cn = cn;
/* 1894 */       this.war = war;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1900 */         this.config.deployWAR(this.cn, this.war);
/*      */       } finally {
/* 1902 */         this.config.removeServiced(this.cn.getName());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DeployDirectory
/*      */     implements Runnable {
/*      */     private final HostConfig config;
/*      */     private final ContextName cn;
/*      */     private final File dir;
/*      */     
/*      */     DeployDirectory(HostConfig config, ContextName cn, File dir) {
/* 1914 */       this.config = config;
/* 1915 */       this.cn = cn;
/* 1916 */       this.dir = dir;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1922 */         this.config.deployDirectory(this.cn, this.dir);
/*      */       } finally {
/* 1924 */         this.config.removeServiced(this.cn.getName());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class MigrateApp
/*      */     implements Runnable
/*      */   {
/*      */     private final HostConfig config;
/*      */     private final ContextName cn;
/*      */     private final File source;
/*      */     private final File destination;
/*      */     
/*      */     MigrateApp(HostConfig config, ContextName cn, File source, File destination) {
/* 1938 */       this.config = config;
/* 1939 */       this.cn = cn;
/* 1940 */       this.source = source;
/* 1941 */       this.destination = destination;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/* 1947 */         this.config.migrateLegacyApp(this.source, this.destination);
/*      */       } finally {
/* 1949 */         this.config.removeServiced(this.cn.getName());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ExpandedDirectoryRemovalListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     private final File toDelete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String newDocBase;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ExpandedDirectoryRemovalListener(File toDelete, String newDocBase) {
/* 1976 */       this.toDelete = toDelete;
/* 1977 */       this.newDocBase = newDocBase;
/*      */     }
/*      */ 
/*      */     
/*      */     public void lifecycleEvent(LifecycleEvent event) {
/* 1982 */       if ("after_stop".equals(event.getType())) {
/*      */         
/* 1984 */         Context context = (Context)event.getLifecycle();
/*      */ 
/*      */         
/* 1987 */         ExpandWar.delete(this.toDelete);
/*      */ 
/*      */         
/* 1990 */         context.setDocBase(this.newDocBase);
/*      */ 
/*      */ 
/*      */         
/* 1994 */         context.removeLifecycleListener(this);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\HostConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */