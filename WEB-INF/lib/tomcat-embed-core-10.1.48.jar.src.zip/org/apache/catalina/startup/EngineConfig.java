/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineConfig
/*     */   implements LifecycleListener
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(EngineConfig.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected Engine engine = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*     */     try {
/*  66 */       this.engine = (Engine)event.getLifecycle();
/*  67 */     } catch (ClassCastException e) {
/*  68 */       log.error(sm.getString("engineConfig.cce", new Object[] { event.getLifecycle() }), e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  73 */     if (event.getType().equals("start")) {
/*  74 */       start();
/*  75 */     } else if (event.getType().equals("stop")) {
/*  76 */       stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void start() {
/*  90 */     if (this.engine.getLogger().isTraceEnabled()) {
/*  91 */       this.engine.getLogger().trace(sm.getString("engineConfig.start"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stop() {
/* 102 */     if (this.engine.getLogger().isTraceEnabled())
/* 103 */       this.engine.getLogger().trace(sm.getString("engineConfig.stop")); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\EngineConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */