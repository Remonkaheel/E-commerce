/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionLoggerListener
/*     */   implements LifecycleListener
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(VersionLoggerListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */   private boolean logArgs = true;
/*     */   
/*     */   private boolean logEnv = false;
/*     */   private boolean logProps = false;
/*     */   
/*     */   public boolean getLogArgs() {
/*  54 */     return this.logArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogArgs(boolean logArgs) {
/*  59 */     this.logArgs = logArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getLogEnv() {
/*  64 */     return this.logEnv;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogEnv(boolean logEnv) {
/*  69 */     this.logEnv = logEnv;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getLogProps() {
/*  74 */     return this.logProps;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLogProps(boolean logProps) {
/*  79 */     this.logProps = logProps;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  85 */     if ("before_init".equals(event.getType())) {
/*  86 */       if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/*  87 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*  89 */       log();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void log() {
/*  95 */     log.info(sm.getString("versionLoggerListener.serverInfo.server.version", new Object[] { ServerInfo.getServerInfo() }));
/*  96 */     log.info(sm.getString("versionLoggerListener.serverInfo.server.built", new Object[] { ServerInfo.getServerBuilt() }));
/*  97 */     log.info(sm.getString("versionLoggerListener.serverInfo.server.number", new Object[] { ServerInfo.getServerNumber() }));
/*  98 */     log.info(sm.getString("versionLoggerListener.os.name", new Object[] { System.getProperty("os.name") }));
/*  99 */     log.info(sm.getString("versionLoggerListener.os.version", new Object[] { System.getProperty("os.version") }));
/* 100 */     log.info(sm.getString("versionLoggerListener.os.arch", new Object[] { System.getProperty("os.arch") }));
/* 101 */     log.info(sm.getString("versionLoggerListener.java.home", new Object[] { System.getProperty("java.home") }));
/* 102 */     log.info(sm.getString("versionLoggerListener.vm.version", new Object[] { System.getProperty("java.runtime.version") }));
/* 103 */     log.info(sm.getString("versionLoggerListener.vm.vendor", new Object[] { System.getProperty("java.vm.vendor") }));
/* 104 */     log.info(sm.getString("versionLoggerListener.catalina.base", new Object[] { System.getProperty("catalina.base") }));
/* 105 */     log.info(sm.getString("versionLoggerListener.catalina.home", new Object[] { System.getProperty("catalina.home") }));
/*     */     
/* 107 */     if (this.logArgs) {
/* 108 */       List<String> args = ManagementFactory.getRuntimeMXBean().getInputArguments();
/* 109 */       for (String arg : args) {
/* 110 */         log.info(sm.getString("versionLoggerListener.arg", new Object[] { arg }));
/*     */       } 
/*     */     } 
/*     */     
/* 114 */     if (this.logEnv) {
/* 115 */       SortedMap<String, String> sortedMap = new TreeMap<>(System.getenv());
/* 116 */       for (Map.Entry<String, String> e : sortedMap.entrySet()) {
/* 117 */         log.info(sm.getString("versionLoggerListener.env", new Object[] { e.getKey(), e.getValue() }));
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     if (this.logProps) {
/* 122 */       SortedMap<String, String> sortedMap = new TreeMap<>();
/* 123 */       for (Map.Entry<Object, Object> e : System.getProperties().entrySet()) {
/* 124 */         sortedMap.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
/*     */       }
/* 126 */       for (Map.Entry<String, String> e : sortedMap.entrySet()) {
/* 127 */         log.info(sm.getString("versionLoggerListener.prop", new Object[] { e.getKey(), e.getValue() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\VersionLoggerListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */