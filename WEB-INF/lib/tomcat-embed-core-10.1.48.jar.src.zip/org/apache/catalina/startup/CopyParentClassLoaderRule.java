/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.tomcat.util.digester.Rule;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyParentClassLoaderRule
/*    */   extends Rule
/*    */ {
/*    */   public void begin(String namespace, String name, Attributes attributes) throws Exception {
/* 50 */     if (this.digester.getLogger().isTraceEnabled()) {
/* 51 */       this.digester.getLogger().trace("Copying parent class loader");
/*    */     }
/* 53 */     Container child = (Container)this.digester.peek(0);
/* 54 */     Object parent = this.digester.peek(1);
/* 55 */     Method method = parent.getClass().getMethod("getParentClassLoader", new Class[0]);
/* 56 */     ClassLoader classLoader = (ClassLoader)method.invoke(parent, new Object[0]);
/* 57 */     child.setParentClassLoader(classLoader);
/*    */     
/* 59 */     StringBuilder code = this.digester.getGeneratedCode();
/* 60 */     if (code != null) {
/* 61 */       code.append(this.digester.toVariableName(child)).append(".setParentClassLoader(");
/* 62 */       code.append(this.digester.toVariableName(parent)).append(".getParentClassLoader());");
/* 63 */       code.append(System.lineSeparator());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\CopyParentClassLoaderRule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */