/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import jakarta.servlet.ServletContainerInitializer;
/*      */ import jakarta.servlet.ServletContext;
/*      */ import jakarta.servlet.ServletRegistration;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.ServletSecurityElement;
/*      */ import jakarta.servlet.descriptor.JspConfigDescriptor;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.File;
/*      */ import java.net.URL;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import org.apache.catalina.AccessLog;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Cluster;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.ThreadBindingListener;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.JarScanner;
/*      */ import org.apache.tomcat.util.descriptor.web.ApplicationParameter;
/*      */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FailedContext
/*      */   extends LifecycleMBeanBase
/*      */   implements Context
/*      */ {
/*   75 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*      */ 
/*      */   
/*      */   private URL configFile;
/*      */   
/*      */   private String docBase;
/*      */ 
/*      */   
/*      */   public URL getConfigFile() {
/*   84 */     return this.configFile;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setConfigFile(URL configFile) {
/*   89 */     this.configFile = configFile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDocBase() {
/*   97 */     return this.docBase;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDocBase(String docBase) {
/*  102 */     this.docBase = docBase;
/*      */   }
/*      */ 
/*      */   
/*  106 */   private String name = null;
/*      */   private Container parent;
/*      */   
/*      */   public String getName() {
/*  110 */     return this.name;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  115 */     this.name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Container getParent() {
/*  123 */     return this.parent;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setParent(Container parent) {
/*  128 */     this.parent = parent;
/*      */   }
/*      */ 
/*      */   
/*  132 */   private String path = null;
/*      */ 
/*      */   
/*      */   public String getPath() {
/*  136 */     return this.path;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPath(String path) {
/*  141 */     this.path = path;
/*      */   }
/*      */ 
/*      */   
/*  145 */   private String webappVersion = null;
/*      */ 
/*      */   
/*      */   public String getWebappVersion() {
/*  149 */     return this.webappVersion;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWebappVersion(String webappVersion) {
/*  154 */     this.webappVersion = webappVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDomainInternal() {
/*  160 */     Container p = getParent();
/*  161 */     if (p == null) {
/*  162 */       return null;
/*      */     }
/*  164 */     return p.getDomain();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMBeanKeyProperties() {
/*  171 */     FailedContext failedContext = this;
/*  172 */     StringBuilder keyProperties = new StringBuilder();
/*  173 */     int containerCount = 0;
/*      */ 
/*      */ 
/*      */     
/*  177 */     while (!(failedContext instanceof org.apache.catalina.Engine)) {
/*  178 */       if (failedContext instanceof Context)
/*  179 */       { keyProperties.append(",context=");
/*  180 */         ContextName cn = new ContextName(failedContext.getName(), false);
/*  181 */         keyProperties.append(cn.getDisplayName()); }
/*  182 */       else if (failedContext instanceof org.apache.catalina.Host)
/*  183 */       { keyProperties.append(",host=");
/*  184 */         keyProperties.append(failedContext.getName()); }
/*  185 */       else { if (failedContext == null) {
/*      */           
/*  187 */           keyProperties.append(",container");
/*  188 */           keyProperties.append(containerCount);
/*  189 */           keyProperties.append("=null");
/*      */           
/*      */           break;
/*      */         } 
/*  193 */         keyProperties.append(",container");
/*  194 */         keyProperties.append(containerCount++);
/*  195 */         keyProperties.append('=');
/*  196 */         keyProperties.append(failedContext.getName()); }
/*      */       
/*  198 */       Container container = failedContext.getParent();
/*      */     } 
/*  200 */     return keyProperties.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getObjectNameKeyProperties() {
/*  207 */     StringBuilder keyProperties = new StringBuilder("j2eeType=WebModule,name=//");
/*      */     
/*  209 */     String hostname = getParent().getName();
/*  210 */     keyProperties.append(Objects.<String>requireNonNullElse(hostname, "DEFAULT"));
/*      */     
/*  212 */     String contextName = getName();
/*  213 */     if (!contextName.startsWith("/")) {
/*  214 */       keyProperties.append('/');
/*      */     }
/*  216 */     keyProperties.append(contextName);
/*      */     
/*  218 */     keyProperties.append(",J2EEApplication=none,J2EEServer=none");
/*      */     
/*  220 */     return keyProperties.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/*  226 */     throw new LifecycleException(sm.getString("failedContext.start", new Object[] { getName() }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWatchedResource(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findWatchedResources() {
/*  245 */     return new String[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWatchedResource(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addChild(Container child) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Container findChild(String name) {
/*  261 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Container[] findChildren() {
/*  266 */     return new Container[0];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeChild(Container child) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  276 */     return getName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Loader getLoader() {
/*  282 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(Loader loader) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Log getLogger() {
/*  292 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLogName() {
/*  297 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Manager getManager() {
/*  302 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManager(Manager manager) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Pipeline getPipeline() {
/*  312 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Cluster getCluster() {
/*  317 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCluster(Cluster cluster) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBackgroundProcessorDelay() {
/*  327 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackgroundProcessorDelay(int delay) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassLoader getParentClassLoader() {
/*  337 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParentClassLoader(ClassLoader parent) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Realm getRealm() {
/*  347 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRealm(Realm realm) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public WebResourceRoot getResources() {
/*  357 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResources(WebResourceRoot resources) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundProcess() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addContainerListener(ContainerListener listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ContainerListener[] findContainerListeners() {
/*  377 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeContainerListener(ContainerListener listener) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireContainerEvent(String type, Object data) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void logAccess(Request request, Response response, long time, boolean useDefault) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public AccessLog getAccessLog() {
/*  407 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStartStopThreads() {
/*  412 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStartStopThreads(int startStopThreads) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAllowCasualMultipartParsing() {
/*  422 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowCasualMultipartParsing(boolean allowCasualMultipartParsing) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getApplicationEventListeners() {
/*  432 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationEventListeners(Object[] listeners) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getApplicationLifecycleListeners() {
/*  442 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationLifecycleListeners(Object[] listeners) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCharset(Locale locale) {
/*  452 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getConfigured() {
/*  457 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigured(boolean configured) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCookies() {
/*  467 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCookies(boolean cookies) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionCookieName() {
/*  477 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionCookieName(String sessionCookieName) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseHttpOnly() {
/*  487 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseHttpOnly(boolean useHttpOnly) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUsePartitioned() {
/*  497 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUsePartitioned(boolean usePartitioned) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionCookieDomain() {
/*  507 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionCookieDomain(String sessionCookieDomain) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionCookiePath() {
/*  517 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionCookiePath(String sessionCookiePath) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSessionCookiePathUsesTrailingSlash() {
/*  527 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionCookiePathUsesTrailingSlash(boolean sessionCookiePathUsesTrailingSlash) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCrossContext() {
/*  537 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCrossContext(boolean crossContext) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAltDDName() {
/*  547 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAltDDName(String altDDName) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDenyUncoveredHttpMethods() {
/*  557 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDenyUncoveredHttpMethods(boolean denyUncoveredHttpMethods) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDisplayName() {
/*  567 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayName(String displayName) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDistributable() {
/*  577 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDistributable(boolean distributable) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncodedPath() {
/*  587 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getIgnoreAnnotations() {
/*  592 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreAnnotations(boolean ignoreAnnotations) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public LoginConfig getLoginConfig() {
/*  602 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoginConfig(LoginConfig config) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public NamingResourcesImpl getNamingResources() {
/*  612 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNamingResources(NamingResourcesImpl namingResources) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPublicId() {
/*  622 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPublicId(String publicId) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getReloadable() {
/*  632 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReloadable(boolean reloadable) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getOverride() {
/*  642 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOverride(boolean override) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPrivileged() {
/*  652 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrivileged(boolean privileged) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletContext getServletContext() {
/*  662 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getSessionTimeout() {
/*  667 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionTimeout(int timeout) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSwallowAbortedUploads() {
/*  677 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSwallowAbortedUploads(boolean swallowAbortedUploads) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSwallowOutput() {
/*  687 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSwallowOutput(boolean swallowOutput) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWrapperClass() {
/*  697 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWrapperClass(String wrapperClass) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getXmlNamespaceAware() {
/*  707 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXmlNamespaceAware(boolean xmlNamespaceAware) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getXmlValidation() {
/*  717 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXmlValidation(boolean xmlValidation) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getXmlBlockExternal() {
/*  727 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXmlBlockExternal(boolean xmlBlockExternal) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getTldValidation() {
/*  737 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTldValidation(boolean tldValidation) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public JarScanner getJarScanner() {
/*  747 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJarScanner(JarScanner jarScanner) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Authenticator getAuthenticator() {
/*  757 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogEffectiveWebXml(boolean logEffectiveWebXml) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLogEffectiveWebXml() {
/*  767 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addApplicationListener(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findApplicationListeners() {
/*  777 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeApplicationListener(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addApplicationParameter(ApplicationParameter parameter) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ApplicationParameter[] findApplicationParameters() {
/*  792 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeApplicationParameter(String name) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConstraint(SecurityConstraint constraint) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public SecurityConstraint[] findConstraints() {
/*  807 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeConstraint(SecurityConstraint constraint) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addErrorPage(ErrorPage errorPage) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ErrorPage findErrorPage(int errorCode) {
/*  822 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ErrorPage findErrorPage(Throwable throwable) {
/*  827 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ErrorPage[] findErrorPages() {
/*  832 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeErrorPage(ErrorPage errorPage) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFilterDef(FilterDef filterDef) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public FilterDef findFilterDef(String filterName) {
/*  847 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public FilterDef[] findFilterDefs() {
/*  852 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFilterDef(FilterDef filterDef) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFilterMap(FilterMap filterMap) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFilterMapBefore(FilterMap filterMap) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public FilterMap[] findFilterMaps() {
/*  872 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFilterMap(FilterMap filterMap) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocaleEncodingMappingParameter(String locale, String encoding) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMimeMapping(String extension, String mimeType) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String findMimeMapping(String extension) {
/*  892 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findMimeMappings() {
/*  897 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMimeMapping(String extension) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addParameter(String name, String value) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String findParameter(String name) {
/*  912 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findParameters() {
/*  917 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeParameter(String name) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRoleMapping(String role, String link) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String findRoleMapping(String role) {
/*  932 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeRoleMapping(String role) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSecurityRole(String role) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean findSecurityRole(String role) {
/*  947 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findSecurityRoles() {
/*  952 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSecurityRole(String role) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addServletMappingDecoded(String pattern, String name, boolean jspWildcard) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String findServletMapping(String pattern) {
/*  967 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findServletMappings() {
/*  972 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeServletMapping(String pattern) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWelcomeFile(String name) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean findWelcomeFile(String name) {
/*  987 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findWelcomeFiles() {
/*  992 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWelcomeFile(String name) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWrapperLifecycle(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findWrapperLifecycles() {
/* 1007 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWrapperLifecycle(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWrapperListener(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findWrapperListeners() {
/* 1022 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWrapperListener(String listener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public InstanceManager createInstanceManager() {
/* 1032 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Wrapper createWrapper() {
/* 1037 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean fireRequestInitEvent(ServletRequest request) {
/* 1042 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean fireRequestDestroyEvent(ServletRequest request) {
/* 1047 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void reload() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRealPath(String path) {
/* 1057 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getEffectiveMajorVersion() {
/* 1062 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEffectiveMajorVersion(int major) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public int getEffectiveMinorVersion() {
/* 1072 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEffectiveMinorVersion(int minor) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public JspConfigDescriptor getJspConfigDescriptor() {
/* 1082 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJspConfigDescriptor(JspConfigDescriptor descriptor) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void addServletContainerInitializer(ServletContainerInitializer sci, Set<Class<?>> classes) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPaused() {
/* 1097 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isServlet22() {
/* 1102 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> addServletSecurity(ServletRegistration.Dynamic registration, ServletSecurityElement servletSecurityElement) {
/* 1108 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResourceOnlyServlets(String resourceOnlyServlets) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getResourceOnlyServlets() {
/* 1118 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isResourceOnlyServlet(String servletName) {
/* 1123 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBaseName() {
/* 1128 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFireRequestListenersOnForwards(boolean enable) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFireRequestListenersOnForwards() {
/* 1138 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPreemptiveAuthentication(boolean enable) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPreemptiveAuthentication() {
/* 1148 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSendRedirectBody(boolean enable) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSendRedirectBody() {
/* 1158 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addValve(Valve valve) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public File getCatalinaBase() {
/* 1168 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public File getCatalinaHome() {
/* 1173 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAddWebinfClassesResources(boolean addWebinfClassesResources) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAddWebinfClassesResources() {
/* 1183 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPostConstructMethod(String clazz, String method) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPreDestroyMethod(String clazz, String method) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePostConstructMethod(String clazz) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePreDestroyMethod(String clazz) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String findPostConstructMethod(String clazz) {
/* 1208 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String findPreDestroyMethod(String clazz) {
/* 1213 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, String> findPostConstructMethods() {
/* 1218 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, String> findPreDestroyMethods() {
/* 1223 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public InstanceManager getInstanceManager() {
/* 1228 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInstanceManager(InstanceManager instanceManager) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContainerSciFilter(String containerSciFilter) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContainerSciFilter() {
/* 1243 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ThreadBindingListener getThreadBindingListener() {
/* 1248 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setThreadBindingListener(ThreadBindingListener threadBindingListener) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassLoader bind(boolean usePrivilegedAction, ClassLoader originalClassLoader) {
/* 1258 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void unbind(boolean usePrivilegedAction, ClassLoader originalClassLoader) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getNamingToken() {
/* 1268 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCookieProcessor(CookieProcessor cookieProcessor) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public CookieProcessor getCookieProcessor() {
/* 1278 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValidateClientProvidedNewSessionId(boolean validateClientProvidedNewSessionId) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getValidateClientProvidedNewSessionId() {
/* 1288 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMapperContextRootRedirectEnabled(boolean mapperContextRootRedirectEnabled) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMapperContextRootRedirectEnabled() {
/* 1298 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMapperDirectoryRedirectEnabled(boolean mapperDirectoryRedirectEnabled) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMapperDirectoryRedirectEnabled() {
/* 1308 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseRelativeRedirects(boolean useRelativeRedirects) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseRelativeRedirects() {
/* 1318 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDispatchersUseEncodedPaths(boolean dispatchersUseEncodedPaths) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDispatchersUseEncodedPaths() {
/* 1328 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestCharacterEncoding(String encoding) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestCharacterEncoding() {
/* 1338 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResponseCharacterEncoding(String encoding) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public String getResponseCharacterEncoding() {
/* 1348 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowMultipleLeadingForwardSlashInPath(boolean allowMultipleLeadingForwardSlashInPath) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAllowMultipleLeadingForwardSlashInPath() {
/* 1358 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void incrementInProgressAsyncCount() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void decrementInProgressAsyncCount() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCreateUploadTargets(boolean createUploadTargets) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCreateUploadTargets() {
/* 1377 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getAlwaysAccessSession() {
/* 1382 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlwaysAccessSession(boolean alwaysAccessSession) {}
/*      */ 
/*      */   
/*      */   public boolean getContextGetResourceRequiresSlash() {
/* 1391 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContextGetResourceRequiresSlash(boolean contextGetResourceRequiresSlash) {}
/*      */ 
/*      */   
/*      */   public boolean getDispatcherWrapsSameObject() {
/* 1400 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDispatcherWrapsSameObject(boolean dispatcherWrapsSameObject) {}
/*      */ 
/*      */   
/*      */   public boolean getParallelAnnotationScanning() {
/* 1409 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParallelAnnotationScanning(boolean parallelAnnotationScanning) {}
/*      */ 
/*      */   
/*      */   public boolean getUseBloomFilterForArchives() {
/* 1418 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseBloomFilterForArchives(boolean useBloomFilterForArchives) {}
/*      */ 
/*      */   
/*      */   public boolean getSuspendWrappedResponseAfterForward() {
/* 1427 */     return false;
/*      */   }
/*      */   
/*      */   public void setSuspendWrappedResponseAfterForward(boolean suspendWrappedResponseAfterForward) {}
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\FailedContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */