/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HostRuleSet
/*    */   implements RuleSet
/*    */ {
/*    */   protected final String prefix;
/*    */   
/*    */   public HostRuleSet() {
/* 42 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HostRuleSet(String prefix) {
/* 52 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addRuleInstances(Digester digester) {
/* 61 */     digester.addObjectCreate(this.prefix + "Host", "org.apache.catalina.core.StandardHost", "className");
/* 62 */     digester.addSetProperties(this.prefix + "Host");
/* 63 */     digester.addRule(this.prefix + "Host", new CopyParentClassLoaderRule());
/* 64 */     digester.addRule(this.prefix + "Host", new LifecycleListenerRule("org.apache.catalina.startup.HostConfig", "hostConfigClass"));
/*    */     
/* 66 */     digester.addSetNext(this.prefix + "Host", "addChild", "org.apache.catalina.Container");
/*    */     
/* 68 */     digester.addCallMethod(this.prefix + "Host/Alias", "addAlias", 0);
/*    */ 
/*    */     
/* 71 */     digester.addObjectCreate(this.prefix + "Host/Cluster", null, "className");
/*    */     
/* 73 */     digester.addSetProperties(this.prefix + "Host/Cluster");
/* 74 */     digester.addSetNext(this.prefix + "Host/Cluster", "setCluster", "org.apache.catalina.Cluster");
/*    */ 
/*    */     
/* 77 */     digester.addObjectCreate(this.prefix + "Host/Listener", null, "className");
/*    */     
/* 79 */     digester.addSetProperties(this.prefix + "Host/Listener");
/* 80 */     digester.addSetNext(this.prefix + "Host/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*    */     
/* 82 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Host/"));
/*    */     
/* 84 */     digester.addObjectCreate(this.prefix + "Host/Valve", null, "className");
/*    */     
/* 86 */     digester.addSetProperties(this.prefix + "Host/Valve");
/* 87 */     digester.addSetNext(this.prefix + "Host/Valve", "addValve", "org.apache.catalina.Valve");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\HostRuleSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */