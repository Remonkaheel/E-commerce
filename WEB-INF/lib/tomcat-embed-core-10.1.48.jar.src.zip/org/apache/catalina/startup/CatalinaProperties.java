/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalinaProperties
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(CatalinaProperties.class);
/*     */   
/*  38 */   private static Properties properties = null;
/*     */ 
/*     */   
/*     */   static {
/*  42 */     loadProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProperty(String name) {
/*  52 */     return properties.getProperty(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadProperties() {
/*  61 */     InputStream is = null;
/*  62 */     String fileName = "catalina.properties";
/*     */     
/*     */     try {
/*  65 */       String configUrl = System.getProperty("catalina.config");
/*  66 */       if (configUrl != null) {
/*  67 */         if (configUrl.indexOf('/') == -1) {
/*     */           
/*  69 */           fileName = configUrl;
/*     */         } else {
/*  71 */           is = (new URI(configUrl)).toURL().openStream();
/*     */         } 
/*     */       }
/*  74 */     } catch (Throwable t) {
/*  75 */       handleThrowable(t);
/*     */     } 
/*     */     
/*  78 */     if (is == null) {
/*     */       try {
/*  80 */         File home = new File(Bootstrap.getCatalinaBase());
/*  81 */         File conf = new File(home, "conf");
/*  82 */         File propsFile = new File(conf, fileName);
/*  83 */         is = new FileInputStream(propsFile);
/*  84 */       } catch (Throwable t) {
/*  85 */         handleThrowable(t);
/*     */       } 
/*     */     }
/*     */     
/*  89 */     if (is == null) {
/*     */       try {
/*  91 */         is = CatalinaProperties.class.getResourceAsStream("/org/apache/catalina/startup/catalina.properties");
/*  92 */       } catch (Throwable t) {
/*  93 */         handleThrowable(t);
/*     */       } 
/*     */     }
/*     */     
/*  97 */     if (is != null) {
/*     */       try {
/*  99 */         properties = new Properties();
/* 100 */         properties.load(is);
/* 101 */       } catch (Throwable t) {
/* 102 */         handleThrowable(t);
/* 103 */         log.warn(t.getMessage(), t);
/*     */       } finally {
/*     */         try {
/* 106 */           is.close();
/* 107 */         } catch (IOException ioe) {
/* 108 */           log.warn("Could not close catalina properties file", ioe);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 113 */     if (is == null) {
/*     */       
/* 115 */       log.warn("Failed to load catalina properties file");
/*     */       
/* 117 */       properties = new Properties();
/*     */     } 
/*     */ 
/*     */     
/* 121 */     Enumeration<?> enumeration = properties.propertyNames();
/* 122 */     while (enumeration.hasMoreElements()) {
/* 123 */       String name = (String)enumeration.nextElement();
/* 124 */       String value = properties.getProperty(name);
/* 125 */       if (value != null) {
/* 126 */         System.setProperty(name, value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void handleThrowable(Throwable t) {
/* 134 */     if (t instanceof ThreadDeath) {
/* 135 */       throw (ThreadDeath)t;
/*     */     }
/* 137 */     if (t instanceof VirtualMachineError)
/* 138 */       throw (VirtualMachineError)t; 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\startup\CatalinaProperties.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */