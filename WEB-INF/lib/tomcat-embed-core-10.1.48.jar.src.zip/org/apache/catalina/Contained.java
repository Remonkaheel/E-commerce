package org.apache.catalina;

public interface Contained {
  Container getContainer();
  
  void setContainer(Container paramContainer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Contained.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */