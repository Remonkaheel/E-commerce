/*     */ package org.apache.catalina;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface UserDatabase
/*     */ {
/*     */   Iterator<Group> getGroups();
/*     */   
/*     */   String getId();
/*     */   
/*     */   Iterator<Role> getRoles();
/*     */   
/*     */   Iterator<User> getUsers();
/*     */   
/*     */   void close() throws Exception;
/*     */   
/*     */   Group createGroup(String paramString1, String paramString2);
/*     */   
/*     */   Role createRole(String paramString1, String paramString2);
/*     */   
/*     */   User createUser(String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   Group findGroup(String paramString);
/*     */   
/*     */   Role findRole(String paramString);
/*     */   
/*     */   User findUser(String paramString);
/*     */   
/*     */   void open() throws Exception;
/*     */   
/*     */   void removeGroup(Group paramGroup);
/*     */   
/*     */   void removeRole(Role paramRole);
/*     */   
/*     */   void removeUser(User paramUser);
/*     */   
/*     */   default void modifiedGroup(Group group) {}
/*     */   
/*     */   default void modifiedRole(Role role) {}
/*     */   
/*     */   default void modifiedUser(User user) {}
/*     */   
/*     */   void save() throws Exception;
/*     */   
/*     */   default void backgroundProcess() {}
/*     */   
/*     */   default boolean isAvailable() {
/* 206 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isSparse() {
/* 217 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\UserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */