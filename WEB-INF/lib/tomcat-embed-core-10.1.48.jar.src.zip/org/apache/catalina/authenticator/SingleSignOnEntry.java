/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.security.Principal;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleSignOnEntry
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  46 */   private String authType = null;
/*     */   
/*  48 */   private String password = null;
/*     */ 
/*     */   
/*  51 */   private transient Principal principal = null;
/*     */   
/*  53 */   private final Map<SingleSignOnSessionKey, SingleSignOnSessionKey> sessionKeys = new ConcurrentHashMap<>();
/*     */   
/*  55 */   private String username = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canReauthenticate = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleSignOnEntry(Principal principal, String authType, String username, String password) {
/*  71 */     updateCredentials(principal, authType, username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSession(SingleSignOn sso, String ssoId, Session session) {
/*  84 */     SingleSignOnSessionKey key = new SingleSignOnSessionKey(session);
/*  85 */     SingleSignOnSessionKey currentKey = this.sessionKeys.putIfAbsent(key, key);
/*  86 */     if (currentKey == null)
/*     */     {
/*  88 */       session.addSessionListener(sso.getSessionListener(ssoId));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSession(Session session) {
/*  98 */     SingleSignOnSessionKey key = new SingleSignOnSessionKey(session);
/*  99 */     this.sessionKeys.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSession(Session session, String oldSessionId) {
/* 110 */     SingleSignOnSessionKey key = new SingleSignOnSessionKey(session, oldSessionId);
/* 111 */     this.sessionKeys.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<SingleSignOnSessionKey> findSessions() {
/* 120 */     return this.sessionKeys.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthType() {
/* 129 */     return this.authType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getCanReauthenticate() {
/* 138 */     return this.canReauthenticate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 148 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal getPrincipal() {
/* 157 */     return this.principal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 167 */     return this.username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void updateCredentials(Principal principal, String authType, String username, String password) {
/* 180 */     this.principal = principal;
/* 181 */     this.authType = authType;
/* 182 */     this.username = username;
/* 183 */     this.password = password;
/* 184 */     this
/* 185 */       .canReauthenticate = ("BASIC".equals(authType) || "FORM".equals(authType));
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 190 */     out.defaultWriteObject();
/* 191 */     if (this.principal instanceof Serializable) {
/* 192 */       out.writeBoolean(true);
/* 193 */       out.writeObject(this.principal);
/*     */     } else {
/* 195 */       out.writeBoolean(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 200 */     in.defaultReadObject();
/* 201 */     boolean hasPrincipal = in.readBoolean();
/* 202 */     if (hasPrincipal)
/* 203 */       this.principal = (Principal)in.readObject(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SingleSignOnEntry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */