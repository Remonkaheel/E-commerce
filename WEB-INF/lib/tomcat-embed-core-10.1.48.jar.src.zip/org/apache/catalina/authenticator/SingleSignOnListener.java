/*    */ package org.apache.catalina.authenticator;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.catalina.Authenticator;
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.catalina.Manager;
/*    */ import org.apache.catalina.Session;
/*    */ import org.apache.catalina.SessionEvent;
/*    */ import org.apache.catalina.SessionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleSignOnListener
/*    */   implements SessionListener, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String ssoId;
/*    */   
/*    */   public SingleSignOnListener(String ssoId) {
/* 35 */     this.ssoId = ssoId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionEvent(SessionEvent event) {
/* 41 */     String type = event.getType();
/* 42 */     if (!"destroySession".equals(type) && !"changeSessionId".equals(type)) {
/*    */       return;
/*    */     }
/*    */     
/* 46 */     Session session = event.getSession();
/* 47 */     Manager manager = session.getManager();
/* 48 */     if (manager == null) {
/*    */       return;
/*    */     }
/* 51 */     Context context = manager.getContext();
/* 52 */     Authenticator authenticator = context.getAuthenticator();
/* 53 */     if (!(authenticator instanceof AuthenticatorBase)) {
/*    */       return;
/*    */     }
/* 56 */     SingleSignOn sso = ((AuthenticatorBase)authenticator).sso;
/* 57 */     if (sso == null) {
/*    */       return;
/*    */     }
/*    */     
/* 61 */     switch (type) {
/*    */       case "changeSessionId":
/* 63 */         sso.sessionChangedId(this.ssoId, session, (String)event.getData());
/*    */         break;
/*    */       
/*    */       case "destroySession":
/* 67 */         sso.sessionDestroyed(this.ssoId, session);
/*    */         break;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SingleSignOnListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */