/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleSignOnSessionKey
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String sessionId;
/*     */   private final String contextName;
/*     */   private final String hostName;
/*     */   
/*     */   public SingleSignOnSessionKey(Session session) {
/*  38 */     this.sessionId = session.getId();
/*  39 */     Context context = session.getManager().getContext();
/*  40 */     this.contextName = context.getName();
/*  41 */     this.hostName = context.getParent().getName();
/*     */   }
/*     */   
/*     */   public SingleSignOnSessionKey(Session session, String sessionId) {
/*  45 */     this.sessionId = sessionId;
/*  46 */     Context context = session.getManager().getContext();
/*  47 */     this.contextName = context.getName();
/*  48 */     this.hostName = context.getParent().getName();
/*     */   }
/*     */   
/*     */   public String getSessionId() {
/*  52 */     return this.sessionId;
/*     */   }
/*     */   
/*     */   public String getContextName() {
/*  56 */     return this.contextName;
/*     */   }
/*     */   
/*     */   public String getHostName() {
/*  60 */     return this.hostName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  65 */     int prime = 31;
/*  66 */     int result = 1;
/*  67 */     result = 31 * result + ((this.sessionId == null) ? 0 : this.sessionId.hashCode());
/*  68 */     result = 31 * result + ((this.contextName == null) ? 0 : this.contextName.hashCode());
/*  69 */     result = 31 * result + ((this.hostName == null) ? 0 : this.hostName.hashCode());
/*  70 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  75 */     if (this == obj) {
/*  76 */       return true;
/*     */     }
/*  78 */     if (obj == null) {
/*  79 */       return false;
/*     */     }
/*  81 */     if (getClass() != obj.getClass()) {
/*  82 */       return false;
/*     */     }
/*  84 */     SingleSignOnSessionKey other = (SingleSignOnSessionKey)obj;
/*  85 */     if (this.sessionId == null) {
/*  86 */       if (other.sessionId != null) {
/*  87 */         return false;
/*     */       }
/*  89 */     } else if (!this.sessionId.equals(other.sessionId)) {
/*  90 */       return false;
/*     */     } 
/*  92 */     if (this.contextName == null) {
/*  93 */       if (other.contextName != null) {
/*  94 */         return false;
/*     */       }
/*  96 */     } else if (!this.contextName.equals(other.contextName)) {
/*  97 */       return false;
/*     */     } 
/*  99 */     if (this.hostName == null) {
/* 100 */       return (other.hostName == null);
/*     */     }
/* 102 */     return this.hostName.equals(other.hostName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return "Host: [" + this.hostName + "], Context: [" + this.contextName + "], SessionID: [" + this.sessionId + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SingleSignOnSessionKey.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */