/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.UpgradeProtocol;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  48 */   private final Log log = LogFactory.getLog(SSLAuthenticator.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doAuthenticate(Request request, HttpServletResponse response) throws IOException {
/*  70 */     if (checkForCachedAuthentication(request, response, false)) {
/*  71 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  75 */     if (this.containerLog.isTraceEnabled()) {
/*  76 */       this.containerLog.trace(" Looking up certificates");
/*     */     }
/*     */     
/*  79 */     X509Certificate[] certs = getRequestCertificates(request);
/*     */     
/*  81 */     if (certs == null || certs.length < 1) {
/*  82 */       if (this.containerLog.isDebugEnabled()) {
/*  83 */         this.containerLog.debug(sm.getString("sslAuthenticatorValve.noCertificates"));
/*     */       }
/*  85 */       response.sendError(401, sm.getString("authenticator.certificates"));
/*  86 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  90 */     Principal principal = this.context.getRealm().authenticate(certs);
/*  91 */     if (principal == null) {
/*  92 */       if (this.containerLog.isDebugEnabled()) {
/*  93 */         this.containerLog.debug(sm.getString("sslAuthenticatorValve.authFailed"));
/*     */       }
/*  95 */       response.sendError(401, sm.getString("authenticator.unauthorized"));
/*  96 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 100 */     register(request, response, principal, "CLIENT_CERT", (String)null, (String)null);
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAuthMethod() {
/* 108 */     return "CLIENT_CERT";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPreemptiveAuthPossible(Request request) {
/* 114 */     X509Certificate[] certs = getRequestCertificates(request);
/* 115 */     return (certs != null && certs.length > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected X509Certificate[] getRequestCertificates(Request request) throws IllegalStateException {
/* 130 */     X509Certificate[] certs = (X509Certificate[])request.getAttribute("jakarta.servlet.request.X509Certificate");
/*     */     
/* 132 */     if (certs == null || certs.length < 1) {
/*     */       try {
/* 134 */         request.getCoyoteRequest().action(ActionCode.REQ_SSL_CERTIFICATE, null);
/* 135 */         certs = (X509Certificate[])request.getAttribute("jakarta.servlet.request.X509Certificate");
/* 136 */       } catch (IllegalStateException illegalStateException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     return certs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 149 */     super.startInternal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     Container container = getContainer();
/* 156 */     if (!(container instanceof Context)) {
/*     */       return;
/*     */     }
/* 159 */     Context context = (Context)container;
/*     */     
/* 161 */     container = context.getParent();
/* 162 */     if (!(container instanceof Host)) {
/*     */       return;
/*     */     }
/* 165 */     Host host = (Host)container;
/*     */     
/* 167 */     container = host.getParent();
/* 168 */     if (!(container instanceof Engine)) {
/*     */       return;
/*     */     }
/* 171 */     Engine engine = (Engine)container;
/*     */ 
/*     */     
/* 174 */     Connector[] connectors = engine.getService().findConnectors();
/*     */     
/* 176 */     for (Connector connector : connectors) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       boolean allHostsRequireCertificate = true;
/* 191 */       for (SSLHostConfig sslHostConfig : connector.findSslHostConfigs()) {
/* 192 */         if (sslHostConfig.getCertificateVerification() != SSLHostConfig.CertificateVerification.REQUIRED) {
/* 193 */           allHostsRequireCertificate = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 199 */       if (!allHostsRequireCertificate) {
/*     */         
/* 201 */         UpgradeProtocol[] upgradeProtocols = connector.findUpgradeProtocols();
/* 202 */         for (UpgradeProtocol upgradeProtocol : upgradeProtocols) {
/* 203 */           if ("h2".equals(upgradeProtocol.getAlpnName())) {
/* 204 */             this.log.warn(sm.getString("sslAuthenticatorValve.http2", new Object[] { context.getName(), host.getName(), connector }));
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 211 */         for (SSLHostConfig sslHostConfig : connector.findSslHostConfigs()) {
/* 212 */           if (!sslHostConfig.isTls13RenegotiationAvailable()) {
/* 213 */             String[] enabledProtocols = sslHostConfig.getEnabledProtocols();
/* 214 */             if (enabledProtocols == null)
/*     */             {
/* 216 */               enabledProtocols = (String[])sslHostConfig.getProtocols().toArray((Object[])new String[0]);
/*     */             }
/* 218 */             for (String enabledProtocol : enabledProtocols) {
/* 219 */               if ("TLSv1.3".equals(enabledProtocol))
/* 220 */                 this.log.warn(sm.getString("sslAuthenticatorValve.tls13", new Object[] { context.getName(), host.getName(), connector })); 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SSLAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */