/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Base64;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.concurrent.CompletionException;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.compat.JreVendor;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.GSSName;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpnegoAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  54 */   private final Log log = LogFactory.getLog(SpnegoAuthenticator.class);
/*     */   
/*     */   private static final String AUTH_HEADER_VALUE_NEGOTIATE = "Negotiate";
/*  57 */   private String loginConfigName = "com.sun.security.jgss.krb5.accept";
/*     */   
/*     */   public String getLoginConfigName() {
/*  60 */     return this.loginConfigName;
/*     */   }
/*     */   
/*     */   public void setLoginConfigName(String loginConfigName) {
/*  64 */     this.loginConfigName = loginConfigName;
/*     */   }
/*     */   
/*     */   private boolean storeDelegatedCredential = true;
/*     */   
/*     */   public boolean isStoreDelegatedCredential() {
/*  70 */     return this.storeDelegatedCredential;
/*     */   }
/*     */   
/*     */   public void setStoreDelegatedCredential(boolean storeDelegatedCredential) {
/*  74 */     this.storeDelegatedCredential = storeDelegatedCredential;
/*     */   }
/*     */   
/*  77 */   private Pattern noKeepAliveUserAgents = null;
/*     */   
/*     */   public String getNoKeepAliveUserAgents() {
/*  80 */     Pattern p = this.noKeepAliveUserAgents;
/*  81 */     if (p == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     return p.pattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNoKeepAliveUserAgents(String noKeepAliveUserAgents) {
/*  89 */     if (noKeepAliveUserAgents == null || noKeepAliveUserAgents.isEmpty()) {
/*  90 */       this.noKeepAliveUserAgents = null;
/*     */     } else {
/*  92 */       this.noKeepAliveUserAgents = Pattern.compile(noKeepAliveUserAgents);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean applyJava8u40Fix = true;
/*     */   
/*     */   public boolean getApplyJava8u40Fix() {
/*  99 */     return this.applyJava8u40Fix;
/*     */   }
/*     */   
/*     */   public void setApplyJava8u40Fix(boolean applyJava8u40Fix) {
/* 103 */     this.applyJava8u40Fix = applyJava8u40Fix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAuthMethod() {
/* 109 */     return "SPNEGO";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 115 */     super.initInternal();
/*     */ 
/*     */     
/* 118 */     String krb5Conf = System.getProperty("java.security.krb5.conf");
/* 119 */     if (krb5Conf == null) {
/*     */       
/* 121 */       File krb5ConfFile = new File(this.container.getCatalinaBase(), "conf/krb5.ini");
/* 122 */       System.setProperty("java.security.krb5.conf", krb5ConfFile.getAbsolutePath());
/*     */     } 
/*     */ 
/*     */     
/* 126 */     String jaasConf = System.getProperty("java.security.auth.login.config");
/* 127 */     if (jaasConf == null) {
/*     */       
/* 129 */       File jaasConfFile = new File(this.container.getCatalinaBase(), "conf/jaas.conf");
/* 130 */       System.setProperty("java.security.auth.login.config", jaasConfFile.getAbsolutePath());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doAuthenticate(Request request, HttpServletResponse response) throws IOException {
/*     */     byte[] outToken;
/*     */     Principal principal;
/* 138 */     if (checkForCachedAuthentication(request, response, true)) {
/* 139 */       return true;
/*     */     }
/*     */     
/* 142 */     MessageBytes authorization = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/*     */     
/* 144 */     if (authorization == null) {
/* 145 */       if (this.log.isDebugEnabled()) {
/* 146 */         this.log.debug(sm.getString("authenticator.noAuthHeader"));
/*     */       }
/* 148 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 149 */       response.sendError(401);
/* 150 */       return false;
/*     */     } 
/*     */     
/* 153 */     authorization.toBytes();
/* 154 */     ByteChunk authorizationBC = authorization.getByteChunk();
/*     */     
/* 156 */     if (!authorizationBC.startsWithIgnoreCase("negotiate ", 0)) {
/* 157 */       if (this.log.isDebugEnabled()) {
/* 158 */         this.log.debug(sm.getString("spnegoAuthenticator.authHeaderNotNego"));
/*     */       }
/* 160 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 161 */       response.sendError(401);
/* 162 */       return false;
/*     */     } 
/*     */     
/* 165 */     authorizationBC.setStart(authorizationBC.getStart() + 10);
/*     */     
/* 167 */     byte[] encoded = new byte[authorizationBC.getLength()];
/* 168 */     System.arraycopy(authorizationBC.getBuffer(), authorizationBC.getStart(), encoded, 0, authorizationBC
/* 169 */         .getLength());
/* 170 */     byte[] decoded = Base64.getDecoder().decode(encoded);
/*     */     
/* 172 */     if (getApplyJava8u40Fix()) {
/* 173 */       SpnegoTokenFixer.fix(decoded);
/*     */     }
/*     */     
/* 176 */     if (decoded.length == 0) {
/* 177 */       if (this.log.isDebugEnabled()) {
/* 178 */         this.log.debug(sm.getString("spnegoAuthenticator.authHeaderNoToken"));
/*     */       }
/* 180 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 181 */       response.sendError(401);
/* 182 */       return false;
/*     */     } 
/*     */     
/* 185 */     LoginContext lc = null;
/* 186 */     GSSContext gssContext = null;
/*     */     
/*     */     try {
/*     */       int credentialLifetime;
/*     */       try {
/* 191 */         lc = new LoginContext(getLoginConfigName());
/* 192 */         lc.login();
/* 193 */       } catch (LoginException e) {
/* 194 */         this.log.error(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/* 195 */         response.sendError(500);
/* 196 */         return false;
/*     */       } 
/*     */       
/* 199 */       Subject subject = lc.getSubject();
/*     */ 
/*     */ 
/*     */       
/* 203 */       GSSManager manager = GSSManager.getInstance();
/*     */ 
/*     */       
/* 206 */       if (JreVendor.IS_IBM_JVM) {
/* 207 */         credentialLifetime = Integer.MAX_VALUE;
/*     */       } else {
/* 209 */         credentialLifetime = 0;
/*     */       } 
/* 211 */       gssContext = manager.createContext((GSSCredential)JreCompat.getInstance().callAs(subject, () -> manager.createCredential((GSSName)null, credentialLifetime, new Oid("1.3.6.1.5.5.2"), 2)));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       GSSContext gssContextFinal = gssContext;
/* 217 */       outToken = (byte[])JreCompat.getInstance().callAs(subject, () -> gssContextFinal.acceptSecContext(decoded, 0, decoded.length));
/*     */ 
/*     */ 
/*     */       
/* 221 */       if (outToken == null) {
/* 222 */         if (this.log.isDebugEnabled()) {
/* 223 */           this.log.debug(sm.getString("spnegoAuthenticator.ticketValidateFail"));
/*     */         }
/*     */         
/* 226 */         response.setHeader("WWW-Authenticate", "Negotiate");
/* 227 */         response.sendError(401);
/* 228 */         return false;
/*     */       } 
/*     */       
/* 231 */       principal = (Principal)JreCompat.getInstance().callAs(subject, () -> this.context.getRealm().authenticate(gssContextFinal, this.storeDelegatedCredential));
/*     */     
/*     */     }
/* 234 */     catch (GSSException e) {
/* 235 */       if (this.log.isDebugEnabled()) {
/* 236 */         this.log.debug(sm.getString("spnegoAuthenticator.ticketValidateFail"), e);
/*     */       }
/* 238 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 239 */       response.sendError(401);
/* 240 */       return false;
/* 241 */     } catch (CompletionException e) {
/* 242 */       Throwable cause = e.getCause();
/* 243 */       if (cause instanceof GSSException) {
/* 244 */         if (this.log.isDebugEnabled()) {
/* 245 */           this.log.debug(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/*     */         }
/*     */       } else {
/* 248 */         this.log.error(sm.getString("spnegoAuthenticator.serviceLoginFail"), e);
/*     */       } 
/* 250 */       response.setHeader("WWW-Authenticate", "Negotiate");
/* 251 */       response.sendError(401);
/* 252 */       return false;
/*     */     } finally {
/* 254 */       if (gssContext != null) {
/*     */         try {
/* 256 */           gssContext.dispose();
/* 257 */         } catch (GSSException gSSException) {}
/*     */       }
/*     */ 
/*     */       
/* 261 */       if (lc != null) {
/*     */         try {
/* 263 */           lc.logout();
/* 264 */         } catch (LoginException loginException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     response.setHeader("WWW-Authenticate", "Negotiate " + 
/* 272 */         Base64.getEncoder().encodeToString(outToken));
/*     */     
/* 274 */     if (principal != null) {
/* 275 */       register(request, response, principal, "SPNEGO", principal.getName(), (String)null);
/*     */       
/* 277 */       Pattern p = this.noKeepAliveUserAgents;
/* 278 */       if (p != null) {
/* 279 */         MessageBytes ua = request.getCoyoteRequest().getMimeHeaders().getValue("user-agent");
/* 280 */         if (ua != null && p.matcher(ua.toString()).matches()) {
/* 281 */           response.setHeader("Connection", "close");
/*     */         }
/*     */       } 
/* 284 */       return true;
/*     */     } 
/*     */     
/* 287 */     response.sendError(401);
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPreemptiveAuthPossible(Request request) {
/* 294 */     MessageBytes authorizationHeader = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/* 295 */     return (authorizationHeader != null && authorizationHeader.startsWithIgnoreCase("negotiate ", 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SpnegoTokenFixer
/*     */   {
/*     */     private final byte[] token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static void fix(byte[] token) {
/* 312 */       SpnegoTokenFixer fixer = new SpnegoTokenFixer(token);
/* 313 */       fixer.fix();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 318 */     private int pos = 0;
/*     */ 
/*     */     
/*     */     private SpnegoTokenFixer(byte[] token) {
/* 322 */       this.token = token;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void fix() {
/* 335 */       if (!tag(96)) {
/*     */         return;
/*     */       }
/* 338 */       if (!length()) {
/*     */         return;
/*     */       }
/* 341 */       if (!oid("1.3.6.1.5.5.2")) {
/*     */         return;
/*     */       }
/* 344 */       if (!tag(160)) {
/*     */         return;
/*     */       }
/* 347 */       if (!length()) {
/*     */         return;
/*     */       }
/* 350 */       if (!tag(48)) {
/*     */         return;
/*     */       }
/* 353 */       if (!length()) {
/*     */         return;
/*     */       }
/* 356 */       if (!tag(160)) {
/*     */         return;
/*     */       }
/* 359 */       lengthAsInt();
/* 360 */       if (!tag(48)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 365 */       int mechTypesLen = lengthAsInt();
/* 366 */       int mechTypesStart = this.pos;
/* 367 */       LinkedHashMap<String, int[]> mechTypeEntries = (LinkedHashMap)new LinkedHashMap<>();
/* 368 */       while (this.pos < mechTypesStart + mechTypesLen) {
/* 369 */         int[] value = new int[2];
/* 370 */         value[0] = this.pos;
/* 371 */         String key = oidAsString();
/* 372 */         value[1] = this.pos - value[0];
/* 373 */         mechTypeEntries.put(key, value);
/*     */       } 
/*     */       
/* 376 */       byte[] replacement = new byte[mechTypesLen];
/* 377 */       int replacementPos = 0;
/*     */       
/* 379 */       int[] first = mechTypeEntries.remove("1.2.840.113554.1.2.2");
/* 380 */       if (first != null) {
/* 381 */         System.arraycopy(this.token, first[0], replacement, replacementPos, first[1]);
/* 382 */         replacementPos += first[1];
/*     */       } 
/* 384 */       for (int[] markers : mechTypeEntries.values()) {
/* 385 */         System.arraycopy(this.token, markers[0], replacement, replacementPos, markers[1]);
/* 386 */         replacementPos += markers[1];
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 391 */       System.arraycopy(replacement, 0, this.token, mechTypesStart, mechTypesLen);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean tag(int expected) {
/* 396 */       return ((this.token[this.pos++] & 0xFF) == expected);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean length() {
/* 403 */       int len = lengthAsInt();
/* 404 */       return (this.pos + len == this.token.length);
/*     */     }
/*     */ 
/*     */     
/*     */     private int lengthAsInt() {
/* 409 */       int len = this.token[this.pos++] & 0xFF;
/* 410 */       if (len > 127) {
/* 411 */         int bytes = len - 128;
/* 412 */         len = 0;
/* 413 */         for (int i = 0; i < bytes; i++) {
/* 414 */           len <<= 8;
/* 415 */           len += this.token[this.pos++] & 0xFF;
/*     */         } 
/*     */       } 
/* 418 */       return len;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean oid(String expected) {
/* 423 */       return expected.equals(oidAsString());
/*     */     }
/*     */ 
/*     */     
/*     */     private String oidAsString() {
/* 428 */       if (!tag(6)) {
/* 429 */         return null;
/*     */       }
/* 431 */       StringBuilder result = new StringBuilder();
/* 432 */       int len = lengthAsInt();
/*     */       
/* 434 */       int v = this.token[this.pos++] & 0xFF;
/* 435 */       int c2 = v % 40;
/* 436 */       int c1 = (v - c2) / 40;
/* 437 */       result.append(c1);
/* 438 */       result.append('.');
/* 439 */       result.append(c2);
/* 440 */       int c = 0;
/* 441 */       boolean write = false;
/* 442 */       for (int i = 1; i < len; i++) {
/* 443 */         int b = this.token[this.pos++] & 0xFF;
/* 444 */         if (b > 127) {
/* 445 */           b -= 128;
/*     */         } else {
/* 447 */           write = true;
/*     */         } 
/* 449 */         c <<= 7;
/* 450 */         c += b;
/* 451 */         if (write) {
/* 452 */           result.append('.');
/* 453 */           result.append(c);
/* 454 */           c = 0;
/* 455 */           write = false;
/*     */         } 
/*     */       } 
/* 458 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SpnegoAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */