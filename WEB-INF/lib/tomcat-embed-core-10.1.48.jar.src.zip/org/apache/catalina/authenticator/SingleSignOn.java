/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.SessionListener;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleSignOn
/*     */   extends ValveBase
/*     */ {
/*  57 */   private static final StringManager sm = StringManager.getManager(SingleSignOn.class);
/*     */   
/*     */   private Engine engine;
/*     */   
/*     */   protected Map<String, SingleSignOnEntry> cache;
/*     */   
/*     */   private boolean requireReauthentication;
/*     */   private String cookieDomain;
/*     */   private String cookieName;
/*     */   
/*     */   public SingleSignOn() {
/*  68 */     super(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.cache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.requireReauthentication = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this.cookieName = "JSESSIONIDSSO";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookieDomain() {
/* 104 */     return this.cookieDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieDomain(String cookieDomain) {
/* 114 */     if (cookieDomain != null && cookieDomain.trim().isEmpty()) {
/* 115 */       this.cookieDomain = null;
/*     */     } else {
/* 117 */       this.cookieDomain = cookieDomain;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookieName() {
/* 126 */     return this.cookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 136 */     this.cookieName = cookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRequireReauthentication() {
/* 154 */     return this.requireReauthentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequireReauthentication(boolean required) {
/* 189 */     this.requireReauthentication = required;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 207 */     request.removeNote("org.apache.catalina.request.SSOID");
/*     */ 
/*     */     
/* 210 */     if (this.containerLog.isTraceEnabled()) {
/* 211 */       this.containerLog.trace(sm.getString("singleSignOn.debug.invoke", new Object[] { request.getRequestURI() }));
/*     */     }
/* 213 */     if (request.getUserPrincipal() != null) {
/* 214 */       if (this.containerLog.isDebugEnabled()) {
/* 215 */         this.containerLog
/* 216 */           .debug(sm.getString("singleSignOn.debug.hasPrincipal", new Object[] { request.getUserPrincipal().getName() }));
/*     */       }
/* 218 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 223 */     if (this.containerLog.isTraceEnabled()) {
/* 224 */       this.containerLog.trace(sm.getString("singleSignOn.debug.cookieCheck"));
/*     */     }
/* 226 */     Cookie cookie = null;
/* 227 */     Cookie[] cookies = request.getCookies();
/* 228 */     if (cookies != null) {
/* 229 */       for (Cookie value : cookies) {
/* 230 */         if (this.cookieName.equals(value.getName())) {
/* 231 */           cookie = value;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 236 */     if (cookie == null) {
/* 237 */       if (this.containerLog.isDebugEnabled()) {
/* 238 */         this.containerLog.debug(sm.getString("singleSignOn.debug.cookieNotFound"));
/*     */       }
/* 240 */       getNext().invoke(request, response);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 245 */     if (this.containerLog.isTraceEnabled()) {
/* 246 */       this.containerLog.trace(sm.getString("singleSignOn.debug.principalCheck", new Object[] { cookie.getValue() }));
/*     */     }
/* 248 */     SingleSignOnEntry entry = this.cache.get(cookie.getValue());
/* 249 */     if (entry != null) {
/* 250 */       if (this.containerLog.isDebugEnabled())
/* 251 */         this.containerLog.debug(sm.getString("singleSignOn.debug.principalFound", new Object[] {
/* 252 */                 (entry.getPrincipal() != null) ? entry.getPrincipal().getName() : "", entry.getAuthType()
/*     */               })); 
/* 254 */       request.setNote("org.apache.catalina.request.SSOID", cookie.getValue());
/*     */       
/* 256 */       if (!getRequireReauthentication()) {
/* 257 */         request.setAuthType(entry.getAuthType());
/* 258 */         request.setUserPrincipal(entry.getPrincipal());
/*     */       } 
/*     */     } else {
/* 261 */       if (this.containerLog.isDebugEnabled()) {
/* 262 */         this.containerLog.debug(sm.getString("singleSignOn.debug.principalNotFound", new Object[] { cookie.getValue() }));
/*     */       }
/*     */       
/* 265 */       cookie.setValue("REMOVE");
/*     */       
/* 267 */       cookie.setMaxAge(0);
/*     */ 
/*     */       
/* 270 */       cookie.setPath("/");
/* 271 */       String domain = getCookieDomain();
/* 272 */       if (domain != null) {
/* 273 */         cookie.setDomain(domain);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 279 */       cookie.setSecure(request.isSecure());
/* 280 */       if (request.getServletContext().getSessionCookieConfig().isHttpOnly() || request
/* 281 */         .getContext().getUseHttpOnly()) {
/* 282 */         cookie.setHttpOnly(true);
/*     */       }
/* 284 */       cookie.setAttribute("Partitioned", 
/* 285 */           Boolean.toString(request.getContext().getUsePartitioned()));
/*     */       
/* 287 */       response.addCookie(cookie);
/*     */     } 
/*     */ 
/*     */     
/* 291 */     getNext().invoke(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sessionDestroyed(String ssoId, Session session) {
/* 306 */     if (!getState().isAvailable()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     if ((session.getMaxInactiveInterval() > 0 && session
/* 315 */       .getIdleTimeInternal() >= session.getMaxInactiveInterval() * 1000L) || 
/* 316 */       !session.getManager().getContext().getState().isAvailable()) {
/* 317 */       if (this.containerLog.isDebugEnabled()) {
/* 318 */         this.containerLog.debug(sm.getString("singleSignOn.debug.sessionTimeout", new Object[] { ssoId, session }));
/*     */       }
/* 320 */       removeSession(ssoId, session);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 325 */       if (this.containerLog.isDebugEnabled()) {
/* 326 */         this.containerLog.debug(sm.getString("singleSignOn.debug.sessionLogout", new Object[] { ssoId, session }));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 332 */       removeSession(ssoId, session);
/*     */ 
/*     */       
/* 335 */       if (this.cache.containsKey(ssoId)) {
/* 336 */         deregister(ssoId);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean associate(String ssoId, Session session) {
/* 351 */     SingleSignOnEntry sso = this.cache.get(ssoId);
/* 352 */     if (sso == null) {
/* 353 */       if (this.containerLog.isDebugEnabled()) {
/* 354 */         this.containerLog.debug(sm.getString("singleSignOn.debug.associateFail", new Object[] { ssoId, session }));
/*     */       }
/* 356 */       return false;
/*     */     } 
/* 358 */     if (this.containerLog.isDebugEnabled()) {
/* 359 */       this.containerLog.debug(sm.getString("singleSignOn.debug.associate", new Object[] { ssoId, session }));
/*     */     }
/* 361 */     sso.addSession(this, ssoId, session);
/* 362 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deregister(String ssoId) {
/* 375 */     SingleSignOnEntry sso = this.cache.remove(ssoId);
/*     */     
/* 377 */     if (sso == null) {
/* 378 */       if (this.containerLog.isDebugEnabled()) {
/* 379 */         this.containerLog.debug(sm.getString("singleSignOn.debug.deregisterFail", new Object[] { ssoId }));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 385 */     Set<SingleSignOnSessionKey> ssoKeys = sso.findSessions();
/* 386 */     if (ssoKeys.isEmpty() && 
/* 387 */       this.containerLog.isDebugEnabled()) {
/* 388 */       this.containerLog.debug(sm.getString("singleSignOn.debug.deregisterNone", new Object[] { ssoId }));
/*     */     }
/*     */     
/* 391 */     for (SingleSignOnSessionKey ssoKey : ssoKeys) {
/* 392 */       if (this.containerLog.isDebugEnabled()) {
/* 393 */         this.containerLog.debug(sm.getString("singleSignOn.debug.deregister", new Object[] { ssoKey, ssoId }));
/*     */       }
/*     */       
/* 396 */       expire(ssoKey);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void expire(SingleSignOnSessionKey key) {
/*     */     Session session;
/* 406 */     if (this.engine == null) {
/* 407 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.engineNull", new Object[] { key }));
/*     */       return;
/*     */     } 
/* 410 */     Container host = this.engine.findChild(key.getHostName());
/* 411 */     if (host == null) {
/* 412 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.hostNotFound", new Object[] { key }));
/*     */       return;
/*     */     } 
/* 415 */     Context context = (Context)host.findChild(key.getContextName());
/* 416 */     if (context == null) {
/* 417 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.contextNotFound", new Object[] { key }));
/*     */       return;
/*     */     } 
/* 420 */     Manager manager = context.getManager();
/* 421 */     if (manager == null) {
/* 422 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.managerNotFound", new Object[] { key }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 427 */       session = manager.findSession(key.getSessionId());
/* 428 */     } catch (IOException ioe) {
/* 429 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.managerError", new Object[] { key }), ioe);
/*     */       return;
/*     */     } 
/* 432 */     if (session == null) {
/* 433 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.sessionNotFound", new Object[] { key }));
/*     */       return;
/*     */     } 
/* 436 */     session.expire();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean reauthenticate(String ssoId, Realm realm, Request request) {
/* 457 */     if (ssoId == null || realm == null) {
/* 458 */       return false;
/*     */     }
/*     */     
/* 461 */     boolean reauthenticated = false;
/*     */     
/* 463 */     SingleSignOnEntry entry = this.cache.get(ssoId);
/* 464 */     if (entry != null && entry.getCanReauthenticate()) {
/*     */       
/* 466 */       String username = entry.getUsername();
/* 467 */       if (username != null) {
/* 468 */         Principal reauthPrincipal = realm.authenticate(username, entry.getPassword());
/* 469 */         if (reauthPrincipal != null) {
/* 470 */           reauthenticated = true;
/*     */           
/* 472 */           request.setAuthType(entry.getAuthType());
/* 473 */           request.setUserPrincipal(reauthPrincipal);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 478 */     return reauthenticated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void register(String ssoId, Principal principal, String authType, String username, String password) {
/* 493 */     if (this.containerLog.isDebugEnabled()) {
/* 494 */       this.containerLog.debug(sm.getString("singleSignOn.debug.register", new Object[] { ssoId, 
/* 495 */               (principal != null) ? principal.getName() : "", authType }));
/*     */     }
/*     */     
/* 498 */     this.cache.put(ssoId, new SingleSignOnEntry(principal, authType, username, password));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean update(String ssoId, Principal principal, String authType, String username, String password) {
/* 524 */     SingleSignOnEntry sso = this.cache.get(ssoId);
/* 525 */     if (sso != null && !sso.getCanReauthenticate()) {
/* 526 */       if (this.containerLog.isDebugEnabled()) {
/* 527 */         this.containerLog.debug(sm.getString("singleSignOn.debug.update", new Object[] { ssoId, authType }));
/*     */       }
/*     */       
/* 530 */       sso.updateCredentials(principal, authType, username, password);
/* 531 */       return true;
/*     */     } 
/* 533 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSession(String ssoId, Session session) {
/* 545 */     if (this.containerLog.isDebugEnabled()) {
/* 546 */       this.containerLog.debug(sm.getString("singleSignOn.debug.removeSession", new Object[] { session, ssoId }));
/*     */     }
/*     */ 
/*     */     
/* 550 */     SingleSignOnEntry entry = this.cache.get(ssoId);
/* 551 */     if (entry == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 556 */     entry.removeSession(session);
/*     */ 
/*     */ 
/*     */     
/* 560 */     if (entry.findSessions().isEmpty()) {
/* 561 */       deregister(ssoId);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected SessionListener getSessionListener(String ssoId) {
/* 567 */     return new SingleSignOnListener(ssoId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 573 */     Container container = getContainer();
/* 574 */     while (container != null && !(container instanceof Engine)) {
/* 575 */       container = container.getParent();
/*     */     }
/* 577 */     if (container != null) {
/* 578 */       this.engine = (Engine)container;
/*     */     }
/*     */ 
/*     */     
/* 582 */     container = getContainer();
/* 583 */     Realm containerRealm = container.getRealm();
/* 584 */     if (containerRealm == null) {
/* 585 */       this.containerLog.warn(sm.getString("singleSignOn.noRealm", new Object[] { container.getName() }));
/*     */     }
/* 587 */     else if (container instanceof Engine) {
/* 588 */       for (Container host : this.engine.findChildren()) {
/* 589 */         if (host.getRealm() != containerRealm) {
/* 590 */           this.containerLog.warn(sm.getString("singleSignOn.duplicateRealm", new Object[] { host.getName() }));
/*     */         } else {
/* 592 */           for (Container context : host.findChildren()) {
/* 593 */             if (context.getRealm() != containerRealm) {
/* 594 */               this.containerLog.warn(sm.getString("singleSignOn.duplicateRealm", new Object[] { context.getName() }));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 599 */     } else if (container instanceof org.apache.catalina.Host) {
/* 600 */       for (Container context : container.findChildren()) {
/* 601 */         if (context.getRealm() != containerRealm) {
/* 602 */           this.containerLog.warn(sm.getString("singleSignOn.duplicateRealm", new Object[] { context.getName() }));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 607 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 613 */     super.stopInternal();
/* 614 */     this.engine = null;
/*     */   }
/*     */   
/*     */   protected void sessionChangedId(String ssoId, Session session, String oldSessionId) {
/* 618 */     if (this.containerLog.isDebugEnabled()) {
/* 619 */       this.containerLog.debug(sm.getString("singleSignOn.debug.sessionChangedId", new Object[] { session, oldSessionId, ssoId }));
/*     */     }
/*     */     
/* 622 */     SingleSignOnEntry entry = this.cache.get(ssoId);
/* 623 */     if (entry == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 631 */     entry.addSession(this, ssoId, session);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 637 */     entry.removeSession(session, oldSessionId);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SingleSignOn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */