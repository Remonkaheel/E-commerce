/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.ContinueResponseTiming;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  54 */   private final Log log = LogFactory.getLog(FormAuthenticator.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected String characterEncoding = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected String landingPage = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   protected int authenticationSessionTimeout = 120;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/*  87 */     return this.characterEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharacterEncoding(String encoding) {
/*  97 */     this.characterEncoding = encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLandingPage() {
/* 107 */     return this.landingPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLandingPage(String landingPage) {
/* 117 */     this.landingPage = landingPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAuthenticationSessionTimeout() {
/* 129 */     return this.authenticationSessionTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationSessionTimeout(int authenticationSessionTimeout) {
/* 141 */     this.authenticationSessionTimeout = authenticationSessionTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doAuthenticate(Request request, HttpServletResponse response) throws IOException {
/* 161 */     Session session = null;
/*     */ 
/*     */ 
/*     */     
/* 165 */     if (!this.cache) {
/* 166 */       session = request.getSessionInternal(true);
/* 167 */       if (this.log.isTraceEnabled()) {
/* 168 */         this.log.trace("Checking for reauthenticate in session " + String.valueOf(session));
/*     */       }
/* 170 */       String str1 = (String)session.getNote("org.apache.catalina.session.USERNAME");
/* 171 */       String str2 = (String)session.getNote("org.apache.catalina.session.PASSWORD");
/* 172 */       if (str1 != null && str2 != null) {
/* 173 */         if (this.log.isTraceEnabled()) {
/* 174 */           this.log.trace("Reauthenticating username '" + str1 + "'");
/*     */         }
/* 176 */         Principal principal1 = this.context.getRealm().authenticate(str1, str2);
/* 177 */         if (principal1 != null) {
/* 178 */           register(request, response, principal1, "FORM", str1, str2);
/* 179 */           if (!matchRequest(request)) {
/* 180 */             return true;
/*     */           }
/*     */         } 
/* 183 */         if (this.log.isDebugEnabled()) {
/* 184 */           this.log.debug(sm.getString("formAuthenticator.reauthFailed"));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 191 */     if (matchRequest(request)) {
/* 192 */       session = request.getSessionInternal(true);
/* 193 */       if (this.log.isTraceEnabled()) {
/* 194 */         this.log.trace("Restore request from session '" + session.getIdInternal() + "'");
/*     */       }
/* 196 */       if (restoreRequest(request, session)) {
/* 197 */         if (this.log.isTraceEnabled()) {
/* 198 */           this.log.trace("Proceed to restored request");
/*     */         }
/* 200 */         return true;
/*     */       } 
/* 202 */       if (this.log.isDebugEnabled()) {
/* 203 */         this.log.debug(sm.getString("formAuthenticator.restoreFailed"));
/*     */       }
/* 205 */       response.sendError(400);
/* 206 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (checkForCachedAuthentication(request, response, true)) {
/* 213 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 217 */     String contextPath = request.getContextPath();
/* 218 */     String requestURI = request.getDecodedRequestURI();
/*     */ 
/*     */     
/* 221 */     boolean loginAction = (requestURI.startsWith(contextPath) && requestURI.endsWith("/j_security_check"));
/*     */     
/* 223 */     LoginConfig config = this.context.getLoginConfig();
/*     */ 
/*     */     
/* 226 */     if (!loginAction) {
/*     */ 
/*     */ 
/*     */       
/* 230 */       if (request.getServletPath().isEmpty() && request.getPathInfo() == null) {
/* 231 */         StringBuilder location = new StringBuilder(requestURI);
/* 232 */         location.append('/');
/* 233 */         if (request.getQueryString() != null) {
/* 234 */           location.append('?');
/* 235 */           location.append(request.getQueryString());
/*     */         } 
/* 237 */         response.sendRedirect(response.encodeRedirectURL(location.toString()));
/* 238 */         return false;
/*     */       } 
/*     */       
/* 241 */       session = request.getSessionInternal(true);
/* 242 */       if (this.log.isTraceEnabled()) {
/* 243 */         this.log.trace("Save request in session '" + session.getIdInternal() + "'");
/*     */       }
/*     */       try {
/* 246 */         saveRequest(request, session);
/* 247 */       } catch (IOException ioe) {
/* 248 */         this.log.debug(sm.getString("authenticator.requestBodyTooBig"), ioe);
/* 249 */         response.sendError(403, sm.getString("authenticator.requestBodyTooBig"));
/* 250 */         return false;
/*     */       } 
/* 252 */       forwardToLoginPage(request, response, config);
/* 253 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 258 */     request.getResponse().sendAcknowledgement(ContinueResponseTiming.ALWAYS);
/* 259 */     Realm realm = this.context.getRealm();
/* 260 */     if (this.characterEncoding != null) {
/* 261 */       request.setCharacterEncoding(this.characterEncoding);
/*     */     }
/* 263 */     String username = request.getParameter("j_username");
/* 264 */     String password = request.getParameter("j_password");
/* 265 */     if (this.log.isTraceEnabled()) {
/* 266 */       this.log.trace("Authenticating username '" + username + "'");
/*     */     }
/* 268 */     Principal principal = realm.authenticate(username, password);
/* 269 */     if (principal == null) {
/* 270 */       forwardToErrorPage(request, response, config);
/* 271 */       return false;
/*     */     } 
/*     */     
/* 274 */     if (this.log.isTraceEnabled()) {
/* 275 */       this.log.trace("Authentication of '" + username + "' was successful");
/*     */     }
/*     */     
/* 278 */     if (session == null) {
/* 279 */       session = request.getSessionInternal(false);
/*     */     }
/* 281 */     if (session != null && getChangeSessionIdOnAuthentication()) {
/*     */       
/* 283 */       String expectedSessionId = (String)session.getNote("org.apache.catalina.authenticator.SESSION_ID");
/* 284 */       if (expectedSessionId == null || !expectedSessionId.equals(request.getRequestedSessionId())) {
/* 285 */         if (this.log.isDebugEnabled()) {
/* 286 */           this.log.debug(sm.getString("formAuthenticator.sessionIdMismatch", new Object[] { session.getId(), expectedSessionId }));
/*     */         }
/* 288 */         session.expire();
/* 289 */         session = null;
/*     */       } 
/*     */     } 
/* 292 */     if (session == null) {
/* 293 */       if (this.containerLog.isDebugEnabled()) {
/* 294 */         this.containerLog.debug(sm.getString("formAuthenticator.sessionExpired"));
/*     */       }
/* 296 */       if (this.landingPage == null) {
/* 297 */         response.sendError(408, sm
/* 298 */             .getString("authenticator.sessionExpired"));
/*     */       }
/*     */       else {
/*     */         
/* 302 */         String uri = request.getContextPath() + request.getContextPath();
/* 303 */         SavedRequest saved = new SavedRequest();
/* 304 */         saved.setMethod("GET");
/* 305 */         saved.setRequestURI(uri);
/* 306 */         saved.setDecodedRequestURI(uri);
/* 307 */         request.getSessionInternal(true).setNote("org.apache.catalina.authenticator.REQUEST", saved);
/* 308 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       } 
/* 310 */       return false;
/*     */     } 
/*     */     
/* 313 */     register(request, response, principal, "FORM", username, password);
/*     */ 
/*     */ 
/*     */     
/* 317 */     requestURI = savedRequestURL(session);
/* 318 */     if (this.log.isTraceEnabled()) {
/* 319 */       this.log.trace("Redirecting to original '" + requestURI + "'");
/*     */     }
/* 321 */     if (requestURI == null) {
/* 322 */       if (this.landingPage == null) {
/* 323 */         response.sendError(400, sm.getString("authenticator.formlogin"));
/*     */       }
/*     */       else {
/*     */         
/* 327 */         String uri = request.getContextPath() + request.getContextPath();
/* 328 */         SavedRequest saved = new SavedRequest();
/* 329 */         saved.setMethod("GET");
/* 330 */         saved.setRequestURI(uri);
/* 331 */         saved.setDecodedRequestURI(uri);
/* 332 */         session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/* 333 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 338 */       Response internalResponse = request.getResponse();
/* 339 */       String location = response.encodeRedirectURL(requestURI);
/* 340 */       if ("HTTP/1.1".equals(request.getProtocol())) {
/* 341 */         internalResponse.sendRedirect(location, 303);
/*     */       } else {
/* 343 */         internalResponse.sendRedirect(location, 302);
/*     */       } 
/*     */     } 
/* 346 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isContinuationRequired(Request request) {
/* 355 */     String contextPath = this.context.getPath();
/* 356 */     String decodedRequestURI = request.getDecodedRequestURI();
/* 357 */     if (decodedRequestURI.startsWith(contextPath) && decodedRequestURI.endsWith("/j_security_check")) {
/* 358 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     Session session = request.getSessionInternal(false);
/* 368 */     if (session != null) {
/* 369 */       SavedRequest savedRequest = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 370 */       return (savedRequest != null && decodedRequestURI.equals(savedRequest.getDecodedRequestURI()));
/*     */     } 
/*     */     
/* 373 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAuthMethod() {
/* 379 */     return "FORM";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void register(Request request, HttpServletResponse response, Principal principal, String authType, String username, String password, boolean alwaysUseSession, boolean cache) {
/* 387 */     super.register(request, response, principal, authType, username, password, alwaysUseSession, cache);
/*     */ 
/*     */ 
/*     */     
/* 391 */     if (!cache) {
/* 392 */       Session session = request.getSessionInternal(false);
/* 393 */       if (session != null) {
/* 394 */         if (username != null) {
/* 395 */           session.setNote("org.apache.catalina.session.USERNAME", username);
/*     */         } else {
/* 397 */           session.removeNote("org.apache.catalina.session.USERNAME");
/*     */         } 
/* 399 */         if (password != null) {
/* 400 */           session.setNote("org.apache.catalina.session.PASSWORD", password);
/*     */         } else {
/* 402 */           session.removeNote("org.apache.catalina.session.PASSWORD");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void forwardToLoginPage(Request request, HttpServletResponse response, LoginConfig config) throws IOException {
/* 422 */     if (this.log.isDebugEnabled()) {
/* 423 */       this.log.debug(sm.getString("formAuthenticator.forwardLogin", new Object[] { request.getRequestURI(), request.getMethod(), config
/* 424 */               .getLoginPage(), this.context.getName() }));
/*     */     }
/*     */     
/* 427 */     String loginPage = config.getLoginPage();
/* 428 */     if (loginPage == null || loginPage.isEmpty()) {
/* 429 */       String msg = sm.getString("formAuthenticator.noLoginPage", new Object[] { this.context.getName() });
/* 430 */       this.log.warn(msg);
/* 431 */       response.sendError(500, msg);
/*     */       
/*     */       return;
/*     */     } 
/* 435 */     if (getChangeSessionIdOnAuthentication()) {
/* 436 */       Session session = request.getSessionInternal(false);
/* 437 */       if (session != null) {
/* 438 */         String oldSessionId = session.getId();
/* 439 */         String newSessionId = changeSessionID(request, session);
/* 440 */         session.setNote("org.apache.catalina.authenticator.SESSION_ID", newSessionId);
/* 441 */         if (this.log.isDebugEnabled()) {
/* 442 */           this.log.debug(sm.getString("formAuthenticator.changeSessionIdLogin", new Object[] { oldSessionId, newSessionId }));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 448 */     String oldMethod = request.getMethod();
/* 449 */     request.getCoyoteRequest().setMethod("GET");
/*     */     
/* 451 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(loginPage);
/*     */     try {
/* 453 */       if (this.context.fireRequestInitEvent((ServletRequest)request.getRequest())) {
/* 454 */         disp.forward((ServletRequest)request.getRequest(), (ServletResponse)response);
/* 455 */         this.context.fireRequestDestroyEvent((ServletRequest)request.getRequest());
/*     */       } 
/* 457 */     } catch (Throwable t) {
/* 458 */       ExceptionUtils.handleThrowable(t);
/* 459 */       String msg = sm.getString("formAuthenticator.forwardLoginFail");
/* 460 */       this.log.warn(msg, t);
/* 461 */       request.setAttribute("jakarta.servlet.error.exception", t);
/* 462 */       response.sendError(500, msg);
/*     */     } finally {
/*     */       
/* 465 */       request.getCoyoteRequest().setMethod(oldMethod);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void forwardToErrorPage(Request request, HttpServletResponse response, LoginConfig config) throws IOException {
/* 483 */     String errorPage = config.getErrorPage();
/* 484 */     if (errorPage == null || errorPage.isEmpty()) {
/* 485 */       String msg = sm.getString("formAuthenticator.noErrorPage", new Object[] { this.context.getName() });
/* 486 */       this.log.warn(msg);
/* 487 */       response.sendError(500, msg);
/*     */       
/*     */       return;
/*     */     } 
/* 491 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(config.getErrorPage());
/*     */     try {
/* 493 */       if (this.context.fireRequestInitEvent((ServletRequest)request.getRequest())) {
/* 494 */         disp.forward((ServletRequest)request.getRequest(), (ServletResponse)response);
/* 495 */         this.context.fireRequestDestroyEvent((ServletRequest)request.getRequest());
/*     */       } 
/* 497 */     } catch (Throwable t) {
/* 498 */       ExceptionUtils.handleThrowable(t);
/* 499 */       String msg = sm.getString("formAuthenticator.forwardErrorFail");
/* 500 */       this.log.warn(msg, t);
/* 501 */       request.setAttribute("jakarta.servlet.error.exception", t);
/* 502 */       response.sendError(500, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchRequest(Request request) {
/* 517 */     Session session = request.getSessionInternal(false);
/* 518 */     if (session == null) {
/* 519 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 523 */     SavedRequest sreq = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 524 */     if (sreq == null) {
/* 525 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 529 */     if ((this.cache && session.getPrincipal() == null) || (!this.cache && request.getPrincipal() == null)) {
/* 530 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 534 */     if (getChangeSessionIdOnAuthentication()) {
/* 535 */       String expectedSessionId = (String)session.getNote("org.apache.catalina.authenticator.SESSION_ID");
/* 536 */       if (expectedSessionId == null || !expectedSessionId.equals(request.getRequestedSessionId())) {
/* 537 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 542 */     String decodedRequestURI = request.getDecodedRequestURI();
/* 543 */     if (decodedRequestURI == null) {
/* 544 */       return false;
/*     */     }
/* 546 */     return decodedRequestURI.equals(sreq.getDecodedRequestURI());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean restoreRequest(Request request, Session session) throws IOException {
/* 564 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 565 */     session.removeNote("org.apache.catalina.authenticator.REQUEST");
/* 566 */     session.removeNote("org.apache.catalina.authenticator.SESSION_ID");
/* 567 */     if (saved == null) {
/* 568 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     byte[] buffer = new byte[4096];
/* 576 */     ServletInputStream servletInputStream = request.createInputStream();
/* 577 */     while (servletInputStream.read(buffer) >= 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     request.clearCookies();
/* 583 */     Iterator<Cookie> cookies = saved.getCookies();
/* 584 */     while (cookies.hasNext()) {
/* 585 */       request.addCookie(cookies.next());
/*     */     }
/*     */     
/* 588 */     String method = saved.getMethod();
/* 589 */     MimeHeaders rmh = request.getCoyoteRequest().getMimeHeaders();
/* 590 */     rmh.recycle();
/* 591 */     boolean cacheable = ("GET".equals(method) || "HEAD".equals(method));
/* 592 */     Iterator<String> names = saved.getHeaderNames();
/* 593 */     while (names.hasNext()) {
/* 594 */       String name = names.next();
/*     */ 
/*     */ 
/*     */       
/* 598 */       if (!"If-Modified-Since".equalsIgnoreCase(name) && (!cacheable || 
/* 599 */         !"If-None-Match".equalsIgnoreCase(name))) {
/* 600 */         Iterator<String> values = saved.getHeaderValues(name);
/* 601 */         while (values.hasNext()) {
/* 602 */           rmh.addValue(name).setString(values.next());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 607 */     request.clearLocales();
/* 608 */     Iterator<Locale> locales = saved.getLocales();
/* 609 */     while (locales.hasNext()) {
/* 610 */       request.addLocale(locales.next());
/*     */     }
/*     */     
/* 613 */     request.getCoyoteRequest().getParameters().recycle();
/*     */     
/* 615 */     ByteChunk body = saved.getBody();
/*     */     
/* 617 */     if (body != null) {
/* 618 */       request.getCoyoteRequest().action(ActionCode.REQ_SET_BODY_REPLAY, body);
/*     */ 
/*     */       
/* 621 */       MessageBytes contentType = MessageBytes.newInstance();
/*     */ 
/*     */       
/* 624 */       String savedContentType = saved.getContentType();
/* 625 */       if (savedContentType == null && "POST".equals(method)) {
/* 626 */         savedContentType = "application/x-www-form-urlencoded";
/*     */       }
/*     */       
/* 629 */       contentType.setString(savedContentType);
/* 630 */       request.getCoyoteRequest().setContentType(contentType);
/*     */     } 
/*     */     
/* 633 */     request.getCoyoteRequest().setMethod(method);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 643 */     request.getCoyoteRequest().requestURI().toStringType();
/* 644 */     request.getCoyoteRequest().queryString().toStringType();
/* 645 */     request.getCoyoteRequest().protocol().toStringType();
/*     */     
/* 647 */     if (saved.getOriginalMaxInactiveIntervalOptional() != null) {
/* 648 */       session.setMaxInactiveInterval(saved.getOriginalMaxInactiveIntervalOptional().intValue());
/*     */     }
/*     */     
/* 651 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void saveRequest(Request request, Session session) throws IOException {
/* 666 */     SavedRequest saved = new SavedRequest();
/* 667 */     Cookie[] cookies = request.getCookies();
/* 668 */     if (cookies != null) {
/* 669 */       for (Cookie cookie : cookies) {
/* 670 */         saved.addCookie(cookie);
/*     */       }
/*     */     }
/* 673 */     Enumeration<String> names = request.getHeaderNames();
/* 674 */     while (names.hasMoreElements()) {
/* 675 */       String name = names.nextElement();
/* 676 */       Enumeration<String> values = request.getHeaders(name);
/* 677 */       while (values.hasMoreElements()) {
/* 678 */         String value = values.nextElement();
/* 679 */         saved.addHeader(name, value);
/*     */       } 
/*     */     } 
/* 682 */     Enumeration<Locale> locales = request.getLocales();
/* 683 */     while (locales.hasMoreElements()) {
/* 684 */       Locale locale = locales.nextElement();
/* 685 */       saved.addLocale(locale);
/*     */     } 
/*     */ 
/*     */     
/* 689 */     request.getResponse().sendAcknowledgement(ContinueResponseTiming.ALWAYS);
/*     */     
/* 691 */     int maxSavePostSize = request.getConnector().getMaxSavePostSize();
/* 692 */     if (maxSavePostSize != 0) {
/* 693 */       ByteChunk body = new ByteChunk();
/* 694 */       body.setLimit(maxSavePostSize);
/*     */       
/* 696 */       byte[] buffer = new byte[4096];
/*     */       
/* 698 */       ServletInputStream servletInputStream = request.getInputStream();
/*     */       int bytesRead;
/* 700 */       while ((bytesRead = servletInputStream.read(buffer)) >= 0) {
/* 701 */         body.append(buffer, 0, bytesRead);
/*     */       }
/*     */ 
/*     */       
/* 705 */       if (body.getLength() > 0) {
/* 706 */         saved.setContentType(request.getContentType());
/* 707 */         saved.setBody(body);
/*     */       } 
/*     */     } 
/*     */     
/* 711 */     saved.setMethod(request.getMethod());
/* 712 */     saved.setQueryString(request.getQueryString());
/* 713 */     saved.setRequestURI(request.getRequestURI());
/* 714 */     saved.setDecodedRequestURI(request.getDecodedRequestURI());
/*     */     
/* 716 */     SavedRequest previousSavedRequest = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 717 */     if (session instanceof HttpSession) {
/* 718 */       if (((HttpSession)session).isNew()) {
/* 719 */         int originalMaxInactiveInterval = session.getMaxInactiveInterval();
/* 720 */         if (originalMaxInactiveInterval > getAuthenticationSessionTimeout() || originalMaxInactiveInterval <= 0) {
/*     */           
/* 722 */           saved.setOriginalMaxInactiveInterval(originalMaxInactiveInterval);
/* 723 */           session.setMaxInactiveInterval(getAuthenticationSessionTimeout());
/*     */         } 
/* 725 */       } else if (previousSavedRequest != null && previousSavedRequest
/* 726 */         .getOriginalMaxInactiveIntervalOptional() != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 732 */         saved.setOriginalMaxInactiveInterval(previousSavedRequest
/* 733 */             .getOriginalMaxInactiveIntervalOptional().intValue());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 738 */     session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String savedRequestURL(Session session) {
/* 751 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 752 */     if (saved == null) {
/* 753 */       return null;
/*     */     }
/* 755 */     StringBuilder sb = new StringBuilder(saved.getRequestURI());
/* 756 */     if (saved.getQueryString() != null) {
/* 757 */       sb.append('?');
/* 758 */       sb.append(saved.getQueryString());
/*     */     } 
/*     */ 
/*     */     
/* 762 */     while (sb.length() > 1 && sb.charAt(1) == '/') {
/* 763 */       sb.deleteCharAt(0);
/*     */     }
/*     */     
/* 766 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\FormAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */