/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SavedRequest
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  46 */   private final List<Cookie> cookies = new ArrayList<>();
/*     */   
/*     */   public void addCookie(Cookie cookie) {
/*  49 */     this.cookies.add(cookie);
/*     */   }
/*     */   
/*     */   public Iterator<Cookie> getCookies() {
/*  53 */     return this.cookies.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private final Map<String, List<String>> headers = new HashMap<>();
/*     */   
/*     */   public void addHeader(String name, String value) {
/*  64 */     ((List<String>)this.headers.computeIfAbsent(name, k -> new ArrayList())).add(value);
/*     */   }
/*     */   
/*     */   public Iterator<String> getHeaderNames() {
/*  68 */     return this.headers.keySet().iterator();
/*     */   }
/*     */   
/*     */   public Iterator<String> getHeaderValues(String name) {
/*  72 */     List<String> values = this.headers.get(name);
/*  73 */     if (values == null) {
/*  74 */       return Collections.emptyIterator();
/*     */     }
/*  76 */     return values.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private final List<Locale> locales = new ArrayList<>();
/*     */   
/*     */   public void addLocale(Locale locale) {
/*  87 */     this.locales.add(locale);
/*     */   }
/*     */   
/*     */   public Iterator<Locale> getLocales() {
/*  91 */     return this.locales.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private String method = null;
/*     */   
/*     */   public String getMethod() {
/* 101 */     return this.method;
/*     */   }
/*     */   
/*     */   public void setMethod(String method) {
/* 105 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private String queryString = null;
/*     */   
/*     */   public String getQueryString() {
/* 115 */     return this.queryString;
/*     */   }
/*     */   
/*     */   public void setQueryString(String queryString) {
/* 119 */     this.queryString = queryString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private String requestURI = null;
/*     */   
/*     */   public String getRequestURI() {
/* 129 */     return this.requestURI;
/*     */   }
/*     */   
/*     */   public void setRequestURI(String requestURI) {
/* 133 */     this.requestURI = requestURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private String decodedRequestURI = null;
/*     */   
/*     */   public String getDecodedRequestURI() {
/* 143 */     return this.decodedRequestURI;
/*     */   }
/*     */   
/*     */   public void setDecodedRequestURI(String decodedRequestURI) {
/* 147 */     this.decodedRequestURI = decodedRequestURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private ByteChunk body = null;
/*     */   
/*     */   public ByteChunk getBody() {
/* 157 */     return this.body;
/*     */   }
/*     */   
/*     */   public void setBody(ByteChunk body) {
/* 161 */     this.body = body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   private String contentType = null;
/*     */   
/*     */   public String getContentType() {
/* 171 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/* 175 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   private Integer originalMaxInactiveInterval = null;
/*     */   
/*     */   public Integer getOriginalMaxInactiveIntervalOptional() {
/* 185 */     return this.originalMaxInactiveInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getOriginalMaxInactiveInterval() {
/* 198 */     return (this.originalMaxInactiveInterval == null) ? -1 : this.originalMaxInactiveInterval.intValue();
/*     */   }
/*     */   
/*     */   public void setOriginalMaxInactiveInterval(int originalMaxInactiveInterval) {
/* 202 */     this.originalMaxInactiveInterval = Integer.valueOf(originalMaxInactiveInterval);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\SavedRequest.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */