/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import jakarta.security.auth.message.AuthException;
/*     */ import jakarta.security.auth.message.AuthStatus;
/*     */ import jakarta.security.auth.message.MessageInfo;
/*     */ import jakarta.security.auth.message.config.AuthConfigFactory;
/*     */ import jakarta.security.auth.message.config.AuthConfigProvider;
/*     */ import jakarta.security.auth.message.config.ClientAuthConfig;
/*     */ import jakarta.security.auth.message.config.RegistrationListener;
/*     */ import jakarta.security.auth.message.config.ServerAuthConfig;
/*     */ import jakarta.security.auth.message.config.ServerAuthContext;
/*     */ import jakarta.security.auth.message.module.ServerAuthModule;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthConfigFactoryImpl
/*     */   extends AuthConfigFactory
/*     */ {
/*  54 */   private final Log log = LogFactory.getLog(AuthConfigFactoryImpl.class);
/*  55 */   private static final StringManager sm = StringManager.getManager(AuthConfigFactoryImpl.class);
/*     */   
/*     */   private static final String CONFIG_PATH = "conf/jaspic-providers.xml";
/*  58 */   private static final File CONFIG_FILE = new File(System.getProperty("catalina.base"), "conf/jaspic-providers.xml");
/*  59 */   private static final Object CONFIG_FILE_LOCK = new Object();
/*     */   
/*  61 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*     */   private static final String SERVLET_LAYER_ID = "HttpServlet";
/*     */   
/*  65 */   private static final String DEFAULT_REGISTRATION_ID = getRegistrationID(null, null);
/*     */   
/*  67 */   private final Map<String, RegistrationContextImpl> layerAppContextRegistrations = new ConcurrentHashMap<>();
/*  68 */   private final Map<String, RegistrationContextImpl> appContextRegistrations = new ConcurrentHashMap<>();
/*  69 */   private final Map<String, RegistrationContextImpl> layerRegistrations = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*  72 */   private final Map<String, RegistrationContextImpl> defaultRegistration = new ConcurrentHashMap<>(1);
/*     */ 
/*     */   
/*     */   public AuthConfigFactoryImpl() {
/*  76 */     loadPersistentRegistrations();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthConfigProvider getConfigProvider(String layer, String appContext, RegistrationListener listener) {
/*  82 */     RegistrationContextImpl registrationContext = findRegistrationContextImpl(layer, appContext);
/*  83 */     if (registrationContext != null) {
/*  84 */       if (listener != null) {
/*  85 */         RegistrationListenerWrapper wrapper = new RegistrationListenerWrapper(layer, appContext, listener);
/*  86 */         registrationContext.addListener(wrapper);
/*     */       } 
/*  88 */       return registrationContext.getProvider();
/*     */     } 
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String registerConfigProvider(String className, Map<String, String> properties, String layer, String appContext, String description) {
/*  97 */     String registrationID = doRegisterConfigProvider(className, properties, layer, appContext, description);
/*  98 */     savePersistentRegistrations();
/*  99 */     return registrationID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String doRegisterConfigProvider(String className, Map<String, String> properties, String layer, String appContext, String description) {
/* 105 */     if (this.log.isDebugEnabled()) {
/* 106 */       this.log.debug(sm.getString("authConfigFactoryImpl.registerClass", new Object[] { className, layer, appContext }));
/*     */     }
/*     */     
/* 109 */     AuthConfigProvider provider = null;
/* 110 */     if (className != null) {
/* 111 */       provider = createAuthConfigProvider(className, properties);
/*     */     }
/*     */     
/* 114 */     String registrationID = getRegistrationID(layer, appContext);
/* 115 */     RegistrationContextImpl registrationContextImpl = new RegistrationContextImpl(layer, appContext, description, true, provider, properties);
/*     */     
/* 117 */     addRegistrationContextImpl(layer, appContext, registrationID, registrationContextImpl);
/* 118 */     return registrationID;
/*     */   }
/*     */ 
/*     */   
/*     */   private AuthConfigProvider createAuthConfigProvider(String className, Map<String, String> properties) throws SecurityException {
/*     */     AuthConfigProvider provider;
/* 124 */     Class<?> clazz = null;
/*     */     
/*     */     try {
/* 127 */       clazz = Class.forName(className, true, Thread.currentThread().getContextClassLoader());
/* 128 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*     */     try {
/* 132 */       if (clazz == null) {
/* 133 */         clazz = Class.forName(className);
/*     */       }
/* 135 */       Constructor<?> constructor = clazz.getConstructor(new Class[] { Map.class, AuthConfigFactory.class });
/* 136 */       provider = (AuthConfigProvider)constructor.newInstance(new Object[] { properties, null });
/* 137 */     } catch (ReflectiveOperationException|IllegalArgumentException e) {
/* 138 */       throw new SecurityException(e);
/*     */     } 
/* 140 */     return provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String registerConfigProvider(AuthConfigProvider provider, String layer, String appContext, String description) {
/* 147 */     if (this.log.isDebugEnabled()) {
/* 148 */       this.log.debug(sm.getString("authConfigFactoryImpl.registerInstance", new Object[] { provider.getClass().getName(), layer, appContext }));
/*     */     }
/*     */     
/* 151 */     String registrationID = getRegistrationID(layer, appContext);
/* 152 */     RegistrationContextImpl registrationContextImpl = new RegistrationContextImpl(layer, appContext, description, false, provider, null);
/*     */     
/* 154 */     addRegistrationContextImpl(layer, appContext, registrationID, registrationContextImpl);
/* 155 */     return registrationID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addRegistrationContextImpl(String layer, String appContext, String registrationID, RegistrationContextImpl registrationContextImpl) {
/*     */     RegistrationContextImpl previous;
/* 164 */     if (layer != null && appContext != null) {
/* 165 */       previous = this.layerAppContextRegistrations.put(registrationID, registrationContextImpl);
/* 166 */     } else if (layer == null && appContext != null) {
/* 167 */       previous = this.appContextRegistrations.put(registrationID, registrationContextImpl);
/* 168 */     } else if (layer != null) {
/* 169 */       previous = this.layerRegistrations.put(registrationID, registrationContextImpl);
/*     */     } else {
/* 171 */       previous = this.defaultRegistration.put(registrationID, registrationContextImpl);
/*     */     } 
/*     */     
/* 174 */     if (previous == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 179 */       if (layer != null && appContext != null) {
/*     */ 
/*     */ 
/*     */         
/* 183 */         RegistrationContextImpl registration = this.appContextRegistrations.get(getRegistrationID(null, appContext));
/* 184 */         if (registration != null) {
/* 185 */           for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 186 */             if (layer.equals(wrapper.getMessageLayer()) && appContext.equals(wrapper.getAppContext())) {
/* 187 */               registration.listeners.remove(wrapper);
/* 188 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/* 193 */       if (appContext != null)
/*     */       {
/*     */ 
/*     */         
/* 197 */         for (RegistrationContextImpl registration : this.layerRegistrations.values()) {
/* 198 */           for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 199 */             if (appContext.equals(wrapper.getAppContext())) {
/* 200 */               registration.listeners.remove(wrapper);
/* 201 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/* 206 */       if (layer != null || appContext != null)
/*     */       {
/* 208 */         for (RegistrationContextImpl registration : this.defaultRegistration.values()) {
/* 209 */           for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 210 */             if ((appContext != null && appContext.equals(wrapper.getAppContext())) || (layer != null && layer
/* 211 */               .equals(wrapper.getMessageLayer()))) {
/* 212 */               registration.listeners.remove(wrapper);
/* 213 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } else {
/*     */       
/* 220 */       for (RegistrationListenerWrapper wrapper : previous.listeners) {
/* 221 */         previous.listeners.remove(wrapper);
/* 222 */         wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeRegistration(String registrationID) {
/* 230 */     RegistrationContextImpl registration = null;
/* 231 */     if (DEFAULT_REGISTRATION_ID.equals(registrationID)) {
/* 232 */       registration = this.defaultRegistration.remove(registrationID);
/*     */     }
/* 234 */     if (registration == null) {
/* 235 */       registration = this.layerAppContextRegistrations.remove(registrationID);
/*     */     }
/* 237 */     if (registration == null) {
/* 238 */       registration = this.appContextRegistrations.remove(registrationID);
/*     */     }
/* 240 */     if (registration == null) {
/* 241 */       registration = this.layerRegistrations.remove(registrationID);
/*     */     }
/*     */     
/* 244 */     if (registration == null) {
/* 245 */       return false;
/*     */     }
/* 247 */     for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 248 */       wrapper.getListener().notify(wrapper.getMessageLayer(), wrapper.getAppContext());
/*     */     }
/* 250 */     if (registration.isPersistent()) {
/* 251 */       savePersistentRegistrations();
/*     */     }
/* 253 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] detachListener(RegistrationListener listener, String layer, String appContext) {
/* 260 */     String registrationID = getRegistrationID(layer, appContext);
/* 261 */     RegistrationContextImpl registrationContext = findRegistrationContextImpl(layer, appContext);
/* 262 */     if (registrationContext != null && registrationContext.removeListener(listener)) {
/* 263 */       return new String[] { registrationID };
/*     */     }
/* 265 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRegistrationIDs(AuthConfigProvider provider) {
/* 271 */     List<String> result = new ArrayList<>();
/* 272 */     if (provider == null) {
/* 273 */       result.addAll(this.layerAppContextRegistrations.keySet());
/* 274 */       result.addAll(this.appContextRegistrations.keySet());
/* 275 */       result.addAll(this.layerRegistrations.keySet());
/* 276 */       if (!this.defaultRegistration.isEmpty()) {
/* 277 */         result.add(DEFAULT_REGISTRATION_ID);
/*     */       }
/*     */     } else {
/* 280 */       findProvider(provider, this.layerAppContextRegistrations, result);
/* 281 */       findProvider(provider, this.appContextRegistrations, result);
/* 282 */       findProvider(provider, this.layerRegistrations, result);
/* 283 */       findProvider(provider, this.defaultRegistration, result);
/*     */     } 
/* 285 */     return result.<String>toArray(EMPTY_STRING_ARRAY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void findProvider(AuthConfigProvider provider, Map<String, RegistrationContextImpl> registrations, List<String> result) {
/* 291 */     for (Map.Entry<String, RegistrationContextImpl> entry : registrations.entrySet()) {
/* 292 */       if (provider.equals(((RegistrationContextImpl)entry.getValue()).getProvider())) {
/* 293 */         result.add(entry.getKey());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthConfigFactory.RegistrationContext getRegistrationContext(String registrationID) {
/* 301 */     AuthConfigFactory.RegistrationContext result = this.defaultRegistration.get(registrationID);
/* 302 */     if (result == null) {
/* 303 */       result = this.layerAppContextRegistrations.get(registrationID);
/*     */     }
/* 305 */     if (result == null) {
/* 306 */       result = this.appContextRegistrations.get(registrationID);
/*     */     }
/* 308 */     if (result == null) {
/* 309 */       result = this.layerRegistrations.get(registrationID);
/*     */     }
/* 311 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 317 */     loadPersistentRegistrations();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String registerServerAuthModule(ServerAuthModule serverAuthModule, Object context) {
/* 323 */     if (context == null) {
/* 324 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.nullContext"));
/*     */     }
/*     */     
/* 327 */     if (context instanceof ServletContext) {
/* 328 */       ServletContext servletContext = (ServletContext)context;
/* 329 */       String appContext = servletContext.getVirtualServerName() + " " + servletContext.getVirtualServerName();
/*     */       
/* 331 */       AuthConfigProvider authConfigProvider = new SingleConfigAuthConfigProvider(serverAuthModule, appContext);
/*     */       
/* 333 */       return registerConfigProvider(authConfigProvider, "HttpServlet", appContext, "");
/*     */     } 
/*     */ 
/*     */     
/* 337 */     throw new IllegalArgumentException(sm
/* 338 */         .getString("authConfigFactoryImpl.unsupportedContextType", new Object[] { context.getClass().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeServerAuthModule(Object context) {
/* 344 */     if (context == null) {
/* 345 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.nullContext"));
/*     */     }
/*     */     
/* 348 */     if (context instanceof ServletContext) {
/* 349 */       ServletContext servletContext = (ServletContext)context;
/* 350 */       String layer = "HttpServlet";
/* 351 */       String appContextID = servletContext.getVirtualServerName() + " " + servletContext.getVirtualServerName();
/*     */       
/* 353 */       removeRegistration(getRegistrationID(layer, appContextID));
/*     */     } 
/*     */ 
/*     */     
/* 357 */     throw new IllegalArgumentException(sm
/* 358 */         .getString("authConfigFactoryImpl.unsupportedContextType", new Object[] { context.getClass().getName() }));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getRegistrationID(String layer, String appContext) {
/* 363 */     if (layer != null && layer.isEmpty()) {
/* 364 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.zeroLengthMessageLayer"));
/*     */     }
/* 366 */     if (appContext != null && appContext.isEmpty()) {
/* 367 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.zeroLengthAppContext"));
/*     */     }
/* 369 */     return ((layer == null) ? "" : layer) + ":" + ((layer == null) ? "" : layer);
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadPersistentRegistrations() {
/* 374 */     synchronized (CONFIG_FILE_LOCK) {
/* 375 */       if (this.log.isDebugEnabled()) {
/* 376 */         this.log.debug(sm.getString("authConfigFactoryImpl.load", new Object[] { CONFIG_FILE.getAbsolutePath() }));
/*     */       }
/* 378 */       if (!CONFIG_FILE.isFile()) {
/*     */         return;
/*     */       }
/* 381 */       PersistentProviderRegistrations.Providers providers = PersistentProviderRegistrations.loadProviders(CONFIG_FILE);
/* 382 */       for (PersistentProviderRegistrations.Provider provider : providers.getProviders()) {
/* 383 */         doRegisterConfigProvider(provider.getClassName(), provider.getProperties(), provider.getLayer(), provider
/* 384 */             .getAppContext(), provider.getDescription());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void savePersistentRegistrations() {
/* 391 */     synchronized (CONFIG_FILE_LOCK) {
/* 392 */       PersistentProviderRegistrations.Providers providers = new PersistentProviderRegistrations.Providers();
/* 393 */       savePersistentProviders(providers, this.layerAppContextRegistrations);
/* 394 */       savePersistentProviders(providers, this.appContextRegistrations);
/* 395 */       savePersistentProviders(providers, this.layerRegistrations);
/* 396 */       savePersistentProviders(providers, this.defaultRegistration);
/* 397 */       PersistentProviderRegistrations.writeProviders(providers, CONFIG_FILE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void savePersistentProviders(PersistentProviderRegistrations.Providers providers, Map<String, RegistrationContextImpl> registrations) {
/* 403 */     for (Map.Entry<String, RegistrationContextImpl> entry : registrations.entrySet()) {
/* 404 */       savePersistentProvider(providers, entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void savePersistentProvider(PersistentProviderRegistrations.Providers providers, RegistrationContextImpl registrationContextImpl) {
/* 410 */     if (registrationContextImpl != null && registrationContextImpl.isPersistent()) {
/* 411 */       PersistentProviderRegistrations.Provider provider = new PersistentProviderRegistrations.Provider();
/* 412 */       provider.setAppContext(registrationContextImpl.getAppContext());
/* 413 */       if (registrationContextImpl.getProvider() != null) {
/* 414 */         provider.setClassName(registrationContextImpl.getProvider().getClass().getName());
/*     */       }
/* 416 */       provider.setDescription(registrationContextImpl.getDescription());
/* 417 */       provider.setLayer(registrationContextImpl.getMessageLayer());
/* 418 */       for (Map.Entry<String, String> property : registrationContextImpl.getProperties().entrySet()) {
/* 419 */         provider.addProperty(property.getKey(), property.getValue());
/*     */       }
/* 421 */       providers.addProvider(provider);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RegistrationContextImpl findRegistrationContextImpl(String layer, String appContext) {
/* 428 */     RegistrationContextImpl result = this.layerAppContextRegistrations.get(getRegistrationID(layer, appContext));
/* 429 */     if (result == null) {
/* 430 */       result = this.appContextRegistrations.get(getRegistrationID(null, appContext));
/*     */     }
/* 432 */     if (result == null) {
/* 433 */       result = this.layerRegistrations.get(getRegistrationID(layer, null));
/*     */     }
/* 435 */     if (result == null) {
/* 436 */       result = this.defaultRegistration.get(DEFAULT_REGISTRATION_ID);
/*     */     }
/* 438 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class RegistrationContextImpl
/*     */     implements AuthConfigFactory.RegistrationContext
/*     */   {
/*     */     private final String messageLayer;
/*     */ 
/*     */     
/*     */     private final String appContext;
/*     */ 
/*     */     
/*     */     private final String description;
/*     */     
/*     */     private final boolean persistent;
/*     */     
/*     */     private final AuthConfigProvider provider;
/*     */     
/*     */     private final Map<String, String> properties;
/*     */     
/*     */     private final List<AuthConfigFactoryImpl.RegistrationListenerWrapper> listeners;
/*     */ 
/*     */     
/*     */     private RegistrationContextImpl(String messageLayer, String appContext, String description, boolean persistent, AuthConfigProvider provider, Map<String, String> properties) {
/* 464 */       this.listeners = new CopyOnWriteArrayList<>(); this.messageLayer = messageLayer; this.appContext = appContext; this.description = description; this.persistent = persistent; this.provider = provider;
/*     */       Map<String, String> propertiesCopy = new HashMap<>();
/*     */       if (properties != null)
/*     */         propertiesCopy.putAll(properties); 
/* 468 */       this.properties = Collections.unmodifiableMap(propertiesCopy); } public String getMessageLayer() { return this.messageLayer; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getAppContext() {
/* 474 */       return this.appContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 479 */       return this.description;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isPersistent() {
/* 485 */       return this.persistent;
/*     */     }
/*     */ 
/*     */     
/*     */     private AuthConfigProvider getProvider() {
/* 490 */       return this.provider;
/*     */     }
/*     */ 
/*     */     
/*     */     private void addListener(AuthConfigFactoryImpl.RegistrationListenerWrapper listener) {
/* 495 */       if (listener != null) {
/* 496 */         this.listeners.add(listener);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private Map<String, String> getProperties() {
/* 502 */       return this.properties;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean removeListener(RegistrationListener listener) {
/* 507 */       boolean result = false;
/* 508 */       for (AuthConfigFactoryImpl.RegistrationListenerWrapper wrapper : this.listeners) {
/* 509 */         if (wrapper.getListener().equals(listener)) {
/* 510 */           this.listeners.remove(wrapper);
/* 511 */           result = true;
/*     */         } 
/*     */       } 
/* 514 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class RegistrationListenerWrapper
/*     */   {
/*     */     private final String messageLayer;
/*     */     
/*     */     private final String appContext;
/*     */     private final RegistrationListener listener;
/*     */     
/*     */     RegistrationListenerWrapper(String messageLayer, String appContext, RegistrationListener listener) {
/* 527 */       this.messageLayer = messageLayer;
/* 528 */       this.appContext = appContext;
/* 529 */       this.listener = listener;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessageLayer() {
/* 534 */       return this.messageLayer;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAppContext() {
/* 539 */       return this.appContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public RegistrationListener getListener() {
/* 544 */       return this.listener;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleModuleServerAuthContext
/*     */     implements ServerAuthContext
/*     */   {
/*     */     private final ServerAuthModule module;
/*     */     
/*     */     SingleModuleServerAuthContext(ServerAuthModule module) {
/* 554 */       this.module = module;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthStatus validateRequest(MessageInfo messageInfo, Subject clientSubject, Subject serviceSubject) throws AuthException {
/* 560 */       return this.module.validateRequest(messageInfo, clientSubject, serviceSubject);
/*     */     }
/*     */ 
/*     */     
/*     */     public AuthStatus secureResponse(MessageInfo messageInfo, Subject serviceSubject) throws AuthException {
/* 565 */       return this.module.secureResponse(messageInfo, serviceSubject);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cleanSubject(MessageInfo messageInfo, Subject subject) throws AuthException {
/* 570 */       this.module.cleanSubject(messageInfo, subject);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleContextServerAuthConfig
/*     */     implements ServerAuthConfig
/*     */   {
/*     */     private final ServerAuthModule serverAuthModule;
/*     */     private final String appContext;
/*     */     private final CallbackHandler handler;
/* 580 */     private final Object serverAuthContextLock = new Object();
/*     */     private volatile ServerAuthContext serverAuthContext;
/*     */     
/*     */     SingleContextServerAuthConfig(ServerAuthModule serverAuthModule, String appContext, CallbackHandler handler) {
/* 584 */       this.serverAuthModule = serverAuthModule;
/* 585 */       this.appContext = appContext;
/* 586 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessageLayer() {
/* 591 */       return "HttpServlet";
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAppContext() {
/* 596 */       return this.appContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAuthContextID(MessageInfo messageInfo) {
/* 601 */       return messageInfo.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void refresh() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isProtected() {
/* 611 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ServerAuthContext getAuthContext(String authContextID, Subject serviceSubject, Map<String, Object> properties) throws AuthException {
/* 620 */       if (this.serverAuthContext == null) {
/* 621 */         synchronized (this.serverAuthContextLock) {
/* 622 */           if (this.serverAuthContext == null) {
/* 623 */             this.serverAuthContext = new AuthConfigFactoryImpl.SingleModuleServerAuthContext(this.serverAuthModule);
/* 624 */             this.serverAuthModule.initialize(null, null, this.handler, properties);
/*     */           } 
/*     */         } 
/*     */       }
/* 628 */       return this.serverAuthContext;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleConfigAuthConfigProvider
/*     */     implements AuthConfigProvider
/*     */   {
/*     */     private final ServerAuthModule serverAuthModule;
/*     */     private final String appContext;
/* 637 */     private final Object serverAuthConfigLock = new Object();
/*     */     private volatile ServerAuthConfig serverAuthConfig;
/*     */     
/*     */     SingleConfigAuthConfigProvider(ServerAuthModule serverAuthModule, String appContext) {
/* 641 */       this.serverAuthModule = serverAuthModule;
/* 642 */       this.appContext = appContext;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClientAuthConfig getClientAuthConfig(String layer, String appContext, CallbackHandler handler) throws AuthException {
/* 649 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ServerAuthConfig getServerAuthConfig(String layer, String appContext, CallbackHandler handler) throws AuthException {
/* 658 */       if (this.serverAuthConfig == null) {
/* 659 */         synchronized (this.serverAuthConfigLock) {
/* 660 */           if (this.serverAuthConfig == null) {
/* 661 */             this.serverAuthConfig = new AuthConfigFactoryImpl.SingleContextServerAuthConfig(this.serverAuthModule, this.appContext, handler);
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 666 */       return this.serverAuthConfig;
/*     */     }
/*     */     
/*     */     public void refresh() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\AuthConfigFactoryImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */