/*    */ package org.apache.catalina.authenticator.jaspic;
/*    */ 
/*    */ import jakarta.security.auth.message.MessageInfo;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageInfoImpl
/*    */   implements MessageInfo
/*    */ {
/* 29 */   protected static final StringManager sm = StringManager.getManager(MessageInfoImpl.class);
/*    */   
/*    */   public static final String IS_MANDATORY = "jakarta.security.auth.message.MessagePolicy.isMandatory";
/*    */   
/* 33 */   private final Map<String, Object> map = new HashMap<>();
/*    */   
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   
/*    */   public MessageInfoImpl() {}
/*    */   
/*    */   public MessageInfoImpl(HttpServletRequest request, HttpServletResponse response, boolean authMandatory) {
/* 41 */     this.request = request;
/* 42 */     this.response = response;
/* 43 */     this.map.put("jakarta.security.auth.message.MessagePolicy.isMandatory", Boolean.toString(authMandatory));
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getMap() {
/* 48 */     return this.map;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getRequestMessage() {
/* 53 */     return this.request;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getResponseMessage() {
/* 58 */     return this.response;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRequestMessage(Object request) {
/* 63 */     if (!(request instanceof HttpServletRequest)) {
/* 64 */       throw new IllegalArgumentException(sm
/* 65 */           .getString("authenticator.jaspic.badRequestType", new Object[] { request.getClass().getName() }));
/*    */     }
/* 67 */     this.request = (HttpServletRequest)request;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResponseMessage(Object response) {
/* 72 */     if (!(response instanceof HttpServletResponse)) {
/* 73 */       throw new IllegalArgumentException(sm
/* 74 */           .getString("authenticator.jaspic.badResponseType", new Object[] { response.getClass().getName() }));
/*    */     }
/* 76 */     this.response = (HttpServletResponse)response;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\MessageInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */