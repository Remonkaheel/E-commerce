/*    */ package org.apache.catalina.authenticator.jaspic;
/*    */ 
/*    */ import jakarta.security.auth.message.AuthException;
/*    */ import jakarta.security.auth.message.AuthStatus;
/*    */ import jakarta.security.auth.message.MessageInfo;
/*    */ import jakarta.security.auth.message.config.ServerAuthContext;
/*    */ import jakarta.security.auth.message.module.ServerAuthModule;
/*    */ import java.util.List;
/*    */ import javax.security.auth.Subject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleServerAuthContext
/*    */   implements ServerAuthContext
/*    */ {
/*    */   private final List<ServerAuthModule> modules;
/*    */   
/*    */   public SimpleServerAuthContext(List<ServerAuthModule> modules) {
/* 40 */     this.modules = modules;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthStatus validateRequest(MessageInfo messageInfo, Subject clientSubject, Subject serviceSubject) throws AuthException {
/* 47 */     for (int moduleIndex = 0; moduleIndex < this.modules.size(); moduleIndex++) {
/* 48 */       ServerAuthModule module = this.modules.get(moduleIndex);
/* 49 */       AuthStatus result = module.validateRequest(messageInfo, clientSubject, serviceSubject);
/* 50 */       if (result != AuthStatus.SEND_FAILURE) {
/* 51 */         messageInfo.getMap().put("moduleIndex", Integer.valueOf(moduleIndex));
/* 52 */         return result;
/*    */       } 
/*    */     } 
/* 55 */     return AuthStatus.SEND_FAILURE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthStatus secureResponse(MessageInfo messageInfo, Subject serviceSubject) throws AuthException {
/* 61 */     ServerAuthModule module = this.modules.get(((Integer)messageInfo.getMap().get("moduleIndex")).intValue());
/* 62 */     return module.secureResponse(messageInfo, serviceSubject);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void cleanSubject(MessageInfo messageInfo, Subject subject) throws AuthException {
/* 68 */     for (ServerAuthModule module : this.modules)
/* 69 */       module.cleanSubject(messageInfo, subject); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\SimpleServerAuthContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */