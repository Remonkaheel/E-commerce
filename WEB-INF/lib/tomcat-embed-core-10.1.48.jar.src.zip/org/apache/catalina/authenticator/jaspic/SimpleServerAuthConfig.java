/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import jakarta.security.auth.message.AuthException;
/*     */ import jakarta.security.auth.message.MessageInfo;
/*     */ import jakarta.security.auth.message.config.ServerAuthConfig;
/*     */ import jakarta.security.auth.message.config.ServerAuthContext;
/*     */ import jakarta.security.auth.message.module.ServerAuthModule;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleServerAuthConfig
/*     */   implements ServerAuthConfig
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(SimpleServerAuthConfig.class);
/*     */   
/*     */   private static final String SERVER_AUTH_MODULE_KEY_PREFIX = "org.apache.catalina.authenticator.jaspic.ServerAuthModule.";
/*     */   
/*     */   private final String layer;
/*     */   
/*     */   private final String appContext;
/*     */   
/*     */   private final CallbackHandler handler;
/*     */   
/*     */   private final Map<String, Object> properties;
/*     */   private volatile ServerAuthContext serverAuthContext;
/*     */   
/*     */   public SimpleServerAuthConfig(String layer, String appContext, CallbackHandler handler, Map<String, Object> properties) {
/*  56 */     this.layer = layer;
/*  57 */     this.appContext = appContext;
/*  58 */     this.handler = handler;
/*  59 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessageLayer() {
/*  65 */     return this.layer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAppContext() {
/*  71 */     return this.appContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthContextID(MessageInfo messageInfo) {
/*  77 */     return messageInfo.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*  83 */     this.serverAuthContext = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProtected() {
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerAuthContext getAuthContext(String authContextID, Subject serviceSubject, Map<String, Object> properties) throws AuthException {
/*  96 */     ServerAuthContext serverAuthContext = this.serverAuthContext;
/*  97 */     if (serverAuthContext == null) {
/*  98 */       synchronized (this) {
/*  99 */         if (this.serverAuthContext == null) {
/* 100 */           Map<String, Object> mergedProperties = new HashMap<>();
/* 101 */           if (this.properties != null) {
/* 102 */             mergedProperties.putAll(this.properties);
/*     */           }
/* 104 */           if (properties != null) {
/* 105 */             mergedProperties.putAll(properties);
/*     */           }
/*     */           
/* 108 */           List<ServerAuthModule> modules = new ArrayList<>();
/* 109 */           int moduleIndex = 1;
/* 110 */           String key = "org.apache.catalina.authenticator.jaspic.ServerAuthModule." + moduleIndex;
/* 111 */           Object moduleClassName = mergedProperties.get(key);
/* 112 */           while (moduleClassName instanceof String) {
/*     */             try {
/* 114 */               Class<?> clazz = Class.forName((String)moduleClassName);
/* 115 */               ServerAuthModule module = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 116 */               module.initialize(null, null, this.handler, mergedProperties);
/* 117 */               modules.add(module);
/* 118 */             } catch (ReflectiveOperationException|IllegalArgumentException|SecurityException e) {
/* 119 */               throw new AuthException(e);
/*     */             } 
/*     */ 
/*     */             
/* 123 */             moduleIndex++;
/* 124 */             key = "org.apache.catalina.authenticator.jaspic.ServerAuthModule." + moduleIndex;
/* 125 */             moduleClassName = mergedProperties.get(key);
/*     */           } 
/*     */           
/* 128 */           if (modules.isEmpty()) {
/* 129 */             throw new AuthException(sm.getString("simpleServerAuthConfig.noModules"));
/*     */           }
/*     */           
/* 132 */           this.serverAuthContext = createServerAuthContext(modules);
/*     */         } 
/* 134 */         serverAuthContext = this.serverAuthContext;
/*     */       } 
/*     */     }
/*     */     
/* 138 */     return serverAuthContext;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ServerAuthContext createServerAuthContext(List<ServerAuthModule> modules) {
/* 143 */     return new SimpleServerAuthContext(modules);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\SimpleServerAuthConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */