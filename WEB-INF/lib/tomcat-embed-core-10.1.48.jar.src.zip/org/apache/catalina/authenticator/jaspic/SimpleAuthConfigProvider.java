/*    */ package org.apache.catalina.authenticator.jaspic;
/*    */ 
/*    */ import jakarta.security.auth.message.AuthException;
/*    */ import jakarta.security.auth.message.config.AuthConfigFactory;
/*    */ import jakarta.security.auth.message.config.AuthConfigProvider;
/*    */ import jakarta.security.auth.message.config.ClientAuthConfig;
/*    */ import jakarta.security.auth.message.config.ServerAuthConfig;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleAuthConfigProvider
/*    */   implements AuthConfigProvider
/*    */ {
/*    */   private final Map<String, Object> properties;
/*    */   private volatile ServerAuthConfig serverAuthConfig;
/*    */   
/*    */   public SimpleAuthConfigProvider(Map<String, Object> properties, AuthConfigFactory factory) {
/* 40 */     this.properties = properties;
/* 41 */     if (factory != null) {
/* 42 */       factory.registerConfigProvider(this, null, null, "Automatic registration");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientAuthConfig getClientAuthConfig(String layer, String appContext, CallbackHandler handler) throws AuthException {
/* 55 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerAuthConfig getServerAuthConfig(String layer, String appContext, CallbackHandler handler) throws AuthException {
/* 62 */     ServerAuthConfig serverAuthConfig = this.serverAuthConfig;
/* 63 */     if (serverAuthConfig == null) {
/* 64 */       synchronized (this) {
/* 65 */         if (this.serverAuthConfig == null) {
/* 66 */           this.serverAuthConfig = createServerAuthConfig(layer, appContext, handler, this.properties);
/*    */         }
/* 68 */         serverAuthConfig = this.serverAuthConfig;
/*    */       } 
/*    */     }
/* 71 */     return serverAuthConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ServerAuthConfig createServerAuthConfig(String layer, String appContext, CallbackHandler handler, Map<String, Object> properties) {
/* 77 */     return new SimpleServerAuthConfig(layer, appContext, handler, properties);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void refresh() {
/* 83 */     ServerAuthConfig serverAuthConfig = this.serverAuthConfig;
/* 84 */     if (serverAuthConfig != null)
/* 85 */       serverAuthConfig.refresh(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\SimpleAuthConfigProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */