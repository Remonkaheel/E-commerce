/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PersistentProviderRegistrations
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/*  48 */   private static final StringManager sm = StringManager.getManager(PersistentProviderRegistrations.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Providers loadProviders(File configFile) {
/*     */     
/*  57 */     try { InputStream is = new FileInputStream(configFile);
/*     */       
/*  59 */       try { Digester digester = new Digester();
/*     */         
/*     */         try {
/*  62 */           digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/*  63 */         } catch (SAXException se) {
/*  64 */           log.warn(sm.getString("persistentProviderRegistrations.xmlFeatureEncoding"), se);
/*     */         } 
/*     */         
/*  67 */         digester.setValidating(true);
/*  68 */         digester.setNamespaceAware(true);
/*     */ 
/*     */ 
/*     */         
/*  72 */         Providers result = new Providers();
/*  73 */         digester.push(result);
/*     */ 
/*     */         
/*  76 */         digester.addObjectCreate("jaspic-providers/provider", Provider.class.getName());
/*  77 */         digester.addSetProperties("jaspic-providers/provider");
/*  78 */         digester.addSetNext("jaspic-providers/provider", "addProvider", Provider.class.getName());
/*     */         
/*  80 */         digester.addObjectCreate("jaspic-providers/provider/property", Property.class.getName());
/*  81 */         digester.addSetProperties("jaspic-providers/provider/property");
/*  82 */         digester.addSetNext("jaspic-providers/provider/property", "addProperty", Property.class.getName());
/*     */ 
/*     */         
/*  85 */         digester.parse(is);
/*     */         
/*  87 */         Providers providers1 = result;
/*  88 */         is.close(); return providers1; } catch (Throwable throwable) { try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException|javax.xml.parsers.ParserConfigurationException|SAXException e)
/*  89 */     { throw new SecurityException(e); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeProviders(Providers providers, File configFile) {
/*  95 */     File configFileOld = new File(configFile.getAbsolutePath() + ".old");
/*  96 */     File configFileNew = new File(configFile.getAbsolutePath() + ".new");
/*  97 */     File configParent = configFileNew.getParentFile();
/*     */ 
/*     */     
/* 100 */     if (configFileOld.exists() && 
/* 101 */       !configFileOld.delete()) {
/* 102 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] { configFileOld
/* 103 */               .getAbsolutePath() }));
/*     */     }
/*     */     
/* 106 */     if (configFileNew.exists() && 
/* 107 */       !configFileNew.delete()) {
/* 108 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] { configFileNew
/* 109 */               .getAbsolutePath() }));
/*     */     }
/*     */     
/* 112 */     if (!configParent.exists() && 
/* 113 */       !configParent.mkdirs()) {
/* 114 */       throw new SecurityException(sm
/* 115 */           .getString("persistentProviderRegistrations.mkdirsFail", new Object[] { configParent.getAbsolutePath() }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 120 */     try { OutputStream fos = new FileOutputStream(configFileNew); 
/* 121 */       try { Writer writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8); 
/* 122 */         try { writer.write("<?xml version='1.0' encoding='utf-8'?>\n<jaspic-providers\n    xmlns=\"http://tomcat.apache.org/xml\"\n    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n    xsi:schemaLocation=\"http://tomcat.apache.org/xml jaspic-providers.xsd\"\n    version=\"1.0\">\n");
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 127 */           for (Provider provider : providers.providers) {
/* 128 */             writer.write("  <provider");
/* 129 */             writeOptional("className", provider.getClassName(), writer);
/* 130 */             writeOptional("layer", provider.getLayer(), writer);
/* 131 */             writeOptional("appContext", provider.getAppContext(), writer);
/* 132 */             writeOptional("description", provider.getDescription(), writer);
/* 133 */             writer.write(">\n");
/* 134 */             for (Map.Entry<String, String> entry : provider.getProperties().entrySet()) {
/* 135 */               writer.write("    <property name=\"");
/* 136 */               writer.write(entry.getKey());
/* 137 */               writer.write("\" value=\"");
/* 138 */               writer.write(entry.getValue());
/* 139 */               writer.write("\"/>\n");
/*     */             } 
/* 141 */             writer.write("  </provider>\n");
/*     */           } 
/* 143 */           writer.write("</jaspic-providers>\n");
/* 144 */           writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 145 */     { if (!configFileNew.delete()) {
/* 146 */         Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/* 147 */         log.warn(sm.getString("persistentProviderRegistrations.deleteFail", new Object[] { configFileNew.getAbsolutePath() }));
/*     */       } 
/* 149 */       throw new SecurityException(ioe); }
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (configFile.isFile() && 
/* 154 */       !configFile.renameTo(configFileOld)) {
/* 155 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] { configFile
/* 156 */               .getAbsolutePath(), configFileOld.getAbsolutePath() }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (!configFileNew.renameTo(configFile)) {
/* 162 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] { configFileNew
/* 163 */               .getAbsolutePath(), configFile.getAbsolutePath() }));
/*     */     }
/*     */ 
/*     */     
/* 167 */     if (configFileOld.exists() && !configFileOld.delete()) {
/* 168 */       Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/* 169 */       log.warn(sm.getString("persistentProviderRegistrations.deleteFail", new Object[] { configFileOld.getAbsolutePath() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void writeOptional(String name, String value, Writer writer) throws IOException {
/* 175 */     if (value != null) {
/* 176 */       writer.write(" " + name + "=\"");
/* 177 */       writer.write(value);
/* 178 */       writer.write("\"");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class Providers
/*     */   {
/* 184 */     private final List<PersistentProviderRegistrations.Provider> providers = new ArrayList<>();
/*     */     
/*     */     public void addProvider(PersistentProviderRegistrations.Provider provider) {
/* 187 */       this.providers.add(provider);
/*     */     }
/*     */     
/*     */     public List<PersistentProviderRegistrations.Provider> getProviders() {
/* 191 */       return this.providers;
/*     */     } }
/*     */   
/*     */   public static class Provider { private String className;
/*     */     private String layer;
/*     */     private String appContext;
/*     */     private String description;
/*     */     private final Map<String, String> properties;
/*     */     
/*     */     public Provider() {
/* 201 */       this.properties = new HashMap<>();
/*     */     }
/*     */     
/*     */     public String getClassName() {
/* 205 */       return this.className;
/*     */     }
/*     */     
/*     */     public void setClassName(String className) {
/* 209 */       this.className = className;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLayer() {
/* 214 */       return this.layer;
/*     */     }
/*     */     
/*     */     public void setLayer(String layer) {
/* 218 */       this.layer = layer;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAppContext() {
/* 223 */       return this.appContext;
/*     */     }
/*     */     
/*     */     public void setAppContext(String appContext) {
/* 227 */       this.appContext = appContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 232 */       return this.description;
/*     */     }
/*     */     
/*     */     public void setDescription(String description) {
/* 236 */       this.description = description;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addProperty(PersistentProviderRegistrations.Property property) {
/* 241 */       this.properties.put(property.getName(), property.getValue());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProperty(String name, String value) {
/* 253 */       addProperty(name, value);
/*     */     }
/*     */     
/*     */     void addProperty(String name, String value) {
/* 257 */       this.properties.put(name, value);
/*     */     }
/*     */     
/*     */     public Map<String, String> getProperties() {
/* 261 */       return this.properties;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Property
/*     */   {
/*     */     private String name;
/*     */     private String value;
/*     */     
/*     */     public String getName() {
/* 272 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(String name) {
/* 276 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 281 */       return this.value;
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 285 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\PersistentProviderRegistrations.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */