/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import jakarta.security.auth.message.callback.CallerPrincipalCallback;
/*     */ import jakarta.security.auth.message.callback.GroupPrincipalCallback;
/*     */ import jakarta.security.auth.message.callback.PasswordValidationCallback;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.realm.GenericPrincipal;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallbackHandlerImpl
/*     */   implements CallbackHandler, Contained
/*     */ {
/*  48 */   private static final StringManager sm = StringManager.getManager(CallbackHandlerImpl.class);
/*  49 */   private final Log log = LogFactory.getLog(CallbackHandlerImpl.class);
/*     */ 
/*     */   
/*     */   private Container container;
/*     */ 
/*     */ 
/*     */   
/*     */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/*  57 */     String name = null;
/*  58 */     Principal principal = null;
/*  59 */     Subject subject = null;
/*  60 */     String[] groups = null;
/*     */     
/*  62 */     if (callbacks != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       for (Callback callback : callbacks) {
/*  69 */         if (callback instanceof CallerPrincipalCallback) {
/*  70 */           CallerPrincipalCallback cpc = (CallerPrincipalCallback)callback;
/*  71 */           name = cpc.getName();
/*  72 */           if (cpc.getPrincipal() != null) {
/*  73 */             principal = cpc.getPrincipal();
/*     */           }
/*  75 */           subject = cpc.getSubject();
/*  76 */         } else if (callback instanceof GroupPrincipalCallback) {
/*  77 */           GroupPrincipalCallback gpc = (GroupPrincipalCallback)callback;
/*  78 */           groups = gpc.getGroups();
/*  79 */         } else if (callback instanceof PasswordValidationCallback) {
/*  80 */           if (this.container == null) {
/*  81 */             this.log.warn(sm.getString("callbackHandlerImpl.containerMissing", new Object[] { callback.getClass().getName() }));
/*  82 */           } else if (this.container.getRealm() == null) {
/*  83 */             this.log.warn(sm.getString("callbackHandlerImpl.realmMissing", new Object[] { callback.getClass().getName(), this.container
/*  84 */                     .getName() }));
/*     */           } else {
/*  86 */             PasswordValidationCallback pvc = (PasswordValidationCallback)callback;
/*     */             
/*  88 */             principal = this.container.getRealm().authenticate(pvc.getUsername(), String.valueOf(pvc.getPassword()));
/*  89 */             pvc.setResult((principal != null));
/*  90 */             subject = pvc.getSubject();
/*     */           } 
/*     */         } else {
/*  93 */           this.log.error(sm.getString("callbackHandlerImpl.jaspicCallbackMissing", new Object[] { callback.getClass().getName() }));
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  98 */       if (subject != null) {
/*     */ 
/*     */         
/* 101 */         if (name == null && principal != null) {
/* 102 */           name = principal.getName();
/*     */         }
/*     */         
/* 105 */         if (name != null)
/*     */         {
/* 107 */           if (principal instanceof GenericPrincipal) {
/*     */             
/* 109 */             subject.getPrivateCredentials().add(principal);
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 116 */             List<String> mergedRoles = new ArrayList<>();
/*     */             
/* 118 */             Set<GenericPrincipal> gps = subject.getPrivateCredentials(GenericPrincipal.class);
/* 119 */             if (!gps.isEmpty()) {
/* 120 */               GenericPrincipal gp = gps.iterator().next();
/* 121 */               mergedRoles.addAll(Arrays.asList(gp.getRoles()));
/*     */               
/* 123 */               subject.getPrivateCredentials().remove(gp);
/*     */             } 
/* 125 */             if (groups != null) {
/* 126 */               mergedRoles.addAll(Arrays.asList(groups));
/*     */             }
/*     */             
/* 129 */             if (mergedRoles.isEmpty()) {
/* 130 */               mergedRoles = Collections.emptyList();
/*     */             }
/*     */             
/* 133 */             subject.getPrivateCredentials().add(new GenericPrincipal(name, mergedRoles, principal));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/* 144 */     return this.container;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Container container) {
/* 150 */     this.container = container;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\jaspic\CallbackHandlerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */