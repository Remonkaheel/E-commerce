/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.Base64;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  40 */   private final Log log = LogFactory.getLog(BasicAuthenticator.class);
/*     */   
/*  42 */   private Charset charset = StandardCharsets.ISO_8859_1;
/*  43 */   private String charsetString = null;
/*     */   
/*     */   private boolean trimCredentials = false;
/*     */   
/*     */   public String getCharset() {
/*  48 */     return this.charsetString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(String charsetString) {
/*  54 */     if (charsetString == null || charsetString.isEmpty()) {
/*  55 */       this.charset = StandardCharsets.ISO_8859_1;
/*  56 */     } else if ("UTF-8".equalsIgnoreCase(charsetString)) {
/*  57 */       this.charset = StandardCharsets.UTF_8;
/*     */     } else {
/*  59 */       throw new IllegalArgumentException(sm.getString("basicAuthenticator.invalidCharset"));
/*     */     } 
/*  61 */     this.charsetString = charsetString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean getTrimCredentials() {
/*  74 */     return this.trimCredentials;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTrimCredentials(boolean trimCredentials) {
/*  87 */     this.trimCredentials = trimCredentials;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doAuthenticate(Request request, HttpServletResponse response) throws IOException {
/*  94 */     if (checkForCachedAuthentication(request, response, true)) {
/*  95 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  99 */     MessageBytes authorization = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/*     */     
/* 101 */     if (authorization != null) {
/* 102 */       authorization.toBytes();
/* 103 */       ByteChunk authorizationBC = authorization.getByteChunk();
/*     */       
/*     */       try {
/* 106 */         BasicCredentials credentials = new BasicCredentials(authorizationBC, this.charset, getTrimCredentials());
/* 107 */         String username = credentials.getUsername();
/* 108 */         String password = credentials.getPassword();
/*     */         
/* 110 */         Principal principal = this.context.getRealm().authenticate(username, password);
/* 111 */         if (principal != null) {
/* 112 */           register(request, response, principal, "BASIC", username, password);
/* 113 */           return true;
/*     */         } 
/* 115 */       } catch (IllegalArgumentException iae) {
/* 116 */         if (this.log.isDebugEnabled()) {
/* 117 */           this.log.debug(sm.getString("basicAuthenticator.invalidAuthorization"), iae);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 123 */     StringBuilder value = new StringBuilder(16);
/* 124 */     value.append("Basic realm=\"");
/* 125 */     value.append(getRealmName(this.context));
/* 126 */     value.append('"');
/* 127 */     if (this.charsetString != null && !this.charsetString.isEmpty()) {
/* 128 */       value.append(", charset=");
/* 129 */       value.append(this.charsetString);
/*     */     } 
/* 131 */     response.setHeader("WWW-Authenticate", value.toString());
/* 132 */     response.sendError(401);
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAuthMethod() {
/* 140 */     return "BASIC";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPreemptiveAuthPossible(Request request) {
/* 146 */     MessageBytes authorizationHeader = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/* 147 */     return (authorizationHeader != null && authorizationHeader.startsWithIgnoreCase("basic ", 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BasicCredentials
/*     */   {
/*     */     private static final String METHOD = "basic ";
/*     */     
/*     */     private final Charset charset;
/*     */     
/*     */     private final boolean trimCredentials;
/*     */     
/*     */     private final ByteChunk authorization;
/*     */     
/*     */     private final int initialOffset;
/*     */     
/*     */     private int base64blobOffset;
/*     */     
/*     */     private int base64blobLength;
/*     */     
/* 168 */     private String username = null;
/* 169 */     private String password = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BasicCredentials(ByteChunk input, Charset charset) throws IllegalArgumentException {
/* 180 */       this(input, charset, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public BasicCredentials(ByteChunk input, Charset charset, boolean trimCredentials) throws IllegalArgumentException {
/* 197 */       this.authorization = input;
/* 198 */       this.initialOffset = input.getStart();
/* 199 */       this.charset = charset;
/* 200 */       this.trimCredentials = trimCredentials;
/*     */       
/* 202 */       parseMethod();
/* 203 */       byte[] decoded = parseBase64();
/* 204 */       parseCredentials(decoded);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 213 */       return this.username;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 223 */       return this.password;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void parseMethod() throws IllegalArgumentException {
/* 230 */       if (this.authorization.startsWithIgnoreCase("basic ", 0)) {
/*     */         
/* 232 */         this.base64blobOffset = this.initialOffset + "basic ".length();
/* 233 */         this.base64blobLength = this.authorization.getLength() - "basic ".length();
/*     */       } else {
/*     */         
/* 236 */         throw new IllegalArgumentException(AuthenticatorBase.sm.getString("basicAuthenticator.notBasic"));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private byte[] parseBase64() throws IllegalArgumentException {
/* 246 */       byte[] encoded = new byte[this.base64blobLength];
/* 247 */       System.arraycopy(this.authorization.getBuffer(), this.base64blobOffset, encoded, 0, this.base64blobLength);
/* 248 */       byte[] decoded = Base64.getDecoder().decode(encoded);
/*     */       
/* 250 */       this.authorization.setStart(this.initialOffset);
/* 251 */       if (decoded == null) {
/* 252 */         throw new IllegalArgumentException(AuthenticatorBase.sm.getString("basicAuthenticator.notBase64"));
/*     */       }
/* 254 */       return decoded;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void parseCredentials(byte[] decoded) throws IllegalArgumentException {
/* 263 */       int colon = -1;
/* 264 */       for (int i = 0; i < decoded.length; i++) {
/* 265 */         if (decoded[i] == 58) {
/* 266 */           colon = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 271 */       if (colon < 0) {
/* 272 */         this.username = new String(decoded, this.charset);
/*     */       } else {
/*     */         
/* 275 */         this.username = new String(decoded, 0, colon, this.charset);
/* 276 */         this.password = new String(decoded, colon + 1, decoded.length - colon - 1, this.charset);
/*     */         
/* 278 */         if (this.password.length() > 1 && this.trimCredentials) {
/* 279 */           this.password = this.password.trim();
/*     */         }
/*     */       } 
/*     */       
/* 283 */       if (this.username.length() > 1 && this.trimCredentials)
/* 284 */         this.username = this.username.trim(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\BasicAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */