/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NonLoginAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*     */   protected boolean doAuthenticate(Request request, HttpServletResponse response) throws IOException {
/*  77 */     if (checkForCachedAuthentication(request, response, true)) {
/*     */ 
/*     */       
/*  80 */       if (this.cache) {
/*  81 */         request.getSessionInternal(true).setPrincipal(request.getPrincipal());
/*     */       }
/*  83 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (this.containerLog.isTraceEnabled()) {
/*  92 */       this.containerLog.trace("User authenticated without any roles");
/*     */     }
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAuthMethod() {
/* 100 */     return "NONE";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\authenticator\NonLoginAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */