package org.apache.catalina;

public interface Engine extends Container {
  String getDefaultHost();
  
  void setDefaultHost(String paramString);
  
  String getJvmRoute();
  
  void setJvmRoute(String paramString);
  
  Service getService();
  
  void setService(Service paramService);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Engine.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */