package org.apache.catalina;

import java.beans.PropertyChangeListener;

public interface Loader {
  void backgroundProcess();
  
  ClassLoader getClassLoader();
  
  Context getContext();
  
  void setContext(Context paramContext);
  
  boolean getDelegate();
  
  void setDelegate(boolean paramBoolean);
  
  void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  boolean modified();
  
  void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Loader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */