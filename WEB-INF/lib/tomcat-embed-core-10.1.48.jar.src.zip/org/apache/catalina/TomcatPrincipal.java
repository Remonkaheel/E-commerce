package org.apache.catalina;

import java.security.Principal;
import java.util.Enumeration;
import org.ietf.jgss.GSSCredential;

public interface TomcatPrincipal extends Principal {
  Principal getUserPrincipal();
  
  GSSCredential getGssCredential();
  
  void logout() throws Exception;
  
  Object getAttribute(String paramString);
  
  Enumeration<String> getAttributeNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\TomcatPrincipal.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */