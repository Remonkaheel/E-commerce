package org.apache.catalina;

import java.io.File;
import java.util.concurrent.ScheduledExecutorService;
import javax.naming.Context;
import org.apache.catalina.deploy.NamingResourcesImpl;
import org.apache.catalina.startup.Catalina;

public interface Server extends Lifecycle {
  NamingResourcesImpl getGlobalNamingResources();
  
  void setGlobalNamingResources(NamingResourcesImpl paramNamingResourcesImpl);
  
  Context getGlobalNamingContext();
  
  int getPort();
  
  void setPort(int paramInt);
  
  int getPortOffset();
  
  void setPortOffset(int paramInt);
  
  int getPortWithOffset();
  
  String getAddress();
  
  void setAddress(String paramString);
  
  String getShutdown();
  
  void setShutdown(String paramString);
  
  ClassLoader getParentClassLoader();
  
  void setParentClassLoader(ClassLoader paramClassLoader);
  
  Catalina getCatalina();
  
  void setCatalina(Catalina paramCatalina);
  
  File getCatalinaBase();
  
  void setCatalinaBase(File paramFile);
  
  File getCatalinaHome();
  
  void setCatalinaHome(File paramFile);
  
  int getUtilityThreads();
  
  void setUtilityThreads(int paramInt);
  
  void addService(Service paramService);
  
  void await();
  
  Service findService(String paramString);
  
  Service[] findServices();
  
  void removeService(Service paramService);
  
  Object getNamingToken();
  
  ScheduledExecutorService getUtilityExecutor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Server.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */