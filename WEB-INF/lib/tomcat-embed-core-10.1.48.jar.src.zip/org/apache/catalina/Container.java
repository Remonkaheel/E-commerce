/*     */ package org.apache.catalina;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.File;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Container
/*     */   extends Lifecycle
/*     */ {
/*     */   public static final String ADD_CHILD_EVENT = "addChild";
/*     */   public static final String ADD_VALVE_EVENT = "addValve";
/*     */   public static final String REMOVE_CHILD_EVENT = "removeChild";
/*     */   public static final String REMOVE_VALVE_EVENT = "removeValve";
/*     */   
/*     */   Log getLogger();
/*     */   
/*     */   String getLogName();
/*     */   
/*     */   ObjectName getObjectName();
/*     */   
/*     */   String getDomain();
/*     */   
/*     */   String getMBeanKeyProperties();
/*     */   
/*     */   Pipeline getPipeline();
/*     */   
/*     */   Cluster getCluster();
/*     */   
/*     */   void setCluster(Cluster paramCluster);
/*     */   
/*     */   int getBackgroundProcessorDelay();
/*     */   
/*     */   void setBackgroundProcessorDelay(int paramInt);
/*     */   
/*     */   String getName();
/*     */   
/*     */   void setName(String paramString);
/*     */   
/*     */   Container getParent();
/*     */   
/*     */   void setParent(Container paramContainer);
/*     */   
/*     */   ClassLoader getParentClassLoader();
/*     */   
/*     */   void setParentClassLoader(ClassLoader paramClassLoader);
/*     */   
/*     */   Realm getRealm();
/*     */   
/*     */   void setRealm(Realm paramRealm);
/*     */   
/*     */   static String getConfigPath(Container container, String resourceName) {
/* 273 */     StringBuilder result = new StringBuilder();
/* 274 */     Container host = null;
/* 275 */     Container engine = null;
/* 276 */     while (container != null) {
/* 277 */       if (container instanceof Host) {
/* 278 */         host = container;
/* 279 */       } else if (container instanceof Engine) {
/* 280 */         engine = container;
/*     */       } 
/* 282 */       container = container.getParent();
/*     */     } 
/* 284 */     if (host != null && ((Host)host).getXmlBase() != null) {
/* 285 */       result.append(((Host)host).getXmlBase()).append('/');
/*     */     } else {
/* 287 */       result.append("conf/");
/* 288 */       if (engine != null) {
/* 289 */         result.append(engine.getName()).append('/');
/*     */       }
/* 291 */       if (host != null) {
/* 292 */         result.append(host.getName()).append('/');
/*     */       }
/*     */     } 
/* 295 */     result.append(resourceName);
/* 296 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Service getService(Container container) {
/* 308 */     while (container != null && !(container instanceof Engine)) {
/* 309 */       container = container.getParent();
/*     */     }
/* 311 */     if (container == null) {
/* 312 */       return null;
/*     */     }
/* 314 */     return ((Engine)container).getService();
/*     */   }
/*     */   
/*     */   void backgroundProcess();
/*     */   
/*     */   void addChild(Container paramContainer);
/*     */   
/*     */   void addContainerListener(ContainerListener paramContainerListener);
/*     */   
/*     */   void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/*     */   
/*     */   Container findChild(String paramString);
/*     */   
/*     */   Container[] findChildren();
/*     */   
/*     */   ContainerListener[] findContainerListeners();
/*     */   
/*     */   void removeChild(Container paramContainer);
/*     */   
/*     */   void removeContainerListener(ContainerListener paramContainerListener);
/*     */   
/*     */   void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/*     */   
/*     */   void fireContainerEvent(String paramString, Object paramObject);
/*     */   
/*     */   void logAccess(Request paramRequest, Response paramResponse, long paramLong, boolean paramBoolean);
/*     */   
/*     */   AccessLog getAccessLog();
/*     */   
/*     */   int getStartStopThreads();
/*     */   
/*     */   void setStartStopThreads(int paramInt);
/*     */   
/*     */   File getCatalinaBase();
/*     */   
/*     */   File getCatalinaHome();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Container.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */