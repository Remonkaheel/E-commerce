/*      */ package org.apache.catalina.mapper;
/*      */ 
/*      */ import jakarta.servlet.http.MappingMatch;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.Ascii;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Mapper
/*      */ {
/*   48 */   private static final Log log = LogFactory.getLog(Mapper.class);
/*      */   
/*   50 */   private static final StringManager sm = StringManager.getManager(Mapper.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   59 */   volatile MappedHost[] hosts = new MappedHost[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   private volatile String defaultHostName = null;
/*   66 */   private volatile MappedHost defaultHost = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   private final Map<Context, ContextVersion> contextObjectToContextVersionMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultHostName(String defaultHostName) {
/*   83 */     this.defaultHostName = renameWildcardHost(defaultHostName);
/*   84 */     if (this.defaultHostName == null) {
/*   85 */       this.defaultHost = null;
/*      */     } else {
/*   87 */       this.defaultHost = exactFind(this.hosts, this.defaultHostName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addHost(String name, String[] aliases, Host host) {
/*  100 */     name = renameWildcardHost(name);
/*  101 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*  102 */     MappedHost newHost = new MappedHost(name, host);
/*  103 */     if (insertMap((MapElement<?>[])this.hosts, (MapElement<?>[])newHosts, newHost)) {
/*  104 */       this.hosts = newHosts;
/*  105 */       if (newHost.name.equals(this.defaultHostName)) {
/*  106 */         this.defaultHost = newHost;
/*      */       }
/*  108 */       if (log.isDebugEnabled()) {
/*  109 */         log.debug(sm.getString("mapper.addHost.success", new Object[] { name }));
/*      */       }
/*      */     } else {
/*  112 */       MappedHost duplicate = this.hosts[find((MapElement<T>[])this.hosts, name)];
/*  113 */       if (duplicate.object == host) {
/*      */ 
/*      */         
/*  116 */         if (log.isDebugEnabled()) {
/*  117 */           log.debug(sm.getString("mapper.addHost.sameHost", new Object[] { name }));
/*      */         }
/*  119 */         newHost = duplicate;
/*      */       } else {
/*  121 */         log.error(sm.getString("mapper.duplicateHost", new Object[] { name, duplicate.getRealHostName() }));
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  127 */     List<MappedHost> newAliases = new ArrayList<>(aliases.length);
/*  128 */     for (String alias : aliases) {
/*  129 */       alias = renameWildcardHost(alias);
/*  130 */       MappedHost newAlias = new MappedHost(alias, newHost);
/*  131 */       if (addHostAliasImpl(newAlias)) {
/*  132 */         newAliases.add(newAlias);
/*      */       }
/*      */     } 
/*  135 */     newHost.addAliases(newAliases);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeHost(String name) {
/*  145 */     name = renameWildcardHost(name);
/*      */     
/*  147 */     MappedHost host = exactFind(this.hosts, name);
/*  148 */     if (host == null || host.isAlias()) {
/*      */       return;
/*      */     }
/*  151 */     MappedHost[] newHosts = (MappedHost[])this.hosts.clone();
/*      */     
/*  153 */     int j = 0;
/*  154 */     for (int i = 0; i < newHosts.length; i++) {
/*  155 */       if (newHosts[i].getRealHost() != host) {
/*  156 */         newHosts[j++] = newHosts[i];
/*      */       }
/*      */     } 
/*  159 */     this.hosts = Arrays.<MappedHost>copyOf(newHosts, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addHostAlias(String name, String alias) {
/*  169 */     MappedHost realHost = exactFind(this.hosts, name);
/*  170 */     if (realHost == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  175 */     alias = renameWildcardHost(alias);
/*  176 */     MappedHost newAlias = new MappedHost(alias, realHost);
/*  177 */     if (addHostAliasImpl(newAlias)) {
/*  178 */       realHost.addAlias(newAlias);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized boolean addHostAliasImpl(MappedHost newAlias) {
/*  183 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*  184 */     if (insertMap((MapElement<?>[])this.hosts, (MapElement<?>[])newHosts, newAlias)) {
/*  185 */       this.hosts = newHosts;
/*  186 */       if (newAlias.name.equals(this.defaultHostName)) {
/*  187 */         this.defaultHost = newAlias;
/*      */       }
/*  189 */       if (log.isDebugEnabled()) {
/*  190 */         log.debug(sm.getString("mapper.addHostAlias.success", new Object[] { newAlias.name, newAlias.getRealHostName() }));
/*      */       }
/*  192 */       return true;
/*      */     } 
/*  194 */     MappedHost duplicate = this.hosts[find((MapElement<T>[])this.hosts, newAlias.name)];
/*  195 */     if (duplicate.getRealHost() == newAlias.getRealHost()) {
/*      */ 
/*      */ 
/*      */       
/*  199 */       if (log.isDebugEnabled()) {
/*  200 */         log.debug(sm.getString("mapper.addHostAlias.sameHost", new Object[] { newAlias.name, newAlias.getRealHostName() }));
/*      */       }
/*  202 */       return false;
/*      */     } 
/*  204 */     log.error(sm.getString("mapper.duplicateHostAlias", new Object[] { newAlias.name, newAlias.getRealHostName(), duplicate
/*  205 */             .getRealHostName() }));
/*  206 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeHostAlias(String alias) {
/*  216 */     alias = renameWildcardHost(alias);
/*      */     
/*  218 */     MappedHost hostMapping = exactFind(this.hosts, alias);
/*  219 */     if (hostMapping == null || !hostMapping.isAlias()) {
/*      */       return;
/*      */     }
/*  222 */     MappedHost[] newHosts = new MappedHost[this.hosts.length - 1];
/*  223 */     if (removeMap((MapElement<?>[])this.hosts, (MapElement<?>[])newHosts, alias)) {
/*  224 */       this.hosts = newHosts;
/*  225 */       hostMapping.getRealHost().removeAlias(hostMapping);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateContextList(MappedHost realHost, ContextList newContextList) {
/*  235 */     realHost.contextList = newContextList;
/*  236 */     for (MappedHost alias : realHost.getAliases()) {
/*  237 */       alias.contextList = newContextList;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addContextVersion(String hostName, Host host, String path, String version, Context context, String[] welcomeResources, WebResourceRoot resources, Collection<WrapperMappingInfo> wrappers) {
/*  256 */     hostName = renameWildcardHost(hostName);
/*      */     
/*  258 */     MappedHost mappedHost = exactFind(this.hosts, hostName);
/*  259 */     if (mappedHost == null) {
/*  260 */       addHost(hostName, new String[0], host);
/*  261 */       mappedHost = exactFind(this.hosts, hostName);
/*  262 */       if (mappedHost == null) {
/*  263 */         log.error(sm.getString("mapper.addContext.noHost", new Object[] { hostName }));
/*      */         return;
/*      */       } 
/*      */     } 
/*  267 */     if (mappedHost.isAlias()) {
/*  268 */       log.error(sm.getString("mapper.addContext.hostIsAlias", new Object[] { hostName }));
/*      */       return;
/*      */     } 
/*  271 */     int slashCount = slashCount(path);
/*  272 */     synchronized (mappedHost) {
/*  273 */       ContextVersion newContextVersion = new ContextVersion(version, path, slashCount, context, resources, welcomeResources);
/*      */       
/*  275 */       if (wrappers != null) {
/*  276 */         addWrappers(newContextVersion, wrappers);
/*      */       }
/*      */       
/*  279 */       ContextList contextList = mappedHost.contextList;
/*  280 */       MappedContext mappedContext = exactFind(contextList.contexts, path);
/*  281 */       if (mappedContext == null) {
/*  282 */         mappedContext = new MappedContext(path, newContextVersion);
/*  283 */         ContextList newContextList = contextList.addContext(mappedContext, slashCount);
/*  284 */         if (newContextList != null) {
/*  285 */           updateContextList(mappedHost, newContextList);
/*  286 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         } 
/*      */       } else {
/*  289 */         ContextVersion[] contextVersions = mappedContext.versions;
/*  290 */         ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length + 1];
/*  291 */         if (insertMap((MapElement<?>[])contextVersions, (MapElement<?>[])newContextVersions, newContextVersion)) {
/*  292 */           mappedContext.versions = newContextVersions;
/*  293 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         }
/*      */         else {
/*      */           
/*  297 */           int pos = find((MapElement<?>[])contextVersions, version);
/*  298 */           if (pos >= 0 && (contextVersions[pos]).name.equals(version)) {
/*  299 */             contextVersions[pos] = newContextVersion;
/*  300 */             this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeContextVersion(Context ctxt, String hostName, String path, String version) {
/*  319 */     hostName = renameWildcardHost(hostName);
/*  320 */     this.contextObjectToContextVersionMap.remove(ctxt);
/*      */     
/*  322 */     MappedHost host = exactFind(this.hosts, hostName);
/*  323 */     if (host == null || host.isAlias()) {
/*      */       return;
/*      */     }
/*      */     
/*  327 */     synchronized (host) {
/*  328 */       ContextList contextList = host.contextList;
/*  329 */       MappedContext context = exactFind(contextList.contexts, path);
/*  330 */       if (context == null) {
/*      */         return;
/*      */       }
/*      */       
/*  334 */       ContextVersion[] contextVersions = context.versions;
/*  335 */       ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length - 1];
/*  336 */       if (removeMap((MapElement<?>[])contextVersions, (MapElement<?>[])newContextVersions, version)) {
/*  337 */         if (newContextVersions.length == 0) {
/*      */           
/*  339 */           ContextList newContextList = contextList.removeContext(path);
/*  340 */           if (newContextList != null) {
/*  341 */             updateContextList(host, newContextList);
/*      */           }
/*      */         } else {
/*  344 */           context.versions = newContextVersions;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pauseContextVersion(Context ctxt, String hostName, String contextPath, String version) {
/*  361 */     hostName = renameWildcardHost(hostName);
/*  362 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*  363 */     if (contextVersion == null || !ctxt.equals(contextVersion.object)) {
/*      */       return;
/*      */     }
/*  366 */     contextVersion.markPaused();
/*      */   }
/*      */ 
/*      */   
/*      */   private ContextVersion findContextVersion(String hostName, String contextPath, String version, boolean silent) {
/*  371 */     MappedHost host = exactFind(this.hosts, hostName);
/*  372 */     if (host == null || host.isAlias()) {
/*  373 */       if (!silent) {
/*  374 */         log.error(sm.getString("mapper.findContext.noHostOrAlias", new Object[] { hostName }));
/*      */       }
/*  376 */       return null;
/*      */     } 
/*  378 */     MappedContext context = exactFind(host.contextList.contexts, contextPath);
/*  379 */     if (context == null) {
/*  380 */       if (!silent) {
/*  381 */         log.error(sm.getString("mapper.findContext.noContext", new Object[] { contextPath }));
/*      */       }
/*  383 */       return null;
/*      */     } 
/*  385 */     ContextVersion contextVersion = exactFind(context.versions, version);
/*  386 */     if (contextVersion == null) {
/*  387 */       if (!silent) {
/*  388 */         log.error(sm.getString("mapper.findContext.noContextVersion", new Object[] { contextPath, version }));
/*      */       }
/*  390 */       return null;
/*      */     } 
/*  392 */     return contextVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWrapper(String hostName, String contextPath, String version, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly) {
/*  398 */     hostName = renameWildcardHost(hostName);
/*  399 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  400 */     if (contextVersion == null) {
/*      */       return;
/*      */     }
/*  403 */     addWrapper(contextVersion, path, wrapper, jspWildCard, resourceOnly);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addWrappers(String hostName, String contextPath, String version, Collection<WrapperMappingInfo> wrappers) {
/*  408 */     hostName = renameWildcardHost(hostName);
/*  409 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  410 */     if (contextVersion == null) {
/*      */       return;
/*      */     }
/*  413 */     addWrappers(contextVersion, wrappers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addWrappers(ContextVersion contextVersion, Collection<WrapperMappingInfo> wrappers) {
/*  423 */     for (WrapperMappingInfo wrapper : wrappers) {
/*  424 */       addWrapper(contextVersion, wrapper.getMapping(), wrapper.getWrapper(), wrapper.isJspWildCard(), wrapper
/*  425 */           .isResourceOnly());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addWrapper(ContextVersion context, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly) {
/*  442 */     synchronized (context) {
/*  443 */       if (path.endsWith("/*")) {
/*      */         
/*  445 */         String name = path.substring(0, path.length() - 2);
/*  446 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*  447 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  448 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  449 */         if (insertMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, newWrapper)) {
/*  450 */           context.wildcardWrappers = newWrappers;
/*  451 */           int slashCount = slashCount(newWrapper.name);
/*  452 */           if (slashCount > context.nesting) {
/*  453 */             context.nesting = slashCount;
/*      */           }
/*      */         } 
/*  456 */       } else if (path.startsWith("*.")) {
/*      */         
/*  458 */         String name = path.substring(2);
/*  459 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*  460 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  461 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  462 */         if (insertMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, newWrapper)) {
/*  463 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  465 */       } else if (path.equals("/")) {
/*      */         
/*  467 */         context.defaultWrapper = new MappedWrapper("", wrapper, jspWildCard, resourceOnly);
/*      */       } else {
/*      */         String name;
/*      */         
/*  471 */         if (path.isEmpty()) {
/*      */ 
/*      */           
/*  474 */           name = "/";
/*      */         } else {
/*  476 */           name = path;
/*      */         } 
/*  478 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*  479 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  480 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  481 */         if (insertMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, newWrapper)) {
/*  482 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWrapper(String hostName, String contextPath, String version, String path) {
/*  498 */     hostName = renameWildcardHost(hostName);
/*  499 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*  500 */     if (contextVersion == null || contextVersion.isPaused()) {
/*      */       return;
/*      */     }
/*  503 */     removeWrapper(contextVersion, path);
/*      */   }
/*      */ 
/*      */   
/*      */   private void removeWrapper(ContextVersion context, String path) {
/*  508 */     if (log.isTraceEnabled()) {
/*  509 */       log.trace(sm.getString("mapper.removeWrapper", new Object[] { context.name, path }));
/*      */     }
/*      */     
/*  512 */     synchronized (context) {
/*  513 */       if (path.endsWith("/*")) {
/*      */         
/*  515 */         String name = path.substring(0, path.length() - 2);
/*  516 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  517 */         if (oldWrappers.length == 0) {
/*      */           return;
/*      */         }
/*  520 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*  521 */         if (removeMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, name)) {
/*      */           
/*  523 */           context.nesting = 0;
/*  524 */           for (MappedWrapper newWrapper : newWrappers) {
/*  525 */             int slashCount = slashCount(newWrapper.name);
/*  526 */             if (slashCount > context.nesting) {
/*  527 */               context.nesting = slashCount;
/*      */             }
/*      */           } 
/*  530 */           context.wildcardWrappers = newWrappers;
/*      */         } 
/*  532 */       } else if (path.startsWith("*.")) {
/*      */         
/*  534 */         String name = path.substring(2);
/*  535 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  536 */         if (oldWrappers.length == 0) {
/*      */           return;
/*      */         }
/*  539 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*  540 */         if (removeMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, name)) {
/*  541 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  543 */       } else if (path.equals("/")) {
/*      */         
/*  545 */         context.defaultWrapper = null;
/*      */       } else {
/*      */         String name;
/*      */         
/*  549 */         if (path.isEmpty()) {
/*      */ 
/*      */           
/*  552 */           name = "/";
/*      */         } else {
/*  554 */           name = path;
/*      */         } 
/*  556 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  557 */         if (oldWrappers.length == 0) {
/*      */           return;
/*      */         }
/*  560 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*  561 */         if (removeMap((MapElement<?>[])oldWrappers, (MapElement<?>[])newWrappers, name)) {
/*  562 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addWelcomeFile(String hostName, String contextPath, String version, String welcomeFile) {
/*  578 */     hostName = renameWildcardHost(hostName);
/*  579 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  580 */     if (contextVersion == null) {
/*      */       return;
/*      */     }
/*  583 */     int len = contextVersion.welcomeResources.length + 1;
/*  584 */     String[] newWelcomeResources = new String[len];
/*  585 */     System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, len - 1);
/*  586 */     newWelcomeResources[len - 1] = welcomeFile;
/*  587 */     contextVersion.welcomeResources = newWelcomeResources;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeWelcomeFile(String hostName, String contextPath, String version, String welcomeFile) {
/*  600 */     hostName = renameWildcardHost(hostName);
/*  601 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  602 */     if (contextVersion == null || contextVersion.isPaused()) {
/*      */       return;
/*      */     }
/*  605 */     int match = -1;
/*  606 */     for (int i = 0; i < contextVersion.welcomeResources.length; i++) {
/*  607 */       if (welcomeFile.equals(contextVersion.welcomeResources[i])) {
/*  608 */         match = i;
/*      */         break;
/*      */       } 
/*      */     } 
/*  612 */     if (match > -1) {
/*  613 */       int len = contextVersion.welcomeResources.length - 1;
/*  614 */       String[] newWelcomeResources = new String[len];
/*  615 */       System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, match);
/*  616 */       if (match < len) {
/*  617 */         System.arraycopy(contextVersion.welcomeResources, match + 1, newWelcomeResources, match, len - match);
/*      */       }
/*  619 */       contextVersion.welcomeResources = newWelcomeResources;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWelcomeFiles(String hostName, String contextPath, String version) {
/*  632 */     hostName = renameWildcardHost(hostName);
/*  633 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  634 */     if (contextVersion == null) {
/*      */       return;
/*      */     }
/*  637 */     contextVersion.welcomeResources = new String[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void map(MessageBytes host, MessageBytes uri, String version, MappingData mappingData) throws IOException {
/*  653 */     if (host.isNull()) {
/*  654 */       String defaultHostName = this.defaultHostName;
/*  655 */       if (defaultHostName == null) {
/*      */         return;
/*      */       }
/*  658 */       host.setChars(MessageBytes.EMPTY_CHAR_ARRAY, 0, 0);
/*  659 */       host.getCharChunk().append(defaultHostName);
/*      */     } 
/*  661 */     host.toChars();
/*  662 */     uri.toChars();
/*  663 */     internalMap(host.getCharChunk(), uri.getCharChunk(), version, mappingData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void map(Context context, MessageBytes uri, MappingData mappingData) throws IOException {
/*  678 */     ContextVersion contextVersion = this.contextObjectToContextVersionMap.get(context);
/*  679 */     uri.toChars();
/*  680 */     CharChunk uricc = uri.getCharChunk();
/*  681 */     uricc.setLimit(-1);
/*  682 */     internalMapWrapper(contextVersion, uricc, mappingData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalMap(CharChunk host, CharChunk uri, String version, MappingData mappingData) throws IOException {
/*  696 */     if (mappingData.host != null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  701 */       throw new AssertionError();
/*      */     }
/*      */ 
/*      */     
/*  705 */     MappedHost[] hosts = this.hosts;
/*  706 */     MappedHost mappedHost = exactFindIgnoreCase(hosts, host);
/*  707 */     if (mappedHost == null) {
/*      */ 
/*      */       
/*  710 */       int firstDot = host.indexOf('.');
/*  711 */       if (firstDot > -1) {
/*  712 */         int start = host.getStart();
/*      */         try {
/*  714 */           host.setStart(firstDot + start);
/*  715 */           mappedHost = exactFindIgnoreCase(hosts, host);
/*      */         } finally {
/*      */           
/*  718 */           host.setStart(start);
/*      */         } 
/*      */       } 
/*  721 */       if (mappedHost == null) {
/*  722 */         mappedHost = this.defaultHost;
/*  723 */         if (mappedHost == null) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     } 
/*  728 */     mappingData.host = mappedHost.object;
/*      */     
/*  730 */     if (uri.isNull()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  735 */     uri.setLimit(-1);
/*      */ 
/*      */     
/*  738 */     ContextList contextList = mappedHost.contextList;
/*  739 */     MappedContext[] contexts = contextList.contexts;
/*  740 */     int pos = find((MapElement<?>[])contexts, uri);
/*  741 */     if (pos == -1) {
/*      */       return;
/*      */     }
/*      */     
/*  745 */     int lastSlash = -1;
/*  746 */     int uriEnd = uri.getEnd();
/*  747 */     boolean found = false;
/*  748 */     MappedContext context = null;
/*  749 */     while (pos >= 0) {
/*  750 */       context = contexts[pos];
/*  751 */       if (uri.startsWith(context.name)) {
/*  752 */         int length = context.name.length();
/*  753 */         if (uri.getLength() == length) {
/*  754 */           found = true; break;
/*      */         } 
/*  756 */         if (uri.startsWithIgnoreCase("/", length)) {
/*  757 */           found = true;
/*      */           break;
/*      */         } 
/*      */       } 
/*  761 */       if (lastSlash == -1) {
/*  762 */         lastSlash = nthSlash(uri, contextList.nesting + 1);
/*      */       } else {
/*  764 */         lastSlash = lastSlash(uri);
/*      */       } 
/*  766 */       uri.setEnd(lastSlash);
/*  767 */       pos = find((MapElement<?>[])contexts, uri);
/*      */     } 
/*  769 */     uri.setEnd(uriEnd);
/*      */     
/*  771 */     if (!found) {
/*  772 */       if ((contexts[0]).name.isEmpty()) {
/*  773 */         context = contexts[0];
/*      */       } else {
/*  775 */         context = null;
/*      */       } 
/*      */     }
/*  778 */     if (context == null) {
/*      */       return;
/*      */     }
/*      */     
/*  782 */     ContextVersion contextVersion = null;
/*  783 */     ContextVersion[] contextVersions = context.versions;
/*  784 */     int versionCount = contextVersions.length;
/*  785 */     if (versionCount > 1) {
/*  786 */       Context[] contextObjects = new Context[contextVersions.length];
/*  787 */       for (int i = 0; i < contextObjects.length; i++) {
/*  788 */         contextObjects[i] = (contextVersions[i]).object;
/*      */       }
/*  790 */       mappingData.contexts = contextObjects;
/*  791 */       if (version != null) {
/*  792 */         contextVersion = exactFind(contextVersions, version);
/*      */       }
/*      */     } 
/*  795 */     if (contextVersion == null)
/*      */     {
/*      */       
/*  798 */       contextVersion = contextVersions[versionCount - 1];
/*      */     }
/*  800 */     mappingData.context = contextVersion.object;
/*  801 */     mappingData.contextSlashCount = contextVersion.slashCount;
/*      */ 
/*      */     
/*  804 */     if (!contextVersion.isPaused()) {
/*  805 */       internalMapWrapper(contextVersion, uri, mappingData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalMapWrapper(ContextVersion contextVersion, CharChunk path, MappingData mappingData) throws IOException {
/*  819 */     int pathStart = path.getStart();
/*  820 */     int pathEnd = path.getEnd();
/*  821 */     boolean noServletPath = false;
/*      */     
/*  823 */     int length = contextVersion.path.length();
/*  824 */     if (length == pathEnd - pathStart) {
/*  825 */       noServletPath = true;
/*      */     }
/*  827 */     int servletPath = pathStart + length;
/*  828 */     path.setStart(servletPath);
/*      */ 
/*      */     
/*  831 */     MappedWrapper[] exactWrappers = contextVersion.exactWrappers;
/*  832 */     internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */ 
/*      */     
/*  835 */     boolean checkJspWelcomeFiles = false;
/*  836 */     MappedWrapper[] wildcardWrappers = contextVersion.wildcardWrappers;
/*  837 */     if (mappingData.wrapper == null) {
/*  838 */       internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*  839 */       if (mappingData.wrapper != null && mappingData.jspWildCard) {
/*  840 */         char[] buf = path.getBuffer();
/*  841 */         if (buf[pathEnd - 1] == '/') {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  847 */           mappingData.wrapper = null;
/*  848 */           checkJspWelcomeFiles = true;
/*      */         } else {
/*      */           
/*  851 */           mappingData.wrapperPath.setChars(buf, path.getStart(), path.getLength());
/*  852 */           mappingData.pathInfo.recycle();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  857 */     if (mappingData.wrapper == null && noServletPath && contextVersion.object
/*  858 */       .getMapperContextRootRedirectEnabled()) {
/*      */       
/*  860 */       path.append('/');
/*  861 */       pathEnd = path.getEnd();
/*  862 */       mappingData.redirectPath.setChars(path.getBuffer(), pathStart, pathEnd - pathStart);
/*  863 */       path.setEnd(pathEnd - 1);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  868 */     MappedWrapper[] extensionWrappers = contextVersion.extensionWrappers;
/*  869 */     if (mappingData.wrapper == null && !checkJspWelcomeFiles) {
/*  870 */       internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*      */     }
/*      */ 
/*      */     
/*  874 */     if (mappingData.wrapper == null) {
/*  875 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  876 */       if (!checkWelcomeFiles) {
/*  877 */         char[] buf = path.getBuffer();
/*  878 */         checkWelcomeFiles = (buf[pathEnd - 1] == '/');
/*      */       } 
/*  880 */       if (checkWelcomeFiles) {
/*  881 */         for (int i = 0; i < contextVersion.welcomeResources.length && mappingData.wrapper == null; i++) {
/*  882 */           path.setStart(pathStart);
/*  883 */           path.setEnd(pathEnd);
/*  884 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i].length());
/*  885 */           path.setStart(servletPath);
/*      */ 
/*      */           
/*  888 */           internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */ 
/*      */           
/*  891 */           if (mappingData.wrapper == null) {
/*  892 */             internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  897 */           if (mappingData.wrapper == null && contextVersion.resources != null) {
/*  898 */             String pathStr = path.toString();
/*  899 */             WebResource file = contextVersion.resources.getResource(pathStr);
/*  900 */             if (file != null && file.isFile()) {
/*  901 */               internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*  902 */               if (mappingData.wrapper == null && contextVersion.defaultWrapper != null) {
/*  903 */                 mappingData.wrapper = contextVersion.defaultWrapper.object;
/*  904 */                 mappingData.requestPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*  905 */                 mappingData.wrapperPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*  906 */                 mappingData.requestPath.setString(pathStr);
/*  907 */                 mappingData.wrapperPath.setString(pathStr);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  913 */         path.setStart(servletPath);
/*  914 */         path.setEnd(pathEnd);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  924 */     if (mappingData.wrapper == null) {
/*  925 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  926 */       if (!checkWelcomeFiles) {
/*  927 */         char[] buf = path.getBuffer();
/*  928 */         checkWelcomeFiles = (buf[pathEnd - 1] == '/');
/*      */       } 
/*  930 */       if (checkWelcomeFiles) {
/*  931 */         for (int i = 0; i < contextVersion.welcomeResources.length && mappingData.wrapper == null; i++) {
/*  932 */           path.setStart(pathStart);
/*  933 */           path.setEnd(pathEnd);
/*  934 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i].length());
/*  935 */           path.setStart(servletPath);
/*  936 */           internalMapExtensionWrapper(extensionWrappers, path, mappingData, false);
/*      */         } 
/*      */         
/*  939 */         path.setStart(servletPath);
/*  940 */         path.setEnd(pathEnd);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  946 */     if (mappingData.wrapper == null && !checkJspWelcomeFiles) {
/*  947 */       if (contextVersion.defaultWrapper != null) {
/*  948 */         mappingData.wrapper = contextVersion.defaultWrapper.object;
/*  949 */         mappingData.requestPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*  950 */         mappingData.wrapperPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*  951 */         mappingData.matchType = MappingMatch.DEFAULT;
/*      */       } 
/*      */       
/*  954 */       char[] buf = path.getBuffer();
/*  955 */       if (contextVersion.resources != null && buf[pathEnd - 1] != '/') {
/*  956 */         String pathStr = path.toString();
/*      */ 
/*      */         
/*  959 */         if (contextVersion.object.getMapperDirectoryRedirectEnabled()) {
/*      */           WebResource file;
/*      */           
/*  962 */           if (pathStr.isEmpty()) {
/*  963 */             file = contextVersion.resources.getResource("/");
/*      */           } else {
/*  965 */             file = contextVersion.resources.getResource(pathStr);
/*      */           } 
/*  967 */           if (file != null && file.isDirectory()) {
/*      */ 
/*      */ 
/*      */             
/*  971 */             path.setStart(pathStart);
/*  972 */             path.append('/');
/*  973 */             mappingData.redirectPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */           } else {
/*  975 */             mappingData.requestPath.setString(pathStr);
/*  976 */             mappingData.wrapperPath.setString(pathStr);
/*      */           } 
/*      */         } else {
/*  979 */           mappingData.requestPath.setString(pathStr);
/*  980 */           mappingData.wrapperPath.setString(pathStr);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  985 */     path.setStart(pathStart);
/*  986 */     path.setEnd(pathEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalMapExactWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData) {
/*  994 */     MappedWrapper wrapper = exactFind(wrappers, path);
/*  995 */     if (wrapper != null) {
/*  996 */       mappingData.requestPath.setString(wrapper.name);
/*  997 */       mappingData.wrapper = wrapper.object;
/*  998 */       if (path.equals("/")) {
/*      */         
/* 1000 */         mappingData.pathInfo.setString("/");
/* 1001 */         mappingData.wrapperPath.setString("");
/* 1002 */         mappingData.matchType = MappingMatch.CONTEXT_ROOT;
/*      */       } else {
/* 1004 */         mappingData.wrapperPath.setString(wrapper.name);
/* 1005 */         mappingData.matchType = MappingMatch.EXACT;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalMapWildcardWrapper(MappedWrapper[] wrappers, int nesting, CharChunk path, MappingData mappingData) {
/* 1017 */     int pathEnd = path.getEnd();
/*      */     
/* 1019 */     int lastSlash = -1;
/* 1020 */     int length = -1;
/* 1021 */     int pos = find((MapElement<?>[])wrappers, path);
/* 1022 */     if (pos != -1) {
/* 1023 */       boolean found = false;
/* 1024 */       while (pos >= 0) {
/* 1025 */         if (path.startsWith((wrappers[pos]).name)) {
/* 1026 */           length = (wrappers[pos]).name.length();
/* 1027 */           if (path.getLength() == length) {
/* 1028 */             found = true; break;
/*      */           } 
/* 1030 */           if (path.startsWithIgnoreCase("/", length)) {
/* 1031 */             found = true;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1035 */         if (lastSlash == -1) {
/* 1036 */           lastSlash = nthSlash(path, nesting + 1);
/*      */         } else {
/* 1038 */           lastSlash = lastSlash(path);
/*      */         } 
/* 1040 */         path.setEnd(lastSlash);
/* 1041 */         pos = find((MapElement<?>[])wrappers, path);
/*      */       } 
/* 1043 */       path.setEnd(pathEnd);
/* 1044 */       if (found) {
/* 1045 */         mappingData.wrapperPath.setString((wrappers[pos]).name);
/* 1046 */         if (path.getLength() > length) {
/* 1047 */           mappingData.pathInfo.setChars(path.getBuffer(), path.getStart() + length, path
/* 1048 */               .getLength() - length);
/*      */         }
/* 1050 */         mappingData.requestPath.setChars(path.getBuffer(), path.getStart(), path.getLength());
/* 1051 */         mappingData.wrapper = (wrappers[pos]).object;
/* 1052 */         mappingData.jspWildCard = (wrappers[pos]).jspWildCard;
/* 1053 */         mappingData.matchType = MappingMatch.PATH;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalMapExtensionWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData, boolean resourceExpected) {
/* 1069 */     char[] buf = path.getBuffer();
/* 1070 */     int pathEnd = path.getEnd();
/* 1071 */     int servletPath = path.getStart();
/* 1072 */     int slash = -1;
/* 1073 */     for (int i = pathEnd - 1; i >= servletPath; i--) {
/* 1074 */       if (buf[i] == '/') {
/* 1075 */         slash = i;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1079 */     if (slash >= 0) {
/* 1080 */       int period = -1;
/* 1081 */       for (int j = pathEnd - 1; j > slash; j--) {
/* 1082 */         if (buf[j] == '.') {
/* 1083 */           period = j;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1087 */       if (period >= 0) {
/* 1088 */         path.setStart(period + 1);
/* 1089 */         path.setEnd(pathEnd);
/* 1090 */         MappedWrapper wrapper = exactFind(wrappers, path);
/* 1091 */         if (wrapper != null && (resourceExpected || !wrapper.resourceOnly)) {
/* 1092 */           mappingData.wrapperPath.setChars(buf, servletPath, pathEnd - servletPath);
/* 1093 */           mappingData.requestPath.setChars(buf, servletPath, pathEnd - servletPath);
/* 1094 */           mappingData.wrapper = wrapper.object;
/* 1095 */           mappingData.matchType = MappingMatch.EXTENSION;
/*      */         } 
/* 1097 */         path.setStart(servletPath);
/* 1098 */         path.setEnd(pathEnd);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> int find(MapElement<T>[] map, CharChunk name) {
/* 1109 */     return find(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> int find(MapElement<T>[] map, CharChunk name, int start, int end) {
/* 1119 */     int a = 0;
/* 1120 */     int b = map.length - 1;
/*      */ 
/*      */     
/* 1123 */     if (b == -1) {
/* 1124 */       return -1;
/*      */     }
/*      */     
/* 1127 */     if (compare(name, start, end, (map[0]).name) < 0) {
/* 1128 */       return -1;
/*      */     }
/* 1130 */     if (b == 0) {
/* 1131 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/* 1136 */       int i = b + a >>> 1;
/* 1137 */       int result = compare(name, start, end, (map[i]).name);
/* 1138 */       if (result == 1)
/* 1139 */       { a = i; }
/* 1140 */       else { if (result == 0) {
/* 1141 */           return i;
/*      */         }
/* 1143 */         b = i; }
/*      */       
/* 1145 */       if (b - a == 1) {
/* 1146 */         int result2 = compare(name, start, end, (map[b]).name);
/* 1147 */         if (result2 < 0) {
/* 1148 */           return a;
/*      */         }
/* 1150 */         return b;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name) {
/* 1162 */     return findIgnoreCase(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name, int start, int end) {
/* 1172 */     int a = 0;
/* 1173 */     int b = map.length - 1;
/*      */ 
/*      */     
/* 1176 */     if (b == -1) {
/* 1177 */       return -1;
/*      */     }
/* 1179 */     if (compareIgnoreCase(name, start, end, (map[0]).name) < 0) {
/* 1180 */       return -1;
/*      */     }
/* 1182 */     if (b == 0) {
/* 1183 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/* 1188 */       int i = b + a >>> 1;
/* 1189 */       int result = compareIgnoreCase(name, start, end, (map[i]).name);
/* 1190 */       if (result == 1)
/* 1191 */       { a = i; }
/* 1192 */       else { if (result == 0) {
/* 1193 */           return i;
/*      */         }
/* 1195 */         b = i; }
/*      */       
/* 1197 */       if (b - a == 1) {
/* 1198 */         int result2 = compareIgnoreCase(name, start, end, (map[b]).name);
/* 1199 */         if (result2 < 0) {
/* 1200 */           return a;
/*      */         }
/* 1202 */         return b;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> int find(MapElement<T>[] map, String name) {
/* 1218 */     int a = 0;
/* 1219 */     int b = map.length - 1;
/*      */ 
/*      */     
/* 1222 */     if (b == -1) {
/* 1223 */       return -1;
/*      */     }
/*      */     
/* 1226 */     if (name.compareTo((map[0]).name) < 0) {
/* 1227 */       return -1;
/*      */     }
/* 1229 */     if (b == 0) {
/* 1230 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/* 1235 */       int i = b + a >>> 1;
/* 1236 */       int result = name.compareTo((map[i]).name);
/* 1237 */       if (result > 0)
/* 1238 */       { a = i; }
/* 1239 */       else { if (result == 0) {
/* 1240 */           return i;
/*      */         }
/* 1242 */         b = i; }
/*      */       
/* 1244 */       if (b - a == 1) {
/* 1245 */         int result2 = name.compareTo((map[b]).name);
/* 1246 */         if (result2 < 0) {
/* 1247 */           return a;
/*      */         }
/* 1249 */         return b;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T, E extends MapElement<T>> E exactFind(E[] map, String name) {
/* 1264 */     int pos = find((MapElement<?>[])map, name);
/* 1265 */     if (pos >= 0) {
/* 1266 */       E result = map[pos];
/* 1267 */       if (name.equals(((MapElement)result).name)) {
/* 1268 */         return result;
/*      */       }
/*      */     } 
/* 1271 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T, E extends MapElement<T>> E exactFind(E[] map, CharChunk name) {
/* 1279 */     int pos = find((MapElement<?>[])map, name);
/* 1280 */     if (pos >= 0) {
/* 1281 */       E result = map[pos];
/* 1282 */       if (name.equals(((MapElement)result).name)) {
/* 1283 */         return result;
/*      */       }
/*      */     } 
/* 1286 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T, E extends MapElement<T>> E exactFindIgnoreCase(E[] map, CharChunk name) {
/* 1296 */     int pos = findIgnoreCase((MapElement<?>[])map, name);
/* 1297 */     if (pos >= 0) {
/* 1298 */       E result = map[pos];
/* 1299 */       if (name.equalsIgnoreCase(((MapElement)result).name)) {
/* 1300 */         return result;
/*      */       }
/*      */     } 
/* 1303 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int compare(CharChunk name, int start, int end, String compareTo) {
/* 1311 */     int result = 0;
/* 1312 */     char[] c = name.getBuffer();
/* 1313 */     int compareLen = compareTo.length();
/* 1314 */     int len = compareLen;
/* 1315 */     if (end - start < len) {
/* 1316 */       len = end - start;
/*      */     }
/* 1318 */     for (int i = 0; i < len && result == 0; i++) {
/* 1319 */       char nameChar = c[i + start];
/* 1320 */       char compareToChar = compareTo.charAt(i);
/* 1321 */       if (nameChar > compareToChar) {
/* 1322 */         result = 1;
/* 1323 */       } else if (nameChar < compareToChar) {
/* 1324 */         result = -1;
/*      */       } 
/*      */     } 
/* 1327 */     if (result == 0) {
/* 1328 */       if (compareLen > end - start) {
/* 1329 */         result = -1;
/* 1330 */       } else if (compareLen < end - start) {
/* 1331 */         result = 1;
/*      */       } 
/*      */     }
/* 1334 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int compareIgnoreCase(CharChunk name, int start, int end, String compareTo) {
/* 1343 */     int result = 0;
/* 1344 */     char[] c = name.getBuffer();
/* 1345 */     int compareLen = compareTo.length();
/* 1346 */     int len = compareLen;
/* 1347 */     if (end - start < len) {
/* 1348 */       len = end - start;
/*      */     }
/* 1350 */     for (int i = 0; i < len && result == 0; i++) {
/* 1351 */       int nameLower = Ascii.toLower(c[i + start]);
/* 1352 */       int compareLower = Ascii.toLower(compareTo.charAt(i));
/* 1353 */       if (nameLower > compareLower) {
/* 1354 */         result = 1;
/* 1355 */       } else if (nameLower < compareLower) {
/* 1356 */         result = -1;
/*      */       } 
/*      */     } 
/* 1359 */     if (result == 0) {
/* 1360 */       if (compareLen > end - start) {
/* 1361 */         result = -1;
/* 1362 */       } else if (compareLen < end - start) {
/* 1363 */         result = 1;
/*      */       } 
/*      */     }
/* 1366 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int lastSlash(CharChunk name) {
/* 1374 */     char[] c = name.getBuffer();
/* 1375 */     int end = name.getEnd();
/* 1376 */     int start = name.getStart();
/* 1377 */     int pos = end; do {
/*      */     
/* 1379 */     } while (pos > start && 
/* 1380 */       c[--pos] != '/');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1385 */     return pos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int nthSlash(CharChunk name, int n) {
/* 1393 */     char[] c = name.getBuffer();
/* 1394 */     int end = name.getEnd();
/* 1395 */     int pos = name.getStart();
/* 1396 */     int count = 0;
/*      */     
/* 1398 */     while (pos < end) {
/* 1399 */       if (c[pos++] == '/' && ++count == n) {
/* 1400 */         pos--;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1405 */     return pos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int slashCount(String name) {
/* 1413 */     int pos = -1;
/* 1414 */     int count = 0;
/* 1415 */     while ((pos = name.indexOf('/', pos + 1)) != -1) {
/* 1416 */       count++;
/*      */     }
/* 1418 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> boolean insertMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, MapElement<T> newElement) {
/* 1426 */     int pos = find(oldMap, newElement.name);
/* 1427 */     if (pos != -1 && newElement.name.equals((oldMap[pos]).name)) {
/* 1428 */       return false;
/*      */     }
/* 1430 */     System.arraycopy(oldMap, 0, newMap, 0, pos + 1);
/* 1431 */     newMap[pos + 1] = newElement;
/* 1432 */     System.arraycopy(oldMap, pos + 1, newMap, pos + 2, oldMap.length - pos - 1);
/* 1433 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> boolean removeMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, String name) {
/* 1441 */     int pos = find(oldMap, name);
/* 1442 */     if (pos != -1 && name.equals((oldMap[pos]).name)) {
/* 1443 */       System.arraycopy(oldMap, 0, newMap, 0, pos);
/* 1444 */       System.arraycopy(oldMap, pos + 1, newMap, pos, oldMap.length - pos - 1);
/* 1445 */       return true;
/*      */     } 
/* 1447 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String renameWildcardHost(String hostName) {
/* 1458 */     if (hostName != null && hostName.startsWith("*.")) {
/* 1459 */       return hostName.substring(1);
/*      */     }
/* 1461 */     return hostName;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class MapElement<T>
/*      */   {
/*      */     public final String name;
/*      */ 
/*      */     
/*      */     public final T object;
/*      */ 
/*      */     
/*      */     public MapElement(String name, T object) {
/* 1475 */       this.name = name;
/* 1476 */       this.object = object;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class MappedHost
/*      */     extends MapElement<Host>
/*      */   {
/*      */     public volatile Mapper.ContextList contextList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MappedHost realHost;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<MappedHost> aliases;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MappedHost(String name, Host host) {
/* 1506 */       super(name, host);
/* 1507 */       this.realHost = this;
/* 1508 */       this.contextList = new Mapper.ContextList();
/* 1509 */       this.aliases = new CopyOnWriteArrayList<>();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MappedHost(String alias, MappedHost realHost) {
/* 1519 */       super(alias, realHost.object);
/* 1520 */       this.realHost = realHost;
/* 1521 */       this.contextList = realHost.contextList;
/* 1522 */       this.aliases = null;
/*      */     }
/*      */     
/*      */     public boolean isAlias() {
/* 1526 */       return (this.realHost != this);
/*      */     }
/*      */     
/*      */     public MappedHost getRealHost() {
/* 1530 */       return this.realHost;
/*      */     }
/*      */     
/*      */     public String getRealHostName() {
/* 1534 */       return this.realHost.name;
/*      */     }
/*      */     
/*      */     public Collection<MappedHost> getAliases() {
/* 1538 */       return this.aliases;
/*      */     }
/*      */     
/*      */     public void addAlias(MappedHost alias) {
/* 1542 */       this.aliases.add(alias);
/*      */     }
/*      */     
/*      */     public void addAliases(Collection<? extends MappedHost> c) {
/* 1546 */       this.aliases.addAll(c);
/*      */     }
/*      */     
/*      */     public void removeAlias(MappedHost alias) {
/* 1550 */       this.aliases.remove(alias);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class ContextList
/*      */   {
/*      */     public final Mapper.MappedContext[] contexts;
/*      */     
/*      */     public final int nesting;
/*      */ 
/*      */     
/*      */     public ContextList() {
/* 1564 */       this(new Mapper.MappedContext[0], 0);
/*      */     }
/*      */     
/*      */     private ContextList(Mapper.MappedContext[] contexts, int nesting) {
/* 1568 */       this.contexts = contexts;
/* 1569 */       this.nesting = nesting;
/*      */     }
/*      */     
/*      */     public ContextList addContext(Mapper.MappedContext mappedContext, int slashCount) {
/* 1573 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length + 1];
/* 1574 */       if (Mapper.insertMap((Mapper.MapElement<?>[])this.contexts, (Mapper.MapElement<?>[])newContexts, mappedContext)) {
/* 1575 */         return new ContextList(newContexts, Math.max(this.nesting, slashCount));
/*      */       }
/* 1577 */       return null;
/*      */     }
/*      */     
/*      */     public ContextList removeContext(String path) {
/* 1581 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length - 1];
/* 1582 */       if (Mapper.removeMap((Mapper.MapElement<?>[])this.contexts, (Mapper.MapElement<?>[])newContexts, path)) {
/* 1583 */         int newNesting = 0;
/* 1584 */         for (Mapper.MappedContext context : newContexts) {
/* 1585 */           newNesting = Math.max(newNesting, Mapper.slashCount(context.name));
/*      */         }
/* 1587 */         return new ContextList(newContexts, newNesting);
/*      */       } 
/* 1589 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final class MappedContext
/*      */     extends MapElement<Void>
/*      */   {
/*      */     public volatile Mapper.ContextVersion[] versions;
/*      */ 
/*      */     
/*      */     public MappedContext(String name, Mapper.ContextVersion firstVersion) {
/* 1601 */       super(name, null);
/* 1602 */       this.versions = new Mapper.ContextVersion[] { firstVersion };
/*      */     }
/*      */   }
/*      */   
/*      */   protected static final class ContextVersion extends MapElement<Context> {
/*      */     public final String path;
/*      */     public final int slashCount;
/*      */     public final WebResourceRoot resources;
/*      */     public String[] welcomeResources;
/* 1611 */     public Mapper.MappedWrapper defaultWrapper = null;
/* 1612 */     public Mapper.MappedWrapper[] exactWrappers = new Mapper.MappedWrapper[0];
/* 1613 */     public Mapper.MappedWrapper[] wildcardWrappers = new Mapper.MappedWrapper[0];
/* 1614 */     public Mapper.MappedWrapper[] extensionWrappers = new Mapper.MappedWrapper[0];
/* 1615 */     public int nesting = 0;
/*      */     
/*      */     private volatile boolean paused;
/*      */     
/*      */     public ContextVersion(String version, String path, int slashCount, Context context, WebResourceRoot resources, String[] welcomeResources) {
/* 1620 */       super(version, context);
/* 1621 */       this.path = path;
/* 1622 */       this.slashCount = slashCount;
/* 1623 */       this.resources = resources;
/* 1624 */       this.welcomeResources = welcomeResources;
/*      */     }
/*      */     
/*      */     public boolean isPaused() {
/* 1628 */       return this.paused;
/*      */     }
/*      */     
/*      */     public void markPaused() {
/* 1632 */       this.paused = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static class MappedWrapper
/*      */     extends MapElement<Wrapper>
/*      */   {
/*      */     public final boolean jspWildCard;
/*      */     
/*      */     public final boolean resourceOnly;
/*      */     
/*      */     public MappedWrapper(String name, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly) {
/* 1645 */       super(name, wrapper);
/* 1646 */       this.jspWildCard = jspWildCard;
/* 1647 */       this.resourceOnly = resourceOnly;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mapper\Mapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */