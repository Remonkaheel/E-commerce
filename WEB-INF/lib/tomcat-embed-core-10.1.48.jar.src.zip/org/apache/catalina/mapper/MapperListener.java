/*     */ package org.apache.catalina.mapper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperListener
/*     */   extends LifecycleMBeanBase
/*     */   implements ContainerListener, LifecycleListener
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(MapperListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Mapper mapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Service service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.mapper");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private final String domain = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapperListener(Service service) {
/*  81 */     this.service = service;
/*  82 */     this.mapper = service.getMapper();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startInternal() throws LifecycleException {
/*  91 */     setState(LifecycleState.STARTING);
/*     */     
/*  93 */     Engine engine = this.service.getContainer();
/*  94 */     if (engine == null) {
/*     */       return;
/*     */     }
/*     */     
/*  98 */     findDefaultHost();
/*     */     
/* 100 */     addListeners((Container)engine);
/*     */     
/* 102 */     Container[] conHosts = engine.findChildren();
/* 103 */     for (Container conHost : conHosts) {
/* 104 */       Host host = (Host)conHost;
/* 105 */       if (!LifecycleState.NEW.equals(host.getState()))
/*     */       {
/* 107 */         registerHost(host);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopInternal() throws LifecycleException {
/* 115 */     setState(LifecycleState.STOPPING);
/*     */     
/* 117 */     Engine engine = this.service.getContainer();
/* 118 */     if (engine == null) {
/*     */       return;
/*     */     }
/* 121 */     removeListeners((Container)engine);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 127 */     if (this.service instanceof LifecycleMBeanBase) {
/* 128 */       return this.service.getDomain();
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 138 */     return "type=Mapper";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void containerEvent(ContainerEvent event) {
/* 146 */     if ("addChild".equals(event.getType())) {
/* 147 */       Container child = (Container)event.getData();
/* 148 */       addListeners(child);
/*     */ 
/*     */       
/* 151 */       if (child.getState().isAvailable()) {
/* 152 */         if (child instanceof Host) {
/* 153 */           registerHost((Host)child);
/* 154 */         } else if (child instanceof Context) {
/* 155 */           registerContext((Context)child);
/* 156 */         } else if (child instanceof Wrapper) {
/*     */ 
/*     */           
/* 159 */           if (child.getParent().getState().isAvailable()) {
/* 160 */             registerWrapper((Wrapper)child);
/*     */           }
/*     */         } 
/*     */       }
/* 164 */     } else if ("removeChild".equals(event.getType())) {
/* 165 */       Container child = (Container)event.getData();
/* 166 */       removeListeners(child);
/*     */     
/*     */     }
/* 169 */     else if ("addAlias".equals(event.getType())) {
/*     */       
/* 171 */       this.mapper.addHostAlias(((Host)event.getSource()).getName(), event.getData().toString());
/* 172 */     } else if ("removeAlias".equals(event.getType())) {
/*     */       
/* 174 */       this.mapper.removeHostAlias(event.getData().toString());
/* 175 */     } else if ("addMapping".equals(event.getType())) {
/*     */       
/* 177 */       Wrapper wrapper = (Wrapper)event.getSource();
/* 178 */       Context context = (Context)wrapper.getParent();
/* 179 */       String contextPath = context.getPath();
/* 180 */       if ("/".equals(contextPath)) {
/* 181 */         contextPath = "";
/*     */       }
/* 183 */       String version = context.getWebappVersion();
/* 184 */       String hostName = context.getParent().getName();
/* 185 */       String wrapperName = wrapper.getName();
/* 186 */       String mapping = (String)event.getData();
/* 187 */       boolean jspWildCard = ("jsp".equals(wrapperName) && mapping.endsWith("/*"));
/* 188 */       this.mapper.addWrapper(hostName, contextPath, version, mapping, wrapper, jspWildCard, context
/* 189 */           .isResourceOnlyServlet(wrapperName));
/* 190 */     } else if ("removeMapping".equals(event.getType())) {
/*     */       
/* 192 */       Wrapper wrapper = (Wrapper)event.getSource();
/*     */       
/* 194 */       Context context = (Context)wrapper.getParent();
/* 195 */       String contextPath = context.getPath();
/* 196 */       if ("/".equals(contextPath)) {
/* 197 */         contextPath = "";
/*     */       }
/* 199 */       String version = context.getWebappVersion();
/* 200 */       String hostName = context.getParent().getName();
/*     */       
/* 202 */       String mapping = (String)event.getData();
/*     */       
/* 204 */       this.mapper.removeWrapper(hostName, contextPath, version, mapping);
/* 205 */     } else if ("addWelcomeFile".equals(event.getType())) {
/*     */       
/* 207 */       Context context = (Context)event.getSource();
/*     */       
/* 209 */       String hostName = context.getParent().getName();
/*     */       
/* 211 */       String contextPath = context.getPath();
/* 212 */       if ("/".equals(contextPath)) {
/* 213 */         contextPath = "";
/*     */       }
/*     */       
/* 216 */       String welcomeFile = (String)event.getData();
/*     */       
/* 218 */       this.mapper.addWelcomeFile(hostName, contextPath, context.getWebappVersion(), welcomeFile);
/* 219 */     } else if ("removeWelcomeFile".equals(event.getType())) {
/*     */       
/* 221 */       Context context = (Context)event.getSource();
/*     */       
/* 223 */       String hostName = context.getParent().getName();
/*     */       
/* 225 */       String contextPath = context.getPath();
/* 226 */       if ("/".equals(contextPath)) {
/* 227 */         contextPath = "";
/*     */       }
/*     */       
/* 230 */       String welcomeFile = (String)event.getData();
/*     */       
/* 232 */       this.mapper.removeWelcomeFile(hostName, contextPath, context.getWebappVersion(), welcomeFile);
/* 233 */     } else if ("clearWelcomeFiles".equals(event.getType())) {
/*     */       
/* 235 */       Context context = (Context)event.getSource();
/*     */       
/* 237 */       String hostName = context.getParent().getName();
/*     */       
/* 239 */       String contextPath = context.getPath();
/* 240 */       if ("/".equals(contextPath)) {
/* 241 */         contextPath = "";
/*     */       }
/*     */       
/* 244 */       this.mapper.clearWelcomeFiles(hostName, contextPath, context.getWebappVersion());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findDefaultHost() {
/* 253 */     Engine engine = this.service.getContainer();
/* 254 */     String defaultHost = engine.getDefaultHost();
/*     */     
/* 256 */     boolean found = false;
/*     */     
/* 258 */     if (defaultHost != null && !defaultHost.isEmpty()) {
/* 259 */       Container[] containers = engine.findChildren();
/*     */       
/* 261 */       for (Container container : containers) {
/* 262 */         Host host = (Host)container;
/* 263 */         if (defaultHost.equalsIgnoreCase(host.getName())) {
/* 264 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/* 268 */         String[] aliases = host.findAliases();
/* 269 */         for (String alias : aliases) {
/* 270 */           if (defaultHost.equalsIgnoreCase(alias)) {
/* 271 */             found = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 278 */     if (found) {
/* 279 */       this.mapper.setDefaultHostName(defaultHost);
/*     */     } else {
/* 281 */       log.error(sm.getString("mapperListener.unknownDefaultHost", new Object[] { defaultHost, this.service }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerHost(Host host) {
/* 291 */     String[] aliases = host.findAliases();
/* 292 */     this.mapper.addHost(host.getName(), aliases, host);
/*     */     
/* 294 */     for (Container container : host.findChildren()) {
/* 295 */       if (container.getState().isAvailable()) {
/* 296 */         registerContext((Context)container);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 301 */     findDefaultHost();
/*     */     
/* 303 */     if (log.isDebugEnabled()) {
/* 304 */       log.debug(sm.getString("mapperListener.registerHost", new Object[] { host.getName(), this.domain, this.service }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unregisterHost(Host host) {
/* 314 */     String hostname = host.getName();
/*     */     
/* 316 */     this.mapper.removeHost(hostname);
/*     */ 
/*     */     
/* 319 */     findDefaultHost();
/*     */     
/* 321 */     if (log.isDebugEnabled()) {
/* 322 */       log.debug(sm.getString("mapperListener.unregisterHost", new Object[] { hostname, this.domain, this.service }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unregisterWrapper(Wrapper wrapper) {
/* 332 */     Context context = (Context)wrapper.getParent();
/* 333 */     String contextPath = context.getPath();
/* 334 */     String wrapperName = wrapper.getName();
/*     */     
/* 336 */     if ("/".equals(contextPath)) {
/* 337 */       contextPath = "";
/*     */     }
/* 339 */     String version = context.getWebappVersion();
/* 340 */     String hostName = context.getParent().getName();
/*     */     
/* 342 */     String[] mappings = wrapper.findMappings();
/*     */     
/* 344 */     for (String mapping : mappings) {
/* 345 */       this.mapper.removeWrapper(hostName, contextPath, version, mapping);
/*     */     }
/*     */     
/* 348 */     if (log.isDebugEnabled()) {
/* 349 */       log.debug(sm.getString("mapperListener.unregisterWrapper", new Object[] { wrapperName, contextPath, this.service }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerContext(Context context) {
/* 359 */     String contextPath = context.getPath();
/* 360 */     if ("/".equals(contextPath)) {
/* 361 */       contextPath = "";
/*     */     }
/* 363 */     Host host = (Host)context.getParent();
/*     */     
/* 365 */     WebResourceRoot resources = context.getResources();
/* 366 */     String[] welcomeFiles = context.findWelcomeFiles();
/* 367 */     List<WrapperMappingInfo> wrappers = new ArrayList<>();
/*     */     
/* 369 */     for (Container container : context.findChildren()) {
/* 370 */       prepareWrapperMappingInfo(context, (Wrapper)container, wrappers);
/*     */       
/* 372 */       if (log.isDebugEnabled()) {
/* 373 */         log.debug(sm.getString("mapperListener.registerWrapper", new Object[] { container.getName(), contextPath, this.service }));
/*     */       }
/*     */     } 
/*     */     
/* 377 */     this.mapper.addContextVersion(host.getName(), host, contextPath, context.getWebappVersion(), context, welcomeFiles, resources, wrappers);
/*     */ 
/*     */     
/* 380 */     if (log.isDebugEnabled()) {
/* 381 */       log.debug(sm.getString("mapperListener.registerContext", new Object[] { contextPath, this.service }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unregisterContext(Context context) {
/* 391 */     String contextPath = context.getPath();
/* 392 */     if ("/".equals(contextPath)) {
/* 393 */       contextPath = "";
/*     */     }
/* 395 */     String hostName = context.getParent().getName();
/*     */     
/* 397 */     if (context.getPaused()) {
/* 398 */       if (log.isDebugEnabled()) {
/* 399 */         log.debug(sm.getString("mapperListener.pauseContext", new Object[] { contextPath, this.service }));
/*     */       }
/*     */       
/* 402 */       this.mapper.pauseContextVersion(context, hostName, contextPath, context.getWebappVersion());
/*     */     } else {
/* 404 */       if (log.isDebugEnabled()) {
/* 405 */         log.debug(sm.getString("mapperListener.unregisterContext", new Object[] { contextPath, this.service }));
/*     */       }
/*     */       
/* 408 */       this.mapper.removeContextVersion(context, hostName, contextPath, context.getWebappVersion());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerWrapper(Wrapper wrapper) {
/* 418 */     Context context = (Context)wrapper.getParent();
/* 419 */     String contextPath = context.getPath();
/* 420 */     if ("/".equals(contextPath)) {
/* 421 */       contextPath = "";
/*     */     }
/* 423 */     String version = context.getWebappVersion();
/* 424 */     String hostName = context.getParent().getName();
/*     */     
/* 426 */     List<WrapperMappingInfo> wrappers = new ArrayList<>();
/* 427 */     prepareWrapperMappingInfo(context, wrapper, wrappers);
/* 428 */     this.mapper.addWrappers(hostName, contextPath, version, wrappers);
/*     */     
/* 430 */     if (log.isDebugEnabled()) {
/* 431 */       log.debug(sm.getString("mapperListener.registerWrapper", new Object[] { wrapper.getName(), contextPath, this.service }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void prepareWrapperMappingInfo(Context context, Wrapper wrapper, List<WrapperMappingInfo> wrappers) {
/* 440 */     String wrapperName = wrapper.getName();
/* 441 */     boolean resourceOnly = context.isResourceOnlyServlet(wrapperName);
/* 442 */     String[] mappings = wrapper.findMappings();
/* 443 */     for (String mapping : mappings) {
/* 444 */       boolean jspWildCard = (wrapperName.equals("jsp") && mapping.endsWith("/*"));
/* 445 */       wrappers.add(new WrapperMappingInfo(mapping, wrapper, jspWildCard, resourceOnly));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/* 451 */     if (event.getType().equals("after_start")) {
/* 452 */       Object obj = event.getSource();
/* 453 */       if (obj instanceof Wrapper) {
/* 454 */         Wrapper w = (Wrapper)obj;
/*     */ 
/*     */         
/* 457 */         if (w.getParent().getState().isAvailable()) {
/* 458 */           registerWrapper(w);
/*     */         }
/* 460 */       } else if (obj instanceof Context) {
/* 461 */         Context c = (Context)obj;
/*     */ 
/*     */         
/* 464 */         if (c.getParent().getState().isAvailable()) {
/* 465 */           registerContext(c);
/*     */         }
/* 467 */       } else if (obj instanceof Host) {
/* 468 */         registerHost((Host)obj);
/*     */       } 
/* 470 */     } else if (event.getType().equals("before_stop")) {
/* 471 */       Object obj = event.getSource();
/* 472 */       if (obj instanceof Wrapper) {
/* 473 */         unregisterWrapper((Wrapper)obj);
/* 474 */       } else if (obj instanceof Context) {
/* 475 */         unregisterContext((Context)obj);
/* 476 */       } else if (obj instanceof Host) {
/* 477 */         unregisterHost((Host)obj);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addListeners(Container container) {
/* 489 */     container.addContainerListener(this);
/* 490 */     container.addLifecycleListener(this);
/* 491 */     for (Container child : container.findChildren()) {
/* 492 */       addListeners(child);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeListeners(Container container) {
/* 503 */     container.removeContainerListener(this);
/* 504 */     container.removeLifecycleListener(this);
/* 505 */     for (Container child : container.findChildren())
/* 506 */       removeListeners(child); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mapper\MapperListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */