/*    */ package org.apache.catalina.mapper;
/*    */ 
/*    */ import jakarta.servlet.http.MappingMatch;
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.catalina.Host;
/*    */ import org.apache.catalina.Wrapper;
/*    */ import org.apache.tomcat.util.buf.MessageBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingData
/*    */ {
/* 31 */   public Host host = null;
/* 32 */   public Context context = null;
/* 33 */   public int contextSlashCount = 0;
/* 34 */   public Context[] contexts = null;
/* 35 */   public Wrapper wrapper = null;
/*    */   
/*    */   public boolean jspWildCard = false;
/* 38 */   public final MessageBytes requestPath = MessageBytes.newInstance();
/* 39 */   public final MessageBytes wrapperPath = MessageBytes.newInstance();
/* 40 */   public final MessageBytes pathInfo = MessageBytes.newInstance();
/*    */   
/* 42 */   public final MessageBytes redirectPath = MessageBytes.newInstance();
/*    */ 
/*    */   
/* 45 */   public MappingMatch matchType = null;
/*    */   
/*    */   public void recycle() {
/* 48 */     this.host = null;
/* 49 */     this.context = null;
/* 50 */     this.contextSlashCount = 0;
/* 51 */     this.contexts = null;
/* 52 */     this.wrapper = null;
/* 53 */     this.jspWildCard = false;
/* 54 */     this.requestPath.recycle();
/* 55 */     this.wrapperPath.recycle();
/* 56 */     this.pathInfo.recycle();
/* 57 */     this.redirectPath.recycle();
/* 58 */     this.matchType = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mapper\MappingData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */