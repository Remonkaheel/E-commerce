/*    */ package org.apache.catalina.mapper;
/*    */ 
/*    */ import org.apache.catalina.Wrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrapperMappingInfo
/*    */ {
/*    */   private final String mapping;
/*    */   private final Wrapper wrapper;
/*    */   private final boolean jspWildCard;
/*    */   private final boolean resourceOnly;
/*    */   
/*    */   public WrapperMappingInfo(String mapping, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly) {
/* 32 */     this.mapping = mapping;
/* 33 */     this.wrapper = wrapper;
/* 34 */     this.jspWildCard = jspWildCard;
/* 35 */     this.resourceOnly = resourceOnly;
/*    */   }
/*    */   
/*    */   public String getMapping() {
/* 39 */     return this.mapping;
/*    */   }
/*    */   
/*    */   public Wrapper getWrapper() {
/* 43 */     return this.wrapper;
/*    */   }
/*    */   
/*    */   public boolean isJspWildCard() {
/* 47 */     return this.jspWildCard;
/*    */   }
/*    */   
/*    */   public boolean isResourceOnly() {
/* 51 */     return this.resourceOnly;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mapper\WrapperMappingInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */