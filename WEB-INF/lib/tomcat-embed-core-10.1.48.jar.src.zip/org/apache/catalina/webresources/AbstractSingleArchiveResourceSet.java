/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSingleArchiveResourceSet
/*     */   extends AbstractArchiveResourceSet
/*     */ {
/*     */   private volatile Boolean multiRelease;
/*     */   
/*     */   public AbstractSingleArchiveResourceSet() {}
/*     */   
/*     */   public AbstractSingleArchiveResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath) throws IllegalArgumentException {
/*  49 */     setRoot(root);
/*  50 */     setWebAppMount(webAppMount);
/*  51 */     setBase(base);
/*  52 */     setInternalPath(internalPath);
/*     */     
/*  54 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  56 */         start();
/*  57 */       } catch (LifecycleException e) {
/*  58 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, JarEntry> getArchiveEntries(boolean single) {
/*  66 */     synchronized (this.archiveLock) {
/*  67 */       if (this.archiveEntries == null && !single) {
/*  68 */         JarFile jarFile = null;
/*  69 */         this.archiveEntries = new HashMap<>();
/*     */         try {
/*  71 */           jarFile = openJarFile();
/*  72 */           Enumeration<JarEntry> entries = jarFile.entries();
/*  73 */           while (entries.hasMoreElements()) {
/*  74 */             JarEntry entry = entries.nextElement();
/*  75 */             this.archiveEntries.put(entry.getName(), entry);
/*     */           } 
/*  77 */         } catch (IOException ioe) {
/*     */           
/*  79 */           this.archiveEntries = null;
/*  80 */           throw new IllegalStateException(ioe);
/*     */         } finally {
/*  82 */           if (jarFile != null) {
/*  83 */             closeJarFile();
/*     */           }
/*     */         } 
/*     */       } 
/*  87 */       return this.archiveEntries;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JarEntry getArchiveEntry(String pathInArchive) {
/*  94 */     JarFile jarFile = null;
/*     */     try {
/*  96 */       jarFile = openJarFile();
/*  97 */       return jarFile.getJarEntry(pathInArchive);
/*  98 */     } catch (IOException ioe) {
/*     */       
/* 100 */       throw new IllegalStateException(ioe);
/*     */     } finally {
/* 102 */       if (jarFile != null) {
/* 103 */         closeJarFile();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMultiRelease() {
/* 111 */     if (this.multiRelease == null) {
/* 112 */       synchronized (this.archiveLock) {
/* 113 */         if (this.multiRelease == null) {
/* 114 */           JarFile jarFile = null;
/*     */           try {
/* 116 */             jarFile = openJarFile();
/* 117 */             this.multiRelease = Boolean.valueOf(jarFile.isMultiRelease());
/* 118 */           } catch (IOException ioe) {
/*     */             
/* 120 */             throw new IllegalStateException(ioe);
/*     */           } finally {
/* 122 */             if (jarFile != null) {
/* 123 */               closeJarFile();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 130 */     return this.multiRelease.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/*     */     
/* 138 */     try { JarFile jarFile = new JarFile(new File(getBase()), true, 1, Runtime.version()); 
/* 139 */       try { setManifest(jarFile.getManifest());
/* 140 */         jarFile.close(); } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 141 */     { throw new IllegalArgumentException(ioe); }
/*     */ 
/*     */     
/*     */     try {
/* 145 */       setBaseUrl(UriUtil.buildJarSafeUrl(new File(getBase())));
/* 146 */     } catch (MalformedURLException e) {
/* 147 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractSingleArchiveResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */