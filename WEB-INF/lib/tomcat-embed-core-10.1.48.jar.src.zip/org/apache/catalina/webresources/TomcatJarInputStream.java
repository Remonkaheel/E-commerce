/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.JarInputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatJarInputStream
/*    */   extends JarInputStream
/*    */ {
/*    */   private JarEntry metaInfEntry;
/*    */   private JarEntry manifestEntry;
/*    */   
/*    */   TomcatJarInputStream(InputStream in) throws IOException {
/* 36 */     super(in);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ZipEntry createZipEntry(String name) {
/* 42 */     ZipEntry ze = super.createZipEntry(name);
/* 43 */     if (this.metaInfEntry == null && "META-INF/".equals(name)) {
/* 44 */       this.metaInfEntry = (JarEntry)ze;
/* 45 */     } else if (this.manifestEntry == null && "META-INF/MANIFEST.MF".equals(name)) {
/* 46 */       this.manifestEntry = (JarEntry)ze;
/*    */     } 
/* 48 */     return ze;
/*    */   }
/*    */ 
/*    */   
/*    */   JarEntry getMetaInfEntry() {
/* 53 */     return this.metaInfEntry;
/*    */   }
/*    */ 
/*    */   
/*    */   JarEntry getManifestEntry() {
/* 58 */     return this.manifestEntry;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\TomcatJarInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */