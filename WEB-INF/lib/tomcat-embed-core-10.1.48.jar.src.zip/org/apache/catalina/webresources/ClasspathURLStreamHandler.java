/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClasspathURLStreamHandler
/*    */   extends URLStreamHandler
/*    */ {
/* 29 */   private static final StringManager sm = StringManager.getManager(ClasspathURLStreamHandler.class);
/*    */ 
/*    */ 
/*    */   
/*    */   protected URLConnection openConnection(URL u) throws IOException {
/* 34 */     String path = u.getPath();
/*    */ 
/*    */     
/* 37 */     URL classpathUrl = Thread.currentThread().getContextClassLoader().getResource(path);
/* 38 */     if (classpathUrl == null)
/*    */     {
/* 40 */       classpathUrl = ClasspathURLStreamHandler.class.getResource(path);
/*    */     }
/*    */     
/* 43 */     if (classpathUrl == null) {
/* 44 */       throw new FileNotFoundException(sm.getString("classpathUrlStreamHandler.notFound", new Object[] { u }));
/*    */     }
/*    */     
/* 47 */     return classpathUrl.openConnection();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\ClasspathURLStreamHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */