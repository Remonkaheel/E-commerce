/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cache
/*     */ {
/*  35 */   private static final Log log = LogFactory.getLog(Cache.class);
/*  36 */   protected static final StringManager sm = StringManager.getManager(Cache.class);
/*     */   
/*     */   private static final long TARGET_FREE_PERCENT_GET = 5L;
/*     */   
/*     */   private static final long TARGET_FREE_PERCENT_BACKGROUND = 10L;
/*     */   
/*     */   private static final int OBJECT_MAX_SIZE_FACTOR = 20;
/*     */   
/*     */   private final StandardRoot root;
/*  45 */   private final AtomicLong size = new AtomicLong(0L);
/*     */   
/*  47 */   private long ttl = 5000L;
/*  48 */   private long maxSize = 10485760L;
/*  49 */   private int objectMaxSize = (int)this.maxSize / 20;
/*     */   
/*     */   private WebResourceRoot.CacheStrategy cacheStrategy;
/*  52 */   private final LongAdder lookupCount = new LongAdder();
/*  53 */   private final LongAdder hitCount = new LongAdder();
/*     */   
/*  55 */   private final ConcurrentMap<String, CachedResource> resourceCache = new ConcurrentHashMap<>();
/*     */   
/*     */   public Cache(StandardRoot root) {
/*  58 */     this.root = root;
/*     */   }
/*     */ 
/*     */   
/*     */   protected WebResource getResource(String path, boolean useClassLoaderResources) {
/*  63 */     if (noCache(path)) {
/*  64 */       return this.root.getResourceInternal(path, useClassLoaderResources);
/*     */     }
/*     */     
/*  67 */     WebResourceRoot.CacheStrategy strategy = getCacheStrategy();
/*  68 */     if (strategy != null && 
/*  69 */       strategy.noCache(path)) {
/*  70 */       return this.root.getResourceInternal(path, useClassLoaderResources);
/*     */     }
/*     */ 
/*     */     
/*  74 */     this.lookupCount.increment();
/*     */     
/*  76 */     CachedResource cacheEntry = this.resourceCache.get(path);
/*     */     
/*  78 */     if (cacheEntry != null && !cacheEntry.validateResource(useClassLoaderResources)) {
/*  79 */       removeCacheEntry(path);
/*  80 */       cacheEntry = null;
/*     */     } 
/*     */     
/*  83 */     if (cacheEntry == null) {
/*     */       
/*  85 */       int objectMaxSizeBytes = getObjectMaxSizeBytes();
/*     */       
/*  87 */       CachedResource newCacheEntry = new CachedResource(this, this.root, path, getTtl(), objectMaxSizeBytes, useClassLoaderResources);
/*     */ 
/*     */ 
/*     */       
/*  91 */       cacheEntry = this.resourceCache.putIfAbsent(path, newCacheEntry);
/*     */       
/*  93 */       if (cacheEntry == null) {
/*     */         
/*  95 */         cacheEntry = newCacheEntry;
/*  96 */         cacheEntry.validateResource(useClassLoaderResources);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 101 */         long delta = cacheEntry.getSize();
/* 102 */         long result = this.size.addAndGet(delta);
/* 103 */         if (log.isDebugEnabled()) {
/* 104 */           log.debug(sm.getString("cache.sizeTracking.add", new Object[] { Long.toString(delta), cacheEntry, path, 
/* 105 */                   Long.toString(result) }));
/*     */         }
/*     */         
/* 108 */         if (this.size.get() > this.maxSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 113 */           long targetSize = this.maxSize * 95L / 100L;
/* 114 */           long newSize = evict(targetSize, this.resourceCache.values().iterator());
/* 115 */           if (newSize > this.maxSize) {
/*     */ 
/*     */             
/* 118 */             removeCacheEntry(path);
/* 119 */             log.warn(sm.getString("cache.addFail", new Object[] { path, this.root.getContext().getName() }));
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 124 */         if (cacheEntry.usesClassLoaderResources() != useClassLoaderResources)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 140 */           cacheEntry = newCacheEntry;
/*     */         }
/*     */         
/* 143 */         cacheEntry.validateResource(useClassLoaderResources);
/*     */       } 
/*     */     } else {
/* 146 */       this.hitCount.increment();
/*     */     } 
/*     */     
/* 149 */     return cacheEntry;
/*     */   }
/*     */   
/*     */   protected WebResource[] getResources(String path, boolean useClassLoaderResources) {
/* 153 */     this.lookupCount.increment();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     CachedResource cacheEntry = this.resourceCache.get(path);
/*     */     
/* 160 */     if (cacheEntry != null && !cacheEntry.validateResources(useClassLoaderResources)) {
/* 161 */       removeCacheEntry(path);
/* 162 */       cacheEntry = null;
/*     */     } 
/*     */     
/* 165 */     if (cacheEntry == null) {
/*     */       
/* 167 */       int objectMaxSizeBytes = getObjectMaxSizeBytes();
/*     */       
/* 169 */       CachedResource newCacheEntry = new CachedResource(this, this.root, path, getTtl(), objectMaxSizeBytes, useClassLoaderResources);
/*     */ 
/*     */ 
/*     */       
/* 173 */       cacheEntry = this.resourceCache.putIfAbsent(path, newCacheEntry);
/*     */       
/* 175 */       if (cacheEntry == null) {
/*     */         
/* 177 */         cacheEntry = newCacheEntry;
/* 178 */         cacheEntry.validateResources(useClassLoaderResources);
/*     */ 
/*     */         
/* 181 */         long delta = cacheEntry.getSize();
/* 182 */         long result = this.size.addAndGet(delta);
/* 183 */         if (log.isDebugEnabled()) {
/* 184 */           log.debug(sm.getString("cache.sizeTracking.add", new Object[] { Long.toString(delta), cacheEntry, path, 
/* 185 */                   Long.toString(result) }));
/*     */         }
/*     */         
/* 188 */         if (this.size.get() > this.maxSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 193 */           long targetSize = this.maxSize * 95L / 100L;
/* 194 */           long newSize = evict(targetSize, this.resourceCache.values().iterator());
/* 195 */           if (newSize > this.maxSize)
/*     */           {
/*     */             
/* 198 */             removeCacheEntry(path);
/* 199 */             log.warn(sm.getString("cache.addFail", new Object[] { path }));
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 205 */         cacheEntry.validateResources(useClassLoaderResources);
/*     */       } 
/*     */     } else {
/* 208 */       this.hitCount.increment();
/*     */     } 
/*     */     
/* 211 */     return cacheEntry.getWebResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void backgroundProcess() {
/* 219 */     TreeSet<CachedResource> orderedResources = new TreeSet<>(Comparator.comparingLong(CachedResource::getNextCheck));
/* 220 */     orderedResources.addAll(this.resourceCache.values());
/*     */     
/* 222 */     Iterator<CachedResource> iter = orderedResources.iterator();
/*     */     
/* 224 */     long targetSize = this.maxSize * 90L / 100L;
/* 225 */     long newSize = evict(targetSize, iter);
/*     */     
/* 227 */     if (newSize > targetSize) {
/* 228 */       log.info(sm.getString("cache.backgroundEvictFail", new Object[] { Long.valueOf(10L), this.root
/* 229 */               .getContext().getName(), Long.valueOf(newSize / 1024L) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean noCache(String path) {
/* 236 */     return ((path.endsWith(".class") && (path
/* 237 */       .startsWith("/WEB-INF/classes/") || path.startsWith("/WEB-INF/lib/"))) || (path
/* 238 */       .startsWith("/WEB-INF/lib/") && path.endsWith(".jar")));
/*     */   }
/*     */ 
/*     */   
/*     */   private long evict(long targetSize, Iterator<CachedResource> iter) {
/* 243 */     long now = System.currentTimeMillis();
/*     */     
/* 245 */     long newSize = this.size.get();
/*     */     
/* 247 */     while (newSize > targetSize && iter.hasNext()) {
/* 248 */       CachedResource resource = iter.next();
/*     */ 
/*     */       
/* 251 */       if (resource.getNextCheck() > now) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 256 */       removeCacheEntry(resource.getWebappPath());
/*     */       
/* 258 */       newSize = this.size.get();
/*     */     } 
/*     */     
/* 261 */     return newSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void removeCacheEntry(String path) {
/* 267 */     CachedResource cachedResource = this.resourceCache.remove(path);
/* 268 */     if (cachedResource != null) {
/* 269 */       long delta = cachedResource.getSize();
/* 270 */       long result = this.size.addAndGet(-delta);
/* 271 */       if (log.isDebugEnabled()) {
/* 272 */         log.debug(sm.getString("cache.sizeTracking.remove", new Object[] { Long.toString(delta), cachedResource, path, 
/* 273 */                 Long.toString(result) }));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public WebResourceRoot.CacheStrategy getCacheStrategy() {
/* 279 */     return this.cacheStrategy;
/*     */   }
/*     */   
/*     */   public void setCacheStrategy(WebResourceRoot.CacheStrategy cacheStrategy) {
/* 283 */     this.cacheStrategy = cacheStrategy;
/*     */   }
/*     */   
/*     */   public long getTtl() {
/* 287 */     return this.ttl;
/*     */   }
/*     */   
/*     */   public void setTtl(long ttl) {
/* 291 */     this.ttl = ttl;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMaxSize() {
/* 296 */     return this.maxSize / 1024L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxSize(long maxSize) {
/* 301 */     this.maxSize = maxSize * 1024L;
/*     */   }
/*     */   
/*     */   public long getLookupCount() {
/* 305 */     return this.lookupCount.sum();
/*     */   }
/*     */   
/*     */   public long getHitCount() {
/* 309 */     return this.hitCount.sum();
/*     */   }
/*     */   
/*     */   public void setObjectMaxSize(int objectMaxSize) {
/* 313 */     if (objectMaxSize * 1024L > 2147483647L) {
/* 314 */       log.warn(sm.getString("cache.objectMaxSizeTooBigBytes", new Object[] { Integer.valueOf(objectMaxSize) }));
/* 315 */       this.objectMaxSize = Integer.MAX_VALUE;
/*     */     } else {
/*     */       
/* 318 */       this.objectMaxSize = objectMaxSize * 1024;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getObjectMaxSize() {
/* 324 */     return this.objectMaxSize / 1024;
/*     */   }
/*     */   
/*     */   public int getObjectMaxSizeBytes() {
/* 328 */     return this.objectMaxSize;
/*     */   }
/*     */   
/*     */   void enforceObjectMaxSizeLimit() {
/* 332 */     long limit = this.maxSize / 20L;
/* 333 */     if (limit > 2147483647L) {
/*     */       return;
/*     */     }
/* 336 */     if (this.objectMaxSize > limit) {
/* 337 */       log.warn(sm.getString("cache.objectMaxSizeTooBig", new Object[] { Integer.valueOf(this.objectMaxSize / 1024), 
/* 338 */               Integer.valueOf((int)limit / 1024) }));
/* 339 */       this.objectMaxSize = (int)limit;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 344 */     this.resourceCache.clear();
/* 345 */     this.size.set(0L);
/*     */   }
/*     */   
/*     */   public long getSize() {
/* 349 */     return this.size.get() / 1024L;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\Cache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */