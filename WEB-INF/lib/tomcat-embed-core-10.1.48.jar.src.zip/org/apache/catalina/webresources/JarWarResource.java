/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.JarFile;
/*    */ import java.util.jar.JarInputStream;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.buf.UriUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarWarResource
/*    */   extends AbstractArchiveResource
/*    */ {
/* 34 */   private static final Log log = LogFactory.getLog(JarWarResource.class);
/*    */ 
/*    */   
/*    */   private final String archivePath;
/*    */ 
/*    */   
/*    */   public JarWarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry, String archivePath) {
/* 41 */     super(archiveResourceSet, webAppPath, "jar:war:" + baseUrl + UriUtil.getWarSeparator() + archivePath + "!/", jarEntry, "war:" + baseUrl + 
/* 42 */         UriUtil.getWarSeparator() + archivePath);
/* 43 */     this.archivePath = archivePath;
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractArchiveResource.JarInputStreamWrapper getJarInputStreamWrapper() {
/* 48 */     JarFile warFile = null;
/* 49 */     JarInputStream jarIs = null;
/* 50 */     JarEntry entry = null;
/*    */     try {
/* 52 */       warFile = getArchiveResourceSet().openJarFile();
/* 53 */       JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 54 */       InputStream isInWar = warFile.getInputStream(jarFileInWar);
/*    */       
/* 56 */       jarIs = new JarInputStream(isInWar);
/*    */       do {
/* 58 */         entry = jarIs.getNextJarEntry();
/* 59 */       } while (entry != null && !entry.getName().equals(getResource().getName()));
/*    */       
/* 61 */       if (entry == null) {
/* 62 */         return null;
/*    */       }
/*    */       
/* 65 */       return new AbstractArchiveResource.JarInputStreamWrapper(this, entry, jarIs);
/* 66 */     } catch (IOException ioe) {
/* 67 */       if (log.isDebugEnabled()) {
/* 68 */         log.debug(sm.getString("jarResource.getInputStreamFail", new Object[] { getResource().getName(), getBaseUrl() }), ioe);
/*    */       }
/*    */       
/* 71 */       entry = null;
/* 72 */       return null;
/*    */     } finally {
/* 74 */       if (entry == null) {
/* 75 */         if (jarIs != null) {
/*    */           try {
/* 77 */             jarIs.close();
/* 78 */           } catch (IOException iOException) {}
/*    */         }
/*    */ 
/*    */         
/* 82 */         if (warFile != null) {
/* 83 */           getArchiveResourceSet().closeJarFile();
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 91 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\JarWarResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */