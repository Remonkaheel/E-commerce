/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.compat.JrePlatform;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFileResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(AbstractFileResourceSet.class);
/*     */   
/*  34 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*     */   private File fileBase;
/*     */   private String absoluteBase;
/*     */   private String canonicalBase;
/*     */   private boolean readOnly = false;
/*     */   private Boolean allowLinking;
/*     */   
/*     */   protected AbstractFileResourceSet(String internalPath) {
/*  43 */     setInternalPath(internalPath);
/*     */   }
/*     */   
/*     */   protected final File getFileBase() {
/*  47 */     return this.fileBase;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/*  52 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/*  57 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowLinking(boolean allowLinking) {
/*  62 */     this.allowLinking = Boolean.valueOf(allowLinking);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowLinking() {
/*  67 */     if (this.allowLinking == null) {
/*  68 */       return getRoot().getAllowLinking();
/*     */     }
/*  70 */     return this.allowLinking.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final File file(String name, boolean mustExist) {
/*  75 */     if (name.equals("/")) {
/*  76 */       name = "";
/*     */     }
/*  78 */     File file = new File(this.fileBase, name);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     if (name.endsWith("/") && file.isFile()) {
/*  84 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (mustExist && !file.canRead()) {
/*  90 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  95 */     if (getAllowLinking()) {
/*  96 */       return file;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (JrePlatform.IS_WINDOWS && isInvalidWindowsFilename(name)) {
/* 102 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 106 */     String canPath = null;
/*     */     try {
/* 108 */       canPath = file.getCanonicalPath();
/* 109 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 112 */     if (canPath == null || !canPath.startsWith(this.canonicalBase)) {
/* 113 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     String absPath = normalize(file.getAbsolutePath());
/* 123 */     if (absPath == null || this.absoluteBase.length() > absPath.length()) {
/* 124 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     absPath = absPath.substring(this.absoluteBase.length());
/* 131 */     canPath = canPath.substring(this.canonicalBase.length());
/*     */ 
/*     */     
/* 134 */     if (!canPath.isEmpty() && canPath.charAt(0) != File.separatorChar) {
/* 135 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     if (!canPath.isEmpty()) {
/* 150 */       canPath = normalize(canPath);
/*     */     }
/* 152 */     if (!canPath.equals(absPath)) {
/* 153 */       if (!canPath.equalsIgnoreCase(absPath))
/*     */       {
/*     */ 
/*     */         
/* 157 */         logIgnoredSymlink(getRoot().getContext().getName(), absPath, canPath);
/*     */       }
/* 159 */       return null;
/*     */     } 
/*     */     
/* 162 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logIgnoredSymlink(String contextPath, String absPath, String canPath) {
/* 168 */     if (absPath.startsWith("/META-INF/") || absPath.startsWith("/WEB-INF/")) {
/* 169 */       log.error(sm.getString("abstractFileResourceSet.canonicalfileCheckFailed", new Object[] { contextPath, absPath, canPath }));
/*     */     } else {
/* 171 */       log.warn(sm.getString("abstractFileResourceSet.canonicalfileCheckFailed", new Object[] { contextPath, absPath, canPath }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isInvalidWindowsFilename(String name) {
/* 177 */     int len = name.length();
/* 178 */     if (len == 0) {
/* 179 */       return false;
/*     */     }
/*     */     
/* 182 */     for (int i = 0; i < len; i++) {
/* 183 */       char c = name.charAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       if (c < ' ' || c == '"' || c == '*' || c == ':' || c == '<' || c == '>' || c == '?' || c == '|') {
/* 200 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     return (name.charAt(len - 1) == ' ');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String normalize(String path) {
/* 220 */     return RequestUtil.normalize(path, (File.separatorChar == '\\'));
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getBaseUrl() {
/*     */     try {
/* 226 */       return getFileBase().toURI().toURL();
/* 227 */     } catch (MalformedURLException e) {
/* 228 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gc() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 247 */     this.fileBase = new File(getBase(), getInternalPath());
/* 248 */     checkType(this.fileBase);
/*     */     
/* 250 */     this.absoluteBase = normalize(this.fileBase.getAbsolutePath());
/*     */     
/*     */     try {
/* 253 */       this.canonicalBase = this.fileBase.getCanonicalPath();
/* 254 */     } catch (IOException ioe) {
/* 255 */       throw new IllegalArgumentException(ioe);
/*     */     } 
/*     */ 
/*     */     
/* 259 */     if ("/".equals(this.absoluteBase)) {
/* 260 */       this.absoluteBase = "";
/*     */     }
/* 262 */     if ("/".equals(this.canonicalBase))
/* 263 */       this.canonicalBase = ""; 
/*     */   }
/*     */   
/*     */   protected abstract void checkType(File paramFile);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractFileResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */