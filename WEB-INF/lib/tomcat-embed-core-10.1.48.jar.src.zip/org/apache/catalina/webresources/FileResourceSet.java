/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileResourceSet
/*     */   extends AbstractFileResourceSet
/*     */ {
/*     */   public FileResourceSet() {
/*  37 */     super("/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath) {
/*  53 */     super(internalPath);
/*  54 */     setRoot(root);
/*  55 */     setWebAppMount(webAppMount);
/*  56 */     setBase(base);
/*     */     
/*  58 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  60 */         start();
/*  61 */       } catch (LifecycleException e) {
/*  62 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResource getResource(String path) {
/*  70 */     checkPath(path);
/*     */     
/*  72 */     String webAppMount = getWebAppMount();
/*  73 */     WebResourceRoot root = getRoot();
/*  74 */     if (path.equals(webAppMount)) {
/*  75 */       File f = file("", true);
/*  76 */       if (f == null) {
/*  77 */         return new EmptyResource(root, path);
/*     */       }
/*  79 */       return new FileResource(root, path, f, isReadOnly(), null);
/*     */     } 
/*     */     
/*  82 */     if (path.charAt(path.length() - 1) != '/') {
/*  83 */       path = path + "/";
/*     */     }
/*     */     
/*  86 */     if (webAppMount.startsWith(path)) {
/*  87 */       String name = path.substring(0, path.length() - 1);
/*  88 */       name = name.substring(name.lastIndexOf('/') + 1);
/*  89 */       if (!name.isEmpty()) {
/*  90 */         return new VirtualResource(root, path, name);
/*     */       }
/*     */     } 
/*  93 */     return new EmptyResource(root, path);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] list(String path) {
/*  98 */     checkPath(path);
/*     */     
/* 100 */     if (path.charAt(path.length() - 1) != '/') {
/* 101 */       path = path + "/";
/*     */     }
/* 103 */     String webAppMount = getWebAppMount();
/*     */     
/* 105 */     if (webAppMount.startsWith(path)) {
/* 106 */       webAppMount = webAppMount.substring(path.length());
/* 107 */       if (webAppMount.equals(getFileBase().getName())) {
/* 108 */         return new String[] { getFileBase().getName() };
/*     */       }
/*     */       
/* 111 */       int i = webAppMount.indexOf('/');
/* 112 */       if (i > 0) {
/* 113 */         return new String[] { webAppMount.substring(0, i) };
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 118 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> listWebAppPaths(String path) {
/* 123 */     checkPath(path);
/*     */     
/* 125 */     ResourceSet<String> result = new ResourceSet();
/*     */     
/* 127 */     if (path.charAt(path.length() - 1) != '/') {
/* 128 */       path = path + "/";
/*     */     }
/* 130 */     String webAppMount = getWebAppMount();
/*     */     
/* 132 */     if (webAppMount.startsWith(path)) {
/* 133 */       webAppMount = webAppMount.substring(path.length());
/* 134 */       if (webAppMount.equals(getFileBase().getName())) {
/* 135 */         result.add(path + path);
/*     */       } else {
/*     */         
/* 138 */         int i = webAppMount.indexOf('/');
/* 139 */         if (i > 0) {
/* 140 */           result.add(path + path);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     result.setLocked(true);
/* 146 */     return (Set<String>)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mkdir(String path) {
/* 151 */     checkPath(path);
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean write(String path, InputStream is, boolean overwrite) {
/* 157 */     checkPath(path);
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkType(File file) {
/* 163 */     if (!file.isFile())
/* 164 */       throw new IllegalArgumentException(sm
/* 165 */           .getString("fileResourceSet.notFile", new Object[] { getBase(), File.separator, getInternalPath() })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\FileResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */