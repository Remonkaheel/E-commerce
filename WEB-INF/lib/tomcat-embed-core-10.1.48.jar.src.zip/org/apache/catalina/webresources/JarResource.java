/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.util.jar.JarEntry;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarResource
/*    */   extends AbstractSingleArchiveResource
/*    */ {
/* 29 */   private static final Log log = LogFactory.getLog(JarResource.class);
/*    */ 
/*    */ 
/*    */   
/*    */   public JarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry) {
/* 34 */     super(archiveResourceSet, webAppPath, "jar:" + baseUrl + "!/", jarEntry, baseUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Log getLog() {
/* 40 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\JarResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */