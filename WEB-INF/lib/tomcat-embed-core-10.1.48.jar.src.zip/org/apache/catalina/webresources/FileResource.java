/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResourceLockSet;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileResource
/*     */   extends AbstractResource
/*     */ {
/*  45 */   private static final Log log = LogFactory.getLog(FileResource.class); private static final boolean PROPERTIES_NEED_CONVERT; private final File resource; private final String name; private final boolean readOnly; private final Manifest manifest; private final boolean needConvert; private final WebResourceLockSet lockSet;
/*     */   private final String lockKey;
/*     */   
/*     */   static {
/*  49 */     boolean isEBCDIC = false;
/*     */     try {
/*  51 */       String encoding = Charset.defaultCharset().displayName();
/*  52 */       if (encoding.contains("EBCDIC")) {
/*  53 */         isEBCDIC = true;
/*     */       }
/*  55 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/*  58 */     PROPERTIES_NEED_CONVERT = isEBCDIC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileResource(WebResourceRoot root, String webAppPath, File resource, boolean readOnly, Manifest manifest) {
/*  71 */     this(root, webAppPath, resource, readOnly, manifest, (WebResourceLockSet)null, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FileResource(WebResourceRoot root, String webAppPath, File resource, boolean readOnly, Manifest manifest, WebResourceLockSet lockSet, String lockKey) {
/*  77 */     super(root, webAppPath);
/*  78 */     this.resource = resource;
/*  79 */     this.lockSet = lockSet;
/*  80 */     this.lockKey = lockKey;
/*     */     
/*  82 */     if (webAppPath.charAt(webAppPath.length() - 1) == '/') {
/*  83 */       String realName = resource.getName() + "/";
/*  84 */       if (webAppPath.endsWith(realName)) {
/*  85 */         this.name = resource.getName();
/*     */       }
/*     */       else {
/*     */         
/*  89 */         int endOfName = webAppPath.length() - 1;
/*  90 */         this.name = webAppPath.substring(webAppPath.lastIndexOf('/', endOfName - 1) + 1, endOfName);
/*     */       } 
/*     */     } else {
/*     */       
/*  94 */       this.name = resource.getName();
/*     */     } 
/*     */     
/*  97 */     this.readOnly = readOnly;
/*  98 */     this.manifest = manifest;
/*  99 */     this.needConvert = (PROPERTIES_NEED_CONVERT && this.name.endsWith(".properties"));
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastModified() {
/* 104 */     return this.resource.lastModified();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 109 */     return this.resource.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVirtual() {
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectory() {
/* 119 */     return this.resource.isDirectory();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 124 */     return this.resource.isFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean delete() {
/* 129 */     if (this.readOnly) {
/* 130 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     WebResourceLockSet.ResourceLock lock = null;
/* 138 */     if (this.lockSet != null) {
/* 139 */       lock = this.lockSet.lockForWrite(this.lockKey);
/*     */     }
/*     */     try {
/* 142 */       return this.resource.delete();
/*     */     } finally {
/* 144 */       if (this.lockSet != null) {
/* 145 */         this.lockSet.unlockForWrite(lock);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 152 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/* 157 */     return getContentLengthInternal(this.needConvert);
/*     */   }
/*     */   
/*     */   private long getContentLengthInternal(boolean convert) {
/* 161 */     if (convert) {
/* 162 */       byte[] content = getContent();
/* 163 */       if (content == null) {
/* 164 */         return -1L;
/*     */       }
/* 166 */       return content.length;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     if (isDirectory()) {
/* 171 */       return -1L;
/*     */     }
/*     */     
/* 174 */     return this.resource.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCanonicalPath() {
/*     */     try {
/* 180 */       return this.resource.getCanonicalPath();
/* 181 */     } catch (IOException ioe) {
/* 182 */       if (log.isDebugEnabled()) {
/* 183 */         log.debug(sm.getString("fileResource.getCanonicalPathFail", new Object[] { this.resource.getPath() }), ioe);
/*     */       }
/* 185 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 191 */     return this.resource.canRead();
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputStream doGetInputStream() {
/* 196 */     if (this.needConvert) {
/* 197 */       byte[] content = getContent();
/* 198 */       if (content == null) {
/* 199 */         return null;
/*     */       }
/* 201 */       return new ByteArrayInputStream(content);
/*     */     } 
/*     */     
/*     */     try {
/* 205 */       return new FileInputStream(this.resource);
/* 206 */     } catch (FileNotFoundException fnfe) {
/*     */       
/* 208 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getContent() {
/* 215 */     long len = getContentLengthInternal(false);
/*     */     
/* 217 */     if (len > 2147483647L) {
/*     */       
/* 219 */       if (getLog().isDebugEnabled()) {
/* 220 */         getLog().debug(sm.getString("abstractResource.getContentTooLarge", new Object[] { getWebappPath(), Long.valueOf(len) }));
/*     */       }
/* 222 */       return null;
/*     */     } 
/*     */     
/* 225 */     if (len < 0L)
/*     */     {
/* 227 */       return null;
/*     */     }
/*     */     
/* 230 */     int size = (int)len;
/* 231 */     byte[] result = new byte[size];
/*     */     
/* 233 */     int pos = 0; 
/* 234 */     try { InputStream is = new FileInputStream(this.resource); 
/* 235 */       try { while (pos < size) {
/* 236 */           int n = is.read(result, pos, size - pos);
/* 237 */           if (n < 0) {
/*     */             break;
/*     */           }
/* 240 */           pos += n;
/*     */         } 
/* 242 */         is.close(); } catch (Throwable throwable) { try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 243 */     { if (getLog().isDebugEnabled()) {
/* 244 */         getLog().debug(sm.getString("abstractResource.getContentFail", new Object[] { getWebappPath() }), ioe);
/*     */       }
/* 246 */       return null; }
/*     */ 
/*     */     
/* 249 */     if (this.needConvert) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       String str = new String(result);
/*     */       try {
/* 256 */         result = str.getBytes(StandardCharsets.UTF_8);
/* 257 */       } catch (Exception e) {
/* 258 */         result = null;
/*     */       } 
/*     */     } 
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCreation() {
/*     */     try {
/* 268 */       BasicFileAttributes attrs = Files.readAttributes(this.resource.toPath(), BasicFileAttributes.class, new java.nio.file.LinkOption[0]);
/* 269 */       return attrs.creationTime().toMillis();
/* 270 */     } catch (IOException ioe) {
/* 271 */       if (log.isDebugEnabled()) {
/* 272 */         log.debug(sm.getString("fileResource.getCreationFail", new Object[] { this.resource.getPath() }), ioe);
/*     */       }
/* 274 */       return 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getURL() {
/* 280 */     if (this.resource.exists()) {
/*     */       try {
/* 282 */         return this.resource.toURI().toURL();
/* 283 */       } catch (MalformedURLException e) {
/* 284 */         if (log.isDebugEnabled()) {
/* 285 */           log.debug(sm.getString("fileResource.getUrlFail", new Object[] { this.resource.getPath() }), e);
/*     */         }
/* 287 */         return null;
/*     */       } 
/*     */     }
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getCodeBase() {
/* 296 */     if (getWebappPath().startsWith("/WEB-INF/classes/") && this.name.endsWith(".class")) {
/* 297 */       return getWebResourceRoot().getResource("/WEB-INF/classes/").getURL();
/*     */     }
/* 299 */     return getURL();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Certificate[] getCertificates() {
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Manifest getManifest() {
/* 310 */     return this.manifest;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Log getLog() {
/* 315 */     return log;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\FileResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */