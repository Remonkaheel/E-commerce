/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceSet;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmptyResourceSet
/*     */   extends LifecycleBase
/*     */   implements WebResourceSet
/*     */ {
/*  38 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*     */   private WebResourceRoot root;
/*     */   private boolean classLoaderOnly;
/*     */   private boolean staticOnly;
/*     */   
/*     */   public EmptyResourceSet(WebResourceRoot root) {
/*  45 */     this.root = root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResource getResource(String path) {
/*  55 */     return new EmptyResource(this.root, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(String path) {
/*  65 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> listWebAppPaths(String path) {
/*  75 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mkdir(String path) {
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(String path, InputStream is, boolean overwrite) {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRoot(WebResourceRoot root) {
/* 100 */     this.root = root;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getClassLoaderOnly() {
/* 105 */     return this.classLoaderOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassLoaderOnly(boolean classLoaderOnly) {
/* 110 */     this.classLoaderOnly = classLoaderOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getStaticOnly() {
/* 115 */     return this.staticOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStaticOnly(boolean staticOnly) {
/* 120 */     this.staticOnly = staticOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getBaseUrl() {
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowLinking(boolean allowLinking) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAllowLinking() {
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gc() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 184 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 189 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\EmptyResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */