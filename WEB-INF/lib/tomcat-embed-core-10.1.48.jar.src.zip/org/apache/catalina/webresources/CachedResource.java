/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Permission;
/*     */ import java.security.cert.Certificate;
/*     */ import java.text.Collator;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedResource
/*     */   implements WebResource
/*     */ {
/*  53 */   private static final Log log = LogFactory.getLog(CachedResource.class);
/*  54 */   private static final StringManager sm = StringManager.getManager(CachedResource.class);
/*     */   
/*     */   private static final long CACHE_ENTRY_SIZE = 500L;
/*     */   
/*     */   private final Cache cache;
/*     */   
/*     */   private final StandardRoot root;
/*     */   
/*     */   private final String webAppPath;
/*     */   
/*     */   private final long ttl;
/*     */   
/*     */   private final int objectMaxSizeBytes;
/*     */   private final boolean usesClassLoaderResources;
/*     */   private volatile WebResource webResource;
/*     */   private volatile WebResource[] webResources;
/*     */   private volatile long nextCheck;
/*  71 */   private volatile Long cachedLastModified = null;
/*  72 */   private volatile String cachedLastModifiedHttp = null;
/*  73 */   private volatile byte[] cachedContent = null;
/*  74 */   private volatile Boolean cachedIsFile = null;
/*  75 */   private volatile Boolean cachedIsDirectory = null;
/*  76 */   private volatile Boolean cachedExists = null;
/*  77 */   private volatile Boolean cachedIsVirtual = null;
/*  78 */   private volatile Long cachedContentLength = null;
/*  79 */   private volatile String cachedStrongETag = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public CachedResource(Cache cache, StandardRoot root, String path, long ttl, int objectMaxSizeBytes, boolean usesClassLoaderResources) {
/*  84 */     this.cache = cache;
/*  85 */     this.root = root;
/*  86 */     this.webAppPath = path;
/*  87 */     this.ttl = ttl;
/*  88 */     this.nextCheck = ttl + System.currentTimeMillis();
/*  89 */     this.objectMaxSizeBytes = objectMaxSizeBytes;
/*  90 */     this.usesClassLoaderResources = usesClassLoaderResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean validateResource(boolean useClassLoaderResources) {
/* 101 */     if (this.usesClassLoaderResources != useClassLoaderResources) {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     if (this.webResource == null) {
/* 106 */       synchronized (this) {
/* 107 */         if (this.webResource == null) {
/* 108 */           this.webResource = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/* 109 */           getLastModified();
/* 110 */           getContentLength();
/*     */ 
/*     */           
/* 113 */           if (this.webResource instanceof EmptyResource) {
/* 114 */             this.cachedExists = Boolean.FALSE;
/*     */           } else {
/* 116 */             this.cachedExists = Boolean.TRUE;
/*     */           } 
/* 118 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 123 */     long now = System.currentTimeMillis();
/*     */     
/* 125 */     if (now < this.nextCheck) {
/* 126 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 130 */     if (!this.root.isPackedWarFile()) {
/* 131 */       WebResource webResourceInternal = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/* 132 */       if (!this.webResource.exists() && webResourceInternal.exists()) {
/* 133 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 138 */       if (this.webResource.getLastModified() != getLastModified() || this.webResource
/* 139 */         .getContentLength() != getContentLength()) {
/* 140 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 144 */       if (this.webResource.getLastModified() != webResourceInternal.getLastModified() || this.webResource
/* 145 */         .getContentLength() != webResourceInternal.getContentLength()) {
/* 146 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 150 */     this.nextCheck = this.ttl + now;
/* 151 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean validateResources(boolean useClassLoaderResources) {
/* 155 */     long now = System.currentTimeMillis();
/*     */     
/* 157 */     if (this.webResources == null) {
/* 158 */       synchronized (this) {
/* 159 */         if (this.webResources == null) {
/* 160 */           this.webResources = this.root.getResourcesInternal(this.webAppPath, useClassLoaderResources);
/* 161 */           this.nextCheck = this.ttl + now;
/* 162 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 167 */     if (now < this.nextCheck) {
/* 168 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 172 */     if (this.root.isPackedWarFile()) {
/* 173 */       this.nextCheck = this.ttl + now;
/* 174 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected long getNextCheck() {
/* 183 */     return this.nextCheck;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastModified() {
/* 188 */     if (this.cachedLastModified == null) {
/* 189 */       this.cachedLastModified = Long.valueOf(this.webResource.getLastModified());
/*     */     }
/* 191 */     return this.cachedLastModified.longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLastModifiedHttp() {
/* 196 */     if (this.cachedLastModifiedHttp == null) {
/* 197 */       this.cachedLastModifiedHttp = this.webResource.getLastModifiedHttp();
/*     */     }
/* 199 */     return this.cachedLastModifiedHttp;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 204 */     if (this.cachedExists == null) {
/* 205 */       this.cachedExists = Boolean.valueOf(this.webResource.exists());
/*     */     }
/* 207 */     return this.cachedExists.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVirtual() {
/* 212 */     if (this.cachedIsVirtual == null) {
/* 213 */       this.cachedIsVirtual = Boolean.valueOf(this.webResource.isVirtual());
/*     */     }
/* 215 */     return this.cachedIsVirtual.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectory() {
/* 220 */     if (this.cachedIsDirectory == null) {
/* 221 */       this.cachedIsDirectory = Boolean.valueOf(this.webResource.isDirectory());
/*     */     }
/* 223 */     return this.cachedIsDirectory.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 228 */     if (this.cachedIsFile == null) {
/* 229 */       this.cachedIsFile = Boolean.valueOf(this.webResource.isFile());
/*     */     }
/* 231 */     return this.cachedIsFile.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean delete() {
/* 236 */     boolean deleteResult = this.webResource.delete();
/* 237 */     if (deleteResult) {
/* 238 */       this.cache.removeCacheEntry(this.webAppPath);
/*     */     }
/* 240 */     return deleteResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 245 */     return this.webResource.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/* 261 */     if (this.cachedContentLength == null) {
/* 262 */       if (this.webResource == null) {
/* 263 */         synchronized (this) {
/* 264 */           if (this.webResource == null) {
/* 265 */             this.webResource = this.root.getResourceInternal(this.webAppPath, this.usesClassLoaderResources);
/*     */           }
/*     */         } 
/*     */       }
/* 269 */       this.cachedContentLength = Long.valueOf(this.webResource.getContentLength());
/*     */     } 
/* 271 */     return this.cachedContentLength.longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCanonicalPath() {
/* 276 */     return this.webResource.getCanonicalPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead() {
/* 281 */     return this.webResource.canRead();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getWebappPath() {
/* 286 */     return this.webAppPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getETag() {
/* 291 */     return this.webResource.getETag();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStrongETag() {
/* 296 */     if (this.cachedStrongETag == null) {
/* 297 */       byte[] buf = getContent();
/* 298 */       if (buf != null) {
/* 299 */         buf = ConcurrentMessageDigest.digestSHA256(new byte[][] { buf });
/* 300 */         this.cachedStrongETag = "\"" + HexUtils.toHexString(buf) + "\"";
/*     */       } else {
/* 302 */         this.cachedStrongETag = this.webResource.getStrongETag();
/*     */       } 
/*     */     } 
/* 305 */     return this.cachedStrongETag;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMimeType(String mimeType) {
/* 310 */     this.webResource.setMimeType(mimeType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMimeType() {
/* 315 */     return this.webResource.getMimeType();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/* 320 */     byte[] content = getContent();
/* 321 */     if (content == null)
/*     */     {
/* 323 */       return this.webResource.getInputStream();
/*     */     }
/* 325 */     return new ByteArrayInputStream(content);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getContent() {
/* 330 */     if (this.cachedContent == null) {
/* 331 */       if (getContentLength() > this.objectMaxSizeBytes) {
/* 332 */         return null;
/*     */       }
/* 334 */       this.cachedContent = this.webResource.getContent();
/*     */     } 
/* 336 */     return this.cachedContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCreation() {
/* 341 */     return this.webResource.getCreation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getURL() {
/* 368 */     URL resourceURL = this.webResource.getURL();
/* 369 */     if (resourceURL == null) {
/* 370 */       return null;
/*     */     }
/*     */     try {
/* 373 */       CachedResourceURLStreamHandler handler = new CachedResourceURLStreamHandler(resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */       
/* 375 */       URL result = new URL(null, resourceURL.toExternalForm(), handler);
/* 376 */       handler.setCacheURL(result);
/* 377 */       return result;
/* 378 */     } catch (MalformedURLException e) {
/* 379 */       log.error(sm.getString("cachedResource.invalidURL", new Object[] { resourceURL.toExternalForm() }), e);
/* 380 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getCodeBase() {
/* 386 */     return this.webResource.getCodeBase();
/*     */   }
/*     */ 
/*     */   
/*     */   public Certificate[] getCertificates() {
/* 391 */     return this.webResource.getCertificates();
/*     */   }
/*     */ 
/*     */   
/*     */   public Manifest getManifest() {
/* 396 */     return this.webResource.getManifest();
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceRoot getWebResourceRoot() {
/* 401 */     return this.webResource.getWebResourceRoot();
/*     */   }
/*     */   
/*     */   WebResource getWebResource() {
/* 405 */     return this.webResource;
/*     */   }
/*     */   
/*     */   WebResource[] getWebResources() {
/* 409 */     return this.webResources;
/*     */   }
/*     */   
/*     */   boolean usesClassLoaderResources() {
/* 413 */     return this.usesClassLoaderResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getSize() {
/* 421 */     long result = 500L;
/*     */ 
/*     */ 
/*     */     
/* 425 */     result += getWebappPath().length() * 2L;
/* 426 */     if (getContentLength() <= this.objectMaxSizeBytes) {
/* 427 */       result += getContentLength();
/*     */     }
/* 429 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static InputStream buildInputStream(String[] files) {
/* 437 */     Arrays.sort(files, Collator.getInstance(Locale.getDefault()));
/* 438 */     StringBuilder result = new StringBuilder();
/* 439 */     for (String file : files) {
/* 440 */       result.append(file);
/*     */       
/* 442 */       result.append('\n');
/*     */     } 
/* 444 */     return new ByteArrayInputStream(result.toString().getBytes(Charset.defaultCharset()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CachedResourceURLStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     private final URL resourceURL;
/*     */ 
/*     */     
/*     */     private final StandardRoot root;
/*     */ 
/*     */     
/*     */     private final String webAppPath;
/*     */ 
/*     */     
/*     */     private final boolean usesClassLoaderResources;
/*     */ 
/*     */     
/* 464 */     private URL cacheURL = null;
/*     */ 
/*     */     
/*     */     CachedResourceURLStreamHandler(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources) {
/* 468 */       this.resourceURL = resourceURL;
/* 469 */       this.root = root;
/* 470 */       this.webAppPath = webAppPath;
/* 471 */       this.usesClassLoaderResources = usesClassLoaderResources;
/*     */     }
/*     */     
/*     */     protected void setCacheURL(URL cacheURL) {
/* 475 */       this.cacheURL = cacheURL;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected URLConnection openConnection(URL u) throws IOException {
/*     */       URI constructedURI;
/* 483 */       if (this.cacheURL != null && u == this.cacheURL) {
/* 484 */         if ("jar".equals(this.cacheURL.getProtocol())) {
/* 485 */           return new CachedResource.CachedResourceJarURLConnection(this.resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */         }
/* 487 */         return new CachedResource.CachedResourceURLConnection(this.resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 494 */         constructedURI = new URI(u.toExternalForm());
/* 495 */       } catch (URISyntaxException e) {
/*     */         
/* 497 */         throw new IOException(e);
/*     */       } 
/* 499 */       URL constructedURL = constructedURI.toURL();
/* 500 */       return constructedURL.openConnection();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean equals(URL u1, URL u2) {
/* 514 */       if (this.cacheURL == u1) {
/* 515 */         return this.resourceURL.equals(u2);
/*     */       }
/*     */ 
/*     */       
/* 519 */       return super.equals(u1, u2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected int hashCode(URL u) {
/* 532 */       if (this.cacheURL == u) {
/* 533 */         return this.resourceURL.hashCode();
/*     */       }
/*     */ 
/*     */       
/* 537 */       return super.hashCode(u);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CachedResourceURLConnection
/*     */     extends URLConnection
/*     */   {
/*     */     private final StandardRoot root;
/*     */     
/*     */     private final String webAppPath;
/*     */     
/*     */     private final boolean usesClassLoaderResources;
/*     */     
/*     */     private final URL resourceURL;
/*     */     
/*     */     protected CachedResourceURLConnection(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources) {
/* 554 */       super(resourceURL);
/* 555 */       this.root = root;
/* 556 */       this.webAppPath = webAppPath;
/* 557 */       this.usesClassLoaderResources = usesClassLoaderResources;
/* 558 */       this.resourceURL = resourceURL;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 568 */       WebResource resource = getResource();
/* 569 */       if (resource.isDirectory()) {
/* 570 */         return CachedResource.buildInputStream(resource.getWebResourceRoot().list(this.webAppPath));
/*     */       }
/* 572 */       return getResource().getInputStream();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Permission getPermission() throws IOException {
/* 579 */       return this.resourceURL.openConnection().getPermission();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLastModified() {
/* 584 */       return getResource().getLastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getContentLengthLong() {
/* 589 */       return getResource().getContentLength();
/*     */     }
/*     */     
/*     */     private WebResource getResource() {
/* 593 */       return this.root.getResource(this.webAppPath, false, this.usesClassLoaderResources);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 599 */       return Objects.<String>requireNonNullElse(getResource().getMimeType(), "content/unknown");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CachedResourceJarURLConnection
/*     */     extends JarURLConnection
/*     */   {
/*     */     private final StandardRoot root;
/*     */     
/*     */     private final String webAppPath;
/*     */     
/*     */     private final boolean usesClassLoaderResources;
/*     */     
/*     */     private final URL resourceURL;
/*     */     
/*     */     protected CachedResourceJarURLConnection(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources) throws IOException {
/* 616 */       super(resourceURL);
/* 617 */       this.root = root;
/* 618 */       this.webAppPath = webAppPath;
/* 619 */       this.usesClassLoaderResources = usesClassLoaderResources;
/* 620 */       this.resourceURL = resourceURL;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 630 */       WebResource resource = getResource();
/* 631 */       if (resource.isDirectory()) {
/* 632 */         return CachedResource.buildInputStream(resource.getWebResourceRoot().list(this.webAppPath));
/*     */       }
/* 634 */       return getResource().getInputStream();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Permission getPermission() throws IOException {
/* 641 */       return this.resourceURL.openConnection().getPermission();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLastModified() {
/* 646 */       return getResource().getLastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getContentLengthLong() {
/* 651 */       return getResource().getContentLength();
/*     */     }
/*     */     
/*     */     private WebResource getResource() {
/* 655 */       return this.root.getResource(this.webAppPath, false, this.usesClassLoaderResources);
/*     */     }
/*     */ 
/*     */     
/*     */     public JarFile getJarFile() throws IOException {
/* 660 */       return ((JarURLConnection)this.resourceURL.openConnection()).getJarFile();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\CachedResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */