/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.security.MessageDigest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResource
/*     */   implements WebResource
/*     */ {
/*  32 */   protected static final StringManager sm = StringManager.getManager(AbstractResource.class);
/*     */   
/*     */   private final WebResourceRoot root;
/*     */   
/*     */   private final String webAppPath;
/*  37 */   private String mimeType = null;
/*     */   
/*     */   private volatile String weakETag;
/*     */   private volatile String strongETag;
/*     */   
/*     */   protected AbstractResource(WebResourceRoot root, String webAppPath) {
/*  43 */     this.root = root;
/*  44 */     this.webAppPath = webAppPath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final WebResourceRoot getWebResourceRoot() {
/*  50 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getWebappPath() {
/*  56 */     return this.webAppPath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLastModifiedHttp() {
/*  62 */     return FastHttpDateFormat.formatDate(getLastModified());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getETag() {
/*  68 */     if (this.weakETag == null) {
/*  69 */       synchronized (this) {
/*  70 */         if (this.weakETag == null) {
/*  71 */           long contentLength = getContentLength();
/*  72 */           long lastModified = getLastModified();
/*  73 */           if (contentLength >= 0L || lastModified >= 0L) {
/*  74 */             this.weakETag = "W/\"" + contentLength + "-" + lastModified + "\"";
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  79 */     return this.weakETag;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getStrongETag() {
/*  84 */     if (this.strongETag == null) {
/*  85 */       synchronized (this) {
/*  86 */         if (this.strongETag == null) {
/*  87 */           long contentLength = getContentLength();
/*  88 */           long lastModified = getLastModified();
/*  89 */           if (contentLength > 0L && lastModified > 0L) {
/*  90 */             if (contentLength <= 16384L) {
/*  91 */               byte[] buf = getContent();
/*  92 */               if (buf != null) {
/*  93 */                 buf = ConcurrentMessageDigest.digestSHA256(new byte[][] { buf });
/*  94 */                 this.strongETag = "\"" + HexUtils.toHexString(buf) + "\"";
/*     */               } else {
/*  96 */                 this.strongETag = getETag();
/*     */               } 
/*     */             } else {
/*  99 */               byte[] buf = new byte[4096]; 
/* 100 */               try { InputStream is = getInputStream(); 
/* 101 */                 try { MessageDigest digest = MessageDigest.getInstance("SHA-256");
/*     */                   while (true) {
/* 103 */                     int n = is.read(buf);
/* 104 */                     if (n <= 0) {
/*     */                       break;
/*     */                     }
/* 107 */                     digest.update(buf, 0, n);
/*     */                   } 
/* 109 */                   this.strongETag = "\"" + HexUtils.toHexString(digest.digest()) + "\"";
/* 110 */                   if (is != null) is.close();  } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception e)
/* 111 */               { this.strongETag = getETag(); }
/*     */             
/*     */             } 
/*     */           } else {
/* 115 */             this.strongETag = getETag();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 120 */     return this.strongETag;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setMimeType(String mimeType) {
/* 125 */     this.mimeType = mimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMimeType() {
/* 131 */     if (this.mimeType == null) {
/* 132 */       String name = getName();
/* 133 */       int extensionStart = name.lastIndexOf('.');
/* 134 */       if (extensionStart > -1) {
/* 135 */         String extension = name.substring(extensionStart + 1);
/* 136 */         this.mimeType = this.root.getContext().findMimeMapping(extension);
/*     */       } 
/*     */     } 
/* 139 */     return this.mimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final InputStream getInputStream() {
/* 145 */     InputStream is = doGetInputStream();
/*     */     
/* 147 */     if (is == null || !this.root.getTrackLockedFiles()) {
/* 148 */       return is;
/*     */     }
/*     */     
/* 151 */     return new TrackedInputStream(this.root, getName(), is);
/*     */   }
/*     */   
/*     */   protected abstract InputStream doGetInputStream();
/*     */   
/*     */   protected abstract Log getLog();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */