/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarWarResourceSet
/*     */   extends AbstractArchiveResourceSet
/*     */ {
/*     */   private final String archivePath;
/*     */   
/*     */   public JarWarResourceSet(WebResourceRoot root, String webAppMount, String base, String archivePath, String internalPath) throws IllegalArgumentException {
/*  63 */     setRoot(root);
/*  64 */     setWebAppMount(webAppMount);
/*  65 */     setBase(base);
/*  66 */     this.archivePath = archivePath;
/*  67 */     setInternalPath(internalPath);
/*     */     
/*  69 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  71 */         start();
/*  72 */       } catch (LifecycleException e) {
/*  73 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected WebResource createArchiveResource(JarEntry jarEntry, String webAppPath, Manifest manifest) {
/*  80 */     return new JarWarResource(this, webAppPath, getBaseUrlString(), jarEntry, this.archivePath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, JarEntry> getArchiveEntries(boolean single) {
/*  91 */     synchronized (this.archiveLock) {
/*  92 */       if (this.archiveEntries == null) {
/*  93 */         JarFile warFile = null;
/*  94 */         InputStream jarFileIs = null;
/*  95 */         this.archiveEntries = new HashMap<>();
/*  96 */         boolean multiRelease = false;
/*     */         try {
/*  98 */           warFile = openJarFile();
/*  99 */           JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 100 */           jarFileIs = warFile.getInputStream(jarFileInWar);
/*     */           
/* 102 */           TomcatJarInputStream jarIs = new TomcatJarInputStream(jarFileIs); 
/* 103 */           try { JarEntry entry = jarIs.getNextJarEntry();
/* 104 */             while (entry != null) {
/* 105 */               this.archiveEntries.put(entry.getName(), entry);
/* 106 */               entry = jarIs.getNextJarEntry();
/*     */             } 
/* 108 */             Manifest m = jarIs.getManifest();
/* 109 */             setManifest(m);
/* 110 */             if (m != null) {
/* 111 */               String value = m.getMainAttributes().getValue("Multi-Release");
/* 112 */               if (value != null) {
/* 113 */                 multiRelease = Boolean.parseBoolean(value);
/*     */               }
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 122 */             entry = jarIs.getMetaInfEntry();
/* 123 */             if (entry != null) {
/* 124 */               this.archiveEntries.put(entry.getName(), entry);
/*     */             }
/* 126 */             entry = jarIs.getManifestEntry();
/* 127 */             if (entry != null) {
/* 128 */               this.archiveEntries.put(entry.getName(), entry);
/*     */             }
/* 130 */             jarIs.close(); } catch (Throwable throwable) { try { jarIs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 131 */            if (multiRelease) {
/* 132 */             processArchivesEntriesForMultiRelease();
/*     */           }
/* 134 */         } catch (IOException ioe) {
/*     */           
/* 136 */           this.archiveEntries = null;
/* 137 */           throw new IllegalStateException(ioe);
/*     */         } finally {
/* 139 */           if (warFile != null) {
/* 140 */             closeJarFile();
/*     */           }
/* 142 */           if (jarFileIs != null) {
/*     */             try {
/* 144 */               jarFileIs.close();
/* 145 */             } catch (IOException iOException) {}
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 151 */       WebResourceRoot root = getRoot();
/* 152 */       if (root.getArchiveIndexStrategyEnum().getUsesBloom()) {
/* 153 */         this.jarContents = new JarContents(this.archiveEntries.values());
/* 154 */         this.retainBloomFilterForArchives = root.getArchiveIndexStrategyEnum().getRetain();
/*     */       } 
/* 156 */       return this.archiveEntries;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JarFile openJarFile() throws IOException {
/* 168 */     synchronized (this.archiveLock) {
/* 169 */       if (this.archive == null) {
/* 170 */         this.archive = new JarFile(new File(getBase()), true, 1, Runtime.version());
/*     */       }
/*     */       
/* 173 */       this.archiveUseCount++;
/* 174 */       return this.archive;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processArchivesEntriesForMultiRelease() {
/* 181 */     int targetVersion = Runtime.version().feature();
/*     */     
/* 183 */     Map<String, VersionedJarEntry> versionedEntries = new HashMap<>();
/* 184 */     Iterator<Map.Entry<String, JarEntry>> iter = this.archiveEntries.entrySet().iterator();
/* 185 */     while (iter.hasNext()) {
/* 186 */       Map.Entry<String, JarEntry> entry = iter.next();
/* 187 */       String name = entry.getKey();
/* 188 */       if (name.startsWith("META-INF/versions/")) {
/*     */         
/* 190 */         iter.remove();
/*     */ 
/*     */         
/* 193 */         int i = name.indexOf('/', 18);
/* 194 */         if (i > 0) {
/* 195 */           String baseName = name.substring(i + 1);
/* 196 */           int version = Integer.parseInt(name.substring(18, i));
/*     */ 
/*     */ 
/*     */           
/* 200 */           if (version <= targetVersion) {
/* 201 */             VersionedJarEntry versionedJarEntry = versionedEntries.get(baseName);
/* 202 */             if (versionedJarEntry == null) {
/*     */ 
/*     */               
/* 205 */               versionedEntries.put(baseName, new VersionedJarEntry(version, entry.getValue()));
/*     */               
/*     */               continue;
/*     */             } 
/* 209 */             if (version > versionedJarEntry.getVersion())
/*     */             {
/*     */               
/* 212 */               versionedEntries.put(baseName, new VersionedJarEntry(version, entry.getValue()));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 220 */     for (Map.Entry<String, VersionedJarEntry> versionedJarEntry : versionedEntries.entrySet()) {
/* 221 */       this.archiveEntries.put(versionedJarEntry.getKey(), ((VersionedJarEntry)versionedJarEntry.getValue()).getJarEntry());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JarEntry getArchiveEntry(String pathInArchive) {
/* 233 */     throw new IllegalStateException(sm.getString("jarWarResourceSet.codingError"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMultiRelease() {
/* 241 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/*     */     
/* 249 */     try { JarFile warFile = new JarFile(getBase()); 
/* 250 */       try { JarEntry jarFileInWar = warFile.getJarEntry(this.archivePath);
/* 251 */         InputStream jarFileIs = warFile.getInputStream(jarFileInWar);
/*     */         
/* 253 */         JarInputStream jarIs = new JarInputStream(jarFileIs); 
/* 254 */         try { setManifest(jarIs.getManifest());
/* 255 */           jarIs.close(); } catch (Throwable throwable) { try { jarIs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 256 */          warFile.close(); } catch (Throwable throwable) { try { warFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 257 */     { throw new IllegalArgumentException(ioe); }
/*     */ 
/*     */     
/*     */     try {
/* 261 */       setBaseUrl(UriUtil.buildJarSafeUrl(new File(getBase())));
/* 262 */     } catch (MalformedURLException e) {
/* 263 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class VersionedJarEntry
/*     */   {
/*     */     private final int version;
/*     */     private final JarEntry jarEntry;
/*     */     
/*     */     VersionedJarEntry(int version, JarEntry jarEntry) {
/* 273 */       this.version = version;
/* 274 */       this.jarEntry = jarEntry;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getVersion() {
/* 279 */       return this.version;
/*     */     }
/*     */ 
/*     */     
/*     */     public JarEntry getJarEntry() {
/* 284 */       return this.jarEntry;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\JarWarResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */