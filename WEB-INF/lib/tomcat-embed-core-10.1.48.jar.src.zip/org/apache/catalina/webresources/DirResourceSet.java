/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceLockSet;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirResourceSet
/*     */   extends AbstractFileResourceSet
/*     */   implements WebResourceLockSet
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(DirResourceSet.class);
/*     */   
/*  50 */   private final Map<String, WebResourceLockSet.ResourceLock> resourceLocksByPath = new HashMap<>();
/*  51 */   private final Object resourceLocksByPathLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirResourceSet() {
/*  58 */     super("/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath) {
/*  75 */     super(internalPath);
/*  76 */     setRoot(root);
/*  77 */     setWebAppMount(webAppMount);
/*  78 */     setBase(base);
/*     */     
/*  80 */     if (root.getContext().getAddWebinfClassesResources()) {
/*  81 */       File f = new File(base, internalPath);
/*  82 */       f = new File(f, "/WEB-INF/classes/META-INF/resources");
/*     */       
/*  84 */       if (f.isDirectory()) {
/*  85 */         root.createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", f.getAbsolutePath(), null, "/");
/*     */       }
/*     */     } 
/*     */     
/*  89 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  91 */         start();
/*  92 */       } catch (LifecycleException e) {
/*  93 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResource getResource(String path) {
/* 102 */     checkPath(path);
/* 103 */     String webAppMount = getWebAppMount();
/* 104 */     WebResourceRoot root = getRoot();
/* 105 */     boolean readOnly = isReadOnly();
/* 106 */     if (isPathMounted(path, webAppMount)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       WebResourceLockSet.ResourceLock lock = readOnly ? null : lockForRead(path);
/*     */       try {
/* 114 */         File f = file(path.substring(webAppMount.length()), false);
/* 115 */         if (f == null) {
/* 116 */           return new EmptyResource(root, path);
/*     */         }
/* 118 */         if (!f.exists()) {
/* 119 */           return new EmptyResource(root, path, f);
/*     */         }
/* 121 */         if (f.isDirectory() && path.charAt(path.length() - 1) != '/') {
/* 122 */           path = path + "/";
/*     */         }
/* 124 */         return new FileResource(root, path, f, readOnly, getManifest(), this, readOnly ? null : lock.key);
/*     */       } finally {
/* 126 */         if (!readOnly) {
/* 127 */           unlockForRead(lock);
/*     */         }
/*     */       } 
/*     */     } 
/* 131 */     return new EmptyResource(root, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(String path) {
/* 138 */     checkPath(path);
/* 139 */     String webAppMount = getWebAppMount();
/* 140 */     if (isPathMounted(path, webAppMount)) {
/* 141 */       File f = file(path.substring(webAppMount.length()), true);
/* 142 */       if (f == null) {
/* 143 */         return EMPTY_STRING_ARRAY;
/*     */       }
/* 145 */       String[] result = f.list();
/* 146 */       return Objects.<String[]>requireNonNullElse(result, EMPTY_STRING_ARRAY);
/*     */     } 
/* 148 */     if (!path.endsWith("/")) {
/* 149 */       path = path + "/";
/*     */     }
/* 151 */     if (webAppMount.startsWith(path)) {
/* 152 */       int i = webAppMount.indexOf('/', path.length());
/* 153 */       if (i == -1) {
/* 154 */         return new String[] { webAppMount.substring(path.length()) };
/*     */       }
/* 156 */       return new String[] { webAppMount.substring(path.length(), i) };
/*     */     } 
/*     */     
/* 159 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> listWebAppPaths(String path) {
/* 165 */     checkPath(path);
/* 166 */     String webAppMount = getWebAppMount();
/* 167 */     ResourceSet<String> result = new ResourceSet();
/* 168 */     if (isPathMounted(path, webAppMount)) {
/* 169 */       File f = file(path.substring(webAppMount.length()), true);
/* 170 */       if (f != null) {
/* 171 */         File[] list = f.listFiles();
/* 172 */         if (list != null) {
/* 173 */           String fCanPath = null;
/* 174 */           for (File entry : list) {
/*     */ 
/*     */             
/* 177 */             if (!getAllowLinking()) {
/*     */ 
/*     */               
/* 180 */               boolean symlink = true;
/* 181 */               String absPath = null;
/* 182 */               String canPath = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 189 */                 absPath = entry.getAbsolutePath().substring(f.getAbsolutePath().length());
/* 190 */                 String entryCanPath = entry.getCanonicalPath();
/* 191 */                 if (fCanPath == null) {
/* 192 */                   fCanPath = f.getCanonicalPath();
/*     */                 }
/* 194 */                 if (entryCanPath.length() >= fCanPath.length()) {
/* 195 */                   canPath = entryCanPath.substring(fCanPath.length());
/* 196 */                   if (absPath.equals(canPath)) {
/* 197 */                     symlink = false;
/*     */                   }
/*     */                 } 
/* 200 */               } catch (IOException ioe) {
/*     */                 
/* 202 */                 canPath = "Unknown";
/*     */               } 
/* 204 */               if (symlink) {
/* 205 */                 logIgnoredSymlink(getRoot().getContext().getName(), absPath, canPath);
/*     */                 continue;
/*     */               } 
/*     */             } 
/* 209 */             StringBuilder sb = new StringBuilder(path);
/* 210 */             if (path.charAt(path.length() - 1) != '/') {
/* 211 */               sb.append('/');
/*     */             }
/* 213 */             sb.append(entry.getName());
/* 214 */             if (entry.isDirectory()) {
/* 215 */               sb.append('/');
/*     */             }
/* 217 */             result.add(sb.toString()); continue;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 222 */       if (!path.endsWith("/")) {
/* 223 */         path = path + "/";
/*     */       }
/* 225 */       if (webAppMount.startsWith(path)) {
/* 226 */         int i = webAppMount.indexOf('/', path.length());
/* 227 */         if (i == -1) {
/* 228 */           result.add(webAppMount + "/");
/*     */         } else {
/* 230 */           result.add(webAppMount.substring(0, i + 1));
/*     */         } 
/*     */       } 
/*     */     } 
/* 234 */     result.setLocked(true);
/* 235 */     return (Set<String>)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mkdir(String path) {
/* 240 */     checkPath(path);
/* 241 */     if (isReadOnly()) {
/* 242 */       return false;
/*     */     }
/* 244 */     String webAppMount = getWebAppMount();
/* 245 */     if (isPathMounted(path, webAppMount)) {
/* 246 */       File f = file(path.substring(webAppMount.length()), false);
/* 247 */       if (f == null) {
/* 248 */         return false;
/*     */       }
/* 250 */       return f.mkdir();
/*     */     } 
/* 252 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(String path, InputStream is, boolean overwrite) {
/* 258 */     checkPath(path);
/*     */     
/* 260 */     if (is == null) {
/* 261 */       throw new NullPointerException(sm.getString("dirResourceSet.writeNpe"));
/*     */     }
/*     */     
/* 264 */     if (isReadOnly()) {
/* 265 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (path.endsWith("/")) {
/* 271 */       return false;
/*     */     }
/*     */     
/* 274 */     String webAppMount = getWebAppMount();
/* 275 */     if (!isPathMounted(path, webAppMount)) {
/* 276 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     WebResourceLockSet.ResourceLock lock = lockForWrite(path);
/*     */     try {
/* 287 */       File dest = file(path.substring(webAppMount.length()), false);
/* 288 */       if (dest == null) {
/* 289 */         return false;
/*     */       }
/*     */       
/* 292 */       if (dest.exists() && !overwrite) {
/* 293 */         return false;
/*     */       }
/*     */       
/*     */       try {
/* 297 */         if (overwrite) {
/* 298 */           Files.copy(is, dest.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */         } else {
/* 300 */           Files.copy(is, dest.toPath(), new CopyOption[0]);
/*     */         } 
/* 302 */       } catch (IOException ioe) {
/* 303 */         return false;
/*     */       } 
/*     */       
/* 306 */       return true;
/*     */     } finally {
/* 308 */       unlockForWrite(lock);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkType(File file) {
/* 314 */     if (!file.isDirectory()) {
/* 315 */       throw new IllegalArgumentException(sm
/* 316 */           .getString("dirResourceSet.notDirectory", new Object[] { getBase(), File.separator, getInternalPath() }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 323 */     super.initInternal();
/*     */     
/* 325 */     if (getWebAppMount().isEmpty()) {
/*     */       
/* 327 */       File mf = file("META-INF/MANIFEST.MF", true);
/* 328 */       if (mf != null && mf.isFile()) {
/* 329 */         try { FileInputStream fis = new FileInputStream(mf); 
/* 330 */           try { setManifest(new Manifest(fis));
/* 331 */             fis.close(); } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 332 */         { log.warn(sm.getString("dirResourceSet.manifestFail", new Object[] { mf.getAbsolutePath() }), ioe); }
/*     */       
/*     */       }
/*     */     } 
/*     */     
/* 337 */     if (isReadOnly()) {
/*     */       return;
/*     */     }
/*     */     
/* 341 */     if (JreCompat.getInstance().isCanonCachesDisabled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 346 */     if (JreCompat.getInstance().disableCanonCaches()) {
/*     */ 
/*     */ 
/*     */       
/* 350 */       log.warn(sm.getString("dirResourceSet.canonCaches.disabled", new Object[] { getFileBase(), 
/* 351 */               getRoot().getContext().getName() }));
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 357 */       throw new IllegalStateException(sm.getString("dirResourceSet.canonCaches.enabled", new Object[] { getFileBase(), 
/* 358 */               getRoot().getContext().getName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLockKey(String path) {
/* 372 */     return RequestUtil.normalize(path).toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceLockSet.ResourceLock lockForRead(String path) {
/*     */     WebResourceLockSet.ResourceLock resourceLock;
/* 378 */     String key = getLockKey(path);
/*     */     
/* 380 */     synchronized (this.resourceLocksByPathLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 385 */       resourceLock = this.resourceLocksByPath.get(key);
/* 386 */       if (resourceLock == null) {
/* 387 */         resourceLock = new WebResourceLockSet.ResourceLock(key);
/* 388 */         this.resourceLocksByPath.put(key, resourceLock);
/*     */       } 
/* 390 */       resourceLock.count.incrementAndGet();
/*     */     } 
/*     */     
/* 393 */     resourceLock.reentrantLock.readLock().lock();
/* 394 */     return resourceLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlockForRead(WebResourceLockSet.ResourceLock resourceLock) {
/* 401 */     resourceLock.reentrantLock.readLock().unlock();
/* 402 */     synchronized (this.resourceLocksByPathLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 407 */       if (resourceLock.count.decrementAndGet() == 0) {
/* 408 */         this.resourceLocksByPath.remove(resourceLock.key);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceLockSet.ResourceLock lockForWrite(String path) {
/*     */     WebResourceLockSet.ResourceLock resourceLock;
/* 416 */     String key = getLockKey(path);
/*     */     
/* 418 */     synchronized (this.resourceLocksByPathLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 423 */       resourceLock = this.resourceLocksByPath.get(key);
/* 424 */       if (resourceLock == null) {
/* 425 */         resourceLock = new WebResourceLockSet.ResourceLock(key);
/* 426 */         this.resourceLocksByPath.put(key, resourceLock);
/*     */       } 
/* 428 */       resourceLock.count.incrementAndGet();
/*     */     } 
/*     */     
/* 431 */     resourceLock.reentrantLock.writeLock().lock();
/* 432 */     return resourceLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlockForWrite(WebResourceLockSet.ResourceLock resourceLock) {
/* 439 */     resourceLock.reentrantLock.writeLock().unlock();
/* 440 */     synchronized (this.resourceLocksByPathLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 445 */       if (resourceLock.count.decrementAndGet() == 0)
/* 446 */         this.resourceLocksByPath.remove(resourceLock.key); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\DirResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */