/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.Manifest;
/*    */ import org.apache.catalina.WebResource;
/*    */ import org.apache.catalina.WebResourceRoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarResourceSet
/*    */   extends AbstractSingleArchiveResourceSet
/*    */ {
/*    */   public WarResourceSet() {}
/*    */   
/*    */   public WarResourceSet(WebResourceRoot root, String webAppMount, String base) throws IllegalArgumentException {
/* 49 */     super(root, webAppMount, base, "/");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected WebResource createArchiveResource(JarEntry jarEntry, String webAppPath, Manifest manifest) {
/* 55 */     return new WarResource(this, webAppPath, getBaseUrlString(), jarEntry);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\WarResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */