/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.TrackedWebResource;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceSet;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardRoot
/*     */   extends LifecycleMBeanBase
/*     */   implements WebResourceRoot
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(StandardRoot.class);
/*  66 */   protected static final StringManager sm = StringManager.getManager(StandardRoot.class);
/*     */   
/*     */   private Context context;
/*     */   private boolean allowLinking = false;
/*     */   private boolean readOnly = false;
/*  71 */   private final List<WebResourceSet> preResources = new ArrayList<>();
/*     */   private WebResourceSet main;
/*  73 */   private final List<WebResourceSet> classResources = new ArrayList<>();
/*  74 */   private final List<WebResourceSet> jarResources = new ArrayList<>();
/*  75 */   private final List<WebResourceSet> postResources = new ArrayList<>();
/*     */   
/*  77 */   private final Cache cache = new Cache(this);
/*     */   private boolean cachingAllowed = true;
/*  79 */   private ObjectName cacheJmxName = null;
/*     */   
/*     */   private boolean trackLockedFiles = false;
/*  82 */   private final Set<TrackedWebResource> trackedResources = ConcurrentHashMap.newKeySet();
/*     */   
/*  84 */   private WebResourceRoot.ArchiveIndexStrategy archiveIndexStrategy = WebResourceRoot.ArchiveIndexStrategy.SIMPLE;
/*     */ 
/*     */   
/*  87 */   private final List<WebResourceSet> mainResources = new ArrayList<>();
/*  88 */   private final List<List<WebResourceSet>> allResources = new ArrayList<>();
/*     */   
/*  90 */   public StandardRoot() { this.allResources.add(this.preResources);
/*  91 */     this.allResources.add(this.mainResources);
/*  92 */     this.allResources.add(this.classResources);
/*  93 */     this.allResources.add(this.jarResources);
/*  94 */     this.allResources.add(this.postResources); } public StandardRoot(Context context) { this.allResources.add(this.preResources); this.allResources.add(this.mainResources); this.allResources.add(this.classResources); this.allResources.add(this.jarResources); this.allResources.add(this.postResources);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.context = context; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] list(String path) {
/* 112 */     return list(path, true);
/*     */   }
/*     */   
/*     */   private String[] list(String path, boolean validate) {
/* 116 */     if (validate) {
/* 117 */       path = validate(path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     HashSet<String> result = new LinkedHashSet<>();
/* 125 */     for (List<WebResourceSet> list : this.allResources) {
/* 126 */       for (WebResourceSet webResourceSet : list) {
/* 127 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 128 */           String[] entries = webResourceSet.list(path);
/* 129 */           result.addAll(Arrays.asList(entries));
/*     */         } 
/*     */       } 
/*     */     } 
/* 133 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> listWebAppPaths(String path) {
/* 139 */     path = validate(path);
/*     */ 
/*     */     
/* 142 */     Set<String> result = new HashSet<>();
/* 143 */     for (List<WebResourceSet> list : this.allResources) {
/* 144 */       for (WebResourceSet webResourceSet : list) {
/* 145 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 146 */           result.addAll(webResourceSet.listWebAppPaths(path));
/*     */         }
/*     */       } 
/*     */     } 
/* 150 */     if (result.isEmpty()) {
/* 151 */       return null;
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mkdir(String path) {
/* 158 */     path = validate(path);
/*     */     
/* 160 */     if (preResourceExists(path)) {
/* 161 */       return false;
/*     */     }
/*     */     
/* 164 */     boolean mkdirResult = this.main.mkdir(path);
/*     */     
/* 166 */     if (mkdirResult && isCachingAllowed())
/*     */     {
/* 168 */       this.cache.removeCacheEntry(path);
/*     */     }
/* 170 */     return mkdirResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean write(String path, InputStream is, boolean overwrite) {
/* 175 */     path = validate(path);
/*     */     
/* 177 */     if (!overwrite && preResourceExists(path)) {
/* 178 */       return false;
/*     */     }
/*     */     
/* 181 */     boolean writeResult = this.main.write(path, is, overwrite);
/*     */     
/* 183 */     if (writeResult && isCachingAllowed())
/*     */     {
/* 185 */       this.cache.removeCacheEntry(path);
/*     */     }
/*     */     
/* 188 */     return writeResult;
/*     */   }
/*     */   
/*     */   private boolean preResourceExists(String path) {
/* 192 */     for (WebResourceSet webResourceSet : this.preResources) {
/* 193 */       WebResource webResource = webResourceSet.getResource(path);
/* 194 */       if (webResource.exists()) {
/* 195 */         return true;
/*     */       }
/*     */     } 
/* 198 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResource getResource(String path) {
/* 203 */     return getResource(path, true, false);
/*     */   }
/*     */   
/*     */   protected WebResource getResource(String path, boolean validate, boolean useClassLoaderResources) {
/* 207 */     if (validate) {
/* 208 */       path = validate(path);
/*     */     }
/*     */     
/* 211 */     if (isCachingAllowed()) {
/* 212 */       return this.cache.getResource(path, useClassLoaderResources);
/*     */     }
/* 214 */     return getResourceInternal(path, useClassLoaderResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResource getClassLoaderResource(String path) {
/* 221 */     return getResource("/WEB-INF/classes" + path, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResource[] getClassLoaderResources(String path) {
/* 227 */     return getResources("/WEB-INF/classes" + path, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String validate(String path) {
/*     */     String result;
/* 240 */     if (!getState().isAvailable()) {
/* 241 */       throw new IllegalStateException(sm.getString("standardRoot.checkStateNotStarted"));
/*     */     }
/*     */     
/* 244 */     if (path == null || !path.startsWith("/")) {
/* 245 */       throw new IllegalArgumentException(sm.getString("standardRoot.invalidPath", new Object[] { path }));
/*     */     }
/*     */ 
/*     */     
/* 249 */     if (File.separatorChar == '\\') {
/*     */ 
/*     */       
/* 252 */       result = RequestUtil.normalize(path, true);
/*     */     }
/*     */     else {
/*     */       
/* 256 */       result = RequestUtil.normalize(path, false);
/*     */     } 
/* 258 */     if (result == null || !result.startsWith("/")) {
/* 259 */       throw new IllegalArgumentException(sm.getString("standardRoot.invalidPathNormal", new Object[] { path, result }));
/*     */     }
/*     */     
/* 262 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final WebResource getResourceInternal(String path, boolean useClassLoaderResources) {
/* 267 */     WebResource virtual = null;
/* 268 */     WebResource mainEmpty = null;
/* 269 */     for (List<WebResourceSet> list : this.allResources) {
/* 270 */       for (WebResourceSet webResourceSet : list) {
/* 271 */         if ((!useClassLoaderResources && !webResourceSet.getClassLoaderOnly()) || (useClassLoaderResources && 
/* 272 */           !webResourceSet.getStaticOnly())) {
/* 273 */           WebResource result = webResourceSet.getResource(path);
/* 274 */           if (result.exists()) {
/* 275 */             return result;
/*     */           }
/* 277 */           if (virtual == null) {
/* 278 */             if (result.isVirtual()) {
/* 279 */               virtual = result; continue;
/* 280 */             }  if (this.main.equals(webResourceSet)) {
/* 281 */               mainEmpty = result;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 289 */     if (virtual != null) {
/* 290 */       return virtual;
/*     */     }
/*     */ 
/*     */     
/* 294 */     return mainEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResource[] getResources(String path) {
/* 299 */     return getResources(path, false);
/*     */   }
/*     */   
/*     */   private WebResource[] getResources(String path, boolean useClassLoaderResources) {
/* 303 */     path = validate(path);
/*     */     
/* 305 */     if (isCachingAllowed()) {
/* 306 */       return this.cache.getResources(path, useClassLoaderResources);
/*     */     }
/* 308 */     return getResourcesInternal(path, useClassLoaderResources);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WebResource[] getResourcesInternal(String path, boolean useClassLoaderResources) {
/* 313 */     List<WebResource> result = new ArrayList<>();
/* 314 */     for (List<WebResourceSet> list : this.allResources) {
/* 315 */       for (WebResourceSet webResourceSet : list) {
/* 316 */         if (useClassLoaderResources || !webResourceSet.getClassLoaderOnly()) {
/* 317 */           WebResource webResource = webResourceSet.getResource(path);
/* 318 */           if (webResource.exists()) {
/* 319 */             result.add(webResource);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 325 */     if (result.isEmpty()) {
/* 326 */       result.add(this.main.getResource(path));
/*     */     }
/*     */     
/* 329 */     return result.<WebResource>toArray(new WebResource[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResource[] listResources(String path) {
/* 334 */     return listResources(path, true);
/*     */   }
/*     */   
/*     */   protected WebResource[] listResources(String path, boolean validate) {
/* 338 */     if (validate) {
/* 339 */       path = validate(path);
/*     */     }
/*     */     
/* 342 */     String[] resources = list(path, false);
/* 343 */     WebResource[] result = new WebResource[resources.length];
/* 344 */     for (int i = 0; i < resources.length; i++) {
/* 345 */       if (path.charAt(path.length() - 1) == '/') {
/* 346 */         result[i] = getResource(path + path, false, false);
/*     */       } else {
/* 348 */         result[i] = getResource(path + "/" + path, false, false);
/*     */       } 
/*     */     } 
/* 351 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createWebResourceSet(WebResourceRoot.ResourceSetType type, String webAppMount, URL url, String internalPath) {
/* 359 */     BaseLocation baseLocation = new BaseLocation(url);
/* 360 */     createWebResourceSet(type, webAppMount, baseLocation.getBasePath(), baseLocation.getArchivePath(), internalPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createWebResourceSet(WebResourceRoot.ResourceSetType type, String webAppMount, String base, String archivePath, String internalPath) {
/*     */     List<WebResourceSet> resourceList;
/*     */     WebResourceSet resourceSet;
/* 370 */     switch (type) {
/*     */       case PRE:
/* 372 */         resourceList = this.preResources;
/*     */         break;
/*     */       case CLASSES_JAR:
/* 375 */         resourceList = this.classResources;
/*     */         break;
/*     */       case RESOURCE_JAR:
/* 378 */         resourceList = this.jarResources;
/*     */         break;
/*     */       case POST:
/* 381 */         resourceList = this.postResources;
/*     */         break;
/*     */       default:
/* 384 */         throw new IllegalArgumentException(sm.getString("standardRoot.createUnknownType", new Object[] { type }));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 389 */     File file = new File(base);
/*     */     
/* 391 */     if (file.isFile()) {
/* 392 */       if (archivePath != null) {
/*     */         
/* 394 */         resourceSet = new JarWarResourceSet(this, webAppMount, base, archivePath, internalPath);
/* 395 */       } else if (file.getName().toLowerCase(Locale.ENGLISH).endsWith(".jar")) {
/* 396 */         resourceSet = new JarResourceSet(this, webAppMount, base, internalPath);
/*     */       } else {
/* 398 */         resourceSet = new FileResourceSet(this, webAppMount, base, internalPath);
/*     */       } 
/* 400 */     } else if (file.isDirectory()) {
/* 401 */       resourceSet = new DirResourceSet(this, webAppMount, base, internalPath);
/*     */     } else {
/* 403 */       throw new IllegalArgumentException(sm.getString("standardRoot.createInvalidFile", new Object[] { file }));
/*     */     } 
/*     */     
/* 406 */     if (type.equals(WebResourceRoot.ResourceSetType.CLASSES_JAR)) {
/* 407 */       resourceSet.setClassLoaderOnly(true);
/* 408 */     } else if (type.equals(WebResourceRoot.ResourceSetType.RESOURCE_JAR)) {
/* 409 */       resourceSet.setStaticOnly(true);
/*     */     } 
/*     */     
/* 412 */     resourceList.add(resourceSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPreResources(WebResourceSet webResourceSet) {
/* 417 */     webResourceSet.setRoot(this);
/* 418 */     this.preResources.add(webResourceSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceSet[] getPreResources() {
/* 423 */     return this.preResources.<WebResourceSet>toArray(new WebResourceSet[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addJarResources(WebResourceSet webResourceSet) {
/* 428 */     webResourceSet.setRoot(this);
/* 429 */     this.jarResources.add(webResourceSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceSet[] getJarResources() {
/* 434 */     return this.jarResources.<WebResourceSet>toArray(new WebResourceSet[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPostResources(WebResourceSet webResourceSet) {
/* 439 */     webResourceSet.setRoot(this);
/* 440 */     this.postResources.add(webResourceSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceSet[] getPostResources() {
/* 445 */     return this.postResources.<WebResourceSet>toArray(new WebResourceSet[0]);
/*     */   }
/*     */   
/*     */   protected WebResourceSet[] getClassResources() {
/* 449 */     return this.classResources.<WebResourceSet>toArray(new WebResourceSet[0]);
/*     */   }
/*     */   
/*     */   protected void addClassResources(WebResourceSet webResourceSet) {
/* 453 */     webResourceSet.setRoot(this);
/* 454 */     this.classResources.add(webResourceSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowLinking(boolean allowLinking) {
/* 459 */     if (this.allowLinking != allowLinking && this.cachingAllowed)
/*     */     {
/* 461 */       this.cache.clear();
/*     */     }
/* 463 */     this.allowLinking = allowLinking;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowLinking() {
/* 468 */     return this.allowLinking;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCachingAllowed(boolean cachingAllowed) {
/* 473 */     this.cachingAllowed = cachingAllowed;
/* 474 */     if (!cachingAllowed) {
/* 475 */       this.cache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCachingAllowed() {
/* 481 */     return this.cachingAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebResourceRoot.CacheStrategy getCacheStrategy() {
/* 487 */     return this.cache.getCacheStrategy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCacheStrategy(WebResourceRoot.CacheStrategy strategy) {
/* 492 */     this.cache.setCacheStrategy(strategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCacheTtl() {
/* 497 */     return this.cache.getTtl();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCacheTtl(long cacheTtl) {
/* 502 */     this.cache.setTtl(cacheTtl);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getCacheMaxSize() {
/* 507 */     return this.cache.getMaxSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCacheMaxSize(long cacheMaxSize) {
/* 512 */     this.cache.setMaxSize(cacheMaxSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCacheObjectMaxSize(int cacheObjectMaxSize) {
/* 517 */     this.cache.setObjectMaxSize(cacheObjectMaxSize);
/*     */ 
/*     */     
/* 520 */     if (getState().isAvailable()) {
/* 521 */       this.cache.enforceObjectMaxSizeLimit();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCacheObjectMaxSize() {
/* 527 */     return this.cache.getObjectMaxSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTrackLockedFiles(boolean trackLockedFiles) {
/* 532 */     this.trackLockedFiles = trackLockedFiles;
/* 533 */     if (!trackLockedFiles) {
/* 534 */       this.trackedResources.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getTrackLockedFiles() {
/* 540 */     return this.trackLockedFiles;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setArchiveIndexStrategy(String archiveIndexStrategy) {
/* 545 */     this.archiveIndexStrategy = WebResourceRoot.ArchiveIndexStrategy.valueOf(archiveIndexStrategy.toUpperCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getArchiveIndexStrategy() {
/* 550 */     return this.archiveIndexStrategy.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public WebResourceRoot.ArchiveIndexStrategy getArchiveIndexStrategyEnum() {
/* 555 */     return this.archiveIndexStrategy;
/*     */   }
/*     */   
/*     */   public List<String> getTrackedResources() {
/* 559 */     List<String> result = new ArrayList<>(this.trackedResources.size());
/* 560 */     for (TrackedWebResource resource : this.trackedResources) {
/* 561 */       result.add(resource.toString());
/*     */     }
/* 563 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context getContext() {
/* 568 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContext(Context context) {
/* 573 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processWebInfLib() throws LifecycleException {
/* 586 */     WebResource[] possibleJars = listResources("/WEB-INF/lib", false);
/*     */     
/* 588 */     for (WebResource possibleJar : possibleJars) {
/* 589 */       if (possibleJar.isFile() && possibleJar.getName().endsWith(".jar")) {
/* 590 */         createWebResourceSet(WebResourceRoot.ResourceSetType.CLASSES_JAR, "/WEB-INF/classes", possibleJar.getURL(), "/");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setMainResources(WebResourceSet main) {
/* 601 */     this.main = main;
/* 602 */     this.mainResources.clear();
/* 603 */     this.mainResources.add(main);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void backgroundProcess() {
/* 609 */     this.cache.backgroundProcess();
/* 610 */     gc();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void gc() {
/* 616 */     for (List<WebResourceSet> list : this.allResources) {
/* 617 */       for (WebResourceSet webResourceSet : list) {
/* 618 */         webResourceSet.gc();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerTrackedResource(TrackedWebResource trackedResource) {
/* 625 */     this.trackedResources.add(trackedResource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void deregisterTrackedResource(TrackedWebResource trackedResource) {
/* 631 */     this.trackedResources.remove(trackedResource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<URL> getBaseUrls() {
/* 637 */     List<URL> result = new ArrayList<>();
/* 638 */     for (List<WebResourceSet> list : this.allResources) {
/* 639 */       for (WebResourceSet webResourceSet : list) {
/* 640 */         if (!webResourceSet.getClassLoaderOnly()) {
/* 641 */           URL url = webResourceSet.getBaseUrl();
/* 642 */           if (url != null) {
/* 643 */             result.add(url);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 648 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPackedWarFile() {
/* 657 */     return (this.main instanceof WarResourceSet && this.preResources.isEmpty() && this.postResources.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 663 */     return (this.readOnly || this.main == null || this.main.isReadOnly());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/* 668 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 674 */     return this.context.getDomain();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 679 */     return "type=WebResourceRoot" + this.context.getMBeanKeyProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 686 */     super.initInternal();
/*     */     
/* 688 */     if (this.context == null) {
/* 689 */       throw new IllegalStateException(sm.getString("standardRoot.noContext"));
/*     */     }
/*     */     
/* 692 */     this.cacheJmxName = register(this.cache, getObjectNameKeyProperties() + ",name=Cache");
/*     */     
/* 694 */     registerURLStreamHandlerFactory();
/*     */     
/* 696 */     for (List<WebResourceSet> list : this.allResources) {
/* 697 */       for (WebResourceSet webResourceSet : list) {
/* 698 */         webResourceSet.init();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerURLStreamHandlerFactory() {
/* 704 */     if (!JreCompat.isGraalAvailable())
/*     */     {
/*     */       
/* 707 */       TomcatURLStreamHandlerFactory.register();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 713 */     this.mainResources.clear();
/*     */     
/* 715 */     this.main = createMainResourceSet();
/*     */     
/* 717 */     this.mainResources.add(this.main);
/*     */     
/* 719 */     for (List<WebResourceSet> list : this.allResources) {
/*     */       
/* 721 */       if (list != this.classResources) {
/* 722 */         for (WebResourceSet webResourceSet : list) {
/* 723 */           webResourceSet.start();
/*     */         }
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 730 */     processWebInfLib();
/*     */     
/* 732 */     for (WebResourceSet classResource : this.classResources) {
/* 733 */       classResource.start();
/*     */     }
/*     */     
/* 736 */     this.cache.enforceObjectMaxSizeLimit();
/*     */     
/* 738 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   protected WebResourceSet createMainResourceSet() {
/*     */     WebResourceSet mainResourceSet;
/* 742 */     String docBase = this.context.getDocBase();
/*     */ 
/*     */     
/* 745 */     if (docBase == null) {
/* 746 */       mainResourceSet = new EmptyResourceSet(this);
/*     */     } else {
/* 748 */       File f = new File(docBase);
/* 749 */       if (!f.isAbsolute()) {
/* 750 */         f = new File(((Host)this.context.getParent()).getAppBaseFile(), f.getPath());
/*     */       }
/* 752 */       if (f.isDirectory()) {
/* 753 */         mainResourceSet = new DirResourceSet(this, "/", f.getAbsolutePath(), "/");
/* 754 */         mainResourceSet.setReadOnly(this.readOnly);
/* 755 */       } else if (f.isFile() && docBase.endsWith(".war")) {
/* 756 */         mainResourceSet = new WarResourceSet(this, "/", f.getAbsolutePath());
/*     */       } else {
/* 758 */         throw new IllegalArgumentException(sm.getString("standardRoot.startInvalidMain", new Object[] { f.getAbsolutePath() }));
/*     */       } 
/*     */     } 
/*     */     
/* 762 */     return mainResourceSet;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 767 */     for (List<WebResourceSet> list : this.allResources) {
/* 768 */       for (WebResourceSet webResourceSet : list) {
/* 769 */         webResourceSet.stop();
/*     */       }
/*     */     } 
/*     */     
/* 773 */     if (this.main != null) {
/* 774 */       this.main.destroy();
/*     */     }
/* 776 */     this.mainResources.clear();
/*     */     
/* 778 */     for (WebResourceSet webResourceSet : this.jarResources) {
/* 779 */       webResourceSet.destroy();
/*     */     }
/* 781 */     this.jarResources.clear();
/*     */     
/* 783 */     for (WebResourceSet webResourceSet : this.classResources) {
/* 784 */       webResourceSet.destroy();
/*     */     }
/* 786 */     this.classResources.clear();
/*     */     
/* 788 */     for (TrackedWebResource trackedResource : this.trackedResources) {
/* 789 */       log.error(sm.getString("standardRoot.lockedFile", new Object[] { this.context.getName(), trackedResource.getName() }), trackedResource
/* 790 */           .getCreatedBy());
/*     */       try {
/* 792 */         trackedResource.close();
/* 793 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 797 */     this.cache.clear();
/*     */     
/* 799 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException {
/* 804 */     for (List<WebResourceSet> list : this.allResources) {
/* 805 */       for (WebResourceSet webResourceSet : list) {
/* 806 */         webResourceSet.destroy();
/*     */       }
/*     */     } 
/*     */     
/* 810 */     unregister(this.cacheJmxName);
/*     */     
/* 812 */     super.destroyInternal();
/*     */   }
/*     */ 
/*     */   
/*     */   static class BaseLocation
/*     */   {
/*     */     private final String basePath;
/*     */     
/*     */     private final String archivePath;
/*     */ 
/*     */     
/*     */     BaseLocation(URL url) {
/*     */       File f;
/* 825 */       if ("jar".equals(url.getProtocol()) || "war".equals(url.getProtocol())) {
/* 826 */         int endOfFileUrl; String jarUrl = url.toString();
/*     */         
/* 828 */         if ("jar".equals(url.getProtocol())) {
/* 829 */           endOfFileUrl = jarUrl.indexOf("!/");
/*     */         } else {
/* 831 */           endOfFileUrl = jarUrl.indexOf(UriUtil.getWarSeparator());
/*     */         } 
/* 833 */         String fileUrl = jarUrl.substring(4, endOfFileUrl);
/*     */         try {
/* 835 */           f = new File(new URI(fileUrl));
/* 836 */         } catch (URISyntaxException e) {
/* 837 */           throw new IllegalArgumentException(e);
/*     */         } 
/* 839 */         int startOfArchivePath = endOfFileUrl + 2;
/* 840 */         if (jarUrl.length() > startOfArchivePath) {
/* 841 */           this.archivePath = jarUrl.substring(startOfArchivePath);
/*     */         } else {
/* 843 */           this.archivePath = null;
/*     */         } 
/* 845 */       } else if ("file".equals(url.getProtocol())) {
/*     */         try {
/* 847 */           f = new File(url.toURI());
/* 848 */         } catch (URISyntaxException e) {
/* 849 */           throw new IllegalArgumentException(e);
/*     */         } 
/* 851 */         this.archivePath = null;
/*     */       } else {
/* 853 */         throw new IllegalArgumentException(StandardRoot.sm.getString("standardRoot.unsupportedProtocol", new Object[] { url.getProtocol() }));
/*     */       } 
/*     */       
/* 856 */       this.basePath = f.getAbsolutePath();
/*     */     }
/*     */ 
/*     */     
/*     */     String getBasePath() {
/* 861 */       return this.basePath;
/*     */     }
/*     */ 
/*     */     
/*     */     String getArchivePath() {
/* 866 */       return this.archivePath;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\StandardRoot.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */