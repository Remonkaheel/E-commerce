/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceSet;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResourceSet
/*     */   extends LifecycleBase
/*     */   implements WebResourceSet
/*     */ {
/*     */   private WebResourceRoot root;
/*     */   private String base;
/*  32 */   private String internalPath = "";
/*     */   
/*     */   private String webAppMount;
/*     */   
/*     */   private boolean classLoaderOnly;
/*     */   private boolean staticOnly;
/*     */   private Manifest manifest;
/*  39 */   protected static final StringManager sm = StringManager.getManager(AbstractResourceSet.class);
/*     */ 
/*     */   
/*     */   protected final void checkPath(String path) {
/*  43 */     if (path == null || path.isEmpty() || path.charAt(0) != '/') {
/*  44 */       throw new IllegalArgumentException(sm.getString("abstractResourceSet.checkPath", new Object[] { path }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setRoot(WebResourceRoot root) {
/*  50 */     this.root = root;
/*     */   }
/*     */   
/*     */   protected final WebResourceRoot getRoot() {
/*  54 */     return this.root;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String getInternalPath() {
/*  59 */     return this.internalPath;
/*     */   }
/*     */   
/*     */   public final void setInternalPath(String internalPath) {
/*  63 */     checkPath(internalPath);
/*     */     
/*  65 */     if (internalPath.equals("/")) {
/*  66 */       this.internalPath = "";
/*     */     } else {
/*  68 */       this.internalPath = internalPath;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void setWebAppMount(String webAppMount) {
/*  73 */     checkPath(webAppMount);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     if (webAppMount.endsWith("/")) {
/*  80 */       this.webAppMount = webAppMount.substring(0, webAppMount.length() - 1);
/*     */     } else {
/*  82 */       this.webAppMount = webAppMount;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final String getWebAppMount() {
/*  87 */     return this.webAppMount;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isPathMounted(String path, String webAppMount) {
/*  92 */     if (path.startsWith(webAppMount)) {
/*  93 */       if (path.length() != webAppMount.length() && path.charAt(webAppMount.length()) != '/') {
/*  94 */         return false;
/*     */       }
/*  96 */       return true;
/*     */     } 
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setBase(String base) {
/* 103 */     this.base = base;
/*     */   }
/*     */   
/*     */   protected final String getBase() {
/* 107 */     return this.base;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getClassLoaderOnly() {
/* 112 */     return this.classLoaderOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassLoaderOnly(boolean classLoaderOnly) {
/* 117 */     this.classLoaderOnly = classLoaderOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getStaticOnly() {
/* 122 */     return this.staticOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStaticOnly(boolean staticOnly) {
/* 127 */     this.staticOnly = staticOnly;
/*     */   }
/*     */   
/*     */   protected final void setManifest(Manifest manifest) {
/* 131 */     this.manifest = manifest;
/*     */   }
/*     */   
/*     */   protected final Manifest getManifest() {
/* 135 */     return this.manifest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void startInternal() throws LifecycleException {
/* 142 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void stopInternal() throws LifecycleException {
/* 147 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void destroyInternal() throws LifecycleException {
/* 152 */     gc();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */