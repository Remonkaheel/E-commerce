/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import org.apache.catalina.WebResourceRoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VirtualResource
/*    */   extends EmptyResource
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public VirtualResource(WebResourceRoot root, String webAppPath, String name) {
/* 26 */     super(root, webAppPath);
/* 27 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVirtual() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDirectory() {
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 42 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\VirtualResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */