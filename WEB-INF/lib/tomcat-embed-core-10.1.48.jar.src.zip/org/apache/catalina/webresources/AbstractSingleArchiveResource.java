/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.JarFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSingleArchiveResource
/*    */   extends AbstractArchiveResource
/*    */ {
/*    */   protected AbstractSingleArchiveResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry, String codeBaseUrl) {
/* 28 */     super(archiveResourceSet, webAppPath, baseUrl, jarEntry, codeBaseUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected AbstractArchiveResource.JarInputStreamWrapper getJarInputStreamWrapper() {
/* 34 */     JarFile jarFile = null;
/*    */     try {
/* 36 */       jarFile = getArchiveResourceSet().openJarFile();
/*    */       
/* 38 */       JarEntry jarEntry = jarFile.getJarEntry(getResource().getName());
/* 39 */       InputStream is = jarFile.getInputStream(jarEntry);
/* 40 */       return new AbstractArchiveResource.JarInputStreamWrapper(this, jarEntry, is);
/* 41 */     } catch (IOException ioe) {
/* 42 */       if (getLog().isDebugEnabled()) {
/* 43 */         getLog().debug(sm.getString("jarResource.getInputStreamFail", new Object[] { getResource().getName(), getBaseUrl() }), ioe);
/*    */       }
/*    */       
/* 46 */       if (jarFile != null) {
/* 47 */         getArchiveResourceSet().closeJarFile();
/*    */       }
/* 49 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractSingleArchiveResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */