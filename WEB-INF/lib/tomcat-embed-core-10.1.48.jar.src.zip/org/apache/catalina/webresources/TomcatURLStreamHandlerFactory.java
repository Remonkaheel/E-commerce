/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.webresources.war.Handler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatURLStreamHandlerFactory
/*     */   implements URLStreamHandlerFactory
/*     */ {
/*     */   private static final String WAR_PROTOCOL = "war";
/*     */   private static final String CLASSPATH_PROTOCOL = "classpath";
/*  33 */   private static volatile TomcatURLStreamHandlerFactory instance = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean registered;
/*     */ 
/*     */ 
/*     */   
/*     */   public static TomcatURLStreamHandlerFactory getInstance() {
/*  42 */     getInstanceInternal(true);
/*  43 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static TomcatURLStreamHandlerFactory getInstanceInternal(boolean register) {
/*  49 */     if (instance == null) {
/*  50 */       synchronized (TomcatURLStreamHandlerFactory.class) {
/*  51 */         if (instance == null) {
/*  52 */           instance = new TomcatURLStreamHandlerFactory(register);
/*     */         }
/*     */       } 
/*     */     }
/*  56 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private final List<URLStreamHandlerFactory> userFactories = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register() {
/*  73 */     return getInstanceInternal(true).isRegistered();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean disable() {
/*  84 */     return !getInstanceInternal(false).isRegistered();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void release(ClassLoader classLoader) {
/*  95 */     if (instance == null) {
/*     */       return;
/*     */     }
/*  98 */     List<URLStreamHandlerFactory> factories = instance.userFactories;
/*  99 */     for (URLStreamHandlerFactory factory : factories) {
/* 100 */       ClassLoader factoryLoader = factory.getClass().getClassLoader();
/* 101 */       while (factoryLoader != null) {
/* 102 */         if (classLoader.equals(factoryLoader)) {
/*     */ 
/*     */ 
/*     */           
/* 106 */           factories.remove(factory);
/*     */           break;
/*     */         } 
/* 109 */         factoryLoader = factoryLoader.getParent();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TomcatURLStreamHandlerFactory(boolean register) {
/* 119 */     this.registered = register;
/* 120 */     if (register) {
/* 121 */       URL.setURLStreamHandlerFactory(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRegistered() {
/* 127 */     return this.registered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUserFactory(URLStreamHandlerFactory factory) {
/* 138 */     this.userFactories.add(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLStreamHandler createURLStreamHandler(String protocol) {
/* 147 */     if ("war".equals(protocol))
/* 148 */       return (URLStreamHandler)new Handler(); 
/* 149 */     if ("classpath".equals(protocol)) {
/* 150 */       return new ClasspathURLStreamHandler();
/*     */     }
/*     */ 
/*     */     
/* 154 */     for (URLStreamHandlerFactory factory : this.userFactories) {
/* 155 */       URLStreamHandler handler = factory.createURLStreamHandler(protocol);
/* 156 */       if (handler != null) {
/* 157 */         return handler;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 162 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\TomcatURLStreamHandlerFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */