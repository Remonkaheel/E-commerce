/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JarContents
/*     */ {
/*     */   private static final int HASH_PRIME_1 = 31;
/*     */   private static final int HASH_PRIME_2 = 17;
/*     */   private static final int TABLE_SIZE = 2048;
/*  47 */   private final BitSet bits1 = new BitSet(2048);
/*  48 */   private final BitSet bits2 = new BitSet(2048);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JarContents(JarFile jar) {
/*  57 */     Enumeration<JarEntry> entries = jar.entries();
/*  58 */     while (entries.hasMoreElements()) {
/*  59 */       JarEntry entry = entries.nextElement();
/*  60 */       processEntry(entry);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JarContents(Collection<JarEntry> entries) {
/*  71 */     for (JarEntry entry : entries) {
/*  72 */       processEntry(entry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void processEntry(JarEntry entry) {
/*  78 */     String name = entry.getName();
/*  79 */     int startPos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     boolean precedingSlash = (name.charAt(0) == '/');
/*  85 */     if (precedingSlash) {
/*  86 */       startPos = 1;
/*     */     }
/*     */ 
/*     */     
/*  90 */     if (name.startsWith("META-INF/versions/", startPos)) {
/*  91 */       int i = name.indexOf('/', 18 + startPos);
/*  92 */       if (i > 0) {
/*  93 */         int version = Integer.parseInt(name.substring(18 + startPos, i));
/*  94 */         if (version <= Runtime.version().feature()) {
/*  95 */           startPos = i + 1;
/*     */         }
/*     */       } 
/*  98 */       if (startPos == name.length()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 104 */     int pathHash1 = hashcode(name, startPos, 31);
/* 105 */     int pathHash2 = hashcode(name, startPos, 17);
/*     */     
/* 107 */     this.bits1.set(pathHash1 % 2048);
/* 108 */     this.bits2.set(pathHash2 % 2048);
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (entry.isDirectory()) {
/* 113 */       pathHash1 = hashcode(name, startPos, name.length() - 1, 31);
/* 114 */       pathHash2 = hashcode(name, startPos, name.length() - 1, 17);
/*     */       
/* 116 */       this.bits1.set(pathHash1 % 2048);
/* 117 */       this.bits2.set(pathHash2 % 2048);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int hashcode(String content, int startPos, int hashPrime) {
/* 131 */     return hashcode(content, startPos, content.length(), hashPrime);
/*     */   }
/*     */   
/*     */   private int hashcode(String content, int startPos, int endPos, int hashPrime) {
/* 135 */     int h = hashPrime / 2;
/* 136 */     for (int i = startPos; i < endPos; i++) {
/* 137 */       h = hashPrime * h + content.charAt(i);
/*     */     }
/*     */     
/* 140 */     if (h < 0) {
/* 141 */       h *= -1;
/*     */     }
/* 143 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mightContainResource(String path, String webappRoot) {
/* 157 */     int startPos = 0;
/* 158 */     if (path.startsWith(webappRoot)) {
/* 159 */       startPos = webappRoot.length();
/*     */     }
/*     */     
/* 162 */     if (path.charAt(startPos) == '/')
/*     */     {
/* 164 */       startPos++;
/*     */     }
/*     */ 
/*     */     
/* 168 */     return (this.bits1.get(hashcode(path, startPos, 31) % 2048) && this.bits2
/* 169 */       .get(hashcode(path, startPos, 17) % 2048));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\JarContents.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */