/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.catalina.LifecycleException;
/*    */ import org.apache.catalina.WebResource;
/*    */ import org.apache.catalina.WebResourceRoot;
/*    */ import org.apache.catalina.startup.ExpandWar;
/*    */ import org.apache.catalina.util.IOTools;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtractingRoot
/*    */   extends StandardRoot
/*    */ {
/* 39 */   private static final StringManager sm = StringManager.getManager(ExtractingRoot.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private static final String APPLICATION_JARS_DIR = "application-jars";
/*    */ 
/*    */ 
/*    */   
/*    */   protected void processWebInfLib() throws LifecycleException {
/* 48 */     if (!super.isPackedWarFile()) {
/* 49 */       super.processWebInfLib();
/*    */       
/*    */       return;
/*    */     } 
/* 53 */     File expansionTarget = getExpansionTarget();
/* 54 */     if (!expansionTarget.isDirectory() && 
/* 55 */       !expansionTarget.mkdirs()) {
/* 56 */       throw new LifecycleException(sm.getString("extractingRoot.targetFailed", new Object[] { expansionTarget }));
/*    */     }
/*    */ 
/*    */     
/* 60 */     WebResource[] possibleJars = listResources("/WEB-INF/lib", false);
/*    */     
/* 62 */     for (WebResource possibleJar : possibleJars) {
/* 63 */       if (possibleJar.isFile() && possibleJar.getName().endsWith(".jar")) {
/*    */         try {
/* 65 */           File dest = new File(expansionTarget, possibleJar.getName());
/* 66 */           dest = dest.getCanonicalFile();
/* 67 */           InputStream sourceStream = possibleJar.getInputStream(); 
/* 68 */           try { OutputStream destStream = new FileOutputStream(dest); 
/* 69 */             try { IOTools.flow(sourceStream, destStream);
/* 70 */               destStream.close(); } catch (Throwable throwable) { try { destStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (sourceStream != null) sourceStream.close();  } catch (Throwable throwable) { if (sourceStream != null)
/*    */               try { sourceStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 72 */            createWebResourceSet(WebResourceRoot.ResourceSetType.CLASSES_JAR, "/WEB-INF/classes", dest.toURI().toURL(), "/");
/* 73 */         } catch (IOException ioe) {
/* 74 */           throw new LifecycleException(sm.getString("extractingRoot.jarFailed", new Object[] { possibleJar.getName() }), ioe);
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private File getExpansionTarget() {
/* 81 */     File tmpDir = (File)getContext().getServletContext().getAttribute("jakarta.servlet.context.tempdir");
/* 82 */     return new File(tmpDir, "application-jars");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isPackedWarFile() {
/* 88 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void stopInternal() throws LifecycleException {
/* 94 */     super.stopInternal();
/*    */     
/* 96 */     if (super.isPackedWarFile()) {
/*    */       
/* 98 */       File expansionTarget = getExpansionTarget();
/* 99 */       ExpandWar.delete(expansionTarget);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\ExtractingRoot.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */