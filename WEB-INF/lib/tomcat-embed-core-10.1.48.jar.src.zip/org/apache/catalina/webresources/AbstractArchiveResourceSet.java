/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractArchiveResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(AbstractArchiveResourceSet.class);
/*     */   
/*     */   private URL baseUrl;
/*     */   private String baseUrlString;
/*  43 */   protected JarFile archive = null;
/*  44 */   protected Map<String, JarEntry> archiveEntries = null;
/*  45 */   protected final Object archiveLock = new Object();
/*  46 */   protected long archiveUseCount = 0L;
/*     */   protected JarContents jarContents;
/*     */   protected boolean retainBloomFilterForArchives = false;
/*     */   
/*     */   protected final void setBaseUrl(URL baseUrl) {
/*  51 */     this.baseUrl = baseUrl;
/*  52 */     if (baseUrl == null) {
/*  53 */       this.baseUrlString = null;
/*     */     } else {
/*  55 */       this.baseUrlString = baseUrl.toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final URL getBaseUrl() {
/*  61 */     return this.baseUrl;
/*     */   }
/*     */   
/*     */   protected final String getBaseUrlString() {
/*  65 */     return this.baseUrlString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] list(String path) {
/*  71 */     checkPath(path);
/*  72 */     String webAppMount = getWebAppMount();
/*     */     
/*  74 */     ArrayList<String> result = new ArrayList<>();
/*  75 */     if (isPathMounted(path, webAppMount)) {
/*  76 */       String pathInJar = getInternalPath() + getInternalPath();
/*     */       
/*  78 */       if (!pathInJar.isEmpty() && pathInJar.charAt(0) == '/') {
/*  79 */         pathInJar = pathInJar.substring(1);
/*     */       }
/*  81 */       for (String name : getArchiveEntries(false).keySet()) {
/*  82 */         if (name.length() > pathInJar.length() && name.startsWith(pathInJar)) {
/*  83 */           if (name.charAt(name.length() - 1) == '/') {
/*  84 */             name = name.substring(pathInJar.length(), name.length() - 1);
/*     */           } else {
/*  86 */             name = name.substring(pathInJar.length());
/*     */           } 
/*  88 */           if (name.isEmpty()) {
/*     */             continue;
/*     */           }
/*  91 */           if (name.charAt(0) == '/') {
/*  92 */             name = name.substring(1);
/*     */           }
/*  94 */           if (!name.isEmpty() && name.lastIndexOf('/') == -1) {
/*  95 */             result.add(name);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 100 */       if (!path.endsWith("/")) {
/* 101 */         path = path + "/";
/*     */       }
/* 103 */       if (webAppMount.startsWith(path)) {
/* 104 */         int i = webAppMount.indexOf('/', path.length());
/* 105 */         if (i == -1) {
/* 106 */           return new String[] { webAppMount.substring(path.length()) };
/*     */         }
/* 108 */         return new String[] { webAppMount.substring(path.length(), i) };
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set<String> listWebAppPaths(String path) {
/* 118 */     checkPath(path);
/* 119 */     String webAppMount = getWebAppMount();
/*     */     
/* 121 */     ResourceSet<String> result = new ResourceSet();
/* 122 */     if (isPathMounted(path, webAppMount)) {
/* 123 */       String pathInJar = getInternalPath() + getInternalPath();
/*     */ 
/*     */       
/* 126 */       if (!pathInJar.isEmpty()) {
/* 127 */         if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 128 */           pathInJar = pathInJar.substring(1) + "/";
/*     */         }
/* 130 */         if (pathInJar.charAt(0) == '/') {
/* 131 */           pathInJar = pathInJar.substring(1);
/*     */         }
/*     */       } 
/*     */       
/* 135 */       for (String name : getArchiveEntries(false).keySet()) {
/* 136 */         if (name.length() > pathInJar.length() && name.startsWith(pathInJar)) {
/* 137 */           int nextSlash = name.indexOf('/', pathInJar.length());
/* 138 */           if (nextSlash != -1 && nextSlash != name.length() - 1) {
/* 139 */             name = name.substring(0, nextSlash + 1);
/*     */           }
/* 141 */           result.add(webAppMount + "/" + webAppMount);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 145 */       if (!path.endsWith("/")) {
/* 146 */         path = path + "/";
/*     */       }
/* 148 */       if (webAppMount.startsWith(path)) {
/* 149 */         int i = webAppMount.indexOf('/', path.length());
/* 150 */         if (i == -1) {
/* 151 */           result.add(webAppMount + "/");
/*     */         } else {
/* 153 */           result.add(webAppMount.substring(0, i + 1));
/*     */         } 
/*     */       } 
/*     */     } 
/* 157 */     result.setLocked(true);
/* 158 */     return (Set<String>)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map<String, JarEntry> getArchiveEntries(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JarEntry getArchiveEntry(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean mkdir(String path) {
/* 187 */     checkPath(path);
/*     */     
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean write(String path, InputStream is, boolean overwrite) {
/* 194 */     checkPath(path);
/*     */     
/* 196 */     if (is == null) {
/* 197 */       throw new NullPointerException(sm.getString("dirResourceSet.writeNpe"));
/*     */     }
/*     */     
/* 200 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final WebResource getResource(String path) {
/* 205 */     checkPath(path);
/* 206 */     String webAppMount = getWebAppMount();
/* 207 */     WebResourceRoot root = getRoot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (this.jarContents != null && 
/* 214 */       !this.jarContents.mightContainResource(getInternalPath().isEmpty() ? path : (getInternalPath() + getInternalPath()), webAppMount)) {
/* 215 */       return new EmptyResource(root, path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (isPathMounted(path, webAppMount)) {
/* 234 */       String pathInJar = getInternalPath() + getInternalPath();
/*     */       
/* 236 */       if (!pathInJar.isEmpty() && pathInJar.charAt(0) == '/') {
/* 237 */         pathInJar = pathInJar.substring(1);
/*     */       }
/* 239 */       if (pathInJar.isEmpty()) {
/*     */ 
/*     */         
/* 242 */         if (!path.endsWith("/")) {
/* 243 */           path = path + "/";
/*     */         }
/* 245 */         return new JarResourceRoot(root, new File(getBase()), this.baseUrlString, path);
/*     */       } 
/* 247 */       JarEntry jarEntry = null;
/* 248 */       if (isMultiRelease()) {
/*     */         
/* 250 */         jarEntry = getArchiveEntry(pathInJar);
/*     */       } else {
/* 252 */         Map<String, JarEntry> jarEntries = getArchiveEntries(true);
/* 253 */         if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 254 */           if (jarEntries == null) {
/* 255 */             jarEntry = getArchiveEntry(pathInJar + "/");
/*     */           } else {
/* 257 */             jarEntry = jarEntries.get(pathInJar + "/");
/*     */           } 
/* 259 */           if (jarEntry != null) {
/* 260 */             path = path + "/";
/*     */           }
/*     */         } 
/* 263 */         if (jarEntry == null) {
/* 264 */           if (jarEntries == null) {
/* 265 */             jarEntry = getArchiveEntry(pathInJar);
/*     */           } else {
/* 267 */             jarEntry = jarEntries.get(pathInJar);
/*     */           } 
/*     */         }
/*     */       } 
/* 271 */       if (jarEntry == null) {
/* 272 */         return new EmptyResource(root, path);
/*     */       }
/* 274 */       return createArchiveResource(jarEntry, path, getManifest());
/*     */     } 
/*     */ 
/*     */     
/* 278 */     return new EmptyResource(root, path);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract boolean isMultiRelease();
/*     */ 
/*     */   
/*     */   protected abstract WebResource createArchiveResource(JarEntry paramJarEntry, String paramString, Manifest paramManifest);
/*     */   
/*     */   public final boolean isReadOnly() {
/* 288 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/* 293 */     if (readOnly) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 298 */     throw new IllegalArgumentException(sm.getString("abstractArchiveResourceSet.setReadOnlyFalse"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowLinking(boolean allowLinking) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAllowLinking() {
/* 317 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JarFile openJarFile() throws IOException {
/* 322 */     synchronized (this.archiveLock) {
/* 323 */       if (this.archive == null) {
/* 324 */         this.archive = new JarFile(new File(getBase()), true, 1, Runtime.version());
/* 325 */         WebResourceRoot root = getRoot();
/* 326 */         if (root.getArchiveIndexStrategyEnum().getUsesBloom() || (root
/* 327 */           .getContext() != null && root.getContext().getUseBloomFilterForArchives())) {
/* 328 */           this.jarContents = new JarContents(this.archive);
/* 329 */           this.retainBloomFilterForArchives = root.getArchiveIndexStrategyEnum().getRetain();
/*     */         } 
/*     */       } 
/* 332 */       this.archiveUseCount++;
/* 333 */       return this.archive;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void closeJarFile() {
/* 338 */     synchronized (this.archiveLock) {
/* 339 */       this.archiveUseCount--;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void gc() {
/* 345 */     synchronized (this.archiveLock) {
/* 346 */       if (this.archive != null && this.archiveUseCount == 0L) {
/*     */         try {
/* 348 */           this.archive.close();
/* 349 */         } catch (IOException ioe) {
/* 350 */           log.warn(sm.getString("abstractArchiveResourceSet.archiveCloseFailed"), ioe);
/*     */         } 
/* 352 */         this.archive = null;
/* 353 */         this.archiveEntries = null;
/* 354 */         if (!this.retainBloomFilterForArchives)
/* 355 */           this.jarContents = null; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\webresources\AbstractArchiveResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */