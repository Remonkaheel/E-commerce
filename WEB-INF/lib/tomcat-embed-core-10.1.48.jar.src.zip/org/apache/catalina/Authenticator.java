package org.apache.catalina;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.apache.catalina.connector.Request;

public interface Authenticator {
  boolean authenticate(Request paramRequest, HttpServletResponse paramHttpServletResponse) throws IOException;
  
  void login(String paramString1, String paramString2, Request paramRequest) throws ServletException;
  
  void logout(Request paramRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Authenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */