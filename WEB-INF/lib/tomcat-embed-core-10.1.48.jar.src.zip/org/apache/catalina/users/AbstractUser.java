/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import org.apache.catalina.User;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUser
/*     */   implements User
/*     */ {
/*  39 */   protected String fullName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   protected String password = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected String username = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName() {
/*  59 */     return this.fullName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFullName(String fullName) {
/*  65 */     this.fullName = fullName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/*  71 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String password) {
/*  77 */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsername() {
/*  83 */     return this.username;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsername(String username) {
/*  89 */     this.username = username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 101 */     return getUsername();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\AbstractUser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */