/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericRole<UD extends UserDatabase>
/*     */   extends AbstractRole
/*     */ {
/*     */   protected final UserDatabase database;
/*     */   
/*     */   GenericRole(UD database, String rolename, String description) {
/*  46 */     this.database = (UserDatabase)database;
/*  47 */     this.rolename = rolename;
/*  48 */     this.description = description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDatabase getUserDatabase() {
/*  67 */     return this.database;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String description) {
/*  73 */     this.database.modifiedRole(this);
/*  74 */     super.setDescription(description);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolename(String rolename) {
/*  80 */     this.database.modifiedRole(this);
/*  81 */     super.setRolename(rolename);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  87 */     if (obj instanceof GenericRole) {
/*  88 */       GenericRole<?> role = (GenericRole)obj;
/*  89 */       return (role.database == this.database && this.rolename.equals(role.getRolename()));
/*     */     } 
/*  91 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     int prime = 31;
/*  98 */     int result = 1;
/*  99 */     result = 31 * result + ((this.database == null) ? 0 : this.database.hashCode());
/* 100 */     result = 31 * result + ((this.rolename == null) ? 0 : this.rolename.hashCode());
/* 101 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\GenericRole.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */