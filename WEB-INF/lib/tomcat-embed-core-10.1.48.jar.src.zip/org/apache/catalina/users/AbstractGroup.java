/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ import org.apache.catalina.Group;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractGroup
/*    */   implements Group
/*    */ {
/* 39 */   protected String description = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   protected String groupname = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 53 */     return this.description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDescription(String description) {
/* 59 */     this.description = description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getGroupname() {
/* 65 */     return this.groupname;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setGroupname(String groupname) {
/* 71 */     this.groupname = groupname;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 83 */     return getGroupname();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\AbstractGroup.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */