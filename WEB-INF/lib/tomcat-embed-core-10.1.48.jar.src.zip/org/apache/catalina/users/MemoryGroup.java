/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.catalina.Role;
/*    */ import org.apache.tomcat.util.buf.StringUtils;
/*    */ import org.apache.tomcat.util.security.Escape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MemoryGroup
/*    */   extends GenericGroup<MemoryUserDatabase>
/*    */ {
/*    */   MemoryGroup(MemoryUserDatabase database, String groupname, String description) {
/* 46 */     super(database, groupname, description, (List<Role>)null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     StringBuilder sb = new StringBuilder("<group groupname=\"");
/* 58 */     sb.append(Escape.xml(this.groupname));
/* 59 */     sb.append("\"");
/* 60 */     if (this.description != null) {
/* 61 */       sb.append(" description=\"");
/* 62 */       sb.append(Escape.xml(this.description));
/* 63 */       sb.append("\"");
/*    */     } 
/* 65 */     sb.append(" roles=\"");
/* 66 */     StringBuilder rsb = new StringBuilder();
/* 67 */     StringUtils.join(this.roles, ',', x -> Escape.xml(x.getRolename()), rsb);
/* 68 */     sb.append(rsb);
/* 69 */     sb.append("\"");
/* 70 */     sb.append("/>");
/* 71 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\MemoryGroup.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */