/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericGroup<UD extends UserDatabase>
/*     */   extends AbstractGroup
/*     */ {
/*     */   protected final UD database;
/*     */   protected final CopyOnWriteArrayList<Role> roles;
/*     */   
/*     */   GenericGroup(UD database, String groupname, String description, List<Role> roles) {
/*  76 */     this.roles = new CopyOnWriteArrayList<>();
/*     */     this.database = database;
/*     */     this.groupname = groupname;
/*     */     this.description = description;
/*     */     if (roles != null)
/*     */       this.roles.addAll(roles); 
/*     */   }
/*     */   public Iterator<Role> getRoles() {
/*  84 */     return this.roles.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDatabase getUserDatabase() {
/*  90 */     return (UserDatabase)this.database;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<User> getUsers() {
/*  96 */     List<User> results = new ArrayList<>();
/*  97 */     Iterator<User> users = this.database.getUsers();
/*  98 */     while (users.hasNext()) {
/*  99 */       User user = users.next();
/* 100 */       if (user.isInGroup(this)) {
/* 101 */         results.add(user);
/*     */       }
/*     */     } 
/* 104 */     return results.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRole(Role role) {
/* 113 */     if (this.roles.addIfAbsent(role)) {
/* 114 */       this.database.modifiedGroup(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInRole(Role role) {
/* 121 */     return this.roles.contains(role);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(Role role) {
/* 127 */     if (this.roles.remove(role)) {
/* 128 */       this.database.modifiedGroup(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRoles() {
/* 135 */     if (!this.roles.isEmpty()) {
/* 136 */       this.roles.clear();
/* 137 */       this.database.modifiedGroup(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 144 */     if (obj instanceof GenericGroup) {
/* 145 */       GenericGroup<?> group = (GenericGroup)obj;
/* 146 */       return (group.database == this.database && this.groupname.equals(group.getGroupname()));
/*     */     } 
/* 148 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int prime = 31;
/* 155 */     int result = 1;
/* 156 */     result = 31 * result + ((this.database == null) ? 0 : this.database.hashCode());
/* 157 */     result = 31 * result + ((this.groupname == null) ? 0 : this.groupname.hashCode());
/* 158 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\GenericGroup.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */