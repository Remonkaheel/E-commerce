/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MemoryUser
/*     */   extends GenericUser<MemoryUserDatabase>
/*     */ {
/*     */   MemoryUser(MemoryUserDatabase database, String username, String password, String fullName) {
/*  47 */     super(database, username, password, fullName, (List<Group>)null, (List<Role>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toXml() {
/*  64 */     StringBuilder sb = new StringBuilder("<user username=\"");
/*  65 */     sb.append(Escape.xml(this.username));
/*  66 */     sb.append("\" password=\"");
/*  67 */     sb.append(Escape.xml(this.password));
/*  68 */     sb.append("\"");
/*  69 */     if (this.fullName != null) {
/*  70 */       sb.append(" fullName=\"");
/*  71 */       sb.append(Escape.xml(this.fullName));
/*  72 */       sb.append("\"");
/*     */     } 
/*  74 */     sb.append(" groups=\"");
/*  75 */     StringUtils.join(this.groups, ',', x -> Escape.xml(x.getGroupname()), sb);
/*  76 */     sb.append("\"");
/*  77 */     sb.append(" roles=\"");
/*  78 */     StringUtils.join(this.roles, ',', x -> Escape.xml(x.getRolename()), sb);
/*  79 */     sb.append("\"");
/*  80 */     sb.append("/>");
/*  81 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     StringBuilder sb = new StringBuilder("User username=\"");
/*  94 */     sb.append(Escape.xml(this.username));
/*  95 */     sb.append("\"");
/*  96 */     if (this.fullName != null) {
/*  97 */       sb.append(", fullName=\"");
/*  98 */       sb.append(Escape.xml(this.fullName));
/*  99 */       sb.append("\"");
/*     */     } 
/* 101 */     sb.append(", groups=\"");
/* 102 */     StringUtils.join(this.groups, ',', x -> Escape.xml(x.getGroupname()), sb);
/* 103 */     sb.append("\"");
/* 104 */     sb.append(", roles=\"");
/* 105 */     StringUtils.join(this.roles, ',', x -> Escape.xml(x.getRolename()), sb);
/* 106 */     sb.append("\"");
/* 107 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\MemoryUser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */