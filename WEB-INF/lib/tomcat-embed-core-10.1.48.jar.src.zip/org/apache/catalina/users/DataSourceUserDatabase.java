/*      */ package org.apache.catalina.users;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.catalina.Group;
/*      */ import org.apache.catalina.Role;
/*      */ import org.apache.catalina.User;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DataSourceUserDatabase
/*      */   extends SparseUserDatabase
/*      */ {
/*   44 */   private static final Log log = LogFactory.getLog(DataSourceUserDatabase.class);
/*   45 */   private static final StringManager sm = StringManager.getManager(DataSourceUserDatabase.class); protected final DataSource dataSource; protected final String id; protected final ConcurrentHashMap<String, User> createdUsers; protected final ConcurrentHashMap<String, User> modifiedUsers; protected final ConcurrentHashMap<String, User> removedUsers; protected final ConcurrentHashMap<String, Group> createdGroups; protected final ConcurrentHashMap<String, Group> modifiedGroups; protected final ConcurrentHashMap<String, Group> removedGroups; protected final ConcurrentHashMap<String, Role> createdRoles; protected final ConcurrentHashMap<String, Role> modifiedRoles; protected final ConcurrentHashMap<String, Role> removedRoles; private String preparedAllUsers; private String preparedAllGroups;
/*      */   private String preparedAllRoles;
/*      */   private String preparedGroup;
/*      */   private String preparedRole;
/*      */   private String preparedUserRoles;
/*      */   private String preparedUser;
/*      */   private String preparedUserGroups;
/*      */   private String preparedGroupRoles;
/*      */   protected String dataSourceName;
/*      */   protected String roleNameCol;
/*      */   protected String roleAndGroupDescriptionCol;
/*      */   protected String groupNameCol;
/*      */   protected String userCredCol;
/*      */   protected String userFullNameCol;
/*      */   protected String userNameCol;
/*      */   protected String userRoleTable;
/*      */   protected String userGroupTable;
/*      */   
/*      */   public DataSourceUserDatabase(DataSource dataSource, String id) {
/*   64 */     this.createdUsers = new ConcurrentHashMap<>();
/*   65 */     this.modifiedUsers = new ConcurrentHashMap<>();
/*   66 */     this.removedUsers = new ConcurrentHashMap<>();
/*      */     
/*   68 */     this.createdGroups = new ConcurrentHashMap<>();
/*   69 */     this.modifiedGroups = new ConcurrentHashMap<>();
/*   70 */     this.removedGroups = new ConcurrentHashMap<>();
/*      */     
/*   72 */     this.createdRoles = new ConcurrentHashMap<>();
/*   73 */     this.modifiedRoles = new ConcurrentHashMap<>();
/*   74 */     this.removedRoles = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   83 */     this.preparedAllUsers = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   89 */     this.preparedAllGroups = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     this.preparedAllRoles = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  101 */     this.preparedGroup = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  107 */     this.preparedRole = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  113 */     this.preparedUserRoles = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  119 */     this.preparedUser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     this.preparedUserGroups = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  131 */     this.preparedGroupRoles = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  137 */     this.dataSourceName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  143 */     this.roleNameCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  149 */     this.roleAndGroupDescriptionCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  155 */     this.groupNameCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  161 */     this.userCredCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     this.userFullNameCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  173 */     this.userNameCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  179 */     this.userRoleTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  185 */     this.userGroupTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  191 */     this.groupRoleTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  197 */     this.userTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  203 */     this.groupTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  209 */     this.roleTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  215 */     this.connectionSuccess = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  221 */     this.readonly = true;
/*      */ 
/*      */ 
/*      */     
/*  225 */     this.dbLock = new ReentrantReadWriteLock();
/*  226 */     this.dbReadLock = this.dbLock.readLock();
/*  227 */     this.dbWriteLock = this.dbLock.writeLock();
/*      */     
/*  229 */     this.groupsLock = new ReentrantReadWriteLock();
/*  230 */     this.groupsReadLock = this.groupsLock.readLock();
/*  231 */     this.groupsWriteLock = this.groupsLock.writeLock();
/*      */     
/*  233 */     this.usersLock = new ReentrantReadWriteLock();
/*  234 */     this.usersReadLock = this.usersLock.readLock();
/*  235 */     this.usersWriteLock = this.usersLock.writeLock();
/*      */     
/*  237 */     this.rolesLock = new ReentrantReadWriteLock();
/*  238 */     this.rolesReadLock = this.rolesLock.readLock();
/*  239 */     this.rolesWriteLock = this.rolesLock.writeLock();
/*      */     this.dataSource = dataSource;
/*      */     this.id = id;
/*      */   }
/*      */   protected String groupRoleTable; protected String userTable; protected String groupTable; protected String roleTable;
/*      */   private volatile boolean connectionSuccess;
/*      */   protected boolean readonly;
/*      */   
/*      */   public String getDataSourceName() {
/*  248 */     return this.dataSourceName;
/*      */   }
/*      */   private final ReentrantReadWriteLock dbLock; private final Lock dbReadLock; private final Lock dbWriteLock; private final ReentrantReadWriteLock groupsLock; private final Lock groupsReadLock; private final Lock groupsWriteLock; private final ReentrantReadWriteLock usersLock; private final Lock usersReadLock;
/*      */   private final Lock usersWriteLock;
/*      */   private final ReentrantReadWriteLock rolesLock;
/*      */   private final Lock rolesReadLock;
/*      */   private final Lock rolesWriteLock;
/*      */   
/*      */   public void setDataSourceName(String dataSourceName) {
/*  257 */     this.dataSourceName = dataSourceName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleNameCol() {
/*  264 */     return this.roleNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleNameCol(String roleNameCol) {
/*  273 */     this.roleNameCol = roleNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserCredCol() {
/*  280 */     return this.userCredCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserCredCol(String userCredCol) {
/*  289 */     this.userCredCol = userCredCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserNameCol() {
/*  296 */     return this.userNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserNameCol(String userNameCol) {
/*  305 */     this.userNameCol = userNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserRoleTable() {
/*  312 */     return this.userRoleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserRoleTable(String userRoleTable) {
/*  321 */     this.userRoleTable = userRoleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserTable() {
/*  328 */     return this.userTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserTable(String userTable) {
/*  337 */     this.userTable = userTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleAndGroupDescriptionCol() {
/*  345 */     return this.roleAndGroupDescriptionCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleAndGroupDescriptionCol(String roleAndGroupDescriptionCol) {
/*  352 */     this.roleAndGroupDescriptionCol = roleAndGroupDescriptionCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGroupNameCol() {
/*  359 */     return this.groupNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGroupNameCol(String groupNameCol) {
/*  366 */     this.groupNameCol = groupNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserFullNameCol() {
/*  373 */     return this.userFullNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserFullNameCol(String userFullNameCol) {
/*  380 */     this.userFullNameCol = userFullNameCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserGroupTable() {
/*  387 */     return this.userGroupTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserGroupTable(String userGroupTable) {
/*  394 */     this.userGroupTable = userGroupTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGroupRoleTable() {
/*  401 */     return this.groupRoleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGroupRoleTable(String groupRoleTable) {
/*  408 */     this.groupRoleTable = groupRoleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGroupTable() {
/*  415 */     return this.groupTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGroupTable(String groupTable) {
/*  422 */     this.groupTable = groupTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleTable() {
/*  429 */     return this.roleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleTable(String roleTable) {
/*  436 */     this.roleTable = roleTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getReadonly() {
/*  443 */     return this.readonly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadonly(boolean readonly) {
/*  450 */     this.readonly = readonly;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getId() {
/*  455 */     return this.id;
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<Group> getGroups() {
/*  460 */     this.dbReadLock.lock();
/*      */     try {
/*  462 */       this.groupsReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  494 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<Role> getRoles() {
/*  500 */     this.dbReadLock.lock();
/*      */     try {
/*  502 */       this.rolesReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  534 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<User> getUsers() {
/*  540 */     this.dbReadLock.lock();
/*      */     try {
/*  542 */       this.usersReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  575 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws Exception {}
/*      */ 
/*      */   
/*      */   public Group createGroup(String groupname, String description) {
/*  585 */     this.dbReadLock.lock();
/*      */     try {
/*  587 */       this.groupsWriteLock.lock();
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  597 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Role createRole(String rolename, String description) {
/*  603 */     this.dbReadLock.lock();
/*      */     try {
/*  605 */       this.rolesWriteLock.lock();
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  615 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public User createUser(String username, String password, String fullName) {
/*  621 */     this.dbReadLock.lock();
/*      */     try {
/*  623 */       this.usersWriteLock.lock();
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  633 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Group findGroup(String groupname) {
/*  639 */     this.dbReadLock.lock();
/*      */     try {
/*  641 */       this.groupsReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  674 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Group findGroupInternal(Connection dbConnection, String groupName) {
/*  679 */     Group<DataSourceUserDatabase> group = null; 
/*  680 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedGroup); 
/*  681 */       try { stmt.setString(1, groupName);
/*  682 */         ResultSet rs = stmt.executeQuery(); 
/*  683 */         try { if (rs.next() && 
/*  684 */             rs.getString(1) != null) {
/*  685 */             String description = (this.roleAndGroupDescriptionCol != null) ? rs.getString(2) : null;
/*  686 */             ArrayList<Role> groupRoles = new ArrayList<>();
/*  687 */             if (groupName != null) {
/*  688 */               groupName = groupName.trim(); 
/*  689 */               try { PreparedStatement stmt2 = dbConnection.prepareStatement(this.preparedGroupRoles); 
/*  690 */                 try { stmt2.setString(1, groupName);
/*  691 */                   ResultSet rs2 = stmt2.executeQuery(); 
/*  692 */                   try { while (rs2.next()) {
/*  693 */                       String roleName = rs2.getString(1);
/*  694 */                       if (roleName != null) {
/*  695 */                         Role groupRole = findRoleInternal(dbConnection, roleName);
/*  696 */                         if (groupRole != null) {
/*  697 */                           groupRoles.add(groupRole);
/*      */                         }
/*      */                       } 
/*      */                     } 
/*  701 */                     if (rs2 != null) rs2.close();  } catch (Throwable throwable) { if (rs2 != null)
/*  702 */                       try { rs2.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt2 != null) stmt2.close();  } catch (Throwable throwable) { if (stmt2 != null) try { stmt2.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  703 */               { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */             
/*      */             } 
/*  706 */             group = new GenericGroup<>(this, groupName, description, groupRoles);
/*      */           } 
/*      */           
/*  709 */           if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/*  710 */             try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  711 */     { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */     
/*  713 */     return group;
/*      */   }
/*      */ 
/*      */   
/*      */   public Role findRole(String rolename) {
/*  718 */     this.dbReadLock.lock();
/*      */     try {
/*  720 */       this.rolesReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  753 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Role findRoleInternal(Connection dbConnection, String roleName) {
/*  758 */     Role<DataSourceUserDatabase> role = null; 
/*  759 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedRole); 
/*  760 */       try { stmt.setString(1, roleName);
/*  761 */         ResultSet rs = stmt.executeQuery(); 
/*  762 */         try { if (rs.next() && 
/*  763 */             rs.getString(1) != null) {
/*  764 */             String description = (this.roleAndGroupDescriptionCol != null) ? rs.getString(2) : null;
/*  765 */             role = new GenericRole<>(this, roleName, description);
/*      */           } 
/*      */           
/*  768 */           if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/*  769 */             try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  770 */     { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */     
/*  772 */     return role;
/*      */   }
/*      */ 
/*      */   
/*      */   public User findUser(String username) {
/*  777 */     this.dbReadLock.lock();
/*      */     try {
/*  779 */       this.usersReadLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  808 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public User findUserInternal(Connection dbConnection, String userName) {
/*  813 */     String dbCredentials = null;
/*  814 */     String fullName = null;
/*      */     
/*  816 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUser); 
/*  817 */       try { stmt.setString(1, userName);
/*      */         
/*  819 */         ResultSet rs = stmt.executeQuery(); 
/*  820 */         try { if (rs.next()) {
/*  821 */             dbCredentials = rs.getString(1);
/*  822 */             if (this.userFullNameCol != null) {
/*  823 */               fullName = rs.getString(2);
/*      */             }
/*      */           } 
/*      */           
/*  827 */           dbCredentials = (dbCredentials != null) ? dbCredentials.trim() : null;
/*  828 */           if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/*  829 */             try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  830 */     { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */ 
/*      */ 
/*      */     
/*  834 */     ArrayList<Group> groups = new ArrayList<>();
/*  835 */     if (isGroupStoreDefined()) {
/*  836 */       try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUserGroups); 
/*  837 */         try { stmt.setString(1, userName);
/*  838 */           ResultSet rs = stmt.executeQuery(); 
/*  839 */           try { while (rs.next()) {
/*  840 */               String groupName = rs.getString(1);
/*  841 */               if (groupName != null) {
/*  842 */                 Group group = findGroupInternal(dbConnection, groupName);
/*  843 */                 if (group != null) {
/*  844 */                   groups.add(group);
/*      */                 }
/*      */               } 
/*      */             } 
/*  848 */             if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/*  849 */               try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  850 */       { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */     
/*      */     }
/*      */     
/*  854 */     ArrayList<Role> roles = new ArrayList<>();
/*  855 */     if (this.userRoleTable != null && this.roleNameCol != null) {
/*  856 */       try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUserRoles); 
/*  857 */         try { stmt.setString(1, userName);
/*  858 */           ResultSet rs = stmt.executeQuery(); 
/*  859 */           try { while (rs.next()) {
/*  860 */               String roleName = rs.getString(1);
/*  861 */               if (roleName != null) {
/*  862 */                 Role role = findRoleInternal(dbConnection, roleName);
/*  863 */                 if (role != null) {
/*  864 */                   roles.add(role);
/*      */                 }
/*      */               } 
/*      */             } 
/*  868 */             if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/*  869 */               try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  870 */       { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */     
/*      */     }
/*      */     
/*  874 */     return new GenericUser<>(this, userName, dbCredentials, fullName, groups, roles);
/*      */   }
/*      */ 
/*      */   
/*      */   public void modifiedGroup(Group group) {
/*  879 */     this.dbReadLock.lock();
/*      */     try {
/*  881 */       this.groupsWriteLock.lock();
/*      */       try {
/*  883 */         String name = group.getName();
/*  884 */         if (!this.createdGroups.containsKey(name) && !this.removedGroups.containsKey(name)) {
/*  885 */           this.modifiedGroups.put(name, group);
/*      */         }
/*      */       } finally {
/*  888 */         this.groupsWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/*  891 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void modifiedRole(Role role) {
/*  897 */     this.dbReadLock.lock();
/*      */     try {
/*  899 */       this.rolesWriteLock.lock();
/*      */       try {
/*  901 */         String name = role.getName();
/*  902 */         if (!this.createdRoles.containsKey(name) && !this.removedRoles.containsKey(name)) {
/*  903 */           this.modifiedRoles.put(name, role);
/*      */         }
/*      */       } finally {
/*  906 */         this.rolesWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/*  909 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void modifiedUser(User user) {
/*  915 */     this.dbReadLock.lock();
/*      */     try {
/*  917 */       this.usersWriteLock.lock();
/*      */       try {
/*  919 */         String name = user.getName();
/*  920 */         if (!this.createdUsers.containsKey(name) && !this.removedUsers.containsKey(name)) {
/*  921 */           this.modifiedUsers.put(name, user);
/*      */         }
/*      */       } finally {
/*  924 */         this.usersWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/*  927 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void open() throws Exception {
/*  934 */     if (log.isDebugEnabled())
/*      */     {
/*  936 */       log.debug(sm.getString("dataSourceUserDatabase.features", new Object[] {
/*  937 */               Boolean.toString((this.userRoleTable != null && this.roleNameCol != null)), 
/*  938 */               Boolean.toString(isRoleStoreDefined()), Boolean.toString(isGroupStoreDefined())
/*      */             }));
/*      */     }
/*  941 */     this.dbWriteLock.lock();
/*      */     
/*      */     try {
/*  944 */       StringBuilder temp = new StringBuilder("SELECT ");
/*  945 */       temp.append(this.userCredCol);
/*  946 */       if (this.userFullNameCol != null) {
/*  947 */         temp.append(',').append(this.userFullNameCol);
/*      */       }
/*  949 */       temp.append(" FROM ");
/*  950 */       temp.append(this.userTable);
/*  951 */       temp.append(" WHERE ");
/*  952 */       temp.append(this.userNameCol);
/*  953 */       temp.append(" = ?");
/*  954 */       this.preparedUser = temp.toString();
/*      */       
/*  956 */       temp = new StringBuilder("SELECT ");
/*  957 */       temp.append(this.userNameCol);
/*  958 */       temp.append(" FROM ");
/*  959 */       temp.append(this.userTable);
/*  960 */       this.preparedAllUsers = temp.toString();
/*      */       
/*  962 */       temp = new StringBuilder("SELECT ");
/*  963 */       temp.append(this.roleNameCol);
/*  964 */       temp.append(" FROM ");
/*  965 */       temp.append(this.userRoleTable);
/*  966 */       temp.append(" WHERE ");
/*  967 */       temp.append(this.userNameCol);
/*  968 */       temp.append(" = ?");
/*  969 */       this.preparedUserRoles = temp.toString();
/*      */       
/*  971 */       if (isGroupStoreDefined()) {
/*  972 */         temp = new StringBuilder("SELECT ");
/*  973 */         temp.append(this.groupNameCol);
/*  974 */         temp.append(" FROM ");
/*  975 */         temp.append(this.userGroupTable);
/*  976 */         temp.append(" WHERE ");
/*  977 */         temp.append(this.userNameCol);
/*  978 */         temp.append(" = ?");
/*  979 */         this.preparedUserGroups = temp.toString();
/*      */         
/*  981 */         temp = new StringBuilder("SELECT ");
/*  982 */         temp.append(this.roleNameCol);
/*  983 */         temp.append(" FROM ");
/*  984 */         temp.append(this.groupRoleTable);
/*  985 */         temp.append(" WHERE ");
/*  986 */         temp.append(this.groupNameCol);
/*  987 */         temp.append(" = ?");
/*  988 */         this.preparedGroupRoles = temp.toString();
/*      */         
/*  990 */         temp = new StringBuilder("SELECT ");
/*  991 */         temp.append(this.groupNameCol);
/*  992 */         if (this.roleAndGroupDescriptionCol != null) {
/*  993 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/*  995 */         temp.append(" FROM ");
/*  996 */         temp.append(this.groupTable);
/*  997 */         temp.append(" WHERE ");
/*  998 */         temp.append(this.groupNameCol);
/*  999 */         temp.append(" = ?");
/* 1000 */         this.preparedGroup = temp.toString();
/*      */         
/* 1002 */         temp = new StringBuilder("SELECT ");
/* 1003 */         temp.append(this.groupNameCol);
/* 1004 */         temp.append(" FROM ");
/* 1005 */         temp.append(this.groupTable);
/* 1006 */         this.preparedAllGroups = temp.toString();
/*      */       } 
/*      */       
/* 1009 */       if (isRoleStoreDefined()) {
/*      */         
/* 1011 */         temp = new StringBuilder("SELECT ");
/* 1012 */         temp.append(this.roleNameCol);
/* 1013 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1014 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/* 1016 */         temp.append(" FROM ");
/* 1017 */         temp.append(this.roleTable);
/* 1018 */         temp.append(" WHERE ");
/* 1019 */         temp.append(this.roleNameCol);
/* 1020 */         temp.append(" = ?");
/* 1021 */         this.preparedRole = temp.toString();
/*      */         
/* 1023 */         temp = new StringBuilder("SELECT ");
/* 1024 */         temp.append(this.roleNameCol);
/* 1025 */         temp.append(" FROM ");
/* 1026 */         temp.append(this.roleTable);
/* 1027 */         this.preparedAllRoles = temp.toString();
/* 1028 */       } else if (this.userRoleTable != null && this.roleNameCol != null) {
/*      */         
/* 1030 */         temp = new StringBuilder("SELECT ");
/* 1031 */         temp.append(this.roleNameCol);
/* 1032 */         temp.append(" FROM ");
/* 1033 */         temp.append(this.userRoleTable);
/* 1034 */         temp.append(" WHERE ");
/* 1035 */         temp.append(this.roleNameCol);
/* 1036 */         temp.append(" = ?");
/* 1037 */         this.preparedRole = temp.toString();
/*      */       } 
/*      */     } finally {
/*      */       
/* 1041 */       this.dbWriteLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeGroup(Group group) {
/* 1048 */     this.dbReadLock.lock();
/*      */     try {
/* 1050 */       this.groupsWriteLock.lock();
/*      */       try {
/* 1052 */         String name = group.getName();
/* 1053 */         this.createdGroups.remove(name);
/* 1054 */         this.modifiedGroups.remove(name);
/* 1055 */         this.removedGroups.put(name, group);
/*      */       } finally {
/* 1057 */         this.groupsWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/* 1060 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeRole(Role role) {
/* 1066 */     this.dbReadLock.lock();
/*      */     try {
/* 1068 */       this.rolesWriteLock.lock();
/*      */       try {
/* 1070 */         String name = role.getName();
/* 1071 */         this.createdRoles.remove(name);
/* 1072 */         this.modifiedRoles.remove(name);
/* 1073 */         this.removedRoles.put(name, role);
/*      */       } finally {
/* 1075 */         this.rolesWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/* 1078 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeUser(User user) {
/* 1084 */     this.dbReadLock.lock();
/*      */     try {
/* 1086 */       this.usersWriteLock.lock();
/*      */       try {
/* 1088 */         String name = user.getName();
/* 1089 */         this.createdUsers.remove(name);
/* 1090 */         this.modifiedUsers.remove(name);
/* 1091 */         this.removedUsers.put(name, user);
/*      */       } finally {
/* 1093 */         this.usersWriteLock.unlock();
/*      */       } 
/*      */     } finally {
/* 1096 */       this.dbReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void save() throws Exception {
/* 1102 */     if (this.readonly) {
/*      */       return;
/*      */     }
/*      */     
/* 1106 */     Connection dbConnection = openConnection();
/* 1107 */     if (dbConnection == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1111 */     this.dbWriteLock.lock();
/*      */     try {
/*      */       try {
/* 1114 */         saveInternal(dbConnection);
/*      */       } finally {
/* 1116 */         closeConnection(dbConnection);
/*      */       } 
/*      */     } finally {
/* 1119 */       this.dbWriteLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void saveInternal(Connection dbConnection) {
/* 1125 */     StringBuilder temp = null;
/*      */     
/* 1127 */     StringBuilder tempRelationDelete = null;
/*      */     
/* 1129 */     if (isRoleStoreDefined()) {
/*      */ 
/*      */       
/* 1132 */       if (!this.removedRoles.isEmpty()) {
/* 1133 */         temp = new StringBuilder("DELETE FROM ");
/* 1134 */         temp.append(this.roleTable);
/* 1135 */         temp.append(" WHERE ").append(this.roleNameCol);
/* 1136 */         temp.append(" = ?");
/* 1137 */         if (this.groupRoleTable != null) {
/* 1138 */           tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1139 */           tempRelationDelete.append(this.groupRoleTable);
/* 1140 */           tempRelationDelete.append(" WHERE ");
/* 1141 */           tempRelationDelete.append(this.roleNameCol);
/* 1142 */           tempRelationDelete.append(" = ?");
/*      */         } 
/* 1144 */         StringBuilder tempRelationDelete2 = new StringBuilder("DELETE FROM ");
/* 1145 */         tempRelationDelete2.append(this.userRoleTable);
/* 1146 */         tempRelationDelete2.append(" WHERE ");
/* 1147 */         tempRelationDelete2.append(this.roleNameCol);
/* 1148 */         tempRelationDelete2.append(" = ?");
/* 1149 */         for (Role role : this.removedRoles.values()) {
/* 1150 */           if (tempRelationDelete != null)
/* 1151 */             try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete.toString()); 
/* 1152 */               try { stmt.setString(1, role.getRolename());
/* 1153 */                 stmt.executeUpdate();
/* 1154 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1155 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */              
/*      */           
/* 1158 */           try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete2.toString()); 
/* 1159 */             try { stmt.setString(1, role.getRolename());
/* 1160 */               stmt.executeUpdate();
/* 1161 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1162 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            
/* 1164 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1165 */             try { stmt.setString(1, role.getRolename());
/* 1166 */               stmt.executeUpdate();
/* 1167 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1168 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/*      */         } 
/* 1171 */         this.removedRoles.clear();
/*      */       } 
/*      */ 
/*      */       
/* 1175 */       if (!this.createdRoles.isEmpty()) {
/* 1176 */         temp = new StringBuilder("INSERT INTO ");
/* 1177 */         temp.append(this.roleTable);
/* 1178 */         temp.append('(').append(this.roleNameCol);
/* 1179 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1180 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/* 1182 */         temp.append(") VALUES (?");
/* 1183 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1184 */           temp.append(", ?");
/*      */         }
/* 1186 */         temp.append(')');
/* 1187 */         for (Role role : this.createdRoles.values()) { 
/* 1188 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1189 */             try { stmt.setString(1, role.getRolename());
/* 1190 */               if (this.roleAndGroupDescriptionCol != null) {
/* 1191 */                 stmt.setString(2, role.getDescription());
/*      */               }
/* 1193 */               stmt.executeUpdate();
/* 1194 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1195 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            }
/*      */         
/* 1198 */         this.createdRoles.clear();
/*      */       } 
/*      */ 
/*      */       
/* 1202 */       if (!this.modifiedRoles.isEmpty() && this.roleAndGroupDescriptionCol != null) {
/* 1203 */         temp = new StringBuilder("UPDATE ");
/* 1204 */         temp.append(this.roleTable);
/* 1205 */         temp.append(" SET ").append(this.roleAndGroupDescriptionCol);
/* 1206 */         temp.append(" = ? WHERE ").append(this.roleNameCol);
/* 1207 */         temp.append(" = ?");
/* 1208 */         for (Role role : this.modifiedRoles.values()) { 
/* 1209 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1210 */             try { stmt.setString(1, role.getDescription());
/* 1211 */               stmt.setString(2, role.getRolename());
/* 1212 */               stmt.executeUpdate();
/* 1213 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1214 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            }
/*      */         
/* 1217 */         this.modifiedRoles.clear();
/*      */       }
/*      */     
/* 1220 */     } else if (this.userRoleTable != null && this.roleNameCol != null) {
/*      */       
/* 1222 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1223 */       tempRelationDelete.append(this.userRoleTable);
/* 1224 */       tempRelationDelete.append(" WHERE ");
/* 1225 */       tempRelationDelete.append(this.roleNameCol);
/* 1226 */       tempRelationDelete.append(" = ?");
/* 1227 */       for (Role role : this.removedRoles.values()) { 
/* 1228 */         try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete.toString()); 
/* 1229 */           try { stmt.setString(1, role.getRolename());
/* 1230 */             stmt.executeUpdate();
/* 1231 */             if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1232 */         { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */          }
/*      */       
/* 1235 */       this.removedRoles.clear();
/*      */     } 
/*      */     
/* 1238 */     if (isGroupStoreDefined()) {
/*      */       
/* 1240 */       StringBuilder tempRelation = new StringBuilder("INSERT INTO ");
/* 1241 */       tempRelation.append(this.groupRoleTable);
/* 1242 */       tempRelation.append('(').append(this.groupNameCol).append(", ");
/* 1243 */       tempRelation.append(this.roleNameCol);
/* 1244 */       tempRelation.append(") VALUES (?, ?)");
/* 1245 */       String groupRoleRelation = tempRelation.toString();
/*      */       
/* 1247 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1248 */       tempRelationDelete.append(this.groupRoleTable);
/* 1249 */       tempRelationDelete.append(" WHERE ");
/* 1250 */       tempRelationDelete.append(this.groupNameCol);
/* 1251 */       tempRelationDelete.append(" = ?");
/* 1252 */       String groupRoleRelationDelete = tempRelationDelete.toString();
/*      */ 
/*      */       
/* 1255 */       if (!this.removedGroups.isEmpty()) {
/* 1256 */         temp = new StringBuilder("DELETE FROM ");
/* 1257 */         temp.append(this.groupTable);
/* 1258 */         temp.append(" WHERE ").append(this.groupNameCol);
/* 1259 */         temp.append(" = ?");
/* 1260 */         StringBuilder tempRelationDelete2 = new StringBuilder("DELETE FROM ");
/* 1261 */         tempRelationDelete2.append(this.userGroupTable);
/* 1262 */         tempRelationDelete2.append(" WHERE ");
/* 1263 */         tempRelationDelete2.append(this.groupNameCol);
/* 1264 */         tempRelationDelete2.append(" = ?");
/* 1265 */         for (Group group : this.removedGroups.values()) { 
/* 1266 */           try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelationDelete); 
/* 1267 */             try { stmt.setString(1, group.getGroupname());
/* 1268 */               stmt.executeUpdate();
/* 1269 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1270 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            
/* 1272 */           try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete2.toString()); 
/* 1273 */             try { stmt.setString(1, group.getGroupname());
/* 1274 */               stmt.executeUpdate();
/* 1275 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1276 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            
/* 1278 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1279 */             try { stmt.setString(1, group.getGroupname());
/* 1280 */               stmt.executeUpdate();
/* 1281 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1282 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            }
/*      */         
/* 1285 */         this.removedGroups.clear();
/*      */       } 
/*      */ 
/*      */       
/* 1289 */       if (!this.createdGroups.isEmpty()) {
/* 1290 */         temp = new StringBuilder("INSERT INTO ");
/* 1291 */         temp.append(this.groupTable);
/* 1292 */         temp.append('(').append(this.groupNameCol);
/* 1293 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1294 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/* 1296 */         temp.append(") VALUES (?");
/* 1297 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1298 */           temp.append(", ?");
/*      */         }
/* 1300 */         temp.append(')');
/* 1301 */         for (Group group : this.createdGroups.values()) { 
/* 1302 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1303 */             try { stmt.setString(1, group.getGroupname());
/* 1304 */               if (this.roleAndGroupDescriptionCol != null) {
/* 1305 */                 stmt.setString(2, group.getDescription());
/*      */               }
/* 1307 */               stmt.executeUpdate();
/* 1308 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1309 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/* 1311 */           Iterator<Role> roles = group.getRoles();
/* 1312 */           while (roles.hasNext()) {
/* 1313 */             Role role = roles.next(); 
/* 1314 */             try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelation); 
/* 1315 */               try { stmt.setString(1, group.getGroupname());
/* 1316 */                 stmt.setString(2, role.getRolename());
/* 1317 */                 stmt.executeUpdate();
/* 1318 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1319 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           }  }
/*      */         
/* 1323 */         this.createdGroups.clear();
/*      */       } 
/*      */ 
/*      */       
/* 1327 */       if (!this.modifiedGroups.isEmpty()) {
/* 1328 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1329 */           temp = new StringBuilder("UPDATE ");
/* 1330 */           temp.append(this.groupTable);
/* 1331 */           temp.append(" SET ").append(this.roleAndGroupDescriptionCol);
/* 1332 */           temp.append(" = ? WHERE ").append(this.groupNameCol);
/* 1333 */           temp.append(" = ?");
/*      */         } 
/* 1335 */         for (Group group : this.modifiedGroups.values()) {
/* 1336 */           if (temp != null)
/* 1337 */             try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1338 */               try { stmt.setString(1, group.getDescription());
/* 1339 */                 stmt.setString(2, group.getGroupname());
/* 1340 */                 stmt.executeUpdate();
/* 1341 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1342 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */              
/*      */           
/* 1345 */           try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelationDelete); 
/* 1346 */             try { stmt.setString(1, group.getGroupname());
/* 1347 */               stmt.executeUpdate();
/* 1348 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1349 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/* 1351 */           Iterator<Role> roles = group.getRoles();
/* 1352 */           while (roles.hasNext()) {
/* 1353 */             Role role = roles.next(); 
/* 1354 */             try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelation); 
/* 1355 */               try { stmt.setString(1, group.getGroupname());
/* 1356 */                 stmt.setString(2, role.getRolename());
/* 1357 */                 stmt.executeUpdate();
/* 1358 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1359 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           } 
/*      */         } 
/* 1363 */         this.modifiedGroups.clear();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1368 */     String userRoleRelation = null;
/* 1369 */     String userRoleRelationDelete = null;
/* 1370 */     if (this.userRoleTable != null && this.roleNameCol != null) {
/* 1371 */       StringBuilder tempRelation = new StringBuilder("INSERT INTO ");
/* 1372 */       tempRelation.append(this.userRoleTable);
/* 1373 */       tempRelation.append('(').append(this.userNameCol).append(", ");
/* 1374 */       tempRelation.append(this.roleNameCol);
/* 1375 */       tempRelation.append(") VALUES (?, ?)");
/* 1376 */       userRoleRelation = tempRelation.toString();
/*      */       
/* 1378 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1379 */       tempRelationDelete.append(this.userRoleTable);
/* 1380 */       tempRelationDelete.append(" WHERE ");
/* 1381 */       tempRelationDelete.append(this.userNameCol);
/* 1382 */       tempRelationDelete.append(" = ?");
/* 1383 */       userRoleRelationDelete = tempRelationDelete.toString();
/*      */     } 
/* 1385 */     String userGroupRelation = null;
/* 1386 */     String userGroupRelationDelete = null;
/* 1387 */     if (isGroupStoreDefined()) {
/* 1388 */       StringBuilder tempRelation = new StringBuilder("INSERT INTO ");
/* 1389 */       tempRelation.append(this.userGroupTable);
/* 1390 */       tempRelation.append('(').append(this.userNameCol).append(", ");
/* 1391 */       tempRelation.append(this.groupNameCol);
/* 1392 */       tempRelation.append(") VALUES (?, ?)");
/* 1393 */       userGroupRelation = tempRelation.toString();
/*      */       
/* 1395 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1396 */       tempRelationDelete.append(this.userGroupTable);
/* 1397 */       tempRelationDelete.append(" WHERE ");
/* 1398 */       tempRelationDelete.append(this.userNameCol);
/* 1399 */       tempRelationDelete.append(" = ?");
/* 1400 */       userGroupRelationDelete = tempRelationDelete.toString();
/*      */     } 
/*      */ 
/*      */     
/* 1404 */     if (!this.removedUsers.isEmpty()) {
/* 1405 */       temp = new StringBuilder("DELETE FROM ");
/* 1406 */       temp.append(this.userTable);
/* 1407 */       temp.append(" WHERE ").append(this.userNameCol);
/* 1408 */       temp.append(" = ?");
/* 1409 */       for (User user : this.removedUsers.values()) {
/* 1410 */         if (userRoleRelationDelete != null) {
/* 1411 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelationDelete); 
/* 1412 */             try { stmt.setString(1, user.getUsername());
/* 1413 */               stmt.executeUpdate();
/* 1414 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1415 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/*      */         }
/* 1418 */         if (userGroupRelationDelete != null)
/* 1419 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelationDelete); 
/* 1420 */             try { stmt.setString(1, user.getUsername());
/* 1421 */               stmt.executeUpdate();
/* 1422 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1423 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */            
/*      */         
/* 1426 */         try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1427 */           try { stmt.setString(1, user.getUsername());
/* 1428 */             stmt.executeUpdate();
/* 1429 */             if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1430 */         { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */       
/*      */       } 
/* 1433 */       this.removedUsers.clear();
/*      */     } 
/*      */ 
/*      */     
/* 1437 */     if (!this.createdUsers.isEmpty()) {
/* 1438 */       temp = new StringBuilder("INSERT INTO ");
/* 1439 */       temp.append(this.userTable);
/* 1440 */       temp.append('(').append(this.userNameCol);
/* 1441 */       temp.append(", ").append(this.userCredCol);
/* 1442 */       if (this.userFullNameCol != null) {
/* 1443 */         temp.append(',').append(this.userFullNameCol);
/*      */       }
/* 1445 */       temp.append(") VALUES (?, ?");
/* 1446 */       if (this.userFullNameCol != null) {
/* 1447 */         temp.append(", ?");
/*      */       }
/* 1449 */       temp.append(')');
/* 1450 */       for (User user : this.createdUsers.values()) { 
/* 1451 */         try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1452 */           try { stmt.setString(1, user.getUsername());
/* 1453 */             stmt.setString(2, user.getPassword());
/* 1454 */             if (this.userFullNameCol != null) {
/* 1455 */               stmt.setString(3, user.getFullName());
/*      */             }
/* 1457 */             stmt.executeUpdate();
/* 1458 */             if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1459 */         { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/* 1461 */         if (userRoleRelation != null) {
/* 1462 */           Iterator<Role> roles = user.getRoles();
/* 1463 */           while (roles.hasNext()) {
/* 1464 */             Role role = roles.next(); 
/* 1465 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelation); 
/* 1466 */               try { stmt.setString(1, user.getUsername());
/* 1467 */                 stmt.setString(2, role.getRolename());
/* 1468 */                 stmt.executeUpdate();
/* 1469 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1470 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           } 
/*      */         } 
/* 1474 */         if (userGroupRelation != null) {
/* 1475 */           Iterator<Group> groups = user.getGroups();
/* 1476 */           while (groups.hasNext()) {
/* 1477 */             Group group = groups.next(); 
/* 1478 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelation); 
/* 1479 */               try { stmt.setString(1, user.getUsername());
/* 1480 */                 stmt.setString(2, group.getGroupname());
/* 1481 */                 stmt.executeUpdate();
/* 1482 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1483 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           } 
/*      */         }  }
/*      */       
/* 1488 */       this.createdUsers.clear();
/*      */     } 
/*      */ 
/*      */     
/* 1492 */     if (!this.modifiedUsers.isEmpty()) {
/* 1493 */       temp = new StringBuilder("UPDATE ");
/* 1494 */       temp.append(this.userTable);
/* 1495 */       temp.append(" SET ").append(this.userCredCol);
/* 1496 */       temp.append(" = ?");
/* 1497 */       if (this.userFullNameCol != null) {
/* 1498 */         temp.append(", ").append(this.userFullNameCol).append(" = ?");
/*      */       }
/* 1500 */       temp.append(" WHERE ").append(this.userNameCol);
/* 1501 */       temp.append(" = ?");
/* 1502 */       for (User user : this.modifiedUsers.values()) { 
/* 1503 */         try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString()); 
/* 1504 */           try { stmt.setString(1, user.getPassword());
/* 1505 */             if (this.userFullNameCol != null) {
/* 1506 */               stmt.setString(2, user.getFullName());
/* 1507 */               stmt.setString(3, user.getUsername());
/*      */             } else {
/* 1509 */               stmt.setString(2, user.getUsername());
/*      */             } 
/* 1511 */             stmt.executeUpdate();
/* 1512 */             if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1513 */         { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/* 1515 */         if (userRoleRelationDelete != null) {
/* 1516 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelationDelete); 
/* 1517 */             try { stmt.setString(1, user.getUsername());
/* 1518 */               stmt.executeUpdate();
/* 1519 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1520 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/*      */         }
/* 1523 */         if (userGroupRelationDelete != null) {
/* 1524 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelationDelete); 
/* 1525 */             try { stmt.setString(1, user.getUsername());
/* 1526 */               stmt.executeUpdate();
/* 1527 */               if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1528 */           { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */         
/*      */         }
/* 1531 */         if (userRoleRelation != null) {
/* 1532 */           Iterator<Role> roles = user.getRoles();
/* 1533 */           while (roles.hasNext()) {
/* 1534 */             Role role = roles.next(); 
/* 1535 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelation); 
/* 1536 */               try { stmt.setString(1, user.getUsername());
/* 1537 */                 stmt.setString(2, role.getRolename());
/* 1538 */                 stmt.executeUpdate();
/* 1539 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1540 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           } 
/*      */         } 
/* 1544 */         if (userGroupRelation != null) {
/* 1545 */           Iterator<Group> groups = user.getGroups();
/* 1546 */           while (groups.hasNext()) {
/* 1547 */             Group group = groups.next(); 
/* 1548 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelation); 
/* 1549 */               try { stmt.setString(1, user.getUsername());
/* 1550 */                 stmt.setString(2, group.getGroupname());
/* 1551 */                 stmt.executeUpdate();
/* 1552 */                 if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1553 */             { log.error(sm.getString("dataSourceUserDatabase.exception"), e); }
/*      */           
/*      */           } 
/*      */         }  }
/*      */       
/* 1558 */       this.modifiedGroups.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAvailable() {
/* 1565 */     return this.connectionSuccess;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isGroupStoreDefined() {
/* 1574 */     return (this.groupTable != null && this.userGroupTable != null && this.groupNameCol != null && this.groupRoleTable != null && 
/* 1575 */       isRoleStoreDefined());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isRoleStoreDefined() {
/* 1585 */     return (this.roleTable != null && this.userRoleTable != null && this.roleNameCol != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Connection openConnection() {
/* 1595 */     if (this.dataSource == null) {
/* 1596 */       return null;
/*      */     }
/*      */     try {
/* 1599 */       Connection connection = this.dataSource.getConnection();
/* 1600 */       this.connectionSuccess = true;
/* 1601 */       return connection;
/* 1602 */     } catch (Exception e) {
/* 1603 */       this.connectionSuccess = false;
/*      */       
/* 1605 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */       
/* 1607 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeConnection(Connection dbConnection) {
/* 1618 */     if (dbConnection == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1624 */       if (!dbConnection.getAutoCommit()) {
/* 1625 */         dbConnection.commit();
/*      */       }
/* 1627 */     } catch (SQLException e) {
/* 1628 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1633 */       dbConnection.close();
/* 1634 */     } catch (SQLException e) {
/* 1635 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\DataSourceUserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */