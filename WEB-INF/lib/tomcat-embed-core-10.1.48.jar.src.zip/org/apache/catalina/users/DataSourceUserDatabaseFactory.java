/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceUserDatabaseFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment) throws Exception {
/*  70 */     if (!(obj instanceof Reference)) {
/*  71 */       return null;
/*     */     }
/*  73 */     Reference ref = (Reference)obj;
/*  74 */     if (!"org.apache.catalina.UserDatabase".equals(ref.getClassName())) {
/*  75 */       return null;
/*     */     }
/*     */     
/*  78 */     DataSource dataSource = null;
/*  79 */     String dataSourceName = null;
/*  80 */     RefAddr ra = ref.get("dataSourceName");
/*  81 */     if (ra != null) {
/*  82 */       dataSourceName = ra.getContent().toString();
/*  83 */       dataSource = (DataSource)nameCtx.lookup(dataSourceName);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  88 */     DataSourceUserDatabase database = new DataSourceUserDatabase(dataSource, name.toString());
/*  89 */     database.setDataSourceName(dataSourceName);
/*     */     
/*  91 */     ra = ref.get("readonly");
/*  92 */     if (ra != null) {
/*  93 */       database.setReadonly(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */     
/*  96 */     ra = ref.get("userTable");
/*  97 */     if (ra != null) {
/*  98 */       database.setUserTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 101 */     ra = ref.get("groupTable");
/* 102 */     if (ra != null) {
/* 103 */       database.setGroupTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 106 */     ra = ref.get("roleTable");
/* 107 */     if (ra != null) {
/* 108 */       database.setRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 111 */     ra = ref.get("userRoleTable");
/* 112 */     if (ra != null) {
/* 113 */       database.setUserRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 116 */     ra = ref.get("userGroupTable");
/* 117 */     if (ra != null) {
/* 118 */       database.setUserGroupTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 121 */     ra = ref.get("groupRoleTable");
/* 122 */     if (ra != null) {
/* 123 */       database.setGroupRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 126 */     ra = ref.get("roleNameCol");
/* 127 */     if (ra != null) {
/* 128 */       database.setRoleNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 131 */     ra = ref.get("roleAndGroupDescriptionCol");
/* 132 */     if (ra != null) {
/* 133 */       database.setRoleAndGroupDescriptionCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 136 */     ra = ref.get("groupNameCol");
/* 137 */     if (ra != null) {
/* 138 */       database.setGroupNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 141 */     ra = ref.get("userCredCol");
/* 142 */     if (ra != null) {
/* 143 */       database.setUserCredCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 146 */     ra = ref.get("userFullNameCol");
/* 147 */     if (ra != null) {
/* 148 */       database.setUserFullNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 151 */     ra = ref.get("userNameCol");
/* 152 */     if (ra != null) {
/* 153 */       database.setUserNameCol(ra.getContent().toString());
/*     */     }
/*     */ 
/*     */     
/* 157 */     database.open();
/* 158 */     return database;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\DataSourceUserDatabaseFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */