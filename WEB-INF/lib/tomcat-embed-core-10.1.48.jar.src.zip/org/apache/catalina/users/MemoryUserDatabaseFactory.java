/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryUserDatabaseFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment) throws Exception {
/*  72 */     if (!(obj instanceof Reference)) {
/*  73 */       return null;
/*     */     }
/*  75 */     Reference ref = (Reference)obj;
/*  76 */     if (!"org.apache.catalina.UserDatabase".equals(ref.getClassName())) {
/*  77 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  82 */     MemoryUserDatabase database = new MemoryUserDatabase(name.toString());
/*  83 */     RefAddr ra = ref.get("pathname");
/*  84 */     if (ra != null) {
/*  85 */       database.setPathname(ra.getContent().toString());
/*     */     }
/*     */     
/*  88 */     ra = ref.get("readonly");
/*  89 */     if (ra != null) {
/*  90 */       database.setReadonly(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */     
/*  93 */     ra = ref.get("watchSource");
/*  94 */     if (ra != null) {
/*  95 */       database.setWatchSource(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */ 
/*     */     
/*  99 */     database.open();
/*     */     
/* 101 */     if (!database.getReadonly()) {
/* 102 */       database.save();
/*     */     }
/* 104 */     return database;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\MemoryUserDatabaseFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */