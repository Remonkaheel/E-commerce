/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.ObjectCreationFactory;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryUserDatabase
/*     */   implements UserDatabase
/*     */ {
/*  77 */   private static final Log log = LogFactory.getLog(MemoryUserDatabase.class);
/*  78 */   private static final StringManager sm = StringManager.getManager(MemoryUserDatabase.class); protected final Map<String, Group> groups; protected final String id; protected String pathname; protected String pathnameOld; protected String pathnameNew; protected boolean readonly; protected final Map<String, Role> roles;
/*     */   protected final Map<String, User> users;
/*     */   private final ReentrantReadWriteLock dbLock;
/*     */   private final Lock readLock;
/*     */   private final Lock writeLock;
/*     */   private volatile long lastModified;
/*     */   private boolean watchSource;
/*     */   
/*     */   public MemoryUserDatabase() {
/*  87 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemoryUserDatabase(String id) {
/* 105 */     this.groups = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.pathname = "conf/tomcat-users.xml";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.pathnameOld = this.pathname + ".old";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.pathnameNew = this.pathname + ".new";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     this.readonly = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.roles = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.users = new ConcurrentHashMap<>();
/*     */     
/* 144 */     this.dbLock = new ReentrantReadWriteLock();
/* 145 */     this.readLock = this.dbLock.readLock();
/* 146 */     this.writeLock = this.dbLock.writeLock();
/*     */     
/* 148 */     this.lastModified = 0L;
/* 149 */     this.watchSource = true;
/*     */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Group> getGroups() {
/* 156 */     this.readLock.lock();
/*     */     try {
/* 158 */       return (Iterator)(new ArrayList(this.groups.values())).iterator();
/*     */     } finally {
/* 160 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 167 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPathname() {
/* 175 */     return this.pathname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathname(String pathname) {
/* 185 */     this.pathname = pathname;
/* 186 */     this.pathnameOld = pathname + ".old";
/* 187 */     this.pathnameNew = pathname + ".new";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getReadonly() {
/* 195 */     return this.readonly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadonly(boolean readonly) {
/* 205 */     this.readonly = readonly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getWatchSource() {
/* 210 */     return this.watchSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWatchSource(boolean watchSource) {
/* 215 */     this.watchSource = watchSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Role> getRoles() {
/* 221 */     this.readLock.lock();
/*     */     try {
/* 223 */       return (Iterator)(new ArrayList(this.roles.values())).iterator();
/*     */     } finally {
/* 225 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<User> getUsers() {
/* 232 */     this.readLock.lock();
/*     */     try {
/* 234 */       return (Iterator)(new ArrayList(this.users.values())).iterator();
/*     */     } finally {
/* 236 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws Exception {
/* 246 */     this.writeLock.lock();
/*     */     try {
/* 248 */       save();
/* 249 */       this.users.clear();
/* 250 */       this.groups.clear();
/* 251 */       this.roles.clear();
/*     */     } finally {
/* 253 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Group createGroup(String groupname, String description) {
/* 260 */     if (groupname == null || groupname.isEmpty()) {
/* 261 */       String msg = sm.getString("memoryUserDatabase.nullGroup");
/* 262 */       log.warn(msg);
/* 263 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 266 */     Group<MemoryUserDatabase> group = new GenericGroup<>(this, groupname, description, null);
/* 267 */     this.readLock.lock();
/*     */     try {
/* 269 */       this.groups.put(group.getGroupname(), group);
/*     */     } finally {
/* 271 */       this.readLock.unlock();
/*     */     } 
/* 273 */     return group;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Role createRole(String rolename, String description) {
/* 279 */     if (rolename == null || rolename.isEmpty()) {
/* 280 */       String msg = sm.getString("memoryUserDatabase.nullRole");
/* 281 */       log.warn(msg);
/* 282 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 285 */     Role<MemoryUserDatabase> role = new GenericRole<>(this, rolename, description);
/* 286 */     this.readLock.lock();
/*     */     try {
/* 288 */       this.roles.put(role.getRolename(), role);
/*     */     } finally {
/* 290 */       this.readLock.unlock();
/*     */     } 
/* 292 */     return role;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User createUser(String username, String password, String fullName) {
/* 299 */     if (username == null || username.isEmpty()) {
/* 300 */       String msg = sm.getString("memoryUserDatabase.nullUser");
/* 301 */       log.warn(msg);
/* 302 */       throw new IllegalArgumentException(msg);
/*     */     } 
/*     */     
/* 305 */     User<MemoryUserDatabase> user = new GenericUser<>(this, username, password, fullName, null, null);
/* 306 */     this.readLock.lock();
/*     */     try {
/* 308 */       this.users.put(user.getUsername(), user);
/*     */     } finally {
/* 310 */       this.readLock.unlock();
/*     */     } 
/* 312 */     return user;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Group findGroup(String groupname) {
/* 318 */     this.readLock.lock();
/*     */     try {
/* 320 */       return this.groups.get(groupname);
/*     */     } finally {
/* 322 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Role findRole(String rolename) {
/* 329 */     this.readLock.lock();
/*     */     try {
/* 331 */       return this.roles.get(rolename);
/*     */     } finally {
/* 333 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public User findUser(String username) {
/* 340 */     this.readLock.lock();
/*     */     try {
/* 342 */       return this.users.get(username);
/*     */     } finally {
/* 344 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws Exception {
/* 351 */     this.writeLock.lock();
/*     */     
/*     */     try {
/* 354 */       this.users.clear();
/* 355 */       this.groups.clear();
/* 356 */       this.roles.clear();
/*     */       
/* 358 */       String pathName = getPathname(); 
/* 359 */       try { ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getResource(pathName); 
/* 360 */         try { this.lastModified = resource.getLastModified();
/*     */ 
/*     */           
/* 363 */           Digester digester = new Digester();
/*     */           try {
/* 365 */             digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/* 366 */           } catch (Exception e) {
/* 367 */             log.warn(sm.getString("memoryUserDatabase.xmlFeatureEncoding"), e);
/*     */           } 
/* 369 */           digester.addFactoryCreate("tomcat-users/group", (ObjectCreationFactory)new MemoryGroupCreationFactory(this), true);
/* 370 */           digester.addFactoryCreate("tomcat-users/role", (ObjectCreationFactory)new MemoryRoleCreationFactory(this), true);
/* 371 */           digester.addFactoryCreate("tomcat-users/user", (ObjectCreationFactory)new MemoryUserCreationFactory(this), true);
/*     */ 
/*     */           
/* 374 */           digester.parse(resource.getInputStream());
/* 375 */           if (resource != null) resource.close();  } catch (Throwable throwable) { if (resource != null) try { resource.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 376 */       { log.error(sm.getString("memoryUserDatabase.fileNotFound", new Object[] { pathName })); }
/* 377 */       catch (Exception e)
/*     */       
/* 379 */       { this.users.clear();
/* 380 */         this.groups.clear();
/* 381 */         this.roles.clear();
/* 382 */         throw e; }
/*     */     
/*     */     } finally {
/* 385 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroup(Group group) {
/* 392 */     this.readLock.lock();
/*     */     try {
/* 394 */       Iterator<User> users = getUsers();
/* 395 */       while (users.hasNext()) {
/* 396 */         User user = users.next();
/* 397 */         user.removeGroup(group);
/*     */       } 
/* 399 */       this.groups.remove(group.getGroupname());
/*     */     } finally {
/* 401 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(Role role) {
/* 408 */     this.readLock.lock();
/*     */     try {
/* 410 */       Iterator<Group> groups = getGroups();
/* 411 */       while (groups.hasNext()) {
/* 412 */         Group group = groups.next();
/* 413 */         group.removeRole(role);
/*     */       } 
/* 415 */       Iterator<User> users = getUsers();
/* 416 */       while (users.hasNext()) {
/* 417 */         User user = users.next();
/* 418 */         user.removeRole(role);
/*     */       } 
/* 420 */       this.roles.remove(role.getRolename());
/*     */     } finally {
/* 422 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUser(User user) {
/* 429 */     this.readLock.lock();
/*     */     try {
/* 431 */       this.users.remove(user.getUsername());
/*     */     } finally {
/* 433 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 445 */     File file = new File(this.pathname);
/* 446 */     if (!file.isAbsolute()) {
/* 447 */       file = new File(System.getProperty("catalina.base"), this.pathname);
/*     */     }
/* 449 */     File dir = file.getParentFile();
/* 450 */     return (dir.exists() && dir.isDirectory() && dir.canWrite());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws Exception {
/* 457 */     if (getReadonly()) {
/* 458 */       log.error(sm.getString("memoryUserDatabase.readOnly"));
/*     */       
/*     */       return;
/*     */     } 
/* 462 */     if (!isWritable()) {
/* 463 */       log.warn(sm.getString("memoryUserDatabase.notPersistable"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 468 */     File fileNew = new File(this.pathnameNew);
/* 469 */     if (!fileNew.isAbsolute()) {
/* 470 */       fileNew = new File(System.getProperty("catalina.base"), this.pathnameNew);
/*     */     }
/*     */     
/* 473 */     this.writeLock.lock(); try {
/*     */       
/* 475 */       try { FileOutputStream fos = new FileOutputStream(fileNew); 
/* 476 */         try { OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8); 
/* 477 */           try { PrintWriter writer = new PrintWriter(osw);
/*     */ 
/*     */             
/* 480 */             try { writer.println("<?xml version='1.0' encoding='utf-8'?>");
/* 481 */               writer.println("<tomcat-users xmlns=\"http://tomcat.apache.org/xml\"");
/* 482 */               writer.println("              xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
/* 483 */               writer.println("              xsi:schemaLocation=\"http://tomcat.apache.org/xml tomcat-users.xsd\"");
/* 484 */               writer.println("              version=\"1.0\">");
/*     */ 
/*     */               
/* 487 */               Iterator<?> values = getRoles();
/* 488 */               while (values.hasNext()) {
/* 489 */                 Role role = (Role)values.next();
/* 490 */                 writer.print("  <role rolename=\"");
/* 491 */                 writer.print(Escape.xml(role.getRolename()));
/* 492 */                 writer.print("\"");
/* 493 */                 if (null != role.getDescription()) {
/* 494 */                   writer.print(" description=\"");
/* 495 */                   writer.print(Escape.xml(role.getDescription()));
/* 496 */                   writer.print("\"");
/*     */                 } 
/* 498 */                 writer.println("/>");
/*     */               } 
/* 500 */               values = getGroups();
/* 501 */               while (values.hasNext()) {
/* 502 */                 Group group = (Group)values.next();
/* 503 */                 writer.print("  <group groupname=\"");
/* 504 */                 writer.print(Escape.xml(group.getName()));
/* 505 */                 writer.print("\"");
/* 506 */                 if (null != group.getDescription()) {
/* 507 */                   writer.print(" description=\"");
/* 508 */                   writer.print(Escape.xml(group.getDescription()));
/* 509 */                   writer.print("\"");
/*     */                 } 
/* 511 */                 writer.print(" roles=\"");
/* 512 */                 for (Iterator<Role> roles = group.getRoles(); roles.hasNext(); ) {
/* 513 */                   Role role = roles.next();
/* 514 */                   writer.print(Escape.xml(role.getRolename()));
/* 515 */                   if (roles.hasNext()) {
/* 516 */                     writer.print(',');
/*     */                   }
/*     */                 } 
/* 519 */                 writer.println("\"/>");
/*     */               } 
/*     */               
/* 522 */               values = getUsers();
/* 523 */               while (values.hasNext()) {
/* 524 */                 User user = (User)values.next();
/* 525 */                 writer.print("  <user username=\"");
/* 526 */                 writer.print(Escape.xml(user.getUsername()));
/* 527 */                 writer.print("\" password=\"");
/* 528 */                 writer.print(Escape.xml(user.getPassword()));
/* 529 */                 writer.print("\"");
/* 530 */                 if (null != user.getFullName()) {
/* 531 */                   writer.print(" fullName=\"");
/* 532 */                   writer.print(Escape.xml(user.getFullName()));
/* 533 */                   writer.print("\"");
/*     */                 } 
/* 535 */                 writer.print(" groups=\"");
/* 536 */                 for (Iterator<Group> groups = user.getGroups(); groups.hasNext(); ) {
/* 537 */                   Group group = groups.next();
/* 538 */                   writer.print(Escape.xml(group.getGroupname()));
/* 539 */                   if (groups.hasNext()) {
/* 540 */                     writer.print(',');
/*     */                   }
/*     */                 } 
/* 543 */                 writer.print("\" roles=\"");
/* 544 */                 for (Iterator<Role> roles = user.getRoles(); roles.hasNext(); ) {
/* 545 */                   Role role = roles.next();
/* 546 */                   writer.print(Escape.xml(role.getRolename()));
/* 547 */                   if (roles.hasNext()) {
/* 548 */                     writer.print(',');
/*     */                   }
/*     */                 } 
/* 551 */                 writer.print("\"/>");
/*     */               } 
/*     */ 
/*     */               
/* 555 */               writer.println("</tomcat-users>");
/*     */ 
/*     */               
/* 558 */               if (writer.checkError()) {
/* 559 */                 throw new IOException(sm.getString("memoryUserDatabase.writeException", new Object[] { fileNew.getAbsolutePath() }));
/*     */               }
/* 561 */               writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  osw.close(); } catch (Throwable throwable) { try { osw.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException ioe)
/* 562 */       { if (fileNew.exists() && !fileNew.delete()) {
/* 563 */           log.warn(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileNew }));
/*     */         }
/* 565 */         throw ioe; }
/*     */       
/* 567 */       this.lastModified = fileNew.lastModified();
/*     */     } finally {
/* 569 */       this.writeLock.unlock();
/*     */     } 
/*     */ 
/*     */     
/* 573 */     File fileOld = new File(this.pathnameOld);
/* 574 */     if (!fileOld.isAbsolute()) {
/* 575 */       fileOld = new File(System.getProperty("catalina.base"), this.pathnameOld);
/*     */     }
/* 577 */     if (fileOld.exists() && !fileOld.delete()) {
/* 578 */       throw new IOException(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileOld }));
/*     */     }
/* 580 */     File fileOrig = new File(this.pathname);
/* 581 */     if (!fileOrig.isAbsolute()) {
/* 582 */       fileOrig = new File(System.getProperty("catalina.base"), this.pathname);
/*     */     }
/* 584 */     if (fileOrig.exists() && 
/* 585 */       !fileOrig.renameTo(fileOld)) {
/* 586 */       throw new IOException(sm.getString("memoryUserDatabase.renameOld", new Object[] { fileOld.getAbsolutePath() }));
/*     */     }
/*     */     
/* 589 */     if (!fileNew.renameTo(fileOrig)) {
/* 590 */       if (fileOld.exists() && 
/* 591 */         !fileOld.renameTo(fileOrig)) {
/* 592 */         log.warn(sm.getString("memoryUserDatabase.restoreOrig", new Object[] { fileOld }));
/*     */       }
/*     */       
/* 595 */       throw new IOException(sm.getString("memoryUserDatabase.renameNew", new Object[] { fileOrig.getAbsolutePath() }));
/*     */     } 
/* 597 */     if (fileOld.exists() && !fileOld.delete()) {
/* 598 */       throw new IOException(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileOld }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void backgroundProcess() {
/* 605 */     if (!this.watchSource) {
/*     */       return;
/*     */     }
/*     */     
/* 609 */     URI uri = ConfigFileLoader.getSource().getURI(getPathname());
/* 610 */     URLConnection uConn = null;
/*     */     try {
/* 612 */       URL url = uri.toURL();
/* 613 */       uConn = url.openConnection();
/*     */       
/* 615 */       if (this.lastModified != uConn.getLastModified()) {
/* 616 */         this.writeLock.lock();
/*     */         try {
/* 618 */           long detectedLastModified = uConn.getLastModified();
/*     */ 
/*     */ 
/*     */           
/* 622 */           if (this.lastModified != detectedLastModified && detectedLastModified + 2000L < 
/* 623 */             System.currentTimeMillis()) {
/* 624 */             log.info(sm.getString("memoryUserDatabase.reload", new Object[] { this.id, uri }));
/* 625 */             open();
/*     */           } 
/*     */         } finally {
/* 628 */           this.writeLock.unlock();
/*     */         } 
/*     */       } 
/* 631 */     } catch (Exception e) {
/* 632 */       log.error(sm.getString("memoryUserDatabase.reloadError", new Object[] { this.id, uri }), e);
/*     */     } finally {
/* 634 */       if (uConn != null) {
/*     */         
/*     */         try {
/* 637 */           uConn.getInputStream().close();
/* 638 */         } catch (FileNotFoundException fnfe) {
/*     */ 
/*     */ 
/*     */           
/* 642 */           this.lastModified = 0L;
/* 643 */         } catch (IOException ioe) {
/* 644 */           log.warn(sm.getString("memoryUserDatabase.fileClose", new Object[] { this.pathname }), ioe);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 653 */     return "MemoryUserDatabase[id=" + this.id + ",pathname=" + this.pathname + ",groupCount=" + this.groups.size() + ",roleCount=" + this.roles
/* 654 */       .size() + ",userCount=" + this.users.size() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\MemoryUserDatabase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */