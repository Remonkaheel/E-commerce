/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ import org.apache.catalina.Role;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRole
/*    */   implements Role
/*    */ {
/* 39 */   protected String description = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   protected String rolename = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 53 */     return this.description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDescription(String description) {
/* 59 */     this.description = description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRolename() {
/* 65 */     return this.rolename;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRolename(String rolename) {
/* 71 */     this.rolename = rolename;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 83 */     return getRolename();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\AbstractRole.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */