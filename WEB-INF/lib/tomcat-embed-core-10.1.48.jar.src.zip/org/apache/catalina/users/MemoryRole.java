/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ import org.apache.tomcat.util.security.Escape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MemoryRole
/*    */   extends GenericRole<MemoryUserDatabase>
/*    */ {
/*    */   MemoryRole(MemoryUserDatabase database, String rolename, String description) {
/* 45 */     super(database, rolename, description);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuilder sb = new StringBuilder("<role rolename=\"");
/* 57 */     sb.append(Escape.xml(this.rolename));
/* 58 */     sb.append("\"");
/* 59 */     if (this.description != null) {
/* 60 */       sb.append(" description=\"");
/* 61 */       sb.append(Escape.xml(this.description));
/* 62 */       sb.append("\"");
/*    */     } 
/* 64 */     sb.append("/>");
/* 65 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\MemoryRole.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */