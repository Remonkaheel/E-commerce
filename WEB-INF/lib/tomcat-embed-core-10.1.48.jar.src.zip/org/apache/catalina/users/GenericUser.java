/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericUser<UD extends UserDatabase>
/*     */   extends AbstractUser
/*     */ {
/*     */   protected final UD database;
/*     */   protected final CopyOnWriteArrayList<Group> groups;
/*     */   protected final CopyOnWriteArrayList<Role> roles;
/*     */   
/*     */   GenericUser(UD database, String username, String password, String fullName, List<Group> groups, List<Role> roles) {
/*  80 */     this.groups = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.roles = new CopyOnWriteArrayList<>();
/*     */     this.database = database;
/*     */     this.username = username;
/*     */     this.password = password;
/*     */     this.fullName = fullName;
/*     */     if (groups != null)
/*     */       this.groups.addAll(groups); 
/*     */     if (roles != null)
/*  94 */       this.roles.addAll(roles);  } public Iterator<Group> getGroups() { return this.groups.iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Role> getRoles() {
/* 100 */     return this.roles.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDatabase getUserDatabase() {
/* 106 */     return (UserDatabase)this.database;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGroup(Group group) {
/* 115 */     if (this.groups.addIfAbsent(group)) {
/* 116 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRole(Role role) {
/* 123 */     if (this.roles.addIfAbsent(role)) {
/* 124 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInGroup(Group group) {
/* 131 */     return this.groups.contains(group);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInRole(Role role) {
/* 137 */     return this.roles.contains(role);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroup(Group group) {
/* 143 */     if (this.groups.remove(group)) {
/* 144 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroups() {
/* 151 */     if (!this.groups.isEmpty()) {
/* 152 */       this.groups.clear();
/* 153 */       this.database.modifiedUser(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(Role role) {
/* 160 */     if (this.roles.remove(role)) {
/* 161 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRoles() {
/* 168 */     if (!this.roles.isEmpty()) {
/* 169 */       this.database.modifiedUser(this);
/*     */     }
/* 171 */     this.roles.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFullName(String fullName) {
/* 177 */     this.database.modifiedUser(this);
/* 178 */     super.setFullName(fullName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String password) {
/* 184 */     this.database.modifiedUser(this);
/* 185 */     super.setPassword(password);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsername(String username) {
/* 191 */     this.database.modifiedUser(this);
/*     */     
/* 193 */     super.setUsername(username);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 198 */     if (obj instanceof GenericUser) {
/* 199 */       GenericUser<?> user = (GenericUser)obj;
/* 200 */       return (user.database == this.database && this.username.equals(user.getUsername()));
/*     */     } 
/* 202 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 208 */     int prime = 31;
/* 209 */     int result = 1;
/* 210 */     result = 31 * result + ((this.database == null) ? 0 : this.database.hashCode());
/* 211 */     result = 31 * result + ((this.username == null) ? 0 : this.username.hashCode());
/* 212 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\users\GenericUser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */