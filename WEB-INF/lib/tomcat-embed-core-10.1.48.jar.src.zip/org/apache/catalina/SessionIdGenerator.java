package org.apache.catalina;

public interface SessionIdGenerator {
  String getJvmRoute();
  
  void setJvmRoute(String paramString);
  
  int getSessionIdLength();
  
  void setSessionIdLength(int paramInt);
  
  String generateSessionId();
  
  String generateSessionId(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\SessionIdGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */