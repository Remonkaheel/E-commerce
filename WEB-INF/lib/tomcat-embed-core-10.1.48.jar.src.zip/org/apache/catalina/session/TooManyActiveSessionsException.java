/*    */ package org.apache.catalina.session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooManyActiveSessionsException
/*    */   extends IllegalStateException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final int maxActiveSessions;
/*    */   
/*    */   public TooManyActiveSessionsException(String message, int maxActive) {
/* 39 */     super(message);
/* 40 */     this.maxActiveSessions = maxActive;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMaxActiveSessions() {
/* 49 */     return this.maxActiveSessions;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\TooManyActiveSessionsException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */