/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.concurrent.KeyedReentrantReadWriteLock;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileStore
/*     */   extends StoreBase
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(FileStore.class);
/*  48 */   private static final StringManager sm = StringManager.getManager(FileStore.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String FILE_EXT = ".session";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private String directory = ".";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private File directoryFile = null;
/*     */   
/*  73 */   private KeyedReentrantReadWriteLock sessionLocksById = new KeyedReentrantReadWriteLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String storeName = "fileStore";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String threadName = "FileStore";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDirectory() {
/*  93 */     return this.directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectory(String path) {
/* 103 */     String oldDirectory = this.directory;
/* 104 */     this.directory = path;
/* 105 */     this.directoryFile = null;
/* 106 */     this.support.firePropertyChange("directory", oldDirectory, this.directory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThreadName() {
/* 114 */     return "FileStore";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStoreName() {
/* 120 */     return "fileStore";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() throws IOException {
/* 127 */     File dir = directory();
/* 128 */     if (dir == null) {
/* 129 */       return 0;
/*     */     }
/* 131 */     String[] files = dir.list();
/*     */ 
/*     */     
/* 134 */     int keycount = 0;
/* 135 */     if (files != null) {
/* 136 */       for (String file : files) {
/* 137 */         if (file.endsWith(".session")) {
/* 138 */           keycount++;
/*     */         }
/*     */       } 
/*     */     }
/* 142 */     return keycount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() throws IOException {
/* 150 */     String[] keys = keys();
/* 151 */     for (String key : keys) {
/* 152 */       remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] keys() throws IOException {
/* 160 */     File dir = directory();
/* 161 */     if (dir == null) {
/* 162 */       return new String[0];
/*     */     }
/* 164 */     String[] files = dir.list();
/*     */ 
/*     */     
/* 167 */     if (files == null || files.length < 1) {
/* 168 */       return new String[0];
/*     */     }
/*     */ 
/*     */     
/* 172 */     List<String> list = new ArrayList<>();
/* 173 */     int n = ".session".length();
/* 174 */     for (String file : files) {
/* 175 */       if (file.endsWith(".session")) {
/* 176 */         list.add(file.substring(0, file.length() - n));
/*     */       }
/*     */     } 
/* 179 */     return list.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session load(String id) throws ClassNotFoundException, IOException {
/* 186 */     File file = file(id);
/* 187 */     if (file == null) {
/* 188 */       return null;
/*     */     }
/*     */     
/* 191 */     Context context = getManager().getContext();
/* 192 */     Log contextLog = context.getLogger();
/*     */     
/* 194 */     if (contextLog.isTraceEnabled()) {
/* 195 */       contextLog.trace(sm.getString(getStoreName() + ".loading", new Object[] { id, file.getAbsolutePath() }));
/*     */     }
/*     */     
/* 198 */     ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */     try {
/* 200 */       Lock readLock = this.sessionLocksById.getLock(id).readLock();
/* 201 */       readLock.lock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String id) throws IOException {
/* 229 */     File file = file(id);
/* 230 */     if (file == null) {
/*     */       return;
/*     */     }
/* 233 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 234 */       this.manager.getContext().getLogger()
/* 235 */         .trace(sm.getString(getStoreName() + ".removing", new Object[] { id, file.getAbsolutePath() }));
/*     */     }
/*     */     
/* 238 */     Lock writeLock = this.sessionLocksById.getLock(id).writeLock();
/* 239 */     writeLock.lock();
/*     */     try {
/* 241 */       if (file.exists() && !file.delete()) {
/* 242 */         throw new IOException(sm.getString("fileStore.deleteSessionFailed", new Object[] { file }));
/*     */       }
/*     */     } finally {
/* 245 */       writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Session session) throws IOException {
/* 253 */     File file = file(session.getIdInternal());
/* 254 */     if (file == null) {
/*     */       return;
/*     */     }
/* 257 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 258 */       this.manager.getContext().getLogger()
/* 259 */         .trace(sm.getString(getStoreName() + ".saving", new Object[] { session.getIdInternal(), file.getAbsolutePath() }));
/*     */     }
/*     */     
/* 262 */     Lock writeLock = this.sessionLocksById.getLock(session.getIdInternal()).writeLock();
/* 263 */     writeLock.lock();
/*     */     
/* 265 */     try { FileOutputStream fos = new FileOutputStream(file.getAbsolutePath()); 
/* 266 */       try { ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(fos)); 
/* 267 */         try { ((StandardSession)session).writeObjectData(oos);
/* 268 */           oos.close(); } catch (Throwable throwable) { try { oos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */        }
/* 270 */     finally { writeLock.unlock(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized File directory() throws IOException {
/* 283 */     if (this.directory == null) {
/* 284 */       return null;
/*     */     }
/* 286 */     if (this.directoryFile != null) {
/* 287 */       return this.directoryFile;
/*     */     }
/* 289 */     File file = new File(this.directory);
/* 290 */     if (!file.isAbsolute()) {
/* 291 */       Context context = this.manager.getContext();
/* 292 */       ServletContext servletContext = context.getServletContext();
/* 293 */       File work = (File)servletContext.getAttribute("jakarta.servlet.context.tempdir");
/* 294 */       file = new File(work, this.directory);
/*     */     } 
/* 296 */     if (!file.exists() || !file.isDirectory()) {
/* 297 */       if (!file.delete() && file.exists()) {
/* 298 */         throw new IOException(sm.getString("fileStore.deleteFailed", new Object[] { file }));
/*     */       }
/* 300 */       if (!file.mkdirs() && !file.isDirectory()) {
/* 301 */         throw new IOException(sm.getString("fileStore.createFailed", new Object[] { file }));
/*     */       }
/*     */     } 
/* 304 */     this.directoryFile = file;
/* 305 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File file(String id) throws IOException {
/* 315 */     File storageDir = directory();
/* 316 */     if (storageDir == null) {
/* 317 */       return null;
/*     */     }
/*     */     
/* 320 */     String filename = id + ".session";
/* 321 */     File file = new File(storageDir, filename);
/* 322 */     File canonicalFile = file.getCanonicalFile();
/*     */ 
/*     */     
/* 325 */     if (!canonicalFile.toPath().startsWith(storageDir.getCanonicalFile().toPath())) {
/* 326 */       log.warn(sm.getString("fileStore.invalid", new Object[] { file.getPath(), id }));
/* 327 */       return null;
/*     */     } 
/*     */     
/* 330 */     return canonicalFile;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\FileStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */