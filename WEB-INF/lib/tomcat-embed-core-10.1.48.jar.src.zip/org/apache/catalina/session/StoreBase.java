/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Store;
/*     */ import org.apache.catalina.util.CustomObjectInputStream;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StoreBase
/*     */   extends LifecycleBase
/*     */   implements Store
/*     */ {
/*     */   protected static final String storeName = "StoreBase";
/*  51 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected static final StringManager sm = StringManager.getManager(StoreBase.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Manager manager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStoreName() {
/*  70 */     return "StoreBase";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManager(Manager manager) {
/*  76 */     Manager oldManager = this.manager;
/*  77 */     this.manager = manager;
/*  78 */     this.support.firePropertyChange("manager", oldManager, this.manager);
/*     */   }
/*     */ 
/*     */   
/*     */   public Manager getManager() {
/*  83 */     return this.manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/*  91 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  96 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] expiredKeys() throws IOException {
/* 107 */     return keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processExpires() {
/*     */     String[] keys;
/* 117 */     if (!getState().isAvailable()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 122 */       keys = expiredKeys();
/* 123 */     } catch (IOException ioe) {
/* 124 */       this.manager.getContext().getLogger().error(sm.getString("store.keysFail"), ioe);
/*     */       return;
/*     */     } 
/* 127 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 128 */       this.manager.getContext().getLogger()
/* 129 */         .trace(getStoreName() + ": processExpires check number of " + getStoreName() + " sessions");
/*     */     }
/*     */     
/* 132 */     long timeNow = System.currentTimeMillis();
/*     */     
/* 134 */     for (String key : keys) {
/*     */       try {
/* 136 */         StandardSession session = (StandardSession)load(key);
/* 137 */         if (session != null)
/*     */         
/*     */         { 
/* 140 */           int timeIdle = (int)((timeNow - session.getThisAccessedTime()) / 1000L);
/* 141 */           if (timeIdle >= session.getMaxInactiveInterval())
/*     */           
/*     */           { 
/* 144 */             if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 145 */               this.manager.getContext().getLogger()
/* 146 */                 .trace(getStoreName() + ": processExpires expire store session " + getStoreName());
/*     */             }
/* 148 */             boolean isLoaded = false;
/* 149 */             if (this.manager instanceof PersistentManagerBase) {
/* 150 */               isLoaded = ((PersistentManagerBase)this.manager).isLoaded(key);
/*     */             } else {
/*     */               try {
/* 153 */                 if (this.manager.findSession(key) != null) {
/* 154 */                   isLoaded = true;
/*     */                 }
/* 156 */               } catch (IOException iOException) {}
/*     */             } 
/*     */ 
/*     */             
/* 160 */             if (isLoaded) {
/*     */               
/* 162 */               session.recycle();
/*     */             } else {
/*     */               
/* 165 */               session.expire();
/*     */             } 
/* 167 */             remove(key); }  } 
/* 168 */       } catch (Exception e) {
/* 169 */         this.manager.getContext().getLogger().error(sm.getString("store.expireFail", new Object[] { key }), e);
/*     */         try {
/* 171 */           remove(key);
/* 172 */         } catch (IOException ioe) {
/* 173 */           this.manager.getContext().getLogger().error(sm.getString("store.removeFail", new Object[] { key }), ioe);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectInputStream getObjectInputStream(InputStream is) throws IOException {
/*     */     CustomObjectInputStream ois;
/* 193 */     BufferedInputStream bis = new BufferedInputStream(is);
/*     */ 
/*     */     
/* 196 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 198 */     if (this.manager instanceof ManagerBase) {
/* 199 */       ManagerBase managerBase = (ManagerBase)this.manager;
/*     */ 
/*     */       
/* 202 */       ois = new CustomObjectInputStream(bis, classLoader, this.manager.getContext().getLogger(), managerBase.getSessionAttributeValueClassNamePattern(), managerBase.getWarnOnSessionAttributeFilterFailure());
/*     */     } else {
/* 204 */       ois = new CustomObjectInputStream(bis, classLoader);
/*     */     } 
/*     */     
/* 207 */     return (ObjectInputStream)ois;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 226 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 239 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 251 */     return ToStringUtil.toString(this, this.manager);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\StoreBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */