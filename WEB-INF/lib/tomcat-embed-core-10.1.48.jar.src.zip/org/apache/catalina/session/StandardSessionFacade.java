/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSessionFacade
/*     */   implements HttpSession
/*     */ {
/*     */   private final HttpSession session;
/*     */   
/*     */   public StandardSessionFacade(HttpSession session) {
/*  37 */     this.session = session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCreationTime() {
/*  53 */     return this.session.getCreationTime();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  59 */     return this.session.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastAccessedTime() {
/*  65 */     return this.session.getLastAccessedTime();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletContext getServletContext() {
/*  71 */     return this.session.getServletContext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInactiveInterval(int interval) {
/*  77 */     this.session.setMaxInactiveInterval(interval);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInactiveInterval() {
/*  83 */     return this.session.getMaxInactiveInterval();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/*  89 */     return this.session.getAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/*  95 */     return this.session.getAttributeNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object value) {
/* 101 */     this.session.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 107 */     this.session.removeAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidate() {
/* 113 */     this.session.invalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew() {
/* 119 */     return this.session.isNew();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\StandardSessionFacade.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */