/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceStore
/*     */   extends StoreBase
/*     */ {
/*  55 */   private String name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String storeName = "dataSourceStore";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected String dataSourceName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean localDataSource = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   protected DataSource dataSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected String sessionTable = "tomcat$sessions";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   protected String sessionAppCol = "app";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected String sessionIdCol = "id";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   protected String sessionDataCol = "data";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   protected String sessionValidCol = "valid";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   protected String sessionMaxInactiveCol = "maxinactive";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   protected String sessionLastAccessedCol = "lastaccess";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 121 */     if (this.name == null) {
/* 122 */       Context context = this.manager.getContext();
/* 123 */       String contextName = context.getName();
/* 124 */       if (!contextName.startsWith("/")) {
/* 125 */         contextName = "/" + contextName;
/*     */       }
/* 127 */       String hostName = "";
/* 128 */       String engineName = "";
/*     */       
/* 130 */       if (context.getParent() != null) {
/* 131 */         Container host = context.getParent();
/* 132 */         hostName = host.getName();
/* 133 */         if (host.getParent() != null) {
/* 134 */           engineName = host.getParent().getName();
/*     */         }
/*     */       } 
/* 137 */       this.name = "/" + engineName + "/" + hostName + contextName;
/*     */     } 
/* 139 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStoreName() {
/* 144 */     return "dataSourceStore";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionTable(String sessionTable) {
/* 153 */     String oldSessionTable = this.sessionTable;
/* 154 */     this.sessionTable = sessionTable;
/* 155 */     this.support.firePropertyChange("sessionTable", oldSessionTable, this.sessionTable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionTable() {
/* 162 */     return this.sessionTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAppCol(String sessionAppCol) {
/* 171 */     String oldSessionAppCol = this.sessionAppCol;
/* 172 */     this.sessionAppCol = sessionAppCol;
/* 173 */     this.support.firePropertyChange("sessionAppCol", oldSessionAppCol, this.sessionAppCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionAppCol() {
/* 180 */     return this.sessionAppCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionIdCol(String sessionIdCol) {
/* 189 */     String oldSessionIdCol = this.sessionIdCol;
/* 190 */     this.sessionIdCol = sessionIdCol;
/* 191 */     this.support.firePropertyChange("sessionIdCol", oldSessionIdCol, this.sessionIdCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionIdCol() {
/* 198 */     return this.sessionIdCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionDataCol(String sessionDataCol) {
/* 207 */     String oldSessionDataCol = this.sessionDataCol;
/* 208 */     this.sessionDataCol = sessionDataCol;
/* 209 */     this.support.firePropertyChange("sessionDataCol", oldSessionDataCol, this.sessionDataCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionDataCol() {
/* 216 */     return this.sessionDataCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionValidCol(String sessionValidCol) {
/* 225 */     String oldSessionValidCol = this.sessionValidCol;
/* 226 */     this.sessionValidCol = sessionValidCol;
/* 227 */     this.support.firePropertyChange("sessionValidCol", oldSessionValidCol, this.sessionValidCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionValidCol() {
/* 234 */     return this.sessionValidCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionMaxInactiveCol(String sessionMaxInactiveCol) {
/* 243 */     String oldSessionMaxInactiveCol = this.sessionMaxInactiveCol;
/* 244 */     this.sessionMaxInactiveCol = sessionMaxInactiveCol;
/* 245 */     this.support.firePropertyChange("sessionMaxInactiveCol", oldSessionMaxInactiveCol, this.sessionMaxInactiveCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionMaxInactiveCol() {
/* 252 */     return this.sessionMaxInactiveCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionLastAccessedCol(String sessionLastAccessedCol) {
/* 261 */     String oldSessionLastAccessedCol = this.sessionLastAccessedCol;
/* 262 */     this.sessionLastAccessedCol = sessionLastAccessedCol;
/* 263 */     this.support.firePropertyChange("sessionLastAccessedCol", oldSessionLastAccessedCol, this.sessionLastAccessedCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionLastAccessedCol() {
/* 270 */     return this.sessionLastAccessedCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String dataSourceName) {
/* 279 */     if (dataSourceName == null || dataSourceName.trim().isEmpty()) {
/* 280 */       this.manager.getContext().getLogger().warn(sm.getString(getStoreName() + ".missingDataSourceName"));
/*     */       return;
/*     */     } 
/* 283 */     this.dataSourceName = dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 290 */     return this.dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLocalDataSource() {
/* 297 */     return this.localDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalDataSource(boolean localDataSource) {
/* 306 */     this.localDataSource = localDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] expiredKeys() throws IOException {
/* 314 */     return keys(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] keys() throws IOException {
/* 319 */     return keys(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] keys(boolean expiredOnly) {
/* 331 */     String[] keys = null;
/* 332 */     int numberOfTries = 2;
/* 333 */     while (numberOfTries > 0) {
/*     */       
/* 335 */       Connection _conn = getConnection();
/* 336 */       if (_conn == null) {
/* 337 */         return new String[0];
/*     */       }
/*     */ 
/*     */       
/* 341 */       try { String keysSql = "SELECT " + this.sessionIdCol + " FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */         
/* 343 */         if (expiredOnly) {
/* 344 */           keysSql = keysSql + " AND (" + keysSql + " + " + this.sessionLastAccessedCol + " * 1000 < ?)";
/*     */         }
/* 346 */         PreparedStatement preparedKeysSql = _conn.prepareStatement(keysSql); 
/* 347 */         try { preparedKeysSql.setString(1, getName());
/* 348 */           if (expiredOnly) {
/* 349 */             preparedKeysSql.setLong(2, System.currentTimeMillis());
/*     */           }
/* 351 */           ResultSet rst = preparedKeysSql.executeQuery(); 
/* 352 */           try { List<String> tmpkeys = new ArrayList<>();
/* 353 */             if (rst != null) {
/* 354 */               while (rst.next()) {
/* 355 */                 tmpkeys.add(rst.getString(1));
/*     */               }
/*     */             }
/* 358 */             keys = tmpkeys.<String>toArray(new String[0]);
/*     */             
/* 360 */             numberOfTries = 0;
/* 361 */             if (rst != null) rst.close();  } catch (Throwable throwable) { if (rst != null)
/* 362 */               try { rst.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (preparedKeysSql != null) preparedKeysSql.close();  } catch (Throwable throwable) { if (preparedKeysSql != null)
/* 363 */             try { preparedKeysSql.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 364 */       { this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.SQLException"), e);
/* 365 */         keys = new String[0]; }
/*     */       finally
/*     */       
/* 368 */       { release(_conn); }
/*     */       
/* 370 */       numberOfTries--;
/*     */     } 
/* 372 */     return keys;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() throws IOException {
/* 377 */     int size = 0;
/* 378 */     String sizeSql = "SELECT COUNT(" + this.sessionIdCol + ") FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */     
/* 380 */     int numberOfTries = 2;
/* 381 */     while (numberOfTries > 0) {
/* 382 */       Connection _conn = getConnection();
/*     */       
/* 384 */       if (_conn == null) {
/* 385 */         return size;
/*     */       }
/*     */       
/* 388 */       try { PreparedStatement preparedSizeSql = _conn.prepareStatement(sizeSql); 
/* 389 */         try { preparedSizeSql.setString(1, getName());
/* 390 */           ResultSet rst = preparedSizeSql.executeQuery(); 
/* 391 */           try { if (rst.next()) {
/* 392 */               size = rst.getInt(1);
/*     */             }
/*     */             
/* 395 */             numberOfTries = 0;
/* 396 */             if (rst != null) rst.close();  } catch (Throwable throwable) { if (rst != null)
/* 397 */               try { rst.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (preparedSizeSql != null) preparedSizeSql.close();  } catch (Throwable throwable) { if (preparedSizeSql != null) try { preparedSizeSql.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 398 */       { this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.SQLException"), e); }
/*     */       finally
/* 400 */       { release(_conn); }
/*     */       
/* 402 */       numberOfTries--;
/*     */     } 
/* 404 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public Session load(String id) throws ClassNotFoundException, IOException {
/* 409 */     StandardSession _session = null;
/* 410 */     Context context = getManager().getContext();
/* 411 */     Log contextLog = context.getLogger();
/*     */     
/* 413 */     int numberOfTries = 2;
/* 414 */     String loadSql = "SELECT " + this.sessionIdCol + ", " + this.sessionDataCol + " FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ? AND " + this.sessionAppCol + " = ?";
/*     */     
/* 416 */     while (numberOfTries > 0) {
/* 417 */       Connection _conn = getConnection();
/* 418 */       if (_conn == null) {
/* 419 */         return null;
/*     */       }
/*     */       
/* 422 */       ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       
/* 424 */       try { PreparedStatement preparedLoadSql = _conn.prepareStatement(loadSql); 
/* 425 */         try { preparedLoadSql.setString(1, id);
/* 426 */           preparedLoadSql.setString(2, getName());
/* 427 */           ResultSet rst = preparedLoadSql.executeQuery(); 
/* 428 */           try { if (rst.next())
/* 429 */             { ObjectInputStream ois = getObjectInputStream(rst.getBinaryStream(2)); 
/* 430 */               try { if (contextLog.isTraceEnabled()) {
/* 431 */                   contextLog.trace(sm.getString("dataSourceStore.loading", new Object[] { id, this.sessionTable }));
/*     */                 }
/*     */                 
/* 434 */                 _session = (StandardSession)this.manager.createEmptySession();
/* 435 */                 _session.readObjectData(ois);
/* 436 */                 _session.setManager(this.manager);
/* 437 */                 if (ois != null) ois.close();  } catch (Throwable throwable) { if (ois != null)
/* 438 */                   try { ois.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } else if (context.getLogger().isDebugEnabled())
/* 439 */             { contextLog.debug(sm.getString("dataSourceStore.noObject", new Object[] { id })); }
/*     */ 
/*     */             
/* 442 */             numberOfTries = 0;
/* 443 */             if (rst != null) rst.close();  } catch (Throwable throwable) { if (rst != null)
/* 444 */               try { rst.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (preparedLoadSql != null) preparedLoadSql.close();  } catch (Throwable throwable) { if (preparedLoadSql != null) try { preparedLoadSql.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 445 */       { contextLog.error(sm.getString("dataSourceStore.SQLException"), e); }
/*     */       finally
/* 447 */       { context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/* 448 */         release(_conn); }
/*     */       
/* 450 */       numberOfTries--;
/*     */     } 
/* 452 */     return _session;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String id) throws IOException {
/* 458 */     int numberOfTries = 2;
/* 459 */     while (numberOfTries > 0) {
/* 460 */       Connection _conn = getConnection();
/*     */       
/* 462 */       if (_conn == null) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 467 */         remove(id, _conn);
/*     */         
/* 469 */         numberOfTries = 0;
/* 470 */       } catch (SQLException e) {
/* 471 */         this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.SQLException"), e);
/*     */       } finally {
/* 473 */         release(_conn);
/*     */       } 
/* 475 */       numberOfTries--;
/*     */     } 
/*     */     
/* 478 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 479 */       this.manager.getContext().getLogger().trace(sm.getString("dataSourceStore.removing", new Object[] { id, this.sessionTable }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove(String id, Connection _conn) throws SQLException {
/* 493 */     String removeSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ?  AND " + this.sessionAppCol + " = ?";
/*     */     
/* 495 */     PreparedStatement preparedRemoveSql = _conn.prepareStatement(removeSql); 
/* 496 */     try { preparedRemoveSql.setString(1, id);
/* 497 */       preparedRemoveSql.setString(2, getName());
/* 498 */       preparedRemoveSql.execute();
/* 499 */       if (preparedRemoveSql != null) preparedRemoveSql.close();  }
/*     */     catch (Throwable throwable) { if (preparedRemoveSql != null)
/*     */         try { preparedRemoveSql.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 504 */      } public void clear() throws IOException { String clearSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */     
/* 506 */     int numberOfTries = 2;
/* 507 */     while (numberOfTries > 0) {
/* 508 */       Connection _conn = getConnection();
/* 509 */       if (_conn == null) {
/*     */         return;
/*     */       }
/*     */       
/* 513 */       try { PreparedStatement preparedClearSql = _conn.prepareStatement(clearSql); 
/* 514 */         try { preparedClearSql.setString(1, getName());
/* 515 */           preparedClearSql.execute();
/*     */           
/* 517 */           numberOfTries = 0;
/* 518 */           if (preparedClearSql != null) preparedClearSql.close();  } catch (Throwable throwable) { if (preparedClearSql != null) try { preparedClearSql.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 519 */       { this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.SQLException"), e); }
/*     */       finally
/* 521 */       { release(_conn); }
/*     */       
/* 523 */       numberOfTries--;
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Session session) throws IOException {
/* 529 */     String saveSql = "INSERT INTO " + this.sessionTable + " (" + this.sessionIdCol + ", " + this.sessionAppCol + ", " + this.sessionDataCol + ", " + this.sessionValidCol + ", " + this.sessionMaxInactiveCol + ", " + this.sessionLastAccessedCol + ") VALUES (?, ?, ?, ?, ?, ?)";
/*     */ 
/*     */ 
/*     */     
/* 533 */     synchronized (session) {
/* 534 */       int numberOfTries = 2;
/* 535 */       while (numberOfTries > 0) {
/* 536 */         Connection _conn = getConnection();
/* 537 */         if (_conn == null) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/* 543 */           remove(session.getIdInternal(), _conn);
/*     */           
/* 545 */           ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 546 */           ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(bos)); 
/* 547 */           try { ((StandardSession)session).writeObjectData(oos);
/* 548 */             oos.close(); } catch (Throwable throwable) { try { oos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 549 */            byte[] obs = bos.toByteArray();
/* 550 */           int size = obs.length;
/* 551 */           ByteArrayInputStream bis = new ByteArrayInputStream(obs, 0, size); 
/* 552 */           try { InputStream in = new BufferedInputStream(bis, size); 
/* 553 */             try { PreparedStatement preparedSaveSql = _conn.prepareStatement(saveSql); 
/* 554 */               try { preparedSaveSql.setString(1, session.getIdInternal());
/* 555 */                 preparedSaveSql.setString(2, getName());
/* 556 */                 preparedSaveSql.setBinaryStream(3, in, size);
/* 557 */                 preparedSaveSql.setString(4, session.isValid() ? "1" : "0");
/* 558 */                 preparedSaveSql.setInt(5, session.getMaxInactiveInterval());
/* 559 */                 preparedSaveSql.setLong(6, session.getLastAccessedTime());
/* 560 */                 preparedSaveSql.execute();
/*     */                 
/* 562 */                 numberOfTries = 0;
/* 563 */                 if (preparedSaveSql != null) preparedSaveSql.close();  } catch (Throwable throwable) { if (preparedSaveSql != null) try { preparedSaveSql.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  bis.close(); } catch (Throwable throwable) { try { bis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 564 */         } catch (SQLException e) {
/* 565 */           this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.SQLException"), e);
/* 566 */         } catch (IOException iOException) {
/*     */         
/*     */         } finally {
/* 569 */           release(_conn);
/*     */         } 
/* 571 */         numberOfTries--;
/*     */       } 
/*     */     } 
/*     */     
/* 575 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 576 */       this.manager.getContext().getLogger()
/* 577 */         .trace(sm.getString("dataSourceStore.saving", new Object[] { session.getIdInternal(), this.sessionTable }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnection() {
/* 591 */     Connection conn = null;
/*     */     try {
/* 593 */       conn = open();
/* 594 */       if (conn == null || conn.isClosed()) {
/* 595 */         this.manager.getContext().getLogger().info(sm.getString("dataSourceStore.checkConnectionDBClosed"));
/* 596 */         conn = open();
/* 597 */         if (conn == null || conn.isClosed()) {
/* 598 */           this.manager.getContext().getLogger().info(sm.getString("dataSourceStore.checkConnectionDBReOpenFail"));
/*     */         }
/*     */       } 
/* 601 */     } catch (SQLException ex) {
/* 602 */       this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.checkConnectionSQLException"), ex);
/*     */     } 
/*     */     
/* 605 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection open() throws SQLException {
/* 616 */     if (this.dataSourceName != null && this.dataSource == null) {
/* 617 */       Context context = getManager().getContext();
/* 618 */       if (getLocalDataSource()) {
/* 619 */         ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */         try {
/* 621 */           Context envCtx = (Context)(new InitialContext()).lookup("java:comp/env");
/* 622 */           this.dataSource = (DataSource)envCtx.lookup(this.dataSourceName);
/* 623 */         } catch (NamingException e) {
/* 624 */           context.getLogger().error(sm.getString("dataSourceStore.wrongDataSource", new Object[] { this.dataSourceName }), e);
/*     */         } finally {
/* 626 */           context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*     */         } 
/*     */       } else {
/*     */         
/*     */         try {
/* 631 */           Service service = Container.getService((Container)context);
/* 632 */           if (service != null) {
/* 633 */             Server server = service.getServer();
/* 634 */             if (server != null) {
/* 635 */               Context namingContext = server.getGlobalNamingContext();
/* 636 */               this.dataSource = (DataSource)namingContext.lookup(this.dataSourceName);
/*     */             } 
/*     */           } 
/* 639 */         } catch (NamingException namingException) {}
/*     */ 
/*     */         
/* 642 */         if (this.dataSource == null) {
/*     */           try {
/* 644 */             Context envCtx = (Context)(new InitialContext()).lookup("java:comp/env");
/* 645 */             this.dataSource = (DataSource)envCtx.lookup(this.dataSourceName);
/* 646 */           } catch (NamingException e) {
/* 647 */             context.getLogger().error(sm.getString("dataSourceStore.wrongDataSource", new Object[] { this.dataSourceName }), e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 655 */     if (this.dataSource != null) {
/* 656 */       return this.dataSource.getConnection();
/*     */     }
/* 658 */     throw new IllegalStateException(sm.getString("dataSourceStore.missingDataSource"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void close(Connection dbConnection) {
/* 670 */     if (dbConnection == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 676 */       if (!dbConnection.getAutoCommit()) {
/* 677 */         dbConnection.commit();
/*     */       }
/* 679 */     } catch (SQLException e) {
/* 680 */       this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.commitSQLException"), e);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 685 */       dbConnection.close();
/* 686 */     } catch (SQLException e) {
/* 687 */       this.manager.getContext().getLogger().error(sm.getString("dataSourceStore.close"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void release(Connection conn) {
/* 697 */     if (this.dataSource != null)
/* 698 */       close(conn); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\DataSourceStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */