/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import jakarta.servlet.ServletContext;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import jakarta.servlet.http.HttpSessionActivationListener;
/*      */ import jakarta.servlet.http.HttpSessionAttributeListener;
/*      */ import jakarta.servlet.http.HttpSessionBindingEvent;
/*      */ import jakarta.servlet.http.HttpSessionBindingListener;
/*      */ import jakarta.servlet.http.HttpSessionEvent;
/*      */ import jakarta.servlet.http.HttpSessionIdListener;
/*      */ import jakarta.servlet.http.HttpSessionListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.io.NotSerializableException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.WriteAbortedException;
/*      */ import java.security.AccessController;
/*      */ import java.security.Principal;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.SessionEvent;
/*      */ import org.apache.catalina.SessionListener;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.authenticator.SavedRequest;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardSession
/*      */   implements HttpSession, Session, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   
/*      */   public StandardSession(Manager manager) {
/*  114 */     this.attributes = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     this.authType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  127 */     this.creationTime = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  134 */     this.expiring = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  141 */     this.facade = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  147 */     this.id = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  153 */     this.lastAccessedTime = this.creationTime;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     this.listeners = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  172 */     this.maxInactiveInterval = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  178 */     this.isNew = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  184 */     this.isValid = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  191 */     this.notes = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  198 */     this.principal = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     this.support = new PropertyChangeSupport(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  217 */     this.thisAccessedTime = this.creationTime;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  223 */     this.accessCount = null;
/*      */     this.manager = manager;
/*      */     if (manager != null) {
/*      */       this.activityCheck = manager.getSessionActivityCheck();
/*      */       this.lastAccessAtStart = manager.getSessionLastAccessAtStart();
/*      */     } 
/*      */     if (this.activityCheck)
/*      */       this.accessCount = new AtomicInteger(); 
/*      */   }
/*      */   protected static final String[] EMPTY_ARRAY = new String[0]; protected ConcurrentMap<String, Object> attributes; protected transient String authType; protected long creationTime; protected volatile transient boolean expiring;
/*      */   protected transient StandardSessionFacade facade;
/*      */   protected String id;
/*      */   protected volatile long lastAccessedTime;
/*      */   protected transient ArrayList<SessionListener> listeners;
/*      */   protected transient Manager manager;
/*      */   protected volatile int maxInactiveInterval;
/*      */   protected volatile boolean isNew;
/*      */   protected volatile boolean isValid;
/*      */   
/*      */   public String getAuthType() {
/*  243 */     return this.authType;
/*      */   }
/*      */   protected transient Map<String, Object> notes;
/*      */   protected transient Principal principal;
/*      */   
/*      */   public void setAuthType(String authType) {
/*  249 */     String oldAuthType = this.authType;
/*  250 */     this.authType = authType;
/*  251 */     this.support.firePropertyChange("authType", oldAuthType, this.authType);
/*      */   }
/*      */   protected static final StringManager sm = StringManager.getManager(StandardSession.class); protected final transient PropertyChangeSupport support; protected volatile long thisAccessedTime; protected transient AtomicInteger accessCount;
/*      */   protected transient boolean activityCheck;
/*      */   protected transient boolean lastAccessAtStart;
/*      */   
/*      */   public void setCreationTime(long time) {
/*  258 */     this.creationTime = time;
/*  259 */     this.lastAccessedTime = time;
/*  260 */     this.thisAccessedTime = time;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getId() {
/*  267 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getIdInternal() {
/*  273 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setId(String id) {
/*  279 */     setId(id, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setId(String id, boolean notify) {
/*  286 */     if (this.id != null && this.manager != null) {
/*  287 */       this.manager.remove(this);
/*      */     }
/*      */     
/*  290 */     this.id = id;
/*      */     
/*  292 */     if (this.manager != null) {
/*  293 */       this.manager.add(this);
/*      */     }
/*      */     
/*  296 */     if (notify) {
/*  297 */       tellNew();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tellNew() {
/*  308 */     fireSessionEvent("createSession", null);
/*      */ 
/*      */     
/*  311 */     Context context = this.manager.getContext();
/*  312 */     Object[] listeners = context.getApplicationLifecycleListeners();
/*  313 */     if (listeners != null && listeners.length > 0) {
/*  314 */       HttpSessionEvent event = new HttpSessionEvent(getSession());
/*  315 */       for (Object o : listeners) {
/*  316 */         if (o instanceof HttpSessionListener) {
/*      */ 
/*      */           
/*  319 */           HttpSessionListener listener = (HttpSessionListener)o;
/*      */           try {
/*  321 */             context.fireContainerEvent("beforeSessionCreated", listener);
/*  322 */             listener.sessionCreated(event);
/*  323 */             context.fireContainerEvent("afterSessionCreated", listener);
/*  324 */           } catch (Throwable t) {
/*  325 */             ExceptionUtils.handleThrowable(t);
/*      */             try {
/*  327 */               context.fireContainerEvent("afterSessionCreated", listener);
/*  328 */             } catch (Exception exception) {}
/*      */ 
/*      */             
/*  331 */             this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tellChangedSessionId(String newId, String oldId, boolean notifySessionListeners, boolean notifyContainerListeners) {
/*  342 */     fireSessionEvent("changeSessionId", oldId);
/*      */     
/*  344 */     Context context = this.manager.getContext();
/*      */     
/*  346 */     if (notifyContainerListeners) {
/*  347 */       context.fireContainerEvent("changeSessionId", new String[] { oldId, newId });
/*      */     }
/*      */ 
/*      */     
/*  351 */     if (notifySessionListeners) {
/*  352 */       Object[] listeners = context.getApplicationEventListeners();
/*  353 */       if (listeners != null && listeners.length > 0) {
/*  354 */         HttpSessionEvent event = new HttpSessionEvent(getSession());
/*      */         
/*  356 */         for (Object listener : listeners) {
/*  357 */           if (listener instanceof HttpSessionIdListener) {
/*      */ 
/*      */ 
/*      */             
/*  361 */             HttpSessionIdListener idListener = (HttpSessionIdListener)listener;
/*      */             try {
/*  363 */               idListener.sessionIdChanged(event, oldId);
/*  364 */             } catch (Throwable t) {
/*  365 */               this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getThisAccessedTime() {
/*  376 */     if (!isValidInternal()) {
/*  377 */       throw new IllegalStateException(sm.getString("standardSession.getThisAccessedTime.ise"));
/*      */     }
/*      */     
/*  380 */     return this.thisAccessedTime;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getThisAccessedTimeInternal() {
/*  385 */     return this.thisAccessedTime;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLastAccessedTime() {
/*  391 */     if (!isValidInternal()) {
/*  392 */       throw new IllegalStateException(sm.getString("standardSession.getLastAccessedTime.ise"));
/*      */     }
/*      */     
/*  395 */     return this.lastAccessedTime;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLastAccessedTimeInternal() {
/*  400 */     return this.lastAccessedTime;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getIdleTime() {
/*  406 */     if (!isValidInternal()) {
/*  407 */       throw new IllegalStateException(sm.getString("standardSession.getIdleTime.ise"));
/*      */     }
/*      */     
/*  410 */     return getIdleTimeInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   public long getIdleTimeInternal() {
/*  415 */     long timeIdle, timeNow = System.currentTimeMillis();
/*      */     
/*  417 */     if (this.lastAccessAtStart) {
/*  418 */       timeIdle = timeNow - this.lastAccessedTime;
/*      */     } else {
/*  420 */       timeIdle = timeNow - this.thisAccessedTime;
/*      */     } 
/*  422 */     return timeIdle;
/*      */   }
/*      */ 
/*      */   
/*      */   public Manager getManager() {
/*  427 */     return this.manager;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManager(Manager manager) {
/*  433 */     this.manager = manager;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxInactiveInterval() {
/*  439 */     return this.maxInactiveInterval;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxInactiveInterval(int interval) {
/*  445 */     this.maxInactiveInterval = interval;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNew(boolean isNew) {
/*  451 */     this.isNew = isNew;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal getPrincipal() {
/*  457 */     return this.principal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrincipal(Principal principal) {
/*  464 */     Principal oldPrincipal = this.principal;
/*  465 */     this.principal = principal;
/*  466 */     this.support.firePropertyChange("principal", oldPrincipal, this.principal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpSession getSession() {
/*  473 */     if (this.facade == null) {
/*  474 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*  475 */         this.facade = AccessController.<StandardSessionFacade>doPrivileged(new PrivilegedNewSessionFacade(this));
/*      */       } else {
/*  477 */         this.facade = new StandardSessionFacade(this);
/*      */       } 
/*      */     }
/*  480 */     return this.facade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isValid() {
/*  487 */     if (!this.isValid) {
/*  488 */       return false;
/*      */     }
/*      */     
/*  491 */     if (this.expiring) {
/*  492 */       return true;
/*      */     }
/*      */     
/*  495 */     if (this.activityCheck && this.accessCount.get() > 0) {
/*  496 */       return true;
/*      */     }
/*      */     
/*  499 */     if (this.maxInactiveInterval > 0) {
/*  500 */       int timeIdle = (int)(getIdleTimeInternal() / 1000L);
/*  501 */       if (timeIdle >= this.maxInactiveInterval) {
/*  502 */         expire(true);
/*      */       }
/*      */     } 
/*      */     
/*  506 */     return this.isValid;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValid(boolean isValid) {
/*  512 */     this.isValid = isValid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void access() {
/*  522 */     this.thisAccessedTime = System.currentTimeMillis();
/*      */     
/*  524 */     if (this.activityCheck) {
/*  525 */       this.accessCount.incrementAndGet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endAccess() {
/*  534 */     this.isNew = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  539 */     if (this.lastAccessAtStart) {
/*  540 */       this.lastAccessedTime = this.thisAccessedTime;
/*  541 */       this.thisAccessedTime = System.currentTimeMillis();
/*      */     } else {
/*  543 */       this.thisAccessedTime = System.currentTimeMillis();
/*  544 */       this.lastAccessedTime = this.thisAccessedTime;
/*      */     } 
/*      */     
/*  547 */     if (this.activityCheck) {
/*  548 */       this.accessCount.decrementAndGet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSessionListener(SessionListener listener) {
/*  557 */     this.listeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void expire() {
/*  565 */     expire(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void expire(boolean notify) {
/*  581 */     if (!this.isValid) {
/*      */       return;
/*      */     }
/*      */     
/*  585 */     synchronized (this) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  590 */       if (this.expiring || !this.isValid) {
/*      */         return;
/*      */       }
/*      */       
/*  594 */       if (this.manager == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  599 */       this.expiring = true;
/*      */ 
/*      */ 
/*      */       
/*  603 */       Context context = this.manager.getContext();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  608 */       if (notify) {
/*  609 */         ClassLoader classLoader = null;
/*      */         
/*  611 */         try { classLoader = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*  612 */           Object[] listeners = context.getApplicationLifecycleListeners();
/*  613 */           if (listeners != null && listeners.length > 0) {
/*  614 */             HttpSessionEvent event = new HttpSessionEvent(getSession());
/*  615 */             for (int i = 0; i < listeners.length; i++) {
/*  616 */               int j = listeners.length - 1 - i;
/*  617 */               if (listeners[j] instanceof HttpSessionListener) {
/*      */ 
/*      */                 
/*  620 */                 HttpSessionListener listener = (HttpSessionListener)listeners[j];
/*      */                 try {
/*  622 */                   context.fireContainerEvent("beforeSessionDestroyed", listener);
/*  623 */                   listener.sessionDestroyed(event);
/*  624 */                   context.fireContainerEvent("afterSessionDestroyed", listener);
/*  625 */                 } catch (Throwable t) {
/*  626 */                   ExceptionUtils.handleThrowable(t);
/*      */                   try {
/*  628 */                     context.fireContainerEvent("afterSessionDestroyed", listener);
/*  629 */                   } catch (Exception exception) {}
/*      */ 
/*      */                   
/*  632 */                   this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }  }
/*  637 */         finally { context.unbind(Globals.IS_SECURITY_ENABLED, classLoader); }
/*      */       
/*      */       } 
/*      */       
/*  641 */       if (this.activityCheck) {
/*  642 */         this.accessCount.set(0);
/*      */       }
/*      */ 
/*      */       
/*  646 */       this.manager.remove(this, true);
/*      */ 
/*      */       
/*  649 */       if (notify) {
/*  650 */         fireSessionEvent("destroySession", null);
/*      */       }
/*      */ 
/*      */       
/*  654 */       if (this.principal instanceof TomcatPrincipal) {
/*  655 */         TomcatPrincipal gp = (TomcatPrincipal)this.principal;
/*      */         try {
/*  657 */           gp.logout();
/*  658 */         } catch (Exception e) {
/*  659 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.logoutfail"), e);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  664 */       setValid(false);
/*  665 */       this.expiring = false;
/*      */ 
/*      */       
/*  668 */       String[] keys = keys();
/*  669 */       ClassLoader oldContextClassLoader = null;
/*      */       try {
/*  671 */         oldContextClassLoader = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*  672 */         for (String key : keys) {
/*  673 */           removeAttributeInternal(key, notify);
/*      */         }
/*      */       } finally {
/*  676 */         context.unbind(Globals.IS_SECURITY_ENABLED, oldContextClassLoader);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void passivate() {
/*  689 */     fireSessionEvent("passivateSession", null);
/*      */ 
/*      */     
/*  692 */     HttpSessionEvent event = null;
/*  693 */     String[] keys = keys();
/*  694 */     for (String key : keys) {
/*  695 */       Object attribute = this.attributes.get(key);
/*  696 */       if (attribute instanceof HttpSessionActivationListener) {
/*  697 */         if (event == null) {
/*  698 */           event = new HttpSessionEvent(getSession());
/*      */         }
/*      */         try {
/*  701 */           ((HttpSessionActivationListener)attribute).sessionWillPassivate(event);
/*  702 */         } catch (Throwable t) {
/*  703 */           ExceptionUtils.handleThrowable(t);
/*  704 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void activate() {
/*  718 */     if (this.activityCheck) {
/*  719 */       this.accessCount = new AtomicInteger();
/*      */     }
/*      */ 
/*      */     
/*  723 */     fireSessionEvent("activateSession", null);
/*      */ 
/*      */     
/*  726 */     HttpSessionEvent event = null;
/*  727 */     String[] keys = keys();
/*  728 */     for (String key : keys) {
/*  729 */       Object attribute = this.attributes.get(key);
/*  730 */       if (attribute instanceof HttpSessionActivationListener) {
/*  731 */         if (event == null) {
/*  732 */           event = new HttpSessionEvent(getSession());
/*      */         }
/*      */         try {
/*  735 */           ((HttpSessionActivationListener)attribute).sessionDidActivate(event);
/*  736 */         } catch (Throwable t) {
/*  737 */           ExceptionUtils.handleThrowable(t);
/*  738 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getNote(String name) {
/*  747 */     return this.notes.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<String> getNoteNames() {
/*  753 */     return this.notes.keySet().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recycle() {
/*  761 */     this.attributes.clear();
/*  762 */     setAuthType(null);
/*  763 */     this.creationTime = 0L;
/*  764 */     this.expiring = false;
/*  765 */     this.id = null;
/*  766 */     this.lastAccessedTime = 0L;
/*  767 */     this.maxInactiveInterval = -1;
/*  768 */     this.notes.clear();
/*  769 */     setPrincipal(null);
/*  770 */     this.isNew = false;
/*  771 */     this.isValid = false;
/*  772 */     this.manager = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNote(String name) {
/*  780 */     this.notes.remove(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSessionListener(SessionListener listener) {
/*  788 */     this.listeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNote(String name, Object value) {
/*  796 */     this.notes.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  803 */     return "StandardSession[" + this.id + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readObjectData(ObjectInputStream stream) throws ClassNotFoundException, IOException {
/*  821 */     doReadObject(stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectData(ObjectOutputStream stream) throws IOException {
/*  836 */     doWriteObject(stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getCreationTime() {
/*  846 */     if (!isValidInternal()) {
/*  847 */       throw new IllegalStateException(sm.getString("standardSession.getCreationTime.ise"));
/*      */     }
/*      */     
/*  850 */     return this.creationTime;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getCreationTimeInternal() {
/*  856 */     return this.creationTime;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletContext getServletContext() {
/*  862 */     if (this.manager == null) {
/*  863 */       return null;
/*      */     }
/*  865 */     Context context = this.manager.getContext();
/*  866 */     return context.getServletContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(String name) {
/*  874 */     if (!isValidInternal()) {
/*  875 */       throw new IllegalStateException(sm.getString("standardSession.getAttribute.ise"));
/*      */     }
/*      */     
/*  878 */     if (name == null) {
/*  879 */       return null;
/*      */     }
/*      */     
/*  882 */     return this.attributes.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getAttributeNames() {
/*  889 */     if (!isValidInternal()) {
/*  890 */       throw new IllegalStateException(sm.getString("standardSession.getAttributeNames.ise"));
/*      */     }
/*      */     
/*  893 */     Set<String> names = new HashSet<>(this.attributes.keySet());
/*  894 */     return Collections.enumeration(names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invalidate() {
/*  901 */     if (!isValidInternal()) {
/*  902 */       throw new IllegalStateException(sm.getString("standardSession.invalidate.ise"));
/*      */     }
/*      */ 
/*      */     
/*  906 */     expire();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNew() {
/*  913 */     if (!isValidInternal()) {
/*  914 */       throw new IllegalStateException(sm.getString("standardSession.isNew.ise"));
/*      */     }
/*      */     
/*  917 */     return this.isNew;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String name) {
/*  924 */     removeAttribute(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String name, boolean notify) {
/*  944 */     if (!isValidInternal()) {
/*  945 */       throw new IllegalStateException(sm.getString("standardSession.removeAttribute.ise"));
/*      */     }
/*      */     
/*  948 */     removeAttributeInternal(name, notify);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/*  955 */     setAttribute(name, value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value, boolean notify) {
/*  977 */     if (name == null) {
/*  978 */       throw new IllegalArgumentException(sm.getString("standardSession.setAttribute.namenull"));
/*      */     }
/*      */ 
/*      */     
/*  982 */     if (value == null) {
/*  983 */       removeAttribute(name);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  988 */     if (!isValidInternal()) {
/*  989 */       throw new IllegalStateException(sm.getString("standardSession.setAttribute.ise", new Object[] { getIdInternal() }));
/*      */     }
/*      */     
/*  992 */     Context context = this.manager.getContext();
/*      */     
/*  994 */     if (context.getDistributable() && !isAttributeDistributable(name, value) && !exclude(name, value)) {
/*  995 */       throw new IllegalArgumentException(sm.getString("standardSession.setAttribute.iae", new Object[] { name }));
/*      */     }
/*      */     
/*  998 */     HttpSessionBindingEvent event = null;
/*      */ 
/*      */     
/* 1001 */     if (notify && value instanceof HttpSessionBindingListener) {
/*      */ 
/*      */       
/* 1004 */       Object oldValue = this.attributes.get(name);
/* 1005 */       if (value != oldValue || this.manager.getNotifyBindingListenerOnUnchangedValue()) {
/* 1006 */         event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */         try {
/* 1008 */           ((HttpSessionBindingListener)value).valueBound(event);
/* 1009 */         } catch (Throwable t) {
/* 1010 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.bindingEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1016 */     Object unbound = this.attributes.put(name, value);
/*      */ 
/*      */     
/* 1019 */     if (notify && unbound instanceof HttpSessionBindingListener)
/*      */     {
/*      */       
/* 1022 */       if (unbound != value || this.manager.getNotifyBindingListenerOnUnchangedValue()) {
/*      */         try {
/* 1024 */           ((HttpSessionBindingListener)unbound)
/* 1025 */             .valueUnbound(new HttpSessionBindingEvent(getSession(), name));
/* 1026 */         } catch (Throwable t) {
/* 1027 */           ExceptionUtils.handleThrowable(t);
/* 1028 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.bindingEvent"), t);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/* 1033 */     if (!notify) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1038 */     Object[] listeners = context.getApplicationEventListeners();
/* 1039 */     if (listeners == null) {
/*      */       return;
/*      */     }
/* 1042 */     for (Object o : listeners) {
/* 1043 */       if (o instanceof HttpSessionAttributeListener) {
/*      */ 
/*      */         
/* 1046 */         HttpSessionAttributeListener listener = (HttpSessionAttributeListener)o;
/*      */         try {
/* 1048 */           if (unbound != null) {
/* 1049 */             if (unbound != value || this.manager.getNotifyAttributeListenerOnUnchangedValue()) {
/* 1050 */               context.fireContainerEvent("beforeSessionAttributeReplaced", listener);
/* 1051 */               if (event == null) {
/* 1052 */                 event = new HttpSessionBindingEvent(getSession(), name, unbound);
/*      */               }
/* 1054 */               listener.attributeReplaced(event);
/* 1055 */               context.fireContainerEvent("afterSessionAttributeReplaced", listener);
/*      */             } 
/*      */           } else {
/* 1058 */             context.fireContainerEvent("beforeSessionAttributeAdded", listener);
/* 1059 */             if (event == null) {
/* 1060 */               event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */             }
/* 1062 */             listener.attributeAdded(event);
/* 1063 */             context.fireContainerEvent("afterSessionAttributeAdded", listener);
/*      */           } 
/* 1065 */         } catch (Throwable t) {
/* 1066 */           ExceptionUtils.handleThrowable(t);
/*      */           try {
/* 1068 */             if (unbound != null) {
/* 1069 */               if (unbound != value || this.manager.getNotifyAttributeListenerOnUnchangedValue()) {
/* 1070 */                 context.fireContainerEvent("afterSessionAttributeReplaced", listener);
/*      */               }
/*      */             } else {
/* 1073 */               context.fireContainerEvent("afterSessionAttributeAdded", listener);
/*      */             } 
/* 1075 */           } catch (Exception exception) {}
/*      */ 
/*      */           
/* 1078 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isValidInternal() {
/* 1090 */     return this.isValid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAttributeDistributable(String name, Object value) {
/* 1101 */     return value instanceof Serializable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doReadObject(ObjectInputStream stream) throws ClassNotFoundException, IOException {
/* 1119 */     this.authType = null;
/* 1120 */     this.creationTime = ((Long)stream.readObject()).longValue();
/* 1121 */     this.lastAccessedTime = ((Long)stream.readObject()).longValue();
/* 1122 */     this.maxInactiveInterval = ((Integer)stream.readObject()).intValue();
/* 1123 */     this.isNew = ((Boolean)stream.readObject()).booleanValue();
/* 1124 */     this.isValid = ((Boolean)stream.readObject()).booleanValue();
/* 1125 */     this.thisAccessedTime = ((Long)stream.readObject()).longValue();
/* 1126 */     this.principal = null;
/*      */     
/* 1128 */     this.id = (String)stream.readObject();
/* 1129 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 1130 */       this.manager.getContext().getLogger().trace("readObject() loading session " + this.id);
/*      */     }
/*      */     
/* 1133 */     if (this.notes == null) {
/* 1134 */       this.notes = new ConcurrentHashMap<>();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1143 */     Object nextObject = stream.readObject();
/* 1144 */     if (!(nextObject instanceof Integer)) {
/*      */ 
/*      */       
/* 1147 */       setAuthType((String)nextObject);
/*      */       try {
/* 1149 */         setPrincipal((Principal)stream.readObject());
/* 1150 */       } catch (ClassNotFoundException|java.io.ObjectStreamException e) {
/* 1151 */         String msg = sm.getString("standardSession.principalNotDeserializable", new Object[] { this.id });
/* 1152 */         if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1153 */           this.manager.getContext().getLogger().debug(msg, e);
/*      */         } else {
/* 1155 */           this.manager.getContext().getLogger().warn(msg);
/*      */         } 
/* 1157 */         throw e;
/*      */       } 
/*      */       
/* 1160 */       nextObject = stream.readObject();
/* 1161 */       if (!(nextObject instanceof Integer)) {
/*      */ 
/*      */         
/* 1164 */         if (nextObject != null) {
/* 1165 */           this.notes.put("org.apache.catalina.authenticator.SESSION_ID", nextObject);
/*      */         }
/* 1167 */         nextObject = stream.readObject();
/* 1168 */         if (nextObject != null) {
/* 1169 */           this.notes.put("org.apache.catalina.authenticator.REQUEST", nextObject);
/*      */         }
/*      */ 
/*      */         
/* 1173 */         nextObject = stream.readObject();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1178 */     if (this.attributes == null) {
/* 1179 */       this.attributes = new ConcurrentHashMap<>();
/*      */     }
/* 1181 */     int n = ((Integer)nextObject).intValue();
/* 1182 */     boolean isValidSave = this.isValid;
/* 1183 */     this.isValid = true;
/* 1184 */     for (int i = 0; i < n; i++) {
/* 1185 */       Object value; String name = (String)stream.readObject();
/*      */       
/*      */       try {
/* 1188 */         value = stream.readObject();
/* 1189 */       } catch (WriteAbortedException wae) {
/* 1190 */         if (wae.getCause() instanceof NotSerializableException) {
/* 1191 */           String msg = sm.getString("standardSession.notDeserializable", new Object[] { name, this.id });
/* 1192 */           if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1193 */             this.manager.getContext().getLogger().debug(msg, wae);
/*      */           } else {
/* 1195 */             this.manager.getContext().getLogger().warn(msg);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1200 */           throw wae;
/*      */         } 
/* 1202 */       }  if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 1203 */         this.manager.getContext().getLogger().trace("  loading attribute '" + name + "' with value '" + String.valueOf(value) + "'");
/*      */       }
/*      */ 
/*      */       
/* 1207 */       if (!exclude(name, value))
/*      */       {
/*      */ 
/*      */         
/* 1211 */         if (null != value)
/* 1212 */           this.attributes.put(name, value); 
/*      */       }
/*      */     } 
/* 1215 */     this.isValid = isValidSave;
/*      */     
/* 1217 */     if (this.listeners == null) {
/* 1218 */       this.listeners = new ArrayList<>();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doWriteObject(ObjectOutputStream stream) throws IOException {
/* 1240 */     stream.writeObject(Long.valueOf(this.creationTime));
/* 1241 */     stream.writeObject(Long.valueOf(this.lastAccessedTime));
/* 1242 */     stream.writeObject(Integer.valueOf(this.maxInactiveInterval));
/* 1243 */     stream.writeObject(Boolean.valueOf(this.isNew));
/* 1244 */     stream.writeObject(Boolean.valueOf(this.isValid));
/* 1245 */     stream.writeObject(Long.valueOf(this.thisAccessedTime));
/* 1246 */     stream.writeObject(this.id);
/* 1247 */     if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 1248 */       this.manager.getContext().getLogger().trace("writeObject() storing session " + this.id);
/*      */     }
/*      */ 
/*      */     
/* 1252 */     String sessionAuthType = null;
/* 1253 */     Principal sessionPrincipal = null;
/* 1254 */     String expectedSessionId = null;
/* 1255 */     SavedRequest savedRequest = null;
/* 1256 */     if (getPersistAuthentication()) {
/* 1257 */       sessionAuthType = getAuthType();
/* 1258 */       sessionPrincipal = getPrincipal();
/* 1259 */       if (sessionPrincipal != null && !(sessionPrincipal instanceof Serializable)) {
/* 1260 */         sessionPrincipal = null;
/* 1261 */         this.manager.getContext().getLogger().warn(sm.getString("standardSession.principalNotSerializable", new Object[] { this.id }));
/*      */       } 
/* 1263 */       expectedSessionId = (String)this.notes.get("org.apache.catalina.authenticator.SESSION_ID");
/* 1264 */       savedRequest = (SavedRequest)this.notes.get("org.apache.catalina.authenticator.REQUEST");
/*      */     } 
/*      */ 
/*      */     
/* 1268 */     stream.writeObject(sessionAuthType);
/*      */     try {
/* 1270 */       stream.writeObject(sessionPrincipal);
/* 1271 */     } catch (NotSerializableException e) {
/* 1272 */       this.manager.getContext().getLogger().warn(sm.getString("standardSession.principalNotSerializable", new Object[] { this.id }), e);
/*      */     } 
/* 1274 */     stream.writeObject(expectedSessionId);
/* 1275 */     stream.writeObject(savedRequest);
/*      */ 
/*      */     
/* 1278 */     String[] keys = keys();
/* 1279 */     List<String> saveNames = new ArrayList<>();
/* 1280 */     List<Object> saveValues = new ArrayList();
/* 1281 */     for (String key : keys) {
/* 1282 */       Object value = this.attributes.get(key);
/* 1283 */       if (value != null)
/*      */       {
/* 1285 */         if (isAttributeDistributable(key, value) && !exclude(key, value)) {
/* 1286 */           saveNames.add(key);
/* 1287 */           saveValues.add(value);
/*      */         } else {
/* 1289 */           removeAttributeInternal(key, true);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1294 */     int n = saveNames.size();
/* 1295 */     stream.writeObject(Integer.valueOf(n));
/* 1296 */     for (int i = 0; i < n; i++) {
/* 1297 */       stream.writeObject(saveNames.get(i));
/*      */       try {
/* 1299 */         stream.writeObject(saveValues.get(i));
/* 1300 */         if (this.manager.getContext().getLogger().isTraceEnabled()) {
/* 1301 */           this.manager.getContext().getLogger().trace("  storing attribute '" + (String)saveNames
/* 1302 */               .get(i) + "' with value '" + String.valueOf(saveValues.get(i)) + "'");
/*      */         }
/* 1304 */       } catch (NotSerializableException e) {
/* 1305 */         this.manager.getContext().getLogger()
/* 1306 */           .warn(sm.getString("standardSession.notSerializable", new Object[] { saveNames.get(i), this.id }), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getPersistAuthentication() {
/* 1318 */     if (this.manager instanceof ManagerBase) {
/* 1319 */       return ((ManagerBase)this.manager).getPersistAuthentication();
/*      */     }
/* 1321 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean exclude(String name, Object value) {
/* 1339 */     if (Constants.excludedAttributeNames.contains(name)) {
/* 1340 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1344 */     Manager manager = getManager();
/* 1345 */     if (manager == null)
/*      */     {
/*      */       
/* 1348 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1352 */     return !manager.willAttributeDistribute(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireSessionEvent(String type, Object data) {
/* 1366 */     if (this.listeners.isEmpty()) {
/*      */       return;
/*      */     }
/* 1369 */     SessionEvent event = new SessionEvent(this, type, data);
/* 1370 */     SessionListener[] list = new SessionListener[0];
/* 1371 */     synchronized (this.listeners) {
/* 1372 */       list = this.listeners.<SessionListener>toArray(list);
/*      */     } 
/*      */     
/* 1375 */     for (SessionListener sessionListener : list) {
/* 1376 */       sessionListener.sessionEvent(event);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] keys() {
/* 1388 */     return (String[])this.attributes.keySet().toArray((Object[])EMPTY_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeAttributeInternal(String name, boolean notify) {
/* 1406 */     if (name == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1411 */     Object value = this.attributes.remove(name);
/*      */ 
/*      */     
/* 1414 */     if (!notify || value == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1419 */     HttpSessionBindingEvent event = null;
/* 1420 */     if (value instanceof HttpSessionBindingListener) {
/* 1421 */       event = new HttpSessionBindingEvent(getSession(), name, value);
/* 1422 */       ((HttpSessionBindingListener)value).valueUnbound(event);
/*      */     } 
/*      */ 
/*      */     
/* 1426 */     Context context = this.manager.getContext();
/* 1427 */     Object[] listeners = context.getApplicationEventListeners();
/* 1428 */     if (listeners == null) {
/*      */       return;
/*      */     }
/* 1431 */     for (Object o : listeners) {
/* 1432 */       if (o instanceof HttpSessionAttributeListener) {
/*      */ 
/*      */         
/* 1435 */         HttpSessionAttributeListener listener = (HttpSessionAttributeListener)o;
/*      */         try {
/* 1437 */           context.fireContainerEvent("beforeSessionAttributeRemoved", listener);
/* 1438 */           if (event == null) {
/* 1439 */             event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */           }
/* 1441 */           listener.attributeRemoved(event);
/* 1442 */           context.fireContainerEvent("afterSessionAttributeRemoved", listener);
/* 1443 */         } catch (Throwable t) {
/* 1444 */           ExceptionUtils.handleThrowable(t);
/*      */           try {
/* 1446 */             context.fireContainerEvent("afterSessionAttributeRemoved", listener);
/* 1447 */           } catch (Exception exception) {}
/*      */ 
/*      */           
/* 1450 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class PrivilegedNewSessionFacade
/*      */     implements PrivilegedAction<StandardSessionFacade> {
/*      */     private final HttpSession session;
/*      */     
/*      */     PrivilegedNewSessionFacade(HttpSession session) {
/* 1461 */       this.session = session;
/*      */     }
/*      */ 
/*      */     
/*      */     public StandardSessionFacade run() {
/* 1466 */       return new StandardSessionFacade(this.session);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\StandardSession.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */