/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Deque;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.SessionIdGenerator;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*      */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*      */ import org.apache.catalina.util.ToStringUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ManagerBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Manager
/*      */ {
/*   61 */   private final Log log = LogFactory.getLog(ManagerBase.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Context context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String name = "ManagerBase";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   protected String secureRandomClass = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   91 */   protected String secureRandomAlgorithm = SessionIdGeneratorBase.DEFAULT_SECURE_RANDOM_ALGORITHM;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   protected String secureRandomProvider = null;
/*      */   
/*  101 */   protected SessionIdGenerator sessionIdGenerator = null;
/*  102 */   protected Class<? extends SessionIdGenerator> sessionIdGeneratorClass = null;
/*      */ 
/*      */   
/*      */   protected volatile int sessionMaxAliveTime;
/*      */ 
/*      */   
/*  108 */   private final Object sessionMaxAliveTimeUpdateLock = new Object();
/*      */ 
/*      */   
/*      */   protected static final int TIMING_STATS_CACHE_SIZE = 100;
/*      */ 
/*      */   
/*  114 */   protected final Deque<SessionTiming> sessionCreationTiming = new LinkedList<>();
/*  115 */   protected final Deque<SessionTiming> sessionExpirationTiming = new LinkedList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   protected final AtomicLong expiredSessions = new AtomicLong(0L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   protected Map<String, Session> sessions = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  133 */   protected long sessionCounter = 0L;
/*      */ 
/*      */   
/*  136 */   protected volatile int maxActive = 0;
/*      */   
/*  138 */   private final Object maxActiveUpdateLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   protected int maxActiveSessions = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   protected int rejectedSessions = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  155 */   protected volatile int duplicates = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   protected long processingTime = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private int count = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  173 */   protected int processExpiresFrequency = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   protected static final StringManager sm = StringManager.getManager(ManagerBase.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */ 
/*      */   
/*      */   private Pattern sessionAttributeNamePattern;
/*      */ 
/*      */   
/*      */   private Pattern sessionAttributeValueClassNamePattern;
/*      */ 
/*      */   
/*      */   private boolean warnOnSessionAttributeFilterFailure;
/*      */   
/*      */   private boolean notifyBindingListenerOnUnchangedValue;
/*      */   
/*      */   private boolean notifyAttributeListenerOnUnchangedValue = true;
/*      */   
/*      */   private boolean persistAuthentication = false;
/*      */   
/*  200 */   private boolean sessionActivityCheck = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*  202 */   private boolean sessionLastAccessAtStart = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */ 
/*      */ 
/*      */   
/*      */   public ManagerBase() {
/*  207 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */ 
/*      */ 
/*      */       
/*  211 */       setSessionAttributeValueClassNameFilter("java\\.lang\\.(?:Boolean|Integer|Long|Number|String)|org\\.apache\\.catalina\\.realm\\.GenericPrincipal\\$SerializablePrincipal|\\[Ljava.lang.String;");
/*      */ 
/*      */       
/*  214 */       setWarnOnSessionAttributeFilterFailure(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNotifyAttributeListenerOnUnchangedValue() {
/*  223 */     return this.notifyAttributeListenerOnUnchangedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNotifyAttributeListenerOnUnchangedValue(boolean notifyAttributeListenerOnUnchangedValue) {
/*  229 */     this.notifyAttributeListenerOnUnchangedValue = notifyAttributeListenerOnUnchangedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNotifyBindingListenerOnUnchangedValue() {
/*  235 */     return this.notifyBindingListenerOnUnchangedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNotifyBindingListenerOnUnchangedValue(boolean notifyBindingListenerOnUnchangedValue) {
/*  241 */     this.notifyBindingListenerOnUnchangedValue = notifyBindingListenerOnUnchangedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSessionActivityCheck() {
/*  247 */     return this.sessionActivityCheck;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionActivityCheck(boolean sessionActivityCheck) {
/*  253 */     this.sessionActivityCheck = sessionActivityCheck;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSessionLastAccessAtStart() {
/*  259 */     return this.sessionLastAccessAtStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionLastAccessAtStart(boolean sessionLastAccessAtStart) {
/*  265 */     this.sessionLastAccessAtStart = sessionLastAccessAtStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionAttributeNameFilter() {
/*  278 */     if (this.sessionAttributeNamePattern == null) {
/*  279 */       return null;
/*      */     }
/*  281 */     return this.sessionAttributeNamePattern.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionAttributeNameFilter(String sessionAttributeNameFilter) throws PatternSyntaxException {
/*  297 */     if (sessionAttributeNameFilter == null || sessionAttributeNameFilter.isEmpty()) {
/*  298 */       this.sessionAttributeNamePattern = null;
/*      */     } else {
/*  300 */       this.sessionAttributeNamePattern = Pattern.compile(sessionAttributeNameFilter);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pattern getSessionAttributeNamePattern() {
/*  312 */     return this.sessionAttributeNamePattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionAttributeValueClassNameFilter() {
/*  324 */     if (this.sessionAttributeValueClassNamePattern == null) {
/*  325 */       return null;
/*      */     }
/*  327 */     return this.sessionAttributeValueClassNamePattern.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pattern getSessionAttributeValueClassNamePattern() {
/*  338 */     return this.sessionAttributeValueClassNamePattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionAttributeValueClassNameFilter(String sessionAttributeValueClassNameFilter) throws PatternSyntaxException {
/*  355 */     if (sessionAttributeValueClassNameFilter == null || sessionAttributeValueClassNameFilter.isEmpty()) {
/*  356 */       this.sessionAttributeValueClassNamePattern = null;
/*      */     } else {
/*  358 */       this.sessionAttributeValueClassNamePattern = Pattern.compile(sessionAttributeValueClassNameFilter);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWarnOnSessionAttributeFilterFailure() {
/*  369 */     return this.warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWarnOnSessionAttributeFilterFailure(boolean warnOnSessionAttributeFilterFailure) {
/*  380 */     this.warnOnSessionAttributeFilterFailure = warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Context getContext() {
/*  386 */     return this.context;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContext(Context context) {
/*  392 */     if (this.context == context) {
/*      */       return;
/*      */     }
/*      */     
/*  396 */     if (!getState().equals(LifecycleState.NEW)) {
/*  397 */       throw new IllegalStateException(sm.getString("managerBase.setContextNotNew"));
/*      */     }
/*  399 */     Context oldContext = this.context;
/*  400 */     this.context = context;
/*  401 */     this.support.firePropertyChange("context", oldContext, this.context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/*  409 */     return getClass().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SessionIdGenerator getSessionIdGenerator() {
/*  415 */     if (this.sessionIdGenerator != null)
/*  416 */       return this.sessionIdGenerator; 
/*  417 */     if (this.sessionIdGeneratorClass != null) {
/*      */       try {
/*  419 */         this.sessionIdGenerator = this.sessionIdGeneratorClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  420 */         return this.sessionIdGenerator;
/*  421 */       } catch (ReflectiveOperationException reflectiveOperationException) {}
/*      */     }
/*      */ 
/*      */     
/*  425 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionIdGenerator(SessionIdGenerator sessionIdGenerator) {
/*  431 */     this.sessionIdGenerator = sessionIdGenerator;
/*  432 */     this.sessionIdGeneratorClass = sessionIdGenerator.getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  440 */     return "ManagerBase";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSecureRandomClass() {
/*  447 */     return this.secureRandomClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecureRandomClass(String secureRandomClass) {
/*  458 */     String oldSecureRandomClass = this.secureRandomClass;
/*  459 */     this.secureRandomClass = secureRandomClass;
/*  460 */     this.support.firePropertyChange("secureRandomClass", oldSecureRandomClass, this.secureRandomClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSecureRandomAlgorithm() {
/*  469 */     return this.secureRandomAlgorithm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm) {
/*  479 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSecureRandomProvider() {
/*  487 */     return this.secureRandomProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecureRandomProvider(String secureRandomProvider) {
/*  497 */     this.secureRandomProvider = secureRandomProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRejectedSessions() {
/*  503 */     return this.rejectedSessions;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getExpiredSessions() {
/*  509 */     return this.expiredSessions.get();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpiredSessions(long expiredSessions) {
/*  515 */     this.expiredSessions.set(expiredSessions);
/*      */   }
/*      */   
/*      */   public long getProcessingTime() {
/*  519 */     return this.processingTime;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProcessingTime(long processingTime) {
/*  524 */     this.processingTime = processingTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getProcessExpiresFrequency() {
/*  531 */     return this.processExpiresFrequency;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProcessExpiresFrequency(int processExpiresFrequency) {
/*  541 */     if (processExpiresFrequency <= 0) {
/*      */       return;
/*      */     }
/*      */     
/*  545 */     int oldProcessExpiresFrequency = this.processExpiresFrequency;
/*  546 */     this.processExpiresFrequency = processExpiresFrequency;
/*  547 */     this.support.firePropertyChange("processExpiresFrequency", Integer.valueOf(oldProcessExpiresFrequency), 
/*  548 */         Integer.valueOf(this.processExpiresFrequency));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPersistAuthentication() {
/*  560 */     return this.persistAuthentication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPersistAuthentication(boolean persistAuthentication) {
/*  570 */     this.persistAuthentication = persistAuthentication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundProcess() {
/*  583 */     this.count = (this.count + 1) % this.processExpiresFrequency;
/*  584 */     if (this.count == 0) {
/*  585 */       processExpires();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void processExpires() {
/*  594 */     long timeNow = System.currentTimeMillis();
/*  595 */     Session[] sessions = findSessions();
/*  596 */     int expireHere = 0;
/*      */     
/*  598 */     if (this.log.isTraceEnabled()) {
/*  599 */       this.log.trace("Start expire sessions " + getName() + " at " + timeNow + " sessioncount " + sessions.length);
/*      */     }
/*  601 */     for (Session session : sessions) {
/*  602 */       if (session != null && !session.isValid()) {
/*  603 */         expireHere++;
/*      */       }
/*      */     } 
/*  606 */     long timeEnd = System.currentTimeMillis();
/*  607 */     if (this.log.isTraceEnabled()) {
/*  608 */       this.log.trace("End expire sessions " + getName() + " processingTime " + timeEnd - timeNow + " expired sessions: " + expireHere);
/*      */     }
/*      */     
/*  611 */     this.processingTime += timeEnd - timeNow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initInternal() throws LifecycleException {
/*  618 */     super.initInternal();
/*      */     
/*  620 */     if (this.context == null) {
/*  621 */       throw new LifecycleException(sm.getString("managerBase.contextNull"));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/*      */     StandardSessionIdGenerator standardSessionIdGenerator;
/*  631 */     synchronized (this.sessionCreationTiming) {
/*  632 */       while (this.sessionCreationTiming.size() < 100) {
/*  633 */         this.sessionCreationTiming.add(null);
/*      */       }
/*      */     } 
/*  636 */     synchronized (this.sessionExpirationTiming) {
/*  637 */       while (this.sessionExpirationTiming.size() < 100) {
/*  638 */         this.sessionExpirationTiming.add(null);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  643 */     SessionIdGenerator sessionIdGenerator = getSessionIdGenerator();
/*  644 */     if (sessionIdGenerator == null) {
/*  645 */       standardSessionIdGenerator = new StandardSessionIdGenerator();
/*  646 */       setSessionIdGenerator((SessionIdGenerator)standardSessionIdGenerator);
/*      */     } 
/*      */     
/*  649 */     standardSessionIdGenerator.setJvmRoute(getJvmRoute());
/*  650 */     if (standardSessionIdGenerator instanceof SessionIdGeneratorBase) {
/*  651 */       SessionIdGeneratorBase sig = (SessionIdGeneratorBase)standardSessionIdGenerator;
/*  652 */       sig.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
/*  653 */       sig.setSecureRandomClass(getSecureRandomClass());
/*  654 */       sig.setSecureRandomProvider(getSecureRandomProvider());
/*      */     } 
/*      */     
/*  657 */     if (standardSessionIdGenerator instanceof Lifecycle) {
/*  658 */       ((Lifecycle)standardSessionIdGenerator).start();
/*      */     } else {
/*      */       
/*  661 */       if (this.log.isTraceEnabled()) {
/*  662 */         this.log.trace("Force random number initialization starting");
/*      */       }
/*  664 */       standardSessionIdGenerator.generateSessionId();
/*  665 */       if (this.log.isTraceEnabled()) {
/*  666 */         this.log.trace("Force random number initialization completed");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/*  674 */     if (this.sessionIdGenerator instanceof Lifecycle) {
/*  675 */       ((Lifecycle)this.sessionIdGenerator).stop();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(Session session) {
/*  682 */     this.sessions.put(session.getIdInternal(), session);
/*  683 */     int size = getActiveSessions();
/*  684 */     if (size > this.maxActive) {
/*  685 */       synchronized (this.maxActiveUpdateLock) {
/*  686 */         if (size > this.maxActive) {
/*  687 */           this.maxActive = size;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/*  696 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Session createSession(String sessionId) {
/*  703 */     if (this.maxActiveSessions >= 0 && getActiveSessions() >= this.maxActiveSessions) {
/*  704 */       this.rejectedSessions++;
/*  705 */       throw new TooManyActiveSessionsException(sm.getString("managerBase.createSession.ise"), this.maxActiveSessions);
/*      */     } 
/*      */ 
/*      */     
/*  709 */     Session session = createEmptySession();
/*      */ 
/*      */     
/*  712 */     session.setNew(true);
/*  713 */     session.setValid(true);
/*  714 */     session.setCreationTime(System.currentTimeMillis());
/*  715 */     session.setMaxInactiveInterval(getContext().getSessionTimeout() * 60);
/*  716 */     String id = sessionId;
/*  717 */     if (id == null) {
/*  718 */       id = generateSessionId();
/*      */     }
/*  720 */     session.setId(id);
/*      */     
/*  722 */     SessionTiming timing = new SessionTiming(session.getCreationTime(), 0);
/*  723 */     synchronized (this.sessionCreationTiming) {
/*  724 */       this.sessionCreationTiming.add(timing);
/*  725 */       this.sessionCreationTiming.poll();
/*      */     } 
/*  727 */     return session;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Session createEmptySession() {
/*  733 */     return getNewSession();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Session findSession(String id) throws IOException {
/*  739 */     if (id == null) {
/*  740 */       return null;
/*      */     }
/*  742 */     return this.sessions.get(id);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Session[] findSessions() {
/*  748 */     return (Session[])this.sessions.values().toArray((Object[])new Session[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove(Session session) {
/*  754 */     remove(session, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove(Session session, boolean update) {
/*  762 */     if (update) {
/*  763 */       long timeNow = System.currentTimeMillis();
/*  764 */       int timeAlive = (int)(timeNow - session.getCreationTimeInternal()) / 1000;
/*  765 */       updateSessionMaxAliveTime(timeAlive);
/*  766 */       this.expiredSessions.incrementAndGet();
/*  767 */       SessionTiming timing = new SessionTiming(timeNow, timeAlive);
/*  768 */       synchronized (this.sessionExpirationTiming) {
/*  769 */         this.sessionExpirationTiming.add(timing);
/*  770 */         this.sessionExpirationTiming.poll();
/*      */       } 
/*      */     } 
/*      */     
/*  774 */     if (session.getIdInternal() != null) {
/*  775 */       this.sessions.remove(session.getIdInternal());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  782 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String rotateSessionId(Session session) {
/*  788 */     String newId = generateSessionId();
/*  789 */     changeSessionId(session, newId, true, true);
/*  790 */     return newId;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeSessionId(Session session, String newId) {
/*  796 */     changeSessionId(session, newId, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void changeSessionId(Session session, String newId, boolean notifySessionListeners, boolean notifyContainerListeners) {
/*  802 */     String oldId = session.getIdInternal();
/*  803 */     session.setId(newId, false);
/*  804 */     session.tellChangedSessionId(newId, oldId, notifySessionListeners, notifyContainerListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean willAttributeDistribute(String name, Object value) {
/*  818 */     Pattern sessionAttributeNamePattern = getSessionAttributeNamePattern();
/*  819 */     if (sessionAttributeNamePattern != null && 
/*  820 */       !sessionAttributeNamePattern.matcher(name).matches()) {
/*  821 */       if (getWarnOnSessionAttributeFilterFailure() || this.log.isDebugEnabled()) {
/*      */         
/*  823 */         String msg = sm.getString("managerBase.sessionAttributeNameFilter", new Object[] { name, sessionAttributeNamePattern });
/*  824 */         if (getWarnOnSessionAttributeFilterFailure()) {
/*  825 */           this.log.warn(msg);
/*      */         } else {
/*  827 */           this.log.debug(msg);
/*      */         } 
/*      */       } 
/*  830 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  834 */     Pattern sessionAttributeValueClassNamePattern = getSessionAttributeValueClassNamePattern();
/*  835 */     if (value != null && sessionAttributeValueClassNamePattern != null && 
/*  836 */       !sessionAttributeValueClassNamePattern.matcher(value.getClass().getName()).matches()) {
/*  837 */       if (getWarnOnSessionAttributeFilterFailure() || this.log.isDebugEnabled()) {
/*  838 */         String msg = sm.getString("managerBase.sessionAttributeValueClassNameFilter", new Object[] { name, value
/*  839 */               .getClass().getName(), sessionAttributeValueClassNamePattern });
/*  840 */         if (getWarnOnSessionAttributeFilterFailure()) {
/*  841 */           this.log.warn(msg);
/*      */         } else {
/*  843 */           this.log.debug(msg);
/*      */         } 
/*      */       } 
/*  846 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  850 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StandardSession getNewSession() {
/*  863 */     return new StandardSession(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String generateSessionId() {
/*  873 */     return this.sessionIdGenerator.generateSessionId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Engine getEngine() {
/*  886 */     Engine e = null;
/*  887 */     for (Context context = getContext(); e == null && context != null; container = context.getParent()) {
/*  888 */       Container container; if (context instanceof Engine) {
/*  889 */         e = (Engine)context;
/*      */       }
/*      */     } 
/*  892 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJvmRoute() {
/*  902 */     Engine e = getEngine();
/*  903 */     return (e == null) ? null : e.getJvmRoute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionCounter(long sessionCounter) {
/*  912 */     this.sessionCounter = sessionCounter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSessionCounter() {
/*  918 */     return getActiveSessions() + getExpiredSessions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int getDuplicates() {
/*  931 */     return this.duplicates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setDuplicates(int duplicates) {
/*  944 */     this.duplicates = duplicates;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getActiveSessions() {
/*  950 */     return this.sessions.size();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxActive() {
/*  956 */     return this.maxActive;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxActive(int maxActive) {
/*  962 */     synchronized (this.maxActiveUpdateLock) {
/*  963 */       this.maxActive = maxActive;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxActiveSessions() {
/*  972 */     return this.maxActiveSessions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxActiveSessions(int max) {
/*  983 */     int oldMaxActiveSessions = this.maxActiveSessions;
/*  984 */     this.maxActiveSessions = max;
/*  985 */     this.support.firePropertyChange("maxActiveSessions", Integer.valueOf(oldMaxActiveSessions), 
/*  986 */         Integer.valueOf(this.maxActiveSessions));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionMaxAliveTime() {
/*  993 */     return this.sessionMaxAliveTime;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionMaxAliveTime(int sessionMaxAliveTime) {
/*  999 */     synchronized (this.sessionMaxAliveTimeUpdateLock) {
/* 1000 */       this.sessionMaxAliveTime = sessionMaxAliveTime;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSessionMaxAliveTime(int sessionAliveTime) {
/* 1011 */     if (sessionAliveTime > this.sessionMaxAliveTime) {
/* 1012 */       synchronized (this.sessionMaxAliveTimeUpdateLock) {
/* 1013 */         if (sessionAliveTime > this.sessionMaxAliveTime) {
/* 1014 */           this.sessionMaxAliveTime = sessionAliveTime;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionAverageAliveTime() {
/*      */     List<SessionTiming> copy;
/* 1029 */     synchronized (this.sessionExpirationTiming) {
/* 1030 */       copy = new ArrayList<>(this.sessionExpirationTiming);
/*      */     } 
/*      */ 
/*      */     
/* 1034 */     int counter = 0;
/* 1035 */     int result = 0;
/*      */ 
/*      */     
/* 1038 */     for (SessionTiming timing : copy) {
/* 1039 */       if (timing != null) {
/* 1040 */         int timeAlive = timing.getDuration();
/* 1041 */         counter++;
/*      */         
/* 1043 */         result = result * (counter - 1) / counter + timeAlive / counter;
/*      */       } 
/*      */     } 
/* 1046 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionCreateRate() {
/*      */     List<SessionTiming> copy;
/* 1060 */     synchronized (this.sessionCreationTiming) {
/* 1061 */       copy = new ArrayList<>(this.sessionCreationTiming);
/*      */     } 
/*      */     
/* 1064 */     return calculateRate(copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionExpireRate() {
/*      */     List<SessionTiming> copy;
/* 1080 */     synchronized (this.sessionExpirationTiming) {
/* 1081 */       copy = new ArrayList<>(this.sessionExpirationTiming);
/*      */     } 
/*      */     
/* 1084 */     return calculateRate(copy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int calculateRate(List<SessionTiming> sessionTiming) {
/* 1090 */     long now = System.currentTimeMillis();
/* 1091 */     long oldest = now;
/* 1092 */     int counter = 0;
/* 1093 */     int result = 0;
/*      */ 
/*      */     
/* 1096 */     for (SessionTiming timing : sessionTiming) {
/* 1097 */       if (timing != null) {
/* 1098 */         counter++;
/* 1099 */         if (timing.getTimestamp() < oldest) {
/* 1100 */           oldest = timing.getTimestamp();
/*      */         }
/*      */       } 
/*      */     } 
/* 1104 */     if (counter > 0) {
/* 1105 */       if (oldest < now) {
/* 1106 */         result = 60000 * counter / (int)(now - oldest);
/*      */       } else {
/*      */         
/* 1109 */         result = Integer.MAX_VALUE;
/*      */       } 
/*      */     }
/* 1112 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String listSessionIds() {
/* 1122 */     StringBuilder sb = new StringBuilder();
/* 1123 */     for (String s : this.sessions.keySet()) {
/* 1124 */       sb.append(s).append(' ');
/*      */     }
/* 1126 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSessionAttribute(String sessionId, String key) {
/* 1139 */     Session s = this.sessions.get(sessionId);
/* 1140 */     if (s == null) {
/* 1141 */       if (this.log.isInfoEnabled()) {
/* 1142 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1144 */       return null;
/*      */     } 
/* 1146 */     Object o = s.getSession().getAttribute(key);
/* 1147 */     if (o == null) {
/* 1148 */       return null;
/*      */     }
/* 1150 */     return o.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<String, String> getSession(String sessionId) {
/* 1166 */     Session s = this.sessions.get(sessionId);
/* 1167 */     if (s == null) {
/* 1168 */       if (this.log.isInfoEnabled()) {
/* 1169 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1171 */       return null;
/*      */     } 
/*      */     
/* 1174 */     Enumeration<String> ee = s.getSession().getAttributeNames();
/* 1175 */     if (ee == null || !ee.hasMoreElements()) {
/* 1176 */       return null;
/*      */     }
/*      */     
/* 1179 */     HashMap<String, String> map = new HashMap<>();
/* 1180 */     while (ee.hasMoreElements()) {
/* 1181 */       String attrName = ee.nextElement();
/* 1182 */       map.put(attrName, getSessionAttribute(sessionId, attrName));
/*      */     } 
/*      */     
/* 1185 */     return map;
/*      */   }
/*      */ 
/*      */   
/*      */   public void expireSession(String sessionId) {
/* 1190 */     Session s = this.sessions.get(sessionId);
/* 1191 */     if (s == null) {
/* 1192 */       if (this.log.isInfoEnabled()) {
/* 1193 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/*      */       return;
/*      */     } 
/* 1197 */     s.expire();
/*      */   }
/*      */   
/*      */   public long getThisAccessedTimestamp(String sessionId) {
/* 1201 */     Session s = this.sessions.get(sessionId);
/* 1202 */     if (s == null) {
/* 1203 */       if (this.log.isInfoEnabled()) {
/* 1204 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1206 */       return -1L;
/*      */     } 
/* 1208 */     return s.getThisAccessedTime();
/*      */   }
/*      */   
/*      */   public String getThisAccessedTime(String sessionId) {
/* 1212 */     Session s = this.sessions.get(sessionId);
/* 1213 */     if (s == null) {
/* 1214 */       if (this.log.isInfoEnabled()) {
/* 1215 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1217 */       return "";
/*      */     } 
/* 1219 */     return (new Date(s.getThisAccessedTime())).toString();
/*      */   }
/*      */   
/*      */   public long getLastAccessedTimestamp(String sessionId) {
/* 1223 */     Session s = this.sessions.get(sessionId);
/* 1224 */     if (s == null) {
/* 1225 */       if (this.log.isInfoEnabled()) {
/* 1226 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1228 */       return -1L;
/*      */     } 
/* 1230 */     return s.getLastAccessedTime();
/*      */   }
/*      */   
/*      */   public String getLastAccessedTime(String sessionId) {
/* 1234 */     Session s = this.sessions.get(sessionId);
/* 1235 */     if (s == null) {
/* 1236 */       if (this.log.isInfoEnabled()) {
/* 1237 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1239 */       return "";
/*      */     } 
/* 1241 */     return (new Date(s.getLastAccessedTime())).toString();
/*      */   }
/*      */   
/*      */   public String getCreationTime(String sessionId) {
/* 1245 */     Session s = this.sessions.get(sessionId);
/* 1246 */     if (s == null) {
/* 1247 */       if (this.log.isInfoEnabled()) {
/* 1248 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1250 */       return "";
/*      */     } 
/* 1252 */     return (new Date(s.getCreationTime())).toString();
/*      */   }
/*      */   
/*      */   public long getCreationTimestamp(String sessionId) {
/* 1256 */     Session s = this.sessions.get(sessionId);
/* 1257 */     if (s == null) {
/* 1258 */       if (this.log.isInfoEnabled()) {
/* 1259 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1261 */       return -1L;
/*      */     } 
/* 1263 */     return s.getCreationTime();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1269 */     return ToStringUtil.toString(this, (Container)this.context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getObjectNameKeyProperties() {
/* 1277 */     StringBuilder name = new StringBuilder("type=Manager");
/*      */     
/* 1279 */     name.append(",host=");
/* 1280 */     name.append(this.context.getParent().getName());
/*      */     
/* 1282 */     name.append(",context=");
/* 1283 */     String contextName = this.context.getName();
/* 1284 */     if (!contextName.startsWith("/")) {
/* 1285 */       name.append('/');
/*      */     }
/* 1287 */     name.append(contextName);
/*      */     
/* 1289 */     return name.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDomainInternal() {
/* 1294 */     return this.context.getDomain();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final class SessionTiming
/*      */   {
/*      */     private final long timestamp;
/*      */     
/*      */     private final int duration;
/*      */     
/*      */     public SessionTiming(long timestamp, int duration) {
/* 1305 */       this.timestamp = timestamp;
/* 1306 */       this.duration = duration;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getTimestamp() {
/* 1313 */       return this.timestamp;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getDuration() {
/* 1320 */       return this.duration;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\ManagerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */