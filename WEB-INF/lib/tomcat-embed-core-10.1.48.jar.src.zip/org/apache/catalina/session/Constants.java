/*    */ package org.apache.catalina.session;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.catalina.valves.CrawlerSessionManagerValve;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Constants
/*    */ {
/* 36 */   public static final Set<String> excludedAttributeNames = Set.of("javax.security.auth.subject", CrawlerSessionManagerValve.class.getName());
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\session\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */