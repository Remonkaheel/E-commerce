/*     */ package org.apache.catalina;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WebResource
/*     */ {
/*     */   long getLastModified();
/*     */   
/*     */   String getLastModifiedHttp();
/*     */   
/*     */   boolean exists();
/*     */   
/*     */   boolean isVirtual();
/*     */   
/*     */   boolean isDirectory();
/*     */   
/*     */   boolean isFile();
/*     */   
/*     */   boolean delete();
/*     */   
/*     */   String getName();
/*     */   
/*     */   long getContentLength();
/*     */   
/*     */   String getCanonicalPath();
/*     */   
/*     */   boolean canRead();
/*     */   
/*     */   String getWebappPath();
/*     */   
/*     */   String getETag();
/*     */   
/*     */   default String getStrongETag() {
/* 108 */     return getETag();
/*     */   }
/*     */   
/*     */   void setMimeType(String paramString);
/*     */   
/*     */   String getMimeType();
/*     */   
/*     */   InputStream getInputStream();
/*     */   
/*     */   byte[] getContent();
/*     */   
/*     */   long getCreation();
/*     */   
/*     */   URL getURL();
/*     */   
/*     */   URL getCodeBase();
/*     */   
/*     */   WebResourceRoot getWebResourceRoot();
/*     */   
/*     */   Certificate[] getCertificates();
/*     */   
/*     */   Manifest getManifest();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\WebResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */