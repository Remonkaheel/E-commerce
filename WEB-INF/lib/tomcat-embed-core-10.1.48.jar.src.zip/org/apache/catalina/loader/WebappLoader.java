/*     */ package org.apache.catalina.loader;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.io.FilePermission;
/*     */ import java.io.IOException;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.jakartaee.ClassConverter;
/*     */ import org.apache.tomcat.jakartaee.EESpecProfile;
/*     */ import org.apache.tomcat.jakartaee.EESpecProfiles;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebappLoader
/*     */   extends LifecycleMBeanBase
/*     */   implements Loader
/*     */ {
/*  61 */   private static final Log log = LogFactory.getLog(WebappLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private WebappClassLoaderBase classLoader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private Context context = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean delegate = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private String jakartaConverter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private String loaderClass = ParallelWebappClassLoader.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   protected static final StringManager sm = StringManager.getManager(WebappLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private String classpath = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 119 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Context getContext() {
/* 125 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(Context context) {
/* 132 */     if (this.context == context) {
/*     */       return;
/*     */     }
/*     */     
/* 136 */     if (getState().isAvailable()) {
/* 137 */       throw new IllegalStateException(sm.getString("webappLoader.setContext.ise"));
/*     */     }
/*     */ 
/*     */     
/* 141 */     Context oldContext = this.context;
/* 142 */     this.context = context;
/* 143 */     this.support.firePropertyChange("context", oldContext, this.context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDelegate() {
/* 149 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelegate(boolean delegate) {
/* 155 */     boolean oldDelegate = this.delegate;
/* 156 */     this.delegate = delegate;
/* 157 */     this.support.firePropertyChange("delegate", Boolean.valueOf(oldDelegate), Boolean.valueOf(this.delegate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJakartaConverter() {
/* 166 */     return this.jakartaConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJakartaConverter(String jakartaConverter) {
/* 177 */     String oldJakartaConverter = this.jakartaConverter;
/* 178 */     this.jakartaConverter = jakartaConverter;
/* 179 */     this.support.firePropertyChange("jakartaConverter", oldJakartaConverter, this.jakartaConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLoaderClass() {
/* 187 */     return this.loaderClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoaderClass(String loaderClass) {
/* 197 */     this.loaderClass = loaderClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoaderInstance(WebappClassLoaderBase loaderInstance) {
/* 207 */     this.classLoader = loaderInstance;
/* 208 */     setLoaderClass(loaderInstance.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 216 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void backgroundProcess() {
/* 223 */     Context context = getContext();
/* 224 */     if (context != null && 
/* 225 */       context.getReloadable() && modified()) {
/* 226 */       Thread currentThread = Thread.currentThread();
/* 227 */       ClassLoader originalTccl = currentThread.getContextClassLoader();
/*     */       try {
/* 229 */         currentThread.setContextClassLoader(WebappLoader.class.getClassLoader());
/* 230 */         context.reload();
/*     */       } finally {
/* 232 */         currentThread.setContextClassLoader(originalTccl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLoaderRepositories() {
/* 240 */     if (this.classLoader == null) {
/* 241 */       return new String[0];
/*     */     }
/* 243 */     URL[] urls = this.classLoader.getURLs();
/* 244 */     String[] result = new String[urls.length];
/* 245 */     for (int i = 0; i < urls.length; i++) {
/* 246 */       result[i] = urls[i].toExternalForm();
/*     */     }
/* 248 */     return result;
/*     */   }
/*     */   
/*     */   public String getLoaderRepositoriesString() {
/* 252 */     String[] repositories = getLoaderRepositories();
/* 253 */     StringBuilder sb = new StringBuilder();
/* 254 */     for (String repository : repositories) {
/* 255 */       sb.append(repository).append(':');
/*     */     }
/* 257 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClasspath() {
/* 267 */     return this.classpath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean modified() {
/* 273 */     return (this.classLoader != null && this.classLoader.modified());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 279 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 285 */     return ToStringUtil.toString(this, (Container)this.context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 299 */     if (log.isDebugEnabled()) {
/* 300 */       log.debug(sm.getString("webappLoader.starting"));
/*     */     }
/*     */     
/* 303 */     if (this.context.getResources() == null) {
/* 304 */       log.info(sm.getString("webappLoader.noResources", new Object[] { this.context }));
/* 305 */       setState(LifecycleState.STARTING);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 312 */       this.classLoader = createClassLoader();
/* 313 */       this.classLoader.setResources(this.context.getResources());
/* 314 */       this.classLoader.setDelegate(this.delegate);
/*     */ 
/*     */       
/* 317 */       if (getJakartaConverter() != null) {
/* 318 */         MigrationUtil.addJakartaEETransformer(this.classLoader, getJakartaConverter());
/*     */       }
/*     */ 
/*     */       
/* 322 */       setClassPath();
/*     */       
/* 324 */       setPermissions();
/*     */       
/* 326 */       this.classLoader.start();
/*     */       
/* 328 */       String contextName = this.context.getName();
/* 329 */       if (!contextName.startsWith("/")) {
/* 330 */         contextName = "/" + contextName;
/*     */       }
/*     */ 
/*     */       
/* 334 */       ObjectName cloname = new ObjectName(this.context.getDomain() + ":type=" + this.context.getDomain() + ",host=" + this.classLoader.getClass().getSimpleName() + ",context=" + this.context.getParent().getName());
/* 335 */       Registry.getRegistry(null).registerComponent(this.classLoader, cloname, null);
/*     */     }
/* 337 */     catch (Throwable t) {
/* 338 */       Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 339 */       ExceptionUtils.handleThrowable(throwable);
/* 340 */       throw new LifecycleException(sm.getString("webappLoader.startError"), throwable);
/*     */     } 
/*     */     
/* 343 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 357 */     if (log.isDebugEnabled()) {
/* 358 */       log.debug(sm.getString("webappLoader.stopping"));
/*     */     }
/*     */     
/* 361 */     setState(LifecycleState.STOPPING);
/*     */ 
/*     */     
/* 364 */     ServletContext servletContext = this.context.getServletContext();
/* 365 */     servletContext.removeAttribute("org.apache.catalina.jsp_classpath");
/*     */ 
/*     */     
/* 368 */     if (this.classLoader != null) {
/*     */       try {
/* 370 */         this.classLoader.stop();
/*     */       } finally {
/* 372 */         this.classLoader.destroy();
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 377 */         String contextName = this.context.getName();
/* 378 */         if (!contextName.startsWith("/")) {
/* 379 */           contextName = "/" + contextName;
/*     */         }
/*     */ 
/*     */         
/* 383 */         ObjectName cloname = new ObjectName(this.context.getDomain() + ":type=" + this.context.getDomain() + ",host=" + this.classLoader.getClass().getSimpleName() + ",context=" + this.context.getParent().getName());
/* 384 */         Registry.getRegistry(null).unregisterComponent(cloname);
/* 385 */       } catch (Exception e) {
/* 386 */         log.warn(sm.getString("webappLoader.stopError"), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 391 */     this.classLoader = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebappClassLoaderBase createClassLoader() throws Exception {
/* 402 */     if (this.classLoader != null) {
/* 403 */       return this.classLoader;
/*     */     }
/*     */     
/* 406 */     if (ParallelWebappClassLoader.class.getName().equals(this.loaderClass)) {
/* 407 */       return new ParallelWebappClassLoader(this.context.getParentClassLoader());
/*     */     }
/*     */     
/* 410 */     Class<?> clazz = Class.forName(this.loaderClass);
/*     */     
/* 412 */     ClassLoader parentClassLoader = this.context.getParentClassLoader();
/*     */     
/* 414 */     Class<?>[] argTypes = new Class[] { ClassLoader.class };
/* 415 */     Object[] args = { parentClassLoader };
/* 416 */     Constructor<?> constr = clazz.getConstructor(argTypes);
/*     */     
/* 418 */     return (WebappClassLoaderBase)constr.newInstance(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setPermissions() {
/* 427 */     if (!Globals.IS_SECURITY_ENABLED) {
/*     */       return;
/*     */     }
/* 430 */     if (this.context == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 435 */     ServletContext servletContext = this.context.getServletContext();
/*     */ 
/*     */     
/* 438 */     File workDir = (File)servletContext.getAttribute("jakarta.servlet.context.tempdir");
/* 439 */     if (workDir != null) {
/*     */       try {
/* 441 */         String workDirPath = workDir.getCanonicalPath();
/* 442 */         this.classLoader.addPermission(new FilePermission(workDirPath, "read,write"));
/* 443 */         this.classLoader.addPermission(new FilePermission(workDirPath + workDirPath + "-", "read,write,delete"));
/* 444 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 449 */     for (URL url : this.context.getResources().getBaseUrls()) {
/* 450 */       this.classLoader.addPermission(url);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setClassPath() {
/* 461 */     if (this.context == null) {
/*     */       return;
/*     */     }
/* 464 */     ServletContext servletContext = this.context.getServletContext();
/* 465 */     if (servletContext == null) {
/*     */       return;
/*     */     }
/*     */     
/* 469 */     StringBuilder classpath = new StringBuilder();
/*     */ 
/*     */     
/* 472 */     ClassLoader loader = getClassLoader();
/*     */     
/* 474 */     if (this.delegate && loader != null)
/*     */     {
/* 476 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 479 */     while (loader != null && 
/* 480 */       buildClassPath(classpath, loader))
/*     */     {
/*     */       
/* 483 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 486 */     if (this.delegate) {
/*     */       
/* 488 */       loader = getClassLoader();
/* 489 */       if (loader != null) {
/* 490 */         buildClassPath(classpath, loader);
/*     */       }
/*     */     } 
/*     */     
/* 494 */     this.classpath = classpath.toString();
/*     */ 
/*     */     
/* 497 */     servletContext.setAttribute("org.apache.catalina.jsp_classpath", this.classpath);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean buildClassPath(StringBuilder classpath, ClassLoader loader) {
/* 502 */     if (loader instanceof URLClassLoader)
/* 503 */     { URL[] repositories = ((URLClassLoader)loader).getURLs();
/* 504 */       for (URL url : repositories) {
/* 505 */         String repository = url.toString();
/* 506 */         if (repository.startsWith("file:"))
/*     */         
/*     */         { try {
/* 509 */             File f = new File(url.toURI());
/* 510 */             repository = f.getAbsolutePath();
/* 511 */           } catch (URISyntaxException uRISyntaxException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 517 */           if (repository != null)
/*     */           
/*     */           { 
/* 520 */             if (classpath.length() > 0) {
/* 521 */               classpath.append(File.pathSeparator);
/*     */             }
/* 523 */             classpath.append(repository); }  } 
/*     */       }  }
/* 525 */     else { if (loader == ClassLoader.getSystemClassLoader()) {
/*     */         
/* 527 */         String cp = System.getProperty("java.class.path");
/* 528 */         if (cp != null && !cp.isEmpty()) {
/* 529 */           if (classpath.length() > 0) {
/* 530 */             classpath.append(File.pathSeparator);
/*     */           }
/* 532 */           classpath.append(cp);
/*     */         } 
/* 534 */         return false;
/*     */       } 
/*     */       
/* 537 */       if (!JreCompat.isGraalAvailable()) {
/* 538 */         log.info(sm.getString("webappLoader.unknownClassLoader", new Object[] { loader, loader.getClass() }));
/*     */       }
/* 540 */       return false; }
/*     */     
/* 542 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 547 */     return this.context.getDomain();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 554 */     StringBuilder name = new StringBuilder("type=Loader");
/*     */     
/* 556 */     name.append(",host=");
/* 557 */     name.append(this.context.getParent().getName());
/*     */     
/* 559 */     name.append(",context=");
/*     */     
/* 561 */     String contextName = this.context.getName();
/* 562 */     if (!contextName.startsWith("/")) {
/* 563 */       name.append('/');
/*     */     }
/* 565 */     name.append(contextName);
/*     */     
/* 567 */     return name.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MigrationUtil
/*     */   {
/*     */     public static void addJakartaEETransformer(WebappClassLoaderBase webappClassLoader, String profileName) {
/*     */       EESpecProfiles eESpecProfiles;
/* 578 */       EESpecProfile profile = null;
/*     */       try {
/* 580 */         eESpecProfiles = EESpecProfiles.valueOf(profileName);
/* 581 */       } catch (IllegalArgumentException ignored) {
/*     */         
/* 583 */         WebappLoader.log.warn(WebappLoader.sm.getString("webappLoader.unknownProfile", new Object[] { profileName }));
/*     */       } 
/* 585 */       webappClassLoader.addTransformer((eESpecProfiles != null) ? (ClassFileTransformer)new ClassConverter((EESpecProfile)eESpecProfiles) : (ClassFileTransformer)new ClassConverter());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\loader\WebappLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */