/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcLeakPrevention
/*    */ {
/*    */   public List<String> clearJdbcDriverRegistrations() throws SQLException {
/* 38 */     List<String> driverNames = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     Set<Driver> originalDrivers = new HashSet<>();
/* 47 */     Enumeration<Driver> drivers = DriverManager.getDrivers();
/* 48 */     while (drivers.hasMoreElements()) {
/* 49 */       originalDrivers.add(drivers.nextElement());
/*    */     }
/* 51 */     drivers = DriverManager.getDrivers();
/* 52 */     while (drivers.hasMoreElements()) {
/* 53 */       Driver driver = drivers.nextElement();
/*    */       
/* 55 */       if (driver.getClass().getClassLoader() != getClass().getClassLoader()) {
/*    */         continue;
/*    */       }
/*    */ 
/*    */       
/* 60 */       if (originalDrivers.contains(driver)) {
/* 61 */         driverNames.add(driver.getClass().getCanonicalName());
/*    */       }
/* 63 */       DriverManager.deregisterDriver(driver);
/*    */     } 
/* 65 */     return driverNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\loader\JdbcLeakPrevention.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */