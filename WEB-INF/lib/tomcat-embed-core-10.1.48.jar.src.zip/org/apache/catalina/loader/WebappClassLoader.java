/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ import org.apache.catalina.LifecycleException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebappClassLoader
/*    */   extends WebappClassLoaderBase
/*    */ {
/*    */   public WebappClassLoader() {}
/*    */   
/*    */   public WebappClassLoader(ClassLoader parent) {
/* 29 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebappClassLoader copyWithoutTransformers() {
/* 36 */     WebappClassLoader result = new WebappClassLoader(getParent());
/*    */     
/* 38 */     copyStateWithoutTransformers(result);
/*    */     
/*    */     try {
/* 41 */       result.start();
/* 42 */     } catch (LifecycleException e) {
/* 43 */       throw new IllegalStateException(e);
/*    */     } 
/*    */     
/* 46 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getClassLoadingLock(String className) {
/* 55 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\loader\WebappClassLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */