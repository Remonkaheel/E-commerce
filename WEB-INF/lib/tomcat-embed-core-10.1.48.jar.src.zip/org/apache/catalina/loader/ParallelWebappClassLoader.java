/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ import org.apache.catalina.LifecycleException;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.compat.JreCompat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParallelWebappClassLoader
/*    */   extends WebappClassLoaderBase
/*    */ {
/* 26 */   private static final Log log = LogFactory.getLog(ParallelWebappClassLoader.class);
/*    */   
/*    */   static {
/* 29 */     if (!JreCompat.isGraalAvailable() && 
/* 30 */       !registerAsParallelCapable()) {
/* 31 */       log.warn(sm.getString("webappClassLoaderParallel.registrationFailed"));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ParallelWebappClassLoader() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public ParallelWebappClassLoader(ClassLoader parent) {
/* 42 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ParallelWebappClassLoader copyWithoutTransformers() {
/* 49 */     ParallelWebappClassLoader result = new ParallelWebappClassLoader(getParent());
/*    */     
/* 51 */     copyStateWithoutTransformers(result);
/*    */     
/*    */     try {
/* 54 */       result.start();
/* 55 */     } catch (LifecycleException e) {
/* 56 */       throw new IllegalStateException(e);
/*    */     } 
/*    */     
/* 59 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\loader\ParallelWebappClassLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */