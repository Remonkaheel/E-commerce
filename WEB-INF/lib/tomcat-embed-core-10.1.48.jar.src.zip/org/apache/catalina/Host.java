package org.apache.catalina;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.regex.Pattern;

public interface Host extends Container {
  public static final String ADD_ALIAS_EVENT = "addAlias";
  
  public static final String REMOVE_ALIAS_EVENT = "removeAlias";
  
  String getXmlBase();
  
  void setXmlBase(String paramString);
  
  File getConfigBaseFile();
  
  String getAppBase();
  
  File getAppBaseFile();
  
  void setAppBase(String paramString);
  
  String getLegacyAppBase();
  
  File getLegacyAppBaseFile();
  
  void setLegacyAppBase(String paramString);
  
  boolean getAutoDeploy();
  
  void setAutoDeploy(boolean paramBoolean);
  
  String getConfigClass();
  
  void setConfigClass(String paramString);
  
  boolean getDeployOnStartup();
  
  void setDeployOnStartup(boolean paramBoolean);
  
  String getDeployIgnore();
  
  Pattern getDeployIgnorePattern();
  
  void setDeployIgnore(String paramString);
  
  ExecutorService getStartStopExecutor();
  
  boolean getCreateDirs();
  
  void setCreateDirs(boolean paramBoolean);
  
  boolean getUndeployOldVersions();
  
  void setUndeployOldVersions(boolean paramBoolean);
  
  void addAlias(String paramString);
  
  String[] findAliases();
  
  void removeAlias(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Host.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */