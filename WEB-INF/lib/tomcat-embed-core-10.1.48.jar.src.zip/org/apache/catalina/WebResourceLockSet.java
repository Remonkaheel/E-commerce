/*    */ package org.apache.catalina;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WebResourceLockSet
/*    */ {
/*    */   ResourceLock lockForRead(String paramString);
/*    */   
/*    */   void unlockForRead(ResourceLock paramResourceLock);
/*    */   
/*    */   ResourceLock lockForWrite(String paramString);
/*    */   
/*    */   void unlockForWrite(ResourceLock paramResourceLock);
/*    */   
/*    */   public static class ResourceLock
/*    */   {
/* 65 */     public final AtomicInteger count = new AtomicInteger(0);
/* 66 */     public final ReentrantReadWriteLock reentrantLock = new ReentrantReadWriteLock();
/*    */     public final String key;
/*    */     
/*    */     public ResourceLock(String key) {
/* 70 */       this.key = key;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\WebResourceLockSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */