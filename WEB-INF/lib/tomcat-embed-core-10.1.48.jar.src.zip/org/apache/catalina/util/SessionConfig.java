/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import jakarta.servlet.SessionCookieConfig;
/*     */ import org.apache.catalina.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionConfig
/*     */ {
/*     */   private static final String DEFAULT_SESSION_COOKIE_NAME = "JSESSIONID";
/*     */   private static final String DEFAULT_SESSION_PARAMETER_NAME = "jsessionid";
/*     */   
/*     */   public static String getSessionCookieName(Context context) {
/*  36 */     return getConfiguredSessionCookieName(context, "JSESSIONID");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSessionUriParamName(Context context) {
/*  47 */     return getConfiguredSessionCookieName(context, "jsessionid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getConfiguredSessionCookieName(Context context, String defaultName) {
/*  56 */     if (context != null) {
/*  57 */       String cookieName = context.getSessionCookieName();
/*  58 */       if (cookieName != null && !cookieName.isEmpty()) {
/*  59 */         return cookieName;
/*     */       }
/*     */       
/*  62 */       SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
/*  63 */       cookieName = scc.getName();
/*  64 */       if (cookieName != null && !cookieName.isEmpty()) {
/*  65 */         return cookieName;
/*     */       }
/*     */     } 
/*  68 */     return defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSessionCookiePath(Context context) {
/*  81 */     SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
/*     */     
/*  83 */     String contextPath = context.getSessionCookiePath();
/*  84 */     if (contextPath == null || contextPath.isEmpty()) {
/*  85 */       contextPath = scc.getPath();
/*     */     }
/*  87 */     if (contextPath == null || contextPath.isEmpty()) {
/*  88 */       contextPath = context.getEncodedPath();
/*     */     }
/*  90 */     if (context.getSessionCookiePathUsesTrailingSlash()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (!contextPath.endsWith("/")) {
/*  96 */         contextPath = contextPath + "/";
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 101 */     else if (contextPath.isEmpty()) {
/* 102 */       contextPath = "/";
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return contextPath;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\SessionConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */