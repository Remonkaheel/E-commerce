/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterUtil
/*     */ {
/*     */   public static boolean matchFiltersURL(FilterMap filterMap, String requestPath) {
/*  47 */     if (filterMap.getMatchAllUrlPatterns()) {
/*  48 */       return true;
/*     */     }
/*     */     
/*  51 */     if (requestPath == null) {
/*  52 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  56 */     String[] testPaths = filterMap.getURLPatterns();
/*     */     
/*  58 */     for (String testPath : testPaths) {
/*  59 */       if (matchFiltersURL(testPath, requestPath)) {
/*  60 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchFiltersURL(String testPath, String requestPath) {
/*  78 */     if (testPath == null) {
/*  79 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     if (testPath.equals(requestPath)) {
/*  89 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  93 */     if (testPath.equals("/*")) {
/*  94 */       return true;
/*     */     }
/*  96 */     if (testPath.endsWith("/*")) {
/*  97 */       if (testPath.regionMatches(0, requestPath, 0, testPath.length() - 2)) {
/*  98 */         if (requestPath.length() == testPath.length() - 2) {
/*  99 */           return true;
/*     */         }
/* 101 */         return ('/' == requestPath.charAt(testPath.length() - 2));
/*     */       } 
/*     */       
/* 104 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 108 */     if (testPath.startsWith("*.")) {
/* 109 */       int slash = requestPath.lastIndexOf('/');
/* 110 */       int period = requestPath.lastIndexOf('.');
/* 111 */       if (slash >= 0 && period > slash && period != requestPath.length() - 1 && requestPath
/* 112 */         .length() - period == testPath.length() - 1) {
/* 113 */         return testPath.regionMatches(2, requestPath, period + 1, testPath.length() - 2);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 118 */     if (testPath.isEmpty() && requestPath.equals("/")) {
/* 119 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getRequestPath(ServletRequest request) {
/* 128 */     String result = null;
/* 129 */     Object attribute = request.getAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH");
/* 130 */     if (attribute != null) {
/* 131 */       result = attribute.toString();
/*     */     }
/* 133 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\FilterUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */