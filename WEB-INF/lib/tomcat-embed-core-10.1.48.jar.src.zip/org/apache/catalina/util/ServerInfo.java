/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerInfo
/*     */ {
/*     */   private static final String serverInfo;
/*     */   private static final String serverBuilt;
/*     */   private static final String serverBuiltIso;
/*     */   private static final String serverNumber;
/*     */   
/*     */   static {
/*  57 */     String info = null;
/*  58 */     String built = null;
/*  59 */     String builtIso = null;
/*  60 */     String number = null;
/*     */     
/*  62 */     Properties props = new Properties(); 
/*  63 */     try { InputStream is = ServerInfo.class.getResourceAsStream("/org/apache/catalina/util/ServerInfo.properties"); 
/*  64 */       try { props.load(is);
/*  65 */         info = props.getProperty("server.info");
/*  66 */         built = props.getProperty("server.built");
/*  67 */         builtIso = props.getProperty("server.built.iso");
/*  68 */         number = props.getProperty("server.number");
/*  69 */         if (is != null) is.close();  } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable t)
/*  70 */     { ExceptionUtils.handleThrowable(t); }
/*     */     
/*  72 */     if (info == null || info.equals("Apache Tomcat/@VERSION@")) {
/*  73 */       info = "Apache Tomcat/10.1.x-dev";
/*     */     }
/*  75 */     if (built == null || built.equals("@VERSION_BUILT@")) {
/*  76 */       built = "unknown";
/*     */     }
/*  78 */     if (builtIso == null || builtIso.equals("@VERSION_BUILT_ISO@")) {
/*  79 */       builtIso = "unknown";
/*     */     }
/*  81 */     if (number == null || number.equals("@VERSION_NUMBER@")) {
/*  82 */       number = "10.1.x";
/*     */     }
/*     */     
/*  85 */     serverInfo = info;
/*  86 */     serverBuilt = built;
/*  87 */     serverBuiltIso = builtIso;
/*  88 */     serverNumber = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getServerInfo() {
/*  99 */     return serverInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getServerBuilt() {
/* 106 */     return serverBuilt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getServerBuiltISO() {
/* 113 */     return serverBuiltIso;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getServerNumber() {
/* 120 */     return serverNumber;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 124 */     System.out.println("Server version: " + getServerInfo());
/* 125 */     System.out.println("Server built:   " + getServerBuilt());
/* 126 */     System.out.println("Server number:  " + getServerNumber());
/* 127 */     System.out.println("OS Name:        " + System.getProperty("os.name"));
/* 128 */     System.out.println("OS Version:     " + System.getProperty("os.version"));
/* 129 */     System.out.println("Architecture:   " + System.getProperty("os.arch"));
/* 130 */     System.out.println("JVM Version:    " + System.getProperty("java.runtime.version"));
/* 131 */     System.out.println("JVM Vendor:     " + System.getProperty("java.vm.vendor"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ServerInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */