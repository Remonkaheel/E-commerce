package org.apache.catalina.util;

public class TomcatCSS {
  public static final String TOMCAT_CSS = "body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\TomcatCSS.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */