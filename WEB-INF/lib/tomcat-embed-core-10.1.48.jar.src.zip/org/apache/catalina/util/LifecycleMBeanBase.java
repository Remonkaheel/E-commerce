/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LifecycleMBeanBase
/*     */   extends LifecycleBase
/*     */   implements JmxEnabled
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(LifecycleMBeanBase.class);
/*     */   
/*  34 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */ 
/*     */ 
/*     */   
/*  38 */   private String domain = null;
/*  39 */   private ObjectName oname = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/*  45 */     if (this.oname == null) {
/*  46 */       this.oname = register(this, getObjectNameKeyProperties());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException {
/*  53 */     unregister(this.oname);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDomain(String domain) {
/*  59 */     this.domain = domain;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getDomain() {
/*  65 */     if (this.domain == null) {
/*  66 */       this.domain = getDomainInternal();
/*     */     }
/*     */     
/*  69 */     if (this.domain == null) {
/*  70 */       this.domain = "Catalina";
/*     */     }
/*     */     
/*  73 */     return this.domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getDomainInternal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectName getObjectName() {
/*  87 */     return this.oname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getObjectNameKeyProperties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ObjectName register(Object obj, String objectNameKeyProperties) {
/* 114 */     StringBuilder name = new StringBuilder(getDomain());
/* 115 */     name.append(':');
/* 116 */     name.append(objectNameKeyProperties);
/*     */     
/* 118 */     ObjectName on = null;
/*     */     
/*     */     try {
/* 121 */       on = new ObjectName(name.toString());
/* 122 */       Registry.getRegistry(null).registerComponent(obj, on, null);
/* 123 */     } catch (Exception e) {
/* 124 */       log.warn(sm.getString("lifecycleMBeanBase.registerFail", new Object[] { obj, name }), e);
/*     */     } 
/*     */     
/* 127 */     return on;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unregister(String objectNameKeyProperties) {
/* 141 */     String name = getDomain() + ":" + getDomain();
/* 142 */     Registry.getRegistry(null).unregisterComponent(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unregister(ObjectName on) {
/* 155 */     Registry.getRegistry(null).unregisterComponent(on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void postDeregister() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void postRegister(Boolean registrationDone) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void preDeregister() throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception {
/* 189 */     this.oname = name;
/* 190 */     this.domain = name.getDomain().intern();
/*     */     
/* 192 */     return this.oname;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\LifecycleMBeanBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */