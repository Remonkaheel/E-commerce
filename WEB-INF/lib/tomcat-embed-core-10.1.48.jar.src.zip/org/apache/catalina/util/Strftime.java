/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Strftime
/*     */ {
/*  46 */   protected static final Properties translate = new Properties(); static {
/*  47 */     translate.put("a", "EEE");
/*  48 */     translate.put("A", "EEEE");
/*  49 */     translate.put("b", "MMM");
/*  50 */     translate.put("B", "MMMM");
/*  51 */     translate.put("c", "EEE MMM d HH:mm:ss yyyy");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     translate.put("d", "dd");
/*  57 */     translate.put("D", "MM/dd/yy");
/*  58 */     translate.put("e", "dd");
/*  59 */     translate.put("F", "yyyy-MM-dd");
/*  60 */     translate.put("g", "yy");
/*  61 */     translate.put("G", "yyyy");
/*  62 */     translate.put("H", "HH");
/*  63 */     translate.put("h", "MMM");
/*  64 */     translate.put("I", "hh");
/*  65 */     translate.put("j", "DDD");
/*  66 */     translate.put("k", "HH");
/*  67 */     translate.put("l", "hh");
/*  68 */     translate.put("m", "MM");
/*  69 */     translate.put("M", "mm");
/*  70 */     translate.put("n", "\n");
/*  71 */     translate.put("p", "a");
/*  72 */     translate.put("P", "a");
/*  73 */     translate.put("r", "hh:mm:ss a");
/*  74 */     translate.put("R", "HH:mm");
/*     */ 
/*     */     
/*  77 */     translate.put("S", "ss");
/*  78 */     translate.put("t", "\t");
/*  79 */     translate.put("T", "HH:mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     translate.put("V", "ww");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     translate.put("X", "HH:mm:ss");
/*  94 */     translate.put("x", "MM/dd/yy");
/*  95 */     translate.put("y", "yy");
/*  96 */     translate.put("Y", "yyyy");
/*  97 */     translate.put("Z", "z");
/*  98 */     translate.put("z", "Z");
/*  99 */     translate.put("%", "%");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SimpleDateFormat simpleDateFormat;
/*     */ 
/*     */ 
/*     */   
/*     */   public Strftime(String origFormat, Locale locale) {
/* 110 */     String convertedFormat = convertDateFormat(origFormat);
/* 111 */     this.simpleDateFormat = new SimpleDateFormat(convertedFormat, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String format(Date date) {
/* 122 */     return this.simpleDateFormat.format(date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 131 */     return this.simpleDateFormat.getTimeZone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 142 */     this.simpleDateFormat.setTimeZone(timeZone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String convertDateFormat(String pattern) {
/* 154 */     boolean inside = false;
/* 155 */     boolean mark = false;
/* 156 */     boolean modifiedCommand = false;
/*     */     
/* 158 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 160 */     for (int i = 0; i < pattern.length(); i++) {
/* 161 */       char c = pattern.charAt(i);
/*     */       
/* 163 */       if (c == '%' && !mark) {
/* 164 */         mark = true;
/*     */       }
/* 166 */       else if (mark) {
/* 167 */         if (modifiedCommand) {
/*     */           
/* 169 */           modifiedCommand = false;
/* 170 */           mark = false;
/*     */         } else {
/* 172 */           inside = translateCommand(buf, pattern, i, inside);
/*     */           
/* 174 */           if (c == 'O' || c == 'E') {
/* 175 */             modifiedCommand = true;
/*     */           } else {
/* 177 */             mark = false;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 181 */         if (!inside && c != ' ') {
/*     */           
/* 183 */           buf.append('\'');
/* 184 */           inside = true;
/*     */         } 
/*     */         
/* 187 */         buf.append(c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 192 */     if (buf.length() > 0) {
/* 193 */       char lastChar = buf.charAt(buf.length() - 1);
/*     */       
/* 195 */       if (lastChar != '\'' && inside) {
/* 196 */         buf.append('\'');
/*     */       }
/*     */     } 
/* 199 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected String quote(String str, boolean insideQuotes) {
/* 203 */     String retVal = str;
/* 204 */     if (!insideQuotes) {
/* 205 */       retVal = "'" + retVal + "'";
/*     */     }
/* 207 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean translateCommand(StringBuilder buf, String pattern, int index, boolean oldInside) {
/* 221 */     char firstChar = pattern.charAt(index);
/* 222 */     boolean newInside = oldInside;
/*     */ 
/*     */ 
/*     */     
/* 226 */     if (firstChar == 'O' || firstChar == 'E') {
/* 227 */       if (index + 1 < pattern.length()) {
/* 228 */         newInside = translateCommand(buf, pattern, index + 1, oldInside);
/*     */       } else {
/* 230 */         buf.append(quote("%" + firstChar, oldInside));
/*     */       } 
/*     */     } else {
/* 233 */       String command = translate.getProperty(String.valueOf(firstChar));
/*     */ 
/*     */       
/* 236 */       if (command == null) {
/* 237 */         buf.append(quote("%" + firstChar, oldInside));
/*     */       } else {
/*     */         
/* 240 */         if (oldInside) {
/* 241 */           buf.append('\'');
/*     */         }
/* 243 */         buf.append(command);
/* 244 */         newInside = false;
/*     */       } 
/*     */     } 
/* 247 */     return newInside;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\Strftime.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */