/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeBucketCounter
/*     */   extends TimeBucketCounterBase
/*     */ {
/*     */   private final int numBits;
/*     */   private final double ratio;
/*     */   
/*     */   public TimeBucketCounter(int bucketDuration, ScheduledExecutorService executorService) {
/*  34 */     super(getActualDuration(bucketDuration), executorService);
/*  35 */     this.numBits = determineShiftBitsOfDuration(bucketDuration);
/*  36 */     this.ratio = ratioToPowerOf2(bucketDuration * 1000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBucketIndex(long timestamp) {
/*  48 */     return timestamp >> this.numBits;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumBits() {
/*  53 */     return this.numBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActualDuration() {
/*  64 */     return (int)Math.pow(2.0D, getNumBits());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int determineShiftBitsOfDuration(int duration) {
/*  77 */     int bits = 0;
/*  78 */     int pof2 = nextPowerOf2(duration * 1000);
/*  79 */     int bitCheck = pof2;
/*  80 */     while (bitCheck > 1) {
/*  81 */       bitCheck = pof2 >> ++bits;
/*     */     }
/*  83 */     return bits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getActualDuration(int duration) {
/*  98 */     return (int)(1L << determineShiftBitsOfDuration(duration)) / 1000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRatio() {
/* 111 */     return this.ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double ratioToPowerOf2(int value) {
/* 123 */     double nextPO2 = nextPowerOf2(value);
/* 124 */     return Math.round(1000.0D * nextPO2 / value) / 1000.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int nextPowerOf2(int value) {
/* 132 */     int valueOfHighestBit = Integer.highestOneBit(value);
/* 133 */     if (valueOfHighestBit == value) {
/* 134 */       return value;
/*     */     }
/*     */     
/* 137 */     return valueOfHighestBit << 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMillisUntilNextBucket() {
/* 143 */     long millis = System.currentTimeMillis();
/* 144 */     long nextTimeBucketMillis = millis + (long)Math.pow(2.0D, this.numBits) >> this.numBits << this.numBits;
/* 145 */     return nextTimeBucketMillis - millis;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\TimeBucketCounter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */