/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.util.Objects;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Introspection
/*     */ {
/*  38 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertyName(Method setter) {
/*  50 */     return Introspector.decapitalize(setter.getName().substring(3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidSetter(Method method) {
/*  62 */     return (method.getName().startsWith("set") && method.getName().length() > 3 && (method
/*  63 */       .getParameterTypes()).length == 1 && method.getReturnType().getName().equals("void"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidLifecycleCallback(Method method) {
/*  74 */     return ((method.getParameterTypes()).length == 0 && !Modifier.isStatic(method.getModifiers()) && (method
/*  75 */       .getExceptionTypes()).length == 0 && method.getReturnType().getName().equals("void"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Field[] getDeclaredFields(Class<?> clazz) {
/*  86 */     Field[] fields = null;
/*  87 */     if (Globals.IS_SECURITY_ENABLED) {
/*  88 */       Objects.requireNonNull(clazz); fields = AccessController.<Field[]>doPrivileged(clazz::getDeclaredFields);
/*     */     } else {
/*  90 */       fields = clazz.getDeclaredFields();
/*     */     } 
/*  92 */     return fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method[] getDeclaredMethods(Class<?> clazz) {
/* 104 */     Method[] methods = null;
/* 105 */     if (Globals.IS_SECURITY_ENABLED) {
/* 106 */       Objects.requireNonNull(clazz); methods = AccessController.<Method[]>doPrivileged(clazz::getDeclaredMethods);
/*     */     } else {
/* 108 */       methods = clazz.getDeclaredMethods();
/*     */     } 
/* 110 */     return methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(Context context, String className) {
/* 124 */     ClassLoader cl = context.getLoader().getClassLoader();
/* 125 */     Log log = context.getLogger();
/* 126 */     Class<?> clazz = null;
/*     */     try {
/* 128 */       clazz = cl.loadClass(className);
/* 129 */     } catch (ClassNotFoundException|NoClassDefFoundError|ClassFormatError e) {
/* 130 */       log.debug(sm.getString("introspection.classLoadFailed", new Object[] { className }), e);
/* 131 */     } catch (Throwable t) {
/* 132 */       ExceptionUtils.handleThrowable(t);
/* 133 */       log.debug(sm.getString("introspection.classLoadFailed", new Object[] { className }), t);
/*     */     } 
/* 135 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> convertPrimitiveType(Class<?> clazz) {
/* 146 */     if (clazz.equals(char.class))
/* 147 */       return Character.class; 
/* 148 */     if (clazz.equals(int.class))
/* 149 */       return Integer.class; 
/* 150 */     if (clazz.equals(boolean.class))
/* 151 */       return Boolean.class; 
/* 152 */     if (clazz.equals(double.class))
/* 153 */       return Double.class; 
/* 154 */     if (clazz.equals(byte.class))
/* 155 */       return Byte.class; 
/* 156 */     if (clazz.equals(short.class))
/* 157 */       return Short.class; 
/* 158 */     if (clazz.equals(long.class))
/* 159 */       return Long.class; 
/* 160 */     if (clazz.equals(float.class)) {
/* 161 */       return Float.class;
/*     */     }
/* 163 */     return clazz;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\Introspection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */