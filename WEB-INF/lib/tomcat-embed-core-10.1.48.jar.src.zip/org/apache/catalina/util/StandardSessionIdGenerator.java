/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardSessionIdGenerator
/*    */   extends SessionIdGeneratorBase
/*    */ {
/*    */   public String generateSessionId(String route) {
/* 24 */     byte[] random = new byte[16];
/* 25 */     int sessionIdLength = getSessionIdLength();
/*    */ 
/*    */ 
/*    */     
/* 29 */     StringBuilder buffer = new StringBuilder(2 * sessionIdLength + 20);
/*    */     
/* 31 */     int resultLenBytes = 0;
/*    */     
/* 33 */     while (resultLenBytes < sessionIdLength) {
/* 34 */       getRandomBytes(random);
/* 35 */       for (int j = 0; j < random.length && resultLenBytes < sessionIdLength; j++) {
/* 36 */         byte b1 = (byte)((random[j] & 0xF0) >> 4);
/* 37 */         byte b2 = (byte)(random[j] & 0xF);
/* 38 */         if (b1 < 10) {
/* 39 */           buffer.append((char)(48 + b1));
/*    */         } else {
/* 41 */           buffer.append((char)(65 + b1 - 10));
/*    */         } 
/* 43 */         if (b2 < 10) {
/* 44 */           buffer.append((char)(48 + b2));
/*    */         } else {
/* 46 */           buffer.append((char)(65 + b2 - 10));
/*    */         } 
/* 48 */         resultLenBytes++;
/*    */       } 
/*    */     } 
/*    */     
/* 52 */     if (route != null && !route.isEmpty()) {
/* 53 */       buffer.append('.').append(route);
/*    */     } else {
/* 55 */       String jvmRoute = getJvmRoute();
/* 56 */       if (jvmRoute != null && !jvmRoute.isEmpty()) {
/* 57 */         buffer.append('.').append(jvmRoute);
/*    */       }
/*    */     } 
/*    */     
/* 61 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\StandardSessionIdGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */