/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import org.apache.catalina.Contained;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.catalina.Manager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToStringUtil
/*    */ {
/*    */   public static String toString(Contained contained) {
/* 34 */     return toString(contained, contained.getContainer());
/*    */   }
/*    */ 
/*    */   
/*    */   public static String toString(Object obj, Container container) {
/* 39 */     return containedToString(obj, container, "Container");
/*    */   }
/*    */ 
/*    */   
/*    */   public static String toString(Object obj, Manager manager) {
/* 44 */     return containedToString(obj, manager, "Manager");
/*    */   }
/*    */ 
/*    */   
/*    */   private static String containedToString(Object contained, Object container, String containerTypeName) {
/* 49 */     StringBuilder sb = new StringBuilder(contained.getClass().getSimpleName());
/* 50 */     sb.append('[');
/* 51 */     if (container == null) {
/* 52 */       sb.append(containerTypeName);
/* 53 */       sb.append(" is null");
/*    */     } else {
/* 55 */       sb.append(container.toString());
/*    */     } 
/* 57 */     sb.append(']');
/* 58 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ToStringUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */