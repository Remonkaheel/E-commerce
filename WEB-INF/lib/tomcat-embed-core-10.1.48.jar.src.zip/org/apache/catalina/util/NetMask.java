/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Arrays;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NetMask
/*     */ {
/*  46 */   private static final StringManager sm = StringManager.getManager(NetMask.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] netaddr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int nrBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int lastByteShift;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean foundPort;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Pattern portPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetMask(String input) {
/*     */     String nonPortPart;
/*     */     int cidr;
/*  89 */     this.expression = input;
/*     */     
/*  91 */     int portIdx = input.indexOf(';');
/*     */ 
/*     */     
/*  94 */     if (portIdx == -1) {
/*  95 */       this.foundPort = false;
/*  96 */       nonPortPart = input;
/*  97 */       this.portPattern = null;
/*     */     } else {
/*  99 */       this.foundPort = true;
/* 100 */       nonPortPart = input.substring(0, portIdx);
/*     */       try {
/* 102 */         this.portPattern = Pattern.compile(input.substring(portIdx + 1));
/* 103 */       } catch (PatternSyntaxException e) {
/*     */ 
/*     */ 
/*     */         
/* 107 */         throw new IllegalArgumentException(sm.getString("netmask.invalidPort", new Object[] { input }), e);
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     int idx = nonPortPart.indexOf('/');
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (idx == -1) {
/*     */       try {
/* 118 */         this.netaddr = InetAddress.getByName(nonPortPart).getAddress();
/* 119 */       } catch (UnknownHostException e) {
/* 120 */         throw new IllegalArgumentException(sm.getString("netmask.invalidAddress", new Object[] { nonPortPart }));
/*     */       } 
/* 122 */       this.nrBytes = this.netaddr.length;
/* 123 */       this.lastByteShift = 0;
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 131 */     String addressPart = nonPortPart.substring(0, idx), cidrPart = nonPortPart.substring(idx + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 137 */       this.netaddr = InetAddress.getByName(addressPart).getAddress();
/* 138 */     } catch (UnknownHostException e) {
/* 139 */       throw new IllegalArgumentException(sm.getString("netmask.invalidAddress", new Object[] { addressPart }));
/*     */     } 
/*     */     
/* 142 */     int addrlen = this.netaddr.length * 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 149 */       cidr = Integer.parseInt(cidrPart);
/* 150 */     } catch (NumberFormatException e) {
/* 151 */       throw new IllegalArgumentException(sm.getString("netmask.cidrNotNumeric", new Object[] { cidrPart }));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (cidr < 0) {
/* 159 */       throw new IllegalArgumentException(sm.getString("netmask.cidrNegative", new Object[] { cidrPart }));
/*     */     }
/* 161 */     if (cidr > addrlen) {
/* 162 */       throw new IllegalArgumentException(sm.getString("netmask.cidrTooBig", new Object[] { cidrPart, Integer.valueOf(addrlen) }));
/*     */     }
/*     */     
/* 165 */     this.nrBytes = cidr / 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     int remainder = cidr % 8;
/*     */     
/* 178 */     this.lastByteShift = (remainder == 0) ? 0 : (8 - remainder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(InetAddress addr, int port) {
/* 191 */     if (!this.foundPort) {
/* 192 */       return false;
/*     */     }
/* 194 */     String portString = Integer.toString(port);
/* 195 */     if (!this.portPattern.matcher(portString).matches()) {
/* 196 */       return false;
/*     */     }
/* 198 */     return matches(addr, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(InetAddress addr) {
/* 210 */     return matches(addr, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(InetAddress addr, boolean checkedPort) {
/* 223 */     if (!checkedPort && this.foundPort) {
/* 224 */       return false;
/*     */     }
/* 226 */     byte[] candidate = addr.getAddress();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (candidate.length != this.netaddr.length) {
/* 242 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     int i = 0;
/* 254 */     for (; i < this.nrBytes; i++) {
/* 255 */       if (this.netaddr[i] != candidate[i]) {
/* 256 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (this.lastByteShift == 0) {
/* 264 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     int lastByte = this.netaddr[i] ^ candidate[i];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 281 */     return (lastByte >> this.lastByteShift == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 287 */     return this.expression;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 292 */     if (this == o) {
/* 293 */       return true;
/*     */     }
/* 295 */     if (o == null || getClass() != o.getClass()) {
/* 296 */       return false;
/*     */     }
/* 298 */     NetMask other = (NetMask)o;
/* 299 */     return (this.nrBytes == other.nrBytes && this.lastByteShift == other.lastByteShift && 
/* 300 */       Arrays.equals(this.netaddr, other.netaddr));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 305 */     return 31 * Arrays.hashCode(this.netaddr) + this.lastByteShift;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\NetMask.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */