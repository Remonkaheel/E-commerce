/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastRateLimiter
/*    */   extends RateLimiterBase
/*    */ {
/*    */   protected String getDefaultPolicyName() {
/* 28 */     return "fast";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected TimeBucketCounterBase newCounterInstance(int duration, ScheduledExecutorService executorService) {
/* 34 */     return new TimeBucketCounter(duration, executorService);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TimeBucketCounter getBucketCounter() {
/* 40 */     return (TimeBucketCounter)this.bucketCounter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\FastRateLimiter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */