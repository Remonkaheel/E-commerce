/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetMaskSet
/*     */ {
/*  37 */   private final Set<NetMask> netmasks = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(InetAddress inetAddress) {
/*  48 */     for (NetMask nm : this.netmasks) {
/*  49 */       if (nm.matches(inetAddress)) {
/*  50 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(String ipAddress) throws UnknownHostException {
/*  68 */     InetAddress inetAddress = InetAddress.getByName(ipAddress);
/*  69 */     return contains(inetAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(NetMask netmask) {
/*  80 */     return this.netmasks.add(netmask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(String input) {
/*  93 */     NetMask netmask = new NetMask(input);
/*  94 */     return this.netmasks.add(netmask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 101 */     this.netmasks.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 110 */     return this.netmasks.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> addAll(String input) {
/* 123 */     if (input == null || input.isEmpty()) {
/* 124 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 127 */     List<String> errMessages = new ArrayList<>();
/*     */     
/* 129 */     for (String s : StringUtils.splitCommaSeparated(input)) {
/*     */       try {
/* 131 */         add(s);
/* 132 */       } catch (IllegalArgumentException e) {
/* 133 */         errMessages.add(s + ": " + s);
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     return Collections.unmodifiableList(errMessages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     String result = this.netmasks.toString();
/*     */ 
/*     */     
/* 151 */     if (result.startsWith("[")) {
/* 152 */       result = result.substring(1);
/*     */     }
/*     */     
/* 155 */     if (result.endsWith("]")) {
/* 156 */       result = result.substring(0, result.length() - 1);
/*     */     }
/*     */     
/* 159 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\NetMaskSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */