/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParameterMap<K, V>
/*     */   implements Map<K, V>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   private final Map<K, V> delegatedMap;
/*     */   private final Map<K, V> unmodifiableDelegatedMap;
/*     */   
/*     */   public ParameterMap() {
/*  49 */     this.delegatedMap = new LinkedHashMap<>();
/*  50 */     this.unmodifiableDelegatedMap = Collections.unmodifiableMap(this.delegatedMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterMap(int initialCapacity) {
/*  60 */     this.delegatedMap = new LinkedHashMap<>(initialCapacity);
/*  61 */     this.unmodifiableDelegatedMap = Collections.unmodifiableMap(this.delegatedMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterMap(int initialCapacity, float loadFactor) {
/*  72 */     this.delegatedMap = new LinkedHashMap<>(initialCapacity, loadFactor);
/*  73 */     this.unmodifiableDelegatedMap = Collections.unmodifiableMap(this.delegatedMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterMap(Map<K, V> map) {
/*  84 */     int mapSize = map.size();
/*  85 */     this.delegatedMap = new LinkedHashMap<>((int)(mapSize * 1.5D));
/*  86 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/*  87 */       this.delegatedMap.put(entry.getKey(), entry.getValue());
/*     */     }
/*  89 */     this.unmodifiableDelegatedMap = Collections.unmodifiableMap(this.delegatedMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterMap(ParameterMap<K, V> map) {
/* 102 */     int mapSize = map.size();
/* 103 */     this.delegatedMap = new LinkedHashMap<>((int)(mapSize * 1.5D));
/* 104 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/* 105 */       this.delegatedMap.put(entry.getKey(), entry.getValue());
/*     */     }
/* 107 */     this.unmodifiableDelegatedMap = Collections.unmodifiableMap(this.delegatedMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean locked = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocked() {
/* 121 */     return this.locked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocked(boolean locked) {
/* 131 */     this.locked = locked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 148 */     checkLocked();
/* 149 */     this.delegatedMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 160 */     checkLocked();
/* 161 */     return this.delegatedMap.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> map) {
/* 172 */     checkLocked();
/* 173 */     this.delegatedMap.putAll(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 184 */     checkLocked();
/* 185 */     return this.delegatedMap.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkLocked() {
/* 190 */     if (this.locked) {
/* 191 */       throw new IllegalStateException(sm.getString("parameterMap.locked"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 198 */     return this.delegatedMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 204 */     return this.delegatedMap.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 210 */     return this.delegatedMap.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 216 */     return this.delegatedMap.containsValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 222 */     return this.delegatedMap.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 233 */     if (this.locked) {
/* 234 */       return this.unmodifiableDelegatedMap.keySet();
/*     */     }
/*     */     
/* 237 */     return this.delegatedMap.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 249 */     if (this.locked) {
/* 250 */       return this.unmodifiableDelegatedMap.values();
/*     */     }
/*     */     
/* 253 */     return this.delegatedMap.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 264 */     if (this.locked) {
/* 265 */       return this.unmodifiableDelegatedMap.entrySet();
/*     */     }
/*     */     
/* 268 */     return this.delegatedMap.entrySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ParameterMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */