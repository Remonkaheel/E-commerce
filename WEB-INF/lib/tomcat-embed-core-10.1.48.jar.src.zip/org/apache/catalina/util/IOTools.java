/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOTools
/*     */ {
/*     */   protected static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   
/*     */   public static void flow(Reader reader, Writer writer, char[] buf) throws IOException {
/*     */     int numRead;
/*  47 */     while ((numRead = reader.read(buf)) >= 0) {
/*  48 */       writer.write(buf, 0, numRead);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void flow(Reader reader, Writer writer) throws IOException {
/*  63 */     char[] buf = new char[4096];
/*  64 */     flow(reader, writer, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void flow(InputStream is, OutputStream os) throws IOException {
/*  78 */     byte[] buf = new byte[4096];
/*     */     int numRead;
/*  80 */     while ((numRead = is.read(buf)) >= 0) {
/*  81 */       if (os != null) {
/*  82 */         os.write(buf, 0, numRead);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readFully(InputStream is, byte[] buf) throws IOException {
/*  99 */     int bytesRead = 0;
/*     */     int read;
/* 101 */     while (bytesRead < buf.length && (read = is.read(buf, bytesRead, buf.length - bytesRead)) >= 0) {
/* 102 */       bytesRead += read;
/*     */     }
/* 104 */     return bytesRead;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\IOTools.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */