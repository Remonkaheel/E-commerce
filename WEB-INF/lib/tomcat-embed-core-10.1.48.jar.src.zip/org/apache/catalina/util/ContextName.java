/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextName
/*     */ {
/*     */   public static final String ROOT_NAME = "ROOT";
/*     */   private static final String VERSION_MARKER = "##";
/*     */   private static final char FWD_SLASH_REPLACEMENT = '#';
/*     */   private final String baseName;
/*     */   private final String path;
/*     */   private final String version;
/*     */   private final String name;
/*     */   
/*     */   public ContextName(String name, boolean stripFileExtension) {
/*  46 */     String tmp2, tmp1 = name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     if (tmp1.startsWith("/")) {
/*  52 */       tmp1 = tmp1.substring(1);
/*     */     }
/*     */ 
/*     */     
/*  56 */     tmp1 = tmp1.replace('/', '#');
/*     */ 
/*     */     
/*  59 */     if (tmp1.startsWith("##") || tmp1.isEmpty()) {
/*  60 */       tmp1 = "ROOT" + tmp1;
/*     */     }
/*     */ 
/*     */     
/*  64 */     if (stripFileExtension && (tmp1.toLowerCase(Locale.ENGLISH).endsWith(".war") || tmp1
/*  65 */       .toLowerCase(Locale.ENGLISH).endsWith(".xml"))) {
/*  66 */       tmp1 = tmp1.substring(0, tmp1.length() - 4);
/*     */     }
/*     */     
/*  69 */     this.baseName = tmp1;
/*     */ 
/*     */ 
/*     */     
/*  73 */     int versionIndex = this.baseName.indexOf("##");
/*  74 */     if (versionIndex > -1) {
/*  75 */       this.version = this.baseName.substring(versionIndex + 2);
/*  76 */       tmp2 = this.baseName.substring(0, versionIndex);
/*     */     } else {
/*  78 */       this.version = "";
/*  79 */       tmp2 = this.baseName;
/*     */     } 
/*     */     
/*  82 */     if ("ROOT".equals(tmp2)) {
/*  83 */       this.path = "";
/*     */     } else {
/*  85 */       this.path = "/" + tmp2.replace('#', '/');
/*     */     } 
/*     */     
/*  88 */     if (versionIndex > -1) {
/*  89 */       this.name = this.path + "##" + this.path;
/*     */     } else {
/*  91 */       this.name = this.path;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextName(String path, String version) {
/* 103 */     if (path == null || "/".equals(path) || "/ROOT".equals(path)) {
/* 104 */       this.path = "";
/*     */     } else {
/* 106 */       this.path = path;
/*     */     } 
/*     */ 
/*     */     
/* 110 */     this.version = Objects.<String>requireNonNullElse(version, "");
/*     */ 
/*     */     
/* 113 */     if (this.version.isEmpty()) {
/* 114 */       this.name = this.path;
/*     */     } else {
/* 116 */       this.name = this.path + "##" + this.path;
/*     */     } 
/*     */ 
/*     */     
/* 120 */     StringBuilder tmp = new StringBuilder();
/* 121 */     if (this.path.isEmpty()) {
/* 122 */       tmp.append("ROOT");
/*     */     } else {
/* 124 */       tmp.append(this.path.substring(1).replace('/', '#'));
/*     */     } 
/* 126 */     if (!this.version.isEmpty()) {
/* 127 */       tmp.append("##");
/* 128 */       tmp.append(this.version);
/*     */     } 
/* 130 */     this.baseName = tmp.toString();
/*     */   }
/*     */   
/*     */   public String getBaseName() {
/* 134 */     return this.baseName;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 138 */     return this.path;
/*     */   }
/*     */   
/*     */   public String getVersion() {
/* 142 */     return this.version;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 146 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/* 150 */     StringBuilder tmp = new StringBuilder();
/* 151 */     if ("".equals(this.path)) {
/* 152 */       tmp.append('/');
/*     */     } else {
/* 154 */       tmp.append(this.path);
/*     */     } 
/*     */     
/* 157 */     if (!this.version.isEmpty()) {
/* 158 */       tmp.append("##");
/* 159 */       tmp.append(this.version);
/*     */     } 
/*     */     
/* 162 */     return tmp.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return getDisplayName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextName extractFromPath(String path) {
/* 181 */     path = path.replace("\\", "/");
/*     */     
/* 183 */     while (path.endsWith("/")) {
/* 184 */       path = path.substring(0, path.length() - 1);
/*     */     }
/*     */     
/* 187 */     int lastSegment = path.lastIndexOf('/');
/* 188 */     if (lastSegment > 0) {
/* 189 */       path = path.substring(lastSegment + 1);
/*     */     }
/*     */     
/* 192 */     return new ContextName(path, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ContextName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */