/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExactRateLimiter
/*    */   extends RateLimiterBase
/*    */ {
/*    */   protected String getDefaultPolicyName() {
/* 28 */     return "exact";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected TimeBucketCounterBase newCounterInstance(int duration, ScheduledExecutorService executorService) {
/* 34 */     return new ExactTimeBucketCounter(duration, executorService);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class ExactTimeBucketCounter
/*    */     extends TimeBucketCounterBase
/*    */   {
/*    */     ExactTimeBucketCounter(int bucketDuration, ScheduledExecutorService executorService) {
/* 45 */       super(bucketDuration, executorService);
/*    */     }
/*    */ 
/*    */     
/*    */     public long getBucketIndex(long timestamp) {
/* 50 */       return timestamp / 1000L / getBucketDuration();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public double getRatio() {
/* 56 */       return 1.0D;
/*    */     }
/*    */ 
/*    */     
/*    */     public long getMillisUntilNextBucket() {
/* 61 */       long millis = System.currentTimeMillis();
/* 62 */       long nextTimeBucketMillis = (getBucketIndex(millis) + 1L) * getBucketDuration() * 1000L;
/* 63 */       return nextTimeBucketMillis - millis;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ExactRateLimiter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */