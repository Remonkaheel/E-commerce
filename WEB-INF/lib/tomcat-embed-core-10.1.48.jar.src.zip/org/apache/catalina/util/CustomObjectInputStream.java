/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InvalidClassException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CustomObjectInputStream
/*     */   extends ObjectInputStream
/*     */ {
/*  39 */   private static final StringManager sm = StringManager.getManager(CustomObjectInputStream.class);
/*     */   
/*  41 */   private static final WeakHashMap<ClassLoader, Set<String>> reportedClassCache = new WeakHashMap<>();
/*     */ 
/*     */   
/*     */   private final ClassLoader classLoader;
/*     */ 
/*     */   
/*     */   private final Set<String> reportedClasses;
/*     */ 
/*     */   
/*     */   private final Log log;
/*     */ 
/*     */   
/*     */   private final Pattern allowedClassNamePattern;
/*     */ 
/*     */   
/*     */   private final String allowedClassNameFilter;
/*     */ 
/*     */   
/*     */   private final boolean warnOnFailure;
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomObjectInputStream(InputStream stream, ClassLoader classLoader) throws IOException {
/*  64 */     this(stream, classLoader, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomObjectInputStream(InputStream stream, ClassLoader classLoader, Log log, Pattern allowedClassNamePattern, boolean warnOnFailure) throws IOException {
/*  84 */     super(stream); Set<String> reportedClasses;
/*  85 */     if (log == null && allowedClassNamePattern != null && warnOnFailure) {
/*  86 */       throw new IllegalArgumentException(sm.getString("customObjectInputStream.logRequired"));
/*     */     }
/*  88 */     this.classLoader = classLoader;
/*  89 */     this.log = log;
/*  90 */     this.allowedClassNamePattern = allowedClassNamePattern;
/*  91 */     if (allowedClassNamePattern == null) {
/*  92 */       this.allowedClassNameFilter = null;
/*     */     } else {
/*  94 */       this.allowedClassNameFilter = allowedClassNamePattern.toString();
/*     */     } 
/*  96 */     this.warnOnFailure = warnOnFailure;
/*     */ 
/*     */     
/*  99 */     synchronized (reportedClassCache) {
/* 100 */       reportedClasses = reportedClassCache.get(classLoader);
/*     */     } 
/* 102 */     if (reportedClasses == null) {
/* 103 */       Set<String> original; reportedClasses = ConcurrentHashMap.newKeySet();
/*     */       
/* 105 */       synchronized (reportedClassCache) {
/* 106 */         original = reportedClassCache.putIfAbsent(classLoader, reportedClasses);
/*     */       } 
/* 108 */       if (original != null)
/*     */       {
/*     */         
/* 111 */         reportedClasses = original;
/*     */       }
/*     */     } 
/* 114 */     this.reportedClasses = reportedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> resolveClass(ObjectStreamClass classDesc) throws ClassNotFoundException, IOException {
/* 130 */     String name = classDesc.getName();
/* 131 */     if (this.allowedClassNamePattern != null) {
/* 132 */       boolean allowed = this.allowedClassNamePattern.matcher(name).matches();
/* 133 */       if (!allowed) {
/* 134 */         boolean doLog = (this.warnOnFailure && this.reportedClasses.add(name));
/* 135 */         String msg = sm.getString("customObjectInputStream.nomatch", new Object[] { name, this.allowedClassNameFilter });
/* 136 */         if (doLog) {
/* 137 */           this.log.warn(msg);
/* 138 */         } else if (this.log.isDebugEnabled()) {
/* 139 */           this.log.debug(msg);
/*     */         } 
/* 141 */         throw new InvalidClassException(msg);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 146 */       return Class.forName(name, false, this.classLoader);
/* 147 */     } catch (ClassNotFoundException e) {
/*     */       
/*     */       try {
/* 150 */         return super.resolveClass(classDesc);
/* 151 */       } catch (ClassNotFoundException e2) {
/*     */ 
/*     */         
/* 154 */         throw e;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> resolveProxyClass(String[] interfaces) throws IOException, ClassNotFoundException {
/* 167 */     Class<?>[] cinterfaces = new Class[interfaces.length];
/* 168 */     for (int i = 0; i < interfaces.length; i++) {
/* 169 */       cinterfaces[i] = this.classLoader.loadClass(interfaces[i]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 175 */       Class<?> proxyClass = Proxy.getProxyClass(this.classLoader, cinterfaces);
/* 176 */       return proxyClass;
/* 177 */     } catch (IllegalArgumentException e) {
/* 178 */       throw new ClassNotFoundException(null, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\CustomObjectInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */