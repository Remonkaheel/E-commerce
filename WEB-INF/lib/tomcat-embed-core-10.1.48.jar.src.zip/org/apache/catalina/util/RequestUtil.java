/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import org.apache.catalina.connector.Request;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestUtil
/*     */ {
/*     */   public static StringBuffer getRequestURL(HttpServletRequest request) {
/*  37 */     StringBuffer url = new StringBuffer();
/*  38 */     String scheme = request.getScheme();
/*  39 */     int port = request.getServerPort();
/*  40 */     if (port < 0)
/*     */     {
/*  42 */       port = 80;
/*     */     }
/*     */     
/*  45 */     url.append(scheme);
/*  46 */     url.append("://");
/*  47 */     url.append(request.getServerName());
/*  48 */     if ((scheme.equals("http") && port != 80) || (scheme.equals("https") && port != 443)) {
/*  49 */       url.append(':');
/*  50 */       url.append(port);
/*     */     } 
/*  52 */     url.append(request.getRequestURI());
/*     */     
/*  54 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripPathParams(String input, Request request) {
/*  68 */     if (input.indexOf(';') < 0) {
/*  69 */       return input;
/*     */     }
/*     */     
/*  72 */     StringBuilder sb = new StringBuilder(input.length());
/*  73 */     int pos = 0;
/*  74 */     int limit = input.length();
/*  75 */     while (pos < limit) {
/*  76 */       int nextSemiColon = input.indexOf(';', pos);
/*  77 */       if (nextSemiColon < 0) {
/*  78 */         nextSemiColon = limit;
/*     */       }
/*  80 */       sb.append(input, pos, nextSemiColon);
/*  81 */       int followingSlash = input.indexOf('/', nextSemiColon);
/*  82 */       if (followingSlash < 0) {
/*  83 */         pos = limit;
/*     */       } else {
/*  85 */         pos = followingSlash;
/*     */       } 
/*  87 */       if (request != null && nextSemiColon + 1 < pos) {
/*  88 */         String pathVariablesString = input.substring(nextSemiColon + 1, pos);
/*  89 */         String[] pathVariables = pathVariablesString.split(";");
/*  90 */         for (String pathVariable : pathVariables) {
/*  91 */           int equals = pathVariable.indexOf('=');
/*  92 */           if (equals > -1 && equals + 1 < pathVariable.length()) {
/*  93 */             String name = pathVariable.substring(0, equals);
/*  94 */             String value = pathVariable.substring(equals + 1);
/*  95 */             request.addPathParameter(name, value);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 101 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\RequestUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */