/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LifecycleBase
/*     */   implements Lifecycle
/*     */ {
/*  38 */   private static final Log log = LogFactory.getLog(LifecycleBase.class);
/*     */   
/*  40 */   private static final StringManager sm = StringManager.getManager(LifecycleBase.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private final List<LifecycleListener> lifecycleListeners = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private volatile LifecycleState state = LifecycleState.NEW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean throwOnFailure = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getThrowOnFailure() {
/*  66 */     return this.throwOnFailure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThrowOnFailure(boolean throwOnFailure) {
/*  78 */     this.throwOnFailure = throwOnFailure;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLifecycleListener(LifecycleListener listener) {
/*  84 */     this.lifecycleListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LifecycleListener[] findLifecycleListeners() {
/*  90 */     return this.lifecycleListeners.<LifecycleListener>toArray(new LifecycleListener[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLifecycleListener(LifecycleListener listener) {
/*  96 */     this.lifecycleListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireLifecycleEvent(String type, Object data) {
/* 107 */     LifecycleEvent event = new LifecycleEvent(this, type, data);
/* 108 */     for (LifecycleListener listener : this.lifecycleListeners) {
/* 109 */       listener.lifecycleEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void init() throws LifecycleException {
/* 116 */     if (!this.state.equals(LifecycleState.NEW)) {
/* 117 */       invalidTransition("before_init");
/*     */     }
/*     */     
/*     */     try {
/* 121 */       setStateInternal(LifecycleState.INITIALIZING, null, false);
/* 122 */       initInternal();
/* 123 */       setStateInternal(LifecycleState.INITIALIZED, null, false);
/* 124 */     } catch (Throwable t) {
/* 125 */       handleSubClassException(t, "lifecycleBase.initFail", new Object[] { toString() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void initInternal() throws LifecycleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void start() throws LifecycleException {
/* 141 */     if (LifecycleState.STARTING_PREP.equals(this.state) || LifecycleState.STARTING.equals(this.state) || LifecycleState.STARTED
/* 142 */       .equals(this.state)) {
/*     */       
/* 144 */       if (log.isDebugEnabled()) {
/* 145 */         LifecycleException lifecycleException = new LifecycleException();
/* 146 */         log.debug(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }), (Throwable)lifecycleException);
/* 147 */       } else if (log.isInfoEnabled()) {
/* 148 */         log.info(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 154 */     if (this.state.equals(LifecycleState.NEW)) {
/* 155 */       init();
/* 156 */     } else if (this.state.equals(LifecycleState.FAILED)) {
/* 157 */       stop();
/* 158 */     } else if (!this.state.equals(LifecycleState.INITIALIZED) && !this.state.equals(LifecycleState.STOPPED)) {
/* 159 */       invalidTransition("before_start");
/*     */     } 
/*     */     
/*     */     try {
/* 163 */       setStateInternal(LifecycleState.STARTING_PREP, null, false);
/* 164 */       startInternal();
/* 165 */       if (this.state.equals(LifecycleState.FAILED)) {
/*     */ 
/*     */         
/* 168 */         stop();
/* 169 */       } else if (!this.state.equals(LifecycleState.STARTING)) {
/*     */ 
/*     */         
/* 172 */         invalidTransition("after_start");
/*     */       } else {
/* 174 */         setStateInternal(LifecycleState.STARTED, null, false);
/*     */       } 
/* 176 */     } catch (Throwable t) {
/*     */ 
/*     */       
/* 179 */       handleSubClassException(t, "lifecycleBase.startFail", new Object[] { toString() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void startInternal() throws LifecycleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void stop() throws LifecycleException {
/* 199 */     if (LifecycleState.STOPPING_PREP.equals(this.state) || LifecycleState.STOPPING.equals(this.state) || LifecycleState.STOPPED
/* 200 */       .equals(this.state)) {
/*     */       
/* 202 */       if (log.isDebugEnabled()) {
/* 203 */         LifecycleException lifecycleException = new LifecycleException();
/* 204 */         log.debug(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }), (Throwable)lifecycleException);
/* 205 */       } else if (log.isInfoEnabled()) {
/* 206 */         log.info(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 212 */     if (this.state.equals(LifecycleState.INITIALIZED)) {
/*     */       return;
/*     */     }
/*     */     
/* 216 */     if (this.state.equals(LifecycleState.NEW)) {
/* 217 */       this.state = LifecycleState.STOPPED;
/*     */       
/*     */       return;
/*     */     } 
/* 221 */     if (!this.state.equals(LifecycleState.STARTED) && !this.state.equals(LifecycleState.FAILED)) {
/* 222 */       invalidTransition("before_stop");
/*     */     }
/*     */     
/*     */     try {
/* 226 */       if (this.state.equals(LifecycleState.FAILED)) {
/*     */ 
/*     */ 
/*     */         
/* 230 */         fireLifecycleEvent("before_stop", null);
/*     */       } else {
/* 232 */         setStateInternal(LifecycleState.STOPPING_PREP, null, false);
/*     */       } 
/*     */       
/* 235 */       stopInternal();
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (!this.state.equals(LifecycleState.STOPPING) && !this.state.equals(LifecycleState.FAILED)) {
/* 240 */         invalidTransition("after_stop");
/*     */       }
/*     */       
/* 243 */       setStateInternal(LifecycleState.STOPPED, null, false);
/* 244 */     } catch (Throwable t) {
/* 245 */       handleSubClassException(t, "lifecycleBase.stopFail", new Object[] { toString() });
/*     */     } finally {
/* 247 */       if (this instanceof Lifecycle.SingleUse) {
/*     */         
/* 249 */         setStateInternal(LifecycleState.STOPPED, null, false);
/* 250 */         destroy();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void stopInternal() throws LifecycleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void destroy() throws LifecycleException {
/* 267 */     if (LifecycleState.FAILED.equals(this.state)) {
/*     */       
/*     */       try {
/* 270 */         stop();
/* 271 */       } catch (LifecycleException e) {
/*     */         
/* 273 */         log.error(sm.getString("lifecycleBase.destroyStopFail", new Object[] { toString() }), (Throwable)e);
/*     */       } 
/*     */     }
/*     */     
/* 277 */     if (LifecycleState.DESTROYING.equals(this.state) || LifecycleState.DESTROYED.equals(this.state)) {
/* 278 */       if (log.isDebugEnabled()) {
/* 279 */         LifecycleException lifecycleException = new LifecycleException();
/* 280 */         log.debug(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }), (Throwable)lifecycleException);
/* 281 */       } else if (log.isInfoEnabled() && !(this instanceof Lifecycle.SingleUse)) {
/*     */ 
/*     */ 
/*     */         
/* 285 */         log.info(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 291 */     if (!this.state.equals(LifecycleState.STOPPED) && !this.state.equals(LifecycleState.FAILED) && 
/* 292 */       !this.state.equals(LifecycleState.NEW) && !this.state.equals(LifecycleState.INITIALIZED)) {
/* 293 */       invalidTransition("before_destroy");
/*     */     }
/*     */     
/*     */     try {
/* 297 */       setStateInternal(LifecycleState.DESTROYING, null, false);
/* 298 */       destroyInternal();
/* 299 */       setStateInternal(LifecycleState.DESTROYED, null, false);
/* 300 */     } catch (Throwable t) {
/* 301 */       handleSubClassException(t, "lifecycleBase.destroyFail", new Object[] { toString() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void destroyInternal() throws LifecycleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LifecycleState getState() {
/* 316 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStateName() {
/* 322 */     return getState().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void setState(LifecycleState state) throws LifecycleException {
/* 336 */     setStateInternal(state, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void setState(LifecycleState state, Object data) throws LifecycleException {
/* 351 */     setStateInternal(state, data, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void setStateInternal(LifecycleState state, Object data, boolean check) throws LifecycleException {
/* 358 */     if (log.isDebugEnabled()) {
/* 359 */       log.debug(sm.getString("lifecycleBase.setState", new Object[] { this, state }));
/*     */     }
/*     */     
/* 362 */     if (check) {
/*     */ 
/*     */ 
/*     */       
/* 366 */       if (state == null) {
/* 367 */         invalidTransition("null");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 377 */       if (state != LifecycleState.FAILED && (this.state != LifecycleState.STARTING_PREP || state != LifecycleState.STARTING) && (this.state != LifecycleState.STOPPING_PREP || state != LifecycleState.STOPPING) && (this.state != LifecycleState.FAILED || state != LifecycleState.STOPPING))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 382 */         invalidTransition(state.name());
/*     */       }
/*     */     } 
/*     */     
/* 386 */     this.state = state;
/* 387 */     String lifecycleEvent = state.getLifecycleEvent();
/* 388 */     if (lifecycleEvent != null) {
/* 389 */       fireLifecycleEvent(lifecycleEvent, data);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void invalidTransition(String type) throws LifecycleException {
/* 395 */     throw new LifecycleException(sm.getString("lifecycleBase.invalidTransition", new Object[] { type, toString(), this.state }));
/*     */   }
/*     */   
/*     */   private void handleSubClassException(Throwable t, String key, Object... args) throws LifecycleException {
/*     */     LifecycleException lifecycleException;
/* 400 */     setStateInternal(LifecycleState.FAILED, null, false);
/* 401 */     ExceptionUtils.handleThrowable(t);
/* 402 */     if (getThrowOnFailure()) {
/* 403 */       if (!(t instanceof LifecycleException)) {
/* 404 */         lifecycleException = new LifecycleException(sm.getString(key, args), t);
/*     */       }
/* 406 */       throw lifecycleException;
/*     */     } 
/* 408 */     log.error(sm.getString(key, args), (Throwable)lifecycleException);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\LifecycleBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */