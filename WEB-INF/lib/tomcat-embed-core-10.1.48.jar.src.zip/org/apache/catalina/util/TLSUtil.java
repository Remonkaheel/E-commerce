/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TLSUtil
/*    */ {
/*    */   public static boolean isTLSRequestAttribute(String name) {
/* 34 */     switch (name) {
/*    */       case "jakarta.servlet.request.X509Certificate":
/*    */       case "jakarta.servlet.request.cipher_suite":
/*    */       case "jakarta.servlet.request.key_size":
/*    */       case "jakarta.servlet.request.ssl_session_id":
/*    */       case "jakarta.servlet.request.ssl_session_mgr":
/*    */       case "org.apache.tomcat.util.net.secure_protocol_version":
/*    */       case "org.apache.tomcat.util.net.secure_requested_protocol_versions":
/*    */       case "org.apache.tomcat.util.net.secure_requested_ciphers":
/* 43 */         return true;
/*    */     } 
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\TLSUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */