/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorPageSupport
/*     */ {
/*  32 */   private final Map<String, ErrorPage> exceptionPages = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*  35 */   private final Map<Integer, ErrorPage> statusPages = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public void add(ErrorPage errorPage) {
/*  39 */     String exceptionType = errorPage.getExceptionType();
/*  40 */     if (exceptionType == null) {
/*  41 */       this.statusPages.put(Integer.valueOf(errorPage.getErrorCode()), errorPage);
/*     */     } else {
/*  43 */       this.exceptionPages.put(exceptionType, errorPage);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(ErrorPage errorPage) {
/*  49 */     String exceptionType = errorPage.getExceptionType();
/*  50 */     if (exceptionType == null) {
/*  51 */       this.statusPages.remove(Integer.valueOf(errorPage.getErrorCode()), errorPage);
/*     */     } else {
/*  53 */       this.exceptionPages.remove(exceptionType, errorPage);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ErrorPage find(int statusCode) {
/*  59 */     return this.statusPages.get(Integer.valueOf(statusCode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorPage find(String exceptionType) {
/*  71 */     return this.exceptionPages.get(exceptionType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ErrorPage find(Throwable exceptionType) {
/*  76 */     if (exceptionType == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     Class<?> clazz = exceptionType.getClass();
/*  80 */     String name = clazz.getName();
/*  81 */     while (!Object.class.equals(clazz)) {
/*  82 */       ErrorPage errorPage = this.exceptionPages.get(name);
/*  83 */       if (errorPage != null) {
/*  84 */         return errorPage;
/*     */       }
/*  86 */       clazz = clazz.getSuperclass();
/*  87 */       if (clazz == null) {
/*     */         break;
/*     */       }
/*  90 */       name = clazz.getName();
/*     */     } 
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ErrorPage[] findAll() {
/*  97 */     Set<ErrorPage> errorPages = new HashSet<>();
/*  98 */     errorPages.addAll(this.exceptionPages.values());
/*  99 */     errorPages.addAll(this.statusPages.values());
/* 100 */     return errorPages.<ErrorPage>toArray(new ErrorPage[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\ErrorPageSupport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */