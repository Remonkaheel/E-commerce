/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetMapper
/*     */ {
/*     */   public static final String DEFAULT_RESOURCE = "/org/apache/catalina/util/CharsetMapperDefault.properties";
/*     */   
/*     */   public CharsetMapper() {
/*  53 */     this("/org/apache/catalina/util/CharsetMapperDefault.properties");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetMapper(String name) {
/*  65 */     if (JreCompat.isGraalAvailable())
/*  66 */     { this.map.put("en", "ISO-8859-1"); }
/*     */     else { 
/*  68 */       try { InputStream stream = getClass().getResourceAsStream(name); 
/*  69 */         try { this.map.load(stream);
/*  70 */           if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null) try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable t)
/*  71 */       { ExceptionUtils.handleThrowable(t);
/*  72 */         throw new IllegalArgumentException(t); }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private final Properties map = new Properties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharset(Locale locale) {
/* 101 */     String charset = this.map.getProperty(locale.toString());
/* 102 */     if (charset == null) {
/* 103 */       charset = this.map.getProperty(locale.getLanguage() + "_" + locale.getLanguage());
/* 104 */       if (charset == null) {
/* 105 */         charset = this.map.getProperty(locale.getLanguage());
/*     */       }
/*     */     } 
/* 108 */     return charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCharsetMappingFromDeploymentDescriptor(String locale, String charset) {
/* 120 */     this.map.put(locale, charset);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\CharsetMapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */