/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URLEncoder
/*     */   implements Cloneable
/*     */ {
/*  32 */   private static final char[] hexadecimal = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   
/*  35 */   public static final URLEncoder DEFAULT = new URLEncoder();
/*  36 */   public static final URLEncoder QUERY = new URLEncoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BitSet safeCharacters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  50 */     DEFAULT.addSafeCharacter('-');
/*  51 */     DEFAULT.addSafeCharacter('.');
/*  52 */     DEFAULT.addSafeCharacter('_');
/*  53 */     DEFAULT.addSafeCharacter('~');
/*     */     
/*  55 */     DEFAULT.addSafeCharacter('!');
/*  56 */     DEFAULT.addSafeCharacter('$');
/*  57 */     DEFAULT.addSafeCharacter('&');
/*  58 */     DEFAULT.addSafeCharacter('\'');
/*  59 */     DEFAULT.addSafeCharacter('(');
/*  60 */     DEFAULT.addSafeCharacter(')');
/*  61 */     DEFAULT.addSafeCharacter('*');
/*  62 */     DEFAULT.addSafeCharacter('+');
/*  63 */     DEFAULT.addSafeCharacter(',');
/*  64 */     DEFAULT.addSafeCharacter(';');
/*  65 */     DEFAULT.addSafeCharacter('=');
/*     */     
/*  67 */     DEFAULT.addSafeCharacter(':');
/*  68 */     DEFAULT.addSafeCharacter('@');
/*     */     
/*  70 */     DEFAULT.addSafeCharacter('/');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     QUERY.setEncodeSpaceAsPlus(true);
/*     */ 
/*     */     
/*  87 */     QUERY.addSafeCharacter('*');
/*  88 */     QUERY.addSafeCharacter('-');
/*  89 */     QUERY.addSafeCharacter('.');
/*  90 */     QUERY.addSafeCharacter('_');
/*  91 */     QUERY.addSafeCharacter('=');
/*  92 */     QUERY.addSafeCharacter('&');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeSpaceAsPlus = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public URLEncoder() {
/* 102 */     this(new BitSet(256));
/*     */     char i;
/* 104 */     for (i = 'a'; i <= 'z'; i = (char)(i + 1)) {
/* 105 */       addSafeCharacter(i);
/*     */     }
/* 107 */     for (i = 'A'; i <= 'Z'; i = (char)(i + 1)) {
/* 108 */       addSafeCharacter(i);
/*     */     }
/* 110 */     for (i = '0'; i <= '9'; i = (char)(i + 1)) {
/* 111 */       addSafeCharacter(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private URLEncoder(BitSet safeCharacters) {
/* 117 */     this.safeCharacters = safeCharacters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSafeCharacter(char c) {
/* 122 */     this.safeCharacters.set(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSafeCharacter(char c) {
/* 127 */     this.safeCharacters.clear(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEncodeSpaceAsPlus(boolean encodeSpaceAsPlus) {
/* 132 */     this.encodeSpaceAsPlus = encodeSpaceAsPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(String path, Charset charset) {
/* 146 */     int maxBytesPerChar = 10;
/* 147 */     StringBuilder rewrittenPath = new StringBuilder(path.length());
/* 148 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/* 149 */     OutputStreamWriter writer = new OutputStreamWriter(buf, charset);
/*     */     
/* 151 */     for (int i = 0; i < path.length(); i++) {
/* 152 */       int c = path.charAt(i);
/* 153 */       if (this.safeCharacters.get(c)) {
/* 154 */         rewrittenPath.append((char)c);
/* 155 */       } else if (this.encodeSpaceAsPlus && c == 32) {
/* 156 */         rewrittenPath.append('+');
/*     */       } else {
/*     */         
/*     */         try {
/* 160 */           writer.write((char)c);
/* 161 */           writer.flush();
/* 162 */         } catch (IOException ioe) {
/* 163 */           buf.reset();
/*     */         } 
/*     */         
/* 166 */         byte[] ba = buf.toByteArray();
/* 167 */         for (byte toEncode : ba) {
/*     */           
/* 169 */           rewrittenPath.append('%');
/* 170 */           int low = toEncode & 0xF;
/* 171 */           int high = (toEncode & 0xF0) >> 4;
/* 172 */           rewrittenPath.append(hexadecimal[high]);
/* 173 */           rewrittenPath.append(hexadecimal[low]);
/*     */         } 
/* 175 */         buf.reset();
/*     */       } 
/*     */     } 
/* 178 */     return rewrittenPath.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 184 */     URLEncoder result = new URLEncoder((BitSet)this.safeCharacters.clone());
/* 185 */     result.setEncodeSpaceAsPlus(this.encodeSpaceAsPlus);
/* 186 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\URLEncoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */