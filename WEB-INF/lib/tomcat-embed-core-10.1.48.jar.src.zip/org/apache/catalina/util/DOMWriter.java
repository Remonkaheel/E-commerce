/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWriter
/*     */ {
/*     */   private final PrintWriter out;
/*     */   
/*     */   public DOMWriter(Writer writer) {
/*  38 */     this.out = new PrintWriter(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(Node node) {
/*     */     Attr[] attrs;
/*     */     boolean xmlns;
/*     */     String data;
/*  50 */     if (node == null) {
/*     */       return;
/*     */     }
/*     */     
/*  54 */     int type = node.getNodeType();
/*  55 */     switch (type) {
/*     */       
/*     */       case 9:
/*  58 */         print(((Document)node).getDocumentElement());
/*  59 */         this.out.flush();
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/*  64 */         this.out.print('<');
/*  65 */         this.out.print(node.getLocalName());
/*  66 */         attrs = sortAttributes(node.getAttributes());
/*  67 */         xmlns = false;
/*  68 */         for (Attr attr : attrs) {
/*  69 */           if (!"xmlns".equals(attr.getPrefix())) {
/*     */ 
/*     */ 
/*     */             
/*  73 */             this.out.print(' ');
/*  74 */             this.out.print(attr.getLocalName());
/*  75 */             if ("xmlns".equals(attr.getLocalName())) {
/*  76 */               xmlns = true;
/*     */             }
/*  78 */             this.out.print("=\"");
/*  79 */             this.out.print(Escape.xml("", true, attr.getNodeValue()));
/*  80 */             this.out.print('"');
/*     */           } 
/*  82 */         }  if (!xmlns && node.getNamespaceURI() != null) {
/*  83 */           this.out.print(" xmlns=\"");
/*  84 */           this.out.print(Escape.xml(node.getNamespaceURI()));
/*  85 */           this.out.print('"');
/*     */         } 
/*  87 */         this.out.print('>');
/*  88 */         printChildren(node);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*  93 */         printChildren(node);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/*  98 */         this.out.print(Escape.xml("", true, node.getNodeValue()));
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 103 */         this.out.print(Escape.xml("", false, node.getNodeValue()));
/*     */         break;
/*     */ 
/*     */       
/*     */       case 7:
/* 108 */         this.out.print("<?");
/* 109 */         this.out.print(node.getLocalName());
/*     */         
/* 111 */         data = node.getNodeValue();
/* 112 */         if (data != null && !data.isEmpty()) {
/* 113 */           this.out.print(' ');
/* 114 */           this.out.print(data);
/*     */         } 
/* 116 */         this.out.print("?>");
/*     */         break;
/*     */     } 
/*     */     
/* 120 */     if (type == 1) {
/* 121 */       this.out.print("</");
/* 122 */       this.out.print(node.getLocalName());
/* 123 */       this.out.print('>');
/*     */     } 
/*     */     
/* 126 */     this.out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void printChildren(Node node) {
/* 132 */     NodeList children = node.getChildNodes();
/* 133 */     if (children != null) {
/* 134 */       int len = children.getLength();
/* 135 */       for (int i = 0; i < len; i++) {
/* 136 */         print(children.item(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Attr[] sortAttributes(NamedNodeMap attrs) {
/* 150 */     if (attrs == null) {
/* 151 */       return new Attr[0];
/*     */     }
/*     */     
/* 154 */     int len = attrs.getLength();
/* 155 */     Attr[] array = new Attr[len]; int i;
/* 156 */     for (i = 0; i < len; i++) {
/* 157 */       array[i] = (Attr)attrs.item(i);
/*     */     }
/* 159 */     for (i = 0; i < len - 1; i++) {
/* 160 */       String name = array[i].getLocalName();
/* 161 */       int index = i;
/* 162 */       for (int j = i + 1; j < len; j++) {
/* 163 */         String curName = array[j].getLocalName();
/* 164 */         if (curName.compareTo(name) < 0) {
/* 165 */           name = curName;
/* 166 */           index = j;
/*     */         } 
/*     */       } 
/* 169 */       if (index != i) {
/* 170 */         Attr temp = array[i];
/* 171 */         array[i] = array[index];
/* 172 */         array[index] = temp;
/*     */       } 
/*     */     } 
/*     */     
/* 176 */     return array;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\DOMWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */