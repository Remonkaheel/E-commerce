/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RateLimiterBase
/*     */   implements RateLimiter
/*     */ {
/*  31 */   private static final AtomicInteger index = new AtomicInteger();
/*     */   
/*     */   TimeBucketCounterBase bucketCounter;
/*     */   
/*     */   int requests;
/*     */   
/*     */   int actualRequests;
/*     */   
/*     */   int duration;
/*     */   
/*     */   int actualDuration;
/*  42 */   private String policyName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private ScheduledThreadPoolExecutor internalExecutorService = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getDefaultPolicyName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPolicyName() {
/*  61 */     if (this.policyName == null) {
/*  62 */       this.policyName = getDefaultPolicyName() + "-" + getDefaultPolicyName();
/*     */     }
/*  64 */     return this.policyName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicyName(String name) {
/*  70 */     Objects.requireNonNull(name);
/*  71 */     this.policyName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDuration() {
/*  77 */     return this.actualDuration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDuration(int duration) {
/*  83 */     this.duration = duration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRequests() {
/*  89 */     return this.actualRequests;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequests(int requests) {
/*  95 */     this.requests = requests;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int increment(String identifier) {
/* 101 */     return this.bucketCounter.increment(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 107 */     this.bucketCounter.destroy();
/* 108 */     if (this.internalExecutorService != null) {
/*     */       try {
/* 110 */         this.internalExecutorService.shutdown();
/* 111 */       } catch (SecurityException securityException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract TimeBucketCounterBase newCounterInstance(int paramInt, ScheduledExecutorService paramScheduledExecutorService);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterConfig(FilterConfig filterConfig) {
/* 134 */     ScheduledExecutorService executorService = (ScheduledExecutorService)filterConfig.getServletContext().getAttribute(ScheduledThreadPoolExecutor.class.getName());
/*     */     
/* 136 */     if (executorService == null) {
/* 137 */       this.internalExecutorService = new ScheduledThreadPoolExecutor(1);
/* 138 */       executorService = this.internalExecutorService;
/*     */     } 
/*     */     
/* 141 */     this.bucketCounter = newCounterInstance(this.duration, executorService);
/* 142 */     this.actualDuration = this.bucketCounter.getBucketDuration();
/* 143 */     this.actualRequests = (int)Math.round(this.bucketCounter.getRatio() * this.requests);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeBucketCounterBase getBucketCounter() {
/* 153 */     return this.bucketCounter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\RateLimiterBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */