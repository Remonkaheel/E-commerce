/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import jakarta.servlet.FilterConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RateLimiter
/*     */ {
/*     */   int getDuration();
/*     */   
/*     */   void setDuration(int paramInt);
/*     */   
/*     */   int getRequests();
/*     */   
/*     */   void setRequests(int paramInt);
/*     */   
/*     */   int increment(String paramString);
/*     */   
/*     */   void destroy();
/*     */   
/*     */   void setFilterConfig(FilterConfig paramFilterConfig);
/*     */   
/*     */   String getPolicyName();
/*     */   
/*     */   void setPolicyName(String paramString);
/*     */   
/*     */   default String getPolicy() {
/*  88 */     return "\"" + getPolicyName() + "\";q=" + getRequests() + ";w=" + getDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getQuota(int requestCount) {
/* 103 */     int maxRequests = getRequests();
/* 104 */     int remaining = (requestCount < 0 || requestCount > maxRequests) ? 0 : (maxRequests - requestCount);
/* 105 */     return "\"" + getPolicyName() + "\";r=" + remaining;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\RateLimiter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */