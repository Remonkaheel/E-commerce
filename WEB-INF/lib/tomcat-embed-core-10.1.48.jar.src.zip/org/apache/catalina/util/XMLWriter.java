/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLWriter
/*     */ {
/*     */   public static final int OPENING = 0;
/*     */   public static final int CLOSING = 1;
/*     */   public static final int NO_CONTENT = 2;
/*  54 */   protected StringBuilder buffer = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Writer writer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean lastWriteWasOpen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLWriter() {
/*  72 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLWriter(Writer writer) {
/*  84 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     return this.buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeProperty(String namespace, String name, String value) {
/* 109 */     writeElement(namespace, name, 0);
/* 110 */     this.buffer.append(value);
/* 111 */     writeElement(namespace, name, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeElement(String namespace, String name, int type) {
/* 123 */     writeElement(namespace, null, name, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeElement(String namespace, String namespaceInfo, String name, int type) {
/* 136 */     if (namespace != null && !namespace.isEmpty()) {
/* 137 */       switch (type) {
/*     */         case 0:
/* 139 */           if (this.lastWriteWasOpen) {
/* 140 */             this.buffer.append('\n');
/*     */           }
/* 142 */           if (namespaceInfo != null) {
/* 143 */             this.buffer.append("<").append(namespace).append(":").append(name).append(" xmlns:")
/* 144 */               .append(namespace).append("=\"").append(namespaceInfo).append("\">");
/*     */           } else {
/* 146 */             this.buffer.append("<").append(namespace).append(":").append(name).append(">");
/*     */           } 
/* 148 */           this.lastWriteWasOpen = true;
/*     */           return;
/*     */         case 1:
/* 151 */           this.buffer.append("</").append(namespace).append(":").append(name).append(">\n");
/* 152 */           this.lastWriteWasOpen = false;
/*     */           return;
/*     */       } 
/*     */       
/* 156 */       if (this.lastWriteWasOpen) {
/* 157 */         this.buffer.append('\n');
/*     */       }
/* 159 */       if (namespaceInfo != null) {
/* 160 */         this.buffer.append("<").append(namespace).append(":").append(name).append(" xmlns:")
/* 161 */           .append(namespace).append("=\"").append(namespaceInfo).append("\"/>\n");
/*     */       } else {
/* 163 */         this.buffer.append("<").append(namespace).append(":").append(name).append("/>\n");
/*     */       } 
/* 165 */       this.lastWriteWasOpen = false;
/*     */     
/*     */     }
/* 168 */     else if (namespaceInfo != null && !namespaceInfo.isEmpty()) {
/* 169 */       switch (type) {
/*     */         case 0:
/* 171 */           if (this.lastWriteWasOpen) {
/* 172 */             this.buffer.append('\n');
/*     */           }
/* 174 */           this.buffer.append("<").append(name).append(" xmlns=\"").append(namespaceInfo).append("\">");
/* 175 */           this.lastWriteWasOpen = true;
/*     */           return;
/*     */         case 1:
/* 178 */           this.buffer.append("</").append(name).append(">\n");
/* 179 */           this.lastWriteWasOpen = false;
/*     */           return;
/*     */       } 
/*     */       
/* 183 */       if (this.lastWriteWasOpen) {
/* 184 */         this.buffer.append('\n');
/*     */       }
/* 186 */       this.buffer.append("<").append(name).append(" xmlns=\"").append(namespaceInfo).append("\"/>\n");
/* 187 */       this.lastWriteWasOpen = false;
/*     */     }
/*     */     else {
/*     */       
/* 191 */       switch (type) {
/*     */         case 0:
/* 193 */           if (this.lastWriteWasOpen) {
/* 194 */             this.buffer.append('\n');
/*     */           }
/* 196 */           this.buffer.append("<").append(name).append(">");
/* 197 */           this.lastWriteWasOpen = true;
/*     */           return;
/*     */         case 1:
/* 200 */           this.buffer.append("</").append(name).append(">\n");
/* 201 */           this.lastWriteWasOpen = false;
/*     */           return;
/*     */       } 
/*     */       
/* 205 */       if (this.lastWriteWasOpen) {
/* 206 */         this.buffer.append('\n');
/*     */       }
/* 208 */       this.buffer.append("<").append(name).append("/>\n");
/* 209 */       this.lastWriteWasOpen = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeText(String text) {
/* 222 */     this.buffer.append(Escape.xml(text));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeRaw(String raw) {
/* 232 */     this.buffer.append(raw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeData(String data) {
/* 242 */     this.buffer.append("<![CDATA[").append(data).append("]]>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeXMLHeader() {
/* 250 */     this.buffer.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendData() throws IOException {
/* 260 */     if (this.writer != null) {
/* 261 */       this.writer.write(this.buffer.toString());
/* 262 */       this.buffer = new StringBuilder();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\XMLWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */