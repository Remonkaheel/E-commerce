/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.SessionIdGenerator;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SessionIdGeneratorBase
/*     */   extends LifecycleBase
/*     */   implements SessionIdGenerator
/*     */ {
/*  36 */   private final Log log = LogFactory.getLog(SessionIdGeneratorBase.class);
/*     */   
/*  38 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_SECURE_RANDOM_ALGORITHM;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  48 */     Set<String> algorithmNames = Security.getAlgorithms("SecureRandom");
/*  49 */     if (algorithmNames.contains("SHA1PRNG")) {
/*  50 */       DEFAULT_SECURE_RANDOM_ALGORITHM = "SHA1PRNG";
/*     */     } else {
/*     */       
/*  53 */       DEFAULT_SECURE_RANDOM_ALGORITHM = "";
/*  54 */       Log log = LogFactory.getLog(SessionIdGeneratorBase.class);
/*  55 */       log.warn(sm.getString("sessionIdGeneratorBase.noSHA1PRNG"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private final Queue<SecureRandom> randoms = new ConcurrentLinkedQueue<>();
/*     */   
/*  67 */   private String secureRandomClass = null;
/*     */   
/*  69 */   private String secureRandomAlgorithm = DEFAULT_SECURE_RANDOM_ALGORITHM;
/*     */   
/*  71 */   private String secureRandomProvider = null;
/*     */ 
/*     */ 
/*     */   
/*  75 */   private String jvmRoute = "";
/*     */ 
/*     */ 
/*     */   
/*  79 */   private int sessionIdLength = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSecureRandomClass() {
/*  89 */     return this.secureRandomClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandomClass(String secureRandomClass) {
/* 100 */     this.secureRandomClass = secureRandomClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSecureRandomAlgorithm() {
/* 110 */     return this.secureRandomAlgorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm) {
/* 125 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSecureRandomProvider() {
/* 135 */     return this.secureRandomProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandomProvider(String secureRandomProvider) {
/* 149 */     this.secureRandomProvider = secureRandomProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJvmRoute() {
/* 155 */     return this.jvmRoute;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJvmRoute(String jvmRoute) {
/* 161 */     this.jvmRoute = jvmRoute;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSessionIdLength() {
/* 167 */     return this.sessionIdLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionIdLength(int sessionIdLength) {
/* 173 */     this.sessionIdLength = sessionIdLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateSessionId() {
/* 178 */     return generateSessionId(this.jvmRoute);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void getRandomBytes(byte[] bytes) {
/* 184 */     SecureRandom random = this.randoms.poll();
/* 185 */     if (random == null) {
/* 186 */       random = createSecureRandom();
/*     */     }
/* 188 */     random.nextBytes(bytes);
/* 189 */     this.randoms.add(random);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecureRandom createSecureRandom() {
/* 198 */     SecureRandom result = null;
/*     */     
/* 200 */     long t1 = System.currentTimeMillis();
/* 201 */     if (this.secureRandomClass != null) {
/*     */       
/*     */       try {
/* 204 */         Class<?> clazz = Class.forName(this.secureRandomClass);
/* 205 */         result = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 206 */       } catch (Exception e) {
/* 207 */         this.log.error(sm.getString("sessionIdGeneratorBase.random", new Object[] { this.secureRandomClass }), e);
/*     */       } 
/*     */     }
/*     */     
/* 211 */     boolean error = false;
/* 212 */     if (result == null) {
/*     */       
/*     */       try {
/* 215 */         if (this.secureRandomProvider != null && !this.secureRandomProvider.isEmpty()) {
/* 216 */           result = SecureRandom.getInstance(this.secureRandomAlgorithm, this.secureRandomProvider);
/* 217 */         } else if (this.secureRandomAlgorithm != null && !this.secureRandomAlgorithm.isEmpty()) {
/* 218 */           result = SecureRandom.getInstance(this.secureRandomAlgorithm);
/*     */         } 
/* 220 */       } catch (NoSuchAlgorithmException e) {
/* 221 */         error = true;
/* 222 */         this.log.error(sm.getString("sessionIdGeneratorBase.randomAlgorithm", new Object[] { this.secureRandomAlgorithm }), e);
/* 223 */       } catch (NoSuchProviderException e) {
/* 224 */         error = true;
/* 225 */         this.log.error(sm.getString("sessionIdGeneratorBase.randomProvider", new Object[] { this.secureRandomProvider }), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (result == null && error && !DEFAULT_SECURE_RANDOM_ALGORITHM.equals(this.secureRandomAlgorithm)) {
/*     */       
/*     */       try {
/* 234 */         result = SecureRandom.getInstance(DEFAULT_SECURE_RANDOM_ALGORITHM);
/* 235 */       } catch (NoSuchAlgorithmException e) {
/* 236 */         this.log.error(sm.getString("sessionIdGeneratorBase.randomAlgorithm", new Object[] { this.secureRandomAlgorithm }), e);
/*     */       } 
/*     */     }
/*     */     
/* 240 */     if (result == null)
/*     */     {
/* 242 */       result = new SecureRandom();
/*     */     }
/*     */ 
/*     */     
/* 246 */     result.nextInt();
/*     */     
/* 248 */     long t2 = System.currentTimeMillis();
/* 249 */     if (t2 - t1 > 100L) {
/* 250 */       this.log.warn(sm.getString("sessionIdGeneratorBase.createRandom", new Object[] { result.getAlgorithm(), Long.valueOf(t2 - t1) }));
/*     */     }
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 265 */     generateSessionId();
/*     */     
/* 267 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 273 */     setState(LifecycleState.STOPPING);
/* 274 */     this.randoms.clear();
/*     */   }
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalin\\util\SessionIdGeneratorBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */