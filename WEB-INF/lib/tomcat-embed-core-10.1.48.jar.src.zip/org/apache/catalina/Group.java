package org.apache.catalina;

import java.security.Principal;
import java.util.Iterator;

public interface Group extends Principal {
  String getDescription();
  
  void setDescription(String paramString);
  
  String getGroupname();
  
  void setGroupname(String paramString);
  
  Iterator<Role> getRoles();
  
  UserDatabase getUserDatabase();
  
  Iterator<User> getUsers();
  
  void addRole(Role paramRole);
  
  boolean isInRole(Role paramRole);
  
  void removeRole(Role paramRole);
  
  void removeRoles();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Group.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */