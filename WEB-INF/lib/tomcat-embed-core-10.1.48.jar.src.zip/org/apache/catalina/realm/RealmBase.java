/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import jakarta.servlet.annotation.ServletSecurity;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import org.apache.catalina.Contained;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.catalina.util.ToStringUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.HexUtils;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityCollection;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*      */ import org.ietf.jgss.GSSContext;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ import org.ietf.jgss.GSSName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RealmBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Realm
/*      */ {
/*   75 */   private static final Log log = LogFactory.getLog(RealmBase.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String USER_ATTRIBUTES_DELIMITER = ",";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String USER_ATTRIBUTES_WILDCARD = "*";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   92 */   private static final List<Class<? extends DigestCredentialHandlerBase>> credentialHandlerClasses = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*   99 */     credentialHandlerClasses.add(MessageDigestCredentialHandler.class);
/*  100 */     credentialHandlerClasses.add(SecretKeyCredentialHandler.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  109 */   protected Container container = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  115 */   protected Log containerLog = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CredentialHandler credentialHandler;
/*      */ 
/*      */ 
/*      */   
/*  124 */   protected static final StringManager sm = StringManager.getManager(RealmBase.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean validate = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String x509UsernameRetrieverClassName;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected X509UsernameRetriever x509UsernameRetriever;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   protected AllRolesMode allRolesMode = AllRolesMode.STRICT_MODE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean stripRealmForGss = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   private int transportGuaranteeRedirectStatus = 302;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  168 */   protected String userAttributes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   protected List<String> userAttributesList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTransportGuaranteeRedirectStatus() {
/*  185 */     return this.transportGuaranteeRedirectStatus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransportGuaranteeRedirectStatus(int transportGuaranteeRedirectStatus) {
/*  196 */     this.transportGuaranteeRedirectStatus = transportGuaranteeRedirectStatus;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CredentialHandler getCredentialHandler() {
/*  202 */     return this.credentialHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCredentialHandler(CredentialHandler credentialHandler) {
/*  208 */     this.credentialHandler = credentialHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Container getContainer() {
/*  214 */     return this.container;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContainer(Container container) {
/*  221 */     Container oldContainer = this.container;
/*  222 */     this.container = container;
/*  223 */     this.support.firePropertyChange("container", oldContainer, this.container);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAllRolesMode() {
/*  233 */     return this.allRolesMode.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllRolesMode(String allRolesMode) {
/*  243 */     this.allRolesMode = AllRolesMode.toMode(allRolesMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getValidate() {
/*  253 */     return this.validate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValidate(boolean validate) {
/*  264 */     this.validate = validate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getX509UsernameRetrieverClassName() {
/*  274 */     return this.x509UsernameRetrieverClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setX509UsernameRetrieverClassName(String className) {
/*  286 */     this.x509UsernameRetrieverClassName = className;
/*      */   }
/*      */   
/*      */   public boolean isStripRealmForGss() {
/*  290 */     return this.stripRealmForGss;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStripRealmForGss(boolean stripRealmForGss) {
/*  295 */     this.stripRealmForGss = stripRealmForGss;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserAttributes() {
/*  303 */     return this.userAttributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserAttributes(String userAttributes) {
/*  319 */     this.userAttributes = userAttributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/*  326 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username) {
/*  333 */     if (username == null) {
/*  334 */       return null;
/*      */     }
/*      */     
/*  337 */     if (this.containerLog.isTraceEnabled()) {
/*  338 */       this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */     }
/*      */     
/*  341 */     return getPrincipal(username);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username, String credentials) {
/*  349 */     if (username == null || credentials == null) {
/*  350 */       if (this.containerLog.isTraceEnabled()) {
/*  351 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*  353 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  357 */     String serverCredentials = getPassword(username);
/*      */     
/*  359 */     if (serverCredentials == null) {
/*      */ 
/*      */       
/*  362 */       getCredentialHandler().mutate(credentials);
/*      */       
/*  364 */       if (this.containerLog.isTraceEnabled()) {
/*  365 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*  367 */       return null;
/*      */     } 
/*      */     
/*  370 */     boolean validated = getCredentialHandler().matches(credentials, serverCredentials);
/*      */     
/*  372 */     if (validated) {
/*  373 */       if (this.containerLog.isTraceEnabled()) {
/*  374 */         this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */       }
/*  376 */       return getPrincipal(username);
/*      */     } 
/*  378 */     if (this.containerLog.isTraceEnabled()) {
/*  379 */       this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */     }
/*  381 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String digestA2) {
/*  390 */     return authenticate(username, clientDigest, nonce, nc, cnonce, qop, realm, digestA2, "MD5");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String digestA2, String algorithm) {
/*      */     String serverDigestValue;
/*      */     byte[] valueBytes;
/*  399 */     String digestA1 = getDigest(username, realm, algorithm);
/*  400 */     if (digestA1 == null) {
/*  401 */       return null;
/*      */     }
/*  403 */     digestA1 = digestA1.toLowerCase(Locale.ENGLISH);
/*      */     
/*  405 */     if (qop == null) {
/*  406 */       serverDigestValue = digestA1 + ":" + digestA1 + ":" + nonce;
/*      */     } else {
/*  408 */       serverDigestValue = digestA1 + ":" + digestA1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  413 */       valueBytes = serverDigestValue.getBytes(getDigestCharset());
/*  414 */     } catch (UnsupportedEncodingException uee) {
/*  415 */       throw new IllegalArgumentException(sm.getString("realmBase.invalidDigestEncoding", new Object[] { getDigestEncoding() }), uee);
/*      */     } 
/*      */ 
/*      */     
/*  419 */     String serverDigest = HexUtils.toHexString(ConcurrentMessageDigest.digest(algorithm, new byte[][] { valueBytes }));
/*      */     
/*  421 */     if (log.isTraceEnabled()) {
/*  422 */       log.trace("Digest : " + clientDigest + " Username:" + username + " ClientDigest:" + clientDigest + " nonce:" + nonce + " nc:" + nc + " cnonce:" + cnonce + " qop:" + qop + " realm:" + realm + "digestA2:" + digestA2 + " Server digest:" + serverDigest);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  427 */     if (serverDigest.equals(clientDigest)) {
/*  428 */       return getPrincipal(username);
/*      */     }
/*      */     
/*  431 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(X509Certificate[] certs) {
/*  438 */     if (certs == null || certs.length < 1) {
/*  439 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  443 */     if (log.isTraceEnabled()) {
/*  444 */       log.trace("Authenticating client certificate chain");
/*      */     }
/*  446 */     if (this.validate) {
/*  447 */       for (X509Certificate cert : certs) {
/*  448 */         if (log.isTraceEnabled()) {
/*  449 */           log.trace(" Checking validity for '" + cert.getSubjectX500Principal().toString() + "'");
/*      */         }
/*      */         try {
/*  452 */           cert.checkValidity();
/*  453 */         } catch (Exception e) {
/*  454 */           if (log.isDebugEnabled()) {
/*  455 */             log.debug(sm.getString("realmBase.validity"), e);
/*      */           }
/*  457 */           return null;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  463 */     return getPrincipal(certs[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(GSSContext gssContext, boolean storeCred) {
/*  469 */     if (gssContext.isEstablished()) {
/*  470 */       GSSName gssName = null;
/*      */       try {
/*  472 */         gssName = gssContext.getSrcName();
/*  473 */       } catch (GSSException e) {
/*  474 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/*      */       } 
/*      */       
/*  477 */       if (gssName != null) {
/*  478 */         GSSCredential gssCredential = null;
/*  479 */         if (storeCred) {
/*  480 */           if (gssContext.getCredDelegState()) {
/*      */             try {
/*  482 */               gssCredential = gssContext.getDelegCred();
/*  483 */             } catch (GSSException e) {
/*  484 */               log.warn(sm.getString("realmBase.delegatedCredentialFail", new Object[] { gssName }), e);
/*      */             }
/*      */           
/*  487 */           } else if (log.isTraceEnabled()) {
/*  488 */             log.trace(sm.getString("realmBase.credentialNotDelegated", new Object[] { gssName }));
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  493 */         return getPrincipal(gssName, gssCredential, gssContext);
/*      */       } 
/*      */     } else {
/*  496 */       log.error(sm.getString("realmBase.gssContextNotEstablished"));
/*      */     } 
/*      */ 
/*      */     
/*  500 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential) {
/*  506 */     if (gssName == null) {
/*  507 */       return null;
/*      */     }
/*      */     
/*  510 */     return getPrincipal(gssName, gssCredential);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundProcess() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SecurityConstraint[] findSecurityConstraints(Request request, Context context) {
/*  528 */     ArrayList<SecurityConstraint> results = null;
/*      */     
/*  530 */     SecurityConstraint[] constraints = context.findConstraints();
/*  531 */     if (constraints == null || constraints.length == 0) {
/*  532 */       if (log.isTraceEnabled()) {
/*  533 */         log.trace("  No applicable constraints defined");
/*      */       }
/*  535 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  539 */     String uri = request.getRequestPathMB().toString();
/*      */ 
/*      */     
/*  542 */     if (uri == null || uri.isEmpty()) {
/*  543 */       uri = "/";
/*      */     }
/*      */     
/*  546 */     String method = request.getMethod();
/*      */     
/*  548 */     boolean found = false; int i;
/*  549 */     for (i = 0; i < constraints.length; i++) {
/*  550 */       SecurityCollection[] collections = constraints[i].findCollections();
/*      */ 
/*      */ 
/*      */       
/*  554 */       if (collections != null) {
/*      */ 
/*      */ 
/*      */         
/*  558 */         if (log.isTraceEnabled()) {
/*  559 */           log.trace("  Checking constraint '" + String.valueOf(constraints[i]) + "' against " + method + " " + uri + " --> " + constraints[i]
/*  560 */               .included(uri, method));
/*      */         }
/*      */         
/*  563 */         for (SecurityCollection securityCollection : collections) {
/*  564 */           String[] patterns = securityCollection.findPatterns();
/*      */ 
/*      */ 
/*      */           
/*  568 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */             
/*  572 */             for (String pattern : patterns) {
/*      */               
/*  574 */               if (uri.equals(pattern) || (pattern.isEmpty() && uri.equals("/"))) {
/*  575 */                 found = true;
/*  576 */                 if (securityCollection.findMethod(method)) {
/*  577 */                   if (results == null) {
/*  578 */                     results = new ArrayList<>();
/*      */                   }
/*  580 */                   results.add(constraints[i]);
/*      */                 } 
/*      */               } 
/*      */             }  } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  587 */     if (found) {
/*  588 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  591 */     int longest = -1;
/*      */     
/*  593 */     for (i = 0; i < constraints.length; i++) {
/*  594 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */ 
/*      */ 
/*      */       
/*  598 */       if (collection != null) {
/*      */ 
/*      */ 
/*      */         
/*  602 */         if (log.isTraceEnabled()) {
/*  603 */           log.trace("  Checking constraint '" + String.valueOf(constraints[i]) + "' against " + method + " " + uri + " --> " + constraints[i]
/*  604 */               .included(uri, method));
/*      */         }
/*      */         
/*  607 */         for (SecurityCollection securityCollection : collection) {
/*  608 */           String[] patterns = securityCollection.findPatterns();
/*      */ 
/*      */ 
/*      */           
/*  612 */           if (patterns != null) {
/*      */ 
/*      */ 
/*      */             
/*  616 */             boolean matched = false;
/*  617 */             int length = -1;
/*  618 */             for (String pattern : patterns) {
/*  619 */               if (pattern.startsWith("/") && pattern.endsWith("/*") && pattern.length() >= longest)
/*      */               {
/*  621 */                 if (pattern.length() == 2) {
/*  622 */                   matched = true;
/*  623 */                   length = pattern.length();
/*  624 */                 } else if (pattern.regionMatches(0, uri, 0, pattern.length() - 1) || (pattern
/*  625 */                   .length() - 2 == uri.length() && pattern
/*  626 */                   .regionMatches(0, uri, 0, pattern.length() - 2))) {
/*  627 */                   matched = true;
/*  628 */                   length = pattern.length();
/*      */                 } 
/*      */               }
/*      */             } 
/*  632 */             if (matched) {
/*  633 */               if (length > longest) {
/*  634 */                 found = false;
/*  635 */                 if (results != null) {
/*  636 */                   results.clear();
/*      */                 }
/*  638 */                 longest = length;
/*      */               } 
/*  640 */               if (securityCollection.findMethod(method)) {
/*  641 */                 found = true;
/*  642 */                 if (results == null) {
/*  643 */                   results = new ArrayList<>();
/*      */                 }
/*  645 */                 results.add(constraints[i]);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  651 */     }  if (found) {
/*  652 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  655 */     for (i = 0; i < constraints.length; i++) {
/*  656 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */ 
/*      */ 
/*      */       
/*  660 */       if (collection != null) {
/*      */ 
/*      */ 
/*      */         
/*  664 */         if (log.isTraceEnabled()) {
/*  665 */           log.trace("  Checking constraint '" + String.valueOf(constraints[i]) + "' against " + method + " " + uri + " --> " + constraints[i]
/*  666 */               .included(uri, method));
/*      */         }
/*      */         
/*  669 */         boolean matched = false;
/*  670 */         int pos = -1;
/*  671 */         for (int j = 0; j < collection.length; j++) {
/*  672 */           String[] patterns = collection[j].findPatterns();
/*      */ 
/*      */ 
/*      */           
/*  676 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */             
/*  680 */             for (int k = 0; k < patterns.length && !matched; k++) {
/*  681 */               String pattern = patterns[k];
/*  682 */               if (pattern.startsWith("*.")) {
/*  683 */                 int slash = uri.lastIndexOf('/');
/*  684 */                 int dot = uri.lastIndexOf('.');
/*  685 */                 if (slash >= 0 && dot > slash && dot != uri.length() - 1 && uri
/*  686 */                   .length() - dot == pattern.length() - 1 && 
/*  687 */                   pattern.regionMatches(1, uri, dot, uri.length() - dot)) {
/*  688 */                   matched = true;
/*  689 */                   pos = j;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*  695 */         if (matched) {
/*  696 */           found = true;
/*  697 */           if (collection[pos].findMethod(method)) {
/*  698 */             if (results == null) {
/*  699 */               results = new ArrayList<>();
/*      */             }
/*  701 */             results.add(constraints[i]);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  706 */     if (found) {
/*  707 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  710 */     for (i = 0; i < constraints.length; i++) {
/*  711 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */ 
/*      */ 
/*      */       
/*  715 */       if (collection != null) {
/*      */ 
/*      */ 
/*      */         
/*  719 */         if (log.isTraceEnabled()) {
/*  720 */           log.trace("  Checking constraint '" + String.valueOf(constraints[i]) + "' against " + method + " " + uri + " --> " + constraints[i]
/*  721 */               .included(uri, method));
/*      */         }
/*      */         
/*  724 */         for (SecurityCollection securityCollection : collection) {
/*  725 */           String[] patterns = securityCollection.findPatterns();
/*      */ 
/*      */ 
/*      */           
/*  729 */           if (patterns != null) {
/*      */ 
/*      */ 
/*      */             
/*  733 */             boolean matched = false;
/*  734 */             for (String pattern : patterns) {
/*  735 */               if (pattern.equals("/")) {
/*  736 */                 matched = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/*  740 */             if (matched) {
/*  741 */               if (results == null) {
/*  742 */                 results = new ArrayList<>();
/*      */               }
/*  744 */               results.add(constraints[i]);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  749 */     }  if (results == null)
/*      */     {
/*  751 */       if (log.isTraceEnabled()) {
/*  752 */         log.trace("  No applicable constraint located");
/*      */       }
/*      */     }
/*  755 */     return resultsToArray(results);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SecurityConstraint[] resultsToArray(ArrayList<SecurityConstraint> results) {
/*  762 */     if (results == null || results.isEmpty()) {
/*  763 */       return null;
/*      */     }
/*  765 */     return results.<SecurityConstraint>toArray(new SecurityConstraint[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasResourcePermission(Request request, Response response, SecurityConstraint[] constraints, Context context) throws IOException {
/*  773 */     if (constraints == null || constraints.length == 0) {
/*  774 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  778 */     Principal principal = request.getPrincipal();
/*  779 */     boolean status = false;
/*  780 */     boolean denyfromall = false;
/*  781 */     for (SecurityConstraint constraint : constraints) {
/*      */       String[] roles;
/*  783 */       if (constraint.getAllRoles()) {
/*      */         
/*  785 */         roles = request.getContext().findSecurityRoles();
/*      */       } else {
/*  787 */         roles = constraint.findAuthRoles();
/*      */       } 
/*      */       
/*  790 */       if (roles == null) {
/*  791 */         roles = new String[0];
/*      */       }
/*      */       
/*  794 */       if (log.isTraceEnabled()) {
/*  795 */         log.trace("  Checking roles " + String.valueOf(principal));
/*      */       }
/*      */       
/*  798 */       if (constraint.getAuthenticatedUsers() && principal != null) {
/*  799 */         if (log.isTraceEnabled()) {
/*  800 */           log.trace("Passing all authenticated users");
/*      */         }
/*  802 */         status = true;
/*  803 */       } else if (roles.length == 0 && !constraint.getAllRoles() && !constraint.getAuthenticatedUsers()) {
/*  804 */         if (constraint.getAuthConstraint()) {
/*  805 */           if (log.isTraceEnabled()) {
/*  806 */             log.trace("No roles");
/*      */           }
/*  808 */           status = false;
/*  809 */           denyfromall = true;
/*      */           
/*      */           break;
/*      */         } 
/*  813 */         if (log.isTraceEnabled()) {
/*  814 */           log.trace("Passing all access");
/*      */         }
/*  816 */         status = true;
/*  817 */       } else if (principal == null) {
/*  818 */         if (log.isTraceEnabled()) {
/*  819 */           log.trace("  No user authenticated, cannot grant access");
/*      */         }
/*      */       } else {
/*  822 */         for (String role : roles) {
/*  823 */           if (hasRole(request.getWrapper(), principal, role)) {
/*  824 */             status = true;
/*  825 */             if (log.isTraceEnabled()) {
/*  826 */               log.trace("Role found:  " + role);
/*      */             }
/*  828 */           } else if (log.isTraceEnabled()) {
/*  829 */             log.trace("No role found:  " + role);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  835 */     if (!denyfromall && this.allRolesMode != AllRolesMode.STRICT_MODE && !status && principal != null) {
/*  836 */       if (log.isTraceEnabled()) {
/*  837 */         log.trace("Checking for all roles mode: " + String.valueOf(this.allRolesMode));
/*      */       }
/*      */       
/*  840 */       for (SecurityConstraint constraint : constraints) {
/*      */         
/*  842 */         if (constraint.getAllRoles()) {
/*  843 */           if (this.allRolesMode == AllRolesMode.AUTH_ONLY_MODE) {
/*  844 */             if (log.isTraceEnabled()) {
/*  845 */               log.trace("Granting access for role-name=*, auth-only");
/*      */             }
/*  847 */             status = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  852 */           String[] roles = request.getContext().findSecurityRoles();
/*  853 */           if (roles == null) {
/*  854 */             roles = new String[0];
/*      */           }
/*  856 */           if (roles.length == 0 && this.allRolesMode == AllRolesMode.STRICT_AUTH_ONLY_MODE) {
/*  857 */             if (log.isTraceEnabled()) {
/*  858 */               log.trace("Granting access for role-name=*, strict auth-only");
/*      */             }
/*  860 */             status = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  868 */     if (!status) {
/*  869 */       response.sendError(403, sm.getString("realmBase.forbidden"));
/*      */     }
/*  871 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasRole(Wrapper wrapper, Principal principal, String role) {
/*  886 */     if (wrapper != null) {
/*  887 */       String realRole = wrapper.findSecurityReference(role);
/*  888 */       if (realRole != null) {
/*  889 */         role = realRole;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  894 */     if (principal == null || role == null) {
/*  895 */       return false;
/*      */     }
/*      */     
/*  898 */     boolean result = hasRoleInternal(principal, role);
/*      */     
/*  900 */     if (log.isTraceEnabled()) {
/*  901 */       String name = principal.getName();
/*  902 */       if (result) {
/*  903 */         log.trace(sm.getString("realmBase.hasRoleSuccess", new Object[] { name, role }));
/*      */       } else {
/*  905 */         log.trace(sm.getString("realmBase.hasRoleFailure", new Object[] { name, role }));
/*      */       } 
/*      */     } 
/*      */     
/*  909 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> parseUserAttributes(String userAttributes) {
/*  924 */     if (userAttributes == null) {
/*  925 */       return null;
/*      */     }
/*  927 */     List<String> attrs = new ArrayList<>();
/*  928 */     for (String name : userAttributes.split(",")) {
/*  929 */       name = name.trim();
/*  930 */       if (!name.isEmpty()) {
/*      */ 
/*      */         
/*  933 */         if (name.equals("*")) {
/*  934 */           return Collections.singletonList("*");
/*      */         }
/*  936 */         if (!attrs.contains(name))
/*      */         {
/*      */ 
/*      */           
/*  940 */           attrs.add(name); } 
/*      */       } 
/*  942 */     }  return !attrs.isEmpty() ? attrs : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasRoleInternal(Principal principal, String role) {
/*  960 */     if (!(principal instanceof GenericPrincipal)) {
/*  961 */       return false;
/*      */     }
/*      */     
/*  964 */     GenericPrincipal gp = (GenericPrincipal)principal;
/*  965 */     return gp.hasRole(role);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasUserDataPermission(Request request, Response response, SecurityConstraint[] constraints) throws IOException {
/*  974 */     if (constraints == null || constraints.length == 0) {
/*  975 */       if (log.isTraceEnabled()) {
/*  976 */         log.trace("  No applicable security constraint defined");
/*      */       }
/*  978 */       return true;
/*      */     } 
/*  980 */     for (SecurityConstraint constraint : constraints) {
/*  981 */       String userConstraint = constraint.getUserConstraint();
/*  982 */       if (userConstraint == null) {
/*  983 */         if (log.isTraceEnabled()) {
/*  984 */           log.trace("  No applicable user data constraint defined");
/*      */         }
/*  986 */         return true;
/*      */       } 
/*  988 */       if (userConstraint.equals(ServletSecurity.TransportGuarantee.NONE.name())) {
/*  989 */         if (log.isTraceEnabled()) {
/*  990 */           log.trace("  User data constraint has no restrictions");
/*      */         }
/*  992 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  997 */     if (request.getRequest().isSecure()) {
/*  998 */       if (log.isTraceEnabled()) {
/*  999 */         log.trace("  User data constraint already satisfied");
/*      */       }
/* 1001 */       return true;
/*      */     } 
/*      */     
/* 1004 */     int redirectPort = request.getConnector().getRedirectPortWithOffset();
/*      */ 
/*      */     
/* 1007 */     if (redirectPort <= 0) {
/* 1008 */       if (log.isTraceEnabled()) {
/* 1009 */         log.trace("  SSL redirect is disabled");
/*      */       }
/* 1011 */       response.sendError(403, request.getRequestURI());
/* 1012 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1016 */     StringBuilder file = new StringBuilder();
/* 1017 */     String protocol = "https";
/* 1018 */     String host = request.getServerName();
/*      */     
/* 1020 */     file.append(protocol).append("://").append(host);
/*      */     
/* 1022 */     if (redirectPort != 443) {
/* 1023 */       file.append(':').append(redirectPort);
/*      */     }
/*      */     
/* 1026 */     file.append(request.getRequestURI());
/* 1027 */     String requestedSessionId = request.getRequestedSessionId();
/* 1028 */     if (requestedSessionId != null && request.isRequestedSessionIdFromURL()) {
/* 1029 */       file.append(';');
/* 1030 */       file.append(SessionConfig.getSessionUriParamName(request.getContext()));
/* 1031 */       file.append('=');
/* 1032 */       file.append(requestedSessionId);
/*      */     } 
/* 1034 */     String queryString = request.getQueryString();
/* 1035 */     if (queryString != null) {
/* 1036 */       file.append('?');
/* 1037 */       file.append(queryString);
/*      */     } 
/* 1039 */     if (log.isTraceEnabled()) {
/* 1040 */       log.trace("  Redirecting to " + file.toString());
/*      */     }
/* 1042 */     response.sendRedirect(file.toString(), this.transportGuaranteeRedirectStatus);
/* 1043 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 1050 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initInternal() throws LifecycleException {
/* 1057 */     super.initInternal();
/*      */ 
/*      */     
/* 1060 */     if (this.container != null) {
/* 1061 */       this.containerLog = this.container.getLogger();
/*      */     }
/*      */     
/* 1064 */     this.x509UsernameRetriever = createUsernameRetriever(this.x509UsernameRetrieverClassName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/* 1077 */     if (this.credentialHandler == null) {
/* 1078 */       this.credentialHandler = new MessageDigestCredentialHandler();
/*      */     }
/* 1080 */     if (this.userAttributes != null) {
/* 1081 */       this.userAttributesList = parseUserAttributes(this.userAttributes);
/*      */     }
/* 1083 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/* 1095 */     setState(LifecycleState.STOPPING);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1101 */     return ToStringUtil.toString((Contained)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasMessageDigest(String algorithm) {
/* 1108 */     CredentialHandler ch = this.credentialHandler;
/* 1109 */     if (ch instanceof MessageDigestCredentialHandler) {
/* 1110 */       String realmAlgorithm = ((MessageDigestCredentialHandler)ch).getAlgorithm();
/* 1111 */       if (realmAlgorithm != null) {
/* 1112 */         if (realmAlgorithm.equals(algorithm)) {
/* 1113 */           return true;
/*      */         }
/* 1115 */         log.debug(sm.getString("relamBase.digestMismatch", new Object[] { algorithm, realmAlgorithm }));
/*      */       } 
/*      */     } 
/*      */     
/* 1119 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getDigest(String username, String realmName) {
/* 1135 */     return getDigest(username, realmName, "MD5");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDigest(String username, String realmName, String algorithm) {
/*      */     byte[] valueBytes;
/* 1149 */     if (hasMessageDigest(algorithm))
/*      */     {
/* 1151 */       return getPassword(username);
/*      */     }
/*      */     
/* 1154 */     String digestValue = username + ":" + username + ":" + realmName;
/*      */ 
/*      */     
/*      */     try {
/* 1158 */       valueBytes = digestValue.getBytes(getDigestCharset());
/* 1159 */     } catch (UnsupportedEncodingException uee) {
/* 1160 */       throw new IllegalArgumentException(sm.getString("realmBase.invalidDigestEncoding", new Object[] { getDigestEncoding() }), uee);
/*      */     } 
/*      */ 
/*      */     
/* 1164 */     return HexUtils.toHexString(ConcurrentMessageDigest.digest(algorithm, new byte[][] { valueBytes }));
/*      */   }
/*      */ 
/*      */   
/*      */   private String getDigestEncoding() {
/* 1169 */     CredentialHandler ch = this.credentialHandler;
/* 1170 */     if (ch instanceof MessageDigestCredentialHandler) {
/* 1171 */       return ((MessageDigestCredentialHandler)ch).getEncoding();
/*      */     }
/* 1173 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Charset getDigestCharset() throws UnsupportedEncodingException {
/* 1178 */     String charset = getDigestEncoding();
/* 1179 */     if (charset == null) {
/* 1180 */       return StandardCharsets.ISO_8859_1;
/*      */     }
/* 1182 */     return B2CConverter.getCharset(charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(X509Certificate usercert) {
/* 1205 */     String username = this.x509UsernameRetriever.getUsername(usercert);
/*      */     
/* 1207 */     if (log.isTraceEnabled()) {
/* 1208 */       log.trace(sm.getString("realmBase.gotX509Username", new Object[] { username }));
/*      */     }
/*      */     
/* 1211 */     return getPrincipal(username);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(GSSName gssName, GSSCredential gssCredential, GSSContext gssContext) {
/* 1235 */     return getPrincipal(gssName, gssCredential);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(GSSName gssName, GSSCredential gssCredential) {
/* 1248 */     String name = gssName.toString();
/*      */     
/* 1250 */     if (isStripRealmForGss()) {
/* 1251 */       int i = name.indexOf('@');
/* 1252 */       if (i > 0)
/*      */       {
/* 1254 */         name = name.substring(0, i);
/*      */       }
/*      */     } 
/*      */     
/* 1258 */     Principal p = getPrincipal(name);
/*      */     
/* 1260 */     if (p instanceof GenericPrincipal) {
/* 1261 */       ((GenericPrincipal)p).setGssCredential(gssCredential);
/*      */     }
/*      */     
/* 1264 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Server getServer() {
/* 1275 */     Container c = this.container;
/* 1276 */     if (c instanceof Context) {
/* 1277 */       c = c.getParent();
/*      */     }
/* 1279 */     if (c instanceof org.apache.catalina.Host) {
/* 1280 */       c = c.getParent();
/*      */     }
/* 1282 */     if (c instanceof Engine) {
/* 1283 */       Service s = ((Engine)c).getService();
/* 1284 */       if (s != null) {
/* 1285 */         return s.getServer();
/*      */       }
/*      */     } 
/* 1288 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) throws IOException {
/* 1331 */     int saltLength = -1;
/* 1332 */     int iterations = -1;
/* 1333 */     int keyLength = -1;
/*      */     
/* 1335 */     String encoding = Charset.defaultCharset().name();
/*      */ 
/*      */     
/* 1338 */     String algorithm = null;
/* 1339 */     String handlerClassName = null;
/*      */     
/* 1341 */     String passwordFile = null;
/*      */     
/* 1343 */     if (args.length == 0) {
/* 1344 */       usage();
/*      */       
/*      */       return;
/*      */     } 
/* 1348 */     int argIndex = 0;
/*      */     
/* 1350 */     boolean endOfList = false;
/*      */ 
/*      */ 
/*      */     
/* 1354 */     while (args.length > argIndex + 1 && args[argIndex].length() == 2 && args[argIndex].charAt(0) == '-' && !endOfList) {
/*      */       
/* 1356 */       switch (args[argIndex].charAt(1)) {
/*      */         case 'a':
/* 1358 */           algorithm = args[argIndex + 1];
/*      */           break;
/*      */         
/*      */         case 'e':
/* 1362 */           encoding = args[argIndex + 1];
/*      */           break;
/*      */         
/*      */         case 'i':
/* 1366 */           iterations = Integer.parseInt(args[argIndex + 1]);
/*      */           break;
/*      */         
/*      */         case 's':
/* 1370 */           saltLength = Integer.parseInt(args[argIndex + 1]);
/*      */           break;
/*      */         
/*      */         case 'k':
/* 1374 */           keyLength = Integer.parseInt(args[argIndex + 1]);
/*      */           break;
/*      */         
/*      */         case 'h':
/* 1378 */           handlerClassName = args[argIndex + 1];
/*      */           break;
/*      */         
/*      */         case 'f':
/* 1382 */           passwordFile = args[argIndex + 1];
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1387 */           endOfList = true;
/*      */ 
/*      */           
/* 1390 */           argIndex--;
/*      */           break;
/*      */         
/*      */         default:
/* 1394 */           usage();
/*      */           return;
/*      */       } 
/*      */       
/* 1398 */       argIndex += 2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1410 */     if (algorithm == null && handlerClassName == null) {
/* 1411 */       algorithm = "SHA-512";
/*      */     }
/*      */     
/* 1414 */     CredentialHandler handler = null;
/*      */     
/* 1416 */     if (handlerClassName == null) {
/* 1417 */       for (Class<? extends DigestCredentialHandlerBase> clazz : credentialHandlerClasses) {
/*      */         try {
/* 1419 */           handler = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1420 */           if (IntrospectionUtils.setProperty(handler, "algorithm", algorithm)) {
/*      */             break;
/*      */           }
/* 1423 */         } catch (ReflectiveOperationException e) {
/*      */           
/* 1425 */           throw new RuntimeException(e);
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1430 */         Class<?> clazz = Class.forName(handlerClassName);
/* 1431 */         handler = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1432 */         IntrospectionUtils.setProperty(handler, "algorithm", algorithm);
/* 1433 */       } catch (ReflectiveOperationException e) {
/* 1434 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } 
/*      */     
/* 1438 */     if (handler == null) {
/* 1439 */       throw new RuntimeException(new NoSuchAlgorithmException(algorithm));
/*      */     }
/*      */     
/* 1442 */     IntrospectionUtils.setProperty(handler, "encoding", encoding);
/* 1443 */     if (iterations > 0) {
/* 1444 */       IntrospectionUtils.setProperty(handler, "iterations", Integer.toString(iterations));
/*      */     }
/* 1446 */     if (saltLength > -1) {
/* 1447 */       IntrospectionUtils.setProperty(handler, "saltLength", Integer.toString(saltLength));
/*      */     }
/* 1449 */     if (keyLength > 0) {
/* 1450 */       IntrospectionUtils.setProperty(handler, "keyLength", Integer.toString(keyLength));
/*      */     }
/* 1452 */     if (passwordFile != null) {
/*      */       
/* 1454 */       argIndex = args.length;
/*      */ 
/*      */ 
/*      */       
/* 1458 */       try { BufferedReader br = passwordFile.equals("-") ? new BufferedReader(new InputStreamReader(System.in)) : new BufferedReader(new FileReader(passwordFile)); 
/*      */         try { String line;
/* 1460 */           while ((line = br.readLine()) != null)
/*      */           {
/* 1462 */             mutateCredential(line, handler);
/*      */           }
/* 1464 */           if (br != null) br.close();  } catch (Throwable throwable) { if (br != null) try { br.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception e)
/*      */       
/*      */       { 
/* 1467 */         if (e instanceof java.io.FileNotFoundException) {
/* 1468 */           System.err.println("cannot stat '" + passwordFile + "': No such file or directory");
/*      */ 
/*      */           
/* 1471 */           System.exit(1);
/*      */         } else {
/* 1473 */           throw e;
/*      */         }  }
/*      */     
/*      */     } 
/* 1477 */     for (; argIndex < args.length; argIndex++) {
/* 1478 */       mutateCredential(args[argIndex], handler);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void mutateCredential(String credential, CredentialHandler handler) {
/* 1483 */     System.out.print(credential + ":");
/* 1484 */     System.out.println(handler.mutate(credential));
/*      */   }
/*      */   
/*      */   private static void usage() {
/* 1488 */     System.out.println("Usage: RealmBase [-a <algorithm>] [-e <encoding>] [-i <iterations>] [-s <salt-length>] [-k <key-length>] [-h <handler-class-name>] | <XX credentials>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getObjectNameKeyProperties() {
/* 1498 */     return "type=Realm" + getRealmSuffix() + this.container.getMBeanKeyProperties();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDomainInternal() {
/* 1503 */     return this.container.getDomain();
/*      */   }
/*      */   
/* 1506 */   protected String realmPath = "/realm0";
/*      */   
/*      */   public String getRealmPath() {
/* 1509 */     return this.realmPath;
/*      */   }
/*      */   
/*      */   public void setRealmPath(String theRealmPath) {
/* 1513 */     this.realmPath = theRealmPath;
/*      */   }
/*      */   
/*      */   protected String getRealmSuffix() {
/* 1517 */     return ",realmPath=" + getRealmPath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class AllRolesMode
/*      */   {
/*      */     private final String name;
/*      */ 
/*      */     
/* 1528 */     public static final AllRolesMode STRICT_MODE = new AllRolesMode("strict");
/*      */     
/* 1530 */     public static final AllRolesMode AUTH_ONLY_MODE = new AllRolesMode("authOnly");
/*      */ 
/*      */ 
/*      */     
/* 1534 */     public static final AllRolesMode STRICT_AUTH_ONLY_MODE = new AllRolesMode("strictAuthOnly");
/*      */     
/*      */     static AllRolesMode toMode(String name) {
/*      */       AllRolesMode mode;
/* 1538 */       if (name.equalsIgnoreCase(STRICT_MODE.name)) {
/* 1539 */         mode = STRICT_MODE;
/* 1540 */       } else if (name.equalsIgnoreCase(AUTH_ONLY_MODE.name)) {
/* 1541 */         mode = AUTH_ONLY_MODE;
/* 1542 */       } else if (name.equalsIgnoreCase(STRICT_AUTH_ONLY_MODE.name)) {
/* 1543 */         mode = STRICT_AUTH_ONLY_MODE;
/*      */       } else {
/* 1545 */         throw new IllegalStateException(RealmBase.sm.getString("realmBase.unknownAllRolesMode", new Object[] { name }));
/*      */       } 
/* 1547 */       return mode;
/*      */     }
/*      */     
/*      */     private AllRolesMode(String name) {
/* 1551 */       this.name = name;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1556 */       boolean equals = false;
/* 1557 */       if (o instanceof AllRolesMode) {
/* 1558 */         AllRolesMode mode = (AllRolesMode)o;
/* 1559 */         equals = this.name.equals(mode.name);
/*      */       } 
/* 1561 */       return equals;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1566 */       return this.name.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1571 */       return this.name;
/*      */     }
/*      */   }
/*      */   
/*      */   private static X509UsernameRetriever createUsernameRetriever(String className) throws LifecycleException {
/* 1576 */     if (null == className || className.trim().isEmpty()) {
/* 1577 */       return new X509SubjectDnRetriever();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1583 */       Class<? extends X509UsernameRetriever> clazz = (Class)Class.forName(className);
/* 1584 */       return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1585 */     } catch (ReflectiveOperationException e) {
/* 1586 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.newInstance", new Object[] { className }), e);
/* 1587 */     } catch (ClassCastException e) {
/* 1588 */       throw new LifecycleException(sm
/* 1589 */           .getString("realmBase.createUsernameRetriever.ClassCastException", new Object[] { className }), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected abstract String getPassword(String paramString);
/*      */   
/*      */   protected abstract Principal getPrincipal(String paramString);
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\RealmBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */