/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import javax.naming.Context;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.naming.ContextBindings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceRealm
/*     */   extends RealmBase
/*     */ {
/*  47 */   private String preparedRoles = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private String preparedCredentials = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected String dataSourceName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean localDataSource = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected String roleNameCol = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected String userCredCol = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected String userNameCol = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   protected String userRoleTable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   protected String userTable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean connectionSuccess = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/* 111 */     return this.dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String dataSourceName) {
/* 120 */     this.dataSourceName = dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLocalDataSource() {
/* 127 */     return this.localDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalDataSource(boolean localDataSource) {
/* 136 */     this.localDataSource = localDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRoleNameCol() {
/* 143 */     return this.roleNameCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoleNameCol(String roleNameCol) {
/* 152 */     this.roleNameCol = roleNameCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserCredCol() {
/* 159 */     return this.userCredCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserCredCol(String userCredCol) {
/* 168 */     this.userCredCol = userCredCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserNameCol() {
/* 175 */     return this.userNameCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserNameCol(String userNameCol) {
/* 184 */     this.userNameCol = userNameCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserRoleTable() {
/* 191 */     return this.userRoleTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserRoleTable(String userRoleTable) {
/* 200 */     this.userRoleTable = userRoleTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserTable() {
/* 207 */     return this.userTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserTable(String userTable) {
/* 216 */     this.userTable = userTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal authenticate(String username, String credentials) {
/* 234 */     if (username == null || credentials == null) {
/* 235 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 239 */     Connection dbConnection = open();
/* 240 */     if (dbConnection == null)
/*     */     {
/* 242 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 247 */       return authenticate(dbConnection, username, credentials);
/*     */     } finally {
/* 249 */       close(dbConnection);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/* 256 */     return this.connectionSuccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal authenticate(Connection dbConnection, String username, String credentials) {
/* 278 */     if (username == null || credentials == null) {
/* 279 */       if (this.containerLog.isTraceEnabled()) {
/* 280 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 282 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 286 */     String dbCredentials = getPassword(dbConnection, username);
/*     */     
/* 288 */     if (dbCredentials == null) {
/*     */ 
/*     */       
/* 291 */       getCredentialHandler().mutate(credentials);
/*     */       
/* 293 */       if (this.containerLog.isTraceEnabled()) {
/* 294 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 296 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 300 */     boolean validated = getCredentialHandler().matches(credentials, dbCredentials);
/*     */     
/* 302 */     if (validated) {
/* 303 */       if (this.containerLog.isTraceEnabled()) {
/* 304 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/*     */     } else {
/* 307 */       if (this.containerLog.isTraceEnabled()) {
/* 308 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 310 */       return null;
/*     */     } 
/*     */     
/* 313 */     ArrayList<String> list = getRoles(dbConnection, username);
/*     */ 
/*     */     
/* 316 */     return (Principal)new GenericPrincipal(username, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void close(Connection dbConnection) {
/* 328 */     if (dbConnection == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 334 */       if (!dbConnection.getAutoCommit()) {
/* 335 */         dbConnection.commit();
/*     */       }
/* 337 */     } catch (SQLException e) {
/* 338 */       this.containerLog.error(sm.getString("dataSourceRealm.commit"), e);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 343 */       dbConnection.close();
/* 344 */     } catch (SQLException e) {
/* 345 */       this.containerLog.error(sm.getString("dataSourceRealm.close"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection open() {
/*     */     try {
/*     */       Context context;
/* 359 */       if (this.localDataSource) {
/* 360 */         context = ContextBindings.getClassLoader();
/* 361 */         context = (Context)context.lookup("comp/env");
/*     */       } else {
/* 363 */         Server server = getServer();
/* 364 */         if (server == null) {
/* 365 */           this.connectionSuccess = false;
/* 366 */           this.containerLog.error(sm.getString("dataSourceRealm.noNamingContext"));
/* 367 */           return null;
/*     */         } 
/* 369 */         context = server.getGlobalNamingContext();
/*     */       } 
/* 371 */       DataSource dataSource = (DataSource)context.lookup(this.dataSourceName);
/* 372 */       Connection connection = dataSource.getConnection();
/* 373 */       this.connectionSuccess = true;
/* 374 */       return connection;
/* 375 */     } catch (Exception e) {
/* 376 */       this.connectionSuccess = false;
/*     */       
/* 378 */       this.containerLog.error(sm.getString("dataSourceRealm.exception"), e);
/*     */       
/* 380 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPassword(String username) {
/* 387 */     Connection dbConnection = open();
/* 388 */     if (dbConnection == null) {
/* 389 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 393 */       return getPassword(dbConnection, username);
/*     */     } finally {
/* 395 */       close(dbConnection);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPassword(Connection dbConnection, String username) {
/* 410 */     String dbCredentials = null;
/*     */     
/* 412 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedCredentials); 
/* 413 */       try { stmt.setString(1, username);
/*     */         
/* 415 */         ResultSet rs = stmt.executeQuery(); 
/* 416 */         try { if (rs.next()) {
/* 417 */             dbCredentials = rs.getString(1);
/*     */           }
/*     */           
/* 420 */           String str = (dbCredentials != null) ? dbCredentials.trim() : null;
/* 421 */           if (rs != null) rs.close(); 
/* 422 */           if (stmt != null) stmt.close();  return str; } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 423 */     { this.containerLog.error(sm.getString("dataSourceRealm.getPassword.exception", new Object[] { username }), e);
/*     */ 
/*     */       
/* 426 */       return null; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected Principal getPrincipal(String username) {
/* 432 */     Connection dbConnection = open();
/* 433 */     if (dbConnection == null) {
/* 434 */       return (Principal)new GenericPrincipal(username, null);
/*     */     }
/*     */     try {
/* 437 */       return (Principal)new GenericPrincipal(username, getRoles(dbConnection, username));
/*     */     } finally {
/* 439 */       close(dbConnection);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArrayList<String> getRoles(String username) {
/* 454 */     Connection dbConnection = open();
/* 455 */     if (dbConnection == null) {
/* 456 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 460 */       return getRoles(dbConnection, username);
/*     */     } finally {
/* 462 */       close(dbConnection);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArrayList<String> getRoles(Connection dbConnection, String username) {
/* 477 */     if (this.allRolesMode != RealmBase.AllRolesMode.STRICT_MODE && !isRoleStoreDefined())
/*     */     {
/*     */       
/* 480 */       return null;
/*     */     }
/*     */     
/* 483 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedRoles); 
/* 484 */       try { stmt.setString(1, username);
/*     */         
/* 486 */         ResultSet rs = stmt.executeQuery(); 
/* 487 */         try { ArrayList<String> list = new ArrayList<>();
/* 488 */           while (rs.next()) {
/* 489 */             String role = rs.getString(1);
/* 490 */             if (role != null) {
/* 491 */               list.add(role.trim());
/*     */             }
/*     */           } 
/* 494 */           ArrayList<String> arrayList1 = list;
/* 495 */           if (rs != null) rs.close(); 
/* 496 */           if (stmt != null) stmt.close();  return arrayList1; } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 497 */     { this.containerLog.error(sm.getString("dataSourceRealm.getRoles.exception", new Object[] { username }), e);
/*     */ 
/*     */       
/* 500 */       return null; }
/*     */   
/*     */   }
/*     */   
/*     */   private boolean isRoleStoreDefined() {
/* 505 */     return (this.userRoleTable != null || this.roleNameCol != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 515 */     StringBuilder temp = new StringBuilder("SELECT ");
/* 516 */     temp.append(this.roleNameCol);
/* 517 */     temp.append(" FROM ");
/* 518 */     temp.append(this.userRoleTable);
/* 519 */     temp.append(" WHERE ");
/* 520 */     temp.append(this.userNameCol);
/* 521 */     temp.append(" = ?");
/* 522 */     this.preparedRoles = temp.toString();
/*     */ 
/*     */     
/* 525 */     temp = new StringBuilder("SELECT ");
/* 526 */     temp.append(this.userCredCol);
/* 527 */     temp.append(" FROM ");
/* 528 */     temp.append(this.userTable);
/* 529 */     temp.append(" WHERE ");
/* 530 */     temp.append(this.userNameCol);
/* 531 */     temp.append(" = ?");
/* 532 */     this.preparedCredentials = temp.toString();
/*     */     
/* 534 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\DataSourceRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */