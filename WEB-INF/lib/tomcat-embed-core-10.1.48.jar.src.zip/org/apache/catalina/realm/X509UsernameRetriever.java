package org.apache.catalina.realm;

import java.security.cert.X509Certificate;

public interface X509UsernameRetriever {
  String getUsername(X509Certificate paramX509Certificate);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\X509UsernameRetriever.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */