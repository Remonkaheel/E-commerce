/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecretKeyCredentialHandler
/*     */   extends DigestCredentialHandlerBase
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(SecretKeyCredentialHandler.class);
/*     */   
/*     */   public static final String DEFAULT_ALGORITHM = "PBKDF2WithHmacSHA1";
/*     */   
/*     */   public static final int DEFAULT_KEY_LENGTH = 160;
/*     */   
/*     */   public static final int DEFAULT_ITERATIONS = 20000;
/*     */   private SecretKeyFactory secretKeyFactory;
/*  40 */   private int keyLength = 160;
/*     */ 
/*     */   
/*     */   public SecretKeyCredentialHandler() throws NoSuchAlgorithmException {
/*  44 */     setAlgorithm("PBKDF2WithHmacSHA1");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlgorithm() {
/*  50 */     return this.secretKeyFactory.getAlgorithm();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlgorithm(String algorithm) throws NoSuchAlgorithmException {
/*  56 */     this.secretKeyFactory = SecretKeyFactory.getInstance(algorithm);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKeyLength() {
/*  61 */     return this.keyLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeyLength(int keyLength) {
/*  66 */     this.keyLength = keyLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(String inputCredentials, String storedCredentials) {
/*  72 */     return matchesSaltIterationsEncoded(inputCredentials, storedCredentials);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String mutate(String inputCredentials, byte[] salt, int iterations) {
/*  78 */     return mutate(inputCredentials, salt, iterations, getKeyLength());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String mutate(String inputCredentials, byte[] salt, int iterations, int keyLength) {
/*     */     try {
/*  85 */       KeySpec spec = new PBEKeySpec(inputCredentials.toCharArray(), salt, iterations, keyLength);
/*  86 */       return HexUtils.toHexString(this.secretKeyFactory.generateSecret(spec).getEncoded());
/*  87 */     } catch (InvalidKeySpecException|IllegalArgumentException e) {
/*  88 */       log.warn(sm.getString("pbeCredentialHandler.invalidKeySpec"), e);
/*  89 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultIterations() {
/*  96 */     return 20000;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLog() {
/* 102 */     return log;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\SecretKeyCredentialHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */