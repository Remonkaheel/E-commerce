/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.catalina.CredentialHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NestedCredentialHandler
/*    */   implements CredentialHandler
/*    */ {
/* 26 */   private final List<CredentialHandler> credentialHandlers = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(String inputCredentials, String storedCredentials) {
/* 31 */     for (CredentialHandler handler : this.credentialHandlers) {
/* 32 */       if (handler.matches(inputCredentials, storedCredentials)) {
/* 33 */         return true;
/*    */       }
/*    */     } 
/* 36 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String mutate(String inputCredentials) {
/* 46 */     if (this.credentialHandlers.isEmpty()) {
/* 47 */       return null;
/*    */     }
/*    */     
/* 50 */     return ((CredentialHandler)this.credentialHandlers.get(0)).mutate(inputCredentials);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCredentialHandler(CredentialHandler handler) {
/* 55 */     this.credentialHandlers.add(handler);
/*    */   }
/*    */   
/*    */   public CredentialHandler[] getCredentialHandlers() {
/* 59 */     return this.credentialHandlers.<CredentialHandler>toArray(new CredentialHandler[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\NestedCredentialHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */