/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.TextInputCallback;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAASCallbackHandler
/*     */   implements CallbackHandler
/*     */ {
/*     */   public JAASCallbackHandler(JAASRealm realm, String username, String password) {
/*  57 */     this(realm, username, password, null, null, null, null, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JAASCallbackHandler(JAASRealm realm, String username, String password, String nonce, String nc, String cnonce, String qop, String realmName, String digestA2, String algorithm, String authMethod) {
/*  78 */     this.realm = realm;
/*  79 */     this.username = username;
/*     */     
/*  81 */     if (password != null && realm.hasMessageDigest(algorithm)) {
/*  82 */       this.password = realm.getCredentialHandler().mutate(password);
/*     */     } else {
/*  84 */       this.password = password;
/*     */     } 
/*  86 */     this.nonce = nonce;
/*  87 */     this.nc = nc;
/*  88 */     this.cnonce = cnonce;
/*  89 */     this.qop = qop;
/*  90 */     this.realmName = realmName;
/*  91 */     this.digestA2 = digestA2;
/*  92 */     this.authMethod = authMethod;
/*  93 */     this.algorithm = algorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   protected static final StringManager sm = StringManager.getManager(JAASCallbackHandler.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String password;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JAASRealm realm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String username;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String nonce;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String nc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String cnonce;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String qop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String realmName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String digestA2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String authMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String algorithm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 175 */     for (Callback callback : callbacks) {
/*     */       
/* 177 */       if (callback instanceof NameCallback) {
/* 178 */         if (this.realm.getContainer().getLogger().isTraceEnabled()) {
/* 179 */           this.realm.getContainer().getLogger().trace(sm.getString("jaasCallback.username", new Object[] { this.username }));
/*     */         }
/* 181 */         ((NameCallback)callback).setName(this.username);
/* 182 */       } else if (callback instanceof PasswordCallback) {
/*     */         char[] passwordcontents;
/* 184 */         if (this.password != null) {
/* 185 */           passwordcontents = this.password.toCharArray();
/*     */         } else {
/* 187 */           passwordcontents = new char[0];
/*     */         } 
/* 189 */         ((PasswordCallback)callback).setPassword(passwordcontents);
/* 190 */       } else if (callback instanceof TextInputCallback) {
/* 191 */         TextInputCallback cb = (TextInputCallback)callback;
/* 192 */         if (cb.getPrompt().equals("nonce")) {
/* 193 */           cb.setText(this.nonce);
/* 194 */         } else if (cb.getPrompt().equals("nc")) {
/* 195 */           cb.setText(this.nc);
/* 196 */         } else if (cb.getPrompt().equals("cnonce")) {
/* 197 */           cb.setText(this.cnonce);
/* 198 */         } else if (cb.getPrompt().equals("qop")) {
/* 199 */           cb.setText(this.qop);
/* 200 */         } else if (cb.getPrompt().equals("realmName")) {
/* 201 */           cb.setText(this.realmName);
/* 202 */         } else if (cb.getPrompt().equals("digestA2")) {
/* 203 */           cb.setText(this.digestA2);
/* 204 */         } else if (cb.getPrompt().equals("authMethod")) {
/* 205 */           cb.setText(this.authMethod);
/* 206 */         } else if (cb.getPrompt().equals("algorithm")) {
/* 207 */           cb.setText(this.algorithm);
/* 208 */         } else if (cb.getPrompt().equals("catalinaBase")) {
/* 209 */           cb.setText(this.realm.getContainer().getCatalinaBase().getAbsolutePath());
/*     */         } else {
/* 211 */           throw new UnsupportedCallbackException(callback);
/*     */         } 
/*     */       } else {
/* 214 */         throw new UnsupportedCallbackException(callback);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\JAASCallbackHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */