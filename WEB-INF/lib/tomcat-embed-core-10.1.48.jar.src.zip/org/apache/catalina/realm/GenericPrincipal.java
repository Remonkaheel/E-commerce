/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import org.apache.catalina.TomcatPrincipal;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericPrincipal
/*     */   implements TomcatPrincipal, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final String name;
/*     */   protected final String[] roles;
/*     */   protected final Principal userPrincipal;
/*     */   protected final transient LoginContext loginContext;
/*     */   protected transient GSSCredential gssCredential;
/*     */   protected final Map<String, Object> attributes;
/*     */   
/*     */   public GenericPrincipal(String name) {
/*  50 */     this(name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPrincipal(String name, List<String> roles) {
/*  61 */     this(name, roles, (Principal)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GenericPrincipal(String name, String password, List<String> roles) {
/*  76 */     this(name, roles, (Principal)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPrincipal(String name, List<String> roles, Principal userPrincipal) {
/*  89 */     this(name, roles, userPrincipal, (LoginContext)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GenericPrincipal(String name, String password, List<String> roles, Principal userPrincipal) {
/* 106 */     this(name, roles, userPrincipal, (LoginContext)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPrincipal(String name, List<String> roles, Principal userPrincipal, LoginContext loginContext) {
/* 120 */     this(name, roles, userPrincipal, loginContext, (GSSCredential)null, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GenericPrincipal(String name, String password, List<String> roles, Principal userPrincipal, LoginContext loginContext) {
/* 139 */     this(name, roles, userPrincipal, loginContext, (GSSCredential)null, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPrincipal(String name, List<String> roles, Principal userPrincipal, LoginContext loginContext, GSSCredential gssCredential, Map<String, Object> attributes) {
/* 157 */     this.name = name;
/* 158 */     this.userPrincipal = userPrincipal;
/* 159 */     if (roles == null) {
/* 160 */       this.roles = new String[0];
/*     */     } else {
/* 162 */       this.roles = roles.<String>toArray(new String[0]);
/* 163 */       if (this.roles.length > 1) {
/* 164 */         Arrays.sort((Object[])this.roles);
/*     */       }
/*     */     } 
/* 167 */     this.loginContext = loginContext;
/* 168 */     this.gssCredential = gssCredential;
/* 169 */     this.attributes = (attributes != null) ? Collections.<String, Object>unmodifiableMap(attributes) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GenericPrincipal(String name, String password, List<String> roles, Principal userPrincipal, LoginContext loginContext, GSSCredential gssCredential) {
/* 190 */     this(name, roles, userPrincipal, loginContext, gssCredential, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 203 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRoles() {
/* 212 */     return (String[])this.roles.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal getUserPrincipal() {
/* 223 */     return (Principal)Objects.requireNonNullElse(this.userPrincipal, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GSSCredential getGssCredential() {
/* 240 */     return this.gssCredential;
/*     */   }
/*     */   
/*     */   protected void setGssCredential(GSSCredential gssCredential) {
/* 244 */     this.gssCredential = gssCredential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasRole(String role) {
/* 263 */     if ("*".equals(role)) {
/* 264 */       return true;
/*     */     }
/* 266 */     if (role == null) {
/* 267 */       return false;
/*     */     }
/* 269 */     return (Arrays.binarySearch((Object[])this.roles, role) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 275 */     StringBuilder sb = new StringBuilder("GenericPrincipal[");
/* 276 */     sb.append(this.name);
/* 277 */     sb.append('(');
/* 278 */     for (String role : this.roles) {
/* 279 */       sb.append(role).append(',');
/*     */     }
/* 281 */     sb.append(")]");
/* 282 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void logout() throws Exception {
/* 288 */     if (this.loginContext != null) {
/* 289 */       this.loginContext.logout();
/*     */     }
/* 291 */     if (this.gssCredential != null) {
/* 292 */       this.gssCredential.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/* 299 */     if (this.attributes == null || name == null) {
/* 300 */       return null;
/*     */     }
/* 302 */     return this.attributes.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/* 308 */     if (this.attributes == null) {
/* 309 */       return Collections.emptyEnumeration();
/*     */     }
/* 311 */     return Collections.enumeration(this.attributes.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object writeReplace() {
/* 318 */     return new SerializablePrincipal(this.name, this.roles, this.userPrincipal, this.attributes);
/*     */   }
/*     */   
/*     */   private static class SerializablePrincipal
/*     */     implements Serializable {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final String name;
/*     */     private final String[] roles;
/*     */     private final Principal principal;
/*     */     private final Map<String, Object> attributes;
/*     */     
/*     */     SerializablePrincipal(String name, String[] roles, Principal principal, Map<String, Object> attributes) {
/* 330 */       this.name = name;
/* 331 */       this.roles = roles;
/* 332 */       if (principal instanceof Serializable) {
/* 333 */         this.principal = principal;
/*     */       } else {
/* 335 */         this.principal = null;
/*     */       } 
/* 337 */       this.attributes = attributes;
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 341 */       return new GenericPrincipal(this.name, Arrays.asList(this.roles), this.principal, null, null, this.attributes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\GenericPrincipal.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */