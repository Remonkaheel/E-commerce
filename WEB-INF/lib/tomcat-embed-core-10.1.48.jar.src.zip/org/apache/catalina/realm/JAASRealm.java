/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.AccountExpiredException;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.CredentialExpiredException;
/*     */ import javax.security.auth.login.FailedLoginException;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAASRealm
/*     */   extends RealmBase
/*     */ {
/* 121 */   private static final Log log = LogFactory.getLog(JAASRealm.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   protected String appName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   protected final List<String> roleClasses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   protected final List<String> userClasses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean useContextClassLoader = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String configFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile Configuration jaasConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile boolean jaasConfigurationLoaded = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean invocationSuccess = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConfigFile() {
/* 174 */     return this.configFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigFile(String configFile) {
/* 183 */     this.configFile = configFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAppName(String name) {
/* 192 */     this.appName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAppName() {
/* 199 */     return this.appName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseContextClassLoader(boolean useContext) {
/* 208 */     this.useContextClassLoader = useContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseContextClassLoader() {
/* 217 */     return this.useContextClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContainer(Container container) {
/* 222 */     super.setContainer(container);
/*     */     
/* 224 */     if (this.appName == null) {
/* 225 */       this.appName = makeLegalForJAAS(container.getName());
/* 226 */       log.info(sm.getString("jaasRealm.appName", new Object[] { this.appName }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   protected String roleClassNames = null;
/*     */   
/*     */   public String getRoleClassNames() {
/* 236 */     return this.roleClassNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoleClassNames(String roleClassNames) {
/* 247 */     this.roleClassNames = roleClassNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseClassNames(String classNamesString, List<String> classNamesList) {
/* 259 */     classNamesList.clear();
/* 260 */     if (classNamesString == null) {
/*     */       return;
/*     */     }
/*     */     
/* 264 */     ClassLoader loader = getClass().getClassLoader();
/* 265 */     if (isUseContextClassLoader()) {
/* 266 */       loader = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     
/* 269 */     String[] classNames = classNamesString.split("[ ]*,[ ]*");
/* 270 */     for (String className : classNames) {
/* 271 */       if (!className.isEmpty()) {
/*     */         
/*     */         try {
/*     */           
/* 275 */           Class<?> principalClass = Class.forName(className, false, loader);
/* 276 */           if (Principal.class.isAssignableFrom(principalClass)) {
/* 277 */             classNamesList.add(className);
/*     */           } else {
/* 279 */             log.error(sm.getString("jaasRealm.notPrincipal", new Object[] { className }));
/*     */           } 
/* 281 */         } catch (ClassNotFoundException e) {
/* 282 */           log.error(sm.getString("jaasRealm.classNotFound", new Object[] { className }));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 290 */   protected String userClassNames = null;
/*     */   
/*     */   public String getUserClassNames() {
/* 293 */     return this.userClassNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserClassNames(String userClassNames) {
/* 304 */     this.userClassNames = userClassNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal authenticate(String username, String credentials) {
/* 312 */     return authenticate(username, new JAASCallbackHandler(this, username, credentials));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String digestA2, String algorithm) {
/* 319 */     return authenticate(username, new JAASCallbackHandler(this, username, clientDigest, nonce, nc, cnonce, qop, realmName, digestA2, algorithm, "DIGEST"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal authenticate(String username, CallbackHandler callbackHandler) {
/*     */     try {
/*     */       LoginContext loginContext;
/*     */       Subject subject;
/* 338 */       if (this.appName == null) {
/* 339 */         this.appName = "Tomcat";
/*     */       }
/*     */       
/* 342 */       if (log.isTraceEnabled()) {
/* 343 */         log.trace(sm.getString("jaasRealm.beginLogin", new Object[] { username, this.appName }));
/*     */       }
/*     */ 
/*     */       
/* 347 */       ClassLoader ocl = null;
/* 348 */       Thread currentThread = null;
/*     */       
/* 350 */       if (!isUseContextClassLoader()) {
/* 351 */         currentThread = Thread.currentThread();
/* 352 */         ocl = currentThread.getContextClassLoader();
/* 353 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 358 */         Configuration config = getConfig();
/* 359 */         loginContext = new LoginContext(this.appName, null, callbackHandler, config);
/* 360 */       } catch (Throwable t) {
/* 361 */         ExceptionUtils.handleThrowable(t);
/* 362 */         log.error(sm.getString("jaasRealm.unexpectedError"), t);
/*     */ 
/*     */         
/* 365 */         this.invocationSuccess = false;
/* 366 */         return null;
/*     */       } finally {
/* 368 */         if (currentThread != null) {
/* 369 */           currentThread.setContextClassLoader(ocl);
/*     */         }
/*     */       } 
/*     */       
/* 373 */       if (log.isTraceEnabled()) {
/* 374 */         log.trace("Login context created " + username);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 380 */         loginContext.login();
/* 381 */         subject = loginContext.getSubject();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 386 */         this.invocationSuccess = true;
/* 387 */         if (subject == null) {
/* 388 */           if (log.isDebugEnabled()) {
/* 389 */             log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }));
/*     */           }
/* 391 */           return null;
/*     */         } 
/* 393 */       } catch (AccountExpiredException e) {
/* 394 */         if (log.isDebugEnabled()) {
/* 395 */           log.debug(sm.getString("jaasRealm.accountExpired", new Object[] { username }), e);
/*     */         }
/*     */ 
/*     */         
/* 399 */         this.invocationSuccess = true;
/* 400 */         return null;
/* 401 */       } catch (CredentialExpiredException e) {
/* 402 */         if (log.isDebugEnabled()) {
/* 403 */           log.debug(sm.getString("jaasRealm.credentialExpired", new Object[] { username }), e);
/*     */         }
/*     */ 
/*     */         
/* 407 */         this.invocationSuccess = true;
/* 408 */         return null;
/* 409 */       } catch (FailedLoginException e) {
/* 410 */         if (log.isDebugEnabled()) {
/* 411 */           log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }), e);
/*     */         }
/*     */ 
/*     */         
/* 415 */         this.invocationSuccess = true;
/* 416 */         return null;
/* 417 */       } catch (LoginException e) {
/* 418 */         log.warn(sm.getString("jaasRealm.loginException", new Object[] { username }), e);
/*     */ 
/*     */         
/* 421 */         this.invocationSuccess = true;
/* 422 */         return null;
/* 423 */       } catch (Throwable t) {
/* 424 */         ExceptionUtils.handleThrowable(t);
/* 425 */         log.error(sm.getString("jaasRealm.unexpectedError"), t);
/*     */ 
/*     */         
/* 428 */         this.invocationSuccess = false;
/* 429 */         return null;
/*     */       } 
/*     */       
/* 432 */       if (log.isTraceEnabled()) {
/* 433 */         log.trace(sm.getString("jaasRealm.loginContextCreated", new Object[] { username }));
/*     */       }
/*     */ 
/*     */       
/* 437 */       Principal principal = createPrincipal(username, subject, loginContext);
/* 438 */       if (principal == null) {
/* 439 */         if (log.isDebugEnabled()) {
/* 440 */           log.debug(sm.getString("jaasRealm.authenticateFailure", new Object[] { username }));
/*     */         }
/* 442 */         return null;
/*     */       } 
/* 444 */       if (log.isTraceEnabled()) {
/* 445 */         log.trace(sm.getString("jaasRealm.authenticateSuccess", new Object[] { username, principal }));
/*     */       }
/*     */       
/* 448 */       return principal;
/* 449 */     } catch (Throwable t) {
/* 450 */       log.error(sm.getString("jaasRealm.unexpectedError"), t);
/*     */       
/* 452 */       this.invocationSuccess = false;
/* 453 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPassword(String username) {
/* 464 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal getPrincipal(String username) {
/* 471 */     return authenticate(username, new JAASCallbackHandler(this, username, null, null, null, null, null, null, null, null, "CLIENT_CERT"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal createPrincipal(String username, Subject subject, LoginContext loginContext) {
/* 494 */     List<String> roles = new ArrayList<>();
/* 495 */     Principal userPrincipal = null;
/*     */ 
/*     */     
/* 498 */     for (Principal principal : subject.getPrincipals()) {
/* 499 */       String principalClass = principal.getClass().getName();
/*     */       
/* 501 */       if (log.isTraceEnabled()) {
/* 502 */         log.trace(sm.getString("jaasRealm.checkPrincipal", new Object[] { principal, principalClass }));
/*     */       }
/*     */       
/* 505 */       if (userPrincipal == null && this.userClasses.contains(principalClass)) {
/* 506 */         userPrincipal = principal;
/* 507 */         if (log.isTraceEnabled()) {
/* 508 */           log.trace(sm.getString("jaasRealm.userPrincipalSuccess", new Object[] { principal.getName() }));
/*     */         }
/*     */       } 
/*     */       
/* 512 */       if (this.roleClasses.contains(principalClass)) {
/* 513 */         roles.add(principal.getName());
/* 514 */         if (log.isTraceEnabled()) {
/* 515 */           log.trace(sm.getString("jaasRealm.rolePrincipalAdd", new Object[] { principal.getName() }));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 521 */     if (userPrincipal == null) {
/* 522 */       if (log.isDebugEnabled()) {
/* 523 */         log.debug(sm.getString("jaasRealm.userPrincipalFailure"));
/* 524 */         log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
/*     */       } 
/* 526 */       return null;
/*     */     } 
/* 528 */     if (roles.isEmpty() && 
/* 529 */       log.isDebugEnabled()) {
/* 530 */       log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 536 */     return (Principal)new GenericPrincipal(username, roles, userPrincipal, loginContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String makeLegalForJAAS(String src) {
/* 548 */     String result = src;
/*     */ 
/*     */     
/* 551 */     if (result == null) {
/* 552 */       result = "other";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 557 */     if (result.startsWith("/")) {
/* 558 */       result = result.substring(1);
/*     */     }
/*     */     
/* 561 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 572 */     parseClassNames(this.userClassNames, this.userClasses);
/* 573 */     parseClassNames(this.roleClassNames, this.roleClasses);
/*     */     
/* 575 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Configuration getConfig() {
/* 586 */     String configFile = this.configFile;
/*     */     try {
/* 588 */       if (this.jaasConfigurationLoaded) {
/* 589 */         return this.jaasConfiguration;
/*     */       }
/* 591 */       synchronized (this) {
/* 592 */         Configuration config; if (configFile == null) {
/* 593 */           this.jaasConfigurationLoaded = true;
/* 594 */           return null;
/*     */         } 
/*     */ 
/*     */         
/* 598 */         Class<Configuration> sunConfigFile = (Class)Class.forName("com.sun.security.auth.login.ConfigFile");
/* 599 */         Constructor<Configuration> constructor = sunConfigFile.getConstructor(new Class[] { URI.class });
/* 600 */         URL resource = Thread.currentThread().getContextClassLoader().getResource(configFile);
/*     */         
/* 602 */         if (resource == null) {
/*     */           
/* 604 */           try { ConfigurationSource.Resource configFileResource = ConfigFileLoader.getSource().getResource(configFile); 
/* 605 */             try { config = constructor.newInstance(new Object[] { configFileResource.getURI() });
/* 606 */               this.jaasConfigurationLoaded = true;
/* 607 */               if (configFileResource != null) configFileResource.close();  } catch (Throwable throwable) { if (configFileResource != null) try { configFileResource.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 608 */           { throw new RuntimeException(sm.getString("jaasRealm.configFileNotFound", new Object[] { configFile })); }
/*     */         
/*     */         } else {
/* 611 */           URI uri = resource.toURI();
/* 612 */           config = constructor.newInstance(new Object[] { uri });
/* 613 */           this.jaasConfigurationLoaded = true;
/*     */         } 
/* 615 */         this.jaasConfiguration = config;
/* 616 */         return this.jaasConfiguration;
/*     */       } 
/* 618 */     } catch (InvocationTargetException ex) {
/* 619 */       throw new RuntimeException(ex.getCause());
/* 620 */     } catch (SecurityException|java.net.URISyntaxException|ReflectiveOperationException|IllegalArgumentException ex) {
/* 621 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/* 627 */     return this.invocationSuccess;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\JAASRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */