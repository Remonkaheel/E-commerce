/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import javax.naming.AuthenticationException;
/*      */ import javax.naming.CompositeName;
/*      */ import javax.naming.InvalidNameException;
/*      */ import javax.naming.Name;
/*      */ import javax.naming.NameNotFoundException;
/*      */ import javax.naming.NameParser;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.PartialResultException;
/*      */ import javax.naming.directory.Attribute;
/*      */ import javax.naming.directory.Attributes;
/*      */ import javax.naming.directory.DirContext;
/*      */ import javax.naming.directory.InitialDirContext;
/*      */ import javax.naming.directory.SearchControls;
/*      */ import javax.naming.directory.SearchResult;
/*      */ import javax.naming.ldap.InitialLdapContext;
/*      */ import javax.naming.ldap.LdapContext;
/*      */ import javax.naming.ldap.StartTlsRequest;
/*      */ import javax.naming.ldap.StartTlsResponse;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*      */ import org.ietf.jgss.GSSContext;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JNDIRealm
/*      */   extends RealmBase
/*      */ {
/*      */   public static final String DEREF_ALIASES = "java.naming.ldap.derefAliases";
/*      */   private static final String AUTHENTICATION_NAME_GSSAPI = "GSSAPI";
/*  151 */   protected String authentication = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   protected String connectionName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   protected String connectionPassword = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   protected String connectionURL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  172 */   protected String contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   protected String derefAliases = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   protected String protocol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean adCompat = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  196 */   protected String referrals = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   protected String userBase = "";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  206 */   protected String userSearch = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean userSearchAsUser = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean userSubtree = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  223 */   protected String userPassword = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  229 */   protected String userRoleAttribute = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  236 */   protected String[] userPatternArray = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  242 */   protected String userPattern = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  247 */   protected String roleBase = "";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   protected String userRoleName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  257 */   protected String roleName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  263 */   protected String roleSearch = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean roleSubtree = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean roleNested = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean roleSearchAsUser = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String alternateURL;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  290 */   protected int connectionAttempt = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  295 */   protected String commonRole = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  301 */   protected String connectionTimeout = "5000";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  307 */   protected String readTimeout = "5000";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  313 */   protected long sizeLimit = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  318 */   protected int timeLimit = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useDelegatedCredential = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  329 */   protected String spnegoDelegationQop = "auth-conf";
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useStartTls = false;
/*      */ 
/*      */   
/*  336 */   private StartTlsResponse tls = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  342 */   private String[] cipherSuitesArray = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  347 */   private HostnameVerifier hostnameVerifier = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  352 */   private SSLSocketFactory sslSocketFactory = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String sslSocketFactoryClassName;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String cipherSuites;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String hostNameVerifierClassName;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String sslProtocol;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean forceDnHexEscape = false;
/*      */ 
/*      */ 
/*      */   
/*      */   protected JNDIConnection singleConnection;
/*      */ 
/*      */ 
/*      */   
/*  384 */   protected final Lock singleConnectionLock = new ReentrantLock();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  389 */   protected SynchronizedStack<JNDIConnection> connectionPool = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  394 */   protected int connectionPoolSize = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useContextClassLoader = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getForceDnHexEscape() {
/*  406 */     return this.forceDnHexEscape;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setForceDnHexEscape(boolean forceDnHexEscape) {
/*  411 */     this.forceDnHexEscape = forceDnHexEscape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthentication() {
/*  419 */     return this.authentication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAuthentication(String authentication) {
/*  429 */     this.authentication = authentication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionName() {
/*  437 */     return this.connectionName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionName(String connectionName) {
/*  447 */     this.connectionName = connectionName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionPassword() {
/*  455 */     return this.connectionPassword;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionPassword(String connectionPassword) {
/*  465 */     this.connectionPassword = connectionPassword;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionURL() {
/*  473 */     return this.connectionURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionURL(String connectionURL) {
/*  483 */     this.connectionURL = connectionURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContextFactory() {
/*  491 */     return this.contextFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContextFactory(String contextFactory) {
/*  501 */     this.contextFactory = contextFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDerefAliases() {
/*  509 */     return this.derefAliases;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDerefAliases(String derefAliases) {
/*  519 */     this.derefAliases = derefAliases;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProtocol() {
/*  527 */     return this.protocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtocol(String protocol) {
/*  537 */     this.protocol = protocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAdCompat() {
/*  545 */     return this.adCompat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAdCompat(boolean adCompat) {
/*  555 */     this.adCompat = adCompat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getReferrals() {
/*  563 */     return this.referrals;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReferrals(String referrals) {
/*  574 */     this.referrals = referrals;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserBase() {
/*  582 */     return this.userBase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserBase(String userBase) {
/*  592 */     this.userBase = userBase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserSearch() {
/*  600 */     return this.userSearch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserSearch(String userSearch) {
/*  610 */     this.userSearch = userSearch;
/*  611 */     this.singleConnection = create();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUserSearchAsUser() {
/*  616 */     return this.userSearchAsUser;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUserSearchAsUser(boolean userSearchAsUser) {
/*  621 */     this.userSearchAsUser = userSearchAsUser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUserSubtree() {
/*  629 */     return this.userSubtree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserSubtree(boolean userSubtree) {
/*  639 */     this.userSubtree = userSubtree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserRoleName() {
/*  647 */     return this.userRoleName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserRoleName(String userRoleName) {
/*  657 */     this.userRoleName = userRoleName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleBase() {
/*  665 */     return this.roleBase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleBase(String roleBase) {
/*  675 */     this.roleBase = roleBase;
/*  676 */     this.singleConnection = create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleName() {
/*  684 */     return this.roleName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleName(String roleName) {
/*  694 */     this.roleName = roleName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRoleSearch() {
/*  702 */     return this.roleSearch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleSearch(String roleSearch) {
/*  712 */     this.roleSearch = roleSearch;
/*  713 */     this.singleConnection = create();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRoleSearchAsUser() {
/*  718 */     return this.roleSearchAsUser;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRoleSearchAsUser(boolean roleSearchAsUser) {
/*  723 */     this.roleSearchAsUser = roleSearchAsUser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRoleSubtree() {
/*  731 */     return this.roleSubtree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleSubtree(boolean roleSubtree) {
/*  741 */     this.roleSubtree = roleSubtree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRoleNested() {
/*  749 */     return this.roleNested;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoleNested(boolean roleNested) {
/*  759 */     this.roleNested = roleNested;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserPassword() {
/*  767 */     return this.userPassword;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserPassword(String userPassword) {
/*  777 */     this.userPassword = userPassword;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUserRoleAttribute() {
/*  782 */     return this.userRoleAttribute;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUserRoleAttribute(String userRoleAttribute) {
/*  787 */     this.userRoleAttribute = userRoleAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserPattern() {
/*  794 */     return this.userPattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserPattern(String userPattern) {
/*  807 */     this.userPattern = userPattern;
/*  808 */     if (userPattern == null) {
/*  809 */       this.userPatternArray = null;
/*      */     } else {
/*  811 */       this.userPatternArray = parseUserPatternString(userPattern);
/*  812 */       this.singleConnection = create();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAlternateURL() {
/*  823 */     return this.alternateURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlternateURL(String alternateURL) {
/*  833 */     this.alternateURL = alternateURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCommonRole() {
/*  841 */     return this.commonRole;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCommonRole(String commonRole) {
/*  851 */     this.commonRole = commonRole;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConnectionTimeout() {
/*  859 */     return this.connectionTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionTimeout(String timeout) {
/*  869 */     this.connectionTimeout = timeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getReadTimeout() {
/*  877 */     return this.readTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadTimeout(String timeout) {
/*  887 */     this.readTimeout = timeout;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getSizeLimit() {
/*  892 */     return this.sizeLimit;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSizeLimit(long sizeLimit) {
/*  897 */     this.sizeLimit = sizeLimit;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTimeLimit() {
/*  902 */     return this.timeLimit;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimeLimit(int timeLimit) {
/*  907 */     this.timeLimit = timeLimit;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUseDelegatedCredential() {
/*  912 */     return this.useDelegatedCredential;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUseDelegatedCredential(boolean useDelegatedCredential) {
/*  917 */     this.useDelegatedCredential = useDelegatedCredential;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSpnegoDelegationQop() {
/*  922 */     return this.spnegoDelegationQop;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSpnegoDelegationQop(String spnegoDelegationQop) {
/*  927 */     this.spnegoDelegationQop = spnegoDelegationQop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseStartTls() {
/*  935 */     return this.useStartTls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseStartTls(boolean useStartTls) {
/*  945 */     this.useStartTls = useStartTls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getCipherSuitesArray() {
/*  953 */     if (this.cipherSuites == null || this.cipherSuitesArray != null) {
/*  954 */       return this.cipherSuitesArray;
/*      */     }
/*  956 */     this.cipherSuites = this.cipherSuites.trim();
/*  957 */     if (this.cipherSuites.isEmpty()) {
/*  958 */       this.containerLog.warn(sm.getString("jndiRealm.emptyCipherSuites"));
/*  959 */       this.cipherSuitesArray = null;
/*      */     } else {
/*  961 */       this.cipherSuitesArray = StringUtils.splitCommaSeparated(this.cipherSuites);
/*  962 */       if (this.containerLog.isTraceEnabled()) {
/*  963 */         this.containerLog.trace(sm.getString("jndiRealm.cipherSuites", new Object[] { Arrays.toString((Object[])this.cipherSuitesArray) }));
/*      */       }
/*      */     } 
/*  966 */     return this.cipherSuitesArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCipherSuites(String suites) {
/*  977 */     this.cipherSuites = suites;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConnectionPoolSize() {
/*  985 */     return this.connectionPoolSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionPoolSize(int connectionPoolSize) {
/*  995 */     this.connectionPoolSize = connectionPoolSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHostnameVerifierClassName() {
/* 1004 */     if (this.hostnameVerifier == null) {
/* 1005 */       return "";
/*      */     }
/* 1007 */     return this.hostnameVerifier.getClass().getCanonicalName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHostnameVerifierClassName(String verifierClassName) {
/* 1018 */     if (verifierClassName != null) {
/* 1019 */       this.hostNameVerifierClassName = verifierClassName.trim();
/*      */     } else {
/* 1021 */       this.hostNameVerifierClassName = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HostnameVerifier getHostnameVerifier() {
/* 1031 */     if (this.hostnameVerifier != null) {
/* 1032 */       return this.hostnameVerifier;
/*      */     }
/* 1034 */     if (this.hostNameVerifierClassName == null || this.hostNameVerifierClassName.isEmpty()) {
/* 1035 */       return null;
/*      */     }
/*      */     try {
/* 1038 */       Object o = constructInstance(this.hostNameVerifierClassName);
/* 1039 */       if (o instanceof HostnameVerifier) {
/* 1040 */         this.hostnameVerifier = (HostnameVerifier)o;
/* 1041 */         return this.hostnameVerifier;
/*      */       } 
/* 1043 */       throw new IllegalArgumentException(sm
/* 1044 */           .getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }));
/*      */     }
/* 1046 */     catch (ReflectiveOperationException|SecurityException e) {
/* 1047 */       throw new IllegalArgumentException(sm
/* 1048 */           .getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSslSocketFactoryClassName(String factoryClassName) {
/* 1061 */     this.sslSocketFactoryClassName = factoryClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSslProtocol(String protocol) {
/* 1071 */     this.sslProtocol = protocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getSupportedSslProtocols() {
/*      */     try {
/* 1080 */       SSLContext sslContext = SSLContext.getDefault();
/* 1081 */       return sslContext.getSupportedSSLParameters().getProtocols();
/* 1082 */     } catch (NoSuchAlgorithmException e) {
/* 1083 */       throw new RuntimeException(sm.getString("jndiRealm.exception"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Object constructInstance(String className) throws ReflectiveOperationException {
/* 1089 */     Class<?> clazz = Class.forName(className);
/* 1090 */     return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseContextClassLoader(boolean useContext) {
/* 1100 */     this.useContextClassLoader = useContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUseContextClassLoader() {
/* 1110 */     return this.useContextClassLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username, String credentials) {
/* 1126 */     ClassLoader ocl = null;
/* 1127 */     Thread currentThread = null;
/* 1128 */     JNDIConnection connection = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       Principal principal;
/*      */ 
/*      */       
/* 1136 */       if (!isUseContextClassLoader()) {
/* 1137 */         currentThread = Thread.currentThread();
/* 1138 */         ocl = currentThread.getContextClassLoader();
/* 1139 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/*      */ 
/*      */       
/* 1143 */       connection = get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1151 */         principal = authenticate(connection, username, credentials);
/*      */       }
/* 1153 */       catch (NullPointerException|NamingException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1166 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */ 
/*      */         
/* 1169 */         close(connection);
/* 1170 */         closePooledConnections();
/*      */ 
/*      */         
/* 1173 */         connection = get();
/*      */ 
/*      */         
/* 1176 */         principal = authenticate(connection, username, credentials);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1181 */       release(connection);
/*      */ 
/*      */       
/* 1184 */       return principal;
/*      */     }
/* 1186 */     catch (Exception e) {
/*      */ 
/*      */       
/* 1189 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */ 
/*      */       
/* 1192 */       close(connection);
/* 1193 */       closePooledConnections();
/*      */ 
/*      */       
/* 1196 */       if (this.containerLog.isTraceEnabled()) {
/* 1197 */         this.containerLog.trace("Returning null principal.");
/*      */       }
/* 1199 */       return null;
/*      */     } finally {
/* 1201 */       if (currentThread != null) {
/* 1202 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal authenticate(JNDIConnection connection, String username, String credentials) throws NamingException {
/* 1223 */     if (username == null || username.isEmpty() || credentials == null || credentials.isEmpty()) {
/* 1224 */       if (this.containerLog.isTraceEnabled()) {
/* 1225 */         this.containerLog.trace("username null or empty: returning null principal.");
/*      */       }
/* 1227 */       return null;
/*      */     } 
/*      */     
/* 1230 */     ClassLoader ocl = null;
/* 1231 */     Thread currentThread = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1237 */       if (!isUseContextClassLoader()) {
/* 1238 */         currentThread = Thread.currentThread();
/* 1239 */         ocl = currentThread.getContextClassLoader();
/* 1240 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/*      */       
/* 1243 */       if (this.userPatternArray != null) {
/* 1244 */         for (int curUserPattern = 0; curUserPattern < this.userPatternArray.length; curUserPattern++) {
/*      */           
/* 1246 */           User user1 = getUser(connection, username, credentials, curUserPattern);
/* 1247 */           if (user1 != null) {
/*      */             
/*      */             try {
/* 1250 */               if (checkCredentials(connection.context, user1, credentials)) {
/*      */                 
/* 1252 */                 List<String> list = getRoles(connection, user1);
/* 1253 */                 if (this.containerLog.isTraceEnabled()) {
/* 1254 */                   this.containerLog.trace("Found roles: " + ((list == null) ? "" : list.toString()));
/*      */                 }
/* 1256 */                 return (Principal)new GenericPrincipal(username, list);
/*      */               } 
/* 1258 */             } catch (InvalidNameException ine) {
/*      */               
/* 1260 */               this.containerLog.warn(sm.getString("jndiRealm.exception"), ine);
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1268 */         return null;
/*      */       } 
/*      */       
/* 1271 */       User user = getUser(connection, username, credentials);
/* 1272 */       if (user == null) {
/* 1273 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1277 */       if (!checkCredentials(connection.context, user, credentials)) {
/* 1278 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1282 */       List<String> roles = getRoles(connection, user);
/* 1283 */       if (this.containerLog.isTraceEnabled()) {
/* 1284 */         this.containerLog.trace("Found roles: " + ((roles == null) ? "" : roles.toString()));
/*      */       }
/*      */ 
/*      */       
/* 1288 */       return (Principal)new GenericPrincipal(username, roles);
/*      */     } finally {
/*      */       
/* 1291 */       if (currentThread != null) {
/* 1292 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username) {
/* 1305 */     ClassLoader ocl = null;
/* 1306 */     Thread currentThread = null;
/*      */     try {
/* 1308 */       if (!isUseContextClassLoader()) {
/* 1309 */         currentThread = Thread.currentThread();
/* 1310 */         ocl = currentThread.getContextClassLoader();
/* 1311 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 1313 */       return super.authenticate(username);
/*      */     } finally {
/* 1315 */       if (currentThread != null) {
/* 1316 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String digestA2, String algorithm) {
/* 1330 */     ClassLoader ocl = null;
/* 1331 */     Thread currentThread = null;
/*      */     try {
/* 1333 */       if (!isUseContextClassLoader()) {
/* 1334 */         currentThread = Thread.currentThread();
/* 1335 */         ocl = currentThread.getContextClassLoader();
/* 1336 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 1338 */       return super.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realm, digestA2, algorithm);
/*      */     } finally {
/* 1340 */       if (currentThread != null) {
/* 1341 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(X509Certificate[] certs) {
/* 1354 */     ClassLoader ocl = null;
/* 1355 */     Thread currentThread = null;
/*      */     try {
/* 1357 */       if (!isUseContextClassLoader()) {
/* 1358 */         currentThread = Thread.currentThread();
/* 1359 */         ocl = currentThread.getContextClassLoader();
/* 1360 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 1362 */       return super.authenticate(certs);
/*      */     } finally {
/* 1364 */       if (currentThread != null) {
/* 1365 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(GSSContext gssContext, boolean storeCred) {
/* 1378 */     ClassLoader ocl = null;
/* 1379 */     Thread currentThread = null;
/*      */     try {
/* 1381 */       if (!isUseContextClassLoader()) {
/* 1382 */         currentThread = Thread.currentThread();
/* 1383 */         ocl = currentThread.getContextClassLoader();
/* 1384 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 1386 */       return super.authenticate(gssContext, storeCred);
/*      */     } finally {
/* 1388 */       if (currentThread != null) {
/* 1389 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential) {
/* 1402 */     ClassLoader ocl = null;
/* 1403 */     Thread currentThread = null;
/*      */     try {
/* 1405 */       if (!isUseContextClassLoader()) {
/* 1406 */         currentThread = Thread.currentThread();
/* 1407 */         ocl = currentThread.getContextClassLoader();
/* 1408 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 1410 */       return super.authenticate(gssName, gssCredential);
/*      */     } finally {
/* 1412 */       if (currentThread != null) {
/* 1413 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUser(JNDIConnection connection, String username) throws NamingException {
/* 1435 */     return getUser(connection, username, (String)null, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUser(JNDIConnection connection, String username, String credentials) throws NamingException {
/* 1454 */     return getUser(connection, username, credentials, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUser(JNDIConnection connection, String username, String credentials, int curUserPattern) throws NamingException {
/*      */     User user;
/* 1480 */     List<String> list = new ArrayList<>();
/* 1481 */     if (this.userPassword != null) {
/* 1482 */       list.add(this.userPassword);
/*      */     }
/* 1484 */     if (this.userRoleName != null) {
/* 1485 */       list.add(this.userRoleName);
/*      */     }
/* 1487 */     if (this.userRoleAttribute != null) {
/* 1488 */       list.add(this.userRoleAttribute);
/*      */     }
/* 1490 */     String[] attrIds = list.<String>toArray(new String[0]);
/*      */ 
/*      */     
/* 1493 */     if (this.userPatternArray != null && curUserPattern >= 0) {
/* 1494 */       user = getUserByPattern(connection, username, credentials, attrIds, curUserPattern);
/* 1495 */       if (this.containerLog.isTraceEnabled()) {
/* 1496 */         this.containerLog.trace("Found user by pattern [" + String.valueOf(user) + "]");
/*      */       }
/*      */     } else {
/* 1499 */       boolean thisUserSearchAsUser = isUserSearchAsUser();
/*      */       try {
/* 1501 */         if (thisUserSearchAsUser) {
/* 1502 */           userCredentialsAdd(connection.context, username, credentials);
/*      */         }
/* 1504 */         user = getUserBySearch(connection, username, attrIds);
/*      */       } finally {
/* 1506 */         if (thisUserSearchAsUser) {
/* 1507 */           userCredentialsRemove(connection.context);
/*      */         }
/*      */       } 
/* 1510 */       if (this.containerLog.isTraceEnabled()) {
/* 1511 */         this.containerLog.trace("Found user by search [" + String.valueOf(user) + "]");
/*      */       }
/*      */     } 
/* 1514 */     if (this.userPassword == null && credentials != null && user != null)
/*      */     {
/*      */       
/* 1517 */       return new User(user.getUserName(), user.getDN(), credentials, user.getRoles(), user.getUserRoleId());
/*      */     }
/*      */     
/* 1520 */     return user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUserByPattern(DirContext context, String username, String[] attrIds, String dn) throws NamingException {
/*      */     Attributes attrs;
/* 1541 */     if (attrIds == null || attrIds.length == 0) {
/* 1542 */       return new User(username, dn, null, null, null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1548 */       attrs = context.getAttributes(dn, attrIds);
/* 1549 */     } catch (NameNotFoundException e) {
/* 1550 */       return null;
/*      */     } 
/* 1552 */     if (attrs == null) {
/* 1553 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1557 */     String password = null;
/* 1558 */     if (this.userPassword != null) {
/* 1559 */       password = getAttributeValue(this.userPassword, attrs);
/*      */     }
/*      */     
/* 1562 */     String userRoleAttrValue = null;
/* 1563 */     if (this.userRoleAttribute != null) {
/* 1564 */       userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */     }
/*      */ 
/*      */     
/* 1568 */     ArrayList<String> roles = null;
/* 1569 */     if (this.userRoleName != null) {
/* 1570 */       roles = addAttributeValues(this.userRoleName, attrs, (ArrayList<String>)null);
/*      */     }
/*      */     
/* 1573 */     return new User(username, dn, password, roles, userRoleAttrValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUserByPattern(JNDIConnection connection, String username, String credentials, String[] attrIds, int curUserPattern) throws NamingException {
/*      */     User user;
/* 1598 */     if (username == null || this.userPatternArray[curUserPattern] == null) {
/* 1599 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1606 */     String dn = connection.userPatternFormatArray[curUserPattern].format(new String[] { doAttributeValueEscaping(username) });
/*      */     
/*      */     try {
/* 1609 */       user = getUserByPattern(connection.context, username, attrIds, dn);
/* 1610 */     } catch (NameNotFoundException e) {
/* 1611 */       return null;
/* 1612 */     } catch (NamingException e) {
/*      */ 
/*      */       
/*      */       try {
/* 1616 */         userCredentialsAdd(connection.context, dn, credentials);
/*      */         
/* 1618 */         user = getUserByPattern(connection.context, username, attrIds, dn);
/*      */       } finally {
/* 1620 */         userCredentialsRemove(connection.context);
/*      */       } 
/*      */     } 
/* 1623 */     return user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected User getUserBySearch(JNDIConnection connection, String username, String[] attrIds) throws NamingException {
/* 1642 */     if (username == null || connection.userSearchFormat == null) {
/* 1643 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1649 */     String filter = connection.userSearchFormat.format(new String[] { doFilterEscaping(username) });
/*      */ 
/*      */     
/* 1652 */     SearchControls constraints = new SearchControls();
/*      */     
/* 1654 */     if (this.userSubtree) {
/* 1655 */       constraints.setSearchScope(2);
/*      */     } else {
/* 1657 */       constraints.setSearchScope(1);
/*      */     } 
/*      */     
/* 1660 */     constraints.setCountLimit(this.sizeLimit);
/* 1661 */     constraints.setTimeLimit(this.timeLimit);
/*      */ 
/*      */     
/* 1664 */     if (attrIds == null) {
/* 1665 */       attrIds = new String[0];
/*      */     }
/* 1667 */     constraints.setReturningAttributes(attrIds);
/*      */     
/* 1669 */     NamingEnumeration<SearchResult> results = connection.context.search(this.userBase, filter, constraints);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1674 */     try { if (results == null || !results.hasMore()) {
/* 1675 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1686 */       SearchResult result = results.next();
/*      */ 
/*      */       
/*      */       try {
/* 1690 */         if (results.hasMore()) {
/* 1691 */           if (this.containerLog.isInfoEnabled()) {
/* 1692 */             this.containerLog.info(sm.getString("jndiRealm.multipleEntries", new Object[] { username }));
/*      */           }
/* 1694 */           return null;
/*      */         } 
/* 1696 */       } catch (PartialResultException ex) {
/* 1697 */         if (!this.adCompat) {
/* 1698 */           throw ex;
/*      */         }
/*      */       } 
/*      */       
/* 1702 */       String dn = getDistinguishedName(connection.context, this.userBase, result);
/*      */       
/* 1704 */       if (this.containerLog.isTraceEnabled()) {
/* 1705 */         this.containerLog.trace("  entry found for " + username + " with dn " + dn);
/*      */       }
/*      */ 
/*      */       
/* 1709 */       Attributes attrs = result.getAttributes();
/* 1710 */       if (attrs == null) {
/* 1711 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1715 */       String password = null;
/* 1716 */       if (this.userPassword != null) {
/* 1717 */         password = getAttributeValue(this.userPassword, attrs);
/*      */       }
/*      */       
/* 1720 */       String userRoleAttrValue = null;
/* 1721 */       if (this.userRoleAttribute != null) {
/* 1722 */         userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */       }
/*      */ 
/*      */       
/* 1726 */       ArrayList<String> roles = null;
/* 1727 */       if (this.userRoleName != null) {
/* 1728 */         roles = addAttributeValues(this.userRoleName, attrs, (ArrayList<String>)null);
/*      */       }
/*      */       
/* 1731 */       return new User(username, dn, password, roles, userRoleAttrValue); } catch (PartialResultException ex) { if (!this.adCompat)
/*      */         throw ex;  return null; }
/* 1733 */     finally { if (results != null) {
/* 1734 */         results.close();
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkCredentials(DirContext context, User user, String credentials) throws NamingException {
/*      */     boolean validated;
/* 1758 */     if (this.userPassword == null) {
/* 1759 */       validated = bindAsUser(context, user, credentials);
/*      */     } else {
/* 1761 */       validated = compareCredentials(context, user, credentials);
/*      */     } 
/*      */     
/* 1764 */     if (this.containerLog.isTraceEnabled()) {
/* 1765 */       if (validated) {
/* 1766 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateSuccess", new Object[] { user.getUserName() }));
/*      */       } else {
/* 1768 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateFailure", new Object[] { user.getUserName() }));
/*      */       } 
/*      */     }
/* 1771 */     return validated;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean compareCredentials(DirContext context, User info, String credentials) throws NamingException {
/* 1788 */     if (this.containerLog.isTraceEnabled()) {
/* 1789 */       this.containerLog.trace("  validating credentials");
/*      */     }
/*      */     
/* 1792 */     if (info == null || credentials == null) {
/* 1793 */       return false;
/*      */     }
/*      */     
/* 1796 */     String password = info.getPassword();
/*      */     
/* 1798 */     return getCredentialHandler().matches(credentials, password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean bindAsUser(DirContext context, User user, String credentials) throws NamingException {
/* 1815 */     if (credentials == null || user == null) {
/* 1816 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1821 */     String dn = user.getDN();
/* 1822 */     if (dn == null) {
/* 1823 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1827 */     if (this.containerLog.isTraceEnabled()) {
/* 1828 */       this.containerLog.trace("  validating credentials by binding as the user");
/*      */     }
/*      */     
/* 1831 */     boolean validated = false;
/* 1832 */     Hashtable<?, ?> preservedEnvironment = context.getEnvironment();
/*      */ 
/*      */     
/*      */     try {
/* 1836 */       userCredentialsAdd(context, dn, credentials);
/*      */       
/* 1838 */       if ("GSSAPI".equals(preservedEnvironment.get("java.naming.security.authentication"))) {
/* 1839 */         context.removeFromEnvironment("java.naming.security.authentication");
/*      */       }
/* 1841 */       if (this.containerLog.isTraceEnabled()) {
/* 1842 */         this.containerLog.trace("  binding as " + dn);
/*      */       }
/* 1844 */       context.getAttributes("", (String[])null);
/* 1845 */       validated = true;
/* 1846 */     } catch (AuthenticationException e) {
/* 1847 */       if (this.containerLog.isTraceEnabled()) {
/* 1848 */         this.containerLog.trace("  bind attempt failed", e);
/*      */       }
/*      */     } finally {
/*      */       
/* 1852 */       restoreEnvironmentParameter(context, "java.naming.security.authentication", preservedEnvironment);
/* 1853 */       userCredentialsRemove(context);
/*      */     } 
/*      */     
/* 1856 */     return validated;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void userCredentialsAdd(DirContext context, String dn, String credentials) throws NamingException {
/* 1871 */     context.addToEnvironment("java.naming.security.principal", dn);
/* 1872 */     context.addToEnvironment("java.naming.security.credentials", credentials);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void userCredentialsRemove(DirContext context) throws NamingException {
/* 1886 */     if (this.connectionName != null) {
/* 1887 */       context.addToEnvironment("java.naming.security.principal", this.connectionName);
/*      */     } else {
/* 1889 */       context.removeFromEnvironment("java.naming.security.principal");
/*      */     } 
/*      */     
/* 1892 */     if (this.connectionPassword != null) {
/* 1893 */       context.addToEnvironment("java.naming.security.credentials", this.connectionPassword);
/*      */     } else {
/* 1895 */       context.removeFromEnvironment("java.naming.security.credentials");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> getRoles(JNDIConnection connection, User user) throws NamingException {
/*      */     String base;
/* 1913 */     if (user == null) {
/* 1914 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1919 */     String dn = user.getDN();
/*      */ 
/*      */     
/* 1922 */     String username = user.getUserName();
/* 1923 */     String userRoleId = user.getUserRoleId();
/*      */     
/* 1925 */     if (dn == null || username == null) {
/* 1926 */       return null;
/*      */     }
/*      */     
/* 1929 */     if (this.containerLog.isTraceEnabled()) {
/* 1930 */       this.containerLog.trace("  getRoles(" + dn + ")");
/*      */     }
/*      */ 
/*      */     
/* 1934 */     List<String> list = new ArrayList<>();
/* 1935 */     List<String> userRoles = user.getRoles();
/* 1936 */     if (userRoles != null) {
/* 1937 */       list.addAll(userRoles);
/*      */     }
/* 1939 */     if (this.commonRole != null) {
/* 1940 */       list.add(this.commonRole);
/*      */     }
/*      */     
/* 1943 */     if (this.containerLog.isTraceEnabled()) {
/* 1944 */       this.containerLog.trace("  Found " + list.size() + " user internal roles");
/* 1945 */       this.containerLog.trace("  Found user internal roles " + list.toString());
/*      */     } 
/*      */ 
/*      */     
/* 1949 */     if (connection.roleFormat == null || this.roleName == null) {
/* 1950 */       return list;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1957 */     String filter = connection.roleFormat.format(new String[] { doFilterEscaping(dn), doFilterEscaping(doAttributeValueEscaping(username)), 
/* 1958 */           doFilterEscaping(doAttributeValueEscaping(userRoleId)) });
/* 1959 */     SearchControls controls = new SearchControls();
/* 1960 */     if (this.roleSubtree) {
/* 1961 */       controls.setSearchScope(2);
/*      */     } else {
/* 1963 */       controls.setSearchScope(1);
/*      */     } 
/* 1965 */     controls.setReturningAttributes(new String[] { this.roleName });
/*      */ 
/*      */     
/* 1968 */     if (connection.roleBaseFormat != null) {
/* 1969 */       NameParser np = connection.context.getNameParser("");
/* 1970 */       Name name = np.parse(dn);
/* 1971 */       String[] nameParts = new String[name.size()];
/* 1972 */       for (int i = 0; i < name.size(); i++)
/*      */       {
/*      */         
/* 1975 */         nameParts[i] = convertToHexEscape(name.get(i));
/*      */       }
/* 1977 */       base = connection.roleBaseFormat.format(nameParts);
/*      */     } else {
/* 1979 */       base = "";
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1984 */     NamingEnumeration<SearchResult> results = searchAsUser(connection.context, user, base, filter, controls, isRoleSearchAsUser());
/*      */     
/* 1986 */     if (results == null) {
/* 1987 */       return list;
/*      */     }
/*      */     
/* 1990 */     Map<String, String> groupMap = new HashMap<>();
/*      */     try {
/* 1992 */       while (results.hasMore()) {
/* 1993 */         SearchResult result = results.next();
/* 1994 */         Attributes attrs = result.getAttributes();
/* 1995 */         if (attrs == null) {
/*      */           continue;
/*      */         }
/* 1998 */         String dname = getDistinguishedName(connection.context, base, result);
/* 1999 */         String name = getAttributeValue(this.roleName, attrs);
/* 2000 */         if (name != null && dname != null) {
/* 2001 */           groupMap.put(dname, name);
/*      */         }
/*      */       } 
/* 2004 */     } catch (PartialResultException ex) {
/* 2005 */       if (!this.adCompat) {
/* 2006 */         throw ex;
/*      */       }
/*      */     } finally {
/* 2009 */       results.close();
/*      */     } 
/*      */     
/* 2012 */     if (this.containerLog.isTraceEnabled()) {
/* 2013 */       Set<Map.Entry<String, String>> entries = groupMap.entrySet();
/* 2014 */       this.containerLog.trace("  Found " + entries.size() + " direct roles");
/* 2015 */       for (Map.Entry<String, String> entry : entries) {
/* 2016 */         this.containerLog.trace("  Found direct role " + (String)entry.getKey() + " -> " + (String)entry.getValue());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2021 */     if (getRoleNested()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2027 */       Map<String, String> newGroups = new HashMap<>(groupMap);
/* 2028 */       while (!newGroups.isEmpty()) {
/* 2029 */         Map<String, String> newThisRound = new HashMap<>();
/*      */         
/* 2031 */         for (Map.Entry<String, String> group : newGroups.entrySet()) {
/*      */ 
/*      */ 
/*      */           
/* 2035 */           filter = connection.roleFormat.format(new String[] { doFilterEscaping(group.getKey()), 
/* 2036 */                 doFilterEscaping(doAttributeValueEscaping(group.getValue())), 
/* 2037 */                 doFilterEscaping(doAttributeValueEscaping(group.getValue())) });
/*      */           
/* 2039 */           if (this.containerLog.isTraceEnabled()) {
/* 2040 */             this.containerLog
/* 2041 */               .trace("Perform a nested group search with base " + this.roleBase + " and filter " + filter);
/*      */           }
/*      */           
/* 2044 */           results = searchAsUser(connection.context, user, base, filter, controls, isRoleSearchAsUser());
/*      */           
/*      */           try {
/* 2047 */             while (results.hasMore()) {
/* 2048 */               SearchResult result = results.next();
/* 2049 */               Attributes attrs = result.getAttributes();
/* 2050 */               if (attrs == null) {
/*      */                 continue;
/*      */               }
/* 2053 */               String dname = getDistinguishedName(connection.context, this.roleBase, result);
/* 2054 */               String name = getAttributeValue(this.roleName, attrs);
/* 2055 */               if (name != null && dname != null && !groupMap.containsKey(dname)) {
/* 2056 */                 groupMap.put(dname, name);
/* 2057 */                 newThisRound.put(dname, name);
/*      */                 
/* 2059 */                 if (this.containerLog.isTraceEnabled()) {
/* 2060 */                   this.containerLog.trace("  Found nested role " + dname + " -> " + name);
/*      */                 }
/*      */               } 
/*      */             } 
/* 2064 */           } catch (PartialResultException ex) {
/* 2065 */             if (!this.adCompat) {
/* 2066 */               throw ex;
/*      */             }
/*      */           } finally {
/* 2069 */             results.close();
/*      */           } 
/*      */         } 
/*      */         
/* 2073 */         newGroups = newThisRound;
/*      */       } 
/*      */     } 
/*      */     
/* 2077 */     list.addAll(groupMap.values());
/* 2078 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NamingEnumeration<SearchResult> searchAsUser(DirContext context, User user, String base, String filter, SearchControls controls, boolean searchAsUser) throws NamingException {
/*      */     NamingEnumeration<SearchResult> results;
/*      */     try {
/* 2102 */       if (searchAsUser) {
/* 2103 */         userCredentialsAdd(context, user.getDN(), user.getPassword());
/*      */       }
/* 2105 */       results = context.search(base, filter, controls);
/*      */     } finally {
/* 2107 */       if (searchAsUser) {
/* 2108 */         userCredentialsRemove(context);
/*      */       }
/*      */     } 
/* 2111 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getAttributeValue(String attrId, Attributes attrs) throws NamingException {
/*      */     String valueString;
/* 2127 */     if (this.containerLog.isTraceEnabled()) {
/* 2128 */       this.containerLog.trace("  retrieving attribute " + attrId);
/*      */     }
/*      */     
/* 2131 */     if (attrId == null || attrs == null) {
/* 2132 */       return null;
/*      */     }
/*      */     
/* 2135 */     Attribute attr = attrs.get(attrId);
/* 2136 */     if (attr == null) {
/* 2137 */       return null;
/*      */     }
/* 2139 */     Object value = attr.get();
/* 2140 */     if (value == null) {
/* 2141 */       return null;
/*      */     }
/*      */     
/* 2144 */     if (value instanceof byte[]) {
/* 2145 */       valueString = new String((byte[])value);
/*      */     } else {
/* 2147 */       valueString = value.toString();
/*      */     } 
/*      */     
/* 2150 */     return valueString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<String> addAttributeValues(String attrId, Attributes attrs, ArrayList<String> values) throws NamingException {
/* 2168 */     if (this.containerLog.isTraceEnabled()) {
/* 2169 */       this.containerLog.trace("  retrieving values for attribute " + attrId);
/*      */     }
/* 2171 */     if (attrId == null || attrs == null) {
/* 2172 */       return values;
/*      */     }
/* 2174 */     if (values == null) {
/* 2175 */       values = new ArrayList<>();
/*      */     }
/* 2177 */     Attribute attr = attrs.get(attrId);
/* 2178 */     if (attr == null) {
/* 2179 */       return values;
/*      */     }
/* 2181 */     NamingEnumeration<?> e = attr.getAll();
/*      */     try {
/* 2183 */       while (e.hasMore()) {
/* 2184 */         String value = (String)e.next();
/* 2185 */         values.add(value);
/*      */       } 
/* 2187 */     } catch (PartialResultException ex) {
/* 2188 */       if (!this.adCompat) {
/* 2189 */         throw ex;
/*      */       }
/*      */     } finally {
/* 2192 */       e.close();
/*      */     } 
/* 2194 */     return values;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void close(JNDIConnection connection) {
/* 2206 */     if (connection == null || connection.context == null) {
/* 2207 */       if (this.connectionPool == null) {
/* 2208 */         this.singleConnectionLock.unlock();
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2214 */     if (this.tls != null) {
/*      */       try {
/* 2216 */         this.tls.close();
/* 2217 */       } catch (IOException ioe) {
/* 2218 */         this.containerLog.error(sm.getString("jndiRealm.tlsClose"), ioe);
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/* 2223 */       if (this.containerLog.isTraceEnabled()) {
/* 2224 */         this.containerLog.trace("Closing directory context");
/*      */       }
/* 2226 */       connection.context.close();
/* 2227 */     } catch (NamingException e) {
/* 2228 */       this.containerLog.error(sm.getString("jndiRealm.close"), e);
/*      */     } 
/* 2230 */     connection.context = null;
/*      */     
/* 2232 */     if (this.connectionPool == null) {
/* 2233 */       this.singleConnectionLock.unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closePooledConnections() {
/* 2242 */     if (this.connectionPool != null)
/*      */     {
/* 2244 */       synchronized (this.connectionPool) {
/*      */         JNDIConnection connection;
/* 2246 */         while ((connection = (JNDIConnection)this.connectionPool.pop()) != null) {
/* 2247 */           close(connection);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getPassword(String username) {
/* 2256 */     String userPassword = getUserPassword();
/* 2257 */     if (userPassword == null || userPassword.isEmpty()) {
/* 2258 */       return null;
/*      */     }
/*      */     
/* 2261 */     JNDIConnection connection = null;
/*      */     
/*      */     try {
/*      */       User user;
/* 2265 */       connection = get();
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2270 */         user = getUser(connection, username, (String)null);
/* 2271 */       } catch (NullPointerException|NamingException e) {
/*      */         
/* 2273 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */ 
/*      */         
/* 2276 */         close(connection);
/* 2277 */         closePooledConnections();
/*      */ 
/*      */         
/* 2280 */         connection = get();
/*      */ 
/*      */         
/* 2283 */         user = getUser(connection, username, (String)null);
/*      */       } 
/*      */ 
/*      */       
/* 2287 */       release(connection);
/*      */       
/* 2289 */       if (user == null)
/*      */       {
/* 2291 */         return null;
/*      */       }
/*      */       
/* 2294 */       return user.getPassword();
/*      */     }
/* 2296 */     catch (Exception e) {
/*      */       
/* 2298 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */       
/* 2300 */       close(connection);
/* 2301 */       closePooledConnections();
/* 2302 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(String username) {
/* 2309 */     return getPrincipal(username, (GSSCredential)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(GSSName gssName, GSSCredential gssCredential) {
/* 2315 */     String name = gssName.toString();
/*      */     
/* 2317 */     if (isStripRealmForGss()) {
/* 2318 */       int i = name.indexOf('@');
/* 2319 */       if (i > 0)
/*      */       {
/* 2321 */         name = name.substring(0, i);
/*      */       }
/*      */     } 
/*      */     
/* 2325 */     return getPrincipal(name, gssCredential);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(String username, GSSCredential gssCredential) {
/* 2331 */     JNDIConnection connection = null;
/*      */     
/*      */     try {
/*      */       Principal principal;
/*      */       
/* 2336 */       connection = get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2343 */         principal = getPrincipal(connection, username, gssCredential);
/*      */       }
/* 2345 */       catch (NamingException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2352 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */ 
/*      */         
/* 2355 */         close(connection);
/* 2356 */         closePooledConnections();
/*      */ 
/*      */         
/* 2359 */         connection = get();
/*      */ 
/*      */         
/* 2362 */         principal = getPrincipal(connection, username, gssCredential);
/*      */       } 
/*      */ 
/*      */       
/* 2366 */       release(connection);
/*      */ 
/*      */       
/* 2369 */       return principal;
/*      */     }
/* 2371 */     catch (Exception e) {
/*      */       
/* 2373 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */ 
/*      */       
/* 2376 */       close(connection);
/* 2377 */       closePooledConnections();
/*      */ 
/*      */       
/* 2380 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Principal getPrincipal(JNDIConnection connection, String username, GSSCredential gssCredential) throws NamingException {
/*      */     User user;
/* 2400 */     List<String> roles = null;
/* 2401 */     Hashtable<?, ?> preservedEnvironment = null;
/* 2402 */     DirContext context = connection.context;
/*      */     
/*      */     try {
/* 2405 */       if (gssCredential != null && isUseDelegatedCredential()) {
/*      */         
/* 2407 */         preservedEnvironment = context.getEnvironment();
/*      */         
/* 2409 */         context.addToEnvironment("java.naming.security.authentication", "GSSAPI");
/* 2410 */         context.addToEnvironment("javax.security.sasl.server.authentication", "true");
/* 2411 */         context.addToEnvironment("javax.security.sasl.qop", this.spnegoDelegationQop);
/*      */       } 
/*      */ 
/*      */       
/* 2415 */       user = getUser(connection, username);
/* 2416 */       if (user != null) {
/* 2417 */         roles = getRoles(connection, user);
/*      */       }
/*      */     } finally {
/* 2420 */       if (gssCredential != null && isUseDelegatedCredential()) {
/* 2421 */         restoreEnvironmentParameter(context, "java.naming.security.authentication", preservedEnvironment);
/* 2422 */         restoreEnvironmentParameter(context, "javax.security.sasl.server.authentication", preservedEnvironment);
/* 2423 */         restoreEnvironmentParameter(context, "javax.security.sasl.qop", preservedEnvironment);
/*      */       } 
/*      */     } 
/*      */     
/* 2427 */     if (user != null) {
/* 2428 */       return (Principal)new GenericPrincipal(user.getUserName(), roles, null, null, gssCredential, null);
/*      */     }
/*      */     
/* 2431 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void restoreEnvironmentParameter(DirContext context, String parameterName, Hashtable<?, ?> preservedEnvironment) {
/*      */     try {
/* 2438 */       context.removeFromEnvironment(parameterName);
/* 2439 */       if (preservedEnvironment != null && preservedEnvironment.containsKey(parameterName)) {
/* 2440 */         context.addToEnvironment(parameterName, preservedEnvironment.get(parameterName));
/*      */       }
/* 2442 */     } catch (NamingException namingException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JNDIConnection get() throws NamingException {
/*      */     JNDIConnection connection;
/* 2458 */     if (this.connectionPool != null) {
/* 2459 */       connection = (JNDIConnection)this.connectionPool.pop();
/* 2460 */       if (connection == null) {
/* 2461 */         connection = create();
/*      */       }
/*      */     } else {
/* 2464 */       this.singleConnectionLock.lock();
/* 2465 */       if (this.singleConnection == null) {
/* 2466 */         this.singleConnection = create();
/*      */       }
/* 2468 */       connection = this.singleConnection;
/*      */     } 
/* 2470 */     if (connection.context == null) {
/* 2471 */       open(connection);
/*      */     }
/* 2473 */     return connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void release(JNDIConnection connection) {
/* 2483 */     if (this.connectionPool != null) {
/* 2484 */       if (connection != null && 
/* 2485 */         !this.connectionPool.push(connection))
/*      */       {
/* 2487 */         close(connection);
/*      */       }
/*      */     } else {
/*      */       
/* 2491 */       this.singleConnectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JNDIConnection create() {
/* 2502 */     return new JNDIConnection(this.userSearch, this.userPatternArray, this.roleBase, this.roleSearch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void open(JNDIConnection connection) throws NamingException {
/*      */     try {
/* 2516 */       connection.context = createDirContext(getDirectoryContextEnvironment());
/* 2517 */     } catch (Exception e) {
/* 2518 */       if (this.alternateURL == null || this.alternateURL.isEmpty())
/*      */       {
/* 2520 */         throw e;
/*      */       }
/* 2522 */       this.connectionAttempt = 1;
/*      */       
/* 2524 */       this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */       
/* 2526 */       connection.context = createDirContext(getDirectoryContextEnvironment());
/*      */     }
/*      */     finally {
/*      */       
/* 2530 */       this.connectionAttempt = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAvailable() {
/* 2538 */     return (this.connectionPool != null || this.singleConnection.context != null);
/*      */   }
/*      */ 
/*      */   
/*      */   private DirContext createDirContext(Hashtable<String, String> env) throws NamingException {
/* 2543 */     if (this.useStartTls) {
/* 2544 */       return createTlsDirContext(env);
/*      */     }
/* 2546 */     return new InitialDirContext(env);
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLSocketFactory getSSLSocketFactory() {
/*      */     SSLSocketFactory result;
/* 2552 */     if (this.sslSocketFactory != null) {
/* 2553 */       return this.sslSocketFactory;
/*      */     }
/*      */     
/* 2556 */     if (this.sslSocketFactoryClassName != null && !this.sslSocketFactoryClassName.trim().isEmpty()) {
/* 2557 */       result = createSSLSocketFactoryFromClassName(this.sslSocketFactoryClassName);
/*      */     } else {
/* 2559 */       result = createSSLContextFactoryFromProtocol(this.sslProtocol);
/*      */     } 
/* 2561 */     this.sslSocketFactory = result;
/* 2562 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLSocketFactory createSSLSocketFactoryFromClassName(String className) {
/*      */     try {
/* 2568 */       Object o = constructInstance(className);
/* 2569 */       if (o instanceof SSLSocketFactory) {
/* 2570 */         return this.sslSocketFactory;
/*      */       }
/* 2572 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }));
/*      */     }
/* 2574 */     catch (ReflectiveOperationException|SecurityException e) {
/* 2575 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private SSLSocketFactory createSSLContextFactoryFromProtocol(String protocol) {
/*      */     try {
/*      */       SSLContext sslContext;
/* 2583 */       if (protocol != null) {
/* 2584 */         sslContext = SSLContext.getInstance(protocol);
/* 2585 */         sslContext.init(null, null, null);
/*      */       } else {
/* 2587 */         sslContext = SSLContext.getDefault();
/*      */       } 
/* 2589 */       return sslContext.getSocketFactory();
/* 2590 */     } catch (NoSuchAlgorithmException|java.security.KeyManagementException e) {
/* 2591 */       List<String> allowedProtocols = Arrays.asList(getSupportedSslProtocols());
/* 2592 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslProtocol", new Object[] { protocol, allowedProtocols }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DirContext createTlsDirContext(Hashtable<String, String> env) throws NamingException {
/* 2608 */     Map<String, Object> savedEnv = new HashMap<>();
/* 2609 */     for (String key : Arrays.<String>asList(new String[] { "java.naming.security.authentication", "java.naming.security.credentials", "java.naming.security.principal", "java.naming.security.protocol" })) {
/*      */       
/* 2611 */       Object entry = env.remove(key);
/* 2612 */       if (entry != null) {
/* 2613 */         savedEnv.put(key, entry);
/*      */       }
/*      */     } 
/* 2616 */     LdapContext result = null;
/*      */     try {
/* 2618 */       result = new InitialLdapContext(env, null);
/* 2619 */       this.tls = (StartTlsResponse)result.extendedOperation(new StartTlsRequest());
/* 2620 */       if (getHostnameVerifier() != null) {
/* 2621 */         this.tls.setHostnameVerifier(getHostnameVerifier());
/*      */       }
/* 2623 */       if (getCipherSuitesArray() != null) {
/* 2624 */         this.tls.setEnabledCipherSuites(getCipherSuitesArray());
/*      */       }
/*      */       try {
/* 2627 */         SSLSession negotiate = this.tls.negotiate(getSSLSocketFactory());
/* 2628 */         this.containerLog.debug(sm.getString("jndiRealm.negotiatedTls", new Object[] { negotiate.getProtocol() }));
/* 2629 */       } catch (IOException ioe) {
/* 2630 */         NamingException ne = new NamingException(ioe.getMessage());
/* 2631 */         ne.initCause(ioe);
/* 2632 */         throw ne;
/*      */       } 
/*      */     } finally {
/* 2635 */       if (result != null) {
/* 2636 */         for (Map.Entry<String, Object> savedEntry : savedEnv.entrySet()) {
/* 2637 */           result.addToEnvironment(savedEntry.getKey(), savedEntry.getValue());
/*      */         }
/*      */       }
/*      */     } 
/* 2641 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Hashtable<String, String> getDirectoryContextEnvironment() {
/* 2652 */     Hashtable<String, String> env = new Hashtable<>();
/*      */ 
/*      */     
/* 2655 */     if (this.containerLog.isTraceEnabled() && this.connectionAttempt == 0) {
/* 2656 */       this.containerLog.trace("Connecting to URL " + this.connectionURL);
/* 2657 */     } else if (this.containerLog.isTraceEnabled() && this.connectionAttempt > 0) {
/* 2658 */       this.containerLog.trace("Connecting to URL " + this.alternateURL);
/*      */     } 
/* 2660 */     env.put("java.naming.factory.initial", this.contextFactory);
/* 2661 */     if (this.connectionName != null) {
/* 2662 */       env.put("java.naming.security.principal", this.connectionName);
/*      */     }
/* 2664 */     if (this.connectionPassword != null) {
/* 2665 */       env.put("java.naming.security.credentials", this.connectionPassword);
/*      */     }
/* 2667 */     if (this.connectionURL != null && this.connectionAttempt == 0) {
/* 2668 */       env.put("java.naming.provider.url", this.connectionURL);
/* 2669 */     } else if (this.alternateURL != null && this.connectionAttempt > 0) {
/* 2670 */       env.put("java.naming.provider.url", this.alternateURL);
/*      */     } 
/* 2672 */     if (this.authentication != null) {
/* 2673 */       env.put("java.naming.security.authentication", this.authentication);
/*      */     }
/* 2675 */     if (this.protocol != null) {
/* 2676 */       env.put("java.naming.security.protocol", this.protocol);
/*      */     }
/* 2678 */     if (this.referrals != null) {
/* 2679 */       env.put("java.naming.referral", this.referrals);
/*      */     }
/* 2681 */     if (this.derefAliases != null) {
/* 2682 */       env.put("java.naming.ldap.derefAliases", this.derefAliases);
/*      */     }
/* 2684 */     if (this.connectionTimeout != null) {
/* 2685 */       env.put("com.sun.jndi.ldap.connect.timeout", this.connectionTimeout);
/*      */     }
/* 2687 */     if (this.readTimeout != null) {
/* 2688 */       env.put("com.sun.jndi.ldap.read.timeout", this.readTimeout);
/*      */     }
/*      */     
/* 2691 */     return env;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/* 2707 */     if (this.connectionPoolSize != 1) {
/* 2708 */       this.connectionPool = new SynchronizedStack(128, this.connectionPoolSize);
/*      */     }
/*      */ 
/*      */     
/* 2712 */     ClassLoader ocl = null;
/* 2713 */     Thread currentThread = null;
/* 2714 */     JNDIConnection connection = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2720 */       if (!isUseContextClassLoader()) {
/* 2721 */         currentThread = Thread.currentThread();
/* 2722 */         ocl = currentThread.getContextClassLoader();
/* 2723 */         currentThread.setContextClassLoader(getClass().getClassLoader());
/*      */       } 
/* 2725 */       connection = get();
/* 2726 */     } catch (NamingException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2731 */       this.containerLog.error(sm.getString("jndiRealm.open"), e);
/*      */     } finally {
/* 2733 */       release(connection);
/* 2734 */       if (currentThread != null) {
/* 2735 */         currentThread.setContextClassLoader(ocl);
/*      */       }
/*      */     } 
/*      */     
/* 2739 */     super.startInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/* 2751 */     super.stopInternal();
/*      */     
/* 2753 */     if (this.connectionPool == null) {
/* 2754 */       this.singleConnectionLock.lock();
/* 2755 */       close(this.singleConnection);
/*      */     } else {
/* 2757 */       closePooledConnections();
/* 2758 */       this.connectionPool = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] parseUserPatternString(String userPatternString) {
/* 2774 */     if (userPatternString != null) {
/* 2775 */       List<String> pathList = new ArrayList<>();
/* 2776 */       int startParenLoc = userPatternString.indexOf('(');
/* 2777 */       if (startParenLoc == -1)
/*      */       {
/* 2779 */         return new String[] { userPatternString };
/*      */       }
/* 2781 */       while (startParenLoc > -1) {
/*      */ 
/*      */ 
/*      */         
/* 2785 */         while (userPatternString.charAt(startParenLoc + 1) == '|' || (startParenLoc != 0 && userPatternString
/* 2786 */           .charAt(startParenLoc - 1) == '\\')) {
/* 2787 */           startParenLoc = userPatternString.indexOf('(', startParenLoc + 1);
/*      */         }
/* 2789 */         int endParenLoc = userPatternString.indexOf(')', startParenLoc + 1);
/*      */         
/* 2791 */         while (userPatternString.charAt(endParenLoc - 1) == '\\') {
/* 2792 */           endParenLoc = userPatternString.indexOf(')', endParenLoc + 1);
/*      */         }
/* 2794 */         String nextPathPart = userPatternString.substring(startParenLoc + 1, endParenLoc);
/* 2795 */         pathList.add(nextPathPart);
/* 2796 */         startParenLoc = userPatternString.indexOf('(', endParenLoc + 1);
/*      */       } 
/* 2798 */       return pathList.<String>toArray(new String[0]);
/*      */     } 
/* 2800 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String doFilterEscaping(String inString) {
/* 2814 */     if (inString == null) {
/* 2815 */       return null;
/*      */     }
/* 2817 */     StringBuilder buf = new StringBuilder(inString.length());
/* 2818 */     for (int i = 0; i < inString.length(); i++) {
/* 2819 */       char c = inString.charAt(i);
/* 2820 */       switch (c) {
/*      */         case '\\':
/* 2822 */           buf.append("\\5c");
/*      */           break;
/*      */         case '*':
/* 2825 */           buf.append("\\2a");
/*      */           break;
/*      */         case '(':
/* 2828 */           buf.append("\\28");
/*      */           break;
/*      */         case ')':
/* 2831 */           buf.append("\\29");
/*      */           break;
/*      */         case '\000':
/* 2834 */           buf.append("\\00");
/*      */           break;
/*      */         default:
/* 2837 */           buf.append(c);
/*      */           break;
/*      */       } 
/*      */     } 
/* 2841 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDistinguishedName(DirContext context, String base, SearchResult result) throws NamingException {
/*      */     Name name;
/* 2860 */     String resultName = result.getName();
/*      */     
/* 2862 */     if (result.isRelative()) {
/* 2863 */       if (this.containerLog.isTraceEnabled()) {
/* 2864 */         this.containerLog.trace("  search returned relative name: " + resultName);
/*      */       }
/* 2866 */       NameParser parser = context.getNameParser("");
/* 2867 */       Name contextName = parser.parse(context.getNameInNamespace());
/* 2868 */       Name baseName = parser.parse(base);
/*      */ 
/*      */       
/* 2871 */       Name entryName = parser.parse((new CompositeName(resultName)).get(0));
/*      */       
/* 2873 */       name = contextName.addAll(baseName);
/* 2874 */       name = name.addAll(entryName);
/*      */     } else {
/* 2876 */       if (this.containerLog.isTraceEnabled()) {
/* 2877 */         this.containerLog.trace("  search returned absolute name: " + resultName);
/*      */       }
/*      */       
/*      */       try {
/* 2881 */         NameParser parser = context.getNameParser("");
/* 2882 */         URI userNameUri = new URI(resultName);
/* 2883 */         String pathComponent = userNameUri.getPath();
/*      */         
/* 2885 */         if (pathComponent.isEmpty()) {
/* 2886 */           throw new InvalidNameException(sm.getString("jndiRealm.invalidName", new Object[] { resultName }));
/*      */         }
/* 2888 */         name = parser.parse(pathComponent.substring(1));
/* 2889 */       } catch (URISyntaxException e) {
/* 2890 */         throw new InvalidNameException(sm.getString("jndiRealm.invalidName", new Object[] { resultName }));
/*      */       } 
/*      */     } 
/*      */     
/* 2894 */     if (getForceDnHexEscape())
/*      */     {
/* 2896 */       return convertToHexEscape(name.toString());
/*      */     }
/* 2898 */     return name.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String doAttributeValueEscaping(String input) {
/* 2911 */     if (input == null) {
/* 2912 */       return null;
/*      */     }
/* 2914 */     int len = input.length();
/* 2915 */     StringBuilder result = new StringBuilder();
/*      */     
/* 2917 */     for (int i = 0; i < len; i++) {
/* 2918 */       char c = input.charAt(i);
/* 2919 */       switch (c) {
/*      */         case ' ':
/* 2921 */           if (i == 0 || i == len - 1) {
/* 2922 */             result.append("\\20"); break;
/*      */           } 
/* 2924 */           result.append(c);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '#':
/* 2929 */           if (i == 0) {
/* 2930 */             result.append("\\23"); break;
/*      */           } 
/* 2932 */           result.append(c);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '"':
/* 2937 */           result.append("\\22");
/*      */           break;
/*      */         
/*      */         case '+':
/* 2941 */           result.append("\\2B");
/*      */           break;
/*      */         
/*      */         case ',':
/* 2945 */           result.append("\\2C");
/*      */           break;
/*      */         
/*      */         case ';':
/* 2949 */           result.append("\\3B");
/*      */           break;
/*      */         
/*      */         case '<':
/* 2953 */           result.append("\\3C");
/*      */           break;
/*      */         
/*      */         case '>':
/* 2957 */           result.append("\\3E");
/*      */           break;
/*      */         
/*      */         case '\\':
/* 2961 */           result.append("\\5C");
/*      */           break;
/*      */         
/*      */         case '\000':
/* 2965 */           result.append("\\00");
/*      */           break;
/*      */         
/*      */         default:
/* 2969 */           result.append(c);
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2974 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static String convertToHexEscape(String input) {
/* 2979 */     if (input.indexOf('\\') == -1)
/*      */     {
/* 2981 */       return input;
/*      */     }
/*      */ 
/*      */     
/* 2985 */     StringBuilder result = new StringBuilder(input.length() + 6);
/* 2986 */     boolean previousSlash = false;
/* 2987 */     for (int i = 0; i < input.length(); i++) {
/* 2988 */       char c = input.charAt(i);
/*      */       
/* 2990 */       if (previousSlash) {
/* 2991 */         switch (c) {
/*      */           case ' ':
/* 2993 */             result.append("\\20");
/*      */             break;
/*      */           
/*      */           case '"':
/* 2997 */             result.append("\\22");
/*      */             break;
/*      */           
/*      */           case '#':
/* 3001 */             result.append("\\23");
/*      */             break;
/*      */           
/*      */           case '+':
/* 3005 */             result.append("\\2B");
/*      */             break;
/*      */           
/*      */           case ',':
/* 3009 */             result.append("\\2C");
/*      */             break;
/*      */           
/*      */           case ';':
/* 3013 */             result.append("\\3B");
/*      */             break;
/*      */           
/*      */           case '<':
/* 3017 */             result.append("\\3C");
/*      */             break;
/*      */           
/*      */           case '=':
/* 3021 */             result.append("\\3D");
/*      */             break;
/*      */           
/*      */           case '>':
/* 3025 */             result.append("\\3E");
/*      */             break;
/*      */           
/*      */           case '\\':
/* 3029 */             result.append("\\5C");
/*      */             break;
/*      */           
/*      */           default:
/* 3033 */             result.append('\\');
/* 3034 */             result.append(c); break;
/*      */         } 
/* 3036 */         previousSlash = false;
/*      */       }
/* 3038 */       else if (c == '\\') {
/* 3039 */         previousSlash = true;
/*      */       } else {
/* 3041 */         result.append(c);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3046 */     if (previousSlash) {
/* 3047 */       result.append('\\');
/*      */     }
/*      */     
/* 3050 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static class User
/*      */   {
/*      */     private final String username;
/*      */     
/*      */     private final String dn;
/*      */     
/*      */     private final String password;
/*      */     
/*      */     private final List<String> roles;
/*      */     
/*      */     private final String userRoleId;
/*      */ 
/*      */     
/*      */     public User(String username, String dn, String password, List<String> roles, String userRoleId) {
/* 3068 */       this.username = username;
/* 3069 */       this.dn = dn;
/* 3070 */       this.password = password;
/* 3071 */       if (roles == null) {
/* 3072 */         this.roles = Collections.emptyList();
/*      */       } else {
/* 3074 */         this.roles = Collections.unmodifiableList(roles);
/*      */       } 
/* 3076 */       this.userRoleId = userRoleId;
/*      */     }
/*      */     
/*      */     public String getUserName() {
/* 3080 */       return this.username;
/*      */     }
/*      */     
/*      */     public String getDN() {
/* 3084 */       return this.dn;
/*      */     }
/*      */     
/*      */     public String getPassword() {
/* 3088 */       return this.password;
/*      */     }
/*      */     
/*      */     public List<String> getRoles() {
/* 3092 */       return this.roles;
/*      */     }
/*      */     
/*      */     public String getUserRoleId() {
/* 3096 */       return this.userRoleId;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class JNDIConnection
/*      */   {
/*      */     public final MessageFormat userSearchFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final MessageFormat[] userPatternFormatArray;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final MessageFormat roleBaseFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final MessageFormat roleFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3129 */     public volatile DirContext context = null;
/*      */ 
/*      */     
/*      */     public JNDIConnection(String userSearch, String[] userPatternArray, String roleBase, String roleSearch) {
/* 3133 */       if (userSearch == null) {
/* 3134 */         this.userSearchFormat = null;
/*      */       } else {
/* 3136 */         this.userSearchFormat = new MessageFormat(userSearch);
/*      */       } 
/*      */       
/* 3139 */       if (userPatternArray == null) {
/* 3140 */         this.userPatternFormatArray = null;
/*      */       } else {
/* 3142 */         int len = userPatternArray.length;
/* 3143 */         this.userPatternFormatArray = new MessageFormat[len];
/* 3144 */         for (int i = 0; i < len; i++) {
/* 3145 */           this.userPatternFormatArray[i] = new MessageFormat(userPatternArray[i]);
/*      */         }
/*      */       } 
/*      */       
/* 3149 */       if (roleBase == null) {
/* 3150 */         this.roleBaseFormat = null;
/*      */       } else {
/* 3152 */         this.roleBaseFormat = new MessageFormat(roleBase);
/*      */       } 
/*      */       
/* 3155 */       if (roleSearch == null) {
/* 3156 */         this.roleFormat = null;
/*      */       } else {
/* 3158 */         this.roleFormat = new MessageFormat(roleSearch);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\JNDIRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */