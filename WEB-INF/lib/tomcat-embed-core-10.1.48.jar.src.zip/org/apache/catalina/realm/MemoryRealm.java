/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryRealm
/*     */   extends RealmBase
/*     */ {
/*  44 */   private static final Log log = LogFactory.getLog(MemoryRealm.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static Digester digester = null;
/*  53 */   private static final Object digesterLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private String pathname = "conf/tomcat-users.xml";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final Map<String, GenericPrincipal> principals = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private final Map<String, String> credentials = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPathname() {
/*  82 */     return this.pathname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathname(String pathname) {
/*  95 */     this.pathname = pathname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal authenticate(String username, String credentials) {
/* 107 */     if (username == null || credentials == null) {
/* 108 */       if (log.isDebugEnabled()) {
/* 109 */         log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 111 */       return null;
/*     */     } 
/*     */     
/* 114 */     GenericPrincipal principal = this.principals.get(username);
/* 115 */     String password = null;
/* 116 */     if (principal != null) {
/* 117 */       password = this.credentials.get(username);
/*     */     }
/*     */     
/* 120 */     if (principal == null || password == null) {
/*     */ 
/*     */       
/* 123 */       getCredentialHandler().mutate(credentials);
/*     */       
/* 125 */       if (log.isDebugEnabled()) {
/* 126 */         log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 128 */       return null;
/*     */     } 
/*     */     
/* 131 */     boolean validated = getCredentialHandler().matches(credentials, password);
/*     */     
/* 133 */     if (validated) {
/* 134 */       if (log.isDebugEnabled()) {
/* 135 */         log.debug(sm.getString("memoryRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/* 137 */       return (Principal)principal;
/*     */     } 
/* 139 */     if (log.isDebugEnabled()) {
/* 140 */       log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */     }
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addUser(String username, String password, String roles) {
/* 160 */     List<String> list = new ArrayList<>();
/* 161 */     roles = roles + ",";
/*     */     while (true) {
/* 163 */       int comma = roles.indexOf(',');
/* 164 */       if (comma < 0) {
/*     */         break;
/*     */       }
/* 167 */       String role = roles.substring(0, comma).trim();
/* 168 */       list.add(role);
/* 169 */       roles = roles.substring(comma + 1);
/*     */     } 
/*     */ 
/*     */     
/* 173 */     GenericPrincipal principal = new GenericPrincipal(username, list);
/* 174 */     this.principals.put(username, principal);
/* 175 */     this.credentials.put(username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Digester getDigester() {
/* 189 */     synchronized (digesterLock) {
/* 190 */       if (digester == null) {
/* 191 */         digester = new Digester();
/* 192 */         digester.setValidating(false);
/*     */         try {
/* 194 */           digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/* 195 */         } catch (Exception e) {
/* 196 */           log.warn(sm.getString("memoryRealm.xmlFeatureEncoding"), e);
/*     */         } 
/* 198 */         digester.addRuleSet(new MemoryRuleSet());
/*     */       } 
/*     */     } 
/* 201 */     return digester;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPassword(String username) {
/* 207 */     return this.credentials.get(username);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal getPrincipal(String username) {
/* 213 */     return (Principal)this.principals.get(username);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 221 */     String pathName = getPathname(); 
/* 222 */     try { InputStream is = ConfigFileLoader.getSource().getResource(pathName).getInputStream();
/*     */       
/* 224 */       try { if (log.isTraceEnabled()) {
/* 225 */           log.trace(sm.getString("memoryRealm.loadPath", new Object[] { pathName }));
/*     */         }
/*     */         
/* 228 */         synchronized (digesterLock) {
/* 229 */           Digester digester = getDigester();
/*     */           try {
/* 231 */             digester.push(this);
/* 232 */             digester.parse(is);
/* 233 */           } catch (Exception e) {
/* 234 */             throw new LifecycleException(sm.getString("memoryRealm.readXml"), e);
/*     */           } finally {
/* 236 */             digester.reset();
/*     */           } 
/*     */         } 
/* 239 */         if (is != null) is.close();  } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 240 */     { throw new LifecycleException(sm.getString("memoryRealm.loadExist", new Object[] { pathName }), ioe); }
/*     */ 
/*     */     
/* 243 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\MemoryRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */