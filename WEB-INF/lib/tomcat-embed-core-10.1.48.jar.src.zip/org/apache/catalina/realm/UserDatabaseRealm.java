/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.naming.Context;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDatabaseRealm
/*     */   extends RealmBase
/*     */ {
/*  51 */   protected volatile UserDatabase database = null;
/*  52 */   private final Object databaseLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   protected String resourceName = "UserDatabase";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean localJndiResource = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useStaticPrincipal = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResourceName() {
/*  77 */     return this.resourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceName(String resourceName) {
/*  87 */     this.resourceName = resourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUseStaticPrincipal() {
/*  95 */     return this.useStaticPrincipal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseStaticPrincipal(boolean useStaticPrincipal) {
/* 105 */     this.useStaticPrincipal = useStaticPrincipal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLocalJndiResource() {
/* 116 */     return this.localJndiResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalJndiResource(boolean localJndiResource) {
/* 127 */     this.localJndiResource = localJndiResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void backgroundProcess() {
/* 138 */     UserDatabase database = getUserDatabase();
/* 139 */     if (database != null) {
/* 140 */       database.backgroundProcess();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPassword(String username) {
/* 147 */     UserDatabase database = getUserDatabase();
/* 148 */     if (database == null) {
/* 149 */       return null;
/*     */     }
/*     */     
/* 152 */     User user = database.findUser(username);
/*     */     
/* 154 */     if (user == null) {
/* 155 */       return null;
/*     */     }
/*     */     
/* 158 */     return user.getPassword();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] getRoles(User user) {
/* 163 */     Set<String> roles = new HashSet<>();
/* 164 */     Iterator<Role> uroles = user.getRoles();
/* 165 */     while (uroles.hasNext()) {
/* 166 */       Role role = uroles.next();
/* 167 */       roles.add(role.getName());
/*     */     } 
/* 169 */     Iterator<Group> groups = user.getGroups();
/* 170 */     while (groups.hasNext()) {
/* 171 */       Group group = groups.next();
/* 172 */       uroles = group.getRoles();
/* 173 */       while (uroles.hasNext()) {
/* 174 */         Role role = uroles.next();
/* 175 */         roles.add(role.getName());
/*     */       } 
/*     */     } 
/* 178 */     return roles.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Principal getPrincipal(String username) {
/* 184 */     UserDatabase database = getUserDatabase();
/* 185 */     if (database == null) {
/* 186 */       return null;
/*     */     }
/* 188 */     User user = database.findUser(username);
/* 189 */     if (user == null) {
/* 190 */       return null;
/*     */     }
/* 192 */     if (this.useStaticPrincipal) {
/* 193 */       return (Principal)new GenericPrincipal(username, Arrays.asList(getRoles(user)));
/*     */     }
/* 195 */     return (Principal)new UserDatabasePrincipal(user, database);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDatabase getUserDatabase() {
/* 206 */     if (this.database == null) {
/* 207 */       synchronized (this.databaseLock) {
/* 208 */         if (this.database == null) {
/*     */           try {
/*     */             Context context;
/* 211 */             if (this.localJndiResource) {
/* 212 */               context = ContextBindings.getClassLoader();
/* 213 */               context = (Context)context.lookup("comp/env");
/*     */             } else {
/* 215 */               Server server = getServer();
/* 216 */               if (server == null) {
/* 217 */                 this.containerLog.error(sm.getString("userDatabaseRealm.noNamingContext"));
/* 218 */                 return null;
/*     */               } 
/* 220 */               context = server.getGlobalNamingContext();
/*     */             } 
/* 222 */             this.database = (UserDatabase)context.lookup(this.resourceName);
/* 223 */           } catch (Throwable t) {
/* 224 */             ExceptionUtils.handleThrowable(t);
/* 225 */             if (this.containerLog != null) {
/* 226 */               this.containerLog.error(sm.getString("userDatabaseRealm.lookup", new Object[] { this.resourceName }), t);
/*     */             }
/* 228 */             this.database = null;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 233 */     return this.database;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 244 */     if (!this.localJndiResource) {
/* 245 */       UserDatabase database = getUserDatabase();
/* 246 */       if (database == null) {
/* 247 */         throw new LifecycleException(sm.getString("userDatabaseRealm.noDatabase", new Object[] { this.resourceName }));
/*     */       }
/*     */     } 
/*     */     
/* 251 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 259 */     super.stopInternal();
/*     */ 
/*     */     
/* 262 */     this.database = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/* 268 */     return (this.database != null && this.database.isAvailable());
/*     */   }
/*     */   
/*     */   public static final class UserDatabasePrincipal
/*     */     extends GenericPrincipal {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final transient UserDatabase database;
/*     */     
/*     */     public UserDatabasePrincipal(User user, UserDatabase database) {
/* 277 */       super(user.getName());
/* 278 */       this.database = database;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getRoles() {
/* 283 */       if (this.database == null) {
/* 284 */         return new String[0];
/*     */       }
/* 286 */       User user = this.database.findUser(this.name);
/* 287 */       if (user == null) {
/* 288 */         return new String[0];
/*     */       }
/* 290 */       Set<String> roles = new HashSet<>();
/* 291 */       Iterator<Role> uroles = user.getRoles();
/* 292 */       while (uroles.hasNext()) {
/* 293 */         Role role = uroles.next();
/* 294 */         roles.add(role.getName());
/*     */       } 
/* 296 */       Iterator<Group> groups = user.getGroups();
/* 297 */       while (groups.hasNext()) {
/* 298 */         Group group = groups.next();
/* 299 */         uroles = group.getRoles();
/* 300 */         while (uroles.hasNext()) {
/* 301 */           Role role = uroles.next();
/* 302 */           roles.add(role.getName());
/*     */         } 
/*     */       } 
/* 305 */       return roles.<String>toArray(new String[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasRole(String role) {
/* 310 */       if ("*".equals(role))
/* 311 */         return true; 
/* 312 */       if (role == null) {
/* 313 */         return false;
/*     */       }
/* 315 */       if (this.database == null) {
/* 316 */         return super.hasRole(role);
/*     */       }
/* 318 */       Role dbrole = this.database.findRole(role);
/* 319 */       if (dbrole == null) {
/* 320 */         return false;
/*     */       }
/* 322 */       User user = this.database.findUser(this.name);
/* 323 */       if (user == null) {
/* 324 */         return false;
/*     */       }
/* 326 */       if (user.isInRole(dbrole)) {
/* 327 */         return true;
/*     */       }
/* 329 */       Iterator<Group> groups = user.getGroups();
/* 330 */       while (groups.hasNext()) {
/* 331 */         Group group = groups.next();
/* 332 */         if (group.isInRole(dbrole)) {
/* 333 */           return true;
/*     */         }
/*     */       } 
/* 336 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object writeReplace() throws ObjectStreamException {
/* 348 */       return new GenericPrincipal(getName(), Arrays.asList(getRoles()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\UserDatabaseRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */