/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDigestCredentialHandler
/*     */   extends DigestCredentialHandlerBase
/*     */ {
/*  55 */   private static final Log log = LogFactory.getLog(MessageDigestCredentialHandler.class);
/*     */   
/*     */   public static final int DEFAULT_ITERATIONS = 1;
/*     */   
/*  59 */   private Charset encoding = StandardCharsets.UTF_8;
/*  60 */   private String algorithm = null;
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/*  64 */     return this.encoding.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEncoding(String encodingName) {
/*  69 */     if (encodingName == null) {
/*  70 */       this.encoding = StandardCharsets.UTF_8;
/*     */     } else {
/*     */       try {
/*  73 */         this.encoding = B2CConverter.getCharset(encodingName);
/*  74 */       } catch (UnsupportedEncodingException e) {
/*  75 */         log.error(sm.getString("mdCredentialHandler.unknownEncoding", new Object[] { encodingName, this.encoding.name() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlgorithm() {
/*  83 */     return this.algorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlgorithm(String algorithm) throws NoSuchAlgorithmException {
/*  89 */     ConcurrentMessageDigest.init(algorithm);
/*  90 */     this.algorithm = algorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(String inputCredentials, String storedCredentials) {
/*  96 */     if (inputCredentials == null || storedCredentials == null) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     if (getAlgorithm() == null)
/*     */     {
/* 102 */       return DigestCredentialHandlerBase.equals(inputCredentials, storedCredentials, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (storedCredentials.startsWith("{MD5}") || storedCredentials.startsWith("{SHA}")) {
/*     */ 
/*     */       
/* 110 */       String base64ServerDigest = storedCredentials.substring(5);
/* 111 */       byte[] arrayOfByte = ConcurrentMessageDigest.digest(getAlgorithm(), new byte[][] { inputCredentials
/* 112 */             .getBytes(StandardCharsets.ISO_8859_1) });
/* 113 */       String base64UserDigest = Base64.getEncoder().encodeToString(arrayOfByte);
/*     */       
/* 115 */       return DigestCredentialHandlerBase.equals(base64UserDigest, base64ServerDigest, false);
/* 116 */     }  if (storedCredentials.startsWith("{SSHA}")) {
/*     */ 
/*     */ 
/*     */       
/* 120 */       String serverDigestPlusSalt = storedCredentials.substring(6);
/* 121 */       byte[] serverDigestPlusSaltBytes = Base64.getDecoder().decode(serverDigestPlusSalt);
/*     */ 
/*     */       
/* 124 */       int digestLength = 20;
/* 125 */       byte[] serverDigestBytes = new byte[20];
/* 126 */       System.arraycopy(serverDigestPlusSaltBytes, 0, serverDigestBytes, 0, 20);
/*     */ 
/*     */       
/* 129 */       int saltLength = serverDigestPlusSaltBytes.length - 20;
/* 130 */       byte[] serverSaltBytes = new byte[saltLength];
/* 131 */       System.arraycopy(serverDigestPlusSaltBytes, 20, serverSaltBytes, 0, saltLength);
/*     */ 
/*     */ 
/*     */       
/* 135 */       byte[] userDigestBytes = ConcurrentMessageDigest.digest(getAlgorithm(), new byte[][] { inputCredentials
/* 136 */             .getBytes(StandardCharsets.ISO_8859_1), serverSaltBytes });
/*     */       
/* 138 */       return Arrays.equals(userDigestBytes, serverDigestBytes);
/* 139 */     }  if (storedCredentials.indexOf('$') > -1) {
/* 140 */       return matchesSaltIterationsEncoded(inputCredentials, storedCredentials);
/*     */     }
/*     */     
/* 143 */     String userDigest = mutate(inputCredentials, (byte[])null, 1);
/* 144 */     if (userDigest == null)
/*     */     {
/*     */       
/* 147 */       return false;
/*     */     }
/* 149 */     return storedCredentials.equalsIgnoreCase(userDigest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String mutate(String inputCredentials, byte[] salt, int iterations) {
/*     */     byte[] userDigest;
/* 157 */     if (this.algorithm == null) {
/* 158 */       return inputCredentials;
/*     */     }
/* 160 */     byte[] inputCredentialbytes = inputCredentials.getBytes(this.encoding);
/*     */     
/* 162 */     if (salt == null) {
/* 163 */       userDigest = ConcurrentMessageDigest.digest(this.algorithm, iterations, new byte[][] { inputCredentialbytes });
/*     */     } else {
/* 165 */       userDigest = ConcurrentMessageDigest.digest(this.algorithm, iterations, new byte[][] { salt, inputCredentialbytes });
/*     */     } 
/* 167 */     return HexUtils.toHexString(userDigest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultIterations() {
/* 174 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLog() {
/* 180 */     return log;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\MessageDigestCredentialHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */