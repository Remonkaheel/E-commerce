/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DigestCredentialHandlerBase
/*     */   implements CredentialHandler
/*     */ {
/*  34 */   protected static final StringManager sm = StringManager.getManager(DigestCredentialHandlerBase.class);
/*     */   
/*     */   public static final int DEFAULT_SALT_LENGTH = 32;
/*     */   
/*  38 */   private int iterations = getDefaultIterations();
/*  39 */   private int saltLength = getDefaultSaltLength();
/*  40 */   private final Object randomLock = new Object();
/*  41 */   private volatile Random random = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logInvalidStoredCredentials = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIterations() {
/*  50 */     return this.iterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIterations(int iterations) {
/*  61 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSaltLength() {
/*  69 */     return this.saltLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaltLength(int saltLength) {
/*  79 */     this.saltLength = saltLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLogInvalidStoredCredentials() {
/*  90 */     return this.logInvalidStoredCredentials;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogInvalidStoredCredentials(boolean logInvalidStoredCredentials) {
/* 101 */     this.logInvalidStoredCredentials = logInvalidStoredCredentials;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String mutate(String userCredential) {
/* 107 */     byte[] salt = null;
/* 108 */     int iterations = getIterations();
/* 109 */     int saltLength = getSaltLength();
/* 110 */     if (saltLength == 0) {
/* 111 */       salt = new byte[0];
/* 112 */     } else if (saltLength > 0) {
/*     */       
/* 114 */       if (this.random == null) {
/* 115 */         synchronized (this.randomLock) {
/* 116 */           if (this.random == null) {
/* 117 */             this.random = new SecureRandom();
/*     */           }
/*     */         } 
/*     */       }
/* 121 */       salt = new byte[saltLength];
/*     */ 
/*     */       
/* 124 */       this.random.nextBytes(salt);
/*     */     } 
/*     */     
/* 127 */     String serverCredential = mutate(userCredential, salt, iterations);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (serverCredential == null) {
/* 133 */       return null;
/*     */     }
/*     */     
/* 136 */     if (saltLength == 0 && iterations == 1)
/*     */     {
/* 138 */       return serverCredential;
/*     */     }
/* 140 */     return HexUtils.toHexString(salt) + "$" + HexUtils.toHexString(salt) + "$" + iterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchesSaltIterationsEncoded(String inputCredentials, String storedCredentials) {
/*     */     byte[] salt;
/* 156 */     if (storedCredentials == null) {
/*     */ 
/*     */       
/* 159 */       logInvalidStoredCredentials(null);
/* 160 */       return false;
/*     */     } 
/*     */     
/* 163 */     int sep1 = storedCredentials.indexOf('$');
/* 164 */     int sep2 = storedCredentials.indexOf('$', sep1 + 1);
/*     */     
/* 166 */     if (sep1 < 0 || sep2 < 0) {
/*     */ 
/*     */       
/* 169 */       logInvalidStoredCredentials(storedCredentials);
/* 170 */       return false;
/*     */     } 
/*     */     
/* 173 */     String hexSalt = storedCredentials.substring(0, sep1);
/*     */     
/* 175 */     int iterations = Integer.parseInt(storedCredentials.substring(sep1 + 1, sep2));
/*     */     
/* 177 */     String storedHexEncoded = storedCredentials.substring(sep2 + 1);
/*     */     
/*     */     try {
/* 180 */       salt = HexUtils.fromHexString(hexSalt);
/* 181 */     } catch (IllegalArgumentException iae) {
/* 182 */       logInvalidStoredCredentials(storedCredentials);
/* 183 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 187 */     String inputHexEncoded = mutate(inputCredentials, salt, iterations, (HexUtils.fromHexString(storedHexEncoded)).length * 8);
/* 188 */     if (inputHexEncoded == null)
/*     */     {
/*     */       
/* 191 */       return false;
/*     */     }
/*     */     
/* 194 */     return equals(storedHexEncoded, inputHexEncoded, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void logInvalidStoredCredentials(String storedCredentials) {
/* 199 */     if (this.logInvalidStoredCredentials)
/*     */     {
/*     */       
/* 202 */       getLog().warn(sm.getString("credentialHandler.invalidStoredCredential", new Object[] { storedCredentials }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultSaltLength() {
/* 211 */     return 32;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String mutate(String paramString, byte[] paramArrayOfbyte, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String mutate(String inputCredentials, byte[] salt, int iterations, int keyLength) {
/* 245 */     return mutate(inputCredentials, salt, iterations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setAlgorithm(String paramString) throws NoSuchAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getAlgorithm();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getDefaultIterations();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Log getLog();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(String s1, String s2, boolean ignoreCase) {
/* 291 */     if (s1 == s2) {
/* 292 */       return true;
/*     */     }
/* 294 */     if (s1 == null || s2 == null) {
/* 295 */       return false;
/*     */     }
/*     */     
/* 298 */     int len1 = s1.length();
/* 299 */     int len2 = s2.length();
/*     */     
/* 301 */     if (len2 == 0) {
/* 302 */       return (len1 == 0);
/*     */     }
/*     */     
/* 305 */     int result = 0;
/* 306 */     result |= len1 - len2;
/*     */ 
/*     */     
/* 309 */     for (int i = 0; i < len1; i++) {
/*     */       
/* 311 */       int index2 = (i - len2 >>> 31) * i;
/* 312 */       char c1 = s1.charAt(i);
/* 313 */       char c2 = s2.charAt(index2);
/* 314 */       if (ignoreCase) {
/* 315 */         c1 = Character.toLowerCase(c1);
/* 316 */         c2 = Character.toLowerCase(c2);
/*     */       } 
/* 318 */       result |= c1 ^ c2;
/*     */     } 
/* 320 */     return (result == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(byte[] b1, byte[] b2) {
/* 338 */     return MessageDigest.isEqual(b1, b2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\DigestCredentialHandlerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */