/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.TextInputCallback;
/*     */ import javax.security.auth.login.FailedLoginException;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.security.auth.spi.LoginModule;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAASMemoryLoginModule
/*     */   extends MemoryRealm
/*     */   implements LoginModule
/*     */ {
/*  73 */   private static final Log log = LogFactory.getLog(JAASMemoryLoginModule.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   protected CallbackHandler callbackHandler = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean committed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected Map<String, ?> options = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected String pathname = "conf/tomcat-users.xml";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   protected Principal principal = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   protected Map<String, ?> sharedState = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   protected Subject subject = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JAASMemoryLoginModule() {
/* 123 */     if (log.isTraceEnabled()) {
/* 124 */       log.trace("MEMORY LOGIN MODULE");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean abort() throws LoginException {
/* 133 */     if (this.principal == null) {
/* 134 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 138 */     if (this.committed) {
/* 139 */       logout();
/*     */     } else {
/* 141 */       this.principal = null;
/*     */     } 
/* 143 */     if (log.isTraceEnabled()) {
/* 144 */       log.trace("Abort");
/*     */     }
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean commit() throws LoginException {
/* 152 */     if (log.isTraceEnabled()) {
/* 153 */       log.trace("commit " + String.valueOf(this.principal));
/*     */     }
/*     */ 
/*     */     
/* 157 */     if (this.principal == null) {
/* 158 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 162 */     if (!this.subject.getPrincipals().contains(this.principal)) {
/* 163 */       this.subject.getPrincipals().add(this.principal);
/*     */ 
/*     */       
/* 166 */       if (this.principal instanceof GenericPrincipal) {
/* 167 */         String[] roles = ((GenericPrincipal)this.principal).getRoles();
/* 168 */         for (String role : roles) {
/* 169 */           this.subject.getPrincipals().add(new GenericPrincipal(role));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 175 */     this.committed = true;
/* 176 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState, Map<String, ?> options) {
/* 183 */     if (log.isTraceEnabled()) {
/* 184 */       log.trace("Init");
/*     */     }
/*     */ 
/*     */     
/* 188 */     this.subject = subject;
/* 189 */     this.callbackHandler = callbackHandler;
/* 190 */     this.sharedState = sharedState;
/* 191 */     this.options = options;
/*     */ 
/*     */     
/* 194 */     Object option = options.get("pathname");
/* 195 */     if (option instanceof String) {
/* 196 */       this.pathname = (String)option;
/*     */     }
/*     */     
/* 199 */     CredentialHandler credentialHandler = null;
/* 200 */     option = options.get("credentialHandlerClassName");
/* 201 */     if (option instanceof String) {
/*     */       try {
/* 203 */         Class<?> clazz = Class.forName((String)option);
/* 204 */         credentialHandler = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 205 */       } catch (ReflectiveOperationException e) {
/* 206 */         throw new IllegalArgumentException(e);
/*     */       } 
/*     */     }
/* 209 */     if (credentialHandler == null) {
/* 210 */       credentialHandler = new MessageDigestCredentialHandler();
/*     */     }
/*     */     
/* 213 */     for (Map.Entry<String, ?> entry : options.entrySet()) {
/* 214 */       if ("pathname".equals(entry.getKey())) {
/*     */         continue;
/*     */       }
/* 217 */       if ("credentialHandlerClassName".equals(entry.getKey())) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 222 */       if (entry.getValue() instanceof String) {
/* 223 */         IntrospectionUtils.setProperty(credentialHandler, entry.getKey(), (String)entry.getValue());
/*     */       }
/*     */     } 
/* 226 */     setCredentialHandler(credentialHandler);
/*     */ 
/*     */     
/* 229 */     load();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean login() throws LoginException {
/*     */     String username, password, nonce, nc, cnonce, qop, realmName, digestA2, algorithm, authMethod;
/* 236 */     if (this.callbackHandler == null) {
/* 237 */       throw new LoginException(sm.getString("jaasMemoryLoginModule.noCallbackHandler"));
/*     */     }
/* 239 */     Callback[] callbacks = new Callback[10];
/* 240 */     callbacks[0] = new NameCallback("Username: ");
/* 241 */     callbacks[1] = new PasswordCallback("Password: ", false);
/* 242 */     callbacks[2] = new TextInputCallback("nonce");
/* 243 */     callbacks[3] = new TextInputCallback("nc");
/* 244 */     callbacks[4] = new TextInputCallback("cnonce");
/* 245 */     callbacks[5] = new TextInputCallback("qop");
/* 246 */     callbacks[6] = new TextInputCallback("realmName");
/* 247 */     callbacks[7] = new TextInputCallback("digestA2");
/* 248 */     callbacks[8] = new TextInputCallback("algorithm");
/* 249 */     callbacks[9] = new TextInputCallback("authMethod");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 264 */       this.callbackHandler.handle(callbacks);
/* 265 */       username = ((NameCallback)callbacks[0]).getName();
/* 266 */       char[] passwordArray = ((PasswordCallback)callbacks[1]).getPassword();
/* 267 */       password = (passwordArray == null) ? null : new String(passwordArray);
/* 268 */       nonce = ((TextInputCallback)callbacks[2]).getText();
/* 269 */       nc = ((TextInputCallback)callbacks[3]).getText();
/* 270 */       cnonce = ((TextInputCallback)callbacks[4]).getText();
/* 271 */       qop = ((TextInputCallback)callbacks[5]).getText();
/* 272 */       realmName = ((TextInputCallback)callbacks[6]).getText();
/* 273 */       digestA2 = ((TextInputCallback)callbacks[7]).getText();
/* 274 */       algorithm = ((TextInputCallback)callbacks[8]).getText();
/* 275 */       authMethod = ((TextInputCallback)callbacks[9]).getText();
/* 276 */     } catch (IOException|javax.security.auth.callback.UnsupportedCallbackException e) {
/* 277 */       throw new LoginException(sm.getString("jaasMemoryLoginModule.callbackHandlerError", new Object[] { e.toString() }));
/*     */     } 
/*     */ 
/*     */     
/* 281 */     if (authMethod == null) {
/*     */       
/* 283 */       this.principal = authenticate(username, password);
/* 284 */     } else if (authMethod.equals("DIGEST")) {
/* 285 */       this.principal = authenticate(username, password, nonce, nc, cnonce, qop, realmName, digestA2, algorithm);
/* 286 */     } else if (authMethod.equals("CLIENT_CERT")) {
/* 287 */       this.principal = getPrincipal(username);
/*     */     } else {
/* 289 */       throw new LoginException(sm.getString("jaasMemoryLoginModule.unknownAuthenticationMethod"));
/*     */     } 
/*     */     
/* 292 */     if (log.isDebugEnabled()) {
/* 293 */       log.debug(sm.getString("jaasMemoryLoginModule.login", new Object[] { username, this.principal }));
/*     */     }
/*     */ 
/*     */     
/* 297 */     if (this.principal != null) {
/* 298 */       return true;
/*     */     }
/* 300 */     throw new FailedLoginException(sm.getString("jaasMemoryLoginModule.invalidCredentials"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean logout() throws LoginException {
/* 307 */     this.subject.getPrincipals().remove(this.principal);
/* 308 */     this.committed = false;
/* 309 */     this.principal = null;
/* 310 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void load() {
/* 322 */     File file = new File(this.pathname);
/* 323 */     if (!file.isAbsolute()) {
/* 324 */       String catalinaBase = getCatalinaBase();
/* 325 */       if (catalinaBase == null) {
/* 326 */         log.error(sm.getString("jaasMemoryLoginModule.noCatalinaBase", new Object[] { this.pathname }));
/*     */         return;
/*     */       } 
/* 329 */       file = new File(catalinaBase, this.pathname);
/*     */     } 
/*     */     
/* 332 */     if (!file.canRead()) {
/* 333 */       log.error(sm.getString("jaasMemoryLoginModule.noConfig", new Object[] { file.getAbsolutePath() }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 338 */     Digester digester = new Digester();
/* 339 */     digester.setValidating(false);
/* 340 */     digester.addRuleSet(new MemoryRuleSet());
/*     */     try {
/* 342 */       digester.push(this);
/* 343 */       digester.parse(file);
/* 344 */     } catch (Exception e) {
/* 345 */       log.error(sm.getString("jaasMemoryLoginModule.parseError", new Object[] { file.getAbsolutePath() }), e);
/*     */     } finally {
/* 347 */       digester.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCatalinaBase() {
/*     */     String result;
/* 356 */     if (this.callbackHandler == null) {
/* 357 */       return null;
/*     */     }
/*     */     
/* 360 */     Callback[] callbacks = new Callback[1];
/* 361 */     callbacks[0] = new TextInputCallback("catalinaBase");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 366 */       this.callbackHandler.handle(callbacks);
/* 367 */       result = ((TextInputCallback)callbacks[0]).getText();
/* 368 */     } catch (IOException|javax.security.auth.callback.UnsupportedCallbackException e) {
/* 369 */       return null;
/*     */     } 
/*     */     
/* 372 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\JAASMemoryLoginModule.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */