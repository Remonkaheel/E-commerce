/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X509SubjectDnRetriever
/*    */   implements X509UsernameRetriever
/*    */ {
/*    */   public String getUsername(X509Certificate clientCert) {
/* 28 */     return clientCert.getSubjectX500Principal().toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\X509SubjectDnRetriever.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */