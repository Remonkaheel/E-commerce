/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.security.Principal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullRealm
/*    */   extends RealmBase
/*    */ {
/*    */   protected String getPassword(String username) {
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Principal getPrincipal(String username) {
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\realm\NullRealm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */