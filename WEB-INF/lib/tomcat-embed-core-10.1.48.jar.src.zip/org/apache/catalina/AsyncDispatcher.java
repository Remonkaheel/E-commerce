package org.apache.catalina;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;

public interface AsyncDispatcher {
  void dispatch(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\AsyncDispatcher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */