/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CsrfPreventionFilterBase
/*     */   extends FilterBase
/*     */ {
/*  34 */   private final Log log = LogFactory.getLog(CsrfPreventionFilterBase.class);
/*     */   
/*  36 */   private String randomClass = SecureRandom.class.getName();
/*     */   
/*     */   private Random randomSource;
/*     */   
/*  40 */   private int denyStatus = 403;
/*     */ 
/*     */   
/*     */   protected Log getLogger() {
/*  44 */     return this.log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDenyStatus() {
/*  51 */     return this.denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDenyStatus(int denyStatus) {
/*  61 */     this.denyStatus = denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRandomClass(String randomClass) {
/*  70 */     this.randomClass = randomClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  76 */     super.init(filterConfig);
/*     */     
/*     */     try {
/*  79 */       Class<?> clazz = Class.forName(this.randomClass);
/*  80 */       this.randomSource = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  81 */     } catch (ReflectiveOperationException e) {
/*  82 */       throw new ServletException(sm.getString("csrfPrevention.invalidRandomClass", new Object[] { this.randomClass }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/*  88 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateNonce(HttpServletRequest request) {
/* 101 */     byte[] random = new byte[16];
/*     */ 
/*     */     
/* 104 */     StringBuilder buffer = new StringBuilder();
/*     */     
/* 106 */     this.randomSource.nextBytes(random);
/*     */     
/* 108 */     for (byte b : random) {
/* 109 */       byte b1 = (byte)((b & 0xF0) >> 4);
/* 110 */       byte b2 = (byte)(b & 0xF);
/* 111 */       if (b1 < 10) {
/* 112 */         buffer.append((char)(48 + b1));
/*     */       } else {
/* 114 */         buffer.append((char)(65 + b1 - 10));
/*     */       } 
/* 116 */       if (b2 < 10) {
/* 117 */         buffer.append((char)(48 + b2));
/*     */       } else {
/* 119 */         buffer.append((char)(65 + b2 - 10));
/*     */       } 
/*     */     } 
/*     */     
/* 123 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected String getRequestedPath(HttpServletRequest request) {
/* 127 */     String path = request.getServletPath();
/* 128 */     if (request.getPathInfo() != null) {
/* 129 */       path = path + path;
/*     */     }
/* 131 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\CsrfPreventionFilterBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */