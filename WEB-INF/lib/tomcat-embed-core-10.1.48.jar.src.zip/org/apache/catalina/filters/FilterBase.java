/*    */ package org.apache.catalina.filters;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import jakarta.servlet.FilterConfig;
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.util.Enumeration;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.tomcat.util.IntrospectionUtils;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FilterBase
/*    */   implements Filter
/*    */ {
/* 34 */   protected static final StringManager sm = StringManager.getManager(FilterBase.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Log getLogger();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 50 */     Enumeration<String> paramNames = filterConfig.getInitParameterNames();
/* 51 */     while (paramNames.hasMoreElements()) {
/* 52 */       String paramName = paramNames.nextElement();
/* 53 */       if (!IntrospectionUtils.setProperty(this, paramName, filterConfig.getInitParameter(paramName))) {
/* 54 */         String msg = sm.getString("filterbase.noSuchProperty", new Object[] { paramName, getClass().getName() });
/* 55 */         if (isConfigProblemFatal()) {
/* 56 */           throw new ServletException(msg);
/*    */         }
/* 58 */         getLogger().warn(msg);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isConfigProblemFatal() {
/* 71 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\FilterBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */