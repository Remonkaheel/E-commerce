package org.apache.catalina.filters;

public final class Constants {
  public static final String CSRF_NONCE_SESSION_ATTR_NAME = "org.apache.catalina.filters.CSRF_NONCE";
  
  public static final String CSRF_NONCE_REQUEST_ATTR_NAME = "org.apache.catalina.filters.CSRF_REQUEST_NONCE";
  
  public static final String CSRF_NONCE_REQUEST_PARAM = "org.apache.catalina.filters.CSRF_NONCE";
  
  public static final String CSRF_NONCE_REQUEST_PARAM_NAME_KEY = "org.apache.catalina.filters.CSRF_NONCE_PARAM_NAME";
  
  @Deprecated
  public static final String METHOD_GET = "GET";
  
  public static final String CSRF_REST_NONCE_HEADER_NAME = "X-CSRF-Token";
  
  public static final String CSRF_REST_NONCE_HEADER_FETCH_VALUE = "Fetch";
  
  public static final String CSRF_REST_NONCE_HEADER_REQUIRED_VALUE = "Required";
  
  public static final String CSRF_REST_NONCE_SESSION_ATTR_NAME = "org.apache.catalina.filters.CSRF_REST_NONCE";
  
  public static final String CSRF_REST_NONCE_HEADER_NAME_KEY = "org.apache.catalina.filters.CSRF_REST_NONCE_HEADER_NAME";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */