/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.catalina.util.RateLimiter;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RateLimitFilter
/*     */   extends FilterBase
/*     */ {
/*     */   public static final int DEFAULT_BUCKET_DURATION = 60;
/*     */   public static final int DEFAULT_BUCKET_REQUESTS = 300;
/*     */   public static final boolean DEFAULT_ENFORCE = true;
/*     */   public static final boolean DEFAULT_EXPOSE_HEADERS = false;
/*     */   public static final String HEADER_RATE_LIMIT_POLICY = "RateLimit-Policy";
/*     */   public static final String HEADER_RATE_LIMIT = "RateLimit";
/*     */   public static final int DEFAULT_STATUS_CODE = 429;
/*     */   public static final String DEFAULT_STATUS_MESSAGE = "Too many requests";
/*     */   public static final String RATE_LIMIT_ATTRIBUTE_COUNT = "org.apache.catalina.filters.RateLimitFilter.Count";
/*     */   transient RateLimiter rateLimiter;
/* 133 */   private String rateLimitClassName = "org.apache.catalina.util.FastRateLimiter";
/*     */   
/* 135 */   private int bucketRequests = 300;
/*     */   
/* 137 */   private int bucketDuration = 60;
/*     */   
/*     */   private boolean enforce = true;
/*     */   
/* 141 */   private int statusCode = 429;
/*     */   
/* 143 */   private String statusMessage = "Too many requests";
/*     */   
/*     */   private String filterName;
/*     */   
/*     */   private boolean exposeHeaders = false;
/*     */   
/* 149 */   private String policyName = null;
/*     */   
/* 151 */   private final transient Log log = LogFactory.getLog(RateLimitFilter.class);
/*     */   
/* 153 */   private static final StringManager sm = StringManager.getManager(RateLimitFilter.class);
/*     */ 
/*     */   
/*     */   public void setBucketDuration(int bucketDuration) {
/* 157 */     this.bucketDuration = bucketDuration;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBucketRequests(int bucketRequests) {
/* 162 */     this.bucketRequests = bucketRequests;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnforce(boolean enforce) {
/* 167 */     this.enforce = enforce;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusCode(int statusCode) {
/* 172 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusMessage(String statusMessage) {
/* 177 */     this.statusMessage = statusMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRateLimitClassName(String rateLimitClassName) {
/* 182 */     this.rateLimitClassName = rateLimitClassName;
/*     */   }
/*     */   
/*     */   public void setExposeHeaders(boolean exposeHeaders) {
/* 186 */     this.exposeHeaders = exposeHeaders;
/*     */   }
/*     */   
/*     */   public void setPolicyName(String policyName) {
/* 190 */     this.policyName = policyName;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/* 195 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/* 201 */     super.init(filterConfig);
/*     */     
/*     */     try {
/* 204 */       this.rateLimiter = Class.forName(this.rateLimitClassName).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 205 */     } catch (ReflectiveOperationException e) {
/* 206 */       throw new ServletException(e);
/*     */     } 
/*     */     
/* 209 */     this.rateLimiter.setDuration(this.bucketDuration);
/* 210 */     this.rateLimiter.setRequests(this.bucketRequests);
/* 211 */     this.rateLimiter.setFilterConfig(filterConfig);
/*     */     
/* 213 */     if (this.policyName != null) {
/* 214 */       String trimmedName = this.policyName.trim();
/* 215 */       if (!trimmedName.isEmpty()) {
/* 216 */         this.rateLimiter.setPolicyName(trimmedName);
/*     */       }
/*     */     } 
/*     */     
/* 220 */     this.filterName = filterConfig.getFilterName();
/*     */     
/* 222 */     this.log.info(sm.getString("rateLimitFilter.initialized", new Object[] { this.filterName, Integer.valueOf(this.bucketRequests), 
/* 223 */             Integer.valueOf(this.bucketDuration), Integer.valueOf(this.rateLimiter.getRequests()), 
/* 224 */             Integer.valueOf(this.rateLimiter.getDuration()), (!this.enforce ? "Not " : "") + "enforcing" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 231 */     String ipAddr = request.getRemoteAddr();
/* 232 */     int reqCount = this.rateLimiter.increment(ipAddr);
/*     */     
/* 234 */     request.setAttribute("org.apache.catalina.filters.RateLimitFilter.Count", Integer.valueOf(reqCount));
/*     */     
/* 236 */     if (this.exposeHeaders) {
/* 237 */       ((HttpServletResponse)response).addHeader("RateLimit-Policy", this.rateLimiter.getPolicy());
/* 238 */       if (this.enforce) {
/* 239 */         ((HttpServletResponse)response).addHeader("RateLimit", this.rateLimiter.getQuota(reqCount));
/*     */       }
/*     */     } 
/* 242 */     if (reqCount > this.rateLimiter.getRequests()) {
/*     */       
/* 244 */       this.log.warn(sm.getString("rateLimitFilter.maxRequestsExceeded", new Object[] { this.filterName, Integer.valueOf(reqCount), ipAddr, 
/* 245 */               Integer.valueOf(this.rateLimiter.getRequests()), Integer.valueOf(this.rateLimiter.getDuration()) }));
/*     */       
/* 247 */       if (this.enforce) {
/* 248 */         ((HttpServletResponse)response).sendError(this.statusCode, this.statusMessage);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 253 */     chain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 258 */     this.rateLimiter.destroy();
/* 259 */     super.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLogger() {
/* 265 */     return this.log;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\RateLimitFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */