/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.GenericFilter;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class WebdavFixFilter
/*     */   extends GenericFilter
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  62 */   protected static final StringManager sm = StringManager.getManager(WebdavFixFilter.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String UA_MINIDIR_START = "Microsoft-WebDAV-MiniRedir";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String UA_MINIDIR_5_1_2600 = "Microsoft-WebDAV-MiniRedir/5.1.2600";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String UA_MINIDIR_5_2_3790 = "Microsoft-WebDAV-MiniRedir/5.2.3790";
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  79 */     if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
/*  80 */       chain.doFilter(request, response);
/*     */       return;
/*     */     } 
/*  83 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  84 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*  85 */     String ua = httpRequest.getHeader("User-Agent");
/*     */     
/*  87 */     if (ua == null || ua.length() == 0 || !ua.startsWith("Microsoft-WebDAV-MiniRedir")) {
/*     */ 
/*     */       
/*  90 */       chain.doFilter(request, response);
/*  91 */     } else if (ua.startsWith("Microsoft-WebDAV-MiniRedir/5.1.2600")) {
/*     */       
/*  93 */       httpResponse.sendRedirect(buildRedirect(httpRequest));
/*  94 */     } else if (ua.startsWith("Microsoft-WebDAV-MiniRedir/5.2.3790")) {
/*     */       
/*  96 */       if (!httpRequest.getContextPath().isEmpty()) {
/*  97 */         getServletContext().log(sm.getString("webDavFilter.xpRootContext"));
/*     */       }
/*     */ 
/*     */       
/* 101 */       getServletContext().log(sm.getString("webDavFilter.xpProblem"));
/*     */       
/* 103 */       chain.doFilter(request, response);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 108 */       httpResponse.sendRedirect(buildRedirect(httpRequest));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String buildRedirect(HttpServletRequest request) {
/* 113 */     StringBuilder location = new StringBuilder(request.getRequestURL().length());
/* 114 */     location.append(request.getScheme());
/* 115 */     location.append("://");
/* 116 */     location.append(request.getServerName());
/* 117 */     location.append(':');
/*     */ 
/*     */ 
/*     */     
/* 121 */     location.append(request.getServerPort());
/* 122 */     location.append(request.getRequestURI());
/* 123 */     return location.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\WebdavFixFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */