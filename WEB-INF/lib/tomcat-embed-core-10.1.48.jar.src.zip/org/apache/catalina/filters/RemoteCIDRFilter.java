/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.util.NetMaskSet;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RemoteCIDRFilter
/*     */   extends FilterBase
/*     */ {
/*     */   private static final String PLAIN_TEXT_MIME_TYPE = "text/plain";
/*  47 */   private final Log log = LogFactory.getLog(RemoteCIDRFilter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private final NetMaskSet allow = new NetMaskSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private final NetMaskSet deny = new NetMaskSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllow() {
/*  66 */     return this.allow.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllow(String input) {
/*  78 */     List<String> messages = this.allow.addAll(input);
/*     */     
/*  80 */     if (messages.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  84 */     for (String message : messages) {
/*  85 */       this.log.error(message);
/*     */     }
/*     */     
/*  88 */     throw new IllegalArgumentException(sm.getString("remoteCidrFilter.invalid", new Object[] { "allow" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeny() {
/*  98 */     return this.deny.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeny(String input) {
/* 110 */     List<String> messages = this.deny.addAll(input);
/*     */     
/* 112 */     if (messages.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 116 */     for (String message : messages) {
/* 117 */       this.log.error(message);
/*     */     }
/*     */     
/* 120 */     throw new IllegalArgumentException(sm.getString("remoteCidrFilter.invalid", new Object[] { "deny" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 136 */     if (isAllowed(request.getRemoteAddr())) {
/* 137 */       chain.doFilter(request, response);
/*     */       
/*     */       return;
/*     */     } 
/* 141 */     if (!(response instanceof HttpServletResponse)) {
/* 142 */       sendErrorWhenNotHttp(response);
/*     */       
/*     */       return;
/*     */     } 
/* 146 */     ((HttpServletResponse)response).sendError(403);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Log getLogger() {
/* 152 */     return this.log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAllowed(String property) {
/*     */     InetAddress addr;
/*     */     try {
/* 167 */       addr = InetAddress.getByName(property);
/* 168 */     } catch (UnknownHostException e) {
/*     */ 
/*     */       
/* 171 */       this.log.error(sm.getString("remoteCidrFilter.noRemoteIp"), e);
/* 172 */       return false;
/*     */     } 
/*     */     
/* 175 */     if (this.deny.contains(addr)) {
/* 176 */       return false;
/*     */     }
/*     */     
/* 179 */     if (this.allow.contains(addr)) {
/* 180 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 185 */     return (!this.deny.isEmpty() && this.allow.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendErrorWhenNotHttp(ServletResponse response) throws IOException {
/* 190 */     PrintWriter writer = response.getWriter();
/* 191 */     response.setContentType("text/plain");
/* 192 */     writer.write(sm.getString("http.403"));
/* 193 */     writer.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\RemoteCIDRFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */