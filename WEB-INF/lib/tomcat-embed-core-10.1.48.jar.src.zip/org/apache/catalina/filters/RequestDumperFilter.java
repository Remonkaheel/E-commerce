/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.GenericFilter;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestDumperFilter
/*     */   extends GenericFilter
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String NON_HTTP_REQ_MSG = "Not available. Non-http request.";
/*     */   private static final String NON_HTTP_RES_MSG = "Not available. Non-http response.";
/*  57 */   private static final ThreadLocal<Timestamp> timestamp = ThreadLocal.withInitial(() -> new Timestamp());
/*     */ 
/*     */ 
/*     */   
/*  61 */   private transient Log log = LogFactory.getLog(RequestDumperFilter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  79 */     HttpServletRequest hRequest = null;
/*  80 */     HttpServletResponse hResponse = null;
/*     */     
/*  82 */     if (request instanceof HttpServletRequest) {
/*  83 */       hRequest = (HttpServletRequest)request;
/*     */     }
/*  85 */     if (response instanceof HttpServletResponse) {
/*  86 */       hResponse = (HttpServletResponse)response;
/*     */     }
/*     */ 
/*     */     
/*  90 */     doLog("START TIME        ", getTimestamp());
/*     */     
/*  92 */     if (hRequest == null) {
/*  93 */       doLog("        requestURI", "Not available. Non-http request.");
/*  94 */       doLog("          authType", "Not available. Non-http request.");
/*     */     } else {
/*  96 */       doLog("        requestURI", hRequest.getRequestURI());
/*  97 */       doLog("          authType", hRequest.getAuthType());
/*     */     } 
/*     */     
/* 100 */     doLog(" characterEncoding", request.getCharacterEncoding());
/* 101 */     doLog("     contentLength", Long.toString(request.getContentLengthLong()));
/* 102 */     doLog("       contentType", request.getContentType());
/*     */     
/* 104 */     if (hRequest == null) {
/* 105 */       doLog("       contextPath", "Not available. Non-http request.");
/* 106 */       doLog("            cookie", "Not available. Non-http request.");
/* 107 */       doLog("            header", "Not available. Non-http request.");
/*     */     } else {
/* 109 */       doLog("       contextPath", hRequest.getContextPath());
/* 110 */       Cookie[] cookies = hRequest.getCookies();
/* 111 */       if (cookies != null) {
/* 112 */         for (Cookie cookie : cookies) {
/* 113 */           doLog("            cookie", cookie.getName() + "=" + cookie.getName());
/*     */         }
/*     */       }
/* 116 */       Enumeration<String> hnames = hRequest.getHeaderNames();
/* 117 */       while (hnames.hasMoreElements()) {
/* 118 */         String hname = hnames.nextElement();
/* 119 */         Enumeration<String> hvalues = hRequest.getHeaders(hname);
/* 120 */         while (hvalues.hasMoreElements()) {
/* 121 */           String hvalue = hvalues.nextElement();
/* 122 */           doLog("            header", hname + "=" + hname);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     doLog("            locale", request.getLocale().toString());
/*     */     
/* 129 */     if (hRequest == null) {
/* 130 */       doLog("            method", "Not available. Non-http request.");
/*     */     } else {
/* 132 */       doLog("            method", hRequest.getMethod());
/*     */     } 
/*     */     
/* 135 */     Enumeration<String> pnames = request.getParameterNames();
/* 136 */     while (pnames.hasMoreElements()) {
/* 137 */       String pname = pnames.nextElement();
/* 138 */       String[] pvalues = request.getParameterValues(pname);
/* 139 */       StringBuilder result = new StringBuilder(pname);
/* 140 */       result.append('=');
/* 141 */       for (int i = 0; i < pvalues.length; i++) {
/* 142 */         if (i > 0) {
/* 143 */           result.append(", ");
/*     */         }
/* 145 */         result.append(pvalues[i]);
/*     */       } 
/* 147 */       doLog("         parameter", result.toString());
/*     */     } 
/*     */     
/* 150 */     if (hRequest == null) {
/* 151 */       doLog("          pathInfo", "Not available. Non-http request.");
/*     */     } else {
/* 153 */       doLog("          pathInfo", hRequest.getPathInfo());
/*     */     } 
/*     */     
/* 156 */     doLog("          protocol", request.getProtocol());
/*     */     
/* 158 */     if (hRequest == null) {
/* 159 */       doLog("       queryString", "Not available. Non-http request.");
/*     */     } else {
/* 161 */       doLog("       queryString", hRequest.getQueryString());
/*     */     } 
/*     */     
/* 164 */     doLog("        remoteAddr", request.getRemoteAddr());
/* 165 */     doLog("        remoteHost", request.getRemoteHost());
/*     */     
/* 167 */     if (hRequest == null) {
/* 168 */       doLog("        remoteUser", "Not available. Non-http request.");
/* 169 */       doLog("requestedSessionId", "Not available. Non-http request.");
/*     */     } else {
/* 171 */       doLog("        remoteUser", hRequest.getRemoteUser());
/* 172 */       doLog("requestedSessionId", hRequest.getRequestedSessionId());
/*     */     } 
/*     */     
/* 175 */     doLog("            scheme", request.getScheme());
/* 176 */     doLog("        serverName", request.getServerName());
/* 177 */     doLog("        serverPort", Integer.toString(request.getServerPort()));
/*     */     
/* 179 */     if (hRequest == null) {
/* 180 */       doLog("       servletPath", "Not available. Non-http request.");
/*     */     } else {
/* 182 */       doLog("       servletPath", hRequest.getServletPath());
/*     */     } 
/*     */     
/* 185 */     doLog("          isSecure", Boolean.valueOf(request.isSecure()).toString());
/* 186 */     doLog("------------------", "--------------------------------------------");
/*     */ 
/*     */     
/* 189 */     chain.doFilter(request, response);
/*     */ 
/*     */     
/* 192 */     doLog("------------------", "--------------------------------------------");
/* 193 */     if (hRequest == null) {
/* 194 */       doLog("          authType", "Not available. Non-http request.");
/*     */     } else {
/* 196 */       doLog("          authType", hRequest.getAuthType());
/*     */     } 
/*     */     
/* 199 */     doLog("       contentType", response.getContentType());
/*     */     
/* 201 */     if (hResponse == null) {
/* 202 */       doLog("            header", "Not available. Non-http response.");
/*     */     } else {
/* 204 */       Iterable<String> rhnames = hResponse.getHeaderNames();
/* 205 */       for (String rhname : rhnames) {
/* 206 */         Iterable<String> rhvalues = hResponse.getHeaders(rhname);
/* 207 */         for (String rhvalue : rhvalues) {
/* 208 */           doLog("            header", rhname + "=" + rhname);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 213 */     if (hRequest == null) {
/* 214 */       doLog("        remoteUser", "Not available. Non-http request.");
/*     */     } else {
/* 216 */       doLog("        remoteUser", hRequest.getRemoteUser());
/*     */     } 
/*     */     
/* 219 */     if (hResponse == null) {
/* 220 */       doLog("            status", "Not available. Non-http response.");
/*     */     } else {
/* 222 */       doLog("            status", Integer.toString(hResponse.getStatus()));
/*     */     } 
/*     */     
/* 225 */     doLog("END TIME          ", getTimestamp());
/* 226 */     doLog("==================", "============================================");
/*     */   }
/*     */   
/*     */   private void doLog(String attribute, String value) {
/* 230 */     String sb = Thread.currentThread().getName() + " " + Thread.currentThread().getName() + "=" + attribute;
/* 231 */     this.log.info(sb);
/*     */   }
/*     */   
/*     */   private String getTimestamp() {
/* 235 */     Timestamp ts = timestamp.get();
/* 236 */     long currentTime = System.currentTimeMillis();
/*     */     
/* 238 */     if (ts.date.getTime() + 999L < currentTime) {
/* 239 */       ts.date.setTime(currentTime - currentTime % 1000L);
/* 240 */       ts.update();
/*     */     } 
/* 242 */     return ts.dateString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
/* 251 */     ois.defaultReadObject();
/* 252 */     this.log = LogFactory.getLog(RequestDumperFilter.class);
/*     */   }
/*     */   
/*     */   private static final class Timestamp
/*     */   {
/* 257 */     private final Date date = new Date(0L);
/* 258 */     private final SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
/* 259 */     private String dateString = this.format.format(this.date);
/*     */     
/*     */     private void update() {
/* 262 */       this.dateString = this.format.format(this.date);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\RequestDumperFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */