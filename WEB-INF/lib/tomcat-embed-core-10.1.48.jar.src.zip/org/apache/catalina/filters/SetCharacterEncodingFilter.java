/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetCharacterEncodingFilter
/*     */   extends FilterBase
/*     */ {
/*  56 */   private final Log log = LogFactory.getLog(SetCharacterEncodingFilter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private String encoding = null;
/*     */   
/*     */   public void setEncoding(String encoding) {
/*  67 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/*  71 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignore = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnore(boolean ignore) {
/*  81 */     this.ignore = ignore;
/*     */   }
/*     */   
/*     */   public boolean isIgnore() {
/*  85 */     return this.ignore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 107 */     if (this.ignore || request.getCharacterEncoding() == null) {
/* 108 */       String characterEncoding = selectEncoding(request);
/* 109 */       if (characterEncoding != null) {
/* 110 */         request.setCharacterEncoding(characterEncoding);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 115 */     chain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLogger() {
/* 123 */     return this.log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String selectEncoding(ServletRequest request) {
/* 139 */     return this.encoding;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\SetCharacterEncodingFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */