/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import jakarta.servlet.FilterChain;
/*      */ import jakarta.servlet.GenericFilter;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.ServletRequestWrapper;
/*      */ import jakarta.servlet.ServletResponse;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.PushBuilder;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.Collections;
/*      */ import java.util.Deque;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.parser.Host;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RemoteIpFilter
/*      */   extends GenericFilter
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected static final String HTTP_SERVER_PORT_PARAMETER = "httpServerPort";
/*      */   protected static final String HTTPS_SERVER_PORT_PARAMETER = "httpsServerPort";
/*      */   protected static final String INTERNAL_PROXIES_PARAMETER = "internalProxies";
/*      */   
/*      */   public static class XForwardedRequest
/*      */     extends HttpServletRequestWrapper
/*      */   {
/*      */     protected final Map<String, List<String>> headers;
/*      */     protected String localName;
/*      */     protected int localPort;
/*      */     protected String remoteAddr;
/*      */     protected String remoteHost;
/*      */     protected String scheme;
/*      */     protected boolean secure;
/*      */     protected String serverName;
/*      */     protected int serverPort;
/*      */     
/*      */     public XForwardedRequest(HttpServletRequest request) {
/*  492 */       super(request);
/*  493 */       this.localName = request.getLocalName();
/*  494 */       this.localPort = request.getLocalPort();
/*  495 */       this.remoteAddr = request.getRemoteAddr();
/*  496 */       this.remoteHost = request.getRemoteHost();
/*  497 */       this.scheme = request.getScheme();
/*  498 */       this.secure = request.isSecure();
/*  499 */       this.serverName = request.getServerName();
/*  500 */       this.serverPort = request.getServerPort();
/*      */       
/*  502 */       this.headers = new HashMap<>();
/*  503 */       for (Enumeration<String> headerNames = request.getHeaderNames(); headerNames.hasMoreElements(); ) {
/*  504 */         String header = headerNames.nextElement();
/*  505 */         this.headers.put(header, Collections.list(request.getHeaders(header)));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public long getDateHeader(String name) {
/*  511 */       String value = getHeader(name);
/*  512 */       if (value == null) {
/*  513 */         return -1L;
/*      */       }
/*  515 */       long date = FastHttpDateFormat.parseDate(value);
/*  516 */       if (date == -1L) {
/*  517 */         throw new IllegalArgumentException(value);
/*      */       }
/*  519 */       return date;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getHeader(String name) {
/*  524 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  525 */       if (header == null || header.getValue() == null || ((List)header.getValue()).isEmpty()) {
/*  526 */         return null;
/*      */       }
/*  528 */       return ((List<String>)header.getValue()).get(0);
/*      */     }
/*      */     
/*      */     protected Map.Entry<String, List<String>> getHeaderEntry(String name) {
/*  532 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  533 */         if (((String)entry.getKey()).equalsIgnoreCase(name)) {
/*  534 */           return entry;
/*      */         }
/*      */       } 
/*  537 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Enumeration<String> getHeaderNames() {
/*  542 */       return Collections.enumeration(this.headers.keySet());
/*      */     }
/*      */ 
/*      */     
/*      */     public Enumeration<String> getHeaders(String name) {
/*  547 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  548 */       if (header == null || header.getValue() == null) {
/*  549 */         return Collections.enumeration(Collections.emptyList());
/*      */       }
/*  551 */       return Collections.enumeration(header.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public int getIntHeader(String name) {
/*  556 */       String value = getHeader(name);
/*  557 */       if (value == null) {
/*  558 */         return -1;
/*      */       }
/*  560 */       return Integer.parseInt(value);
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLocalName() {
/*  565 */       return this.localName;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getLocalPort() {
/*  570 */       return this.localPort;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getRemoteAddr() {
/*  575 */       return this.remoteAddr;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getRemoteHost() {
/*  580 */       return this.remoteHost;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getScheme() {
/*  585 */       return this.scheme;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getServerName() {
/*  590 */       return this.serverName;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getServerPort() {
/*  595 */       return this.serverPort;
/*      */     }
/*      */     
/*      */     public void removeHeader(String name) {
/*  599 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  600 */       if (header != null) {
/*  601 */         this.headers.remove(header.getKey());
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value) {
/*  606 */       List<String> values = Collections.singletonList(value);
/*  607 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  608 */       if (header == null) {
/*  609 */         this.headers.put(name, values);
/*      */       } else {
/*  611 */         header.setValue(values);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setLocalName(String localName) {
/*  617 */       this.localName = localName;
/*      */     }
/*      */     
/*      */     public void setLocalPort(int localPort) {
/*  621 */       this.localPort = localPort;
/*      */     }
/*      */     
/*      */     public void setRemoteAddr(String remoteAddr) {
/*  625 */       this.remoteAddr = remoteAddr;
/*      */     }
/*      */     
/*      */     public void setRemoteHost(String remoteHost) {
/*  629 */       this.remoteHost = remoteHost;
/*      */     }
/*      */     
/*      */     public void setScheme(String scheme) {
/*  633 */       this.scheme = scheme;
/*      */     }
/*      */     
/*      */     public void setSecure(boolean secure) {
/*  637 */       getRequest().setAttribute("org.apache.catalina.filters.RemoteIpFilter.secure", Boolean.valueOf(secure));
/*      */     }
/*      */     
/*      */     public void setServerName(String serverName) {
/*  641 */       this.serverName = serverName;
/*      */     }
/*      */     
/*      */     public void setServerPort(int serverPort) {
/*  645 */       this.serverPort = serverPort;
/*      */     }
/*      */ 
/*      */     
/*      */     public StringBuffer getRequestURL() {
/*  650 */       return RequestUtil.getRequestURL((HttpServletRequest)this);
/*      */     }
/*      */ 
/*      */     
/*      */     public PushBuilder newPushBuilder() {
/*  655 */       ServletRequest current = getRequest();
/*  656 */       while (current instanceof ServletRequestWrapper) {
/*  657 */         current = ((ServletRequestWrapper)current).getRequest();
/*      */       }
/*  659 */       if (current instanceof RequestFacade) {
/*  660 */         return ((RequestFacade)current).newPushBuilder((HttpServletRequest)this);
/*      */       }
/*  662 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  676 */   private transient Log log = LogFactory.getLog(RemoteIpFilter.class);
/*  677 */   protected static final StringManager sm = StringManager.getManager(RemoteIpFilter.class);
/*      */ 
/*      */   
/*      */   protected static final String PROTOCOL_HEADER_PARAMETER = "protocolHeader";
/*      */ 
/*      */   
/*      */   protected static final String PROTOCOL_HEADER_HTTPS_VALUE_PARAMETER = "protocolHeaderHttpsValue";
/*      */ 
/*      */   
/*      */   protected static final String HOST_HEADER_PARAMETER = "hostHeader";
/*      */ 
/*      */   
/*      */   protected static final String PORT_HEADER_PARAMETER = "portHeader";
/*      */ 
/*      */   
/*      */   protected static final String CHANGE_LOCAL_NAME_PARAMETER = "changeLocalName";
/*      */ 
/*      */   
/*      */   protected static final String CHANGE_LOCAL_PORT_PARAMETER = "changeLocalPort";
/*      */ 
/*      */   
/*      */   protected static final String PROXIES_HEADER_PARAMETER = "proxiesHeader";
/*      */ 
/*      */   
/*      */   protected static final String REMOTE_IP_HEADER_PARAMETER = "remoteIpHeader";
/*      */   
/*      */   protected static final String TRUSTED_PROXIES_PARAMETER = "trustedProxies";
/*      */   
/*      */   protected static final String ENABLE_LOOKUPS_PARAMETER = "enableLookups";
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings) {
/*  710 */     return StringUtils.splitCommaSeparated(commaDelimitedStrings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected static String listToCommaDelimitedString(List<String> stringList) {
/*  724 */     if (stringList == null) {
/*  725 */       return "";
/*      */     }
/*  727 */     StringBuilder result = new StringBuilder();
/*  728 */     for (Iterator<String> it = stringList.iterator(); it.hasNext(); ) {
/*  729 */       Object element = it.next();
/*  730 */       if (element != null) {
/*  731 */         result.append(element);
/*  732 */         if (it.hasNext()) {
/*  733 */           result.append(", ");
/*      */         }
/*      */       } 
/*      */     } 
/*  737 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  743 */   private int httpServerPort = 80;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  748 */   private int httpsServerPort = 443;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  753 */   private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|100\\.6[4-9]{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.[7-9]{1}\\d{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.1[0-1]{1}\\d{1}\\.\\d{1,3}\\.\\d{1,3}|100\\.12[0-7]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}|0:0:0:0:0:0:0:1|::1|fe[89ab]\\p{XDigit}:.*|f[cd]\\p{XDigit}{2}+:.*");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  764 */   private String protocolHeader = "X-Forwarded-Proto";
/*      */   
/*  766 */   private String protocolHeaderHttpsValue = "https";
/*      */   
/*  768 */   private String hostHeader = null;
/*      */   
/*      */   private boolean changeLocalName = false;
/*      */   
/*  772 */   private String portHeader = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean changeLocalPort = false;
/*      */ 
/*      */   
/*  779 */   private String proxiesHeader = "X-Forwarded-By";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  784 */   private String remoteIpHeader = "X-Forwarded-For";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean requestAttributesEnabled = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  794 */   private Pattern trustedProxies = null;
/*      */ 
/*      */   
/*      */   private boolean enableLookups;
/*      */ 
/*      */   
/*      */   public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  801 */     boolean isInternal = (this.internalProxies != null && this.internalProxies.matcher(request.getRemoteAddr()).matches());
/*      */     
/*  803 */     if (isInternal || (this.trustedProxies != null && this.trustedProxies.matcher(request.getRemoteAddr()).matches())) {
/*  804 */       String remoteIp = null;
/*  805 */       Deque<String> proxiesHeaderValue = new ArrayDeque<>();
/*  806 */       StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
/*      */       
/*  808 */       for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements(); ) {
/*  809 */         if (concatRemoteIpHeaderValue.length() > 0) {
/*  810 */           concatRemoteIpHeaderValue.append(", ");
/*      */         }
/*      */         
/*  813 */         concatRemoteIpHeaderValue.append(e.nextElement());
/*      */       } 
/*      */       
/*  816 */       String[] remoteIpHeaderValue = StringUtils.splitCommaSeparated(concatRemoteIpHeaderValue.toString());
/*      */       
/*  818 */       if (!isInternal) {
/*  819 */         proxiesHeaderValue.addFirst(request.getRemoteAddr());
/*      */       }
/*      */       int idx;
/*  822 */       for (idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--) {
/*  823 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  824 */         remoteIp = currentRemoteIp;
/*  825 */         if (this.internalProxies == null || !this.internalProxies.matcher(currentRemoteIp).matches())
/*      */         {
/*  827 */           if (this.trustedProxies != null && this.trustedProxies.matcher(currentRemoteIp).matches()) {
/*  828 */             proxiesHeaderValue.addFirst(currentRemoteIp);
/*      */           } else {
/*  830 */             idx--;
/*      */             break;
/*      */           } 
/*      */         }
/*      */       } 
/*  835 */       LinkedList<String> newRemoteIpHeaderValue = new LinkedList<>();
/*  836 */       for (; idx >= 0; idx--) {
/*  837 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  838 */         newRemoteIpHeaderValue.addFirst(currentRemoteIp);
/*      */       } 
/*      */       
/*  841 */       XForwardedRequest xRequest = new XForwardedRequest(request);
/*  842 */       if (remoteIp != null) {
/*      */         
/*  844 */         xRequest.setRemoteAddr(remoteIp);
/*  845 */         if (getEnableLookups()) {
/*      */ 
/*      */           
/*      */           try {
/*      */ 
/*      */             
/*  851 */             InetAddress inetAddress = InetAddress.getByName(remoteIp);
/*      */             
/*  853 */             xRequest.setRemoteHost(inetAddress.getCanonicalHostName());
/*  854 */           } catch (UnknownHostException unknownHostException) {
/*  855 */             this.log.debug(sm.getString("remoteIpFilter.invalidRemoteAddress", new Object[] { remoteIp }), unknownHostException);
/*  856 */             xRequest.setRemoteHost(remoteIp);
/*      */           } 
/*      */         } else {
/*  859 */           xRequest.setRemoteHost(remoteIp);
/*      */         } 
/*      */         
/*  862 */         if (proxiesHeaderValue.isEmpty()) {
/*  863 */           xRequest.removeHeader(this.proxiesHeader);
/*      */         } else {
/*  865 */           String commaDelimitedListOfProxies = StringUtils.join(proxiesHeaderValue);
/*  866 */           xRequest.setHeader(this.proxiesHeader, commaDelimitedListOfProxies);
/*      */         } 
/*  868 */         if (newRemoteIpHeaderValue.isEmpty()) {
/*  869 */           xRequest.removeHeader(this.remoteIpHeader);
/*      */         } else {
/*  871 */           String commaDelimitedRemoteIpHeaderValue = StringUtils.join(newRemoteIpHeaderValue);
/*  872 */           xRequest.setHeader(this.remoteIpHeader, commaDelimitedRemoteIpHeaderValue);
/*      */         } 
/*      */       } 
/*      */       
/*  876 */       if (this.protocolHeader != null) {
/*  877 */         String protocolHeaderValue = request.getHeader(this.protocolHeader);
/*  878 */         if (protocolHeaderValue != null)
/*      */         {
/*      */           
/*  881 */           if (isForwardedProtoHeaderValueSecure(protocolHeaderValue)) {
/*  882 */             xRequest.setSecure(true);
/*  883 */             xRequest.setScheme("https");
/*  884 */             setPorts(xRequest, this.httpsServerPort);
/*      */           } else {
/*  886 */             xRequest.setSecure(false);
/*  887 */             xRequest.setScheme("http");
/*  888 */             setPorts(xRequest, this.httpServerPort);
/*      */           } 
/*      */         }
/*      */       } 
/*  892 */       if (this.hostHeader != null) {
/*  893 */         String hostHeaderValue = request.getHeader(this.hostHeader);
/*  894 */         if (hostHeaderValue != null) {
/*      */           try {
/*  896 */             int portIndex = Host.parse(hostHeaderValue);
/*  897 */             if (portIndex > -1) {
/*  898 */               this.log.debug(sm.getString("remoteIpFilter.invalidHostWithPort", new Object[] { hostHeaderValue, this.hostHeader }));
/*  899 */               hostHeaderValue = hostHeaderValue.substring(0, portIndex);
/*      */             } 
/*      */             
/*  902 */             xRequest.setServerName(hostHeaderValue);
/*  903 */             if (isChangeLocalName()) {
/*  904 */               xRequest.setLocalName(hostHeaderValue);
/*      */             }
/*      */           }
/*  907 */           catch (IllegalArgumentException iae) {
/*  908 */             this.log.debug(sm.getString("remoteIpFilter.invalidHostHeader", new Object[] { hostHeaderValue, this.hostHeader }), iae);
/*      */           } 
/*      */         }
/*      */       } 
/*  912 */       request.setAttribute("org.apache.tomcat.request.forwarded", Boolean.TRUE);
/*      */       
/*  914 */       if (this.log.isTraceEnabled()) {
/*  915 */         this.log.trace("Incoming request " + request.getRequestURI() + " with originalRemoteAddr [" + request
/*  916 */             .getRemoteAddr() + "], originalRemoteHost=[" + request.getRemoteHost() + "], originalSecure=[" + request
/*  917 */             .isSecure() + "], originalScheme=[" + request.getScheme() + "], originalServerName=[" + request
/*  918 */             .getServerName() + "], originalServerPort=[" + request
/*  919 */             .getServerPort() + "] will be seen as newRemoteAddr=[" + xRequest.getRemoteAddr() + "], newRemoteHost=[" + xRequest
/*  920 */             .getRemoteHost() + "], newSecure=[" + xRequest.isSecure() + "], newScheme=[" + xRequest
/*  921 */             .getScheme() + "], newServerName=[" + xRequest.getServerName() + "], newServerPort=[" + xRequest
/*  922 */             .getServerPort() + "]");
/*      */       }
/*  924 */       if (this.requestAttributesEnabled) {
/*  925 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", xRequest.getRemoteAddr());
/*  926 */         request.setAttribute("org.apache.tomcat.remoteAddr", xRequest.getRemoteAddr());
/*  927 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", xRequest.getRemoteHost());
/*  928 */         request.setAttribute("org.apache.catalina.AccessLog.Protocol", xRequest.getProtocol());
/*  929 */         request.setAttribute("org.apache.catalina.AccessLog.ServerName", xRequest.getServerName());
/*  930 */         request.setAttribute("org.apache.catalina.AccessLog.ServerPort", Integer.valueOf(xRequest.getServerPort()));
/*      */       } 
/*  932 */       chain.doFilter((ServletRequest)xRequest, (ServletResponse)response);
/*      */     } else {
/*  934 */       if (this.log.isTraceEnabled()) {
/*  935 */         this.log.trace("Skip RemoteIpFilter for request " + request.getRequestURI() + " with originalRemoteAddr '" + request
/*  936 */             .getRemoteAddr() + "'");
/*      */       }
/*  938 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isForwardedProtoHeaderValueSecure(String protocolHeaderValue) {
/*  947 */     if (!protocolHeaderValue.contains(",")) {
/*  948 */       return this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue);
/*      */     }
/*  950 */     String[] forwardedProtocols = StringUtils.splitCommaSeparated(protocolHeaderValue);
/*  951 */     if (forwardedProtocols.length == 0) {
/*  952 */       return false;
/*      */     }
/*  954 */     for (String forwardedProtocol : forwardedProtocols) {
/*  955 */       if (!this.protocolHeaderHttpsValue.equalsIgnoreCase(forwardedProtocol)) {
/*  956 */         return false;
/*      */       }
/*      */     } 
/*  959 */     return true;
/*      */   }
/*      */   
/*      */   private void setPorts(XForwardedRequest xrequest, int defaultPort) {
/*  963 */     int port = defaultPort;
/*  964 */     if (getPortHeader() != null) {
/*  965 */       String portHeaderValue = xrequest.getHeader(getPortHeader());
/*  966 */       if (portHeaderValue != null) {
/*      */         try {
/*  968 */           port = Integer.parseInt(portHeaderValue);
/*  969 */         } catch (NumberFormatException nfe) {
/*  970 */           this.log.debug(sm.getString("remoteIpFilter.invalidPort", new Object[] { portHeaderValue, getPortHeader() }), nfe);
/*      */         } 
/*      */       }
/*      */     } 
/*  974 */     xrequest.setServerPort(port);
/*  975 */     if (isChangeLocalPort()) {
/*  976 */       xrequest.setLocalPort(port);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  987 */     if (request instanceof HttpServletRequest && response instanceof HttpServletResponse) {
/*  988 */       doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*      */     } else {
/*  990 */       chain.doFilter(request, response);
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isChangeLocalName() {
/*  995 */     return this.changeLocalName;
/*      */   }
/*      */   
/*      */   public boolean isChangeLocalPort() {
/*  999 */     return this.changeLocalPort;
/*      */   }
/*      */   
/*      */   public int getHttpsServerPort() {
/* 1003 */     return this.httpsServerPort;
/*      */   }
/*      */   
/*      */   public Pattern getInternalProxies() {
/* 1007 */     return this.internalProxies;
/*      */   }
/*      */   
/*      */   public String getProtocolHeader() {
/* 1011 */     return this.protocolHeader;
/*      */   }
/*      */   
/*      */   public String getPortHeader() {
/* 1015 */     return this.portHeader;
/*      */   }
/*      */   
/*      */   public String getProtocolHeaderHttpsValue() {
/* 1019 */     return this.protocolHeaderHttpsValue;
/*      */   }
/*      */   
/*      */   public String getProxiesHeader() {
/* 1023 */     return this.proxiesHeader;
/*      */   }
/*      */   
/*      */   public String getRemoteIpHeader() {
/* 1027 */     return this.remoteIpHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRequestAttributesEnabled() {
/* 1036 */     return this.requestAttributesEnabled;
/*      */   }
/*      */   
/*      */   public Pattern getTrustedProxies() {
/* 1040 */     return this.trustedProxies;
/*      */   }
/*      */   
/*      */   public boolean getEnableLookups() {
/* 1044 */     return this.enableLookups;
/*      */   }
/*      */ 
/*      */   
/*      */   public void init() throws ServletException {
/* 1049 */     if (getInitParameter("internalProxies") != null) {
/* 1050 */       setInternalProxies(getInitParameter("internalProxies"));
/*      */     }
/*      */     
/* 1053 */     if (getInitParameter("protocolHeader") != null) {
/* 1054 */       setProtocolHeader(getInitParameter("protocolHeader"));
/*      */     }
/*      */     
/* 1057 */     if (getInitParameter("protocolHeaderHttpsValue") != null) {
/* 1058 */       setProtocolHeaderHttpsValue(getInitParameter("protocolHeaderHttpsValue"));
/*      */     }
/*      */     
/* 1061 */     if (getInitParameter("hostHeader") != null) {
/* 1062 */       setHostHeader(getInitParameter("hostHeader"));
/*      */     }
/*      */     
/* 1065 */     if (getInitParameter("portHeader") != null) {
/* 1066 */       setPortHeader(getInitParameter("portHeader"));
/*      */     }
/*      */     
/* 1069 */     if (getInitParameter("changeLocalName") != null) {
/* 1070 */       setChangeLocalName(Boolean.parseBoolean(getInitParameter("changeLocalName")));
/*      */     }
/*      */     
/* 1073 */     if (getInitParameter("changeLocalPort") != null) {
/* 1074 */       setChangeLocalPort(Boolean.parseBoolean(getInitParameter("changeLocalPort")));
/*      */     }
/*      */     
/* 1077 */     if (getInitParameter("proxiesHeader") != null) {
/* 1078 */       setProxiesHeader(getInitParameter("proxiesHeader"));
/*      */     }
/*      */     
/* 1081 */     if (getInitParameter("remoteIpHeader") != null) {
/* 1082 */       setRemoteIpHeader(getInitParameter("remoteIpHeader"));
/*      */     }
/*      */     
/* 1085 */     if (getInitParameter("trustedProxies") != null) {
/* 1086 */       setTrustedProxies(getInitParameter("trustedProxies"));
/*      */     }
/*      */     
/* 1089 */     if (getInitParameter("httpServerPort") != null) {
/*      */       try {
/* 1091 */         setHttpServerPort(Integer.parseInt(getInitParameter("httpServerPort")));
/* 1092 */       } catch (NumberFormatException e) {
/* 1093 */         throw new NumberFormatException(sm.getString("remoteIpFilter.invalidNumber", new Object[] { "httpServerPort", e
/* 1094 */                 .getLocalizedMessage() }));
/*      */       } 
/*      */     }
/*      */     
/* 1098 */     if (getInitParameter("httpsServerPort") != null) {
/*      */       try {
/* 1100 */         setHttpsServerPort(Integer.parseInt(getInitParameter("httpsServerPort")));
/* 1101 */       } catch (NumberFormatException e) {
/* 1102 */         throw new NumberFormatException(sm.getString("remoteIpFilter.invalidNumber", new Object[] { "httpsServerPort", e
/* 1103 */                 .getLocalizedMessage() }));
/*      */       } 
/*      */     }
/*      */     
/* 1107 */     if (getInitParameter("enableLookups") != null) {
/* 1108 */       setEnableLookups(Boolean.parseBoolean(getInitParameter("enableLookups")));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChangeLocalName(boolean changeLocalName) {
/* 1125 */     this.changeLocalName = changeLocalName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChangeLocalPort(boolean changeLocalPort) {
/* 1141 */     this.changeLocalPort = changeLocalPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHttpServerPort(int httpServerPort) {
/* 1156 */     this.httpServerPort = httpServerPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHttpsServerPort(int httpsServerPort) {
/* 1170 */     this.httpsServerPort = httpsServerPort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInternalProxies(String internalProxies) {
/* 1185 */     if (internalProxies == null || internalProxies.isEmpty()) {
/* 1186 */       this.internalProxies = null;
/*      */     } else {
/* 1188 */       this.internalProxies = Pattern.compile(internalProxies);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHostHeader(String hostHeader) {
/* 1203 */     this.hostHeader = hostHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPortHeader(String portHeader) {
/* 1218 */     this.portHeader = portHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtocolHeader(String protocolHeader) {
/* 1233 */     this.protocolHeader = protocolHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue) {
/* 1247 */     this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProxiesHeader(String proxiesHeader) {
/* 1270 */     this.proxiesHeader = proxiesHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoteIpHeader(String remoteIpHeader) {
/* 1287 */     this.remoteIpHeader = remoteIpHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {
/* 1306 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTrustedProxies(String trustedProxies) {
/* 1320 */     if (trustedProxies == null || trustedProxies.isEmpty()) {
/* 1321 */       this.trustedProxies = null;
/*      */     } else {
/* 1323 */       this.trustedProxies = Pattern.compile(trustedProxies);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setEnableLookups(boolean enableLookups) {
/* 1328 */     this.enableLookups = enableLookups;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
/* 1336 */     ois.defaultReadObject();
/* 1337 */     this.log = LogFactory.getLog(RemoteIpFilter.class);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\RemoteIpFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */