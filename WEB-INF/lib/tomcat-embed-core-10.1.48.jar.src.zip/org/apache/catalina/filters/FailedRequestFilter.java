/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.http.Parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FailedRequestFilter
/*     */   extends FilterBase
/*     */ {
/*  45 */   private final Log log = LogFactory.getLog(FailedRequestFilter.class);
/*     */ 
/*     */   
/*     */   protected Log getLogger() {
/*  49 */     return this.log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  56 */     if (!isGoodRequest(request)) {
/*  57 */       int status; Parameters.FailReason reason = (Parameters.FailReason)request.getAttribute("org.apache.catalina.parameter_parse_failed_reason");
/*     */ 
/*     */ 
/*     */       
/*  61 */       switch (reason) {
/*     */         
/*     */         case IO_ERROR:
/*  64 */           status = 500;
/*     */           break;
/*     */         case POST_TOO_LARGE:
/*  67 */           status = 413;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/*  86 */           status = 400;
/*     */           break;
/*     */       } 
/*     */       
/*     */       try {
/*  91 */         ((HttpServletResponse)response).sendError(status);
/*  92 */       } catch (IllegalStateException illegalStateException) {}
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  97 */     chain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isGoodRequest(ServletRequest request) {
/* 102 */     request.getParameter("none");
/*     */     
/* 104 */     if (request.getAttribute("org.apache.catalina.parameter_parse_failed") != null) {
/* 105 */       return false;
/*     */     }
/* 107 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/* 112 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\FailedRequestFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */