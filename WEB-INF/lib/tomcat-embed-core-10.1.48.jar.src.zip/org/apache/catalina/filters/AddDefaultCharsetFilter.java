/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddDefaultCharsetFilter
/*     */   extends FilterBase
/*     */ {
/*  48 */   private final Log log = LogFactory.getLog(AddDefaultCharsetFilter.class);
/*     */   
/*     */   private static final String DEFAULT_ENCODING = "ISO-8859-1";
/*     */   
/*     */   private String encoding;
/*     */   
/*     */   public void setEncoding(String encoding) {
/*  55 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Log getLogger() {
/*  60 */     return this.log;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  65 */     super.init(filterConfig);
/*  66 */     if (this.encoding == null || this.encoding.isEmpty() || this.encoding.equalsIgnoreCase("default")) {
/*  67 */       this.encoding = "ISO-8859-1";
/*  68 */     } else if (this.encoding.equalsIgnoreCase("system")) {
/*  69 */       this.encoding = Charset.defaultCharset().name();
/*  70 */     } else if (!Charset.isSupported(this.encoding)) {
/*  71 */       throw new IllegalArgumentException(sm.getString("addDefaultCharset.unsupportedCharset", new Object[] { this.encoding }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  80 */     if (response instanceof HttpServletResponse) {
/*  81 */       ResponseWrapper wrapped = new ResponseWrapper((HttpServletResponse)response, this.encoding);
/*  82 */       chain.doFilter(request, (ServletResponse)wrapped);
/*     */     } else {
/*  84 */       chain.doFilter(request, response);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private String encoding;
/*     */ 
/*     */     
/*     */     public ResponseWrapper(HttpServletResponse response, String encoding) {
/*  96 */       super(response);
/*  97 */       this.encoding = encoding;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setContentType(String contentType) {
/* 103 */       if (contentType != null && contentType.startsWith("text/")) {
/* 104 */         if (!contentType.contains("charset=")) {
/* 105 */           super.setContentType(contentType + ";charset=" + contentType);
/*     */         } else {
/* 107 */           super.setContentType(contentType);
/* 108 */           this.encoding = getCharacterEncoding();
/*     */         } 
/*     */       } else {
/* 111 */         super.setContentType(contentType);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setHeader(String name, String value) {
/* 118 */       if (name.trim().equalsIgnoreCase("content-type")) {
/* 119 */         setContentType(value);
/*     */       } else {
/* 121 */         super.setHeader(name, value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void addHeader(String name, String value) {
/* 127 */       if (name.trim().equalsIgnoreCase("content-type")) {
/* 128 */         setContentType(value);
/*     */       } else {
/* 130 */         super.addHeader(name, value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void setCharacterEncoding(String charset) {
/* 136 */       super.setCharacterEncoding(charset);
/* 137 */       this.encoding = charset;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\AddDefaultCharsetFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */