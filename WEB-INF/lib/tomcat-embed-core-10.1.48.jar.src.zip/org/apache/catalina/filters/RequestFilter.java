/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestFilter
/*     */   extends FilterBase
/*     */ {
/*  57 */   protected Pattern allow = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected Pattern deny = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected int denyStatus = 403;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PLAIN_TEXT_MIME_TYPE = "text/plain";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllow() {
/*  84 */     if (this.allow == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return this.allow.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllow(String allow) {
/*  97 */     if (allow == null || allow.isEmpty()) {
/*  98 */       this.allow = null;
/*     */     } else {
/* 100 */       this.allow = Pattern.compile(allow);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDeny() {
/* 110 */     if (this.deny == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     return this.deny.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeny(String deny) {
/* 123 */     if (deny == null || deny.isEmpty()) {
/* 124 */       this.deny = null;
/*     */     } else {
/* 126 */       this.deny = Pattern.compile(deny);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDenyStatus() {
/* 135 */     return this.denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDenyStatus(int denyStatus) {
/* 145 */     this.denyStatus = denyStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isConfigProblemFatal() {
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void process(String property, ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 192 */     if (isAllowed(property)) {
/* 193 */       chain.doFilter(request, response);
/*     */     }
/* 195 */     else if (response instanceof HttpServletResponse) {
/* 196 */       if (getLogger().isDebugEnabled()) {
/* 197 */         getLogger().debug(sm.getString("requestFilter.deny", new Object[] { ((HttpServletRequest)request).getRequestURI(), property }));
/*     */       }
/*     */       
/* 200 */       ((HttpServletResponse)response).sendError(this.denyStatus);
/*     */     } else {
/* 202 */       sendErrorWhenNotHttp(response);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAllowed(String property) {
/* 216 */     if (this.deny != null && this.deny.matcher(property).matches()) {
/* 217 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 221 */     if (this.allow != null && this.allow.matcher(property).matches()) {
/* 222 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 227 */     return (this.deny != null && this.allow == null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendErrorWhenNotHttp(ServletResponse response) throws IOException {
/* 232 */     response.setContentType("text/plain");
/* 233 */     response.getWriter().write(sm.getString("http.403"));
/* 234 */     response.getWriter().flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\filters\RequestFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */