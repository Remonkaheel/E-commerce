package org.apache.catalina;

import java.beans.PropertyChangeListener;
import java.io.IOException;

public interface Store {
  Manager getManager();
  
  void setManager(Manager paramManager);
  
  int getSize() throws IOException;
  
  void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  String[] keys() throws IOException;
  
  Session load(String paramString) throws ClassNotFoundException, IOException;
  
  void remove(String paramString) throws IOException;
  
  void clear() throws IOException;
  
  void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  void save(Session paramSession) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Store.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */