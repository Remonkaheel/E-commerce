package org.apache.catalina;

import javax.management.MBeanRegistration;
import javax.management.ObjectName;

public interface JmxEnabled extends MBeanRegistration {
  String getDomain();
  
  void setDomain(String paramString);
  
  ObjectName getObjectName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\JmxEnabled.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */