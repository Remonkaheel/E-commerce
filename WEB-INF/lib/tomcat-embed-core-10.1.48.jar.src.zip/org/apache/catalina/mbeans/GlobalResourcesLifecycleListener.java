/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.naming.Binding;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.OperationNotSupportedException;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalResourcesLifecycleListener
/*     */   implements LifecycleListener
/*     */ {
/*  52 */   private static final Log log = LogFactory.getLog(GlobalResourcesLifecycleListener.class);
/*  53 */   protected static final StringManager sm = StringManager.getManager(GlobalResourcesLifecycleListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected Lifecycle component = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  74 */     if ("start".equals(event.getType())) {
/*  75 */       if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/*  76 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*  78 */       this.component = event.getLifecycle();
/*  79 */       createMBeans();
/*  80 */     } else if ("stop".equals(event.getType())) {
/*  81 */       destroyMBeans();
/*  82 */       this.component = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createMBeans() {
/*     */     Context context;
/*     */     try {
/*  96 */       context = (Context)(new InitialContext()).lookup("java:/");
/*  97 */     } catch (NamingException e) {
/*  98 */       log.error(sm.getString("globalResources.noNamingContext"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 104 */       createMBeans("", context);
/* 105 */     } catch (NamingException e) {
/* 106 */       log.error(sm.getString("globalResources.createError"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createMBeans(String prefix, Context context) throws NamingException {
/* 121 */     if (log.isDebugEnabled()) {
/* 122 */       log.debug(sm.getString("globalResources.create", new Object[] { prefix }));
/*     */     }
/*     */     
/*     */     try {
/* 126 */       NamingEnumeration<Binding> bindings = context.listBindings("");
/* 127 */       while (bindings.hasMore()) {
/* 128 */         Binding binding = bindings.next();
/* 129 */         String name = prefix + prefix;
/* 130 */         Object value = context.lookup(binding.getName());
/* 131 */         if (log.isTraceEnabled()) {
/* 132 */           log.trace("Checking resource " + name);
/*     */         }
/* 134 */         if (value instanceof Context) {
/* 135 */           createMBeans(name + "/", (Context)value); continue;
/* 136 */         }  if (value instanceof UserDatabase) {
/*     */           try {
/* 138 */             createMBeans(name, (UserDatabase)value);
/* 139 */           } catch (Exception e) {
/* 140 */             log.error(sm.getString("globalResources.userDatabaseCreateError", new Object[] { name }), e);
/*     */           } 
/*     */         }
/*     */       } 
/* 144 */     } catch (RuntimeException ex) {
/* 145 */       log.error(sm.getString("globalResources.createError.runtime"), ex);
/* 146 */     } catch (OperationNotSupportedException ex) {
/* 147 */       log.error(sm.getString("globalResources.createError.operation"), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createMBeans(String name, UserDatabase database) throws Exception {
/* 163 */     if (log.isTraceEnabled()) {
/* 164 */       log.trace("Creating UserDatabase MBeans for resource " + name);
/* 165 */       log.trace("Database=" + String.valueOf(database));
/*     */     } 
/*     */     try {
/* 168 */       MBeanUtils.createMBean(database);
/* 169 */     } catch (Exception e) {
/* 170 */       throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase", new Object[] { name }), e);
/*     */     } 
/*     */     
/* 173 */     if (database.isSparse()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 179 */     Iterator<Role> roles = database.getRoles();
/* 180 */     while (roles.hasNext()) {
/* 181 */       Role role = roles.next();
/* 182 */       if (log.isTraceEnabled()) {
/* 183 */         log.trace("  Creating Role MBean for role " + String.valueOf(role));
/*     */       }
/*     */       try {
/* 186 */         MBeanUtils.createMBean(role);
/* 187 */       } catch (Exception e) {
/* 188 */         throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase.role", new Object[] { role }), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 194 */     Iterator<Group> groups = database.getGroups();
/* 195 */     while (groups.hasNext()) {
/* 196 */       Group group = groups.next();
/* 197 */       if (log.isTraceEnabled()) {
/* 198 */         log.trace("  Creating Group MBean for group " + String.valueOf(group));
/*     */       }
/*     */       try {
/* 201 */         MBeanUtils.createMBean(group);
/* 202 */       } catch (Exception e) {
/* 203 */         throw new IllegalArgumentException(sm
/* 204 */             .getString("globalResources.createError.userDatabase.group", new Object[] { group }), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 209 */     Iterator<User> users = database.getUsers();
/* 210 */     while (users.hasNext()) {
/* 211 */       User user = users.next();
/* 212 */       if (log.isTraceEnabled()) {
/* 213 */         log.trace("  Creating User MBean for user " + String.valueOf(user));
/*     */       }
/*     */       try {
/* 216 */         MBeanUtils.createMBean(user);
/* 217 */       } catch (Exception e) {
/* 218 */         throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase.user", new Object[] { user }), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyMBeans() {
/* 229 */     if (log.isTraceEnabled())
/* 230 */       log.trace("Destroying MBeans for Global JNDI Resources"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\GlobalResourcesLifecycleListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */