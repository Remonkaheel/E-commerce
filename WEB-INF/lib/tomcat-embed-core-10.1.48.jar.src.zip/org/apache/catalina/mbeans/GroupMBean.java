/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager(GroupMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected final ManagedBean managed = this.registry.findManagedBean("Group");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRoles() {
/*  60 */     Group group = (Group)this.resource;
/*  61 */     List<String> results = new ArrayList<>();
/*  62 */     Iterator<Role> roles = group.getRoles();
/*  63 */     while (roles.hasNext()) {
/*  64 */       Role role = null;
/*     */       try {
/*  66 */         role = roles.next();
/*  67 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), role);
/*  68 */         results.add(oname.toString());
/*  69 */       } catch (MalformedObjectNameException e) {
/*  70 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { role }), e);
/*     */       } 
/*     */     } 
/*  73 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUsers() {
/*  82 */     Group group = (Group)this.resource;
/*  83 */     List<String> results = new ArrayList<>();
/*  84 */     Iterator<User> users = group.getUsers();
/*  85 */     while (users.hasNext()) {
/*  86 */       User user = null;
/*     */       try {
/*  88 */         user = users.next();
/*  89 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), user);
/*  90 */         results.add(oname.toString());
/*  91 */       } catch (MalformedObjectNameException e) {
/*  92 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.user", new Object[] { user }), e);
/*     */       } 
/*     */     } 
/*  95 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRole(String rolename) {
/* 106 */     Group group = (Group)this.resource;
/* 107 */     if (group == null) {
/*     */       return;
/*     */     }
/* 110 */     Role role = group.getUserDatabase().findRole(rolename);
/* 111 */     if (role == null) {
/* 112 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 114 */     group.addRole(role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(String rolename) {
/* 125 */     Group group = (Group)this.resource;
/* 126 */     if (group == null) {
/*     */       return;
/*     */     }
/* 129 */     Role role = group.getUserDatabase().findRole(rolename);
/* 130 */     if (role == null) {
/* 131 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 133 */     group.removeRole(role);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\GroupMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */