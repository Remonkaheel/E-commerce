/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseCatalinaMBean<T>
/*    */   extends BaseModelMBean
/*    */ {
/*    */   protected T doGetManagedResource() throws MBeanException {
/*    */     try {
/* 31 */       T resource = (T)getManagedResource();
/* 32 */       return resource;
/* 33 */     } catch (InstanceNotFoundException|javax.management.RuntimeOperationsException|javax.management.modelmbean.InvalidTargetObjectTypeException e) {
/* 34 */       throw new MBeanException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected static Object newInstance(String type) throws MBeanException {
/*    */     try {
/* 41 */       return Class.forName(type).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 42 */     } catch (ReflectiveOperationException e) {
/* 43 */       throw new MBeanException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\BaseCatalinaMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */