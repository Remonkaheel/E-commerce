/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import javax.management.Attribute;
/*    */ import javax.management.AttributeNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.ReflectionException;
/*    */ import javax.management.RuntimeOperationsException;
/*    */ import org.apache.catalina.connector.Connector;
/*    */ import org.apache.tomcat.util.IntrospectionUtils;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectorMBean
/*    */   extends ClassNameMBean<Connector>
/*    */ {
/* 35 */   private static final StringManager sm = StringManager.getManager(ConnectorMBean.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getAttribute(String name) throws AttributeNotFoundException, MBeanException, ReflectionException {
/* 41 */     if (name == null) {
/* 42 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/* 43 */           .getString("mBean.nullName"));
/*    */     }
/*    */     
/* 46 */     Connector connector = doGetManagedResource();
/* 47 */     return IntrospectionUtils.getProperty(connector, name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
/* 56 */     if (attribute == null) {
/* 57 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm
/* 58 */           .getString("mBean.nullAttribute"));
/*    */     }
/* 60 */     String name = attribute.getName();
/* 61 */     Object value = attribute.getValue();
/* 62 */     if (name == null) {
/* 63 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/* 64 */           .getString("mBean.nullName"));
/*    */     }
/*    */     
/* 67 */     Connector connector = doGetManagedResource();
/* 68 */     IntrospectionUtils.setProperty(connector, name, String.valueOf(value));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ConnectorMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */