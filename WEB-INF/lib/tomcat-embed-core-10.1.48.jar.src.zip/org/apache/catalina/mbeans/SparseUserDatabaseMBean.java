/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseUserDatabaseMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  46 */   private static final StringManager sm = StringManager.getManager(SparseUserDatabaseMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected final MBeanServer mserver = MBeanUtils.createServer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected final ManagedBean managed = this.registry.findManagedBean("SparseUserDatabase");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected final ManagedBean managedGroup = this.registry.findManagedBean("Group");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected final ManagedBean managedRole = this.registry.findManagedBean("Role");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected final ManagedBean managedUser = this.registry.findManagedBean("User");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGroups() {
/*  92 */     UserDatabase database = (UserDatabase)this.resource;
/*  93 */     List<String> results = new ArrayList<>();
/*  94 */     Iterator<Group> groups = database.getGroups();
/*  95 */     while (groups.hasNext()) {
/*  96 */       Group group = groups.next();
/*  97 */       results.add(findGroup(group.getGroupname()));
/*     */     } 
/*  99 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRoles() {
/* 107 */     UserDatabase database = (UserDatabase)this.resource;
/* 108 */     List<String> results = new ArrayList<>();
/* 109 */     Iterator<Role> roles = database.getRoles();
/* 110 */     while (roles.hasNext()) {
/* 111 */       Role role = roles.next();
/* 112 */       results.add(findRole(role.getRolename()));
/*     */     } 
/* 114 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUsers() {
/* 122 */     UserDatabase database = (UserDatabase)this.resource;
/* 123 */     List<String> results = new ArrayList<>();
/* 124 */     Iterator<User> users = database.getUsers();
/* 125 */     while (users.hasNext()) {
/* 126 */       User user = users.next();
/* 127 */       results.add(findUser(user.getUsername()));
/*     */     } 
/* 129 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createGroup(String groupname, String description) {
/* 144 */     UserDatabase database = (UserDatabase)this.resource;
/* 145 */     Group group = database.createGroup(groupname, description);
/*     */     try {
/* 147 */       MBeanUtils.createMBean(group);
/* 148 */     } catch (Exception e) {
/* 149 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.group", new Object[] { groupname }), e);
/*     */     } 
/* 151 */     return findGroup(groupname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createRole(String rolename, String description) {
/* 164 */     UserDatabase database = (UserDatabase)this.resource;
/* 165 */     Role role = database.createRole(rolename, description);
/*     */     try {
/* 167 */       MBeanUtils.createMBean(role);
/* 168 */     } catch (Exception e) {
/* 169 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.role", new Object[] { rolename }), e);
/*     */     } 
/* 171 */     return findRole(rolename);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createUser(String username, String password, String fullName) {
/* 185 */     UserDatabase database = (UserDatabase)this.resource;
/* 186 */     User user = database.createUser(username, password, fullName);
/*     */     try {
/* 188 */       MBeanUtils.createMBean(user);
/* 189 */     } catch (Exception e) {
/* 190 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.user", new Object[] { username }), e);
/*     */     } 
/* 192 */     return findUser(username);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findGroup(String groupname) {
/* 204 */     UserDatabase database = (UserDatabase)this.resource;
/* 205 */     Group group = database.findGroup(groupname);
/* 206 */     if (group == null) {
/* 207 */       return null;
/*     */     }
/*     */     try {
/* 210 */       ObjectName oname = MBeanUtils.createObjectName(this.managedGroup.getDomain(), group);
/* 211 */       if (database.isSparse() && !this.mserver.isRegistered(oname)) {
/* 212 */         MBeanUtils.createMBean(group);
/*     */       }
/* 214 */       return oname.toString();
/* 215 */     } catch (Exception e) {
/* 216 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.group", new Object[] { groupname }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findRole(String rolename) {
/* 229 */     UserDatabase database = (UserDatabase)this.resource;
/* 230 */     Role role = database.findRole(rolename);
/* 231 */     if (role == null) {
/* 232 */       return null;
/*     */     }
/*     */     try {
/* 235 */       ObjectName oname = MBeanUtils.createObjectName(this.managedRole.getDomain(), role);
/* 236 */       if (database.isSparse() && !this.mserver.isRegistered(oname)) {
/* 237 */         MBeanUtils.createMBean(role);
/*     */       }
/* 239 */       return oname.toString();
/* 240 */     } catch (Exception e) {
/* 241 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { rolename }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findUser(String username) {
/* 255 */     UserDatabase database = (UserDatabase)this.resource;
/* 256 */     User user = database.findUser(username);
/* 257 */     if (user == null) {
/* 258 */       return null;
/*     */     }
/*     */     try {
/* 261 */       ObjectName oname = MBeanUtils.createObjectName(this.managedUser.getDomain(), user);
/* 262 */       if (database.isSparse() && !this.mserver.isRegistered(oname)) {
/* 263 */         MBeanUtils.createMBean(user);
/*     */       }
/* 265 */       return oname.toString();
/* 266 */     } catch (Exception e) {
/* 267 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.user", new Object[] { username }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroup(String groupname) {
/* 278 */     UserDatabase database = (UserDatabase)this.resource;
/* 279 */     Group group = database.findGroup(groupname);
/* 280 */     if (group == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 284 */       MBeanUtils.destroyMBean(group);
/* 285 */       database.removeGroup(group);
/* 286 */     } catch (Exception e) {
/* 287 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.group", new Object[] { groupname }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(String rolename) {
/* 298 */     UserDatabase database = (UserDatabase)this.resource;
/* 299 */     Role role = database.findRole(rolename);
/* 300 */     if (role == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 304 */       MBeanUtils.destroyMBean(role);
/* 305 */       database.removeRole(role);
/* 306 */     } catch (Exception e) {
/* 307 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.role", new Object[] { rolename }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUser(String username) {
/* 318 */     UserDatabase database = (UserDatabase)this.resource;
/* 319 */     User user = database.findUser(username);
/* 320 */     if (user == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 324 */       MBeanUtils.destroyMBean(user);
/* 325 */       database.removeUser(user);
/* 326 */     } catch (Exception e) {
/* 327 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.user", new Object[] { username }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() {
/*     */     try {
/* 337 */       UserDatabase database = (UserDatabase)this.resource;
/* 338 */       if (database.isSparse()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         ObjectName query = new ObjectName("Users:type=Group,database=" + database.getId() + ",*");
/* 344 */         Set<ObjectName> results = this.mserver.queryNames(query, null);
/* 345 */         for (ObjectName result : results) {
/* 346 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */ 
/*     */         
/* 350 */         query = new ObjectName("Users:type=Role,database=" + database.getId() + ",*");
/* 351 */         results = this.mserver.queryNames(query, null);
/* 352 */         for (ObjectName result : results) {
/* 353 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */ 
/*     */         
/* 357 */         query = new ObjectName("Users:type=User,database=" + database.getId() + ",*");
/* 358 */         results = this.mserver.queryNames(query, null);
/* 359 */         for (ObjectName result : results) {
/* 360 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */       } 
/* 363 */       database.save();
/* 364 */     } catch (Exception e) {
/* 365 */       throw new IllegalArgumentException(sm.getString("userMBean.saveError"), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\SparseUserDatabaseMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */