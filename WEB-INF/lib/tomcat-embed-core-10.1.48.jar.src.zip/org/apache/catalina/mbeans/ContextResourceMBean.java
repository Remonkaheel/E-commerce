/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextResourceMBean
/*     */   extends BaseCatalinaMBean<ContextResource>
/*     */ {
/*  35 */   private static final StringManager sm = StringManager.getManager(ContextResourceMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) throws AttributeNotFoundException, MBeanException, ReflectionException {
/*  41 */     if (name == null) {
/*  42 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/*  43 */           .getString("mBean.nullName"));
/*     */     }
/*     */     
/*  46 */     ContextResource cr = doGetManagedResource();
/*     */     
/*  48 */     String value = null;
/*  49 */     if ("auth".equals(name))
/*  50 */       return cr.getAuth(); 
/*  51 */     if ("description".equals(name))
/*  52 */       return cr.getDescription(); 
/*  53 */     if ("name".equals(name))
/*  54 */       return cr.getName(); 
/*  55 */     if ("scope".equals(name))
/*  56 */       return cr.getScope(); 
/*  57 */     if ("type".equals(name)) {
/*  58 */       return cr.getType();
/*     */     }
/*  60 */     value = (String)cr.getProperty(name);
/*  61 */     if (value == null) {
/*  62 */       throw new AttributeNotFoundException(sm.getString("mBean.attributeNotFound", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/*  66 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
/*  75 */     if (attribute == null) {
/*  76 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm
/*  77 */           .getString("mBean.nullAttribute"));
/*     */     }
/*  79 */     String name = attribute.getName();
/*  80 */     Object value = attribute.getValue();
/*  81 */     if (name == null) {
/*  82 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/*  83 */           .getString("mBean.nullName"));
/*     */     }
/*     */     
/*  86 */     ContextResource cr = doGetManagedResource();
/*     */     
/*  88 */     if ("auth".equals(name)) {
/*  89 */       cr.setAuth((String)value);
/*  90 */     } else if ("description".equals(name)) {
/*  91 */       cr.setDescription((String)value);
/*  92 */     } else if ("name".equals(name)) {
/*  93 */       cr.setName((String)value);
/*  94 */     } else if ("scope".equals(name)) {
/*  95 */       cr.setScope((String)value);
/*  96 */     } else if ("type".equals(name)) {
/*  97 */       cr.setType((String)value);
/*     */     } else {
/*  99 */       cr.setProperty(name, String.valueOf(value));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 104 */     NamingResources nr = cr.getNamingResources();
/* 105 */     nr.removeResource(cr.getName());
/* 106 */     nr.addResource(cr);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ContextResourceMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */