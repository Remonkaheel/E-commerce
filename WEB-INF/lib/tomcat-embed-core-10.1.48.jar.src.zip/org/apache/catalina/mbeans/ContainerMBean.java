/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.core.ContainerBase;
/*     */ import org.apache.catalina.startup.ContextConfig;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerMBean
/*     */   extends BaseCatalinaMBean<ContainerBase>
/*     */ {
/*     */   public void addChild(String type, String name) throws MBeanException {
/*  51 */     Container contained = (Container)newInstance(type);
/*  52 */     contained.setName(name);
/*     */     
/*  54 */     if (contained instanceof org.apache.catalina.core.StandardHost) {
/*  55 */       HostConfig config = new HostConfig();
/*  56 */       contained.addLifecycleListener((LifecycleListener)config);
/*  57 */     } else if (contained instanceof org.apache.catalina.core.StandardContext) {
/*  58 */       ContextConfig config = new ContextConfig();
/*  59 */       contained.addLifecycleListener((LifecycleListener)config);
/*     */     } 
/*     */     
/*  62 */     boolean oldValue = true;
/*     */     
/*  64 */     ContainerBase container = doGetManagedResource();
/*     */     try {
/*  66 */       oldValue = container.getStartChildren();
/*  67 */       container.setStartChildren(false);
/*  68 */       container.addChild(contained);
/*  69 */       contained.init();
/*  70 */     } catch (LifecycleException e) {
/*  71 */       throw new MBeanException(e);
/*     */     } finally {
/*  73 */       if (container != null) {
/*  74 */         container.setStartChildren(oldValue);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChild(String name) throws MBeanException {
/*  88 */     if (name != null) {
/*  89 */       Container container = (Container)doGetManagedResource();
/*  90 */       Container contained = container.findChild(name);
/*  91 */       container.removeChild(contained);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addValve(String valveType) throws MBeanException {
/* 106 */     Valve valve = (Valve)newInstance(valveType);
/*     */     
/* 108 */     Container container = (Container)doGetManagedResource();
/* 109 */     container.getPipeline().addValve(valve);
/*     */     
/* 111 */     if (valve instanceof JmxEnabled) {
/* 112 */       return ((JmxEnabled)valve).getObjectName().toString();
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeValve(String valveName) throws MBeanException {
/*     */     ObjectName oname;
/* 127 */     Container container = (Container)doGetManagedResource();
/*     */ 
/*     */     
/*     */     try {
/* 131 */       oname = new ObjectName(valveName);
/* 132 */     } catch (MalformedObjectNameException|NullPointerException e) {
/* 133 */       throw new MBeanException(e);
/*     */     } 
/*     */     
/* 136 */     if (container != null) {
/* 137 */       Valve[] valves = container.getPipeline().getValves();
/* 138 */       for (Valve valve : valves) {
/* 139 */         if (valve instanceof JmxEnabled) {
/* 140 */           ObjectName voname = ((JmxEnabled)valve).getObjectName();
/* 141 */           if (voname.equals(oname)) {
/* 142 */             container.getPipeline().removeValve(valve);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLifecycleListener(String type) throws MBeanException {
/* 158 */     LifecycleListener listener = (LifecycleListener)newInstance(type);
/* 159 */     Container container = (Container)doGetManagedResource();
/* 160 */     container.addLifecycleListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLifecycleListeners(String type) throws MBeanException {
/* 173 */     Container container = (Container)doGetManagedResource();
/*     */     
/* 175 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 176 */     for (LifecycleListener listener : listeners) {
/* 177 */       if (listener.getClass().getName().equals(type)) {
/* 178 */         container.removeLifecycleListener(listener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findLifecycleListenerNames() throws MBeanException {
/* 192 */     Container container = (Container)doGetManagedResource();
/* 193 */     List<String> result = new ArrayList<>();
/*     */     
/* 195 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 196 */     for (LifecycleListener listener : listeners) {
/* 197 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 200 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findContainerListenerNames() throws MBeanException {
/* 212 */     Container container = (Container)doGetManagedResource();
/* 213 */     List<String> result = new ArrayList<>();
/*     */     
/* 215 */     ContainerListener[] listeners = container.findContainerListeners();
/* 216 */     for (ContainerListener listener : listeners) {
/* 217 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 220 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ContainerMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */