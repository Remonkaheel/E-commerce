/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextResourceLinkMBean
/*     */   extends BaseCatalinaMBean<ContextResourceLink>
/*     */ {
/*  35 */   private static final StringManager sm = StringManager.getManager(ContextResourceLinkMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) throws AttributeNotFoundException, MBeanException, ReflectionException {
/*  41 */     if (name == null) {
/*  42 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/*  43 */           .getString("mBean.nullName"));
/*     */     }
/*     */     
/*  46 */     ContextResourceLink cl = doGetManagedResource();
/*     */     
/*  48 */     String value = null;
/*  49 */     if ("global".equals(name))
/*  50 */       return cl.getGlobal(); 
/*  51 */     if ("description".equals(name))
/*  52 */       return cl.getDescription(); 
/*  53 */     if ("name".equals(name))
/*  54 */       return cl.getName(); 
/*  55 */     if ("type".equals(name)) {
/*  56 */       return cl.getType();
/*     */     }
/*  58 */     value = (String)cl.getProperty(name);
/*  59 */     if (value == null) {
/*  60 */       throw new AttributeNotFoundException(sm.getString("mBean.attributeNotFound", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/*  64 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
/*  73 */     if (attribute == null) {
/*  74 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm
/*  75 */           .getString("mBean.nullAttribute"));
/*     */     }
/*     */     
/*  78 */     String name = attribute.getName();
/*  79 */     Object value = attribute.getValue();
/*  80 */     if (name == null) {
/*  81 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm
/*  82 */           .getString("mBean.nullName"));
/*     */     }
/*     */     
/*  85 */     ContextResourceLink crl = doGetManagedResource();
/*     */     
/*  87 */     if ("global".equals(name)) {
/*  88 */       crl.setGlobal((String)value);
/*  89 */     } else if ("description".equals(name)) {
/*  90 */       crl.setDescription((String)value);
/*  91 */     } else if ("name".equals(name)) {
/*  92 */       crl.setName((String)value);
/*  93 */     } else if ("type".equals(name)) {
/*  94 */       crl.setType((String)value);
/*     */     } else {
/*  96 */       crl.setProperty(name, String.valueOf(value));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     NamingResources nr = crl.getNamingResources();
/* 102 */     nr.removeResourceLink(crl.getName());
/* 103 */     nr.addResourceLink(crl);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ContextResourceLinkMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */