/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager(UserMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected final ManagedBean managed = this.registry.findManagedBean("User");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGroups() {
/*  65 */     User user = (User)this.resource;
/*  66 */     List<String> results = new ArrayList<>();
/*  67 */     Iterator<Group> groups = user.getGroups();
/*  68 */     while (groups.hasNext()) {
/*  69 */       Group group = null;
/*     */       try {
/*  71 */         group = groups.next();
/*  72 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), group);
/*  73 */         results.add(oname.toString());
/*  74 */       } catch (MalformedObjectNameException e) {
/*  75 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.group", new Object[] { group }), e);
/*     */       } 
/*     */     } 
/*  78 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRoles() {
/*  87 */     User user = (User)this.resource;
/*  88 */     List<String> results = new ArrayList<>();
/*  89 */     Iterator<Role> roles = user.getRoles();
/*  90 */     while (roles.hasNext()) {
/*  91 */       Role role = null;
/*     */       try {
/*  93 */         role = roles.next();
/*  94 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), role);
/*  95 */         results.add(oname.toString());
/*  96 */       } catch (MalformedObjectNameException e) {
/*  97 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { role }), e);
/*     */       } 
/*     */     } 
/* 100 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGroup(String groupname) {
/* 113 */     User user = (User)this.resource;
/* 114 */     if (user == null) {
/*     */       return;
/*     */     }
/* 117 */     Group group = user.getUserDatabase().findGroup(groupname);
/* 118 */     if (group == null) {
/* 119 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidGroup", new Object[] { groupname }));
/*     */     }
/* 121 */     user.addGroup(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRole(String rolename) {
/* 132 */     User user = (User)this.resource;
/* 133 */     if (user == null) {
/*     */       return;
/*     */     }
/* 136 */     Role role = user.getUserDatabase().findRole(rolename);
/* 137 */     if (role == null) {
/* 138 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 140 */     user.addRole(role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroup(String groupname) {
/* 151 */     User user = (User)this.resource;
/* 152 */     if (user == null) {
/*     */       return;
/*     */     }
/* 155 */     Group group = user.getUserDatabase().findGroup(groupname);
/* 156 */     if (group == null) {
/* 157 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidGroup", new Object[] { groupname }));
/*     */     }
/* 159 */     user.removeGroup(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(String rolename) {
/* 170 */     User user = (User)this.resource;
/* 171 */     if (user == null) {
/*     */       return;
/*     */     }
/* 174 */     Role role = user.getUserDatabase().findRole(rolename);
/* 175 */     if (role == null) {
/* 176 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 178 */     user.removeRole(role);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\UserMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */