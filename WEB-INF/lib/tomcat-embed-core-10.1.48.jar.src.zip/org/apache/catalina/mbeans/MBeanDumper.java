/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Set;
/*     */ import java.util.StringJoiner;
/*     */ import javax.management.JMRuntimeException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanDumper
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(MBeanDumper.class);
/*  42 */   protected static final StringManager sm = StringManager.getManager(MBeanDumper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CRLF = "\r\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String dumpBeans(MBeanServer mbeanServer, Set<ObjectName> names) {
/*  56 */     StringBuilder buf = new StringBuilder();
/*  57 */     for (ObjectName oname : names) {
/*  58 */       buf.append("Name: ");
/*  59 */       buf.append(oname.toString());
/*  60 */       buf.append("\r\n");
/*     */       
/*     */       try {
/*  63 */         MBeanInfo minfo = mbeanServer.getMBeanInfo(oname);
/*     */         
/*  65 */         String code = minfo.getClassName();
/*  66 */         if ("org.apache.commons.modeler.BaseModelMBean".equals(code)) {
/*  67 */           code = (String)mbeanServer.getAttribute(oname, "modelerType");
/*     */         }
/*  69 */         buf.append("modelerType: ");
/*  70 */         buf.append(code);
/*  71 */         buf.append("\r\n");
/*     */         
/*  73 */         MBeanAttributeInfo[] attrs = minfo.getAttributes();
/*     */         
/*  75 */         for (MBeanAttributeInfo attr : attrs) {
/*  76 */           if (attr.isReadable()) {
/*     */ 
/*     */             
/*  79 */             String attName = attr.getName();
/*  80 */             if (!"modelerType".equals(attName))
/*     */             {
/*     */               
/*  83 */               if (attName.indexOf('=') < 0 && attName.indexOf(':') < 0 && attName.indexOf(' ') < 0)
/*     */               { Object value;
/*     */ 
/*     */ 
/*     */                 
/*     */                 try {
/*  89 */                   value = mbeanServer.getAttribute(oname, attName);
/*  90 */                 } catch (JMRuntimeException rme) {
/*  91 */                   Throwable cause = rme.getCause();
/*  92 */                   if (cause instanceof UnsupportedOperationException) {
/*  93 */                     if (log.isDebugEnabled()) {
/*  94 */                       log.debug(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                     }
/*  96 */                   } else if (cause instanceof NullPointerException) {
/*  97 */                     if (log.isDebugEnabled()) {
/*  98 */                       log.debug(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                     }
/*     */                   } else {
/* 101 */                     log.error(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                   }
/*     */                 
/* 104 */                 } catch (Throwable t) {
/* 105 */                   ExceptionUtils.handleThrowable(t);
/* 106 */                   log.error(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), t);
/*     */                 } 
/*     */                 
/* 109 */                 if (value != null)
/*     */                   
/*     */                   try { String valueString;
/*     */ 
/*     */                     
/* 114 */                     Class<?> c = value.getClass();
/* 115 */                     if (c.isArray()) {
/* 116 */                       int len = Array.getLength(value);
/*     */                       
/* 118 */                       StringBuilder sb = new StringBuilder("Array[" + c.getComponentType().getName() + "] of length " + len);
/* 119 */                       if (len > 0) {
/* 120 */                         sb.append("\r\n");
/*     */                       }
/* 122 */                       for (int j = 0; j < len; j++) {
/* 123 */                         Object item = Array.get(value, j);
/* 124 */                         sb.append(tableItemToString(item));
/* 125 */                         if (j < len - 1) {
/* 126 */                           sb.append("\r\n");
/*     */                         }
/*     */                       } 
/* 129 */                       valueString = sb.toString();
/* 130 */                     } else if (TabularData.class.isInstance(value)) {
/* 131 */                       TabularData tab = TabularData.class.cast(value);
/* 132 */                       StringJoiner joiner = new StringJoiner("\r\n");
/* 133 */                       joiner.add("TabularData[" + tab.getTabularType().getRowType().getTypeName() + "] of length " + tab
/* 134 */                           .size());
/* 135 */                       for (Object item : tab.values()) {
/* 136 */                         joiner.add(tableItemToString(item));
/*     */                       }
/* 138 */                       valueString = joiner.toString();
/*     */                     } else {
/* 140 */                       valueString = valueToString(value);
/*     */                     } 
/* 142 */                     buf.append(attName);
/* 143 */                     buf.append(": ");
/* 144 */                     buf.append(valueString);
/* 145 */                     buf.append("\r\n"); }
/* 146 */                   catch (Throwable t)
/* 147 */                   { ExceptionUtils.handleThrowable(t); }   }  } 
/*     */           } 
/*     */         } 
/* 150 */       } catch (Throwable t) {
/* 151 */         ExceptionUtils.handleThrowable(t);
/*     */       } 
/* 153 */       buf.append("\r\n");
/*     */     } 
/* 155 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String value) {
/* 163 */     int idx = value.indexOf('\n');
/* 164 */     if (idx < 0) {
/* 165 */       return value;
/*     */     }
/*     */     
/* 168 */     int prev = 0;
/* 169 */     StringBuilder sb = new StringBuilder();
/* 170 */     while (idx >= 0) {
/* 171 */       appendHead(sb, value, prev, idx);
/* 172 */       sb.append("\\n\n ");
/* 173 */       prev = idx + 1;
/* 174 */       if (idx == value.length() - 1) {
/*     */         break;
/*     */       }
/* 177 */       idx = value.indexOf('\n', idx + 1);
/*     */     } 
/* 179 */     if (prev < value.length()) {
/* 180 */       appendHead(sb, value, prev, value.length());
/*     */     }
/* 182 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendHead(StringBuilder sb, String value, int start, int end) {
/* 187 */     if (end < 1) {
/*     */       return;
/*     */     }
/*     */     
/* 191 */     int pos = start;
/* 192 */     while (end - pos > 78) {
/* 193 */       sb.append(value, pos, pos + 78);
/* 194 */       sb.append("\n ");
/* 195 */       pos += 78;
/*     */     } 
/* 197 */     sb.append(value, pos, end);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String tableItemToString(Object item) {
/* 202 */     if (item == null) {
/* 203 */       return "\tNULL VALUE";
/*     */     }
/*     */     try {
/* 206 */       return "\t" + valueToString(item);
/* 207 */     } catch (Throwable t) {
/* 208 */       ExceptionUtils.handleThrowable(t);
/* 209 */       return "\tNON-STRINGABLE VALUE";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String valueToString(Object value) {
/*     */     String valueString;
/* 217 */     if (CompositeData.class.isInstance(value)) {
/* 218 */       StringBuilder sb = new StringBuilder("{");
/* 219 */       String sep = "";
/* 220 */       CompositeData composite = CompositeData.class.cast(value);
/* 221 */       Set<String> keys = composite.getCompositeType().keySet();
/* 222 */       for (String key : keys) {
/* 223 */         sb.append(sep).append(key).append('=').append(composite.get(key));
/* 224 */         sep = ", ";
/*     */       } 
/* 226 */       sb.append('}');
/* 227 */       valueString = sb.toString();
/*     */     } else {
/* 229 */       valueString = value.toString();
/*     */     } 
/* 231 */     return escape(valueString);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\MBeanDumper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */