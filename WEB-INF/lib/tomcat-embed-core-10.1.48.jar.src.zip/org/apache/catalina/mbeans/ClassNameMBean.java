/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassNameMBean<T>
/*    */   extends BaseCatalinaMBean<T>
/*    */ {
/*    */   public String getClassName() {
/* 34 */     return this.resource.getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ClassNameMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */