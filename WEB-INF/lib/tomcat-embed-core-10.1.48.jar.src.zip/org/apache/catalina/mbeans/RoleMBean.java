/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*    */ import org.apache.tomcat.util.modeler.ManagedBean;
/*    */ import org.apache.tomcat.util.modeler.Registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleMBean
/*    */   extends BaseModelMBean
/*    */ {
/* 35 */   protected final Registry registry = MBeanUtils.createRegistry();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   protected final ManagedBean managed = this.registry.findManagedBean("Role");
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\RoleMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */