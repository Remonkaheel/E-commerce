/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamingResourcesMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  40 */   private static final StringManager sm = StringManager.getManager(NamingResourcesMBean.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected final ManagedBean managed = this.registry.findManagedBean("NamingResources");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getEnvironments() {
/*  64 */     ContextEnvironment[] envs = ((NamingResourcesImpl)this.resource).findEnvironments();
/*  65 */     List<String> results = new ArrayList<>();
/*  66 */     for (ContextEnvironment env : envs) {
/*     */       try {
/*  68 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), env);
/*  69 */         results.add(oname.toString());
/*  70 */       } catch (MalformedObjectNameException e) {
/*  71 */         throw new IllegalArgumentException(sm
/*  72 */             .getString("namingResourcesMBean.createObjectNameError.environment", new Object[] { env }), e);
/*     */       } 
/*     */     } 
/*  75 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getResources() {
/*  85 */     ContextResource[] resources = ((NamingResourcesImpl)this.resource).findResources();
/*  86 */     List<String> results = new ArrayList<>();
/*  87 */     for (ContextResource contextResource : resources) {
/*     */       try {
/*  89 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), contextResource);
/*  90 */         results.add(oname.toString());
/*  91 */       } catch (MalformedObjectNameException e) {
/*  92 */         throw new IllegalArgumentException(sm
/*  93 */             .getString("namingResourcesMBean.createObjectNameError.resource", new Object[] { contextResource }), e);
/*     */       } 
/*     */     } 
/*  96 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getResourceLinks() {
/* 106 */     ContextResourceLink[] resourceLinks = ((NamingResourcesImpl)this.resource).findResourceLinks();
/* 107 */     List<String> results = new ArrayList<>();
/* 108 */     for (ContextResourceLink resourceLink : resourceLinks) {
/*     */       try {
/* 110 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), resourceLink);
/* 111 */         results.add(oname.toString());
/* 112 */       } catch (MalformedObjectNameException e) {
/* 113 */         throw new IllegalArgumentException(sm
/* 114 */             .getString("namingResourcesMBean.createObjectNameError.resourceLink", new Object[] { resourceLink }), e);
/*     */       } 
/*     */     } 
/* 117 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addEnvironment(String envName, String type, String value) throws MalformedObjectNameException {
/* 136 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 137 */     if (nresources == null) {
/* 138 */       return null;
/*     */     }
/* 140 */     ContextEnvironment env = nresources.findEnvironment(envName);
/* 141 */     if (env != null) {
/* 142 */       throw new IllegalArgumentException(sm
/* 143 */           .getString("namingResourcesMBean.addAlreadyExists.environment", new Object[] { envName }));
/*     */     }
/* 145 */     env = new ContextEnvironment();
/* 146 */     env.setName(envName);
/* 147 */     env.setType(type);
/* 148 */     env.setValue(value);
/* 149 */     nresources.addEnvironment(env);
/*     */ 
/*     */     
/* 152 */     ManagedBean managed = this.registry.findManagedBean("ContextEnvironment");
/* 153 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), env);
/* 154 */     return oname.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addResource(String resourceName, String type) throws MalformedObjectNameException {
/* 170 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 171 */     if (nresources == null) {
/* 172 */       return null;
/*     */     }
/* 174 */     ContextResource resource = nresources.findResource(resourceName);
/* 175 */     if (resource != null) {
/* 176 */       throw new IllegalArgumentException(sm
/* 177 */           .getString("namingResourcesMBean.addAlreadyExists.resource", new Object[] { resourceName }));
/*     */     }
/* 179 */     resource = new ContextResource();
/* 180 */     resource.setName(resourceName);
/* 181 */     resource.setType(type);
/* 182 */     nresources.addResource(resource);
/*     */ 
/*     */     
/* 185 */     ManagedBean managed = this.registry.findManagedBean("ContextResource");
/* 186 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), resource);
/* 187 */     return oname.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addResourceLink(String resourceLinkName, String type) throws MalformedObjectNameException {
/* 203 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 204 */     if (nresources == null) {
/* 205 */       return null;
/*     */     }
/* 207 */     ContextResourceLink resourceLink = nresources.findResourceLink(resourceLinkName);
/* 208 */     if (resourceLink != null) {
/* 209 */       throw new IllegalArgumentException(sm
/* 210 */           .getString("namingResourcesMBean.addAlreadyExists.resourceLink", new Object[] { resourceLinkName }));
/*     */     }
/* 212 */     resourceLink = new ContextResourceLink();
/* 213 */     resourceLink.setName(resourceLinkName);
/* 214 */     resourceLink.setType(type);
/* 215 */     nresources.addResourceLink(resourceLink);
/*     */ 
/*     */     
/* 218 */     ManagedBean managed = this.registry.findManagedBean("ContextResourceLink");
/* 219 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), resourceLink);
/* 220 */     return oname.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeEnvironment(String envName) {
/* 230 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 231 */     if (nresources == null) {
/*     */       return;
/*     */     }
/* 234 */     ContextEnvironment env = nresources.findEnvironment(envName);
/* 235 */     if (env == null) {
/* 236 */       throw new IllegalArgumentException(sm
/* 237 */           .getString("namingResourcesMBean.removeNotFound.environment", new Object[] { envName }));
/*     */     }
/* 239 */     nresources.removeEnvironment(envName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeResource(String resourceName) {
/* 249 */     resourceName = ObjectName.unquote(resourceName);
/* 250 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 251 */     if (nresources == null) {
/*     */       return;
/*     */     }
/* 254 */     ContextResource resource = nresources.findResource(resourceName);
/* 255 */     if (resource == null) {
/* 256 */       throw new IllegalArgumentException(sm
/* 257 */           .getString("namingResourcesMBean.removeNotFound.resource", new Object[] { resourceName }));
/*     */     }
/* 259 */     nresources.removeResource(resourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeResourceLink(String resourceLinkName) {
/* 269 */     resourceLinkName = ObjectName.unquote(resourceLinkName);
/* 270 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 271 */     if (nresources == null) {
/*     */       return;
/*     */     }
/* 274 */     ContextResourceLink resourceLink = nresources.findResourceLink(resourceLinkName);
/* 275 */     if (resourceLink == null) {
/* 276 */       throw new IllegalArgumentException(sm
/* 277 */           .getString("namingResourcesMBean.removeNotFound.resourceLink", new Object[] { resourceLinkName }));
/*     */     }
/* 279 */     nresources.removeResourceLink(resourceLinkName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\NamingResourcesMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */