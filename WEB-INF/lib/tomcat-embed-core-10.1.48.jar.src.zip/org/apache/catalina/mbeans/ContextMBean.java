/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.MBeanException;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.tomcat.util.descriptor.web.ApplicationParameter;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextMBean
/*     */   extends BaseCatalinaMBean<Context>
/*     */ {
/*     */   public String[] findApplicationParameters() throws MBeanException {
/*  39 */     Context context = doGetManagedResource();
/*     */     
/*  41 */     ApplicationParameter[] params = context.findApplicationParameters();
/*  42 */     String[] stringParams = new String[params.length];
/*  43 */     for (int counter = 0; counter < params.length; counter++) {
/*  44 */       stringParams[counter] = params[counter].toString();
/*     */     }
/*     */     
/*  47 */     return stringParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findConstraints() throws MBeanException {
/*  60 */     Context context = doGetManagedResource();
/*     */     
/*  62 */     SecurityConstraint[] constraints = context.findConstraints();
/*  63 */     String[] stringConstraints = new String[constraints.length];
/*  64 */     for (int counter = 0; counter < constraints.length; counter++) {
/*  65 */       stringConstraints[counter] = constraints[counter].toString();
/*     */     }
/*     */     
/*  68 */     return stringConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findErrorPage(int errorCode) throws MBeanException {
/*  82 */     Context context = doGetManagedResource();
/*  83 */     ErrorPage errorPage = context.findErrorPage(errorCode);
/*  84 */     if (errorPage != null) {
/*  85 */       return errorPage.toString();
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findErrorPage(Throwable exceptionType) throws MBeanException {
/* 102 */     Context context = doGetManagedResource();
/* 103 */     ErrorPage errorPage = context.findErrorPage(exceptionType);
/* 104 */     if (errorPage != null) {
/* 105 */       return errorPage.toString();
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findErrorPages() throws MBeanException {
/* 121 */     Context context = doGetManagedResource();
/*     */     
/* 123 */     ErrorPage[] pages = context.findErrorPages();
/* 124 */     String[] stringPages = new String[pages.length];
/* 125 */     for (int counter = 0; counter < pages.length; counter++) {
/* 126 */       stringPages[counter] = pages[counter].toString();
/*     */     }
/*     */     
/* 129 */     return stringPages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findFilterDef(String name) throws MBeanException {
/* 144 */     Context context = doGetManagedResource();
/*     */     
/* 146 */     FilterDef filterDef = context.findFilterDef(name);
/* 147 */     if (filterDef != null) {
/* 148 */       return filterDef.toString();
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findFilterDefs() throws MBeanException {
/* 164 */     Context context = doGetManagedResource();
/*     */     
/* 166 */     FilterDef[] filterDefs = context.findFilterDefs();
/* 167 */     String[] stringFilters = new String[filterDefs.length];
/* 168 */     for (int counter = 0; counter < filterDefs.length; counter++) {
/* 169 */       stringFilters[counter] = filterDefs[counter].toString();
/*     */     }
/*     */     
/* 172 */     return stringFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findFilterMaps() throws MBeanException {
/* 185 */     Context context = doGetManagedResource();
/*     */     
/* 187 */     FilterMap[] maps = context.findFilterMaps();
/* 188 */     String[] stringMaps = new String[maps.length];
/* 189 */     for (int counter = 0; counter < maps.length; counter++) {
/* 190 */       stringMaps[counter] = maps[counter].toString();
/*     */     }
/*     */     
/* 193 */     return stringMaps;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ContextMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */