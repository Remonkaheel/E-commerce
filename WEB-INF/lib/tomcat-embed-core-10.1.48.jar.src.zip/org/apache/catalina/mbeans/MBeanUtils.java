/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.catalina.util.ContextName;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanUtils
/*     */ {
/*  49 */   protected static final StringManager sm = StringManager.getManager(MBeanUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private static final String[][] exceptions = new String[][] { { "org.apache.catalina.users.MemoryGroup", "Group" }, { "org.apache.catalina.users.MemoryRole", "Role" }, { "org.apache.catalina.users.MemoryUser", "User" }, { "org.apache.catalina.users.GenericGroup", "Group" }, { "org.apache.catalina.users.GenericRole", "Role" }, { "org.apache.catalina.users.GenericUser", "User" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static Registry registry = createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private static MBeanServer mserver = createServer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String createManagedName(Object component) {
/*  83 */     String className = component.getClass().getName();
/*  84 */     for (String[] exception : exceptions) {
/*  85 */       if (className.equals(exception[0])) {
/*  86 */         return exception[1];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  91 */     int period = className.lastIndexOf('.');
/*  92 */     if (period >= 0) {
/*  93 */       className = className.substring(period + 1);
/*     */     }
/*  95 */     return className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynamicMBean createMBean(ContextEnvironment environment) throws Exception {
/* 111 */     String mname = createManagedName(environment);
/* 112 */     ManagedBean managed = registry.findManagedBean(mname);
/* 113 */     if (managed == null) {
/* 114 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 115 */       throw new MBeanException(e);
/*     */     } 
/* 117 */     String domain = managed.getDomain();
/* 118 */     if (domain == null) {
/* 119 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 121 */     DynamicMBean mbean = managed.createMBean(environment);
/* 122 */     ObjectName oname = createObjectName(domain, environment);
/* 123 */     if (mserver.isRegistered(oname)) {
/* 124 */       mserver.unregisterMBean(oname);
/*     */     }
/* 126 */     mserver.registerMBean(mbean, oname);
/* 127 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynamicMBean createMBean(ContextResource resource) throws Exception {
/* 143 */     String mname = createManagedName(resource);
/* 144 */     ManagedBean managed = registry.findManagedBean(mname);
/* 145 */     if (managed == null) {
/* 146 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 147 */       throw new MBeanException(e);
/*     */     } 
/* 149 */     String domain = managed.getDomain();
/* 150 */     if (domain == null) {
/* 151 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 153 */     DynamicMBean mbean = managed.createMBean(resource);
/* 154 */     ObjectName oname = createObjectName(domain, resource);
/* 155 */     if (mserver.isRegistered(oname)) {
/* 156 */       mserver.unregisterMBean(oname);
/*     */     }
/* 158 */     mserver.registerMBean(mbean, oname);
/* 159 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynamicMBean createMBean(ContextResourceLink resourceLink) throws Exception {
/* 175 */     String mname = createManagedName(resourceLink);
/* 176 */     ManagedBean managed = registry.findManagedBean(mname);
/* 177 */     if (managed == null) {
/* 178 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 179 */       throw new MBeanException(e);
/*     */     } 
/* 181 */     String domain = managed.getDomain();
/* 182 */     if (domain == null) {
/* 183 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 185 */     DynamicMBean mbean = managed.createMBean(resourceLink);
/* 186 */     ObjectName oname = createObjectName(domain, resourceLink);
/* 187 */     if (mserver.isRegistered(oname)) {
/* 188 */       mserver.unregisterMBean(oname);
/*     */     }
/* 190 */     mserver.registerMBean(mbean, oname);
/* 191 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DynamicMBean createMBean(Group group) throws Exception {
/* 207 */     String mname = createManagedName(group);
/* 208 */     ManagedBean managed = registry.findManagedBean(mname);
/* 209 */     if (managed == null) {
/* 210 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 211 */       throw new MBeanException(e);
/*     */     } 
/* 213 */     String domain = managed.getDomain();
/* 214 */     if (domain == null) {
/* 215 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 217 */     DynamicMBean mbean = managed.createMBean(group);
/* 218 */     ObjectName oname = createObjectName(domain, group);
/* 219 */     if (mserver.isRegistered(oname)) {
/* 220 */       mserver.unregisterMBean(oname);
/*     */     }
/* 222 */     mserver.registerMBean(mbean, oname);
/* 223 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DynamicMBean createMBean(Role role) throws Exception {
/* 239 */     String mname = createManagedName(role);
/* 240 */     ManagedBean managed = registry.findManagedBean(mname);
/* 241 */     if (managed == null) {
/* 242 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 243 */       throw new MBeanException(e);
/*     */     } 
/* 245 */     String domain = managed.getDomain();
/* 246 */     if (domain == null) {
/* 247 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 249 */     DynamicMBean mbean = managed.createMBean(role);
/* 250 */     ObjectName oname = createObjectName(domain, role);
/* 251 */     if (mserver.isRegistered(oname)) {
/* 252 */       mserver.unregisterMBean(oname);
/*     */     }
/* 254 */     mserver.registerMBean(mbean, oname);
/* 255 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DynamicMBean createMBean(User user) throws Exception {
/* 271 */     String mname = createManagedName(user);
/* 272 */     ManagedBean managed = registry.findManagedBean(mname);
/* 273 */     if (managed == null) {
/* 274 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 275 */       throw new MBeanException(e);
/*     */     } 
/* 277 */     String domain = managed.getDomain();
/* 278 */     if (domain == null) {
/* 279 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 281 */     DynamicMBean mbean = managed.createMBean(user);
/* 282 */     ObjectName oname = createObjectName(domain, user);
/* 283 */     if (mserver.isRegistered(oname)) {
/* 284 */       mserver.unregisterMBean(oname);
/*     */     }
/* 286 */     mserver.registerMBean(mbean, oname);
/* 287 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DynamicMBean createMBean(UserDatabase userDatabase) throws Exception {
/* 303 */     if (userDatabase.isSparse()) {
/*     */       
/* 305 */       ManagedBean managedBean = registry.findManagedBean("SparseUserDatabase");
/* 306 */       if (managedBean == null) {
/* 307 */         Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { "SparseUserDatabase" }));
/* 308 */         throw new MBeanException(e);
/*     */       } 
/* 310 */       String str = managedBean.getDomain();
/* 311 */       if (str == null) {
/* 312 */         str = mserver.getDefaultDomain();
/*     */       }
/* 314 */       DynamicMBean dynamicMBean = managedBean.createMBean(userDatabase);
/* 315 */       ObjectName objectName = createObjectName(str, userDatabase);
/* 316 */       if (mserver.isRegistered(objectName)) {
/* 317 */         mserver.unregisterMBean(objectName);
/*     */       }
/* 319 */       mserver.registerMBean(dynamicMBean, objectName);
/*     */     } 
/*     */     
/* 322 */     String mname = createManagedName(userDatabase);
/* 323 */     ManagedBean managed = registry.findManagedBean(mname);
/* 324 */     if (managed == null) {
/* 325 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 326 */       throw new MBeanException(e);
/*     */     } 
/* 328 */     String domain = managed.getDomain();
/* 329 */     if (domain == null) {
/* 330 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 332 */     DynamicMBean mbean = managed.createMBean(userDatabase);
/* 333 */     ObjectName oname = createObjectName(domain, userDatabase);
/* 334 */     if (mserver.isRegistered(oname)) {
/* 335 */       mserver.unregisterMBean(oname);
/*     */     }
/* 337 */     mserver.registerMBean(mbean, oname);
/* 338 */     return mbean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ObjectName createObjectName(String domain, ContextEnvironment environment) throws MalformedObjectNameException {
/* 356 */     ObjectName name = null;
/* 357 */     Object container = environment.getNamingResources().getContainer();
/* 358 */     if (container instanceof org.apache.catalina.Server) {
/* 359 */       name = new ObjectName(domain + ":type=Environment,resourcetype=Global,name=" + domain);
/* 360 */     } else if (container instanceof Context) {
/* 361 */       Context context = (Context)container;
/* 362 */       ContextName cn = new ContextName(context.getName(), false);
/* 363 */       Container host = context.getParent();
/*     */       
/* 365 */       name = new ObjectName(domain + ":type=Environment,resourcetype=Context,host=" + domain + ",context=" + host.getName() + ",name=" + cn.getDisplayName());
/*     */     } 
/* 367 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ObjectName createObjectName(String domain, ContextResource resource) throws MalformedObjectNameException {
/* 385 */     ObjectName name = null;
/* 386 */     String quotedResourceName = ObjectName.quote(resource.getName());
/* 387 */     Object container = resource.getNamingResources().getContainer();
/* 388 */     if (container instanceof org.apache.catalina.Server) {
/* 389 */       name = new ObjectName(domain + ":type=Resource,resourcetype=Global,class=" + domain + ",name=" + resource.getType());
/*     */     }
/* 391 */     else if (container instanceof Context) {
/* 392 */       Context context = (Context)container;
/* 393 */       ContextName cn = new ContextName(context.getName(), false);
/* 394 */       Container host = context.getParent();
/*     */       
/* 396 */       name = new ObjectName(domain + ":type=Resource,resourcetype=Context,host=" + domain + ",context=" + host.getName() + ",class=" + cn.getDisplayName() + ",name=" + resource.getType());
/*     */     } 
/*     */     
/* 399 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ObjectName createObjectName(String domain, ContextResourceLink resourceLink) throws MalformedObjectNameException {
/* 417 */     ObjectName name = null;
/* 418 */     String quotedResourceLinkName = ObjectName.quote(resourceLink.getName());
/* 419 */     Object container = resourceLink.getNamingResources().getContainer();
/* 420 */     if (container instanceof org.apache.catalina.Server) {
/* 421 */       name = new ObjectName(domain + ":type=ResourceLink,resourcetype=Global,name=" + domain);
/*     */     }
/* 423 */     else if (container instanceof Context) {
/* 424 */       Context context = (Context)container;
/* 425 */       ContextName cn = new ContextName(context.getName(), false);
/* 426 */       Container host = context.getParent();
/*     */       
/* 428 */       name = new ObjectName(domain + ":type=ResourceLink,resourcetype=Context,host=" + domain + ",context=" + host.getName() + ",name=" + cn.getDisplayName());
/*     */     } 
/*     */     
/* 431 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ObjectName createObjectName(String domain, Group group) throws MalformedObjectNameException {
/* 448 */     return new ObjectName(domain + ":type=Group,groupname=" + domain + ",database=" + ObjectName.quote(group.getGroupname()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ObjectName createObjectName(String domain, Role role) throws MalformedObjectNameException {
/* 466 */     return new ObjectName(domain + ":type=Role,rolename=" + domain + ",database=" + ObjectName.quote(role.getRolename()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ObjectName createObjectName(String domain, User user) throws MalformedObjectNameException {
/* 484 */     return new ObjectName(domain + ":type=User,username=" + domain + ",database=" + ObjectName.quote(user.getUsername()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ObjectName createObjectName(String domain, UserDatabase userDatabase) throws MalformedObjectNameException {
/* 501 */     return new ObjectName(domain + ":type=UserDatabase,database=" + domain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized Registry createRegistry() {
/* 511 */     if (registry == null) {
/* 512 */       registry = Registry.getRegistry(null);
/* 513 */       ClassLoader cl = MBeanUtils.class.getClassLoader();
/*     */       
/* 515 */       registry.loadDescriptors("org.apache.catalina.mbeans", cl);
/* 516 */       registry.loadDescriptors("org.apache.catalina.authenticator", cl);
/* 517 */       registry.loadDescriptors("org.apache.catalina.core", cl);
/* 518 */       registry.loadDescriptors("org.apache.catalina", cl);
/* 519 */       registry.loadDescriptors("org.apache.catalina.deploy", cl);
/* 520 */       registry.loadDescriptors("org.apache.catalina.loader", cl);
/* 521 */       registry.loadDescriptors("org.apache.catalina.realm", cl);
/* 522 */       registry.loadDescriptors("org.apache.catalina.session", cl);
/* 523 */       registry.loadDescriptors("org.apache.catalina.startup", cl);
/* 524 */       registry.loadDescriptors("org.apache.catalina.users", cl);
/* 525 */       registry.loadDescriptors("org.apache.catalina.ha", cl);
/* 526 */       registry.loadDescriptors("org.apache.catalina.connector", cl);
/* 527 */       registry.loadDescriptors("org.apache.catalina.valves", cl);
/* 528 */       registry.loadDescriptors("org.apache.catalina.storeconfig", cl);
/* 529 */       registry.loadDescriptors("org.apache.tomcat.util.descriptor.web", cl);
/*     */     } 
/* 531 */     return registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized MBeanServer createServer() {
/* 542 */     if (mserver == null) {
/* 543 */       mserver = Registry.getRegistry(null).getMBeanServer();
/*     */     }
/* 545 */     return mserver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroyMBean(ContextEnvironment environment) throws Exception {
/* 558 */     String mname = createManagedName(environment);
/* 559 */     ManagedBean managed = registry.findManagedBean(mname);
/* 560 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 563 */     String domain = managed.getDomain();
/* 564 */     if (domain == null) {
/* 565 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 567 */     ObjectName oname = createObjectName(domain, environment);
/* 568 */     if (mserver.isRegistered(oname)) {
/* 569 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroyMBean(ContextResource resource) throws Exception {
/* 586 */     if ("org.apache.catalina.UserDatabase".equals(resource.getType())) {
/* 587 */       destroyMBeanUserDatabase(resource.getName());
/*     */     }
/*     */     
/* 590 */     String mname = createManagedName(resource);
/* 591 */     ManagedBean managed = registry.findManagedBean(mname);
/* 592 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 595 */     String domain = managed.getDomain();
/* 596 */     if (domain == null) {
/* 597 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 599 */     ObjectName oname = createObjectName(domain, resource);
/* 600 */     if (mserver.isRegistered(oname)) {
/* 601 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroyMBean(ContextResourceLink resourceLink) throws Exception {
/* 616 */     String mname = createManagedName(resourceLink);
/* 617 */     ManagedBean managed = registry.findManagedBean(mname);
/* 618 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 621 */     String domain = managed.getDomain();
/* 622 */     if (domain == null) {
/* 623 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 625 */     ObjectName oname = createObjectName(domain, resourceLink);
/* 626 */     if (mserver.isRegistered(oname)) {
/* 627 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void destroyMBean(Group group) throws Exception {
/* 641 */     String mname = createManagedName(group);
/* 642 */     ManagedBean managed = registry.findManagedBean(mname);
/* 643 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 646 */     String domain = managed.getDomain();
/* 647 */     if (domain == null) {
/* 648 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 650 */     ObjectName oname = createObjectName(domain, group);
/* 651 */     if (mserver.isRegistered(oname)) {
/* 652 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void destroyMBean(Role role) throws Exception {
/* 667 */     String mname = createManagedName(role);
/* 668 */     ManagedBean managed = registry.findManagedBean(mname);
/* 669 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 672 */     String domain = managed.getDomain();
/* 673 */     if (domain == null) {
/* 674 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 676 */     ObjectName oname = createObjectName(domain, role);
/* 677 */     if (mserver.isRegistered(oname)) {
/* 678 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void destroyMBean(User user) throws Exception {
/* 693 */     String mname = createManagedName(user);
/* 694 */     ManagedBean managed = registry.findManagedBean(mname);
/* 695 */     if (managed == null) {
/*     */       return;
/*     */     }
/* 698 */     String domain = managed.getDomain();
/* 699 */     if (domain == null) {
/* 700 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 702 */     ObjectName oname = createObjectName(domain, user);
/* 703 */     if (mserver.isRegistered(oname)) {
/* 704 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void destroyMBeanUserDatabase(String userDatabase) throws Exception {
/* 723 */     ObjectName query = new ObjectName("Users:type=Group,database=" + userDatabase + ",*");
/* 724 */     Set<ObjectName> results = mserver.queryNames(query, null);
/* 725 */     for (ObjectName result : results) {
/* 726 */       mserver.unregisterMBean(result);
/*     */     }
/*     */ 
/*     */     
/* 730 */     query = new ObjectName("Users:type=Role,database=" + userDatabase + ",*");
/* 731 */     results = mserver.queryNames(query, null);
/* 732 */     for (ObjectName result : results) {
/* 733 */       mserver.unregisterMBean(result);
/*     */     }
/*     */ 
/*     */     
/* 737 */     query = new ObjectName("Users:type=User,database=" + userDatabase + ",*");
/* 738 */     results = mserver.queryNames(query, null);
/* 739 */     for (ObjectName result : results) {
/* 740 */       mserver.unregisterMBean(result);
/*     */     }
/*     */ 
/*     */     
/* 744 */     ObjectName db = new ObjectName("Users:type=UserDatabase,database=" + userDatabase);
/* 745 */     if (mserver.isRegistered(db)) {
/* 746 */       mserver.unregisterMBean(db);
/*     */     }
/* 748 */     db = new ObjectName("Catalina:type=UserDatabase,database=" + userDatabase);
/* 749 */     if (mserver.isRegistered(db))
/* 750 */       mserver.unregisterMBean(db); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\MBeanUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */