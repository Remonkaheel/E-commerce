/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import javax.management.Attribute;
/*    */ import javax.management.AttributeNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.ReflectionException;
/*    */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*    */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextEnvironmentMBean
/*    */   extends BaseCatalinaMBean<ContextEnvironment>
/*    */ {
/*    */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, MBeanException, ReflectionException {
/* 37 */     super.setAttribute(attribute);
/*    */     
/* 39 */     ContextEnvironment ce = doGetManagedResource();
/*    */ 
/*    */ 
/*    */     
/* 43 */     NamingResources nr = ce.getNamingResources();
/* 44 */     nr.removeEnvironment(ce.getName());
/* 45 */     nr.addEnvironment(ce);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ContextEnvironmentMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */