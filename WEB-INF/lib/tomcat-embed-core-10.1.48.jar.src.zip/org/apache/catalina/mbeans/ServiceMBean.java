/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.MBeanException;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceMBean
/*     */   extends BaseCatalinaMBean<Service>
/*     */ {
/*     */   public void addConnector(String address, int port, boolean isAjp, boolean isSSL) throws MBeanException {
/*  39 */     Service service = doGetManagedResource();
/*  40 */     String protocol = isAjp ? "AJP/1.3" : "HTTP/1.1";
/*  41 */     Connector connector = new Connector(protocol);
/*  42 */     if (address != null && !address.isEmpty()) {
/*  43 */       connector.setProperty("address", address);
/*     */     }
/*  45 */     connector.setPort(port);
/*  46 */     connector.setSecure(isSSL);
/*  47 */     connector.setScheme(isSSL ? "https" : "http");
/*     */     
/*  49 */     service.addConnector(connector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExecutor(String type) throws MBeanException {
/*  61 */     Service service = doGetManagedResource();
/*  62 */     Executor executor = (Executor)newInstance(type);
/*  63 */     service.addExecutor(executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findConnectors() throws MBeanException {
/*  76 */     Service service = doGetManagedResource();
/*     */     
/*  78 */     Connector[] connectors = service.findConnectors();
/*  79 */     String[] str = new String[connectors.length];
/*     */     
/*  81 */     for (int i = 0; i < connectors.length; i++) {
/*  82 */       str[i] = connectors[i].toString();
/*     */     }
/*     */     
/*  85 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findExecutors() throws MBeanException {
/*  98 */     Service service = doGetManagedResource();
/*     */     
/* 100 */     Executor[] executors = service.findExecutors();
/* 101 */     String[] str = new String[executors.length];
/*     */     
/* 103 */     for (int i = 0; i < executors.length; i++) {
/* 104 */       str[i] = executors[i].toString();
/*     */     }
/*     */     
/* 107 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExecutor(String name) throws MBeanException {
/* 121 */     Service service = doGetManagedResource();
/* 122 */     Executor executor = service.getExecutor(name);
/* 123 */     if (executor != null) {
/* 124 */       return executor.toString();
/*     */     }
/* 126 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\ServiceMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */