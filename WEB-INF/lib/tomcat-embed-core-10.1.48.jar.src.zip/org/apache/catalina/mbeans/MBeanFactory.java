/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.InetAddress;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.apache.catalina.core.StandardEngine;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.core.StandardService;
/*     */ import org.apache.catalina.loader.WebappLoader;
/*     */ import org.apache.catalina.realm.DataSourceRealm;
/*     */ import org.apache.catalina.realm.JNDIRealm;
/*     */ import org.apache.catalina.realm.MemoryRealm;
/*     */ import org.apache.catalina.realm.UserDatabaseRealm;
/*     */ import org.apache.catalina.session.StandardManager;
/*     */ import org.apache.catalina.startup.ContextConfig;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanFactory
/*     */ {
/*  53 */   private static final Log log = LogFactory.getLog(MBeanFactory.class);
/*     */   
/*  55 */   protected static final StringManager sm = StringManager.getManager(MBeanFactory.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static final MBeanServer mserver = MBeanUtils.createServer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object container;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Object container) {
/*  79 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPathStr(String t) {
/*  91 */     if (t == null || t.equals("/")) {
/*  92 */       return "";
/*     */     }
/*  94 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Container getParentContainerFromParent(ObjectName pname) throws Exception {
/* 102 */     String type = pname.getKeyProperty("type");
/* 103 */     String j2eeType = pname.getKeyProperty("j2eeType");
/* 104 */     Service service = getService(pname);
/* 105 */     StandardEngine engine = (StandardEngine)service.getContainer();
/* 106 */     if (j2eeType != null && j2eeType.equals("WebModule")) {
/* 107 */       String name = pname.getKeyProperty("name");
/* 108 */       name = name.substring(2);
/* 109 */       int i = name.indexOf('/');
/* 110 */       String hostName = name.substring(0, i);
/* 111 */       String path = name.substring(i);
/* 112 */       Container host = engine.findChild(hostName);
/* 113 */       String pathStr = getPathStr(path);
/* 114 */       return host.findChild(pathStr);
/* 115 */     }  if (type != null) {
/* 116 */       if (type.equals("Engine"))
/* 117 */         return (Container)engine; 
/* 118 */       if (type.equals("Host")) {
/* 119 */         String hostName = pname.getKeyProperty("host");
/* 120 */         return engine.findChild(hostName);
/*     */       } 
/*     */     } 
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Container getParentContainerFromChild(ObjectName oname) throws Exception {
/* 133 */     String hostName = oname.getKeyProperty("host");
/* 134 */     String path = oname.getKeyProperty("path");
/* 135 */     Service service = getService(oname);
/* 136 */     Engine engine = service.getContainer();
/* 137 */     if (hostName == null)
/*     */     {
/* 139 */       return (Container)engine; } 
/* 140 */     if (path == null)
/*     */     {
/* 142 */       return engine.findChild(hostName);
/*     */     }
/*     */     
/* 145 */     Container host = engine.findChild(hostName);
/* 146 */     path = getPathStr(path);
/* 147 */     return host.findChild(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Service getService(ObjectName oname) throws Exception {
/* 154 */     if (this.container instanceof Service)
/*     */     {
/* 156 */       return (Service)this.container;
/*     */     }
/*     */     
/* 159 */     StandardService service = null;
/* 160 */     String domain = oname.getDomain();
/* 161 */     if (this.container instanceof Server) {
/* 162 */       Service[] services = ((Server)this.container).findServices();
/* 163 */       for (Service value : services) {
/* 164 */         service = (StandardService)value;
/* 165 */         if (domain.equals(service.getObjectName().getDomain())) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/* 170 */     if (service == null || !service.getObjectName().getDomain().equals(domain)) {
/* 171 */       throw new Exception(sm.getString("mBeanFactory.noService", new Object[] { domain }));
/*     */     }
/* 173 */     return (Service)service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createAjpConnector(String parent, String address, int port) throws Exception {
/* 191 */     return createConnector(parent, address, port, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createDataSourceRealm(String parent, String dataSourceName, String roleNameCol, String userCredCol, String userNameCol, String userRoleTable, String userTable) throws Exception {
/* 214 */     DataSourceRealm realm = new DataSourceRealm();
/* 215 */     realm.setDataSourceName(dataSourceName);
/* 216 */     realm.setRoleNameCol(roleNameCol);
/* 217 */     realm.setUserCredCol(userCredCol);
/* 218 */     realm.setUserNameCol(userNameCol);
/* 219 */     realm.setUserRoleTable(userRoleTable);
/* 220 */     realm.setUserTable(userTable);
/*     */ 
/*     */     
/* 223 */     return addRealmToParent(parent, (Realm)realm);
/*     */   }
/*     */ 
/*     */   
/*     */   private String addRealmToParent(String parent, Realm realm) throws Exception {
/* 228 */     ObjectName pname = new ObjectName(parent);
/* 229 */     Container container = getParentContainerFromParent(pname);
/* 230 */     if (container == null) {
/* 231 */       throw new IllegalArgumentException(sm.getString("mBeanFactory.noParent", new Object[] { parent }));
/*     */     }
/*     */     
/* 234 */     container.setRealm(realm);
/*     */     
/* 236 */     ObjectName oname = null;
/* 237 */     if (realm instanceof JmxEnabled) {
/* 238 */       oname = ((JmxEnabled)realm).getObjectName();
/*     */     }
/* 240 */     if (oname != null) {
/* 241 */       return oname.toString();
/*     */     }
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createHttpConnector(String parent, String address, int port) throws Exception {
/* 260 */     return createConnector(parent, address, port, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createConnector(String parent, String address, int port, boolean isAjp, boolean isSSL) throws Exception {
/* 278 */     String protocol = isAjp ? "AJP/1.3" : "HTTP/1.1";
/* 279 */     Connector retobj = new Connector(protocol);
/* 280 */     if (address != null && !address.isEmpty()) {
/* 281 */       retobj.setProperty("address", address);
/*     */     }
/*     */     
/* 284 */     retobj.setPort(port);
/*     */     
/* 286 */     retobj.setSecure(isSSL);
/* 287 */     retobj.setScheme(isSSL ? "https" : "http");
/*     */ 
/*     */     
/* 290 */     ObjectName pname = new ObjectName(parent);
/* 291 */     Service service = getService(pname);
/* 292 */     service.addConnector(retobj);
/*     */ 
/*     */     
/* 295 */     ObjectName coname = retobj.getObjectName();
/*     */     
/* 297 */     return coname.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createHttpsConnector(String parent, String address, int port) throws Exception {
/* 313 */     return createConnector(parent, address, port, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createJNDIRealm(String parent) throws Exception {
/* 329 */     JNDIRealm realm = new JNDIRealm();
/*     */ 
/*     */     
/* 332 */     return addRealmToParent(parent, (Realm)realm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createMemoryRealm(String parent) throws Exception {
/* 348 */     MemoryRealm realm = new MemoryRealm();
/*     */ 
/*     */     
/* 351 */     return addRealmToParent(parent, (Realm)realm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createStandardContext(String parent, String path, String docBase) throws Exception {
/* 368 */     return createStandardContext(parent, path, docBase, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createStandardContext(String parent, String path, String docBase, boolean xmlValidation, boolean xmlNamespaceAware) throws Exception {
/* 389 */     StandardContext context = new StandardContext();
/* 390 */     path = getPathStr(path);
/* 391 */     context.setPath(path);
/* 392 */     context.setDocBase(docBase);
/* 393 */     context.setXmlValidation(xmlValidation);
/* 394 */     context.setXmlNamespaceAware(xmlNamespaceAware);
/*     */     
/* 396 */     ContextConfig contextConfig = new ContextConfig();
/* 397 */     context.addLifecycleListener((LifecycleListener)contextConfig);
/*     */ 
/*     */     
/* 400 */     ObjectName pname = new ObjectName(parent);
/* 401 */     ObjectName deployer = new ObjectName(pname.getDomain() + ":type=Deployer,host=" + pname.getDomain());
/* 402 */     if (mserver.isRegistered(deployer)) {
/* 403 */       String contextName = context.getName();
/* 404 */       Boolean result = (Boolean)mserver.invoke(deployer, "tryAddServiced", new Object[] { contextName }, new String[] { "java.lang.String" });
/*     */       
/* 406 */       if (result.booleanValue()) {
/*     */         try {
/* 408 */           String configPath = (String)mserver.getAttribute(deployer, "configBaseName");
/* 409 */           String baseName = context.getBaseName();
/* 410 */           File configFile = new File(new File(configPath), baseName + ".xml");
/* 411 */           if (configFile.isFile()) {
/* 412 */             context.setConfigFile(configFile.toURI().toURL());
/*     */           }
/* 414 */           mserver.invoke(deployer, "manageApp", new Object[] { context }, new String[] { "org.apache.catalina.Context" });
/*     */         } finally {
/*     */           
/* 417 */           mserver.invoke(deployer, "removeServiced", new Object[] { contextName }, new String[] { "java.lang.String" });
/*     */         } 
/*     */       } else {
/*     */         
/* 421 */         throw new IllegalStateException(sm
/* 422 */             .getString("mBeanFactory.contextCreate.addServicedFail", new Object[] { contextName }));
/*     */       } 
/*     */     } else {
/* 425 */       log.warn(sm.getString("mBeanFactory.noDeployer", new Object[] { pname.getKeyProperty("host") }));
/* 426 */       Service service = getService(pname);
/* 427 */       Engine engine = service.getContainer();
/* 428 */       Host host = (Host)engine.findChild(pname.getKeyProperty("host"));
/* 429 */       host.addChild((Container)context);
/*     */     } 
/*     */ 
/*     */     
/* 433 */     return context.getObjectName().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createStandardHost(String parent, String name, String appBase, boolean autoDeploy, boolean deployOnStartup, boolean deployXML, boolean unpackWARs) throws Exception {
/* 456 */     StandardHost host = new StandardHost();
/* 457 */     host.setName(name);
/* 458 */     host.setAppBase(appBase);
/* 459 */     host.setAutoDeploy(autoDeploy);
/* 460 */     host.setDeployOnStartup(deployOnStartup);
/* 461 */     host.setDeployXML(deployXML);
/* 462 */     host.setUnpackWARs(unpackWARs);
/*     */ 
/*     */     
/* 465 */     HostConfig hostConfig = new HostConfig();
/* 466 */     host.addLifecycleListener((LifecycleListener)hostConfig);
/*     */ 
/*     */     
/* 469 */     ObjectName pname = new ObjectName(parent);
/* 470 */     Service service = getService(pname);
/* 471 */     Engine engine = service.getContainer();
/* 472 */     engine.addChild((Container)host);
/*     */ 
/*     */     
/* 475 */     return host.getObjectName().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createStandardServiceEngine(String domain, String defaultHost, String baseDir) throws Exception {
/* 493 */     if (!(this.container instanceof Server)) {
/* 494 */       throw new Exception(sm.getString("mBeanFactory.notServer"));
/*     */     }
/*     */     
/* 497 */     StandardEngine engine = new StandardEngine();
/* 498 */     engine.setDomain(domain);
/* 499 */     engine.setName(domain);
/* 500 */     engine.setDefaultHost(defaultHost);
/*     */     
/* 502 */     StandardService standardService = new StandardService();
/* 503 */     standardService.setContainer((Engine)engine);
/* 504 */     standardService.setName(domain);
/*     */     
/* 506 */     ((Server)this.container).addService((Service)standardService);
/*     */     
/* 508 */     return engine.getObjectName().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createStandardManager(String parent) throws Exception {
/* 524 */     StandardManager manager = new StandardManager();
/*     */ 
/*     */     
/* 527 */     ObjectName pname = new ObjectName(parent);
/* 528 */     Container container = getParentContainerFromParent(pname);
/* 529 */     if (container instanceof Context) {
/* 530 */       ((Context)container).setManager((Manager)manager);
/*     */     } else {
/* 532 */       throw new Exception(sm.getString("mBeanFactory.managerContext"));
/*     */     } 
/* 534 */     ObjectName oname = manager.getObjectName();
/* 535 */     if (oname != null) {
/* 536 */       return oname.toString();
/*     */     }
/* 538 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createUserDatabaseRealm(String parent, String resourceName) throws Exception {
/* 557 */     UserDatabaseRealm realm = new UserDatabaseRealm();
/* 558 */     realm.setResourceName(resourceName);
/*     */ 
/*     */     
/* 561 */     return addRealmToParent(parent, (Realm)realm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createValve(String className, String parent) throws Exception {
/* 579 */     ObjectName parentName = new ObjectName(parent);
/* 580 */     Container container = getParentContainerFromParent(parentName);
/*     */     
/* 582 */     if (container == null) {
/* 583 */       throw new IllegalArgumentException(sm.getString("mBeanFactory.noParent", new Object[] { parent }));
/*     */     }
/*     */     
/* 586 */     Valve valve = Class.forName(className).getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     
/* 588 */     container.getPipeline().addValve(valve);
/*     */     
/* 590 */     if (valve instanceof JmxEnabled) {
/* 591 */       return ((JmxEnabled)valve).getObjectName().toString();
/*     */     }
/* 593 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createWebappLoader(String parent) throws Exception {
/* 610 */     WebappLoader loader = new WebappLoader();
/*     */ 
/*     */     
/* 613 */     ObjectName pname = new ObjectName(parent);
/* 614 */     Container container = getParentContainerFromParent(pname);
/* 615 */     if (container instanceof Context) {
/* 616 */       ((Context)container).setLoader((Loader)loader);
/*     */     }
/* 618 */     return loader.getObjectName().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnector(String name) throws Exception {
/* 633 */     ObjectName oname = new ObjectName(name);
/* 634 */     Service service = getService(oname);
/* 635 */     String port = oname.getKeyProperty("port");
/* 636 */     String address = oname.getKeyProperty("address");
/* 637 */     if (address != null) {
/* 638 */       address = ObjectName.unquote(address);
/*     */     }
/*     */     
/* 641 */     Connector[] conns = service.findConnectors();
/*     */     
/* 643 */     for (Connector conn : conns) {
/* 644 */       String connAddress = null;
/* 645 */       Object objConnAddress = conn.getProperty("address");
/* 646 */       if (objConnAddress != null) {
/* 647 */         connAddress = ((InetAddress)objConnAddress).getHostAddress();
/*     */       }
/* 649 */       String connPort = "" + conn.getPortWithOffset();
/*     */       
/* 651 */       if (address == null) {
/*     */ 
/*     */         
/* 654 */         if (connAddress == null && port.equals(connPort)) {
/* 655 */           service.removeConnector(conn);
/* 656 */           conn.destroy();
/*     */           break;
/*     */         } 
/* 659 */       } else if (address.equals(connAddress) && port.equals(connPort)) {
/* 660 */         service.removeConnector(conn);
/* 661 */         conn.destroy();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeContext(String contextName) throws Exception {
/* 678 */     ObjectName oname = new ObjectName(contextName);
/* 679 */     String domain = oname.getDomain();
/* 680 */     StandardService service = (StandardService)getService(oname);
/*     */     
/* 682 */     Engine engine = service.getContainer();
/* 683 */     String name = oname.getKeyProperty("name");
/* 684 */     name = name.substring(2);
/* 685 */     int i = name.indexOf('/');
/* 686 */     String hostName = name.substring(0, i);
/* 687 */     String path = name.substring(i);
/* 688 */     ObjectName deployer = new ObjectName(domain + ":type=Deployer,host=" + domain);
/* 689 */     String pathStr = getPathStr(path);
/* 690 */     if (mserver.isRegistered(deployer)) {
/* 691 */       Boolean result = (Boolean)mserver.invoke(deployer, "tryAddServiced", new Object[] { pathStr }, new String[] { "java.lang.String" });
/*     */       
/* 693 */       if (result.booleanValue()) {
/*     */         try {
/* 695 */           mserver.invoke(deployer, "unmanageApp", new Object[] { pathStr }, new String[] { "java.lang.String" });
/*     */         } finally {
/*     */           
/* 698 */           mserver.invoke(deployer, "removeServiced", new Object[] { pathStr }, new String[] { "java.lang.String" });
/*     */         } 
/*     */       } else {
/*     */         
/* 702 */         throw new IllegalStateException(sm.getString("mBeanFactory.removeContext.addServicedFail", new Object[] { pathStr }));
/*     */       } 
/*     */     } else {
/* 705 */       log.warn(sm.getString("mBeanFactory.noDeployer", new Object[] { hostName }));
/* 706 */       Host host = (Host)engine.findChild(hostName);
/* 707 */       Context context = (Context)host.findChild(pathStr);
/*     */       
/* 709 */       host.removeChild((Container)context);
/* 710 */       if (context instanceof StandardContext) {
/*     */         try {
/* 712 */           context.destroy();
/* 713 */         } catch (Exception e) {
/* 714 */           log.warn(sm.getString("mBeanFactory.contextDestroyError"), e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHost(String name) throws Exception {
/* 732 */     ObjectName oname = new ObjectName(name);
/* 733 */     String hostName = oname.getKeyProperty("host");
/* 734 */     Service service = getService(oname);
/* 735 */     Engine engine = service.getContainer();
/* 736 */     Host host = (Host)engine.findChild(hostName);
/*     */ 
/*     */     
/* 739 */     if (host != null) {
/* 740 */       engine.removeChild((Container)host);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLoader(String name) throws Exception {
/* 754 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 756 */     Container container = getParentContainerFromChild(oname);
/* 757 */     if (container instanceof Context) {
/* 758 */       ((Context)container).setLoader(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeManager(String name) throws Exception {
/* 772 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 774 */     Container container = getParentContainerFromChild(oname);
/* 775 */     if (container instanceof Context) {
/* 776 */       ((Context)container).setManager(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRealm(String name) throws Exception {
/* 790 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 792 */     Container container = getParentContainerFromChild(oname);
/* 793 */     container.setRealm(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeService(String name) throws Exception {
/* 806 */     if (!(this.container instanceof Server)) {
/* 807 */       throw new Exception(sm.getString("mBeanFactory.notServer"));
/*     */     }
/*     */ 
/*     */     
/* 811 */     ObjectName oname = new ObjectName(name);
/* 812 */     Service service = getService(oname);
/* 813 */     ((Server)this.container).removeService(service);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeValve(String name) throws Exception {
/* 827 */     ObjectName oname = new ObjectName(name);
/* 828 */     Container container = getParentContainerFromChild(oname);
/* 829 */     Valve[] valves = container.getPipeline().getValves();
/* 830 */     for (Valve valve : valves) {
/* 831 */       ObjectName voname = ((JmxEnabled)valve).getObjectName();
/* 832 */       if (voname.equals(oname))
/* 833 */         container.getPipeline().removeValve(valve); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\MBeanFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */