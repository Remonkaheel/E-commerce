/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceUserDatabaseMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  44 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected final ManagedBean managed = this.registry.findManagedBean("DataSourceUserDatabase");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGroups() {
/*  59 */     UserDatabase database = (UserDatabase)this.resource;
/*  60 */     List<String> results = new ArrayList<>();
/*  61 */     Iterator<Group> groups = database.getGroups();
/*  62 */     while (groups.hasNext()) {
/*  63 */       Group group = groups.next();
/*  64 */       results.add(group.getGroupname());
/*     */     } 
/*  66 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRoles() {
/*  74 */     UserDatabase database = (UserDatabase)this.resource;
/*  75 */     List<String> results = new ArrayList<>();
/*  76 */     Iterator<Role> roles = database.getRoles();
/*  77 */     while (roles.hasNext()) {
/*  78 */       Role role = roles.next();
/*  79 */       results.add(role.getRolename());
/*     */     } 
/*  81 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUsers() {
/*  89 */     UserDatabase database = (UserDatabase)this.resource;
/*  90 */     List<String> results = new ArrayList<>();
/*  91 */     Iterator<User> users = database.getUsers();
/*  92 */     while (users.hasNext()) {
/*  93 */       User user = users.next();
/*  94 */       results.add(user.getUsername());
/*     */     } 
/*  96 */     return results.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createGroup(String groupname, String description) {
/* 111 */     UserDatabase database = (UserDatabase)this.resource;
/* 112 */     Group group = database.createGroup(groupname, description);
/* 113 */     return group.getGroupname();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createRole(String rolename, String description) {
/* 126 */     UserDatabase database = (UserDatabase)this.resource;
/* 127 */     Role role = database.createRole(rolename, description);
/* 128 */     return role.getRolename();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createUser(String username, String password, String fullName) {
/* 142 */     UserDatabase database = (UserDatabase)this.resource;
/* 143 */     User user = database.createUser(username, password, fullName);
/* 144 */     return user.getUsername();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroup(String groupname) {
/* 154 */     UserDatabase database = (UserDatabase)this.resource;
/* 155 */     Group group = database.findGroup(groupname);
/* 156 */     if (group == null) {
/*     */       return;
/*     */     }
/* 159 */     database.removeGroup(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRole(String rolename) {
/* 169 */     UserDatabase database = (UserDatabase)this.resource;
/* 170 */     Role role = database.findRole(rolename);
/* 171 */     if (role == null) {
/*     */       return;
/*     */     }
/* 174 */     database.removeRole(role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUser(String username) {
/* 184 */     UserDatabase database = (UserDatabase)this.resource;
/* 185 */     User user = database.findUser(username);
/* 186 */     if (user == null) {
/*     */       return;
/*     */     }
/* 189 */     database.removeUser(user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeUserPassword(String username, String password) {
/* 200 */     UserDatabase database = (UserDatabase)this.resource;
/* 201 */     User user = database.findUser(username);
/* 202 */     if (user != null) {
/* 203 */       user.setPassword(password);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUserRole(String username, String rolename) {
/* 215 */     UserDatabase database = (UserDatabase)this.resource;
/* 216 */     User user = database.findUser(username);
/* 217 */     Role role = database.findRole(rolename);
/* 218 */     if (user != null && role != null) {
/* 219 */       user.addRole(role);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUserRole(String username, String rolename) {
/* 231 */     UserDatabase database = (UserDatabase)this.resource;
/* 232 */     User user = database.findUser(username);
/* 233 */     Role role = database.findRole(rolename);
/* 234 */     if (user != null && role != null) {
/* 235 */       user.removeRole(role);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUserRoles(String username) {
/* 248 */     UserDatabase database = (UserDatabase)this.resource;
/* 249 */     User user = database.findUser(username);
/* 250 */     if (user != null) {
/* 251 */       List<String> results = new ArrayList<>();
/* 252 */       Iterator<Role> roles = user.getRoles();
/* 253 */       while (roles.hasNext()) {
/* 254 */         Role role = roles.next();
/* 255 */         results.add(role.getRolename());
/*     */       } 
/* 257 */       return results.<String>toArray(new String[0]);
/*     */     } 
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUserGroup(String username, String groupname) {
/* 271 */     UserDatabase database = (UserDatabase)this.resource;
/* 272 */     User user = database.findUser(username);
/* 273 */     Group group = database.findGroup(groupname);
/* 274 */     if (user != null && group != null) {
/* 275 */       user.addGroup(group);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUserGroup(String username, String groupname) {
/* 287 */     UserDatabase database = (UserDatabase)this.resource;
/* 288 */     User user = database.findUser(username);
/* 289 */     Group group = database.findGroup(groupname);
/* 290 */     if (user != null && group != null) {
/* 291 */       user.removeGroup(group);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUserGroups(String username) {
/* 304 */     UserDatabase database = (UserDatabase)this.resource;
/* 305 */     User user = database.findUser(username);
/* 306 */     if (user != null) {
/* 307 */       List<String> results = new ArrayList<>();
/* 308 */       Iterator<Group> groups = user.getGroups();
/* 309 */       while (groups.hasNext()) {
/* 310 */         Group group = groups.next();
/* 311 */         results.add(group.getGroupname());
/*     */       } 
/* 313 */       return results.<String>toArray(new String[0]);
/*     */     } 
/* 315 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGroupRole(String groupname, String rolename) {
/* 327 */     UserDatabase database = (UserDatabase)this.resource;
/* 328 */     Group group = database.findGroup(groupname);
/* 329 */     Role role = database.findRole(rolename);
/* 330 */     if (group != null && role != null) {
/* 331 */       group.addRole(role);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeGroupRole(String groupname, String rolename) {
/* 343 */     UserDatabase database = (UserDatabase)this.resource;
/* 344 */     Group group = database.findGroup(groupname);
/* 345 */     Role role = database.findRole(rolename);
/* 346 */     if (group != null && role != null) {
/* 347 */       group.removeRole(role);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGroupRoles(String groupname) {
/* 360 */     UserDatabase database = (UserDatabase)this.resource;
/* 361 */     Group group = database.findGroup(groupname);
/* 362 */     if (group != null) {
/* 363 */       List<String> results = new ArrayList<>();
/* 364 */       Iterator<Role> roles = group.getRoles();
/* 365 */       while (roles.hasNext()) {
/* 366 */         Role role = roles.next();
/* 367 */         results.add(role.getRolename());
/*     */       } 
/* 369 */       return results.<String>toArray(new String[0]);
/*     */     } 
/* 371 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\DataSourceUserDatabaseMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */