/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import org.apache.tomcat.util.modeler.ManagedBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemoryUserDatabaseMBean
/*    */   extends SparseUserDatabaseMBean
/*    */ {
/* 32 */   protected final ManagedBean managed = this.registry.findManagedBean("MemoryUserDatabase");
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\mbeans\MemoryUserDatabaseMBean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */