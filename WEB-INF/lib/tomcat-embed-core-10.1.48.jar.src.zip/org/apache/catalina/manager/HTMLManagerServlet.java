/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import jakarta.servlet.ServletResponse;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import jakarta.servlet.http.Part;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.manager.util.SessionUtils;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HTMLManagerServlet
/*      */   extends ManagerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   static final String APPLICATION_MESSAGE = "message";
/*      */   static final String APPLICATION_ERROR = "error";
/*      */   static final String sessionsListJspPath = "/WEB-INF/jsp/sessionsList.jsp";
/*      */   static final String sessionDetailJspPath = "/WEB-INF/jsp/sessionDetail.jsp";
/*      */   static final String connectorCiphersJspPath = "/WEB-INF/jsp/connectorCiphers.jsp";
/*      */   static final String connectorCertsJspPath = "/WEB-INF/jsp/connectorCerts.jsp";
/*      */   static final String connectorTrustedCertsJspPath = "/WEB-INF/jsp/connectorTrustedCerts.jsp";
/*      */   private boolean showProxySessions = false;
/*   81 */   private String htmlSubTitle = null; private static final String APPS_HEADER_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n";
/*      */   private static final String APPS_ROW_DETAILS_SECTION = "<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n";
/*      */   private static final String MANAGER_APP_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STARTED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  &nbsp;&nbsp;<small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STOPPED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n";
/*      */   
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*   88 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   93 */     String command = request.getPathInfo();
/*      */     
/*   95 */     String path = request.getParameter("path");
/*   96 */     ContextName cn = null;
/*   97 */     if (path != null) {
/*   98 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*      */ 
/*      */     
/*  102 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  104 */     String message = "";
/*      */     
/*  106 */     if (command != null && !command.equals("/"))
/*      */     {
/*  108 */       if (!command.equals("/list"))
/*      */       {
/*  110 */         if (command.equals("/sessions")) {
/*      */           try {
/*  112 */             if (cn != null) {
/*  113 */               doSessions(cn, request, response, smClient);
/*      */               return;
/*      */             } 
/*  116 */           } catch (Exception e) {
/*  117 */             log(sm.getString("htmlManagerServlet.error.sessions", new Object[] { cn }), e);
/*  118 */             message = smClient.getString("managerServlet.exception", new Object[] { e.toString() });
/*      */           } 
/*  120 */         } else if (command.equals("/sslConnectorCiphers")) {
/*  121 */           sslConnectorCiphers(request, response, smClient);
/*  122 */         } else if (command.equals("/sslConnectorCerts")) {
/*  123 */           sslConnectorCerts(request, response, smClient);
/*  124 */         } else if (command.equals("/sslConnectorTrustedCerts")) {
/*  125 */           sslConnectorTrustedCerts(request, response, smClient);
/*  126 */         } else if (command.equals("/upload") || command.equals("/deploy") || command.equals("/reload") || command
/*  127 */           .equals("/undeploy") || command.equals("/expire") || command.equals("/start") || command
/*  128 */           .equals("/stop")) {
/*  129 */           message = smClient.getString("managerServlet.postCommand", new Object[] { command });
/*      */         } else {
/*  131 */           message = smClient.getString("managerServlet.unknownCommand", new Object[] { command });
/*      */         }  } 
/*      */     }
/*  134 */     list(request, response, message, smClient);
/*      */   }
/*      */   private static final String STARTED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n"; private static final String STOPPED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n";
/*      */   private static final String DEPLOY_SECTION = "</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployVersion\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{6}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n";
/*      */   
/*      */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*  140 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     String command = request.getPathInfo();
/*      */     
/*  147 */     String path = request.getParameter("path");
/*  148 */     ContextName cn = null;
/*  149 */     if (path != null) {
/*  150 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*      */     
/*  153 */     String deployPath = request.getParameter("deployPath");
/*  154 */     String deployWar = request.getParameter("deployWar");
/*  155 */     String deployConfig = request.getParameter("deployConfig");
/*  156 */     ContextName deployCn = null;
/*  157 */     if (deployPath != null && !deployPath.isEmpty()) {
/*  158 */       deployCn = new ContextName(deployPath, request.getParameter("deployVersion"));
/*  159 */     } else if (deployConfig != null && !deployConfig.isEmpty()) {
/*  160 */       deployCn = ContextName.extractFromPath(deployConfig);
/*  161 */     } else if (deployWar != null && !deployWar.isEmpty()) {
/*  162 */       deployCn = ContextName.extractFromPath(deployWar);
/*      */     } 
/*      */     
/*  165 */     String tlsHostName = request.getParameter("tlsHostName");
/*      */ 
/*      */     
/*  168 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  170 */     String message = "";
/*      */     
/*  172 */     if (command != null && !command.isEmpty())
/*      */     {
/*      */       
/*  175 */       if (command.equals("/upload")) {
/*  176 */         message = upload(request, smClient);
/*  177 */       } else if (command.equals("/deploy")) {
/*  178 */         message = deployInternal(deployConfig, deployCn, deployWar, smClient);
/*  179 */       } else if (command.equals("/reload")) {
/*  180 */         message = reload(cn, smClient);
/*  181 */       } else if (command.equals("/undeploy")) {
/*  182 */         message = undeploy(cn, smClient);
/*  183 */       } else if (command.equals("/expire")) {
/*  184 */         message = expireSessions(cn, request, smClient);
/*  185 */       } else if (command.equals("/start")) {
/*  186 */         message = start(cn, smClient);
/*  187 */       } else if (command.equals("/stop")) {
/*  188 */         message = stop(cn, smClient);
/*  189 */       } else if (command.equals("/findleaks")) {
/*  190 */         message = findleaks(smClient);
/*  191 */       } else if (command.equals("/sslReload")) {
/*  192 */         message = sslReload(tlsHostName, smClient);
/*      */       } else {
/*      */         
/*  195 */         doGet(request, response);
/*      */         return;
/*      */       } 
/*      */     }
/*  199 */     list(request, response, message, smClient);
/*      */   }
/*      */   private static final String UPLOAD_SECTION = "<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n"; private static final String CONFIG_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"tlsHostName\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>"; private static final String DIAGNOSTICS_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{2}\">\n   <input type=\"submit\" value=\"{4}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{6}\">\n   <input type=\"submit\" value=\"{7}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{9}\">\n   <input type=\"submit\" value=\"{10}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{11}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{12}\">\n   <input type=\"submit\" value=\"{13}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{14}</small>\n </td>\n</tr>\n</table>\n<br>";
/*      */   
/*      */   protected String upload(HttpServletRequest request, StringManager smClient) {
/*  204 */     String message = "";
/*      */ 
/*      */     
/*      */     try {
/*  208 */       Part warPart = request.getPart("deployWar");
/*  209 */       if (warPart == null) {
/*  210 */         message = smClient.getString("htmlManagerServlet.deployUploadNoFile");
/*      */       } else {
/*      */         
/*  213 */         String filename = warPart.getSubmittedFileName();
/*  214 */         if (filename == null || !filename.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  215 */           message = smClient.getString("htmlManagerServlet.deployUploadNotWar", new Object[] { filename });
/*      */         }
/*      */         else {
/*      */           
/*  219 */           if (filename.lastIndexOf('\\') >= 0) {
/*  220 */             filename = filename.substring(filename.lastIndexOf('\\') + 1);
/*      */           }
/*  222 */           if (filename.lastIndexOf('/') >= 0) {
/*  223 */             filename = filename.substring(filename.lastIndexOf('/') + 1);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  228 */           File file = new File(this.host.getAppBaseFile(), filename);
/*  229 */           if (file.exists()) {
/*  230 */             message = smClient.getString("htmlManagerServlet.deployUploadWarExists", new Object[] { filename });
/*      */           }
/*      */           else {
/*      */             
/*  234 */             ContextName cn = new ContextName(filename, true);
/*  235 */             String name = cn.getName();
/*      */             
/*  237 */             if (this.host.findChild(name) != null && !isDeployed(name))
/*  238 */             { message = smClient.getString("htmlManagerServlet.deployUploadInServerXml", new Object[] { filename });
/*      */               
/*      */                }
/*      */             
/*  242 */             else if (tryAddServiced(name))
/*      */             { try {
/*  244 */                 warPart.write(file.getAbsolutePath());
/*      */               } finally {
/*  246 */                 removeServiced(name);
/*      */               } 
/*      */               
/*  249 */               check(name); }
/*      */             else
/*  251 */             { message = smClient.getString("managerServlet.inService", new Object[] { name }); } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  255 */     } catch (Exception e) {
/*  256 */       message = smClient.getString("htmlManagerServlet.deployUploadFail", new Object[] { e.getMessage() });
/*  257 */       log(message, e);
/*      */     } 
/*  259 */     return message;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String deployInternal(String config, ContextName cn, String war, StringManager smClient) {
/*  274 */     StringWriter stringWriter = new StringWriter();
/*  275 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  277 */     deploy(printWriter, config, cn, war, false, smClient);
/*      */     
/*  279 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void list(HttpServletRequest request, HttpServletResponse response, String message, StringManager smClient) throws IOException {
/*  296 */     if (this.debug >= 1) {
/*  297 */       log("list: Listing contexts for virtual host '" + this.host.getName() + "'");
/*      */     }
/*      */     
/*  300 */     PrintWriter writer = response.getWriter();
/*      */     
/*  302 */     Object[] args = new Object[2];
/*  303 */     args[0] = getServletContext().getContextPath();
/*  304 */     args[1] = smClient.getString("htmlManagerServlet.title");
/*  305 */     if (this.htmlSubTitle != null) {
/*  306 */       args[1] = String.valueOf(args[1]) + "</font><br/><font size=\"+1\">" + String.valueOf(args[1]);
/*      */     }
/*      */ 
/*      */     
/*  310 */     writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*      */ 
/*      */     
/*  313 */     writer.print(MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*      */ 
/*      */     
/*  316 */     args = new Object[3];
/*  317 */     args[0] = smClient.getString("htmlManagerServlet.messageLabel");
/*  318 */     if (message == null || message.isEmpty()) {
/*  319 */       args[1] = "OK";
/*      */     } else {
/*  321 */       args[1] = Escape.htmlElementContent(message);
/*      */     } 
/*  323 */     writer.print(MessageFormat.format(Constants.MESSAGE_SECTION, args));
/*      */ 
/*      */     
/*  326 */     args = new Object[9];
/*  327 */     args[0] = smClient.getString("htmlManagerServlet.manager");
/*  328 */     args[1] = response.encodeURL(getServletContext().getContextPath() + "/html/list");
/*  329 */     args[2] = smClient.getString("htmlManagerServlet.list");
/*  330 */     args[3] = 
/*  331 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/*      */     
/*  333 */     args[4] = smClient.getString("htmlManagerServlet.helpHtmlManager");
/*  334 */     args[5] = 
/*  335 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/*  336 */     args[6] = smClient.getString("htmlManagerServlet.helpManager");
/*  337 */     args[7] = response.encodeURL(getServletContext().getContextPath() + "/status");
/*  338 */     args[8] = smClient.getString("statusServlet.title");
/*  339 */     writer.print(MessageFormat.format(Constants.MANAGER_SECTION, args));
/*      */ 
/*      */     
/*  342 */     args = new Object[7];
/*  343 */     args[0] = smClient.getString("htmlManagerServlet.appsTitle");
/*  344 */     args[1] = smClient.getString("htmlManagerServlet.appsPath");
/*  345 */     args[2] = smClient.getString("htmlManagerServlet.appsVersion");
/*  346 */     args[3] = smClient.getString("htmlManagerServlet.appsName");
/*  347 */     args[4] = smClient.getString("htmlManagerServlet.appsAvailable");
/*  348 */     args[5] = smClient.getString("htmlManagerServlet.appsSessions");
/*  349 */     args[6] = smClient.getString("htmlManagerServlet.appsTasks");
/*  350 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n", args));
/*      */ 
/*      */ 
/*      */     
/*  354 */     Container[] children = this.host.findChildren();
/*  355 */     String[] contextNames = new String[children.length];
/*  356 */     for (int i = 0; i < children.length; i++) {
/*  357 */       contextNames[i] = children[i].getName();
/*      */     }
/*      */     
/*  360 */     Arrays.sort((Object[])contextNames);
/*      */     
/*  362 */     String appsStart = smClient.getString("htmlManagerServlet.appsStart");
/*  363 */     String appsStop = smClient.getString("htmlManagerServlet.appsStop");
/*  364 */     String appsReload = smClient.getString("htmlManagerServlet.appsReload");
/*  365 */     String appsUndeploy = smClient.getString("htmlManagerServlet.appsUndeploy");
/*  366 */     String appsExpire = smClient.getString("htmlManagerServlet.appsExpire");
/*  367 */     String noVersion = "<i>" + smClient.getString("htmlManagerServlet.noVersion") + "</i>";
/*      */     
/*  369 */     boolean isHighlighted = true;
/*      */ 
/*      */ 
/*      */     
/*  373 */     for (String contextName : contextNames) {
/*  374 */       Context ctxt = (Context)this.host.findChild(contextName);
/*      */       
/*  376 */       if (ctxt != null) {
/*      */         boolean isDeployed; String highlightColor;
/*  378 */         isHighlighted = !isHighlighted;
/*  379 */         if (isHighlighted) {
/*  380 */           highlightColor = "#C3F3C3";
/*      */         } else {
/*  382 */           highlightColor = "#FFFFFF";
/*      */         } 
/*      */         
/*  385 */         String contextPath = ctxt.getPath();
/*  386 */         String displayPath = contextPath;
/*  387 */         if (displayPath.isEmpty()) {
/*  388 */           displayPath = "/";
/*      */         }
/*      */         
/*  391 */         StringBuilder tmp = new StringBuilder();
/*  392 */         tmp.append("path=");
/*  393 */         tmp.append(URLEncoder.DEFAULT.encode(displayPath, StandardCharsets.UTF_8));
/*  394 */         String webappVersion = ctxt.getWebappVersion();
/*  395 */         if (webappVersion != null && !webappVersion.isEmpty()) {
/*  396 */           tmp.append("&version=");
/*  397 */           tmp.append(URLEncoder.DEFAULT.encode(webappVersion, StandardCharsets.UTF_8));
/*      */         } 
/*  399 */         String pathVersion = tmp.toString();
/*      */         
/*      */         try {
/*  402 */           isDeployed = isDeployed(contextName);
/*  403 */         } catch (Exception e) {
/*      */           
/*  405 */           isDeployed = false;
/*      */         } 
/*      */         
/*  408 */         args = new Object[7];
/*  409 */         args[0] = "<a href=\"" + URLEncoder.DEFAULT
/*  410 */           .encode(contextPath + "/", StandardCharsets.UTF_8) + "\" rel=\"noopener noreferrer\">" + 
/*  411 */           Escape.htmlElementContent(displayPath) + "</a>";
/*  412 */         if (webappVersion == null || webappVersion.isEmpty()) {
/*  413 */           args[1] = noVersion;
/*      */         } else {
/*  415 */           args[1] = Escape.htmlElementContent(webappVersion);
/*      */         } 
/*  417 */         if (ctxt.getDisplayName() == null) {
/*  418 */           args[2] = "&nbsp;";
/*      */         } else {
/*  420 */           args[2] = Escape.htmlElementContent(ctxt.getDisplayName());
/*      */         } 
/*  422 */         args[3] = Boolean.valueOf(ctxt.getState().isAvailable());
/*  423 */         args[4] = Escape.htmlElementContent(response
/*  424 */             .encodeURL(getServletContext().getContextPath() + "/html/sessions?" + getServletContext().getContextPath()));
/*  425 */         Manager manager = ctxt.getManager();
/*  426 */         if (manager instanceof DistributedManager && this.showProxySessions) {
/*  427 */           args[5] = Integer.valueOf(((DistributedManager)manager).getActiveSessionsFull());
/*  428 */         } else if (manager != null) {
/*  429 */           args[5] = Integer.valueOf(manager.getActiveSessions());
/*      */         } else {
/*  431 */           args[5] = Integer.valueOf(0);
/*      */         } 
/*      */         
/*  434 */         args[6] = highlightColor;
/*      */         
/*  436 */         writer.print(MessageFormat.format("<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n", args));
/*      */         
/*  438 */         args = new Object[14];
/*  439 */         args[0] = Escape.htmlElementContent(response
/*  440 */             .encodeURL(request.getContextPath() + "/html/start?" + request.getContextPath()));
/*  441 */         args[1] = appsStart;
/*  442 */         args[2] = 
/*  443 */           Escape.htmlElementContent(response.encodeURL(request.getContextPath() + "/html/stop?" + request.getContextPath()));
/*  444 */         args[3] = appsStop;
/*  445 */         args[4] = Escape.htmlElementContent(response
/*  446 */             .encodeURL(request.getContextPath() + "/html/reload?" + request.getContextPath()));
/*  447 */         args[5] = appsReload;
/*  448 */         args[6] = Escape.htmlElementContent(response
/*  449 */             .encodeURL(request.getContextPath() + "/html/undeploy?" + request.getContextPath()));
/*  450 */         args[7] = appsUndeploy;
/*  451 */         args[8] = Escape.htmlElementContent(response
/*  452 */             .encodeURL(request.getContextPath() + "/html/expire?" + request.getContextPath()));
/*  453 */         args[9] = appsExpire;
/*  454 */         args[10] = smClient.getString("htmlManagerServlet.expire.explain");
/*  455 */         if (manager == null) {
/*  456 */           args[11] = smClient.getString("htmlManagerServlet.noManager");
/*      */         } else {
/*  458 */           args[11] = Integer.valueOf(ctxt.getSessionTimeout());
/*      */         } 
/*  460 */         args[12] = smClient.getString("htmlManagerServlet.expire.unit");
/*  461 */         args[13] = highlightColor;
/*      */         
/*  463 */         if (ctxt.getName().equals(this.context.getName())) {
/*  464 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*  465 */         } else if (ctxt.getState().isAvailable() && isDeployed) {
/*  466 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  &nbsp;&nbsp;<small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*  467 */         } else if (ctxt.getState().isAvailable() && !isDeployed) {
/*  468 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*  469 */         } else if (!ctxt.getState().isAvailable() && isDeployed) {
/*  470 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         } else {
/*  472 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  479 */     args = new Object[8];
/*  480 */     args[0] = smClient.getString("htmlManagerServlet.deployTitle");
/*  481 */     args[1] = smClient.getString("htmlManagerServlet.deployServer");
/*  482 */     args[2] = response.encodeURL(getServletContext().getContextPath() + "/html/deploy");
/*  483 */     args[3] = smClient.getString("htmlManagerServlet.deployPath");
/*  484 */     args[4] = smClient.getString("htmlManagerServlet.deployVersion");
/*  485 */     args[5] = smClient.getString("htmlManagerServlet.deployConfig");
/*  486 */     args[6] = smClient.getString("htmlManagerServlet.deployWar");
/*  487 */     args[7] = smClient.getString("htmlManagerServlet.deployButton");
/*  488 */     writer.print(MessageFormat.format("</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployVersion\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{6}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n", args));
/*      */     
/*  490 */     args = new Object[4];
/*  491 */     args[0] = smClient.getString("htmlManagerServlet.deployUpload");
/*  492 */     args[1] = response.encodeURL(getServletContext().getContextPath() + "/html/upload");
/*  493 */     args[2] = smClient.getString("htmlManagerServlet.deployUploadFile");
/*  494 */     args[3] = smClient.getString("htmlManagerServlet.deployButton");
/*  495 */     writer.print(MessageFormat.format("<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n", args));
/*      */ 
/*      */     
/*  498 */     args = new Object[5];
/*  499 */     args[0] = smClient.getString("htmlManagerServlet.configTitle");
/*  500 */     args[1] = smClient.getString("htmlManagerServlet.configSslReloadTitle");
/*  501 */     args[2] = response.encodeURL(getServletContext().getContextPath() + "/html/sslReload");
/*  502 */     args[3] = smClient.getString("htmlManagerServlet.configSslHostName");
/*  503 */     args[4] = smClient.getString("htmlManagerServlet.configReloadButton");
/*  504 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"tlsHostName\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>", args));
/*      */ 
/*      */     
/*  507 */     args = new Object[15];
/*  508 */     args[0] = smClient.getString("htmlManagerServlet.diagnosticsTitle");
/*  509 */     args[1] = smClient.getString("htmlManagerServlet.diagnosticsLeak");
/*  510 */     args[2] = response.encodeURL(getServletContext().getContextPath() + "/html/findleaks");
/*  511 */     args[3] = smClient.getString("htmlManagerServlet.diagnosticsLeakWarning");
/*  512 */     args[4] = smClient.getString("htmlManagerServlet.diagnosticsLeakButton");
/*  513 */     args[5] = smClient.getString("htmlManagerServlet.diagnosticsSsl");
/*  514 */     args[6] = response.encodeURL(getServletContext().getContextPath() + "/html/sslConnectorCiphers");
/*  515 */     args[7] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherButton");
/*  516 */     args[8] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherText");
/*  517 */     args[9] = response.encodeURL(getServletContext().getContextPath() + "/html/sslConnectorCerts");
/*  518 */     args[10] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCertsButton");
/*  519 */     args[11] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCertsText");
/*  520 */     args[12] = response.encodeURL(getServletContext().getContextPath() + "/html/sslConnectorTrustedCerts");
/*  521 */     args[13] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorTrustedCertsButton");
/*  522 */     args[14] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorTrustedCertsText");
/*  523 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{2}\">\n   <input type=\"submit\" value=\"{4}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{6}\">\n   <input type=\"submit\" value=\"{7}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{9}\">\n   <input type=\"submit\" value=\"{10}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{11}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{12}\">\n   <input type=\"submit\" value=\"{13}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{14}</small>\n </td>\n</tr>\n</table>\n<br>", args));
/*      */ 
/*      */     
/*  526 */     args = new Object[9];
/*  527 */     args[0] = smClient.getString("htmlManagerServlet.serverTitle");
/*  528 */     args[1] = smClient.getString("htmlManagerServlet.serverVersion");
/*  529 */     args[2] = smClient.getString("htmlManagerServlet.serverJVMVersion");
/*  530 */     args[3] = smClient.getString("htmlManagerServlet.serverJVMVendor");
/*  531 */     args[4] = smClient.getString("htmlManagerServlet.serverOSName");
/*  532 */     args[5] = smClient.getString("htmlManagerServlet.serverOSVersion");
/*  533 */     args[6] = smClient.getString("htmlManagerServlet.serverOSArch");
/*  534 */     args[7] = smClient.getString("htmlManagerServlet.serverHostname");
/*  535 */     args[8] = smClient.getString("htmlManagerServlet.serverIPAddress");
/*  536 */     writer.print(MessageFormat.format(Constants.SERVER_HEADER_SECTION, args));
/*      */ 
/*      */     
/*  539 */     args = new Object[8];
/*  540 */     args[0] = ServerInfo.getServerInfo();
/*  541 */     args[1] = System.getProperty("java.runtime.version");
/*  542 */     args[2] = System.getProperty("java.vm.vendor");
/*  543 */     args[3] = System.getProperty("os.name");
/*  544 */     args[4] = System.getProperty("os.version");
/*  545 */     args[5] = System.getProperty("os.arch");
/*      */     try {
/*  547 */       InetAddress address = InetAddress.getLocalHost();
/*  548 */       args[6] = address.getHostName();
/*  549 */       args[7] = address.getHostAddress();
/*  550 */     } catch (UnknownHostException e) {
/*  551 */       args[6] = "-";
/*  552 */       args[7] = "-";
/*      */     } 
/*  554 */     writer.print(MessageFormat.format(Constants.SERVER_ROW_SECTION, args));
/*      */ 
/*      */     
/*  557 */     writer.print(Constants.HTML_TAIL_SECTION);
/*      */ 
/*      */     
/*  560 */     writer.flush();
/*  561 */     writer.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String reload(ContextName cn, StringManager smClient) {
/*  576 */     StringWriter stringWriter = new StringWriter();
/*  577 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  579 */     reload(printWriter, cn, smClient);
/*      */     
/*  581 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String undeploy(ContextName cn, StringManager smClient) {
/*  596 */     StringWriter stringWriter = new StringWriter();
/*  597 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  599 */     undeploy(printWriter, cn, smClient);
/*      */     
/*  601 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String sessions(ContextName cn, int idle, StringManager smClient) {
/*  617 */     StringWriter stringWriter = new StringWriter();
/*  618 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  620 */     sessions(printWriter, cn, idle, smClient);
/*      */     
/*  622 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String start(ContextName cn, StringManager smClient) {
/*  637 */     StringWriter stringWriter = new StringWriter();
/*  638 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  640 */     start(printWriter, cn, smClient);
/*      */     
/*  642 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String stop(ContextName cn, StringManager smClient) {
/*  657 */     StringWriter stringWriter = new StringWriter();
/*  658 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  660 */     stop(printWriter, cn, smClient);
/*      */     
/*  662 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String findleaks(StringManager smClient) {
/*  676 */     StringBuilder msg = new StringBuilder();
/*      */     
/*  678 */     StringWriter stringWriter = new StringWriter();
/*  679 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  681 */     findleaks(false, printWriter, smClient);
/*      */     
/*  683 */     String writerText = stringWriter.toString();
/*      */     
/*  685 */     if (!writerText.isEmpty()) {
/*  686 */       if (!writerText.startsWith("FAIL -")) {
/*  687 */         msg.append(smClient.getString("htmlManagerServlet.findleaksList"));
/*      */       }
/*  689 */       msg.append(writerText);
/*      */     } else {
/*  691 */       msg.append(smClient.getString("htmlManagerServlet.findleaksNone"));
/*      */     } 
/*      */     
/*  694 */     return msg.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected String sslReload(String tlsHostName, StringManager smClient) {
/*  699 */     StringWriter stringWriter = new StringWriter();
/*  700 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  702 */     sslReload(printWriter, tlsHostName, smClient);
/*      */     
/*  704 */     return stringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sslConnectorCiphers(HttpServletRequest request, HttpServletResponse response, StringManager smClient) throws ServletException, IOException {
/*  710 */     request.setAttribute("cipherList", getConnectorCiphers(smClient));
/*  711 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorCiphers.jsp").forward((ServletRequest)request, (ServletResponse)response);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sslConnectorCerts(HttpServletRequest request, HttpServletResponse response, StringManager smClient) throws ServletException, IOException {
/*  717 */     request.setAttribute("certList", getConnectorCerts(smClient));
/*  718 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorCerts.jsp").forward((ServletRequest)request, (ServletResponse)response);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sslConnectorTrustedCerts(HttpServletRequest request, HttpServletResponse response, StringManager smClient) throws ServletException, IOException {
/*  724 */     request.setAttribute("trustedCertList", getConnectorTrustedCerts(smClient));
/*  725 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorTrustedCerts.jsp").forward((ServletRequest)request, (ServletResponse)response);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServletInfo() {
/*  731 */     return "HTMLManagerServlet, Copyright (c) 1999-2025, The Apache Software Foundation";
/*      */   }
/*      */ 
/*      */   
/*      */   public void init() throws ServletException {
/*  736 */     super.init();
/*      */ 
/*      */     
/*  739 */     String value = getServletConfig().getInitParameter("showProxySessions");
/*  740 */     this.showProxySessions = Boolean.parseBoolean(value);
/*      */     
/*  742 */     this.htmlSubTitle = getServletConfig().getInitParameter("htmlSubTitle");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String expireSessions(ContextName cn, HttpServletRequest req, StringManager smClient) {
/*  757 */     int idle = -1;
/*  758 */     String idleParam = req.getParameter("idle");
/*  759 */     if (idleParam != null) {
/*      */       try {
/*  761 */         idle = Integer.parseInt(idleParam);
/*  762 */       } catch (NumberFormatException e) {
/*  763 */         log(sm.getString("managerServlet.error.idleParam", new Object[] { idleParam }));
/*      */       } 
/*      */     }
/*  766 */     return sessions(cn, idle, smClient);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSessions(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient) throws ServletException, IOException {
/*  782 */     req.setAttribute("path", cn.getPath());
/*  783 */     req.setAttribute("version", cn.getVersion());
/*  784 */     String action = req.getParameter("action");
/*  785 */     if (this.debug >= 1) {
/*  786 */       log("sessions: Session action '" + action + "' for web application '" + cn.getDisplayName() + "'");
/*      */     }
/*  788 */     if ("sessionDetail".equals(action)) {
/*  789 */       String sessionId = req.getParameter("sessionId");
/*  790 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient); return;
/*      */     } 
/*  792 */     if ("invalidateSessions".equals(action)) {
/*  793 */       String[] sessionIds = req.getParameterValues("sessionIds");
/*  794 */       int i = invalidateSessions(cn, sessionIds, smClient);
/*  795 */       req.setAttribute("message", Integer.toString(i) + " sessions invalidated.");
/*  796 */     } else if ("removeSessionAttribute".equals(action)) {
/*  797 */       String sessionId = req.getParameter("sessionId");
/*  798 */       String name = req.getParameter("attributeName");
/*  799 */       boolean removed = removeSessionAttribute(cn, sessionId, name, smClient);
/*      */       
/*  801 */       String outMessage = removed ? ("Session attribute '" + name + "' removed.") : ("Session did not contain any attribute named '" + name + "'");
/*  802 */       req.setAttribute("message", outMessage);
/*  803 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient);
/*      */       return;
/*      */     } 
/*  806 */     displaySessionsListPage(cn, req, resp, smClient);
/*      */   }
/*      */   
/*      */   protected List<Session> getSessionsForName(ContextName cn, StringManager smClient) {
/*  810 */     if (cn == null || (!cn.getPath().startsWith("/") && !cn.getPath().isEmpty())) {
/*  811 */       String path = null;
/*  812 */       if (cn != null) {
/*  813 */         path = cn.getPath();
/*      */       }
/*  815 */       throw new IllegalArgumentException(smClient
/*  816 */           .getString("managerServlet.invalidPath", new Object[] { Escape.htmlElementContent(path) }));
/*      */     } 
/*      */     
/*  819 */     Context ctxt = (Context)this.host.findChild(cn.getName());
/*  820 */     if (null == ctxt) {
/*  821 */       throw new IllegalArgumentException(smClient
/*  822 */           .getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(cn.getDisplayName()) }));
/*      */     }
/*  824 */     Manager manager = ctxt.getManager();
/*  825 */     List<Session> sessions = new ArrayList<>(Arrays.asList(manager.findSessions()));
/*  826 */     if (manager instanceof DistributedManager && this.showProxySessions) {
/*      */       
/*  828 */       Set<String> sessionIds = ((DistributedManager)manager).getSessionIdsFull();
/*      */       
/*  830 */       for (Session session : sessions) {
/*  831 */         sessionIds.remove(session.getId());
/*      */       }
/*      */       
/*  834 */       for (String sessionId : sessionIds) {
/*  835 */         sessions.add(new DummyProxySession(sessionId));
/*      */       }
/*      */     } 
/*  838 */     return sessions;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Session getSessionForNameAndId(ContextName cn, String id, StringManager smClient) {
/*  843 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  844 */     if (sessions.isEmpty()) {
/*  845 */       return null;
/*      */     }
/*  847 */     for (Session session : sessions) {
/*  848 */       if (session.getId().equals(id)) {
/*  849 */         return session;
/*      */       }
/*      */     } 
/*  852 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void displaySessionsListPage(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient) throws ServletException, IOException {
/*  868 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  869 */     String sortBy = req.getParameter("sort");
/*  870 */     String orderBy = null;
/*  871 */     if (null != sortBy && !sortBy.trim().isEmpty()) {
/*  872 */       Comparator<Session> comparator = getComparator(sortBy);
/*  873 */       if (comparator != null) {
/*  874 */         orderBy = req.getParameter("order");
/*  875 */         if ("DESC".equalsIgnoreCase(orderBy)) {
/*  876 */           comparator = Collections.reverseOrder(comparator);
/*  877 */           orderBy = "ASC";
/*      */         } else {
/*  879 */           orderBy = "DESC";
/*      */         } 
/*      */         try {
/*  882 */           sessions.sort(comparator);
/*  883 */         } catch (IllegalStateException ise) {
/*      */           
/*  885 */           req.setAttribute("error", "Can't sort session list: one session is invalidated");
/*      */         } 
/*      */       } else {
/*  888 */         log(sm.getString("htmlManagerServlet.error.sortOrder", new Object[] { sortBy }));
/*      */       } 
/*      */     } 
/*      */     
/*  892 */     req.setAttribute("sort", sortBy);
/*  893 */     req.setAttribute("order", orderBy);
/*  894 */     req.setAttribute("activeSessions", sessions);
/*      */ 
/*      */ 
/*      */     
/*  898 */     resp.setHeader("Pragma", "No-cache");
/*  899 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/*  900 */     resp.setDateHeader("Expires", 0L);
/*  901 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/sessionsList.jsp").include((ServletRequest)req, (ServletResponse)resp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void displaySessionDetailPage(HttpServletRequest req, HttpServletResponse resp, ContextName cn, String sessionId, StringManager smClient) throws ServletException, IOException {
/*  918 */     Session session = getSessionForNameAndId(cn, sessionId, smClient);
/*      */ 
/*      */ 
/*      */     
/*  922 */     resp.setHeader("Pragma", "No-cache");
/*  923 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/*  924 */     resp.setDateHeader("Expires", 0L);
/*  925 */     req.setAttribute("currentSession", session);
/*  926 */     getServletContext().getRequestDispatcher(resp.encodeURL("/WEB-INF/jsp/sessionDetail.jsp")).include((ServletRequest)req, (ServletResponse)resp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int invalidateSessions(ContextName cn, String[] sessionIds, StringManager smClient) {
/*  939 */     if (null == sessionIds) {
/*  940 */       return 0;
/*      */     }
/*  942 */     int nbAffectedSessions = 0;
/*  943 */     for (String sessionId : sessionIds) {
/*  944 */       Session session = getSessionForNameAndId(cn, sessionId, smClient);
/*  945 */       if (null == session) {
/*      */         
/*  947 */         if (this.debug >= 1) {
/*  948 */           log("Cannot invalidate null session " + sessionId);
/*      */         }
/*      */       } else {
/*      */         
/*      */         try {
/*  953 */           session.getSession().invalidate();
/*  954 */           nbAffectedSessions++;
/*  955 */           if (this.debug >= 1) {
/*  956 */             log("Invalidating session id " + sessionId);
/*      */           }
/*  958 */         } catch (IllegalStateException ise) {
/*  959 */           if (this.debug >= 1)
/*  960 */             log("Cannot invalidate already invalidated session id " + sessionId); 
/*      */         } 
/*      */       } 
/*      */     } 
/*  964 */     return nbAffectedSessions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean removeSessionAttribute(ContextName cn, String sessionId, String attributeName, StringManager smClient) {
/*  979 */     Session session = getSessionForNameAndId(cn, sessionId, smClient);
/*  980 */     if (null == session) {
/*      */       
/*  982 */       if (this.debug >= 1) {
/*  983 */         log("Cannot remove attribute '" + attributeName + "' for null session " + sessionId);
/*      */       }
/*  985 */       return false;
/*      */     } 
/*  987 */     HttpSession httpSession = session.getSession();
/*  988 */     boolean wasPresent = (null != httpSession.getAttribute(attributeName));
/*      */     try {
/*  990 */       httpSession.removeAttribute(attributeName);
/*  991 */     } catch (IllegalStateException ise) {
/*  992 */       if (this.debug >= 1) {
/*  993 */         log("Cannot remote attribute '" + attributeName + "' for invalidated session id " + sessionId);
/*      */       }
/*      */     } 
/*  996 */     return wasPresent;
/*      */   }
/*      */   
/*      */   protected Comparator<Session> getComparator(String sortBy) {
/* 1000 */     if ("CreationTime".equalsIgnoreCase(sortBy))
/* 1001 */       return Comparator.comparingLong(Session::getCreationTime); 
/* 1002 */     if ("id".equalsIgnoreCase(sortBy))
/* 1003 */       return comparingNullable(Session::getId); 
/* 1004 */     if ("LastAccessedTime".equalsIgnoreCase(sortBy))
/* 1005 */       return Comparator.comparingLong(Session::getLastAccessedTime); 
/* 1006 */     if ("MaxInactiveInterval".equalsIgnoreCase(sortBy))
/* 1007 */       return Comparator.comparingInt(Session::getMaxInactiveInterval); 
/* 1008 */     if ("new".equalsIgnoreCase(sortBy))
/* 1009 */       return Comparator.comparing(s -> Boolean.valueOf(s.getSession().isNew())); 
/* 1010 */     if ("locale".equalsIgnoreCase(sortBy))
/* 1011 */       return Comparator.comparing(JspHelper::guessDisplayLocaleFromSession); 
/* 1012 */     if ("user".equalsIgnoreCase(sortBy))
/* 1013 */       return comparingNullable(JspHelper::guessDisplayUserFromSession); 
/* 1014 */     if ("UsedTime".equalsIgnoreCase(sortBy))
/* 1015 */       return Comparator.comparingLong(SessionUtils::getUsedTimeForSession); 
/* 1016 */     if ("InactiveTime".equalsIgnoreCase(sortBy))
/* 1017 */       return Comparator.comparingLong(SessionUtils::getInactiveTimeForSession); 
/* 1018 */     if ("TTL".equalsIgnoreCase(sortBy)) {
/* 1019 */       return Comparator.comparingLong(SessionUtils::getTTLForSession);
/*      */     }
/* 1021 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <U extends Comparable<? super U>> Comparator<Session> comparingNullable(Function<Session, ? extends U> keyExtractor) {
/* 1032 */     return (s1, s2) -> {
/*      */         Comparable<Comparable> comparable = keyExtractor.apply(s1);
/*      */         Comparable comparable1 = keyExtractor.apply(s2);
/*      */         return (comparable == null) ? ((comparable1 == null) ? 0 : -1) : ((comparable1 == null) ? 1 : comparable.compareTo(comparable1));
/*      */       };
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\HTMLManagerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */