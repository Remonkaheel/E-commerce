/*     */ package org.apache.catalina.manager.util;
/*     */ 
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionUtils
/*     */ {
/*     */   private static final String STRUTS_LOCALE_KEY = "org.apache.struts.action.LOCALE";
/*     */   private static final String JSTL_LOCALE_KEY = "jakarta.servlet.jsp.jstl.fmt.locale";
/*     */   private static final String SPRING_LOCALE_KEY = "org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE";
/*  54 */   private static final String[] LOCALE_TEST_ATTRIBUTES = new String[] { "org.apache.struts.action.LOCALE", "org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE", "jakarta.servlet.jsp.jstl.fmt.locale", "Locale", "java.util.Locale" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static final String[] USER_TEST_ATTRIBUTES = new String[] { "Login", "User", "userName", "UserName", "Utilisateur", "SPRING_SECURITY_LAST_USERNAME" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale guessLocaleFromSession(Session in_session) {
/*  73 */     return guessLocaleFromSession(in_session.getSession());
/*     */   }
/*     */   
/*     */   public static Locale guessLocaleFromSession(HttpSession in_session) {
/*  77 */     if (null == in_session) {
/*  78 */       return null;
/*     */     }
/*     */     try {
/*  81 */       Locale locale = null;
/*     */ 
/*     */       
/*  84 */       for (String localeTestAttribute : LOCALE_TEST_ATTRIBUTES) {
/*  85 */         Object obj = in_session.getAttribute(localeTestAttribute);
/*  86 */         if (obj instanceof Locale) {
/*  87 */           locale = (Locale)obj;
/*     */           break;
/*     */         } 
/*  90 */         obj = in_session.getAttribute(localeTestAttribute.toLowerCase(Locale.ENGLISH));
/*  91 */         if (obj instanceof Locale) {
/*  92 */           locale = (Locale)obj;
/*     */           break;
/*     */         } 
/*  95 */         obj = in_session.getAttribute(localeTestAttribute.toUpperCase(Locale.ENGLISH));
/*  96 */         if (obj instanceof Locale) {
/*  97 */           locale = (Locale)obj;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 102 */       if (null != locale) {
/* 103 */         return locale;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 108 */       List<Object> tapestryArray = new ArrayList();
/* 109 */       for (Enumeration<String> enumeration = in_session.getAttributeNames(); enumeration.hasMoreElements(); ) {
/* 110 */         String name = enumeration.nextElement();
/* 111 */         if (name.contains("tapestry") && name.contains("engine") && null != in_session.getAttribute(name)) {
/* 112 */           tapestryArray.add(in_session.getAttribute(name));
/*     */         }
/*     */       } 
/* 115 */       if (tapestryArray.size() == 1) {
/*     */         
/* 117 */         Object probableEngine = tapestryArray.get(0);
/* 118 */         if (null != probableEngine) {
/*     */           try {
/* 120 */             Method readMethod = probableEngine.getClass().getMethod("getLocale", (Class[])null);
/*     */             
/* 122 */             Object possibleLocale = readMethod.invoke(probableEngine, (Object[])null);
/* 123 */             if (possibleLocale instanceof Locale) {
/* 124 */               locale = (Locale)possibleLocale;
/*     */             }
/* 126 */           } catch (Exception e) {
/* 127 */             Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 128 */             ExceptionUtils.handleThrowable(t);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 134 */       if (null != locale) {
/* 135 */         return locale;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 140 */       List<Object> localeArray = new ArrayList();
/* 141 */       for (Enumeration<String> enumeration1 = in_session.getAttributeNames(); enumeration1.hasMoreElements(); ) {
/* 142 */         String name = enumeration1.nextElement();
/* 143 */         Object obj = in_session.getAttribute(name);
/* 144 */         if (obj instanceof Locale) {
/* 145 */           localeArray.add(obj);
/*     */         }
/*     */       } 
/* 148 */       if (localeArray.size() == 1) {
/* 149 */         locale = (Locale)localeArray.get(0);
/*     */       }
/*     */       
/* 152 */       return locale;
/* 153 */     } catch (IllegalStateException ise) {
/*     */       
/* 155 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object guessUserFromSession(Session in_session) {
/* 167 */     if (null == in_session) {
/* 168 */       return null;
/*     */     }
/* 170 */     if (in_session.getPrincipal() != null) {
/* 171 */       return in_session.getPrincipal().getName();
/*     */     }
/* 173 */     HttpSession httpSession = in_session.getSession();
/* 174 */     if (httpSession == null) {
/* 175 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 179 */       Object user = null;
/*     */       
/* 181 */       for (String userTestAttribute : USER_TEST_ATTRIBUTES) {
/* 182 */         Object obj = httpSession.getAttribute(userTestAttribute);
/* 183 */         if (null != obj) {
/* 184 */           user = obj;
/*     */           break;
/*     */         } 
/* 187 */         obj = httpSession.getAttribute(userTestAttribute.toLowerCase(Locale.ENGLISH));
/* 188 */         if (null != obj) {
/* 189 */           user = obj;
/*     */           break;
/*     */         } 
/* 192 */         obj = httpSession.getAttribute(userTestAttribute.toUpperCase(Locale.ENGLISH));
/* 193 */         if (null != obj) {
/* 194 */           user = obj;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 199 */       if (null != user) {
/* 200 */         return user;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 205 */       List<Object> principalArray = new ArrayList();
/* 206 */       for (Enumeration<String> enumeration = httpSession.getAttributeNames(); enumeration.hasMoreElements(); ) {
/* 207 */         String name = enumeration.nextElement();
/* 208 */         Object obj = httpSession.getAttribute(name);
/* 209 */         if (obj instanceof java.security.Principal || obj instanceof javax.security.auth.Subject) {
/* 210 */           principalArray.add(obj);
/*     */         }
/*     */       } 
/* 213 */       if (principalArray.size() == 1) {
/* 214 */         user = principalArray.get(0);
/*     */       }
/*     */       
/* 217 */       return user;
/* 218 */     } catch (IllegalStateException ise) {
/*     */       
/* 220 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static long getUsedTimeForSession(Session in_session) {
/*     */     try {
/* 227 */       return in_session.getThisAccessedTime() - in_session.getCreationTime();
/* 228 */     } catch (IllegalStateException ise) {
/*     */       
/* 230 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long getTTLForSession(Session in_session) {
/*     */     try {
/* 236 */       return 1000L * in_session.getMaxInactiveInterval() - 
/* 237 */         System.currentTimeMillis() - in_session.getThisAccessedTime();
/* 238 */     } catch (IllegalStateException ise) {
/*     */       
/* 240 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long getInactiveTimeForSession(Session in_session) {
/*     */     try {
/* 246 */       return System.currentTimeMillis() - in_session.getThisAccessedTime();
/* 247 */     } catch (IllegalStateException ise) {
/*     */       
/* 249 */       return -1L;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manage\\util\SessionUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */