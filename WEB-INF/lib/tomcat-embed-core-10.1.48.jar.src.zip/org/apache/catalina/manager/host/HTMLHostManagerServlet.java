/*     */ package org.apache.catalina.manager.host;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.manager.Constants;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLHostManagerServlet
/*     */   extends HostManagerServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String HOSTS_HEADER_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"5\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{0}</small></td>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n</tr>\n";
/*     */   private static final String HOSTS_ROW_DETAILS_SECTION = "<tr>\n <td class=\"row-left\"><small><a href=\"http://{0}\" rel=\"noopener noreferrer\">{0}</a></small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n";
/*     */   private static final String MANAGER_HOST_ROW_BUTTON_SECTION = " <td class=\"row-left\">\n  <small>{4}</small>\n </td>\n</tr>\n";
/*     */   private static final String HOSTS_ROW_BUTTON_SECTION = " <td class=\"row-left\" NOWRAP>\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">   <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">   <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_START = "</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"name\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"aliases\" size=\"64\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"appBase\" size=\"64\">\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_BOOLEAN = "<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_END = "<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{0}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n";
/*     */   private static final String PERSIST_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form class=\"inline\" method=\"POST\" action=\"{1}\">   <small><input type=\"submit\" value=\"{2}\"></small>  </form> {3}\n </td>\n</tr>\n</table>\n<br>\n\n";
/*     */   
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*  63 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request.getLocales());
/*     */ 
/*     */     
/*  66 */     String command = request.getPathInfo();
/*     */ 
/*     */     
/*  69 */     response.setContentType("text/html; charset=utf-8");
/*     */     
/*  71 */     String message = "";
/*     */     
/*  73 */     if (command != null)
/*     */     {
/*  75 */       if (!command.equals("/list"))
/*     */       {
/*  77 */         if (command.equals("/add") || command.equals("/remove") || command.equals("/start") || command
/*  78 */           .equals("/stop") || command.equals("/persist")) {
/*  79 */           message = smClient.getString("hostManagerServlet.postCommand", new Object[] { command });
/*     */         } else {
/*  81 */           message = smClient.getString("hostManagerServlet.unknownCommand", new Object[] { command });
/*     */         }  } 
/*     */     }
/*  84 */     list(request, response, message, smClient);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/*  91 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request.getLocales());
/*     */ 
/*     */     
/*  94 */     String command = request.getPathInfo();
/*     */     
/*  96 */     String name = request.getParameter("name");
/*     */ 
/*     */     
/*  99 */     response.setContentType("text/html; charset=utf-8");
/*     */     
/* 101 */     String message = "";
/*     */ 
/*     */     
/* 104 */     if (command != null)
/*     */     {
/* 106 */       if (command.equals("/add")) {
/* 107 */         message = add(request, name, smClient);
/* 108 */       } else if (command.equals("/remove")) {
/* 109 */         message = remove(name, smClient);
/* 110 */       } else if (command.equals("/start")) {
/* 111 */         message = start(name, smClient);
/* 112 */       } else if (command.equals("/stop")) {
/* 113 */         message = stop(name, smClient);
/* 114 */       } else if (command.equals("/persist")) {
/* 115 */         message = persist(smClient);
/*     */       } else {
/*     */         
/* 118 */         doGet(request, response);
/*     */       } 
/*     */     }
/* 121 */     list(request, response, message, smClient);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String add(HttpServletRequest request, String name, StringManager smClient) {
/* 136 */     StringWriter stringWriter = new StringWriter();
/* 137 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 139 */     add(request, printWriter, name, true, smClient);
/*     */     
/* 141 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String remove(String name, StringManager smClient) {
/* 155 */     StringWriter stringWriter = new StringWriter();
/* 156 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 158 */     remove(printWriter, name, smClient);
/*     */     
/* 160 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String start(String name, StringManager smClient) {
/* 174 */     StringWriter stringWriter = new StringWriter();
/* 175 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 177 */     start(printWriter, name, smClient);
/*     */     
/* 179 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String stop(String name, StringManager smClient) {
/* 193 */     StringWriter stringWriter = new StringWriter();
/* 194 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 196 */     stop(printWriter, name, smClient);
/*     */     
/* 198 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String persist(StringManager smClient) {
/* 211 */     StringWriter stringWriter = new StringWriter();
/* 212 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 214 */     persist(printWriter, smClient);
/*     */     
/* 216 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void list(HttpServletRequest request, HttpServletResponse response, String message, StringManager smClient) throws IOException {
/* 234 */     if (this.debug >= 1) {
/* 235 */       log(sm.getString("hostManagerServlet.list", new Object[] { this.engine.getName() }));
/*     */     }
/*     */     
/* 238 */     PrintWriter writer = response.getWriter();
/*     */     
/* 240 */     Object[] args = new Object[2];
/* 241 */     args[0] = getServletContext().getContextPath();
/* 242 */     args[1] = smClient.getString("htmlHostManagerServlet.title");
/*     */ 
/*     */     
/* 245 */     writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*     */ 
/*     */     
/* 248 */     writer.print(MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*     */ 
/*     */     
/* 251 */     args = new Object[3];
/* 252 */     args[0] = smClient.getString("htmlHostManagerServlet.messageLabel");
/* 253 */     if (message == null || message.isEmpty()) {
/* 254 */       args[1] = "OK";
/*     */     } else {
/* 256 */       args[1] = Escape.htmlElementContent(message);
/*     */     } 
/* 258 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n <tr>\n  <td class=\"row-left\" width=\"10%\"><small><strong>{0}</strong></small>&nbsp;</td>\n  <td class=\"row-left\"><pre>{1}</pre></td>\n </tr>\n</table>\n<br>\n\n", args));
/*     */ 
/*     */     
/* 261 */     args = new Object[9];
/* 262 */     args[0] = smClient.getString("htmlHostManagerServlet.manager");
/* 263 */     args[1] = response.encodeURL(getServletContext().getContextPath() + "/html/list");
/* 264 */     args[2] = smClient.getString("htmlHostManagerServlet.list");
/* 265 */     args[3] = 
/* 266 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/*     */     
/* 268 */     args[4] = smClient.getString("htmlHostManagerServlet.helpHtmlManager");
/* 269 */     args[5] = 
/* 270 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/*     */     
/* 272 */     args[6] = smClient.getString("htmlHostManagerServlet.helpManager");
/* 273 */     args[7] = response.encodeURL("/manager/status");
/* 274 */     args[8] = smClient.getString("statusServlet.title");
/* 275 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"4\" class=\"title\">{0}</td>\n</tr>\n <tr>\n  <td class=\"row-left\"><a href=\"{1}\">{2}</a></td>\n  <td class=\"row-center\"><a href=\"{3}\" rel=\"noopener noreferrer\">{4}</a></td>\n  <td class=\"row-center\"><a href=\"{5}\" rel=\"noopener noreferrer\">{6}</a></td>\n  <td class=\"row-right\"><a href=\"{7}\">{8}</a></td>\n </tr>\n</table>\n<br>\n\n", args));
/*     */ 
/*     */     
/* 278 */     args = new Object[3];
/* 279 */     args[0] = smClient.getString("htmlHostManagerServlet.hostName");
/* 280 */     args[1] = smClient.getString("htmlHostManagerServlet.hostAliases");
/* 281 */     args[2] = smClient.getString("htmlHostManagerServlet.hostTasks");
/* 282 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"5\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{0}</small></td>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n</tr>\n", args));
/*     */ 
/*     */ 
/*     */     
/* 286 */     Container[] children = this.engine.findChildren();
/* 287 */     String[] hostNames = new String[children.length];
/* 288 */     for (int i = 0; i < children.length; i++) {
/* 289 */       hostNames[i] = children[i].getName();
/*     */     }
/*     */     
/* 292 */     SortedSet<String> sortedHostNames = new TreeSet<>(Arrays.asList(hostNames));
/*     */     
/* 294 */     String hostsStart = smClient.getString("htmlHostManagerServlet.hostsStart");
/* 295 */     String hostsStop = smClient.getString("htmlHostManagerServlet.hostsStop");
/* 296 */     String hostsRemove = smClient.getString("htmlHostManagerServlet.hostsRemove");
/* 297 */     String hostThis = smClient.getString("htmlHostManagerServlet.hostThis");
/*     */     
/* 299 */     for (String hostName : sortedHostNames) {
/* 300 */       Host host = (Host)this.engine.findChild(hostName);
/*     */       
/* 302 */       if (host != null) {
/* 303 */         args = new Object[2];
/* 304 */         args[0] = 
/* 305 */           Escape.htmlElementContent(hostName);
/* 306 */         String[] aliases = host.findAliases();
/* 307 */         StringBuilder buf = new StringBuilder();
/* 308 */         if (aliases.length > 0) {
/* 309 */           buf.append(aliases[0]);
/* 310 */           for (int j = 1; j < aliases.length; j++) {
/* 311 */             buf.append(", ").append(aliases[j]);
/*     */           }
/*     */         } 
/*     */         
/* 315 */         if (buf.length() == 0) {
/* 316 */           buf.append("&nbsp;");
/* 317 */           args[1] = buf.toString();
/*     */         } else {
/* 319 */           args[1] = Escape.htmlElementContent(buf.toString());
/*     */         } 
/*     */         
/* 322 */         writer.print(MessageFormat.format("<tr>\n <td class=\"row-left\"><small><a href=\"http://{0}\" rel=\"noopener noreferrer\">{0}</a></small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n", args));
/*     */         
/* 324 */         args = new Object[5];
/* 325 */         if (host.getState().isAvailable()) {
/* 326 */           args[0] = response.encodeURL(getServletContext().getContextPath() + "/html/stop?name=" + getServletContext().getContextPath());
/*     */           
/* 328 */           args[1] = hostsStop;
/*     */         } else {
/* 330 */           args[0] = response.encodeURL(getServletContext().getContextPath() + "/html/start?name=" + getServletContext().getContextPath());
/*     */           
/* 332 */           args[1] = hostsStart;
/*     */         } 
/* 334 */         args[2] = response.encodeURL(getServletContext().getContextPath() + "/html/remove?name=" + getServletContext().getContextPath());
/*     */         
/* 336 */         args[3] = hostsRemove;
/* 337 */         args[4] = hostThis;
/* 338 */         if (host == this.installedHost) {
/* 339 */           writer.print(MessageFormat.format(" <td class=\"row-left\">\n  <small>{4}</small>\n </td>\n</tr>\n", args)); continue;
/*     */         } 
/* 341 */         writer.print(MessageFormat.format(" <td class=\"row-left\" NOWRAP>\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">   <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">   <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n </td>\n</tr>\n", args));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 347 */     args = new Object[6];
/* 348 */     args[0] = smClient.getString("htmlHostManagerServlet.addTitle");
/* 349 */     args[1] = smClient.getString("htmlHostManagerServlet.addHost");
/* 350 */     args[2] = response.encodeURL(getServletContext().getContextPath() + "/html/add");
/* 351 */     args[3] = smClient.getString("htmlHostManagerServlet.addName");
/* 352 */     args[4] = smClient.getString("htmlHostManagerServlet.addAliases");
/* 353 */     args[5] = smClient.getString("htmlHostManagerServlet.addAppBase");
/* 354 */     writer.print(MessageFormat.format("</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"name\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"aliases\" size=\"64\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"appBase\" size=\"64\">\n </td>\n</tr>\n", args));
/*     */     
/* 356 */     args = new Object[3];
/* 357 */     args[0] = smClient.getString("htmlHostManagerServlet.addAutoDeploy");
/* 358 */     args[1] = "autoDeploy";
/* 359 */     args[2] = "checked";
/* 360 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 361 */     args[0] = smClient.getString("htmlHostManagerServlet.addDeployOnStartup");
/* 362 */     args[1] = "deployOnStartup";
/* 363 */     args[2] = "checked";
/* 364 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 365 */     args[0] = smClient.getString("htmlHostManagerServlet.addDeployXML");
/* 366 */     args[1] = "deployXML";
/* 367 */     args[2] = "checked";
/* 368 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 369 */     args[0] = smClient.getString("htmlHostManagerServlet.addUnpackWARs");
/* 370 */     args[1] = "unpackWARs";
/* 371 */     args[2] = "checked";
/* 372 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 374 */     args[0] = smClient.getString("htmlHostManagerServlet.addManager");
/* 375 */     args[1] = "manager";
/* 376 */     args[2] = "checked";
/* 377 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 379 */     args[0] = smClient.getString("htmlHostManagerServlet.addCopyXML");
/* 380 */     args[1] = "copyXML";
/* 381 */     args[2] = "";
/* 382 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 384 */     args = new Object[1];
/* 385 */     args[0] = smClient.getString("htmlHostManagerServlet.addButton");
/* 386 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{0}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */ 
/*     */     
/* 389 */     args = new Object[4];
/* 390 */     args[0] = smClient.getString("htmlHostManagerServlet.persistTitle");
/* 391 */     args[1] = response.encodeURL(getServletContext().getContextPath() + "/html/persist");
/* 392 */     args[2] = smClient.getString("htmlHostManagerServlet.persistAllButton");
/* 393 */     args[3] = smClient.getString("htmlHostManagerServlet.persistAll");
/* 394 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form class=\"inline\" method=\"POST\" action=\"{1}\">   <small><input type=\"submit\" value=\"{2}\"></small>  </form> {3}\n </td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */ 
/*     */     
/* 397 */     args = new Object[7];
/* 398 */     args[0] = smClient.getString("htmlHostManagerServlet.serverTitle");
/* 399 */     args[1] = smClient.getString("htmlHostManagerServlet.serverVersion");
/* 400 */     args[2] = smClient.getString("htmlHostManagerServlet.serverJVMVersion");
/* 401 */     args[3] = smClient.getString("htmlHostManagerServlet.serverJVMVendor");
/* 402 */     args[4] = smClient.getString("htmlHostManagerServlet.serverOSName");
/* 403 */     args[5] = smClient.getString("htmlHostManagerServlet.serverOSVersion");
/* 404 */     args[6] = smClient.getString("htmlHostManagerServlet.serverOSArch");
/* 405 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-center\"><small>{5}</small></td>\n <td class=\"header-center\"><small>{6}</small></td>\n</tr>\n", args));
/*     */ 
/*     */     
/* 408 */     args = new Object[6];
/* 409 */     args[0] = ServerInfo.getServerInfo();
/* 410 */     args[1] = System.getProperty("java.runtime.version");
/* 411 */     args[2] = System.getProperty("java.vm.vendor");
/* 412 */     args[3] = System.getProperty("os.name");
/* 413 */     args[4] = System.getProperty("os.version");
/* 414 */     args[5] = System.getProperty("os.arch");
/* 415 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-center\"><small>{0}</small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n <td class=\"row-center\"><small>{2}</small></td>\n <td class=\"row-center\"><small>{3}</small></td>\n <td class=\"row-center\"><small>{4}</small></td>\n <td class=\"row-center\"><small>{5}</small></td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */ 
/*     */     
/* 418 */     writer.print("<hr size=\"1\" noshade=\"noshade\">\n<center><font size=\"-1\" color=\"#525D76\">\n <em>Copyright &copy; 1999-2025, Apache Software Foundation</em></font></center>\n\n</body>\n</html>");
/*     */ 
/*     */     
/* 421 */     writer.flush();
/* 422 */     writer.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\host\HTMLHostManagerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */