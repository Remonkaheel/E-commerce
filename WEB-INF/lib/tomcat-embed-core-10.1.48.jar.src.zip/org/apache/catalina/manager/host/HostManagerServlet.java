/*     */ package org.apache.catalina.manager.host;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.UnavailableException;
/*     */ import jakarta.servlet.http.HttpServlet;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerServlet;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostManagerServlet
/*     */   extends HttpServlet
/*     */   implements ContainerServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  90 */   protected transient Context context = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected int debug = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   protected transient Host installedHost = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   protected transient Engine engine = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager.host");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   protected transient Wrapper wrapper = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Wrapper getWrapper() {
/* 128 */     return this.wrapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWrapper(Wrapper wrapper) {
/* 135 */     this.wrapper = wrapper;
/* 136 */     if (wrapper == null) {
/* 137 */       this.context = null;
/* 138 */       this.installedHost = null;
/* 139 */       this.engine = null;
/*     */     } else {
/* 141 */       this.context = (Context)wrapper.getParent();
/* 142 */       this.installedHost = (Host)this.context.getParent();
/* 143 */       this.engine = (Engine)this.installedHost.getParent();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/* 162 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request.getLocales());
/*     */ 
/*     */     
/* 165 */     String command = request.getPathInfo();
/* 166 */     if (command == null) {
/* 167 */       command = request.getServletPath();
/*     */     }
/* 169 */     String name = request.getParameter("name");
/*     */ 
/*     */     
/* 172 */     response.setContentType("text/plain; charset=utf-8");
/*     */ 
/*     */ 
/*     */     
/* 176 */     response.setHeader("X-Content-Type-Options", "nosniff");
/* 177 */     PrintWriter writer = response.getWriter();
/*     */ 
/*     */     
/* 180 */     if (command == null) {
/* 181 */       writer.println(smClient.getString("hostManagerServlet.noCommand"));
/* 182 */     } else if (command.equals("/add")) {
/* 183 */       add(request, writer, name, false, smClient);
/* 184 */     } else if (command.equals("/remove")) {
/* 185 */       remove(writer, name, smClient);
/* 186 */     } else if (command.equals("/list")) {
/* 187 */       list(writer, smClient);
/* 188 */     } else if (command.equals("/start")) {
/* 189 */       start(writer, name, smClient);
/* 190 */     } else if (command.equals("/stop")) {
/* 191 */       stop(writer, name, smClient);
/* 192 */     } else if (command.equals("/persist")) {
/* 193 */       persist(writer, smClient);
/*     */     } else {
/* 195 */       writer.println(smClient.getString("hostManagerServlet.unknownCommand", new Object[] { command }));
/*     */     } 
/*     */ 
/*     */     
/* 199 */     writer.flush();
/* 200 */     writer.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void add(HttpServletRequest request, PrintWriter writer, String name, boolean htmlMode, StringManager smClient) {
/* 215 */     String aliases = request.getParameter("aliases");
/* 216 */     String appBase = request.getParameter("appBase");
/* 217 */     boolean manager = booleanParameter(request, "manager", false, htmlMode);
/* 218 */     boolean autoDeploy = booleanParameter(request, "autoDeploy", true, htmlMode);
/* 219 */     boolean deployOnStartup = booleanParameter(request, "deployOnStartup", true, htmlMode);
/* 220 */     boolean deployXML = booleanParameter(request, "deployXML", true, htmlMode);
/* 221 */     boolean unpackWARs = booleanParameter(request, "unpackWARs", true, htmlMode);
/* 222 */     boolean copyXML = booleanParameter(request, "copyXML", false, htmlMode);
/* 223 */     add(writer, name, aliases, appBase, manager, autoDeploy, deployOnStartup, deployXML, unpackWARs, copyXML, smClient);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean booleanParameter(HttpServletRequest request, String parameter, boolean theDefault, boolean htmlMode) {
/* 240 */     String value = request.getParameter(parameter);
/* 241 */     boolean booleanValue = theDefault;
/* 242 */     if (value != null) {
/* 243 */       if (htmlMode) {
/* 244 */         if (value.equals("on")) {
/* 245 */           booleanValue = true;
/*     */         }
/* 247 */       } else if (theDefault) {
/* 248 */         if (value.equals("false")) {
/* 249 */           booleanValue = false;
/*     */         }
/* 251 */       } else if (value.equals("true")) {
/* 252 */         booleanValue = true;
/*     */       } 
/* 254 */     } else if (htmlMode) {
/* 255 */       booleanValue = false;
/*     */     } 
/* 257 */     return booleanValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws ServletException {
/* 265 */     if (this.wrapper == null || this.context == null) {
/* 266 */       throw new UnavailableException(sm.getString("hostManagerServlet.noWrapper"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 272 */       String value = getServletConfig().getInitParameter("debug");
/* 273 */       this.debug = Integer.parseInt(value);
/* 274 */     } catch (Throwable t) {
/* 275 */       ExceptionUtils.handleThrowable(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void add(PrintWriter writer, String name, String aliases, String appBase, boolean manager, boolean autoDeploy, boolean deployOnStartup, boolean deployXML, boolean unpackWARs, boolean copyXML, StringManager smClient) {
/*     */     File appBaseFile;
/* 302 */     if (this.debug >= 1) {
/* 303 */       log(sm.getString("hostManagerServlet.add", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/* 307 */     if (name == null || name.isEmpty()) {
/* 308 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 313 */     if (this.engine.findChild(name) != null) {
/* 314 */       writer.println(smClient.getString("hostManagerServlet.alreadyHost", new Object[] { name }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 321 */     String applicationBase = appBase;
/* 322 */     if (applicationBase == null || applicationBase.isEmpty()) {
/* 323 */       applicationBase = name;
/*     */     }
/* 325 */     File file = new File(applicationBase);
/* 326 */     if (!file.isAbsolute()) {
/* 327 */       file = new File(this.engine.getCatalinaBase(), file.getPath());
/*     */     }
/*     */     try {
/* 330 */       appBaseFile = file.getCanonicalFile();
/* 331 */     } catch (IOException ioe) {
/* 332 */       appBaseFile = file;
/*     */     } 
/* 334 */     if (!appBaseFile.mkdirs() && !appBaseFile.isDirectory()) {
/* 335 */       writer.println(smClient.getString("hostManagerServlet.appBaseCreateFail", new Object[] { appBaseFile.toString(), name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 340 */     File configBaseFile = getConfigBase(name);
/*     */ 
/*     */     
/* 343 */     if (manager) {
/* 344 */       if (configBaseFile == null) {
/* 345 */         writer.println(smClient.getString("hostManagerServlet.configBaseCreateFail", new Object[] { name })); return;
/*     */       } 
/*     */       
/* 348 */       try { InputStream is = getServletContext().getResourceAsStream("/WEB-INF/manager.xml"); 
/* 349 */         try { if (is == null)
/* 350 */           { writer.println(smClient.getString("hostManagerServlet.managerXml"));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 355 */             if (is != null) is.close();  return; }  Path dest = (new File(configBaseFile, "manager.xml")).toPath(); Files.copy(is, dest, new java.nio.file.CopyOption[0]); if (is != null) is.close();  } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 356 */       { writer.println(smClient.getString("hostManagerServlet.managerXml"));
/*     */         
/*     */         return; }
/*     */     
/*     */     } 
/* 361 */     StandardHost host = new StandardHost();
/* 362 */     host.setAppBase(applicationBase);
/* 363 */     host.setName(name);
/*     */     
/* 365 */     host.addLifecycleListener((LifecycleListener)new HostConfig());
/*     */ 
/*     */     
/* 368 */     if (aliases != null && !aliases.isEmpty()) {
/* 369 */       StringTokenizer tok = new StringTokenizer(aliases, ", ");
/* 370 */       while (tok.hasMoreTokens()) {
/* 371 */         host.addAlias(tok.nextToken());
/*     */       }
/*     */     } 
/* 374 */     host.setAutoDeploy(autoDeploy);
/* 375 */     host.setDeployOnStartup(deployOnStartup);
/* 376 */     host.setDeployXML(deployXML);
/* 377 */     host.setUnpackWARs(unpackWARs);
/* 378 */     host.setCopyXML(copyXML);
/*     */ 
/*     */     
/*     */     try {
/* 382 */       this.engine.addChild((Container)host);
/* 383 */     } catch (Exception e) {
/* 384 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/*     */       return;
/*     */     } 
/* 388 */     host = (StandardHost)this.engine.findChild(name);
/* 389 */     if (host != null) {
/* 390 */       writer.println(smClient.getString("hostManagerServlet.addSuccess", new Object[] { name }));
/*     */     } else {
/*     */       
/* 393 */       writer.println(smClient.getString("hostManagerServlet.addFailed", new Object[] { name }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void remove(PrintWriter writer, String name, StringManager smClient) {
/* 408 */     if (this.debug >= 1) {
/* 409 */       log(sm.getString("hostManagerServlet.remove", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/* 413 */     if (name == null || name.isEmpty()) {
/* 414 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 419 */     if (this.engine.findChild(name) == null) {
/* 420 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 425 */     if (this.engine.findChild(name) == this.installedHost) {
/* 426 */       writer.println(smClient.getString("hostManagerServlet.cannotRemoveOwnHost", new Object[] { name }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 433 */       Container child = this.engine.findChild(name);
/* 434 */       this.engine.removeChild(child);
/* 435 */       if (child instanceof org.apache.catalina.core.ContainerBase) {
/* 436 */         child.destroy();
/*     */       }
/* 438 */     } catch (Exception e) {
/* 439 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       
/*     */       return;
/*     */     } 
/* 443 */     StandardHost standardHost = (StandardHost)this.engine.findChild(name);
/* 444 */     if (standardHost == null) {
/* 445 */       writer.println(smClient.getString("hostManagerServlet.removeSuccess", new Object[] { name }));
/*     */     } else {
/*     */       
/* 448 */       writer.println(smClient.getString("hostManagerServlet.removeFailed", new Object[] { name }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void list(PrintWriter writer, StringManager smClient) {
/* 462 */     if (this.debug >= 1) {
/* 463 */       log(sm.getString("hostManagerServlet.list", new Object[] { this.engine.getName() }));
/*     */     }
/*     */     
/* 466 */     writer.println(smClient.getString("hostManagerServlet.listed", new Object[] { this.engine.getName() }));
/* 467 */     Container[] hosts = this.engine.findChildren();
/* 468 */     for (Container container : hosts) {
/* 469 */       Host host = (Host)container;
/* 470 */       String name = host.getName();
/* 471 */       String[] aliases = host.findAliases();
/* 472 */       writer.println(String.format("[%s]:[%s]", new Object[] { name, StringUtils.join(aliases) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void start(PrintWriter writer, String name, StringManager smClient) {
/* 486 */     if (this.debug >= 1) {
/* 487 */       log(sm.getString("hostManagerServlet.start", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/* 491 */     if (name == null || name.isEmpty()) {
/* 492 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/* 496 */     Container host = this.engine.findChild(name);
/*     */ 
/*     */     
/* 499 */     if (host == null) {
/* 500 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 505 */     if (host == this.installedHost) {
/* 506 */       writer.println(smClient.getString("hostManagerServlet.cannotStartOwnHost", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 511 */     if (host.getState().isAvailable()) {
/* 512 */       writer.println(smClient.getString("hostManagerServlet.alreadyStarted", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 518 */       host.start();
/* 519 */       writer.println(smClient.getString("hostManagerServlet.started", new Object[] { name }));
/* 520 */     } catch (Exception e) {
/* 521 */       getServletContext().log(sm.getString("hostManagerServlet.startFailed", new Object[] { name }), e);
/* 522 */       writer.println(smClient.getString("hostManagerServlet.startFailed", new Object[] { name }));
/* 523 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stop(PrintWriter writer, String name, StringManager smClient) {
/* 537 */     if (this.debug >= 1) {
/* 538 */       log(sm.getString("hostManagerServlet.stop", new Object[] { name }));
/*     */     }
/*     */ 
/*     */     
/* 542 */     if (name == null || name.isEmpty()) {
/* 543 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/* 547 */     Container host = this.engine.findChild(name);
/*     */ 
/*     */     
/* 550 */     if (host == null) {
/* 551 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 556 */     if (host == this.installedHost) {
/* 557 */       writer.println(smClient.getString("hostManagerServlet.cannotStopOwnHost", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 562 */     if (!host.getState().isAvailable()) {
/* 563 */       writer.println(smClient.getString("hostManagerServlet.alreadyStopped", new Object[] { name }));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 569 */       host.stop();
/* 570 */       writer.println(smClient.getString("hostManagerServlet.stopped", new Object[] { name }));
/* 571 */     } catch (Exception e) {
/* 572 */       getServletContext().log(sm.getString("hostManagerServlet.stopFailed", new Object[] { name }), e);
/* 573 */       writer.println(smClient.getString("hostManagerServlet.stopFailed", new Object[] { name }));
/* 574 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void persist(PrintWriter writer, StringManager smClient) {
/* 587 */     if (this.debug >= 1) {
/* 588 */       log(sm.getString("hostManagerServlet.persist"));
/*     */     }
/*     */     
/*     */     try {
/* 592 */       MBeanServer platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
/* 593 */       ObjectName oname = new ObjectName("Catalina:type=StoreConfig");
/* 594 */       platformMBeanServer.invoke(oname, "storeConfig", null, null);
/* 595 */       writer.println(smClient.getString("hostManagerServlet.persisted"));
/* 596 */     } catch (Exception e) {
/* 597 */       getServletContext().log(sm.getString("hostManagerServlet.persistFailed"), e);
/* 598 */       writer.println(smClient.getString("hostManagerServlet.persistFailed"));
/*     */ 
/*     */       
/* 601 */       if (e instanceof javax.management.InstanceNotFoundException) {
/* 602 */         writer.println(smClient.getString("hostManagerServlet.noStoreConfig"));
/*     */       } else {
/* 604 */         writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getConfigBase(String hostName) {
/* 620 */     File configBase = new File(this.context.getCatalinaBase(), "conf");
/* 621 */     if (!configBase.exists()) {
/* 622 */       return null;
/*     */     }
/* 624 */     if (this.engine != null) {
/* 625 */       configBase = new File(configBase, this.engine.getName());
/*     */     }
/* 627 */     if (this.installedHost != null) {
/* 628 */       configBase = new File(configBase, hostName);
/*     */     }
/* 630 */     if (!configBase.mkdirs() && !configBase.isDirectory()) {
/* 631 */       return null;
/*     */     }
/* 633 */     return configBase;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\host\HostManagerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */