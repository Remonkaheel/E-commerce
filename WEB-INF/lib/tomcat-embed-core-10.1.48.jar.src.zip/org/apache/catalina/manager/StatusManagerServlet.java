/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServlet;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerNotification;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusManagerServlet
/*     */   extends HttpServlet
/*     */   implements NotificationListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  56 */   protected MBeanServer mBeanServer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected final List<ObjectName> threadPools = Collections.synchronizedList(new ArrayList<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected final List<ObjectName> requestProcessors = Collections.synchronizedList(new ArrayList<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected final List<ObjectName> globalRequestProcessors = Collections.synchronizedList(new ArrayList<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws ServletException {
/*  89 */     this.mBeanServer = Registry.getRegistry(null).getMBeanServer();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  94 */       String onStr = "*:type=ThreadPool,*";
/*  95 */       ObjectName objectName = new ObjectName(onStr);
/*  96 */       Set<ObjectInstance> set = this.mBeanServer.queryMBeans(objectName, null);
/*  97 */       Iterator<ObjectInstance> iterator = set.iterator();
/*  98 */       while (iterator.hasNext()) {
/*  99 */         ObjectInstance oi = iterator.next();
/* 100 */         this.threadPools.add(oi.getObjectName());
/*     */       } 
/*     */ 
/*     */       
/* 104 */       onStr = "*:type=GlobalRequestProcessor,*";
/* 105 */       objectName = new ObjectName(onStr);
/* 106 */       set = this.mBeanServer.queryMBeans(objectName, null);
/* 107 */       iterator = set.iterator();
/* 108 */       while (iterator.hasNext()) {
/* 109 */         ObjectInstance oi = iterator.next();
/* 110 */         this.globalRequestProcessors.add(oi.getObjectName());
/*     */       } 
/*     */ 
/*     */       
/* 114 */       onStr = "*:type=RequestProcessor,*";
/* 115 */       objectName = new ObjectName(onStr);
/* 116 */       set = this.mBeanServer.queryMBeans(objectName, null);
/* 117 */       iterator = set.iterator();
/* 118 */       while (iterator.hasNext()) {
/* 119 */         ObjectInstance oi = iterator.next();
/* 120 */         this.requestProcessors.add(oi.getObjectName());
/*     */       } 
/*     */ 
/*     */       
/* 124 */       onStr = "JMImplementation:type=MBeanServerDelegate";
/* 125 */       objectName = new ObjectName(onStr);
/* 126 */       this.mBeanServer.addNotificationListener(objectName, this, (NotificationFilter)null, (Object)null);
/*     */     }
/* 128 */     catch (Exception e) {
/* 129 */       log(sm.getString("managerServlet.error.jmx"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 139 */     String onStr = "JMImplementation:type=MBeanServerDelegate";
/*     */     
/*     */     try {
/* 142 */       ObjectName objectName = new ObjectName(onStr);
/* 143 */       this.mBeanServer.removeNotificationListener(objectName, this, (NotificationFilter)null, (Object)null);
/* 144 */     } catch (Exception e) {
/* 145 */       log(sm.getString("managerServlet.error.jmx"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/* 154 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*     */ 
/*     */     
/* 157 */     int mode = 0;
/*     */     
/* 159 */     if (request.getParameter("XML") != null && request.getParameter("XML").equals("true")) {
/* 160 */       mode = 1;
/*     */     }
/*     */     
/* 163 */     if (request.getParameter("JSON") != null && request.getParameter("JSON").equals("true")) {
/* 164 */       mode = 2;
/*     */     }
/* 166 */     StatusTransformer.setContentType(response, mode);
/*     */     
/* 168 */     PrintWriter writer = response.getWriter();
/*     */     
/* 170 */     boolean completeStatus = (request.getPathInfo() != null && request.getPathInfo().equals("/all"));
/*     */ 
/*     */     
/* 173 */     Object[] args = new Object[1];
/* 174 */     args[0] = getServletContext().getContextPath();
/* 175 */     StatusTransformer.writeHeader(writer, args, mode);
/*     */ 
/*     */     
/* 178 */     args = new Object[2];
/* 179 */     args[0] = getServletContext().getContextPath();
/* 180 */     if (completeStatus) {
/* 181 */       args[1] = smClient.getString("statusServlet.complete");
/*     */     } else {
/* 183 */       args[1] = smClient.getString("statusServlet.title");
/*     */     } 
/*     */     
/* 186 */     StatusTransformer.writeBody(writer, args, mode);
/*     */ 
/*     */     
/* 189 */     args = new Object[9];
/* 190 */     args[0] = smClient.getString("htmlManagerServlet.manager");
/* 191 */     args[1] = response.encodeURL(getServletContext().getContextPath() + "/html/list");
/* 192 */     args[2] = smClient.getString("htmlManagerServlet.list");
/* 193 */     args[3] = 
/* 194 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/*     */     
/* 196 */     args[4] = smClient.getString("htmlManagerServlet.helpHtmlManager");
/* 197 */     args[5] = 
/* 198 */       getServletContext().getContextPath() + "/" + getServletContext().getContextPath();
/* 199 */     args[6] = smClient.getString("htmlManagerServlet.helpManager");
/* 200 */     if (completeStatus) {
/* 201 */       args[7] = response.encodeURL(getServletContext().getContextPath() + "/status");
/* 202 */       args[8] = smClient.getString("statusServlet.title");
/*     */     } else {
/* 204 */       args[7] = response.encodeURL(getServletContext().getContextPath() + "/status/all");
/* 205 */       args[8] = smClient.getString("statusServlet.complete");
/*     */     } 
/*     */     
/* 208 */     StatusTransformer.writeManager(writer, args, mode);
/*     */ 
/*     */     
/* 211 */     args = new Object[9];
/* 212 */     args[0] = smClient.getString("htmlManagerServlet.serverTitle");
/* 213 */     args[1] = smClient.getString("htmlManagerServlet.serverVersion");
/* 214 */     args[2] = smClient.getString("htmlManagerServlet.serverJVMVersion");
/* 215 */     args[3] = smClient.getString("htmlManagerServlet.serverJVMVendor");
/* 216 */     args[4] = smClient.getString("htmlManagerServlet.serverOSName");
/* 217 */     args[5] = smClient.getString("htmlManagerServlet.serverOSVersion");
/* 218 */     args[6] = smClient.getString("htmlManagerServlet.serverOSArch");
/* 219 */     args[7] = smClient.getString("htmlManagerServlet.serverHostname");
/* 220 */     args[8] = smClient.getString("htmlManagerServlet.serverIPAddress");
/*     */     
/* 222 */     StatusTransformer.writePageHeading(writer, args, mode);
/*     */ 
/*     */     
/* 225 */     args = new Object[8];
/* 226 */     args[0] = ServerInfo.getServerInfo();
/* 227 */     args[1] = System.getProperty("java.runtime.version");
/* 228 */     args[2] = System.getProperty("java.vm.vendor");
/* 229 */     args[3] = System.getProperty("os.name");
/* 230 */     args[4] = System.getProperty("os.version");
/* 231 */     args[5] = System.getProperty("os.arch");
/*     */     try {
/* 233 */       InetAddress address = InetAddress.getLocalHost();
/* 234 */       args[6] = address.getHostName();
/* 235 */       args[7] = address.getHostAddress();
/* 236 */     } catch (UnknownHostException e) {
/* 237 */       args[6] = "-";
/* 238 */       args[7] = "-";
/*     */     } 
/*     */     
/* 241 */     StatusTransformer.writeServerInfo(writer, args, mode);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 246 */       args = new Object[9];
/* 247 */       args[0] = smClient.getString("htmlManagerServlet.jvmFreeMemory");
/* 248 */       args[1] = smClient.getString("htmlManagerServlet.jvmTotalMemory");
/* 249 */       args[2] = smClient.getString("htmlManagerServlet.jvmMaxMemory");
/* 250 */       args[3] = smClient.getString("htmlManagerServlet.jvmTableTitleMemoryPool");
/* 251 */       args[4] = smClient.getString("htmlManagerServlet.jvmTableTitleType");
/* 252 */       args[5] = smClient.getString("htmlManagerServlet.jvmTableTitleInitial");
/* 253 */       args[6] = smClient.getString("htmlManagerServlet.jvmTableTitleTotal");
/* 254 */       args[7] = smClient.getString("htmlManagerServlet.jvmTableTitleMaximum");
/* 255 */       args[8] = smClient.getString("htmlManagerServlet.jvmTableTitleUsed");
/*     */       
/* 257 */       StatusTransformer.writeVMState(writer, mode, args);
/*     */       
/* 259 */       args = new Object[19];
/* 260 */       args[0] = smClient.getString("htmlManagerServlet.connectorStateMaxThreads");
/* 261 */       args[1] = smClient.getString("htmlManagerServlet.connectorStateThreadCount");
/* 262 */       args[2] = smClient.getString("htmlManagerServlet.connectorStateThreadBusy");
/* 263 */       args[3] = smClient.getString("htmlManagerServlet.connectorStateAliveSocketCount");
/* 264 */       args[4] = smClient.getString("htmlManagerServlet.connectorStateMaxProcessingTime");
/* 265 */       args[5] = smClient.getString("htmlManagerServlet.connectorStateProcessingTime");
/* 266 */       args[6] = smClient.getString("htmlManagerServlet.connectorStateRequestCount");
/* 267 */       args[7] = smClient.getString("htmlManagerServlet.connectorStateErrorCount");
/* 268 */       args[8] = smClient.getString("htmlManagerServlet.connectorStateBytesReceived");
/* 269 */       args[9] = smClient.getString("htmlManagerServlet.connectorStateBytesSent");
/* 270 */       args[10] = smClient.getString("htmlManagerServlet.connectorStateTableTitleStage");
/* 271 */       args[11] = smClient.getString("htmlManagerServlet.connectorStateTableTitleTime");
/* 272 */       args[12] = smClient.getString("htmlManagerServlet.connectorStateTableTitleBSent");
/* 273 */       args[13] = smClient.getString("htmlManagerServlet.connectorStateTableTitleBRecv");
/* 274 */       args[14] = smClient.getString("htmlManagerServlet.connectorStateTableTitleClientForw");
/* 275 */       args[15] = smClient.getString("htmlManagerServlet.connectorStateTableTitleClientAct");
/* 276 */       args[16] = smClient.getString("htmlManagerServlet.connectorStateTableTitleVHost");
/* 277 */       args[17] = smClient.getString("htmlManagerServlet.connectorStateTableTitleRequest");
/* 278 */       args[18] = smClient.getString("htmlManagerServlet.connectorStateHint");
/* 279 */       StatusTransformer.writeConnectorsState(writer, this.mBeanServer, this.threadPools, this.globalRequestProcessors, this.requestProcessors, mode, args);
/*     */ 
/*     */       
/* 282 */       if (request.getPathInfo() != null && request.getPathInfo().equals("/all"))
/*     */       {
/*     */         
/* 285 */         StatusTransformer.writeDetailedState(writer, this.mBeanServer, mode);
/*     */       }
/*     */     }
/* 288 */     catch (Exception e) {
/* 289 */       throw new ServletException(e);
/*     */     } 
/*     */ 
/*     */     
/* 293 */     StatusTransformer.writeFooter(writer, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleNotification(Notification notification, Object handback) {
/* 302 */     if (notification instanceof MBeanServerNotification) {
/* 303 */       ObjectName objectName = ((MBeanServerNotification)notification).getMBeanName();
/* 304 */       if (notification.getType().equals("JMX.mbean.registered")) {
/* 305 */         String type = objectName.getKeyProperty("type");
/* 306 */         if (type != null) {
/* 307 */           if (type.equals("ThreadPool")) {
/* 308 */             this.threadPools.add(objectName);
/* 309 */           } else if (type.equals("GlobalRequestProcessor")) {
/* 310 */             this.globalRequestProcessors.add(objectName);
/* 311 */           } else if (type.equals("RequestProcessor")) {
/* 312 */             this.requestProcessors.add(objectName);
/*     */           } 
/*     */         }
/* 315 */       } else if (notification.getType().equals("JMX.mbean.unregistered")) {
/* 316 */         String type = objectName.getKeyProperty("type");
/* 317 */         if (type != null)
/* 318 */           if (type.equals("ThreadPool")) {
/* 319 */             this.threadPools.remove(objectName);
/* 320 */           } else if (type.equals("GlobalRequestProcessor")) {
/* 321 */             this.globalRequestProcessors.remove(objectName);
/* 322 */           } else if (type.equals("RequestProcessor")) {
/* 323 */             this.requestProcessors.remove(objectName);
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\StatusManagerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */