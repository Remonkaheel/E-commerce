/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.MemoryPoolMXBean;
/*      */ import java.lang.management.MemoryUsage;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectInstance;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.tomcat.util.json.JSONFilter;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatusTransformer
/*      */ {
/*      */   public static void setContentType(HttpServletResponse response, int mode) {
/*   49 */     if (mode == 0) {
/*   50 */       response.setContentType("text/html;charset=utf-8");
/*   51 */     } else if (mode == 1) {
/*   52 */       response.setContentType("text/xml;charset=utf-8");
/*   53 */     } else if (mode == 2) {
/*   54 */       response.setContentType("application/json;charset=utf-8");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeHeader(PrintWriter writer, Object[] args, int mode) {
/*   67 */     if (mode == 0) {
/*      */       
/*   69 */       writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*   70 */     } else if (mode == 1) {
/*   71 */       writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
/*   72 */       writer.print(MessageFormat.format("<?xml-stylesheet type=\"text/xsl\" href=\"{0}/xform.xsl\" ?>\n", args));
/*   73 */       writer.write("<status>");
/*   74 */     } else if (mode == 2) {
/*   75 */       writer.append('{').append('"').append("tomcat").append('"').append(':').append('{').println();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeBody(PrintWriter writer, Object[] args, int mode) {
/*   88 */     if (mode == 0) {
/*   89 */       writer.print(MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeManager(PrintWriter writer, Object[] args, int mode) {
/*  102 */     if (mode == 0) {
/*  103 */       writer.print(MessageFormat.format(Constants.MANAGER_SECTION, args));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void writePageHeading(PrintWriter writer, Object[] args, int mode) {
/*  109 */     if (mode == 0) {
/*  110 */       writer.print(MessageFormat.format(Constants.SERVER_HEADER_SECTION, args));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void writeServerInfo(PrintWriter writer, Object[] args, int mode) {
/*  116 */     if (mode == 0) {
/*  117 */       writer.print(MessageFormat.format(Constants.SERVER_ROW_SECTION, args));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void writeFooter(PrintWriter writer, int mode) {
/*  123 */     if (mode == 0) {
/*      */       
/*  125 */       writer.print(Constants.HTML_TAIL_SECTION);
/*  126 */     } else if (mode == 1) {
/*  127 */       writer.write("</status>");
/*  128 */     } else if (mode == 2) {
/*  129 */       writer.append('}').append('}');
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeVMState(PrintWriter writer, int mode, Object[] args) throws Exception {
/*  145 */     SortedMap<String, MemoryPoolMXBean> memoryPoolMBeans = new TreeMap<>();
/*  146 */     for (MemoryPoolMXBean mbean : ManagementFactory.getMemoryPoolMXBeans()) {
/*  147 */       String sortKey = String.valueOf(mbean.getType()) + ":" + String.valueOf(mbean.getType());
/*  148 */       memoryPoolMBeans.put(sortKey, mbean);
/*      */     } 
/*      */     
/*  151 */     if (mode == 0) {
/*  152 */       writer.print("<h1>JVM</h1>");
/*      */       
/*  154 */       writer.print("<p>");
/*  155 */       writer.print(args[0]);
/*  156 */       writer.print(' ');
/*  157 */       writer.print(formatSize(Long.valueOf(Runtime.getRuntime().freeMemory()), true));
/*  158 */       writer.print(' ');
/*  159 */       writer.print(args[1]);
/*  160 */       writer.print(' ');
/*  161 */       writer.print(formatSize(Long.valueOf(Runtime.getRuntime().totalMemory()), true));
/*  162 */       writer.print(' ');
/*  163 */       writer.print(args[2]);
/*  164 */       writer.print(' ');
/*  165 */       writer.print(formatSize(Long.valueOf(Runtime.getRuntime().maxMemory()), true));
/*  166 */       writer.print("</p>");
/*      */       
/*  168 */       writer.write("<table border=\"0\"><thead><tr><th>" + String.valueOf(args[3]) + "</th><th>" + String.valueOf(args[4]) + "</th><th>" + String.valueOf(args[5]) + "</th><th>" + String.valueOf(args[6]) + "</th><th>" + String.valueOf(args[7]) + "</th><th>" + String.valueOf(args[8]) + "</th></tr></thead><tbody>");
/*      */ 
/*      */       
/*  171 */       for (MemoryPoolMXBean memoryPoolMBean : memoryPoolMBeans.values()) {
/*  172 */         MemoryUsage usage = memoryPoolMBean.getUsage();
/*  173 */         writer.write("<tr><td>");
/*  174 */         writer.print(memoryPoolMBean.getName());
/*  175 */         writer.write("</td><td>");
/*  176 */         writer.print(memoryPoolMBean.getType());
/*  177 */         writer.write("</td><td>");
/*  178 */         writer.print(formatSize(Long.valueOf(usage.getInit()), true));
/*  179 */         writer.write("</td><td>");
/*  180 */         writer.print(formatSize(Long.valueOf(usage.getCommitted()), true));
/*  181 */         writer.write("</td><td>");
/*  182 */         writer.print(formatSize(Long.valueOf(usage.getMax()), true));
/*  183 */         writer.write("</td><td>");
/*  184 */         writer.print(formatSize(Long.valueOf(usage.getUsed()), true));
/*  185 */         if (usage.getMax() > 0L) {
/*  186 */           writer.write(" (" + usage.getUsed() * 100L / usage.getMax() + "%)");
/*      */         }
/*  188 */         writer.write("</td></tr>");
/*      */       } 
/*  190 */       writer.write("</tbody></table>");
/*  191 */     } else if (mode == 1) {
/*  192 */       writer.write("<jvm>");
/*      */       
/*  194 */       writer.write("<memory");
/*  195 */       writer.write(" free='" + Runtime.getRuntime().freeMemory() + "'");
/*  196 */       writer.write(" total='" + Runtime.getRuntime().totalMemory() + "'");
/*  197 */       writer.write(" max='" + Runtime.getRuntime().maxMemory() + "'/>");
/*      */       
/*  199 */       for (MemoryPoolMXBean memoryPoolMBean : memoryPoolMBeans.values()) {
/*  200 */         MemoryUsage usage = memoryPoolMBean.getUsage();
/*  201 */         writer.write("<memorypool");
/*  202 */         writer.write(" name='" + Escape.xml("", memoryPoolMBean.getName()) + "'");
/*  203 */         writer.write(" type='" + String.valueOf(memoryPoolMBean.getType()) + "'");
/*  204 */         writer.write(" usageInit='" + usage.getInit() + "'");
/*  205 */         writer.write(" usageCommitted='" + usage.getCommitted() + "'");
/*  206 */         writer.write(" usageMax='" + usage.getMax() + "'");
/*  207 */         writer.write(" usageUsed='" + usage.getUsed() + "'/>");
/*      */       } 
/*      */       
/*  210 */       writer.write("</jvm>");
/*  211 */     } else if (mode == 2) {
/*  212 */       indent(writer, 1).append('"').append("jvm").append('"').append(':').append('{').println();
/*      */       
/*  214 */       indent(writer, 2).append('"').append("memory").append('"').append(':').append('{');
/*  215 */       appendJSonValue(writer, "free", Long.valueOf(Runtime.getRuntime().freeMemory())).append(',');
/*  216 */       appendJSonValue(writer, "total", Long.valueOf(Runtime.getRuntime().totalMemory())).append(',');
/*  217 */       appendJSonValue(writer, "max", Long.valueOf(Runtime.getRuntime().maxMemory()));
/*  218 */       writer.append('}').append(',').println();
/*      */       
/*  220 */       indent(writer, 2).append('"').append("memorypool").append('"').append(':').append('[');
/*  221 */       boolean first = true;
/*  222 */       for (MemoryPoolMXBean memoryPoolMBean : memoryPoolMBeans.values()) {
/*  223 */         MemoryUsage usage = memoryPoolMBean.getUsage();
/*  224 */         if (first) {
/*  225 */           first = false;
/*  226 */           writer.println();
/*      */         } else {
/*  228 */           writer.append(',').println();
/*      */         } 
/*  230 */         indent(writer, 3).append('{');
/*  231 */         appendJSonValue(writer, "name", JSONFilter.escape(memoryPoolMBean.getName())).append(',');
/*  232 */         appendJSonValue(writer, "type", memoryPoolMBean.getType().toString()).append(',');
/*  233 */         appendJSonValue(writer, "usageInit", Long.valueOf(usage.getInit())).append(',');
/*  234 */         appendJSonValue(writer, "usageCommitted", Long.valueOf(usage.getCommitted())).append(',');
/*  235 */         appendJSonValue(writer, "usageMax", Long.valueOf(usage.getMax())).append(',');
/*  236 */         appendJSonValue(writer, "usageUsed", Long.valueOf(usage.getUsed()));
/*  237 */         writer.append('}');
/*      */       } 
/*  239 */       writer.println();
/*  240 */       indent(writer, 2).append(']').println();
/*      */       
/*  242 */       indent(writer, 1).append('}');
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static PrintWriter appendJSonValue(PrintWriter writer, String name, Object value) {
/*  249 */     writer.append('"').append(name).append('"').append(':');
/*  250 */     if (value instanceof Number) {
/*  251 */       return writer.append(value.toString());
/*      */     }
/*  253 */     return writer.append('"').append(value.toString()).append('"');
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static PrintWriter indent(PrintWriter writer, int count) {
/*  259 */     for (int i = 0; i < count; i++) {
/*  260 */       writer.append(' ').append(' ');
/*      */     }
/*  262 */     return writer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeConnectorsState(PrintWriter writer, MBeanServer mBeanServer, List<ObjectName> threadPools, List<ObjectName> globalRequestProcessors, List<ObjectName> requestProcessors, int mode, Object[] args) throws Exception {
/*  282 */     if (mode == 2) {
/*  283 */       writer.append(',').println();
/*  284 */       indent(writer, 1).append('"').append("connector").append('"').append(':').append('[').println();
/*      */     } 
/*  286 */     boolean first = true;
/*  287 */     for (ObjectName objectName : threadPools) {
/*  288 */       if (first) {
/*  289 */         first = false;
/*      */       }
/*  291 */       else if (mode == 2) {
/*  292 */         writer.append(',').println();
/*      */       } 
/*      */       
/*  295 */       String name = objectName.getKeyProperty("name");
/*      */       
/*  297 */       writeConnectorState(writer, objectName, name, mBeanServer, globalRequestProcessors, requestProcessors, mode, args);
/*      */     } 
/*      */     
/*  300 */     if (mode == 2) {
/*  301 */       writer.append(']');
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeConnectorState(PrintWriter writer, ObjectName tpName, String name, MBeanServer mBeanServer, List<ObjectName> globalRequestProcessors, List<ObjectName> requestProcessors, int mode, Object[] args) throws Exception {
/*  324 */     if (mode == 0) {
/*  325 */       writer.print("<h1>");
/*  326 */       writer.print(name);
/*  327 */       writer.print("</h1>");
/*      */       
/*  329 */       writer.print("<p>");
/*  330 */       writer.print(args[0]);
/*  331 */       writer.print(' ');
/*  332 */       writer.print(mBeanServer.getAttribute(tpName, "maxThreads"));
/*  333 */       writer.print(' ');
/*  334 */       writer.print(args[1]);
/*  335 */       writer.print(' ');
/*  336 */       writer.print(mBeanServer.getAttribute(tpName, "currentThreadCount"));
/*  337 */       writer.print(' ');
/*  338 */       writer.print(args[2]);
/*  339 */       writer.print(' ');
/*  340 */       writer.print(mBeanServer.getAttribute(tpName, "currentThreadsBusy"));
/*  341 */       writer.print(' ');
/*  342 */       writer.print(args[3]);
/*  343 */       writer.print(' ');
/*  344 */       writer.print(mBeanServer.getAttribute(tpName, "keepAliveCount"));
/*      */       
/*  346 */       writer.print("<br>");
/*      */       
/*  348 */       ObjectName grpName = null;
/*      */       
/*  350 */       for (ObjectName objectName : globalRequestProcessors) {
/*      */         
/*  352 */         if (name.equals(objectName.getKeyProperty("name")) && objectName.getKeyProperty("Upgrade") == null) {
/*  353 */           grpName = objectName;
/*      */         }
/*      */       } 
/*      */       
/*  357 */       if (grpName == null) {
/*      */         return;
/*      */       }
/*      */       
/*  361 */       writer.print(args[4]);
/*  362 */       writer.print(' ');
/*  363 */       writer.print(formatTime(mBeanServer.getAttribute(grpName, "maxTime"), false));
/*  364 */       writer.print(' ');
/*  365 */       writer.print(args[5]);
/*  366 */       writer.print(' ');
/*  367 */       writer.print(formatTime(mBeanServer.getAttribute(grpName, "processingTime"), true));
/*  368 */       writer.print(' ');
/*  369 */       writer.print(args[6]);
/*  370 */       writer.print(' ');
/*  371 */       writer.print(mBeanServer.getAttribute(grpName, "requestCount"));
/*  372 */       writer.print(' ');
/*  373 */       writer.print(args[7]);
/*  374 */       writer.print(' ');
/*  375 */       writer.print(mBeanServer.getAttribute(grpName, "errorCount"));
/*  376 */       writer.print(' ');
/*  377 */       writer.print(args[8]);
/*  378 */       writer.print(' ');
/*  379 */       writer.print(formatSize(mBeanServer.getAttribute(grpName, "bytesReceived"), true));
/*  380 */       writer.print(' ');
/*  381 */       writer.print(args[9]);
/*  382 */       writer.print(' ');
/*  383 */       writer.print(formatSize(mBeanServer.getAttribute(grpName, "bytesSent"), true));
/*  384 */       writer.print("</p>");
/*      */       
/*  386 */       writer.print("<table border=\"0\"><tr><th>" + String.valueOf(args[10]) + "</th><th>" + String.valueOf(args[11]) + "</th><th>" + String.valueOf(args[12]) + "</th><th>" + String.valueOf(args[13]) + "</th><th>" + String.valueOf(args[14]) + "</th><th>" + String.valueOf(args[15]) + "</th><th>" + String.valueOf(args[16]) + "</th><th>" + String.valueOf(args[17]) + "</th></tr>");
/*      */ 
/*      */ 
/*      */       
/*  390 */       for (ObjectName objectName : requestProcessors) {
/*  391 */         if (name.equals(getConnectorName(objectName.getKeyProperty("worker")))) {
/*  392 */           writer.print("<tr>");
/*  393 */           writeProcessorState(writer, objectName, mBeanServer, mode);
/*  394 */           writer.print("</tr>");
/*      */         } 
/*      */       } 
/*      */       
/*  398 */       writer.print("</table>");
/*      */       
/*  400 */       writer.print("<p>");
/*  401 */       writer.print(args[18]);
/*  402 */       writer.print("</p>");
/*  403 */     } else if (mode == 1) {
/*  404 */       writer.write("<connector name='" + name + "'>");
/*      */       
/*  406 */       writer.write("<threadInfo ");
/*  407 */       writer.write(" maxThreads=\"" + String.valueOf(mBeanServer.getAttribute(tpName, "maxThreads")) + "\"");
/*  408 */       writer.write(" currentThreadCount=\"" + String.valueOf(mBeanServer.getAttribute(tpName, "currentThreadCount")) + "\"");
/*  409 */       writer.write(" currentThreadsBusy=\"" + String.valueOf(mBeanServer.getAttribute(tpName, "currentThreadsBusy")) + "\"");
/*  410 */       writer.write(" />");
/*      */       
/*  412 */       ObjectName grpName = null;
/*      */       
/*  414 */       for (ObjectName objectName : globalRequestProcessors) {
/*      */         
/*  416 */         if (name.equals(objectName.getKeyProperty("name")) && objectName.getKeyProperty("Upgrade") == null) {
/*  417 */           grpName = objectName;
/*      */         }
/*      */       } 
/*      */       
/*  421 */       if (grpName != null) {
/*      */         
/*  423 */         writer.write("<requestInfo ");
/*  424 */         writer.write(" maxTime=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "maxTime")) + "\"");
/*  425 */         writer.write(" processingTime=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "processingTime")) + "\"");
/*  426 */         writer.write(" requestCount=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "requestCount")) + "\"");
/*  427 */         writer.write(" errorCount=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "errorCount")) + "\"");
/*  428 */         writer.write(" bytesReceived=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "bytesReceived")) + "\"");
/*  429 */         writer.write(" bytesSent=\"" + String.valueOf(mBeanServer.getAttribute(grpName, "bytesSent")) + "\"");
/*  430 */         writer.write(" />");
/*      */         
/*  432 */         writer.write("<workers>");
/*  433 */         for (ObjectName objectName : requestProcessors) {
/*  434 */           if (name.equals(getConnectorName(objectName.getKeyProperty("worker")))) {
/*  435 */             writeProcessorState(writer, objectName, mBeanServer, mode);
/*      */           }
/*      */         } 
/*  438 */         writer.write("</workers>");
/*      */       } 
/*      */       
/*  441 */       writer.write("</connector>");
/*  442 */     } else if (mode == 2) {
/*  443 */       indent(writer, 2).append('{').println();
/*      */       
/*  445 */       indent(writer, 3);
/*  446 */       String jsonName = JSONFilter.escape(name);
/*  447 */       if (jsonName.length() > 4 && jsonName.startsWith("\\\"") && jsonName.endsWith("\\\"")) {
/*  448 */         jsonName = jsonName.substring(2, jsonName.length() - 2);
/*      */       }
/*  450 */       appendJSonValue(writer, "name", jsonName).append(',').println();
/*  451 */       indent(writer, 3).append('"').append("threadInfo").append('"').append(':').append('{');
/*  452 */       appendJSonValue(writer, "maxThreads", mBeanServer.getAttribute(tpName, "maxThreads")).append(',');
/*  453 */       appendJSonValue(writer, "currentThreadCount", mBeanServer.getAttribute(tpName, "currentThreadCount"))
/*  454 */         .append(',');
/*  455 */       appendJSonValue(writer, "currentThreadsBusy", mBeanServer.getAttribute(tpName, "currentThreadsBusy"));
/*  456 */       writer.append('}');
/*      */       
/*  458 */       ObjectName grpName = null;
/*  459 */       for (ObjectName objectName : globalRequestProcessors) {
/*      */         
/*  461 */         if (name.equals(objectName.getKeyProperty("name")) && objectName.getKeyProperty("Upgrade") == null) {
/*  462 */           grpName = objectName;
/*      */         }
/*      */       } 
/*      */       
/*  466 */       if (grpName != null) {
/*  467 */         writer.append(',').println();
/*  468 */         indent(writer, 3).append('"').append("requestInfo").append('"').append(':').append('{');
/*  469 */         appendJSonValue(writer, "maxTime", mBeanServer.getAttribute(grpName, "maxTime")).append(',');
/*  470 */         appendJSonValue(writer, "processingTime", mBeanServer.getAttribute(grpName, "processingTime"))
/*  471 */           .append(',');
/*  472 */         appendJSonValue(writer, "requestCount", mBeanServer.getAttribute(grpName, "requestCount")).append(',');
/*  473 */         appendJSonValue(writer, "errorCount", mBeanServer.getAttribute(grpName, "errorCount")).append(',');
/*  474 */         appendJSonValue(writer, "bytesReceived", mBeanServer.getAttribute(grpName, "bytesReceived"))
/*  475 */           .append(',');
/*  476 */         appendJSonValue(writer, "bytesSent", mBeanServer.getAttribute(grpName, "bytesSent"));
/*  477 */         writer.append('}').println();
/*      */       } 
/*      */ 
/*      */       
/*  481 */       indent(writer, 2).append('}');
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String getConnectorName(String name) {
/*  494 */     if (name.indexOf("-auto-") > 0) {
/*  495 */       return name.substring(0, name.lastIndexOf("-")) + "\"";
/*      */     }
/*  497 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void writeProcessorState(PrintWriter writer, ObjectName pName, MBeanServer mBeanServer, int mode) throws Exception {
/*      */     String stageStr;
/*  514 */     Integer stageValue = (Integer)mBeanServer.getAttribute(pName, "stage");
/*  515 */     int stage = stageValue.intValue();
/*  516 */     boolean fullStatus = true;
/*  517 */     boolean showRequest = true;
/*      */ 
/*      */     
/*  520 */     switch (stage) {
/*      */       
/*      */       case 1:
/*  523 */         stageStr = "P";
/*  524 */         fullStatus = false;
/*      */         break;
/*      */       case 2:
/*  527 */         stageStr = "P";
/*  528 */         fullStatus = false;
/*      */         break;
/*      */       case 3:
/*  531 */         stageStr = "S";
/*      */         break;
/*      */       case 4:
/*  534 */         stageStr = "F";
/*      */         break;
/*      */       case 5:
/*  537 */         stageStr = "F";
/*      */         break;
/*      */       case 7:
/*  540 */         stageStr = "R";
/*  541 */         fullStatus = false;
/*      */         break;
/*      */       case 6:
/*  544 */         stageStr = "K";
/*  545 */         showRequest = false;
/*      */         break;
/*      */       case 0:
/*  548 */         stageStr = "R";
/*  549 */         fullStatus = false;
/*      */         break;
/*      */       
/*      */       default:
/*  553 */         stageStr = "?";
/*  554 */         fullStatus = false;
/*      */         break;
/*      */     } 
/*      */     
/*  558 */     if (mode == 0) {
/*  559 */       writer.write("<td><strong>");
/*  560 */       writer.write(stageStr);
/*  561 */       writer.write("</strong></td>");
/*      */       
/*  563 */       if (fullStatus) {
/*  564 */         writer.write("<td>");
/*  565 */         writer.print(formatTime(mBeanServer.getAttribute(pName, "requestProcessingTime"), false));
/*  566 */         writer.write("</td>");
/*  567 */         writer.write("<td>");
/*  568 */         if (showRequest) {
/*  569 */           writer.print(formatSize(mBeanServer.getAttribute(pName, "requestBytesSent"), false));
/*      */         } else {
/*  571 */           writer.write("?");
/*      */         } 
/*  573 */         writer.write("</td>");
/*  574 */         writer.write("<td>");
/*  575 */         if (showRequest) {
/*  576 */           writer.print(formatSize(mBeanServer.getAttribute(pName, "requestBytesReceived"), false));
/*      */         } else {
/*  578 */           writer.write("?");
/*      */         } 
/*  580 */         writer.write("</td>");
/*  581 */         writer.write("<td>");
/*  582 */         writer.print(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "remoteAddrForwarded")));
/*  583 */         writer.write("</td>");
/*  584 */         writer.write("<td>");
/*  585 */         writer.print(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "remoteAddr")));
/*  586 */         writer.write("</td>");
/*  587 */         writer.write("<td nowrap>");
/*  588 */         writer.write(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "virtualHost")));
/*  589 */         writer.write("</td>");
/*  590 */         writer.write("<td nowrap class=\"row-left\">");
/*  591 */         if (showRequest) {
/*  592 */           writer.write(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "method")));
/*  593 */           writer.write(32);
/*  594 */           writer.write(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "currentUri")));
/*  595 */           String queryString = (String)mBeanServer.getAttribute(pName, "currentQueryString");
/*  596 */           if (queryString != null && !queryString.isEmpty()) {
/*  597 */             writer.write("?");
/*  598 */             writer.print(Escape.htmlElementContent(queryString));
/*      */           } 
/*  600 */           writer.write(32);
/*  601 */           writer.write(Escape.htmlElementContent(mBeanServer.getAttribute(pName, "protocol")));
/*      */         } else {
/*  603 */           writer.write("?");
/*      */         } 
/*  605 */         writer.write("</td>");
/*      */       } else {
/*  607 */         writer.write("<td>?</td><td>?</td><td>?</td><td>?</td><td>?</td><td>?</td>");
/*      */       } 
/*  609 */     } else if (mode == 1) {
/*  610 */       writer.write("<worker ");
/*  611 */       writer.write(" stage=\"" + stageStr + "\"");
/*      */       
/*  613 */       if (fullStatus) {
/*  614 */         writer.write(" requestProcessingTime=\"" + 
/*  615 */             String.valueOf(mBeanServer.getAttribute(pName, "requestProcessingTime")) + "\"");
/*  616 */         writer.write(" requestBytesSent=\"");
/*  617 */         if (showRequest) {
/*  618 */           writer.write(String.valueOf(mBeanServer.getAttribute(pName, "requestBytesSent")));
/*      */         } else {
/*  620 */           writer.write("0");
/*      */         } 
/*  622 */         writer.write("\"");
/*  623 */         writer.write(" requestBytesReceived=\"");
/*  624 */         if (showRequest) {
/*  625 */           writer.write(String.valueOf(mBeanServer.getAttribute(pName, "requestBytesReceived")));
/*      */         } else {
/*  627 */           writer.write("0");
/*      */         } 
/*  629 */         writer.write("\"");
/*  630 */         writer.write(" remoteAddr=\"" + 
/*  631 */             Escape.htmlElementContent(mBeanServer.getAttribute(pName, "remoteAddr")) + "\"");
/*  632 */         writer.write(" virtualHost=\"" + 
/*  633 */             Escape.htmlElementContent(mBeanServer.getAttribute(pName, "virtualHost")) + "\"");
/*      */         
/*  635 */         if (showRequest) {
/*  636 */           writer.write(" method=\"" + 
/*  637 */               Escape.htmlElementContent(mBeanServer.getAttribute(pName, "method")) + "\"");
/*  638 */           writer.write(" currentUri=\"" + 
/*  639 */               Escape.htmlElementContent(mBeanServer.getAttribute(pName, "currentUri")) + "\"");
/*      */           
/*  641 */           String queryString = (String)mBeanServer.getAttribute(pName, "currentQueryString");
/*  642 */           if (queryString != null && !queryString.isEmpty()) {
/*  643 */             writer.write(" currentQueryString=\"" + Escape.htmlElementContent(queryString) + "\"");
/*      */           } else {
/*  645 */             writer.write(" currentQueryString=\"&#63;\"");
/*      */           } 
/*  647 */           writer.write(" protocol=\"" + 
/*  648 */               Escape.htmlElementContent(mBeanServer.getAttribute(pName, "protocol")) + "\"");
/*      */         } else {
/*  650 */           writer.write(" method=\"&#63;\"");
/*  651 */           writer.write(" currentUri=\"&#63;\"");
/*  652 */           writer.write(" currentQueryString=\"&#63;\"");
/*  653 */           writer.write(" protocol=\"&#63;\"");
/*      */         } 
/*      */       } else {
/*  656 */         writer.write(" requestProcessingTime=\"0\"");
/*  657 */         writer.write(" requestBytesSent=\"0\"");
/*  658 */         writer.write(" requestBytesReceived=\"0\"");
/*  659 */         writer.write(" remoteAddr=\"&#63;\"");
/*  660 */         writer.write(" virtualHost=\"&#63;\"");
/*  661 */         writer.write(" method=\"&#63;\"");
/*  662 */         writer.write(" currentUri=\"&#63;\"");
/*  663 */         writer.write(" currentQueryString=\"&#63;\"");
/*  664 */         writer.write(" protocol=\"&#63;\"");
/*      */       } 
/*  666 */       writer.write(" />");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeDetailedState(PrintWriter writer, MBeanServer mBeanServer, int mode) throws Exception {
/*  683 */     ObjectName queryHosts = new ObjectName("*:j2eeType=WebModule,*");
/*  684 */     Set<ObjectName> hostsON = mBeanServer.queryNames(queryHosts, null);
/*  685 */     if (mode == 0) {
/*      */ 
/*      */       
/*  688 */       writer.print("<h1>");
/*  689 */       writer.print("Application list");
/*  690 */       writer.print("</h1>");
/*      */       
/*  692 */       writer.print("<p>");
/*  693 */       int count = 0;
/*  694 */       Iterator<ObjectName> iterator = hostsON.iterator();
/*  695 */       while (iterator.hasNext()) {
/*  696 */         ObjectName contextON = iterator.next();
/*  697 */         String webModuleName = contextON.getKeyProperty("name");
/*  698 */         if (webModuleName.startsWith("//")) {
/*  699 */           webModuleName = webModuleName.substring(2);
/*      */         }
/*  701 */         int slash = webModuleName.indexOf('/');
/*  702 */         if (slash == -1) {
/*  703 */           count++;
/*      */           
/*      */           continue;
/*      */         } 
/*  707 */         writer.print("<a href=\"#" + count++ + ".0\">");
/*  708 */         writer.print(Escape.htmlElementContent(webModuleName));
/*  709 */         writer.print("</a>");
/*  710 */         if (iterator.hasNext()) {
/*  711 */           writer.print("<br>");
/*      */         }
/*      */       } 
/*      */       
/*  715 */       writer.print("</p>");
/*      */ 
/*      */       
/*  718 */       count = 0;
/*  719 */       iterator = hostsON.iterator();
/*  720 */       while (iterator.hasNext()) {
/*  721 */         ObjectName contextON = iterator.next();
/*  722 */         writer.print("<a class=\"A.name\" name=\"" + count++ + ".0\">");
/*  723 */         writeContext(writer, contextON, mBeanServer, mode);
/*      */       }
/*      */     
/*  726 */     } else if (mode != 1) {
/*      */       
/*  728 */       if (mode == 2) {
/*  729 */         writer.append(',').println();
/*  730 */         indent(writer, 1).append('"').append("context").append('"').append(':').append('[').println();
/*  731 */         Iterator<ObjectName> iterator = hostsON.iterator();
/*  732 */         boolean first = true;
/*  733 */         while (iterator.hasNext()) {
/*  734 */           if (first) {
/*  735 */             first = false;
/*      */           } else {
/*  737 */             writer.append(',').println();
/*      */           } 
/*  739 */           ObjectName contextON = iterator.next();
/*  740 */           writeContext(writer, contextON, mBeanServer, mode);
/*      */         } 
/*  742 */         writer.println();
/*  743 */         indent(writer, 1).append(']').println();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void writeContext(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode) throws Exception {
/*  762 */     String hostName, contextName, webModuleName = objectName.getKeyProperty("name");
/*  763 */     String name = webModuleName;
/*  764 */     if (name == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  770 */     if (name.startsWith("//")) {
/*  771 */       name = name.substring(2);
/*      */     }
/*  773 */     int slash = name.indexOf('/');
/*  774 */     if (slash != -1) {
/*  775 */       hostName = name.substring(0, slash);
/*  776 */       contextName = name.substring(slash);
/*      */     } else {
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  782 */     ObjectName queryManager = new ObjectName(objectName.getDomain() + ":type=Manager,context=" + objectName.getDomain() + ",host=" + contextName + ",*");
/*  783 */     Set<ObjectName> managersON = mBeanServer.queryNames(queryManager, null);
/*  784 */     ObjectName managerON = null;
/*  785 */     for (ObjectName aManagersON : managersON) {
/*  786 */       managerON = aManagersON;
/*      */     }
/*      */ 
/*      */     
/*  790 */     ObjectName queryJspMonitor = new ObjectName(objectName.getDomain() + ":type=JspMonitor,WebModule=" + objectName.getDomain() + ",*");
/*  791 */     Set<ObjectName> jspMonitorONs = mBeanServer.queryNames(queryJspMonitor, null);
/*      */ 
/*      */     
/*  794 */     if (contextName.equals("/")) {
/*  795 */       contextName = "";
/*      */     }
/*      */     
/*  798 */     if (mode == 0) {
/*      */       
/*  800 */       writer.print("<h1>");
/*  801 */       writer.print(Escape.htmlElementContent(name));
/*  802 */       writer.print("</h1>");
/*  803 */       writer.print("</a>");
/*      */       
/*  805 */       writer.print("<p>");
/*  806 */       Object startTime = mBeanServer.getAttribute(objectName, "startTime");
/*  807 */       writer.print(" Start time: " + String.valueOf(new Date(((Long)startTime).longValue())));
/*  808 */       writer.print(" Startup time: ");
/*  809 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "startupTime"), false));
/*  810 */       writer.print(" TLD scan time: ");
/*  811 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "tldScanTime"), false));
/*  812 */       if (managerON != null) {
/*  813 */         writeManager(writer, managerON, mBeanServer, mode);
/*      */       }
/*  815 */       if (jspMonitorONs != null) {
/*  816 */         writeJspMonitor(writer, jspMonitorONs, mBeanServer, mode);
/*      */       }
/*  818 */       writer.print("</p>");
/*      */       
/*  820 */       String onStr = objectName.getDomain() + ":j2eeType=Servlet,WebModule=" + objectName.getDomain() + ",*";
/*  821 */       ObjectName servletObjectName = new ObjectName(onStr);
/*  822 */       Set<ObjectInstance> set = mBeanServer.queryMBeans(servletObjectName, null);
/*  823 */       for (ObjectInstance oi : set) {
/*  824 */         writeWrapper(writer, oi.getObjectName(), mBeanServer, mode);
/*      */       }
/*      */     }
/*  827 */     else if (mode != 1) {
/*      */       
/*  829 */       if (mode == 2) {
/*  830 */         indent(writer, 2).append('{').println();
/*  831 */         appendJSonValue(indent(writer, 3), "name", JSONFilter.escape(JSONFilter.escape(name))).append(',');
/*  832 */         appendJSonValue(writer, "startTime", (new Date(((Long)mBeanServer
/*  833 */               .getAttribute(objectName, "startTime")).longValue())).toString())
/*  834 */           .append(',');
/*  835 */         appendJSonValue(writer, "startupTime", mBeanServer.getAttribute(objectName, "startupTime")).append(',');
/*  836 */         appendJSonValue(writer, "tldScanTime", mBeanServer.getAttribute(objectName, "tldScanTime"));
/*  837 */         if (managerON != null) {
/*  838 */           writeManager(writer, managerON, mBeanServer, mode);
/*      */         }
/*  840 */         if (jspMonitorONs != null) {
/*  841 */           writeJspMonitor(writer, jspMonitorONs, mBeanServer, mode);
/*      */         }
/*  843 */         writer.append(',').println();
/*  844 */         indent(writer, 3).append('"').append("wrapper").append('"').append(':').append('[').println();
/*  845 */         String onStr = objectName.getDomain() + ":j2eeType=Servlet,WebModule=" + objectName.getDomain() + ",*";
/*  846 */         ObjectName servletObjectName = new ObjectName(onStr);
/*  847 */         Set<ObjectInstance> set = mBeanServer.queryMBeans(servletObjectName, null);
/*  848 */         boolean first = true;
/*  849 */         for (ObjectInstance oi : set) {
/*  850 */           if (first) {
/*  851 */             first = false;
/*      */           } else {
/*  853 */             writer.append(',').println();
/*      */           } 
/*  855 */           writeWrapper(writer, oi.getObjectName(), mBeanServer, mode);
/*      */         } 
/*  857 */         writer.println();
/*  858 */         indent(writer, 3).append(']').println();
/*  859 */         indent(writer, 2).append('}');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeManager(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode) throws Exception {
/*  878 */     if (mode == 0) {
/*  879 */       writer.print("<br>");
/*  880 */       writer.print(" Active sessions: ");
/*  881 */       writer.print(mBeanServer.getAttribute(objectName, "activeSessions"));
/*  882 */       writer.print(" Session count: ");
/*  883 */       writer.print(mBeanServer.getAttribute(objectName, "sessionCounter"));
/*  884 */       writer.print(" Max active sessions: ");
/*  885 */       writer.print(mBeanServer.getAttribute(objectName, "maxActive"));
/*  886 */       writer.print(" Rejected session creations: ");
/*  887 */       writer.print(mBeanServer.getAttribute(objectName, "rejectedSessions"));
/*  888 */       writer.print(" Expired sessions: ");
/*  889 */       writer.print(mBeanServer.getAttribute(objectName, "expiredSessions"));
/*  890 */       writer.print(" Longest session alive time: ");
/*  891 */       writer.print(formatSeconds(mBeanServer.getAttribute(objectName, "sessionMaxAliveTime")));
/*  892 */       writer.print(" Average session alive time: ");
/*  893 */       writer.print(formatSeconds(mBeanServer.getAttribute(objectName, "sessionAverageAliveTime")));
/*  894 */       writer.print(" Processing time: ");
/*  895 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "processingTime"), false));
/*  896 */     } else if (mode != 1) {
/*      */       
/*  898 */       if (mode == 2) {
/*  899 */         writer.append(',').println();
/*  900 */         indent(writer, 3).append('"').append("manager").append('"').append(':').append('{');
/*  901 */         appendJSonValue(writer, "activeSessions", mBeanServer.getAttribute(objectName, "activeSessions"))
/*  902 */           .append(',');
/*  903 */         appendJSonValue(writer, "sessionCounter", mBeanServer.getAttribute(objectName, "sessionCounter"))
/*  904 */           .append(',');
/*  905 */         appendJSonValue(writer, "maxActive", mBeanServer.getAttribute(objectName, "maxActive")).append(',');
/*  906 */         appendJSonValue(writer, "rejectedSessions", mBeanServer.getAttribute(objectName, "rejectedSessions"))
/*  907 */           .append(',');
/*  908 */         appendJSonValue(writer, "expiredSessions", mBeanServer.getAttribute(objectName, "expiredSessions"))
/*  909 */           .append(',');
/*  910 */         appendJSonValue(writer, "sessionMaxAliveTime", mBeanServer.getAttribute(objectName, "sessionMaxAliveTime"))
/*  911 */           .append(',');
/*  912 */         appendJSonValue(writer, "sessionAverageAliveTime", mBeanServer
/*  913 */             .getAttribute(objectName, "sessionAverageAliveTime")).append(',');
/*  914 */         appendJSonValue(writer, "processingTime", mBeanServer.getAttribute(objectName, "processingTime"));
/*  915 */         writer.append('}');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeJspMonitor(PrintWriter writer, Set<ObjectName> jspMonitorONs, MBeanServer mBeanServer, int mode) throws Exception {
/*  934 */     int jspCount = 0;
/*  935 */     int jspReloadCount = 0;
/*      */     
/*  937 */     for (ObjectName jspMonitorON : jspMonitorONs) {
/*  938 */       Object obj = mBeanServer.getAttribute(jspMonitorON, "jspCount");
/*  939 */       jspCount += ((Integer)obj).intValue();
/*  940 */       obj = mBeanServer.getAttribute(jspMonitorON, "jspReloadCount");
/*  941 */       jspReloadCount += ((Integer)obj).intValue();
/*      */     } 
/*      */     
/*  944 */     if (mode == 0) {
/*  945 */       writer.print("<br>");
/*  946 */       writer.print(" JSPs loaded: ");
/*  947 */       writer.print(jspCount);
/*  948 */       writer.print(" JSPs reloaded: ");
/*  949 */       writer.print(jspReloadCount);
/*  950 */     } else if (mode != 1) {
/*      */       
/*  952 */       if (mode == 2) {
/*  953 */         writer.append(',').println();
/*  954 */         indent(writer, 3).append('"').append("jsp").append('"').append(':').append('{');
/*  955 */         appendJSonValue(writer, "jspCount", Integer.valueOf(jspCount)).append(',');
/*  956 */         appendJSonValue(writer, "jspReloadCount", Integer.valueOf(jspReloadCount));
/*  957 */         writer.append('}');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeWrapper(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode) throws Exception {
/*  975 */     String servletName = objectName.getKeyProperty("name");
/*      */     
/*  977 */     String[] mappings = (String[])mBeanServer.invoke(objectName, "findMappings", null, null);
/*      */     
/*  979 */     if (mode == 0) {
/*  980 */       writer.print("<h2>");
/*  981 */       writer.print(Escape.htmlElementContent(servletName));
/*  982 */       if (mappings != null && mappings.length > 0) {
/*  983 */         writer.print(" [ ");
/*  984 */         for (int i = 0; i < mappings.length; i++) {
/*  985 */           writer.print(Escape.htmlElementContent(mappings[i]));
/*  986 */           if (i < mappings.length - 1) {
/*  987 */             writer.print(" , ");
/*      */           }
/*      */         } 
/*  990 */         writer.print(" ] ");
/*      */       } 
/*  992 */       writer.print("</h2>");
/*      */       
/*  994 */       writer.print("<p>");
/*  995 */       writer.print(" Processing time: ");
/*  996 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "processingTime"), true));
/*  997 */       writer.print(" Max time: ");
/*  998 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "maxTime"), false));
/*  999 */       writer.print(" Request count: ");
/* 1000 */       writer.print(mBeanServer.getAttribute(objectName, "requestCount"));
/* 1001 */       writer.print(" Error count: ");
/* 1002 */       writer.print(mBeanServer.getAttribute(objectName, "errorCount"));
/* 1003 */       writer.print(" Load time: ");
/* 1004 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "loadTime"), false));
/* 1005 */       writer.print(" Classloading time: ");
/* 1006 */       writer.print(formatTime(mBeanServer.getAttribute(objectName, "classLoadTime"), false));
/* 1007 */       writer.print("</p>");
/* 1008 */     } else if (mode != 1) {
/*      */       
/* 1010 */       if (mode == 2) {
/* 1011 */         indent(writer, 4).append('{');
/* 1012 */         appendJSonValue(writer, "servletName", JSONFilter.escape(servletName)).append(',');
/* 1013 */         appendJSonValue(writer, "processingTime", mBeanServer.getAttribute(objectName, "processingTime"))
/* 1014 */           .append(',');
/* 1015 */         appendJSonValue(writer, "maxTime", mBeanServer.getAttribute(objectName, "maxTime")).append(',');
/* 1016 */         appendJSonValue(writer, "requestCount", mBeanServer.getAttribute(objectName, "requestCount")).append(',');
/* 1017 */         appendJSonValue(writer, "errorCount", mBeanServer.getAttribute(objectName, "errorCount")).append(',');
/* 1018 */         appendJSonValue(writer, "loadTime", mBeanServer.getAttribute(objectName, "loadTime")).append(',');
/* 1019 */         appendJSonValue(writer, "classLoadTime", mBeanServer.getAttribute(objectName, "classLoadTime"));
/* 1020 */         writer.append('}');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatSize(Object obj, boolean mb) {
/* 1036 */     long bytes = -1L;
/*      */     
/* 1038 */     if (obj instanceof Long) {
/* 1039 */       bytes = ((Long)obj).longValue();
/* 1040 */     } else if (obj instanceof Integer) {
/* 1041 */       bytes = ((Integer)obj).intValue();
/*      */     } 
/*      */     
/* 1044 */     if (mb) {
/* 1045 */       StringBuilder buff = new StringBuilder();
/* 1046 */       if (bytes < 0L) {
/* 1047 */         buff.append('-');
/* 1048 */         bytes = -bytes;
/*      */       } 
/* 1050 */       long mbytes = bytes / 1048576L;
/* 1051 */       long rest = (bytes - mbytes * 1048576L) * 100L / 1048576L;
/* 1052 */       buff.append(mbytes).append('.');
/* 1053 */       if (rest < 10L) {
/* 1054 */         buff.append('0');
/*      */       }
/* 1056 */       buff.append(rest).append(" MiB");
/* 1057 */       return buff.toString();
/*      */     } 
/* 1059 */     return "" + bytes / 1024L + " KiB";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatTime(Object obj, boolean seconds) {
/* 1075 */     long time = -1L;
/*      */     
/* 1077 */     if (obj instanceof Long) {
/* 1078 */       time = ((Long)obj).longValue();
/* 1079 */     } else if (obj instanceof Integer) {
/* 1080 */       time = ((Integer)obj).intValue();
/*      */     } 
/*      */     
/* 1083 */     if (seconds) {
/* 1084 */       return "" + (float)time / 1000.0F + " s";
/*      */     }
/* 1086 */     return "" + time + " ms";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatSeconds(Object obj) {
/* 1100 */     long time = -1L;
/*      */     
/* 1102 */     if (obj instanceof Long) {
/* 1103 */       time = ((Long)obj).longValue();
/* 1104 */     } else if (obj instanceof Integer) {
/* 1105 */       time = ((Integer)obj).intValue();
/*      */     } 
/*      */     
/* 1108 */     return "" + time + " s";
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\StatusTransformer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */