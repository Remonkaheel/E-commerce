/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.manager.util.SessionUtils;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JspHelper
/*     */ {
/*     */   private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*     */   private static final int HIGHEST_SPECIAL = 62;
/*     */   
/*     */   public static String guessDisplayLocaleFromSession(Session in_session) {
/*  55 */     return localeToString(SessionUtils.guessLocaleFromSession(in_session));
/*     */   }
/*     */   
/*     */   private static String localeToString(Locale locale) {
/*  59 */     if (locale != null) {
/*  60 */       return escapeXml(locale.toString());
/*     */     }
/*  62 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String guessDisplayUserFromSession(Session in_session) {
/*  74 */     Object user = SessionUtils.guessUserFromSession(in_session);
/*  75 */     return escapeXml(user);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDisplayCreationTimeForSession(Session in_session) {
/*     */     try {
/*  81 */       if (in_session.getCreationTime() == 0L) {
/*  82 */         return "";
/*     */       }
/*  84 */       DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  85 */       return formatter.format(new Date(in_session.getCreationTime()));
/*  86 */     } catch (IllegalStateException ise) {
/*     */       
/*  88 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getDisplayLastAccessedTimeForSession(Session in_session) {
/*     */     try {
/*  94 */       if (in_session.getLastAccessedTime() == 0L) {
/*  95 */         return "";
/*     */       }
/*  97 */       DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  98 */       return formatter.format(new Date(in_session.getLastAccessedTime()));
/*  99 */     } catch (IllegalStateException ise) {
/*     */       
/* 101 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getDisplayUsedTimeForSession(Session in_session) {
/*     */     try {
/* 107 */       if (in_session.getCreationTime() == 0L) {
/* 108 */         return "";
/*     */       }
/* 110 */     } catch (IllegalStateException ise) {
/*     */       
/* 112 */       return "";
/*     */     } 
/* 114 */     return secondsToTimeString(SessionUtils.getUsedTimeForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String getDisplayTTLForSession(Session in_session) {
/*     */     try {
/* 119 */       if (in_session.getCreationTime() == 0L) {
/* 120 */         return "";
/*     */       }
/* 122 */     } catch (IllegalStateException ise) {
/*     */       
/* 124 */       return "";
/*     */     } 
/* 126 */     return secondsToTimeString(SessionUtils.getTTLForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String getDisplayInactiveTimeForSession(Session in_session) {
/*     */     try {
/* 131 */       if (in_session.getCreationTime() == 0L) {
/* 132 */         return "";
/*     */       }
/* 134 */     } catch (IllegalStateException ise) {
/*     */       
/* 136 */       return "";
/*     */     } 
/* 138 */     return secondsToTimeString(SessionUtils.getInactiveTimeForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String secondsToTimeString(long in_seconds) {
/* 142 */     StringBuilder buff = new StringBuilder(9);
/* 143 */     if (in_seconds < 0L) {
/* 144 */       buff.append('-');
/* 145 */       in_seconds = -in_seconds;
/*     */     } 
/* 147 */     long rest = in_seconds;
/* 148 */     long hour = rest / 3600L;
/* 149 */     rest %= 3600L;
/* 150 */     long minute = rest / 60L;
/* 151 */     rest %= 60L;
/* 152 */     long second = rest;
/* 153 */     if (hour < 10L) {
/* 154 */       buff.append('0');
/*     */     }
/* 156 */     buff.append(hour);
/* 157 */     buff.append(':');
/* 158 */     if (minute < 10L) {
/* 159 */       buff.append('0');
/*     */     }
/* 161 */     buff.append(minute);
/* 162 */     buff.append(':');
/* 163 */     if (second < 10L) {
/* 164 */       buff.append('0');
/*     */     }
/* 166 */     buff.append(second);
/* 167 */     return buff.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   private static final char[][] specialCharactersRepresentation = new char[63][];
/*     */   static {
/* 178 */     specialCharactersRepresentation[38] = "&amp;".toCharArray();
/* 179 */     specialCharactersRepresentation[60] = "&lt;".toCharArray();
/* 180 */     specialCharactersRepresentation[62] = "&gt;".toCharArray();
/* 181 */     specialCharactersRepresentation[34] = "&#034;".toCharArray();
/* 182 */     specialCharactersRepresentation[39] = "&#039;".toCharArray();
/*     */   }
/*     */   
/*     */   public static String escapeXml(Object obj) {
/* 186 */     String value = null;
/*     */     try {
/* 188 */       value = (obj == null) ? null : obj.toString();
/* 189 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 192 */     return escapeXml(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeXml(String buffer) {
/* 211 */     if (buffer == null) {
/* 212 */       return "";
/*     */     }
/*     */     
/* 215 */     return Escape.xml(buffer);
/*     */   }
/*     */   
/*     */   public static String formatNumber(long number) {
/* 219 */     return NumberFormat.getNumberInstance().format(number);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\JspHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */