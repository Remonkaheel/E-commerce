/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletInputStream;
/*      */ import jakarta.servlet.UnavailableException;
/*      */ import jakarta.servlet.http.HttpServlet;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.Binding;
/*      */ import javax.naming.Context;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.startup.ExpandWar;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*      */ import org.apache.tomcat.util.Diagnostics;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.net.SSLContext;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.net.SSLHostConfigCertificate;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ManagerServlet
/*      */   extends HttpServlet
/*      */   implements ContainerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  159 */   protected File configBase = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   protected transient Context context = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  171 */   protected int debug = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   protected File versioned = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   protected transient Host host = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   protected transient MBeanServer mBeanServer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   protected ObjectName oname = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   protected transient Context global = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  207 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  213 */   protected transient Wrapper wrapper = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Wrapper getWrapper() {
/*  221 */     return this.wrapper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWrapper(Wrapper wrapper) {
/*  228 */     this.wrapper = wrapper;
/*  229 */     if (wrapper == null) {
/*  230 */       this.context = null;
/*  231 */       this.host = null;
/*  232 */       this.oname = null;
/*      */     } else {
/*  234 */       this.context = (Context)wrapper.getParent();
/*  235 */       this.host = (Host)this.context.getParent();
/*  236 */       Engine engine = (Engine)this.host.getParent();
/*  237 */       String name = engine.getName() + ":type=Deployer,host=" + engine.getName();
/*      */       try {
/*  239 */         this.oname = new ObjectName(name);
/*  240 */       } catch (Exception e) {
/*  241 */         log(sm.getString("managerServlet.objectNameFail", new Object[] { name }), e);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  246 */     this.mBeanServer = Registry.getRegistry(null).getMBeanServer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*  265 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */ 
/*      */     
/*  268 */     String command = request.getPathInfo();
/*  269 */     if (command == null) {
/*  270 */       command = request.getServletPath();
/*      */     }
/*      */     
/*  273 */     String path = request.getParameter("path");
/*  274 */     String war = request.getParameter("war");
/*  275 */     String config = request.getParameter("config");
/*  276 */     ContextName cn = null;
/*  277 */     if (path != null) {
/*  278 */       cn = new ContextName(path, request.getParameter("version"));
/*  279 */     } else if (config != null) {
/*  280 */       cn = ContextName.extractFromPath(config);
/*  281 */     } else if (war != null) {
/*  282 */       cn = ContextName.extractFromPath(war);
/*      */     } 
/*      */     
/*  285 */     String type = request.getParameter("type");
/*  286 */     String tag = request.getParameter("tag");
/*  287 */     boolean update = (request.getParameter("update") != null && request.getParameter("update").equals("true"));
/*  288 */     String tlsHostName = request.getParameter("tlsHostName");
/*      */     
/*  290 */     boolean statusLine = "true".equals(request.getParameter("statusLine"));
/*      */ 
/*      */     
/*  293 */     response.setContentType("text/plain; charset=utf-8");
/*      */ 
/*      */ 
/*      */     
/*  297 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  298 */     PrintWriter writer = response.getWriter();
/*      */ 
/*      */     
/*  301 */     if (command == null) {
/*  302 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  303 */     } else if (command.equals("/deploy")) {
/*  304 */       if (war != null || config != null) {
/*  305 */         deploy(writer, config, cn, war, update, smClient);
/*  306 */       } else if (tag != null) {
/*  307 */         deploy(writer, cn, tag, smClient);
/*      */       } else {
/*  309 */         writer.println(smClient.getString("managerServlet.invalidCommand", new Object[] { command }));
/*      */       } 
/*  311 */     } else if (command.equals("/list")) {
/*  312 */       list(writer, smClient);
/*  313 */     } else if (command.equals("/reload")) {
/*  314 */       reload(writer, cn, smClient);
/*  315 */     } else if (command.equals("/resources")) {
/*  316 */       resources(writer, type, smClient);
/*  317 */     } else if (command.equals("/save")) {
/*  318 */       save(writer, path, smClient);
/*  319 */     } else if (command.equals("/serverinfo")) {
/*  320 */       serverinfo(writer, smClient);
/*  321 */     } else if (command.equals("/sessions")) {
/*  322 */       expireSessions(writer, cn, request, smClient);
/*  323 */     } else if (command.equals("/expire")) {
/*  324 */       expireSessions(writer, cn, request, smClient);
/*  325 */     } else if (command.equals("/start")) {
/*  326 */       start(writer, cn, smClient);
/*  327 */     } else if (command.equals("/stop")) {
/*  328 */       stop(writer, cn, smClient);
/*  329 */     } else if (command.equals("/undeploy")) {
/*  330 */       undeploy(writer, cn, smClient);
/*  331 */     } else if (command.equals("/findleaks")) {
/*  332 */       findleaks(statusLine, writer, smClient);
/*  333 */     } else if (command.equals("/vminfo")) {
/*  334 */       vmInfo(writer, smClient, request.getLocales());
/*  335 */     } else if (command.equals("/threaddump")) {
/*  336 */       threadDump(writer, smClient, request.getLocales());
/*  337 */     } else if (command.equals("/sslConnectorCiphers")) {
/*  338 */       sslConnectorCiphers(writer, smClient);
/*  339 */     } else if (command.equals("/sslConnectorCerts")) {
/*  340 */       sslConnectorCerts(writer, smClient);
/*  341 */     } else if (command.equals("/sslConnectorTrustedCerts")) {
/*  342 */       sslConnectorTrustedCerts(writer, smClient);
/*  343 */     } else if (command.equals("/sslReload")) {
/*  344 */       sslReload(writer, tlsHostName, smClient);
/*      */     } else {
/*  346 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     } 
/*      */ 
/*      */     
/*  350 */     writer.flush();
/*  351 */     writer.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*  359 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request.getLocales());
/*      */ 
/*      */     
/*  362 */     String command = request.getPathInfo();
/*  363 */     if (command == null) {
/*  364 */       command = request.getServletPath();
/*      */     }
/*  366 */     String path = request.getParameter("path");
/*  367 */     ContextName cn = null;
/*  368 */     if (path != null) {
/*  369 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*  371 */     String config = request.getParameter("config");
/*  372 */     String tag = request.getParameter("tag");
/*  373 */     boolean update = (request.getParameter("update") != null && request.getParameter("update").equals("true"));
/*      */ 
/*      */     
/*  376 */     response.setContentType("text/plain;charset=utf-8");
/*      */ 
/*      */ 
/*      */     
/*  380 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  381 */     PrintWriter writer = response.getWriter();
/*      */ 
/*      */     
/*  384 */     if (command == null) {
/*  385 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  386 */     } else if (command.equals("/deploy")) {
/*  387 */       deploy(writer, config, cn, tag, update, request, smClient);
/*      */     } else {
/*  389 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     } 
/*      */ 
/*      */     
/*  393 */     writer.flush();
/*  394 */     writer.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() throws ServletException {
/*      */     Context context2, context3;
/*  403 */     if (this.wrapper == null || this.context == null) {
/*  404 */       throw new UnavailableException(sm.getString("managerServlet.noWrapper"));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  410 */       String value = getServletConfig().getInitParameter("debug");
/*  411 */       this.debug = Integer.parseInt(value);
/*  412 */     } catch (Throwable t) {
/*  413 */       ExceptionUtils.handleThrowable(t);
/*      */     } 
/*      */ 
/*      */     
/*  417 */     Server server = ((Engine)this.host.getParent()).getService().getServer();
/*  418 */     if (server != null) {
/*  419 */       this.global = server.getGlobalNamingContext();
/*      */     }
/*      */ 
/*      */     
/*  423 */     this.versioned = (File)getServletContext().getAttribute("jakarta.servlet.context.tempdir");
/*      */     
/*  425 */     this.configBase = new File(this.context.getCatalinaBase(), "conf");
/*  426 */     Context context1 = this.context;
/*  427 */     Container host = null;
/*  428 */     Container engine = null;
/*  429 */     while (context1 != null) {
/*  430 */       if (context1 instanceof Host) {
/*  431 */         context2 = context1;
/*      */       }
/*  433 */       if (context1 instanceof Engine) {
/*  434 */         context3 = context1;
/*      */       }
/*  436 */       Container container = context1.getParent();
/*      */     } 
/*  438 */     if (context3 != null) {
/*  439 */       this.configBase = new File(this.configBase, context3.getName());
/*      */     }
/*  441 */     if (context2 != null) {
/*  442 */       this.configBase = new File(this.configBase, context2.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  447 */     if (this.debug >= 1) {
/*  448 */       log("init: Associated with Deployer '" + String.valueOf(this.oname) + "'");
/*  449 */       if (this.global != null) {
/*  450 */         log("init: Global resources are available");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void findleaks(boolean statusLine, PrintWriter writer, StringManager smClient) {
/*  469 */     if (!(this.host instanceof StandardHost)) {
/*  470 */       writer.println(smClient.getString("managerServlet.findleaksFail"));
/*      */       
/*      */       return;
/*      */     } 
/*  474 */     String[] results = ((StandardHost)this.host).findReloadedContextMemoryLeaks();
/*      */     
/*  476 */     if (results.length > 0) {
/*  477 */       if (statusLine) {
/*  478 */         writer.println(smClient.getString("managerServlet.findleaksList"));
/*      */       }
/*  480 */       for (String result : results) {
/*  481 */         if (result.isEmpty()) {
/*  482 */           result = "/";
/*      */         }
/*  484 */         writer.println(result);
/*      */       } 
/*  486 */     } else if (statusLine) {
/*  487 */       writer.println(smClient.getString("managerServlet.findleaksNone"));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void sslReload(PrintWriter writer, String tlsHostName, StringManager smClient) {
/*  493 */     Connector[] connectors = getConnectors();
/*  494 */     boolean found = false;
/*  495 */     for (Connector connector : connectors) {
/*  496 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/*  497 */         ProtocolHandler protocol = connector.getProtocolHandler();
/*  498 */         if (protocol instanceof AbstractHttp11Protocol) {
/*  499 */           AbstractHttp11Protocol<?> http11Protoocol = (AbstractHttp11Protocol)protocol;
/*  500 */           if (tlsHostName == null || tlsHostName.isEmpty()) {
/*  501 */             found = true;
/*  502 */             http11Protoocol.reloadSslHostConfigs();
/*      */           } else {
/*  504 */             SSLHostConfig[] sslHostConfigs = http11Protoocol.findSslHostConfigs();
/*  505 */             for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/*      */ 
/*      */               
/*  508 */               if (sslHostConfig.getHostName().equalsIgnoreCase(tlsHostName)) {
/*  509 */                 found = true;
/*  510 */                 http11Protoocol.reloadSslHostConfig(tlsHostName);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  517 */     if (found) {
/*  518 */       if (tlsHostName == null || tlsHostName.isEmpty()) {
/*  519 */         writer.println(smClient.getString("managerServlet.sslReloadAll"));
/*      */       } else {
/*  521 */         writer.println(smClient.getString("managerServlet.sslReload", new Object[] { tlsHostName }));
/*      */       } 
/*      */     } else {
/*  524 */       writer.println(smClient.getString("managerServlet.sslReloadFail"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void vmInfo(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales) {
/*  537 */     writer.println(smClient.getString("managerServlet.vminfo"));
/*  538 */     writer.print(Diagnostics.getVMInfo(requestedLocales));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void threadDump(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales) {
/*  549 */     writer.println(smClient.getString("managerServlet.threaddump"));
/*  550 */     writer.print(Diagnostics.getThreadDump(requestedLocales));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void sslConnectorCiphers(PrintWriter writer, StringManager smClient) {
/*  555 */     writer.println(smClient.getString("managerServlet.sslConnectorCiphers"));
/*  556 */     Map<String, List<String>> connectorCiphers = getConnectorCiphers(smClient);
/*  557 */     for (Map.Entry<String, List<String>> entry : connectorCiphers.entrySet()) {
/*  558 */       writer.println(entry.getKey());
/*  559 */       for (String cipher : entry.getValue()) {
/*  560 */         writer.print("  ");
/*  561 */         writer.println(cipher);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void sslConnectorCerts(PrintWriter writer, StringManager smClient) {
/*  568 */     writer.println(smClient.getString("managerServlet.sslConnectorCerts"));
/*  569 */     Map<String, List<String>> connectorCerts = getConnectorCerts(smClient);
/*  570 */     for (Map.Entry<String, List<String>> entry : connectorCerts.entrySet()) {
/*  571 */       writer.println(entry.getKey());
/*  572 */       for (String cert : entry.getValue()) {
/*  573 */         writer.println(cert);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void sslConnectorTrustedCerts(PrintWriter writer, StringManager smClient) {
/*  580 */     writer.println(smClient.getString("managerServlet.sslConnectorTrustedCerts"));
/*  581 */     Map<String, List<String>> connectorTrustedCerts = getConnectorTrustedCerts(smClient);
/*  582 */     for (Map.Entry<String, List<String>> entry : connectorTrustedCerts.entrySet()) {
/*  583 */       writer.println(entry.getKey());
/*  584 */       for (String cert : entry.getValue()) {
/*  585 */         writer.println(cert);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void save(PrintWriter writer, String path, StringManager smClient) {
/*      */     ObjectName storeConfigOname;
/*      */     try {
/*  603 */       storeConfigOname = new ObjectName("Catalina:type=StoreConfig");
/*  604 */     } catch (MalformedObjectNameException e) {
/*      */       
/*  606 */       log(sm.getString("managerServlet.exception"), e);
/*  607 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       
/*      */       return;
/*      */     } 
/*  611 */     if (!this.mBeanServer.isRegistered(storeConfigOname)) {
/*  612 */       writer.println(smClient.getString("managerServlet.storeConfig.noMBean", new Object[] { storeConfigOname }));
/*      */       
/*      */       return;
/*      */     } 
/*  616 */     if (path == null || !path.startsWith("/")) {
/*      */       try {
/*  618 */         this.mBeanServer.invoke(storeConfigOname, "storeConfig", null, null);
/*  619 */         writer.println(smClient.getString("managerServlet.saved"));
/*  620 */       } catch (Exception e) {
/*  621 */         log(sm.getString("managerServlet.error.storeConfig"), e);
/*  622 */         writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       } 
/*      */     } else {
/*  625 */       String contextPath = path;
/*  626 */       if (path.equals("/")) {
/*  627 */         contextPath = "";
/*      */       }
/*  629 */       Context context = (Context)this.host.findChild(contextPath);
/*  630 */       if (context == null) {
/*  631 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { path }));
/*      */         return;
/*      */       } 
/*      */       try {
/*  635 */         Boolean result = (Boolean)this.mBeanServer.invoke(storeConfigOname, "store", new Object[] { context }, new String[] { "org.apache.catalina.Context" });
/*      */         
/*  637 */         if (result.booleanValue()) {
/*  638 */           writer.println(smClient.getString("managerServlet.savedContext", new Object[] { path }));
/*      */         } else {
/*  640 */           writer.println(smClient.getString("managerServlet.savedContextFail", new Object[] { path }));
/*      */         } 
/*  642 */       } catch (Exception e) {
/*  643 */         log(sm.getString("managerServlet.error.storeContextConfig", new Object[] { path }), e);
/*  644 */         writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deploy(PrintWriter writer, String config, ContextName cn, String tag, boolean update, HttpServletRequest request, StringManager smClient) {
/*      */     File uploadedWar;
/*  664 */     if (config != null && config.isEmpty()) {
/*  665 */       config = null;
/*      */     }
/*      */     
/*  668 */     if (this.debug >= 1) {
/*  669 */       if (config == null) {
/*  670 */         log("deploy: Deploying web application '" + String.valueOf(cn) + "'");
/*      */       } else {
/*  672 */         log("deploy: Deploying web application '" + String.valueOf(cn) + "' with context configuration at '" + config + "'");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  678 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*  681 */     String name = cn.getName();
/*  682 */     String baseName = cn.getBaseName();
/*  683 */     String displayPath = cn.getDisplayName();
/*      */ 
/*      */ 
/*      */     
/*  687 */     Context context = (Context)this.host.findChild(name);
/*  688 */     if (context != null && !update) {
/*  689 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*      */       return;
/*      */     } 
/*  693 */     if (config != null && config.startsWith("file:")) {
/*  694 */       config = config.substring("file:".length());
/*      */     }
/*      */     
/*  697 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */ 
/*      */ 
/*      */     
/*  701 */     if (tag == null) {
/*  702 */       if (update) {
/*      */ 
/*      */ 
/*      */         
/*  706 */         uploadedWar = new File(deployedWar.getAbsolutePath() + ".tmp");
/*  707 */         if (uploadedWar.exists() && !uploadedWar.delete()) {
/*  708 */           writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { uploadedWar }));
/*      */         }
/*      */       } else {
/*  711 */         uploadedWar = deployedWar;
/*      */       } 
/*      */     } else {
/*  714 */       File uploadPath = new File(this.versioned, tag);
/*  715 */       if (!uploadPath.mkdirs() && !uploadPath.isDirectory()) {
/*  716 */         writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { uploadPath }));
/*      */         return;
/*      */       } 
/*  719 */       uploadedWar = new File(uploadPath, baseName + ".war");
/*      */     } 
/*  721 */     if (this.debug >= 2) {
/*  722 */       log("Uploading WAR file to " + String.valueOf(uploadedWar));
/*      */     }
/*      */     
/*      */     try {
/*  726 */       if (tryAddServiced(name)) {
/*      */         try {
/*  728 */           if (config != null) {
/*  729 */             if (!this.configBase.mkdirs() && !this.configBase.isDirectory()) {
/*  730 */               writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { this.configBase }));
/*      */               return;
/*      */             } 
/*  733 */             if (!ExpandWar.copy(new File(config), new File(this.configBase, baseName + ".xml"))) {
/*  734 */               writer.println(smClient.getString("managerServlet.copyFail", new Object[] { new File(config), new File(this.configBase, baseName + ".xml") }));
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */           
/*  740 */           uploadWar(writer, request, uploadedWar, smClient);
/*  741 */           if (update && tag == null) {
/*  742 */             if (deployedWar.exists() && !deployedWar.delete()) {
/*  743 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar }));
/*      */               
/*      */               return;
/*      */             } 
/*  747 */             if (!uploadedWar.renameTo(deployedWar)) {
/*  748 */               writer.println(smClient.getString("managerServlet.renameFail", new Object[] { uploadedWar, deployedWar }));
/*      */               return;
/*      */             } 
/*      */           } 
/*  752 */           if (tag != null)
/*      */           {
/*  754 */             if (!ExpandWar.copy(uploadedWar, deployedWar)) {
/*  755 */               writer.println(smClient.getString("managerServlet.copyFail", new Object[] { uploadedWar, deployedWar }));
/*      */               return;
/*      */             } 
/*      */           }
/*      */         } finally {
/*  760 */           removeServiced(name);
/*      */         } 
/*      */         
/*  763 */         check(name);
/*      */       } else {
/*  765 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } 
/*  767 */     } catch (Exception e) {
/*  768 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), e);
/*  769 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       
/*      */       return;
/*      */     } 
/*  773 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deploy(PrintWriter writer, ContextName cn, String tag, StringManager smClient) {
/*  790 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/*  794 */     String baseName = cn.getBaseName();
/*  795 */     String name = cn.getName();
/*  796 */     String displayPath = cn.getDisplayName();
/*      */ 
/*      */     
/*  799 */     File localWar = new File(new File(this.versioned, tag), baseName + ".war");
/*      */     
/*  801 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */ 
/*      */     
/*      */     try {
/*  805 */       if (tryAddServiced(name)) {
/*      */         try {
/*  807 */           if (!deployedWar.delete()) {
/*  808 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar }));
/*      */             return;
/*      */           } 
/*  811 */           if (!ExpandWar.copy(localWar, deployedWar)) {
/*  812 */             writer.println(smClient.getString("managerServlet.copyFail", new Object[] { localWar, deployedWar }));
/*      */             return;
/*      */           } 
/*      */         } finally {
/*  816 */           removeServiced(name);
/*      */         } 
/*      */         
/*  819 */         check(name);
/*      */       } else {
/*  821 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } 
/*  823 */     } catch (Exception e) {
/*  824 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), e);
/*  825 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() }));
/*      */       
/*      */       return;
/*      */     } 
/*  829 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deploy(PrintWriter writer, String config, ContextName cn, String war, boolean update, StringManager smClient) {
/*  846 */     if (config != null && config.isEmpty()) {
/*  847 */       config = null;
/*      */     }
/*  849 */     if (war != null && war.isEmpty()) {
/*  850 */       war = null;
/*      */     }
/*      */     
/*  853 */     if (this.debug >= 1) {
/*  854 */       if (config != null) {
/*  855 */         if (war != null) {
/*  856 */           log("install: Installing context configuration at '" + config + "' from '" + war + "'");
/*      */         } else {
/*  858 */           log("install: Installing context configuration at '" + config + "'");
/*      */         }
/*      */       
/*  861 */       } else if (cn != null) {
/*  862 */         log("install: Installing web application '" + String.valueOf(cn) + "' from '" + war + "'");
/*      */       } else {
/*  864 */         log("install: Installing web application from '" + war + "'");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  869 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/*  873 */     String name = cn.getName();
/*  874 */     String baseName = cn.getBaseName();
/*  875 */     String displayPath = cn.getDisplayName();
/*      */ 
/*      */ 
/*      */     
/*  879 */     Context context = (Context)this.host.findChild(name);
/*  880 */     if (context != null && !update) {
/*  881 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*      */       return;
/*      */     } 
/*  885 */     if (config != null && config.startsWith("file:")) {
/*  886 */       config = config.substring("file:".length());
/*      */     }
/*  888 */     if (war != null && war.startsWith("file:")) {
/*  889 */       war = war.substring("file:".length());
/*      */     }
/*      */     
/*      */     try {
/*  893 */       if (tryAddServiced(name)) {
/*      */         try {
/*  895 */           if (config != null) {
/*  896 */             if (!this.configBase.mkdirs() && !this.configBase.isDirectory()) {
/*  897 */               writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { this.configBase }));
/*      */               return;
/*      */             } 
/*  900 */             File localConfigFile = new File(this.configBase, baseName + ".xml");
/*  901 */             File configFile = new File(config);
/*      */             
/*  903 */             if (!configFile.getCanonicalPath().equals(localConfigFile.getCanonicalPath())) {
/*  904 */               if (localConfigFile.isFile() && !localConfigFile.delete()) {
/*  905 */                 writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localConfigFile }));
/*      */                 return;
/*      */               } 
/*  908 */               if (!ExpandWar.copy(configFile, localConfigFile)) {
/*  909 */                 writer.println(smClient
/*  910 */                     .getString("managerServlet.copyFail", new Object[] { configFile, localConfigFile }));
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*  915 */           if (war != null) {
/*      */             File localWarFile;
/*  917 */             if (war.endsWith(".war")) {
/*  918 */               localWarFile = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */             } else {
/*  920 */               localWarFile = new File(this.host.getAppBaseFile(), baseName);
/*      */             } 
/*  922 */             File warFile = new File(war);
/*  923 */             if (!warFile.isAbsolute()) {
/*  924 */               warFile = new File(this.host.getAppBaseFile(), war);
/*      */             }
/*      */             
/*  927 */             if (!warFile.getCanonicalPath().equals(localWarFile.getCanonicalPath())) {
/*  928 */               if (localWarFile.exists() && !ExpandWar.delete(localWarFile)) {
/*  929 */                 writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localWarFile }));
/*      */                 return;
/*      */               } 
/*  932 */               if (!ExpandWar.copy(warFile, localWarFile)) {
/*  933 */                 writer.println(smClient.getString("managerServlet.copyFail", new Object[] { warFile, localWarFile }));
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } finally {
/*  939 */           removeServiced(name);
/*      */         } 
/*      */         
/*  942 */         check(name);
/*      */       } else {
/*  944 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } 
/*  946 */       writeDeployResult(writer, smClient, name, displayPath);
/*  947 */     } catch (Throwable t) {
/*  948 */       ExceptionUtils.handleThrowable(t);
/*  949 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), t);
/*  950 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeDeployResult(PrintWriter writer, StringManager smClient, String name, String displayPath) {
/*  957 */     Context deployed = (Context)this.host.findChild(name);
/*  958 */     if (deployed != null && deployed.getConfigured() && deployed.getState().isAvailable()) {
/*  959 */       writer.println(smClient.getString("managerServlet.deployed", new Object[] { displayPath }));
/*  960 */     } else if (deployed != null && !deployed.getState().isAvailable()) {
/*  961 */       writer.println(smClient.getString("managerServlet.deployedButNotStarted", new Object[] { displayPath }));
/*      */     } else {
/*      */       
/*  964 */       writer.println(smClient.getString("managerServlet.deployFailed", new Object[] { displayPath }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void list(PrintWriter writer, StringManager smClient) {
/*  977 */     if (this.debug >= 1) {
/*  978 */       log("list: Listing contexts for virtual host '" + this.host.getName() + "'");
/*      */     }
/*      */     
/*  981 */     writer.println(smClient.getString("managerServlet.listed", new Object[] { this.host.getName() }));
/*  982 */     Container[] contexts = this.host.findChildren();
/*  983 */     for (Container container : contexts) {
/*  984 */       Context context = (Context)container;
/*  985 */       if (context != null) {
/*  986 */         List<String> parts; String displayPath = context.getPath();
/*  987 */         if (displayPath.isEmpty()) {
/*  988 */           displayPath = "/";
/*      */         }
/*      */         
/*  991 */         if (context.getState().isAvailable()) {
/*  992 */           parts = Arrays.asList(new String[] { displayPath, "running", "" + (context.getManager().findSessions()).length, context
/*  993 */                 .getDocBase() });
/*      */         } else {
/*  995 */           parts = Arrays.asList(new String[] { displayPath, "stopped", "0", context.getDocBase() });
/*      */         } 
/*  997 */         writer.println(StringUtils.join(parts, ':'));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reload(PrintWriter writer, ContextName cn, StringManager smClient) {
/* 1012 */     if (this.debug >= 1) {
/* 1013 */       log("restart: Reloading web application '" + String.valueOf(cn) + "'");
/*      */     }
/*      */     
/* 1016 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/* 1021 */       Context context = (Context)this.host.findChild(cn.getName());
/* 1022 */       if (context == null) {
/* 1023 */         writer.println(smClient
/* 1024 */             .getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(cn.getDisplayName()) }));
/*      */         
/*      */         return;
/*      */       } 
/* 1028 */       if (context.getName().equals(this.context.getName())) {
/* 1029 */         writer.println(smClient.getString("managerServlet.noSelf"));
/*      */         return;
/*      */       } 
/* 1032 */       context.reload();
/* 1033 */       writer.println(smClient.getString("managerServlet.reloaded", new Object[] { cn.getDisplayName() }));
/* 1034 */     } catch (Throwable t) {
/* 1035 */       ExceptionUtils.handleThrowable(t);
/* 1036 */       log(sm.getString("managerServlet.error.reload", new Object[] { cn.getDisplayName() }), t);
/* 1037 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resources(PrintWriter writer, String type, StringManager smClient) {
/* 1053 */     if (this.debug >= 1) {
/* 1054 */       if (type != null) {
/* 1055 */         log("resources:  Listing resources of type " + type);
/*      */       } else {
/* 1057 */         log("resources:  Listing resources of all types");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1062 */     if (this.global == null) {
/* 1063 */       writer.println(smClient.getString("managerServlet.noGlobal"));
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1068 */     if (type != null) {
/* 1069 */       writer.println(smClient.getString("managerServlet.resourcesType", new Object[] { type }));
/*      */     } else {
/* 1071 */       writer.println(smClient.getString("managerServlet.resourcesAll"));
/*      */     } 
/*      */     
/* 1074 */     printResources(writer, "", this.global, type, smClient);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printResources(PrintWriter writer, String prefix, Context namingContext, String type, StringManager smClient) {
/*      */     try {
/* 1092 */       NamingEnumeration<Binding> items = namingContext.listBindings("");
/* 1093 */       while (items.hasMore()) {
/* 1094 */         Binding item = items.next();
/* 1095 */         Object obj = item.getObject();
/* 1096 */         if (obj instanceof Context) {
/* 1097 */           printResources(writer, prefix + prefix + "/", (Context)obj, type, smClient); continue;
/*      */         } 
/* 1099 */         if (type != null && (obj == null || !IntrospectionUtils.isInstance(obj.getClass(), type))) {
/*      */           continue;
/*      */         }
/* 1102 */         writer.print(prefix + prefix);
/* 1103 */         writer.print(':');
/* 1104 */         writer.print(item.getClassName());
/*      */         
/* 1106 */         writer.println();
/*      */       }
/*      */     
/* 1109 */     } catch (Throwable t) {
/* 1110 */       ExceptionUtils.handleThrowable(t);
/* 1111 */       log(sm.getString("managerServlet.error.resources", new Object[] { type }), t);
/* 1112 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void serverinfo(PrintWriter writer, StringManager smClient) {
/* 1124 */     if (this.debug >= 1) {
/* 1125 */       log("serverinfo");
/*      */     }
/*      */     try {
/* 1128 */       writer.println(smClient.getString("managerServlet.serverInfo", new Object[] { ServerInfo.getServerInfo(), 
/* 1129 */               System.getProperty("os.name"), System.getProperty("os.version"), System.getProperty("os.arch"), 
/* 1130 */               System.getProperty("java.runtime.version"), System.getProperty("java.vm.vendor") }));
/* 1131 */     } catch (Throwable t) {
/* 1132 */       ExceptionUtils.handleThrowable(t);
/* 1133 */       log(sm.getString("managerServlet.error.serverInfo"), t);
/* 1134 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sessions(PrintWriter writer, ContextName cn, int idle, StringManager smClient) {
/* 1149 */     if (this.debug >= 1) {
/* 1150 */       log("sessions: Session information for web application '" + String.valueOf(cn) + "'");
/* 1151 */       if (idle >= 0) {
/* 1152 */         log("sessions: Session expiration for " + idle + " minutes '" + String.valueOf(cn) + "'");
/*      */       }
/*      */     } 
/*      */     
/* 1156 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/* 1160 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */     try {
/* 1163 */       Context context = (Context)this.host.findChild(cn.getName());
/* 1164 */       if (context == null) {
/* 1165 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         return;
/*      */       } 
/* 1168 */       Manager manager = context.getManager();
/* 1169 */       if (manager == null) {
/* 1170 */         writer.println(smClient.getString("managerServlet.noManager", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         return;
/*      */       } 
/* 1173 */       int maxCount = 60;
/* 1174 */       int histoInterval = 1;
/* 1175 */       int maxInactiveInterval = context.getSessionTimeout();
/* 1176 */       if (maxInactiveInterval > 0) {
/* 1177 */         histoInterval = maxInactiveInterval / maxCount;
/* 1178 */         if (histoInterval * maxCount < maxInactiveInterval) {
/* 1179 */           histoInterval++;
/*      */         }
/* 1181 */         if (0 == histoInterval) {
/* 1182 */           histoInterval = 1;
/*      */         }
/* 1184 */         maxCount = maxInactiveInterval / histoInterval;
/* 1185 */         if (histoInterval * maxCount < maxInactiveInterval) {
/* 1186 */           maxCount++;
/*      */         }
/*      */       } 
/*      */       
/* 1190 */       writer.println(smClient.getString("managerServlet.sessions", new Object[] { displayPath }));
/* 1191 */       writer.println(smClient.getString("managerServlet.sessiondefaultmax", new Object[] { "" + maxInactiveInterval }));
/* 1192 */       Session[] sessions = manager.findSessions();
/* 1193 */       int[] timeout = new int[maxCount + 1];
/* 1194 */       int notimeout = 0;
/* 1195 */       int expired = 0;
/* 1196 */       for (Session session : sessions) {
/* 1197 */         int time = (int)(session.getIdleTimeInternal() / 1000L);
/* 1198 */         if (idle >= 0 && time >= idle * 60) {
/* 1199 */           session.expire();
/* 1200 */           expired++;
/*      */         } 
/* 1202 */         time = time / 60 / histoInterval;
/* 1203 */         if (time < 0) {
/* 1204 */           notimeout++;
/* 1205 */         } else if (time >= maxCount) {
/* 1206 */           timeout[maxCount] = timeout[maxCount] + 1;
/*      */         } else {
/* 1208 */           timeout[time] = timeout[time] + 1;
/*      */         } 
/*      */       } 
/* 1211 */       if (timeout[0] > 0) {
/* 1212 */         writer.println(smClient
/* 1213 */             .getString("managerServlet.sessiontimeout", new Object[] { "<" + histoInterval, "" + timeout[0] }));
/*      */       }
/* 1215 */       for (int i = 1; i < maxCount; i++) {
/* 1216 */         if (timeout[i] > 0) {
/* 1217 */           writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { "" + i * histoInterval + " - <" + i * histoInterval, "" + timeout[i] }));
/*      */         }
/*      */       } 
/*      */       
/* 1221 */       if (timeout[maxCount] > 0) {
/* 1222 */         writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { ">=" + maxCount * histoInterval, "" + timeout[maxCount] }));
/*      */       }
/*      */       
/* 1225 */       if (notimeout > 0) {
/* 1226 */         writer.println(smClient.getString("managerServlet.sessiontimeout.unlimited", new Object[] { "" + notimeout }));
/*      */       }
/* 1228 */       if (idle >= 0) {
/* 1229 */         writer.println(smClient.getString("managerServlet.sessiontimeout.expired", new Object[] { ">" + idle, "" + expired }));
/*      */       }
/* 1231 */     } catch (Throwable t) {
/* 1232 */       ExceptionUtils.handleThrowable(t);
/* 1233 */       log(sm.getString("managerServlet.error.sessions", new Object[] { displayPath }), t);
/* 1234 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void expireSessions(PrintWriter writer, ContextName cn, HttpServletRequest req, StringManager smClient) {
/* 1249 */     int idle = -1;
/* 1250 */     String idleParam = req.getParameter("idle");
/* 1251 */     if (idleParam != null) {
/*      */       try {
/* 1253 */         idle = Integer.parseInt(idleParam);
/* 1254 */       } catch (NumberFormatException e) {
/* 1255 */         log(sm.getString("managerServlet.error.idleParam", new Object[] { idleParam }));
/*      */       } 
/*      */     }
/* 1258 */     sessions(writer, cn, idle, smClient);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void start(PrintWriter writer, ContextName cn, StringManager smClient) {
/* 1270 */     if (this.debug >= 1) {
/* 1271 */       log("start: Starting web application '" + String.valueOf(cn) + "'");
/*      */     }
/*      */     
/* 1274 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/* 1278 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */     try {
/* 1281 */       Context context = (Context)this.host.findChild(cn.getName());
/* 1282 */       if (context == null) {
/* 1283 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         return;
/*      */       } 
/* 1286 */       context.start();
/* 1287 */       if (context.getState().isAvailable()) {
/* 1288 */         writer.println(smClient.getString("managerServlet.started", new Object[] { displayPath }));
/*      */       } else {
/* 1290 */         writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/*      */       } 
/* 1292 */     } catch (Throwable t) {
/* 1293 */       ExceptionUtils.handleThrowable(t);
/* 1294 */       log(sm.getString("managerServlet.error.start", new Object[] { displayPath }), t);
/* 1295 */       writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/* 1296 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stop(PrintWriter writer, ContextName cn, StringManager smClient) {
/* 1311 */     if (this.debug >= 1) {
/* 1312 */       log("stop: Stopping web application '" + String.valueOf(cn) + "'");
/*      */     }
/*      */     
/* 1315 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/* 1319 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */     try {
/* 1322 */       Context context = (Context)this.host.findChild(cn.getName());
/* 1323 */       if (context == null) {
/* 1324 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         
/*      */         return;
/*      */       } 
/* 1328 */       if (context.getName().equals(this.context.getName())) {
/* 1329 */         writer.println(smClient.getString("managerServlet.noSelf"));
/*      */         return;
/*      */       } 
/* 1332 */       context.stop();
/* 1333 */       writer.println(smClient.getString("managerServlet.stopped", new Object[] { displayPath }));
/* 1334 */     } catch (Throwable t) {
/* 1335 */       ExceptionUtils.handleThrowable(t);
/* 1336 */       log(sm.getString("managerServlet.error.stop", new Object[] { displayPath }), t);
/* 1337 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void undeploy(PrintWriter writer, ContextName cn, StringManager smClient) {
/* 1352 */     if (this.debug >= 1) {
/* 1353 */       log("undeploy: Undeploying web application at '" + String.valueOf(cn) + "'");
/*      */     }
/*      */     
/* 1356 */     if (!validateContextName(cn, writer, smClient)) {
/*      */       return;
/*      */     }
/*      */     
/* 1360 */     String name = cn.getName();
/* 1361 */     String baseName = cn.getBaseName();
/* 1362 */     String displayPath = cn.getDisplayName();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1367 */       Context context = (Context)this.host.findChild(name);
/* 1368 */       if (context == null) {
/* 1369 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         
/*      */         return;
/*      */       } 
/* 1373 */       if (!isDeployed(name)) {
/* 1374 */         writer.println(smClient
/* 1375 */             .getString("managerServlet.notDeployed", new Object[] { Escape.htmlElementContent(displayPath) }));
/*      */         
/*      */         return;
/*      */       } 
/* 1379 */       if (tryAddServiced(name)) {
/*      */         
/*      */         try {
/* 1382 */           context.stop();
/* 1383 */         } catch (Throwable t) {
/* 1384 */           ExceptionUtils.handleThrowable(t);
/*      */         } 
/*      */         try {
/* 1387 */           File war = new File(this.host.getAppBaseFile(), baseName + ".war");
/* 1388 */           File dir = new File(this.host.getAppBaseFile(), baseName);
/* 1389 */           File xml = new File(this.configBase, baseName + ".xml");
/* 1390 */           if (war.exists() && !war.delete()) {
/* 1391 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { war })); return;
/*      */           } 
/* 1393 */           if (dir.exists() && !ExpandWar.delete(dir, false)) {
/* 1394 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { dir })); return;
/*      */           } 
/* 1396 */           if (xml.exists() && !xml.delete()) {
/* 1397 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { xml }));
/*      */             return;
/*      */           } 
/*      */         } finally {
/* 1401 */           removeServiced(name);
/*      */         } 
/*      */         
/* 1404 */         check(name);
/*      */       } else {
/* 1406 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       } 
/* 1408 */       writer.println(smClient.getString("managerServlet.undeployed", new Object[] { displayPath }));
/* 1409 */     } catch (Throwable t) {
/* 1410 */       ExceptionUtils.handleThrowable(t);
/* 1411 */       log(sm.getString("managerServlet.error.undeploy", new Object[] { displayPath }), t);
/* 1412 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { t.toString() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isDeployed(String name) throws Exception {
/* 1431 */     String[] params = { name };
/* 1432 */     String[] signature = { "java.lang.String" };
/* 1433 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "isDeployed", (Object[])params, signature);
/* 1434 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void check(String name) throws Exception {
/* 1446 */     String[] params = { name };
/* 1447 */     String[] signature = { "java.lang.String" };
/* 1448 */     this.mBeanServer.invoke(this.oname, "check", (Object[])params, signature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean tryAddServiced(String name) throws Exception {
/* 1463 */     String[] params = { name };
/* 1464 */     String[] signature = { "java.lang.String" };
/* 1465 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "tryAddServiced", (Object[])params, signature);
/* 1466 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeServiced(String name) throws Exception {
/* 1478 */     String[] params = { name };
/* 1479 */     String[] signature = { "java.lang.String" };
/* 1480 */     this.mBeanServer.invoke(this.oname, "removeServiced", (Object[])params, signature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void uploadWar(PrintWriter writer, HttpServletRequest request, File war, StringManager smClient) throws IOException {
/* 1497 */     if (war.exists() && !war.delete()) {
/* 1498 */       String msg = smClient.getString("managerServlet.deleteFail", new Object[] { war });
/* 1499 */       throw new IOException(msg);
/*      */     } 
/*      */     
/* 1502 */     try { ServletInputStream istream = request.getInputStream(); try { OutputStream ostream = new FileOutputStream(war); 
/* 1503 */         try { IOTools.flow((InputStream)istream, ostream);
/* 1504 */           ostream.close(); } catch (Throwable throwable) { try { ostream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (istream != null) istream.close();  } catch (Throwable throwable) { if (istream != null) try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 1505 */     { if (war.exists() && !war.delete()) {
/* 1506 */         writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { war }));
/*      */       }
/* 1508 */       throw ioe; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean validateContextName(ContextName cn, PrintWriter writer, StringManager smClient) {
/* 1517 */     if (cn != null && (cn.getPath().startsWith("/") || cn.getPath().isEmpty())) {
/* 1518 */       return true;
/*      */     }
/*      */     
/* 1521 */     String path = null;
/* 1522 */     if (cn != null) {
/* 1523 */       path = Escape.htmlElementContent(cn.getPath());
/*      */     }
/* 1525 */     writer.println(smClient.getString("managerServlet.invalidPath", new Object[] { path }));
/* 1526 */     return false;
/*      */   }
/*      */   
/*      */   protected Map<String, List<String>> getConnectorCiphers(StringManager smClient) {
/* 1530 */     Map<String, List<String>> result = new HashMap<>();
/*      */     
/* 1532 */     Connector[] connectors = getConnectors();
/* 1533 */     for (Connector connector : connectors) {
/* 1534 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1535 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1536 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1537 */           String name = connector.toString() + "-" + connector.toString();
/*      */           
/* 1539 */           result.put(name, new ArrayList<>(new LinkedHashSet<>(
/* 1540 */                   Arrays.asList(sslHostConfig.getEnabledCiphers()))));
/*      */         } 
/*      */       } else {
/* 1543 */         ArrayList<String> cipherList = new ArrayList<>(1);
/* 1544 */         cipherList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1545 */         result.put(connector.toString(), cipherList);
/*      */       } 
/*      */     } 
/* 1548 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map<String, List<String>> getConnectorCerts(StringManager smClient) {
/* 1553 */     Map<String, List<String>> result = new HashMap<>();
/*      */     
/* 1555 */     Connector[] connectors = getConnectors();
/* 1556 */     for (Connector connector : connectors) {
/* 1557 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1558 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1559 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1560 */           Set<SSLHostConfigCertificate> sslHostConfigCerts = sslHostConfig.getCertificates();
/* 1561 */           for (SSLHostConfigCertificate sslHostConfigCert : sslHostConfigCerts) {
/*      */             
/* 1563 */             String name = connector.toString() + "-" + connector.toString() + "-" + sslHostConfig.getHostName();
/* 1564 */             List<String> certList = new ArrayList<>();
/* 1565 */             SSLContext sslContext = sslHostConfigCert.getSslContext();
/* 1566 */             String alias = sslHostConfigCert.getCertificateKeyAlias();
/* 1567 */             if (alias == null) {
/* 1568 */               alias = "tomcat";
/*      */             }
/* 1570 */             if (sslContext == null) {
/* 1571 */               certList.add(smClient.getString("managerServlet.certsNotLoaded"));
/*      */             } else {
/* 1573 */               X509Certificate[] certs = sslContext.getCertificateChain(alias);
/* 1574 */               if (certs == null) {
/* 1575 */                 certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/*      */               } else {
/* 1577 */                 for (Certificate cert : certs) {
/* 1578 */                   certList.add(cert.toString());
/*      */                 }
/*      */               } 
/*      */             } 
/* 1582 */             result.put(name, certList);
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1586 */         List<String> certList = new ArrayList<>(1);
/* 1587 */         certList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1588 */         result.put(connector.toString(), certList);
/*      */       } 
/*      */     } 
/*      */     
/* 1592 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map<String, List<String>> getConnectorTrustedCerts(StringManager smClient) {
/* 1597 */     Map<String, List<String>> result = new HashMap<>();
/*      */     
/* 1599 */     Connector[] connectors = getConnectors();
/* 1600 */     for (Connector connector : connectors) {
/* 1601 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1602 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1603 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1604 */           String name = connector.toString() + "-" + connector.toString();
/* 1605 */           List<String> certList = new ArrayList<>();
/* 1606 */           SSLContext sslContext = ((SSLHostConfigCertificate)sslHostConfig.getCertificates().iterator().next()).getSslContext();
/* 1607 */           if (sslContext == null) {
/* 1608 */             certList.add(smClient.getString("managerServlet.certsNotLoaded"));
/*      */           } else {
/* 1610 */             X509Certificate[] certs = sslContext.getAcceptedIssuers();
/* 1611 */             if (certs == null) {
/* 1612 */               certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/* 1613 */             } else if (certs.length == 0) {
/* 1614 */               certList.add(smClient.getString("managerServlet.trustedCertsNotConfigured"));
/*      */             } else {
/* 1616 */               for (Certificate cert : certs) {
/* 1617 */                 certList.add(cert.toString());
/*      */               }
/*      */             } 
/*      */           } 
/* 1621 */           result.put(name, certList);
/*      */         } 
/*      */       } else {
/* 1624 */         List<String> certList = new ArrayList<>(1);
/* 1625 */         certList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1626 */         result.put(connector.toString(), certList);
/*      */       } 
/*      */     } 
/*      */     
/* 1630 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private Connector[] getConnectors() {
/* 1635 */     Engine e = (Engine)this.host.getParent();
/* 1636 */     Service s = e.getService();
/* 1637 */     return s.findConnectors();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\ManagerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */