/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServlet;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import org.apache.catalina.mbeans.MBeanDumper;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMXProxyServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  53 */   private static final String[] NO_PARAMETERS = new String[0];
/*     */   
/*  55 */   private static final StringManager sm = StringManager.getManager(JMXProxyServlet.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected transient MBeanServer mBeanServer = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient Registry registry;
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws ServletException {
/*  70 */     this.registry = Registry.getRegistry(null);
/*  71 */     this.mBeanServer = Registry.getRegistry(null).getMBeanServer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*  77 */     response.setContentType("text/plain;charset=utf-8");
/*     */ 
/*     */ 
/*     */     
/*  81 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  82 */     PrintWriter writer = response.getWriter();
/*     */     
/*  84 */     if (this.mBeanServer == null) {
/*  85 */       writer.println("Error - No mbean server");
/*     */       
/*     */       return;
/*     */     } 
/*  89 */     String qry = request.getParameter("set");
/*  90 */     if (qry != null) {
/*  91 */       String name = request.getParameter("att");
/*  92 */       String val = request.getParameter("val");
/*     */       
/*  94 */       setAttribute(writer, qry, name, val);
/*     */       return;
/*     */     } 
/*  97 */     qry = request.getParameter("get");
/*  98 */     if (qry != null) {
/*  99 */       String name = request.getParameter("att");
/* 100 */       getAttribute(writer, qry, name, request.getParameter("key"));
/*     */       return;
/*     */     } 
/* 103 */     qry = request.getParameter("invoke");
/* 104 */     if (qry != null) {
/* 105 */       String opName = request.getParameter("op");
/* 106 */       String[] params = getInvokeParameters(request.getParameter("ps"));
/* 107 */       invokeOperation(writer, qry, opName, params);
/*     */       return;
/*     */     } 
/* 110 */     qry = request.getParameter("qry");
/* 111 */     if (qry == null) {
/* 112 */       qry = "*:*";
/*     */     }
/*     */     
/* 115 */     listBeans(writer, qry);
/*     */   }
/*     */   
/*     */   public void getAttribute(PrintWriter writer, String onameStr, String att, String key) {
/*     */     try {
/*     */       String valueStr;
/* 121 */       ObjectName oname = new ObjectName(onameStr);
/* 122 */       Object value = this.mBeanServer.getAttribute(oname, att);
/*     */       
/* 124 */       if (null != key && value instanceof CompositeData) {
/* 125 */         value = ((CompositeData)value).get(key);
/*     */       }
/*     */ 
/*     */       
/* 129 */       if (value != null) {
/* 130 */         valueStr = value.toString();
/*     */       } else {
/* 132 */         valueStr = "<null>";
/*     */       } 
/*     */       
/* 135 */       writer.print("OK - Attribute get '");
/* 136 */       writer.print(onameStr);
/* 137 */       writer.print("' - ");
/* 138 */       writer.print(att);
/*     */       
/* 140 */       if (null != key) {
/* 141 */         writer.print(" - key '");
/* 142 */         writer.print(key);
/* 143 */         writer.print("'");
/*     */       } 
/*     */       
/* 146 */       writer.print(" = ");
/*     */       
/* 148 */       writer.println(MBeanDumper.escape(valueStr));
/* 149 */     } catch (Exception e) {
/* 150 */       writer.println("Error - " + e.toString());
/* 151 */       e.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(PrintWriter writer, String onameStr, String att, String val) {
/*     */     try {
/* 158 */       setAttributeInternal(onameStr, att, val);
/* 159 */       writer.println("OK - Attribute set");
/* 160 */     } catch (Exception e) {
/* 161 */       writer.println("Error - " + e.toString());
/* 162 */       e.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void listBeans(PrintWriter writer, String qry) {
/*     */     Set<ObjectName> names;
/*     */     try {
/* 171 */       names = this.mBeanServer.queryNames(new ObjectName(qry), null);
/* 172 */       writer.println("OK - Number of results: " + names.size());
/* 173 */       writer.println();
/* 174 */     } catch (Exception e) {
/* 175 */       writer.println("Error - " + e.toString());
/* 176 */       e.printStackTrace(writer);
/*     */       
/*     */       return;
/*     */     } 
/* 180 */     String dump = MBeanDumper.dumpBeans(this.mBeanServer, names);
/* 181 */     writer.print(dump);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupported(String type) {
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void invokeOperation(PrintWriter writer, String onameStr, String op, String[] valuesStr) {
/*     */     try {
/* 199 */       Object retVal = invokeOperationInternal(onameStr, op, valuesStr);
/* 200 */       if (retVal != null) {
/* 201 */         writer.println("OK - Operation " + op + " returned:");
/* 202 */         output("", writer, retVal);
/*     */       } else {
/* 204 */         writer.println("OK - Operation " + op + " without return value");
/*     */       } 
/* 206 */     } catch (Exception e) {
/* 207 */       writer.println("Error - " + e.toString());
/* 208 */       e.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getInvokeParameters(String paramString) {
/* 222 */     if (paramString == null) {
/* 223 */       return NO_PARAMETERS;
/*     */     }
/* 225 */     return paramString.split(",");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setAttributeInternal(String onameStr, String attributeName, String value) throws OperationsException, MBeanException, ReflectionException {
/* 235 */     ObjectName oname = new ObjectName(onameStr);
/* 236 */     String type = this.registry.getType(oname, attributeName);
/* 237 */     Object valueObj = this.registry.convertValue(type, value);
/* 238 */     this.mBeanServer.setAttribute(oname, new Attribute(attributeName, valueObj));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object invokeOperationInternal(String onameStr, String operation, String[] parameters) throws OperationsException, MBeanException, ReflectionException {
/* 255 */     ObjectName oname = new ObjectName(onameStr);
/* 256 */     int paramCount = (null == parameters) ? 0 : parameters.length;
/* 257 */     MBeanOperationInfo methodInfo = this.registry.getMethodInfo(oname, operation, paramCount);
/* 258 */     if (null == methodInfo) {
/*     */       MBeanInfo info;
/*     */       
/*     */       try {
/* 262 */         info = this.registry.getMBeanServer().getMBeanInfo(oname);
/* 263 */       } catch (InstanceNotFoundException infe) {
/* 264 */         throw infe;
/* 265 */       } catch (Exception e) {
/* 266 */         throw new IllegalArgumentException(sm.getString("jmxProxyServlet.noBeanFound", new Object[] { onameStr }), e);
/*     */       } 
/* 268 */       throw new IllegalArgumentException(sm.getString("jmxProxyServlet.noOperationOnBean", new Object[] { operation, 
/* 269 */               Integer.valueOf(paramCount), onameStr, info.getClassName() }));
/*     */     } 
/*     */     
/* 272 */     MBeanParameterInfo[] signature = methodInfo.getSignature();
/* 273 */     String[] signatureTypes = new String[signature.length];
/* 274 */     Object[] values = new Object[signature.length];
/* 275 */     for (int i = 0; i < signature.length; i++) {
/* 276 */       MBeanParameterInfo pi = signature[i];
/* 277 */       signatureTypes[i] = pi.getType();
/* 278 */       values[i] = this.registry.convertValue(pi.getType(), parameters[i]);
/*     */     } 
/*     */     
/* 281 */     return this.mBeanServer.invoke(oname, operation, values, signatureTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private void output(String indent, PrintWriter writer, Object result) {
/* 286 */     if (result instanceof Object[]) {
/* 287 */       for (Object obj : (Object[])result) {
/* 288 */         output("  " + indent, writer, obj);
/*     */       }
/*     */     } else {
/*     */       String strValue;
/* 292 */       if (result != null) {
/* 293 */         strValue = result.toString();
/*     */       } else {
/* 295 */         strValue = "<null>";
/*     */       } 
/* 297 */       writer.println(indent + indent);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\manager\JMXProxyServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */