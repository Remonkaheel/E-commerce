package org.apache.catalina;

import java.io.Closeable;

public interface TrackedWebResource extends Closeable {
  Exception getCreatedBy();
  
  String getName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\TrackedWebResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */