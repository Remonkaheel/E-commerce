package org.apache.catalina;

import java.io.InputStream;
import java.net.URL;
import java.util.Set;

public interface WebResourceSet extends Lifecycle {
  WebResource getResource(String paramString);
  
  String[] list(String paramString);
  
  Set<String> listWebAppPaths(String paramString);
  
  boolean mkdir(String paramString);
  
  boolean write(String paramString, InputStream paramInputStream, boolean paramBoolean);
  
  void setRoot(WebResourceRoot paramWebResourceRoot);
  
  boolean getClassLoaderOnly();
  
  void setClassLoaderOnly(boolean paramBoolean);
  
  boolean getStaticOnly();
  
  void setStaticOnly(boolean paramBoolean);
  
  URL getBaseUrl();
  
  void setReadOnly(boolean paramBoolean);
  
  boolean isReadOnly();
  
  void gc();
  
  void setAllowLinking(boolean paramBoolean);
  
  boolean getAllowLinking();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\WebResourceSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */