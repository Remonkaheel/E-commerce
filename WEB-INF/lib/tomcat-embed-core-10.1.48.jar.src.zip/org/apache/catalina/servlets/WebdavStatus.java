package org.apache.catalina.servlets;

class WebdavStatus {
  public static final int SC_OK = 200;
  
  public static final int SC_CREATED = 201;
  
  public static final int SC_ACCEPTED = 202;
  
  public static final int SC_NO_CONTENT = 204;
  
  public static final int SC_MOVED_PERMANENTLY = 301;
  
  public static final int SC_MOVED_TEMPORARILY = 302;
  
  public static final int SC_NOT_MODIFIED = 304;
  
  public static final int SC_BAD_REQUEST = 400;
  
  public static final int SC_UNAUTHORIZED = 401;
  
  public static final int SC_FORBIDDEN = 403;
  
  public static final int SC_NOT_FOUND = 404;
  
  public static final int SC_INTERNAL_SERVER_ERROR = 500;
  
  public static final int SC_NOT_IMPLEMENTED = 501;
  
  public static final int SC_BAD_GATEWAY = 502;
  
  public static final int SC_SERVICE_UNAVAILABLE = 503;
  
  public static final int SC_CONTINUE = 100;
  
  public static final int SC_METHOD_NOT_ALLOWED = 405;
  
  public static final int SC_CONFLICT = 409;
  
  public static final int SC_PRECONDITION_FAILED = 412;
  
  public static final int SC_REQUEST_TOO_LONG = 413;
  
  public static final int SC_UNSUPPORTED_MEDIA_TYPE = 415;
  
  public static final int SC_MULTI_STATUS = 207;
  
  public static final int SC_UNPROCESSABLE_CONTENT = 422;
  
  public static final int SC_METHOD_FAILURE = 420;
  
  public static final int SC_LOCKED = 423;
  
  public static final int SC_FAILED_DEPENDENCY = 424;
  
  public static final int SC_INSUFFICIENT_STORAGE = 507;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\servlets\WebdavStatus.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */