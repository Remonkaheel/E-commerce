/*     */ package org.apache.catalina.servlets;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.util.DOMWriter;
/*     */ import org.apache.catalina.util.XMLWriter;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourcePropertyStore
/*     */   implements WebdavServlet.PropertyStore
/*     */ {
/*  65 */   protected static final StringManager sm = StringManager.getManager(DataSourcePropertyStore.class);
/*  66 */   private final Log log = LogFactory.getLog(DataSourcePropertyStore.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private String dataSourceName = "WebdavPropertyStore";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private String tableName = "properties";
/*     */   
/*     */   private String addPropertyStatement;
/*     */   
/*     */   private String setPropertyStatement;
/*     */   private String removeAllPropertiesStatement;
/*     */   private String removePropertyStatement;
/*     */   private String getPropertyStatement;
/*     */   private String getPropertiesNameStatement;
/*     */   private String getPropertiesStatement;
/*     */   private String getPropertiesNodeStatement;
/*  87 */   private final ReentrantReadWriteLock dbLock = new ReentrantReadWriteLock();
/*  88 */   private final Lock dbReadLock = this.dbLock.readLock();
/*  89 */   private final Lock dbWriteLock = this.dbLock.writeLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataSourceName() {
/*  95 */     return this.dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceName(String dataSourceName) {
/* 102 */     this.dataSourceName = dataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName() {
/* 109 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableName(String tableName) {
/* 116 */     this.tableName = tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   protected DataSource dataSource = null;
/*     */ 
/*     */   
/*     */   public void init() {
/* 126 */     if (this.dataSource == null) {
/*     */       try {
/* 128 */         this.dataSource = (DataSource)(new InitialContext()).lookup("java:comp/env/" + this.dataSourceName);
/* 129 */       } catch (NamingException e) {
/* 130 */         throw new IllegalArgumentException(sm
/* 131 */             .getString("webdavservlet.dataSourceStore.noDataSource", new Object[] { this.dataSourceName }), e);
/*     */       } 
/*     */     }
/* 134 */     this.addPropertyStatement = "INSERT INTO " + this.tableName + " (path, namespace, name, node) VALUES (?, ?, ?, ?)";
/* 135 */     this.setPropertyStatement = "UPDATE " + this.tableName + " SET node = ? WHERE path = ? AND namespace = ? AND name = ?";
/* 136 */     this.removeAllPropertiesStatement = "DELETE FROM " + this.tableName + " WHERE path = ?";
/* 137 */     this.removePropertyStatement = "DELETE FROM " + this.tableName + " WHERE path = ? AND namespace = ? AND name = ?";
/* 138 */     this.getPropertyStatement = "SELECT node FROM " + this.tableName + " WHERE path = ? AND namespace = ? AND name = ?";
/* 139 */     this.getPropertiesNameStatement = "SELECT namespace, name FROM " + this.tableName + " WHERE path = ?";
/* 140 */     this.getPropertiesStatement = "SELECT namespace, name, node FROM " + this.tableName + " WHERE path = ?";
/* 141 */     this.getPropertiesNodeStatement = "SELECT node FROM " + this.tableName + " WHERE path = ?";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void periodicEvent() {}
/*     */ 
/*     */   
/*     */   public void copy(String source, String destination) {
/* 154 */     if (this.dataSource == null) {
/*     */       return;
/*     */     }
/* 157 */     this.dbWriteLock.lock(); 
/* 158 */     try { Connection connection = this.dataSource.getConnection(); 
/* 159 */       try { PreparedStatement statement = connection.prepareStatement(this.getPropertiesStatement); 
/* 160 */         try { statement.setString(1, source);
/* 161 */           if (statement.execute()) {
/* 162 */             ResultSet rs = statement.getResultSet();
/* 163 */             while (rs.next()) {
/* 164 */               String namespace = rs.getString(1);
/* 165 */               String name = rs.getString(2);
/* 166 */               String node = rs.getString(3);
/* 167 */               boolean found = false;
/* 168 */               PreparedStatement statement2 = connection.prepareStatement(this.getPropertyStatement); 
/* 169 */               try { statement2.setString(1, destination);
/* 170 */                 statement2.setString(2, namespace);
/* 171 */                 statement2.setString(3, name);
/* 172 */                 if (statement2.execute()) {
/* 173 */                   ResultSet rs2 = statement2.getResultSet();
/* 174 */                   if (rs2.next()) {
/* 175 */                     found = true;
/*     */                   }
/*     */                 } 
/* 178 */                 if (statement2 != null) statement2.close();  } catch (Throwable throwable) { if (statement2 != null)
/* 179 */                   try { statement2.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (found) {
/* 180 */                 statement2 = connection.prepareStatement(this.setPropertyStatement); 
/* 181 */                 try { statement2.setString(1, node);
/* 182 */                   statement2.setString(2, destination);
/* 183 */                   statement2.setString(3, namespace);
/* 184 */                   statement2.setString(4, name);
/* 185 */                   statement2.execute();
/* 186 */                   if (statement2 != null) statement2.close();  } catch (Throwable throwable) { if (statement2 != null)
/*     */                     try { statement2.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  continue;
/* 188 */               }  statement2 = connection.prepareStatement(this.addPropertyStatement); 
/* 189 */               try { statement2.setString(1, destination);
/* 190 */                 statement2.setString(2, namespace);
/* 191 */                 statement2.setString(3, name);
/* 192 */                 statement2.setString(4, node);
/* 193 */                 statement2.execute();
/* 194 */                 if (statement2 != null) statement2.close();  } catch (Throwable throwable) { if (statement2 != null)
/*     */                   try { statement2.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */             
/*     */             } 
/* 198 */           }  if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 199 */     { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "copy", source }), e); }
/*     */     finally
/* 201 */     { this.dbWriteLock.unlock(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(String resource) {
/* 207 */     if (this.dataSource == null) {
/*     */       return;
/*     */     }
/* 210 */     this.dbWriteLock.lock(); 
/* 211 */     try { Connection connection = this.dataSource.getConnection(); 
/* 212 */       try { PreparedStatement statement = connection.prepareStatement(this.removeAllPropertiesStatement); 
/* 213 */         try { statement.setString(1, resource);
/* 214 */           statement.execute();
/* 215 */           if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 216 */     { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "delete", resource }), e); }
/*     */     finally
/* 218 */     { this.dbWriteLock.unlock(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean propfind(String resource, Node property, boolean nameOnly, XMLWriter generatedXML) {
/* 224 */     if (this.dataSource == null) {
/* 225 */       return false;
/*     */     }
/* 227 */     if (nameOnly) {
/*     */       
/* 229 */       this.dbReadLock.lock(); 
/* 230 */       try { Connection connection = this.dataSource.getConnection(); 
/* 231 */         try { PreparedStatement statement = connection.prepareStatement(this.getPropertiesNameStatement); 
/* 232 */           try { statement.setString(1, resource);
/* 233 */             if (statement.execute()) {
/* 234 */               ResultSet rs = statement.getResultSet();
/* 235 */               while (rs.next()) {
/* 236 */                 String namespace = rs.getString(1);
/* 237 */                 String name = rs.getString(2);
/* 238 */                 generatedXML.writeElement(null, namespace, name, 2);
/*     */               } 
/*     */             } 
/* 241 */             if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 242 */       { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "propfind", resource }), e); }
/*     */       finally
/* 244 */       { this.dbReadLock.unlock(); }
/*     */     
/* 246 */     } else if (property != null) {
/*     */       
/* 248 */       this.dbReadLock.lock(); 
/* 249 */       try { Connection connection = this.dataSource.getConnection(); 
/* 250 */         try { PreparedStatement statement = connection.prepareStatement(this.getPropertyStatement); 
/* 251 */           try { statement.setString(1, resource);
/* 252 */             statement.setString(2, property.getNamespaceURI());
/* 253 */             statement.setString(3, property.getLocalName());
/* 254 */             if (statement.execute())
/* 255 */             { ResultSet rs = statement.getResultSet();
/* 256 */               if (rs.next())
/* 257 */               { String node = rs.getString(1);
/* 258 */                 generatedXML.writeRaw(node);
/* 259 */                 boolean bool = true;
/*     */ 
/*     */                 
/* 262 */                 if (statement != null) statement.close();  if (connection != null) connection.close();  return bool; }  }  if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 263 */       { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "propfind", resource }), e); }
/*     */       finally
/* 265 */       { this.dbReadLock.unlock(); }
/*     */     
/*     */     } else {
/*     */       
/* 269 */       this.dbReadLock.lock(); 
/* 270 */       try { Connection connection = this.dataSource.getConnection(); 
/* 271 */         try { PreparedStatement statement = connection.prepareStatement(this.getPropertiesNodeStatement); 
/* 272 */           try { statement.setString(1, resource);
/* 273 */             if (statement.execute()) {
/* 274 */               ResultSet rs = statement.getResultSet();
/* 275 */               while (rs.next()) {
/* 276 */                 String node = rs.getString(1);
/* 277 */                 generatedXML.writeRaw(node);
/*     */               } 
/*     */             } 
/* 280 */             if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 281 */       { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "propfind", resource }), e); }
/*     */       finally
/* 283 */       { this.dbReadLock.unlock(); }
/*     */     
/*     */     } 
/* 286 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void proppatch(String resource, ArrayList<WebdavServlet.ProppatchOperation> operations) {
/* 291 */     boolean protectedProperty = false;
/*     */     
/* 293 */     for (WebdavServlet.ProppatchOperation operation : operations) {
/* 294 */       if (operation.getProtectedProperty()) {
/* 295 */         protectedProperty = true;
/* 296 */         operation.setStatusCode(403);
/*     */       } 
/*     */     } 
/* 299 */     if (protectedProperty) {
/* 300 */       for (WebdavServlet.ProppatchOperation operation : operations) {
/* 301 */         if (!operation.getProtectedProperty()) {
/* 302 */           operation.setStatusCode(424);
/*     */         }
/*     */       } 
/*     */     } else {
/* 306 */       if (this.dataSource == null) {
/* 307 */         for (WebdavServlet.ProppatchOperation operation : operations) {
/* 308 */           operation.setStatusCode(500);
/*     */         }
/*     */         return;
/*     */       } 
/* 312 */       boolean failure = false;
/* 313 */       this.dbWriteLock.lock(); 
/* 314 */       try { Connection connection = this.dataSource.getConnection(); 
/* 315 */         try { connection.setAutoCommit(false);
/* 316 */           for (WebdavServlet.ProppatchOperation operation : operations) {
/* 317 */             if (operation.getUpdateType() == WebdavServlet.PropertyUpdateType.SET) {
/* 318 */               Node node = operation.getPropertyNode().cloneNode(true);
/* 319 */               StringWriter strWriter = new StringWriter();
/* 320 */               DOMWriter domWriter = new DOMWriter(strWriter);
/* 321 */               domWriter.print(node);
/* 322 */               String serializedNode = strWriter.toString();
/* 323 */               boolean found = false;
/*     */               try {
/* 325 */                 PreparedStatement statement = connection.prepareStatement(this.getPropertyStatement); 
/* 326 */                 try { statement.setString(1, resource);
/* 327 */                   statement.setString(2, node.getNamespaceURI());
/* 328 */                   statement.setString(3, node.getLocalName());
/* 329 */                   if (statement.execute()) {
/* 330 */                     ResultSet rs = statement.getResultSet();
/* 331 */                     if (rs.next()) {
/* 332 */                       found = true;
/*     */                     }
/*     */                   } 
/* 335 */                   if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null)
/* 336 */                     try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (found)
/* 337 */                 { statement = connection.prepareStatement(this.setPropertyStatement); 
/* 338 */                   try { statement.setString(1, serializedNode);
/* 339 */                     statement.setString(2, resource);
/* 340 */                     statement.setString(3, node.getNamespaceURI());
/* 341 */                     statement.setString(4, node.getLocalName());
/* 342 */                     statement.execute();
/* 343 */                     if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null)
/*     */                       try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 345 */                 else { statement = connection.prepareStatement(this.addPropertyStatement); 
/* 346 */                   try { statement.setString(1, resource);
/* 347 */                     statement.setString(2, node.getNamespaceURI());
/* 348 */                     statement.setString(3, node.getLocalName());
/* 349 */                     statement.setString(4, serializedNode);
/* 350 */                     statement.execute();
/* 351 */                     if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null)
/*     */                       try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } 
/* 353 */               } catch (SQLException e) {
/* 354 */                 failure = true;
/* 355 */                 operation.setStatusCode(500);
/*     */                 break;
/*     */               } 
/*     */             } 
/* 359 */             if (operation.getUpdateType() == WebdavServlet.PropertyUpdateType.REMOVE) {
/* 360 */               Node node = operation.getPropertyNode(); 
/* 361 */               try { PreparedStatement statement = connection.prepareStatement(this.removePropertyStatement); 
/* 362 */                 try { statement.setString(1, resource);
/* 363 */                   statement.setString(2, node.getNamespaceURI());
/* 364 */                   statement.setString(3, node.getLocalName());
/* 365 */                   statement.execute();
/* 366 */                   if (statement != null) statement.close();  } catch (Throwable throwable) { if (statement != null) try { statement.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 367 */               { failure = true;
/* 368 */                 operation.setStatusCode(500);
/*     */                 break; }
/*     */             
/*     */             } 
/*     */           } 
/* 373 */           if (failure) {
/* 374 */             connection.rollback();
/* 375 */             for (WebdavServlet.ProppatchOperation operation : operations) {
/* 376 */               if (operation.getStatusCode() == 200) {
/* 377 */                 operation.setStatusCode(424);
/*     */               }
/*     */             } 
/*     */           } else {
/* 381 */             connection.commit();
/*     */           } 
/* 383 */           if (connection != null) connection.close();  } catch (Throwable throwable) { if (connection != null) try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 384 */       { this.log.warn(sm.getString("webdavservlet.dataSourceStore.error", new Object[] { "proppatch", resource }), e);
/* 385 */         for (WebdavServlet.ProppatchOperation operation : operations) {
/* 386 */           operation.setStatusCode(500);
/*     */         } }
/*     */       finally
/* 389 */       { this.dbWriteLock.unlock(); }
/*     */     
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\servlets\DataSourcePropertyStore.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */