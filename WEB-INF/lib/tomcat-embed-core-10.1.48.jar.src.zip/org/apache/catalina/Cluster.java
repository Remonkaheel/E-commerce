package org.apache.catalina;

public interface Cluster extends Contained {
  String getClusterName();
  
  void setClusterName(String paramString);
  
  Manager createManager(String paramString);
  
  void registerManager(Manager paramManager);
  
  void removeManager(Manager paramManager);
  
  void backgroundProcess();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Cluster.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */