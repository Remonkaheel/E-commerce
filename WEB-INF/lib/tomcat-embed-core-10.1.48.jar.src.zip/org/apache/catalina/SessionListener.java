package org.apache.catalina;

import java.util.EventListener;

public interface SessionListener extends EventListener {
  void sessionEvent(SessionEvent paramSessionEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\SessionListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */