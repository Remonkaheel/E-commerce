package org.apache.catalina;

import jakarta.servlet.http.HttpSession;
import java.security.Principal;
import java.util.Iterator;

public interface Session {
  public static final String SESSION_CREATED_EVENT = "createSession";
  
  public static final String SESSION_DESTROYED_EVENT = "destroySession";
  
  public static final String SESSION_ACTIVATED_EVENT = "activateSession";
  
  public static final String SESSION_PASSIVATED_EVENT = "passivateSession";
  
  public static final String SESSION_CHANGED_ID_EVENT = "changeSessionId";
  
  String getAuthType();
  
  void setAuthType(String paramString);
  
  long getCreationTime();
  
  long getCreationTimeInternal();
  
  void setCreationTime(long paramLong);
  
  String getId();
  
  String getIdInternal();
  
  void setId(String paramString);
  
  void setId(String paramString, boolean paramBoolean);
  
  long getThisAccessedTime();
  
  long getThisAccessedTimeInternal();
  
  long getLastAccessedTime();
  
  long getLastAccessedTimeInternal();
  
  long getIdleTime();
  
  long getIdleTimeInternal();
  
  Manager getManager();
  
  void setManager(Manager paramManager);
  
  int getMaxInactiveInterval();
  
  void setMaxInactiveInterval(int paramInt);
  
  void setNew(boolean paramBoolean);
  
  Principal getPrincipal();
  
  void setPrincipal(Principal paramPrincipal);
  
  HttpSession getSession();
  
  void setValid(boolean paramBoolean);
  
  boolean isValid();
  
  void access();
  
  void addSessionListener(SessionListener paramSessionListener);
  
  void endAccess();
  
  void expire();
  
  Object getNote(String paramString);
  
  Iterator<String> getNoteNames();
  
  void recycle();
  
  void removeNote(String paramString);
  
  void removeSessionListener(SessionListener paramSessionListener);
  
  void setNote(String paramString, Object paramObject);
  
  void tellChangedSessionId(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean isAttributeDistributable(String paramString, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Session.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */