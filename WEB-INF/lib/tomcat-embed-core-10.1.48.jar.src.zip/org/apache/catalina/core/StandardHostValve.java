/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.ClientAbortException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardHostValve
/*     */   extends ValveBase
/*     */ {
/*  50 */   private static final Log log = LogFactory.getLog(StandardHostValve.class);
/*  51 */   private static final StringManager sm = StringManager.getManager(StandardHostValve.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final ClassLoader MY_CLASSLOADER = StandardHostValve.class.getClassLoader();
/*     */ 
/*     */ 
/*     */   
/*     */   StandardHostValve() {
/*  61 */     super(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*  81 */     Context context = request.getContext();
/*  82 */     if (context == null) {
/*     */       
/*  84 */       if (!response.isError()) {
/*  85 */         response.sendError(404);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  90 */     if (request.isAsyncSupported()) {
/*  91 */       request.setAsyncSupported(context.getPipeline().isAsyncSupported());
/*     */     }
/*     */     
/*  94 */     boolean asyncAtStart = request.isAsync();
/*     */     
/*     */     try {
/*  97 */       context.bind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */       
/*  99 */       if (!asyncAtStart && !context.fireRequestInitEvent((ServletRequest)request.getRequest())) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 112 */         if (!response.isErrorReportRequired()) {
/* 113 */           context.getPipeline().getFirst().invoke(request, response);
/*     */         }
/* 115 */       } catch (Throwable throwable) {
/* 116 */         ExceptionUtils.handleThrowable(throwable);
/* 117 */         this.container.getLogger().error(sm.getString("standardHostValve.exception", new Object[] { request.getRequestURI() }), throwable);
/*     */ 
/*     */         
/* 120 */         if (!response.isErrorReportRequired()) {
/* 121 */           request.setAttribute("jakarta.servlet.error.exception", throwable);
/* 122 */           throwable(request, response, throwable);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       response.setSuspended(false);
/*     */       
/* 131 */       Throwable t = (Throwable)request.getAttribute("jakarta.servlet.error.exception");
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (!context.getState().isAvailable()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 140 */       if (response.isErrorReportRequired()) {
/*     */ 
/*     */         
/* 143 */         AtomicBoolean result = new AtomicBoolean(false);
/* 144 */         response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/* 145 */         if (result.get()) {
/* 146 */           if (t != null) {
/* 147 */             throwable(request, response, t);
/*     */           } else {
/* 149 */             status(request, response);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 154 */       if (!request.isAsync() && !asyncAtStart) {
/* 155 */         context.fireRequestDestroyEvent((ServletRequest)request.getRequest());
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 160 */       if (context.getAlwaysAccessSession()) {
/* 161 */         request.getSession(false);
/*     */       }
/*     */       
/* 164 */       context.unbind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void status(Request request, Response response) {
/* 181 */     int statusCode = response.getStatus();
/*     */ 
/*     */     
/* 184 */     Context context = request.getContext();
/* 185 */     if (context == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     if (!response.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 197 */     ErrorPage errorPage = context.findErrorPage(statusCode);
/* 198 */     if (errorPage == null)
/*     */     {
/* 200 */       errorPage = context.findErrorPage(0);
/*     */     }
/* 202 */     if (errorPage != null && response.isErrorReportRequired()) {
/* 203 */       response.setAppCommitted(false);
/* 204 */       setRequestErrorAttributes(request, statusCode, null, response.getMessage(), null, errorPage.getLocation());
/*     */       
/* 206 */       if (custom(request, response, errorPage)) {
/* 207 */         response.setErrorReported();
/*     */         try {
/* 209 */           response.finishResponse();
/* 210 */         } catch (ClientAbortException clientAbortException) {
/*     */         
/* 212 */         } catch (IOException ioe) {
/* 213 */           this.container.getLogger().warn(sm.getString("standardHostValve.exception", new Object[] { errorPage }), ioe);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void throwable(Request request, Response response, Throwable throwable) {
/* 230 */     Context context = request.getContext();
/* 231 */     if (context == null) {
/*     */       return;
/*     */     }
/*     */     
/* 235 */     Throwable realError = throwable;
/*     */     
/* 237 */     if (realError instanceof ServletException) {
/* 238 */       realError = ((ServletException)realError).getRootCause();
/* 239 */       if (realError == null) {
/* 240 */         realError = throwable;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 245 */     if (realError instanceof ClientAbortException) {
/* 246 */       if (log.isDebugEnabled()) {
/* 247 */         log.debug(sm.getString("standardHost.clientAbort", new Object[] { realError.getCause().getMessage() }));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 252 */     ErrorPage errorPage = context.findErrorPage(throwable);
/* 253 */     if (errorPage == null && realError != throwable) {
/* 254 */       errorPage = context.findErrorPage(realError);
/*     */     }
/*     */     
/* 257 */     if (errorPage != null) {
/* 258 */       if (response.setErrorReported()) {
/* 259 */         response.setAppCommitted(false);
/* 260 */         setRequestErrorAttributes(request, 500, realError.getClass(), throwable
/* 261 */             .getMessage(), realError, errorPage.getLocation());
/*     */         
/* 263 */         if (custom(request, response, errorPage)) {
/*     */           try {
/* 265 */             response.finishResponse();
/* 266 */           } catch (IOException ioe) {
/* 267 */             this.container.getLogger().warn(sm.getString("standardHostValve.exception", new Object[] { errorPage }), ioe);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 277 */       if (response.getStatus() < 400) {
/* 278 */         response.setStatus(500);
/*     */       }
/*     */       
/* 281 */       response.setError();
/*     */       
/* 283 */       status(request, response);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setRequestErrorAttributes(Request request, int statusCode, Class<?> exceptionType, String message, Throwable exception, String location) {
/* 295 */     request.setAttribute("jakarta.servlet.error.status_code", Integer.valueOf(statusCode));
/*     */     
/* 297 */     if (exceptionType != null) {
/* 298 */       request.setAttribute("jakarta.servlet.error.exception_type", exceptionType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     request.setAttribute("jakarta.servlet.error.message", Objects.requireNonNullElse(message, ""));
/*     */     
/* 309 */     if (exception != null) {
/* 310 */       request.setAttribute("jakarta.servlet.error.exception", exception);
/*     */     }
/*     */     
/* 313 */     request.setAttribute("jakarta.servlet.error.request_uri", request.getRequestURI());
/*     */     
/* 315 */     Wrapper wrapper = request.getWrapper();
/* 316 */     if (wrapper != null) {
/* 317 */       request.setAttribute("jakarta.servlet.error.servlet_name", wrapper.getName());
/*     */     }
/*     */     
/* 320 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", location);
/* 321 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean custom(Request request, Response response, ErrorPage errorPage) {
/* 337 */     if (this.container.getLogger().isTraceEnabled()) {
/* 338 */       this.container.getLogger().trace("Processing " + String.valueOf(errorPage));
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 343 */       ServletContext servletContext = request.getContext().getServletContext();
/* 344 */       RequestDispatcher rd = servletContext.getRequestDispatcher(errorPage.getLocation());
/*     */       
/* 346 */       if (rd == null) {
/* 347 */         this.container.getLogger()
/* 348 */           .error(sm.getString("standardHostValve.customStatusFailed", new Object[] { errorPage.getLocation() }));
/* 349 */         return false;
/*     */       } 
/*     */       
/* 352 */       if (response.isCommitted()) {
/*     */ 
/*     */         
/* 355 */         rd.include((ServletRequest)request.getRequest(), (ServletResponse)response.getResponse());
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 360 */           response.flushBuffer();
/* 361 */         } catch (Throwable t) {
/* 362 */           ExceptionUtils.handleThrowable(t);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 367 */         response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, request
/* 368 */             .getAttribute("jakarta.servlet.error.exception"));
/*     */       } else {
/*     */         
/* 371 */         response.resetBuffer(true);
/* 372 */         response.setContentLength(-1);
/*     */         
/* 374 */         rd.forward((ServletRequest)request.getRequest(), (ServletResponse)response.getResponse());
/*     */ 
/*     */         
/* 377 */         response.setSuspended(false);
/*     */       } 
/*     */ 
/*     */       
/* 381 */       return true;
/*     */     }
/* 383 */     catch (Throwable t) {
/* 384 */       ExceptionUtils.handleThrowable(t);
/*     */       
/* 386 */       this.container.getLogger().error(sm.getString("standardHostValve.exception", new Object[] { errorPage }), t);
/* 387 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardHostValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */