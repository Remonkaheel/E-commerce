/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.catalina.AccessLog;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.realm.NullRealm;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardEngine
/*     */   extends ContainerBase
/*     */   implements Engine
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(StandardEngine.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private String defaultHost;
/*     */ 
/*     */ 
/*     */   
/*     */   private Service service;
/*     */ 
/*     */ 
/*     */   
/*     */   private String jvmRouteId;
/*     */ 
/*     */   
/*     */   private final AtomicReference<AccessLog> defaultAccessLog;
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardEngine() {
/*  71 */     this.defaultHost = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.service = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.defaultAccessLog = new AtomicReference<>();
/*     */     this.pipeline.setBasic((Valve)new StandardEngineValve());
/*     */     this.backgroundProcessorDelay = 10;
/*     */   }
/*     */   public Realm getRealm() {
/*     */     NullRealm nullRealm;
/*  93 */     Realm configured = super.getRealm();
/*     */ 
/*     */     
/*  96 */     if (configured == null) {
/*  97 */       nullRealm = new NullRealm();
/*  98 */       setRealm((Realm)nullRealm);
/*     */     } 
/* 100 */     return (Realm)nullRealm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultHost() {
/* 106 */     return this.defaultHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultHost(String host) {
/* 113 */     String oldDefaultHost = this.defaultHost;
/* 114 */     if (host == null) {
/* 115 */       this.defaultHost = null;
/*     */     } else {
/* 117 */       this.defaultHost = host.toLowerCase(Locale.ENGLISH);
/*     */     } 
/* 119 */     if (getState().isAvailable()) {
/* 120 */       this.service.getMapper().setDefaultHostName(host);
/*     */     }
/* 122 */     this.support.firePropertyChange("defaultHost", oldDefaultHost, this.defaultHost);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJvmRoute(String routeId) {
/* 129 */     this.jvmRouteId = routeId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJvmRoute() {
/* 135 */     return this.jvmRouteId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Service getService() {
/* 141 */     return this.service;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setService(Service service) {
/* 147 */     this.service = service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(Container child) {
/* 161 */     if (!(child instanceof Host)) {
/* 162 */       throw new IllegalArgumentException(sm.getString("standardEngine.notHost"));
/*     */     }
/* 164 */     super.addChild(child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(Container container) {
/* 178 */     throw new IllegalArgumentException(sm.getString("standardEngine.notParent"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 187 */     getRealm();
/* 188 */     super.initInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 196 */     if (log.isInfoEnabled()) {
/* 197 */       log.info(sm.getString("standardEngine.start", new Object[] { ServerInfo.getServerInfo() }));
/*     */     }
/*     */ 
/*     */     
/* 201 */     super.startInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logAccess(Request request, Response response, long time, boolean useDefault) {
/* 215 */     boolean logged = false;
/*     */     
/* 217 */     if (getAccessLog() != null) {
/* 218 */       this.accessLog.log(request, response, time);
/* 219 */       logged = true;
/*     */     } 
/*     */     
/* 222 */     if (!logged && useDefault) {
/* 223 */       AccessLog newDefaultAccessLog = this.defaultAccessLog.get();
/* 224 */       if (newDefaultAccessLog == null) {
/*     */ 
/*     */         
/* 227 */         Host host = (Host)findChild(getDefaultHost());
/* 228 */         Context context = null;
/* 229 */         if (host != null && host.getState().isAvailable()) {
/* 230 */           newDefaultAccessLog = host.getAccessLog();
/*     */           
/* 232 */           if (newDefaultAccessLog != null) {
/* 233 */             if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog)) {
/* 234 */               AccessLogListener l = new AccessLogListener(this, host, null);
/* 235 */               l.install();
/*     */             } 
/*     */           } else {
/*     */             
/* 239 */             context = (Context)host.findChild("");
/* 240 */             if (context != null && context.getState().isAvailable()) {
/* 241 */               newDefaultAccessLog = context.getAccessLog();
/* 242 */               if (newDefaultAccessLog != null && 
/* 243 */                 this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog)) {
/* 244 */                 AccessLogListener l = new AccessLogListener(this, null, context);
/* 245 */                 l.install();
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 252 */         if (newDefaultAccessLog == null) {
/* 253 */           newDefaultAccessLog = new NoopAccessLog();
/* 254 */           if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog)) {
/* 255 */             AccessLogListener l = new AccessLogListener(this, host, context);
/* 256 */             l.install();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 261 */       newDefaultAccessLog.log(request, response, time);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getParentClassLoader() {
/* 268 */     if (this.parentClassLoader != null) {
/* 269 */       return this.parentClassLoader;
/*     */     }
/* 271 */     if (this.service != null) {
/* 272 */       return this.service.getParentClassLoader();
/*     */     }
/* 274 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public File getCatalinaBase() {
/* 280 */     if (this.service != null) {
/* 281 */       Server s = this.service.getServer();
/* 282 */       if (s != null) {
/* 283 */         File base = s.getCatalinaBase();
/* 284 */         if (base != null) {
/* 285 */           return base;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 290 */     return super.getCatalinaBase();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public File getCatalinaHome() {
/* 296 */     if (this.service != null) {
/* 297 */       Server s = this.service.getServer();
/* 298 */       if (s != null) {
/* 299 */         File base = s.getCatalinaHome();
/* 300 */         if (base != null) {
/* 301 */           return base;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 306 */     return super.getCatalinaHome();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 314 */     return "type=Engine";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 320 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class NoopAccessLog
/*     */     implements AccessLog
/*     */   {
/*     */     public void log(Request request, Response response, long time) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getRequestAttributesEnabled() {
/* 341 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static final class AccessLogListener
/*     */     implements PropertyChangeListener, LifecycleListener, ContainerListener
/*     */   {
/*     */     private final StandardEngine engine;
/*     */     private final Host host;
/*     */     private final Context context;
/*     */     private volatile boolean disabled = false;
/*     */     
/*     */     public AccessLogListener(StandardEngine engine, Host host, Context context) {
/* 354 */       this.engine = engine;
/* 355 */       this.host = host;
/* 356 */       this.context = context;
/*     */     }
/*     */     
/*     */     public void install() {
/* 360 */       this.engine.addPropertyChangeListener(this);
/* 361 */       if (this.host != null) {
/* 362 */         this.host.addContainerListener(this);
/* 363 */         this.host.addLifecycleListener(this);
/*     */       } 
/* 365 */       if (this.context != null) {
/* 366 */         this.context.addLifecycleListener(this);
/*     */       }
/*     */     }
/*     */     
/*     */     private void uninstall() {
/* 371 */       this.disabled = true;
/* 372 */       if (this.context != null) {
/* 373 */         this.context.removeLifecycleListener(this);
/*     */       }
/* 375 */       if (this.host != null) {
/* 376 */         this.host.removeLifecycleListener(this);
/* 377 */         this.host.removeContainerListener(this);
/*     */       } 
/* 379 */       this.engine.removePropertyChangeListener(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event) {
/* 384 */       if (this.disabled) {
/*     */         return;
/*     */       }
/*     */       
/* 388 */       String type = event.getType();
/* 389 */       if ("after_start".equals(type) || "before_stop".equals(type) || "before_destroy".equals(type)) {
/*     */ 
/*     */ 
/*     */         
/* 393 */         this.engine.defaultAccessLog.set(null);
/* 394 */         uninstall();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent evt) {
/* 400 */       if (this.disabled) {
/*     */         return;
/*     */       }
/* 403 */       if ("defaultHost".equals(evt.getPropertyName())) {
/*     */ 
/*     */         
/* 406 */         this.engine.defaultAccessLog.set(null);
/* 407 */         uninstall();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void containerEvent(ContainerEvent event) {
/* 414 */       if (this.disabled) {
/*     */         return;
/*     */       }
/* 417 */       if ("addChild".equals(event.getType())) {
/* 418 */         Context context = (Context)event.getData();
/* 419 */         if (context.getPath().isEmpty()) {
/*     */ 
/*     */           
/* 422 */           this.engine.defaultAccessLog.set(null);
/* 423 */           uninstall();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardEngine.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */