/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.ObjectName;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.log.SystemLogHandler;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.modeler.Util;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterConfig
/*     */   implements FilterConfig, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  57 */   static final StringManager sm = StringManager.getManager(ApplicationFilterConfig.class);
/*     */   
/*  59 */   private transient Log log = LogFactory.getLog(ApplicationFilterConfig.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static final List<String> emptyString = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final transient Context context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final FilterDef filterDef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectName oname;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ApplicationFilterConfig(Context context, FilterDef filterDef) throws ClassCastException, ReflectiveOperationException, ServletException, NamingException, IllegalArgumentException, SecurityException {
/* 117 */     this.filter = null;
/*     */     this.context = context;
/*     */     this.filterDef = filterDef;
/*     */     if (filterDef.getFilter() == null) {
/*     */       getFilter();
/*     */     } else {
/*     */       this.filter = filterDef.getFilter();
/*     */       context.getInstanceManager().newInstance(this.filter);
/*     */       initFilter();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilterName() {
/* 135 */     return this.filterDef.getFilterName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilterClass() {
/* 142 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInitParameter(String name) {
/* 148 */     Map<String, String> map = this.filterDef.getParameterMap();
/* 149 */     if (map == null) {
/* 150 */       return null;
/*     */     }
/*     */     
/* 153 */     return map.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getInitParameterNames() {
/* 160 */     Map<String, String> map = this.filterDef.getParameterMap();
/*     */     
/* 162 */     if (map == null) {
/* 163 */       return Collections.enumeration(emptyString);
/*     */     }
/*     */     
/* 166 */     return Collections.enumeration(map.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletContext getServletContext() {
/* 173 */     return this.context.getServletContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "ApplicationFilterConfig[name=" + this.filterDef.getFilterName() + ", filterClass=" + this.filterDef
/* 181 */       .getFilterClass() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFilterInitParameterMap() {
/* 187 */     return Collections.unmodifiableMap(this.filterDef.getParameterMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Filter getFilter() throws ClassCastException, ReflectiveOperationException, ServletException, NamingException, IllegalArgumentException, SecurityException {
/* 212 */     if (this.filter != null) {
/* 213 */       return this.filter;
/*     */     }
/*     */ 
/*     */     
/* 217 */     String filterClass = this.filterDef.getFilterClass();
/* 218 */     this.filter = (Filter)this.context.getInstanceManager().newInstance(filterClass);
/*     */     
/* 220 */     initFilter();
/*     */     
/* 222 */     return this.filter;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initFilter() throws ServletException {
/* 227 */     if (this.context instanceof StandardContext && this.context.getSwallowOutput()) {
/*     */       try {
/* 229 */         SystemLogHandler.startCapture();
/* 230 */         this.filter.init(this);
/*     */       } finally {
/* 232 */         String capturedlog = SystemLogHandler.stopCapture();
/* 233 */         if (capturedlog != null && !capturedlog.isEmpty()) {
/* 234 */           getServletContext().log(capturedlog);
/*     */         }
/*     */       } 
/*     */     } else {
/* 238 */       this.filter.init(this);
/*     */     } 
/*     */ 
/*     */     
/* 242 */     registerJMX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FilterDef getFilterDef() {
/* 249 */     return this.filterDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void release() {
/* 257 */     unregisterJMX();
/*     */     
/* 259 */     if (this.filter != null) {
/*     */       try {
/* 261 */         if (Globals.IS_SECURITY_ENABLED) {
/*     */           try {
/* 263 */             SecurityUtil.doAsPrivilege("destroy", this.filter);
/*     */           } finally {
/* 265 */             SecurityUtil.remove(this.filter);
/*     */           } 
/*     */         } else {
/* 268 */           this.filter.destroy();
/*     */         } 
/* 270 */       } catch (Throwable t) {
/* 271 */         ExceptionUtils.handleThrowable(t);
/* 272 */         this.context.getLogger().error(sm.getString("applicationFilterConfig.release", new Object[] { this.filterDef.getFilterName(), this.filterDef
/* 273 */                 .getFilterClass() }), t);
/*     */       } 
/* 275 */       if (!this.context.getIgnoreAnnotations()) {
/*     */         try {
/* 277 */           this.context.getInstanceManager().destroyInstance(this.filter);
/* 278 */         } catch (Exception e) {
/* 279 */           Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 280 */           ExceptionUtils.handleThrowable(t);
/* 281 */           this.context.getLogger().error(sm.getString("applicationFilterConfig.preDestroy", new Object[] { this.filterDef
/* 282 */                   .getFilterName(), this.filterDef.getFilterClass() }), t);
/*     */         } 
/*     */       }
/*     */     } 
/* 286 */     this.filter = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerJMX() {
/* 294 */     String onameStr, parentName = this.context.getName();
/* 295 */     if (!parentName.startsWith("/")) {
/* 296 */       parentName = "/" + parentName;
/*     */     }
/*     */     
/* 299 */     String hostName = this.context.getParent().getName();
/* 300 */     hostName = (hostName == null) ? "DEFAULT" : hostName;
/*     */ 
/*     */     
/* 303 */     String domain = this.context.getParent().getParent().getName();
/*     */     
/* 305 */     String webMod = "//" + hostName + parentName;
/*     */     
/* 307 */     String filterName = this.filterDef.getFilterName();
/* 308 */     if (Util.objectNameValueNeedsQuote(filterName)) {
/* 309 */       filterName = ObjectName.quote(filterName);
/*     */     }
/* 311 */     if (this.context instanceof StandardContext) {
/* 312 */       StandardContext standardContext = (StandardContext)this.context;
/*     */       
/* 314 */       onameStr = domain + ":j2eeType=Filter,WebModule=" + domain + ",name=" + webMod + ",J2EEApplication=" + filterName + ",J2EEServer=" + standardContext.getJ2EEApplication();
/*     */     } else {
/* 316 */       onameStr = domain + ":j2eeType=Filter,name=" + domain + ",WebModule=" + filterName;
/*     */     } 
/*     */     try {
/* 319 */       this.oname = new ObjectName(onameStr);
/* 320 */       Registry.getRegistry(null).registerComponent(this, this.oname, null);
/* 321 */     } catch (Exception e) {
/* 322 */       this.log.warn(sm.getString("applicationFilterConfig.jmxRegisterFail", new Object[] { getFilterClass(), getFilterName() }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void unregisterJMX() {
/* 329 */     if (this.oname != null) {
/*     */       try {
/* 331 */         Registry.getRegistry(null).unregisterComponent(this.oname);
/* 332 */         if (this.log.isDebugEnabled()) {
/* 333 */           this.log.debug(sm.getString("applicationFilterConfig.jmxUnregister", new Object[] { getFilterClass(), getFilterName() }));
/*     */         }
/* 335 */       } catch (Exception e) {
/* 336 */         this.log.warn(sm.getString("applicationFilterConfig.jmxUnregisterFail", new Object[] { getFilterClass(), getFilterName() }), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
/* 347 */     ois.defaultReadObject();
/* 348 */     this.log = LogFactory.getLog(ApplicationFilterConfig.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationFilterConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */