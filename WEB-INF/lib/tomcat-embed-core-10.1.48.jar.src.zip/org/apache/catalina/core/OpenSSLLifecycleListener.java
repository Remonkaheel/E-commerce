/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.net.openssl.OpenSSLStatus;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenSSLLifecycleListener
/*     */   implements LifecycleListener
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(OpenSSLLifecycleListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected static final StringManager sm = StringManager.getManager(OpenSSLLifecycleListener.class);
/*     */   
/*  46 */   protected static final Object lock = new Object();
/*     */ 
/*     */   
/*     */   public static boolean isAvailable() {
/*  50 */     if (OpenSSLStatus.isInstanceCreated()) {
/*  51 */       synchronized (lock) {
/*  52 */         if (!JreCompat.isJre22Available()) {
/*  53 */           OpenSSLStatus.setInitialized(true);
/*     */         } else {
/*     */           
/*     */           try {
/*  57 */             Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/*  58 */             openSSLLibraryClass.getMethod("init", new Class[0]).invoke(null, new Object[0]);
/*  59 */           } catch (Throwable t) {
/*  60 */             Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/*  61 */             ExceptionUtils.handleThrowable(throwable);
/*  62 */             log.error(sm.getString("openssllistener.sslInit"), throwable);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*  67 */     return OpenSSLStatus.isAvailable();
/*     */   }
/*     */   
/*     */   public OpenSSLLifecycleListener() {
/*  71 */     OpenSSLStatus.setInstanceCreated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  84 */     boolean initError = false;
/*  85 */     if ("before_init".equals(event.getType())) {
/*  86 */       if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/*  87 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*  89 */       synchronized (lock) {
/*  90 */         if (!JreCompat.isJre22Available()) {
/*  91 */           log.info(sm.getString("openssllistener.java22"));
/*  92 */           OpenSSLStatus.setInitialized(true);
/*     */           
/*     */           return;
/*     */         } 
/*     */         try {
/*  97 */           Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/*  98 */           openSSLLibraryClass.getMethod("init", new Class[0]).invoke(null, new Object[0]);
/*  99 */         } catch (Throwable t) {
/* 100 */           Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 101 */           ExceptionUtils.handleThrowable(throwable);
/* 102 */           log.error(sm.getString("openssllistener.sslInit"), throwable);
/* 103 */           initError = true;
/*     */         } 
/*     */         
/* 106 */         if (null != getFIPSMode() && !"off".equalsIgnoreCase(getFIPSMode()) && !isFIPSModeActive()) {
/* 107 */           String errorMessage = sm.getString("openssllistener.initializeFIPSFailed");
/* 108 */           Error e = new Error(errorMessage);
/*     */           
/* 110 */           log.fatal(errorMessage, e);
/* 111 */           initError = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     if (initError || "after_destroy".equals(event.getType())) {
/* 116 */       synchronized (lock) {
/* 117 */         if (!JreCompat.isJre22Available()) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/* 123 */           Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 124 */           openSSLLibraryClass.getMethod("destroy", new Class[0]).invoke(null, new Object[0]);
/* 125 */         } catch (Throwable t) {
/* 126 */           Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 127 */           ExceptionUtils.handleThrowable(throwable);
/* 128 */           log.warn(sm.getString("openssllistener.destroy"), throwable);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSSLEngine() {
/* 136 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 139 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 140 */         return (String)openSSLLibraryClass.getMethod("getSSLEngine", new Class[0]).invoke(null, new Object[0]);
/* 141 */       } catch (Throwable t) {
/* 142 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 143 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/* 146 */     return null;
/*     */   }
/*     */   
/*     */   public void setSSLEngine(String SSLEngine) {
/* 150 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 153 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 154 */         openSSLLibraryClass.getMethod("setSSLEngine", new Class[] { String.class }).invoke(null, new Object[] { SSLEngine });
/* 155 */       } catch (Throwable t) {
/* 156 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 157 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public String getSSLRandomSeed() {
/* 163 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 166 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 167 */         return (String)openSSLLibraryClass.getMethod("getSSLRandomSeed", new Class[0]).invoke(null, new Object[0]);
/* 168 */       } catch (Throwable t) {
/* 169 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 170 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */   
/*     */   public void setSSLRandomSeed(String SSLRandomSeed) {
/* 177 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 180 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 181 */         openSSLLibraryClass.getMethod("setSSLRandomSeed", new Class[] { String.class }).invoke(null, new Object[] { SSLRandomSeed });
/* 182 */       } catch (Throwable t) {
/* 183 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 184 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFIPSMode() {
/* 190 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 193 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 194 */         return (String)openSSLLibraryClass.getMethod("getFIPSMode", new Class[0]).invoke(null, new Object[0]);
/* 195 */       } catch (Throwable t) {
/* 196 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 197 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */   
/*     */   public void setFIPSMode(String FIPSMode) {
/* 204 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 207 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 208 */         openSSLLibraryClass.getMethod("setFIPSMode", new Class[] { String.class }).invoke(null, new Object[] { FIPSMode });
/* 209 */       } catch (Throwable t) {
/* 210 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 211 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFIPSModeActive() {
/* 217 */     if (JreCompat.isJre22Available()) {
/*     */       
/*     */       try {
/* 220 */         Class<?> openSSLLibraryClass = Class.forName("org.apache.tomcat.util.net.openssl.panama.OpenSSLLibrary");
/* 221 */         return ((Boolean)openSSLLibraryClass.getMethod("isFIPSModeActive", new Class[0]).invoke(null, new Object[0])).booleanValue();
/* 222 */       } catch (Throwable t) {
/* 223 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 224 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */     }
/* 227 */     return false;
/*     */   }
/*     */   
/*     */   public void setUseOpenSSL(boolean useOpenSSL) {
/* 231 */     if (useOpenSSL != OpenSSLStatus.getUseOpenSSL()) {
/* 232 */       OpenSSLStatus.setUseOpenSSL(useOpenSSL);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean getUseOpenSSL() {
/* 237 */     return OpenSSLStatus.getUseOpenSSL();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\OpenSSLLifecycleListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */