/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextNamingInfoListener
/*     */   implements LifecycleListener
/*     */ {
/*     */   private static final String PATH_ENTRY_NAME = "context/path";
/*     */   private static final String ENCODED_PATH_ENTRY_NAME = "context/encodedPath";
/*     */   private static final String WEBAPP_VERSION_ENTRY_NAME = "context/webappVersion";
/*     */   private static final String NAME_ENTRY_NAME = "context/name";
/*     */   private static final String BASE_NAME_ENTRY_NAME = "context/baseName";
/*     */   private static final String DISPLAY_NAME_ENTRY_NAME = "context/displayName";
/*  55 */   private static final Log log = LogFactory.getLog(ContextNamingInfoListener.class);
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static final StringManager sm = StringManager.getManager(ContextNamingInfoListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean emptyOnRoot = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmptyOnRoot(boolean emptyOnRoot) {
/*  70 */     this.emptyOnRoot = emptyOnRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmptyOnRoot() {
/*  79 */     return this.emptyOnRoot;
/*     */   }
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  84 */     if (event.getType().equals("configure_start")) {
/*  85 */       if (!(event.getLifecycle() instanceof Context)) {
/*  86 */         log.warn(sm.getString("listener.notContext", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */         return;
/*     */       } 
/*  89 */       Context context = (Context)event.getLifecycle();
/*  90 */       String path = context.getPath();
/*  91 */       String encodedPath = context.getEncodedPath();
/*  92 */       String name = context.getName();
/*     */       
/*  94 */       if (!this.emptyOnRoot && path.isEmpty()) {
/*  95 */         path = encodedPath = "/";
/*  96 */         name = "ROOT" + name;
/*     */       } 
/*     */       
/*  99 */       addEnvEntry(context, "context/path", path);
/* 100 */       addEnvEntry(context, "context/encodedPath", encodedPath);
/* 101 */       addEnvEntry(context, "context/webappVersion", context.getWebappVersion());
/* 102 */       addEnvEntry(context, "context/name", name);
/* 103 */       addEnvEntry(context, "context/baseName", context.getBaseName());
/* 104 */       addEnvEntry(context, "context/displayName", context.getDisplayName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addEnvEntry(Context context, String name, String value) {
/* 109 */     ContextEnvironment ce = new ContextEnvironment();
/* 110 */     ce.setName(name);
/* 111 */     ce.setOverride(true);
/* 112 */     ce.setType("java.lang.String");
/* 113 */     ce.setValue(value);
/* 114 */     if (log.isDebugEnabled()) {
/* 115 */       log.info(sm.getString("contextNamingInfoListener.envEntry", new Object[] { name, value }));
/*     */     }
/* 117 */     context.getNamingResources().addEnvironment(ce);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ContextNamingInfoListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */