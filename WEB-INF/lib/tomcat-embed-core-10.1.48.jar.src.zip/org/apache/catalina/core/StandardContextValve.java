/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.io.IOException;
/*    */ import org.apache.catalina.Wrapper;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.catalina.valves.ValveBase;
/*    */ import org.apache.coyote.ContinueResponseTiming;
/*    */ import org.apache.tomcat.util.buf.MessageBytes;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StandardContextValve
/*    */   extends ValveBase
/*    */ {
/* 40 */   private static final StringManager sm = StringManager.getManager(StandardContextValve.class);
/*    */   
/*    */   StandardContextValve() {
/* 43 */     super(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 61 */     MessageBytes requestPathMB = request.getRequestPathMB();
/* 62 */     if (requestPathMB.startsWithIgnoreCase("/META-INF/", 0) || requestPathMB.equalsIgnoreCase("/META-INF") || requestPathMB
/* 63 */       .startsWithIgnoreCase("/WEB-INF/", 0) || requestPathMB.equalsIgnoreCase("/WEB-INF")) {
/* 64 */       response.sendError(404);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 69 */     Wrapper wrapper = request.getWrapper();
/* 70 */     if (wrapper == null || wrapper.isUnavailable()) {
/* 71 */       response.sendError(404);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/*    */     try {
/* 77 */       response.sendAcknowledgement(ContinueResponseTiming.IMMEDIATELY);
/* 78 */     } catch (IOException ioe) {
/* 79 */       this.container.getLogger().error(sm.getString("standardContextValve.acknowledgeException"), ioe);
/* 80 */       request.setAttribute("jakarta.servlet.error.exception", ioe);
/* 81 */       response.sendError(500);
/*    */       
/*    */       return;
/*    */     } 
/* 85 */     if (request.isAsyncSupported()) {
/* 86 */       request.setAsyncSupported(wrapper.getPipeline().isAsyncSupported());
/*    */     }
/* 88 */     wrapper.getPipeline().getFirst().invoke(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardContextValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */