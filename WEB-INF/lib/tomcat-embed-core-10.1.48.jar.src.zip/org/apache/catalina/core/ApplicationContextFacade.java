/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterRegistration;
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import jakarta.servlet.SessionCookieConfig;
/*     */ import jakarta.servlet.SessionTrackingMode;
/*     */ import jakarta.servlet.descriptor.JspConfigDescriptor;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Enumeration;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationContextFacade
/*     */   implements ServletContext
/*     */ {
/*     */   private final Map<String, Class<?>[]> classCache;
/*     */   private final Map<String, Method> objectCache;
/*     */   private final ApplicationContext context;
/*     */   
/*     */   public ApplicationContextFacade(ApplicationContext context) {
/*  79 */     this.context = context;
/*     */     
/*  81 */     this.classCache = (Map)new HashMap<>();
/*  82 */     this.objectCache = new ConcurrentHashMap<>();
/*  83 */     initClassCache();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initClassCache() {
/*  88 */     Class<?>[] clazz = new Class[] { String.class };
/*  89 */     this.classCache.put("getContext", clazz);
/*  90 */     this.classCache.put("getMimeType", clazz);
/*  91 */     this.classCache.put("getResourcePaths", clazz);
/*  92 */     this.classCache.put("getResource", clazz);
/*  93 */     this.classCache.put("getResourceAsStream", clazz);
/*  94 */     this.classCache.put("getRequestDispatcher", clazz);
/*  95 */     this.classCache.put("getNamedDispatcher", clazz);
/*  96 */     this.classCache.put("getServlet", clazz);
/*  97 */     this.classCache.put("setInitParameter", new Class[] { String.class, String.class });
/*  98 */     this.classCache.put("createServlet", new Class[] { Class.class });
/*  99 */     this.classCache.put("addServlet", new Class[] { String.class, String.class });
/* 100 */     this.classCache.put("createFilter", new Class[] { Class.class });
/* 101 */     this.classCache.put("addFilter", new Class[] { String.class, String.class });
/* 102 */     this.classCache.put("createListener", new Class[] { Class.class });
/* 103 */     this.classCache.put("addListener", clazz);
/* 104 */     this.classCache.put("getFilterRegistration", clazz);
/* 105 */     this.classCache.put("getServletRegistration", clazz);
/* 106 */     this.classCache.put("getInitParameter", clazz);
/* 107 */     this.classCache.put("setAttribute", new Class[] { String.class, Object.class });
/* 108 */     this.classCache.put("removeAttribute", clazz);
/* 109 */     this.classCache.put("getRealPath", clazz);
/* 110 */     this.classCache.put("getAttribute", clazz);
/* 111 */     this.classCache.put("log", clazz);
/* 112 */     this.classCache.put("setSessionTrackingModes", new Class[] { Set.class });
/* 113 */     this.classCache.put("addJspFile", new Class[] { String.class, String.class });
/* 114 */     this.classCache.put("declareRoles", new Class[] { String[].class });
/* 115 */     this.classCache.put("setSessionTimeout", new Class[] { int.class });
/* 116 */     this.classCache.put("setRequestCharacterEncoding", new Class[] { String.class });
/* 117 */     this.classCache.put("setResponseCharacterEncoding", new Class[] { String.class });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletContext getContext(String uripath) {
/* 135 */     ServletContext theContext = null;
/* 136 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 137 */       theContext = (ServletContext)doPrivileged("getContext", new Object[] { uripath });
/*     */     } else {
/* 139 */       theContext = this.context.getContext(uripath);
/*     */     } 
/* 141 */     if (theContext != null && theContext instanceof ApplicationContext) {
/* 142 */       theContext = ((ApplicationContext)theContext).getFacade();
/*     */     }
/* 144 */     return theContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 150 */     return this.context.getMajorVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 156 */     return this.context.getMinorVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMimeType(String file) {
/* 162 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 163 */       return (String)doPrivileged("getMimeType", new Object[] { file });
/*     */     }
/* 165 */     return this.context.getMimeType(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getResourcePaths(String path) {
/* 172 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 173 */       return (Set<String>)doPrivileged("getResourcePaths", new Object[] { path });
/*     */     }
/* 175 */     return this.context.getResourcePaths(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResource(String path) throws MalformedURLException {
/* 182 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 184 */         return (URL)invokeMethod(this.context, "getResource", new Object[] { path });
/* 185 */       } catch (Throwable t) {
/* 186 */         ExceptionUtils.handleThrowable(t);
/* 187 */         if (t instanceof MalformedURLException) {
/* 188 */           throw (MalformedURLException)t;
/*     */         }
/* 190 */         return null;
/*     */       } 
/*     */     }
/* 193 */     return this.context.getResource(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getResourceAsStream(String path) {
/* 200 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 201 */       return (InputStream)doPrivileged("getResourceAsStream", new Object[] { path });
/*     */     }
/* 203 */     return this.context.getResourceAsStream(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestDispatcher getRequestDispatcher(String path) {
/* 210 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 211 */       return (RequestDispatcher)doPrivileged("getRequestDispatcher", new Object[] { path });
/*     */     }
/* 213 */     return this.context.getRequestDispatcher(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestDispatcher getNamedDispatcher(String name) {
/* 220 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 221 */       return (RequestDispatcher)doPrivileged("getNamedDispatcher", new Object[] { name });
/*     */     }
/* 223 */     return this.context.getNamedDispatcher(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String msg) {
/* 230 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 231 */       doPrivileged("log", new Object[] { msg });
/*     */     } else {
/* 233 */       this.context.log(msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Throwable throwable) {
/* 240 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 241 */       doPrivileged("log", new Class[] { String.class, Throwable.class }, new Object[] { message, throwable });
/*     */     } else {
/* 243 */       this.context.log(message, throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRealPath(String path) {
/* 250 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 251 */       return (String)doPrivileged("getRealPath", new Object[] { path });
/*     */     }
/* 253 */     return this.context.getRealPath(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerInfo() {
/* 260 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 261 */       return (String)doPrivileged("getServerInfo", null);
/*     */     }
/* 263 */     return this.context.getServerInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInitParameter(String name) {
/* 270 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 271 */       return (String)doPrivileged("getInitParameter", new Object[] { name });
/*     */     }
/* 273 */     return this.context.getInitParameter(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getInitParameterNames() {
/* 281 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 282 */       return (Enumeration<String>)doPrivileged("getInitParameterNames", null);
/*     */     }
/* 284 */     return this.context.getInitParameterNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/* 291 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 292 */       return doPrivileged("getAttribute", new Object[] { name });
/*     */     }
/* 294 */     return this.context.getAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/* 302 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 303 */       return (Enumeration<String>)doPrivileged("getAttributeNames", null);
/*     */     }
/* 305 */     return this.context.getAttributeNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object object) {
/* 312 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 313 */       doPrivileged("setAttribute", new Object[] { name, object });
/*     */     } else {
/* 315 */       this.context.setAttribute(name, object);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 322 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 323 */       doPrivileged("removeAttribute", new Object[] { name });
/*     */     } else {
/* 325 */       this.context.removeAttribute(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServletContextName() {
/* 332 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 333 */       return (String)doPrivileged("getServletContextName", null);
/*     */     }
/* 335 */     return this.context.getServletContextName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/* 342 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 343 */       return (String)doPrivileged("getContextPath", null);
/*     */     }
/* 345 */     return this.context.getContextPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, String className) {
/* 352 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 353 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Object[] { filterName, className });
/*     */     }
/* 355 */     return this.context.addFilter(filterName, className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter) {
/* 362 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 363 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Filter.class }, new Object[] { filterName, filter });
/*     */     }
/*     */     
/* 366 */     return this.context.addFilter(filterName, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass) {
/* 373 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 374 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Class.class }, new Object[] { filterName, filterClass });
/*     */     }
/*     */     
/* 377 */     return this.context.addFilter(filterName, filterClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Filter> T createFilter(Class<T> c) throws ServletException {
/* 384 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 386 */         return (T)invokeMethod(this.context, "createFilter", new Object[] { c });
/* 387 */       } catch (Throwable t) {
/* 388 */         ExceptionUtils.handleThrowable(t);
/* 389 */         if (t instanceof ServletException) {
/* 390 */           throw (ServletException)t;
/*     */         }
/* 392 */         return null;
/*     */       } 
/*     */     }
/* 395 */     return this.context.createFilter(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterRegistration getFilterRegistration(String filterName) {
/* 402 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 403 */       return (FilterRegistration)doPrivileged("getFilterRegistration", new Object[] { filterName });
/*     */     }
/* 405 */     return this.context.getFilterRegistration(filterName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, String className) {
/* 412 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 413 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Object[] { servletName, className });
/*     */     }
/* 415 */     return this.context.addServlet(servletName, className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet) {
/* 422 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 423 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Servlet.class }, new Object[] { servletName, servlet });
/*     */     }
/*     */     
/* 426 */     return this.context.addServlet(servletName, servlet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass) {
/* 433 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 434 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Class.class }, new Object[] { servletName, servletClass });
/*     */     }
/*     */     
/* 437 */     return this.context.addServlet(servletName, servletClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistration.Dynamic addJspFile(String jspName, String jspFile) {
/* 444 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 445 */       return (ServletRegistration.Dynamic)doPrivileged("addJspFile", new Object[] { jspName, jspFile });
/*     */     }
/* 447 */     return this.context.addJspFile(jspName, jspFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Servlet> T createServlet(Class<T> c) throws ServletException {
/* 455 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 457 */         return (T)invokeMethod(this.context, "createServlet", new Object[] { c });
/* 458 */       } catch (Throwable t) {
/* 459 */         ExceptionUtils.handleThrowable(t);
/* 460 */         if (t instanceof ServletException) {
/* 461 */           throw (ServletException)t;
/*     */         }
/* 463 */         return null;
/*     */       } 
/*     */     }
/* 466 */     return this.context.createServlet(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRegistration getServletRegistration(String servletName) {
/* 473 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 474 */       return (ServletRegistration)doPrivileged("getServletRegistration", new Object[] { servletName });
/*     */     }
/* 476 */     return this.context.getServletRegistration(servletName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes() {
/* 484 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 485 */       return (Set<SessionTrackingMode>)doPrivileged("getDefaultSessionTrackingModes", null);
/*     */     }
/* 487 */     return this.context.getDefaultSessionTrackingModes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes() {
/* 494 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 495 */       return (Set<SessionTrackingMode>)doPrivileged("getEffectiveSessionTrackingModes", null);
/*     */     }
/* 497 */     return this.context.getEffectiveSessionTrackingModes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionCookieConfig getSessionCookieConfig() {
/* 504 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 505 */       return (SessionCookieConfig)doPrivileged("getSessionCookieConfig", null);
/*     */     }
/* 507 */     return this.context.getSessionCookieConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes) {
/* 514 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 515 */       doPrivileged("setSessionTrackingModes", new Object[] { sessionTrackingModes });
/*     */     } else {
/* 517 */       this.context.setSessionTrackingModes(sessionTrackingModes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setInitParameter(String name, String value) {
/* 524 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 525 */       return ((Boolean)doPrivileged("setInitParameter", new Object[] { name, value })).booleanValue();
/*     */     }
/* 527 */     return this.context.setInitParameter(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(Class<? extends EventListener> listenerClass) {
/* 534 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 535 */       doPrivileged("addListener", new Class[] { Class.class }, new Object[] { listenerClass });
/*     */     } else {
/* 537 */       this.context.addListener(listenerClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(String className) {
/* 544 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 545 */       doPrivileged("addListener", new Object[] { className });
/*     */     } else {
/* 547 */       this.context.addListener(className);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends EventListener> void addListener(T t) {
/* 554 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 555 */       doPrivileged("addListener", new Class[] { EventListener.class }, new Object[] { t });
/*     */     } else {
/* 557 */       this.context.addListener(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends EventListener> T createListener(Class<T> c) throws ServletException {
/* 565 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 567 */         return (T)invokeMethod(this.context, "createListener", new Object[] { c });
/* 568 */       } catch (Throwable t) {
/* 569 */         ExceptionUtils.handleThrowable(t);
/* 570 */         if (t instanceof ServletException) {
/* 571 */           throw (ServletException)t;
/*     */         }
/* 573 */         return null;
/*     */       } 
/*     */     }
/* 576 */     return this.context.createListener(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareRoles(String... roleNames) {
/* 583 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 584 */       doPrivileged("declareRoles", new Object[] { roleNames });
/*     */     } else {
/* 586 */       this.context.declareRoles(roleNames);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 593 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 594 */       return (ClassLoader)doPrivileged("getClassLoader", null);
/*     */     }
/* 596 */     return this.context.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEffectiveMajorVersion() {
/* 603 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 604 */       return ((Integer)doPrivileged("getEffectiveMajorVersion", null)).intValue();
/*     */     }
/* 606 */     return this.context.getEffectiveMajorVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEffectiveMinorVersion() {
/* 613 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 614 */       return ((Integer)doPrivileged("getEffectiveMinorVersion", null)).intValue();
/*     */     }
/* 616 */     return this.context.getEffectiveMinorVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ? extends FilterRegistration> getFilterRegistrations() {
/* 624 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 625 */       return (Map<String, ? extends FilterRegistration>)doPrivileged("getFilterRegistrations", null);
/*     */     }
/* 627 */     return this.context.getFilterRegistrations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JspConfigDescriptor getJspConfigDescriptor() {
/* 634 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 635 */       return (JspConfigDescriptor)doPrivileged("getJspConfigDescriptor", null);
/*     */     }
/* 637 */     return this.context.getJspConfigDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ? extends ServletRegistration> getServletRegistrations() {
/* 645 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 646 */       return (Map<String, ? extends ServletRegistration>)doPrivileged("getServletRegistrations", null);
/*     */     }
/* 648 */     return this.context.getServletRegistrations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVirtualServerName() {
/* 655 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 656 */       return (String)doPrivileged("getVirtualServerName", null);
/*     */     }
/* 658 */     return this.context.getVirtualServerName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSessionTimeout() {
/* 665 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 666 */       return ((Integer)doPrivileged("getSessionTimeout", null)).intValue();
/*     */     }
/* 668 */     return this.context.getSessionTimeout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionTimeout(int sessionTimeout) {
/* 675 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 676 */       doPrivileged("setSessionTimeout", new Object[] { Integer.valueOf(sessionTimeout) });
/*     */     } else {
/* 678 */       this.context.setSessionTimeout(sessionTimeout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequestCharacterEncoding() {
/* 685 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 686 */       return (String)doPrivileged("getRequestCharacterEncoding", null);
/*     */     }
/* 688 */     return this.context.getRequestCharacterEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestCharacterEncoding(String encoding) {
/* 695 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 696 */       doPrivileged("setRequestCharacterEncoding", new Object[] { encoding });
/*     */     } else {
/* 698 */       this.context.setRequestCharacterEncoding(encoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResponseCharacterEncoding() {
/* 705 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 706 */       return (String)doPrivileged("getResponseCharacterEncoding", null);
/*     */     }
/* 708 */     return this.context.getResponseCharacterEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseCharacterEncoding(String encoding) {
/* 715 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 716 */       doPrivileged("setResponseCharacterEncoding", new Object[] { encoding });
/*     */     } else {
/* 718 */       this.context.setResponseCharacterEncoding(encoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object doPrivileged(String methodName, Object[] params) {
/*     */     try {
/* 731 */       return invokeMethod(this.context, methodName, params);
/* 732 */     } catch (Throwable t) {
/* 733 */       ExceptionUtils.handleThrowable(t);
/* 734 */       throw new RuntimeException(t.getMessage(), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object invokeMethod(ApplicationContext appContext, String methodName, Object[] params) throws Throwable {
/*     */     try {
/* 750 */       Method method = this.objectCache.get(methodName);
/* 751 */       if (method == null) {
/* 752 */         method = appContext.getClass().getMethod(methodName, this.classCache.get(methodName));
/* 753 */         this.objectCache.put(methodName, method);
/*     */       } 
/*     */       
/* 756 */       return executeMethod(method, appContext, params);
/* 757 */     } catch (Exception ex) {
/* 758 */       handleException(ex);
/* 759 */       return null;
/*     */     } finally {
/* 761 */       params = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object doPrivileged(String methodName, Class<?>[] clazz, Object[] params) {
/*     */     try {
/* 775 */       Method method = this.context.getClass().getMethod(methodName, clazz);
/* 776 */       return executeMethod(method, this.context, params);
/* 777 */     } catch (Exception ex) {
/*     */       try {
/* 779 */         handleException(ex);
/* 780 */       } catch (Throwable t) {
/* 781 */         ExceptionUtils.handleThrowable(t);
/* 782 */         throw new RuntimeException(t.getMessage());
/*     */       } 
/* 784 */       return null;
/*     */     } finally {
/* 786 */       params = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object executeMethod(Method method, ApplicationContext context, Object[] params) throws PrivilegedActionException, IllegalAccessException, InvocationTargetException {
/* 801 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 802 */       return AccessController.doPrivileged(new PrivilegedExecuteMethod(method, context, params));
/*     */     }
/* 804 */     return method.invoke(context, params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleException(Exception ex) throws Throwable {
/*     */     Throwable realException;
/* 818 */     if (ex instanceof PrivilegedActionException) {
/* 819 */       ex = ((PrivilegedActionException)ex).getException();
/*     */     }
/*     */     
/* 822 */     if (ex instanceof InvocationTargetException) {
/* 823 */       realException = ex.getCause();
/* 824 */       if (realException == null) {
/* 825 */         realException = ex;
/*     */       }
/*     */     } else {
/* 828 */       realException = ex;
/*     */     } 
/*     */     
/* 831 */     throw realException;
/*     */   }
/*     */   
/*     */   private static class PrivilegedExecuteMethod
/*     */     implements PrivilegedExceptionAction<Object>
/*     */   {
/*     */     private final Method method;
/*     */     private final ApplicationContext context;
/*     */     private final Object[] params;
/*     */     
/*     */     PrivilegedExecuteMethod(Method method, ApplicationContext context, Object[] params) {
/* 842 */       this.method = method;
/* 843 */       this.context = context;
/* 844 */       this.params = params;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object run() throws Exception {
/* 849 */       return this.method.invoke(this.context, this.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationContextFacade.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */