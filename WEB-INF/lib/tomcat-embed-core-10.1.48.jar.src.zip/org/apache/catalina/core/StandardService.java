/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.mapper.Mapper;
/*     */ import org.apache.catalina.mapper.MapperListener;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardService
/*     */   extends LifecycleMBeanBase
/*     */   implements Service
/*     */ {
/*  53 */   private static final Log log = LogFactory.getLog(StandardService.class);
/*  54 */   private static final StringManager sm = StringManager.getManager(StandardService.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private String name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private Server server = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   protected Connector[] connectors = new Connector[0];
/*  80 */   private final ReadWriteLock connectorsLock = new ReentrantReadWriteLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   protected final ArrayList<Executor> executors = new ArrayList<>();
/*  86 */   private final ReadWriteLock executorsLock = new ReentrantReadWriteLock();
/*     */   
/*  88 */   private Engine engine = null;
/*     */   
/*  90 */   private ClassLoader parentClassLoader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   protected final Mapper mapper = new Mapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   protected final MapperListener mapperListener = new MapperListener(this);
/*     */ 
/*     */   
/* 104 */   private long gracefulStopAwaitMillis = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getGracefulStopAwaitMillis() {
/* 110 */     return this.gracefulStopAwaitMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGracefulStopAwaitMillis(long gracefulStopAwaitMillis) {
/* 115 */     this.gracefulStopAwaitMillis = gracefulStopAwaitMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mapper getMapper() {
/* 121 */     return this.mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Engine getContainer() {
/* 127 */     return this.engine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Engine engine) {
/* 133 */     Engine oldEngine = this.engine;
/* 134 */     if (oldEngine != null) {
/* 135 */       oldEngine.setService(null);
/*     */     }
/* 137 */     this.engine = engine;
/* 138 */     if (this.engine != null) {
/* 139 */       this.engine.setService(this);
/*     */     }
/* 141 */     if (getState().isAvailable()) {
/* 142 */       if (this.engine != null) {
/*     */         try {
/* 144 */           this.engine.start();
/* 145 */         } catch (LifecycleException e) {
/* 146 */           log.error(sm.getString("standardService.engine.startFailed"), (Throwable)e);
/*     */         } 
/*     */       }
/*     */       
/*     */       try {
/* 151 */         this.mapperListener.stop();
/* 152 */       } catch (LifecycleException e) {
/* 153 */         log.error(sm.getString("standardService.mapperListener.stopFailed"), (Throwable)e);
/*     */       } 
/*     */       try {
/* 156 */         this.mapperListener.start();
/* 157 */       } catch (LifecycleException e) {
/* 158 */         log.error(sm.getString("standardService.mapperListener.startFailed"), (Throwable)e);
/*     */       } 
/* 160 */       if (oldEngine != null) {
/*     */         try {
/* 162 */           oldEngine.stop();
/* 163 */         } catch (LifecycleException e) {
/* 164 */           log.error(sm.getString("standardService.engine.stopFailed"), (Throwable)e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 170 */     this.support.firePropertyChange("container", oldEngine, this.engine);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 176 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 182 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Server getServer() {
/* 188 */     return this.server;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServer(Server server) {
/* 194 */     this.server = server;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConnector(Connector connector) {
/* 203 */     Lock writeLock = this.connectorsLock.writeLock();
/* 204 */     writeLock.lock();
/*     */     try {
/* 206 */       connector.setService(this);
/* 207 */       Connector[] results = new Connector[this.connectors.length + 1];
/* 208 */       System.arraycopy(this.connectors, 0, results, 0, this.connectors.length);
/* 209 */       results[this.connectors.length] = connector;
/* 210 */       this.connectors = results;
/*     */     } finally {
/* 212 */       writeLock.unlock();
/*     */     } 
/*     */     
/*     */     try {
/* 216 */       if (getState().isAvailable()) {
/* 217 */         connector.start();
/*     */       }
/* 219 */     } catch (LifecycleException e) {
/* 220 */       throw new IllegalArgumentException(sm.getString("standardService.connector.startFailed", new Object[] { connector }), e);
/*     */     } 
/*     */ 
/*     */     
/* 224 */     this.support.firePropertyChange("connector", (Object)null, connector);
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectName[] getConnectorNames() {
/* 229 */     Lock readLock = this.connectorsLock.readLock();
/* 230 */     readLock.lock();
/*     */     try {
/* 232 */       ObjectName[] results = new ObjectName[this.connectors.length];
/* 233 */       for (int i = 0; i < results.length; i++) {
/* 234 */         results[i] = this.connectors[i].getObjectName();
/*     */       }
/* 236 */       return results;
/*     */     } finally {
/* 238 */       readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 249 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Connector[] findConnectors() {
/* 255 */     Lock readLock = this.connectorsLock.readLock();
/* 256 */     readLock.lock();
/*     */     
/*     */     try {
/* 259 */       return (Connector[])this.connectors.clone();
/*     */     } finally {
/* 261 */       readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnector(Connector connector) {
/* 269 */     Lock writeLock = this.connectorsLock.writeLock();
/* 270 */     writeLock.lock();
/*     */     try {
/* 272 */       int j = -1;
/* 273 */       for (int i = 0; i < this.connectors.length; i++) {
/* 274 */         if (connector == this.connectors[i]) {
/* 275 */           j = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 279 */       if (j < 0) {
/*     */         return;
/*     */       }
/* 282 */       int k = 0;
/* 283 */       Connector[] results = new Connector[this.connectors.length - 1];
/* 284 */       for (int m = 0; m < this.connectors.length; m++) {
/* 285 */         if (m != j) {
/* 286 */           results[k++] = this.connectors[m];
/*     */         }
/*     */       } 
/* 289 */       this.connectors = results;
/*     */     } finally {
/*     */       
/* 292 */       writeLock.unlock();
/*     */     } 
/*     */     
/* 295 */     if (connector.getState().isAvailable()) {
/*     */       try {
/* 297 */         connector.stop();
/* 298 */       } catch (LifecycleException e) {
/* 299 */         log.error(sm.getString("standardService.connector.stopFailed", new Object[] { connector }), (Throwable)e);
/*     */       } 
/*     */     }
/* 302 */     connector.setService(null);
/*     */ 
/*     */     
/* 305 */     this.support.firePropertyChange("connector", connector, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 315 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 321 */     return "StandardService[" + getName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExecutor(Executor ex) {
/* 327 */     boolean added = false;
/* 328 */     this.executorsLock.writeLock().lock();
/*     */     try {
/* 330 */       if (!this.executors.contains(ex)) {
/* 331 */         added = true;
/* 332 */         this.executors.add(ex);
/*     */       } 
/*     */     } finally {
/* 335 */       this.executorsLock.writeLock().unlock();
/*     */     } 
/* 337 */     if (added && getState().isAvailable()) {
/*     */       try {
/* 339 */         ex.start();
/* 340 */       } catch (LifecycleException x) {
/* 341 */         log.error(sm.getString("standardService.executor.start"), (Throwable)x);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Executor[] findExecutors() {
/* 349 */     this.executorsLock.readLock().lock();
/*     */     try {
/* 351 */       return this.executors.<Executor>toArray(new Executor[0]);
/*     */     } finally {
/* 353 */       this.executorsLock.readLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Executor getExecutor(String executorName) {
/* 360 */     this.executorsLock.readLock().lock();
/*     */     try {
/* 362 */       for (Executor executor : this.executors) {
/* 363 */         if (executorName.equals(executor.getName())) {
/* 364 */           return executor;
/*     */         }
/*     */       } 
/*     */     } finally {
/* 368 */       this.executorsLock.readLock().unlock();
/*     */     } 
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeExecutor(Executor ex) {
/*     */     boolean removed;
/* 377 */     this.executorsLock.writeLock().lock();
/*     */     try {
/* 379 */       removed = this.executors.remove(ex);
/*     */     } finally {
/* 381 */       this.executorsLock.writeLock().unlock();
/*     */     } 
/* 383 */     if (removed && getState().isAvailable()) {
/*     */       try {
/* 385 */         ex.stop();
/* 386 */       } catch (LifecycleException e) {
/* 387 */         log.error(sm.getString("standardService.executor.stop"), (Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 403 */     if (log.isInfoEnabled()) {
/* 404 */       log.info(sm.getString("standardService.start.name", new Object[] { this.name }));
/*     */     }
/* 406 */     setState(LifecycleState.STARTING);
/*     */ 
/*     */     
/* 409 */     if (this.engine != null) {
/* 410 */       this.engine.start();
/*     */     }
/*     */     
/* 413 */     for (Executor executor : findExecutors()) {
/* 414 */       executor.start();
/*     */     }
/*     */     
/* 417 */     this.mapperListener.start();
/*     */ 
/*     */     
/* 420 */     for (Connector connector : findConnectors()) {
/*     */       
/* 422 */       if (connector.getState() != LifecycleState.FAILED) {
/* 423 */         connector.start();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 438 */     Connector[] connectors = findConnectors();
/*     */ 
/*     */ 
/*     */     
/* 442 */     for (Connector connector : connectors) {
/* 443 */       connector.getProtocolHandler().closeServerSocketGraceful();
/*     */     }
/*     */ 
/*     */     
/* 447 */     long waitMillis = this.gracefulStopAwaitMillis;
/* 448 */     if (waitMillis > 0L) {
/* 449 */       for (Connector connector : connectors) {
/* 450 */         waitMillis = connector.getProtocolHandler().awaitConnectionsClose(waitMillis);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 455 */     for (Connector connector : connectors) {
/* 456 */       connector.pause();
/*     */     }
/*     */     
/* 459 */     if (log.isInfoEnabled()) {
/* 460 */       log.info(sm.getString("standardService.stop.name", new Object[] { this.name }));
/*     */     }
/* 462 */     setState(LifecycleState.STOPPING);
/*     */ 
/*     */     
/* 465 */     if (this.engine != null) {
/* 466 */       this.engine.stop();
/*     */     }
/*     */ 
/*     */     
/* 470 */     for (Connector connector : connectors) {
/* 471 */       if (LifecycleState.STARTED.equals(connector.getState()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 477 */         connector.stop();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 482 */     if (this.mapperListener.getState() != LifecycleState.INITIALIZED) {
/* 483 */       this.mapperListener.stop();
/*     */     }
/*     */     
/* 486 */     for (Executor executor : findExecutors()) {
/* 487 */       executor.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/* 501 */     super.initInternal();
/*     */     
/* 503 */     if (this.engine != null) {
/* 504 */       this.engine.init();
/*     */     }
/*     */ 
/*     */     
/* 508 */     for (Executor executor : findExecutors()) {
/* 509 */       if (executor instanceof JmxEnabled) {
/* 510 */         ((JmxEnabled)executor).setDomain(getDomain());
/*     */       }
/* 512 */       executor.init();
/*     */     } 
/*     */ 
/*     */     
/* 516 */     this.mapperListener.init();
/*     */ 
/*     */     
/* 519 */     for (Connector connector : findConnectors()) {
/* 520 */       connector.init();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyInternal() throws LifecycleException {
/* 527 */     this.mapperListener.destroy();
/*     */ 
/*     */     
/* 530 */     for (Connector connector : findConnectors()) {
/* 531 */       connector.destroy();
/*     */     }
/*     */ 
/*     */     
/* 535 */     for (Executor executor : findExecutors()) {
/* 536 */       executor.destroy();
/*     */     }
/*     */     
/* 539 */     if (this.engine != null) {
/* 540 */       this.engine.destroy();
/*     */     }
/*     */     
/* 543 */     super.destroyInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getParentClassLoader() {
/* 549 */     if (this.parentClassLoader != null) {
/* 550 */       return this.parentClassLoader;
/*     */     }
/* 552 */     if (this.server != null) {
/* 553 */       return this.server.getParentClassLoader();
/*     */     }
/* 555 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentClassLoader(ClassLoader parent) {
/* 561 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/* 562 */     this.parentClassLoader = parent;
/* 563 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 569 */     String domain = null;
/* 570 */     Engine engine = getContainer();
/*     */ 
/*     */     
/* 573 */     if (engine != null) {
/* 574 */       domain = engine.getName();
/*     */     }
/*     */ 
/*     */     
/* 578 */     if (domain == null) {
/* 579 */       domain = getName();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 584 */     return domain;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getObjectNameKeyProperties() {
/* 590 */     return "type=Service";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardService.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */