/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import jakarta.servlet.MultipartConfigElement;
/*      */ import jakarta.servlet.Servlet;
/*      */ import jakarta.servlet.ServletConfig;
/*      */ import jakarta.servlet.ServletContext;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.UnavailableException;
/*      */ import jakarta.servlet.annotation.MultipartConfig;
/*      */ import jakarta.servlet.http.HttpServlet;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.PeriodicEventListener;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.log.SystemLogHandler;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.modeler.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardWrapper
/*      */   extends ContainerBase
/*      */   implements ServletConfig, Wrapper, NotificationEmitter
/*      */ {
/*   71 */   private final Log log = LogFactory.getLog(StandardWrapper.class);
/*      */   
/*   73 */   protected static final String[] DEFAULT_SERVLET_METHODS = new String[] { "GET", "HEAD", "POST" }; protected long available; protected final NotificationBroadcasterSupport broadcaster;
/*      */   protected final AtomicInteger countAllocated;
/*      */   protected final StandardWrapperFacade facade;
/*      */   protected volatile Servlet instance;
/*      */   protected volatile boolean instanceInitialized;
/*      */   protected int loadOnStartup;
/*      */   protected final ArrayList<String> mappings;
/*      */   protected HashMap<String, String> parameters;
/*      */   protected HashMap<String, String> references;
/*      */   protected String runAs;
/*      */   protected long sequenceNumber;
/*      */   protected String servletClass;
/*      */   protected volatile boolean unloading;
/*      */   protected long unloadDelay;
/*      */   protected boolean isJspServlet;
/*      */   protected ObjectName jspMonitorON;
/*      */   protected boolean swallowOutput;
/*      */   StandardWrapperValve swValve;
/*      */   protected long loadTime;
/*      */   protected int classLoadTime;
/*      */   protected MultipartConfigElement multipartConfigElement;
/*      */   protected boolean asyncSupported;
/*      */   protected boolean enabled;
/*      */   private boolean overridable;
/*      */   
/*      */   public StandardWrapper() {
/*   99 */     this.available = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  109 */     this.countAllocated = new AtomicInteger(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  115 */     this.facade = new StandardWrapperFacade(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     this.instance = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  127 */     this.instanceInitialized = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  133 */     this.loadOnStartup = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  139 */     this.mappings = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     this.parameters = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     this.references = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  158 */     this.runAs = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  163 */     this.sequenceNumber = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  168 */     this.servletClass = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  174 */     this.unloading = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     this.unloadDelay = 2000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  198 */     this.swallowOutput = false;
/*      */ 
/*      */ 
/*      */     
/*  202 */     this.loadTime = 0L;
/*  203 */     this.classLoadTime = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  208 */     this.multipartConfigElement = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  213 */     this.asyncSupported = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  218 */     this.enabled = true;
/*      */     
/*  220 */     this.overridable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  227 */     this.parametersLock = new ReentrantReadWriteLock();
/*      */     
/*  229 */     this.mappingsLock = new ReentrantReadWriteLock();
/*      */     
/*  231 */     this.referencesLock = new ReentrantReadWriteLock();
/*      */     this.swValve = new StandardWrapperValve();
/*      */     this.pipeline.setBasic((Valve)this.swValve);
/*      */     this.broadcaster = new NotificationBroadcasterSupport();
/*      */   }
/*      */   protected static Class<?>[] classType = new Class[] { ServletConfig.class }; private final ReentrantReadWriteLock parametersLock;
/*      */   public boolean isOverridable() {
/*  238 */     return this.overridable;
/*      */   }
/*      */   private final ReentrantReadWriteLock mappingsLock; private final ReentrantReadWriteLock referencesLock; protected MBeanNotificationInfo[] notificationInfo;
/*      */   
/*      */   public void setOverridable(boolean overridable) {
/*  243 */     this.overridable = overridable;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getAvailable() {
/*  248 */     return this.available;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAvailable(long available) {
/*  254 */     long oldAvailable = this.available;
/*  255 */     if (available > System.currentTimeMillis()) {
/*  256 */       this.available = available;
/*      */     } else {
/*  258 */       this.available = 0L;
/*      */     } 
/*  260 */     this.support.firePropertyChange("available", Long.valueOf(oldAvailable), Long.valueOf(this.available));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCountAllocated() {
/*  268 */     return this.countAllocated.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLoadOnStartup() {
/*  275 */     if (this.isJspServlet && this.loadOnStartup == -1)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  280 */       return Integer.MAX_VALUE;
/*      */     }
/*  282 */     return this.loadOnStartup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoadOnStartup(int value) {
/*  290 */     int oldLoadOnStartup = this.loadOnStartup;
/*  291 */     this.loadOnStartup = value;
/*  292 */     this.support.firePropertyChange("loadOnStartup", Integer.valueOf(oldLoadOnStartup), 
/*  293 */         Integer.valueOf(this.loadOnStartup));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoadOnStartupString(String value) {
/*      */     try {
/*  308 */       setLoadOnStartup(Integer.parseInt(value));
/*  309 */     } catch (NumberFormatException e) {
/*  310 */       setLoadOnStartup(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLoadOnStartupString() {
/*  318 */     return Integer.toString(getLoadOnStartup());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParent(Container container) {
/*  330 */     if (container != null && !(container instanceof Context)) {
/*  331 */       throw new IllegalArgumentException(sm.getString("standardWrapper.notContext"));
/*      */     }
/*  333 */     if (container instanceof StandardContext) {
/*  334 */       this.swallowOutput = ((StandardContext)container).getSwallowOutput();
/*  335 */       this.unloadDelay = ((StandardContext)container).getUnloadDelay();
/*      */     } 
/*  337 */     super.setParent(container);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRunAs() {
/*  344 */     return this.runAs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRunAs(String runAs) {
/*  351 */     String oldRunAs = this.runAs;
/*  352 */     this.runAs = runAs;
/*  353 */     this.support.firePropertyChange("runAs", oldRunAs, this.runAs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServletClass() {
/*  360 */     return this.servletClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServletClass(String servletClass) {
/*  367 */     String oldServletClass = this.servletClass;
/*  368 */     this.servletClass = servletClass;
/*  369 */     this.support.firePropertyChange("servletClass", oldServletClass, this.servletClass);
/*  370 */     if ("org.apache.jasper.servlet.JspServlet".equals(servletClass)) {
/*  371 */       this.isJspServlet = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServletName(String name) {
/*  384 */     setName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnavailable() {
/*  392 */     if (!isEnabled())
/*  393 */       return true; 
/*  394 */     if (this.available == 0L)
/*  395 */       return false; 
/*  396 */     if (this.available <= System.currentTimeMillis()) {
/*  397 */       this.available = 0L;
/*  398 */       return false;
/*      */     } 
/*  400 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getServletMethods() throws ServletException {
/*  409 */     this.instance = loadServlet();
/*      */     
/*  411 */     Class<? extends Servlet> servletClazz = this.instance.getClass();
/*  412 */     if (!HttpServlet.class.isAssignableFrom(servletClazz)) {
/*  413 */       return DEFAULT_SERVLET_METHODS;
/*      */     }
/*      */     
/*  416 */     Set<String> allow = new HashSet<>();
/*  417 */     allow.add("OPTIONS");
/*      */     
/*  419 */     if (this.isJspServlet) {
/*  420 */       allow.add("GET");
/*  421 */       allow.add("HEAD");
/*  422 */       allow.add("POST");
/*      */     } else {
/*  424 */       allow.add("TRACE");
/*      */       
/*  426 */       Method[] methods = getAllDeclaredMethods(servletClazz);
/*  427 */       for (int i = 0; methods != null && i < methods.length; i++) {
/*  428 */         Method m = methods[i];
/*      */         
/*  430 */         switch (m.getName()) {
/*      */           case "doGet":
/*  432 */             allow.add("GET");
/*  433 */             allow.add("HEAD");
/*      */             break;
/*      */           case "doPost":
/*  436 */             allow.add("POST");
/*      */             break;
/*      */           case "doPut":
/*  439 */             allow.add("PUT");
/*      */             break;
/*      */           case "doDelete":
/*  442 */             allow.add("DELETE");
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*      */     } 
/*  448 */     return allow.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Servlet getServlet() {
/*  454 */     return this.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServlet(Servlet servlet) {
/*  460 */     this.instance = servlet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void backgroundProcess() {
/*  468 */     super.backgroundProcess();
/*      */     
/*  470 */     if (!getState().isAvailable()) {
/*      */       return;
/*      */     }
/*      */     
/*  474 */     if (getServlet() instanceof PeriodicEventListener) {
/*  475 */       ((PeriodicEventListener)getServlet()).periodicEvent();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable getRootCause(ServletException e) {
/*      */     Throwable throwable1, rootCauseCheck;
/*  488 */     ServletException servletException = e;
/*      */ 
/*      */     
/*  491 */     int loops = 0;
/*      */     do {
/*  493 */       loops++;
/*  494 */       rootCauseCheck = servletException.getCause();
/*  495 */       if (rootCauseCheck == null)
/*  496 */         continue;  throwable1 = rootCauseCheck;
/*      */     }
/*  498 */     while (rootCauseCheck != null && loops < 20);
/*  499 */     return throwable1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addChild(Container child) {
/*  511 */     throw new IllegalStateException(sm.getString("standardWrapper.notChild"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInitParameter(String name, String value) {
/*  519 */     this.parametersLock.writeLock().lock();
/*      */     try {
/*  521 */       this.parameters.put(name, value);
/*      */     } finally {
/*  523 */       this.parametersLock.writeLock().unlock();
/*      */     } 
/*  525 */     fireContainerEvent("addInitParameter", name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMapping(String mapping) {
/*  533 */     this.mappingsLock.writeLock().lock();
/*      */     try {
/*  535 */       this.mappings.add(mapping);
/*      */     } finally {
/*  537 */       this.mappingsLock.writeLock().unlock();
/*      */     } 
/*  539 */     if (this.parent.getState().equals(LifecycleState.STARTED)) {
/*  540 */       fireContainerEvent("addMapping", mapping);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSecurityReference(String name, String link) {
/*  549 */     this.referencesLock.writeLock().lock();
/*      */     try {
/*  551 */       this.references.put(name, link);
/*      */     } finally {
/*  553 */       this.referencesLock.writeLock().unlock();
/*      */     } 
/*  555 */     fireContainerEvent("addSecurityReference", name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Servlet allocate() throws ServletException {
/*  564 */     if (this.unloading) {
/*  565 */       throw new ServletException(sm.getString("standardWrapper.unloading", new Object[] { getName() }));
/*      */     }
/*      */     
/*  568 */     boolean newInstance = false;
/*      */ 
/*      */     
/*  571 */     if (this.instance == null || !this.instanceInitialized) {
/*  572 */       synchronized (this) {
/*  573 */         if (this.instance == null) {
/*      */           try {
/*  575 */             if (this.log.isTraceEnabled()) {
/*  576 */               this.log.trace("Allocating instance");
/*      */             }
/*  578 */             this.instance = loadServlet();
/*  579 */             newInstance = true;
/*      */ 
/*      */             
/*  582 */             this.countAllocated.incrementAndGet();
/*  583 */           } catch (ServletException e) {
/*  584 */             throw e;
/*  585 */           } catch (Throwable t) {
/*  586 */             ExceptionUtils.handleThrowable(t);
/*  587 */             throw new ServletException(sm.getString("standardWrapper.allocate"), t);
/*      */           } 
/*      */         }
/*  590 */         if (!this.instanceInitialized) {
/*  591 */           initServlet(this.instance);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  596 */     if (this.log.isTraceEnabled()) {
/*  597 */       this.log.trace("  Returning instance");
/*      */     }
/*      */ 
/*      */     
/*  601 */     if (!newInstance) {
/*  602 */       this.countAllocated.incrementAndGet();
/*      */     }
/*  604 */     return this.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void deallocate(Servlet servlet) throws ServletException {
/*  610 */     this.countAllocated.decrementAndGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findInitParameter(String name) {
/*  617 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  619 */       return this.parameters.get(name);
/*      */     } finally {
/*  621 */       this.parametersLock.readLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findInitParameters() {
/*  630 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  632 */       return (String[])this.parameters.keySet().toArray((Object[])new String[0]);
/*      */     } finally {
/*  634 */       this.parametersLock.readLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findMappings() {
/*  643 */     this.mappingsLock.readLock().lock();
/*      */     try {
/*  645 */       return this.mappings.<String>toArray(new String[0]);
/*      */     } finally {
/*  647 */       this.mappingsLock.readLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findSecurityReference(String name) {
/*      */     String reference;
/*  657 */     this.referencesLock.readLock().lock();
/*      */     try {
/*  659 */       reference = this.references.get(name);
/*      */     } finally {
/*  661 */       this.referencesLock.readLock().unlock();
/*      */     } 
/*      */ 
/*      */     
/*  665 */     if (getParent() instanceof Context) {
/*  666 */       Context context = (Context)getParent();
/*  667 */       if (reference != null) {
/*  668 */         reference = context.findRoleMapping(reference);
/*      */       } else {
/*  670 */         reference = context.findRoleMapping(name);
/*      */       } 
/*      */     } 
/*      */     
/*  674 */     return reference;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findSecurityReferences() {
/*  681 */     this.referencesLock.readLock().lock();
/*      */     try {
/*  683 */       return (String[])this.references.keySet().toArray((Object[])new String[0]);
/*      */     } finally {
/*  685 */       this.referencesLock.readLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void load() throws ServletException {
/*  701 */     this.instance = loadServlet();
/*      */     
/*  703 */     if (!this.instanceInitialized) {
/*  704 */       initServlet(this.instance);
/*      */     }
/*      */     
/*  707 */     if (this.isJspServlet) {
/*  708 */       StringBuilder oname = new StringBuilder(getDomain());
/*      */       
/*  710 */       oname.append(":type=JspMonitor");
/*      */       
/*  712 */       oname.append(getWebModuleKeyProperties());
/*      */       
/*  714 */       oname.append(",name=");
/*  715 */       oname.append(getName());
/*      */       
/*  717 */       oname.append(getJ2EEKeyProperties());
/*      */       
/*      */       try {
/*  720 */         this.jspMonitorON = new ObjectName(oname.toString());
/*  721 */         Registry.getRegistry(null).registerComponent(this.instance, this.jspMonitorON, null);
/*  722 */       } catch (Exception e) {
/*  723 */         this.log.warn(sm.getString("standardWrapper.jspMonitorError", new Object[] { this.instance }), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Servlet loadServlet() throws ServletException {
/*      */     Servlet servlet;
/*  741 */     if (this.instance != null) {
/*  742 */       return this.instance;
/*      */     }
/*      */     
/*  745 */     PrintStream out = System.out;
/*  746 */     if (this.swallowOutput) {
/*  747 */       SystemLogHandler.startCapture();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  752 */       long t1 = System.currentTimeMillis();
/*      */       
/*  754 */       if (this.servletClass == null) {
/*  755 */         unavailable((UnavailableException)null);
/*  756 */         throw new ServletException(sm.getString("standardWrapper.notClass", new Object[] { getName() }));
/*      */       } 
/*      */       
/*  759 */       InstanceManager instanceManager = ((StandardContext)getParent()).getInstanceManager();
/*      */       try {
/*  761 */         servlet = (Servlet)instanceManager.newInstance(this.servletClass);
/*  762 */       } catch (ClassCastException e) {
/*  763 */         unavailable((UnavailableException)null);
/*      */         
/*  765 */         throw new ServletException(sm.getString("standardWrapper.notServlet", new Object[] { this.servletClass }), e);
/*  766 */       } catch (Throwable t) {
/*  767 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/*  768 */         ExceptionUtils.handleThrowable(throwable);
/*  769 */         unavailable((UnavailableException)null);
/*      */ 
/*      */ 
/*      */         
/*  773 */         if (this.log.isDebugEnabled()) {
/*  774 */           this.log.debug(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), throwable);
/*      */         }
/*      */ 
/*      */         
/*  778 */         throw new ServletException(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), throwable);
/*      */       } 
/*      */       
/*  781 */       if (this.multipartConfigElement == null) {
/*  782 */         MultipartConfig annotation = (MultipartConfig)servlet.getClass().getAnnotation(MultipartConfig.class);
/*  783 */         if (annotation != null) {
/*  784 */           this.multipartConfigElement = new MultipartConfigElement(annotation);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  791 */       if (servlet instanceof ContainerServlet) {
/*  792 */         ((ContainerServlet)servlet).setWrapper(this);
/*      */       }
/*      */       
/*  795 */       this.classLoadTime = (int)(System.currentTimeMillis() - t1);
/*      */       
/*  797 */       initServlet(servlet);
/*      */       
/*  799 */       fireContainerEvent("load", this);
/*      */       
/*  801 */       this.loadTime = System.currentTimeMillis() - t1;
/*      */     } finally {
/*  803 */       if (this.swallowOutput) {
/*  804 */         String log = SystemLogHandler.stopCapture();
/*  805 */         if (log != null && !log.isEmpty()) {
/*  806 */           if (getServletContext() != null) {
/*  807 */             getServletContext().log(log);
/*      */           } else {
/*  809 */             out.println(log);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  814 */     return servlet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initServlet(Servlet servlet) throws ServletException {
/*  821 */     if (this.instanceInitialized) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  827 */       if (Globals.IS_SECURITY_ENABLED) {
/*  828 */         boolean success = false;
/*      */         try {
/*  830 */           Object[] args = { this.facade };
/*  831 */           SecurityUtil.doAsPrivilege("init", servlet, classType, args);
/*  832 */           success = true;
/*      */         } finally {
/*  834 */           if (!success)
/*      */           {
/*  836 */             SecurityUtil.remove(servlet);
/*      */           }
/*      */         } 
/*      */       } else {
/*  840 */         servlet.init(this.facade);
/*      */       } 
/*      */       
/*  843 */       this.instanceInitialized = true;
/*  844 */     } catch (UnavailableException f) {
/*  845 */       unavailable(f);
/*  846 */       throw f;
/*  847 */     } catch (ServletException f) {
/*      */ 
/*      */       
/*  850 */       throw f;
/*  851 */     } catch (Throwable f) {
/*  852 */       ExceptionUtils.handleThrowable(f);
/*  853 */       getServletContext().log(sm.getString("standardWrapper.initException", new Object[] { getName() }), f);
/*      */ 
/*      */       
/*  856 */       throw new ServletException(sm.getString("standardWrapper.initException", new Object[] { getName() }), f);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeInitParameter(String name) {
/*  863 */     this.parametersLock.writeLock().lock();
/*      */     try {
/*  865 */       this.parameters.remove(name);
/*      */     } finally {
/*  867 */       this.parametersLock.writeLock().unlock();
/*      */     } 
/*  869 */     fireContainerEvent("removeInitParameter", name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMapping(String mapping) {
/*  877 */     this.mappingsLock.writeLock().lock();
/*      */     try {
/*  879 */       this.mappings.remove(mapping);
/*      */     } finally {
/*  881 */       this.mappingsLock.writeLock().unlock();
/*      */     } 
/*  883 */     if (this.parent.getState().equals(LifecycleState.STARTED)) {
/*  884 */       fireContainerEvent("removeMapping", mapping);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSecurityReference(String name) {
/*  893 */     this.referencesLock.writeLock().lock();
/*      */     try {
/*  895 */       this.references.remove(name);
/*      */     } finally {
/*  897 */       this.referencesLock.writeLock().unlock();
/*      */     } 
/*  899 */     fireContainerEvent("removeSecurityReference", name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unavailable(UnavailableException unavailable) {
/*  906 */     getServletContext().log(sm.getString("standardWrapper.unavailable", new Object[] { getName() }));
/*  907 */     if (unavailable == null) {
/*  908 */       setAvailable(Long.MAX_VALUE);
/*  909 */     } else if (unavailable.isPermanent()) {
/*  910 */       setAvailable(Long.MAX_VALUE);
/*      */     } else {
/*  912 */       int unavailableSeconds = unavailable.getUnavailableSeconds();
/*  913 */       if (unavailableSeconds <= 0) {
/*  914 */         unavailableSeconds = 60;
/*      */       }
/*  916 */       setAvailable(System.currentTimeMillis() + unavailableSeconds * 1000L);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void unload() throws ServletException {
/*  926 */     if (this.instance == null) {
/*      */       return;
/*      */     }
/*  929 */     this.unloading = true;
/*      */ 
/*      */     
/*  932 */     if (this.countAllocated.get() > 0) {
/*  933 */       int nRetries = 0;
/*  934 */       long delay = this.unloadDelay / 20L;
/*  935 */       while (nRetries < 21 && this.countAllocated.get() > 0) {
/*  936 */         if (nRetries % 10 == 0) {
/*  937 */           this.log.info(sm.getString("standardWrapper.waiting", new Object[] { this.countAllocated.toString(), getName() }));
/*      */         }
/*      */         try {
/*  940 */           Thread.sleep(delay);
/*  941 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/*  944 */         nRetries++;
/*      */       } 
/*      */     } 
/*      */     
/*  948 */     if (this.instanceInitialized) {
/*  949 */       PrintStream out = System.out;
/*  950 */       if (this.swallowOutput) {
/*  951 */         SystemLogHandler.startCapture();
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  956 */         if (Globals.IS_SECURITY_ENABLED) {
/*      */           try {
/*  958 */             SecurityUtil.doAsPrivilege("destroy", this.instance);
/*      */           } finally {
/*  960 */             SecurityUtil.remove(this.instance);
/*      */           } 
/*      */         } else {
/*  963 */           this.instance.destroy();
/*      */         }
/*      */       
/*  966 */       } catch (Throwable t) {
/*  967 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/*  968 */         ExceptionUtils.handleThrowable(throwable);
/*  969 */         fireContainerEvent("unload", this);
/*  970 */         this.unloading = false;
/*  971 */         throw new ServletException(sm.getString("standardWrapper.destroyException", new Object[] { getName() }), throwable);
/*      */       } finally {
/*      */         
/*  974 */         if (!((Context)getParent()).getIgnoreAnnotations()) {
/*      */           try {
/*  976 */             ((Context)getParent()).getInstanceManager().destroyInstance(this.instance);
/*  977 */           } catch (Throwable t) {
/*  978 */             ExceptionUtils.handleThrowable(t);
/*  979 */             this.log.error(sm.getString("standardWrapper.destroyInstance", new Object[] { getName() }), t);
/*      */           } 
/*      */         }
/*      */         
/*  983 */         if (this.swallowOutput) {
/*  984 */           String log = SystemLogHandler.stopCapture();
/*  985 */           if (log != null && !log.isEmpty()) {
/*  986 */             if (getServletContext() != null) {
/*  987 */               getServletContext().log(log);
/*      */             } else {
/*  989 */               out.println(log);
/*      */             } 
/*      */           }
/*      */         } 
/*  993 */         this.instance = null;
/*  994 */         this.instanceInitialized = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  999 */     this.instance = null;
/*      */     
/* 1001 */     if (this.isJspServlet && this.jspMonitorON != null) {
/* 1002 */       Registry.getRegistry(null).unregisterComponent(this.jspMonitorON);
/*      */     }
/*      */     
/* 1005 */     this.unloading = false;
/* 1006 */     fireContainerEvent("unload", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInitParameter(String name) {
/* 1015 */     return findInitParameter(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getInitParameterNames() {
/* 1022 */     this.parametersLock.readLock().lock();
/*      */     try {
/* 1024 */       return (Enumeration)Collections.enumeration(this.parameters.keySet());
/*      */     } finally {
/* 1026 */       this.parametersLock.readLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletContext getServletContext() {
/* 1034 */     if (this.parent == null)
/* 1035 */       return null; 
/* 1036 */     if (!(this.parent instanceof Context)) {
/* 1037 */       return null;
/*      */     }
/* 1039 */     return ((Context)this.parent).getServletContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServletName() {
/* 1046 */     return getName();
/*      */   }
/*      */   
/*      */   public long getProcessingTime() {
/* 1050 */     return this.swValve.getProcessingTime();
/*      */   }
/*      */   
/*      */   public long getMaxTime() {
/* 1054 */     return this.swValve.getMaxTime();
/*      */   }
/*      */   
/*      */   public long getMinTime() {
/* 1058 */     return this.swValve.getMinTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int getRequestCount() {
/* 1071 */     return this.swValve.getRequestCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int getErrorCount() {
/* 1084 */     return this.swValve.getErrorCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void incrementErrorCount() {
/* 1092 */     this.swValve.incrementErrorCount();
/*      */   }
/*      */   
/*      */   public long getLoadTime() {
/* 1096 */     return this.loadTime;
/*      */   }
/*      */   
/*      */   public int getClassLoadTime() {
/* 1100 */     return this.classLoadTime;
/*      */   }
/*      */ 
/*      */   
/*      */   public MultipartConfigElement getMultipartConfigElement() {
/* 1105 */     return this.multipartConfigElement;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMultipartConfigElement(MultipartConfigElement multipartConfigElement) {
/* 1110 */     this.multipartConfigElement = multipartConfigElement;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAsyncSupported() {
/* 1115 */     return this.asyncSupported;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAsyncSupported(boolean asyncSupported) {
/* 1120 */     this.asyncSupported = asyncSupported;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/* 1125 */     return this.enabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean enabled) {
/* 1130 */     this.enabled = enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Method[] getAllDeclaredMethods(Class<?> c) {
/* 1141 */     if (c.equals(HttpServlet.class)) {
/* 1142 */       return null;
/*      */     }
/*      */     
/* 1145 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/*      */     
/* 1147 */     Method[] thisMethods = c.getDeclaredMethods();
/* 1148 */     if (thisMethods.length == 0) {
/* 1149 */       return parentMethods;
/*      */     }
/*      */     
/* 1152 */     if (parentMethods != null && parentMethods.length > 0) {
/* 1153 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/* 1154 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/* 1155 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*      */       
/* 1157 */       thisMethods = allMethods;
/*      */     } 
/*      */     
/* 1160 */     return thisMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/* 1178 */     if (getObjectName() != null) {
/* 1179 */       Notification notification = new Notification("j2ee.state.starting", getObjectName(), this.sequenceNumber++);
/* 1180 */       this.broadcaster.sendNotification(notification);
/*      */     } 
/*      */ 
/*      */     
/* 1184 */     super.startInternal();
/*      */     
/* 1186 */     setAvailable(0L);
/*      */ 
/*      */     
/* 1189 */     if (getObjectName() != null) {
/* 1190 */       Notification notification = new Notification("j2ee.state.running", getObjectName(), this.sequenceNumber++);
/* 1191 */       this.broadcaster.sendNotification(notification);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/* 1207 */     setAvailable(Long.MAX_VALUE);
/*      */ 
/*      */     
/* 1210 */     if (getObjectName() != null) {
/* 1211 */       Notification notification = new Notification("j2ee.state.stopping", getObjectName(), this.sequenceNumber++);
/* 1212 */       this.broadcaster.sendNotification(notification);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1217 */       unload();
/* 1218 */     } catch (ServletException e) {
/* 1219 */       getServletContext().log(sm.getString("standardWrapper.unloadException", new Object[] { getName() }), (Throwable)e);
/*      */     } 
/*      */ 
/*      */     
/* 1223 */     super.stopInternal();
/*      */ 
/*      */     
/* 1226 */     if (getObjectName() != null) {
/* 1227 */       Notification notification = new Notification("j2ee.state.stopped", getObjectName(), this.sequenceNumber++);
/* 1228 */       this.broadcaster.sendNotification(notification);
/*      */ 
/*      */       
/* 1231 */       notification = new Notification("j2ee.object.deleted", getObjectName(), this.sequenceNumber++);
/* 1232 */       this.broadcaster.sendNotification(notification);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getObjectNameKeyProperties() {
/* 1241 */     StringBuilder keyProperties = new StringBuilder("j2eeType=Servlet");
/*      */     
/* 1243 */     keyProperties.append(getWebModuleKeyProperties());
/*      */     
/* 1245 */     keyProperties.append(",name=");
/*      */     
/* 1247 */     String name = getName();
/* 1248 */     if (Util.objectNameValueNeedsQuote(name)) {
/* 1249 */       name = ObjectName.quote(name);
/*      */     }
/* 1251 */     keyProperties.append(name);
/*      */     
/* 1253 */     keyProperties.append(getJ2EEKeyProperties());
/*      */     
/* 1255 */     return keyProperties.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String getWebModuleKeyProperties() {
/* 1261 */     StringBuilder keyProperties = new StringBuilder(",WebModule=//");
/* 1262 */     String hostName = getParent().getParent().getName();
/* 1263 */     keyProperties.append(Objects.<String>requireNonNullElse(hostName, "DEFAULT"));
/*      */     
/* 1265 */     String contextName = getParent().getName();
/* 1266 */     if (!contextName.startsWith("/")) {
/* 1267 */       keyProperties.append('/');
/*      */     }
/* 1269 */     keyProperties.append(contextName);
/*      */     
/* 1271 */     return keyProperties.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private String getJ2EEKeyProperties() {
/* 1276 */     StringBuilder keyProperties = new StringBuilder(",J2EEApplication=");
/*      */     
/* 1278 */     StandardContext ctx = null;
/* 1279 */     if (this.parent instanceof StandardContext) {
/* 1280 */       ctx = (StandardContext)getParent();
/*      */     }
/*      */     
/* 1283 */     if (ctx == null) {
/* 1284 */       keyProperties.append("none");
/*      */     } else {
/* 1286 */       keyProperties.append(ctx.getJ2EEApplication());
/*      */     } 
/* 1288 */     keyProperties.append(",J2EEServer=");
/* 1289 */     if (ctx == null) {
/* 1290 */       keyProperties.append("none");
/*      */     } else {
/* 1292 */       keyProperties.append(ctx.getJ2EEServer());
/*      */     } 
/*      */     
/* 1295 */     return keyProperties.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object object) throws ListenerNotFoundException {
/* 1302 */     this.broadcaster.removeNotificationListener(listener, filter, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MBeanNotificationInfo[] getNotificationInfo() {
/* 1309 */     if (this.notificationInfo == null) {
/* 1310 */       this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1321 */         .notificationInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(new String[] { "j2ee.object.created" }, Notification.class.getName(), "servlet is created"), new MBeanNotificationInfo(new String[] { "j2ee.state.starting" }, Notification.class.getName(), "servlet is starting"), new MBeanNotificationInfo(new String[] { "j2ee.state.running" }, Notification.class.getName(), "servlet is running"), new MBeanNotificationInfo(new String[] { "j2ee.state.stopped" }, Notification.class.getName(), "servlet start to stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.stopped" }, Notification.class.getName(), "servlet is stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.deleted" }, Notification.class.getName(), "servlet is deleted") };
/*      */     }
/*      */     
/* 1324 */     return this.notificationInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object object) throws IllegalArgumentException {
/* 1331 */     this.broadcaster.addNotificationListener(listener, filter, object);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException {
/* 1337 */     this.broadcaster.removeNotificationListener(listener);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardWrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */