/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FrameworkListener
/*     */   implements LifecycleListener, ContainerListener
/*     */ {
/*  39 */   protected final ConcurrentHashMap<Context, LifecycleListener> contextListeners = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract LifecycleListener createLifecycleListener(Context paramContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*  52 */     Lifecycle lifecycle = event.getLifecycle();
/*  53 */     if ("before_start".equals(event.getType()) && lifecycle instanceof Server) {
/*  54 */       Server server = (Server)lifecycle;
/*  55 */       registerListenersForServer(server);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void containerEvent(ContainerEvent event) {
/*  61 */     String type = event.getType();
/*  62 */     if ("addChild".equals(type)) {
/*  63 */       processContainerAddChild((Container)event.getData());
/*  64 */     } else if ("removeChild".equals(type)) {
/*  65 */       processContainerRemoveChild((Container)event.getData());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerListenersForServer(Server server) {
/*  70 */     for (Service service : server.findServices()) {
/*  71 */       Engine engine = service.getContainer();
/*  72 */       if (engine != null) {
/*  73 */         engine.addContainerListener(this);
/*  74 */         registerListenersForEngine(engine);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerListenersForEngine(Engine engine) {
/*  80 */     for (Container hostContainer : engine.findChildren()) {
/*  81 */       Host host = (Host)hostContainer;
/*  82 */       host.addContainerListener(this);
/*  83 */       registerListenersForHost(host);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerListenersForHost(Host host) {
/*  88 */     for (Container contextContainer : host.findChildren()) {
/*  89 */       Context context = (Context)contextContainer;
/*  90 */       registerContextListener(context);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerContextListener(Context context) {
/*  95 */     LifecycleListener listener = createLifecycleListener(context);
/*  96 */     this.contextListeners.put(context, listener);
/*  97 */     context.addLifecycleListener(listener);
/*     */   }
/*     */   
/*     */   protected void processContainerAddChild(Container child) {
/* 101 */     if (child instanceof Context) {
/* 102 */       registerContextListener((Context)child);
/* 103 */     } else if (child instanceof Engine) {
/* 104 */       registerListenersForEngine((Engine)child);
/* 105 */     } else if (child instanceof Host) {
/* 106 */       registerListenersForHost((Host)child);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void processContainerRemoveChild(Container child) {
/* 111 */     if (child instanceof Context) {
/* 112 */       LifecycleListener listener = this.contextListeners.remove(child);
/* 113 */       if (listener != null) {
/* 114 */         child.removeLifecycleListener(listener);
/*     */       }
/* 116 */     } else if (child instanceof Host || child instanceof Engine) {
/* 117 */       child.removeContainerListener(this);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\FrameworkListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */