/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AprStatus
/*    */ {
/*    */   private static volatile boolean aprInitialized = false;
/*    */   private static volatile boolean aprAvailable = false;
/*    */   private static volatile boolean useOpenSSL = true;
/*    */   private static volatile boolean instanceCreated = false;
/* 27 */   private static volatile int openSSLVersion = 0;
/*    */   
/*    */   public static boolean isAprInitialized() {
/* 30 */     return aprInitialized;
/*    */   }
/*    */   
/*    */   public static boolean isAprAvailable() {
/* 34 */     return aprAvailable;
/*    */   }
/*    */   
/*    */   public static boolean getUseOpenSSL() {
/* 38 */     return useOpenSSL;
/*    */   }
/*    */   
/*    */   public static boolean isInstanceCreated() {
/* 42 */     return instanceCreated;
/*    */   }
/*    */   
/*    */   public static void setAprInitialized(boolean aprInitialized) {
/* 46 */     AprStatus.aprInitialized = aprInitialized;
/*    */   }
/*    */   
/*    */   public static void setAprAvailable(boolean aprAvailable) {
/* 50 */     AprStatus.aprAvailable = aprAvailable;
/*    */   }
/*    */   
/*    */   public static void setUseOpenSSL(boolean useOpenSSL) {
/* 54 */     AprStatus.useOpenSSL = useOpenSSL;
/*    */   }
/*    */   
/*    */   public static void setInstanceCreated(boolean instanceCreated) {
/* 58 */     AprStatus.instanceCreated = instanceCreated;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getOpenSSLVersion() {
/* 65 */     return openSSLVersion;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setOpenSSLVersion(int openSSLVersion) {
/* 72 */     AprStatus.openSSLVersion = openSSLVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\AprStatus.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */