/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.FilterRegistration;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationFilterRegistration
/*     */   implements FilterRegistration.Dynamic
/*     */ {
/*  40 */   private static final StringManager sm = StringManager.getManager(ApplicationFilterRegistration.class);
/*     */   
/*     */   private final FilterDef filterDef;
/*     */   private final Context context;
/*     */   
/*     */   public ApplicationFilterRegistration(FilterDef filterDef, Context context) {
/*  46 */     this.filterDef = filterDef;
/*  47 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMappingForServletNames(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... servletNames) {
/*  55 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  57 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     
/*  59 */     if (dispatcherTypes != null) {
/*  60 */       for (DispatcherType dispatcherType : dispatcherTypes) {
/*  61 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     
/*  65 */     if (servletNames != null) {
/*  66 */       for (String servletName : servletNames) {
/*  67 */         filterMap.addServletName(servletName);
/*     */       }
/*     */       
/*  70 */       if (isMatchAfter) {
/*  71 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/*  73 */         this.context.addFilterMapBefore(filterMap);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMappingForUrlPatterns(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... urlPatterns) {
/*  83 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  85 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     
/*  87 */     if (dispatcherTypes != null) {
/*  88 */       for (DispatcherType dispatcherType : dispatcherTypes) {
/*  89 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     
/*  93 */     if (urlPatterns != null) {
/*     */       
/*  95 */       for (String urlPattern : urlPatterns) {
/*  96 */         filterMap.addURLPattern(urlPattern);
/*     */       }
/*     */       
/*  99 */       if (isMatchAfter) {
/* 100 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/* 102 */         this.context.addFilterMapBefore(filterMap);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getServletNameMappings() {
/* 111 */     Collection<String> result = new HashSet<>();
/*     */     
/* 113 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 115 */     for (FilterMap filterMap : filterMaps) {
/* 116 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 117 */         result.addAll(Arrays.asList(filterMap.getServletNames()));
/*     */       }
/*     */     } 
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getUrlPatternMappings() {
/* 125 */     Collection<String> result = new HashSet<>();
/*     */     
/* 127 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 129 */     for (FilterMap filterMap : filterMaps) {
/* 130 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 131 */         result.addAll(Arrays.asList(filterMap.getURLPatterns()));
/*     */       }
/*     */     } 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 139 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInitParameter(String name) {
/* 144 */     return (String)this.filterDef.getParameterMap().get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getInitParameters() {
/* 149 */     ParameterMap<String, String> result = new ParameterMap();
/* 150 */     result.putAll(this.filterDef.getParameterMap());
/* 151 */     result.setLocked(true);
/* 152 */     return (Map<String, String>)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 157 */     return this.filterDef.getFilterName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setInitParameter(String name, String value) {
/* 162 */     if (name == null || value == null) {
/* 163 */       throw new IllegalArgumentException(sm
/* 164 */           .getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/* 166 */     if (getInitParameter(name) != null) {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     this.filterDef.addInitParameter(name, value);
/*     */     
/* 172 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters) {
/* 178 */     Set<String> conflicts = new HashSet<>();
/*     */     
/* 180 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 181 */       if (entry.getKey() == null || entry.getValue() == null) {
/* 182 */         throw new IllegalArgumentException(sm
/* 183 */             .getString("applicationFilterRegistration.nullInitParams", new Object[] { entry.getKey(), entry.getValue() }));
/*     */       }
/* 185 */       if (getInitParameter(entry.getKey()) != null) {
/* 186 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 193 */       setInitParameter(entry.getKey(), entry.getValue());
/*     */     }
/*     */     
/* 196 */     return conflicts;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported) {
/* 201 */     this.filterDef.setAsyncSupported(Boolean.valueOf(asyncSupported).toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationFilterRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */