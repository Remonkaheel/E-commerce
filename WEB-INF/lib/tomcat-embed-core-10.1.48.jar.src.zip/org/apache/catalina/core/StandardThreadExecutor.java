/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.ResizableExecutor;
/*     */ import org.apache.tomcat.util.threads.TaskQueue;
/*     */ import org.apache.tomcat.util.threads.TaskThreadFactory;
/*     */ import org.apache.tomcat.util.threads.ThreadPoolExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardThreadExecutor
/*     */   extends LifecycleMBeanBase
/*     */   implements Executor, ExecutorService, ResizableExecutor
/*     */ {
/*  41 */   protected static final StringManager sm = StringManager.getManager(StandardThreadExecutor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected int threadPriority = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean daemon = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   protected String namePrefix = "tomcat-exec-";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected int maxThreads = 200;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   protected int minSpareThreads = 25;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   protected int maxIdleTime = 60000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected ThreadPoolExecutor executor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected int maxQueueSize = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected long threadRenewalDelay = 1000L;
/*     */   
/*  95 */   private TaskQueue taskqueue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 115 */     this.taskqueue = new TaskQueue(this.maxQueueSize);
/* 116 */     TaskThreadFactory tf = new TaskThreadFactory(this.namePrefix, this.daemon, getThreadPriority());
/* 117 */     this.executor = new ThreadPoolExecutor(getMinSpareThreads(), getMaxThreads(), this.maxIdleTime, TimeUnit.MILLISECONDS, (BlockingQueue)this.taskqueue, (ThreadFactory)tf);
/*     */     
/* 119 */     this.executor.setThreadRenewalDelay(this.threadRenewalDelay);
/* 120 */     this.taskqueue.setParent(this.executor);
/*     */     
/* 122 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 135 */     setState(LifecycleState.STOPPING);
/* 136 */     if (this.executor != null) {
/* 137 */       this.executor.shutdownNow();
/*     */     }
/* 139 */     this.executor = null;
/* 140 */     this.taskqueue = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Runnable command) {
/* 146 */     if (this.executor != null) {
/*     */ 
/*     */       
/* 149 */       this.executor.execute(command);
/*     */     } else {
/* 151 */       throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void contextStopping() {
/* 156 */     if (this.executor != null) {
/* 157 */       this.executor.contextStopping();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getThreadPriority() {
/* 162 */     return this.threadPriority;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDaemon() {
/* 167 */     return this.daemon;
/*     */   }
/*     */   
/*     */   public String getNamePrefix() {
/* 171 */     return this.namePrefix;
/*     */   }
/*     */   
/*     */   public int getMaxIdleTime() {
/* 175 */     return this.maxIdleTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxThreads() {
/* 180 */     return this.maxThreads;
/*     */   }
/*     */   
/*     */   public int getMinSpareThreads() {
/* 184 */     return this.minSpareThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 189 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setThreadPriority(int threadPriority) {
/* 193 */     this.threadPriority = threadPriority;
/*     */   }
/*     */   
/*     */   public void setDaemon(boolean daemon) {
/* 197 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */   public void setNamePrefix(String namePrefix) {
/* 201 */     this.namePrefix = namePrefix;
/*     */   }
/*     */   
/*     */   public void setMaxIdleTime(int maxIdleTime) {
/* 205 */     this.maxIdleTime = maxIdleTime;
/* 206 */     if (this.executor != null) {
/* 207 */       this.executor.setKeepAliveTime(maxIdleTime, TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMaxThreads(int maxThreads) {
/* 212 */     this.maxThreads = maxThreads;
/* 213 */     if (this.executor != null) {
/* 214 */       this.executor.setMaximumPoolSize(maxThreads);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMinSpareThreads(int minSpareThreads) {
/* 219 */     this.minSpareThreads = minSpareThreads;
/* 220 */     if (this.executor != null) {
/* 221 */       this.executor.setCorePoolSize(minSpareThreads);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 226 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setMaxQueueSize(int size) {
/* 230 */     this.maxQueueSize = size;
/*     */   }
/*     */   
/*     */   public int getMaxQueueSize() {
/* 234 */     return this.maxQueueSize;
/*     */   }
/*     */   
/*     */   public long getThreadRenewalDelay() {
/* 238 */     return this.threadRenewalDelay;
/*     */   }
/*     */   
/*     */   public void setThreadRenewalDelay(long threadRenewalDelay) {
/* 242 */     this.threadRenewalDelay = threadRenewalDelay;
/* 243 */     if (this.executor != null) {
/* 244 */       this.executor.setThreadRenewalDelay(threadRenewalDelay);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActiveCount() {
/* 251 */     return (this.executor != null) ? this.executor.getActiveCount() : 0;
/*     */   }
/*     */   
/*     */   public long getCompletedTaskCount() {
/* 255 */     return (this.executor != null) ? this.executor.getCompletedTaskCount() : 0L;
/*     */   }
/*     */   
/*     */   public int getCorePoolSize() {
/* 259 */     return (this.executor != null) ? this.executor.getCorePoolSize() : 0;
/*     */   }
/*     */   
/*     */   public int getLargestPoolSize() {
/* 263 */     return (this.executor != null) ? this.executor.getLargestPoolSize() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPoolSize() {
/* 268 */     return (this.executor != null) ? this.executor.getPoolSize() : 0;
/*     */   }
/*     */   
/*     */   public int getQueueSize() {
/* 272 */     return (this.executor != null) ? this.executor.getQueue().size() : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resizePool(int corePoolSize, int maximumPoolSize) {
/* 278 */     if (this.executor == null) {
/* 279 */       return false;
/*     */     }
/*     */     
/* 282 */     this.executor.setCorePoolSize(corePoolSize);
/* 283 */     this.executor.setMaximumPoolSize(maximumPoolSize);
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resizeQueue(int capacity) {
/* 290 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 302 */     return "type=Executor,name=" + getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Runnable> shutdownNow() {
/* 315 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 321 */     if (this.executor != null) {
/* 322 */       return this.executor.isShutdown();
/*     */     }
/* 324 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 331 */     if (this.executor != null) {
/* 332 */       return this.executor.isTerminated();
/*     */     }
/* 334 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/* 341 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 347 */     if (this.executor != null) {
/* 348 */       return this.executor.submit(task);
/*     */     }
/* 350 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Runnable task, T result) {
/* 357 */     if (this.executor != null) {
/* 358 */       return this.executor.submit(task, result);
/*     */     }
/* 360 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<?> submit(Runnable task) {
/* 367 */     if (this.executor != null) {
/* 368 */       return this.executor.submit(task);
/*     */     }
/* 370 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 377 */     if (this.executor != null) {
/* 378 */       return this.executor.invokeAll(tasks);
/*     */     }
/* 380 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 388 */     if (this.executor != null) {
/* 389 */       return this.executor.invokeAll(tasks, timeout, unit);
/*     */     }
/* 391 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 398 */     if (this.executor != null) {
/* 399 */       return (T)this.executor.invokeAny(tasks);
/*     */     }
/* 401 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 409 */     if (this.executor != null) {
/* 410 */       return (T)this.executor.invokeAny(tasks, timeout, unit);
/*     */     }
/* 412 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardThreadExecutor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */