/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesRoleMappingListener
/*     */   implements LifecycleListener
/*     */ {
/*     */   private static final String WEBAPP_PROTOCOL = "webapp:";
/*  49 */   private static final Log log = LogFactory.getLog(PropertiesRoleMappingListener.class);
/*     */ 
/*     */ 
/*     */   
/*  53 */   private static final StringManager sm = StringManager.getManager(ContextNamingInfoListener.class);
/*     */   
/*  55 */   private String roleMappingFile = "webapp:/WEB-INF/role-mapping.properties";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String keyPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoleMappingFile(String roleMappingFile) {
/*  68 */     Objects.requireNonNull(roleMappingFile, sm.getString("propertiesRoleMappingListener.roleMappingFileNull"));
/*  69 */     if (roleMappingFile.isEmpty()) {
/*  70 */       throw new IllegalArgumentException(sm.getString("propertiesRoleMappingListener.roleMappingFileEmpty"));
/*     */     }
/*     */     
/*  73 */     this.roleMappingFile = roleMappingFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRoleMappingFile() {
/*  82 */     return this.roleMappingFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyPrefix(String keyPrefix) {
/*  91 */     this.keyPrefix = keyPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyPrefix() {
/* 100 */     return this.keyPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/* 105 */     if (event.getType().equals("configure_start")) {
/* 106 */       if (!(event.getLifecycle() instanceof Context)) {
/* 107 */         log.warn(sm.getString("listener.notContext", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */         return;
/*     */       } 
/* 110 */       Properties props = new Properties();
/* 111 */       Context context = (Context)event.getLifecycle(); 
/* 112 */       try { ConfigurationSource.Resource resource = context.findConfigFileResource(this.roleMappingFile); 
/* 113 */         try { props.load(resource.getInputStream());
/* 114 */           if (resource != null) resource.close();  } catch (Throwable throwable) { if (resource != null) try { resource.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException ioe)
/* 115 */       { throw new IllegalStateException(sm
/* 116 */             .getString("propertiesRoleMappingListener.roleMappingFileFail", new Object[] { this.roleMappingFile }), ioe); }
/*     */ 
/*     */       
/* 119 */       int linkCount = 0;
/* 120 */       for (Map.Entry<Object, Object> prop : props.entrySet()) {
/* 121 */         String role = (String)prop.getKey();
/*     */         
/* 123 */         if (this.keyPrefix != null) {
/* 124 */           if (role.startsWith(this.keyPrefix)) {
/* 125 */             role = role.substring(this.keyPrefix.length());
/*     */           } else {
/*     */             continue;
/*     */           } 
/*     */         }
/*     */         
/* 131 */         String link = (String)prop.getValue();
/*     */         
/* 133 */         if (log.isTraceEnabled()) {
/* 134 */           log.trace(sm.getString("propertiesRoleMappingListener.linkedRole", new Object[] { role, link }));
/*     */         }
/* 136 */         context.addRoleMapping(role, link);
/* 137 */         linkCount++;
/*     */       } 
/*     */       
/* 140 */       if (log.isDebugEnabled())
/* 141 */         log.debug(sm.getString("propertiesRoleMappingListener.linkedRoleCount", new Object[] { Integer.valueOf(linkCount) })); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\PropertiesRoleMappingListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */