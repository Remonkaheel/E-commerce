/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import jakarta.servlet.ServletConfig;
/*    */ import jakarta.servlet.ServletContext;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardWrapperFacade
/*    */   implements ServletConfig
/*    */ {
/*    */   private final ServletConfig config;
/*    */   private ServletContext context;
/*    */   
/*    */   public StandardWrapperFacade(StandardWrapper config) {
/* 60 */     this.context = null;
/*    */     this.config = config;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getServletName() {
/* 68 */     return this.config.getServletName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServletContext getServletContext() {
/* 78 */     if (this.context == null) {
/* 79 */       this.context = this.config.getServletContext();
/* 80 */       if (this.context instanceof ApplicationContext) {
/* 81 */         this.context = ((ApplicationContext)this.context).getFacade();
/*    */       }
/*    */     } 
/* 84 */     return this.context;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getInitParameter(String name) {
/* 90 */     return this.config.getInitParameter(name);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Enumeration<String> getInitParameterNames() {
/* 96 */     return this.config.getInitParameterNames();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardWrapperFacade.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */