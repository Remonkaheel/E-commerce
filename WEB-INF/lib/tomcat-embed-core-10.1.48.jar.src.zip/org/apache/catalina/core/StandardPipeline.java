/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPipeline
/*     */   extends LifecycleBase
/*     */   implements Pipeline
/*     */ {
/*  49 */   private static final Log log = LogFactory.getLog(StandardPipeline.class);
/*  50 */   private static final StringManager sm = StringManager.getManager(StandardPipeline.class);
/*     */   
/*     */   protected Valve basic;
/*     */   
/*     */   protected Container container;
/*     */   
/*     */   protected Valve first;
/*     */ 
/*     */   
/*     */   public StandardPipeline() {
/*  60 */     this((Container)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardPipeline(Container container) {
/*  84 */     this.basic = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.container = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.first = null;
/*     */     setContainer(container);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsyncSupported() {
/* 103 */     Valve valve = (this.first != null) ? this.first : this.basic;
/* 104 */     boolean supported = true;
/* 105 */     while (supported && valve != null) {
/* 106 */       supported = valve.isAsyncSupported();
/* 107 */       valve = valve.getNext();
/*     */     } 
/* 109 */     return supported;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void findNonAsyncValves(Set<String> result) {
/* 115 */     Valve valve = (this.first != null) ? this.first : this.basic;
/* 116 */     while (valve != null) {
/* 117 */       if (!valve.isAsyncSupported()) {
/* 118 */         result.add(valve.getClass().getName());
/*     */       }
/* 120 */       valve = valve.getNext();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/* 129 */     return this.container;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Container container) {
/* 135 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/* 149 */     Valve current = this.first;
/* 150 */     if (current == null) {
/* 151 */       current = this.basic;
/*     */     }
/* 153 */     while (current != null) {
/* 154 */       if (current instanceof Lifecycle) {
/* 155 */         ((Lifecycle)current).start();
/*     */       }
/* 157 */       current = current.getNext();
/*     */     } 
/*     */     
/* 160 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/* 167 */     setState(LifecycleState.STOPPING);
/*     */ 
/*     */     
/* 170 */     Valve current = this.first;
/* 171 */     if (current == null) {
/* 172 */       current = this.basic;
/*     */     }
/* 174 */     while (current != null) {
/* 175 */       if (current instanceof Lifecycle) {
/* 176 */         ((Lifecycle)current).stop();
/*     */       }
/* 178 */       current = current.getNext();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyInternal() {
/* 185 */     Valve[] valves = getValves();
/* 186 */     for (Valve valve : valves) {
/* 187 */       removeValve(valve);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 194 */     return ToStringUtil.toString((Contained)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Valve getBasic() {
/* 203 */     return this.basic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBasic(Valve valve) {
/* 211 */     Valve oldBasic = this.basic;
/* 212 */     if (oldBasic == valve) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 217 */     if (oldBasic != null) {
/* 218 */       if (getState().isAvailable() && oldBasic instanceof Lifecycle) {
/*     */         try {
/* 220 */           ((Lifecycle)oldBasic).stop();
/* 221 */         } catch (LifecycleException e) {
/* 222 */           log.error(sm.getString("standardPipeline.basic.stop"), (Throwable)e);
/*     */         } 
/*     */       }
/* 225 */       if (oldBasic instanceof Contained) {
/*     */         try {
/* 227 */           ((Contained)oldBasic).setContainer(null);
/* 228 */         } catch (Throwable t) {
/* 229 */           ExceptionUtils.handleThrowable(t);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 235 */     if (valve == null) {
/*     */       return;
/*     */     }
/* 238 */     if (valve instanceof Contained) {
/* 239 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/* 241 */     if (getState().isAvailable() && valve instanceof Lifecycle) {
/*     */       try {
/* 243 */         ((Lifecycle)valve).start();
/* 244 */       } catch (LifecycleException e) {
/* 245 */         log.error(sm.getString("standardPipeline.basic.start"), (Throwable)e);
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 251 */     Valve current = this.first;
/* 252 */     while (current != null) {
/* 253 */       if (current.getNext() == oldBasic) {
/* 254 */         current.setNext(valve);
/*     */         break;
/*     */       } 
/* 257 */       current = current.getNext();
/*     */     } 
/*     */     
/* 260 */     this.basic = valve;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValve(Valve valve) {
/* 269 */     if (valve instanceof Contained) {
/* 270 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/*     */ 
/*     */     
/* 274 */     if (getState().isAvailable() && 
/* 275 */       valve instanceof Lifecycle) {
/*     */       try {
/* 277 */         ((Lifecycle)valve).start();
/* 278 */       } catch (LifecycleException e) {
/* 279 */         log.error(sm.getString("standardPipeline.valve.start"), (Throwable)e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 285 */     if (this.first == null) {
/* 286 */       this.first = valve;
/* 287 */       valve.setNext(this.basic);
/*     */     } else {
/* 289 */       Valve current = this.first;
/* 290 */       while (current != null) {
/* 291 */         if (current.getNext() == this.basic) {
/* 292 */           current.setNext(valve);
/* 293 */           valve.setNext(this.basic);
/*     */           break;
/*     */         } 
/* 296 */         current = current.getNext();
/*     */       } 
/*     */     } 
/*     */     
/* 300 */     this.container.fireContainerEvent("addValve", valve);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Valve[] getValves() {
/* 307 */     List<Valve> valveList = new ArrayList<>();
/* 308 */     Valve current = this.first;
/* 309 */     if (current == null) {
/* 310 */       current = this.basic;
/*     */     }
/* 312 */     while (current != null) {
/* 313 */       valveList.add(current);
/* 314 */       current = current.getNext();
/*     */     } 
/*     */     
/* 317 */     return valveList.<Valve>toArray(new Valve[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectName[] getValveObjectNames() {
/* 323 */     List<ObjectName> valveList = new ArrayList<>();
/* 324 */     Valve current = this.first;
/* 325 */     if (current == null) {
/* 326 */       current = this.basic;
/*     */     }
/* 328 */     while (current != null) {
/* 329 */       if (current instanceof JmxEnabled) {
/* 330 */         valveList.add(((JmxEnabled)current).getObjectName());
/*     */       }
/* 332 */       current = current.getNext();
/*     */     } 
/*     */     
/* 335 */     return valveList.<ObjectName>toArray(new ObjectName[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeValve(Valve valve) {
/*     */     Valve current;
/* 343 */     if (this.first == valve) {
/* 344 */       this.first = this.first.getNext();
/* 345 */       current = null;
/*     */     } else {
/* 347 */       current = this.first;
/*     */     } 
/* 349 */     while (current != null) {
/* 350 */       if (current.getNext() == valve) {
/* 351 */         current.setNext(valve.getNext());
/*     */         break;
/*     */       } 
/* 354 */       current = current.getNext();
/*     */     } 
/*     */     
/* 357 */     if (this.first == this.basic) {
/* 358 */       this.first = null;
/*     */     }
/*     */     
/* 361 */     if (valve instanceof Contained) {
/* 362 */       ((Contained)valve).setContainer(null);
/*     */     }
/*     */     
/* 365 */     if (valve instanceof Lifecycle) {
/*     */       
/* 367 */       if (getState().isAvailable()) {
/*     */         try {
/* 369 */           ((Lifecycle)valve).stop();
/* 370 */         } catch (LifecycleException e) {
/* 371 */           log.error(sm.getString("standardPipeline.valve.stop"), (Throwable)e);
/*     */         } 
/*     */       }
/*     */       try {
/* 375 */         ((Lifecycle)valve).destroy();
/* 376 */       } catch (LifecycleException e) {
/* 377 */         log.error(sm.getString("standardPipeline.valve.destroy"), (Throwable)e);
/*     */       } 
/*     */     } 
/*     */     
/* 381 */     this.container.fireContainerEvent("removeValve", valve);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Valve getFirst() {
/* 387 */     if (this.first != null) {
/* 388 */       return this.first;
/*     */     }
/*     */     
/* 391 */     return this.basic;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardPipeline.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */