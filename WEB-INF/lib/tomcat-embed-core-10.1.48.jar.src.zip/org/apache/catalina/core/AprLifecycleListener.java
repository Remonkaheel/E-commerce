/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.jni.Library;
/*     */ import org.apache.tomcat.jni.LibraryNotFoundError;
/*     */ import org.apache.tomcat.jni.SSL;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AprLifecycleListener
/*     */   implements LifecycleListener
/*     */ {
/*  50 */   private static final Log log = LogFactory.getLog(AprLifecycleListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final List<String> initInfoLogMessages = new ArrayList<>(3);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected static final StringManager sm = StringManager.getManager(AprLifecycleListener.class);
/*     */ 
/*     */   
/*     */   protected static final int TCN_REQUIRED_MAJOR = 1;
/*     */   
/*     */   protected static final int TCN_REQUIRED_MINOR = 2;
/*     */   
/*     */   protected static final int TCN_REQUIRED_PATCH = 34;
/*     */   
/*     */   protected static final int TCN_RECOMMENDED_MAJOR = 2;
/*     */   
/*     */   protected static final int TCN_RECOMMENDED_MINOR = 0;
/*     */   
/*     */   protected static final int TCN_RECOMMENDED_PV = 5;
/*     */   
/*  76 */   private static int tcnMajor = 0;
/*  77 */   private static int tcnMinor = 0;
/*  78 */   private static int tcnPatch = 0;
/*  79 */   private static int tcnVersion = 0;
/*     */   
/*  81 */   protected static String SSLEngine = "on";
/*  82 */   protected static String FIPSMode = "off";
/*  83 */   protected static String SSLRandomSeed = "builtin";
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean sslInitialized = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean fipsModeActive = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int FIPS_ON = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int FIPS_OFF = 0;
/*     */ 
/*     */   
/* 102 */   protected static final Object lock = new Object();
/*     */ 
/*     */   
/* 105 */   private static int referenceCount = 0;
/*     */   
/*     */   private boolean instanceInitialized = false;
/*     */ 
/*     */   
/*     */   public static boolean isAprAvailable() {
/* 111 */     if (AprStatus.isInstanceCreated()) {
/* 112 */       synchronized (lock) {
/* 113 */         init();
/*     */       } 
/*     */     }
/* 116 */     return AprStatus.isAprAvailable();
/*     */   }
/*     */   
/*     */   public AprLifecycleListener() {
/* 120 */     AprStatus.setInstanceCreated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/* 133 */     if ("before_init".equals(event.getType())) {
/* 134 */       synchronized (lock) {
/* 135 */         this.instanceInitialized = true;
/* 136 */         if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/* 137 */           log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */         }
/* 139 */         if (referenceCount++ != 0) {
/*     */           return;
/*     */         }
/*     */         
/* 143 */         init();
/* 144 */         for (String msg : initInfoLogMessages) {
/* 145 */           log.info(msg);
/*     */         }
/* 147 */         initInfoLogMessages.clear();
/* 148 */         if (AprStatus.isAprAvailable()) {
/*     */           try {
/* 150 */             initializeSSL();
/* 151 */           } catch (Throwable t) {
/* 152 */             Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 153 */             ExceptionUtils.handleThrowable(throwable);
/* 154 */             log.error(sm.getString("aprListener.sslInit"), throwable);
/*     */           } 
/*     */         }
/*     */         
/* 158 */         if (null != FIPSMode && !"off".equalsIgnoreCase(FIPSMode) && !isFIPSModeActive()) {
/* 159 */           Error e = new Error(sm.getString("aprListener.initializeFIPSFailed"));
/*     */           
/* 161 */           log.fatal(e.getMessage(), e);
/* 162 */           throw e;
/*     */         } 
/*     */       } 
/* 165 */     } else if ("after_destroy".equals(event.getType())) {
/* 166 */       synchronized (lock) {
/*     */         
/* 168 */         if (this.instanceInitialized) {
/* 169 */           referenceCount--;
/*     */         }
/* 171 */         if (referenceCount != 0) {
/*     */           return;
/*     */         }
/*     */         
/* 175 */         if (!AprStatus.isAprAvailable()) {
/*     */           return;
/*     */         }
/*     */         try {
/* 179 */           terminateAPR();
/* 180 */         } catch (Throwable t) {
/* 181 */           Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 182 */           ExceptionUtils.handleThrowable(throwable);
/* 183 */           log.warn(sm.getString("aprListener.aprDestroy"), throwable);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void terminateAPR() {
/* 191 */     AprStatus.setAprInitialized(false);
/* 192 */     AprStatus.setAprAvailable(false);
/* 193 */     fipsModeActive = false;
/* 194 */     sslInitialized = false;
/*     */     
/* 196 */     System.gc();
/* 197 */     Library.terminate();
/*     */   }
/*     */   
/*     */   private static void init() {
/* 201 */     int rqver = 1234;
/* 202 */     int rcver = 2005;
/*     */     
/* 204 */     if (AprStatus.isAprInitialized()) {
/*     */       return;
/*     */     }
/* 207 */     AprStatus.setAprInitialized(true);
/*     */     
/*     */     try {
/* 210 */       Library.initialize(null);
/* 211 */       tcnMajor = Library.TCN_MAJOR_VERSION;
/* 212 */       tcnMinor = Library.TCN_MINOR_VERSION;
/* 213 */       tcnPatch = Library.TCN_PATCH_VERSION;
/* 214 */       tcnVersion = tcnMajor * 1000 + tcnMinor * 100 + tcnPatch;
/* 215 */     } catch (LibraryNotFoundError lnfe) {
/*     */       
/* 217 */       if (log.isDebugEnabled()) {
/* 218 */         log.debug(sm.getString("aprListener.aprInitDebug", new Object[] { lnfe.getLibraryNames(), 
/* 219 */                 System.getProperty("java.library.path"), lnfe.getMessage() }), (Throwable)lnfe);
/*     */       }
/* 221 */       initInfoLogMessages.add(sm.getString("aprListener.aprInit", new Object[] { System.getProperty("java.library.path") }));
/*     */       return;
/* 223 */     } catch (Throwable t) {
/*     */       
/* 225 */       Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 226 */       ExceptionUtils.handleThrowable(throwable);
/* 227 */       log.warn(sm.getString("aprListener.aprInitError", new Object[] { throwable.getMessage() }), throwable);
/*     */       return;
/*     */     } 
/* 230 */     if (tcnMajor > 1 && "off".equalsIgnoreCase(SSLEngine)) {
/* 231 */       log.error(sm.getString("aprListener.sslRequired", new Object[] { SSLEngine, Library.versionString() }));
/*     */       
/*     */       try {
/* 234 */         terminateAPR();
/* 235 */       } catch (Throwable t) {
/* 236 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 237 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */       return;
/*     */     } 
/* 241 */     if (tcnVersion < rqver) {
/* 242 */       log.error(sm.getString("aprListener.tcnInvalid", new Object[] { Library.versionString(), "1.2.34" }));
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 247 */         terminateAPR();
/* 248 */       } catch (Throwable t) {
/* 249 */         Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
/* 250 */         ExceptionUtils.handleThrowable(throwable);
/*     */       } 
/*     */       return;
/*     */     } 
/* 254 */     if (tcnVersion < rcver) {
/* 255 */       initInfoLogMessages.add(sm.getString("aprListener.tcnVersion", new Object[] { Library.versionString(), "2.0.5" }));
/*     */     }
/*     */ 
/*     */     
/* 259 */     initInfoLogMessages
/* 260 */       .add(sm.getString("aprListener.tcnValid", new Object[] { Library.versionString(), Library.aprVersionString() }));
/*     */     
/* 262 */     AprStatus.setAprAvailable(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void initializeSSL() throws Exception {
/* 267 */     if ("off".equalsIgnoreCase(SSLEngine)) {
/*     */       return;
/*     */     }
/* 270 */     if (sslInitialized) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 275 */     sslInitialized = true;
/*     */     
/* 277 */     String methodName = "randSet";
/* 278 */     Class<?>[] paramTypes = new Class[1];
/* 279 */     paramTypes[0] = String.class;
/* 280 */     Object[] paramValues = new Object[1];
/* 281 */     paramValues[0] = SSLRandomSeed;
/* 282 */     Class<?> clazz = Class.forName("org.apache.tomcat.jni.SSL");
/* 283 */     Method method = clazz.getMethod(methodName, paramTypes);
/* 284 */     method.invoke(null, paramValues);
/*     */ 
/*     */     
/* 287 */     methodName = "initialize";
/* 288 */     paramValues[0] = "on".equalsIgnoreCase(SSLEngine) ? null : SSLEngine;
/* 289 */     method = clazz.getMethod(methodName, paramTypes);
/* 290 */     method.invoke(null, paramValues);
/*     */     
/* 292 */     AprStatus.setOpenSSLVersion(SSL.version());
/*     */     
/* 294 */     boolean usingProviders = (tcnMajor > 1 || (tcnVersion > 1233 && (SSL.version() & 0xF0000000L) > 536870912L));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (usingProviders || (null != FIPSMode && !"off".equalsIgnoreCase(FIPSMode))) {
/* 300 */       boolean enterFipsMode; fipsModeActive = false;
/*     */       
/* 302 */       int fipsModeState = SSL.fipsModeGet();
/*     */       
/* 304 */       if (log.isDebugEnabled()) {
/* 305 */         log.debug(sm.getString("aprListener.currentFIPSMode", new Object[] { Integer.valueOf(fipsModeState) }));
/*     */       }
/*     */       
/* 308 */       if (null == FIPSMode || "off".equalsIgnoreCase(FIPSMode)) {
/* 309 */         if (fipsModeState == 1) {
/* 310 */           fipsModeActive = true;
/*     */         }
/* 312 */         enterFipsMode = false;
/* 313 */       } else if ("on".equalsIgnoreCase(FIPSMode)) {
/* 314 */         if (fipsModeState == 1) {
/* 315 */           if (!usingProviders) {
/* 316 */             log.info(sm.getString("aprListener.skipFIPSInitialization"));
/*     */           }
/* 318 */           fipsModeActive = true;
/* 319 */           enterFipsMode = false;
/*     */         } else {
/* 321 */           if (usingProviders) {
/* 322 */             throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", new Object[] { FIPSMode }));
/*     */           }
/* 324 */           enterFipsMode = true;
/*     */         }
/*     */       
/* 327 */       } else if ("require".equalsIgnoreCase(FIPSMode)) {
/* 328 */         if (fipsModeState == 1) {
/* 329 */           fipsModeActive = true;
/* 330 */           enterFipsMode = false;
/*     */         } else {
/* 332 */           if (usingProviders) {
/* 333 */             throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", new Object[] { FIPSMode }));
/*     */           }
/* 335 */           throw new IllegalStateException(sm.getString("aprListener.requireNotInFIPSMode"));
/*     */         }
/*     */       
/* 338 */       } else if ("enter".equalsIgnoreCase(FIPSMode)) {
/* 339 */         if (fipsModeState == 0) {
/* 340 */           if (usingProviders) {
/* 341 */             throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", new Object[] { FIPSMode }));
/*     */           }
/* 343 */           enterFipsMode = true;
/*     */         
/*     */         }
/* 346 */         else if (usingProviders) {
/* 347 */           fipsModeActive = true;
/* 348 */           enterFipsMode = false;
/*     */         } else {
/* 350 */           throw new IllegalStateException(sm
/* 351 */               .getString("aprListener.enterAlreadyInFIPSMode", new Object[] { Integer.valueOf(fipsModeState) }));
/*     */         } 
/*     */       } else {
/*     */         
/* 355 */         throw new IllegalArgumentException(sm.getString("aprListener.wrongFIPSMode", new Object[] { FIPSMode }));
/*     */       } 
/*     */       
/* 358 */       if (enterFipsMode) {
/* 359 */         log.info(sm.getString("aprListener.initializingFIPS"));
/*     */         
/* 361 */         fipsModeState = SSL.fipsModeSet(1);
/* 362 */         if (fipsModeState != 1) {
/*     */ 
/*     */           
/* 365 */           String message = sm.getString("aprListener.initializeFIPSFailed");
/* 366 */           log.error(message);
/* 367 */           throw new IllegalStateException(message);
/*     */         } 
/*     */         
/* 370 */         fipsModeActive = true;
/* 371 */         log.info(sm.getString("aprListener.initializeFIPSSuccess"));
/*     */       } 
/*     */       
/* 374 */       if (usingProviders && fipsModeActive) {
/* 375 */         log.info(sm.getString("aprListener.usingFIPSProvider"));
/*     */       }
/*     */     } 
/*     */     
/* 379 */     log.info(sm.getString("aprListener.initializedOpenSSL", new Object[] { SSL.versionString() }));
/*     */   }
/*     */   
/*     */   public String getSSLEngine() {
/* 383 */     return SSLEngine;
/*     */   }
/*     */   
/*     */   public void setSSLEngine(String SSLEngine) {
/* 387 */     if (!SSLEngine.equals(AprLifecycleListener.SSLEngine)) {
/*     */       
/* 389 */       if (sslInitialized) {
/* 390 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLEngine"));
/*     */       }
/*     */       
/* 393 */       AprLifecycleListener.SSLEngine = SSLEngine;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSSLRandomSeed() {
/* 398 */     return SSLRandomSeed;
/*     */   }
/*     */   
/*     */   public void setSSLRandomSeed(String SSLRandomSeed) {
/* 402 */     if (!SSLRandomSeed.equals(AprLifecycleListener.SSLRandomSeed)) {
/*     */       
/* 404 */       if (sslInitialized) {
/* 405 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLRandomSeed"));
/*     */       }
/*     */       
/* 408 */       AprLifecycleListener.SSLRandomSeed = SSLRandomSeed;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getFIPSMode() {
/* 413 */     return FIPSMode;
/*     */   }
/*     */   
/*     */   public void setFIPSMode(String FIPSMode) {
/* 417 */     if (!FIPSMode.equals(AprLifecycleListener.FIPSMode)) {
/*     */       
/* 419 */       if (sslInitialized) {
/* 420 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForFIPSMode"));
/*     */       }
/*     */       
/* 423 */       AprLifecycleListener.FIPSMode = FIPSMode;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isFIPSModeActive() {
/* 428 */     return fipsModeActive;
/*     */   }
/*     */   
/*     */   public void setUseOpenSSL(boolean useOpenSSL) {
/* 432 */     if (useOpenSSL != AprStatus.getUseOpenSSL()) {
/* 433 */       AprStatus.setUseOpenSSL(useOpenSSL);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean getUseOpenSSL() {
/* 438 */     return AprStatus.getUseOpenSSL();
/*     */   }
/*     */   
/*     */   public static boolean isInstanceCreated() {
/* 442 */     return AprStatus.isInstanceCreated();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\AprLifecycleListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */