/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.http.Part;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.http.fileupload.FileItem;
/*     */ import org.apache.tomcat.util.http.fileupload.ParameterParser;
/*     */ import org.apache.tomcat.util.http.parser.HttpParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationPart
/*     */   implements Part
/*     */ {
/*     */   private final FileItem fileItem;
/*     */   private final File location;
/*     */   
/*     */   public ApplicationPart(FileItem fileItem, File location) {
/*  47 */     this.fileItem = fileItem;
/*  48 */     this.location = location;
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete() throws IOException {
/*  53 */     this.fileItem.delete();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  58 */     return this.fileItem.getContentType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeader(String name) {
/*  63 */     if (this.fileItem instanceof org.apache.tomcat.util.http.fileupload.disk.DiskFileItem) {
/*  64 */       return this.fileItem.getHeaders().getHeader(name);
/*     */     }
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getHeaderNames() {
/*  71 */     if (this.fileItem instanceof org.apache.tomcat.util.http.fileupload.disk.DiskFileItem) {
/*  72 */       LinkedHashSet<String> headerNames = new LinkedHashSet<>();
/*  73 */       Iterator<String> iter = this.fileItem.getHeaders().getHeaderNames();
/*  74 */       while (iter.hasNext()) {
/*  75 */         headerNames.add(iter.next());
/*     */       }
/*  77 */       return headerNames;
/*     */     } 
/*  79 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getHeaders(String name) {
/*  84 */     if (this.fileItem instanceof org.apache.tomcat.util.http.fileupload.disk.DiskFileItem) {
/*  85 */       LinkedHashSet<String> headers = new LinkedHashSet<>();
/*  86 */       Iterator<String> iter = this.fileItem.getHeaders().getHeaders(name);
/*  87 */       while (iter.hasNext()) {
/*  88 */         headers.add(iter.next());
/*     */       }
/*  90 */       return headers;
/*     */     } 
/*  92 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  97 */     return this.fileItem.getInputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 102 */     return this.fileItem.getFieldName();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 107 */     return this.fileItem.getSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(String fileName) throws IOException {
/* 112 */     File file = new File(fileName);
/* 113 */     if (!file.isAbsolute()) {
/* 114 */       file = new File(this.location, fileName);
/*     */     }
/*     */     try {
/* 117 */       this.fileItem.write(file);
/* 118 */     } catch (Exception e) {
/* 119 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getString(String encoding) throws UnsupportedEncodingException, IOException {
/* 124 */     return this.fileItem.getString(encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubmittedFileName() {
/* 132 */     String fileName = null;
/* 133 */     String cd = getHeader("Content-Disposition");
/* 134 */     if (cd != null) {
/* 135 */       String cdl = cd.toLowerCase(Locale.ENGLISH);
/* 136 */       if (cdl.startsWith("form-data") || cdl.startsWith("attachment")) {
/* 137 */         ParameterParser paramParser = new ParameterParser();
/* 138 */         paramParser.setLowerCaseNames(true);
/*     */         
/* 140 */         Map<String, String> params = paramParser.parse(cd, ';');
/* 141 */         if (params.containsKey("filename")) {
/* 142 */           fileName = params.get("filename");
/*     */ 
/*     */           
/* 145 */           if (fileName != null) {
/*     */             
/* 147 */             if (fileName.indexOf('\\') > -1) {
/*     */               
/* 149 */               fileName = HttpParser.unquote(fileName.trim());
/*     */             } else {
/*     */               
/* 152 */               fileName = fileName.trim();
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 158 */             fileName = "";
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 163 */     return fileName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationPart.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */