/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.SessionTrackingMode;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.PushBuilder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.authenticator.AuthenticatorBase;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.util.SessionConfig;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*     */ import org.apache.tomcat.util.http.CookieProcessor;
/*     */ import org.apache.tomcat.util.http.parser.HttpParser;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationPushBuilder
/*     */   implements PushBuilder
/*     */ {
/*  50 */   private static final StringManager sm = StringManager.getManager(ApplicationPushBuilder.class);
/*  51 */   private static final Set<String> DISALLOWED_METHODS = new HashSet<>();
/*     */   
/*     */   static {
/*  54 */     DISALLOWED_METHODS.add("POST");
/*  55 */     DISALLOWED_METHODS.add("PUT");
/*  56 */     DISALLOWED_METHODS.add("DELETE");
/*  57 */     DISALLOWED_METHODS.add("CONNECT");
/*  58 */     DISALLOWED_METHODS.add("OPTIONS");
/*  59 */     DISALLOWED_METHODS.add("TRACE");
/*     */   }
/*     */ 
/*     */   
/*     */   private final HttpServletRequest baseRequest;
/*     */   private final Request catalinaRequest;
/*     */   private final Request coyoteRequest;
/*     */   private final String sessionCookieName;
/*     */   private final String sessionPathParameterName;
/*     */   private final boolean addSessionCookie;
/*     */   private final boolean addSessionPathParameter;
/*  70 */   private final Map<String, List<String>> headers = (Map<String, List<String>>)new CaseInsensitiveKeyMap();
/*  71 */   private final List<Cookie> cookies = new ArrayList<>();
/*  72 */   private String method = "GET";
/*     */   
/*     */   private String path;
/*     */   
/*     */   private String queryString;
/*     */   private String sessionId;
/*     */   private String userName;
/*     */   
/*     */   public ApplicationPushBuilder(Request catalinaRequest, HttpServletRequest request) {
/*  81 */     this.baseRequest = request;
/*  82 */     this.catalinaRequest = catalinaRequest;
/*  83 */     this.coyoteRequest = catalinaRequest.getCoyoteRequest();
/*     */ 
/*     */     
/*  86 */     Enumeration<String> headerNames = request.getHeaderNames();
/*  87 */     while (headerNames.hasMoreElements()) {
/*  88 */       String headerName = headerNames.nextElement();
/*  89 */       List<String> values = new ArrayList<>();
/*  90 */       this.headers.put(headerName, values);
/*  91 */       Enumeration<String> headerValues = request.getHeaders(headerName);
/*  92 */       while (headerValues.hasMoreElements()) {
/*  93 */         values.add(headerValues.nextElement());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  98 */     this.headers.remove("if-match");
/*  99 */     this.headers.remove("if-none-match");
/* 100 */     this.headers.remove("if-modified-since");
/* 101 */     this.headers.remove("if-unmodified-since");
/* 102 */     this.headers.remove("if-range");
/* 103 */     this.headers.remove("range");
/* 104 */     this.headers.remove("expect");
/* 105 */     this.headers.remove("authorization");
/* 106 */     this.headers.remove("referer");
/*     */     
/* 108 */     this.headers.remove("cookie");
/*     */ 
/*     */     
/* 111 */     StringBuffer referer = request.getRequestURL();
/* 112 */     if (request.getQueryString() != null) {
/* 113 */       referer.append('?');
/* 114 */       referer.append(request.getQueryString());
/*     */     } 
/* 116 */     addHeader("referer", referer.toString());
/*     */ 
/*     */     
/* 119 */     Context context = catalinaRequest.getContext();
/* 120 */     this.sessionCookieName = SessionConfig.getSessionCookieName(context);
/* 121 */     this.sessionPathParameterName = SessionConfig.getSessionUriParamName(context);
/*     */     
/* 123 */     HttpSession session = request.getSession(false);
/* 124 */     if (session != null) {
/* 125 */       this.sessionId = session.getId();
/*     */     }
/* 127 */     if (this.sessionId == null) {
/* 128 */       this.sessionId = request.getRequestedSessionId();
/*     */     }
/* 130 */     if (!request.isRequestedSessionIdFromCookie() && !request.isRequestedSessionIdFromURL() && this.sessionId != null) {
/*     */       
/* 132 */       Set<SessionTrackingMode> sessionTrackingModes = request.getServletContext().getEffectiveSessionTrackingModes();
/* 133 */       this.addSessionCookie = sessionTrackingModes.contains(SessionTrackingMode.COOKIE);
/* 134 */       this.addSessionPathParameter = sessionTrackingModes.contains(SessionTrackingMode.URL);
/*     */     } else {
/* 136 */       this.addSessionCookie = request.isRequestedSessionIdFromCookie();
/* 137 */       this.addSessionPathParameter = request.isRequestedSessionIdFromURL();
/*     */     } 
/*     */ 
/*     */     
/* 141 */     if (request.getCookies() != null) {
/* 142 */       this.cookies.addAll(Arrays.asList(request.getCookies()));
/*     */     }
/* 144 */     for (Cookie responseCookie : catalinaRequest.getResponse().getCookies()) {
/* 145 */       if (responseCookie.getMaxAge() < 0) {
/*     */ 
/*     */         
/* 148 */         this.cookies.removeIf(cookie -> cookie.getName().equals(responseCookie.getName())); continue;
/*     */       } 
/* 150 */       this.cookies.add(new Cookie(responseCookie.getName(), responseCookie.getValue()));
/*     */     } 
/*     */     
/* 153 */     if (this.cookies.size() > 0) {
/* 154 */       List<String> cookieValues = new ArrayList<>(1);
/* 155 */       cookieValues.add(generateCookieHeader(this.cookies, catalinaRequest.getContext().getCookieProcessor()));
/* 156 */       this.headers.put("cookie", cookieValues);
/*     */     } 
/*     */ 
/*     */     
/* 160 */     if (catalinaRequest.getPrincipal() != null) {
/* 161 */       if (session == null || catalinaRequest.getSessionInternal(false).getPrincipal() == null || 
/* 162 */         !(context.getAuthenticator() instanceof AuthenticatorBase) || 
/* 163 */         !((AuthenticatorBase)context.getAuthenticator()).getCache())
/*     */       {
/* 165 */         this.userName = catalinaRequest.getPrincipal().getName();
/*     */       }
/* 167 */       setHeader("authorization", "x-push");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PushBuilder path(String path) {
/* 173 */     if (path.startsWith("/")) {
/* 174 */       this.path = path;
/*     */     } else {
/* 176 */       String contextPath = this.baseRequest.getContextPath();
/* 177 */       int len = contextPath.length() + path.length() + 1;
/* 178 */       StringBuilder sb = new StringBuilder(len);
/* 179 */       sb.append(contextPath);
/* 180 */       sb.append('/');
/* 181 */       sb.append(path);
/* 182 */       this.path = sb.toString();
/*     */     } 
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 190 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder method(String method) {
/* 196 */     String upperMethod = method.trim().toUpperCase(Locale.ENGLISH);
/* 197 */     if (DISALLOWED_METHODS.contains(upperMethod) || upperMethod.length() == 0) {
/* 198 */       throw new IllegalArgumentException(sm.getString("applicationPushBuilder.methodInvalid", new Object[] { upperMethod }));
/*     */     }
/*     */     
/* 201 */     if (!HttpParser.isToken(upperMethod)) {
/* 202 */       throw new IllegalArgumentException(sm.getString("applicationPushBuilder.methodNotToken", new Object[] { upperMethod }));
/*     */     }
/* 204 */     this.method = method;
/* 205 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethod() {
/* 211 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder queryString(String queryString) {
/* 217 */     this.queryString = queryString;
/* 218 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueryString() {
/* 224 */     return this.queryString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder sessionId(String sessionId) {
/* 230 */     this.sessionId = sessionId;
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionId() {
/* 237 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder addHeader(String name, String value) {
/* 243 */     ((List<String>)this.headers.computeIfAbsent(name, k -> new ArrayList())).add(value);
/* 244 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder setHeader(String name, String value) {
/* 250 */     List<String> values = this.headers.get(name);
/* 251 */     if (values == null) {
/* 252 */       values = new ArrayList<>();
/* 253 */       this.headers.put(name, values);
/*     */     } else {
/* 255 */       values.clear();
/*     */     } 
/* 257 */     values.add(value);
/*     */     
/* 259 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBuilder removeHeader(String name) {
/* 265 */     this.headers.remove(name);
/*     */     
/* 267 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getHeaderNames() {
/* 273 */     return Collections.unmodifiableSet(this.headers.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeader(String name) {
/* 279 */     List<String> values = this.headers.get(name);
/* 280 */     if (values == null) {
/* 281 */       return null;
/*     */     }
/* 283 */     return values.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void push() {
/*     */     String pushPath;
/* 290 */     if (this.path == null) {
/* 291 */       throw new IllegalStateException(sm.getString("pushBuilder.noPath"));
/*     */     }
/*     */     
/* 294 */     Request pushTarget = new Request();
/*     */     
/* 296 */     pushTarget.setMethod(this.method);
/*     */     
/* 298 */     pushTarget.serverName().setString(this.baseRequest.getServerName());
/* 299 */     pushTarget.setServerPort(this.baseRequest.getServerPort());
/* 300 */     pushTarget.scheme().setString(this.baseRequest.getScheme());
/*     */ 
/*     */     
/* 303 */     for (Map.Entry<String, List<String>> header : this.headers.entrySet()) {
/* 304 */       for (String value : header.getValue()) {
/* 305 */         pushTarget.getMimeHeaders().addValue(header.getKey()).setString(value);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 310 */     int queryIndex = this.path.indexOf('?');
/*     */     
/* 312 */     String pushQueryString = null;
/* 313 */     if (queryIndex > -1) {
/* 314 */       pushPath = this.path.substring(0, queryIndex);
/* 315 */       if (queryIndex + 1 < this.path.length()) {
/* 316 */         pushQueryString = this.path.substring(queryIndex + 1);
/*     */       }
/*     */     } else {
/* 319 */       pushPath = this.path;
/*     */     } 
/*     */ 
/*     */     
/* 323 */     if (this.sessionId != null) {
/* 324 */       if (this.addSessionPathParameter) {
/* 325 */         pushPath = pushPath + ";" + pushPath + "=" + this.sessionPathParameterName;
/* 326 */         pushTarget.addPathParameter(this.sessionPathParameterName, this.sessionId);
/*     */       } 
/* 328 */       if (this.addSessionCookie) {
/* 329 */         String sessionCookieHeader = this.sessionCookieName + "=" + this.sessionCookieName;
/* 330 */         MessageBytes mb = pushTarget.getMimeHeaders().getValue("cookie");
/* 331 */         if (mb == null) {
/* 332 */           mb = pushTarget.getMimeHeaders().addValue("cookie");
/* 333 */           mb.setString(sessionCookieHeader);
/*     */         } else {
/* 335 */           mb.setString(mb.getString() + ";" + mb.getString());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 341 */     pushTarget.requestURI().setString(pushPath);
/* 342 */     pushTarget.decodedURI().setString(decode(pushPath, this.catalinaRequest.getConnector().getURICharset()));
/*     */ 
/*     */     
/* 345 */     if (pushQueryString == null && this.queryString != null) {
/* 346 */       pushTarget.queryString().setString(this.queryString);
/* 347 */     } else if (pushQueryString != null && this.queryString == null) {
/* 348 */       pushTarget.queryString().setString(pushQueryString);
/* 349 */     } else if (pushQueryString != null && this.queryString != null) {
/* 350 */       pushTarget.queryString().setString(pushQueryString + "&" + pushQueryString);
/*     */     } 
/*     */ 
/*     */     
/* 354 */     if (this.userName != null) {
/* 355 */       pushTarget.getRemoteUser().setString(this.userName);
/* 356 */       pushTarget.setRemoteUserNeedsAuthorization(true);
/*     */     } 
/*     */     
/* 359 */     this.coyoteRequest.action(ActionCode.PUSH_REQUEST, pushTarget);
/*     */ 
/*     */     
/* 362 */     this.path = null;
/* 363 */     this.headers.remove("if-none-match");
/* 364 */     this.headers.remove("if-modified-since");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String decode(String input, Charset charset) {
/* 370 */     int start = input.indexOf('%');
/* 371 */     int end = 0;
/*     */ 
/*     */     
/* 374 */     if (start == -1) {
/* 375 */       return input;
/*     */     }
/*     */     
/* 378 */     StringBuilder result = new StringBuilder(input.length());
/* 379 */     while (start != -1) {
/*     */ 
/*     */       
/* 382 */       result.append(input.substring(end, start));
/*     */       
/* 384 */       end = start + 3;
/* 385 */       while (end < input.length() && input.charAt(end) == '%') {
/* 386 */         end += 3;
/*     */       }
/* 388 */       result.append(decodePercentSequence(input.substring(start, end), charset));
/* 389 */       start = input.indexOf('%', end);
/*     */     } 
/*     */     
/* 392 */     result.append(input.substring(end));
/*     */     
/* 394 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String decodePercentSequence(String sequence, Charset charset) {
/* 399 */     byte[] bytes = new byte[sequence.length() / 3];
/* 400 */     for (int i = 0; i < bytes.length; i += 3) {
/* 401 */       bytes[i] = 
/* 402 */         (byte)((HexUtils.getDec(sequence.charAt(1 + 3 * i)) << 4) + HexUtils.getDec(sequence.charAt(2 + 3 * i)));
/*     */     }
/*     */     
/* 405 */     return new String(bytes, charset);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String generateCookieHeader(List<Cookie> cookies, CookieProcessor cookieProcessor) {
/* 410 */     StringBuilder result = new StringBuilder();
/* 411 */     boolean first = true;
/* 412 */     for (Cookie cookie : cookies) {
/* 413 */       if (first) {
/* 414 */         first = false;
/*     */       } else {
/* 416 */         result.append(';');
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 423 */       result.append(cookieProcessor.generateHeader(cookie, null));
/*     */     } 
/* 425 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationPushBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */