/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import jakarta.servlet.Filter;
/*      */ import jakarta.servlet.FilterRegistration;
/*      */ import jakarta.servlet.RequestDispatcher;
/*      */ import jakarta.servlet.Servlet;
/*      */ import jakarta.servlet.ServletContext;
/*      */ import jakarta.servlet.ServletContextAttributeEvent;
/*      */ import jakarta.servlet.ServletContextAttributeListener;
/*      */ import jakarta.servlet.ServletException;
/*      */ import jakarta.servlet.ServletRegistration;
/*      */ import jakarta.servlet.ServletSecurityElement;
/*      */ import jakarta.servlet.SessionCookieConfig;
/*      */ import jakarta.servlet.SessionTrackingMode;
/*      */ import jakarta.servlet.annotation.ServletSecurity;
/*      */ import jakarta.servlet.descriptor.JspConfigDescriptor;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ApplicationContext
/*      */   implements ServletContext
/*      */ {
/*      */   protected Map<String, Object> attributes;
/*      */   private final Map<String, String> readOnlyAttributes;
/*      */   private final StandardContext context;
/*      */   private final Service service;
/*      */   private final ServletContext facade;
/*      */   private final Map<String, String> parameters;
/*      */   private static final StringManager sm = StringManager.getManager(ApplicationContext.class);
/*      */   private final ThreadLocal<DispatchData> dispatchData;
/*      */   private final SessionCookieConfig sessionCookieConfig;
/*      */   
/*      */   public ApplicationContext(StandardContext context) {
/*  113 */     this.attributes = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  119 */     this.readOnlyAttributes = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  137 */     this.facade = new ApplicationContextFacade(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  143 */     this.parameters = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  155 */     this.dispatchData = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  166 */     this.sessionTrackingModes = null;
/*  167 */     this.defaultSessionTrackingModes = null;
/*  168 */     this.supportedSessionTrackingModes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  174 */     this.newServletContextListenerAllowed = true;
/*      */     this.context = context;
/*      */     this.service = ((Engine)context.getParent().getParent()).getService();
/*      */     this.sessionCookieConfig = new ApplicationSessionCookieConfig(context);
/*      */     populateSessionTrackingModes();
/*      */   }
/*      */   public Object getAttribute(String name) {
/*  181 */     return this.attributes.get(name);
/*      */   }
/*      */   private Set<SessionTrackingMode> sessionTrackingModes;
/*      */   private Set<SessionTrackingMode> defaultSessionTrackingModes;
/*      */   
/*      */   public Enumeration<String> getAttributeNames() {
/*  187 */     Set<String> names = new HashSet<>(this.attributes.keySet());
/*  188 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */   private Set<SessionTrackingMode> supportedSessionTrackingModes;
/*      */   private boolean newServletContextListenerAllowed;
/*      */   
/*      */   public ServletContext getContext(String uri) {
/*      */     Context child;
/*  196 */     if (uri == null || !uri.startsWith("/")) {
/*  197 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  203 */       Container host = this.context.getParent();
/*  204 */       child = (Context)host.findChild(uri);
/*      */ 
/*      */       
/*  207 */       if (child != null && !child.getState().isAvailable()) {
/*  208 */         child = null;
/*      */       }
/*      */ 
/*      */       
/*  212 */       if (child == null) {
/*  213 */         int i = uri.indexOf("##");
/*  214 */         if (i > -1) {
/*  215 */           uri = uri.substring(0, i);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  221 */         MessageBytes hostMB = MessageBytes.newInstance();
/*  222 */         hostMB.setString(host.getName());
/*      */         
/*  224 */         MessageBytes pathMB = MessageBytes.newInstance();
/*  225 */         pathMB.setString(uri);
/*      */         
/*  227 */         MappingData mappingData = new MappingData();
/*  228 */         this.service.getMapper().map(hostMB, pathMB, null, mappingData);
/*  229 */         child = mappingData.context;
/*      */       } 
/*  231 */     } catch (Throwable t) {
/*  232 */       ExceptionUtils.handleThrowable(t);
/*  233 */       return null;
/*      */     } 
/*      */     
/*  236 */     if (child == null) {
/*  237 */       return null;
/*      */     }
/*      */     
/*  240 */     if (this.context.getCrossContext())
/*      */     {
/*  242 */       return child.getServletContext(); } 
/*  243 */     if (child == this.context)
/*      */     {
/*  245 */       return this.context.getServletContext();
/*      */     }
/*      */     
/*  248 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContextPath() {
/*  255 */     return this.context.getPath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInitParameter(String name) {
/*  263 */     if ("org.apache.jasper.XML_VALIDATE_TLD".equals(name) && this.context.getTldValidation()) {
/*  264 */       return "true";
/*      */     }
/*  266 */     if ("org.apache.jasper.XML_BLOCK_EXTERNAL".equals(name) && 
/*  267 */       !this.context.getXmlBlockExternal())
/*      */     {
/*  269 */       return "false";
/*      */     }
/*      */     
/*  272 */     return this.parameters.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration<String> getInitParameterNames() {
/*  278 */     Set<String> names = new HashSet<>(this.parameters.keySet());
/*      */ 
/*      */     
/*  281 */     if (this.context.getTldValidation()) {
/*  282 */       names.add("org.apache.jasper.XML_VALIDATE_TLD");
/*      */     }
/*  284 */     if (!this.context.getXmlBlockExternal()) {
/*  285 */       names.add("org.apache.jasper.XML_BLOCK_EXTERNAL");
/*      */     }
/*  287 */     return Collections.enumeration(names);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMajorVersion() {
/*  293 */     return 6;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMinorVersion() {
/*  299 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMimeType(String file) {
/*  306 */     if (file == null) {
/*  307 */       return null;
/*      */     }
/*  309 */     int period = file.lastIndexOf('.');
/*  310 */     if (period < 0) {
/*  311 */       return null;
/*      */     }
/*  313 */     String extension = file.substring(period + 1);
/*  314 */     if (extension.isEmpty()) {
/*  315 */       return null;
/*      */     }
/*  317 */     return this.context.findMimeMapping(extension);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestDispatcher getNamedDispatcher(String name) {
/*  326 */     if (name == null) {
/*  327 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  331 */     Wrapper wrapper = (Wrapper)this.context.findChild(name);
/*  332 */     if (wrapper == null) {
/*  333 */       return null;
/*      */     }
/*      */     
/*  336 */     return new ApplicationDispatcher(wrapper, null, null, null, null, null, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRealPath(String path) {
/*  343 */     String validatedPath = validateResourcePath(path, true);
/*  344 */     return this.context.getRealPath(validatedPath);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RequestDispatcher getRequestDispatcher(String path) {
/*      */     String uri, queryString;
/*      */     MappingData mappingData;
/*  352 */     if (path == null) {
/*  353 */       return null;
/*      */     }
/*  355 */     if (!path.startsWith("/")) {
/*  356 */       throw new IllegalArgumentException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  363 */     int pos = path.indexOf('?');
/*  364 */     if (pos >= 0) {
/*  365 */       uri = path.substring(0, pos);
/*  366 */       queryString = path.substring(pos + 1);
/*      */     } else {
/*  368 */       uri = path;
/*  369 */       queryString = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  374 */     String uriToMap = RequestUtil.stripPathParams(uri, null);
/*      */ 
/*      */     
/*  377 */     if (getContext().getDispatchersUseEncodedPaths()) {
/*  378 */       uriToMap = UDecoder.URLDecode(uriToMap, StandardCharsets.UTF_8, this.context.getEncodedSolidusHandlingEnum(), this.context
/*  379 */           .getEncodedReverseSolidusHandlingEnum());
/*      */     }
/*      */ 
/*      */     
/*  383 */     uriToMap = RequestUtil.normalize(uriToMap);
/*  384 */     if (uriToMap == null) {
/*  385 */       getContext().getLogger().warn(sm.getString("applicationContext.illegalDispatchPath", new Object[] { path }), new IllegalArgumentException());
/*      */       
/*  387 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  395 */     if (getContext().getDispatchersUseEncodedPaths()) {
/*  396 */       uri = URLEncoder.DEFAULT.encode(getContextPath(), StandardCharsets.UTF_8) + URLEncoder.DEFAULT.encode(getContextPath(), StandardCharsets.UTF_8);
/*      */     } else {
/*  398 */       uri = URLEncoder.DEFAULT.encode(getContextPath() + getContextPath(), StandardCharsets.UTF_8);
/*      */     } 
/*      */ 
/*      */     
/*  402 */     DispatchData dd = this.dispatchData.get();
/*  403 */     if (dd == null) {
/*  404 */       dd = new DispatchData();
/*  405 */       this.dispatchData.set(dd);
/*      */     } 
/*      */ 
/*      */     
/*  409 */     MessageBytes uriMB = dd.uriMB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getResource(String path) throws MalformedURLException {
/*  452 */     String validatedPath = validateResourcePath(path, !this.context.getContextGetResourceRequiresSlash());
/*      */     
/*  454 */     if (validatedPath == null) {
/*  455 */       throw new MalformedURLException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */     
/*  458 */     WebResourceRoot resources = this.context.getResources();
/*  459 */     if (resources != null) {
/*  460 */       return resources.getResource(validatedPath).getURL();
/*      */     }
/*      */     
/*  463 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getResourceAsStream(String path) {
/*  470 */     String validatedPath = validateResourcePath(path, !this.context.getContextGetResourceRequiresSlash());
/*      */     
/*  472 */     if (validatedPath == null) {
/*  473 */       return null;
/*      */     }
/*      */     
/*  476 */     WebResourceRoot resources = this.context.getResources();
/*  477 */     if (resources != null) {
/*  478 */       return resources.getResource(validatedPath).getInputStream();
/*      */     }
/*      */     
/*  481 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String validateResourcePath(String path, boolean addMissingInitialSlash) {
/*  489 */     if (path == null) {
/*  490 */       return null;
/*      */     }
/*      */     
/*  493 */     if (!path.startsWith("/")) {
/*  494 */       if (addMissingInitialSlash) {
/*  495 */         return "/" + path;
/*      */       }
/*  497 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  501 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getResourcePaths(String path) {
/*  509 */     if (path == null) {
/*  510 */       return null;
/*      */     }
/*  512 */     if (!path.startsWith("/")) {
/*  513 */       throw new IllegalArgumentException(sm.getString("applicationContext.resourcePaths.iae", new Object[] { path }));
/*      */     }
/*      */     
/*  516 */     WebResourceRoot resources = this.context.getResources();
/*  517 */     if (resources != null) {
/*  518 */       return resources.listWebAppPaths(path);
/*      */     }
/*      */     
/*  521 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerInfo() {
/*  527 */     return ServerInfo.getServerInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServletContextName() {
/*  533 */     return this.context.getDisplayName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(String message) {
/*  539 */     this.context.getLogger().info(message);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(String message, Throwable throwable) {
/*  545 */     this.context.getLogger().error(message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String name) {
/*  554 */     if (this.readOnlyAttributes.containsKey(name)) {
/*      */       return;
/*      */     }
/*  557 */     Object value = this.attributes.remove(name);
/*  558 */     if (value == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  563 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  564 */     if (listeners == null || listeners.length == 0) {
/*      */       return;
/*      */     }
/*  567 */     ServletContextAttributeEvent event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*  568 */     for (Object obj : listeners) {
/*  569 */       if (obj instanceof ServletContextAttributeListener) {
/*      */ 
/*      */         
/*  572 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)obj;
/*      */         try {
/*  574 */           this.context.fireContainerEvent("beforeContextAttributeRemoved", listener);
/*  575 */           listener.attributeRemoved(event);
/*  576 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*  577 */         } catch (Throwable t) {
/*  578 */           ExceptionUtils.handleThrowable(t);
/*  579 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*  580 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/*      */     ServletContextAttributeEvent event;
/*  589 */     if (name == null) {
/*  590 */       throw new NullPointerException(sm.getString("applicationContext.setAttribute.namenull"));
/*      */     }
/*      */ 
/*      */     
/*  594 */     if (value == null) {
/*  595 */       removeAttribute(name);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  601 */     if (this.readOnlyAttributes.containsKey(name)) {
/*      */       return;
/*      */     }
/*      */     
/*  605 */     Object oldValue = this.attributes.put(name, value);
/*  606 */     boolean replaced = (oldValue != null);
/*      */ 
/*      */     
/*  609 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  610 */     if (listeners == null || listeners.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  614 */     if (replaced) {
/*  615 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, oldValue);
/*      */     } else {
/*  617 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*      */     } 
/*      */     
/*  620 */     for (Object obj : listeners) {
/*  621 */       if (obj instanceof ServletContextAttributeListener) {
/*      */ 
/*      */         
/*  624 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)obj;
/*      */         try {
/*  626 */           if (replaced) {
/*  627 */             this.context.fireContainerEvent("beforeContextAttributeReplaced", listener);
/*  628 */             listener.attributeReplaced(event);
/*  629 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           } else {
/*  631 */             this.context.fireContainerEvent("beforeContextAttributeAdded", listener);
/*  632 */             listener.attributeAdded(event);
/*  633 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           } 
/*  635 */         } catch (Throwable t) {
/*  636 */           ExceptionUtils.handleThrowable(t);
/*  637 */           if (replaced) {
/*  638 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           } else {
/*  640 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           } 
/*  642 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, String className) {
/*  650 */     return addFilter(filterName, className, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter) {
/*  656 */     return addFilter(filterName, null, filter);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass) {
/*  662 */     return addFilter(filterName, filterClass.getName(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FilterRegistration.Dynamic addFilter(String filterName, String filterClass, Filter filter) throws IllegalStateException {
/*  669 */     if (filterName == null || filterName.isEmpty()) {
/*  670 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidFilterName", new Object[] { filterName }));
/*      */     }
/*      */ 
/*      */     
/*  674 */     checkState("applicationContext.addFilter.ise");
/*      */     
/*  676 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*      */ 
/*      */ 
/*      */     
/*  680 */     if (filterDef == null) {
/*  681 */       filterDef = new FilterDef();
/*  682 */       filterDef.setFilterName(filterName);
/*  683 */       this.context.addFilterDef(filterDef);
/*      */     }
/*  685 */     else if (filterDef.getFilterName() != null && filterDef.getFilterClass() != null) {
/*  686 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  690 */     if (filter == null) {
/*  691 */       filterDef.setFilterClass(filterClass);
/*      */     } else {
/*  693 */       filterDef.setFilterClass(filter.getClass().getName());
/*  694 */       filterDef.setFilter(filter);
/*      */     } 
/*      */     
/*  697 */     return new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends Filter> T createFilter(Class<T> c) throws ServletException {
/*      */     try {
/*  705 */       return (T)this.context.getInstanceManager().newInstance(c.getName());
/*      */     }
/*  707 */     catch (InvocationTargetException e) {
/*  708 */       ExceptionUtils.handleThrowable(e.getCause());
/*  709 */       throw new ServletException(e);
/*  710 */     } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/*  711 */       throw new ServletException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FilterRegistration getFilterRegistration(String filterName) {
/*  718 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*  719 */     if (filterDef == null) {
/*  720 */       return null;
/*      */     }
/*  722 */     return (FilterRegistration)new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, String className) {
/*  728 */     return addServlet(servletName, className, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet) {
/*  734 */     return addServlet(servletName, null, servlet, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass) {
/*  740 */     return addServlet(servletName, servletClass.getName(), null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletRegistration.Dynamic addJspFile(String jspName, String jspFile) {
/*      */     String jspServletClassName;
/*  748 */     if (jspFile == null || !jspFile.startsWith("/")) {
/*  749 */       throw new IllegalArgumentException(sm.getString("applicationContext.addJspFile.iae", new Object[] { jspFile }));
/*      */     }
/*      */     
/*  752 */     Map<String, String> jspFileInitParams = new HashMap<>();
/*      */     
/*  754 */     Wrapper jspServlet = (Wrapper)this.context.findChild("jsp");
/*      */ 
/*      */     
/*  757 */     if (jspServlet == null) {
/*      */ 
/*      */       
/*  760 */       jspServletClassName = "org.apache.jasper.servlet.JspServlet";
/*      */     }
/*      */     else {
/*      */       
/*  764 */       jspServletClassName = jspServlet.getServletClass();
/*      */       
/*  766 */       String[] params = jspServlet.findInitParameters();
/*  767 */       for (String param : params) {
/*  768 */         jspFileInitParams.put(param, jspServlet.findInitParameter(param));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  773 */     jspFileInitParams.put("jspFile", jspFile);
/*      */     
/*  775 */     return addServlet(jspName, jspServletClassName, null, jspFileInitParams);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ServletRegistration.Dynamic addServlet(String servletName, String servletClass, Servlet servlet, Map<String, String> initParams) throws IllegalStateException {
/*  782 */     if (servletName == null || servletName.isEmpty()) {
/*  783 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidServletName", new Object[] { servletName }));
/*      */     }
/*      */ 
/*      */     
/*  787 */     checkState("applicationContext.addServlet.ise");
/*      */     
/*  789 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*      */ 
/*      */ 
/*      */     
/*  793 */     if (wrapper == null) {
/*  794 */       wrapper = this.context.createWrapper();
/*  795 */       wrapper.setName(servletName);
/*  796 */       this.context.addChild((Container)wrapper);
/*      */     }
/*  798 */     else if (wrapper.getName() != null && wrapper.getServletClass() != null) {
/*  799 */       if (wrapper.isOverridable()) {
/*  800 */         wrapper.setOverridable(false);
/*      */       } else {
/*  802 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  807 */     ServletSecurity annotation = null;
/*  808 */     if (servlet == null) {
/*  809 */       wrapper.setServletClass(servletClass);
/*  810 */       Class<?> clazz = Introspection.loadClass(this.context, servletClass);
/*  811 */       if (clazz != null) {
/*  812 */         annotation = clazz.<ServletSecurity>getAnnotation(ServletSecurity.class);
/*      */       }
/*      */     } else {
/*  815 */       wrapper.setServletClass(servlet.getClass().getName());
/*  816 */       wrapper.setServlet(servlet);
/*  817 */       if (this.context.wasCreatedDynamicServlet(servlet)) {
/*  818 */         annotation = (ServletSecurity)servlet.getClass().getAnnotation(ServletSecurity.class);
/*      */       }
/*      */     } 
/*      */     
/*  822 */     if (initParams != null) {
/*  823 */       for (Map.Entry<String, String> initParam : initParams.entrySet()) {
/*  824 */         wrapper.addInitParameter(initParam.getKey(), initParam.getValue());
/*      */       }
/*      */     }
/*      */     
/*  828 */     ServletRegistration.Dynamic registration = new ApplicationServletRegistration(wrapper, this.context);
/*  829 */     if (annotation != null) {
/*  830 */       registration.setServletSecurity(new ServletSecurityElement(annotation));
/*      */     }
/*  832 */     return registration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends Servlet> T createServlet(Class<T> c) throws ServletException {
/*      */     try {
/*  840 */       Servlet servlet = (Servlet)this.context.getInstanceManager().newInstance(c.getName());
/*  841 */       this.context.dynamicServletCreated(servlet);
/*  842 */       return (T)servlet;
/*  843 */     } catch (InvocationTargetException e) {
/*  844 */       ExceptionUtils.handleThrowable(e.getCause());
/*  845 */       throw new ServletException(e);
/*  846 */     } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/*  847 */       throw new ServletException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ServletRegistration getServletRegistration(String servletName) {
/*  854 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*  855 */     if (wrapper == null) {
/*  856 */       return null;
/*      */     }
/*      */     
/*  859 */     return (ServletRegistration)new ApplicationServletRegistration(wrapper, this.context);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes() {
/*  865 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void populateSessionTrackingModes() {
/*  871 */     this.defaultSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/*  872 */     this.supportedSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/*      */     
/*  874 */     if (this.context.getCookies()) {
/*  875 */       this.defaultSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/*  876 */       this.supportedSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  881 */     Connector[] connectors = this.service.findConnectors();
/*      */     
/*  883 */     for (Connector connector : connectors) {
/*  884 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/*  885 */         this.supportedSessionTrackingModes.add(SessionTrackingMode.SSL);
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes() {
/*  894 */     if (this.sessionTrackingModes != null) {
/*  895 */       return this.sessionTrackingModes;
/*      */     }
/*  897 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SessionCookieConfig getSessionCookieConfig() {
/*  903 */     return this.sessionCookieConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes) {
/*  910 */     checkState("applicationContext.setSessionTracking.ise");
/*      */ 
/*      */     
/*  913 */     for (SessionTrackingMode sessionTrackingMode : sessionTrackingModes) {
/*  914 */       if (!this.supportedSessionTrackingModes.contains(sessionTrackingMode)) {
/*  915 */         throw new IllegalArgumentException(sm.getString("applicationContext.setSessionTracking.iae.invalid", new Object[] { sessionTrackingMode
/*  916 */                 .toString(), getContextPath() }));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  921 */     if (sessionTrackingModes.contains(SessionTrackingMode.SSL) && 
/*  922 */       sessionTrackingModes.size() > 1) {
/*  923 */       throw new IllegalArgumentException(sm
/*  924 */           .getString("applicationContext.setSessionTracking.iae.ssl", new Object[] { getContextPath() }));
/*      */     }
/*      */ 
/*      */     
/*  928 */     this.sessionTrackingModes = sessionTrackingModes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setInitParameter(String name, String value) {
/*  935 */     if (name == null) {
/*  936 */       throw new NullPointerException(sm.getString("applicationContext.setAttribute.namenull"));
/*      */     }
/*  938 */     checkState("applicationContext.setInitParam.ise");
/*  939 */     return (this.parameters.putIfAbsent(name, value) == null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addListener(Class<? extends EventListener> listenerClass) {
/*      */     EventListener listener;
/*      */     try {
/*  947 */       listener = createListener((Class)listenerClass);
/*  948 */     } catch (ServletException e) {
/*  949 */       throw new IllegalArgumentException(sm
/*  950 */           .getString("applicationContext.addListener.iae.init", new Object[] { listenerClass.getName() }), e);
/*      */     } 
/*  952 */     addListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addListener(String className) {
/*      */     try {
/*  960 */       if (this.context.getInstanceManager() != null) {
/*  961 */         Object obj = this.context.getInstanceManager().newInstance(className);
/*      */         
/*  963 */         if (!(obj instanceof EventListener)) {
/*  964 */           throw new IllegalArgumentException(sm
/*  965 */               .getString("applicationContext.addListener.iae.wrongType", new Object[] { className }));
/*      */         }
/*      */         
/*  968 */         EventListener listener = (EventListener)obj;
/*  969 */         addListener(listener);
/*      */       } 
/*  971 */     } catch (InvocationTargetException e) {
/*  972 */       ExceptionUtils.handleThrowable(e.getCause());
/*  973 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*  974 */     } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/*  975 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends EventListener> void addListener(T t) {
/*  983 */     checkState("applicationContext.addListener.ise");
/*      */     
/*  985 */     boolean match = false;
/*  986 */     if (t instanceof ServletContextAttributeListener || t instanceof jakarta.servlet.ServletRequestListener || t instanceof jakarta.servlet.ServletRequestAttributeListener || t instanceof jakarta.servlet.http.HttpSessionIdListener || t instanceof jakarta.servlet.http.HttpSessionAttributeListener) {
/*      */ 
/*      */       
/*  989 */       this.context.addApplicationEventListener(t);
/*  990 */       match = true;
/*      */     } 
/*      */     
/*  993 */     if (t instanceof jakarta.servlet.http.HttpSessionListener || (t instanceof jakarta.servlet.ServletContextListener && this.newServletContextListenerAllowed)) {
/*      */ 
/*      */ 
/*      */       
/*  997 */       this.context.addApplicationLifecycleListener(t);
/*  998 */       match = true;
/*      */     } 
/*      */     
/* 1001 */     if (match) {
/*      */       return;
/*      */     }
/*      */     
/* 1005 */     if (t instanceof jakarta.servlet.ServletContextListener) {
/* 1006 */       throw new IllegalArgumentException(sm
/* 1007 */           .getString("applicationContext.addListener.iae.sclNotAllowed", new Object[] { t.getClass().getName() }));
/*      */     }
/* 1009 */     throw new IllegalArgumentException(sm
/* 1010 */         .getString("applicationContext.addListener.iae.wrongType", new Object[] { t.getClass().getName() }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends EventListener> T createListener(Class<T> c) throws ServletException {
/*      */     try {
/* 1019 */       EventListener eventListener = (EventListener)this.context.getInstanceManager().newInstance(c);
/* 1020 */       if (eventListener instanceof jakarta.servlet.ServletContextListener || eventListener instanceof ServletContextAttributeListener || eventListener instanceof jakarta.servlet.ServletRequestListener || eventListener instanceof jakarta.servlet.ServletRequestAttributeListener || eventListener instanceof jakarta.servlet.http.HttpSessionListener || eventListener instanceof jakarta.servlet.http.HttpSessionIdListener || eventListener instanceof jakarta.servlet.http.HttpSessionAttributeListener)
/*      */       {
/*      */ 
/*      */         
/* 1024 */         return (T)eventListener;
/*      */       }
/* 1026 */       throw new IllegalArgumentException(sm
/* 1027 */           .getString("applicationContext.addListener.iae.wrongType", new Object[] { eventListener.getClass().getName() }));
/* 1028 */     } catch (InvocationTargetException e) {
/* 1029 */       ExceptionUtils.handleThrowable(e.getCause());
/* 1030 */       throw new ServletException(e);
/* 1031 */     } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 1032 */       throw new ServletException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void declareRoles(String... roleNames) {
/* 1041 */     checkState("applicationContext.addRole.ise");
/*      */     
/* 1043 */     if (roleNames == null) {
/* 1044 */       throw new IllegalArgumentException(sm.getString("applicationContext.roles.iae", new Object[] { getContextPath() }));
/*      */     }
/*      */     
/* 1047 */     for (String role : roleNames) {
/* 1048 */       if (role == null || role.isEmpty()) {
/* 1049 */         throw new IllegalArgumentException(sm.getString("applicationContext.role.iae", new Object[] { getContextPath() }));
/*      */       }
/* 1051 */       this.context.addSecurityRole(role);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassLoader getClassLoader() {
/* 1058 */     ClassLoader result = this.context.getLoader().getClassLoader();
/* 1059 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1060 */       ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/* 1061 */       ClassLoader parent = result;
/* 1062 */       while (parent != null && 
/* 1063 */         parent != tccl)
/*      */       {
/*      */         
/* 1066 */         parent = parent.getParent();
/*      */       }
/* 1068 */       if (parent == null) {
/* 1069 */         System.getSecurityManager().checkPermission(new RuntimePermission("getClassLoader"));
/*      */       }
/*      */     } 
/*      */     
/* 1073 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getEffectiveMajorVersion() {
/* 1079 */     return this.context.getEffectiveMajorVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getEffectiveMinorVersion() {
/* 1085 */     return this.context.getEffectiveMinorVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, ? extends FilterRegistration> getFilterRegistrations() {
/* 1091 */     Map<String, ApplicationFilterRegistration> result = new HashMap<>();
/*      */     
/* 1093 */     FilterDef[] filterDefs = this.context.findFilterDefs();
/* 1094 */     for (FilterDef filterDef : filterDefs) {
/* 1095 */       result.put(filterDef.getFilterName(), new ApplicationFilterRegistration(filterDef, this.context));
/*      */     }
/*      */     
/* 1098 */     return (Map)result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JspConfigDescriptor getJspConfigDescriptor() {
/* 1104 */     return this.context.getJspConfigDescriptor();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, ? extends ServletRegistration> getServletRegistrations() {
/* 1110 */     Map<String, ApplicationServletRegistration> result = new HashMap<>();
/*      */     
/* 1112 */     Container[] wrappers = this.context.findChildren();
/* 1113 */     for (Container wrapper : wrappers) {
/* 1114 */       result.put(wrapper.getName(), new ApplicationServletRegistration((Wrapper)wrapper, this.context));
/*      */     }
/*      */     
/* 1117 */     return (Map)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVirtualServerName() {
/* 1124 */     Container host = this.context.getParent();
/* 1125 */     Container engine = host.getParent();
/* 1126 */     return engine.getName() + "/" + engine.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSessionTimeout() {
/* 1132 */     return this.context.getSessionTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionTimeout(int sessionTimeout) {
/* 1138 */     checkState("applicationContext.setSessionTimeout.ise");
/* 1139 */     this.context.setSessionTimeout(sessionTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestCharacterEncoding() {
/* 1145 */     return this.context.getRequestCharacterEncoding();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestCharacterEncoding(String encoding) {
/* 1151 */     checkState("applicationContext.setRequestEncoding.ise");
/* 1152 */     this.context.setRequestCharacterEncoding(encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getResponseCharacterEncoding() {
/* 1158 */     return this.context.getResponseCharacterEncoding();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResponseCharacterEncoding(String encoding) {
/* 1164 */     checkState("applicationContext.setResponseEncoding.ise");
/* 1165 */     this.context.setResponseCharacterEncoding(encoding);
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkState(String messageKey) {
/* 1170 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 1171 */       throw new IllegalStateException(sm.getString(messageKey, new Object[] { getContextPath() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected StandardContext getContext() {
/* 1178 */     return this.context;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearAttributes() {
/* 1187 */     List<String> list = new ArrayList<>(this.attributes.keySet());
/*      */ 
/*      */ 
/*      */     
/* 1191 */     for (String key : list) {
/* 1192 */       removeAttribute(key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ServletContext getFacade() {
/* 1202 */     return this.facade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setAttributeReadOnly(String name) {
/* 1211 */     if (this.attributes.containsKey(name)) {
/* 1212 */       this.readOnlyAttributes.put(name, name);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setNewServletContextListenerAllowed(boolean allowed) {
/* 1219 */     this.newServletContextListenerAllowed = allowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class DispatchData
/*      */   {
/* 1231 */     public MessageBytes uriMB = MessageBytes.newInstance(); DispatchData() {
/* 1232 */       CharChunk uriCC = this.uriMB.getCharChunk();
/* 1233 */       uriCC.setLimit(-1);
/* 1234 */       this.mappingData = new MappingData();
/*      */     }
/*      */     
/*      */     public MappingData mappingData;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */