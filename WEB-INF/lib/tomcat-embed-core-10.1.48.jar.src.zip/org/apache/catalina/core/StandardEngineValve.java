/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.io.IOException;
/*    */ import org.apache.catalina.Host;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.catalina.valves.ValveBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StandardEngineValve
/*    */   extends ValveBase
/*    */ {
/*    */   StandardEngineValve() {
/* 37 */     super(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(Request request, Response response) throws IOException, ServletException {
/* 57 */     Host host = request.getHost();
/* 58 */     if (host == null) {
/*    */ 
/*    */ 
/*    */       
/* 62 */       if (!response.isError()) {
/* 63 */         response.sendError(404);
/*    */       }
/*    */       return;
/*    */     } 
/* 67 */     if (request.isAsyncSupported()) {
/* 68 */       request.setAsyncSupported(host.getPipeline().isAsyncSupported());
/*    */     }
/*    */ 
/*    */     
/* 72 */     host.getPipeline().getFirst().invoke(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardEngineValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */