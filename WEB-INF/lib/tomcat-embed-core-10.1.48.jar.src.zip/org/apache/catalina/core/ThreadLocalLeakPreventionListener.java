/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.ThreadPoolExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadLocalLeakPreventionListener
/*     */   extends FrameworkListener
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(ThreadLocalLeakPreventionListener.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean serverStopping = false;
/*     */ 
/*     */   
/*  54 */   protected static final StringManager sm = StringManager.getManager(ThreadLocalLeakPreventionListener.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/*     */     try {
/*  63 */       super.lifecycleEvent(event);
/*     */       
/*  65 */       Lifecycle lifecycle = event.getLifecycle();
/*  66 */       if ("before_stop".equals(event.getType()) && lifecycle instanceof org.apache.catalina.Server)
/*     */       {
/*     */         
/*  69 */         this.serverStopping = true;
/*     */       }
/*     */       
/*  72 */       if ("after_stop".equals(event.getType()) && lifecycle instanceof Context) {
/*  73 */         stopIdleThreads((Context)lifecycle);
/*     */       }
/*  75 */     } catch (Exception e) {
/*  76 */       log.error(sm.getString("threadLocalLeakPreventionListener.lifecycleEvent.error", new Object[] { event }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void containerEvent(ContainerEvent event) {
/*     */     try {
/*  83 */       super.containerEvent(event);
/*  84 */     } catch (Exception e) {
/*  85 */       log.error(sm.getString("threadLocalLeakPreventionListener.containerEvent.error", new Object[] { event }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void stopIdleThreads(Context context) {
/*  96 */     if (this.serverStopping) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     if (!(context instanceof StandardContext) || 
/* 101 */       !((StandardContext)context).getRenewThreadsWhenStoppingContext()) {
/* 102 */       if (log.isTraceEnabled()) {
/* 103 */         log.trace("Not renewing threads when the context is stopping. It is not configured to do it.");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 108 */     Engine engine = (Engine)context.getParent().getParent();
/* 109 */     Service service = engine.getService();
/* 110 */     Connector[] connectors = service.findConnectors();
/* 111 */     if (connectors != null) {
/* 112 */       for (Connector connector : connectors) {
/* 113 */         ProtocolHandler handler = connector.getProtocolHandler();
/* 114 */         Executor executor = null;
/* 115 */         if (handler != null) {
/* 116 */           executor = handler.getExecutor();
/*     */         }
/*     */         
/* 119 */         if (executor instanceof ThreadPoolExecutor) {
/* 120 */           ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor)executor;
/* 121 */           threadPoolExecutor.contextStopping();
/* 122 */         } else if (executor instanceof StandardThreadExecutor) {
/* 123 */           StandardThreadExecutor stdThreadExecutor = (StandardThreadExecutor)executor;
/* 124 */           stdThreadExecutor.contextStopping();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LifecycleListener createLifecycleListener(Context context) {
/* 133 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ThreadLocalLeakPreventionListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */