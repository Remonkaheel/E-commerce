/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.util.FilterUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterFactory
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(ApplicationFilterFactory.class);
/*  38 */   private static final StringManager sm = StringManager.getManager(ApplicationFilterFactory.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ApplicationFilterChain createFilterChain(ServletRequest request, Wrapper wrapper, Servlet servlet) {
/*     */     ApplicationFilterChain filterChain;
/*  57 */     if (servlet == null) {
/*  58 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  63 */     if (request instanceof Request) {
/*  64 */       Request req = (Request)request;
/*  65 */       if (Globals.IS_SECURITY_ENABLED) {
/*     */         
/*  67 */         filterChain = new ApplicationFilterChain();
/*     */       } else {
/*  69 */         filterChain = (ApplicationFilterChain)req.getFilterChain();
/*  70 */         if (filterChain == null) {
/*  71 */           filterChain = new ApplicationFilterChain();
/*  72 */           req.setFilterChain(filterChain);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/*  77 */       filterChain = new ApplicationFilterChain();
/*     */     } 
/*     */     
/*  80 */     filterChain.setServlet(servlet);
/*  81 */     filterChain.setServletSupportsAsync(wrapper.isAsyncSupported());
/*     */ 
/*     */     
/*  84 */     StandardContext context = (StandardContext)wrapper.getParent();
/*  85 */     filterChain.setDispatcherWrapsSameObject(context.getDispatcherWrapsSameObject());
/*  86 */     FilterMap[] filterMaps = context.findFilterMaps();
/*     */ 
/*     */     
/*  89 */     if (filterMaps == null || filterMaps.length == 0) {
/*  90 */       return filterChain;
/*     */     }
/*     */ 
/*     */     
/*  94 */     DispatcherType dispatcher = (DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE");
/*     */     
/*  96 */     String requestPath = FilterUtil.getRequestPath(request);
/*     */     
/*  98 */     String servletName = wrapper.getName();
/*     */ 
/*     */     
/* 101 */     for (FilterMap filterMap : filterMaps) {
/* 102 */       if (matchDispatcher(filterMap, dispatcher))
/*     */       {
/*     */         
/* 105 */         if (FilterUtil.matchFiltersURL(filterMap, requestPath)) {
/*     */ 
/*     */ 
/*     */           
/* 109 */           ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)context.findFilterConfig(filterMap.getFilterName());
/* 110 */           if (filterConfig == null) {
/* 111 */             log.warn(sm.getString("applicationFilterFactory.noFilterConfig", new Object[] { filterMap.getFilterName() }));
/*     */           } else {
/*     */             
/* 114 */             filterChain.addFilter(filterConfig);
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 118 */     for (FilterMap filterMap : filterMaps) {
/* 119 */       if (matchDispatcher(filterMap, dispatcher))
/*     */       {
/*     */         
/* 122 */         if (matchFiltersServlet(filterMap, servletName)) {
/*     */ 
/*     */ 
/*     */           
/* 126 */           ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)context.findFilterConfig(filterMap.getFilterName());
/* 127 */           if (filterConfig == null) {
/* 128 */             log.warn(sm.getString("applicationFilterFactory.noFilterConfig", new Object[] { filterMap.getFilterName() }));
/*     */           } else {
/*     */             
/* 131 */             filterChain.addFilter(filterConfig);
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 135 */     return filterChain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchFiltersServlet(FilterMap filterMap, String servletName) {
/* 151 */     if (servletName == null) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     if (filterMap.getMatchAllServletNames()) {
/* 156 */       return true;
/*     */     }
/* 158 */     String[] servletNames = filterMap.getServletNames();
/* 159 */     for (String name : servletNames) {
/* 160 */       if (servletName.equals(name)) {
/* 161 */         return true;
/*     */       }
/*     */     } 
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchDispatcher(FilterMap filterMap, DispatcherType type) {
/* 175 */     switch (type) {
/*     */       case FORWARD:
/* 177 */         if ((filterMap.getDispatcherMapping() & 0x2) != 0) {
/* 178 */           return true;
/*     */         }
/*     */         break;
/*     */       case INCLUDE:
/* 182 */         if ((filterMap.getDispatcherMapping() & 0x4) != 0) {
/* 183 */           return true;
/*     */         }
/*     */         break;
/*     */       case REQUEST:
/* 187 */         if ((filterMap.getDispatcherMapping() & 0x8) != 0) {
/* 188 */           return true;
/*     */         }
/*     */         break;
/*     */       case ERROR:
/* 192 */         if ((filterMap.getDispatcherMapping() & 0x1) != 0) {
/* 193 */           return true;
/*     */         }
/*     */         break;
/*     */       case ASYNC:
/* 197 */         if ((filterMap.getDispatcherMapping() & 0x10) != 0) {
/* 198 */           return true;
/*     */         }
/*     */         break;
/*     */     } 
/* 202 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationFilterFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */