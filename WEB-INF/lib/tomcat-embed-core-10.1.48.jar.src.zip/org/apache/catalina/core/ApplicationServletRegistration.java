/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.MultipartConfigElement;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import jakarta.servlet.ServletSecurityElement;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationServletRegistration
/*     */   implements ServletRegistration.Dynamic
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(ApplicationServletRegistration.class);
/*     */   
/*     */   private final Wrapper wrapper;
/*     */   private final Context context;
/*     */   private ServletSecurityElement constraint;
/*     */   
/*     */   public ApplicationServletRegistration(Wrapper wrapper, Context context) {
/*  49 */     this.wrapper = wrapper;
/*  50 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  56 */     return this.wrapper.getServletClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInitParameter(String name) {
/*  61 */     return this.wrapper.findInitParameter(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getInitParameters() {
/*  66 */     ParameterMap<String, String> result = new ParameterMap();
/*     */     
/*  68 */     String[] parameterNames = this.wrapper.findInitParameters();
/*     */     
/*  70 */     for (String parameterName : parameterNames) {
/*  71 */       result.put(parameterName, this.wrapper.findInitParameter(parameterName));
/*     */     }
/*     */     
/*  74 */     result.setLocked(true);
/*  75 */     return (Map<String, String>)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  80 */     return this.wrapper.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setInitParameter(String name, String value) {
/*  85 */     if (name == null || value == null) {
/*  86 */       throw new IllegalArgumentException(sm
/*  87 */           .getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/*  89 */     if (getInitParameter(name) != null) {
/*  90 */       return false;
/*     */     }
/*     */     
/*  93 */     this.wrapper.addInitParameter(name, value);
/*     */     
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters) {
/* 101 */     Set<String> conflicts = new HashSet<>();
/*     */     
/* 103 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 104 */       if (entry.getKey() == null || entry.getValue() == null) {
/* 105 */         throw new IllegalArgumentException(sm
/* 106 */             .getString("applicationFilterRegistration.nullInitParams", new Object[] { entry.getKey(), entry.getValue() }));
/*     */       }
/* 108 */       if (getInitParameter(entry.getKey()) != null) {
/* 109 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (conflicts.isEmpty()) {
/* 116 */       for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 117 */         setInitParameter(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*     */     
/* 121 */     return conflicts;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported) {
/* 126 */     this.wrapper.setAsyncSupported(asyncSupported);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLoadOnStartup(int loadOnStartup) {
/* 131 */     this.wrapper.setLoadOnStartup(loadOnStartup);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMultipartConfig(MultipartConfigElement multipartConfig) {
/* 136 */     this.wrapper.setMultipartConfigElement(multipartConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRunAsRole(String roleName) {
/* 141 */     this.wrapper.setRunAs(roleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> setServletSecurity(ServletSecurityElement constraint) {
/* 146 */     if (constraint == null) {
/* 147 */       throw new IllegalArgumentException(sm.getString("applicationServletRegistration.setServletSecurity.iae", new Object[] {
/* 148 */               getName(), this.context.getName()
/*     */             }));
/*     */     }
/* 151 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 152 */       throw new IllegalStateException(sm.getString("applicationServletRegistration.setServletSecurity.ise", new Object[] {
/* 153 */               getName(), this.context.getName()
/*     */             }));
/*     */     }
/* 156 */     this.constraint = constraint;
/* 157 */     return this.context.addServletSecurity(this, constraint);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> addMapping(String... urlPatterns) {
/* 163 */     if (urlPatterns == null) {
/* 164 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 167 */     Set<String> conflicts = new HashSet<>();
/*     */     
/* 169 */     for (String urlPattern : urlPatterns) {
/* 170 */       String wrapperName = this.context.findServletMapping(urlPattern);
/* 171 */       if (wrapperName != null) {
/* 172 */         Wrapper wrapper = (Wrapper)this.context.findChild(wrapperName);
/* 173 */         if (wrapper.isOverridable()) {
/*     */ 
/*     */           
/* 176 */           this.context.removeServletMapping(urlPattern);
/*     */         } else {
/* 178 */           conflicts.add(urlPattern);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     if (!conflicts.isEmpty()) {
/* 184 */       return conflicts;
/*     */     }
/*     */     
/* 187 */     for (String urlPattern : urlPatterns) {
/* 188 */       this.context.addServletMappingDecoded(UDecoder.URLDecode(urlPattern, StandardCharsets.UTF_8), this.wrapper.getName());
/*     */     }
/*     */     
/* 191 */     if (this.constraint != null) {
/* 192 */       this.context.addServletSecurity(this, this.constraint);
/*     */     }
/*     */     
/* 195 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getMappings() {
/* 201 */     Set<String> result = new HashSet<>();
/* 202 */     String servletName = this.wrapper.getName();
/*     */     
/* 204 */     String[] urlPatterns = this.context.findServletMappings();
/* 205 */     for (String urlPattern : urlPatterns) {
/* 206 */       String name = this.context.findServletMapping(urlPattern);
/* 207 */       if (name.equals(servletName)) {
/* 208 */         result.add(urlPattern);
/*     */       }
/*     */     } 
/* 211 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRunAsRole() {
/* 216 */     return this.wrapper.getRunAs();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationServletRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */