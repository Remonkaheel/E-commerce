/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterChain
/*     */   implements FilterChain
/*     */ {
/*  47 */   private static final ThreadLocal<ServletRequest> lastServicedRequest = new ThreadLocal<>();
/*  48 */   private static final ThreadLocal<ServletResponse> lastServicedResponse = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int INCREMENT = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private ApplicationFilterConfig[] filters = new ApplicationFilterConfig[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private int pos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private int n = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private Servlet servlet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean servletSupportsAsync = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dispatcherWrapsSameObject = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private static final StringManager sm = StringManager.getManager(ApplicationFilterChain.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final Class<?>[] classType = new Class[] { ServletRequest.class, ServletResponse.class, FilterChain.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private static final Class<?>[] classTypeUsedInService = new Class[] { ServletRequest.class, ServletResponse.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
/* 117 */     if (Globals.IS_SECURITY_ENABLED) {
/* 118 */       ServletRequest req = request;
/* 119 */       ServletResponse res = response;
/*     */       try {
/* 121 */         AccessController.doPrivileged(() -> {
/*     */               internalDoFilter(req, res);
/*     */               return null;
/*     */             });
/* 125 */       } catch (PrivilegedActionException pe) {
/* 126 */         Exception e = pe.getException();
/* 127 */         if (e instanceof ServletException)
/* 128 */           throw (ServletException)e; 
/* 129 */         if (e instanceof IOException)
/* 130 */           throw (IOException)e; 
/* 131 */         if (e instanceof RuntimeException) {
/* 132 */           throw (RuntimeException)e;
/*     */         }
/* 134 */         throw new ServletException(e.getMessage(), e);
/*     */       } 
/*     */     } else {
/*     */       
/* 138 */       internalDoFilter(request, response);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalDoFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
/* 146 */     if (this.pos < this.n) {
/* 147 */       ApplicationFilterConfig filterConfig = this.filters[this.pos++];
/*     */       try {
/* 149 */         Filter filter = filterConfig.getFilter();
/*     */         
/* 151 */         if (request.isAsyncSupported() && !filterConfig.getFilterDef().getAsyncSupportedBoolean()) {
/* 152 */           request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", Boolean.FALSE);
/*     */         }
/* 154 */         if (Globals.IS_SECURITY_ENABLED) {
/* 155 */           ServletRequest req = request;
/* 156 */           ServletResponse res = response;
/* 157 */           Principal principal = ((HttpServletRequest)req).getUserPrincipal();
/*     */           
/* 159 */           Object[] args = { req, res, this };
/* 160 */           SecurityUtil.doAsPrivilege("doFilter", filter, classType, args, principal);
/*     */         } else {
/* 162 */           filter.doFilter(request, response, this);
/*     */         } 
/* 164 */       } catch (IOException|ServletException|RuntimeException e) {
/* 165 */         throw e;
/* 166 */       } catch (Throwable t) {
/* 167 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 168 */         ExceptionUtils.handleThrowable(t);
/* 169 */         throw new ServletException(sm.getString("filterChain.filter"), t);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 176 */       if (this.dispatcherWrapsSameObject) {
/* 177 */         lastServicedRequest.set(request);
/* 178 */         lastServicedResponse.set(response);
/*     */       } 
/*     */       
/* 181 */       if (request.isAsyncSupported() && !this.servletSupportsAsync) {
/* 182 */         request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", Boolean.FALSE);
/*     */       }
/*     */       
/* 185 */       if (request instanceof HttpServletRequest && response instanceof jakarta.servlet.http.HttpServletResponse && Globals.IS_SECURITY_ENABLED) {
/*     */         
/* 187 */         ServletRequest req = request;
/* 188 */         ServletResponse res = response;
/* 189 */         Principal principal = ((HttpServletRequest)req).getUserPrincipal();
/* 190 */         Object[] args = { req, res };
/* 191 */         SecurityUtil.doAsPrivilege("service", this.servlet, classTypeUsedInService, args, principal);
/*     */       } else {
/* 193 */         this.servlet.service(request, response);
/*     */       } 
/* 195 */     } catch (IOException|ServletException|RuntimeException e) {
/* 196 */       throw e;
/* 197 */     } catch (Throwable t) {
/* 198 */       t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 199 */       ExceptionUtils.handleThrowable(t);
/* 200 */       throw new ServletException(sm.getString("filterChain.servlet"), t);
/*     */     } finally {
/* 202 */       if (this.dispatcherWrapsSameObject) {
/* 203 */         lastServicedRequest.set(null);
/* 204 */         lastServicedResponse.set(null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServletRequest getLastServicedRequest() {
/* 216 */     return lastServicedRequest.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServletResponse getLastServicedResponse() {
/* 226 */     return lastServicedResponse.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addFilter(ApplicationFilterConfig filterConfig) {
/* 240 */     for (int i = 0; i < this.n; i++) {
/* 241 */       if (this.filters[i] == filterConfig) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 246 */     if (this.n == this.filters.length) {
/* 247 */       this.filters = Arrays.<ApplicationFilterConfig>copyOf(this.filters, this.n + 10);
/*     */     }
/* 249 */     this.filters[this.n++] = filterConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void release() {
/* 258 */     for (int i = 0; i < this.n; i++) {
/* 259 */       this.filters[i] = null;
/*     */     }
/* 261 */     this.n = 0;
/* 262 */     this.pos = 0;
/* 263 */     this.servlet = null;
/* 264 */     this.servletSupportsAsync = false;
/* 265 */     this.dispatcherWrapsSameObject = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reuse() {
/* 273 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setServlet(Servlet servlet) {
/* 283 */     this.servlet = servlet;
/*     */   }
/*     */ 
/*     */   
/*     */   void setServletSupportsAsync(boolean servletSupportsAsync) {
/* 288 */     this.servletSupportsAsync = servletSupportsAsync;
/*     */   }
/*     */ 
/*     */   
/*     */   void setDispatcherWrapsSameObject(boolean dispatcherWrapsSameObject) {
/* 293 */     this.dispatcherWrapsSameObject = dispatcherWrapsSameObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findNonAsyncFilters(Set<String> result) {
/* 304 */     for (int i = 0; i < this.n; i++) {
/* 305 */       ApplicationFilterConfig filter = this.filters[i];
/* 306 */       if (!filter.getFilterDef().getAsyncSupportedBoolean())
/* 307 */         result.add(filter.getFilterClass()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationFilterChain.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */