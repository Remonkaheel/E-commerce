/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import org.apache.catalina.LifecycleEvent;
/*    */ import org.apache.catalina.LifecycleListener;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JniLifecycleListener
/*    */   implements LifecycleListener
/*    */ {
/* 38 */   private static final Log log = LogFactory.getLog(JniLifecycleListener.class);
/* 39 */   protected static final StringManager sm = StringManager.getManager(JniLifecycleListener.class);
/*    */   
/* 41 */   private String libraryName = "";
/* 42 */   private String libraryPath = "";
/*    */ 
/*    */ 
/*    */   
/*    */   public void lifecycleEvent(LifecycleEvent event) {
/* 47 */     if ("before_start".equals(event.getType()))
/*    */     {
/* 49 */       if (!this.libraryName.isEmpty()) {
/* 50 */         System.loadLibrary(this.libraryName);
/* 51 */         log.info(sm.getString("jniLifecycleListener.load.name", new Object[] { this.libraryName }));
/* 52 */       } else if (!this.libraryPath.isEmpty()) {
/* 53 */         System.load(this.libraryPath);
/* 54 */         log.info(sm.getString("jniLifecycleListener.load.path", new Object[] { this.libraryPath }));
/*    */       } else {
/* 56 */         throw new IllegalArgumentException(sm.getString("jniLifecycleListener.missingPathOrName"));
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLibraryName(String libraryName) {
/* 63 */     if (!this.libraryPath.isEmpty()) {
/* 64 */       throw new IllegalArgumentException(sm.getString("jniLifecycleListener.bothPathAndName"));
/*    */     }
/*    */     
/* 67 */     this.libraryName = libraryName;
/*    */   }
/*    */   
/*    */   public String getLibraryName() {
/* 71 */     return this.libraryName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLibraryPath(String libraryPath) {
/* 76 */     if (!this.libraryName.isEmpty()) {
/* 77 */       throw new IllegalArgumentException(sm.getString("jniLifecycleListener.bothPathAndName"));
/*    */     }
/*    */     
/* 80 */     this.libraryPath = libraryPath;
/*    */   }
/*    */   
/*    */   public String getLibraryPath() {
/* 84 */     return this.libraryPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\JniLifecycleListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */