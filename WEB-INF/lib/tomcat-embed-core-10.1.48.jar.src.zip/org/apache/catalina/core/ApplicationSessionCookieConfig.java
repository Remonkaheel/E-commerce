/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.SessionCookieConfig;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.util.SessionConfig;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationSessionCookieConfig
/*     */   implements SessionCookieConfig
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(ApplicationSessionCookieConfig.class);
/*     */   
/*     */   private static final int DEFAULT_MAX_AGE = -1;
/*     */   
/*     */   private static final boolean DEFAULT_HTTP_ONLY = false;
/*     */   private static final boolean DEFAULT_SECURE = false;
/*  43 */   private final Map<String, String> attributes = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */   
/*     */   private String name;
/*     */   private final StandardContext context;
/*     */   
/*     */   public ApplicationSessionCookieConfig(StandardContext context) {
/*  49 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComment() {
/*  54 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDomain() {
/*  59 */     return getAttribute("Domain");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxAge() {
/*  64 */     String maxAge = getAttribute("Max-Age");
/*  65 */     if (maxAge == null) {
/*  66 */       return -1;
/*     */     }
/*  68 */     return Integer.parseInt(maxAge);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  73 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/*  78 */     return getAttribute("Path");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHttpOnly() {
/*  83 */     String httpOnly = getAttribute("HttpOnly");
/*  84 */     if (httpOnly == null) {
/*  85 */       return false;
/*     */     }
/*  87 */     return Boolean.parseBoolean(httpOnly);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSecure() {
/*  92 */     String secure = getAttribute("Secure");
/*  93 */     if (secure == null) {
/*  94 */       return false;
/*     */     }
/*  96 */     return Boolean.parseBoolean(secure);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComment(String comment) {
/* 101 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 102 */       throw new IllegalStateException(sm
/* 103 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "comment", this.context.getPath() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDomain(String domain) {
/* 109 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 110 */       throw new IllegalStateException(sm
/* 111 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "domain name", this.context.getPath() }));
/*     */     }
/* 113 */     setAttribute("Domain", domain);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHttpOnly(boolean httpOnly) {
/* 118 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 119 */       throw new IllegalStateException(sm
/* 120 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "HttpOnly", this.context.getPath() }));
/*     */     }
/* 122 */     setAttribute("HttpOnly", Boolean.toString(httpOnly));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxAge(int maxAge) {
/* 127 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 128 */       throw new IllegalStateException(sm
/* 129 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "max age", this.context.getPath() }));
/*     */     }
/* 131 */     setAttribute("Max-Age", Integer.toString(maxAge));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 136 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 137 */       throw new IllegalStateException(sm
/* 138 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "name", this.context.getPath() }));
/*     */     }
/* 140 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPath(String path) {
/* 145 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 146 */       throw new IllegalStateException(sm
/* 147 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "path", this.context.getPath() }));
/*     */     }
/* 149 */     setAttribute("Path", path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSecure(boolean secure) {
/* 154 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 155 */       throw new IllegalStateException(sm
/* 156 */           .getString("applicationSessionCookieConfig.ise", new Object[] { "secure", this.context.getPath() }));
/*     */     }
/* 158 */     setAttribute("Secure", Boolean.toString(secure));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, String value) {
/* 164 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 165 */       throw new IllegalStateException(sm
/* 166 */           .getString("applicationSessionCookieConfig.ise", new Object[] { name, this.context.getPath() }));
/*     */     }
/* 168 */     this.attributes.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(String name) {
/* 173 */     return this.attributes.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getAttributes() {
/* 179 */     return Collections.unmodifiableMap(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cookie createSessionCookie(Context context, String sessionId, boolean secure) {
/* 193 */     SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     Cookie cookie = new Cookie(SessionConfig.getSessionCookieName(context), sessionId);
/*     */ 
/*     */     
/* 203 */     cookie.setMaxAge(scc.getMaxAge());
/*     */     
/* 205 */     if (context.getSessionCookieDomain() == null) {
/*     */       
/* 207 */       if (scc.getDomain() != null) {
/* 208 */         cookie.setDomain(scc.getDomain());
/*     */       }
/*     */     } else {
/* 211 */       cookie.setDomain(context.getSessionCookieDomain());
/*     */     } 
/*     */ 
/*     */     
/* 215 */     if (scc.isSecure() || secure) {
/* 216 */       cookie.setSecure(true);
/*     */     }
/*     */ 
/*     */     
/* 220 */     if (scc.isHttpOnly() || context.getUseHttpOnly()) {
/* 221 */       cookie.setHttpOnly(true);
/*     */     }
/*     */     
/* 224 */     cookie.setAttribute("Partitioned", Boolean.toString(context.getUsePartitioned()));
/*     */     
/* 226 */     cookie.setPath(SessionConfig.getSessionCookiePath(context));
/*     */ 
/*     */     
/* 229 */     for (Map.Entry<String, String> attribute : (Iterable<Map.Entry<String, String>>)scc.getAttributes().entrySet()) {
/* 230 */       switch ((String)attribute.getKey()) {
/*     */         case "Comment":
/*     */         case "Domain":
/*     */         case "Max-Age":
/*     */         case "Path":
/*     */         case "Secure":
/*     */         case "HttpOnly":
/*     */           continue;
/*     */       } 
/*     */       
/* 240 */       cookie.setAttribute(attribute.getKey(), attribute.getValue());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 245 */     return cookie;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationSessionCookieConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */