/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncEvent;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.catalina.AsyncDispatcher;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.AsyncContextCallback;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.coyote.RequestInfo;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncContextImpl
/*     */   implements AsyncContext, AsyncContextCallback
/*     */ {
/*  55 */   private static final Log log = LogFactory.getLog(AsyncContextImpl.class);
/*     */   
/*  57 */   protected static final StringManager sm = StringManager.getManager(AsyncContextImpl.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private final Object asyncContextLock = new Object();
/*     */   
/*  67 */   private volatile ServletRequest servletRequest = null;
/*  68 */   private volatile ServletResponse servletResponse = null;
/*  69 */   private final List<AsyncListenerWrapper> listeners = new ArrayList<>();
/*     */   private boolean hasOriginalRequestAndResponse = true;
/*  71 */   private volatile Runnable dispatch = null;
/*  72 */   private Context context = null;
/*     */   
/*  74 */   private long timeout = -1L;
/*  75 */   private AsyncEvent event = null;
/*     */   private volatile Request request;
/*  77 */   private final AtomicBoolean hasErrorProcessingStarted = new AtomicBoolean(false);
/*  78 */   private final AtomicBoolean hasOnErrorReturned = new AtomicBoolean(false);
/*     */   
/*     */   public AsyncContextImpl(Request request) {
/*  81 */     this.request = request;
/*  82 */     if (log.isTraceEnabled()) {
/*  83 */       logDebug("Constructor");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void complete() {
/*  89 */     if (log.isTraceEnabled()) {
/*  90 */       logDebug("complete   ");
/*     */     }
/*  92 */     check();
/*  93 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_COMPLETE, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fireOnComplete() {
/*  98 */     if (log.isTraceEnabled()) {
/*  99 */       log.trace(sm.getString("asyncContextImpl.fireOnComplete"));
/*     */     }
/* 101 */     List<AsyncListenerWrapper> listenersCopy = new ArrayList<>(this.listeners);
/*     */     
/* 103 */     ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */     try {
/* 105 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 107 */           listener.fireOnComplete(this.event);
/* 108 */         } catch (Throwable t) {
/* 109 */           ExceptionUtils.handleThrowable(t);
/* 110 */           log.warn(sm.getString("asyncContextImpl.onCompleteError", new Object[] { listener.getClass().getName() }), t);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 114 */       this.context.fireRequestDestroyEvent((ServletRequest)this.request.getRequest());
/* 115 */       clearServletRequestResponse();
/* 116 */       this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean timeout() {
/* 122 */     AtomicBoolean result = new AtomicBoolean();
/* 123 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_TIMEOUT, result);
/*     */     
/* 125 */     Context context = this.context;
/*     */     
/* 127 */     if (result.get()) {
/* 128 */       if (log.isTraceEnabled()) {
/* 129 */         log.trace(sm.getString("asyncContextImpl.fireOnTimeout"));
/*     */       }
/* 131 */       ClassLoader oldCL = context.bind(false, null);
/*     */       try {
/* 133 */         List<AsyncListenerWrapper> listenersCopy = new ArrayList<>(this.listeners);
/* 134 */         for (AsyncListenerWrapper listener : listenersCopy) {
/*     */           try {
/* 136 */             listener.fireOnTimeout(this.event);
/* 137 */           } catch (Throwable t) {
/* 138 */             ExceptionUtils.handleThrowable(t);
/* 139 */             log.warn(sm.getString("asyncContextImpl.onTimeoutError", new Object[] { listener.getClass().getName() }), t);
/*     */           } 
/*     */         } 
/* 142 */         this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_TIMINGOUT, result);
/*     */       } finally {
/* 144 */         context.unbind(false, oldCL);
/*     */       } 
/*     */     } 
/* 147 */     return !result.get();
/*     */   }
/*     */   
/*     */   public void dispatch() {
/*     */     String path, cpath;
/* 152 */     check();
/*     */ 
/*     */     
/* 155 */     ServletRequest servletRequest = getRequest();
/* 156 */     if (servletRequest instanceof HttpServletRequest) {
/* 157 */       HttpServletRequest sr = (HttpServletRequest)servletRequest;
/* 158 */       path = sr.getRequestURI();
/* 159 */       cpath = sr.getContextPath();
/*     */     } else {
/* 161 */       path = this.request.getRequestURI();
/* 162 */       cpath = this.request.getContextPath();
/*     */     } 
/* 164 */     if (cpath.length() > 1) {
/* 165 */       path = path.substring(cpath.length());
/*     */     }
/* 167 */     if (!this.context.getDispatchersUseEncodedPaths()) {
/* 168 */       path = UDecoder.URLDecode(path, StandardCharsets.UTF_8);
/*     */     }
/* 170 */     dispatch(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatch(String path) {
/* 175 */     check();
/* 176 */     dispatch(getRequest().getServletContext(), path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatch(ServletContext servletContext, String path) {
/* 181 */     synchronized (this.asyncContextLock) {
/* 182 */       if (log.isTraceEnabled()) {
/* 183 */         logDebug("dispatch   ");
/*     */       }
/* 185 */       check();
/* 186 */       if (this.dispatch != null) {
/* 187 */         throw new IllegalStateException(sm.getString("asyncContextImpl.dispatchingStarted"));
/*     */       }
/* 189 */       if (this.request.getAttribute("jakarta.servlet.async.request_uri") == null) {
/* 190 */         this.request.setAttribute("jakarta.servlet.async.request_uri", this.request.getRequestURI());
/* 191 */         this.request.setAttribute("jakarta.servlet.async.context_path", this.request.getContextPath());
/* 192 */         this.request.setAttribute("jakarta.servlet.async.servlet_path", this.request.getServletPath());
/* 193 */         this.request.setAttribute("jakarta.servlet.async.path_info", this.request.getPathInfo());
/* 194 */         this.request.setAttribute("jakarta.servlet.async.query_string", this.request.getQueryString());
/*     */       } 
/* 196 */       RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
/* 197 */       if (!(requestDispatcher instanceof AsyncDispatcher)) {
/* 198 */         throw new UnsupportedOperationException(sm.getString("asyncContextImpl.noAsyncDispatcher"));
/*     */       }
/* 200 */       AsyncDispatcher applicationDispatcher = (AsyncDispatcher)requestDispatcher;
/* 201 */       ServletRequest servletRequest = getRequest();
/* 202 */       ServletResponse servletResponse = getResponse();
/* 203 */       this.dispatch = new AsyncRunnable(this.request, applicationDispatcher, servletRequest, servletResponse);
/* 204 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCH, null);
/* 205 */       clearServletRequestResponse();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ServletRequest getRequest() {
/* 211 */     check();
/* 212 */     if (this.servletRequest == null) {
/* 213 */       throw new IllegalStateException(sm.getString("asyncContextImpl.request.ise"));
/*     */     }
/* 215 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServletResponse getResponse() {
/* 220 */     check();
/* 221 */     if (this.servletResponse == null) {
/* 222 */       throw new IllegalStateException(sm.getString("asyncContextImpl.response.ise"));
/*     */     }
/* 224 */     return this.servletResponse;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(Runnable run) {
/* 229 */     if (log.isTraceEnabled()) {
/* 230 */       logDebug("start      ");
/*     */     }
/* 232 */     check();
/* 233 */     Runnable wrapper = new RunnableWrapper(run, this.context, this.request.getCoyoteRequest());
/* 234 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_RUN, wrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(AsyncListener listener) {
/* 239 */     check();
/* 240 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 241 */     wrapper.setListener(listener);
/* 242 */     this.listeners.add(wrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(AsyncListener listener, ServletRequest servletRequest, ServletResponse servletResponse) {
/* 247 */     check();
/* 248 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 249 */     wrapper.setListener(listener);
/* 250 */     wrapper.setServletRequest(servletRequest);
/* 251 */     wrapper.setServletResponse(servletResponse);
/* 252 */     this.listeners.add(wrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends AsyncListener> T createListener(Class<T> clazz) throws ServletException {
/*     */     AsyncListener asyncListener;
/* 258 */     check();
/*     */     
/*     */     try {
/* 261 */       asyncListener = (AsyncListener)this.context.getInstanceManager().newInstance(clazz.getName(), clazz.getClassLoader());
/* 262 */     } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 263 */       throw new ServletException(e);
/* 264 */     } catch (Exception e) {
/* 265 */       ExceptionUtils.handleThrowable(e.getCause());
/* 266 */       throw new ServletException(e);
/*     */     } 
/* 268 */     return (T)asyncListener;
/*     */   }
/*     */   
/*     */   public void recycle() {
/* 272 */     if (log.isTraceEnabled()) {
/* 273 */       logDebug("recycle    ");
/*     */     }
/* 275 */     this.context = null;
/* 276 */     this.dispatch = null;
/* 277 */     this.event = null;
/* 278 */     this.hasOriginalRequestAndResponse = true;
/* 279 */     this.listeners.clear();
/* 280 */     this.request = null;
/* 281 */     clearServletRequestResponse();
/* 282 */     this.timeout = -1L;
/* 283 */     this.hasErrorProcessingStarted.set(false);
/* 284 */     this.hasOnErrorReturned.set(false);
/*     */   }
/*     */   
/*     */   private void clearServletRequestResponse() {
/* 288 */     this.servletRequest = null;
/* 289 */     this.servletResponse = null;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 293 */     AtomicBoolean result = new AtomicBoolean(false);
/* 294 */     Request request = this.request;
/* 295 */     check();
/* 296 */     request.getCoyoteRequest().action(ActionCode.ASYNC_IS_STARTED, result);
/* 297 */     return result.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStarted(Context context, ServletRequest request, ServletResponse response, boolean originalRequestResponse) {
/* 303 */     synchronized (this.asyncContextLock) {
/* 304 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_START, this);
/*     */       
/* 306 */       this.context = context;
/* 307 */       context.incrementInProgressAsyncCount();
/* 308 */       this.servletRequest = request;
/* 309 */       this.servletResponse = response;
/* 310 */       this.hasOriginalRequestAndResponse = originalRequestResponse;
/* 311 */       this.event = new AsyncEvent(this, request, response);
/*     */       
/* 313 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList<>(this.listeners);
/* 314 */       this.listeners.clear();
/* 315 */       if (log.isTraceEnabled()) {
/* 316 */         log.trace(sm.getString("asyncContextImpl.fireOnStartAsync"));
/*     */       }
/* 318 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 320 */           listener.fireOnStartAsync(this.event);
/* 321 */         } catch (Throwable t) {
/* 322 */           ExceptionUtils.handleThrowable(t);
/* 323 */           log.warn(sm.getString("asyncContextImpl.onStartAsyncError", new Object[] { listener.getClass().getName() }), t);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasOriginalRequestAndResponse() {
/* 331 */     check();
/* 332 */     return this.hasOriginalRequestAndResponse;
/*     */   }
/*     */   
/*     */   protected void doInternalDispatch() throws ServletException, IOException {
/* 336 */     if (log.isTraceEnabled()) {
/* 337 */       logDebug("intDispatch");
/*     */     }
/*     */     try {
/* 340 */       Runnable runnable = this.dispatch;
/* 341 */       this.dispatch = null;
/* 342 */       runnable.run();
/* 343 */       if (!this.request.isAsync()) {
/* 344 */         fireOnComplete();
/*     */       }
/* 346 */     } catch (RuntimeException x) {
/* 347 */       AtomicBoolean result = new AtomicBoolean();
/* 348 */       this.request.getCoyoteRequest().action(ActionCode.IS_IO_ALLOWED, result);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 355 */       if (!result.get()) {
/* 356 */         fireOnComplete();
/*     */       }
/* 358 */       if (x.getCause() instanceof ServletException) {
/* 359 */         throw (ServletException)x.getCause();
/*     */       }
/* 361 */       if (x.getCause() instanceof IOException) {
/* 362 */         throw (IOException)x.getCause();
/*     */       }
/* 364 */       throw new ServletException(x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTimeout() {
/* 371 */     check();
/* 372 */     return this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(long timeout) {
/* 378 */     check();
/* 379 */     this.timeout = timeout;
/* 380 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_SETTIMEOUT, Long.valueOf(timeout));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAvailable() {
/* 386 */     Context context = this.context;
/* 387 */     if (context == null) {
/* 388 */       return false;
/*     */     }
/* 390 */     return context.getState().isAvailable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorState(Throwable t, boolean fireOnError) {
/* 395 */     if (!this.hasErrorProcessingStarted.compareAndSet(false, true)) {
/*     */       return;
/*     */     }
/*     */     
/* 399 */     if (t != null) {
/* 400 */       this.request.setAttribute("jakarta.servlet.error.exception", t);
/*     */     }
/* 402 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_ERROR, null);
/*     */     
/* 404 */     if (fireOnError) {
/* 405 */       if (log.isTraceEnabled()) {
/* 406 */         log.trace(sm.getString("asyncContextImpl.fireOnError"));
/*     */       }
/*     */       
/* 409 */       AsyncEvent errorEvent = new AsyncEvent(this.event.getAsyncContext(), this.event.getSuppliedRequest(), this.event.getSuppliedResponse(), t);
/* 410 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList<>(this.listeners);
/* 411 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 413 */           listener.fireOnError(errorEvent);
/* 414 */         } catch (Throwable t2) {
/* 415 */           ExceptionUtils.handleThrowable(t2);
/* 416 */           log.warn(sm.getString("asyncContextImpl.onErrorError", new Object[] { listener.getClass().getName() }), t2);
/*     */         } finally {
/* 418 */           this.hasOnErrorReturned.set(true);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 424 */     AtomicBoolean result = new AtomicBoolean();
/* 425 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/* 426 */     if (result.get()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 432 */       ServletResponse servletResponse = this.servletResponse;
/* 433 */       if (servletResponse instanceof HttpServletResponse) {
/* 434 */         ((HttpServletResponse)servletResponse).setStatus(500);
/*     */       }
/*     */       
/* 437 */       Host host = (Host)this.context.getParent();
/* 438 */       Valve stdHostValve = host.getPipeline().getBasic();
/* 439 */       if (stdHostValve instanceof StandardHostValve) {
/* 440 */         ((StandardHostValve)stdHostValve).throwable(this.request, this.request.getResponse(), t);
/*     */       }
/*     */       
/* 443 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/* 444 */       if (result.get())
/*     */       {
/*     */         
/* 447 */         complete();
/*     */       }
/* 449 */     } else if (this.request.isAsyncDispatching()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 454 */       this.request.getResponse().resetError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementInProgressAsyncCount() {
/* 461 */     this.context.incrementInProgressAsyncCount();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrementInProgressAsyncCount() {
/* 467 */     this.context.decrementInProgressAsyncCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logDebug(String method) {
/*     */     String rHashCode, crHashCode, rpHashCode, stage;
/* 476 */     StringBuilder uri = new StringBuilder();
/* 477 */     if (this.request == null) {
/* 478 */       rHashCode = "null";
/* 479 */       crHashCode = "null";
/* 480 */       rpHashCode = "null";
/* 481 */       stage = "-";
/* 482 */       uri.append("N/A");
/*     */     } else {
/* 484 */       rHashCode = Integer.toHexString(this.request.hashCode());
/* 485 */       Request coyoteRequest = this.request.getCoyoteRequest();
/* 486 */       if (coyoteRequest == null) {
/* 487 */         crHashCode = "null";
/* 488 */         rpHashCode = "null";
/* 489 */         stage = "-";
/*     */       } else {
/* 491 */         crHashCode = Integer.toHexString(coyoteRequest.hashCode());
/* 492 */         RequestInfo rp = coyoteRequest.getRequestProcessor();
/* 493 */         if (rp == null) {
/* 494 */           rpHashCode = "null";
/* 495 */           stage = "-";
/*     */         } else {
/* 497 */           rpHashCode = Integer.toHexString(rp.hashCode());
/* 498 */           stage = Integer.toString(rp.getStage());
/*     */         } 
/*     */       } 
/* 501 */       uri.append(this.request.getRequestURI());
/* 502 */       if (this.request.getQueryString() != null) {
/* 503 */         uri.append('?');
/* 504 */         uri.append(this.request.getQueryString());
/*     */       } 
/*     */     } 
/* 507 */     String threadName = Thread.currentThread().getName();
/* 508 */     int len = threadName.length();
/* 509 */     if (len > 20) {
/* 510 */       threadName = threadName.substring(len - 20, len);
/*     */     }
/* 512 */     String msg = String.format("Req: %1$8s  CReq: %2$8s  RP: %3$8s  Stage: %4$s  Thread: %5$20s  State: %6$20s  Method: %7$11s  URI: %8$s", new Object[] { rHashCode, crHashCode, rpHashCode, stage, threadName, "N/A", method, uri });
/*     */ 
/*     */ 
/*     */     
/* 516 */     if (log.isTraceEnabled()) {
/* 517 */       log.trace(msg, new DebugException());
/*     */     } else {
/* 519 */       log.debug(msg);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void check() {
/* 524 */     Request request = this.request;
/* 525 */     if (request == null)
/*     */     {
/* 527 */       throw new IllegalStateException(sm.getString("asyncContextImpl.requestEnded"));
/*     */     }
/* 529 */     if (this.hasOnErrorReturned.get() && !request.getCoyoteRequest().isRequestThread())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 535 */       throw new IllegalStateException(sm.getString("asyncContextImpl.afterOnError"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DebugException
/*     */     extends Exception {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */   
/*     */   private static class RunnableWrapper implements Runnable {
/*     */     private final Runnable wrapped;
/*     */     private final Context context;
/*     */     private final Request coyoteRequest;
/*     */     
/*     */     RunnableWrapper(Runnable wrapped, Context ctxt, Request coyoteRequest) {
/* 550 */       this.wrapped = wrapped;
/* 551 */       this.context = ctxt;
/* 552 */       this.coyoteRequest = coyoteRequest;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 558 */       ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       try {
/* 560 */         this.wrapped.run();
/* 561 */       } catch (Throwable t) {
/* 562 */         ExceptionUtils.handleThrowable(t);
/* 563 */         this.context.getLogger().error(AsyncContextImpl.sm.getString("asyncContextImpl.asyncRunnableError"), t);
/* 564 */         this.coyoteRequest.setAttribute("jakarta.servlet.error.exception", t);
/* 565 */         Response coyoteResponse = this.coyoteRequest.getResponse();
/* 566 */         coyoteResponse.setStatus(500);
/* 567 */         coyoteResponse.setError();
/*     */       } finally {
/* 569 */         this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 575 */       this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AsyncRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final AsyncDispatcher applicationDispatcher;
/*     */     private final Request request;
/*     */     private final ServletRequest servletRequest;
/*     */     private final ServletResponse servletResponse;
/*     */     
/*     */     AsyncRunnable(Request request, AsyncDispatcher applicationDispatcher, ServletRequest servletRequest, ServletResponse servletResponse) {
/* 589 */       this.request = request;
/* 590 */       this.applicationDispatcher = applicationDispatcher;
/* 591 */       this.servletRequest = servletRequest;
/* 592 */       this.servletResponse = servletResponse;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 597 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCHED, null);
/*     */       try {
/* 599 */         this.applicationDispatcher.dispatch(this.servletRequest, this.servletResponse);
/* 600 */       } catch (Exception e) {
/* 601 */         throw new RuntimeException(AsyncContextImpl.sm.getString("asyncContextImpl.asyncDispatchError"), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\AsyncContextImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */