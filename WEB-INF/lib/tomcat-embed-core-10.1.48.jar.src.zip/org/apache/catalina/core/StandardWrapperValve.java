/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.UnavailableException;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.coyote.BadRequestException;
/*     */ import org.apache.coyote.CloseNowException;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.log.SystemLogHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardWrapperValve
/*     */   extends ValveBase
/*     */ {
/*  50 */   private static final StringManager sm = StringManager.getManager(StandardWrapperValve.class);
/*     */   
/*     */   private final LongAdder processingTime;
/*     */   private volatile long maxTime;
/*     */   
/*     */   StandardWrapperValve() {
/*  56 */     super(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.processingTime = new LongAdder();
/*     */     
/*  67 */     this.minTime = Long.MAX_VALUE;
/*  68 */     this.requestCount = new AtomicInteger(0);
/*  69 */     this.errorCount = new AtomicInteger(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile long minTime;
/*     */ 
/*     */ 
/*     */   
/*     */   private final AtomicInteger requestCount;
/*     */ 
/*     */   
/*     */   private final AtomicInteger errorCount;
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException {
/*  87 */     boolean unavailable = false;
/*  88 */     Throwable throwable = null;
/*     */     
/*  90 */     long t1 = System.currentTimeMillis();
/*  91 */     this.requestCount.incrementAndGet();
/*  92 */     StandardWrapper wrapper = (StandardWrapper)getContainer();
/*  93 */     Servlet servlet = null;
/*  94 */     Context context = (Context)wrapper.getParent();
/*     */ 
/*     */     
/*  97 */     if (!context.getState().isAvailable()) {
/*  98 */       response.sendError(503, sm
/*  99 */           .getString("standardContext.isUnavailable"));
/* 100 */       unavailable = true;
/*     */     } 
/*     */ 
/*     */     
/* 104 */     if (!unavailable && wrapper.isUnavailable()) {
/* 105 */       this.container.getLogger().info(sm.getString("standardWrapper.isUnavailable", new Object[] { wrapper.getName() }));
/* 106 */       checkWrapperAvailable(response, wrapper);
/* 107 */       unavailable = true;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 112 */       if (!unavailable) {
/* 113 */         servlet = wrapper.allocate();
/*     */       }
/* 115 */     } catch (UnavailableException e) {
/* 116 */       this.container.getLogger().error(sm.getString("standardWrapper.allocateException", new Object[] { wrapper.getName() }), (Throwable)e);
/* 117 */       checkWrapperAvailable(response, wrapper);
/* 118 */     } catch (ServletException e) {
/* 119 */       this.container.getLogger().error(sm.getString("standardWrapper.allocateException", new Object[] { wrapper.getName()
/* 120 */             }), StandardWrapper.getRootCause(e));
/* 121 */       ServletException servletException1 = e;
/* 122 */       exception(request, response, (Throwable)e);
/* 123 */     } catch (Throwable t) {
/* 124 */       ExceptionUtils.handleThrowable(t);
/* 125 */       this.container.getLogger().error(sm.getString("standardWrapper.allocateException", new Object[] { wrapper.getName() }), t);
/* 126 */       throwable = t;
/* 127 */       exception(request, response, t);
/*     */     } 
/*     */ 
/*     */     
/* 131 */     MessageBytes requestPathMB = request.getRequestPathMB();
/* 132 */     DispatcherType dispatcherType = DispatcherType.REQUEST;
/* 133 */     if (request.getDispatcherType() == DispatcherType.ASYNC) {
/* 134 */       dispatcherType = DispatcherType.ASYNC;
/*     */     }
/* 136 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", dispatcherType);
/* 137 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", requestPathMB);
/*     */     
/* 139 */     ApplicationFilterChain filterChain = ApplicationFilterFactory.createFilterChain((ServletRequest)request, wrapper, servlet);
/*     */ 
/*     */ 
/*     */     
/* 143 */     Container container = this.container;
/*     */     try {
/* 145 */       if (servlet != null && filterChain != null)
/*     */       {
/* 147 */         if (context.getSwallowOutput()) {
/*     */           try {
/* 149 */             SystemLogHandler.startCapture();
/* 150 */             if (request.isAsyncDispatching()) {
/* 151 */               request.getAsyncContextInternal().doInternalDispatch();
/*     */             } else {
/* 153 */               filterChain.doFilter((ServletRequest)request.getRequest(), (ServletResponse)response.getResponse());
/*     */             } 
/*     */           } finally {
/* 156 */             String log = SystemLogHandler.stopCapture();
/* 157 */             if (log != null && !log.isEmpty()) {
/* 158 */               context.getLogger().info(log);
/*     */             }
/*     */           }
/*     */         
/* 162 */         } else if (request.isAsyncDispatching()) {
/* 163 */           request.getAsyncContextInternal().doInternalDispatch();
/*     */         } else {
/* 165 */           filterChain.doFilter((ServletRequest)request.getRequest(), (ServletResponse)response.getResponse());
/*     */         }
/*     */       
/*     */       }
/*     */     }
/* 170 */     catch (BadRequestException e) {
/* 171 */       if (container.getLogger().isDebugEnabled()) {
/* 172 */         container.getLogger().debug(sm
/* 173 */             .getString("standardWrapper.serviceException", new Object[] { wrapper.getName(), context.getName() }), (Throwable)e);
/*     */       }
/* 175 */       BadRequestException badRequestException1 = e;
/* 176 */       exception(request, response, (Throwable)e, 400);
/* 177 */     } catch (CloseNowException e) {
/* 178 */       if (container.getLogger().isDebugEnabled()) {
/* 179 */         container.getLogger().debug(sm
/* 180 */             .getString("standardWrapper.serviceException", new Object[] { wrapper.getName(), context.getName() }), (Throwable)e);
/*     */       }
/* 182 */       CloseNowException closeNowException1 = e;
/* 183 */       exception(request, response, (Throwable)e);
/* 184 */     } catch (IOException ioe) {
/* 185 */       container.getLogger()
/* 186 */         .error(sm.getString("standardWrapper.serviceException", new Object[] { wrapper.getName(), context.getName() }), ioe);
/* 187 */       throwable = ioe;
/* 188 */       exception(request, response, ioe);
/* 189 */     } catch (UnavailableException e) {
/* 190 */       container.getLogger()
/* 191 */         .error(sm.getString("standardWrapper.serviceException", new Object[] { wrapper.getName(), context.getName() }), (Throwable)e);
/* 192 */       wrapper.unavailable(e);
/* 193 */       checkWrapperAvailable(response, wrapper);
/*     */     
/*     */     }
/* 196 */     catch (ServletException e) {
/* 197 */       Throwable rootCause = StandardWrapper.getRootCause(e);
/* 198 */       if (!(rootCause instanceof BadRequestException)) {
/* 199 */         container.getLogger().error(sm.getString("standardWrapper.serviceExceptionRoot", new Object[] { wrapper.getName(), context
/* 200 */                 .getName(), e.getMessage() }), rootCause);
/*     */       }
/* 202 */       ServletException servletException1 = e;
/* 203 */       exception(request, response, (Throwable)e);
/* 204 */     } catch (Throwable t) {
/* 205 */       ExceptionUtils.handleThrowable(t);
/* 206 */       container.getLogger()
/* 207 */         .error(sm.getString("standardWrapper.serviceException", new Object[] { wrapper.getName(), context.getName() }), t);
/* 208 */       throwable = t;
/* 209 */       exception(request, response, t);
/*     */     } finally {
/*     */       
/* 212 */       if (filterChain != null) {
/* 213 */         filterChain.release();
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 218 */         if (servlet != null) {
/* 219 */           wrapper.deallocate(servlet);
/*     */         }
/* 221 */       } catch (Throwable t) {
/* 222 */         ExceptionUtils.handleThrowable(t);
/* 223 */         container.getLogger().error(sm.getString("standardWrapper.deallocateException", new Object[] { wrapper.getName() }), t);
/* 224 */         if (throwable == null) {
/* 225 */           throwable = t;
/* 226 */           exception(request, response, t);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 233 */         if (servlet != null && wrapper.getAvailable() == Long.MAX_VALUE) {
/* 234 */           wrapper.unload();
/*     */         }
/* 236 */       } catch (Throwable t) {
/* 237 */         ExceptionUtils.handleThrowable(t);
/* 238 */         container.getLogger().error(sm.getString("standardWrapper.unloadException", new Object[] { wrapper.getName() }), t);
/* 239 */         if (throwable == null) {
/* 240 */           exception(request, response, t);
/*     */         }
/*     */       } 
/* 243 */       long t2 = System.currentTimeMillis();
/*     */       
/* 245 */       long time = t2 - t1;
/* 246 */       this.processingTime.add(time);
/* 247 */       if (time > this.maxTime) {
/* 248 */         this.maxTime = time;
/*     */       }
/* 250 */       if (time < this.minTime) {
/* 251 */         this.minTime = time;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkWrapperAvailable(Response response, StandardWrapper wrapper) throws IOException {
/* 257 */     long available = wrapper.getAvailable();
/* 258 */     if (available > 0L && available < Long.MAX_VALUE) {
/* 259 */       response.setDateHeader("Retry-After", available);
/* 260 */       response.sendError(503, sm
/* 261 */           .getString("standardWrapper.isUnavailable", new Object[] { wrapper.getName() }));
/* 262 */     } else if (available == Long.MAX_VALUE) {
/* 263 */       response.sendError(404, sm
/* 264 */           .getString("standardWrapper.notFound", new Object[] { wrapper.getName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void exception(Request request, Response response, Throwable exception) {
/* 280 */     exception(request, response, exception, 500);
/*     */   }
/*     */ 
/*     */   
/*     */   private void exception(Request request, Response response, Throwable exception, int errorCode) {
/* 285 */     request.setAttribute("jakarta.servlet.error.exception", exception);
/* 286 */     response.setStatus(errorCode);
/* 287 */     response.setError();
/*     */   }
/*     */   
/*     */   public long getProcessingTime() {
/* 291 */     return this.processingTime.sum();
/*     */   }
/*     */   
/*     */   public long getMaxTime() {
/* 295 */     return this.maxTime;
/*     */   }
/*     */   
/*     */   public long getMinTime() {
/* 299 */     return this.minTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getRequestCount() {
/* 312 */     return this.requestCount.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getErrorCount() {
/* 325 */     return this.errorCount.get();
/*     */   }
/*     */   
/*     */   public void incrementErrorCount() {
/* 329 */     this.errorCount.incrementAndGet();
/*     */   }
/*     */   
/*     */   protected void initInternal() throws LifecycleException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardWrapperValve.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */