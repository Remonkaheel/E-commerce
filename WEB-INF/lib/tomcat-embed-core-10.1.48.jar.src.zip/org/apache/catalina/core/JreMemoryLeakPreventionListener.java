/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.net.URLConnection;
/*     */ import java.security.SecureRandom;
/*     */ import java.sql.DriverManager;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JreMemoryLeakPreventionListener
/*     */   implements LifecycleListener
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(JreMemoryLeakPreventionListener.class);
/*  49 */   private static final StringManager sm = StringManager.getManager(JreMemoryLeakPreventionListener.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean appContextProtection = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAppContextProtection() {
/*  59 */     return this.appContextProtection;
/*     */   }
/*     */   
/*     */   public void setAppContextProtection(boolean appContextProtection) {
/*  63 */     this.appContextProtection = appContextProtection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean urlCacheProtection = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUrlCacheProtection() {
/*  73 */     return this.urlCacheProtection;
/*     */   }
/*     */   
/*     */   public void setUrlCacheProtection(boolean urlCacheProtection) {
/*  77 */     this.urlCacheProtection = urlCacheProtection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean driverManagerProtection = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDriverManagerProtection() {
/*  88 */     return this.driverManagerProtection;
/*     */   }
/*     */   
/*     */   public void setDriverManagerProtection(boolean driverManagerProtection) {
/*  92 */     this.driverManagerProtection = driverManagerProtection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private String classesToInitialize = null;
/*     */   
/*     */   public String getClassesToInitialize() {
/* 103 */     return this.classesToInitialize;
/*     */   }
/*     */   
/*     */   public void setClassesToInitialize(String classesToInitialize) {
/* 107 */     this.classesToInitialize = classesToInitialize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initSeedGenerator = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getInitSeedGenerator() {
/* 117 */     return this.initSeedGenerator;
/*     */   }
/*     */   
/*     */   public void setInitSeedGenerator(boolean initSeedGenerator) {
/* 121 */     this.initSeedGenerator = initSeedGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lifecycleEvent(LifecycleEvent event) {
/* 128 */     if ("before_init".equals(event.getType())) {
/* 129 */       if (!(event.getLifecycle() instanceof org.apache.catalina.Server)) {
/* 130 */         log.warn(sm.getString("listener.notServer", new Object[] { event.getLifecycle().getClass().getSimpleName() }));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       if (this.driverManagerProtection) {
/* 142 */         DriverManager.getDrivers();
/*     */       }
/*     */       
/* 145 */       Thread currentThread = Thread.currentThread();
/* 146 */       ClassLoader loader = currentThread.getContextClassLoader();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 151 */         currentThread.setContextClassLoader(ClassLoader.getSystemClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 166 */         if (this.appContextProtection) {
/* 167 */           ImageIO.getCacheDirectory();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 184 */         if (this.urlCacheProtection) {
/* 185 */           URLConnection.setDefaultUseCaches("JAR", false);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         if (this.initSeedGenerator) {
/* 193 */           SecureRandom.getSeed(1);
/*     */         }
/*     */         
/* 196 */         if (this.classesToInitialize != null) {
/* 197 */           StringTokenizer strTok = new StringTokenizer(this.classesToInitialize, ", \r\n\t");
/* 198 */           while (strTok.hasMoreTokens()) {
/* 199 */             String classNameToLoad = strTok.nextToken();
/*     */             try {
/* 201 */               Class.forName(classNameToLoad);
/* 202 */             } catch (ClassNotFoundException e) {
/* 203 */               log.error(sm.getString("jreLeakListener.classToInitializeFail", new Object[] { classNameToLoad }), e);
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } finally {
/*     */         
/* 210 */         currentThread.setContextClassLoader(loader);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\JreMemoryLeakPreventionListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */