/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.Context;
/*      */ import javax.naming.NameAlreadyBoundException;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.StringRefAddr;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextAccessController;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.naming.EjbRef;
/*      */ import org.apache.naming.HandlerRef;
/*      */ import org.apache.naming.LookupRef;
/*      */ import org.apache.naming.NamingContext;
/*      */ import org.apache.naming.ResourceEnvRef;
/*      */ import org.apache.naming.ResourceLinkRef;
/*      */ import org.apache.naming.ResourceRef;
/*      */ import org.apache.naming.ServiceRef;
/*      */ import org.apache.naming.TransactionRef;
/*      */ import org.apache.naming.factory.ResourceLinkFactory;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextHandler;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextTransaction;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ResourceBase;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NamingContextListener
/*      */   implements LifecycleListener, PropertyChangeListener
/*      */ {
/*   82 */   private static final Log log = LogFactory.getLog(NamingContextListener.class);
/*   83 */   protected static final StringManager sm = StringManager.getManager(NamingContextListener.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   91 */   protected String name = "/";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   protected Object container = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private Object token = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean initialized = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   protected NamingResourcesImpl namingResources = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   protected NamingContext namingContext = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   protected Context compCtx = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   protected Context envCtx = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   protected HashMap<String, ObjectName> objectNames = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean exceptionOnFailedWrite = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getExceptionOnFailedWrite() {
/*  153 */     return this.exceptionOnFailedWrite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExceptionOnFailedWrite(boolean exceptionOnFailedWrite) {
/*  164 */     this.exceptionOnFailedWrite = exceptionOnFailedWrite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  172 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  182 */     this.name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Context getEnvContext() {
/*  190 */     return this.envCtx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lifecycleEvent(LifecycleEvent event) {
/*  199 */     this.container = event.getLifecycle();
/*      */     
/*  201 */     if (this.container instanceof Context) {
/*  202 */       this.namingResources = ((Context)this.container).getNamingResources();
/*  203 */       this.token = ((Context)this.container).getNamingToken();
/*  204 */     } else if (this.container instanceof Server) {
/*  205 */       this.namingResources = ((Server)this.container).getGlobalNamingResources();
/*  206 */       this.token = ((Server)this.container).getNamingToken();
/*      */     } else {
/*      */       return;
/*      */     } 
/*      */     
/*  211 */     if ("configure_start".equals(event.getType())) {
/*      */       
/*  213 */       if (this.initialized) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/*  218 */         Hashtable<String, Object> contextEnv = new Hashtable<>();
/*  219 */         this.namingContext = new NamingContext(contextEnv, getName());
/*  220 */         ContextAccessController.setSecurityToken(getName(), this.token);
/*  221 */         ContextAccessController.setSecurityToken(this.container, this.token);
/*  222 */         ContextBindings.bindContext(this.container, (Context)this.namingContext, this.token);
/*  223 */         if (log.isDebugEnabled()) {
/*  224 */           log.debug(sm.getString("naming.bind", new Object[] { this.container }));
/*      */         }
/*      */ 
/*      */         
/*  228 */         this.namingContext.setExceptionOnFailedWrite(getExceptionOnFailedWrite());
/*      */ 
/*      */         
/*  231 */         ContextAccessController.setWritable(getName(), this.token);
/*      */         
/*      */         try {
/*  234 */           createNamingContext();
/*  235 */         } catch (NamingException e) {
/*  236 */           log.error(sm.getString("naming.namingContextCreationFailed", new Object[] { this.container }), e);
/*      */         } 
/*      */         
/*  239 */         this.namingResources.addPropertyChangeListener(this);
/*      */ 
/*      */         
/*  242 */         if (this.container instanceof Context) {
/*      */           
/*  244 */           ContextAccessController.setReadOnly(getName());
/*      */           try {
/*  246 */             ContextBindings.bindClassLoader(this.container, this.token, ((Context)this.container)
/*  247 */                 .getLoader().getClassLoader());
/*  248 */           } catch (NamingException e) {
/*  249 */             log.error(sm.getString("naming.bindFailed", new Object[] { this.container }), e);
/*      */           } 
/*      */         } 
/*      */         
/*  253 */         if (this.container instanceof Server) {
/*  254 */           ResourceLinkFactory.setGlobalContext((Context)this.namingContext);
/*      */           try {
/*  256 */             ContextBindings.bindClassLoader(this.container, this.token, getClass().getClassLoader());
/*  257 */           } catch (NamingException e) {
/*  258 */             log.error(sm.getString("naming.bindFailed", new Object[] { this.container }), e);
/*      */           } 
/*  260 */           if (this.container instanceof StandardServer) {
/*  261 */             ((StandardServer)this.container).setGlobalNamingContext((Context)this.namingContext);
/*      */           }
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/*  267 */         this.initialized = true;
/*      */       }
/*      */     
/*  270 */     } else if ("configure_stop".equals(event.getType())) {
/*      */       
/*  272 */       if (!this.initialized) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  278 */         ContextAccessController.setWritable(getName(), this.token);
/*  279 */         ContextBindings.unbindContext(this.container, this.token);
/*      */         
/*  281 */         if (this.container instanceof Context) {
/*  282 */           ContextBindings.unbindClassLoader(this.container, this.token, ((Context)this.container)
/*  283 */               .getLoader().getClassLoader());
/*      */         }
/*      */         
/*  286 */         if (this.container instanceof Server) {
/*  287 */           ContextBindings.unbindClassLoader(this.container, this.token, getClass().getClassLoader());
/*      */         }
/*      */         
/*  290 */         this.namingResources.removePropertyChangeListener(this);
/*      */         
/*  292 */         ContextAccessController.unsetSecurityToken(getName(), this.token);
/*  293 */         ContextAccessController.unsetSecurityToken(this.container, this.token);
/*      */ 
/*      */         
/*  296 */         if (!this.objectNames.isEmpty()) {
/*  297 */           Collection<ObjectName> names = this.objectNames.values();
/*  298 */           Registry registry = Registry.getRegistry(null);
/*  299 */           for (ObjectName objectName : names) {
/*  300 */             registry.unregisterComponent(objectName);
/*      */           }
/*      */         } 
/*      */         
/*  304 */         Context global = getGlobalNamingContext();
/*  305 */         if (global != null) {
/*  306 */           ResourceLinkFactory.deregisterGlobalResourceAccess(global);
/*      */         }
/*      */       } finally {
/*  309 */         this.objectNames.clear();
/*      */         
/*  311 */         this.namingContext = null;
/*  312 */         this.envCtx = null;
/*  313 */         this.compCtx = null;
/*  314 */         this.initialized = false;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void propertyChange(PropertyChangeEvent event) {
/*  328 */     if (!this.initialized) {
/*      */       return;
/*      */     }
/*      */     
/*  332 */     Object source = event.getSource();
/*  333 */     if (source == this.namingResources) {
/*      */ 
/*      */       
/*  336 */       ContextAccessController.setWritable(getName(), this.token);
/*      */       
/*  338 */       processGlobalResourcesChange(event.getPropertyName(), event.getOldValue(), event.getNewValue());
/*      */ 
/*      */       
/*  341 */       ContextAccessController.setReadOnly(getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processGlobalResourcesChange(String name, Object oldValue, Object newValue) {
/*  361 */     switch (name) {
/*      */       case "ejb":
/*  363 */         if (oldValue != null) {
/*  364 */           ContextEjb ejb = (ContextEjb)oldValue;
/*  365 */           if (ejb.getName() != null) {
/*  366 */             removeEjb(ejb.getName());
/*      */           }
/*      */         } 
/*  369 */         if (newValue != null) {
/*  370 */           ContextEjb ejb = (ContextEjb)newValue;
/*  371 */           if (ejb.getName() != null) {
/*  372 */             addEjb(ejb);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "environment":
/*  377 */         if (oldValue != null) {
/*  378 */           ContextEnvironment env = (ContextEnvironment)oldValue;
/*  379 */           if (env.getName() != null) {
/*  380 */             removeEnvironment(env.getName());
/*      */           }
/*      */         } 
/*  383 */         if (newValue != null) {
/*  384 */           ContextEnvironment env = (ContextEnvironment)newValue;
/*  385 */           if (env.getName() != null) {
/*  386 */             addEnvironment(env);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "localEjb":
/*  391 */         if (oldValue != null) {
/*  392 */           ContextLocalEjb ejb = (ContextLocalEjb)oldValue;
/*  393 */           if (ejb.getName() != null) {
/*  394 */             removeLocalEjb(ejb.getName());
/*      */           }
/*      */         } 
/*  397 */         if (newValue != null) {
/*  398 */           ContextLocalEjb ejb = (ContextLocalEjb)newValue;
/*  399 */           if (ejb.getName() != null) {
/*  400 */             addLocalEjb(ejb);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "messageDestinationRef":
/*  405 */         if (oldValue != null) {
/*  406 */           MessageDestinationRef mdr = (MessageDestinationRef)oldValue;
/*  407 */           if (mdr.getName() != null) {
/*  408 */             removeMessageDestinationRef(mdr.getName());
/*      */           }
/*      */         } 
/*  411 */         if (newValue != null) {
/*  412 */           MessageDestinationRef mdr = (MessageDestinationRef)newValue;
/*  413 */           if (mdr.getName() != null) {
/*  414 */             addMessageDestinationRef(mdr);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "resource":
/*  419 */         if (oldValue != null) {
/*  420 */           ContextResource resource = (ContextResource)oldValue;
/*  421 */           if (resource.getName() != null) {
/*  422 */             removeResource(resource.getName());
/*      */           }
/*      */         } 
/*  425 */         if (newValue != null) {
/*  426 */           ContextResource resource = (ContextResource)newValue;
/*  427 */           if (resource.getName() != null) {
/*  428 */             addResource(resource);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "resourceEnvRef":
/*  433 */         if (oldValue != null) {
/*  434 */           ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)oldValue;
/*  435 */           if (resourceEnvRef.getName() != null) {
/*  436 */             removeResourceEnvRef(resourceEnvRef.getName());
/*      */           }
/*      */         } 
/*  439 */         if (newValue != null) {
/*  440 */           ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)newValue;
/*  441 */           if (resourceEnvRef.getName() != null) {
/*  442 */             addResourceEnvRef(resourceEnvRef);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "resourceLink":
/*  447 */         if (oldValue != null) {
/*  448 */           ContextResourceLink rl = (ContextResourceLink)oldValue;
/*  449 */           if (rl.getName() != null) {
/*  450 */             removeResourceLink(rl.getName());
/*      */           }
/*      */         } 
/*  453 */         if (newValue != null) {
/*  454 */           ContextResourceLink rl = (ContextResourceLink)newValue;
/*  455 */           if (rl.getName() != null) {
/*  456 */             addResourceLink(rl);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case "service":
/*  461 */         if (oldValue != null) {
/*  462 */           ContextService service = (ContextService)oldValue;
/*  463 */           if (service.getName() != null) {
/*  464 */             removeService(service.getName());
/*      */           }
/*      */         } 
/*  467 */         if (newValue != null) {
/*  468 */           ContextService service = (ContextService)newValue;
/*  469 */           if (service.getName() != null) {
/*  470 */             addService(service);
/*      */           }
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createNamingContext() throws NamingException {
/*  486 */     if (this.container instanceof Server) {
/*  487 */       this.compCtx = (Context)this.namingContext;
/*  488 */       this.envCtx = (Context)this.namingContext;
/*      */     } else {
/*  490 */       this.compCtx = this.namingContext.createSubcontext("comp");
/*  491 */       this.envCtx = this.compCtx.createSubcontext("env");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  498 */       this.namingContext.bind("module", this.compCtx);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  503 */     if (log.isTraceEnabled()) {
/*  504 */       log.trace("Creating JNDI naming context");
/*      */     }
/*      */     
/*  507 */     if (this.namingResources == null) {
/*  508 */       this.namingResources = new NamingResourcesImpl();
/*  509 */       this.namingResources.setContainer(this.container);
/*      */     } 
/*      */ 
/*      */     
/*  513 */     ContextResourceLink[] resourceLinks = this.namingResources.findResourceLinks(); int i;
/*  514 */     for (i = 0; i < resourceLinks.length; i++) {
/*  515 */       addResourceLink(resourceLinks[i]);
/*      */     }
/*      */ 
/*      */     
/*  519 */     ContextResource[] resources = this.namingResources.findResources();
/*  520 */     for (i = 0; i < resources.length; i++) {
/*  521 */       addResource(resources[i]);
/*      */     }
/*      */ 
/*      */     
/*  525 */     ContextResourceEnvRef[] resourceEnvRefs = this.namingResources.findResourceEnvRefs();
/*  526 */     for (i = 0; i < resourceEnvRefs.length; i++) {
/*  527 */       addResourceEnvRef(resourceEnvRefs[i]);
/*      */     }
/*      */ 
/*      */     
/*  531 */     ContextEnvironment[] contextEnvironments = this.namingResources.findEnvironments();
/*  532 */     for (i = 0; i < contextEnvironments.length; i++) {
/*  533 */       addEnvironment(contextEnvironments[i]);
/*      */     }
/*      */ 
/*      */     
/*  537 */     ContextEjb[] ejbs = this.namingResources.findEjbs();
/*  538 */     for (i = 0; i < ejbs.length; i++) {
/*  539 */       addEjb(ejbs[i]);
/*      */     }
/*      */ 
/*      */     
/*  543 */     MessageDestinationRef[] mdrs = this.namingResources.findMessageDestinationRefs();
/*  544 */     for (i = 0; i < mdrs.length; i++) {
/*  545 */       addMessageDestinationRef(mdrs[i]);
/*      */     }
/*      */ 
/*      */     
/*  549 */     ContextService[] services = this.namingResources.findServices();
/*  550 */     for (i = 0; i < services.length; i++) {
/*  551 */       addService(services[i]);
/*      */     }
/*      */ 
/*      */     
/*  555 */     if (this.container instanceof Context) {
/*      */       try {
/*  557 */         TransactionRef transactionRef = new TransactionRef();
/*  558 */         this.compCtx.bind("UserTransaction", transactionRef);
/*  559 */         ContextTransaction transaction = this.namingResources.getTransaction();
/*  560 */         if (transaction != null) {
/*  561 */           Iterator<String> params = transaction.listProperties();
/*  562 */           while (params.hasNext()) {
/*  563 */             String paramName = params.next();
/*  564 */             String paramValue = (String)transaction.getProperty(paramName);
/*  565 */             StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  566 */             transactionRef.add(refAddr);
/*      */           } 
/*      */         } 
/*  569 */       } catch (NameAlreadyBoundException nameAlreadyBoundException) {
/*      */ 
/*      */       
/*  572 */       } catch (NamingException e) {
/*  573 */         log.error(sm.getString("naming.bindFailed", new Object[] { "UserTransaction" }), e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  578 */     if (this.container instanceof Context) {
/*      */       try {
/*  580 */         this.compCtx.bind("Resources", ((Context)this.container).getResources());
/*  581 */       } catch (NamingException e) {
/*  582 */         log.error(sm.getString("naming.bindFailed", new Object[] { "Resources" }), e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectName createObjectName(ContextResource resource) throws MalformedObjectNameException {
/*  600 */     String domain = null;
/*  601 */     if (this.container instanceof StandardServer) {
/*  602 */       domain = ((StandardServer)this.container).getDomain();
/*  603 */     } else if (this.container instanceof ContainerBase) {
/*  604 */       domain = ((ContainerBase)this.container).getDomain();
/*      */     } 
/*  606 */     if (domain == null) {
/*  607 */       domain = "Catalina";
/*      */     }
/*      */     
/*  610 */     ObjectName name = null;
/*  611 */     String quotedResourceName = ObjectName.quote(resource.getName());
/*  612 */     if (this.container instanceof Server) {
/*      */       
/*  614 */       name = new ObjectName(domain + ":type=DataSource,class=" + domain + ",name=" + resource.getType());
/*  615 */     } else if (this.container instanceof Context) {
/*  616 */       String contextName = ((Context)this.container).getName();
/*  617 */       if (!contextName.startsWith("/")) {
/*  618 */         contextName = "/" + contextName;
/*      */       }
/*  620 */       Host host = (Host)((Context)this.container).getParent();
/*      */       
/*  622 */       name = new ObjectName(domain + ":type=DataSource,host=" + domain + ",context=" + host.getName() + ",class=" + contextName + ",name=" + resource.getType());
/*      */     } 
/*      */     
/*  625 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEjb(ContextEjb ejb) {
/*      */     EjbRef ejbRef;
/*  637 */     LookupRef lookupRef = lookForLookupRef((ResourceBase)ejb);
/*      */     
/*  639 */     if (lookupRef == null) {
/*      */       
/*  641 */       ejbRef = new EjbRef(ejb.getType(), ejb.getHome(), ejb.getRemote(), ejb.getLink());
/*      */       
/*  643 */       Iterator<String> params = ejb.listProperties();
/*  644 */       while (params.hasNext()) {
/*  645 */         String paramName = params.next();
/*  646 */         String paramValue = (String)ejb.getProperty(paramName);
/*  647 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  648 */         ejbRef.add(refAddr);
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/*  653 */       createSubcontexts(this.envCtx, ejb.getName());
/*  654 */       this.envCtx.bind(ejb.getName(), ejbRef);
/*  655 */     } catch (NamingException e) {
/*  656 */       log.error(sm.getString("naming.bindFailed", new Object[] { ejb.getName() }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEnvironment(ContextEnvironment env) {
/*  668 */     Object value = lookForLookupRef((ResourceBase)env);
/*      */     
/*  670 */     if (value == null) {
/*      */ 
/*      */       
/*  673 */       String type = env.getType();
/*      */       try {
/*  675 */         switch (type) {
/*      */           case "java.lang.String":
/*  677 */             value = env.getValue();
/*      */             break;
/*      */           case "java.lang.Byte":
/*  680 */             if (env.getValue() == null) {
/*  681 */               value = Byte.valueOf((byte)0); break;
/*      */             } 
/*  683 */             value = Byte.decode(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Short":
/*  687 */             if (env.getValue() == null) {
/*  688 */               value = Short.valueOf((short)0); break;
/*      */             } 
/*  690 */             value = Short.decode(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Integer":
/*  694 */             if (env.getValue() == null) {
/*  695 */               value = Integer.valueOf(0); break;
/*      */             } 
/*  697 */             value = Integer.decode(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Long":
/*  701 */             if (env.getValue() == null) {
/*  702 */               value = Long.valueOf(0L); break;
/*      */             } 
/*  704 */             value = Long.decode(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Boolean":
/*  708 */             value = Boolean.valueOf(env.getValue());
/*      */             break;
/*      */           case "java.lang.Double":
/*  711 */             if (env.getValue() == null) {
/*  712 */               value = Double.valueOf(0.0D); break;
/*      */             } 
/*  714 */             value = Double.valueOf(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Float":
/*  718 */             if (env.getValue() == null) {
/*  719 */               value = Float.valueOf(0.0F); break;
/*      */             } 
/*  721 */             value = Float.valueOf(env.getValue());
/*      */             break;
/*      */           
/*      */           case "java.lang.Character":
/*  725 */             if (env.getValue() == null) {
/*  726 */               value = Character.valueOf(false); break;
/*      */             } 
/*  728 */             if (env.getValue().length() == 1) {
/*  729 */               value = Character.valueOf(env.getValue().charAt(0)); break;
/*      */             } 
/*  731 */             throw new IllegalArgumentException();
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  736 */             value = constructEnvEntry(env.getType(), env.getValue());
/*  737 */             if (value == null) {
/*  738 */               log.error(sm.getString("naming.invalidEnvEntryType", new Object[] { env.getName() }));
/*      */             }
/*      */             break;
/*      */         } 
/*  742 */       } catch (IllegalArgumentException e) {
/*  743 */         log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { env.getName() }));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  748 */     if (value != null) {
/*      */       try {
/*  750 */         if (log.isDebugEnabled()) {
/*  751 */           log.debug(sm.getString("naming.addEnvEntry", new Object[] { env.getName() }));
/*      */         }
/*  753 */         createSubcontexts(this.envCtx, env.getName());
/*  754 */         this.envCtx.bind(env.getName(), value);
/*  755 */       } catch (NamingException e) {
/*  756 */         log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { env.getName() }), e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private Object constructEnvEntry(String type, String value) {
/*      */     try {
/*  764 */       Class<?> clazz = Class.forName(type);
/*      */       
/*      */       try {
/*  767 */         Constructor<?> c = clazz.getConstructor(new Class[] { String.class });
/*  768 */         return c.newInstance(new Object[] { value });
/*  769 */       } catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */ 
/*      */         
/*  773 */         if (value.length() != 1) {
/*  774 */           return null;
/*      */         }
/*      */         
/*      */         try {
/*  778 */           Constructor<?> c = clazz.getConstructor(new Class[] { char.class });
/*  779 */           return c.newInstance(new Object[] { Character.valueOf(value.charAt(0)) });
/*  780 */         } catch (NoSuchMethodException noSuchMethodException1) {}
/*      */       }
/*      */     
/*  783 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  786 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLocalEjb(ContextLocalEjb localEjb) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addService(ContextService service) {
/*      */     ServiceRef serviceRef;
/*  820 */     LookupRef lookupRef = lookForLookupRef((ResourceBase)service);
/*      */     
/*  822 */     if (lookupRef == null) {
/*      */       
/*  824 */       if (service.getWsdlfile() != null) {
/*  825 */         URL wsdlURL = null;
/*      */         
/*      */         try {
/*  828 */           URI wsdlURI = new URI(service.getWsdlfile());
/*  829 */           wsdlURL = wsdlURI.toURL();
/*  830 */         } catch (MalformedURLException|java.net.URISyntaxException|IllegalArgumentException malformedURLException) {}
/*      */ 
/*      */         
/*  833 */         if (wsdlURL == null) {
/*      */           try {
/*  835 */             wsdlURL = ((Context)this.container).getServletContext().getResource(service.getWsdlfile());
/*  836 */           } catch (MalformedURLException malformedURLException) {}
/*      */         }
/*      */ 
/*      */         
/*  840 */         if (wsdlURL == null) {
/*      */           try {
/*  842 */             wsdlURL = ((Context)this.container).getServletContext().getResource("/" + service.getWsdlfile());
/*  843 */             if (log.isDebugEnabled()) {
/*  844 */               log.debug(sm.getString("naming.addSlash", new Object[] { service.getWsdlfile() }));
/*      */             }
/*  846 */           } catch (MalformedURLException e) {
/*  847 */             log.error(sm.getString("naming.wsdlFailed", new Object[] { service.getWsdlfile() }), e);
/*      */           } 
/*      */         }
/*  850 */         if (wsdlURL == null) {
/*  851 */           service.setWsdlfile(null);
/*      */         } else {
/*  853 */           service.setWsdlfile(wsdlURL.toString());
/*      */         } 
/*      */       } 
/*      */       
/*  857 */       if (service.getJaxrpcmappingfile() != null) {
/*  858 */         URL jaxrpcURL = null;
/*      */         
/*      */         try {
/*  861 */           URI jaxrpcURI = new URI(service.getJaxrpcmappingfile());
/*  862 */           jaxrpcURL = jaxrpcURI.toURL();
/*  863 */         } catch (MalformedURLException|java.net.URISyntaxException|IllegalArgumentException malformedURLException) {}
/*      */ 
/*      */         
/*  866 */         if (jaxrpcURL == null) {
/*      */           
/*      */           try {
/*  869 */             jaxrpcURL = ((Context)this.container).getServletContext().getResource(service.getJaxrpcmappingfile());
/*  870 */           } catch (MalformedURLException malformedURLException) {}
/*      */         }
/*      */ 
/*      */         
/*  874 */         if (jaxrpcURL == null) {
/*      */           
/*      */           try {
/*  877 */             jaxrpcURL = ((Context)this.container).getServletContext().getResource("/" + service.getJaxrpcmappingfile());
/*  878 */             if (log.isDebugEnabled()) {
/*  879 */               log.debug(sm.getString("naming.addSlash", new Object[] { service.getJaxrpcmappingfile() }));
/*      */             }
/*  881 */           } catch (MalformedURLException e) {
/*  882 */             log.error(sm.getString("naming.wsdlFailed", new Object[] { service.getJaxrpcmappingfile() }), e);
/*      */           } 
/*      */         }
/*  885 */         if (jaxrpcURL == null) {
/*  886 */           service.setJaxrpcmappingfile(null);
/*      */         } else {
/*  888 */           service.setJaxrpcmappingfile(jaxrpcURL.toString());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  894 */       serviceRef = new ServiceRef(service.getName(), service.getInterface(), service.getServiceqname(), service.getWsdlfile(), service.getJaxrpcmappingfile());
/*      */ 
/*      */       
/*  897 */       Iterator<String> portcomponent = service.getServiceendpoints();
/*  898 */       while (portcomponent.hasNext()) {
/*  899 */         String serviceendpoint = portcomponent.next();
/*  900 */         StringRefAddr refAddr = new StringRefAddr("serviceendpointinterface", serviceendpoint);
/*  901 */         serviceRef.add(refAddr);
/*  902 */         String portlink = service.getPortlink(serviceendpoint);
/*  903 */         refAddr = new StringRefAddr("portcomponentlink", portlink);
/*  904 */         serviceRef.add(refAddr);
/*      */       } 
/*      */       
/*  907 */       Iterator<String> handlers = service.getHandlers();
/*  908 */       while (handlers.hasNext()) {
/*  909 */         String handlername = handlers.next();
/*  910 */         ContextHandler handler = service.getHandler(handlername);
/*  911 */         HandlerRef handlerRef = new HandlerRef(handlername, handler.getHandlerclass());
/*  912 */         Iterator<String> localParts = handler.getLocalparts();
/*  913 */         while (localParts.hasNext()) {
/*  914 */           String localPart = localParts.next();
/*  915 */           String namespaceURI = handler.getNamespaceuri(localPart);
/*  916 */           handlerRef.add(new StringRefAddr("handlerlocalpart", localPart));
/*  917 */           handlerRef.add(new StringRefAddr("handlernamespace", namespaceURI));
/*      */         } 
/*  919 */         Iterator<String> params = handler.listProperties();
/*  920 */         while (params.hasNext()) {
/*  921 */           String paramName = params.next();
/*  922 */           String paramValue = (String)handler.getProperty(paramName);
/*  923 */           handlerRef.add(new StringRefAddr("handlerparamname", paramName));
/*  924 */           handlerRef.add(new StringRefAddr("handlerparamvalue", paramValue));
/*      */         }  int i;
/*  926 */         for (i = 0; i < handler.getSoapRolesSize(); i++) {
/*  927 */           handlerRef.add(new StringRefAddr("handlersoaprole", handler.getSoapRole(i)));
/*      */         }
/*  929 */         for (i = 0; i < handler.getPortNamesSize(); i++) {
/*  930 */           handlerRef.add(new StringRefAddr("handlerportname", handler.getPortName(i)));
/*      */         }
/*  932 */         serviceRef.addHandler(handlerRef);
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/*  937 */       if (log.isDebugEnabled()) {
/*  938 */         log.debug(sm.getString("naming.addService", new Object[] { serviceRef, service.getName() }));
/*      */       }
/*  940 */       createSubcontexts(this.envCtx, service.getName());
/*  941 */       this.envCtx.bind(service.getName(), serviceRef);
/*  942 */     } catch (NamingException e) {
/*  943 */       log.error(sm.getString("naming.bindFailed", new Object[] { service.getName() }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResource(ContextResource resource) {
/*      */     ResourceRef resourceRef;
/*  955 */     LookupRef lookupRef = lookForLookupRef((ResourceBase)resource);
/*      */     
/*  957 */     if (lookupRef == null) {
/*      */ 
/*      */       
/*  960 */       resourceRef = new ResourceRef(resource.getType(), resource.getDescription(), resource.getScope(), resource.getAuth(), resource.getSingleton());
/*      */       
/*  962 */       Iterator<String> params = resource.listProperties();
/*  963 */       while (params.hasNext()) {
/*  964 */         String paramName = params.next();
/*  965 */         String paramValue = (String)resource.getProperty(paramName);
/*  966 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  967 */         resourceRef.add(refAddr);
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/*  972 */       if (log.isDebugEnabled()) {
/*  973 */         log.debug(sm.getString("naming.addResourceRef", new Object[] { resourceRef, resource.getName() }));
/*      */       }
/*  975 */       createSubcontexts(this.envCtx, resource.getName());
/*  976 */       this.envCtx.bind(resource.getName(), resourceRef);
/*  977 */     } catch (NamingException e) {
/*  978 */       log.error(sm.getString("naming.bindFailed", new Object[] { resource.getName() }), e);
/*      */     } 
/*      */     
/*  981 */     if (("javax.sql.DataSource".equals(resourceRef.getClassName()) || "javax.sql.XADataSource"
/*  982 */       .equals(resourceRef.getClassName())) && resource.getSingleton()) {
/*  983 */       Object actualResource = null;
/*      */       try {
/*  985 */         ObjectName on = createObjectName(resource);
/*  986 */         actualResource = this.envCtx.lookup(resource.getName());
/*  987 */         Registry.getRegistry(null).registerComponent(actualResource, on, null);
/*  988 */         this.objectNames.put(resource.getName(), on);
/*  989 */       } catch (Exception e) {
/*  990 */         log.warn(sm.getString("naming.jmxRegistrationFailed", new Object[] { resource.getName() }), e);
/*      */       } 
/*      */ 
/*      */       
/*  994 */       if (actualResource instanceof AutoCloseable && !resource.getCloseMethodConfigured()) {
/*  995 */         resource.setCloseMethod("close");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResourceEnvRef(ContextResourceEnvRef resourceEnvRef) {
/*      */     ResourceEnvRef resourceEnvRef1;
/* 1008 */     LookupRef lookupRef = lookForLookupRef((ResourceBase)resourceEnvRef);
/*      */     
/* 1010 */     if (lookupRef == null) {
/*      */       
/* 1012 */       resourceEnvRef1 = new ResourceEnvRef(resourceEnvRef.getType());
/*      */       
/* 1014 */       Iterator<String> params = resourceEnvRef.listProperties();
/* 1015 */       while (params.hasNext()) {
/* 1016 */         String paramName = params.next();
/* 1017 */         String paramValue = (String)resourceEnvRef.getProperty(paramName);
/* 1018 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/* 1019 */         resourceEnvRef1.add(refAddr);
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/* 1024 */       if (log.isDebugEnabled()) {
/* 1025 */         log.debug(sm.getString("naming.addResourceEnvRef", new Object[] { resourceEnvRef.getName() }));
/*      */       }
/* 1027 */       createSubcontexts(this.envCtx, resourceEnvRef.getName());
/* 1028 */       this.envCtx.bind(resourceEnvRef.getName(), resourceEnvRef1);
/* 1029 */     } catch (NamingException e) {
/* 1030 */       log.error(sm.getString("naming.bindFailed", new Object[] { resourceEnvRef.getName() }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addResourceLink(ContextResourceLink resourceLink) {
/* 1044 */     ResourceLinkRef resourceLinkRef = new ResourceLinkRef(resourceLink.getType(), resourceLink.getGlobal(), resourceLink.getFactory(), null);
/* 1045 */     Iterator<String> i = resourceLink.listProperties();
/* 1046 */     while (i.hasNext()) {
/* 1047 */       String key = i.next();
/* 1048 */       Object val = resourceLink.getProperty(key);
/* 1049 */       if (val != null) {
/* 1050 */         StringRefAddr refAddr = new StringRefAddr(key, val.toString());
/* 1051 */         resourceLinkRef.add(refAddr);
/*      */       } 
/*      */     } 
/* 1054 */     Context ctx = "UserTransaction".equals(resourceLink.getName()) ? this.compCtx : this.envCtx;
/*      */     try {
/* 1056 */       if (log.isDebugEnabled()) {
/* 1057 */         log.debug(sm.getString("naming.addResourceLink", new Object[] { resourceLink.getName() }));
/*      */       }
/* 1059 */       createSubcontexts(this.envCtx, resourceLink.getName());
/* 1060 */       ctx.bind(resourceLink.getName(), resourceLinkRef);
/* 1061 */     } catch (NamingException e) {
/* 1062 */       log.error(sm.getString("naming.bindFailed", new Object[] { resourceLink.getName() }), e);
/*      */     } 
/*      */     
/* 1065 */     ResourceLinkFactory.registerGlobalResourceAccess(getGlobalNamingContext(), resourceLink.getName(), resourceLink
/* 1066 */         .getGlobal());
/*      */   }
/*      */ 
/*      */   
/*      */   private Context getGlobalNamingContext() {
/* 1071 */     if (this.container instanceof Context) {
/* 1072 */       Engine e = (Engine)((Context)this.container).getParent().getParent();
/* 1073 */       Server s = e.getService().getServer();
/*      */       
/* 1075 */       if (s != null) {
/* 1076 */         return s.getGlobalNamingContext();
/*      */       }
/*      */     } 
/* 1079 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeEjb(String name) {
/*      */     try {
/* 1091 */       this.envCtx.unbind(name);
/* 1092 */     } catch (NamingException e) {
/* 1093 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeEnvironment(String name) {
/*      */     try {
/* 1107 */       this.envCtx.unbind(name);
/* 1108 */     } catch (NamingException e) {
/* 1109 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLocalEjb(String name) {
/*      */     try {
/* 1123 */       this.envCtx.unbind(name);
/* 1124 */     } catch (NamingException e) {
/* 1125 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMessageDestinationRef(String name) {
/*      */     try {
/* 1139 */       this.envCtx.unbind(name);
/* 1140 */     } catch (NamingException e) {
/* 1141 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeService(String name) {
/*      */     try {
/* 1155 */       this.envCtx.unbind(name);
/* 1156 */     } catch (NamingException e) {
/* 1157 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResource(String name) {
/*      */     try {
/* 1171 */       this.envCtx.unbind(name);
/* 1172 */     } catch (NamingException e) {
/* 1173 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */     
/* 1176 */     ObjectName on = this.objectNames.get(name);
/* 1177 */     if (on != null) {
/* 1178 */       Registry.getRegistry(null).unregisterComponent(on);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResourceEnvRef(String name) {
/*      */     try {
/* 1192 */       this.envCtx.unbind(name);
/* 1193 */     } catch (NamingException e) {
/* 1194 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeResourceLink(String name) {
/*      */     try {
/* 1208 */       this.envCtx.unbind(name);
/* 1209 */     } catch (NamingException e) {
/* 1210 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     } 
/*      */     
/* 1213 */     ResourceLinkFactory.deregisterGlobalResourceAccess(getGlobalNamingContext(), name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createSubcontexts(Context ctx, String name) throws NamingException {
/* 1221 */     Context currentContext = ctx;
/* 1222 */     StringTokenizer tokenizer = new StringTokenizer(name, "/");
/* 1223 */     while (tokenizer.hasMoreTokens()) {
/* 1224 */       String token = tokenizer.nextToken();
/* 1225 */       if (!token.isEmpty() && tokenizer.hasMoreTokens()) {
/*      */         try {
/* 1227 */           currentContext = currentContext.createSubcontext(token);
/* 1228 */         } catch (NamingException e) {
/*      */ 
/*      */           
/* 1231 */           currentContext = (Context)currentContext.lookup(token);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LookupRef lookForLookupRef(ResourceBase resourceBase) {
/* 1246 */     String lookupName = resourceBase.getLookupName();
/* 1247 */     if (lookupName != null && !lookupName.isEmpty()) {
/* 1248 */       return new LookupRef(resourceBase.getType(), lookupName);
/*      */     }
/* 1250 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\NamingContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */