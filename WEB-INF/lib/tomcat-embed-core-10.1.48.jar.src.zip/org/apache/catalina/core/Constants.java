package org.apache.catalina.core;

public class Constants {
  public static final int MAJOR_VERSION = 6;
  
  public static final int MINOR_VERSION = 0;
  
  public static final String JSP_SERVLET_CLASS = "org.apache.jasper.servlet.JspServlet";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */