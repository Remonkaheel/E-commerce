/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletRequestWrapper;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationRequest
/*     */   extends ServletRequestWrapper
/*     */ {
/*     */   @Deprecated
/*  48 */   protected static final String[] specials = new String[] { "jakarta.servlet.include.request_uri", "jakarta.servlet.include.context_path", "jakarta.servlet.include.servlet_path", "jakarta.servlet.include.path_info", "jakarta.servlet.include.query_string", "jakarta.servlet.include.mapping", "jakarta.servlet.forward.request_uri", "jakarta.servlet.forward.context_path", "jakarta.servlet.forward.servlet_path", "jakarta.servlet.forward.path_info", "jakarta.servlet.forward.query_string", "jakarta.servlet.forward.mapping" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private static final Set<String> specialsSet = new HashSet<>(Arrays.asList(specials));
/*     */   
/*  60 */   private static final int shortestSpecialNameLength = specialsSet.stream().mapToInt(String::length).min().getAsInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   protected final HashMap<String, Object> attributes = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ApplicationRequest(ServletRequest request) {
/*  74 */     super(request);
/*  75 */     setRequest(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/*  88 */     synchronized (this.attributes) {
/*  89 */       return this.attributes.get(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/*  99 */     synchronized (this.attributes) {
/* 100 */       return Collections.enumeration(this.attributes.keySet());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 112 */     synchronized (this.attributes) {
/* 113 */       this.attributes.remove(name);
/* 114 */       if (!isSpecial(name)) {
/* 115 */         getRequest().removeAttribute(name);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object value) {
/* 129 */     synchronized (this.attributes) {
/* 130 */       this.attributes.put(name, value);
/* 131 */       if (!isSpecial(name)) {
/* 132 */         getRequest().setAttribute(name, value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected boolean isSpecial(String name) {
/* 148 */     if (name.length() < shortestSpecialNameLength) {
/* 149 */       return false;
/*     */     }
/* 151 */     return specialsSet.contains(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequest(ServletRequest request) {
/* 164 */     super.setRequest(request);
/*     */ 
/*     */     
/* 167 */     synchronized (this.attributes) {
/* 168 */       this.attributes.clear();
/* 169 */       Enumeration<String> names = request.getAttributeNames();
/* 170 */       while (names.hasMoreElements()) {
/* 171 */         String name = names.nextElement();
/* 172 */         Object value = request.getAttribute(name);
/* 173 */         this.attributes.put(name, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationRequest.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */