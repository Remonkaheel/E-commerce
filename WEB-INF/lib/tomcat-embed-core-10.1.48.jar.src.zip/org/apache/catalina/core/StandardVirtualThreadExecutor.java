/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.VirtualThreadExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardVirtualThreadExecutor
/*     */   extends LifecycleMBeanBase
/*     */   implements Executor, ExecutorService
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(StandardVirtualThreadExecutor.class);
/*     */   
/*     */   private String name;
/*     */   private ExecutorService executor;
/*  46 */   private String namePrefix = "tomcat-virt-";
/*     */   
/*     */   public void setName(String name) {
/*  49 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  54 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getNamePrefix() {
/*  58 */     return this.namePrefix;
/*     */   }
/*     */   
/*     */   public void setNamePrefix(String namePrefix) {
/*  62 */     this.namePrefix = namePrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(Runnable command) {
/*  67 */     if (this.executor == null) {
/*  68 */       throw new IllegalStateException(sm.getString("standardVirtualThreadExecutor.notStarted"));
/*     */     }
/*  70 */     this.executor.execute(command);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initInternal() throws LifecycleException {
/*  77 */     super.initInternal();
/*  78 */     if (!JreCompat.isJre21Available()) {
/*  79 */       throw new LifecycleException(sm.getString("standardVirtualThreadExecutor.noVirtualThreads"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void startInternal() throws LifecycleException {
/*  85 */     this.executor = (ExecutorService)new VirtualThreadExecutor(getNamePrefix());
/*  86 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stopInternal() throws LifecycleException {
/*  91 */     this.executor = null;
/*  92 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDomainInternal() {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getObjectNameKeyProperties() {
/* 103 */     return "type=Executor,name=" + getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Runnable> shutdownNow() {
/* 115 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 121 */     if (this.executor != null) {
/* 122 */       return this.executor.isShutdown();
/*     */     }
/* 124 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 131 */     if (this.executor != null) {
/* 132 */       return this.executor.isTerminated();
/*     */     }
/* 134 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 147 */     if (this.executor != null) {
/* 148 */       return this.executor.submit(task);
/*     */     }
/* 150 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Runnable task, T result) {
/* 157 */     if (this.executor != null) {
/* 158 */       return this.executor.submit(task, result);
/*     */     }
/* 160 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<?> submit(Runnable task) {
/* 167 */     if (this.executor != null) {
/* 168 */       return this.executor.submit(task);
/*     */     }
/* 170 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 177 */     if (this.executor != null) {
/* 178 */       return this.executor.invokeAll(tasks);
/*     */     }
/* 180 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 188 */     if (this.executor != null) {
/* 189 */       return this.executor.invokeAll(tasks, timeout, unit);
/*     */     }
/* 191 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 198 */     if (this.executor != null) {
/* 199 */       return this.executor.invokeAny(tasks);
/*     */     }
/* 201 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 209 */     if (this.executor != null) {
/* 210 */       return this.executor.invokeAny(tasks, timeout, unit);
/*     */     }
/* 212 */     throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardVirtualThreadExecutor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */