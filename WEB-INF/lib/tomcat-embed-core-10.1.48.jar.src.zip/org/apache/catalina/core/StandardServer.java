/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.ServerSocket;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.Random;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ScheduledFuture;
/*      */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.Context;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.mbeans.MBeanFactory;
/*      */ import org.apache.catalina.startup.Catalina;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.StringCache;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.threads.ScheduledThreadPoolExecutor;
/*      */ import org.apache.tomcat.util.threads.TaskThreadFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class StandardServer
/*      */   extends LifecycleMBeanBase
/*      */   implements Server
/*      */ {
/*   68 */   private static final Log log = LogFactory.getLog(StandardServer.class);
/*   69 */   private static final StringManager sm = StringManager.getManager(StandardServer.class);
/*      */   private Context globalNamingContext; private NamingResourcesImpl globalNamingResources; private final NamingContextListener namingContextListener;
/*      */   private int port;
/*      */   private int portOffset;
/*      */   private String address;
/*      */   private Random random;
/*      */   private Service[] services;
/*      */   private final ReentrantReadWriteLock servicesLock;
/*      */   private final Lock servicesReadLock;
/*      */   private final Lock servicesWriteLock;
/*      */   private String shutdown;
/*      */   final PropertyChangeSupport support;
/*      */   private volatile boolean stopAwait;
/*      */   private Catalina catalina;
/*      */   private ClassLoader parentClassLoader;
/*      */   private volatile Thread awaitThread;
/*      */   private volatile ServerSocket awaitSocket;
/*      */   private File catalinaHome;
/*      */   private File catalinaBase;
/*      */   private final Object namingToken;
/*      */   private int utilityThreads;
/*      */   private boolean utilityThreadsAsDaemon;
/*      */   private ScheduledThreadPoolExecutor utilityExecutor;
/*      */   private final Object utilityExecutorLock;
/*      */   private ScheduledExecutorService utilityExecutorWrapper;
/*      */   private ScheduledFuture<?> periodicLifecycleEventFuture;
/*      */   private ScheduledFuture<?> monitorFuture;
/*      */   private int periodicEventDelay;
/*      */   private ObjectName onameStringCache;
/*      */   private ObjectName onameMBeanFactory;
/*      */   
/*  100 */   public StandardServer() { this.globalNamingContext = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  118 */     this.port = 8005;
/*      */     
/*  120 */     this.portOffset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     this.address = "localhost";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  132 */     this.random = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  138 */     this.services = new Service[0];
/*      */     
/*  140 */     this.servicesLock = new ReentrantReadWriteLock();
/*  141 */     this.servicesReadLock = this.servicesLock.readLock();
/*  142 */     this.servicesWriteLock = this.servicesLock.writeLock();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  147 */     this.shutdown = "SHUTDOWN";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  153 */     this.support = new PropertyChangeSupport(this);
/*      */     
/*  155 */     this.stopAwait = false;
/*      */     
/*  157 */     this.catalina = null;
/*      */     
/*  159 */     this.parentClassLoader = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  164 */     this.awaitThread = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  169 */     this.awaitSocket = null;
/*      */     
/*  171 */     this.catalinaHome = null;
/*      */     
/*  173 */     this.catalinaBase = null;
/*      */     
/*  175 */     this.namingToken = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     this.utilityThreads = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  185 */     this.utilityThreadsAsDaemon = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  190 */     this.utilityExecutor = null;
/*  191 */     this.utilityExecutorLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     this.utilityExecutorWrapper = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     this.periodicLifecycleEventFuture = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  209 */     this.periodicEventDelay = 10; this.globalNamingResources = new NamingResourcesImpl();
/*      */     this.globalNamingResources.setContainer(this);
/*      */     if (isUseNaming()) {
/*      */       this.namingContextListener = new NamingContextListener();
/*      */       addLifecycleListener(this.namingContextListener);
/*      */     } else {
/*      */       this.namingContextListener = null;
/*  216 */     }  } public Object getNamingToken() { return this.namingToken; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Context getGlobalNamingContext() {
/*  222 */     return this.globalNamingContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGlobalNamingContext(Context globalNamingContext) {
/*  232 */     this.globalNamingContext = globalNamingContext;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NamingResourcesImpl getGlobalNamingResources() {
/*  238 */     return this.globalNamingResources;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGlobalNamingResources(NamingResourcesImpl globalNamingResources) {
/*  245 */     NamingResourcesImpl oldGlobalNamingResources = this.globalNamingResources;
/*  246 */     this.globalNamingResources = globalNamingResources;
/*  247 */     this.globalNamingResources.setContainer(this);
/*  248 */     this.support.firePropertyChange("globalNamingResources", oldGlobalNamingResources, this.globalNamingResources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerInfo() {
/*  259 */     return ServerInfo.getServerInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerBuilt() {
/*  269 */     return ServerInfo.getServerBuilt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerNumber() {
/*  279 */     return ServerInfo.getServerNumber();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPort() {
/*  285 */     return this.port;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPort(int port) {
/*  291 */     this.port = port;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPortOffset() {
/*  297 */     return this.portOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPortOffset(int portOffset) {
/*  303 */     if (portOffset < 0) {
/*  304 */       throw new IllegalArgumentException(sm
/*  305 */           .getString("standardServer.portOffset.invalid", new Object[] { Integer.valueOf(portOffset) }));
/*      */     }
/*  307 */     this.portOffset = portOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPortWithOffset() {
/*  315 */     int port = getPort();
/*  316 */     if (port > 0) {
/*  317 */       return port + getPortOffset();
/*      */     }
/*  319 */     return port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAddress() {
/*  326 */     return this.address;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAddress(String address) {
/*  332 */     this.address = address;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getShutdown() {
/*  337 */     return this.shutdown;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShutdown(String shutdown) {
/*  343 */     this.shutdown = shutdown;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Catalina getCatalina() {
/*  349 */     return this.catalina;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalina(Catalina catalina) {
/*  355 */     this.catalina = catalina;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUtilityThreads() {
/*  361 */     return this.utilityThreads;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getUtilityThreadsInternal(int utilityThreads) {
/*  369 */     int result = utilityThreads;
/*  370 */     if (result <= 0) {
/*  371 */       result = Runtime.getRuntime().availableProcessors() + result;
/*  372 */       if (result < 2) {
/*  373 */         result = 2;
/*      */       }
/*      */     } 
/*  376 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUtilityThreads(int utilityThreads) {
/*  383 */     int oldUtilityThreads = this.utilityThreads;
/*  384 */     if (getUtilityThreadsInternal(utilityThreads) < getUtilityThreadsInternal(oldUtilityThreads)) {
/*      */       return;
/*      */     }
/*  387 */     this.utilityThreads = utilityThreads;
/*  388 */     synchronized (this.utilityExecutorLock) {
/*  389 */       if (oldUtilityThreads != utilityThreads && this.utilityExecutor != null) {
/*  390 */         reconfigureUtilityExecutor(getUtilityThreadsInternal(utilityThreads));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void reconfigureUtilityExecutor(int threads) {
/*  401 */     if (this.utilityExecutor != null) {
/*  402 */       this.utilityExecutor.setCorePoolSize(threads);
/*      */     } else {
/*  404 */       ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(threads, (ThreadFactory)new TaskThreadFactory("Catalina-utility-", this.utilityThreadsAsDaemon, 1));
/*      */       
/*  406 */       scheduledThreadPoolExecutor.setKeepAliveTime(10L, TimeUnit.SECONDS);
/*  407 */       scheduledThreadPoolExecutor.setRemoveOnCancelPolicy(true);
/*  408 */       scheduledThreadPoolExecutor.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/*  409 */       this.utilityExecutor = scheduledThreadPoolExecutor;
/*  410 */       this.utilityExecutorWrapper = (ScheduledExecutorService)new ScheduledThreadPoolExecutor(this.utilityExecutor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUtilityThreadsAsDaemon() {
/*  421 */     return this.utilityThreadsAsDaemon;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUtilityThreadsAsDaemon(boolean utilityThreadsAsDaemon) {
/*  431 */     this.utilityThreadsAsDaemon = utilityThreadsAsDaemon;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPeriodicEventDelay() {
/*  439 */     return this.periodicEventDelay;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPeriodicEventDelay(int periodicEventDelay) {
/*  449 */     this.periodicEventDelay = periodicEventDelay;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addService(Service service) {
/*  459 */     service.setServer(this);
/*      */     
/*  461 */     this.servicesWriteLock.lock();
/*      */     try {
/*  463 */       Service[] results = new Service[this.services.length + 1];
/*  464 */       System.arraycopy(this.services, 0, results, 0, this.services.length);
/*  465 */       results[this.services.length] = service;
/*  466 */       this.services = results;
/*      */     } finally {
/*  468 */       this.servicesWriteLock.unlock();
/*      */     } 
/*      */     
/*  471 */     if (getState().isAvailable()) {
/*      */       try {
/*  473 */         service.start();
/*  474 */       } catch (LifecycleException lifecycleException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  480 */     this.support.firePropertyChange("service", (Object)null, service);
/*      */   }
/*      */   
/*      */   public void stopAwait() {
/*  484 */     this.stopAwait = true;
/*  485 */     Thread t = this.awaitThread;
/*  486 */     if (t != null) {
/*  487 */       ServerSocket s = this.awaitSocket;
/*  488 */       if (s != null) {
/*  489 */         this.awaitSocket = null;
/*      */         try {
/*  491 */           s.close();
/*  492 */         } catch (IOException iOException) {}
/*      */       } 
/*      */ 
/*      */       
/*  496 */       t.interrupt();
/*      */       try {
/*  498 */         t.join(1000L);
/*  499 */       } catch (InterruptedException interruptedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void await() {
/*  508 */     if (getPortWithOffset() == -2) {
/*      */       return;
/*      */     }
/*      */     
/*  512 */     Thread currentThread = Thread.currentThread();
/*  513 */     if (getPortWithOffset() == -1) {
/*      */       try {
/*  515 */         this.awaitThread = currentThread;
/*  516 */         while (!this.stopAwait) {
/*      */           try {
/*  518 */             Thread.sleep(10000L);
/*  519 */           } catch (InterruptedException interruptedException) {}
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/*  524 */         this.awaitThread = null;
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/*  531 */       this.awaitSocket = new ServerSocket(getPortWithOffset(), 1, InetAddress.getByName(this.address));
/*  532 */     } catch (IOException ioe) {
/*  533 */       log.error(sm.getString("standardServer.awaitSocket.fail", new Object[] { this.address, String.valueOf(getPortWithOffset()), 
/*  534 */               String.valueOf(getPort()), String.valueOf(getPortOffset()) }), ioe);
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/*  539 */       this.awaitThread = currentThread;
/*      */ 
/*      */       
/*  542 */       while (!this.stopAwait) {
/*  543 */         ServerSocket serverSocket1 = this.awaitSocket;
/*  544 */         if (serverSocket1 == null) {
/*      */           break;
/*      */         }
/*      */ 
/*      */         
/*  549 */         Socket socket = null;
/*  550 */         StringBuilder command = new StringBuilder();
/*      */         
/*      */         try { InputStream stream;
/*  553 */           long acceptStartTime = System.currentTimeMillis();
/*      */           
/*  555 */           try { socket = serverSocket1.accept();
/*  556 */             socket.setSoTimeout(10000);
/*  557 */             stream = socket.getInputStream(); }
/*  558 */           catch (SocketTimeoutException ste)
/*      */           
/*      */           { 
/*  561 */             log.warn(sm.getString("standardServer.accept.timeout", new Object[] {
/*  562 */                     Long.valueOf(System.currentTimeMillis() - acceptStartTime)
/*      */                   }), ste);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  602 */               if (socket != null) {
/*  603 */                 socket.close();
/*      */               }
/*  605 */             } catch (IOException iOException) {} continue; } catch (AccessControlException ace) { log.warn(sm.getString("standardServer.accept.security"), ace); try { if (socket != null) socket.close();  } catch (IOException iOException) {} continue; } catch (IOException ioe) { if (this.stopAwait) { try { if (socket != null) socket.close();  } catch (IOException iOException) {} break; }  log.error(sm.getString("standardServer.accept.error"), ioe); try { if (socket != null) socket.close();  } catch (IOException iOException) {} break; }  int expected = 1024; while (expected < this.shutdown.length()) { if (this.random == null) this.random = new Random();  expected += this.random.nextInt() % 1024; }  while (expected > 0) { int ch; try { ch = stream.read(); } catch (IOException ioe) { log.warn(sm.getString("standardServer.accept.readError"), ioe); ch = -1; }  if (ch < 32 || ch == 127) break;  command.append((char)ch); expected--; }  } finally { try { if (socket != null) socket.close();  } catch (IOException iOException) {} }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  611 */         boolean match = command.toString().equals(this.shutdown);
/*  612 */         if (match) {
/*  613 */           log.info(sm.getString("standardServer.shutdownViaPort"));
/*      */           break;
/*      */         } 
/*  616 */         log.warn(sm.getString("standardServer.invalidShutdownCommand", new Object[] { command.toString() }));
/*      */       } 
/*      */     } finally {
/*      */       
/*  620 */       ServerSocket serverSocket = this.awaitSocket;
/*  621 */       this.awaitThread = null;
/*  622 */       this.awaitSocket = null;
/*      */ 
/*      */       
/*  625 */       if (serverSocket != null) {
/*      */         try {
/*  627 */           serverSocket.close();
/*  628 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Service findService(String name) {
/*  638 */     if (name == null) {
/*  639 */       return null;
/*      */     }
/*  641 */     this.servicesReadLock.lock();
/*      */     
/*      */     try {
/*  644 */       for (Service service : this.services) {
/*  645 */         if (name.equals(service.getName())) {
/*  646 */           return service;
/*      */         }
/*      */       } 
/*      */     } finally {
/*  650 */       this.servicesReadLock.unlock();
/*      */     } 
/*      */     
/*  653 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Service[] findServices() {
/*  659 */     this.servicesReadLock.lock();
/*      */     
/*      */     try {
/*  662 */       return (Service[])this.services.clone();
/*      */     } finally {
/*  664 */       this.servicesReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectName[] getServiceNames() {
/*  672 */     this.servicesReadLock.lock();
/*      */     
/*      */     try {
/*  675 */       ObjectName[] onames = new ObjectName[this.services.length];
/*  676 */       for (int i = 0; i < this.services.length; i++) {
/*  677 */         onames[i] = ((StandardService)this.services[i]).getObjectName();
/*      */       }
/*  679 */       return onames;
/*      */     } finally {
/*  681 */       this.servicesReadLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeService(Service service) {
/*  689 */     this.servicesWriteLock.lock();
/*      */     
/*      */     try {
/*  692 */       int j = -1;
/*  693 */       for (int i = 0; i < this.services.length; i++) {
/*  694 */         if (service == this.services[i]) {
/*  695 */           j = i;
/*      */           break;
/*      */         } 
/*      */       } 
/*  699 */       if (j < 0) {
/*      */         return;
/*      */       }
/*  702 */       int k = 0;
/*  703 */       Service[] results = new Service[this.services.length - 1];
/*  704 */       for (int m = 0; m < this.services.length; m++) {
/*  705 */         if (m != j) {
/*  706 */           results[k++] = this.services[m];
/*      */         }
/*      */       } 
/*  709 */       this.services = results;
/*      */     } finally {
/*  711 */       this.servicesWriteLock.unlock();
/*      */     } 
/*      */     
/*      */     try {
/*  715 */       service.stop();
/*  716 */     } catch (LifecycleException lifecycleException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  721 */     this.support.firePropertyChange("service", service, (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public File getCatalinaBase() {
/*  727 */     if (this.catalinaBase != null) {
/*  728 */       return this.catalinaBase;
/*      */     }
/*      */     
/*  731 */     this.catalinaBase = getCatalinaHome();
/*  732 */     return this.catalinaBase;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalinaBase(File catalinaBase) {
/*  738 */     this.catalinaBase = catalinaBase;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public File getCatalinaHome() {
/*  744 */     return this.catalinaHome;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalinaHome(File catalinaHome) {
/*  750 */     this.catalinaHome = catalinaHome;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/*  763 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  775 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  782 */     return "StandardServer[" + getPort() + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void storeConfig() throws InstanceNotFoundException, MBeanException {
/*      */     try {
/*  797 */       ObjectName sname = new ObjectName("Catalina:type=StoreConfig");
/*  798 */       MBeanServer server = Registry.getRegistry(null).getMBeanServer();
/*  799 */       if (server.isRegistered(sname)) {
/*  800 */         server.invoke(sname, "storeConfig", null, null);
/*      */       } else {
/*  802 */         log.error(sm.getString("standardServer.storeConfig.notAvailable", new Object[] { sname }));
/*      */       } 
/*  804 */     } catch (Throwable t) {
/*  805 */       ExceptionUtils.handleThrowable(t);
/*  806 */       log.error(sm.getString("standardServer.storeConfig.error"), t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void storeContext(Context context) throws InstanceNotFoundException, MBeanException {
/*      */     try {
/*  824 */       ObjectName sname = new ObjectName("Catalina:type=StoreConfig");
/*  825 */       MBeanServer server = Registry.getRegistry(null).getMBeanServer();
/*  826 */       if (server.isRegistered(sname)) {
/*  827 */         server.invoke(sname, "store", new Object[] { context }, new String[] { "java.lang.String" });
/*      */       } else {
/*  829 */         log.error(sm.getString("standardServer.storeConfig.notAvailable", new Object[] { sname }));
/*      */       } 
/*  831 */     } catch (Throwable t) {
/*  832 */       ExceptionUtils.handleThrowable(t);
/*  833 */       log.error(sm.getString("standardServer.storeConfig.contextError", new Object[] { context.getName() }), t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isUseNaming() {
/*  842 */     boolean useNaming = true;
/*      */     
/*  844 */     String useNamingProperty = System.getProperty("catalina.useNaming");
/*  845 */     if (useNamingProperty != null && useNamingProperty.equals("false")) {
/*  846 */       useNaming = false;
/*      */     }
/*  848 */     return useNaming;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startInternal() throws LifecycleException {
/*  855 */     fireLifecycleEvent("configure_start", null);
/*  856 */     setState(LifecycleState.STARTING);
/*      */ 
/*      */     
/*  859 */     synchronized (this.utilityExecutorLock) {
/*  860 */       reconfigureUtilityExecutor(getUtilityThreadsInternal(this.utilityThreads));
/*  861 */       register(this.utilityExecutor, "type=UtilityExecutor");
/*      */     } 
/*      */     
/*  864 */     this.globalNamingResources.start();
/*      */ 
/*      */     
/*  867 */     for (Service service : findServices()) {
/*  868 */       service.start();
/*      */     }
/*      */     
/*  871 */     if (this.periodicEventDelay > 0) {
/*  872 */       this.monitorFuture = getUtilityExecutor().scheduleWithFixedDelay(this::startPeriodicLifecycleEvent, 0L, 60L, TimeUnit.SECONDS);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void startPeriodicLifecycleEvent() {
/*  879 */     if (this.periodicLifecycleEventFuture == null || this.periodicLifecycleEventFuture.isDone()) {
/*  880 */       if (this.periodicLifecycleEventFuture != null && this.periodicLifecycleEventFuture.isDone()) {
/*      */         
/*      */         try {
/*  883 */           this.periodicLifecycleEventFuture.get();
/*  884 */         } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*  885 */           log.error(sm.getString("standardServer.periodicEventError"), e);
/*      */         } 
/*      */       }
/*  888 */       this
/*  889 */         .periodicLifecycleEventFuture = getUtilityExecutor().scheduleAtFixedRate(() -> fireLifecycleEvent("periodic", null), this.periodicEventDelay, this.periodicEventDelay, TimeUnit.SECONDS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopInternal() throws LifecycleException {
/*  898 */     setState(LifecycleState.STOPPING);
/*      */     
/*  900 */     if (this.monitorFuture != null) {
/*  901 */       this.monitorFuture.cancel(true);
/*  902 */       this.monitorFuture = null;
/*      */     } 
/*  904 */     if (this.periodicLifecycleEventFuture != null) {
/*  905 */       this.periodicLifecycleEventFuture.cancel(false);
/*  906 */       this.periodicLifecycleEventFuture = null;
/*      */     } 
/*      */     
/*  909 */     fireLifecycleEvent("configure_stop", null);
/*      */ 
/*      */     
/*  912 */     for (Service service : findServices()) {
/*  913 */       service.stop();
/*      */     }
/*      */     
/*  916 */     synchronized (this.utilityExecutorLock) {
/*  917 */       if (this.utilityExecutor != null) {
/*  918 */         this.utilityExecutor.shutdownNow();
/*  919 */         unregister("type=UtilityExecutor");
/*  920 */         this.utilityExecutor = null;
/*      */       } 
/*      */     } 
/*      */     
/*  924 */     this.globalNamingResources.stop();
/*      */     
/*  926 */     stopAwait();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initInternal() throws LifecycleException {
/*  937 */     super.initInternal();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  943 */     this.onameStringCache = register(new StringCache(), "type=StringCache");
/*      */ 
/*      */     
/*  946 */     MBeanFactory factory = new MBeanFactory();
/*  947 */     factory.setContainer(this);
/*  948 */     this.onameMBeanFactory = register(factory, "type=MBeanFactory");
/*      */ 
/*      */     
/*  951 */     this.globalNamingResources.init();
/*      */ 
/*      */     
/*  954 */     for (Service service : findServices()) {
/*  955 */       service.init();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void destroyInternal() throws LifecycleException {
/*  962 */     for (Service service : findServices()) {
/*  963 */       service.destroy();
/*      */     }
/*      */     
/*  966 */     this.globalNamingResources.destroy();
/*      */     
/*  968 */     unregister(this.onameMBeanFactory);
/*      */     
/*  970 */     unregister(this.onameStringCache);
/*      */     
/*  972 */     super.destroyInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   public ClassLoader getParentClassLoader() {
/*  977 */     if (this.parentClassLoader != null) {
/*  978 */       return this.parentClassLoader;
/*      */     }
/*  980 */     if (this.catalina != null) {
/*  981 */       return this.catalina.getParentClassLoader();
/*      */     }
/*  983 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setParentClassLoader(ClassLoader parent) {
/*  988 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/*  989 */     this.parentClassLoader = parent;
/*  990 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getDomainInternal() {
/* 1007 */     String domain = null;
/*      */     
/* 1009 */     Service[] services = findServices();
/* 1010 */     if (services.length > 0) {
/* 1011 */       Service service = services[0];
/* 1012 */       if (service != null) {
/* 1013 */         domain = service.getDomain();
/*      */       }
/*      */     } 
/* 1016 */     return domain;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getObjectNameKeyProperties() {
/* 1022 */     return "type=Server";
/*      */   }
/*      */ 
/*      */   
/*      */   public ScheduledExecutorService getUtilityExecutor() {
/* 1027 */     return this.utilityExecutorWrapper;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\StandardServer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */