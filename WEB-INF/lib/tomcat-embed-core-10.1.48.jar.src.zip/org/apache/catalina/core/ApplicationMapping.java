/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletMapping;
/*     */ import jakarta.servlet.http.MappingMatch;
/*     */ import org.apache.catalina.mapper.MappingData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationMapping
/*     */ {
/*     */   private final MappingData mappingData;
/*  28 */   private volatile HttpServletMapping mapping = null;
/*     */   
/*     */   public ApplicationMapping(MappingData mappingData) {
/*  31 */     this.mappingData = mappingData;
/*     */   }
/*     */   
/*     */   public HttpServletMapping getHttpServletMapping() {
/*  35 */     if (this.mapping == null) {
/*     */       String servletName;
/*  37 */       if (this.mappingData.wrapper == null) {
/*  38 */         servletName = "";
/*     */       } else {
/*  40 */         servletName = this.mappingData.wrapper.getName();
/*     */       } 
/*  42 */       if (this.mappingData.matchType == null) {
/*  43 */         this.mapping = new MappingImpl("", "", null, servletName);
/*     */       } else {
/*  45 */         String path; int extIndex; String matchValue; switch (this.mappingData.matchType) {
/*     */           case CONTEXT_ROOT:
/*  47 */             this.mapping = new MappingImpl("", "", this.mappingData.matchType, servletName);
/*     */             break;
/*     */           case DEFAULT:
/*  50 */             this.mapping = new MappingImpl("", "/", this.mappingData.matchType, servletName);
/*     */             break;
/*     */           case EXACT:
/*  53 */             this
/*  54 */               .mapping = new MappingImpl(this.mappingData.wrapperPath.toString().substring(1), this.mappingData.wrapperPath.toString(), this.mappingData.matchType, servletName);
/*     */             break;
/*     */           case EXTENSION:
/*  57 */             path = this.mappingData.wrapperPath.toString();
/*  58 */             extIndex = path.lastIndexOf('.');
/*  59 */             this.mapping = new MappingImpl(path.substring(1, extIndex), "*" + path.substring(extIndex), this.mappingData.matchType, servletName);
/*     */             break;
/*     */ 
/*     */           
/*     */           case PATH:
/*  64 */             if (this.mappingData.pathInfo.isNull()) {
/*  65 */               matchValue = null;
/*     */             } else {
/*  67 */               matchValue = this.mappingData.pathInfo.toString().substring(1);
/*     */             } 
/*  69 */             this.mapping = new MappingImpl(matchValue, this.mappingData.wrapperPath.toString() + "/*", this.mappingData.matchType, servletName);
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/*  76 */     return this.mapping;
/*     */   }
/*     */   
/*     */   public void recycle() {
/*  80 */     this.mapping = null;
/*     */   }
/*     */   
/*     */   private static class MappingImpl
/*     */     implements HttpServletMapping {
/*     */     private final String matchValue;
/*     */     private final String pattern;
/*     */     private final MappingMatch mappingType;
/*     */     private final String servletName;
/*     */     
/*     */     MappingImpl(String matchValue, String pattern, MappingMatch mappingType, String servletName) {
/*  91 */       this.matchValue = matchValue;
/*  92 */       this.pattern = pattern;
/*  93 */       this.mappingType = mappingType;
/*  94 */       this.servletName = servletName;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMatchValue() {
/*  99 */       return this.matchValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPattern() {
/* 104 */       return this.pattern;
/*     */     }
/*     */ 
/*     */     
/*     */     public MappingMatch getMappingMatch() {
/* 109 */       return this.mappingType;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getServletName() {
/* 114 */       return this.servletName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\core\ApplicationMapping.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */