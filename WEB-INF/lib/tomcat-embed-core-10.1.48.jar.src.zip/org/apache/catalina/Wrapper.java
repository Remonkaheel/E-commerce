package org.apache.catalina;

import jakarta.servlet.MultipartConfigElement;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.UnavailableException;

public interface Wrapper extends Container {
  public static final String ADD_MAPPING_EVENT = "addMapping";
  
  public static final String REMOVE_MAPPING_EVENT = "removeMapping";
  
  long getAvailable();
  
  void setAvailable(long paramLong);
  
  int getLoadOnStartup();
  
  void setLoadOnStartup(int paramInt);
  
  String getRunAs();
  
  void setRunAs(String paramString);
  
  String getServletClass();
  
  void setServletClass(String paramString);
  
  String[] getServletMethods() throws ServletException;
  
  boolean isUnavailable();
  
  Servlet getServlet();
  
  void setServlet(Servlet paramServlet);
  
  void addInitParameter(String paramString1, String paramString2);
  
  void addMapping(String paramString);
  
  void addSecurityReference(String paramString1, String paramString2);
  
  Servlet allocate() throws ServletException;
  
  void deallocate(Servlet paramServlet) throws ServletException;
  
  String findInitParameter(String paramString);
  
  String[] findInitParameters();
  
  String[] findMappings();
  
  String findSecurityReference(String paramString);
  
  String[] findSecurityReferences();
  
  void incrementErrorCount();
  
  void load() throws ServletException;
  
  void removeInitParameter(String paramString);
  
  void removeMapping(String paramString);
  
  void removeSecurityReference(String paramString);
  
  void unavailable(UnavailableException paramUnavailableException);
  
  void unload() throws ServletException;
  
  MultipartConfigElement getMultipartConfigElement();
  
  void setMultipartConfigElement(MultipartConfigElement paramMultipartConfigElement);
  
  boolean isAsyncSupported();
  
  void setAsyncSupported(boolean paramBoolean);
  
  boolean isEnabled();
  
  void setEnabled(boolean paramBoolean);
  
  boolean isOverridable();
  
  void setOverridable(boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Wrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */