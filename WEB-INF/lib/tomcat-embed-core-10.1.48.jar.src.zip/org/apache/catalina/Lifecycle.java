package org.apache.catalina;

public interface Lifecycle {
  public static final String BEFORE_INIT_EVENT = "before_init";
  
  public static final String AFTER_INIT_EVENT = "after_init";
  
  public static final String START_EVENT = "start";
  
  public static final String BEFORE_START_EVENT = "before_start";
  
  public static final String AFTER_START_EVENT = "after_start";
  
  public static final String STOP_EVENT = "stop";
  
  public static final String BEFORE_STOP_EVENT = "before_stop";
  
  public static final String AFTER_STOP_EVENT = "after_stop";
  
  public static final String AFTER_DESTROY_EVENT = "after_destroy";
  
  public static final String BEFORE_DESTROY_EVENT = "before_destroy";
  
  public static final String PERIODIC_EVENT = "periodic";
  
  public static final String CONFIGURE_START_EVENT = "configure_start";
  
  public static final String CONFIGURE_STOP_EVENT = "configure_stop";
  
  void addLifecycleListener(LifecycleListener paramLifecycleListener);
  
  LifecycleListener[] findLifecycleListeners();
  
  void removeLifecycleListener(LifecycleListener paramLifecycleListener);
  
  void init() throws LifecycleException;
  
  void start() throws LifecycleException;
  
  void stop() throws LifecycleException;
  
  void destroy() throws LifecycleException;
  
  LifecycleState getState();
  
  String getStateName();
  
  public static interface SingleUse {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Lifecycle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */