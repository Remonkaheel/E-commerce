package org.apache.catalina;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;

public interface AccessLog {
  public static final String REMOTE_ADDR_ATTRIBUTE = "org.apache.catalina.AccessLog.RemoteAddr";
  
  public static final String REMOTE_HOST_ATTRIBUTE = "org.apache.catalina.AccessLog.RemoteHost";
  
  public static final String PROTOCOL_ATTRIBUTE = "org.apache.catalina.AccessLog.Protocol";
  
  public static final String SERVER_NAME_ATTRIBUTE = "org.apache.catalina.AccessLog.ServerName";
  
  public static final String SERVER_PORT_ATTRIBUTE = "org.apache.catalina.AccessLog.ServerPort";
  
  void log(Request paramRequest, Response paramResponse, long paramLong);
  
  void setRequestAttributesEnabled(boolean paramBoolean);
  
  boolean getRequestAttributesEnabled();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\AccessLog.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */