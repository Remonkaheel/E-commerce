package org.apache.catalina;

import java.util.Set;

public interface DistributedManager {
  int getActiveSessionsFull();
  
  Set<String> getSessionIdsFull();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\DistributedManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */