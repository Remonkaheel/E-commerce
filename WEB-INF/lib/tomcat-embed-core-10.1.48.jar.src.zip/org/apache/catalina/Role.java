package org.apache.catalina;

import java.security.Principal;

public interface Role extends Principal {
  String getDescription();
  
  void setDescription(String paramString);
  
  String getRolename();
  
  void setRolename(String paramString);
  
  UserDatabase getUserDatabase();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Role.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */