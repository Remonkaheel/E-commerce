package org.apache.catalina;

public interface ContainerServlet {
  Wrapper getWrapper();
  
  void setWrapper(Wrapper paramWrapper);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\ContainerServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */