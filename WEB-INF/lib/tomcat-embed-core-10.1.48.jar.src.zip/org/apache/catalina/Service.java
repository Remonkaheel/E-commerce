package org.apache.catalina;

import org.apache.catalina.connector.Connector;
import org.apache.catalina.mapper.Mapper;

public interface Service extends Lifecycle {
  Engine getContainer();
  
  void setContainer(Engine paramEngine);
  
  String getName();
  
  void setName(String paramString);
  
  Server getServer();
  
  void setServer(Server paramServer);
  
  ClassLoader getParentClassLoader();
  
  void setParentClassLoader(ClassLoader paramClassLoader);
  
  String getDomain();
  
  void addConnector(Connector paramConnector);
  
  Connector[] findConnectors();
  
  void removeConnector(Connector paramConnector);
  
  void addExecutor(Executor paramExecutor);
  
  Executor[] findExecutors();
  
  Executor getExecutor(String paramString);
  
  void removeExecutor(Executor paramExecutor);
  
  Mapper getMapper();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-core-10.1.48.jar!\org\apache\catalina\Service.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */