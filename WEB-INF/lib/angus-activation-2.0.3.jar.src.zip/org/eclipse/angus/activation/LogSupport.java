/*    */ package org.eclipse.angus.activation;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LogSupport
/*    */ {
/*    */   private static boolean debug = false;
/*    */   private static Logger logger;
/* 22 */   private static final Level level = Level.FINE;
/*    */   
/*    */   static {
/*    */     try {
/* 26 */       debug = Boolean.getBoolean("angus.activation.debug");
/* 27 */     } catch (Throwable throwable) {}
/*    */ 
/*    */     
/* 30 */     logger = Logger.getLogger("angus.activation");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void log(String msg) {
/* 41 */     if (!isLoggable()) {
/*    */       return;
/*    */     }
/* 44 */     if (debug)
/* 45 */       System.out.println(msg); 
/* 46 */     logger.log(level, msg);
/*    */   }
/*    */   
/*    */   public static void log(String msg, Throwable t) {
/* 50 */     if (!isLoggable()) {
/*    */       return;
/*    */     }
/* 53 */     if (debug)
/* 54 */       System.out.println(msg + "; Exception: " + t); 
/* 55 */     logger.log(level, msg, t);
/*    */   }
/*    */   
/*    */   public static boolean isLoggable() {
/* 59 */     return (debug || logger.isLoggable(level));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\LogSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */