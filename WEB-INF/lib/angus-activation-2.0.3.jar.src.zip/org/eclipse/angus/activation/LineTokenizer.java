/*     */ package org.eclipse.angus.activation;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LineTokenizer
/*     */ {
/*     */   private int currentPosition;
/*     */   private int maxPosition;
/*     */   private String str;
/* 222 */   private Vector<String> stack = new Vector<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String singles = "=";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineTokenizer(String str) {
/* 232 */     this.currentPosition = 0;
/* 233 */     this.str = str;
/* 234 */     this.maxPosition = str.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void skipWhiteSpace() {
/* 241 */     while (this.currentPosition < this.maxPosition && 
/* 242 */       Character.isWhitespace(this.str.charAt(this.currentPosition))) {
/* 243 */       this.currentPosition++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 254 */     if (this.stack.size() > 0)
/* 255 */       return true; 
/* 256 */     skipWhiteSpace();
/* 257 */     return (this.currentPosition < this.maxPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() {
/* 268 */     int size = this.stack.size();
/* 269 */     if (size > 0) {
/* 270 */       String t = this.stack.elementAt(size - 1);
/* 271 */       this.stack.removeElementAt(size - 1);
/* 272 */       return t;
/*     */     } 
/* 274 */     skipWhiteSpace();
/*     */     
/* 276 */     if (this.currentPosition >= this.maxPosition) {
/* 277 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 280 */     int start = this.currentPosition;
/* 281 */     char c = this.str.charAt(start);
/* 282 */     if (c == '"') {
/* 283 */       this.currentPosition++;
/* 284 */       boolean filter = false;
/* 285 */       while (this.currentPosition < this.maxPosition) {
/* 286 */         c = this.str.charAt(this.currentPosition++);
/* 287 */         if (c == '\\') {
/* 288 */           this.currentPosition++;
/* 289 */           filter = true; continue;
/* 290 */         }  if (c == '"') {
/*     */           String s;
/*     */           
/* 293 */           if (filter) {
/* 294 */             StringBuilder sb = new StringBuilder();
/* 295 */             for (int i = start + 1; i < this.currentPosition - 1; i++) {
/* 296 */               c = this.str.charAt(i);
/* 297 */               if (c != '\\')
/* 298 */                 sb.append(c); 
/*     */             } 
/* 300 */             s = sb.toString();
/*     */           } else {
/* 302 */             s = this.str.substring(start + 1, this.currentPosition - 1);
/* 303 */           }  return s;
/*     */         } 
/*     */       } 
/* 306 */     } else if ("=".indexOf(c) >= 0) {
/* 307 */       this.currentPosition++;
/*     */     } else {
/* 309 */       while (this.currentPosition < this.maxPosition && "="
/* 310 */         .indexOf(this.str.charAt(this.currentPosition)) < 0 && 
/* 311 */         !Character.isWhitespace(this.str.charAt(this.currentPosition))) {
/* 312 */         this.currentPosition++;
/*     */       }
/*     */     } 
/* 315 */     return this.str.substring(start, this.currentPosition);
/*     */   }
/*     */   
/*     */   public void pushToken(String token) {
/* 319 */     this.stack.addElement(token);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\LineTokenizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */