/*     */ package org.eclipse.angus.activation;
/*     */ 
/*     */ import jakarta.activation.MimeTypeEntry;
/*     */ import jakarta.activation.MimeTypeRegistry;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeTypeFile
/*     */   implements MimeTypeRegistry
/*     */ {
/*  30 */   private String fname = null;
/*  31 */   private Hashtable<String, MimeTypeEntry> type_hash = new Hashtable<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeFile(String new_fname) throws IOException {
/*  40 */     File mime_file = null;
/*  41 */     FileReader fr = null;
/*     */     
/*  43 */     this.fname = new_fname;
/*     */     
/*  45 */     mime_file = new File(this.fname);
/*     */     
/*  47 */     fr = new FileReader(mime_file);
/*     */     
/*     */     try {
/*  50 */       parse(new BufferedReader(fr));
/*     */     } finally {
/*     */       try {
/*  53 */         fr.close();
/*  54 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeFile(InputStream is) throws IOException {
/*  61 */     parse(new BufferedReader(new InputStreamReader(is, StandardCharsets.ISO_8859_1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeFile() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeEntry getMimeTypeEntry(String file_ext) {
/*  77 */     return this.type_hash.get(file_ext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMIMETypeString(String file_ext) {
/*  87 */     MimeTypeEntry entry = getMimeTypeEntry(file_ext);
/*     */     
/*  89 */     if (entry != null) {
/*  90 */       return entry.getMIMEType();
/*     */     }
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToRegistry(String mime_types) {
/*     */     try {
/* 114 */       parse(new BufferedReader(new StringReader(mime_types)));
/* 115 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(BufferedReader buf_reader) throws IOException {
/* 124 */     String line = null, prev = null;
/*     */     
/* 126 */     while ((line = buf_reader.readLine()) != null) {
/* 127 */       if (prev == null) {
/* 128 */         prev = line;
/*     */       } else {
/* 130 */         prev = prev + line;
/* 131 */       }  int end = prev.length();
/* 132 */       if (prev.length() > 0 && prev.charAt(end - 1) == '\\') {
/* 133 */         prev = prev.substring(0, end - 1);
/*     */         continue;
/*     */       } 
/* 136 */       parseEntry(prev);
/* 137 */       prev = null;
/*     */     } 
/* 139 */     if (prev != null) {
/* 140 */       parseEntry(prev);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseEntry(String line) {
/* 147 */     String mime_type = null;
/* 148 */     String file_ext = null;
/* 149 */     line = line.trim();
/*     */     
/* 151 */     if (line.length() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 155 */     if (line.charAt(0) == '#') {
/*     */       return;
/*     */     }
/*     */     
/* 159 */     if (line.indexOf('=') > 0) {
/*     */       
/* 161 */       LineTokenizer lt = new LineTokenizer(line);
/* 162 */       while (lt.hasMoreTokens()) {
/* 163 */         String name = lt.nextToken();
/* 164 */         String value = null;
/* 165 */         if (lt.hasMoreTokens() && lt.nextToken().equals("=") && lt
/* 166 */           .hasMoreTokens())
/* 167 */           value = lt.nextToken(); 
/* 168 */         if (value == null) {
/* 169 */           LogSupport.log("Bad .jakarta.mime.types entry: " + line);
/*     */           return;
/*     */         } 
/* 172 */         if (name.equals("type")) {
/* 173 */           mime_type = value; continue;
/* 174 */         }  if (name.equals("exts")) {
/* 175 */           StringTokenizer st = new StringTokenizer(value, ",");
/* 176 */           while (st.hasMoreTokens()) {
/* 177 */             file_ext = st.nextToken();
/* 178 */             MimeTypeEntry entry = new MimeTypeEntry(mime_type, file_ext);
/*     */             
/* 180 */             this.type_hash.put(file_ext, entry);
/* 181 */             LogSupport.log("Added: " + entry);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 188 */       StringTokenizer strtok = new StringTokenizer(line);
/* 189 */       int num_tok = strtok.countTokens();
/*     */       
/* 191 */       if (num_tok == 0) {
/*     */         return;
/*     */       }
/* 194 */       mime_type = strtok.nextToken();
/*     */       
/* 196 */       while (strtok.hasMoreTokens()) {
/* 197 */         MimeTypeEntry entry = null;
/*     */         
/* 199 */         file_ext = strtok.nextToken();
/* 200 */         entry = new MimeTypeEntry(mime_type, file_ext);
/* 201 */         this.type_hash.put(file_ext, entry);
/* 202 */         LogSupport.log("Added: " + entry);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\MimeTypeFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */