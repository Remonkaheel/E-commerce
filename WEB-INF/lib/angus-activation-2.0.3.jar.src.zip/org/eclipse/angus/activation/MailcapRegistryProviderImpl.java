/*    */ package org.eclipse.angus.activation;
/*    */ 
/*    */ import jakarta.activation.MailcapRegistry;
/*    */ import jakarta.activation.spi.MailcapRegistryProvider;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailcapRegistryProviderImpl
/*    */   implements MailcapRegistryProvider
/*    */ {
/*    */   public MailcapRegistry getByFileName(String name) throws IOException {
/* 29 */     return new MailcapFile(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public MailcapRegistry getByInputStream(InputStream inputStream) throws IOException {
/* 34 */     return new MailcapFile(inputStream);
/*    */   }
/*    */ 
/*    */   
/*    */   public MailcapRegistry getInMemory() {
/* 39 */     return new MailcapFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\MailcapRegistryProviderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */