/*     */ package org.eclipse.angus.activation.nativeimage;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.eclipse.angus.activation.MailcapFile;
/*     */ import org.graalvm.nativeimage.hosted.Feature;
/*     */ import org.graalvm.nativeimage.hosted.RuntimeReflection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AngusActivationFeature
/*     */   implements Feature
/*     */ {
/*  33 */   private static final boolean ENABLED = getOption("angus.activation.native-image.enable", true);
/*  34 */   private static final boolean DEBUG = getOption("angus.activation.native-image.trace", false);
/*     */   
/*  36 */   private static final List<String> RESOURCES = Arrays.asList(new String[] { "META-INF/jakarta.mailcap", "META-INF/jakarta.mailcap.default" });
/*  37 */   private static final List<String> RESOURCES_OLD = Arrays.asList(new String[] { "META-INF/mailcap", "META-INF/mailcap.default" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInConfiguration(Feature.IsInConfigurationAccess access) {
/*  47 */     return ENABLED;
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeAnalysis(Feature.BeforeAnalysisAccess access) {
/*  52 */     Set<String> commands = commands(access, RESOURCES);
/*  53 */     if (commands.isEmpty()) {
/*  54 */       commands = commands(access, RESOURCES_OLD);
/*     */     }
/*     */     
/*  57 */     commands.forEach(command -> {
/*     */           Class<?> cls = access.findClassByName(command);
/*     */           if (cls != null) {
/*     */             log(());
/*     */             try {
/*     */               RuntimeReflection.register(new Class[] { cls });
/*     */               RuntimeReflection.register(new Executable[] { cls.getConstructor(new Class[0]) });
/*  64 */             } catch (NoSuchMethodException e) {
/*     */               log(());
/*     */             } 
/*     */           } else {
/*     */             log(());
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   private static Set<String> commands(Feature.BeforeAnalysisAccess access, List<String> resources) {
/*  74 */     Set<String> commands = new HashSet<>();
/*  75 */     for (String resource : resources) {
/*  76 */       log(() -> "looking for " + resource);
/*     */       try {
/*  78 */         Enumeration<URL> urls = access.getApplicationClassLoader().getResources(resource);
/*  79 */         while (urls.hasMoreElements())
/*  80 */         { URL url = urls.nextElement();
/*  81 */           log(() -> "processing " + url);
/*  82 */           InputStream is = url.openStream(); 
/*  83 */           try { MailcapFile mf = new MailcapFile(is);
/*  84 */             for (String mimeType : mf.getMimeTypes()) {
/*  85 */               Map<String, List<String>> map = mf.getMailcapList(mimeType);
/*  86 */               if (map != null)
/*  87 */                 map.values().forEach(list -> {
/*     */                       Objects.requireNonNull(commands); list.forEach(commands::add);
/*  89 */                     });  map = mf.getMailcapFallbackList(mimeType);
/*  90 */               if (map != null)
/*  91 */                 map.values().forEach(list -> {
/*     */                       Objects.requireNonNull(commands); list.forEach(commands::add);
/*     */                     }); 
/*  94 */             }  if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/*     */               try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } 
/*  96 */       } catch (IOException ioe) {
/*  97 */         throw new RuntimeException(ioe);
/*     */       } 
/*     */     } 
/* 100 */     return commands;
/*     */   }
/*     */   
/*     */   private static boolean getOption(String name, boolean def) {
/* 104 */     String prop = System.getProperty(name);
/* 105 */     if (prop == null) {
/* 106 */       return def;
/*     */     }
/* 108 */     return Boolean.parseBoolean(name);
/*     */   }
/*     */   
/*     */   private static void log(Supplier<String> msg) {
/* 112 */     if (DEBUG)
/* 113 */       System.out.println(msg.get()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\nativeimage\AngusActivationFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */