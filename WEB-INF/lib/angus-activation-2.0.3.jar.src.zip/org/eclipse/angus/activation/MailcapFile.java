/*     */ package org.eclipse.angus.activation;
/*     */ 
/*     */ import jakarta.activation.MailcapRegistry;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapFile
/*     */   implements MailcapRegistry
/*     */ {
/*  40 */   private Map<String, Map<String, List<String>>> type_hash = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private Map<String, Map<String, List<String>>> fallback_hash = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private Map<String, List<String>> native_commands = new HashMap<>();
/*     */   
/*     */   private static boolean addReverse = false;
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       addReverse = Boolean.getBoolean("angus.activation.addreverse");
/*  58 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapFile(String new_fname) throws IOException {
/*  70 */     LogSupport.log("new MailcapFile: file " + new_fname);
/*  71 */     BufferedReader reader = new BufferedReader(new FileReader(new_fname)); try {
/*  72 */       parse(reader);
/*  73 */       reader.close();
/*     */     } catch (Throwable throwable) {
/*     */       try {
/*     */         reader.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       } 
/*     */       throw throwable;
/*     */     } 
/*     */   } public MailcapFile(InputStream is) throws IOException {
/*  83 */     LogSupport.log("new MailcapFile: InputStream");
/*  84 */     parse(new BufferedReader(new InputStreamReader(is, StandardCharsets.ISO_8859_1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapFile() {
/*  91 */     LogSupport.log("new MailcapFile: default");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getMailcapList(String mime_type) {
/* 106 */     return getMailcapList(mime_type, this.type_hash);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getMailcapFallbackList(String mime_type) {
/* 121 */     return getMailcapList(mime_type, this.fallback_hash);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, List<String>> getMailcapList(String mime_type, Map<String, Map<String, List<String>>> db) {
/* 137 */     Map<String, List<String>> search_result = null;
/* 138 */     Map<String, List<String>> wildcard_result = null;
/*     */ 
/*     */     
/* 141 */     search_result = db.get(mime_type);
/*     */ 
/*     */     
/* 144 */     int separator = mime_type.indexOf('/');
/* 145 */     String subtype = mime_type.substring(separator + 1);
/* 146 */     if (!subtype.equals("*")) {
/* 147 */       String type = mime_type.substring(0, separator + 1) + "*";
/* 148 */       wildcard_result = db.get(type);
/*     */       
/* 150 */       if (wildcard_result != null)
/* 151 */         if (search_result != null) {
/*     */           
/* 153 */           search_result = mergeResults(search_result, wildcard_result);
/*     */         } else {
/* 155 */           search_result = wildcard_result;
/*     */         }  
/*     */     } 
/* 158 */     return search_result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMimeTypes() {
/* 167 */     Set<String> types = new HashSet<>(this.type_hash.keySet());
/* 168 */     types.addAll(this.fallback_hash.keySet());
/* 169 */     types.addAll(this.native_commands.keySet());
/* 170 */     String[] mts = new String[types.size()];
/* 171 */     mts = types.<String>toArray(mts);
/* 172 */     return mts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getNativeCommands(String mime_type) {
/* 182 */     String[] cmds = null;
/* 183 */     List<String> v = this.native_commands.get(mime_type.toLowerCase(Locale.ENGLISH));
/* 184 */     if (v != null) {
/* 185 */       cmds = new String[v.size()];
/* 186 */       cmds = v.<String>toArray(cmds);
/*     */     } 
/* 188 */     return cmds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, List<String>> mergeResults(Map<String, List<String>> first, Map<String, List<String>> second) {
/* 198 */     Iterator<String> verb_enum = second.keySet().iterator();
/* 199 */     Map<String, List<String>> clonedHash = new HashMap<>(first);
/*     */ 
/*     */     
/* 202 */     while (verb_enum.hasNext()) {
/* 203 */       String verb = verb_enum.next();
/* 204 */       List<String> cmdVector = clonedHash.get(verb);
/* 205 */       if (cmdVector == null) {
/* 206 */         clonedHash.put(verb, second.get(verb));
/*     */         continue;
/*     */       } 
/* 209 */       List<String> oldV = second.get(verb);
/* 210 */       cmdVector = new ArrayList<>(cmdVector);
/* 211 */       cmdVector.addAll(oldV);
/* 212 */       clonedHash.put(verb, cmdVector);
/*     */     } 
/*     */     
/* 215 */     return clonedHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToMailcap(String mail_cap) {
/* 231 */     LogSupport.log("appendToMailcap: " + mail_cap);
/*     */     try {
/* 233 */       parse(new BufferedReader(new StringReader(mail_cap)));
/* 234 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(BufferedReader reader) throws IOException {
/* 243 */     String line = null;
/* 244 */     String continued = null;
/*     */     
/* 246 */     while ((line = reader.readLine()) != null) {
/*     */ 
/*     */       
/* 249 */       line = line.trim();
/*     */       
/*     */       try {
/* 252 */         if (line.charAt(0) == '#')
/*     */           continue; 
/* 254 */         if (line.charAt(line.length() - 1) == '\\') {
/* 255 */           if (continued != null) {
/* 256 */             continued = continued + line.substring(0, line.length() - 1); continue;
/*     */           } 
/* 258 */           continued = line.substring(0, line.length() - 1); continue;
/* 259 */         }  if (continued != null) {
/*     */           
/* 261 */           continued = continued + line;
/*     */           
/*     */           try {
/* 264 */             parseLine(continued);
/* 265 */           } catch (MailcapParseException mailcapParseException) {}
/*     */ 
/*     */           
/* 268 */           continued = null;
/*     */           continue;
/*     */         } 
/*     */         try {
/* 272 */           parseLine(line);
/*     */         }
/* 274 */         catch (MailcapParseException mailcapParseException) {}
/*     */ 
/*     */       
/*     */       }
/* 278 */       catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseLine(String mailcapEntry) throws MailcapParseException, IOException {
/* 295 */     MailcapTokenizer tokenizer = new MailcapTokenizer(mailcapEntry);
/* 296 */     tokenizer.setIsAutoquoting(false);
/*     */     
/* 298 */     LogSupport.log("parse: " + mailcapEntry);
/*     */     
/* 300 */     int currentToken = tokenizer.nextToken();
/* 301 */     if (currentToken != 2) {
/* 302 */       reportParseError(2, currentToken, tokenizer
/* 303 */           .getCurrentTokenValue());
/*     */     }
/*     */     
/* 306 */     String primaryType = tokenizer.getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
/* 307 */     String subType = "*";
/*     */ 
/*     */ 
/*     */     
/* 311 */     currentToken = tokenizer.nextToken();
/* 312 */     if (currentToken != 47 && currentToken != 59)
/*     */     {
/* 314 */       reportParseError(47, 59, currentToken, tokenizer
/*     */           
/* 316 */           .getCurrentTokenValue());
/*     */     }
/*     */ 
/*     */     
/* 320 */     if (currentToken == 47) {
/*     */       
/* 322 */       currentToken = tokenizer.nextToken();
/* 323 */       if (currentToken != 2) {
/* 324 */         reportParseError(2, currentToken, tokenizer
/* 325 */             .getCurrentTokenValue());
/*     */       }
/*     */       
/* 328 */       subType = tokenizer.getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
/*     */ 
/*     */       
/* 331 */       currentToken = tokenizer.nextToken();
/*     */     } 
/*     */     
/* 334 */     String mimeType = primaryType + "/" + subType;
/*     */     
/* 336 */     LogSupport.log("  Type: " + mimeType);
/*     */ 
/*     */     
/* 339 */     Map<String, List<String>> commands = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 342 */     if (currentToken != 59) {
/* 343 */       reportParseError(59, currentToken, tokenizer
/* 344 */           .getCurrentTokenValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 349 */     tokenizer.setIsAutoquoting(true);
/* 350 */     currentToken = tokenizer.nextToken();
/* 351 */     tokenizer.setIsAutoquoting(false);
/* 352 */     if (currentToken != 2 && currentToken != 59)
/*     */     {
/* 354 */       reportParseError(2, 59, currentToken, tokenizer
/*     */           
/* 356 */           .getCurrentTokenValue());
/*     */     }
/*     */     
/* 359 */     if (currentToken == 2) {
/*     */ 
/*     */       
/* 362 */       List<String> v = this.native_commands.get(mimeType);
/* 363 */       if (v == null) {
/* 364 */         v = new ArrayList<>();
/* 365 */         v.add(mailcapEntry);
/* 366 */         this.native_commands.put(mimeType, v);
/*     */       } else {
/*     */         
/* 369 */         v.add(mailcapEntry);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 374 */     if (currentToken != 59) {
/* 375 */       currentToken = tokenizer.nextToken();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 380 */     if (currentToken == 59) {
/* 381 */       boolean isFallback = false;
/*     */ 
/*     */ 
/*     */       
/*     */       do {
/* 386 */         currentToken = tokenizer.nextToken();
/* 387 */         if (currentToken != 2) {
/* 388 */           reportParseError(2, currentToken, tokenizer
/* 389 */               .getCurrentTokenValue());
/*     */         }
/*     */         
/* 392 */         String paramName = tokenizer.getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
/*     */ 
/*     */         
/* 395 */         currentToken = tokenizer.nextToken();
/* 396 */         if (currentToken != 61 && currentToken != 59 && currentToken != 5)
/*     */         {
/*     */           
/* 399 */           reportParseError(61, 59, 5, currentToken, tokenizer
/*     */ 
/*     */               
/* 402 */               .getCurrentTokenValue());
/*     */         }
/*     */ 
/*     */         
/* 406 */         if (currentToken != 61) {
/*     */           continue;
/*     */         }
/*     */         
/* 410 */         tokenizer.setIsAutoquoting(true);
/* 411 */         currentToken = tokenizer.nextToken();
/* 412 */         tokenizer.setIsAutoquoting(false);
/* 413 */         if (currentToken != 2) {
/* 414 */           reportParseError(2, currentToken, tokenizer
/* 415 */               .getCurrentTokenValue());
/*     */         }
/*     */         
/* 418 */         String paramValue = tokenizer.getCurrentTokenValue();
/*     */ 
/*     */         
/* 421 */         if (paramName.startsWith("x-java-")) {
/* 422 */           String commandName = paramName.substring(7);
/*     */ 
/*     */           
/* 425 */           if (commandName.equals("fallback-entry") && paramValue
/* 426 */             .equalsIgnoreCase("true")) {
/* 427 */             isFallback = true;
/*     */           }
/*     */           else {
/*     */             
/* 431 */             LogSupport.log("    Command: " + commandName + ", Class: " + paramValue);
/*     */             
/* 433 */             List<String> classes = commands.computeIfAbsent(commandName, k -> new ArrayList());
/* 434 */             if (addReverse) {
/* 435 */               classes.add(0, paramValue);
/*     */             } else {
/* 437 */               classes.add(paramValue);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 442 */         currentToken = tokenizer.nextToken();
/*     */       }
/* 444 */       while (currentToken == 59);
/*     */       
/* 446 */       Map<String, Map<String, List<String>>> masterHash = isFallback ? this.fallback_hash : this.type_hash;
/* 447 */       Map<String, List<String>> curcommands = masterHash.get(mimeType);
/* 448 */       if (curcommands == null) {
/* 449 */         masterHash.put(mimeType, commands);
/*     */       } else {
/* 451 */         LogSupport.log("Merging commands for type " + mimeType);
/*     */ 
/*     */         
/* 454 */         Iterator<String> cn = curcommands.keySet().iterator();
/* 455 */         while (cn.hasNext()) {
/* 456 */           String cmdName = cn.next();
/* 457 */           List<String> ccv = curcommands.get(cmdName);
/* 458 */           List<String> cv = commands.get(cmdName);
/* 459 */           if (cv == null) {
/*     */             continue;
/*     */           }
/* 462 */           Iterator<String> cvn = cv.iterator();
/* 463 */           while (cvn.hasNext()) {
/* 464 */             String clazz = cvn.next();
/* 465 */             if (!ccv.contains(clazz)) {
/* 466 */               if (addReverse) {
/* 467 */                 ccv.add(0, clazz); continue;
/*     */               } 
/* 469 */               ccv.add(clazz);
/*     */             } 
/*     */           } 
/*     */         } 
/* 473 */         cn = commands.keySet().iterator();
/* 474 */         while (cn.hasNext()) {
/* 475 */           String cmdName = cn.next();
/* 476 */           if (curcommands.containsKey(cmdName))
/*     */             continue; 
/* 478 */           List<String> cv = commands.get(cmdName);
/* 479 */           curcommands.put(cmdName, cv);
/*     */         } 
/*     */       } 
/* 482 */     } else if (currentToken != 5) {
/* 483 */       reportParseError(5, 59, currentToken, tokenizer
/*     */           
/* 485 */           .getCurrentTokenValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int expectedToken, int actualToken, String actualTokenValue) throws MailcapParseException {
/* 491 */     throw new MailcapParseException("Encountered a " + 
/* 492 */         MailcapTokenizer.nameForToken(actualToken) + " token (" + actualTokenValue + ") while expecting a " + 
/*     */         
/* 494 */         MailcapTokenizer.nameForToken(expectedToken) + " token.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int expectedToken, int otherExpectedToken, int actualToken, String actualTokenValue) throws MailcapParseException {
/* 500 */     throw new MailcapParseException("Encountered a " + 
/* 501 */         MailcapTokenizer.nameForToken(actualToken) + " token (" + actualTokenValue + ") while expecting a " + 
/*     */         
/* 503 */         MailcapTokenizer.nameForToken(expectedToken) + " or a " + 
/* 504 */         MailcapTokenizer.nameForToken(otherExpectedToken) + " token.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int expectedToken, int otherExpectedToken, int anotherExpectedToken, int actualToken, String actualTokenValue) throws MailcapParseException {
/* 510 */     throw new MailcapParseException("Encountered a " + 
/* 511 */         MailcapTokenizer.nameForToken(actualToken) + " token (" + actualTokenValue + ") while expecting a " + 
/*     */         
/* 513 */         MailcapTokenizer.nameForToken(expectedToken) + ", a " + 
/* 514 */         MailcapTokenizer.nameForToken(otherExpectedToken) + ", or a " + 
/* 515 */         MailcapTokenizer.nameForToken(anotherExpectedToken) + " token.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\MailcapFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */