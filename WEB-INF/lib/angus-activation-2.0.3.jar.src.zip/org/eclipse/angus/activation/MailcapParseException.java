/*    */ package org.eclipse.angus.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailcapParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -1445946122972156790L;
/*    */   
/*    */   public MailcapParseException() {}
/*    */   
/*    */   public MailcapParseException(String inInfo) {
/* 25 */     super(inInfo);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\MailcapParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */