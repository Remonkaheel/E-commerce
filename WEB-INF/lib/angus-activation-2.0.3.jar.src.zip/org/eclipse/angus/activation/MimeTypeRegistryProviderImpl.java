/*    */ package org.eclipse.angus.activation;
/*    */ 
/*    */ import jakarta.activation.MimeTypeRegistry;
/*    */ import jakarta.activation.spi.MimeTypeRegistryProvider;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeTypeRegistryProviderImpl
/*    */   implements MimeTypeRegistryProvider
/*    */ {
/*    */   public MimeTypeRegistry getByFileName(String name) throws IOException {
/* 28 */     return new MimeTypeFile(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public MimeTypeRegistry getByInputStream(InputStream inputStream) throws IOException {
/* 33 */     return new MimeTypeFile(inputStream);
/*    */   }
/*    */ 
/*    */   
/*    */   public MimeTypeRegistry getInMemory() {
/* 38 */     return new MimeTypeFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\org\eclipse\angus\activation\MimeTypeRegistryProviderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */