module org.eclipse.angus.activation {
  requires java.base;
  requires java.logging;
  requires transitive jakarta.activation;
  requires org.graalvm.sdk;
  
  exports org.eclipse.angus.activation;
  
  provides jakarta.activation.spi.MailcapRegistryProvider with org.eclipse.angus.activation.MailcapRegistryProviderImpl;
  provides jakarta.activation.spi.MimeTypeRegistryProvider with org.eclipse.angus.activation.MimeTypeRegistryProviderImpl;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\angus-activation-2.0.3.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */