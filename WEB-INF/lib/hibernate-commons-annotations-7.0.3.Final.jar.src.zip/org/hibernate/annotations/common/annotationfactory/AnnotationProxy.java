/*     */ package org.hibernate.annotations.common.annotationfactory;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotationProxy
/*     */   implements Annotation, InvocationHandler
/*     */ {
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   private final Map<Method, Object> values;
/*     */   
/*     */   public AnnotationProxy(AnnotationDescriptor descriptor) {
/*  50 */     this.annotationType = descriptor.type();
/*  51 */     this.values = getAnnotationValues(this.annotationType, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<Method, Object> getAnnotationValues(Class<? extends Annotation> annotationType, AnnotationDescriptor descriptor) {
/*  57 */     Map<Method, Object> result = new HashMap<>();
/*  58 */     int processedValuesFromDescriptor = 0;
/*  59 */     for (Method m : annotationType.getDeclaredMethods()) {
/*  60 */       if (descriptor.containsElement(m.getName())) {
/*  61 */         result.put(m, descriptor.valueOf(m.getName()));
/*  62 */         processedValuesFromDescriptor++;
/*     */       }
/*  64 */       else if (m.getDefaultValue() != null) {
/*  65 */         result.put(m, m.getDefaultValue());
/*     */       } else {
/*     */         
/*  68 */         throw new IllegalArgumentException("No value provided for " + m.getName());
/*     */       } 
/*     */     } 
/*  71 */     if (processedValuesFromDescriptor != descriptor.numberOfElements()) {
/*  72 */       throw new RuntimeException("Trying to instanciate " + annotationType + " with unknown elements");
/*     */     }
/*  74 */     return toSmallMap(result);
/*     */   }
/*     */   static <K, V> Map<K, V> toSmallMap(Map<K, V> map) {
/*     */     Map.Entry<K, V> entry;
/*  78 */     switch (map.size()) {
/*     */       case 0:
/*  80 */         return Collections.emptyMap();
/*     */       case 1:
/*  82 */         entry = map.entrySet().iterator().next();
/*  83 */         return Collections.singletonMap(entry.getKey(), entry.getValue());
/*     */     } 
/*  85 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  90 */     if (this.values.containsKey(method)) {
/*  91 */       return this.values.get(method);
/*     */     }
/*  93 */     return method.invoke(this, args);
/*     */   }
/*     */   
/*     */   public Class<? extends Annotation> annotationType() {
/*  97 */     return this.annotationType;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 101 */     StringBuilder result = new StringBuilder();
/* 102 */     result.append('@').append(annotationType().getName()).append('(');
/* 103 */     for (Method m : getRegisteredMethodsInAlphabeticalOrder()) {
/* 104 */       result.append(m.getName()).append('=').append(this.values.get(m)).append(", ");
/*     */     }
/*     */     
/* 107 */     if (this.values.size() > 0) {
/* 108 */       result.delete(result.length() - 2, result.length());
/* 109 */       result.append(")");
/*     */     } else {
/*     */       
/* 112 */       result.delete(result.length() - 1, result.length());
/*     */     } 
/*     */     
/* 115 */     return result.toString();
/*     */   }
/*     */   
/*     */   private SortedSet<Method> getRegisteredMethodsInAlphabeticalOrder() {
/* 119 */     SortedSet<Method> result = new TreeSet<>(new Comparator<Method>()
/*     */         {
/*     */           public int compare(Method o1, Method o2) {
/* 122 */             return o1.getName().compareTo(o2.getName());
/*     */           }
/*     */         });
/*     */     
/* 126 */     result.addAll(this.values.keySet());
/* 127 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\annotationfactory\AnnotationProxy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */