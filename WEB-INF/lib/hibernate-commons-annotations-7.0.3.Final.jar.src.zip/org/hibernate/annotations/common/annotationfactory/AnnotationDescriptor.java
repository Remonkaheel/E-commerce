/*    */ package org.hibernate.annotations.common.annotationfactory;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnnotationDescriptor
/*    */ {
/*    */   private final Class<? extends Annotation> type;
/*    */   private Map<String, Object> elements;
/*    */   
/*    */   public AnnotationDescriptor(Class<? extends Annotation> annotationType) {
/* 28 */     this.type = annotationType;
/*    */   }
/*    */   
/*    */   public void setValue(String elementName, Object value) {
/* 32 */     if (this.elements == null) {
/* 33 */       this.elements = new HashMap<>(4);
/*    */     }
/* 35 */     this.elements.put(elementName, value);
/*    */   }
/*    */   
/*    */   public Object valueOf(String elementName) {
/* 39 */     return (this.elements == null) ? null : this.elements.get(elementName);
/*    */   }
/*    */   
/*    */   public boolean containsElement(String elementName) {
/* 43 */     return (this.elements == null) ? false : this.elements.containsKey(elementName);
/*    */   }
/*    */   
/*    */   public int numberOfElements() {
/* 47 */     return (this.elements == null) ? 0 : this.elements.size();
/*    */   }
/*    */   
/*    */   public Class<? extends Annotation> type() {
/* 51 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\annotationfactory\AnnotationDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */