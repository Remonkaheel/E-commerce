/*    */ package org.hibernate.annotations.common.annotationfactory;
/*    */ 
/*    */ import java.lang.reflect.Proxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnnotationFactory
/*    */ {
/*    */   public static <T extends java.lang.annotation.Annotation> T create(AnnotationDescriptor descriptor) {
/* 31 */     return create(descriptor, descriptor.type().getClassLoader());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends java.lang.annotation.Annotation> T createUsingTccl(AnnotationDescriptor descriptor) {
/* 43 */     return create(descriptor, Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends java.lang.annotation.Annotation> T create(AnnotationDescriptor descriptor, ClassLoader classLoader) {
/* 56 */     return (T)Proxy.newProxyInstance(classLoader, new Class[] { descriptor
/*    */           
/* 58 */           .type() }, new AnnotationProxy(descriptor));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\annotationfactory\AnnotationFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */