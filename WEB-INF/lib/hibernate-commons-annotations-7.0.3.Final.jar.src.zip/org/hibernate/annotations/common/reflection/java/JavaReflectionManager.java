/*     */ package org.hibernate.annotations.common.reflection.java;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.hibernate.annotations.common.reflection.AnnotationReader;
/*     */ import org.hibernate.annotations.common.reflection.MetadataProvider;
/*     */ import org.hibernate.annotations.common.reflection.MetadataProviderInjector;
/*     */ import org.hibernate.annotations.common.reflection.ReflectionManager;
/*     */ import org.hibernate.annotations.common.reflection.XClass;
/*     */ import org.hibernate.annotations.common.reflection.XMethod;
/*     */ import org.hibernate.annotations.common.reflection.XPackage;
/*     */ import org.hibernate.annotations.common.reflection.XProperty;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.IdentityTypeEnvironment;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironmentFactory;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeSwitch;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaReflectionManager
/*     */   implements ReflectionManager, MetadataProviderInjector
/*     */ {
/*  39 */   private static final boolean METADATA_CACHE_DIAGNOSTICS = Boolean.getBoolean("org.hibernate.annotations.common.METADATA_CACHE_DIAGNOSTICS");
/*     */   
/*     */   private MetadataProvider metadataProvider;
/*     */   
/*  43 */   private final AtomicBoolean empty = new AtomicBoolean(true);
/*     */   
/*     */   public MetadataProvider getMetadataProvider() {
/*  46 */     if (this.metadataProvider == null) {
/*  47 */       setMetadataProvider(new JavaMetadataProvider());
/*     */     }
/*  49 */     return this.metadataProvider;
/*     */   }
/*     */   
/*     */   public void setMetadataProvider(MetadataProvider metadataProvider) {
/*  53 */     this.metadataProvider = metadataProvider;
/*     */   }
/*     */   
/*  56 */   private final TypeEnvironmentMap<Class, JavaXClass> xClasses = new TypeEnvironmentMap<>(this::javaXClassConstruction);
/*     */   
/*     */   private Map<Package, JavaXPackage> packagesToXPackages;
/*     */   
/*     */   private JavaXClass javaXClassConstruction(Class classType, TypeEnvironment typeEnvironment) {
/*  61 */     used();
/*  62 */     return new JavaXClass(classType, typeEnvironment, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  67 */   private final TypeEnvironmentMap<Member, JavaXProperty> xProperties = new TypeEnvironmentMap<>(this::javaXPropertyConstruction);
/*     */   
/*     */   private JavaXProperty javaXPropertyConstruction(Member member, TypeEnvironment typeEnvironment) {
/*  70 */     used();
/*  71 */     return JavaXProperty.create(member, typeEnvironment, this);
/*     */   }
/*     */   
/*  74 */   private final TypeEnvironmentMap<Member, JavaXMethod> xMethods = new TypeEnvironmentMap<>(this::javaJavaXMethodConstruction);
/*     */   
/*     */   private JavaXMethod javaJavaXMethodConstruction(Member member, TypeEnvironment typeEnvironment) {
/*  77 */     used();
/*  78 */     return JavaXMethod.create(member, typeEnvironment, this);
/*     */   }
/*     */   
/*     */   public XClass toXClass(Class clazz) {
/*  82 */     return toXClass(clazz, IdentityTypeEnvironment.INSTANCE);
/*     */   }
/*     */   
/*     */   public Class toClass(XClass xClazz) {
/*  86 */     if (!(xClazz instanceof JavaXClass)) {
/*  87 */       throw new IllegalArgumentException("XClass not coming from this ReflectionManager implementation");
/*     */     }
/*  89 */     return (Class)((JavaXClass)xClazz).toAnnotatedElement();
/*     */   }
/*     */   
/*     */   public Method toMethod(XMethod xMethod) {
/*  93 */     if (!(xMethod instanceof JavaXMethod)) {
/*  94 */       throw new IllegalArgumentException("XMethod not coming from this ReflectionManager implementation");
/*     */     }
/*  96 */     return (Method)((JavaXAnnotatedElement)xMethod).toAnnotatedElement();
/*     */   }
/*     */   
/*     */   XClass toXClass(Type t, final TypeEnvironment context) {
/* 100 */     return (XClass)(new TypeSwitch<XClass>()
/*     */       {
/*     */         public XClass caseClass(Class classType) {
/* 103 */           return JavaReflectionManager.this.xClasses.getOrCompute(context, classType);
/*     */         }
/*     */ 
/*     */         
/*     */         public XClass caseParameterizedType(ParameterizedType parameterizedType) {
/* 108 */           return JavaReflectionManager.this.toXClass(parameterizedType.getRawType(), 
/* 109 */               TypeEnvironmentFactory.getEnvironment(parameterizedType, context));
/*     */         }
/* 112 */       }).doSwitch(context.bind(t));
/*     */   }
/*     */ 
/*     */   
/*     */   public XPackage toXPackage(Package pkg) {
/* 117 */     Map<Package, JavaXPackage> packagesToXPackagesMap = getPackagesToXPackagesMap();
/* 118 */     JavaXPackage xPackage = packagesToXPackagesMap.get(pkg);
/* 119 */     if (xPackage == null) {
/* 120 */       xPackage = new JavaXPackage(pkg, this);
/* 121 */       used();
/* 122 */       packagesToXPackagesMap.put(pkg, xPackage);
/*     */     } 
/* 124 */     return xPackage;
/*     */   }
/*     */   
/*     */   private Map<Package, JavaXPackage> getPackagesToXPackagesMap() {
/* 128 */     if (this.packagesToXPackages == null) {
/* 129 */       this.packagesToXPackages = new HashMap<>(8, 0.5F);
/*     */     }
/* 131 */     return this.packagesToXPackages;
/*     */   }
/*     */   
/*     */   XProperty getXProperty(Member member, TypeEnvironment context) {
/* 135 */     return this.xProperties.getOrCompute(context, member);
/*     */   }
/*     */   
/*     */   XMethod getXMethod(Member member, TypeEnvironment context) {
/* 139 */     return this.xMethods.getOrCompute(context, member);
/*     */   }
/*     */   
/*     */   TypeEnvironment getTypeEnvironment(Type t) {
/* 143 */     return (TypeEnvironment)(new TypeSwitch<TypeEnvironment>()
/*     */       {
/*     */         public TypeEnvironment caseClass(Class classType) {
/* 146 */           return TypeEnvironmentFactory.getEnvironment(classType);
/*     */         }
/*     */ 
/*     */         
/*     */         public TypeEnvironment caseParameterizedType(ParameterizedType parameterizedType) {
/* 151 */           return TypeEnvironmentFactory.getEnvironment(parameterizedType);
/*     */         }
/*     */ 
/*     */         
/*     */         public TypeEnvironment defaultCase(Type type) {
/* 156 */           return IdentityTypeEnvironment.INSTANCE;
/*     */         }
/* 158 */       }).doSwitch(t);
/*     */   }
/*     */   
/*     */   public JavaXType toXType(TypeEnvironment context, Type propType) {
/* 162 */     Type boundType = toApproximatingEnvironment(context).bind(propType);
/* 163 */     if (TypeUtils.isArray(boundType)) {
/* 164 */       return new JavaXArrayType(propType, context, this);
/*     */     }
/* 166 */     if (TypeUtils.isCollection(boundType)) {
/* 167 */       return new JavaXCollectionType(propType, context, this);
/*     */     }
/* 169 */     if (TypeUtils.isSimple(boundType)) {
/* 170 */       return new JavaXSimpleType(propType, context, this);
/*     */     }
/* 172 */     throw new IllegalArgumentException("No PropertyTypeExtractor available for type void ");
/*     */   }
/*     */ 
/*     */   
/*     */   public Type toType(XClass xClazz) {
/* 177 */     if (!(xClazz instanceof JavaXClass)) {
/* 178 */       throw new IllegalArgumentException("XClass not coming from this ReflectionManager implementation");
/*     */     }
/* 180 */     JavaXClass javaXClazz = (JavaXClass)xClazz;
/* 181 */     final Class<?> clazz = javaXClazz.toClass();
/* 182 */     final TypeVariable[] typeArguments = (TypeVariable[])clazz.getTypeParameters();
/* 183 */     if (arrayOfTypeVariable.length == 0) {
/* 184 */       return clazz;
/*     */     }
/* 186 */     return javaXClazz.getTypeEnvironment().bind(new ParameterizedType()
/*     */         {
/*     */           public Type[] getActualTypeArguments()
/*     */           {
/* 190 */             return typeArguments;
/*     */           }
/*     */ 
/*     */           
/*     */           public Type getRawType() {
/* 195 */             return clazz;
/*     */           }
/*     */ 
/*     */           
/*     */           public Type getOwnerType() {
/* 200 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(XClass class1, Class class2) {
/* 207 */     if (class1 == null) {
/* 208 */       return (class2 == null);
/*     */     }
/* 210 */     return ((JavaXClass)class1).toClass().equals(class2);
/*     */   }
/*     */   
/*     */   public TypeEnvironment toApproximatingEnvironment(TypeEnvironment context) {
/* 214 */     return TypeEnvironmentFactory.toApproximatingEnvironment(context);
/*     */   }
/*     */   
/*     */   public AnnotationReader buildAnnotationReader(AnnotatedElement annotatedElement) {
/* 218 */     return getMetadataProvider().getAnnotationReader(annotatedElement);
/*     */   }
/*     */   
/*     */   public Map getDefaults() {
/* 222 */     return getMetadataProvider().getDefaults();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 227 */     boolean wasEmpty = this.empty.getAndSet(true);
/* 228 */     if (!wasEmpty) {
/* 229 */       this.xClasses.clear();
/* 230 */       this.packagesToXPackages = null;
/* 231 */       this.xProperties.clear();
/* 232 */       this.xMethods.clear();
/* 233 */       if (METADATA_CACHE_DIAGNOSTICS) {
/* 234 */         (new RuntimeException("Diagnostics message : Caches now empty")).printStackTrace();
/*     */       }
/*     */     } 
/* 237 */     if (this.metadataProvider != null) {
/* 238 */       this.metadataProvider.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void used() {
/* 243 */     boolean wasEmpty = this.empty.getAndSet(false);
/* 244 */     if (wasEmpty && METADATA_CACHE_DIAGNOSTICS)
/* 245 */       (new RuntimeException("Diagnostics message : Caches now being used")).printStackTrace(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaReflectionManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */