package org.hibernate.annotations.common.reflection.java;

import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;

@FunctionalInterface
interface XTypeConstruction<K, V> {
  V createInstance(K paramK, TypeEnvironment paramTypeEnvironment);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\XTypeConstruction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */