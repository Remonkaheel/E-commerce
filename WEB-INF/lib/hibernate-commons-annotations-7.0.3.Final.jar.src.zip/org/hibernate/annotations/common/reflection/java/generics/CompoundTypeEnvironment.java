/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompoundTypeEnvironment
/*    */   implements TypeEnvironment
/*    */ {
/*    */   private final TypeEnvironment f;
/*    */   private final TypeEnvironment g;
/*    */   private final int hashCode;
/*    */   
/*    */   public static TypeEnvironment create(TypeEnvironment f, TypeEnvironment g) {
/* 22 */     if (g == IdentityTypeEnvironment.INSTANCE)
/* 23 */       return f; 
/* 24 */     if (f == IdentityTypeEnvironment.INSTANCE)
/* 25 */       return g; 
/* 26 */     return new CompoundTypeEnvironment(f, g);
/*    */   }
/*    */   
/*    */   private CompoundTypeEnvironment(TypeEnvironment f, TypeEnvironment g) {
/* 30 */     this.f = f;
/* 31 */     this.g = g;
/* 32 */     this.hashCode = doHashCode(f, g);
/*    */   }
/*    */   
/*    */   public Type bind(Type type) {
/* 36 */     return this.f.bind(this.g.bind(type));
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     if (this == o) return true; 
/* 41 */     if (!(o instanceof CompoundTypeEnvironment)) return false;
/*    */     
/* 43 */     CompoundTypeEnvironment that = (CompoundTypeEnvironment)o;
/*    */     
/* 45 */     if (differentHashCode(that)) return false;
/*    */     
/* 47 */     if (!this.f.equals(that.f)) return false; 
/* 48 */     return this.g.equals(that.g);
/*    */   }
/*    */   
/*    */   private boolean differentHashCode(CompoundTypeEnvironment that) {
/* 52 */     return (this.hashCode != that.hashCode);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static int doHashCode(TypeEnvironment f, TypeEnvironment g) {
/* 59 */     int result = f.hashCode();
/* 60 */     result = 29 * result + g.hashCode();
/* 61 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 66 */     return this.hashCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return this.f.toString() + "(" + this.f.toString() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\CompoundTypeEnvironment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */