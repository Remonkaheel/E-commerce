/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TypeFactory
/*    */ {
/*    */   static ParameterizedType createParameterizedType(Type rawType, Type[] substTypeArgs, Type ownerType) {
/* 22 */     return new ParameterizedTypeImpl(rawType, substTypeArgs, ownerType);
/*    */   }
/*    */   
/*    */   static Type createArrayType(Type componentType) {
/* 26 */     if (componentType instanceof Class) {
/* 27 */       return Array.newInstance((Class)componentType, 0).getClass();
/*    */     }
/* 29 */     return createGenericArrayType(componentType);
/*    */   }
/*    */   
/*    */   private static GenericArrayType createGenericArrayType(Type componentType) {
/* 33 */     return new GenericArrayTypeImpl(componentType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\TypeFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */