/*     */ package org.hibernate.annotations.common.reflection.java.generics;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ApproximatingTypeEnvironment
/*     */   implements TypeEnvironment
/*     */ {
/*     */   public Type bind(Type type) {
/*  47 */     Type result = fineApproximation(type);
/*  48 */     assert TypeUtils.isResolved(result);
/*  49 */     return result;
/*     */   }
/*     */   
/*     */   private Type fineApproximation(Type type) {
/*  53 */     return (new TypeSwitch<Type>() {
/*     */         public Type caseWildcardType(WildcardType wildcardType) {
/*  55 */           return wildcardType;
/*     */         }
/*     */ 
/*     */         
/*     */         public Type caseClass(Class classType) {
/*  60 */           return classType;
/*     */         }
/*     */ 
/*     */         
/*     */         public Type caseGenericArrayType(GenericArrayType genericArrayType) {
/*  65 */           if (TypeUtils.isResolved(genericArrayType)) {
/*  66 */             return genericArrayType;
/*     */           }
/*  68 */           Type componentType = genericArrayType.getGenericComponentType();
/*  69 */           Type boundComponentType = ApproximatingTypeEnvironment.this.bind(componentType);
/*  70 */           if (boundComponentType instanceof Class) {
/*  71 */             return Array.newInstance((Class)boundComponentType, 0).getClass();
/*     */           }
/*     */ 
/*     */           
/*  75 */           return Object[].class;
/*     */         }
/*     */ 
/*     */         
/*     */         public Type caseParameterizedType(ParameterizedType parameterizedType) {
/*  80 */           if (TypeUtils.isResolved(parameterizedType)) {
/*  81 */             return parameterizedType;
/*     */           }
/*     */           
/*  84 */           if (!TypeUtils.isCollection(parameterizedType)) {
/*  85 */             return Object.class;
/*     */           }
/*     */           
/*  88 */           Type[] typeArguments = parameterizedType.getActualTypeArguments();
/*  89 */           Type[] approximatedTypeArguments = new Type[typeArguments.length];
/*  90 */           for (int i = 0; i < typeArguments.length; i++) {
/*  91 */             approximatedTypeArguments[i] = ApproximatingTypeEnvironment.this.coarseApproximation(typeArguments[i]);
/*     */           }
/*     */           
/*  94 */           return new ParameterizedTypeImpl(ApproximatingTypeEnvironment.this
/*  95 */               .bind(parameterizedType.getRawType()), approximatedTypeArguments, parameterizedType
/*     */               
/*  97 */               .getOwnerType());
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Type defaultCase(Type t) {
/* 103 */           return ApproximatingTypeEnvironment.this.coarseApproximation(t);
/*     */         }
/* 105 */       }).doSwitch(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type coarseApproximation(Type type) {
/* 143 */     Type result = (new TypeSwitch<Type>() { public Type caseWildcardType(WildcardType wildcardType) { return approximateTo(wildcardType.getUpperBounds()); } public Type caseGenericArrayType(GenericArrayType genericArrayType) { if (TypeUtils.isResolved(genericArrayType)) return genericArrayType;  return Object[].class; } public Type caseParameterizedType(ParameterizedType parameterizedType) { if (TypeUtils.isResolved(parameterizedType)) return parameterizedType;  return parameterizedType.getRawType(); } public Type caseTypeVariable(TypeVariable typeVariable) { return approximateTo(typeVariable.getBounds()); } private Type approximateTo(Type[] bounds) { return ApproximatingTypeEnvironment.this.coarseApproximation(bounds[0]); } public Type defaultCase(Type t) { return t; } }).doSwitch(type);
/* 144 */     assert TypeUtils.isResolved(result);
/* 145 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     return "approximated_types";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\ApproximatingTypeEnvironment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */