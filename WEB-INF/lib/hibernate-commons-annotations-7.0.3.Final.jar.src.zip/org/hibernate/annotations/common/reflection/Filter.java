package org.hibernate.annotations.common.reflection;

public interface Filter {
  boolean returnStatic();
  
  boolean returnTransient();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\Filter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */