/*     */ package org.hibernate.annotations.common.reflection.java.generics;
/*     */ 
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeUtils
/*     */ {
/*     */   public static boolean isResolved(Type t) {
/*  20 */     return (new TypeSwitch<Boolean>()
/*     */       {
/*     */         public Boolean caseClass(Class classType) {
/*  23 */           return Boolean.valueOf(true);
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseGenericArrayType(GenericArrayType genericArrayType) {
/*  28 */           return Boolean.valueOf(TypeUtils.isResolved(genericArrayType.getGenericComponentType()));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseParameterizedType(ParameterizedType parameterizedType) {
/*  33 */           Type[] typeArgs = parameterizedType.getActualTypeArguments();
/*  34 */           for (Type arg : typeArgs) {
/*  35 */             if (!TypeUtils.isResolved(arg)) {
/*  36 */               return Boolean.valueOf(false);
/*     */             }
/*     */           } 
/*  39 */           return Boolean.valueOf(TypeUtils.isResolved(parameterizedType.getRawType()));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseTypeVariable(TypeVariable typeVariable) {
/*  44 */           return Boolean.valueOf(false);
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseWildcardType(WildcardType wildcardType) {
/*  49 */           return Boolean.valueOf((TypeUtils.areResolved(wildcardType.getUpperBounds()).booleanValue() && TypeUtils.areResolved(wildcardType.getLowerBounds()).booleanValue()));
/*     */         }
/*  51 */       }).doSwitch(t).booleanValue();
/*     */   }
/*     */   
/*     */   private static Boolean areResolved(Type[] types) {
/*  55 */     for (Type t : types) {
/*  56 */       if (!isResolved(t)) {
/*  57 */         return Boolean.valueOf(false);
/*     */       }
/*     */     } 
/*  60 */     return Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   public static Class<? extends Collection> getCollectionClass(Type type) {
/*  64 */     return (new TypeSwitch<Class<? extends Collection>>()
/*     */       {
/*     */         public Class<? extends Collection> caseClass(Class<?> clazz)
/*     */         {
/*  68 */           return TypeUtils.isCollectionClass(clazz) ? (Class)clazz : null;
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends Collection> caseParameterizedType(ParameterizedType parameterizedType) {
/*  73 */           return TypeUtils.getCollectionClass(parameterizedType.getRawType());
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends Collection> caseWildcardType(WildcardType wildcardType) {
/*  78 */           Type[] upperBounds = wildcardType.getUpperBounds();
/*  79 */           if (upperBounds.length == 0) {
/*  80 */             return null;
/*     */           }
/*  82 */           return TypeUtils.getCollectionClass(upperBounds[0]);
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends Collection> defaultCase(Type t) {
/*  87 */           return null;
/*     */         }
/*  89 */       }).doSwitch(type);
/*     */   }
/*     */   
/*     */   private static boolean isCollectionClass(Class<?> clazz) {
/*  93 */     return (Collection.class.isAssignableFrom(clazz) || Map.class
/*  94 */       .isAssignableFrom(clazz));
/*     */   }
/*     */   
/*     */   public static boolean isSimple(Type type) {
/*  98 */     return (new TypeSwitch<Boolean>()
/*     */       {
/*     */         public Boolean caseClass(Class<?> clazz) {
/* 101 */           return Boolean.valueOf((!clazz.isArray() && !TypeUtils.isCollectionClass(clazz)));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseParameterizedType(ParameterizedType parameterizedType) {
/* 106 */           return Boolean.valueOf(TypeUtils.isSimple(parameterizedType.getRawType()));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseWildcardType(WildcardType wildcardType) {
/* 111 */           return Boolean.valueOf((TypeUtils.areSimple(wildcardType.getUpperBounds()).booleanValue() && TypeUtils.areSimple(wildcardType.getLowerBounds()).booleanValue()));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean defaultCase(Type t) {
/* 116 */           return Boolean.valueOf(false);
/*     */         }
/* 118 */       }).doSwitch(type).booleanValue();
/*     */   }
/*     */   
/*     */   private static Boolean areSimple(Type[] types) {
/* 122 */     for (Type t : types) {
/* 123 */       if (!isSimple(t)) {
/* 124 */         return Boolean.valueOf(false);
/*     */       }
/*     */     } 
/* 127 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isVoid(Type type) {
/* 132 */     return void.class.equals(type);
/*     */   }
/*     */   
/*     */   public static boolean isArray(Type t) {
/* 136 */     return (new TypeSwitch<Boolean>()
/*     */       {
/*     */         public Boolean caseClass(Class clazz) {
/* 139 */           return Boolean.valueOf(clazz.isArray());
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean caseGenericArrayType(GenericArrayType genericArrayType) {
/* 144 */           return Boolean.valueOf(TypeUtils.isSimple(genericArrayType.getGenericComponentType()));
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean defaultCase(Type type) {
/* 149 */           return Boolean.valueOf(false);
/*     */         }
/* 151 */       }).doSwitch(t).booleanValue();
/*     */   }
/*     */   
/*     */   public static boolean isCollection(Type t) {
/* 155 */     return (getCollectionClass(t) != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\TypeUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */