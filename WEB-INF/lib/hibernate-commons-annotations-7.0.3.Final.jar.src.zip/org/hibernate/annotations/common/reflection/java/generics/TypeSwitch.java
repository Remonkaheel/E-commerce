/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.lang.reflect.TypeVariable;
/*    */ import java.lang.reflect.WildcardType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeSwitch<T>
/*    */ {
/*    */   public final T doSwitch(Type type) {
/* 22 */     if (type instanceof Class) {
/* 23 */       return caseClass((Class)type);
/*    */     }
/* 25 */     if (type instanceof GenericArrayType) {
/* 26 */       return caseGenericArrayType((GenericArrayType)type);
/*    */     }
/* 28 */     if (type instanceof ParameterizedType) {
/* 29 */       return caseParameterizedType((ParameterizedType)type);
/*    */     }
/* 31 */     if (type instanceof TypeVariable) {
/* 32 */       return caseTypeVariable((TypeVariable)type);
/*    */     }
/* 34 */     if (type instanceof WildcardType) {
/* 35 */       return caseWildcardType((WildcardType)type);
/*    */     }
/* 37 */     return defaultCase(type);
/*    */   }
/*    */   
/*    */   public T caseWildcardType(WildcardType wildcardType) {
/* 41 */     return defaultCase(wildcardType);
/*    */   }
/*    */   
/*    */   public T caseTypeVariable(TypeVariable typeVariable) {
/* 45 */     return defaultCase(typeVariable);
/*    */   }
/*    */   
/*    */   public T caseClass(Class classType) {
/* 49 */     return defaultCase(classType);
/*    */   }
/*    */   
/*    */   public T caseGenericArrayType(GenericArrayType genericArrayType) {
/* 53 */     return defaultCase(genericArrayType);
/*    */   }
/*    */   
/*    */   public T caseParameterizedType(ParameterizedType parameterizedType) {
/* 57 */     return defaultCase(parameterizedType);
/*    */   }
/*    */   
/*    */   public T defaultCase(Type t) {
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\TypeSwitch.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */