/*     */ package org.hibernate.annotations.common.reflection.java.generics;
/*     */ 
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.HashMap;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleTypeEnvironment
/*     */   implements TypeEnvironment
/*     */ {
/*  23 */   private final HashMap<Type, Type> typeMap = new HashMap<>();
/*     */   
/*  25 */   private final TypeSwitch<Type> substitute = new TypeSwitch<Type>()
/*     */     {
/*     */       public Type caseClass(Class classType) {
/*  28 */         return classType;
/*     */       }
/*     */ 
/*     */       
/*     */       public Type caseGenericArrayType(GenericArrayType genericArrayType) {
/*  33 */         Type originalComponentType = genericArrayType.getGenericComponentType();
/*  34 */         Type boundComponentType = SimpleTypeEnvironment.this.bind(originalComponentType);
/*     */         
/*  36 */         if (originalComponentType == boundComponentType) {
/*  37 */           return genericArrayType;
/*     */         }
/*  39 */         return TypeFactory.createArrayType(boundComponentType);
/*     */       }
/*     */ 
/*     */       
/*     */       public Type caseParameterizedType(ParameterizedType parameterizedType) {
/*  44 */         Type[] originalArguments = parameterizedType.getActualTypeArguments();
/*  45 */         Type[] boundArguments = SimpleTypeEnvironment.this.substitute(originalArguments);
/*     */         
/*  47 */         if (areSame((Object[])originalArguments, (Object[])boundArguments)) {
/*  48 */           return parameterizedType;
/*     */         }
/*  50 */         return new ParameterizedTypeImpl(parameterizedType
/*  51 */             .getRawType(), boundArguments, parameterizedType.getOwnerType());
/*     */       }
/*     */ 
/*     */       
/*     */       private boolean areSame(Object[] array1, Object[] array2) {
/*  56 */         if (array1.length != array2.length) {
/*  57 */           return false;
/*     */         }
/*  59 */         for (int i = 0; i < array1.length; i++) {
/*  60 */           if (array1[i] != array2[i]) {
/*  61 */             return false;
/*     */           }
/*     */         } 
/*  64 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public Type caseTypeVariable(TypeVariable typeVariable) {
/*  69 */         Type type = SimpleTypeEnvironment.this.typeMap.get(typeVariable);
/*  70 */         if (type == null) {
/*  71 */           return typeVariable;
/*     */         }
/*  73 */         return type;
/*     */       }
/*     */ 
/*     */       
/*     */       public Type caseWildcardType(WildcardType wildcardType) {
/*  78 */         return wildcardType;
/*     */       }
/*     */     };
/*     */   
/*     */   public SimpleTypeEnvironment(Type[] formalTypeArgs, Type[] actualTypeArgs) {
/*  83 */     for (int i = 0; i < formalTypeArgs.length; i++) {
/*  84 */       this.typeMap.put(formalTypeArgs[i], actualTypeArgs[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public Type bind(Type type) {
/*  89 */     return this.substitute.doSwitch(type);
/*     */   }
/*     */   
/*     */   private Type[] substitute(Type[] types) {
/*  93 */     Type[] substTypes = new Type[types.length];
/*  94 */     for (int i = 0; i < substTypes.length; i++) {
/*  95 */       substTypes[i] = bind(types[i]);
/*     */     }
/*  97 */     return substTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 102 */     if (this == o) {
/* 103 */       return true;
/*     */     }
/* 105 */     if (o == null || SimpleTypeEnvironment.class != o.getClass()) {
/* 106 */       return false;
/*     */     }
/* 108 */     SimpleTypeEnvironment that = (SimpleTypeEnvironment)o;
/* 109 */     return Objects.equals(this.typeMap, that.typeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return Objects.hash(new Object[] { this.typeMap });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\SimpleTypeEnvironment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */