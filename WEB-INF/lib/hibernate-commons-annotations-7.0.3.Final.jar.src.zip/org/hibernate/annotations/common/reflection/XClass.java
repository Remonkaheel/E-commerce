/*    */ package org.hibernate.annotations.common.reflection;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface XClass
/*    */   extends XAnnotatedElement
/*    */ {
/*    */   public static final String ACCESS_PROPERTY = "property";
/*    */   public static final String ACCESS_FIELD = "field";
/*    */   public static final String ACCESS_RECORD = "record";
/*    */   
/* 19 */   public static final Filter DEFAULT_FILTER = new Filter()
/*    */     {
/*    */       public boolean returnStatic() {
/* 22 */         return false;
/*    */       }
/*    */       
/*    */       public boolean returnTransient() {
/* 26 */         return false;
/*    */       }
/*    */     };
/*    */   
/*    */   String getName();
/*    */   
/*    */   XClass getSuperclass();
/*    */   
/*    */   XAnnotatedElement getContainingElement();
/*    */   
/*    */   XClass[] getInterfaces();
/*    */   
/*    */   boolean isInterface();
/*    */   
/*    */   boolean isAbstract();
/*    */   
/*    */   boolean isPrimitive();
/*    */   
/*    */   boolean isEnum();
/*    */   
/*    */   boolean isAssignableFrom(XClass paramXClass);
/*    */   
/*    */   List<XProperty> getDeclaredProperties(String paramString);
/*    */   
/*    */   List<XProperty> getDeclaredProperties(String paramString, Filter paramFilter);
/*    */   
/*    */   List<XMethod> getDeclaredMethods();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\XClass.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */