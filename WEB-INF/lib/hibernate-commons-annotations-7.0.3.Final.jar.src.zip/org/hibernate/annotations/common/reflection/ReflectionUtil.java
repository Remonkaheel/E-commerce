/*    */ package org.hibernate.annotations.common.reflection;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.lang.reflect.Type;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReflectionUtil
/*    */ {
/*    */   public static boolean isProperty(Method m, Type boundType, Filter filter) {
/* 19 */     return (isPropertyType(boundType) && 
/* 20 */       !m.isSynthetic() && 
/* 21 */       !m.isBridge() && (filter
/* 22 */       .returnStatic() || !Modifier.isStatic(m.getModifiers())) && m
/* 23 */       .getParameterCount() == 0 && (m
/* 24 */       .getName().startsWith("get") || m.getName().startsWith("is")));
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isProperty(Field f, Type boundType, Filter filter) {
/* 29 */     return ((filter.returnStatic() || !Modifier.isStatic(f.getModifiers())) && (filter
/* 30 */       .returnTransient() || !Modifier.isTransient(f.getModifiers())) && 
/* 31 */       !f.isSynthetic() && 
/* 32 */       isPropertyType(boundType));
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean isPropertyType(Type type) {
/* 37 */     return !TypeUtils.isVoid(type);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\ReflectionUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */