/*     */ package org.hibernate.annotations.common.reflection.java;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.annotations.common.reflection.Filter;
/*     */ import org.hibernate.annotations.common.reflection.ReflectionUtil;
/*     */ import org.hibernate.annotations.common.reflection.XAnnotatedElement;
/*     */ import org.hibernate.annotations.common.reflection.XClass;
/*     */ import org.hibernate.annotations.common.reflection.XMethod;
/*     */ import org.hibernate.annotations.common.reflection.XProperty;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.CompoundTypeEnvironment;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JavaXClass
/*     */   extends JavaXAnnotatedElement
/*     */   implements XClass
/*     */ {
/*     */   private static final Class<?> RECORD_CLASS;
/*     */   private static final Method GET_RECORD_COMPONENTS;
/*     */   private static final Method GET_ACCESSOR;
/*     */   private final TypeEnvironment context;
/*     */   private final Class clazz;
/*     */   
/*     */   static {
/*  32 */     Class<?> recordClass = null;
/*  33 */     Method getRecordComponents = null;
/*  34 */     Method getAccessor = null;
/*     */     
/*     */     try {
/*  37 */       recordClass = Class.forName("java.lang.Record");
/*  38 */       getRecordComponents = Class.class.getMethod("getRecordComponents", new Class[0]);
/*  39 */       Class<?> recordComponentClass = Class.forName("java.lang.reflect.RecordComponent");
/*  40 */       getAccessor = recordComponentClass.getMethod("getAccessor", new Class[0]);
/*     */     }
/*  42 */     catch (Exception exception) {}
/*     */ 
/*     */     
/*  45 */     RECORD_CLASS = recordClass;
/*  46 */     GET_RECORD_COMPONENTS = getRecordComponents;
/*  47 */     GET_ACCESSOR = getAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaXClass(Class clazz, TypeEnvironment env, JavaReflectionManager factory) {
/*  54 */     super(clazz, factory);
/*  55 */     this.clazz = clazz;
/*  56 */     this.context = env;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  60 */     return toClass().getName();
/*     */   }
/*     */   
/*     */   public XClass getSuperclass() {
/*  64 */     return getFactory().toXClass(toClass().getSuperclass(), 
/*  65 */         CompoundTypeEnvironment.create(
/*  66 */           getTypeEnvironment(), 
/*  67 */           getFactory().getTypeEnvironment(toClass())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XAnnotatedElement getContainingElement() {
/*  74 */     Class<?> enclosingClass = toClass().getEnclosingClass();
/*  75 */     if (enclosingClass != null) {
/*  76 */       return (XAnnotatedElement)getFactory().toXClass(enclosingClass, 
/*  77 */           CompoundTypeEnvironment.create(
/*  78 */             getTypeEnvironment(), 
/*  79 */             getFactory().getTypeEnvironment(toClass())));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  84 */     return (XAnnotatedElement)getFactory().toXPackage(toClass().getPackage());
/*     */   }
/*     */ 
/*     */   
/*     */   public XClass[] getInterfaces() {
/*  89 */     Class[] classes = toClass().getInterfaces();
/*  90 */     int length = classes.length;
/*  91 */     XClass[] xClasses = new XClass[length];
/*  92 */     if (length != 0) {
/*  93 */       TypeEnvironment environment = CompoundTypeEnvironment.create(
/*  94 */           getTypeEnvironment(), 
/*  95 */           getFactory().getTypeEnvironment(toClass()));
/*     */       
/*  97 */       for (int index = 0; index < length; index++) {
/*  98 */         xClasses[index] = getFactory().toXClass(classes[index], environment);
/*     */       }
/*     */     } 
/* 101 */     return xClasses;
/*     */   }
/*     */   
/*     */   public boolean isInterface() {
/* 105 */     return toClass().isInterface();
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/* 109 */     return Modifier.isAbstract(toClass().getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isPrimitive() {
/* 113 */     return toClass().isPrimitive();
/*     */   }
/*     */   
/*     */   public boolean isEnum() {
/* 117 */     return toClass().isEnum();
/*     */   }
/*     */   
/*     */   private List<XProperty> getDeclaredFieldProperties(Filter filter) {
/* 121 */     Field[] declaredFields = toClass().getDeclaredFields();
/* 122 */     ArrayList<XProperty> result = new ArrayList<>();
/* 123 */     for (Field f : declaredFields) {
/* 124 */       if (ReflectionUtil.isProperty(f, getTypeEnvironment().bind(f.getGenericType()), filter)) {
/* 125 */         result.add(getFactory().getXProperty(f, getTypeEnvironment()));
/*     */       }
/*     */     } 
/* 128 */     result.trimToSize();
/* 129 */     return result;
/*     */   }
/*     */   
/*     */   private List<XProperty> getDeclaredMethodProperties(Filter filter) {
/* 133 */     ArrayList<XProperty> result = new ArrayList<>();
/* 134 */     Method[] declaredMethods = toClass().getDeclaredMethods();
/* 135 */     for (Method m : declaredMethods) {
/* 136 */       if (ReflectionUtil.isProperty(m, getTypeEnvironment().bind(m.getGenericReturnType()), filter)) {
/* 137 */         result.add(getFactory().getXProperty(m, getTypeEnvironment()));
/*     */       }
/*     */     } 
/* 140 */     result.trimToSize();
/* 141 */     return result;
/*     */   }
/*     */   
/*     */   private List<XProperty> getDeclaredComponentProperties(Filter filter) {
/* 145 */     ArrayList<XProperty> result = new ArrayList<>();
/* 146 */     Class<?> javaClass = toClass();
/* 147 */     if (RECORD_CLASS == null || !RECORD_CLASS.isAssignableFrom(javaClass)) {
/* 148 */       return result;
/*     */     }
/*     */     try {
/* 151 */       Object[] declaredComponents = (Object[])GET_RECORD_COMPONENTS.invoke(javaClass, new Object[0]);
/* 152 */       for (Object component : declaredComponents) {
/* 153 */         Method accessor = (Method)GET_ACCESSOR.invoke(component, new Object[0]);
/* 154 */         result.add(getFactory().getXProperty(accessor, getTypeEnvironment()));
/*     */       } 
/* 156 */     } catch (Exception e) {
/* 157 */       throw new RuntimeException("Could not access record components", e);
/*     */     } 
/* 159 */     result.trimToSize();
/* 160 */     return result;
/*     */   }
/*     */   
/*     */   public List<XProperty> getDeclaredProperties(String accessType) {
/* 164 */     return getDeclaredProperties(accessType, XClass.DEFAULT_FILTER);
/*     */   }
/*     */   
/*     */   public List<XProperty> getDeclaredProperties(String accessType, Filter filter) {
/* 168 */     if (accessType.equals("field")) {
/* 169 */       return getDeclaredFieldProperties(filter);
/*     */     }
/* 171 */     if (accessType.equals("property")) {
/* 172 */       return getDeclaredMethodProperties(filter);
/*     */     }
/* 174 */     if (accessType.equals("record")) {
/* 175 */       return getDeclaredComponentProperties(filter);
/*     */     }
/* 177 */     throw new IllegalArgumentException("Unknown access type " + accessType);
/*     */   }
/*     */   
/*     */   public List<XMethod> getDeclaredMethods() {
/* 181 */     Method[] declaredMethods = toClass().getDeclaredMethods();
/* 182 */     List<XMethod> result = new ArrayList<>(declaredMethods.length);
/* 183 */     for (Method m : declaredMethods) {
/* 184 */       result.add(getFactory().getXMethod(m, getTypeEnvironment()));
/*     */     }
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   public Class<?> toClass() {
/* 190 */     return this.clazz;
/*     */   }
/*     */   
/*     */   public boolean isAssignableFrom(XClass c) {
/* 194 */     return toClass().isAssignableFrom(((JavaXClass)c).toClass());
/*     */   }
/*     */   
/*     */   boolean isArray() {
/* 198 */     return toClass().isArray();
/*     */   }
/*     */   
/*     */   TypeEnvironment getTypeEnvironment() {
/* 202 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 207 */     return getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXClass.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */