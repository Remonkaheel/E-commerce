package org.hibernate.annotations.common.reflection;

import java.lang.reflect.AnnotatedElement;
import java.util.Map;

public interface MetadataProvider {
  Map<Object, Object> getDefaults();
  
  AnnotationReader getAnnotationReader(AnnotatedElement paramAnnotatedElement);
  
  default void reset() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\MetadataProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */