/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.hibernate.annotations.common.reflection.AnnotationReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaAnnotationReader
/*    */   implements AnnotationReader
/*    */ {
/*    */   protected final AnnotatedElement element;
/*    */   
/*    */   public JavaAnnotationReader(AnnotatedElement el) {
/* 22 */     this.element = el;
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 26 */     return this.element.getAnnotation(annotationType);
/*    */   }
/*    */   
/*    */   public <T extends Annotation> boolean isAnnotationPresent(Class<T> annotationType) {
/* 30 */     return this.element.isAnnotationPresent(annotationType);
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 34 */     return this.element.getAnnotations();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaAnnotationReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */