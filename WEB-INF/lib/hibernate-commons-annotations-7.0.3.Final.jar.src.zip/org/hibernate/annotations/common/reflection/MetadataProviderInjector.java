package org.hibernate.annotations.common.reflection;

public interface MetadataProviderInjector {
  MetadataProvider getMetadataProvider();
  
  void setMetadataProvider(MetadataProvider paramMetadataProvider);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\MetadataProviderInjector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */