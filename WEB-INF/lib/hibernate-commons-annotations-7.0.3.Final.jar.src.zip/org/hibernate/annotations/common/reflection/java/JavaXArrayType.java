/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import org.hibernate.annotations.common.reflection.XClass;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeSwitch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaXArrayType
/*    */   extends JavaXType
/*    */ {
/*    */   public JavaXArrayType(Type type, TypeEnvironment context, JavaReflectionManager factory) {
/* 22 */     super(type, context, factory);
/*    */   }
/*    */   
/*    */   public boolean isArray() {
/* 26 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isCollection() {
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public XClass getElementClass() {
/* 34 */     return toXClass(getElementType());
/*    */   }
/*    */ 
/*    */   
/*    */   private Type getElementType() {
/* 39 */     return (Type)(new TypeSwitch<Type>()
/*    */       {
/*    */         public Type caseClass(Class classType) {
/* 42 */           return classType.getComponentType();
/*    */         }
/*    */ 
/*    */         
/*    */         public Type caseGenericArrayType(GenericArrayType genericArrayType) {
/* 47 */           return genericArrayType.getGenericComponentType();
/*    */         }
/*    */ 
/*    */         
/*    */         public Type defaultCase(Type t) {
/* 52 */           throw new IllegalArgumentException("" + t + " is not an array type");
/*    */         }
/* 54 */       }).doSwitch(approximate());
/*    */   }
/*    */   
/*    */   public XClass getClassOrElementClass() {
/* 58 */     return getElementClass();
/*    */   }
/*    */   
/*    */   public Class<? extends Collection> getCollectionClass() {
/* 62 */     return null;
/*    */   }
/*    */   
/*    */   public XClass getMapKey() {
/* 66 */     return null;
/*    */   }
/*    */   
/*    */   public XClass getType() {
/* 70 */     Type<? extends Object> boundType = getElementType();
/* 71 */     if (boundType instanceof Class) {
/* 72 */       boundType = arrayTypeOf((Class)boundType);
/*    */     }
/* 74 */     return toXClass(boundType);
/*    */   }
/*    */   
/*    */   private Class<? extends Object> arrayTypeOf(Class<?> componentType) {
/* 78 */     return (Class)Array.newInstance(componentType, 0).getClass();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXArrayType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */