/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.SortedMap;
/*    */ import org.hibernate.annotations.common.reflection.XClass;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeSwitch;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaXCollectionType
/*    */   extends JavaXType
/*    */ {
/*    */   public JavaXCollectionType(Type type, TypeEnvironment context, JavaReflectionManager factory) {
/* 25 */     super(type, context, factory);
/*    */   }
/*    */   
/*    */   public boolean isArray() {
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isCollection() {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public XClass getElementClass() {
/* 37 */     return (XClass)(new TypeSwitch<XClass>()
/*    */       {
/*    */         public XClass caseParameterizedType(ParameterizedType parameterizedType) {
/* 40 */           Type componentType, args[] = parameterizedType.getActualTypeArguments();
/*    */           
/* 42 */           Class<? extends Collection> collectionClass = JavaXCollectionType.this.getCollectionClass();
/* 43 */           if (Map.class.isAssignableFrom(collectionClass) || SortedMap.class
/* 44 */             .isAssignableFrom(collectionClass)) {
/* 45 */             componentType = args[1];
/*    */           } else {
/*    */             
/* 48 */             componentType = args[0];
/*    */           } 
/* 50 */           return JavaXCollectionType.this.toXClass(componentType);
/*    */         }
/* 52 */       }).doSwitch(approximate());
/*    */   }
/*    */   
/*    */   public XClass getMapKey() {
/* 56 */     return (XClass)(new TypeSwitch<XClass>()
/*    */       {
/*    */         public XClass caseParameterizedType(ParameterizedType parameterizedType) {
/* 59 */           if (Map.class.isAssignableFrom(JavaXCollectionType.this.getCollectionClass())) {
/* 60 */             return JavaXCollectionType.this.toXClass(parameterizedType.getActualTypeArguments()[0]);
/*    */           }
/* 62 */           return null;
/*    */         }
/* 64 */       }).doSwitch(approximate());
/*    */   }
/*    */   
/*    */   public XClass getClassOrElementClass() {
/* 68 */     return toXClass(approximate());
/*    */   }
/*    */   
/*    */   public Class<? extends Collection> getCollectionClass() {
/* 72 */     return TypeUtils.getCollectionClass(approximate());
/*    */   }
/*    */   
/*    */   public XClass getType() {
/* 76 */     return toXClass(approximate());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXCollectionType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */