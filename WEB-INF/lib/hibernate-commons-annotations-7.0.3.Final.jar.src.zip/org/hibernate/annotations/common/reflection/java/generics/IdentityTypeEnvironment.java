/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IdentityTypeEnvironment
/*    */   implements TypeEnvironment
/*    */ {
/* 17 */   public static final TypeEnvironment INSTANCE = new IdentityTypeEnvironment();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Type bind(Type type) {
/* 23 */     return type;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 27 */     return "{}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\IdentityTypeEnvironment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */