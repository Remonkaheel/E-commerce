/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Member;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import org.hibernate.annotations.common.reflection.XClass;
/*    */ import org.hibernate.annotations.common.reflection.XMember;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaXMember
/*    */   extends JavaXAnnotatedElement
/*    */   implements XMember
/*    */ {
/*    */   private final Type type;
/*    */   private final TypeEnvironment env;
/*    */   private final JavaXType xType;
/*    */   
/*    */   protected static Type typeOf(Member member, TypeEnvironment env) {
/* 27 */     if (member instanceof Field) {
/* 28 */       return env.bind(((Field)member).getGenericType());
/*    */     }
/* 30 */     if (member instanceof Method) {
/* 31 */       return env.bind(((Method)member).getGenericReturnType());
/*    */     }
/* 33 */     throw new IllegalArgumentException("Member " + member + " is neither a field nor a method");
/*    */   }
/*    */   
/*    */   protected JavaXMember(Member member, Type type, TypeEnvironment env, JavaReflectionManager factory, JavaXType xType) {
/* 37 */     super((AnnotatedElement)member, factory);
/* 38 */     this.type = type;
/* 39 */     this.env = env;
/* 40 */     this.xType = xType;
/*    */   }
/*    */   
/*    */   public XClass getType() {
/* 44 */     return this.xType.getType();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Type getJavaType() {
/* 50 */     return this.env.bind(this.type);
/*    */   }
/*    */   
/*    */   protected TypeEnvironment getTypeEnvironment() {
/* 54 */     return this.env;
/*    */   }
/*    */   
/*    */   public Member getMember() {
/* 58 */     return (Member)toAnnotatedElement();
/*    */   }
/*    */ 
/*    */   
/*    */   public XClass getDeclaringClass() {
/* 63 */     return getFactory().toXClass(getMember().getDeclaringClass());
/*    */   }
/*    */   
/*    */   public Class<? extends Collection> getCollectionClass() {
/* 67 */     return this.xType.getCollectionClass();
/*    */   }
/*    */   
/*    */   public XClass getClassOrElementClass() {
/* 71 */     return this.xType.getClassOrElementClass();
/*    */   }
/*    */   
/*    */   public XClass getElementClass() {
/* 75 */     return this.xType.getElementClass();
/*    */   }
/*    */   
/*    */   public XClass getMapKey() {
/* 79 */     return this.xType.getMapKey();
/*    */   }
/*    */   
/*    */   public boolean isArray() {
/* 83 */     return this.xType.isArray();
/*    */   }
/*    */   
/*    */   public boolean isCollection() {
/* 87 */     return this.xType.isCollection();
/*    */   }
/*    */   
/*    */   public int getModifiers() {
/* 91 */     return getMember().getModifiers();
/*    */   }
/*    */   
/*    */   public final boolean isTypeResolved() {
/* 95 */     return this.xType.isResolved();
/*    */   }
/*    */   
/*    */   public void setAccessible(boolean accessible) {
/* 99 */     ((AccessibleObject)getMember()).setAccessible(accessible);
/*    */   }
/*    */   
/*    */   public abstract String getName();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXMember.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */