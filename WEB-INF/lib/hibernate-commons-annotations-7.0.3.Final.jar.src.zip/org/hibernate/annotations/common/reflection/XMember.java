package org.hibernate.annotations.common.reflection;

import java.util.Collection;

public interface XMember extends XAnnotatedElement {
  XClass getDeclaringClass();
  
  String getName();
  
  boolean isCollection();
  
  boolean isArray();
  
  Class<? extends Collection> getCollectionClass();
  
  XClass getType();
  
  XClass getElementClass();
  
  XClass getClassOrElementClass();
  
  XClass getMapKey();
  
  int getModifiers();
  
  void setAccessible(boolean paramBoolean);
  
  Object invoke(Object paramObject, Object... paramVarArgs);
  
  Object invoke(Object paramObject);
  
  boolean isTypeResolved();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\XMember.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */