/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Objects;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TypeEnvironmentMap<K, V>
/*    */ {
/*    */   private HashMap<TypeEnvironment, ContextScope> rootMap;
/*    */   private final XTypeConstruction<K, V> constructionMethod;
/*    */   
/*    */   TypeEnvironmentMap(XTypeConstruction<K, V> constructionMethod) {
/* 35 */     Objects.requireNonNull(constructionMethod);
/* 36 */     this.constructionMethod = constructionMethod;
/*    */   }
/*    */   
/*    */   private <K, V> HashMap<TypeEnvironment, ContextScope> getOrInitRootMap() {
/* 40 */     if (this.rootMap == null) {
/* 41 */       this.rootMap = new HashMap<>(8, 0.5F);
/*    */     }
/* 43 */     return this.rootMap;
/*    */   }
/*    */   
/*    */   V getOrCompute(TypeEnvironment context, K subKey) {
/* 47 */     ContextScope contextualMap = getOrInitRootMap().computeIfAbsent(context, x$0 -> new ContextScope(x$0));
/* 48 */     return contextualMap.getOrCompute(subKey);
/*    */   }
/*    */   
/*    */   void clear() {
/* 52 */     HashMap<TypeEnvironment, ContextScope> m = this.rootMap;
/* 53 */     if (m != null) {
/*    */ 
/*    */       
/* 56 */       this.rootMap = null;
/* 57 */       m.clear();
/*    */     } 
/*    */   }
/*    */   
/*    */   private final class ContextScope
/*    */     extends HashMap<K, V>
/*    */   {
/*    */     private final TypeEnvironment context;
/*    */     
/*    */     private ContextScope(TypeEnvironment context) {
/* 67 */       super(64, 0.85F);
/* 68 */       this.context = context;
/*    */     }
/*    */     
/*    */     private V getOrCompute(K subKey) {
/* 72 */       return computeIfAbsent(subKey, this::buildObject);
/*    */     }
/*    */     
/*    */     private V buildObject(K subKey) {
/* 76 */       return TypeEnvironmentMap.this.constructionMethod.createInstance(subKey, this.context);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\TypeEnvironmentMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */