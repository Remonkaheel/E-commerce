/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import org.hibernate.annotations.common.reflection.XClass;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaXSimpleType
/*    */   extends JavaXType
/*    */ {
/*    */   public JavaXSimpleType(Type type, TypeEnvironment context, JavaReflectionManager factory) {
/* 19 */     super(type, context, factory);
/*    */   }
/*    */   
/*    */   public boolean isArray() {
/* 23 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isCollection() {
/* 27 */     return false;
/*    */   }
/*    */   
/*    */   public XClass getElementClass() {
/* 31 */     return toXClass(approximate());
/*    */   }
/*    */   
/*    */   public XClass getClassOrElementClass() {
/* 35 */     return getElementClass();
/*    */   }
/*    */   
/*    */   public Class<? extends Collection> getCollectionClass() {
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public XClass getType() {
/* 43 */     return toXClass(approximate());
/*    */   }
/*    */   
/*    */   public XClass getMapKey() {
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXSimpleType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */