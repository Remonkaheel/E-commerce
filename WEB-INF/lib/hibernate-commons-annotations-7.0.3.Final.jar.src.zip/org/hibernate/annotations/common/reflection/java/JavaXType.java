/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import org.hibernate.annotations.common.reflection.XClass;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JavaXType
/*    */ {
/*    */   private final TypeEnvironment context;
/*    */   private final JavaReflectionManager factory;
/*    */   private final Type approximatedType;
/*    */   private final Type boundType;
/*    */   
/*    */   protected JavaXType(Type unboundType, TypeEnvironment context, JavaReflectionManager factory) {
/* 27 */     this.context = context;
/* 28 */     this.factory = factory;
/* 29 */     this.boundType = context.bind(unboundType);
/* 30 */     this.approximatedType = factory.toApproximatingEnvironment(context).bind(unboundType);
/*    */   }
/*    */   
/*    */   public abstract boolean isArray();
/*    */   
/*    */   public abstract boolean isCollection();
/*    */   
/*    */   public abstract XClass getElementClass();
/*    */   
/*    */   public abstract XClass getClassOrElementClass();
/*    */   
/*    */   public abstract Class<? extends Collection> getCollectionClass();
/*    */   
/*    */   public abstract XClass getMapKey();
/*    */   
/*    */   public abstract XClass getType();
/*    */   
/*    */   public boolean isResolved() {
/* 48 */     return TypeUtils.isResolved(this.boundType);
/*    */   }
/*    */   
/*    */   protected Type approximate() {
/* 52 */     return this.approximatedType;
/*    */   }
/*    */   
/*    */   protected XClass toXClass(Type type) {
/* 56 */     return this.factory.toXClass(type, this.context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */