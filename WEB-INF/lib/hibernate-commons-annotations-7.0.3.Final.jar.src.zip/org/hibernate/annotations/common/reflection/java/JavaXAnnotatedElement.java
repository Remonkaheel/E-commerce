/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.hibernate.annotations.common.reflection.AnnotationReader;
/*    */ import org.hibernate.annotations.common.reflection.XAnnotatedElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JavaXAnnotatedElement
/*    */   implements XAnnotatedElement
/*    */ {
/*    */   private final JavaReflectionManager factory;
/*    */   private final AnnotatedElement annotatedElement;
/*    */   
/*    */   public JavaXAnnotatedElement(AnnotatedElement annotatedElement, JavaReflectionManager factory) {
/* 23 */     this.factory = factory;
/* 24 */     this.annotatedElement = annotatedElement;
/*    */   }
/*    */   
/*    */   protected JavaReflectionManager getFactory() {
/* 28 */     return this.factory;
/*    */   }
/*    */   
/*    */   private AnnotationReader getAnnotationReader() {
/* 32 */     return this.factory.buildAnnotationReader(this.annotatedElement);
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 36 */     return (T)getAnnotationReader().getAnnotation(annotationType);
/*    */   }
/*    */   
/*    */   public <T extends Annotation> boolean isAnnotationPresent(Class<T> annotationType) {
/* 40 */     return getAnnotationReader().isAnnotationPresent(annotationType);
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 44 */     return getAnnotationReader().getAnnotations();
/*    */   }
/*    */   
/*    */   AnnotatedElement toAnnotatedElement() {
/* 48 */     return this.annotatedElement;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 53 */     if (!(obj instanceof JavaXAnnotatedElement)) return false; 
/* 54 */     JavaXAnnotatedElement other = (JavaXAnnotatedElement)obj;
/*    */     
/* 56 */     return this.annotatedElement.equals(other.toAnnotatedElement());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 61 */     return this.annotatedElement.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     return this.annotatedElement.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXAnnotatedElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */