/*     */ package org.hibernate.annotations.common.reflection.java;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import org.hibernate.annotations.common.reflection.XProperty;
/*     */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JavaXProperty
/*     */   extends JavaXMember
/*     */   implements XProperty
/*     */ {
/*  20 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   private static final Class<?> RECORD_CLASS;
/*     */   
/*     */   static {
/*  24 */     Class<?> recordClass = null;
/*     */     
/*     */     try {
/*  27 */       recordClass = Class.forName("java.lang.Record");
/*     */     }
/*  29 */     catch (Exception exception) {}
/*     */ 
/*     */     
/*  32 */     RECORD_CLASS = recordClass;
/*     */   }
/*     */   
/*     */   static JavaXProperty create(Member member, TypeEnvironment context, JavaReflectionManager factory) {
/*  36 */     Type propType = typeOf(member, context);
/*  37 */     JavaXType xType = factory.toXType(context, propType);
/*  38 */     return new JavaXProperty(member, propType, context, factory, xType);
/*     */   }
/*     */   
/*     */   private JavaXProperty(Member member, Type type, TypeEnvironment env, JavaReflectionManager factory, JavaXType xType) {
/*  42 */     super(member, type, env, factory, xType);
/*  43 */     assert member instanceof Field || member instanceof Method;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  47 */     String fullName = getMember().getName();
/*  48 */     if (getMember() instanceof Method) {
/*  49 */       if (fullName.startsWith("get")) {
/*  50 */         return decapitalize(fullName.substring("get".length()));
/*     */       }
/*  52 */       if (fullName.startsWith("is")) {
/*  53 */         return decapitalize(fullName.substring("is".length()));
/*     */       }
/*     */       
/*  56 */       if (RECORD_CLASS == null || !RECORD_CLASS.isAssignableFrom(getMember().getDeclaringClass())) {
/*  57 */         throw new RuntimeException("Method " + fullName + " is not a property getter");
/*     */       }
/*  59 */       return fullName;
/*     */     } 
/*     */     
/*  62 */     return fullName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String decapitalize(String name) {
/*  68 */     if (name != null && name.length() != 0) {
/*  69 */       if (name.length() > 1 && Character.isUpperCase(name.charAt(1))) {
/*  70 */         return name;
/*     */       }
/*  72 */       char[] chars = name.toCharArray();
/*  73 */       chars[0] = Character.toLowerCase(chars[0]);
/*  74 */       return new String(chars);
/*     */     } 
/*     */     
/*  77 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object target) {
/*     */     try {
/*  87 */       if (getMember() instanceof Method) {
/*  88 */         return ((Method)getMember()).invoke(target, EMPTY_ARRAY);
/*     */       }
/*     */       
/*  91 */       return ((Field)getMember()).get(target);
/*     */     
/*     */     }
/*  94 */     catch (NullPointerException e) {
/*  95 */       throw new IllegalArgumentException("Invoking " + getName() + " on a  null object", e);
/*     */     }
/*  97 */     catch (IllegalArgumentException e) {
/*  98 */       throw new IllegalArgumentException("Invoking " + getName() + " with wrong parameters", e);
/*     */     }
/* 100 */     catch (Exception e) {
/* 101 */       throw new IllegalStateException("Unable to invoke " + getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object target, Object... parameters) {
/* 107 */     if (parameters.length != 0) {
/* 108 */       throw new IllegalArgumentException("An XProperty cannot have invoke parameters");
/*     */     }
/* 110 */     return invoke(target);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     return getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */