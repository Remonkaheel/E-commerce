/*     */ package org.hibernate.annotations.common.reflection.java.generics;
/*     */ 
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeEnvironmentFactory
/*     */ {
/*     */   public static TypeEnvironment getEnvironment(Class context) {
/*  30 */     if (context == null) {
/*  31 */       return IdentityTypeEnvironment.INSTANCE;
/*     */     }
/*  33 */     return createEnvironment(context);
/*     */   }
/*     */   
/*     */   public static TypeEnvironment getEnvironment(Type context) {
/*  37 */     if (context == null) {
/*  38 */       return IdentityTypeEnvironment.INSTANCE;
/*     */     }
/*  40 */     return createEnvironment(context);
/*     */   }
/*     */   
/*     */   public static TypeEnvironment getEnvironment(Type t, TypeEnvironment context) {
/*  44 */     return CompoundTypeEnvironment.create(getEnvironment(t), context);
/*     */   }
/*     */   
/*     */   public static TypeEnvironment toApproximatingEnvironment(TypeEnvironment context) {
/*  48 */     return CompoundTypeEnvironment.create(new ApproximatingTypeEnvironment(), context);
/*     */   }
/*     */   
/*     */   private static TypeEnvironment createEnvironment(Type context) {
/*  52 */     return (new TypeSwitch<TypeEnvironment>()
/*     */       {
/*     */         public TypeEnvironment caseClass(Class classType) {
/*  55 */           return CompoundTypeEnvironment.create(
/*  56 */               TypeEnvironmentFactory.createSuperTypeEnvironment(classType), 
/*  57 */               TypeEnvironmentFactory.getEnvironment(classType.getSuperclass()));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeEnvironment caseParameterizedType(ParameterizedType parameterizedType) {
/*  63 */           return TypeEnvironmentFactory.createEnvironment(parameterizedType);
/*     */         }
/*     */ 
/*     */         
/*     */         public TypeEnvironment defaultCase(Type t) {
/*  68 */           throw new IllegalArgumentException("Invalid type for generating environment: " + t);
/*     */         }
/*  70 */       }).doSwitch(context);
/*     */   }
/*     */   
/*     */   private static TypeEnvironment createSuperTypeEnvironment(Class clazz) {
/*  74 */     Class superclass = clazz.getSuperclass();
/*  75 */     if (superclass == null) {
/*  76 */       return IdentityTypeEnvironment.INSTANCE;
/*     */     }
/*     */     
/*  79 */     Type genericSuperclass = clazz.getGenericSuperclass();
/*     */     
/*  81 */     if (genericSuperclass instanceof Class) {
/*  82 */       return IdentityTypeEnvironment.INSTANCE;
/*     */     }
/*     */     
/*  85 */     if (genericSuperclass instanceof ParameterizedType) {
/*  86 */       TypeVariable[] arrayOfTypeVariable = superclass.getTypeParameters();
/*  87 */       Type[] actualArgs = ((ParameterizedType)genericSuperclass).getActualTypeArguments();
/*  88 */       return new SimpleTypeEnvironment((Type[])arrayOfTypeVariable, actualArgs);
/*     */     } 
/*     */     
/*  91 */     throw new AssertionError("Should be unreachable");
/*     */   }
/*     */   
/*     */   private static TypeEnvironment createEnvironment(ParameterizedType t) {
/*  95 */     Type[] tactuals = t.getActualTypeArguments();
/*  96 */     Type rawType = t.getRawType();
/*  97 */     if (rawType instanceof Class) {
/*  98 */       TypeVariable[] tparms = ((Class)rawType).getTypeParameters();
/*  99 */       return new SimpleTypeEnvironment((Type[])tparms, tactuals);
/*     */     } 
/* 101 */     return IdentityTypeEnvironment.INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\TypeEnvironmentFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */