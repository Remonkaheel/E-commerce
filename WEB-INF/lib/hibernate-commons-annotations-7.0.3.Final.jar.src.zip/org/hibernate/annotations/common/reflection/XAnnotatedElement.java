package org.hibernate.annotations.common.reflection;

import java.lang.annotation.Annotation;

public interface XAnnotatedElement {
  <T extends Annotation> T getAnnotation(Class<T> paramClass);
  
  <T extends Annotation> boolean isAnnotationPresent(Class<T> paramClass);
  
  Annotation[] getAnnotations();
  
  boolean equals(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\XAnnotatedElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */