package org.hibernate.annotations.common.reflection;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Map;

public interface ReflectionManager {
  <T> XClass toXClass(Class<T> paramClass);
  
  Class toClass(XClass paramXClass);
  
  Type toType(XClass paramXClass);
  
  Method toMethod(XMethod paramXMethod);
  
  XPackage toXPackage(Package paramPackage);
  
  <T> boolean equals(XClass paramXClass, Class<T> paramClass);
  
  AnnotationReader buildAnnotationReader(AnnotatedElement paramAnnotatedElement);
  
  Map getDefaults();
  
  default void reset() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\ReflectionManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */