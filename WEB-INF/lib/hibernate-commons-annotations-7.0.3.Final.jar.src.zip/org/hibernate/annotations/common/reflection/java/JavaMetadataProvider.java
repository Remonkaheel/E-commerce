/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.hibernate.annotations.common.reflection.AnnotationReader;
/*    */ import org.hibernate.annotations.common.reflection.MetadataProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaMetadataProvider
/*    */   implements MetadataProvider
/*    */ {
/*    */   public Map<Object, Object> getDefaults() {
/* 19 */     return Collections.emptyMap();
/*    */   }
/*    */   
/*    */   public AnnotationReader getAnnotationReader(AnnotatedElement annotatedElement) {
/* 23 */     return new JavaAnnotationReader(annotatedElement);
/*    */   }
/*    */   
/*    */   public void reset() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaMetadataProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */