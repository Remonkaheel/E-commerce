/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericArrayTypeImpl
/*    */   implements GenericArrayType
/*    */ {
/*    */   private final Type componentType;
/*    */   
/*    */   public GenericArrayTypeImpl(Type componentType) {
/* 16 */     this.componentType = componentType;
/*    */   }
/*    */   
/*    */   public Type getGenericComponentType() {
/* 20 */     return this.componentType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 25 */     if (!(obj instanceof GenericArrayType)) {
/* 26 */       return false;
/*    */     }
/* 28 */     GenericArrayType other = (GenericArrayType)obj;
/* 29 */     return Objects.equals(getGenericComponentType(), other.getGenericComponentType());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 34 */     return Objects.hashCode(getGenericComponentType());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\GenericArrayTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */