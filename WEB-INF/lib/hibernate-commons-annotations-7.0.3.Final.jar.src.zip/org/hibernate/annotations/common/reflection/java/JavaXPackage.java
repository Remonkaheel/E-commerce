/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import org.hibernate.annotations.common.reflection.XPackage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaXPackage
/*    */   extends JavaXAnnotatedElement
/*    */   implements XPackage
/*    */ {
/*    */   public JavaXPackage(Package pkg, JavaReflectionManager factory) {
/* 16 */     super(pkg, factory);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 20 */     return ((Package)toAnnotatedElement()).getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXPackage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */