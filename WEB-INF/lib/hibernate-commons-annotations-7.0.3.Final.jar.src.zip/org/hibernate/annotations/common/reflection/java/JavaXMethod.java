/*    */ package org.hibernate.annotations.common.reflection.java;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import org.hibernate.annotations.common.reflection.XMethod;
/*    */ import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaXMethod
/*    */   extends JavaXMember
/*    */   implements XMethod
/*    */ {
/* 18 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*    */   
/*    */   static JavaXMethod create(Member member, TypeEnvironment context, JavaReflectionManager factory) {
/* 21 */     Type propType = typeOf(member, context);
/* 22 */     JavaXType xType = factory.toXType(context, propType);
/* 23 */     return new JavaXMethod(member, propType, context, factory, xType);
/*    */   }
/*    */   
/*    */   private JavaXMethod(Member member, Type type, TypeEnvironment env, JavaReflectionManager factory, JavaXType xType) {
/* 27 */     super(member, type, env, factory, xType);
/* 28 */     assert member instanceof Method;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 33 */     return getMember().getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object invoke(Object target) {
/* 38 */     return invoke(target, EMPTY_ARRAY);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object invoke(Object target, Object... parameters) {
/*    */     try {
/* 44 */       return ((Method)getMember()).invoke(target, parameters);
/*    */     }
/* 46 */     catch (NullPointerException e) {
/* 47 */       throw new IllegalArgumentException("Invoking " + getName() + " on a  null object", e);
/*    */     }
/* 49 */     catch (IllegalArgumentException e) {
/* 50 */       throw new IllegalArgumentException("Invoking " + getName() + " with wrong parameters", e);
/*    */     }
/* 52 */     catch (Exception e) {
/* 53 */       throw new IllegalStateException("Unable to invoke " + getName(), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\JavaXMethod.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */