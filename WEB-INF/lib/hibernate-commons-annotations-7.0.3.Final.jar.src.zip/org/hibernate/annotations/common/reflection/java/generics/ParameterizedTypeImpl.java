/*    */ package org.hibernate.annotations.common.reflection.java.generics;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import java.util.StringJoiner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterizedTypeImpl
/*    */   implements ParameterizedType
/*    */ {
/*    */   private final Type[] substTypeArgs;
/*    */   private final Type rawType;
/*    */   private final Type ownerType;
/*    */   
/*    */   public ParameterizedTypeImpl(Type rawType, Type[] substTypeArgs, Type ownerType) {
/* 20 */     this.substTypeArgs = substTypeArgs;
/* 21 */     this.rawType = rawType;
/* 22 */     this.ownerType = ownerType;
/*    */   }
/*    */   
/*    */   public Type[] getActualTypeArguments() {
/* 26 */     return this.substTypeArgs;
/*    */   }
/*    */   
/*    */   public Type getRawType() {
/* 30 */     return this.rawType;
/*    */   }
/*    */   
/*    */   public Type getOwnerType() {
/* 34 */     return this.ownerType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 39 */     if (!(obj instanceof ParameterizedType)) {
/* 40 */       return false;
/*    */     }
/* 42 */     ParameterizedType other = (ParameterizedType)obj;
/* 43 */     return (Objects.equals(getOwnerType(), other.getOwnerType()) && 
/* 44 */       Objects.equals(getRawType(), other.getRawType()) && 
/* 45 */       Arrays.equals((Object[])getActualTypeArguments(), (Object[])other.getActualTypeArguments()));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 50 */     return Arrays.hashCode((Object[])getActualTypeArguments()) ^ 
/* 51 */       Objects.hashCode(getOwnerType()) ^ 
/* 52 */       Objects.hashCode(getRawType());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     StringBuilder sb = new StringBuilder();
/* 58 */     if (this.ownerType != null) {
/* 59 */       sb.append(this.ownerType.getTypeName());
/*    */       
/* 61 */       sb.append("$");
/*    */       
/* 63 */       if (this.ownerType instanceof ParameterizedType) {
/*    */ 
/*    */         
/* 66 */         sb.append(this.rawType
/* 67 */             .getTypeName().replace(((ParameterizedType)this.ownerType)
/* 68 */               .getRawType().getTypeName() + "$", ""));
/*    */ 
/*    */       
/*    */       }
/* 72 */       else if (this.rawType instanceof Class) {
/* 73 */         sb.append(((Class)this.rawType).getSimpleName());
/*    */       } else {
/* 75 */         sb.append(this.rawType.getTypeName());
/*    */       } 
/*    */     } else {
/* 78 */       sb.append(this.rawType.getTypeName());
/*    */     } 
/*    */     
/* 81 */     if (this.substTypeArgs != null) {
/* 82 */       StringJoiner sj = new StringJoiner(", ", "<", ">");
/* 83 */       sj.setEmptyValue("");
/* 84 */       for (Type t : this.substTypeArgs) {
/* 85 */         sj.add(t.getTypeName());
/*    */       }
/* 87 */       sb.append(sj);
/*    */     } 
/*    */     
/* 90 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-commons-annotations-7.0.3.Final.jar!\org\hibernate\annotations\common\reflection\java\generics\ParameterizedTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */