module org.apache.logging.log4j.to.slf4j {
  requires java.base;
  requires transitive org.apache.logging.log4j;
  requires org.jspecify;
  requires transitive org.slf4j;
  
  exports org.apache.logging.slf4j;
  
  provides org.apache.logging.log4j.spi.Provider with org.apache.logging.slf4j.SLF4JProvider;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */