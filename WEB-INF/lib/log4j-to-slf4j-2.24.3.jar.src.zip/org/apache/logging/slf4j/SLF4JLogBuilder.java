/*     */ package org.apache.logging.slf4j;
/*     */ 
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogBuilder;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.SimpleMessage;
/*     */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.LambdaUtil;
/*     */ import org.apache.logging.log4j.util.StackLocatorUtil;
/*     */ import org.apache.logging.log4j.util.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SLF4JLogBuilder
/*     */   implements LogBuilder
/*     */ {
/*  33 */   private static Message EMPTY_MESSAGE = (Message)new SimpleMessage("");
/*  34 */   private static final String FQCN = SLF4JLogBuilder.class.getName();
/*  35 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   
/*     */   private ExtendedLogger logger;
/*     */   private Level level;
/*     */   private Marker marker;
/*     */   private Throwable throwable;
/*     */   private volatile boolean inUse;
/*     */   private final long threadId;
/*     */   
/*     */   public SLF4JLogBuilder(SLF4JLogger logger, Level level) {
/*  45 */     this.logger = (ExtendedLogger)logger;
/*  46 */     this.level = level;
/*  47 */     this.threadId = Thread.currentThread().getId();
/*  48 */     this.inUse = (level != null);
/*     */   }
/*     */   
/*     */   public SLF4JLogBuilder() {
/*  52 */     this(null, null);
/*     */   }
/*     */   
/*     */   public LogBuilder reset(SLF4JLogger logger, Level level) {
/*  56 */     this.logger = (ExtendedLogger)logger;
/*  57 */     this.level = level;
/*  58 */     this.marker = null;
/*  59 */     this.throwable = null;
/*  60 */     this.inUse = true;
/*  61 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isInUse() {
/*  65 */     return this.inUse;
/*     */   }
/*     */   
/*     */   private boolean isValid() {
/*  69 */     if (!this.inUse) {
/*  70 */       LOGGER.warn("Attempt to reuse LogBuilder was ignored. {}", StackLocatorUtil.getCallerClass(2));
/*  71 */       return false;
/*     */     } 
/*  73 */     if (this.threadId != Thread.currentThread().getId()) {
/*  74 */       LOGGER.warn("LogBuilder can only be used on the owning thread. {}", StackLocatorUtil.getCallerClass(2));
/*  75 */       return false;
/*     */     } 
/*  77 */     return true;
/*     */   }
/*     */   
/*     */   private void logMessage(Message message) {
/*     */     try {
/*  82 */       this.logger.logMessage(FQCN, this.level, this.marker, message, this.throwable);
/*     */     } finally {
/*  84 */       this.inUse = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withMarker(Marker marker) {
/*  90 */     this.marker = marker;
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withThrowable(Throwable throwable) {
/*  96 */     this.throwable = throwable;
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withLocation() {
/* 102 */     LOGGER.info("Call to withLocation() ignored since SLF4J does not support setting location information.");
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withLocation(StackTraceElement location) {
/* 108 */     return withLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(CharSequence message) {
/* 113 */     if (isValid()) {
/* 114 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message) {
/* 120 */     if (isValid()) {
/* 121 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object... params) {
/* 127 */     if (isValid()) {
/* 128 */       logMessage(this.logger.getMessageFactory().newMessage(message, params));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Supplier<?>... params) {
/* 134 */     if (isValid()) {
/* 135 */       logMessage(this.logger.getMessageFactory().newMessage(message, LambdaUtil.getAll((Supplier[])params)));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Message message) {
/* 141 */     if (isValid()) {
/* 142 */       logMessage(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Supplier<Message> messageSupplier) {
/* 148 */     if (isValid()) {
/* 149 */       logMessage((Message)messageSupplier.get());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Message logAndGet(Supplier<Message> messageSupplier) {
/* 155 */     Message message = null;
/* 156 */     if (isValid()) {
/* 157 */       logMessage(message = (Message)messageSupplier.get());
/*     */     }
/* 159 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object message) {
/* 164 */     if (isValid()) {
/* 165 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0) {
/* 171 */     if (isValid()) {
/* 172 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1) {
/* 178 */     if (isValid()) {
/* 179 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2) {
/* 185 */     if (isValid()) {
/* 186 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3) {
/* 192 */     if (isValid()) {
/* 193 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 199 */     if (isValid()) {
/* 200 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 206 */     if (isValid()) {
/* 207 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 213 */     if (isValid()) {
/* 214 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 221 */     if (isValid()) {
/* 222 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 238 */     if (isValid()) {
/* 239 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7, p8 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 256 */     if (isValid()) {
/* 257 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log() {
/* 263 */     if (isValid())
/* 264 */       logMessage(EMPTY_MESSAGE); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\SLF4JLogBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */