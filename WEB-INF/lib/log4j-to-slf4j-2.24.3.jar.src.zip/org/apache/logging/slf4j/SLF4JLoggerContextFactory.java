/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.logging.log4j.spi.LoggerContext;
/*    */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ import org.apache.logging.log4j.util.LoaderUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SLF4JLoggerContextFactory
/*    */   implements LoggerContextFactory
/*    */ {
/* 26 */   private static final StatusLogger LOGGER = StatusLogger.getLogger();
/* 27 */   private static final LoggerContext context = new SLF4JLoggerContext();
/*    */ 
/*    */   
/*    */   public SLF4JLoggerContextFactory() {
/* 31 */     boolean misconfigured = false;
/*    */     try {
/* 33 */       LoaderUtil.loadClass("org.slf4j.helpers.Log4jLoggerFactory");
/* 34 */       misconfigured = true;
/* 35 */     } catch (ClassNotFoundException classNotFoundIsGood) {
/* 36 */       LOGGER.debug("org.slf4j.helpers.Log4jLoggerFactory is not on classpath. Good!");
/*    */     } 
/* 38 */     if (misconfigured) {
/* 39 */       throw new IllegalStateException("slf4j-impl jar is mutually exclusive with log4j-to-slf4j jar (the first routes calls from SLF4J to Log4j, the second from Log4j to SLF4J)");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggerContext getContext(String fqcn, ClassLoader loader, Object externalContext, boolean currentContext) {
/* 47 */     return context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggerContext getContext(String fqcn, ClassLoader loader, Object externalContext, boolean currentContext, URI configLocation, String name) {
/* 58 */     return context;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeContext(LoggerContext ignored) {}
/*    */ 
/*    */   
/*    */   public boolean isClassLoaderDependent() {
/* 67 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\SLF4JLoggerContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */