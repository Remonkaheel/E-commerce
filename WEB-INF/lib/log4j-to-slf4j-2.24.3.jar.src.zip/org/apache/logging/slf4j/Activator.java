/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import org.apache.logging.log4j.util.ProviderActivator;
/*    */ import org.osgi.annotation.bundle.Header;
/*    */ import org.osgi.annotation.bundle.Headers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Headers({@Header(name = "Bundle-Activator", value = "${@class}"), @Header(name = "Bundle-ActivationPolicy", value = "lazy")})
/*    */ public class Activator
/*    */   extends ProviderActivator
/*    */ {
/*    */   public Activator() {
/* 29 */     super(new SLF4JProvider());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\Activator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */