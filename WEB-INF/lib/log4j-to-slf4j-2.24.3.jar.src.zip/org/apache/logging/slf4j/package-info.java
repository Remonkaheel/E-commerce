package org.apache.logging.slf4j;

import org.osgi.annotation.bundle.Export;
import org.osgi.annotation.versioning.Version;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */