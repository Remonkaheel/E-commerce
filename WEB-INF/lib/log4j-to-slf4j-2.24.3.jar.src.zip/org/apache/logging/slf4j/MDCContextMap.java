/*     */ package org.apache.logging.slf4j;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.spi.CleanableThreadContextMap;
/*     */ import org.apache.logging.log4j.util.SortedArrayStringMap;
/*     */ import org.apache.logging.log4j.util.StringMap;
/*     */ import org.slf4j.MDC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDCContextMap
/*     */   implements CleanableThreadContextMap
/*     */ {
/*  32 */   private static final StringMap EMPTY_CONTEXT_DATA = (StringMap)new SortedArrayStringMap(1);
/*     */   
/*     */   static {
/*  35 */     EMPTY_CONTEXT_DATA.freeze();
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, String value) {
/*  40 */     MDC.put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<String, String> m) {
/*  45 */     for (Map.Entry<String, String> entry : m.entrySet()) {
/*  46 */       MDC.put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String key) {
/*  52 */     return MDC.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/*  57 */     MDC.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAll(Iterable<String> keys) {
/*  62 */     for (String key : keys) {
/*  63 */       MDC.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  69 */     MDC.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/*  74 */     Map<String, String> map = MDC.getCopyOfContextMap();
/*  75 */     return (map != null && map.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopy() {
/*  80 */     Map<String, String> contextMap = MDC.getCopyOfContextMap();
/*  81 */     return (contextMap != null) ? contextMap : new HashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImmutableMapOrNull() {
/*  86 */     return MDC.getCopyOfContextMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  91 */     Map<String, String> map = MDC.getCopyOfContextMap();
/*  92 */     return (map == null || map.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public StringMap getReadOnlyContextData() {
/*  97 */     Map<String, String> copy = getCopy();
/*  98 */     if (copy.isEmpty()) {
/*  99 */       return EMPTY_CONTEXT_DATA;
/*     */     }
/* 101 */     SortedArrayStringMap sortedArrayStringMap = new SortedArrayStringMap();
/* 102 */     for (Map.Entry<String, String> entry : copy.entrySet()) {
/* 103 */       sortedArrayStringMap.putValue(entry.getKey(), entry.getValue());
/*     */     }
/* 105 */     return (StringMap)sortedArrayStringMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\MDCContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */