/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*    */ import org.apache.logging.log4j.spi.Provider;
/*    */ import org.apache.logging.log4j.spi.ThreadContextMap;
/*    */ import org.jspecify.annotations.NullMarked;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @NullMarked
/*    */ @ServiceProvider(value = Provider.class, resolution = "optional")
/*    */ public class SLF4JProvider
/*    */   extends Provider
/*    */ {
/* 33 */   private static final LoggerContextFactory CONTEXT_FACTORY = new SLF4JLoggerContextFactory();
/* 34 */   private static final ThreadContextMap THREAD_CONTEXT_MAP = (ThreadContextMap)new MDCContextMap();
/*    */   
/*    */   public SLF4JProvider() {
/* 37 */     super(Integer.valueOf(15), "2.6.0", SLF4JLoggerContextFactory.class, MDCContextMap.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public LoggerContextFactory getLoggerContextFactory() {
/* 42 */     return CONTEXT_FACTORY;
/*    */   }
/*    */ 
/*    */   
/*    */   public ThreadContextMap getThreadContextMapInstance() {
/* 47 */     return THREAD_CONTEXT_MAP;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\SLF4JProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */