/*     */ package org.apache.logging.slf4j;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogBuilder;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.message.LoggerNameAwareMessage;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.spi.AbstractLogger;
/*     */ import org.apache.logging.log4j.spi.StandardLevel;
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.MarkerFactory;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SLF4JLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   private static final boolean LAZY_LEVEL_CHECK = "ch.qos.logback.classic.LoggerContext"
/*  39 */     .equals(LoggerFactory.getILoggerFactory().getClass().getName());
/*     */   
/*  41 */   private static final ThreadLocal<SLF4JLogBuilder> logBuilder = ThreadLocal.withInitial(SLF4JLogBuilder::new);
/*     */   
/*     */   private final Logger logger;
/*     */   private final LocationAwareLogger locationAwareLogger;
/*     */   
/*     */   public SLF4JLogger(String name, MessageFactory messageFactory, Logger logger) {
/*  47 */     super(name, messageFactory);
/*  48 */     this.logger = logger;
/*  49 */     this.locationAwareLogger = (logger instanceof LocationAwareLogger) ? (LocationAwareLogger)logger : null;
/*     */   }
/*     */   
/*     */   public SLF4JLogger(String name, Logger logger) {
/*  53 */     super(name);
/*  54 */     this.logger = logger;
/*  55 */     this.locationAwareLogger = (logger instanceof LocationAwareLogger) ? (LocationAwareLogger)logger : null;
/*     */   }
/*     */   
/*     */   private int convertLevel(Level level) {
/*  59 */     switch (level.getStandardLevel()) {
/*     */       case DEBUG:
/*  61 */         return 10;
/*     */       case TRACE:
/*  63 */         return 0;
/*     */       case INFO:
/*  65 */         return 20;
/*     */       case WARN:
/*  67 */         return 30;
/*     */       case ERROR:
/*  69 */         return 40;
/*     */     } 
/*  71 */     return 40;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getLevel() {
/*  77 */     if (this.logger.isTraceEnabled()) {
/*  78 */       return Level.TRACE;
/*     */     }
/*  80 */     if (this.logger.isDebugEnabled()) {
/*  81 */       return Level.DEBUG;
/*     */     }
/*  83 */     if (this.logger.isInfoEnabled()) {
/*  84 */       return Level.INFO;
/*     */     }
/*  86 */     if (this.logger.isWarnEnabled()) {
/*  87 */       return Level.WARN;
/*     */     }
/*  89 */     if (this.logger.isErrorEnabled()) {
/*  90 */       return Level.ERROR;
/*     */     }
/*     */ 
/*     */     
/*  94 */     return Level.OFF;
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/*  98 */     return (this.locationAwareLogger != null) ? (Logger)this.locationAwareLogger : this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Marker getMarker(Marker marker) {
/* 104 */     return (marker == null) ? null : convertMarker(marker);
/*     */   }
/*     */   
/*     */   private static Marker convertMarker(Marker marker) {
/* 108 */     Marker slf4jMarker = MarkerFactory.getMarker(marker.getName());
/* 109 */     Marker[] parents = marker.getParents();
/* 110 */     if (parents != null) {
/* 111 */       for (Marker parent : parents) {
/* 112 */         Marker slf4jParent = getMarker(parent);
/* 113 */         if (!slf4jMarker.contains(slf4jParent)) {
/* 114 */           slf4jMarker.add(slf4jParent);
/*     */         }
/*     */       } 
/*     */     }
/* 118 */     return slf4jMarker;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Message data, Throwable t) {
/* 123 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, CharSequence data, Throwable t) {
/* 128 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Object data, Throwable t) {
/* 133 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String data) {
/* 138 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String data, Object... p1) {
/* 143 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0) {
/* 148 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1) {
/* 154 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 165 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 177 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 190 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 204 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 219 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 235 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 252 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 270 */     return isEnabledFor(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String data, Throwable t) {
/* 275 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   private boolean isEnabledFor(Level level, Marker marker) {
/* 279 */     Marker slf4jMarker = getMarker(marker);
/* 280 */     switch (level.getStandardLevel()) {
/*     */       case DEBUG:
/* 282 */         return this.logger.isDebugEnabled(slf4jMarker);
/*     */       case TRACE:
/* 284 */         return this.logger.isTraceEnabled(slf4jMarker);
/*     */       case INFO:
/* 286 */         return this.logger.isInfoEnabled(slf4jMarker);
/*     */       case WARN:
/* 288 */         return this.logger.isWarnEnabled(slf4jMarker);
/*     */       case ERROR:
/* 290 */         return this.logger.isErrorEnabled(slf4jMarker);
/*     */     } 
/* 292 */     return this.logger.isErrorEnabled(slf4jMarker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logMessage(String fqcn, Level level, Marker marker, Message message, Throwable t) {
/* 299 */     Marker slf4jMarker = getMarker(marker);
/* 300 */     String formattedMessage = message.getFormattedMessage();
/* 301 */     if (this.locationAwareLogger != null) {
/* 302 */       if (message instanceof LoggerNameAwareMessage) {
/* 303 */         ((LoggerNameAwareMessage)message).setLoggerName(getName());
/*     */       }
/* 305 */       this.locationAwareLogger.log(slf4jMarker, fqcn, convertLevel(level), formattedMessage, null, t);
/*     */     } else {
/* 307 */       switch (level.getStandardLevel()) {
/*     */         case DEBUG:
/* 309 */           this.logger.debug(slf4jMarker, formattedMessage, t);
/*     */           return;
/*     */         case TRACE:
/* 312 */           this.logger.trace(slf4jMarker, formattedMessage, t);
/*     */           return;
/*     */         case INFO:
/* 315 */           this.logger.info(slf4jMarker, formattedMessage, t);
/*     */           return;
/*     */         case WARN:
/* 318 */           this.logger.warn(slf4jMarker, formattedMessage, t);
/*     */           return;
/*     */         case ERROR:
/* 321 */           this.logger.error(slf4jMarker, formattedMessage, t);
/*     */           return;
/*     */       } 
/* 324 */       this.logger.error(slf4jMarker, formattedMessage, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogBuilder always() {
/* 332 */     return atLevel(Level.OFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atTrace() {
/* 337 */     return atLevel(Level.TRACE);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atDebug() {
/* 342 */     return atLevel(Level.DEBUG);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atInfo() {
/* 347 */     return atLevel(Level.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atWarn() {
/* 352 */     return atLevel(Level.WARN);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atError() {
/* 357 */     return atLevel(Level.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder atFatal() {
/* 362 */     return atLevel(Level.TRACE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LogBuilder getLogBuilder(Level level) {
/* 367 */     SLF4JLogBuilder builder = logBuilder.get();
/* 368 */     return (Constants.ENABLE_THREADLOCALS && !builder.isInUse()) ? 
/* 369 */       builder.reset(this, level) : 
/* 370 */       new SLF4JLogBuilder(this, level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LogBuilder atLevel(Level level) {
/* 376 */     if (LAZY_LEVEL_CHECK) {
/* 377 */       return getLogBuilder(level);
/*     */     }
/* 379 */     return super.atLevel(level);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\SLF4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */