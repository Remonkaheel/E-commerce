/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import org.apache.logging.log4j.message.MessageFactory;
/*    */ import org.apache.logging.log4j.message.ParameterizedMessageFactory;
/*    */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*    */ import org.apache.logging.log4j.spi.LoggerContext;
/*    */ import org.apache.logging.log4j.spi.LoggerRegistry;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SLF4JLoggerContext
/*    */   implements LoggerContext
/*    */ {
/* 29 */   private final LoggerRegistry<ExtendedLogger> loggerRegistry = new LoggerRegistry();
/*    */   
/* 31 */   private static final MessageFactory DEFAULT_MESSAGE_FACTORY = (MessageFactory)ParameterizedMessageFactory.INSTANCE;
/*    */ 
/*    */   
/*    */   public Object getExternalContext() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtendedLogger getLogger(String name) {
/* 40 */     return getLogger(name, DEFAULT_MESSAGE_FACTORY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtendedLogger getLogger(String name, MessageFactory messageFactory) {
/* 46 */     MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : DEFAULT_MESSAGE_FACTORY;
/* 47 */     ExtendedLogger oldLogger = this.loggerRegistry.getLogger(name, effectiveMessageFactory);
/* 48 */     if (oldLogger != null) {
/* 49 */       return oldLogger;
/*    */     }
/* 51 */     ExtendedLogger newLogger = createLogger(name, effectiveMessageFactory);
/* 52 */     this.loggerRegistry.putIfAbsent(name, effectiveMessageFactory, newLogger);
/* 53 */     return this.loggerRegistry.getLogger(name, effectiveMessageFactory);
/*    */   }
/*    */   
/*    */   private static ExtendedLogger createLogger(String name, MessageFactory messageFactory) {
/* 57 */     Logger logger = LoggerFactory.getLogger(name);
/* 58 */     return (ExtendedLogger)new SLF4JLogger(name, messageFactory, logger);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLogger(String name) {
/* 63 */     return this.loggerRegistry.hasLogger(name, DEFAULT_MESSAGE_FACTORY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasLogger(String name, MessageFactory messageFactory) {
/* 69 */     MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : DEFAULT_MESSAGE_FACTORY;
/* 70 */     return this.loggerRegistry.hasLogger(name, effectiveMessageFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLogger(String name, Class<? extends MessageFactory> messageFactoryClass) {
/* 75 */     return this.loggerRegistry.hasLogger(name, messageFactoryClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-to-slf4j-2.24.3.jar!\org\apache\logging\slf4j\SLF4JLoggerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */