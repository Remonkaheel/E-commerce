/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormHttpMessageReader
/*     */   extends LoggingCodecSupport
/*     */   implements HttpMessageReader<MultiValueMap<String, String>>
/*     */ {
/*  56 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/*  59 */   private static final ResolvableType MULTIVALUE_STRINGS_TYPE = ResolvableType.forClassWithGenerics(MultiValueMap.class, new Class[] { String.class, String.class });
/*     */ 
/*     */   
/*  62 */   private Charset defaultCharset = DEFAULT_CHARSET;
/*     */   
/*  64 */   private int maxInMemorySize = 262144;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(Charset charset) {
/*  73 */     Assert.notNull(charset, "Charset must not be null");
/*  74 */     this.defaultCharset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getDefaultCharset() {
/*  81 */     return this.defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/*  93 */     this.maxInMemorySize = byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/* 101 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 107 */     if (!supportsMediaType(mediaType)) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (MultiValueMap.class.isAssignableFrom(elementType.toClass()) && elementType.hasUnresolvableGenerics()) {
/* 111 */       return true;
/*     */     }
/* 113 */     return MULTIVALUE_STRINGS_TYPE.isAssignableFrom(elementType);
/*     */   }
/*     */   
/*     */   private static boolean supportsMediaType(@Nullable MediaType mediaType) {
/* 117 */     return (mediaType == null || MediaType.APPLICATION_FORM_URLENCODED.isCompatibleWith(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<MultiValueMap<String, String>> read(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 124 */     return Flux.from((Publisher)readMono(elementType, message, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<MultiValueMap<String, String>> readMono(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 131 */     MediaType contentType = message.getHeaders().getContentType();
/* 132 */     Charset charset = getMediaTypeCharset(contentType);
/*     */     
/* 134 */     return DataBufferUtils.join((Publisher)message.getBody(), this.maxInMemorySize)
/* 135 */       .map(buffer -> {
/*     */           String body = buffer.toString(charset);
/*     */           DataBufferUtils.release(buffer);
/*     */           MultiValueMap<String, String> formData = parseFormData(charset, body);
/*     */           logFormData(formData, hints);
/*     */           return formData;
/*     */         });
/*     */   }
/*     */   
/*     */   private void logFormData(MultiValueMap<String, String> formData, Map<String, Object> hints) {
/* 145 */     LogFormatUtils.traceDebug(this.logger, traceOn -> Hints.getLogPrefix(hints) + "Read " + Hints.getLogPrefix(hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Charset getMediaTypeCharset(@Nullable MediaType mediaType) {
/* 152 */     if (mediaType != null && mediaType.getCharset() != null) {
/* 153 */       return mediaType.getCharset();
/*     */     }
/*     */     
/* 156 */     return getDefaultCharset();
/*     */   }
/*     */ 
/*     */   
/*     */   private MultiValueMap<String, String> parseFormData(Charset charset, String body) {
/* 161 */     String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
/* 162 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap(pairs.length);
/* 163 */     for (String pair : pairs) {
/* 164 */       int idx = pair.indexOf('=');
/* 165 */       if (idx == -1) {
/* 166 */         linkedMultiValueMap.add(URLDecoder.decode(pair, charset), null);
/*     */       } else {
/*     */         
/* 169 */         String name = URLDecoder.decode(pair.substring(0, idx), charset);
/* 170 */         String value = URLDecoder.decode(pair.substring(idx + 1), charset);
/* 171 */         linkedMultiValueMap.add(name, value);
/*     */       } 
/*     */     } 
/* 174 */     return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getReadableMediaTypes() {
/* 179 */     return Collections.singletonList(MediaType.APPLICATION_FORM_URLENCODED);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\FormHttpMessageReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */