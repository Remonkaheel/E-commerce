/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlinx.serialization.BinaryFormat;
/*     */ import kotlinx.serialization.DeserializationStrategy;
/*     */ import kotlinx.serialization.KSerializer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.ByteArrayDecoder;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KotlinSerializationBinaryDecoder<T extends BinaryFormat>
/*     */   extends KotlinSerializationSupport<T>
/*     */   implements Decoder<Object>
/*     */ {
/*  50 */   private final ByteArrayDecoder byteArrayDecoder = new ByteArrayDecoder();
/*     */ 
/*     */   
/*     */   public KotlinSerializationBinaryDecoder(T format, MimeType... supportedMimeTypes) {
/*  54 */     super(format, supportedMimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/*  69 */     this.byteArrayDecoder.setMaxInMemorySize(byteCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/*  76 */     return this.byteArrayDecoder.getMaxInMemorySize();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  81 */     return canSerialize(elementType, mimeType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes() {
/*  86 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes(ResolvableType targetType) {
/*  91 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Object> decode(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  99 */     return Flux.error(new UnsupportedOperationException());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> decodeToMono(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 105 */     return Mono.defer(() -> {
/*     */           KSerializer<Object> serializer = serializer(elementType);
/*     */           return (serializer == null) ? Mono.error((Throwable)new DecodingException("Could not find KSerializer for " + String.valueOf(elementType))) : this.byteArrayDecoder.decodeToMono(inputStream, elementType, mimeType, hints).handle(());
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\KotlinSerializationBinaryDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */