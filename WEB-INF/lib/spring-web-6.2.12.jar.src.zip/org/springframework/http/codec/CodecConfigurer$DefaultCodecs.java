package org.springframework.http.codec;

import java.util.function.Consumer;
import org.springframework.core.codec.Decoder;
import org.springframework.core.codec.Encoder;

public interface DefaultCodecs {
  void jackson2JsonDecoder(Decoder<?> paramDecoder);
  
  void jackson2JsonEncoder(Encoder<?> paramEncoder);
  
  void jackson2SmileDecoder(Decoder<?> paramDecoder);
  
  void jackson2SmileEncoder(Encoder<?> paramEncoder);
  
  void protobufDecoder(Decoder<?> paramDecoder);
  
  void protobufEncoder(Encoder<?> paramEncoder);
  
  void jaxb2Decoder(Decoder<?> paramDecoder);
  
  void jaxb2Encoder(Encoder<?> paramEncoder);
  
  void kotlinSerializationCborDecoder(Decoder<?> paramDecoder);
  
  void kotlinSerializationCborEncoder(Encoder<?> paramEncoder);
  
  void kotlinSerializationJsonDecoder(Decoder<?> paramDecoder);
  
  void kotlinSerializationJsonEncoder(Encoder<?> paramEncoder);
  
  void kotlinSerializationProtobufDecoder(Decoder<?> paramDecoder);
  
  void kotlinSerializationProtobufEncoder(Encoder<?> paramEncoder);
  
  void configureDefaultCodec(Consumer<Object> paramConsumer);
  
  void maxInMemorySize(int paramInt);
  
  void enableLoggingRequestDetails(boolean paramBoolean);
  
  CodecConfigurer.MultipartCodecs multipartCodecs();
  
  void multipartReader(HttpMessageReader<?> paramHttpMessageReader);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\CodecConfigurer$DefaultCodecs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */