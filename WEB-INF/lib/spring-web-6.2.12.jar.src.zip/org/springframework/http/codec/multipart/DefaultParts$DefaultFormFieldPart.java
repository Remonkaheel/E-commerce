/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultFormFieldPart
/*     */   extends DefaultParts.AbstractPart
/*     */   implements FormFieldPart
/*     */ {
/*     */   private final String value;
/*     */   
/*     */   public DefaultFormFieldPart(HttpHeaders headers, String value) {
/* 136 */     super(headers);
/* 137 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> content() {
/* 142 */     return Flux.defer(() -> {
/*     */           byte[] bytes = this.value.getBytes(MultipartUtils.charset(headers()));
/*     */           return (Publisher)Flux.just(DefaultDataBufferFactory.sharedInstance.wrap(bytes));
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public String value() {
/* 150 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     String name = headers().getContentDisposition().getName();
/* 156 */     if (name != null) {
/* 157 */       return "DefaultFormFieldPart{" + name() + "}";
/*     */     }
/*     */     
/* 160 */     return "DefaultFormFieldPart";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultParts$DefaultFormFieldPart.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */