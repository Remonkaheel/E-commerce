/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartHttpMessageWriter
/*     */   extends MultipartWriterSupport
/*     */   implements HttpMessageWriter<Part>
/*     */ {
/*     */   public PartHttpMessageWriter() {
/*  48 */     super(MultipartHttpMessageReader.MIME_TYPES);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/*  53 */     if (Part.class.isAssignableFrom(elementType.toClass())) {
/*  54 */       if (mediaType == null) {
/*  55 */         return true;
/*     */       }
/*  57 */       for (MediaType supportedMediaType : getWritableMediaTypes()) {
/*  58 */         if (supportedMediaType.isCompatibleWith(mediaType)) {
/*  59 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends Part> parts, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage outputMessage, Map<String, Object> hints) {
/*  72 */     byte[] boundary = generateMultipartBoundary();
/*     */     
/*  74 */     mediaType = getMultipartMediaType(mediaType, boundary);
/*  75 */     outputMessage.getHeaders().setContentType(mediaType);
/*     */     
/*  77 */     if (this.logger.isDebugEnabled()) {
/*  78 */       this.logger.debug(Hints.getLogPrefix(hints) + "Encoding Publisher<Part>");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     Flux<DataBuffer> body = Flux.from(parts).concatMap(part -> encodePart(boundary, part, outputMessage.bufferFactory())).concatWith((Publisher)generateLastLine(boundary, outputMessage.bufferFactory())).doOnDiscard(DataBuffer.class, DataBufferUtils::release);
/*     */     
/*  86 */     if (this.logger.isDebugEnabled()) {
/*  87 */       body = body.doOnNext(buffer -> Hints.touchDataBuffer(buffer, hints, this.logger));
/*     */     }
/*     */     
/*  90 */     return outputMessage.writeWith((Publisher)body);
/*     */   }
/*     */   
/*     */   private <T> Flux<DataBuffer> encodePart(byte[] boundary, Part part, DataBufferFactory bufferFactory) {
/*  94 */     HttpHeaders headers = new HttpHeaders((MultiValueMap)part.headers());
/*     */     
/*  96 */     String name = part.name();
/*  97 */     if (!headers.containsKey("Content-Disposition")) {
/*     */       
/*  99 */       FilePart filePart = (FilePart)part; headers.setContentDispositionFormData(name, (part instanceof FilePart) ? filePart.filename() : null);
/*     */     } 
/*     */     
/* 102 */     return Flux.concat(new Publisher[] { (Publisher)
/* 103 */           generateBoundaryLine(boundary, bufferFactory), (Publisher)
/* 104 */           generatePartHeaders(headers, bufferFactory), (Publisher)part
/* 105 */           .content(), (Publisher)
/* 106 */           generateNewLine(bufferFactory) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\PartHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */