/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Path;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.ContentDisposition;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FilePartEvent
/*     */   extends PartEvent
/*     */ {
/*     */   default String filename() {
/*  70 */     String filename = headers().getContentDisposition().getFilename();
/*  71 */     Assert.state((filename != null), "No filename found");
/*  72 */     return filename;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String name, Resource resource) {
/*  84 */     return create(name, resource, (Consumer<HttpHeaders>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String name, Resource resource, @Nullable Consumer<HttpHeaders> headersConsumer) {
/*     */     try {
/*  97 */       return create(name, resource.getFile().toPath(), headersConsumer);
/*     */     }
/*  99 */     catch (IOException ex) {
/* 100 */       return Flux.error(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String name, Path path) {
/* 112 */     return create(name, path, (Consumer<HttpHeaders>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String name, Path path, @Nullable Consumer<HttpHeaders> headersConsumer) {
/* 124 */     Assert.hasLength(name, "Name must not be empty");
/* 125 */     Assert.notNull(path, "Path must not be null");
/*     */     
/* 127 */     return Flux.defer(() -> {
/*     */           String pathName = StringUtils.cleanPath(path.toString());
/*     */           MediaType contentType = MediaTypeFactory.getMediaType(pathName).orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */           String filename = StringUtils.getFilename(pathName);
/*     */           if (filename == null) {
/*     */             return (Publisher)Flux.error(new IllegalArgumentException("Invalid file: " + pathName));
/*     */           }
/*     */           Flux<DataBuffer> contents = DataBufferUtils.read(path, (DataBufferFactory)DefaultDataBufferFactory.sharedInstance, 8192, new java.nio.file.OpenOption[0]);
/*     */           return (Publisher)create(name, filename, contentType, contents, headersConsumer);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String partName, String filename, MediaType contentType, Flux<DataBuffer> contents) {
/* 154 */     return create(partName, filename, contentType, contents, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Flux<FilePartEvent> create(String partName, String filename, MediaType contentType, Flux<DataBuffer> contents, @Nullable Consumer<HttpHeaders> headersConsumer) {
/* 171 */     Assert.hasLength(partName, "PartName must not be empty");
/* 172 */     Assert.hasLength(filename, "Filename must not be empty");
/* 173 */     Assert.notNull(contentType, "ContentType must not be null");
/* 174 */     Assert.notNull(contents, "Contents must not be null");
/*     */     
/* 176 */     return Flux.defer(() -> {
/*     */           HttpHeaders headers = new HttpHeaders();
/*     */           headers.setContentType(contentType);
/*     */           headers.setContentDisposition(ContentDisposition.formData().name(partName).filename(filename, StandardCharsets.UTF_8).build());
/*     */           if (headersConsumer != null)
/*     */             headersConsumer.accept(headers); 
/*     */           return (Publisher)contents.map(()).concatWith((Publisher)Mono.just(DefaultPartEvents.file(headers)));
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\FilePartEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */