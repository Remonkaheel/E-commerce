/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultFormFieldPartEvent
/*     */   extends DefaultPartEvents.AbstractPartEvent
/*     */   implements FormPartEvent
/*     */ {
/*     */   private static final String EMPTY = "";
/*     */   private final String value;
/*     */   
/*     */   public DefaultFormFieldPartEvent(HttpHeaders headers) {
/* 138 */     this(headers, "");
/*     */   }
/*     */   
/*     */   public DefaultFormFieldPartEvent(HttpHeaders headers, String value) {
/* 142 */     super(headers);
/* 143 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String value() {
/* 148 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBuffer content() {
/* 153 */     byte[] bytes = this.value.getBytes(MultipartUtils.charset(headers()));
/* 154 */     return (DataBuffer)DefaultDataBufferFactory.sharedInstance.wrap(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/* 159 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultPartEvents$DefaultFormFieldPartEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */