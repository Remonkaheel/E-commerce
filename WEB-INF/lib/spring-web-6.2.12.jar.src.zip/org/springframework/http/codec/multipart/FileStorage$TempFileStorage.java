/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TempFileStorage
/*     */   extends FileStorage
/*     */ {
/*     */   private static final String IDENTIFIER = "spring-multipart-";
/*     */   private final Supplier<Scheduler> scheduler;
/*  91 */   private volatile Mono<Path> directory = tempDirectory();
/*     */ 
/*     */   
/*     */   public TempFileStorage(Supplier<Scheduler> scheduler) {
/*  95 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Path> directory() {
/* 100 */     return this.directory
/* 101 */       .flatMap(this::createNewDirectoryIfDeleted)
/* 102 */       .subscribeOn(this.scheduler.get());
/*     */   }
/*     */   
/*     */   private Mono<Path> createNewDirectoryIfDeleted(Path directory) {
/* 106 */     if (!Files.exists(directory, new java.nio.file.LinkOption[0])) {
/*     */       
/* 108 */       Mono<Path> newDirectory = tempDirectory();
/* 109 */       this.directory = newDirectory;
/* 110 */       return newDirectory;
/*     */     } 
/*     */     
/* 113 */     return Mono.just(directory);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<Path> tempDirectory() {
/* 118 */     return Mono.fromCallable(() -> {
/*     */           Path directory = Files.createTempDirectory("spring-multipart-", (FileAttribute<?>[])new FileAttribute[0]);
/*     */           if (FileStorage.logger.isDebugEnabled()) {
/*     */             FileStorage.logger.debug("Created temporary storage directory: " + String.valueOf(directory));
/*     */           }
/*     */           return directory;
/* 124 */         }).cache();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\FileStorage$TempFileStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */