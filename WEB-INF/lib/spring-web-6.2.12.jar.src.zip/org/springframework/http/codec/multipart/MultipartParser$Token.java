package org.springframework.http.codec.multipart;

import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;

public abstract class Token {
  public abstract HttpHeaders headers();
  
  public abstract DataBuffer buffer();
  
  public abstract boolean isLast();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartParser$Token.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */