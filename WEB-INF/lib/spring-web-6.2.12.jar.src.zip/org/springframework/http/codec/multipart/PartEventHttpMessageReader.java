/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.http.codec.HttpMessageReader;
/*     */ import org.springframework.http.codec.LoggingCodecSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Signal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartEventHttpMessageReader
/*     */   extends LoggingCodecSupport
/*     */   implements HttpMessageReader<PartEvent>
/*     */ {
/*  55 */   private int maxInMemorySize = 262144;
/*     */   
/*  57 */   private int maxHeadersSize = 10240;
/*     */   
/*  59 */   private int maxParts = -1;
/*     */   
/*  61 */   private long maxPartSize = -1L;
/*     */   
/*  63 */   private Charset headersCharset = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/*  70 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int maxInMemorySize) {
/*  83 */     this.maxInMemorySize = maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxHeadersSize(int byteCount) {
/*  92 */     this.maxHeadersSize = byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxParts(int maxParts) {
/* 101 */     this.maxParts = maxParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxPartSize(long maxPartSize) {
/* 110 */     this.maxPartSize = maxPartSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeadersCharset(Charset headersCharset) {
/* 120 */     Assert.notNull(headersCharset, "Charset must not be null");
/* 121 */     this.headersCharset = headersCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MediaType> getReadableMediaTypes() {
/* 127 */     return Collections.singletonList(MediaType.MULTIPART_FORM_DATA);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 132 */     return (PartEvent.class.equals(elementType.toClass()) && (mediaType == null || MediaType.MULTIPART_FORM_DATA
/* 133 */       .isCompatibleWith(mediaType)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<PartEvent> readMono(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 139 */     return Mono.error(new UnsupportedOperationException("Cannot read multipart request body into single PartEvent"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<PartEvent> read(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 147 */     return Flux.defer(() -> {
/*     */           byte[] boundary = MultipartUtils.boundary((HttpMessage)message, this.headersCharset);
/*     */           if (boundary == null) {
/*     */             return (Publisher)Flux.error((Throwable)new DecodingException("No multipart boundary found in Content-Type: \"" + String.valueOf(message.getHeaders().getContentType()) + "\""));
/*     */           }
/*     */           Flux<MultipartParser.Token> allPartsTokens = MultipartParser.parse(message.getBody(), boundary, this.maxHeadersSize, this.headersCharset);
/*     */           AtomicInteger partCount = new AtomicInteger();
/*     */           Objects.requireNonNull(MultipartParser.HeadersToken.class);
/*     */           return (Publisher)allPartsTokens.windowUntil(MultipartParser.HeadersToken.class::isInstance, true).concatMap(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tooManyParts(AtomicInteger partCount) {
/* 179 */     int count = partCount.incrementAndGet();
/* 180 */     return (this.maxParts > 0 && count > this.maxParts);
/*     */   }
/*     */ 
/*     */   
/*     */   private Publisher<? extends PartEvent> createEvents(HttpHeaders headers, Flux<MultipartParser.BodyToken> bodyTokens) {
/* 185 */     if (MultipartUtils.isFormField(headers)) {
/* 186 */       int maxSize; Flux<DataBuffer> contents = bodyTokens.map(MultipartParser.BodyToken::buffer);
/*     */       
/* 188 */       if (this.maxPartSize == -1L) {
/* 189 */         maxSize = this.maxInMemorySize;
/*     */       }
/*     */       else {
/*     */         
/* 193 */         maxSize = (int)Math.min(this.maxInMemorySize, this.maxPartSize);
/*     */       } 
/* 195 */       return (Publisher<? extends PartEvent>)DataBufferUtils.join((Publisher)contents, maxSize)
/* 196 */         .map(content -> {
/*     */             String value = content.toString(MultipartUtils.charset(headers));
/*     */             
/*     */             DataBufferUtils.release(content);
/*     */             return DefaultPartEvents.form(headers, value);
/* 201 */           }).switchIfEmpty(Mono.fromCallable(() -> DefaultPartEvents.form(headers)));
/*     */     } 
/*     */     
/* 204 */     boolean isFilePart = (headers.getContentDisposition().getFilename() != null);
/* 205 */     AtomicLong partSize = new AtomicLong();
/* 206 */     return (Publisher<? extends PartEvent>)bodyTokens
/* 207 */       .concatMap(body -> {
/*     */           DataBuffer buffer = body.buffer();
/*     */ 
/*     */           
/*     */           if (tooLarge(partSize, buffer)) {
/*     */             DataBufferUtils.release(buffer);
/*     */ 
/*     */             
/*     */             return (Publisher)Mono.error((Throwable)new DataBufferLimitException("Part exceeded the limit of " + this.maxPartSize + " bytes"));
/*     */           } 
/*     */           
/*     */           return isFilePart ? (Publisher)Mono.just(DefaultPartEvents.file(headers, buffer, body.isLast())) : (Publisher)Mono.just(DefaultPartEvents.create(headers, body.buffer(), body.isLast()));
/* 219 */         }).switchIfEmpty((Publisher)Mono.fromCallable(() -> isFilePart ? DefaultPartEvents.file(headers) : DefaultPartEvents.create(headers)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tooLarge(AtomicLong partSize, DataBuffer buffer) {
/* 225 */     if (this.maxPartSize != -1L) {
/* 226 */       long size = partSize.addAndGet(buffer.readableByteCount());
/* 227 */       return (size > this.maxPartSize);
/*     */     } 
/*     */     
/* 230 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\PartEventHttpMessageReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */