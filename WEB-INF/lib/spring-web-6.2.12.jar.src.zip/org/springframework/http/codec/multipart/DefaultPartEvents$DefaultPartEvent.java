/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultPartEvent
/*     */   extends DefaultPartEvents.AbstractPartEvent
/*     */ {
/*  98 */   private static final DataBuffer EMPTY = (DataBuffer)DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
/*     */   
/*     */   private final DataBuffer content;
/*     */   
/*     */   private final boolean last;
/*     */ 
/*     */   
/*     */   public DefaultPartEvent(HttpHeaders headers) {
/* 106 */     this(headers, EMPTY, true);
/*     */   }
/*     */   
/*     */   public DefaultPartEvent(HttpHeaders headers, DataBuffer content, boolean last) {
/* 110 */     super(headers);
/* 111 */     this.content = content;
/* 112 */     this.last = last;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBuffer content() {
/* 117 */     return this.content;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/* 122 */     return this.last;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultPartEvents$DefaultPartEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */