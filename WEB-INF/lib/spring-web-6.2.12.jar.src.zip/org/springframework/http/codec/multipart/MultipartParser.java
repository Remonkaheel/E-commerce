/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.BaseSubscriber;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxSink;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MultipartParser
/*     */   extends BaseSubscriber<DataBuffer>
/*     */ {
/*     */   private static final byte CR = 13;
/*     */   private static final byte LF = 10;
/*  59 */   private static final byte[] CR_LF = new byte[] { 13, 10 };
/*     */   
/*     */   private static final byte HYPHEN = 45;
/*     */   
/*  63 */   private static final byte[] TWO_HYPHENS = new byte[] { 45, 45 };
/*     */   
/*     */   private static final String HEADER_ENTRY_SEPARATOR = "\\r\\n";
/*     */   
/*  67 */   private static final Log logger = LogFactory.getLog(MultipartParser.class);
/*     */   
/*     */   private final AtomicReference<State> state;
/*     */   
/*     */   private final FluxSink<Token> sink;
/*     */   
/*     */   private final byte[] boundary;
/*     */   
/*     */   private final int maxHeadersSize;
/*     */   
/*  77 */   private final AtomicBoolean requestOutstanding = new AtomicBoolean();
/*     */   
/*     */   private final Charset headersCharset;
/*     */ 
/*     */   
/*     */   private MultipartParser(FluxSink<Token> sink, byte[] boundary, int maxHeadersSize, Charset headersCharset) {
/*  83 */     this.sink = sink;
/*  84 */     this.boundary = boundary;
/*  85 */     this.maxHeadersSize = maxHeadersSize;
/*  86 */     this.headersCharset = headersCharset;
/*  87 */     this.state = new AtomicReference<>(new PreambleState());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Flux<Token> parse(Flux<DataBuffer> buffers, byte[] boundary, int maxHeadersSize, Charset headersCharset) {
/* 100 */     return Flux.create(sink -> {
/*     */           MultipartParser parser = new MultipartParser(sink, boundary, maxHeadersSize, headersCharset);
/*     */           Objects.requireNonNull(parser);
/*     */           sink.onCancel(parser::onSinkCancel);
/*     */           sink.onRequest(());
/*     */           buffers.subscribe((CoreSubscriber)parser);
/*     */         });
/*     */   }
/*     */   
/*     */   public Context currentContext() {
/* 110 */     return Context.of(this.sink.contextView());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnSubscribe(Subscription subscription) {
/* 115 */     if (this.sink.requestedFromDownstream() > 0L) {
/* 116 */       requestBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnNext(DataBuffer value) {
/* 122 */     this.requestOutstanding.set(false);
/* 123 */     ((State)this.state.get()).onNext(value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnComplete() {
/* 128 */     ((State)this.state.get()).onComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnError(Throwable throwable) {
/* 133 */     State oldState = this.state.getAndSet(DisposedState.INSTANCE);
/* 134 */     oldState.dispose();
/* 135 */     this.sink.error(throwable);
/*     */   }
/*     */   
/*     */   private void onSinkCancel() {
/* 139 */     State oldState = this.state.getAndSet(DisposedState.INSTANCE);
/* 140 */     oldState.dispose();
/* 141 */     cancel();
/*     */   }
/*     */   
/*     */   boolean changeState(State oldState, State newState, @Nullable DataBuffer remainder) {
/* 145 */     if (this.state.compareAndSet(oldState, newState)) {
/* 146 */       if (logger.isTraceEnabled()) {
/* 147 */         logger.trace("Changed state: " + String.valueOf(oldState) + " -> " + String.valueOf(newState));
/*     */       }
/* 149 */       oldState.dispose();
/* 150 */       if (remainder != null) {
/* 151 */         if (remainder.readableByteCount() > 0) {
/* 152 */           newState.onNext(remainder);
/*     */         } else {
/*     */           
/* 155 */           DataBufferUtils.release(remainder);
/* 156 */           requestBuffer();
/*     */         } 
/*     */       }
/* 159 */       return true;
/*     */     } 
/*     */     
/* 162 */     DataBufferUtils.release(remainder);
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void emitHeaders(HttpHeaders headers) {
/* 168 */     if (logger.isTraceEnabled()) {
/* 169 */       logger.trace("Emitting headers: " + String.valueOf(headers));
/*     */     }
/* 171 */     this.sink.next(new HeadersToken(headers));
/*     */   }
/*     */   
/*     */   void emitBody(DataBuffer buffer, boolean last) {
/* 175 */     if (logger.isTraceEnabled()) {
/* 176 */       logger.trace("Emitting body: " + String.valueOf(buffer));
/*     */     }
/* 178 */     this.sink.next(new BodyToken(buffer, last));
/*     */   }
/*     */   
/*     */   void emitError(Throwable t) {
/* 182 */     cancel();
/* 183 */     this.sink.error(t);
/*     */   }
/*     */   
/*     */   void emitComplete() {
/* 187 */     cancel();
/* 188 */     this.sink.complete();
/*     */   }
/*     */   
/*     */   private void requestBuffer() {
/* 192 */     if (upstream() != null && 
/* 193 */       !this.sink.isCancelled() && this.sink
/* 194 */       .requestedFromDownstream() > 0L && this.requestOutstanding
/* 195 */       .compareAndSet(false, true)) {
/* 196 */       request(1L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Token
/*     */   {
/*     */     public abstract HttpHeaders headers();
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract DataBuffer buffer();
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean isLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class HeadersToken
/*     */     extends Token
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */ 
/*     */     
/*     */     public HeadersToken(HttpHeaders headers) {
/* 223 */       this.headers = headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders headers() {
/* 228 */       return this.headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public DataBuffer buffer() {
/* 233 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLast() {
/* 238 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class BodyToken
/*     */     extends Token
/*     */   {
/*     */     private final DataBuffer buffer;
/*     */ 
/*     */     
/*     */     private final boolean last;
/*     */ 
/*     */     
/*     */     public BodyToken(DataBuffer buffer, boolean last) {
/* 254 */       this.buffer = buffer;
/* 255 */       this.last = last;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders headers() {
/* 260 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     public DataBuffer buffer() {
/* 265 */       return this.buffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLast() {
/* 270 */       return this.last;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface State
/*     */   {
/*     */     void onNext(DataBuffer param1DataBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void onComplete();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default void dispose() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class PreambleState
/*     */     implements State
/*     */   {
/*     */     private final DataBufferUtils.Matcher firstBoundary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PreambleState() {
/* 312 */       this.firstBoundary = DataBufferUtils.matcher(
/* 313 */           MultipartUtils.concat(new byte[][] { MultipartParser.TWO_HYPHENS, this$0.boundary }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(DataBuffer buf) {
/* 323 */       int endIdx = this.firstBoundary.match(buf);
/* 324 */       if (endIdx != -1) {
/* 325 */         if (MultipartParser.logger.isTraceEnabled()) {
/* 326 */           MultipartParser.logger.trace("First boundary found @" + endIdx + " in " + String.valueOf(buf));
/*     */         }
/* 328 */         DataBuffer preambleBuffer = buf.split(endIdx + 1);
/* 329 */         DataBufferUtils.release(preambleBuffer);
/*     */         
/* 331 */         MultipartParser.this.changeState(this, new MultipartParser.HeadersState(), buf);
/*     */       } else {
/*     */         
/* 334 */         DataBufferUtils.release(buf);
/* 335 */         MultipartParser.this.requestBuffer();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 341 */       if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, (DataBuffer)null)) {
/* 342 */         MultipartParser.this.emitError((Throwable)new DecodingException("Could not find first boundary"));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 348 */       return "PREAMBLE";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class HeadersState
/*     */     implements State
/*     */   {
/* 361 */     private final DataBufferUtils.Matcher endHeaders = DataBufferUtils.matcher(MultipartUtils.concat(new byte[][] { MultipartParser.CR_LF, MultipartParser.CR_LF }));
/*     */     
/* 363 */     private final AtomicInteger byteCount = new AtomicInteger();
/*     */     
/* 365 */     private final List<DataBuffer> buffers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(DataBuffer buf) {
/* 380 */       if (isLastBoundary(buf)) {
/* 381 */         if (MultipartParser.logger.isTraceEnabled()) {
/* 382 */           MultipartParser.logger.trace("Last boundary found in " + String.valueOf(buf));
/*     */         }
/*     */         
/* 385 */         if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, buf)) {
/* 386 */           MultipartParser.this.emitComplete();
/*     */         }
/*     */         return;
/*     */       } 
/* 390 */       int endIdx = this.endHeaders.match(buf);
/* 391 */       if (endIdx != -1) {
/* 392 */         if (MultipartParser.logger.isTraceEnabled()) {
/* 393 */           MultipartParser.logger.trace("End of headers found @" + endIdx + " in " + String.valueOf(buf));
/*     */         }
/* 395 */         long count = this.byteCount.addAndGet(endIdx);
/* 396 */         if (belowMaxHeaderSize(count)) {
/* 397 */           DataBuffer headerBuf = buf.split(endIdx + 1);
/* 398 */           this.buffers.add(headerBuf);
/* 399 */           MultipartParser.this.emitHeaders(parseHeaders());
/*     */           
/* 401 */           MultipartParser.this.changeState(this, new MultipartParser.BodyState(), buf);
/*     */         } 
/*     */       } else {
/*     */         
/* 405 */         long count = this.byteCount.addAndGet(buf.readableByteCount());
/* 406 */         if (belowMaxHeaderSize(count)) {
/* 407 */           this.buffers.add(buf);
/* 408 */           MultipartParser.this.requestBuffer();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isLastBoundary(DataBuffer buf) {
/* 418 */       return ((this.buffers.isEmpty() && buf
/* 419 */         .readableByteCount() >= 2 && buf
/* 420 */         .getByte(0) == 45 && buf.getByte(1) == 45) || (this.buffers
/* 421 */         .size() == 1 && ((DataBuffer)this.buffers
/* 422 */         .get(0)).readableByteCount() == 1 && ((DataBuffer)this.buffers
/* 423 */         .get(0)).getByte(0) == 45 && buf
/* 424 */         .readableByteCount() >= 1 && buf
/* 425 */         .getByte(0) == 45));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean belowMaxHeaderSize(long count) {
/* 433 */       if (count <= MultipartParser.this.maxHeadersSize) {
/* 434 */         return true;
/*     */       }
/*     */       
/* 437 */       MultipartParser.this.emitError((Throwable)new DataBufferLimitException("Part headers exceeded the memory usage limit of " + MultipartParser.this.maxHeadersSize + " bytes"));
/*     */       
/* 439 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private HttpHeaders parseHeaders() {
/* 449 */       if (this.buffers.isEmpty()) {
/* 450 */         return HttpHeaders.EMPTY;
/*     */       }
/* 452 */       DataBuffer joined = ((DataBuffer)this.buffers.get(0)).factory().join(this.buffers);
/* 453 */       this.buffers.clear();
/* 454 */       String string = joined.toString(MultipartParser.this.headersCharset);
/* 455 */       DataBufferUtils.release(joined);
/* 456 */       String[] lines = string.split("\\r\\n");
/* 457 */       HttpHeaders result = new HttpHeaders();
/* 458 */       for (String line : lines) {
/* 459 */         int idx = line.indexOf(':');
/* 460 */         if (idx != -1) {
/* 461 */           String name = line.substring(0, idx);
/* 462 */           String value = line.substring(idx + 1);
/* 463 */           while (value.startsWith(" ")) {
/* 464 */             value = value.substring(1);
/*     */           }
/* 466 */           result.add(name, value);
/*     */         } 
/*     */       } 
/* 469 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 474 */       if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, (DataBuffer)null)) {
/* 475 */         MultipartParser.this.emitError((Throwable)new DecodingException("Could not find end of headers"));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 481 */       this.buffers.forEach(DataBufferUtils::release);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 486 */       return "HEADERS";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class BodyState
/*     */     implements State
/*     */   {
/*     */     private final DataBufferUtils.Matcher boundary;
/*     */ 
/*     */ 
/*     */     
/*     */     private final int boundaryLength;
/*     */ 
/*     */ 
/*     */     
/* 504 */     private final Deque<DataBuffer> queue = new ConcurrentLinkedDeque<>();
/*     */     
/*     */     public BodyState() {
/* 507 */       byte[] delimiter = MultipartUtils.concat(new byte[][] { MultipartParser.CR_LF, MultipartParser.TWO_HYPHENS, this$0.boundary });
/* 508 */       this.boundary = DataBufferUtils.matcher(delimiter);
/* 509 */       this.boundaryLength = delimiter.length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(DataBuffer buffer) {
/* 522 */       int endIdx = this.boundary.match(buffer);
/* 523 */       if (endIdx != -1) {
/* 524 */         DataBuffer boundaryBuffer = buffer.split(endIdx + 1);
/* 525 */         if (MultipartParser.logger.isTraceEnabled()) {
/* 526 */           MultipartParser.logger.trace("Boundary found @" + endIdx + " in " + String.valueOf(buffer));
/*     */         }
/* 528 */         int len = endIdx - this.boundaryLength + 1 - boundaryBuffer.readPosition();
/* 529 */         if (len > 0) {
/*     */ 
/*     */           
/* 532 */           DataBuffer body = boundaryBuffer.split(len);
/* 533 */           DataBufferUtils.release(boundaryBuffer);
/* 534 */           enqueue(body);
/* 535 */           flush();
/*     */         }
/* 537 */         else if (len < 0) {
/*     */ 
/*     */           
/* 540 */           DataBufferUtils.release(boundaryBuffer);
/*     */           DataBuffer prev;
/* 542 */           while ((prev = this.queue.pollLast()) != null) {
/* 543 */             int prevByteCount = prev.readableByteCount();
/* 544 */             int prevLen = prevByteCount + len;
/* 545 */             if (prevLen >= 0) {
/*     */               
/* 547 */               DataBuffer body = prev.split(prevLen + prev.readPosition());
/* 548 */               DataBufferUtils.release(prev);
/* 549 */               enqueue(body);
/* 550 */               flush();
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 555 */             DataBufferUtils.release(prev);
/* 556 */             len += prevByteCount;
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 562 */           DataBufferUtils.release(boundaryBuffer);
/* 563 */           flush();
/*     */         } 
/*     */         
/* 566 */         MultipartParser.this.changeState(this, new MultipartParser.HeadersState(), buffer);
/*     */       } else {
/*     */         
/* 569 */         enqueue(buffer);
/* 570 */         MultipartParser.this.requestBuffer();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void enqueue(DataBuffer buf) {
/* 581 */       this.queue.add(buf);
/*     */       
/* 583 */       int len = 0;
/* 584 */       Deque<DataBuffer> emit = new ArrayDeque<>();
/* 585 */       for (Iterator<DataBuffer> iterator = this.queue.descendingIterator(); iterator.hasNext(); ) {
/* 586 */         DataBuffer previous = iterator.next();
/* 587 */         if (len > this.boundaryLength) {
/*     */           
/* 589 */           emit.addFirst(previous);
/* 590 */           iterator.remove();
/*     */         } 
/* 592 */         len += previous.readableByteCount();
/*     */       } 
/*     */       
/* 595 */       emit.forEach(buffer -> MultipartParser.this.emitBody(buffer, false));
/*     */     }
/*     */     
/*     */     private void flush() {
/* 599 */       for (Iterator<DataBuffer> iterator = this.queue.iterator(); iterator.hasNext(); ) {
/* 600 */         DataBuffer buffer = iterator.next();
/* 601 */         boolean last = !iterator.hasNext();
/* 602 */         MultipartParser.this.emitBody(buffer, last);
/*     */       } 
/* 604 */       this.queue.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 609 */       if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, (DataBuffer)null)) {
/* 610 */         String msg = "Could not find end of body (␍␊--" + new String(MultipartParser.this.boundary, StandardCharsets.UTF_8) + ")";
/*     */ 
/*     */         
/* 613 */         MultipartParser.this.emitError((Throwable)new DecodingException(msg));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 619 */       this.queue.forEach(DataBufferUtils::release);
/* 620 */       this.queue.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 625 */       return "BODY";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DisposedState
/*     */     implements State
/*     */   {
/* 636 */     public static final DisposedState INSTANCE = new DisposedState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(DataBuffer buf) {
/* 643 */       DataBufferUtils.release(buf);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     public String toString() {
/* 652 */       return "DISPOSED";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */