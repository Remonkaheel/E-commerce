/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.LoggingCodecSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FastByteArrayOutputStream;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartWriterSupport
/*     */   extends LoggingCodecSupport
/*     */ {
/*  46 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*     */   private final List<MediaType> supportedMediaTypes;
/*     */   
/*  50 */   private Charset charset = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultipartWriterSupport(List<MediaType> supportedMediaTypes) {
/*  57 */     this.supportedMediaTypes = supportedMediaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/*  65 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/*  76 */     Assert.notNull(charset, "Charset must not be null");
/*  77 */     this.charset = charset;
/*     */   }
/*     */   
/*     */   public List<MediaType> getWritableMediaTypes() {
/*  81 */     return this.supportedMediaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] generateMultipartBoundary() {
/*  89 */     return MimeTypeUtils.generateMultipartBoundary();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MediaType getMultipartMediaType(@Nullable MediaType mediaType, byte[] boundary) {
/*  98 */     Map<String, String> params = new HashMap<>();
/*  99 */     if (mediaType != null) {
/* 100 */       params.putAll(mediaType.getParameters());
/*     */     }
/* 102 */     params.put("boundary", new String(boundary, StandardCharsets.US_ASCII));
/* 103 */     Charset charset = getCharset();
/* 104 */     if (!charset.equals(StandardCharsets.UTF_8) && 
/* 105 */       !charset.equals(StandardCharsets.US_ASCII)) {
/* 106 */       params.put("charset", charset.name());
/*     */     }
/*     */     
/* 109 */     mediaType = (mediaType != null) ? mediaType : MediaType.MULTIPART_FORM_DATA;
/* 110 */     mediaType = new MediaType(mediaType, params);
/* 111 */     return mediaType;
/*     */   }
/*     */   
/*     */   protected Mono<DataBuffer> generateBoundaryLine(byte[] boundary, DataBufferFactory bufferFactory) {
/* 115 */     return Mono.fromCallable(() -> {
/*     */           DataBuffer buffer = bufferFactory.allocateBuffer(boundary.length + 4);
/*     */           buffer.write((byte)45);
/*     */           buffer.write((byte)45);
/*     */           buffer.write(boundary);
/*     */           buffer.write((byte)13);
/*     */           buffer.write((byte)10);
/*     */           return buffer;
/*     */         });
/*     */   }
/*     */   
/*     */   protected Mono<DataBuffer> generateNewLine(DataBufferFactory bufferFactory) {
/* 127 */     return Mono.fromCallable(() -> {
/*     */           DataBuffer buffer = bufferFactory.allocateBuffer(2);
/*     */           buffer.write((byte)13);
/*     */           buffer.write((byte)10);
/*     */           return buffer;
/*     */         });
/*     */   }
/*     */   
/*     */   protected Mono<DataBuffer> generateLastLine(byte[] boundary, DataBufferFactory bufferFactory) {
/* 136 */     return Mono.fromCallable(() -> {
/*     */           DataBuffer buffer = bufferFactory.allocateBuffer(boundary.length + 6);
/*     */           buffer.write((byte)45);
/*     */           buffer.write((byte)45);
/*     */           buffer.write(boundary);
/*     */           buffer.write((byte)45);
/*     */           buffer.write((byte)45);
/*     */           buffer.write((byte)13);
/*     */           buffer.write((byte)10);
/*     */           return buffer;
/*     */         });
/*     */   }
/*     */   
/*     */   protected Mono<DataBuffer> generatePartHeaders(HttpHeaders headers, DataBufferFactory bufferFactory) {
/* 150 */     return Mono.fromCallable(() -> {
/*     */           FastByteArrayOutputStream bos = new FastByteArrayOutputStream();
/*     */           for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)headers.entrySet()) {
/*     */             byte[] headerName = ((String)entry.getKey()).getBytes(getCharset());
/*     */             for (String headerValueString : entry.getValue()) {
/*     */               byte[] headerValue = headerValueString.getBytes(getCharset());
/*     */               bos.write(headerName);
/*     */               bos.write(58);
/*     */               bos.write(32);
/*     */               bos.write(headerValue);
/*     */               bos.write(13);
/*     */               bos.write(10);
/*     */             } 
/*     */           } 
/*     */           bos.write(13);
/*     */           bos.write(10);
/*     */           byte[] bytes = bos.toByteArrayUnsafe();
/*     */           return bufferFactory.wrap(bytes);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartWriterSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */