package org.springframework.http.codec.multipart;

import java.nio.file.Path;
import org.springframework.core.io.buffer.DataBuffer;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

interface Content {
  Flux<DataBuffer> content();
  
  Mono<Void> transferTo(Path paramPath);
  
  Mono<Void> delete();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultParts$Content.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */