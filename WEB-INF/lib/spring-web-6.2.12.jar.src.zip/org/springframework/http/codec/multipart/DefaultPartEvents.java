/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DefaultPartEvents
/*     */ {
/*     */   public static FormPartEvent form(HttpHeaders headers) {
/*  33 */     Assert.notNull(headers, "Headers must not be null");
/*  34 */     return new DefaultFormFieldPartEvent(headers);
/*     */   }
/*     */   
/*     */   public static FormPartEvent form(HttpHeaders headers, String value) {
/*  38 */     Assert.notNull(headers, "Headers must not be null");
/*  39 */     Assert.notNull(value, "Value must not be null");
/*  40 */     return new DefaultFormFieldPartEvent(headers, value);
/*     */   }
/*     */   
/*     */   public static FilePartEvent file(HttpHeaders headers, DataBuffer dataBuffer, boolean isLast) {
/*  44 */     Assert.notNull(headers, "Headers must not be null");
/*  45 */     Assert.notNull(dataBuffer, "DataBuffer must not be null");
/*  46 */     return new DefaultFilePartEvent(headers, dataBuffer, isLast);
/*     */   }
/*     */   
/*     */   public static FilePartEvent file(HttpHeaders headers) {
/*  50 */     Assert.notNull(headers, "Headers must not be null");
/*  51 */     return new DefaultFilePartEvent(headers);
/*     */   }
/*     */   
/*     */   public static PartEvent create(HttpHeaders headers, DataBuffer dataBuffer, boolean isLast) {
/*  55 */     Assert.notNull(headers, "Headers must not be null");
/*  56 */     Assert.notNull(dataBuffer, "DataBuffer must not be null");
/*  57 */     if (headers.getContentDisposition().getFilename() != null) {
/*  58 */       return file(headers, dataBuffer, isLast);
/*     */     }
/*     */     
/*  61 */     return new DefaultPartEvent(headers, dataBuffer, isLast);
/*     */   }
/*     */ 
/*     */   
/*     */   public static PartEvent create(HttpHeaders headers) {
/*  66 */     Assert.notNull(headers, "Headers must not be null");
/*  67 */     if (headers.getContentDisposition().getFilename() != null) {
/*  68 */       return file(headers);
/*     */     }
/*     */     
/*  71 */     return new DefaultPartEvent(headers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class AbstractPartEvent
/*     */     implements PartEvent
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */ 
/*     */     
/*     */     protected AbstractPartEvent(HttpHeaders headers) {
/*  83 */       this.headers = HttpHeaders.readOnlyHttpHeaders(headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders headers() {
/*  88 */       return this.headers;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultPartEvent
/*     */     extends AbstractPartEvent
/*     */   {
/*  98 */     private static final DataBuffer EMPTY = (DataBuffer)DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
/*     */     
/*     */     private final DataBuffer content;
/*     */     
/*     */     private final boolean last;
/*     */ 
/*     */     
/*     */     public DefaultPartEvent(HttpHeaders headers) {
/* 106 */       this(headers, EMPTY, true);
/*     */     }
/*     */     
/*     */     public DefaultPartEvent(HttpHeaders headers, DataBuffer content, boolean last) {
/* 110 */       super(headers);
/* 111 */       this.content = content;
/* 112 */       this.last = last;
/*     */     }
/*     */ 
/*     */     
/*     */     public DataBuffer content() {
/* 117 */       return this.content;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLast() {
/* 122 */       return this.last;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultFormFieldPartEvent
/*     */     extends AbstractPartEvent
/*     */     implements FormPartEvent
/*     */   {
/*     */     private static final String EMPTY = "";
/*     */     
/*     */     private final String value;
/*     */ 
/*     */     
/*     */     public DefaultFormFieldPartEvent(HttpHeaders headers) {
/* 138 */       this(headers, "");
/*     */     }
/*     */     
/*     */     public DefaultFormFieldPartEvent(HttpHeaders headers, String value) {
/* 142 */       super(headers);
/* 143 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String value() {
/* 148 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public DataBuffer content() {
/* 153 */       byte[] bytes = this.value.getBytes(MultipartUtils.charset(headers()));
/* 154 */       return (DataBuffer)DefaultDataBufferFactory.sharedInstance.wrap(bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLast() {
/* 159 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultFilePartEvent
/*     */     extends DefaultPartEvent
/*     */     implements FilePartEvent
/*     */   {
/*     */     public DefaultFilePartEvent(HttpHeaders headers) {
/* 169 */       super(headers);
/*     */     }
/*     */     
/*     */     public DefaultFilePartEvent(HttpHeaders headers, DataBuffer content, boolean last) {
/* 173 */       super(headers, content, last);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultPartEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */