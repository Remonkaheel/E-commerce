/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BodyState
/*     */   implements MultipartParser.State
/*     */ {
/*     */   private final DataBufferUtils.Matcher boundary;
/*     */   private final int boundaryLength;
/* 504 */   private final Deque<DataBuffer> queue = new ConcurrentLinkedDeque<>();
/*     */   
/*     */   public BodyState() {
/* 507 */     byte[] delimiter = MultipartUtils.concat(new byte[][] { MultipartParser.CR_LF, MultipartParser.TWO_HYPHENS, paramMultipartParser.boundary });
/* 508 */     this.boundary = DataBufferUtils.matcher(delimiter);
/* 509 */     this.boundaryLength = delimiter.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNext(DataBuffer buffer) {
/* 522 */     int endIdx = this.boundary.match(buffer);
/* 523 */     if (endIdx != -1) {
/* 524 */       DataBuffer boundaryBuffer = buffer.split(endIdx + 1);
/* 525 */       if (MultipartParser.logger.isTraceEnabled()) {
/* 526 */         MultipartParser.logger.trace("Boundary found @" + endIdx + " in " + String.valueOf(buffer));
/*     */       }
/* 528 */       int len = endIdx - this.boundaryLength + 1 - boundaryBuffer.readPosition();
/* 529 */       if (len > 0) {
/*     */ 
/*     */         
/* 532 */         DataBuffer body = boundaryBuffer.split(len);
/* 533 */         DataBufferUtils.release(boundaryBuffer);
/* 534 */         enqueue(body);
/* 535 */         flush();
/*     */       }
/* 537 */       else if (len < 0) {
/*     */ 
/*     */         
/* 540 */         DataBufferUtils.release(boundaryBuffer);
/*     */         DataBuffer prev;
/* 542 */         while ((prev = this.queue.pollLast()) != null) {
/* 543 */           int prevByteCount = prev.readableByteCount();
/* 544 */           int prevLen = prevByteCount + len;
/* 545 */           if (prevLen >= 0) {
/*     */             
/* 547 */             DataBuffer body = prev.split(prevLen + prev.readPosition());
/* 548 */             DataBufferUtils.release(prev);
/* 549 */             enqueue(body);
/* 550 */             flush();
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 555 */           DataBufferUtils.release(prev);
/* 556 */           len += prevByteCount;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 562 */         DataBufferUtils.release(boundaryBuffer);
/* 563 */         flush();
/*     */       } 
/*     */       
/* 566 */       MultipartParser.this.changeState(this, new MultipartParser.HeadersState(MultipartParser.this), buffer);
/*     */     } else {
/*     */       
/* 569 */       enqueue(buffer);
/* 570 */       MultipartParser.this.requestBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enqueue(DataBuffer buf) {
/* 581 */     this.queue.add(buf);
/*     */     
/* 583 */     int len = 0;
/* 584 */     Deque<DataBuffer> emit = new ArrayDeque<>();
/* 585 */     for (Iterator<DataBuffer> iterator = this.queue.descendingIterator(); iterator.hasNext(); ) {
/* 586 */       DataBuffer previous = iterator.next();
/* 587 */       if (len > this.boundaryLength) {
/*     */         
/* 589 */         emit.addFirst(previous);
/* 590 */         iterator.remove();
/*     */       } 
/* 592 */       len += previous.readableByteCount();
/*     */     } 
/*     */     
/* 595 */     emit.forEach(buffer -> MultipartParser.this.emitBody(buffer, false));
/*     */   }
/*     */   
/*     */   private void flush() {
/* 599 */     for (Iterator<DataBuffer> iterator = this.queue.iterator(); iterator.hasNext(); ) {
/* 600 */       DataBuffer buffer = iterator.next();
/* 601 */       boolean last = !iterator.hasNext();
/* 602 */       MultipartParser.this.emitBody(buffer, last);
/*     */     } 
/* 604 */     this.queue.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 609 */     if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, null)) {
/* 610 */       String msg = "Could not find end of body (␍␊--" + new String(MultipartParser.this.boundary, StandardCharsets.UTF_8) + ")";
/*     */ 
/*     */       
/* 613 */       MultipartParser.this.emitError((Throwable)new DecodingException(msg));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 619 */     this.queue.forEach(DataBufferUtils::release);
/* 620 */     this.queue.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 625 */     return "BODY";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartParser$BodyState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */