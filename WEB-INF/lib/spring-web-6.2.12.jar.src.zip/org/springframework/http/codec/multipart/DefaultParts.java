/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.ContentDisposition;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DefaultParts
/*     */ {
/*     */   public static FormFieldPart formFieldPart(HttpHeaders headers, String value) {
/*  51 */     Assert.notNull(headers, "Headers must not be null");
/*  52 */     Assert.notNull(value, "Value must not be null");
/*     */     
/*  54 */     return new DefaultFormFieldPart(headers, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Part part(HttpHeaders headers, Flux<DataBuffer> dataBuffers) {
/*  67 */     Assert.notNull(headers, "Headers must not be null");
/*  68 */     Assert.notNull(dataBuffers, "DataBuffers must not be null");
/*     */     
/*  70 */     return partInternal(headers, new FluxContent(dataBuffers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Part part(HttpHeaders headers, Path file, Scheduler scheduler) {
/*  83 */     Assert.notNull(headers, "Headers must not be null");
/*  84 */     Assert.notNull(file, "File must not be null");
/*  85 */     Assert.notNull(scheduler, "Scheduler must not be null");
/*     */     
/*  87 */     return partInternal(headers, new FileContent(file, scheduler));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Part partInternal(HttpHeaders headers, Content content) {
/*  92 */     String filename = headers.getContentDisposition().getFilename();
/*  93 */     if (filename != null) {
/*  94 */       return new DefaultFilePart(headers, content);
/*     */     }
/*     */     
/*  97 */     return new DefaultPart(headers, content);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class AbstractPart
/*     */     implements Part
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */ 
/*     */ 
/*     */     
/*     */     protected AbstractPart(HttpHeaders headers) {
/* 110 */       Assert.notNull(headers, "HttpHeaders is required");
/* 111 */       this.headers = headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public String name() {
/* 116 */       String name = headers().getContentDisposition().getName();
/* 117 */       Assert.state((name != null), "No name available");
/* 118 */       return name;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders headers() {
/* 123 */       return this.headers;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultFormFieldPart
/*     */     extends AbstractPart
/*     */     implements FormFieldPart
/*     */   {
/*     */     private final String value;
/*     */ 
/*     */     
/*     */     public DefaultFormFieldPart(HttpHeaders headers, String value) {
/* 136 */       super(headers);
/* 137 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<DataBuffer> content() {
/* 142 */       return Flux.defer(() -> {
/*     */             byte[] bytes = this.value.getBytes(MultipartUtils.charset(headers()));
/*     */             return (Publisher)Flux.just(DefaultDataBufferFactory.sharedInstance.wrap(bytes));
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public String value() {
/* 150 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 155 */       String name = headers().getContentDisposition().getName();
/* 156 */       if (name != null) {
/* 157 */         return "DefaultFormFieldPart{" + name() + "}";
/*     */       }
/*     */       
/* 160 */       return "DefaultFormFieldPart";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultPart
/*     */     extends AbstractPart
/*     */   {
/*     */     protected final DefaultParts.Content content;
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultPart(HttpHeaders headers, DefaultParts.Content content) {
/* 174 */       super(headers);
/* 175 */       this.content = content;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<DataBuffer> content() {
/* 180 */       return this.content.content();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> delete() {
/* 185 */       return this.content.delete();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 190 */       String name = headers().getContentDisposition().getName();
/* 191 */       if (name != null) {
/* 192 */         return "DefaultPart{" + name + "}";
/*     */       }
/*     */       
/* 195 */       return "DefaultPart";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultFilePart
/*     */     extends DefaultPart
/*     */     implements FilePart
/*     */   {
/*     */     public DefaultFilePart(HttpHeaders headers, DefaultParts.Content content) {
/* 207 */       super(headers, content);
/*     */     }
/*     */ 
/*     */     
/*     */     public String filename() {
/* 212 */       String filename = headers().getContentDisposition().getFilename();
/* 213 */       Assert.state((filename != null), "No filename found");
/* 214 */       return filename;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> transferTo(Path dest) {
/* 219 */       return this.content.transferTo(dest);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 224 */       ContentDisposition contentDisposition = headers().getContentDisposition();
/* 225 */       String name = contentDisposition.getName();
/* 226 */       String filename = contentDisposition.getFilename();
/* 227 */       return (name != null) ? ("DefaultFilePart{" + 
/* 228 */         name + " (" + filename + ")}") : ("DefaultFilePart{(" + 
/*     */ 
/*     */         
/* 231 */         filename + ")}");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FluxContent
/*     */     implements Content
/*     */   {
/*     */     private final Flux<DataBuffer> content;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FluxContent(Flux<DataBuffer> content) {
/* 258 */       this.content = content;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<DataBuffer> content() {
/* 263 */       return this.content;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> transferTo(Path dest) {
/* 268 */       return DataBufferUtils.write((Publisher)this.content, dest, new OpenOption[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> delete() {
/* 273 */       return Mono.empty();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FileContent
/*     */     implements Content
/*     */   {
/*     */     private final Path file;
/*     */     
/*     */     private final Scheduler scheduler;
/*     */ 
/*     */     
/*     */     public FileContent(Path file, Scheduler scheduler) {
/* 288 */       this.file = file;
/* 289 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<DataBuffer> content() {
/* 294 */       return DataBufferUtils.readByteChannel(() -> Files.newByteChannel(this.file, new OpenOption[] { StandardOpenOption.READ }), (DataBufferFactory)DefaultDataBufferFactory.sharedInstance, 1024)
/*     */ 
/*     */         
/* 297 */         .subscribeOn(this.scheduler);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> transferTo(Path dest) {
/* 302 */       return blockingOperation(() -> Files.copy(this.file, dest, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING }));
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> delete() {
/* 307 */       return blockingOperation(() -> {
/*     */             Files.delete(this.file);
/*     */             return null;
/*     */           });
/*     */     }
/*     */     
/*     */     private Mono<Void> blockingOperation(Callable<?> callable) {
/* 314 */       return Mono.create(sink -> {
/*     */             try {
/*     */               callable.call();
/*     */               
/*     */               sink.success();
/* 319 */             } catch (Exception ex) {
/*     */               
/*     */               sink.error(ex);
/*     */             } 
/* 323 */           }).subscribeOn(this.scheduler);
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface Content {
/*     */     Flux<DataBuffer> content();
/*     */     
/*     */     Mono<Void> transferTo(Path param1Path);
/*     */     
/*     */     Mono<Void> delete();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultParts.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */