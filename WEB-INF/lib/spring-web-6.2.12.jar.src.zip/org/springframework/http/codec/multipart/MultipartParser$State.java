package org.springframework.http.codec.multipart;

import org.springframework.core.io.buffer.DataBuffer;

interface State {
  void onNext(DataBuffer paramDataBuffer);
  
  void onComplete();
  
  default void dispose() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartParser$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */