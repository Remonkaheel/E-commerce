/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.http.HttpMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.http.codec.HttpMessageReader;
/*     */ import org.springframework.http.codec.LoggingCodecSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPartHttpMessageReader
/*     */   extends LoggingCodecSupport
/*     */   implements HttpMessageReader<Part>
/*     */ {
/*  61 */   private int maxInMemorySize = 262144;
/*     */   
/*  63 */   private int maxHeadersSize = 10240;
/*     */   
/*  65 */   private long maxDiskUsagePerPart = -1L;
/*     */   
/*  67 */   private int maxParts = -1;
/*     */   
/*     */   @Nullable
/*     */   private Scheduler blockingOperationScheduler;
/*     */   
/*  72 */   private FileStorage fileStorage = FileStorage.tempDirectory(this::getBlockingOperationScheduler);
/*     */   
/*  74 */   private Charset headersCharset = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxHeadersSize(int byteCount) {
/*  83 */     this.maxHeadersSize = byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/*  90 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int maxInMemorySize) {
/* 105 */     this.maxInMemorySize = maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxDiskUsagePerPart(long maxDiskUsagePerPart) {
/* 115 */     this.maxDiskUsagePerPart = maxDiskUsagePerPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxParts(int maxParts) {
/* 123 */     this.maxParts = maxParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileStorageDirectory(Path fileStorageDirectory) throws IOException {
/* 137 */     Assert.notNull(fileStorageDirectory, "FileStorageDirectory must not be null");
/* 138 */     this.fileStorage = FileStorage.fromPath(fileStorageDirectory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockingOperationScheduler(Scheduler blockingOperationScheduler) {
/* 151 */     Assert.notNull(blockingOperationScheduler, "'blockingOperationScheduler' must not be null");
/* 152 */     this.blockingOperationScheduler = blockingOperationScheduler;
/*     */   }
/*     */   
/*     */   private Scheduler getBlockingOperationScheduler() {
/* 156 */     return (this.blockingOperationScheduler != null) ? 
/* 157 */       this.blockingOperationScheduler : Schedulers.boundedElastic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeadersCharset(Charset headersCharset) {
/* 168 */     Assert.notNull(headersCharset, "HeadersCharset must not be null");
/* 169 */     this.headersCharset = headersCharset;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getReadableMediaTypes() {
/* 174 */     return Collections.singletonList(MediaType.MULTIPART_FORM_DATA);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 179 */     return (Part.class.equals(elementType.toClass()) && (mediaType == null || MediaType.MULTIPART_FORM_DATA
/* 180 */       .isCompatibleWith(mediaType)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Part> readMono(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 186 */     return Mono.error(new UnsupportedOperationException("Cannot read multipart request body into single Part"));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Part> read(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 191 */     return Flux.defer(() -> {
/*     */           byte[] boundary = MultipartUtils.boundary((HttpMessage)message, this.headersCharset);
/*     */           if (boundary == null) {
/*     */             return (Publisher)Flux.error((Throwable)new DecodingException("No multipart boundary found in Content-Type: \"" + String.valueOf(message.getHeaders().getContentType()) + "\""));
/*     */           }
/*     */           Flux<MultipartParser.Token> allPartsTokens = MultipartParser.parse(message.getBody(), boundary, this.maxHeadersSize, this.headersCharset);
/*     */           AtomicInteger partCount = new AtomicInteger();
/*     */           return (Publisher)allPartsTokens.windowUntil(MultipartParser.Token::isLast).concatMap(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tooManyParts(AtomicInteger partCount) {
/* 218 */     int count = partCount.incrementAndGet();
/* 219 */     return (this.maxParts > 0 && count > this.maxParts);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\DefaultPartHttpMessageReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */