package org.springframework.http.codec.multipart;

public interface FormFieldPart extends Part {
  String value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\FormFieldPart.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */