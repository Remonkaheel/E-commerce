/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.FastByteArrayOutputStream;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.BaseSubscriber;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PartGenerator
/*     */   extends BaseSubscriber<MultipartParser.Token>
/*     */ {
/*  63 */   private static final Log logger = LogFactory.getLog(PartGenerator.class);
/*     */   
/*  65 */   private final AtomicReference<State> state = new AtomicReference<>(new InitialState());
/*     */   
/*  67 */   private final AtomicBoolean requestOutstanding = new AtomicBoolean();
/*     */ 
/*     */   
/*     */   private final MonoSink<Part> sink;
/*     */ 
/*     */   
/*     */   private final int maxInMemorySize;
/*     */   
/*     */   private final long maxDiskUsagePerPart;
/*     */   
/*     */   private final Mono<Path> fileStorageDirectory;
/*     */   
/*     */   private final Scheduler blockingOperationScheduler;
/*     */ 
/*     */   
/*     */   private PartGenerator(MonoSink<Part> sink, int maxInMemorySize, long maxDiskUsagePerPart, Mono<Path> fileStorageDirectory, Scheduler blockingOperationScheduler) {
/*  83 */     this.sink = sink;
/*  84 */     this.maxInMemorySize = maxInMemorySize;
/*  85 */     this.maxDiskUsagePerPart = maxDiskUsagePerPart;
/*  86 */     this.fileStorageDirectory = fileStorageDirectory;
/*  87 */     this.blockingOperationScheduler = blockingOperationScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Part> createPart(Flux<MultipartParser.Token> tokens, int maxInMemorySize, long maxDiskUsagePerPart, Mono<Path> fileStorageDirectory, Scheduler blockingOperationScheduler) {
/*  96 */     return Mono.create(sink -> {
/*     */           PartGenerator generator = new PartGenerator(sink, maxInMemorySize, maxDiskUsagePerPart, fileStorageDirectory, blockingOperationScheduler);
/*     */           sink.onCancel((Disposable)generator);
/*     */           sink.onRequest(());
/*     */           tokens.subscribe((CoreSubscriber)generator);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 108 */     return Context.of(this.sink.contextView());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnSubscribe(Subscription subscription) {
/* 113 */     requestToken();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnNext(MultipartParser.Token token) {
/* 118 */     this.requestOutstanding.set(false);
/* 119 */     State state = this.state.get();
/* 120 */     if (token instanceof MultipartParser.HeadersToken) {
/* 121 */       newPart(state, token.headers());
/*     */     } else {
/*     */       
/* 124 */       state.body(token.buffer());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void newPart(State currentState, HttpHeaders headers) {
/* 129 */     if (MultipartUtils.isFormField(headers)) {
/* 130 */       changeState(currentState, new FormFieldState(headers));
/* 131 */       requestToken();
/*     */     } else {
/*     */       
/* 134 */       changeState(currentState, new InMemoryState(headers));
/* 135 */       requestToken();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnComplete() {
/* 141 */     ((State)this.state.get()).onComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void hookOnError(Throwable throwable) {
/* 146 */     ((State)this.state.get()).error(throwable);
/* 147 */     changeStateInternal(DisposedState.INSTANCE);
/* 148 */     this.sink.error(throwable);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 153 */     changeStateInternal(DisposedState.INSTANCE);
/* 154 */     cancel();
/*     */   }
/*     */   
/*     */   boolean changeState(State oldState, State newState) {
/* 158 */     if (this.state.compareAndSet(oldState, newState)) {
/* 159 */       if (logger.isTraceEnabled()) {
/* 160 */         logger.trace("Changed state: " + String.valueOf(oldState) + " -> " + String.valueOf(newState));
/*     */       }
/* 162 */       oldState.dispose();
/* 163 */       return true;
/*     */     } 
/*     */     
/* 166 */     logger.warn("Could not switch from " + String.valueOf(oldState) + " to " + String.valueOf(newState) + "; current state:" + 
/* 167 */         String.valueOf(this.state.get()));
/* 168 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void changeStateInternal(State newState) {
/* 173 */     if (this.state.get() == DisposedState.INSTANCE) {
/*     */       return;
/*     */     }
/* 176 */     State oldState = this.state.getAndSet(newState);
/* 177 */     if (logger.isTraceEnabled()) {
/* 178 */       logger.trace("Changed state: " + String.valueOf(oldState) + " -> " + String.valueOf(newState));
/*     */     }
/* 180 */     oldState.dispose();
/*     */   }
/*     */   
/*     */   void emitPart(Part part) {
/* 184 */     if (logger.isTraceEnabled()) {
/* 185 */       logger.trace("Emitting: " + String.valueOf(part));
/*     */     }
/* 187 */     this.sink.success(part);
/*     */   }
/*     */   
/*     */   void emitError(Throwable t) {
/* 191 */     cancel();
/* 192 */     this.sink.error(t);
/*     */   }
/*     */   
/*     */   void requestToken() {
/* 196 */     if (upstream() != null && ((State)this.state
/* 197 */       .get()).canRequest() && this.requestOutstanding
/* 198 */       .compareAndSet(false, true)) {
/* 199 */       request(1L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface State
/*     */   {
/*     */     void body(DataBuffer param1DataBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void onComplete();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default void error(Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default boolean canRequest() {
/* 243 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default void dispose() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class InitialState
/*     */     implements State
/*     */   {
/*     */     public void body(DataBuffer dataBuffer) {
/* 264 */       DataBufferUtils.release(dataBuffer);
/* 265 */       PartGenerator.this.emitError(new IllegalStateException("Body token not expected"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     public String toString() {
/* 274 */       return "INITIAL";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class FormFieldState
/*     */     implements State
/*     */   {
/* 285 */     private final FastByteArrayOutputStream value = new FastByteArrayOutputStream();
/*     */     
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     public FormFieldState(HttpHeaders headers) {
/* 290 */       this.headers = headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 295 */       int size = this.value.size() + dataBuffer.readableByteCount();
/* 296 */       if (PartGenerator.this.maxInMemorySize == -1 || size < PartGenerator.this.maxInMemorySize) {
/*     */         
/* 298 */         store(dataBuffer);
/* 299 */         PartGenerator.this.requestToken();
/*     */       } else {
/*     */         
/* 302 */         DataBufferUtils.release(dataBuffer);
/* 303 */         PartGenerator.this.emitError((Throwable)new DataBufferLimitException("Form field value exceeded the memory usage limit of " + PartGenerator.this.maxInMemorySize + " bytes"));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void store(DataBuffer dataBuffer) {
/*     */       try {
/* 310 */         byte[] bytes = new byte[dataBuffer.readableByteCount()];
/* 311 */         dataBuffer.read(bytes);
/* 312 */         this.value.write(bytes);
/*     */       }
/* 314 */       catch (IOException ex) {
/* 315 */         PartGenerator.this.emitError(ex);
/*     */       } finally {
/*     */         
/* 318 */         DataBufferUtils.release(dataBuffer);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 324 */       byte[] bytes = this.value.toByteArrayUnsafe();
/* 325 */       String value = new String(bytes, MultipartUtils.charset(this.headers));
/* 326 */       PartGenerator.this.emitPart(DefaultParts.formFieldPart(this.headers, value));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 331 */       return "FORM-FIELD";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class InMemoryState
/*     */     implements State
/*     */   {
/* 346 */     private final AtomicLong byteCount = new AtomicLong();
/*     */     
/* 348 */     private final Queue<DataBuffer> content = new ConcurrentLinkedQueue<>();
/*     */     
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private volatile boolean releaseOnDispose = true;
/*     */ 
/*     */     
/*     */     public InMemoryState(HttpHeaders headers) {
/* 356 */       this.headers = headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 361 */       long prevCount = this.byteCount.get();
/* 362 */       long count = this.byteCount.addAndGet(dataBuffer.readableByteCount());
/* 363 */       if (PartGenerator.this.maxInMemorySize == -1 || count <= PartGenerator.this.maxInMemorySize) {
/*     */         
/* 365 */         storeBuffer(dataBuffer);
/*     */       }
/* 367 */       else if (prevCount <= PartGenerator.this.maxInMemorySize) {
/* 368 */         switchToFile(dataBuffer, count);
/*     */       } else {
/*     */         
/* 371 */         DataBufferUtils.release(dataBuffer);
/* 372 */         PartGenerator.this.emitError(new IllegalStateException("Body token not expected"));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void storeBuffer(DataBuffer dataBuffer) {
/* 377 */       this.content.add(dataBuffer);
/* 378 */       PartGenerator.this.requestToken();
/*     */     }
/*     */     
/*     */     private void switchToFile(DataBuffer current, long byteCount) {
/* 382 */       List<DataBuffer> content = new ArrayList<>(this.content);
/* 383 */       content.add(current);
/* 384 */       this.releaseOnDispose = false;
/*     */       
/* 386 */       PartGenerator.CreateFileState newState = new PartGenerator.CreateFileState(this.headers, content, byteCount);
/* 387 */       if (PartGenerator.this.changeState(this, newState)) {
/* 388 */         newState.createFile();
/*     */       } else {
/*     */         
/* 391 */         content.forEach(DataBufferUtils::release);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 397 */       emitMemoryPart();
/*     */     }
/*     */     
/*     */     private void emitMemoryPart() {
/* 401 */       byte[] bytes = new byte[(int)this.byteCount.get()];
/* 402 */       int idx = 0;
/* 403 */       for (DataBuffer buffer : this.content) {
/* 404 */         int len = buffer.readableByteCount();
/* 405 */         buffer.read(bytes, idx, len);
/* 406 */         idx += len;
/* 407 */         DataBufferUtils.release(buffer);
/*     */       } 
/* 409 */       this.content.clear();
/* 410 */       Flux<DataBuffer> content = Flux.just(DefaultDataBufferFactory.sharedInstance.wrap(bytes));
/* 411 */       PartGenerator.this.emitPart(DefaultParts.part(this.headers, content));
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 416 */       if (this.releaseOnDispose) {
/* 417 */         this.content.forEach(DataBufferUtils::release);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 423 */       return "IN-MEMORY";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class CreateFileState
/*     */     implements State
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */ 
/*     */     
/*     */     private final Collection<DataBuffer> content;
/*     */ 
/*     */     
/*     */     private final long byteCount;
/*     */ 
/*     */     
/*     */     private volatile boolean completed;
/*     */ 
/*     */     
/*     */     private volatile boolean releaseOnDispose = true;
/*     */ 
/*     */ 
/*     */     
/*     */     public CreateFileState(HttpHeaders headers, Collection<DataBuffer> content, long byteCount) {
/* 449 */       this.headers = headers;
/* 450 */       this.content = content;
/* 451 */       this.byteCount = byteCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 456 */       DataBufferUtils.release(dataBuffer);
/* 457 */       PartGenerator.this.emitError(new IllegalStateException("Body token not expected"));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 462 */       this.completed = true;
/*     */     }
/*     */     
/*     */     public void createFile() {
/* 466 */       PartGenerator.this.fileStorageDirectory
/* 467 */         .map(this::createFileState)
/* 468 */         .subscribeOn(PartGenerator.this.blockingOperationScheduler)
/* 469 */         .subscribe(this::fileCreated, PartGenerator.this::emitError);
/*     */     }
/*     */     
/*     */     private PartGenerator.WritingFileState createFileState(Path directory) {
/*     */       try {
/* 474 */         Path tempFile = Files.createTempFile(directory, null, ".multipart", (FileAttribute<?>[])new FileAttribute[0]);
/* 475 */         if (PartGenerator.logger.isTraceEnabled()) {
/* 476 */           PartGenerator.logger.trace("Storing multipart data in file " + String.valueOf(tempFile));
/*     */         }
/* 478 */         WritableByteChannel channel = Files.newByteChannel(tempFile, new OpenOption[] { StandardOpenOption.WRITE });
/* 479 */         return new PartGenerator.WritingFileState(this, tempFile, channel);
/*     */       }
/* 481 */       catch (IOException ex) {
/* 482 */         throw new UncheckedIOException("Could not create temp file in " + String.valueOf(directory), ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void fileCreated(PartGenerator.WritingFileState newState) {
/* 487 */       this.releaseOnDispose = false;
/*     */       
/* 489 */       if (PartGenerator.this.changeState(this, newState)) {
/*     */         
/* 491 */         newState.writeBuffers(this.content);
/*     */         
/* 493 */         if (this.completed) {
/* 494 */           newState.onComplete();
/*     */         }
/*     */       } else {
/*     */         
/* 498 */         MultipartUtils.closeChannel(newState.channel);
/* 499 */         MultipartUtils.deleteFile(newState.file);
/* 500 */         this.content.forEach(DataBufferUtils::release);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 506 */       if (this.releaseOnDispose) {
/* 507 */         this.content.forEach(DataBufferUtils::release);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 513 */       return "CREATE-FILE";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class IdleFileState
/*     */     implements State
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private final Path file;
/*     */     
/*     */     private final WritableByteChannel channel;
/*     */     
/*     */     private final AtomicLong byteCount;
/*     */     
/*     */     private volatile boolean closeOnDispose = true;
/*     */     
/*     */     private volatile boolean deleteOnDispose = true;
/*     */ 
/*     */     
/*     */     public IdleFileState(PartGenerator.WritingFileState state) {
/* 535 */       this.headers = state.headers;
/* 536 */       this.file = state.file;
/* 537 */       this.channel = state.channel;
/* 538 */       this.byteCount = state.byteCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 543 */       long count = this.byteCount.addAndGet(dataBuffer.readableByteCount());
/* 544 */       if (PartGenerator.this.maxDiskUsagePerPart == -1L || count <= PartGenerator.this.maxDiskUsagePerPart) {
/*     */         
/* 546 */         this.closeOnDispose = false;
/* 547 */         this.deleteOnDispose = false;
/* 548 */         PartGenerator.WritingFileState newState = new PartGenerator.WritingFileState(this);
/* 549 */         if (PartGenerator.this.changeState(this, newState)) {
/* 550 */           newState.writeBuffer(dataBuffer);
/*     */         } else {
/*     */           
/* 553 */           MultipartUtils.closeChannel(this.channel);
/* 554 */           MultipartUtils.deleteFile(this.file);
/* 555 */           DataBufferUtils.release(dataBuffer);
/*     */         } 
/*     */       } else {
/*     */         
/* 559 */         MultipartUtils.closeChannel(this.channel);
/* 560 */         MultipartUtils.deleteFile(this.file);
/* 561 */         DataBufferUtils.release(dataBuffer);
/* 562 */         PartGenerator.this.emitError((Throwable)new DataBufferLimitException("Part exceeded the disk usage limit of " + PartGenerator.this.maxDiskUsagePerPart + " bytes"));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 570 */       MultipartUtils.closeChannel(this.channel);
/* 571 */       this.deleteOnDispose = false;
/* 572 */       PartGenerator.this.emitPart(DefaultParts.part(this.headers, this.file, PartGenerator.this.blockingOperationScheduler));
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 577 */       if (this.closeOnDispose) {
/* 578 */         MultipartUtils.closeChannel(this.channel);
/*     */       }
/* 580 */       if (this.deleteOnDispose) {
/* 581 */         MultipartUtils.deleteFile(this.file);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 588 */       return "IDLE-FILE";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class WritingFileState
/*     */     implements State
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private final Path file;
/*     */     
/*     */     private final WritableByteChannel channel;
/*     */     
/*     */     private final AtomicLong byteCount;
/*     */     
/*     */     private volatile boolean completed;
/*     */     
/*     */     private volatile boolean disposed;
/*     */ 
/*     */     
/*     */     public WritingFileState(PartGenerator.CreateFileState state, Path file, WritableByteChannel channel) {
/* 610 */       this.headers = state.headers;
/* 611 */       this.file = file;
/* 612 */       this.channel = channel;
/* 613 */       this.byteCount = new AtomicLong(state.byteCount);
/*     */     }
/*     */     
/*     */     public WritingFileState(PartGenerator.IdleFileState state) {
/* 617 */       this.headers = state.headers;
/* 618 */       this.file = state.file;
/* 619 */       this.channel = state.channel;
/* 620 */       this.byteCount = state.byteCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 625 */       DataBufferUtils.release(dataBuffer);
/* 626 */       PartGenerator.this.emitError(new IllegalStateException("Body token not expected"));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 631 */       this.completed = true;
/* 632 */       PartGenerator.State state = PartGenerator.this.state.get();
/*     */       
/* 634 */       if (state != this) {
/* 635 */         state.onComplete();
/*     */       } else {
/*     */         
/* 638 */         this.completed = true;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void writeBuffer(DataBuffer dataBuffer) {
/* 643 */       Mono.just(dataBuffer)
/* 644 */         .flatMap(this::writeInternal)
/* 645 */         .subscribeOn(PartGenerator.this.blockingOperationScheduler)
/* 646 */         .subscribe(null, PartGenerator.this::emitError, this::writeComplete);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeBuffers(Iterable<DataBuffer> dataBuffers) {
/* 652 */       Flux.fromIterable(dataBuffers)
/* 653 */         .concatMap(this::writeInternal)
/* 654 */         .then()
/* 655 */         .subscribeOn(PartGenerator.this.blockingOperationScheduler)
/* 656 */         .subscribe(null, PartGenerator.this::emitError, this::writeComplete);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void writeComplete() {
/* 662 */       PartGenerator.IdleFileState newState = new PartGenerator.IdleFileState(this);
/* 663 */       if (this.disposed) {
/* 664 */         newState.dispose();
/*     */       }
/* 666 */       else if (PartGenerator.this.changeState(this, newState)) {
/* 667 */         if (this.completed) {
/* 668 */           newState.onComplete();
/*     */         } else {
/*     */           
/* 671 */           PartGenerator.this.requestToken();
/*     */         } 
/*     */       } else {
/*     */         
/* 675 */         MultipartUtils.closeChannel(this.channel);
/* 676 */         MultipartUtils.deleteFile(this.file);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Mono<Void> writeInternal(DataBuffer dataBuffer) {
/*     */       try {
/* 683 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 684 */         try { while (iterator.hasNext()) {
/* 685 */             ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 686 */             while (byteBuffer.hasRemaining()) {
/* 687 */               this.channel.write(byteBuffer);
/*     */             }
/*     */           } 
/* 690 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 691 */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return Mono.empty();
/*     */       }
/* 693 */       catch (IOException ex) {
/* 694 */         MultipartUtils.closeChannel(this.channel);
/* 695 */         MultipartUtils.deleteFile(this.file);
/* 696 */         return Mono.error(ex);
/*     */       } finally {
/*     */         
/* 699 */         DataBufferUtils.release(dataBuffer);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canRequest() {
/* 705 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 710 */       this.disposed = true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 716 */       return "WRITE-FILE";
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class DisposedState
/*     */     implements State
/*     */   {
/* 723 */     public static final DisposedState INSTANCE = new DisposedState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void body(DataBuffer dataBuffer) {
/* 730 */       DataBufferUtils.release(dataBuffer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     public String toString() {
/* 739 */       return "DISPOSED";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\PartGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */