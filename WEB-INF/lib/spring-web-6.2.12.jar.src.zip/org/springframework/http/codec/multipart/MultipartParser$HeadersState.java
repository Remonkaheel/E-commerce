/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HeadersState
/*     */   implements MultipartParser.State
/*     */ {
/* 361 */   private final DataBufferUtils.Matcher endHeaders = DataBufferUtils.matcher(MultipartUtils.concat(new byte[][] { MultipartParser.CR_LF, MultipartParser.CR_LF }));
/*     */   
/* 363 */   private final AtomicInteger byteCount = new AtomicInteger();
/*     */   
/* 365 */   private final List<DataBuffer> buffers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNext(DataBuffer buf) {
/* 380 */     if (isLastBoundary(buf)) {
/* 381 */       if (MultipartParser.logger.isTraceEnabled()) {
/* 382 */         MultipartParser.logger.trace("Last boundary found in " + String.valueOf(buf));
/*     */       }
/*     */       
/* 385 */       if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, buf)) {
/* 386 */         MultipartParser.this.emitComplete();
/*     */       }
/*     */       return;
/*     */     } 
/* 390 */     int endIdx = this.endHeaders.match(buf);
/* 391 */     if (endIdx != -1) {
/* 392 */       if (MultipartParser.logger.isTraceEnabled()) {
/* 393 */         MultipartParser.logger.trace("End of headers found @" + endIdx + " in " + String.valueOf(buf));
/*     */       }
/* 395 */       long count = this.byteCount.addAndGet(endIdx);
/* 396 */       if (belowMaxHeaderSize(count)) {
/* 397 */         DataBuffer headerBuf = buf.split(endIdx + 1);
/* 398 */         this.buffers.add(headerBuf);
/* 399 */         MultipartParser.this.emitHeaders(parseHeaders());
/*     */         
/* 401 */         MultipartParser.this.changeState(this, new MultipartParser.BodyState(MultipartParser.this), buf);
/*     */       } 
/*     */     } else {
/*     */       
/* 405 */       long count = this.byteCount.addAndGet(buf.readableByteCount());
/* 406 */       if (belowMaxHeaderSize(count)) {
/* 407 */         this.buffers.add(buf);
/* 408 */         MultipartParser.this.requestBuffer();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLastBoundary(DataBuffer buf) {
/* 418 */     return ((this.buffers.isEmpty() && buf
/* 419 */       .readableByteCount() >= 2 && buf
/* 420 */       .getByte(0) == 45 && buf.getByte(1) == 45) || (this.buffers
/* 421 */       .size() == 1 && ((DataBuffer)this.buffers
/* 422 */       .get(0)).readableByteCount() == 1 && ((DataBuffer)this.buffers
/* 423 */       .get(0)).getByte(0) == 45 && buf
/* 424 */       .readableByteCount() >= 1 && buf
/* 425 */       .getByte(0) == 45));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean belowMaxHeaderSize(long count) {
/* 433 */     if (count <= MultipartParser.this.maxHeadersSize) {
/* 434 */       return true;
/*     */     }
/*     */     
/* 437 */     MultipartParser.this.emitError((Throwable)new DataBufferLimitException("Part headers exceeded the memory usage limit of " + MultipartParser.this.maxHeadersSize + " bytes"));
/*     */     
/* 439 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpHeaders parseHeaders() {
/* 449 */     if (this.buffers.isEmpty()) {
/* 450 */       return HttpHeaders.EMPTY;
/*     */     }
/* 452 */     DataBuffer joined = ((DataBuffer)this.buffers.get(0)).factory().join(this.buffers);
/* 453 */     this.buffers.clear();
/* 454 */     String string = joined.toString(MultipartParser.this.headersCharset);
/* 455 */     DataBufferUtils.release(joined);
/* 456 */     String[] lines = string.split("\\r\\n");
/* 457 */     HttpHeaders result = new HttpHeaders();
/* 458 */     for (String line : lines) {
/* 459 */       int idx = line.indexOf(':');
/* 460 */       if (idx != -1) {
/* 461 */         String name = line.substring(0, idx);
/* 462 */         String value = line.substring(idx + 1);
/* 463 */         while (value.startsWith(" ")) {
/* 464 */           value = value.substring(1);
/*     */         }
/* 466 */         result.add(name, value);
/*     */       } 
/*     */     } 
/* 469 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 474 */     if (MultipartParser.this.changeState(this, MultipartParser.DisposedState.INSTANCE, null)) {
/* 475 */       MultipartParser.this.emitError((Throwable)new DecodingException("Could not find end of headers"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 481 */     this.buffers.forEach(DataBufferUtils::release);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 486 */     return "HEADERS";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartParser$HeadersState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */