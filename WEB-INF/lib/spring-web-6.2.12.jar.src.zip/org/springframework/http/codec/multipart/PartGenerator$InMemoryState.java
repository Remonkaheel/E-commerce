/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InMemoryState
/*     */   implements PartGenerator.State
/*     */ {
/* 346 */   private final AtomicLong byteCount = new AtomicLong();
/*     */   
/* 348 */   private final Queue<DataBuffer> content = new ConcurrentLinkedQueue<>();
/*     */   
/*     */   private final HttpHeaders headers;
/*     */   
/*     */   private volatile boolean releaseOnDispose = true;
/*     */ 
/*     */   
/*     */   public InMemoryState(HttpHeaders headers) {
/* 356 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void body(DataBuffer dataBuffer) {
/* 361 */     long prevCount = this.byteCount.get();
/* 362 */     long count = this.byteCount.addAndGet(dataBuffer.readableByteCount());
/* 363 */     if (PartGenerator.this.maxInMemorySize == -1 || count <= PartGenerator.this.maxInMemorySize) {
/*     */       
/* 365 */       storeBuffer(dataBuffer);
/*     */     }
/* 367 */     else if (prevCount <= PartGenerator.this.maxInMemorySize) {
/* 368 */       switchToFile(dataBuffer, count);
/*     */     } else {
/*     */       
/* 371 */       DataBufferUtils.release(dataBuffer);
/* 372 */       PartGenerator.this.emitError(new IllegalStateException("Body token not expected"));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void storeBuffer(DataBuffer dataBuffer) {
/* 377 */     this.content.add(dataBuffer);
/* 378 */     PartGenerator.this.requestToken();
/*     */   }
/*     */   
/*     */   private void switchToFile(DataBuffer current, long byteCount) {
/* 382 */     List<DataBuffer> content = new ArrayList<>(this.content);
/* 383 */     content.add(current);
/* 384 */     this.releaseOnDispose = false;
/*     */     
/* 386 */     PartGenerator.CreateFileState newState = new PartGenerator.CreateFileState(PartGenerator.this, this.headers, content, byteCount);
/* 387 */     if (PartGenerator.this.changeState(this, newState)) {
/* 388 */       newState.createFile();
/*     */     } else {
/*     */       
/* 391 */       content.forEach(DataBufferUtils::release);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 397 */     emitMemoryPart();
/*     */   }
/*     */   
/*     */   private void emitMemoryPart() {
/* 401 */     byte[] bytes = new byte[(int)this.byteCount.get()];
/* 402 */     int idx = 0;
/* 403 */     for (DataBuffer buffer : this.content) {
/* 404 */       int len = buffer.readableByteCount();
/* 405 */       buffer.read(bytes, idx, len);
/* 406 */       idx += len;
/* 407 */       DataBufferUtils.release(buffer);
/*     */     } 
/* 409 */     this.content.clear();
/* 410 */     Flux<DataBuffer> content = Flux.just(DefaultDataBufferFactory.sharedInstance.wrap(bytes));
/* 411 */     PartGenerator.this.emitPart(DefaultParts.part(this.headers, content));
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 416 */     if (this.releaseOnDispose) {
/* 417 */       this.content.forEach(DataBufferUtils::release);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 423 */     return "IN-MEMORY";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\PartGenerator$InMemoryState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */