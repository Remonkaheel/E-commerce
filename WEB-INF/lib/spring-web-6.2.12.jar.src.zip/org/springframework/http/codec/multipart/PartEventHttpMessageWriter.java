/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Signal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartEventHttpMessageWriter
/*     */   extends MultipartWriterSupport
/*     */   implements HttpMessageWriter<PartEvent>
/*     */ {
/*     */   public PartEventHttpMessageWriter() {
/*  49 */     super(Collections.singletonList(MediaType.MULTIPART_FORM_DATA));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/*  54 */     if (PartEvent.class.isAssignableFrom(elementType.toClass())) {
/*  55 */       if (mediaType == null) {
/*  56 */         return true;
/*     */       }
/*  58 */       for (MediaType supportedMediaType : getWritableMediaTypes()) {
/*  59 */         if (supportedMediaType.isCompatibleWith(mediaType)) {
/*  60 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends PartEvent> partDataStream, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage outputMessage, Map<String, Object> hints) {
/*  72 */     byte[] boundary = generateMultipartBoundary();
/*     */     
/*  74 */     mediaType = getMultipartMediaType(mediaType, boundary);
/*  75 */     outputMessage.getHeaders().setContentType(mediaType);
/*     */     
/*  77 */     if (this.logger.isDebugEnabled()) {
/*  78 */       this.logger.debug(Hints.getLogPrefix(hints) + "Encoding Publisher<PartEvent>");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     Flux<DataBuffer> body = Flux.from(partDataStream).windowUntil(PartEvent::isLast).concatMap(partData -> partData.switchOnFirst(())).concatWith((Publisher)generateLastLine(boundary, outputMessage.bufferFactory())).doOnDiscard(DataBuffer.class, DataBufferUtils::release);
/*     */     
/*  98 */     if (this.logger.isDebugEnabled()) {
/*  99 */       body = body.doOnNext(buffer -> Hints.touchDataBuffer(buffer, hints, this.logger));
/*     */     }
/*     */     
/* 102 */     return outputMessage.writeWith((Publisher)body);
/*     */   }
/*     */   
/*     */   private Flux<DataBuffer> encodePartData(byte[] boundary, DataBufferFactory bufferFactory, HttpHeaders headers, Flux<DataBuffer> body) {
/* 106 */     return Flux.concat(new Publisher[] { (Publisher)
/* 107 */           generateBoundaryLine(boundary, bufferFactory), (Publisher)
/* 108 */           generatePartHeaders(headers, bufferFactory), (Publisher)body, (Publisher)
/*     */           
/* 110 */           generateNewLine(bufferFactory) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\PartEventHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */