/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.ResolvableTypeProvider;
/*     */ import org.springframework.core.codec.CharSequenceEncoder;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.Encoder;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.http.codec.EncoderHttpMessageWriter;
/*     */ import org.springframework.http.codec.FormHttpMessageWriter;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.http.codec.ResourceHttpMessageWriter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartHttpMessageWriter
/*     */   extends MultipartWriterSupport
/*     */   implements HttpMessageWriter<MultiValueMap<String, ?>>
/*     */ {
/*  79 */   private static final Map<String, Object> DEFAULT_HINTS = Hints.from(Hints.SUPPRESS_LOGGING_HINT, Boolean.valueOf(true));
/*     */ 
/*     */ 
/*     */   
/*     */   private final Supplier<List<HttpMessageWriter<?>>> partWritersSupplier;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final HttpMessageWriter<MultiValueMap<String, String>> formWriter;
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartHttpMessageWriter() {
/*  92 */     this(Arrays.asList((HttpMessageWriter<?>[])new HttpMessageWriter[] { (HttpMessageWriter)new EncoderHttpMessageWriter(
/*  93 */               (Encoder)CharSequenceEncoder.textPlainOnly()), (HttpMessageWriter)new ResourceHttpMessageWriter() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartHttpMessageWriter(List<HttpMessageWriter<?>> partWriters) {
/* 102 */     this(partWriters, (HttpMessageWriter<MultiValueMap<String, String>>)new FormHttpMessageWriter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartHttpMessageWriter(List<HttpMessageWriter<?>> partWriters, @Nullable HttpMessageWriter<MultiValueMap<String, String>> formWriter) {
/* 115 */     this(() -> partWriters, formWriter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartHttpMessageWriter(Supplier<List<HttpMessageWriter<?>>> partWritersSupplier, @Nullable HttpMessageWriter<MultiValueMap<String, String>> formWriter) {
/* 130 */     super(initMediaTypes(formWriter));
/* 131 */     this.partWritersSupplier = partWritersSupplier;
/* 132 */     this.formWriter = formWriter;
/*     */   }
/*     */   
/*     */   private static List<MediaType> initMediaTypes(@Nullable HttpMessageWriter<?> formWriter) {
/* 136 */     List<MediaType> result = new ArrayList<>(MultipartHttpMessageReader.MIME_TYPES);
/* 137 */     if (formWriter != null) {
/* 138 */       result.addAll(formWriter.getWritableMediaTypes());
/*     */     }
/* 140 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HttpMessageWriter<?>> getPartWriters() {
/* 149 */     return Collections.unmodifiableList(this.partWritersSupplier.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HttpMessageWriter<MultiValueMap<String, String>> getFormWriter() {
/* 159 */     return this.formWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 165 */     if (MultiValueMap.class.isAssignableFrom(elementType.toClass())) {
/* 166 */       if (mediaType == null) {
/* 167 */         return true;
/*     */       }
/* 169 */       for (MediaType supportedMediaType : getWritableMediaTypes()) {
/* 170 */         if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 171 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends MultiValueMap<String, ?>> inputStream, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage outputMessage, Map<String, Object> hints) {
/* 183 */     return Mono.from(inputStream)
/* 184 */       .flatMap(map -> {
/*     */           if (this.formWriter == null || isMultipart(map, mediaType)) {
/*     */             return writeMultipart(map, outputMessage, mediaType, hints);
/*     */           }
/*     */           Mono<MultiValueMap<String, String>> input = Mono.just(map);
/*     */           return this.formWriter.write((Publisher)input, elementType, mediaType, outputMessage, hints);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMultipart(MultiValueMap<String, ?> map, @Nullable MediaType contentType) {
/* 197 */     if (contentType != null) {
/* 198 */       return contentType.getType().equalsIgnoreCase("multipart");
/*     */     }
/* 200 */     for (List<?> values : (Iterable<List<?>>)map.values()) {
/* 201 */       for (Object value : values) {
/* 202 */         if (value != null && !(value instanceof String)) {
/* 203 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> writeMultipart(MultiValueMap<String, ?> map, ReactiveHttpOutputMessage outputMessage, @Nullable MediaType mediaType, Map<String, Object> hints) {
/* 213 */     byte[] boundary = generateMultipartBoundary();
/*     */     
/* 215 */     mediaType = getMultipartMediaType(mediaType, boundary);
/* 216 */     outputMessage.getHeaders().setContentType(mediaType);
/*     */     
/* 218 */     LogFormatUtils.traceDebug(this.logger, traceOn -> Hints.getLogPrefix(hints) + "Encoding " + Hints.getLogPrefix(hints));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     DataBufferFactory bufferFactory = outputMessage.bufferFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     Flux<DataBuffer> body = Flux.fromIterable(map.entrySet()).concatMap(entry -> encodePartValues(boundary, (String)entry.getKey(), (List)entry.getValue(), bufferFactory)).concatWith((Publisher)generateLastLine(boundary, bufferFactory)).doOnDiscard(DataBuffer.class, DataBufferUtils::release);
/*     */     
/* 230 */     if (this.logger.isDebugEnabled()) {
/* 231 */       body = body.doOnNext(buffer -> Hints.touchDataBuffer(buffer, hints, this.logger));
/*     */     }
/*     */     
/* 234 */     return outputMessage.writeWith((Publisher)body);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Flux<DataBuffer> encodePartValues(byte[] boundary, String name, List<?> values, DataBufferFactory bufferFactory) {
/* 240 */     return Flux.fromIterable(values)
/* 241 */       .concatMap(value -> encodePart(boundary, name, value, bufferFactory));
/*     */   }
/*     */   private <T> Flux<DataBuffer> encodePart(byte[] boundary, String name, T value, DataBufferFactory factory) {
/*     */     T body;
/*     */     Mono mono;
/* 246 */     MultipartHttpOutputMessage message = new MultipartHttpOutputMessage(factory);
/* 247 */     HttpHeaders headers = message.getHeaders();
/*     */ 
/*     */     
/* 250 */     ResolvableType resolvableType = null;
/* 251 */     if (value instanceof HttpEntity) { HttpEntity httpEntity = (HttpEntity)value;
/* 252 */       headers.putAll((Map)httpEntity.getHeaders());
/* 253 */       body = (T)httpEntity.getBody();
/* 254 */       Assert.state((body != null), "MultipartHttpMessageWriter only supports HttpEntity with body");
/* 255 */       if (httpEntity instanceof ResolvableTypeProvider) { ResolvableTypeProvider resolvableTypeProvider = (ResolvableTypeProvider)httpEntity;
/* 256 */         resolvableType = resolvableTypeProvider.getResolvableType(); }
/*     */        }
/*     */     else
/*     */     
/* 260 */     { body = value; }
/*     */     
/* 262 */     if (resolvableType == null) {
/* 263 */       resolvableType = ResolvableType.forClass(body.getClass());
/*     */     }
/*     */     
/* 266 */     if (!headers.containsKey("Content-Disposition")) {
/* 267 */       if (body instanceof Resource) { Resource resource = (Resource)body;
/* 268 */         headers.setContentDispositionFormData(name, resource.getFilename()); }
/*     */       
/* 270 */       else if (resolvableType.resolve() == Resource.class)
/* 271 */       { mono = Mono.from((Publisher)body).doOnNext(o -> headers.setContentDispositionFormData(name, ((Resource)o).getFilename())); }
/*     */       
/*     */       else
/*     */       
/* 275 */       { headers.setContentDispositionFormData(name, null); }
/*     */     
/*     */     }
/*     */     
/* 279 */     MediaType contentType = headers.getContentType();
/*     */     
/* 281 */     ResolvableType finalBodyType = resolvableType;
/*     */ 
/*     */     
/* 284 */     Optional<HttpMessageWriter<?>> writer = ((List<HttpMessageWriter<?>>)this.partWritersSupplier.get()).stream().filter(partWriter -> partWriter.canWrite(finalBodyType, contentType)).findFirst();
/*     */     
/* 286 */     if (writer.isEmpty()) {
/* 287 */       return Flux.error((Throwable)new CodecException("No suitable writer found for part: " + name));
/*     */     }
/*     */     
/* 290 */     Publisher<T> publisher = (Publisher)mono, bodyPublisher = (mono instanceof Publisher) ? publisher : (Publisher<T>)Mono.just(mono);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     Mono<Void> partContentReady = ((HttpMessageWriter)writer.get()).write(bodyPublisher, resolvableType, contentType, message, DEFAULT_HINTS);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     Objects.requireNonNull(message); Flux<DataBuffer> partContent = partContentReady.thenMany((Publisher)Flux.defer(message::getBody));
/*     */     
/* 303 */     return Flux.concat(new Publisher[] { (Publisher)
/* 304 */           generateBoundaryLine(boundary, factory), (Publisher)partContent, (Publisher)
/*     */           
/* 306 */           generateNewLine(factory) });
/*     */   }
/*     */ 
/*     */   
/*     */   private class MultipartHttpOutputMessage
/*     */     implements ReactiveHttpOutputMessage
/*     */   {
/*     */     private final DataBufferFactory bufferFactory;
/* 314 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     
/* 316 */     private final AtomicBoolean committed = new AtomicBoolean();
/*     */     
/*     */     @Nullable
/*     */     private Flux<DataBuffer> body;
/*     */     
/*     */     public MultipartHttpOutputMessage(DataBufferFactory bufferFactory) {
/* 322 */       this.bufferFactory = bufferFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 327 */       return (this.body != null) ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public DataBufferFactory bufferFactory() {
/* 332 */       return this.bufferFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public void beforeCommit(Supplier<? extends Mono<Void>> action) {
/* 337 */       this.committed.set(true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCommitted() {
/* 342 */       return this.committed.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 347 */       if (this.body != null) {
/* 348 */         return Mono.error(new IllegalStateException("Multiple calls to writeWith() not supported"));
/*     */       }
/* 350 */       this.body = MultipartHttpMessageWriter.this.generatePartHeaders(this.headers, this.bufferFactory).concatWith(body);
/*     */ 
/*     */       
/* 353 */       return Mono.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 358 */       return Mono.error(new UnsupportedOperationException());
/*     */     }
/*     */     
/*     */     public Flux<DataBuffer> getBody() {
/* 362 */       return (this.body != null) ? this.body : 
/* 363 */         Flux.error(new IllegalStateException("Body has not been written yet"));
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> setComplete() {
/* 368 */       return Mono.error(new UnsupportedOperationException());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */