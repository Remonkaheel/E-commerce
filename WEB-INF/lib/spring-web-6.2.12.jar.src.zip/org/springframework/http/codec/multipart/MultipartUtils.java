/*     */ package org.springframework.http.codec.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.Channel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MultipartUtils
/*     */ {
/*     */   public static Charset charset(HttpHeaders headers) {
/*  43 */     MediaType contentType = headers.getContentType();
/*  44 */     if (contentType != null) {
/*  45 */       Charset charset = contentType.getCharset();
/*  46 */       if (charset != null) {
/*  47 */         return charset;
/*     */       }
/*     */     } 
/*  50 */     return StandardCharsets.UTF_8;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static byte[] boundary(HttpMessage message, Charset headersCharset) {
/*  55 */     MediaType contentType = message.getHeaders().getContentType();
/*  56 */     if (contentType != null) {
/*  57 */       String boundary = contentType.getParameter("boundary");
/*  58 */       if (boundary != null) {
/*  59 */         int len = boundary.length();
/*  60 */         if (len > 2 && boundary.charAt(0) == '"' && boundary.charAt(len - 1) == '"') {
/*  61 */           boundary = boundary.substring(1, len - 1);
/*     */         }
/*  63 */         return boundary.getBytes(headersCharset);
/*     */       } 
/*     */     } 
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] concat(byte[]... byteArrays) {
/*  74 */     int len = 0;
/*  75 */     for (byte[] byteArray : byteArrays) {
/*  76 */       len += byteArray.length;
/*     */     }
/*  78 */     byte[] result = new byte[len];
/*  79 */     len = 0;
/*  80 */     for (byte[] byteArray : byteArrays) {
/*  81 */       System.arraycopy(byteArray, 0, result, len, byteArray.length);
/*  82 */       len += byteArray.length;
/*     */     } 
/*  84 */     return result;
/*     */   }
/*     */   
/*     */   public static void closeChannel(Channel channel) {
/*     */     try {
/*  89 */       if (channel.isOpen()) {
/*  90 */         channel.close();
/*     */       }
/*     */     }
/*  93 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static void deleteFile(Path file) {
/*     */     try {
/*  99 */       Files.delete(file);
/*     */     }
/* 101 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isFormField(HttpHeaders headers) {
/* 106 */     MediaType contentType = headers.getContentType();
/* 107 */     return ((contentType == null || MediaType.TEXT_PLAIN.equalsTypeAndSubtype((MimeType)contentType)) && headers
/* 108 */       .getContentDisposition().getFilename() == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\multipart\MultipartUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */