/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlinx.serialization.DeserializationStrategy;
/*     */ import kotlinx.serialization.KSerializer;
/*     */ import kotlinx.serialization.StringFormat;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.codec.StringDecoder;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KotlinSerializationStringDecoder<T extends StringFormat>
/*     */   extends KotlinSerializationSupport<T>
/*     */   implements Decoder<Object>
/*     */ {
/*  51 */   private final StringDecoder stringDecoder = StringDecoder.allMimeTypes(StringDecoder.DEFAULT_DELIMITERS, false);
/*     */ 
/*     */   
/*     */   public KotlinSerializationStringDecoder(T format, MimeType... supportedMimeTypes) {
/*  55 */     super(format, supportedMimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/*  70 */     this.stringDecoder.setMaxInMemorySize(byteCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/*  77 */     return this.stringDecoder.getMaxInMemorySize();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  82 */     return canSerialize(elementType, mimeType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes() {
/*  87 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes(ResolvableType targetType) {
/*  92 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Object> decode(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  98 */     return Flux.defer(() -> {
/*     */           KSerializer<Object> serializer = serializer(elementType);
/*     */           return (Publisher)((serializer == null) ? Mono.error((Throwable)new DecodingException("Could not find KSerializer for " + String.valueOf(elementType))) : this.stringDecoder.decode(inputStream, elementType, mimeType, hints).handle(()));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> decodeToMono(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 119 */     return Mono.defer(() -> {
/*     */           KSerializer<Object> serializer = serializer(elementType);
/*     */           return (serializer == null) ? Mono.error((Throwable)new DecodingException("Could not find KSerializer for " + String.valueOf(elementType))) : this.stringDecoder.decodeToMono(inputStream, elementType, mimeType, hints).handle(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodecException processException(IllegalArgumentException ex) {
/* 139 */     return (CodecException)new DecodingException("Decoding error: " + ex.getMessage(), ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\KotlinSerializationStringDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */