/*     */ package org.springframework.http.codec.xml;
/*     */ 
/*     */ import com.fasterxml.aalto.AsyncByteBufferFeeder;
/*     */ import com.fasterxml.aalto.AsyncXMLInputFactory;
/*     */ import com.fasterxml.aalto.AsyncXMLStreamReader;
/*     */ import com.fasterxml.aalto.evt.EventAllocatorImpl;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.XMLEventAllocator;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.AbstractDecoder;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.xml.StaxUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.SignalType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlEventDecoder
/*     */   extends AbstractDecoder<XMLEvent>
/*     */ {
/*  87 */   private static final XMLInputFactory inputFactory = StaxUtils.createDefensiveInputFactory();
/*     */   
/*  89 */   private static final boolean aaltoPresent = ClassUtils.isPresent("com.fasterxml.aalto.AsyncXMLStreamReader", XmlEventDecoder.class
/*  90 */       .getClassLoader());
/*     */   
/*  92 */   boolean useAalto = aaltoPresent;
/*     */   
/*  94 */   private int maxInMemorySize = 262144;
/*     */ 
/*     */   
/*     */   public XmlEventDecoder() {
/*  98 */     super(new MimeType[] { MimeTypeUtils.APPLICATION_XML, MimeTypeUtils.TEXT_XML, (MimeType)new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/* 112 */     this.maxInMemorySize = byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/* 120 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<XMLEvent> decode(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 128 */     if (this.useAalto) {
/* 129 */       AaltoDataBufferToXmlEvent mapper = new AaltoDataBufferToXmlEvent(this.maxInMemorySize);
/* 130 */       return Flux.from(input)
/* 131 */         .flatMapIterable(mapper)
/* 132 */         .doFinally(signalType -> mapper.endOfInput());
/*     */     } 
/*     */     
/* 135 */     return DataBufferUtils.join(input, this.maxInMemorySize)
/* 136 */       .flatMapIterable(buffer -> {
/*     */           try {
/*     */             InputStream is = buffer.asInputStream();
/*     */             
/*     */             Iterator<Object> eventReader = inputFactory.createXMLEventReader(is);
/*     */             List<XMLEvent> result = new ArrayList<>();
/*     */             eventReader.forEachRemaining(());
/*     */             return result;
/* 144 */           } catch (XMLStreamException ex) {
/*     */             throw new DecodingException(ex.getMessage(), ex);
/*     */           } finally {
/*     */             DataBufferUtils.release(buffer);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AaltoDataBufferToXmlEvent
/*     */     implements Function<DataBuffer, List<? extends XMLEvent>>
/*     */   {
/* 161 */     private static final AsyncXMLInputFactory inputFactory = (AsyncXMLInputFactory)StaxUtils.createDefensiveInputFactory(com.fasterxml.aalto.stax.InputFactoryImpl::new);
/*     */     
/* 163 */     private final AsyncXMLStreamReader<AsyncByteBufferFeeder> streamReader = inputFactory
/* 164 */       .createAsyncForByteBuffer();
/*     */     
/* 166 */     private final XMLEventAllocator eventAllocator = (XMLEventAllocator)EventAllocatorImpl.getDefaultInstance();
/*     */     
/*     */     private final int maxInMemorySize;
/*     */     
/*     */     private int byteCount;
/*     */     
/*     */     private int elementDepth;
/*     */ 
/*     */     
/*     */     public AaltoDataBufferToXmlEvent(int maxInMemorySize) {
/* 176 */       this.maxInMemorySize = maxInMemorySize;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends XMLEvent> apply(DataBuffer dataBuffer) {
/*     */       try {
/* 183 */         increaseByteCount(dataBuffer);
/* 184 */         AsyncByteBufferFeeder inputFeeder = (AsyncByteBufferFeeder)this.streamReader.getInputFeeder();
/* 185 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 186 */         try { while (iterator.hasNext()) {
/* 187 */             inputFeeder.feedInput((ByteBuffer)iterator.next());
/*     */           }
/* 189 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 190 */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  List<XMLEvent> events = new ArrayList<>();
/*     */         
/* 192 */         while (this.streamReader.next() != 257) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 197 */           XMLEvent event = this.eventAllocator.allocate((XMLStreamReader)this.streamReader);
/* 198 */           events.add(event);
/* 199 */           if (event.isEndDocument()) {
/*     */             break;
/*     */           }
/* 202 */           checkDepthAndResetByteCount(event);
/*     */         } 
/*     */         
/* 205 */         if (this.maxInMemorySize > 0 && this.byteCount > this.maxInMemorySize) {
/* 206 */           raiseLimitException();
/*     */         }
/* 208 */         return events;
/*     */       }
/* 210 */       catch (XMLStreamException ex) {
/* 211 */         throw new DecodingException(ex.getMessage(), ex);
/*     */       } finally {
/*     */         
/* 214 */         DataBufferUtils.release(dataBuffer);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void increaseByteCount(DataBuffer dataBuffer) {
/* 219 */       if (this.maxInMemorySize > 0) {
/* 220 */         if (dataBuffer.readableByteCount() > Integer.MAX_VALUE - this.byteCount) {
/* 221 */           raiseLimitException();
/*     */         } else {
/*     */           
/* 224 */           this.byteCount += dataBuffer.readableByteCount();
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void checkDepthAndResetByteCount(XMLEvent event) {
/* 230 */       if (this.maxInMemorySize > 0) {
/* 231 */         if (event.isStartElement()) {
/* 232 */           this.byteCount = (this.elementDepth == 1) ? 0 : this.byteCount;
/* 233 */           this.elementDepth++;
/*     */         }
/* 235 */         else if (event.isEndElement()) {
/* 236 */           this.elementDepth--;
/* 237 */           this.byteCount = (this.elementDepth == 1) ? 0 : this.byteCount;
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void raiseLimitException() {
/* 243 */       throw new DataBufferLimitException("Exceeded limit on max bytes per XML top-level node: " + this.maxInMemorySize);
/*     */     }
/*     */ 
/*     */     
/*     */     public void endOfInput() {
/* 248 */       ((AsyncByteBufferFeeder)this.streamReader.getInputFeeder()).endOfInput();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\XmlEventDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */