/*     */ package org.springframework.http.codec.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SplitHandler
/*     */   implements BiConsumer<XMLEvent, SynchronousSink<List<XMLEvent>>>
/*     */ {
/*     */   private final Set<QName> names;
/*     */   @Nullable
/*     */   private List<XMLEvent> events;
/* 156 */   private int elementDepth = 0;
/*     */   
/* 158 */   private int barrier = Integer.MAX_VALUE;
/*     */   
/*     */   public SplitHandler(Set<QName> names) {
/* 161 */     this.names = names;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(XMLEvent event, SynchronousSink<List<XMLEvent>> sink) {
/* 166 */     if (event.isStartElement()) {
/* 167 */       if (this.barrier == Integer.MAX_VALUE) {
/* 168 */         QName startElementName = event.asStartElement().getName();
/* 169 */         if (this.names.contains(startElementName)) {
/* 170 */           this.events = new ArrayList<>();
/* 171 */           this.barrier = this.elementDepth;
/*     */         } 
/*     */       } 
/* 174 */       this.elementDepth++;
/*     */     } 
/* 176 */     if (this.elementDepth > this.barrier) {
/* 177 */       Assert.state((this.events != null), "No XMLEvent List");
/* 178 */       this.events.add(event);
/*     */     } 
/* 180 */     if (event.isEndElement()) {
/* 181 */       this.elementDepth--;
/* 182 */       if (this.elementDepth == this.barrier) {
/* 183 */         this.barrier = Integer.MAX_VALUE;
/* 184 */         Assert.state((this.events != null), "No XMLEvent List");
/* 185 */         sink.next(this.events);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\Jaxb2Helper$SplitHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */