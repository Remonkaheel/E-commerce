/*     */ package org.springframework.http.codec.xml;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.MarshalException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.AbstractSingleValueEncoder;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.EncodingException;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jaxb2XmlEncoder
/*     */   extends AbstractSingleValueEncoder<Object>
/*     */ {
/*  62 */   private final JaxbContextContainer jaxbContexts = new JaxbContextContainer();
/*     */   
/*  64 */   private Function<Marshaller, Marshaller> marshallerProcessor = Function.identity();
/*     */ 
/*     */   
/*     */   public Jaxb2XmlEncoder() {
/*  68 */     super(new MimeType[] { MimeTypeUtils.APPLICATION_XML, MimeTypeUtils.TEXT_XML, (MimeType)new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarshallerProcessor(Function<Marshaller, Marshaller> processor) {
/*  78 */     this.marshallerProcessor = this.marshallerProcessor.andThen(processor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Function<Marshaller, Marshaller> getMarshallerProcessor() {
/*  86 */     return this.marshallerProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  92 */     if (super.canEncode(elementType, mimeType)) {
/*  93 */       Class<?> outputClass = elementType.toClass();
/*  94 */       return (outputClass.isAnnotationPresent((Class)XmlRootElement.class) || outputClass
/*  95 */         .isAnnotationPresent((Class)XmlType.class) || JAXBElement.class
/*  96 */         .isAssignableFrom(outputClass));
/*     */     } 
/*     */     
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Flux<DataBuffer> encode(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 108 */     return Mono.fromCallable(() -> encodeValue(value, bufferFactory, valueType, mimeType, hints)).flux();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 115 */     if (!Hints.isLoggingSuppressed(hints)) {
/* 116 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*     */             String formatted = LogFormatUtils.formatValue(value, !traceOn.booleanValue());
/*     */             
/*     */             return Hints.getLogPrefix(hints) + "Encoding [" + Hints.getLogPrefix(hints) + "]";
/*     */           });
/*     */     }
/* 122 */     boolean release = true;
/* 123 */     DataBuffer buffer = bufferFactory.allocateBuffer(1024);
/*     */     try {
/* 125 */       OutputStream outputStream = buffer.asOutputStream();
/* 126 */       Class<?> clazz = getMarshallerType(value);
/* 127 */       Marshaller marshaller = initMarshaller(clazz);
/* 128 */       marshaller.marshal(value, outputStream);
/* 129 */       release = false;
/* 130 */       return buffer;
/*     */     }
/* 132 */     catch (MarshalException ex) {
/* 133 */       throw new EncodingException("Could not marshal " + String.valueOf(value.getClass()) + " to XML", ex);
/*     */     }
/* 135 */     catch (JAXBException ex) {
/* 136 */       throw new CodecException("Invalid JAXB configuration", ex);
/*     */     } finally {
/*     */       
/* 139 */       if (release) {
/* 140 */         DataBufferUtils.release(buffer);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class<?> getMarshallerType(Object value) {
/* 146 */     if (value instanceof JAXBElement) { JAXBElement<?> jaxbElement = (JAXBElement)value;
/* 147 */       return jaxbElement.getDeclaredType(); }
/*     */ 
/*     */     
/* 150 */     return ClassUtils.getUserClass(value);
/*     */   }
/*     */ 
/*     */   
/*     */   private Marshaller initMarshaller(Class<?> clazz) throws CodecException, JAXBException {
/* 155 */     Marshaller marshaller = this.jaxbContexts.createMarshaller(clazz);
/* 156 */     marshaller.setProperty("jaxb.encoding", StandardCharsets.UTF_8.name());
/* 157 */     marshaller = this.marshallerProcessor.apply(marshaller);
/* 158 */     return marshaller;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\Jaxb2XmlEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */