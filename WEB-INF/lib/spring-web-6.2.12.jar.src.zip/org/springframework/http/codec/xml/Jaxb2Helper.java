/*     */ package org.springframework.http.codec.xml;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Jaxb2Helper
/*     */ {
/*     */   private static final String JAXB_DEFAULT_ANNOTATION_VALUE = "##default";
/*     */   
/*     */   public static Set<QName> toQNames(Class<?> clazz) {
/*  63 */     Set<QName> result = new HashSet<>(1);
/*  64 */     findQNames(clazz, result, new HashSet<>());
/*  65 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void findQNames(Class<?> clazz, Set<QName> qNames, Set<Class<?>> completedClasses) {
/*  70 */     if (completedClasses.contains(clazz)) {
/*     */       return;
/*     */     }
/*  73 */     if (clazz.isAnnotationPresent((Class)XmlRootElement.class)) {
/*  74 */       XmlRootElement annotation = clazz.<XmlRootElement>getAnnotation(XmlRootElement.class);
/*  75 */       qNames.add(new QName(namespace(annotation.namespace(), clazz), 
/*  76 */             localPart(annotation.name(), clazz)));
/*     */     }
/*  78 */     else if (clazz.isAnnotationPresent((Class)XmlType.class)) {
/*  79 */       XmlType annotation = clazz.<XmlType>getAnnotation(XmlType.class);
/*  80 */       qNames.add(new QName(namespace(annotation.namespace(), clazz), 
/*  81 */             localPart(annotation.name(), clazz)));
/*     */     } else {
/*     */       
/*  84 */       throw new IllegalArgumentException("Output class [" + clazz.getName() + "] is neither annotated with @XmlRootElement nor @XmlType");
/*     */     } 
/*     */     
/*  87 */     completedClasses.add(clazz);
/*  88 */     if (clazz.isAnnotationPresent((Class)XmlSeeAlso.class)) {
/*  89 */       XmlSeeAlso annotation = clazz.<XmlSeeAlso>getAnnotation(XmlSeeAlso.class);
/*  90 */       for (Class<?> seeAlso : annotation.value()) {
/*  91 */         findQNames(seeAlso, qNames, completedClasses);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String localPart(String value, Class<?> outputClass) {
/*  97 */     if ("##default".equals(value)) {
/*  98 */       return ClassUtils.getShortNameAsProperty(outputClass);
/*     */     }
/*     */     
/* 101 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String namespace(String value, Class<?> outputClass) {
/* 106 */     if ("##default".equals(value)) {
/* 107 */       Package outputClassPackage = outputClass.getPackage();
/* 108 */       if (outputClassPackage != null && outputClassPackage.isAnnotationPresent((Class)XmlSchema.class)) {
/* 109 */         XmlSchema annotation = outputClassPackage.<XmlSchema>getAnnotation(XmlSchema.class);
/* 110 */         return annotation.namespace();
/*     */       } 
/*     */       
/* 113 */       return "";
/*     */     } 
/*     */ 
/*     */     
/* 117 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Flux<List<XMLEvent>> split(Flux<XMLEvent> xmlEventFlux, Set<QName> names) {
/* 145 */     return xmlEventFlux.handle(new SplitHandler(names));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SplitHandler
/*     */     implements BiConsumer<XMLEvent, SynchronousSink<List<XMLEvent>>>
/*     */   {
/*     */     private final Set<QName> names;
/*     */     
/*     */     @Nullable
/*     */     private List<XMLEvent> events;
/* 156 */     private int elementDepth = 0;
/*     */     
/* 158 */     private int barrier = Integer.MAX_VALUE;
/*     */     
/*     */     public SplitHandler(Set<QName> names) {
/* 161 */       this.names = names;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(XMLEvent event, SynchronousSink<List<XMLEvent>> sink) {
/* 166 */       if (event.isStartElement()) {
/* 167 */         if (this.barrier == Integer.MAX_VALUE) {
/* 168 */           QName startElementName = event.asStartElement().getName();
/* 169 */           if (this.names.contains(startElementName)) {
/* 170 */             this.events = new ArrayList<>();
/* 171 */             this.barrier = this.elementDepth;
/*     */           } 
/*     */         } 
/* 174 */         this.elementDepth++;
/*     */       } 
/* 176 */       if (this.elementDepth > this.barrier) {
/* 177 */         Assert.state((this.events != null), "No XMLEvent List");
/* 178 */         this.events.add(event);
/*     */       } 
/* 180 */       if (event.isEndElement()) {
/* 181 */         this.elementDepth--;
/* 182 */         if (this.elementDepth == this.barrier) {
/* 183 */           this.barrier = Integer.MAX_VALUE;
/* 184 */           Assert.state((this.events != null), "No XMLEvent List");
/* 185 */           sink.next(this.events);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\Jaxb2Helper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */