/*    */ package org.springframework.http.codec.xml;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBContext;
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import jakarta.xml.bind.Marshaller;
/*    */ import jakarta.xml.bind.Unmarshaller;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.core.codec.CodecException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JaxbContextContainer
/*    */ {
/* 38 */   private final ConcurrentMap<Class<?>, JAXBContext> jaxbContexts = new ConcurrentHashMap<>(64);
/*    */ 
/*    */   
/*    */   public Marshaller createMarshaller(Class<?> clazz) throws CodecException, JAXBException {
/* 42 */     JAXBContext jaxbContext = getJaxbContext(clazz);
/* 43 */     return jaxbContext.createMarshaller();
/*    */   }
/*    */   
/*    */   public Unmarshaller createUnmarshaller(Class<?> clazz) throws CodecException, JAXBException {
/* 47 */     JAXBContext jaxbContext = getJaxbContext(clazz);
/* 48 */     return jaxbContext.createUnmarshaller();
/*    */   }
/*    */   
/*    */   private JAXBContext getJaxbContext(Class<?> clazz) throws CodecException {
/* 52 */     return this.jaxbContexts.computeIfAbsent(clazz, key -> {
/*    */           
/*    */           try {
/*    */             return createJaxbContext(clazz);
/* 56 */           } catch (JAXBException ex) {
/*    */             throw new CodecException("Could not create JAXBContext for class [" + String.valueOf(clazz) + "]: " + ex.getMessage(), ex);
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private JAXBContext createJaxbContext(Class<?> clazz) throws JAXBException {
/* 69 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*    */     try {
/* 71 */       Thread.currentThread().setContextClassLoader(clazz.getClassLoader());
/* 72 */       return JAXBContext.newInstance(new Class[] { clazz });
/*    */     } finally {
/*    */       
/* 75 */       Thread.currentThread().setContextClassLoader(currentClassLoader);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\JaxbContextContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */