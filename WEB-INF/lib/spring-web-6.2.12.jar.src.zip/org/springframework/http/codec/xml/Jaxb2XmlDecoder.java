/*     */ package org.springframework.http.codec.xml;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.AbstractDecoder;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.xml.StaxUtils;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jaxb2XmlDecoder
/*     */   extends AbstractDecoder<Object>
/*     */ {
/*  72 */   private static final XMLInputFactory inputFactory = StaxUtils.createDefensiveInputFactory();
/*     */ 
/*     */   
/*  75 */   private final XmlEventDecoder xmlEventDecoder = new XmlEventDecoder();
/*     */   
/*  77 */   private final JaxbContextContainer jaxbContexts = new JaxbContextContainer();
/*     */   
/*  79 */   private Function<Unmarshaller, Unmarshaller> unmarshallerProcessor = Function.identity();
/*     */   
/*  81 */   private int maxInMemorySize = 262144;
/*     */ 
/*     */   
/*     */   public Jaxb2XmlDecoder() {
/*  85 */     super(new MimeType[] { MimeTypeUtils.APPLICATION_XML, MimeTypeUtils.TEXT_XML, (MimeType)new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jaxb2XmlDecoder(MimeType... supportedMimeTypes) {
/*  94 */     super(supportedMimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnmarshallerProcessor(Function<Unmarshaller, Unmarshaller> processor) {
/* 104 */     this.unmarshallerProcessor = this.unmarshallerProcessor.andThen(processor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Function<Unmarshaller, Unmarshaller> getUnmarshallerProcessor() {
/* 112 */     return this.unmarshallerProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/* 125 */     this.maxInMemorySize = byteCount;
/* 126 */     this.xmlEventDecoder.setMaxInMemorySize(byteCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/* 134 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 140 */     Class<?> outputClass = elementType.toClass();
/* 141 */     return ((outputClass.isAnnotationPresent((Class)XmlRootElement.class) || outputClass
/* 142 */       .isAnnotationPresent((Class)XmlType.class)) && super.canDecode(elementType, mimeType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Object> decode(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 149 */     Flux<XMLEvent> xmlEventFlux = this.xmlEventDecoder.decode(inputStream, 
/* 150 */         ResolvableType.forClass(XMLEvent.class), mimeType, hints);
/*     */     
/* 152 */     Class<?> outputClass = elementType.toClass();
/* 153 */     Set<QName> typeNames = Jaxb2Helper.toQNames(outputClass);
/* 154 */     Flux<List<XMLEvent>> splitEvents = Jaxb2Helper.split(xmlEventFlux, typeNames);
/*     */     
/* 156 */     return splitEvents.map(events -> {
/*     */           Object value = unmarshal(events, outputClass);
/*     */           LogFormatUtils.traceDebug(this.logger, ());
/*     */           return value;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> decodeToMono(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 170 */     return DataBufferUtils.join(input, this.maxInMemorySize)
/* 171 */       .map(dataBuffer -> decode(dataBuffer, elementType, mimeType, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Object decode(DataBuffer dataBuffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) throws DecodingException {
/*     */     try {
/* 180 */       Iterator<Object> eventReader = inputFactory.createXMLEventReader(dataBuffer.asInputStream(), 
/* 181 */           encoding(mimeType));
/* 182 */       List<XMLEvent> events = new ArrayList<>();
/* 183 */       eventReader.forEachRemaining(event -> events.add((XMLEvent)event));
/* 184 */       return unmarshal(events, targetType.toClass());
/*     */     }
/* 186 */     catch (XMLStreamException ex) {
/* 187 */       throw new DecodingException(ex.getMessage(), ex);
/*     */     }
/* 189 */     catch (Throwable ex) {
/* 190 */       Throwable cause = ex.getCause();
/* 191 */       if (cause instanceof XMLStreamException) {
/* 192 */         throw new DecodingException(cause.getMessage(), cause);
/*     */       }
/*     */       
/* 195 */       throw Exceptions.propagate(ex);
/*     */     }
/*     */     finally {
/*     */       
/* 199 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String encoding(@Nullable MimeType mimeType) {
/* 205 */     if (mimeType == null) {
/* 206 */       return null;
/*     */     }
/* 208 */     Charset charset = mimeType.getCharset();
/* 209 */     if (charset == null) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     return charset.name();
/*     */   }
/*     */ 
/*     */   
/*     */   private Object unmarshal(List<XMLEvent> events, Class<?> outputClass) {
/*     */     try {
/* 219 */       Unmarshaller unmarshaller = initUnmarshaller(outputClass);
/* 220 */       XMLEventReader eventReader = StaxUtils.createXMLEventReader(events);
/* 221 */       if (outputClass.isAnnotationPresent((Class)XmlRootElement.class) || outputClass
/* 222 */         .isAnnotationPresent((Class)XmlSeeAlso.class)) {
/* 223 */         return unmarshaller.unmarshal(eventReader);
/*     */       }
/*     */       
/* 226 */       JAXBElement<?> jaxbElement = unmarshaller.unmarshal(eventReader, outputClass);
/* 227 */       return jaxbElement.getValue();
/*     */     
/*     */     }
/* 230 */     catch (UnmarshalException ex) {
/* 231 */       throw new DecodingException("Could not unmarshal XML to " + String.valueOf(outputClass), ex);
/*     */     }
/* 233 */     catch (JAXBException ex) {
/* 234 */       throw new CodecException("Invalid JAXB configuration", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Unmarshaller initUnmarshaller(Class<?> outputClass) throws CodecException, JAXBException {
/* 239 */     Unmarshaller unmarshaller = this.jaxbContexts.createUnmarshaller(outputClass);
/* 240 */     return this.unmarshallerProcessor.apply(unmarshaller);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\xml\Jaxb2XmlDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */