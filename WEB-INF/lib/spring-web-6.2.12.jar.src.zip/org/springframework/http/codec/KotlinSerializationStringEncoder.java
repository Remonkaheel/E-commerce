/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import kotlinx.serialization.KSerializer;
/*     */ import kotlinx.serialization.SerializationStrategy;
/*     */ import kotlinx.serialization.StringFormat;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CharSequenceEncoder;
/*     */ import org.springframework.core.codec.Encoder;
/*     */ import org.springframework.core.codec.EncodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KotlinSerializationStringEncoder<T extends StringFormat>
/*     */   extends KotlinSerializationSupport<T>
/*     */   implements Encoder<Object>
/*     */ {
/*  55 */   private static final byte[] NEWLINE_SEPARATOR = new byte[] { 10 };
/*     */   
/*  57 */   protected static final byte[] EMPTY_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */   
/*  61 */   private final CharSequenceEncoder charSequenceEncoder = CharSequenceEncoder.allMimeTypes();
/*  62 */   private final Set<MimeType> streamingMediaTypes = new HashSet<>();
/*     */   
/*     */   protected KotlinSerializationStringEncoder(T format, MimeType... supportedMimeTypes) {
/*  65 */     super(format, supportedMimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStreamingMediaTypes(Collection<MediaType> streamingMediaTypes) {
/*  74 */     this.streamingMediaTypes.clear();
/*  75 */     this.streamingMediaTypes.addAll(streamingMediaTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  80 */     return canSerialize(elementType, mimeType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes() {
/*  85 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes(ResolvableType elementType) {
/*  90 */     return supportedMimeTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> encode(Publisher<?> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  97 */     if (inputStream instanceof Mono) { Mono<?> mono = (Mono)inputStream;
/*  98 */       return mono
/*  99 */         .map(value -> encodeValue(value, bufferFactory, elementType, mimeType, hints))
/* 100 */         .flux(); }
/*     */     
/* 102 */     if (mimeType != null && this.streamingMediaTypes.contains(mimeType)) {
/* 103 */       return Flux.from(inputStream)
/* 104 */         .map(value -> encodeStreamingValue(value, bufferFactory, elementType, mimeType, hints, EMPTY_BYTES, NEWLINE_SEPARATOR));
/*     */     }
/*     */     
/* 107 */     return encodeNonStream(inputStream, bufferFactory, elementType, mimeType, hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataBuffer encodeStreamingValue(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints, byte[] prefix, byte[] suffix) {
/* 114 */     List<DataBuffer> buffers = new ArrayList<>(3);
/* 115 */     if (prefix.length > 0) {
/* 116 */       buffers.add(bufferFactory.allocateBuffer(prefix.length).write(prefix));
/*     */     }
/* 118 */     buffers.add(encodeValue(value, bufferFactory, valueType, mimeType, hints));
/* 119 */     if (suffix.length > 0) {
/* 120 */       buffers.add(bufferFactory.allocateBuffer(suffix.length).write(suffix));
/*     */     }
/* 122 */     return bufferFactory.join(buffers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Flux<DataBuffer> encodeNonStream(Publisher<?> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 128 */     ResolvableType listType = ResolvableType.forClassWithGenerics(List.class, new ResolvableType[] { elementType });
/* 129 */     return Flux.from(inputStream)
/* 130 */       .collectList()
/* 131 */       .map(list -> encodeValue(list, bufferFactory, listType, mimeType, hints))
/* 132 */       .flux();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 140 */     KSerializer<Object> serializer = serializer(valueType);
/* 141 */     if (serializer == null) {
/* 142 */       throw new EncodingException("Could not find KSerializer for " + String.valueOf(valueType));
/*     */     }
/* 144 */     String string = ((StringFormat)format()).encodeToString((SerializationStrategy)serializer, value);
/* 145 */     return this.charSequenceEncoder.encodeValue(string, bufferFactory, valueType, mimeType, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\KotlinSerializationStringEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */