/*    */ package org.springframework.http.codec;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.http.codec.support.DefaultClientCodecConfigurer;
/*    */ import org.springframework.http.codec.support.DefaultServerCodecConfigurer;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CodecConfigurerRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 39 */     hints.resources().registerPattern("org/springframework/http/codec/CodecConfigurer.properties");
/*    */     
/* 41 */     hints.reflection().registerTypes(
/* 42 */         TypeReference.listOf(new Class[] { DefaultClientCodecConfigurer.class, DefaultServerCodecConfigurer.class }, ), typeHint -> typeHint.onReachableType(CodecConfigurerFactory.class).withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\CodecConfigurerRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */