/*    */ package org.springframework.http.codec.json;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Arrays;
/*    */ import java.util.Map;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.codec.CharBufferDecoder;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jackson2JsonDecoder
/*    */   extends AbstractJackson2Decoder
/*    */ {
/* 49 */   private static final CharBufferDecoder CHAR_BUFFER_DECODER = CharBufferDecoder.textPlainOnly(Arrays.asList(new String[] { ",", "\n" }, ), false);
/*    */   
/* 51 */   private static final ResolvableType CHAR_BUFFER_TYPE = ResolvableType.forClass(CharBuffer.class);
/*    */ 
/*    */   
/*    */   public Jackson2JsonDecoder() {
/* 55 */     super(Jackson2ObjectMapperBuilder.json().build(), new MimeType[0]);
/*    */   }
/*    */   
/*    */   public Jackson2JsonDecoder(ObjectMapper mapper, MimeType... mimeTypes) {
/* 59 */     super(mapper, mimeTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Flux<DataBuffer> processInput(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 66 */     Flux<DataBuffer> flux = Flux.from(input);
/* 67 */     if (mimeType == null) {
/* 68 */       return flux;
/*    */     }
/*    */ 
/*    */     
/* 72 */     Charset charset = mimeType.getCharset();
/* 73 */     if (charset == null || StandardCharsets.UTF_8.equals(charset) || StandardCharsets.US_ASCII.equals(charset)) {
/* 74 */       return flux;
/*    */     }
/*    */ 
/*    */     
/* 78 */     MimeType textMimeType = new MimeType(MimeTypeUtils.TEXT_PLAIN, charset);
/* 79 */     Flux<CharBuffer> decoded = CHAR_BUFFER_DECODER.decode(input, CHAR_BUFFER_TYPE, textMimeType, null);
/* 80 */     return decoded.map(charBuffer -> DefaultDataBufferFactory.sharedInstance.wrap(StandardCharsets.UTF_8.encode(charBuffer)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\Jackson2JsonDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */