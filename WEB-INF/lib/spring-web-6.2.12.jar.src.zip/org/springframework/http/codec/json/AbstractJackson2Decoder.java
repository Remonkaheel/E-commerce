/*     */ package org.springframework.http.codec.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.PooledDataBuffer;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.codec.HttpMessageDecoder;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2Decoder
/*     */   extends Jackson2CodecSupport
/*     */   implements HttpMessageDecoder<Object>
/*     */ {
/*  67 */   private int maxInMemorySize = 262144;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJackson2Decoder(ObjectMapper mapper, MimeType... mimeTypes) {
/*  74 */     super(mapper, mimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/*  88 */     this.maxInMemorySize = byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/*  96 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 103 */     if (!supportsMimeType(mimeType)) {
/* 104 */       return false;
/*     */     }
/* 106 */     ObjectMapper mapper = selectObjectMapper(elementType, mimeType);
/* 107 */     if (mapper == null) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (CharSequence.class.isAssignableFrom(elementType.toClass())) {
/* 111 */       return false;
/*     */     }
/* 113 */     JavaType javaType = mapper.constructType(elementType.getType());
/* 114 */     if (!this.logger.isDebugEnabled()) {
/* 115 */       return mapper.canDeserialize(javaType);
/*     */     }
/*     */     
/* 118 */     AtomicReference<Throwable> causeRef = new AtomicReference<>();
/* 119 */     if (mapper.canDeserialize(javaType, causeRef)) {
/* 120 */       return true;
/*     */     }
/* 122 */     logWarningIfNecessary((Type)javaType, causeRef.get());
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Object> decode(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 131 */     ObjectMapper mapper = selectObjectMapper(elementType, mimeType);
/* 132 */     if (mapper == null) {
/* 133 */       return Flux.error(new IllegalStateException("No ObjectMapper for " + String.valueOf(elementType)));
/*     */     }
/*     */     
/* 136 */     boolean forceUseOfBigDecimal = mapper.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
/* 137 */     if (BigDecimal.class.equals(elementType.getType())) {
/* 138 */       forceUseOfBigDecimal = true;
/*     */     }
/*     */ 
/*     */     
/* 142 */     boolean tokenizeArrays = (!elementType.isArray() && !Collection.class.isAssignableFrom(elementType.resolve(Object.class)));
/*     */     
/* 144 */     Flux<DataBuffer> processed = processInput(input, elementType, mimeType, hints);
/* 145 */     Flux<TokenBuffer> tokens = Jackson2Tokenizer.tokenize(processed, mapper.getFactory(), mapper, tokenizeArrays, forceUseOfBigDecimal, 
/* 146 */         getMaxInMemorySize());
/*     */     
/* 148 */     return Flux.deferContextual(contextView -> {
/*     */           Map<String, Object> hintsToUse = contextView.isEmpty() ? hints : Hints.merge(hints, ContextView.class.getName(), contextView);
/*     */           ObjectReader reader = createObjectReader(mapper, elementType, hintsToUse);
/*     */           return (Publisher)tokens.handle(()).doOnDiscard(PooledDataBuffer.class, DataBufferUtils::release);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Flux<DataBuffer> processInput(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 185 */     return Flux.from(input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> decodeToMono(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 192 */     return Mono.deferContextual(contextView -> {
/*     */           Map<String, Object> hintsToUse = contextView.isEmpty() ? hints : Hints.merge(hints, ContextView.class.getName(), contextView);
/*     */           return DataBufferUtils.join(input, this.maxInMemorySize).flatMap(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decode(DataBuffer dataBuffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) throws DecodingException {
/* 206 */     ObjectMapper mapper = selectObjectMapper(targetType, mimeType);
/* 207 */     if (mapper == null) {
/* 208 */       throw new IllegalStateException("No ObjectMapper for " + String.valueOf(targetType));
/*     */     }
/*     */     
/*     */     try {
/* 212 */       ObjectReader objectReader = createObjectReader(mapper, targetType, hints);
/* 213 */       Object value = objectReader.readValue(dataBuffer.asInputStream());
/* 214 */       logValue(value, hints);
/* 215 */       return value;
/*     */     }
/* 217 */     catch (IOException ex) {
/* 218 */       throw processException(ex);
/*     */     } finally {
/*     */       
/* 221 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectReader createObjectReader(ObjectMapper mapper, ResolvableType elementType, @Nullable Map<String, Object> hints) {
/* 228 */     Assert.notNull(elementType, "'elementType' must not be null");
/* 229 */     Class<?> contextClass = getContextClass(elementType);
/* 230 */     if (contextClass == null && hints != null) {
/* 231 */       contextClass = getContextClass((ResolvableType)hints.get(ACTUAL_TYPE_HINT));
/*     */     }
/* 233 */     JavaType javaType = getJavaType(elementType.getType(), contextClass);
/* 234 */     Class<?> jsonView = (hints != null) ? (Class)hints.get(Jackson2CodecSupport.JSON_VIEW_HINT) : null;
/*     */ 
/*     */ 
/*     */     
/* 238 */     ObjectReader objectReader = (jsonView != null) ? mapper.readerWithView(jsonView).forType(javaType) : mapper.readerFor(javaType);
/*     */     
/* 240 */     return customizeReader(objectReader, elementType, hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectReader customizeReader(ObjectReader reader, ResolvableType elementType, @Nullable Map<String, Object> hints) {
/* 257 */     return reader;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Class<?> getContextClass(@Nullable ResolvableType elementType) {
/* 262 */     MethodParameter param = (elementType != null) ? getParameter(elementType) : null;
/* 263 */     return (param != null) ? param.getContainingClass() : null;
/*     */   }
/*     */   
/*     */   private void logValue(@Nullable Object value, @Nullable Map<String, Object> hints) {
/* 267 */     if (!Hints.isLoggingSuppressed(hints)) {
/* 268 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*     */             String formatted = LogFormatUtils.formatValue(value, !traceOn.booleanValue());
/*     */             return Hints.getLogPrefix(hints) + "Decoded [" + Hints.getLogPrefix(hints) + "]";
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private CodecException processException(IOException ex) {
/* 276 */     if (ex instanceof InvalidDefinitionException) { InvalidDefinitionException ide = (InvalidDefinitionException)ex;
/* 277 */       JavaType type = ide.getType();
/* 278 */       return new CodecException("Type definition error: " + String.valueOf(type), ex); }
/*     */     
/* 280 */     if (ex instanceof JsonProcessingException) { JsonProcessingException jpe = (JsonProcessingException)ex;
/* 281 */       String originalMessage = jpe.getOriginalMessage();
/* 282 */       return (CodecException)new DecodingException("JSON decoding error: " + originalMessage, ex); }
/*     */     
/* 284 */     return (CodecException)new DecodingException("I/O error while parsing input stream", ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDecodeHints(ResolvableType actualType, ResolvableType elementType, ServerHttpRequest request, ServerHttpResponse response) {
/* 294 */     return getHints(actualType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes() {
/* 299 */     return getMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes(ResolvableType targetType) {
/* 304 */     return getMimeTypes(targetType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <A extends java.lang.annotation.Annotation> A getAnnotation(MethodParameter parameter, Class<A> annotType) {
/* 312 */     return (A)parameter.getParameterAnnotation(annotType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\AbstractJackson2Decoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */