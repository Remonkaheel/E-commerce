/*    */ package org.springframework.http.codec.json;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import kotlinx.serialization.StringFormat;
/*    */ import kotlinx.serialization.json.Json;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.KotlinSerializationStringEncoder;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationJsonEncoder
/*    */   extends KotlinSerializationStringEncoder<Json>
/*    */ {
/*    */   public KotlinSerializationJsonEncoder() {
/* 52 */     this((Json)Json.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationJsonEncoder(Json json) {
/* 56 */     super((StringFormat)json, new MimeType[] { (MimeType)MediaType.APPLICATION_JSON, (MimeType)new MediaType("application", "*+json"), (MimeType)MediaType.APPLICATION_NDJSON });
/*    */     
/* 58 */     setStreamingMediaTypes(List.of(MediaType.APPLICATION_NDJSON));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<DataBuffer> encodeNonStream(Publisher<?> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 65 */     JsonArrayJoinHelper helper = new JsonArrayJoinHelper();
/* 66 */     return Flux.from(inputStream)
/* 67 */       .map(value -> encodeStreamingValue(value, bufferFactory, elementType, mimeType, hints, helper.getPrefix(), EMPTY_BYTES))
/*    */       
/* 69 */       .switchIfEmpty((Publisher)Mono.fromCallable(() -> bufferFactory.wrap(helper.getPrefix())))
/* 70 */       .concatWith((Publisher)Mono.fromCallable(() -> bufferFactory.wrap(helper.getSuffix())));
/*    */   }
/*    */ 
/*    */   
/*    */   private static class JsonArrayJoinHelper
/*    */   {
/* 76 */     private static final byte[] COMMA_SEPARATOR = new byte[] { 44 };
/*    */     
/* 78 */     private static final byte[] OPEN_BRACKET = new byte[] { 91 };
/*    */     
/* 80 */     private static final byte[] CLOSE_BRACKET = new byte[] { 93 };
/*    */     
/*    */     private boolean firstItemEmitted;
/*    */     
/*    */     public byte[] getPrefix() {
/* 85 */       byte[] prefix = this.firstItemEmitted ? COMMA_SEPARATOR : OPEN_BRACKET;
/* 86 */       this.firstItemEmitted = true;
/* 87 */       return prefix;
/*    */     }
/*    */     
/*    */     public byte[] getSuffix() {
/* 91 */       return CLOSE_BRACKET;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\KotlinSerializationJsonEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */