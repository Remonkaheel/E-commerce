/*     */ package org.springframework.http.codec.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.async.ByteArrayFeeder;
/*     */ import com.fasterxml.jackson.core.async.ByteBufferFeeder;
/*     */ import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Jackson2Tokenizer
/*     */ {
/*     */   private final JsonParser parser;
/*     */   private final DeserializationContext deserializationContext;
/*     */   private final NonBlockingInputFeeder inputFeeder;
/*     */   private final boolean tokenizeArrayElements;
/*     */   private final boolean forceUseOfBigDecimal;
/*     */   private final int maxInMemorySize;
/*     */   private int objectDepth;
/*     */   private int arrayDepth;
/*     */   private int byteCount;
/*     */   private TokenBuffer tokenBuffer;
/*     */   
/*     */   private Jackson2Tokenizer(JsonParser parser, DeserializationContext deserializationContext, boolean tokenizeArrayElements, boolean forceUseOfBigDecimal, int maxInMemorySize) {
/*  80 */     this.parser = parser;
/*  81 */     this.deserializationContext = deserializationContext;
/*  82 */     this.inputFeeder = this.parser.getNonBlockingInputFeeder();
/*  83 */     this.tokenizeArrayElements = tokenizeArrayElements;
/*  84 */     this.forceUseOfBigDecimal = forceUseOfBigDecimal;
/*  85 */     this.maxInMemorySize = maxInMemorySize;
/*  86 */     this.tokenBuffer = createToken();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<TokenBuffer> tokenize(DataBuffer dataBuffer) {
/*     */     try {
/*  93 */       int bufferSize = dataBuffer.readableByteCount();
/*  94 */       List<TokenBuffer> tokens = new ArrayList<>();
/*  95 */       NonBlockingInputFeeder nonBlockingInputFeeder = this.inputFeeder; if (nonBlockingInputFeeder instanceof ByteBufferFeeder) { ByteBufferFeeder byteBufferFeeder = (ByteBufferFeeder)nonBlockingInputFeeder;
/*  96 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/*  97 */         try { while (iterator.hasNext()) {
/*  98 */             byteBufferFeeder.feedInput((ByteBuffer)iterator.next());
/*  99 */             parseTokens(tokens);
/*     */           } 
/* 101 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/*     */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 103 */       else { nonBlockingInputFeeder = this.inputFeeder; if (nonBlockingInputFeeder instanceof ByteArrayFeeder) { ByteArrayFeeder byteArrayFeeder = (ByteArrayFeeder)nonBlockingInputFeeder;
/* 104 */           byte[] bytes = new byte[bufferSize];
/* 105 */           dataBuffer.read(bytes);
/* 106 */           byteArrayFeeder.feedInput(bytes, 0, bufferSize);
/* 107 */           parseTokens(tokens); }
/*     */          }
/* 109 */        assertInMemorySize(bufferSize, tokens);
/* 110 */       return tokens;
/*     */     }
/* 112 */     catch (JsonProcessingException ex) {
/* 113 */       throw new DecodingException("JSON decoding error: " + ex.getOriginalMessage(), ex);
/*     */     }
/* 115 */     catch (IOException ex) {
/* 116 */       throw Exceptions.propagate(ex);
/*     */     } finally {
/*     */       
/* 119 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Flux<TokenBuffer> endOfInput() {
/* 124 */     return Flux.defer(() -> {
/*     */           this.inputFeeder.endOfInput();
/*     */           
/*     */           try {
/*     */             List<TokenBuffer> tokens = new ArrayList<>();
/*     */             parseTokens(tokens);
/*     */             return (Publisher)Flux.fromIterable(tokens);
/* 131 */           } catch (JsonProcessingException ex) {
/*     */             
/*     */             throw new DecodingException("JSON decoding error: " + ex.getOriginalMessage(), ex);
/* 134 */           } catch (IOException ex) {
/*     */             throw Exceptions.propagate(ex);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseTokens(List<TokenBuffer> tokens) throws IOException {
/* 142 */     boolean previousNull = false;
/* 143 */     while (!this.parser.isClosed()) {
/* 144 */       JsonToken token = this.parser.nextToken();
/* 145 */       if (token == JsonToken.NOT_AVAILABLE || (token == null && previousNull)) {
/*     */         break;
/*     */       }
/*     */       
/* 149 */       if (token == null) {
/* 150 */         previousNull = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 154 */       previousNull = false;
/*     */       
/* 156 */       updateDepth(token);
/* 157 */       if (!this.tokenizeArrayElements) {
/* 158 */         processTokenNormal(token, tokens);
/*     */         continue;
/*     */       } 
/* 161 */       processTokenArray(token, tokens);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateDepth(JsonToken token) {
/* 167 */     switch (token) { case START_OBJECT:
/* 168 */         this.objectDepth++; break;
/* 169 */       case END_OBJECT: this.objectDepth--; break;
/* 170 */       case START_ARRAY: this.arrayDepth++; break;
/* 171 */       case END_ARRAY: this.arrayDepth--;
/*     */         break; }
/*     */   
/*     */   }
/*     */   private void processTokenNormal(JsonToken token, List<TokenBuffer> result) throws IOException {
/* 176 */     this.tokenBuffer.copyCurrentEvent(this.parser);
/*     */     
/* 178 */     if ((token.isStructEnd() || token.isScalarValue()) && this.objectDepth == 0 && this.arrayDepth == 0) {
/* 179 */       result.add(this.tokenBuffer);
/* 180 */       this.tokenBuffer = createToken();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processTokenArray(JsonToken token, List<TokenBuffer> result) throws IOException {
/* 185 */     if (!isTopLevelArrayToken(token)) {
/* 186 */       this.tokenBuffer.copyCurrentEvent(this.parser);
/*     */     }
/*     */     
/* 189 */     if (this.objectDepth == 0 && (this.arrayDepth == 0 || this.arrayDepth == 1) && (token == JsonToken.END_OBJECT || token
/* 190 */       .isScalarValue())) {
/* 191 */       result.add(this.tokenBuffer);
/* 192 */       this.tokenBuffer = createToken();
/*     */     } 
/*     */   }
/*     */   
/*     */   private TokenBuffer createToken() {
/* 197 */     TokenBuffer tokenBuffer = new TokenBuffer(this.parser, this.deserializationContext);
/* 198 */     tokenBuffer.forceUseOfBigDecimal(this.forceUseOfBigDecimal);
/* 199 */     return tokenBuffer;
/*     */   }
/*     */   
/*     */   private boolean isTopLevelArrayToken(JsonToken token) {
/* 203 */     return (this.objectDepth == 0 && ((token == JsonToken.START_ARRAY && this.arrayDepth == 1) || (token == JsonToken.END_ARRAY && this.arrayDepth == 0)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void assertInMemorySize(int currentBufferSize, List<TokenBuffer> result) {
/* 208 */     if (this.maxInMemorySize >= 0) {
/* 209 */       if (!result.isEmpty()) {
/* 210 */         this.byteCount = 0;
/*     */       }
/* 212 */       else if (currentBufferSize > Integer.MAX_VALUE - this.byteCount) {
/* 213 */         raiseLimitException();
/*     */       } else {
/*     */         
/* 216 */         this.byteCount += currentBufferSize;
/* 217 */         if (this.byteCount > this.maxInMemorySize) {
/* 218 */           raiseLimitException();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void raiseLimitException() {
/* 225 */     throw new DataBufferLimitException("Exceeded limit on max bytes per JSON object: " + this.maxInMemorySize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Flux<TokenBuffer> tokenize(Flux<DataBuffer> dataBuffers, JsonFactory jsonFactory, ObjectMapper objectMapper, boolean tokenizeArrays, boolean forceUseOfBigDecimal, int maxInMemorySize) {
/*     */     try {
/*     */       JsonParser parser;
/*     */       DefaultDeserializationContext defaultDeserializationContext;
/* 247 */       if (jsonFactory.getFormatName().equals("Smile")) {
/*     */         
/* 249 */         parser = jsonFactory.createNonBlockingByteArrayParser();
/*     */       } else {
/*     */         
/* 252 */         parser = jsonFactory.createNonBlockingByteBufferParser();
/*     */       } 
/* 254 */       DeserializationContext context = objectMapper.getDeserializationContext();
/* 255 */       if (context instanceof DefaultDeserializationContext) { DefaultDeserializationContext ddc = (DefaultDeserializationContext)context;
/* 256 */         defaultDeserializationContext = ddc.createInstance(objectMapper.getDeserializationConfig(), parser, objectMapper
/* 257 */             .getInjectableValues()); }
/*     */       
/* 259 */       Jackson2Tokenizer tokenizer = new Jackson2Tokenizer(parser, (DeserializationContext)defaultDeserializationContext, tokenizeArrays, forceUseOfBigDecimal, maxInMemorySize);
/*     */       
/* 261 */       Objects.requireNonNull(tokenizer); return dataBuffers.concatMapIterable(tokenizer::tokenize).concatWith((Publisher)tokenizer.endOfInput());
/*     */     }
/* 263 */     catch (IOException ex) {
/* 264 */       return Flux.error(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\Jackson2Tokenizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */