/*    */ package org.springframework.http.codec.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JsonArrayJoinHelper
/*    */ {
/* 76 */   private static final byte[] COMMA_SEPARATOR = new byte[] { 44 };
/*    */   
/* 78 */   private static final byte[] OPEN_BRACKET = new byte[] { 91 };
/*    */   
/* 80 */   private static final byte[] CLOSE_BRACKET = new byte[] { 93 };
/*    */   
/*    */   private boolean firstItemEmitted;
/*    */   
/*    */   public byte[] getPrefix() {
/* 85 */     byte[] prefix = this.firstItemEmitted ? COMMA_SEPARATOR : OPEN_BRACKET;
/* 86 */     this.firstItemEmitted = true;
/* 87 */     return prefix;
/*    */   }
/*    */   
/*    */   public byte[] getSuffix() {
/* 91 */     return CLOSE_BRACKET;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\KotlinSerializationJsonEncoder$JsonArrayJoinHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */