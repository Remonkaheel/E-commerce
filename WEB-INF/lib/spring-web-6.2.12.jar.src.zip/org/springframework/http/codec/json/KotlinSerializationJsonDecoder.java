/*    */ package org.springframework.http.codec.json;
/*    */ 
/*    */ import kotlinx.serialization.StringFormat;
/*    */ import kotlinx.serialization.json.Json;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.KotlinSerializationStringDecoder;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationJsonDecoder
/*    */   extends KotlinSerializationStringDecoder<Json>
/*    */ {
/*    */   public KotlinSerializationJsonDecoder() {
/* 45 */     this((Json)Json.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationJsonDecoder(Json json) {
/* 49 */     super((StringFormat)json, new MimeType[] { (MimeType)MediaType.APPLICATION_JSON, (MimeType)new MediaType("application", "*+json"), (MimeType)MediaType.APPLICATION_NDJSON });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\KotlinSerializationJsonDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */