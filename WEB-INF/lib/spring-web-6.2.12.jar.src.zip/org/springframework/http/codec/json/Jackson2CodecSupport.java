/*     */ package org.springframework.http.codec.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonView;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Jackson2CodecSupport
/*     */ {
/*  64 */   public static final String JSON_VIEW_HINT = Jackson2CodecSupport.class.getName() + ".jsonView";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   static final String ACTUAL_TYPE_HINT = Jackson2CodecSupport.class.getName() + ".actualType";
/*     */ 
/*     */   
/*     */   private static final String JSON_VIEW_HINT_ERROR = "@JsonView only supported for write hints with exactly 1 class argument: ";
/*     */   
/*  78 */   private static final List<MimeType> defaultMimeTypes = (List)List.of(MediaType.APPLICATION_JSON, new MediaType("application", "*+json"), MediaType.APPLICATION_NDJSON);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   protected final Log logger = HttpLogging.forLogName(getClass());
/*     */ 
/*     */   
/*     */   private ObjectMapper defaultObjectMapper;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<Class<?>, Map<MimeType, ObjectMapper>> objectMapperRegistrations;
/*     */ 
/*     */   
/*     */   private final List<MimeType> mimeTypes;
/*     */ 
/*     */   
/*     */   protected Jackson2CodecSupport(ObjectMapper objectMapper, MimeType... mimeTypes) {
/*  98 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  99 */     this.defaultObjectMapper = objectMapper;
/* 100 */     this.mimeTypes = !ObjectUtils.isEmpty((Object[])mimeTypes) ? List.<MimeType>of(mimeTypes) : defaultMimeTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectMapper(ObjectMapper objectMapper) {
/* 110 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/* 111 */     this.defaultObjectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMapper getObjectMapper() {
/* 118 */     return this.defaultObjectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerObjectMappersForType(Class<?> clazz, Consumer<Map<MimeType, ObjectMapper>> registrar) {
/* 138 */     if (this.objectMapperRegistrations == null) {
/* 139 */       this.objectMapperRegistrations = new LinkedHashMap<>();
/*     */     }
/*     */     
/* 142 */     Map<MimeType, ObjectMapper> registrations = this.objectMapperRegistrations.computeIfAbsent(clazz, c -> new LinkedHashMap<>());
/* 143 */     registrar.accept(registrations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Map<MimeType, ObjectMapper> getObjectMappersForType(Class<?> clazz) {
/* 155 */     for (Map.Entry<Class<?>, Map<MimeType, ObjectMapper>> entry : getObjectMapperRegistrations().entrySet()) {
/* 156 */       if (((Class)entry.getKey()).isAssignableFrom(clazz)) {
/* 157 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 160 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */   protected Map<Class<?>, Map<MimeType, ObjectMapper>> getObjectMapperRegistrations() {
/* 164 */     return (this.objectMapperRegistrations != null) ? this.objectMapperRegistrations : Collections.<Class<?>, Map<MimeType, ObjectMapper>>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MimeType> getMimeTypes() {
/* 171 */     return this.mimeTypes;
/*     */   }
/*     */   
/*     */   protected List<MimeType> getMimeTypes(ResolvableType elementType) {
/* 175 */     Class<?> elementClass = elementType.toClass();
/* 176 */     List<MimeType> result = null;
/* 177 */     for (Map.Entry<Class<?>, Map<MimeType, ObjectMapper>> entry : getObjectMapperRegistrations().entrySet()) {
/* 178 */       if (((Class)entry.getKey()).isAssignableFrom(elementClass)) {
/* 179 */         result = (result != null) ? result : new ArrayList<>(((Map)entry.getValue()).size());
/* 180 */         result.addAll(((Map)entry.getValue()).keySet());
/*     */       } 
/*     */     } 
/* 183 */     if (!CollectionUtils.isEmpty(result)) {
/* 184 */       return result;
/*     */     }
/* 186 */     return ProblemDetail.class.isAssignableFrom(elementClass) ? getMediaTypesForProblemDetail() : getMimeTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MimeType> getMediaTypesForProblemDetail() {
/* 195 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   protected boolean supportsMimeType(@Nullable MimeType mimeType) {
/* 199 */     if (mimeType == null) {
/* 200 */       return true;
/*     */     }
/* 202 */     for (MimeType supportedMimeType : this.mimeTypes) {
/* 203 */       if (supportedMimeType.isCompatibleWith(mimeType)) {
/* 204 */         return true;
/*     */       }
/*     */     } 
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logWarningIfNecessary(Type type, @Nullable Throwable cause) {
/* 219 */     if (cause == null) {
/*     */       return;
/*     */     }
/* 222 */     if (this.logger.isDebugEnabled()) {
/* 223 */       String msg = "Failed to evaluate Jackson " + ((type instanceof JavaType) ? "de" : "") + "serialization for type [" + String.valueOf(type) + "]";
/*     */       
/* 225 */       this.logger.debug(msg, cause);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected JavaType getJavaType(Type type, @Nullable Class<?> contextClass) {
/* 230 */     return this.defaultObjectMapper.constructType(GenericTypeResolver.resolveType(type, contextClass));
/*     */   }
/*     */   
/*     */   protected Map<String, Object> getHints(ResolvableType resolvableType) {
/* 234 */     MethodParameter param = getParameter(resolvableType);
/* 235 */     if (param != null) {
/* 236 */       Map<String, Object> hints = null;
/* 237 */       if (resolvableType.hasGenerics()) {
/* 238 */         hints = new HashMap<>(2);
/* 239 */         hints.put(ACTUAL_TYPE_HINT, resolvableType);
/*     */       } 
/* 241 */       JsonView annotation = getAnnotation(param, JsonView.class);
/* 242 */       if (annotation != null) {
/* 243 */         Class<?>[] classes = annotation.value();
/* 244 */         Assert.isTrue((classes.length == 1), () -> "@JsonView only supported for write hints with exactly 1 class argument: " + String.valueOf(param));
/* 245 */         hints = (hints != null) ? hints : new HashMap<>(1);
/* 246 */         hints.put(JSON_VIEW_HINT, classes[0]);
/*     */       } 
/* 248 */       if (hints != null) {
/* 249 */         return hints;
/*     */       }
/*     */     } 
/* 252 */     return Hints.none();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected MethodParameter getParameter(ResolvableType type) {
/* 257 */     Object object = type.getSource(); MethodParameter methodParameter = (MethodParameter)object; return (object instanceof MethodParameter) ? methodParameter : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ObjectMapper selectObjectMapper(ResolvableType targetType, @Nullable MimeType targetMimeType) {
/* 271 */     if (targetMimeType == null || CollectionUtils.isEmpty(this.objectMapperRegistrations)) {
/* 272 */       return this.defaultObjectMapper;
/*     */     }
/* 274 */     Class<?> targetClass = targetType.toClass();
/* 275 */     for (Map.Entry<Class<?>, Map<MimeType, ObjectMapper>> typeEntry : getObjectMapperRegistrations().entrySet()) {
/* 276 */       if (((Class)typeEntry.getKey()).isAssignableFrom(targetClass)) {
/* 277 */         for (Map.Entry<MimeType, ObjectMapper> objectMapperEntry : (Iterable<Map.Entry<MimeType, ObjectMapper>>)((Map)typeEntry.getValue()).entrySet()) {
/* 278 */           if (((MimeType)objectMapperEntry.getKey()).includes(targetMimeType)) {
/* 279 */             return objectMapperEntry.getValue();
/*     */           }
/*     */         } 
/*     */         
/* 283 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 287 */     return this.defaultObjectMapper;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract <A extends java.lang.annotation.Annotation> A getAnnotation(MethodParameter paramMethodParameter, Class<A> paramClass);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\Jackson2CodecSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */