/*     */ package org.springframework.http.codec.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SequenceWriter;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.EncodingException;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.HttpMessageEncoder;
/*     */ import org.springframework.http.converter.json.MappingJacksonValue;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2Encoder
/*     */   extends Jackson2CodecSupport
/*     */   implements HttpMessageEncoder<Object>
/*     */ {
/*  72 */   private static final byte[] NEWLINE_SEPARATOR = new byte[] { 10 };
/*     */   
/*  74 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static final Map<String, JsonEncoding> ENCODINGS = CollectionUtils.newHashMap((JsonEncoding.values()).length); static {
/*  80 */     for (JsonEncoding encoding : JsonEncoding.values()) {
/*  81 */       ENCODINGS.put(encoding.getJavaName(), encoding);
/*     */     }
/*  83 */     ENCODINGS.put("US-ASCII", JsonEncoding.UTF8);
/*     */   }
/*     */ 
/*     */   
/*  87 */   private final List<MediaType> streamingMediaTypes = new ArrayList<>(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJackson2Encoder(ObjectMapper mapper, MimeType... mimeTypes) {
/*  94 */     super(mapper, mimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStreamingMediaTypes(List<MediaType> mediaTypes) {
/* 103 */     this.streamingMediaTypes.clear();
/* 104 */     this.streamingMediaTypes.addAll(mediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 111 */     if (!supportsMimeType(mimeType)) {
/* 112 */       return false;
/*     */     }
/* 114 */     if (mimeType != null && mimeType.getCharset() != null) {
/* 115 */       Charset charset = mimeType.getCharset();
/* 116 */       if (!ENCODINGS.containsKey(charset.name())) {
/* 117 */         return false;
/*     */       }
/*     */     } 
/* 120 */     ObjectMapper mapper = selectObjectMapper(elementType, mimeType);
/* 121 */     if (mapper == null) {
/* 122 */       return false;
/*     */     }
/* 124 */     Class<?> clazz = elementType.toClass();
/* 125 */     if (String.class.isAssignableFrom(elementType.resolve(clazz))) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (Object.class == clazz) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (!this.logger.isDebugEnabled()) {
/* 132 */       return mapper.canSerialize(clazz);
/*     */     }
/*     */     
/* 135 */     AtomicReference<Throwable> causeRef = new AtomicReference<>();
/* 136 */     if (mapper.canSerialize(clazz, causeRef)) {
/* 137 */       return true;
/*     */     }
/* 139 */     logWarningIfNecessary(clazz, causeRef.get());
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> encode(Publisher<?> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 148 */     Assert.notNull(inputStream, "'inputStream' must not be null");
/* 149 */     Assert.notNull(bufferFactory, "'bufferFactory' must not be null");
/* 150 */     Assert.notNull(elementType, "'elementType' must not be null");
/*     */     
/* 152 */     return Flux.deferContextual(contextView -> {
/*     */           Map<String, Object> hintsToUse = contextView.isEmpty() ? hints : Hints.merge(hints, ContextView.class.getName(), contextView);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (inputStream instanceof Mono) {
/*     */             return (Publisher)Mono.from(inputStream).map(()).flux();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             Flux<DataBuffer> dataBufferFlux;
/*     */ 
/*     */ 
/*     */             
/*     */             ObjectMapper mapper = selectObjectMapper(elementType, mimeType);
/*     */ 
/*     */ 
/*     */             
/*     */             if (mapper == null) {
/*     */               throw new IllegalStateException("No ObjectMapper for " + String.valueOf(elementType));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             ObjectWriter writer = createObjectWriter(mapper, elementType, mimeType, (Class<?>)null, hintsToUse);
/*     */ 
/*     */ 
/*     */             
/*     */             ByteArrayBuilder byteBuilder = new ByteArrayBuilder(writer.getFactory()._getBufferRecycler());
/*     */ 
/*     */ 
/*     */             
/*     */             JsonEncoding encoding = getJsonEncoding(mimeType);
/*     */ 
/*     */ 
/*     */             
/*     */             JsonGenerator generator = mapper.getFactory().createGenerator((OutputStream)byteBuilder, encoding);
/*     */ 
/*     */ 
/*     */             
/*     */             SequenceWriter sequenceWriter = writer.writeValues(generator);
/*     */ 
/*     */ 
/*     */             
/*     */             byte[] separator = getStreamingMediaTypeSeparator(mimeType);
/*     */ 
/*     */ 
/*     */             
/*     */             if (separator != null) {
/*     */               dataBufferFlux = Flux.from(inputStream).map(());
/*     */             } else {
/*     */               JsonArrayJoinHelper helper = new JsonArrayJoinHelper();
/*     */ 
/*     */ 
/*     */               
/*     */               dataBufferFlux = Flux.from(inputStream).map(()).switchIfEmpty((Publisher)Mono.fromCallable(())).concatWith((Publisher)Mono.fromCallable(()));
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             return (Publisher)dataBufferFlux.doOnNext(()).doAfterTerminate(());
/* 217 */           } catch (IOException ex) {
/*     */             return (Publisher)Flux.error(ex);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 227 */     Class<?> jsonView = null;
/* 228 */     FilterProvider filters = null;
/* 229 */     if (value instanceof MappingJacksonValue) { MappingJacksonValue mappingJacksonValue = (MappingJacksonValue)value;
/* 230 */       value = mappingJacksonValue.getValue();
/* 231 */       valueType = ResolvableType.forInstance(value);
/* 232 */       jsonView = mappingJacksonValue.getSerializationView();
/* 233 */       filters = mappingJacksonValue.getFilters(); }
/*     */ 
/*     */     
/* 236 */     ObjectMapper mapper = selectObjectMapper(valueType, mimeType);
/* 237 */     if (mapper == null) {
/* 238 */       throw new IllegalStateException("No ObjectMapper for " + String.valueOf(valueType));
/*     */     }
/*     */     
/* 241 */     ObjectWriter writer = createObjectWriter(mapper, valueType, mimeType, jsonView, hints);
/* 242 */     if (filters != null) {
/* 243 */       writer = writer.with(filters);
/*     */     }
/*     */     
/* 246 */     ByteArrayBuilder byteBuilder = new ByteArrayBuilder(writer.getFactory()._getBufferRecycler());
/*     */     try {
/* 248 */       JsonEncoding encoding = getJsonEncoding(mimeType);
/*     */       
/* 250 */       logValue(hints, value);
/*     */       
/* 252 */       try { JsonGenerator generator = mapper.getFactory().createGenerator((OutputStream)byteBuilder, encoding); 
/* 253 */         try { writer.writeValue(generator, value);
/* 254 */           generator.flush();
/* 255 */           if (generator != null) generator.close();  } catch (Throwable throwable) { if (generator != null)
/* 256 */             try { generator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (InvalidDefinitionException ex)
/* 257 */       { throw new CodecException("Type definition error: " + String.valueOf(ex.getType()), ex); }
/*     */       
/* 259 */       catch (JsonProcessingException ex)
/* 260 */       { throw new EncodingException("JSON encoding error: " + ex.getOriginalMessage(), ex); }
/*     */       
/* 262 */       catch (IOException ex)
/* 263 */       { throw new IllegalStateException("Unexpected I/O error while writing to byte array builder", ex); }
/*     */ 
/*     */       
/* 266 */       byte[] bytes = byteBuilder.toByteArray();
/* 267 */       DataBuffer buffer = bufferFactory.allocateBuffer(bytes.length);
/* 268 */       buffer.write(bytes);
/* 269 */       Hints.touchDataBuffer(buffer, hints, this.logger);
/*     */       
/* 271 */       return buffer;
/*     */     } finally {
/*     */       
/* 274 */       byteBuilder.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataBuffer encodeStreamingValue(Object value, DataBufferFactory bufferFactory, @Nullable Map<String, Object> hints, SequenceWriter sequenceWriter, ByteArrayBuilder byteArrayBuilder, byte[] prefix, byte[] suffix) {
/*     */     int offset, length;
/* 283 */     logValue(hints, value);
/*     */     
/*     */     try {
/* 286 */       sequenceWriter.write(value);
/* 287 */       sequenceWriter.flush();
/*     */     }
/* 289 */     catch (InvalidDefinitionException ex) {
/* 290 */       throw new CodecException("Type definition error: " + String.valueOf(ex.getType()), ex);
/*     */     }
/* 292 */     catch (JsonProcessingException ex) {
/* 293 */       throw new EncodingException("JSON encoding error: " + ex.getOriginalMessage(), ex);
/*     */     }
/* 295 */     catch (IOException ex) {
/* 296 */       throw new IllegalStateException("Unexpected I/O error while writing to byte array builder", ex);
/*     */     } 
/*     */     
/* 299 */     byte[] bytes = byteArrayBuilder.toByteArray();
/* 300 */     byteArrayBuilder.reset();
/*     */ 
/*     */ 
/*     */     
/* 304 */     if (bytes.length > 0 && bytes[0] == 32) {
/*     */       
/* 306 */       offset = 1;
/* 307 */       length = bytes.length - 1;
/*     */     } else {
/*     */       
/* 310 */       offset = 0;
/* 311 */       length = bytes.length;
/*     */     } 
/* 313 */     DataBuffer buffer = bufferFactory.allocateBuffer(length + prefix.length + suffix.length);
/* 314 */     if (prefix.length != 0) {
/* 315 */       buffer.write(prefix);
/*     */     }
/* 317 */     buffer.write(bytes, offset, length);
/* 318 */     if (suffix.length != 0) {
/* 319 */       buffer.write(suffix);
/*     */     }
/* 321 */     Hints.touchDataBuffer(buffer, hints, this.logger);
/*     */     
/* 323 */     return buffer;
/*     */   }
/*     */   
/*     */   private void logValue(@Nullable Map<String, Object> hints, Object value) {
/* 327 */     if (!Hints.isLoggingSuppressed(hints)) {
/* 328 */       LogFormatUtils.traceDebug(this.logger, traceOn -> {
/*     */             String formatted = LogFormatUtils.formatValue(value, !traceOn.booleanValue());
/*     */             return Hints.getLogPrefix(hints) + "Encoding [" + Hints.getLogPrefix(hints) + "]";
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectWriter createObjectWriter(ObjectMapper mapper, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Class<?> jsonView, @Nullable Map<String, Object> hints) {
/* 339 */     JavaType javaType = getJavaType(valueType.getType(), null);
/* 340 */     if (jsonView == null && hints != null) {
/* 341 */       jsonView = (Class)hints.get(Jackson2CodecSupport.JSON_VIEW_HINT);
/*     */     }
/* 343 */     ObjectWriter writer = (jsonView != null) ? mapper.writerWithView(jsonView) : mapper.writer();
/* 344 */     if (javaType.isContainerType()) {
/* 345 */       writer = writer.forType(javaType);
/*     */     }
/* 347 */     return customizeWriter(writer, mimeType, valueType, hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectWriter customizeWriter(ObjectWriter writer, @Nullable MimeType mimeType, ResolvableType elementType, @Nullable Map<String, Object> hints) {
/* 364 */     return writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected byte[] getStreamingMediaTypeSeparator(@Nullable MimeType mimeType) {
/* 376 */     for (MediaType streamingMediaType : this.streamingMediaTypes) {
/* 377 */       if (streamingMediaType.isCompatibleWith(mimeType)) {
/* 378 */         return NEWLINE_SEPARATOR;
/*     */       }
/*     */     } 
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonEncoding getJsonEncoding(@Nullable MimeType mimeType) {
/* 391 */     if (mimeType != null && mimeType.getCharset() != null) {
/* 392 */       Charset charset = mimeType.getCharset();
/* 393 */       JsonEncoding result = ENCODINGS.get(charset.name());
/* 394 */       if (result != null) {
/* 395 */         return result;
/*     */       }
/*     */     } 
/* 398 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes() {
/* 406 */     return getMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes(ResolvableType elementType) {
/* 411 */     return getMimeTypes(elementType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getStreamingMediaTypes() {
/* 416 */     return Collections.unmodifiableList(this.streamingMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getEncodeHints(@Nullable ResolvableType actualType, ResolvableType elementType, @Nullable MediaType mediaType, ServerHttpRequest request, ServerHttpResponse response) {
/* 423 */     return (actualType != null) ? getHints(actualType) : Hints.none();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <A extends java.lang.annotation.Annotation> A getAnnotation(MethodParameter parameter, Class<A> annotType) {
/* 432 */     return (A)parameter.getMethodAnnotation(annotType);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JsonArrayJoinHelper
/*     */   {
/* 438 */     private static final byte[] COMMA_SEPARATOR = new byte[] { 44 };
/*     */     
/* 440 */     private static final byte[] OPEN_BRACKET = new byte[] { 91 };
/*     */     
/* 442 */     private static final byte[] CLOSE_BRACKET = new byte[] { 93 };
/*     */     
/*     */     private boolean firstItemEmitted;
/*     */     
/*     */     public byte[] getDelimiter() {
/* 447 */       if (this.firstItemEmitted) {
/* 448 */         return COMMA_SEPARATOR;
/*     */       }
/* 450 */       this.firstItemEmitted = true;
/* 451 */       return AbstractJackson2Encoder.EMPTY_BYTES;
/*     */     }
/*     */     
/*     */     public byte[] getPrefix() {
/* 455 */       return this.firstItemEmitted ? AbstractJackson2Encoder.EMPTY_BYTES : OPEN_BRACKET;
/*     */     }
/*     */     
/*     */     public byte[] getSuffix() {
/* 459 */       return CLOSE_BRACKET;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\AbstractJackson2Encoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */