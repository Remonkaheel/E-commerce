/*    */ package org.springframework.http.codec.json;
/*    */ 
/*    */ import com.fasterxml.jackson.core.PrettyPrinter;
/*    */ import com.fasterxml.jackson.core.util.DefaultIndenter;
/*    */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.ObjectWriter;
/*    */ import com.fasterxml.jackson.databind.SerializationFeature;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jackson2JsonEncoder
/*    */   extends AbstractJackson2Encoder
/*    */ {
/* 51 */   private static final List<MimeType> problemDetailMimeTypes = (List)Collections.singletonList(MediaType.APPLICATION_PROBLEM_JSON);
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private final PrettyPrinter ssePrettyPrinter;
/*    */ 
/*    */   
/*    */   public Jackson2JsonEncoder() {
/* 59 */     this(Jackson2ObjectMapperBuilder.json().build(), new MimeType[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public Jackson2JsonEncoder(ObjectMapper mapper, MimeType... mimeTypes) {
/* 64 */     super(mapper, mimeTypes);
/* 65 */     setStreamingMediaTypes(Arrays.asList(new MediaType[] { MediaType.APPLICATION_NDJSON, MediaType.APPLICATION_STREAM_JSON }));
/* 66 */     this.ssePrettyPrinter = initSsePrettyPrinter();
/*    */   }
/*    */   
/*    */   private static PrettyPrinter initSsePrettyPrinter() {
/* 70 */     DefaultPrettyPrinter printer = new DefaultPrettyPrinter();
/* 71 */     printer.indentObjectsWith((DefaultPrettyPrinter.Indenter)new DefaultIndenter("  ", "\ndata:"));
/* 72 */     return (PrettyPrinter)printer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<MimeType> getMediaTypesForProblemDetail() {
/* 78 */     return problemDetailMimeTypes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ObjectWriter customizeWriter(ObjectWriter writer, @Nullable MimeType mimeType, ResolvableType elementType, @Nullable Map<String, Object> hints) {
/* 85 */     return 
/* 86 */       (this.ssePrettyPrinter != null && MediaType.TEXT_EVENT_STREAM.isCompatibleWith(mimeType) && writer
/* 87 */       .getConfig().isEnabled(SerializationFeature.INDENT_OUTPUT)) ? 
/* 88 */       writer.with(this.ssePrettyPrinter) : writer;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\json\Jackson2JsonEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */