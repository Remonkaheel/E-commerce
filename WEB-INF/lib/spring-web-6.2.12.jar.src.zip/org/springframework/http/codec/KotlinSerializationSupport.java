/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KType;
/*     */ import kotlin.reflect.full.KCallables;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import kotlinx.serialization.KSerializer;
/*     */ import kotlinx.serialization.SerialFormat;
/*     */ import kotlinx.serialization.SerializersKt;
/*     */ import kotlinx.serialization.descriptors.PolymorphicKind;
/*     */ import kotlinx.serialization.descriptors.SerialDescriptor;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.MimeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KotlinSerializationSupport<T extends SerialFormat>
/*     */ {
/*  57 */   private final Map<Type, KSerializer<Object>> typeSerializerCache = (Map<Type, KSerializer<Object>>)new ConcurrentReferenceHashMap();
/*     */   
/*  59 */   private final Map<KType, KSerializer<Object>> kTypeSerializerCache = (Map<KType, KSerializer<Object>>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private final T format;
/*     */ 
/*     */   
/*     */   private final List<MimeType> supportedMimeTypes;
/*     */ 
/*     */ 
/*     */   
/*     */   protected KotlinSerializationSupport(T format, MimeType... supportedMimeTypes) {
/*  71 */     this.format = format;
/*  72 */     this.supportedMimeTypes = Arrays.asList(supportedMimeTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final T format() {
/*  79 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final List<MimeType> supportedMimeTypes() {
/*  86 */     return this.supportedMimeTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean canSerialize(ResolvableType type, @Nullable MimeType mimeType) {
/*  97 */     KSerializer<Object> serializer = serializer(type);
/*  98 */     if (serializer == null) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     return (supports(mimeType) && !String.class.isAssignableFrom(type.toClass()) && 
/* 103 */       !ServerSentEvent.class.isAssignableFrom(type.toClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean supports(@Nullable MimeType mimeType) {
/* 109 */     if (mimeType == null) {
/* 110 */       return true;
/*     */     }
/* 112 */     for (MimeType candidate : this.supportedMimeTypes) {
/* 113 */       if (candidate.isCompatibleWith(mimeType)) {
/* 114 */         return true;
/*     */       }
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final KSerializer<Object> serializer(ResolvableType resolvableType) {
/* 131 */     Object object = resolvableType.getSource(); if (object instanceof MethodParameter) { MethodParameter parameter = (MethodParameter)object;
/* 132 */       Method method = parameter.getMethod();
/* 133 */       Assert.notNull(method, "Method must not be null");
/* 134 */       if (KotlinDetector.isKotlinType(method.getDeclaringClass())) {
/* 135 */         KFunction<?> function = ReflectJvmMapping.getKotlinFunction(method);
/* 136 */         if (function != null) {
/*     */           
/* 138 */           KType kType = (parameter.getParameterIndex() == -1) ? function.getReturnType() : ((KParameter)KCallables.getValueParameters((KCallable)function).get(parameter.getParameterIndex())).getType();
/* 139 */           KSerializer<Object> kSerializer = this.kTypeSerializerCache.get(kType);
/* 140 */           if (kSerializer == null) {
/*     */             try {
/* 142 */               kSerializer = SerializersKt.serializerOrNull(this.format.getSerializersModule(), kType);
/*     */             }
/* 144 */             catch (IllegalArgumentException illegalArgumentException) {}
/*     */             
/* 146 */             if (kSerializer != null) {
/* 147 */               if (hasPolymorphism(kSerializer.getDescriptor(), new HashSet<>())) {
/* 148 */                 return null;
/*     */               }
/* 150 */               this.kTypeSerializerCache.put(kType, kSerializer);
/*     */             } 
/*     */           } 
/* 153 */           return kSerializer;
/*     */         } 
/*     */       }  }
/*     */     
/* 157 */     Type type = resolvableType.getType();
/* 158 */     KSerializer<Object> serializer = this.typeSerializerCache.get(type);
/* 159 */     if (serializer == null) {
/*     */       try {
/* 161 */         serializer = SerializersKt.serializerOrNull(this.format.getSerializersModule(), type);
/*     */       }
/* 163 */       catch (IllegalArgumentException illegalArgumentException) {}
/*     */       
/* 165 */       if (serializer != null) {
/* 166 */         if (hasPolymorphism(serializer.getDescriptor(), new HashSet<>())) {
/* 167 */           return null;
/*     */         }
/* 169 */         this.typeSerializerCache.put(type, serializer);
/*     */       } 
/*     */     } 
/* 172 */     return serializer;
/*     */   }
/*     */   
/*     */   private static boolean hasPolymorphism(SerialDescriptor descriptor, Set<String> alreadyProcessed) {
/* 176 */     alreadyProcessed.add(descriptor.getSerialName());
/* 177 */     if (descriptor.getKind().equals(PolymorphicKind.OPEN.INSTANCE)) {
/* 178 */       return true;
/*     */     }
/* 180 */     for (int i = 0; i < descriptor.getElementsCount(); i++) {
/* 181 */       SerialDescriptor elementDescriptor = descriptor.getElementDescriptor(i);
/* 182 */       if (!alreadyProcessed.contains(elementDescriptor.getSerialName()) && hasPolymorphism(elementDescriptor, alreadyProcessed)) {
/* 183 */         return true;
/*     */       }
/*     */     } 
/* 186 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\KotlinSerializationSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */