/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BuilderImpl<T>
/*     */   implements ServerSentEvent.Builder<T>
/*     */ {
/*     */   @Nullable
/*     */   private String id;
/*     */   @Nullable
/*     */   private String event;
/*     */   @Nullable
/*     */   private Duration retry;
/*     */   @Nullable
/*     */   private String comment;
/*     */   @Nullable
/*     */   private T data;
/*     */   
/*     */   public BuilderImpl() {}
/*     */   
/*     */   public BuilderImpl(T data) {
/* 251 */     this.data = data;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent.Builder<T> id(String id) {
/* 256 */     this.id = id;
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent.Builder<T> event(String event) {
/* 262 */     this.event = event;
/* 263 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent.Builder<T> retry(Duration retry) {
/* 268 */     this.retry = retry;
/* 269 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent.Builder<T> comment(String comment) {
/* 274 */     this.comment = comment;
/* 275 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent.Builder<T> data(@Nullable T data) {
/* 280 */     this.data = data;
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSentEvent<T> build() {
/* 286 */     return new ServerSentEvent<>(this.id, this.event, this.retry, this.comment, this.data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerSentEvent$BuilderImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */