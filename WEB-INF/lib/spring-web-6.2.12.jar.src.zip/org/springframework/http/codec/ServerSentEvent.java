/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerSentEvent<T>
/*     */ {
/*     */   @Nullable
/*     */   private final String id;
/*     */   @Nullable
/*     */   private final String event;
/*     */   @Nullable
/*     */   private final Duration retry;
/*     */   @Nullable
/*     */   private final String comment;
/*     */   @Nullable
/*     */   private final T data;
/*     */   
/*     */   private ServerSentEvent(@Nullable String id, @Nullable String event, @Nullable Duration retry, @Nullable String comment, @Nullable T data) {
/*  58 */     this.id = id;
/*  59 */     this.event = event;
/*  60 */     this.retry = retry;
/*  61 */     this.comment = comment;
/*  62 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String id() {
/*  71 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String event() {
/*  79 */     return this.event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Duration retry() {
/*  87 */     return this.retry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String comment() {
/*  95 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T data() {
/* 103 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String format() {
/* 112 */     StringBuilder sb = new StringBuilder();
/* 113 */     if (this.id != null) {
/* 114 */       appendAttribute("id", this.id, sb);
/*     */     }
/* 116 */     if (this.event != null) {
/* 117 */       appendAttribute("event", this.event, sb);
/*     */     }
/* 119 */     if (this.retry != null) {
/* 120 */       appendAttribute("retry", Long.valueOf(this.retry.toMillis()), sb);
/*     */     }
/* 122 */     if (this.comment != null) {
/* 123 */       sb.append(':').append(StringUtils.replace(this.comment, "\n", "\n:")).append('\n');
/*     */     }
/* 125 */     if (this.data != null) {
/* 126 */       sb.append("data:");
/*     */     }
/* 128 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private void appendAttribute(String fieldName, Object fieldValue, StringBuilder sb) {
/* 132 */     sb.append(fieldName).append(':').append(fieldValue).append('\n');
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 137 */     if (this != other) { if (other instanceof ServerSentEvent) { ServerSentEvent<?> that = (ServerSentEvent)other;
/* 138 */         if (ObjectUtils.nullSafeEquals(this.id, that.id) && 
/* 139 */           ObjectUtils.nullSafeEquals(this.event, that.event) && 
/* 140 */           ObjectUtils.nullSafeEquals(this.retry, that.retry) && 
/* 141 */           ObjectUtils.nullSafeEquals(this.comment, that.comment) && 
/* 142 */           ObjectUtils.nullSafeEquals(this.data, that.data)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 147 */     return ObjectUtils.nullSafeHash(new Object[] { this.id, this.event, this.retry, this.comment, this.data });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return "ServerSentEvent [id = '" + this.id + "', event='" + this.event + "', retry=" + String.valueOf(this.retry) + ", comment='" + this.comment + "', data=" + String.valueOf(this.data) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Builder<T> builder() {
/* 163 */     return new BuilderImpl<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Builder<T> builder(T data) {
/* 172 */     return new BuilderImpl<>(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BuilderImpl<T>
/*     */     implements Builder<T>
/*     */   {
/*     */     @Nullable
/*     */     private String id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Duration retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String comment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private T data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BuilderImpl() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BuilderImpl(T data) {
/* 251 */       this.data = data;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent.Builder<T> id(String id) {
/* 256 */       this.id = id;
/* 257 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent.Builder<T> event(String event) {
/* 262 */       this.event = event;
/* 263 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent.Builder<T> retry(Duration retry) {
/* 268 */       this.retry = retry;
/* 269 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent.Builder<T> comment(String comment) {
/* 274 */       this.comment = comment;
/* 275 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent.Builder<T> data(@Nullable T data) {
/* 280 */       this.data = data;
/* 281 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerSentEvent<T> build() {
/* 286 */       return new ServerSentEvent<>(this.id, this.event, this.retry, this.comment, this.data);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Builder<T> {
/*     */     Builder<T> id(String param1String);
/*     */     
/*     */     Builder<T> event(String param1String);
/*     */     
/*     */     Builder<T> retry(Duration param1Duration);
/*     */     
/*     */     Builder<T> comment(String param1String);
/*     */     
/*     */     Builder<T> data(@Nullable T param1T);
/*     */     
/*     */     ServerSentEvent<T> build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerSentEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */