/*    */ package org.springframework.http.codec.support;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.core.codec.Encoder;
/*    */ import org.springframework.http.codec.HttpMessageWriter;
/*    */ import org.springframework.http.codec.ServerCodecConfigurer;
/*    */ import org.springframework.http.codec.ServerSentEventHttpMessageWriter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ServerDefaultCodecsImpl
/*    */   extends BaseDefaultCodecs
/*    */   implements ServerCodecConfigurer.ServerDefaultCodecs
/*    */ {
/*    */   @Nullable
/*    */   private Encoder<?> sseEncoder;
/*    */   
/*    */   ServerDefaultCodecsImpl() {}
/*    */   
/*    */   ServerDefaultCodecsImpl(ServerDefaultCodecsImpl other) {
/* 42 */     super(other);
/* 43 */     this.sseEncoder = other.sseEncoder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void serverSentEventEncoder(Encoder<?> encoder) {
/* 49 */     this.sseEncoder = encoder;
/* 50 */     initObjectWriters();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void extendObjectWriters(List<HttpMessageWriter<?>> objectWriters) {
/* 55 */     objectWriters.add(new ServerSentEventHttpMessageWriter(getSseEncoder()));
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private Encoder<?> getSseEncoder() {
/* 60 */     return (this.sseEncoder != null) ? this.sseEncoder : (
/* 61 */       jackson2Present ? getJackson2JsonEncoder() : (
/* 62 */       kotlinSerializationJsonPresent ? getKotlinSerializationJsonEncoder() : 
/* 63 */       null));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\ServerDefaultCodecsImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */