/*    */ package org.springframework.http.codec.support;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.core.codec.Decoder;
/*    */ import org.springframework.http.codec.ClientCodecConfigurer;
/*    */ import org.springframework.http.codec.HttpMessageReader;
/*    */ import org.springframework.http.codec.ServerSentEventHttpMessageReader;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClientDefaultCodecsImpl
/*    */   extends BaseDefaultCodecs
/*    */   implements ClientCodecConfigurer.ClientDefaultCodecs
/*    */ {
/*    */   @Nullable
/*    */   private Decoder<?> sseDecoder;
/*    */   
/*    */   ClientDefaultCodecsImpl() {}
/*    */   
/*    */   ClientDefaultCodecsImpl(ClientDefaultCodecsImpl other) {
/* 42 */     super(other);
/* 43 */     this.sseDecoder = other.sseDecoder;
/*    */   }
/*    */ 
/*    */   
/*    */   public void serverSentEventDecoder(Decoder<?> decoder) {
/* 48 */     this.sseDecoder = decoder;
/* 49 */     initObjectReaders();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void extendObjectReaders(List<HttpMessageReader<?>> objectReaders) {
/* 58 */     Decoder<?> decoder = (this.sseDecoder != null) ? this.sseDecoder : (jackson2Present ? getJackson2JsonDecoder() : (kotlinSerializationJsonPresent ? getKotlinSerializationJsonDecoder() : null));
/*    */     
/* 60 */     addCodec(objectReaders, new ServerSentEventHttpMessageReader(decoder));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\ClientDefaultCodecsImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */