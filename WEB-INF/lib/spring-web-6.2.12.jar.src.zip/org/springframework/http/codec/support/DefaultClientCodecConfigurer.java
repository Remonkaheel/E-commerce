/*    */ package org.springframework.http.codec.support;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.codec.ClientCodecConfigurer;
/*    */ import org.springframework.http.codec.CodecConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultClientCodecConfigurer
/*    */   extends BaseCodecConfigurer
/*    */   implements ClientCodecConfigurer
/*    */ {
/*    */   public DefaultClientCodecConfigurer() {
/* 31 */     super(new ClientDefaultCodecsImpl());
/*    */   }
/*    */   
/*    */   private DefaultClientCodecConfigurer(DefaultClientCodecConfigurer other) {
/* 35 */     super(other);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientCodecConfigurer.ClientDefaultCodecs defaultCodecs() {
/* 41 */     return (ClientCodecConfigurer.ClientDefaultCodecs)super.defaultCodecs();
/*    */   }
/*    */ 
/*    */   
/*    */   public DefaultClientCodecConfigurer clone() {
/* 46 */     return new DefaultClientCodecConfigurer(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BaseDefaultCodecs cloneDefaultCodecs() {
/* 51 */     return new ClientDefaultCodecsImpl((ClientDefaultCodecsImpl)defaultCodecs());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\DefaultClientCodecConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */