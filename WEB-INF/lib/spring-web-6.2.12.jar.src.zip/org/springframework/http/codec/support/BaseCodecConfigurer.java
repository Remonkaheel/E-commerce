/*     */ package org.springframework.http.codec.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.Encoder;
/*     */ import org.springframework.http.codec.CodecConfigurer;
/*     */ import org.springframework.http.codec.DecoderHttpMessageReader;
/*     */ import org.springframework.http.codec.EncoderHttpMessageWriter;
/*     */ import org.springframework.http.codec.HttpMessageReader;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseCodecConfigurer
/*     */   implements CodecConfigurer
/*     */ {
/*     */   protected final BaseDefaultCodecs defaultCodecs;
/*     */   protected final DefaultCustomCodecs customCodecs;
/*     */   
/*     */   BaseCodecConfigurer(BaseDefaultCodecs defaultCodecs) {
/*  55 */     Assert.notNull(defaultCodecs, "'defaultCodecs' is required");
/*  56 */     this.defaultCodecs = defaultCodecs;
/*  57 */     this.customCodecs = new DefaultCustomCodecs();
/*  58 */     this.defaultCodecs.setPartWritersSupplier(this::getWriters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseCodecConfigurer(BaseCodecConfigurer other) {
/*  66 */     this.defaultCodecs = other.cloneDefaultCodecs();
/*  67 */     this.customCodecs = new DefaultCustomCodecs(other.customCodecs);
/*  68 */     this.defaultCodecs.setPartWritersSupplier(this::getWriters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodecConfigurer.DefaultCodecs defaultCodecs() {
/*  81 */     return this.defaultCodecs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerDefaults(boolean shouldRegister) {
/*  86 */     this.defaultCodecs.registerDefaults(shouldRegister);
/*     */   }
/*     */ 
/*     */   
/*     */   public CodecConfigurer.CustomCodecs customCodecs() {
/*  91 */     return this.customCodecs;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<HttpMessageReader<?>> getReaders() {
/*  96 */     this.defaultCodecs.applyDefaultConfig(this.customCodecs);
/*     */     
/*  98 */     List<HttpMessageReader<?>> result = new ArrayList<>();
/*  99 */     result.addAll(this.customCodecs.getTypedReaders().keySet());
/* 100 */     result.addAll(this.defaultCodecs.getTypedReaders());
/* 101 */     result.addAll(this.customCodecs.getObjectReaders().keySet());
/* 102 */     result.addAll(this.defaultCodecs.getObjectReaders());
/* 103 */     result.addAll(this.defaultCodecs.getCatchAllReaders());
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<HttpMessageWriter<?>> getWriters() {
/* 109 */     this.defaultCodecs.applyDefaultConfig(this.customCodecs);
/*     */     
/* 111 */     List<HttpMessageWriter<?>> result = new ArrayList<>();
/* 112 */     result.addAll(this.customCodecs.getTypedWriters().keySet());
/* 113 */     result.addAll(this.defaultCodecs.getTypedWriters());
/* 114 */     result.addAll(this.customCodecs.getObjectWriters().keySet());
/* 115 */     result.addAll(this.defaultCodecs.getObjectWriters());
/* 116 */     result.addAll(this.defaultCodecs.getCatchAllWriters());
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract BaseDefaultCodecs cloneDefaultCodecs();
/*     */ 
/*     */   
/*     */   public abstract CodecConfigurer clone();
/*     */   
/*     */   protected static final class DefaultCustomCodecs
/*     */     implements CodecConfigurer.CustomCodecs
/*     */   {
/* 129 */     private final Map<HttpMessageReader<?>, Boolean> typedReaders = new LinkedHashMap<>(4);
/*     */     
/* 131 */     private final Map<HttpMessageWriter<?>, Boolean> typedWriters = new LinkedHashMap<>(4);
/*     */     
/* 133 */     private final Map<HttpMessageReader<?>, Boolean> objectReaders = new LinkedHashMap<>(4);
/*     */     
/* 135 */     private final Map<HttpMessageWriter<?>, Boolean> objectWriters = new LinkedHashMap<>(4);
/*     */     
/* 137 */     private final List<Consumer<CodecConfigurer.DefaultCodecConfig>> defaultConfigConsumers = new ArrayList<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultCustomCodecs() {}
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultCustomCodecs(DefaultCustomCodecs other) {
/* 147 */       this.typedReaders.putAll(other.typedReaders);
/* 148 */       this.typedWriters.putAll(other.typedWriters);
/* 149 */       this.objectReaders.putAll(other.objectReaders);
/* 150 */       this.objectWriters.putAll(other.objectWriters);
/*     */     }
/*     */ 
/*     */     
/*     */     public void register(Object codec) {
/* 155 */       addCodec(codec, false);
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerWithDefaultConfig(Object codec) {
/* 160 */       addCodec(codec, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerWithDefaultConfig(Object codec, Consumer<CodecConfigurer.DefaultCodecConfig> configConsumer) {
/* 165 */       addCodec(codec, false);
/* 166 */       this.defaultConfigConsumers.add(configConsumer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void decoder(Decoder<?> decoder) {
/* 172 */       addCodec(decoder, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void encoder(Encoder<?> encoder) {
/* 178 */       addCodec(encoder, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void reader(HttpMessageReader<?> reader) {
/* 184 */       addCodec(reader, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void writer(HttpMessageWriter<?> writer) {
/* 190 */       addCodec(writer, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void withDefaultCodecConfig(Consumer<CodecConfigurer.DefaultCodecConfig> codecsConfigConsumer) {
/* 196 */       this.defaultConfigConsumers.add(codecsConfigConsumer);
/*     */     }
/*     */ 
/*     */     
/*     */     private void addCodec(Object codec, boolean applyDefaultConfig) {
/* 201 */       if (codec instanceof Decoder) { Decoder<?> decoder = (Decoder)codec;
/* 202 */         codec = new DecoderHttpMessageReader(decoder); }
/*     */       
/* 204 */       else if (codec instanceof Encoder) { Encoder<?> encoder = (Encoder)codec;
/* 205 */         codec = new EncoderHttpMessageWriter(encoder); }
/*     */ 
/*     */       
/* 208 */       if (codec instanceof HttpMessageReader) { HttpMessageReader<?> reader = (HttpMessageReader)codec;
/* 209 */         boolean canReadToObject = reader.canRead(ResolvableType.forClass(Object.class), null);
/* 210 */         (canReadToObject ? this.objectReaders : this.typedReaders).put(reader, Boolean.valueOf(applyDefaultConfig)); }
/*     */       
/* 212 */       else if (codec instanceof HttpMessageWriter) { HttpMessageWriter<?> writer = (HttpMessageWriter)codec;
/* 213 */         boolean canWriteObject = writer.canWrite(ResolvableType.forClass(Object.class), null);
/* 214 */         (canWriteObject ? this.objectWriters : this.typedWriters).put(writer, Boolean.valueOf(applyDefaultConfig)); }
/*     */       else
/*     */       
/* 217 */       { throw new IllegalArgumentException("Unexpected codec type: " + codec.getClass().getName()); }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     Map<HttpMessageReader<?>, Boolean> getTypedReaders() {
/* 224 */       return this.typedReaders;
/*     */     }
/*     */     
/*     */     Map<HttpMessageWriter<?>, Boolean> getTypedWriters() {
/* 228 */       return this.typedWriters;
/*     */     }
/*     */     
/*     */     Map<HttpMessageReader<?>, Boolean> getObjectReaders() {
/* 232 */       return this.objectReaders;
/*     */     }
/*     */     
/*     */     Map<HttpMessageWriter<?>, Boolean> getObjectWriters() {
/* 236 */       return this.objectWriters;
/*     */     }
/*     */     
/*     */     List<Consumer<CodecConfigurer.DefaultCodecConfig>> getDefaultConfigConsumers() {
/* 240 */       return this.defaultConfigConsumers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\BaseCodecConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */