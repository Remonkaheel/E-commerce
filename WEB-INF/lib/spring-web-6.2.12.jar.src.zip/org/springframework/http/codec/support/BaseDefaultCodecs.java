/*     */ package org.springframework.http.codec.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.codec.AbstractDataBufferDecoder;
/*     */ import org.springframework.core.codec.ByteArrayDecoder;
/*     */ import org.springframework.core.codec.ByteArrayEncoder;
/*     */ import org.springframework.core.codec.ByteBufferDecoder;
/*     */ import org.springframework.core.codec.ByteBufferEncoder;
/*     */ import org.springframework.core.codec.CharSequenceEncoder;
/*     */ import org.springframework.core.codec.DataBufferDecoder;
/*     */ import org.springframework.core.codec.DataBufferEncoder;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.Encoder;
/*     */ import org.springframework.core.codec.Netty5BufferDecoder;
/*     */ import org.springframework.core.codec.Netty5BufferEncoder;
/*     */ import org.springframework.core.codec.NettyByteBufDecoder;
/*     */ import org.springframework.core.codec.NettyByteBufEncoder;
/*     */ import org.springframework.core.codec.ResourceDecoder;
/*     */ import org.springframework.core.codec.StringDecoder;
/*     */ import org.springframework.http.codec.CodecConfigurer;
/*     */ import org.springframework.http.codec.DecoderHttpMessageReader;
/*     */ import org.springframework.http.codec.EncoderHttpMessageWriter;
/*     */ import org.springframework.http.codec.FormHttpMessageReader;
/*     */ import org.springframework.http.codec.FormHttpMessageWriter;
/*     */ import org.springframework.http.codec.HttpMessageReader;
/*     */ import org.springframework.http.codec.HttpMessageWriter;
/*     */ import org.springframework.http.codec.ResourceHttpMessageReader;
/*     */ import org.springframework.http.codec.ResourceHttpMessageWriter;
/*     */ import org.springframework.http.codec.ServerSentEventHttpMessageReader;
/*     */ import org.springframework.http.codec.ServerSentEventHttpMessageWriter;
/*     */ import org.springframework.http.codec.cbor.KotlinSerializationCborDecoder;
/*     */ import org.springframework.http.codec.cbor.KotlinSerializationCborEncoder;
/*     */ import org.springframework.http.codec.json.AbstractJackson2Decoder;
/*     */ import org.springframework.http.codec.json.Jackson2JsonDecoder;
/*     */ import org.springframework.http.codec.json.Jackson2JsonEncoder;
/*     */ import org.springframework.http.codec.json.Jackson2SmileDecoder;
/*     */ import org.springframework.http.codec.json.Jackson2SmileEncoder;
/*     */ import org.springframework.http.codec.json.KotlinSerializationJsonDecoder;
/*     */ import org.springframework.http.codec.json.KotlinSerializationJsonEncoder;
/*     */ import org.springframework.http.codec.multipart.DefaultPartHttpMessageReader;
/*     */ import org.springframework.http.codec.multipart.MultipartHttpMessageReader;
/*     */ import org.springframework.http.codec.multipart.MultipartHttpMessageWriter;
/*     */ import org.springframework.http.codec.multipart.PartEventHttpMessageReader;
/*     */ import org.springframework.http.codec.multipart.PartEventHttpMessageWriter;
/*     */ import org.springframework.http.codec.multipart.PartHttpMessageWriter;
/*     */ import org.springframework.http.codec.protobuf.KotlinSerializationProtobufDecoder;
/*     */ import org.springframework.http.codec.protobuf.KotlinSerializationProtobufEncoder;
/*     */ import org.springframework.http.codec.protobuf.ProtobufDecoder;
/*     */ import org.springframework.http.codec.protobuf.ProtobufEncoder;
/*     */ import org.springframework.http.codec.protobuf.ProtobufHttpMessageWriter;
/*     */ import org.springframework.http.codec.xml.Jaxb2XmlDecoder;
/*     */ import org.springframework.http.codec.xml.Jaxb2XmlEncoder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BaseDefaultCodecs
/*     */   implements CodecConfigurer.DefaultCodecs, CodecConfigurer.DefaultCodecConfig
/*     */ {
/*     */   static final boolean jackson2Present;
/*     */   private static final boolean jackson2SmilePresent;
/*     */   private static final boolean jaxb2Present;
/*     */   private static final boolean protobufPresent;
/*     */   static final boolean nettyByteBufPresent;
/*     */   static final boolean netty5BufferPresent;
/*     */   static final boolean kotlinSerializationCborPresent;
/*     */   static final boolean kotlinSerializationJsonPresent;
/*     */   static final boolean kotlinSerializationProtobufPresent;
/*     */   @Nullable
/*     */   private Decoder<?> jackson2JsonDecoder;
/*     */   @Nullable
/*     */   private Encoder<?> jackson2JsonEncoder;
/*     */   @Nullable
/*     */   private Encoder<?> jackson2SmileEncoder;
/*     */   @Nullable
/*     */   private Decoder<?> jackson2SmileDecoder;
/*     */   @Nullable
/*     */   private Decoder<?> protobufDecoder;
/*     */   
/*     */   static {
/* 107 */     ClassLoader classLoader = BaseCodecConfigurer.class.getClassLoader();
/*     */     
/* 109 */     jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", classLoader) && ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", classLoader));
/* 110 */     jackson2SmilePresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.smile.SmileFactory", classLoader);
/* 111 */     jaxb2Present = ClassUtils.isPresent("jakarta.xml.bind.Binder", classLoader);
/* 112 */     protobufPresent = ClassUtils.isPresent("com.google.protobuf.Message", classLoader);
/* 113 */     nettyByteBufPresent = ClassUtils.isPresent("io.netty.buffer.ByteBuf", classLoader);
/* 114 */     netty5BufferPresent = ClassUtils.isPresent("io.netty5.buffer.Buffer", classLoader);
/* 115 */     kotlinSerializationCborPresent = ClassUtils.isPresent("kotlinx.serialization.cbor.Cbor", classLoader);
/* 116 */     kotlinSerializationJsonPresent = ClassUtils.isPresent("kotlinx.serialization.json.Json", classLoader);
/* 117 */     kotlinSerializationProtobufPresent = ClassUtils.isPresent("kotlinx.serialization.protobuf.ProtoBuf", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Encoder<?> protobufEncoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Decoder<?> jaxb2Decoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Encoder<?> jaxb2Encoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Decoder<?> kotlinSerializationCborDecoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Encoder<?> kotlinSerializationCborEncoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Decoder<?> kotlinSerializationJsonDecoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Encoder<?> kotlinSerializationJsonEncoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Decoder<?> kotlinSerializationProtobufDecoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Encoder<?> kotlinSerializationProtobufEncoder;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private DefaultMultipartCodecs multipartCodecs;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Supplier<List<HttpMessageWriter<?>>> partWritersSupplier;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private HttpMessageReader<?> multipartReader;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Consumer<Object> codecConsumer;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Integer maxInMemorySize;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean enableLoggingRequestDetails;
/*     */ 
/*     */   
/*     */   private boolean registerDefaults = true;
/*     */ 
/*     */   
/* 186 */   private final List<HttpMessageReader<?>> typedReaders = new ArrayList<>();
/*     */   
/* 188 */   private final List<HttpMessageReader<?>> objectReaders = new ArrayList<>();
/*     */   
/* 190 */   private final List<HttpMessageWriter<?>> typedWriters = new ArrayList<>();
/*     */   
/* 192 */   private final List<HttpMessageWriter<?>> objectWriters = new ArrayList<>();
/*     */ 
/*     */   
/*     */   BaseDefaultCodecs() {
/* 196 */     initReaders();
/* 197 */     initWriters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initReaders() {
/* 205 */     initTypedReaders();
/* 206 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initWriters() {
/* 214 */     initTypedWriters();
/* 215 */     initObjectWriters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseDefaultCodecs(BaseDefaultCodecs other) {
/* 222 */     this.jackson2JsonDecoder = other.jackson2JsonDecoder;
/* 223 */     this.jackson2JsonEncoder = other.jackson2JsonEncoder;
/* 224 */     this.jackson2SmileDecoder = other.jackson2SmileDecoder;
/* 225 */     this.jackson2SmileEncoder = other.jackson2SmileEncoder;
/* 226 */     this.protobufDecoder = other.protobufDecoder;
/* 227 */     this.protobufEncoder = other.protobufEncoder;
/* 228 */     this.jaxb2Decoder = other.jaxb2Decoder;
/* 229 */     this.jaxb2Encoder = other.jaxb2Encoder;
/* 230 */     this.kotlinSerializationCborDecoder = other.kotlinSerializationCborDecoder;
/* 231 */     this.kotlinSerializationCborEncoder = other.kotlinSerializationCborEncoder;
/* 232 */     this.kotlinSerializationJsonDecoder = other.kotlinSerializationJsonDecoder;
/* 233 */     this.kotlinSerializationJsonEncoder = other.kotlinSerializationJsonEncoder;
/* 234 */     this.kotlinSerializationProtobufDecoder = other.kotlinSerializationProtobufDecoder;
/* 235 */     this.kotlinSerializationProtobufEncoder = other.kotlinSerializationProtobufEncoder;
/* 236 */     this
/* 237 */       .multipartCodecs = (other.multipartCodecs != null) ? new DefaultMultipartCodecs(other.multipartCodecs) : null;
/* 238 */     this.multipartReader = other.multipartReader;
/* 239 */     this.codecConsumer = other.codecConsumer;
/* 240 */     this.maxInMemorySize = other.maxInMemorySize;
/* 241 */     this.enableLoggingRequestDetails = other.enableLoggingRequestDetails;
/* 242 */     this.registerDefaults = other.registerDefaults;
/* 243 */     this.typedReaders.addAll(other.typedReaders);
/* 244 */     this.objectReaders.addAll(other.objectReaders);
/* 245 */     this.typedWriters.addAll(other.typedWriters);
/* 246 */     this.objectWriters.addAll(other.objectWriters);
/*     */   }
/*     */ 
/*     */   
/*     */   public void jackson2JsonDecoder(Decoder<?> decoder) {
/* 251 */     this.jackson2JsonDecoder = decoder;
/* 252 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jackson2JsonEncoder(Encoder<?> encoder) {
/* 257 */     this.jackson2JsonEncoder = encoder;
/* 258 */     initObjectWriters();
/* 259 */     initTypedWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jackson2SmileDecoder(Decoder<?> decoder) {
/* 264 */     this.jackson2SmileDecoder = decoder;
/* 265 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jackson2SmileEncoder(Encoder<?> encoder) {
/* 270 */     this.jackson2SmileEncoder = encoder;
/* 271 */     initObjectWriters();
/* 272 */     initTypedWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void protobufDecoder(Decoder<?> decoder) {
/* 277 */     this.protobufDecoder = decoder;
/* 278 */     initTypedReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void protobufEncoder(Encoder<?> encoder) {
/* 283 */     this.protobufEncoder = encoder;
/* 284 */     initTypedWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jaxb2Decoder(Decoder<?> decoder) {
/* 289 */     this.jaxb2Decoder = decoder;
/* 290 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jaxb2Encoder(Encoder<?> encoder) {
/* 295 */     this.jaxb2Encoder = encoder;
/* 296 */     initObjectWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationCborDecoder(Decoder<?> decoder) {
/* 301 */     this.kotlinSerializationCborDecoder = decoder;
/* 302 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationCborEncoder(Encoder<?> encoder) {
/* 307 */     this.kotlinSerializationCborEncoder = encoder;
/* 308 */     initObjectWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationJsonDecoder(Decoder<?> decoder) {
/* 313 */     this.kotlinSerializationJsonDecoder = decoder;
/* 314 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationJsonEncoder(Encoder<?> encoder) {
/* 319 */     this.kotlinSerializationJsonEncoder = encoder;
/* 320 */     initObjectWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationProtobufDecoder(Decoder<?> decoder) {
/* 325 */     this.kotlinSerializationProtobufDecoder = decoder;
/* 326 */     initObjectReaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public void kotlinSerializationProtobufEncoder(Encoder<?> encoder) {
/* 331 */     this.kotlinSerializationProtobufEncoder = encoder;
/* 332 */     initObjectWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureDefaultCodec(Consumer<Object> codecConsumer) {
/* 337 */     this
/* 338 */       .codecConsumer = (this.codecConsumer != null) ? this.codecConsumer.andThen(codecConsumer) : codecConsumer;
/* 339 */     initReaders();
/* 340 */     initWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxInMemorySize(int byteCount) {
/* 345 */     if (!ObjectUtils.nullSafeEquals(this.maxInMemorySize, Integer.valueOf(byteCount))) {
/* 346 */       this.maxInMemorySize = Integer.valueOf(byteCount);
/* 347 */       initReaders();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer maxInMemorySize() {
/* 354 */     return this.maxInMemorySize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void enableLoggingRequestDetails(boolean enable) {
/* 359 */     if (!ObjectUtils.nullSafeEquals(this.enableLoggingRequestDetails, Boolean.valueOf(enable))) {
/* 360 */       this.enableLoggingRequestDetails = Boolean.valueOf(enable);
/* 361 */       initReaders();
/* 362 */       initWriters();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CodecConfigurer.MultipartCodecs multipartCodecs() {
/* 368 */     if (this.multipartCodecs == null) {
/* 369 */       this.multipartCodecs = new DefaultMultipartCodecs();
/*     */     }
/* 371 */     return this.multipartCodecs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multipartReader(HttpMessageReader<?> multipartReader) {
/* 376 */     this.multipartReader = multipartReader;
/* 377 */     initTypedReaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPartWritersSupplier(Supplier<List<HttpMessageWriter<?>>> supplier) {
/* 387 */     this.partWritersSupplier = supplier;
/* 388 */     initTypedWriters();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Boolean isEnableLoggingRequestDetails() {
/* 394 */     return this.enableLoggingRequestDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void registerDefaults(boolean registerDefaults) {
/* 401 */     if (this.registerDefaults != registerDefaults) {
/* 402 */       this.registerDefaults = registerDefaults;
/* 403 */       initReaders();
/* 404 */       initWriters();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageReader<?>> getTypedReaders() {
/* 413 */     return this.typedReaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initTypedReaders() {
/* 421 */     this.typedReaders.clear();
/* 422 */     if (!this.registerDefaults) {
/*     */       return;
/*     */     }
/* 425 */     addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)new ByteArrayDecoder()));
/* 426 */     addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)new ByteBufferDecoder()));
/* 427 */     addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)new DataBufferDecoder()));
/* 428 */     if (nettyByteBufPresent) {
/* 429 */       addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)new NettyByteBufDecoder()));
/*     */     }
/* 431 */     if (netty5BufferPresent) {
/* 432 */       addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)new Netty5BufferDecoder()));
/*     */     }
/* 434 */     addCodec(this.typedReaders, new ResourceHttpMessageReader(new ResourceDecoder()));
/* 435 */     addCodec(this.typedReaders, new DecoderHttpMessageReader((Decoder)StringDecoder.textPlainOnly()));
/* 436 */     if (protobufPresent) {
/* 437 */       addCodec(this.typedReaders, new DecoderHttpMessageReader((this.protobufDecoder != null) ? 
/* 438 */             this.protobufDecoder : (Decoder)new ProtobufDecoder()));
/*     */     }
/* 440 */     else if (kotlinSerializationProtobufPresent) {
/* 441 */       addCodec(this.typedReaders, new DecoderHttpMessageReader((this.kotlinSerializationProtobufDecoder != null) ? 
/* 442 */             this.kotlinSerializationProtobufDecoder : (Decoder)new KotlinSerializationProtobufDecoder()));
/*     */     } 
/* 444 */     addCodec(this.typedReaders, new FormHttpMessageReader());
/* 445 */     if (this.multipartReader != null) {
/* 446 */       addCodec(this.typedReaders, this.multipartReader);
/*     */     } else {
/*     */       
/* 449 */       DefaultPartHttpMessageReader partReader = new DefaultPartHttpMessageReader();
/* 450 */       addCodec(this.typedReaders, partReader);
/* 451 */       addCodec(this.typedReaders, new MultipartHttpMessageReader((HttpMessageReader)partReader));
/*     */     } 
/* 453 */     addCodec(this.typedReaders, new PartEventHttpMessageReader());
/*     */ 
/*     */     
/* 456 */     extendTypedReaders(this.typedReaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> void addCodec(List<T> codecs, T codec) {
/* 464 */     initCodec(codec);
/* 465 */     codecs.add(codec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initCodec(@Nullable Object codec) {
/* 474 */     if (codec instanceof DecoderHttpMessageReader) { DecoderHttpMessageReader<?> decoderHttpMessageReader = (DecoderHttpMessageReader)codec;
/* 475 */       codec = decoderHttpMessageReader.getDecoder(); }
/*     */     
/* 477 */     else if (codec instanceof EncoderHttpMessageWriter) { EncoderHttpMessageWriter<?> encoderHttpMessageWriter = (EncoderHttpMessageWriter)codec;
/* 478 */       codec = encoderHttpMessageWriter.getEncoder(); }
/*     */ 
/*     */     
/* 481 */     if (codec == null) {
/*     */       return;
/*     */     }
/*     */     
/* 485 */     Integer size = this.maxInMemorySize;
/* 486 */     if (size != null) {
/* 487 */       if (codec instanceof AbstractDataBufferDecoder) { AbstractDataBufferDecoder<?> abstractDataBufferDecoder = (AbstractDataBufferDecoder)codec;
/* 488 */         abstractDataBufferDecoder.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */ 
/*     */       
/* 492 */       if (protobufPresent && 
/* 493 */         codec instanceof ProtobufDecoder) { ProtobufDecoder protobufDec = (ProtobufDecoder)codec;
/* 494 */         protobufDec.setMaxMessageSize(size.intValue()); }
/*     */ 
/*     */       
/* 497 */       if (kotlinSerializationCborPresent && 
/* 498 */         codec instanceof KotlinSerializationCborDecoder) { KotlinSerializationCborDecoder kotlinSerializationCborDec = (KotlinSerializationCborDecoder)codec;
/* 499 */         kotlinSerializationCborDec.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */       
/* 502 */       if (kotlinSerializationJsonPresent && 
/* 503 */         codec instanceof KotlinSerializationJsonDecoder) { KotlinSerializationJsonDecoder kotlinSerializationJsonDec = (KotlinSerializationJsonDecoder)codec;
/* 504 */         kotlinSerializationJsonDec.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */       
/* 507 */       if (kotlinSerializationProtobufPresent && 
/* 508 */         codec instanceof KotlinSerializationProtobufDecoder) { KotlinSerializationProtobufDecoder kotlinSerializationProtobufDec = (KotlinSerializationProtobufDecoder)codec;
/* 509 */         kotlinSerializationProtobufDec.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */       
/* 512 */       if (jackson2Present && 
/* 513 */         codec instanceof AbstractJackson2Decoder) { AbstractJackson2Decoder abstractJackson2Decoder = (AbstractJackson2Decoder)codec;
/* 514 */         abstractJackson2Decoder.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */       
/* 517 */       if (jaxb2Present && 
/* 518 */         codec instanceof Jaxb2XmlDecoder) { Jaxb2XmlDecoder jaxb2XmlDecoder = (Jaxb2XmlDecoder)codec;
/* 519 */         jaxb2XmlDecoder.setMaxInMemorySize(size.intValue()); }
/*     */ 
/*     */       
/* 522 */       if (codec instanceof FormHttpMessageReader) { FormHttpMessageReader formHttpMessageReader = (FormHttpMessageReader)codec;
/* 523 */         formHttpMessageReader.setMaxInMemorySize(size.intValue()); }
/*     */       
/* 525 */       if (codec instanceof ServerSentEventHttpMessageReader) { ServerSentEventHttpMessageReader serverSentEventHttpMessageReader = (ServerSentEventHttpMessageReader)codec;
/* 526 */         serverSentEventHttpMessageReader.setMaxInMemorySize(size.intValue()); }
/*     */       
/* 528 */       if (codec instanceof DefaultPartHttpMessageReader) { DefaultPartHttpMessageReader defaultPartHttpMessageReader = (DefaultPartHttpMessageReader)codec;
/* 529 */         defaultPartHttpMessageReader.setMaxInMemorySize(size.intValue()); }
/*     */       
/* 531 */       if (codec instanceof PartEventHttpMessageReader) { PartEventHttpMessageReader partEventHttpMessageReader = (PartEventHttpMessageReader)codec;
/* 532 */         partEventHttpMessageReader.setMaxInMemorySize(size.intValue()); }
/*     */     
/*     */     } 
/*     */     
/* 536 */     Boolean enable = this.enableLoggingRequestDetails;
/* 537 */     if (enable != null) {
/* 538 */       if (codec instanceof FormHttpMessageReader) { FormHttpMessageReader formHttpMessageReader = (FormHttpMessageReader)codec;
/* 539 */         formHttpMessageReader.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */       
/* 541 */       if (codec instanceof MultipartHttpMessageReader) { MultipartHttpMessageReader multipartHttpMessageReader = (MultipartHttpMessageReader)codec;
/* 542 */         multipartHttpMessageReader.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */       
/* 544 */       if (codec instanceof DefaultPartHttpMessageReader) { DefaultPartHttpMessageReader defaultPartHttpMessageReader = (DefaultPartHttpMessageReader)codec;
/* 545 */         defaultPartHttpMessageReader.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */       
/* 547 */       if (codec instanceof PartEventHttpMessageReader) { PartEventHttpMessageReader partEventHttpMessageReader = (PartEventHttpMessageReader)codec;
/* 548 */         partEventHttpMessageReader.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */       
/* 550 */       if (codec instanceof FormHttpMessageWriter) { FormHttpMessageWriter formHttpMessageWriter = (FormHttpMessageWriter)codec;
/* 551 */         formHttpMessageWriter.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */       
/* 553 */       if (codec instanceof MultipartHttpMessageWriter) { MultipartHttpMessageWriter multipartHttpMessageWriter = (MultipartHttpMessageWriter)codec;
/* 554 */         multipartHttpMessageWriter.setEnableLoggingRequestDetails(enable.booleanValue()); }
/*     */     
/*     */     } 
/*     */     
/* 558 */     if (this.codecConsumer != null) {
/* 559 */       this.codecConsumer.accept(codec);
/*     */     }
/*     */ 
/*     */     
/* 563 */     if (codec instanceof MultipartHttpMessageReader) { MultipartHttpMessageReader multipartHttpMessageReader = (MultipartHttpMessageReader)codec;
/* 564 */       initCodec(multipartHttpMessageReader.getPartReader()); }
/*     */     
/* 566 */     else if (codec instanceof MultipartHttpMessageWriter) { MultipartHttpMessageWriter multipartHttpMessageWriter = (MultipartHttpMessageWriter)codec;
/* 567 */       initCodec(multipartHttpMessageWriter.getFormWriter()); }
/*     */     
/* 569 */     else if (codec instanceof ServerSentEventHttpMessageReader) { ServerSentEventHttpMessageReader serverSentEventHttpMessageReader = (ServerSentEventHttpMessageReader)codec;
/* 570 */       initCodec(serverSentEventHttpMessageReader.getDecoder()); }
/*     */     
/* 572 */     else if (codec instanceof ServerSentEventHttpMessageWriter) { ServerSentEventHttpMessageWriter serverSentEventHttpMessageWriter = (ServerSentEventHttpMessageWriter)codec;
/* 573 */       initCodec(serverSentEventHttpMessageWriter.getEncoder()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendTypedReaders(List<HttpMessageReader<?>> typedReaders) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageReader<?>> getObjectReaders() {
/* 587 */     return this.objectReaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initObjectReaders() {
/* 595 */     this.objectReaders.clear();
/* 596 */     if (!this.registerDefaults) {
/*     */       return;
/*     */     }
/* 599 */     if (kotlinSerializationCborPresent) {
/* 600 */       addCodec(this.objectReaders, new DecoderHttpMessageReader((this.kotlinSerializationCborDecoder != null) ? 
/* 601 */             this.kotlinSerializationCborDecoder : 
/* 602 */             (Decoder)new KotlinSerializationCborDecoder()));
/*     */     }
/* 604 */     if (kotlinSerializationJsonPresent) {
/* 605 */       addCodec(this.objectReaders, new DecoderHttpMessageReader(getKotlinSerializationJsonDecoder()));
/*     */     }
/* 607 */     if (kotlinSerializationProtobufPresent) {
/* 608 */       addCodec(this.objectReaders, new DecoderHttpMessageReader(
/* 609 */             (this.kotlinSerializationProtobufDecoder != null) ? 
/* 610 */             this.kotlinSerializationProtobufDecoder : 
/* 611 */             (Decoder)new KotlinSerializationProtobufDecoder()));
/*     */     }
/* 613 */     if (jackson2Present) {
/* 614 */       addCodec(this.objectReaders, new DecoderHttpMessageReader(getJackson2JsonDecoder()));
/*     */     }
/* 616 */     if (jackson2SmilePresent) {
/* 617 */       addCodec(this.objectReaders, new DecoderHttpMessageReader((this.jackson2SmileDecoder != null) ? 
/* 618 */             this.jackson2SmileDecoder : (Decoder)new Jackson2SmileDecoder()));
/*     */     }
/* 620 */     if (jaxb2Present) {
/* 621 */       addCodec(this.objectReaders, new DecoderHttpMessageReader((this.jaxb2Decoder != null) ? 
/* 622 */             this.jaxb2Decoder : (Decoder)new Jaxb2XmlDecoder()));
/*     */     }
/*     */ 
/*     */     
/* 626 */     extendObjectReaders(this.objectReaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendObjectReaders(List<HttpMessageReader<?>> objectReaders) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageReader<?>> getCatchAllReaders() {
/* 639 */     if (!this.registerDefaults) {
/* 640 */       return Collections.emptyList();
/*     */     }
/* 642 */     List<HttpMessageReader<?>> readers = new ArrayList<>();
/* 643 */     addCodec(readers, new DecoderHttpMessageReader((Decoder)StringDecoder.allMimeTypes()));
/* 644 */     return readers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageWriter<?>> getTypedWriters() {
/* 651 */     return this.typedWriters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initTypedWriters() {
/* 659 */     this.typedWriters.clear();
/* 660 */     if (!this.registerDefaults) {
/*     */       return;
/*     */     }
/* 663 */     this.typedWriters.addAll(getBaseTypedWriters());
/* 664 */     extendTypedWriters(this.typedWriters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageWriter<?>> getBaseTypedWriters() {
/* 671 */     if (!this.registerDefaults) {
/* 672 */       return Collections.emptyList();
/*     */     }
/* 674 */     List<HttpMessageWriter<?>> writers = new ArrayList<>();
/* 675 */     addCodec(writers, new EncoderHttpMessageWriter((Encoder)new ByteArrayEncoder()));
/* 676 */     addCodec(writers, new EncoderHttpMessageWriter((Encoder)new ByteBufferEncoder()));
/* 677 */     addCodec(writers, new EncoderHttpMessageWriter((Encoder)new DataBufferEncoder()));
/* 678 */     if (nettyByteBufPresent) {
/* 679 */       addCodec(writers, new EncoderHttpMessageWriter((Encoder)new NettyByteBufEncoder()));
/*     */     }
/* 681 */     if (netty5BufferPresent) {
/* 682 */       addCodec(writers, new EncoderHttpMessageWriter((Encoder)new Netty5BufferEncoder()));
/*     */     }
/* 684 */     addCodec(writers, new ResourceHttpMessageWriter());
/* 685 */     addCodec(writers, new EncoderHttpMessageWriter((Encoder)CharSequenceEncoder.textPlainOnly()));
/* 686 */     if (protobufPresent) {
/* 687 */       addCodec(writers, new ProtobufHttpMessageWriter((this.protobufEncoder != null) ? 
/* 688 */             this.protobufEncoder : (Encoder)new ProtobufEncoder()));
/*     */     }
/* 690 */     addCodec(writers, new MultipartHttpMessageWriter(this::getPartWriters, (HttpMessageWriter)new FormHttpMessageWriter()));
/* 691 */     addCodec(writers, new PartEventHttpMessageWriter());
/* 692 */     addCodec(writers, new PartHttpMessageWriter());
/* 693 */     return writers;
/*     */   }
/*     */   
/*     */   private List<HttpMessageWriter<?>> getPartWriters() {
/* 697 */     if (this.multipartCodecs != null) {
/* 698 */       return this.multipartCodecs.getWriters();
/*     */     }
/* 700 */     if (this.partWritersSupplier != null) {
/* 701 */       return this.partWritersSupplier.get();
/*     */     }
/*     */     
/* 704 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendTypedWriters(List<HttpMessageWriter<?>> typedWriters) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageWriter<?>> getObjectWriters() {
/* 719 */     return this.objectWriters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initObjectWriters() {
/* 727 */     this.objectWriters.clear();
/* 728 */     if (!this.registerDefaults) {
/*     */       return;
/*     */     }
/* 731 */     this.objectWriters.addAll(getBaseObjectWriters());
/* 732 */     extendObjectWriters(this.objectWriters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<HttpMessageWriter<?>> getBaseObjectWriters() {
/* 739 */     List<HttpMessageWriter<?>> writers = new ArrayList<>();
/* 740 */     if (kotlinSerializationCborPresent) {
/* 741 */       addCodec(writers, new EncoderHttpMessageWriter((this.kotlinSerializationCborEncoder != null) ? 
/* 742 */             this.kotlinSerializationCborEncoder : 
/* 743 */             (Encoder)new KotlinSerializationCborEncoder()));
/*     */     }
/* 745 */     if (kotlinSerializationJsonPresent) {
/* 746 */       addCodec(writers, new EncoderHttpMessageWriter(getKotlinSerializationJsonEncoder()));
/*     */     }
/* 748 */     if (kotlinSerializationProtobufPresent) {
/* 749 */       addCodec(writers, new EncoderHttpMessageWriter((this.kotlinSerializationProtobufEncoder != null) ? 
/* 750 */             this.kotlinSerializationProtobufEncoder : 
/* 751 */             (Encoder)new KotlinSerializationProtobufEncoder()));
/*     */     }
/* 753 */     if (jackson2Present) {
/* 754 */       addCodec(writers, new EncoderHttpMessageWriter(getJackson2JsonEncoder()));
/*     */     }
/* 756 */     if (jackson2SmilePresent) {
/* 757 */       addCodec(writers, new EncoderHttpMessageWriter((this.jackson2SmileEncoder != null) ? 
/* 758 */             this.jackson2SmileEncoder : (Encoder)new Jackson2SmileEncoder()));
/*     */     }
/* 760 */     if (jaxb2Present) {
/* 761 */       addCodec(writers, new EncoderHttpMessageWriter((this.jaxb2Encoder != null) ? 
/* 762 */             this.jaxb2Encoder : (Encoder)new Jaxb2XmlEncoder()));
/*     */     }
/* 764 */     return writers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendObjectWriters(List<HttpMessageWriter<?>> objectWriters) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<HttpMessageWriter<?>> getCatchAllWriters() {
/* 777 */     if (!this.registerDefaults) {
/* 778 */       return Collections.emptyList();
/*     */     }
/* 780 */     List<HttpMessageWriter<?>> result = new ArrayList<>();
/* 781 */     result.add(new EncoderHttpMessageWriter((Encoder)CharSequenceEncoder.allMimeTypes()));
/* 782 */     return result;
/*     */   }
/*     */   
/*     */   void applyDefaultConfig(BaseCodecConfigurer.DefaultCustomCodecs customCodecs) {
/* 786 */     applyDefaultConfig(customCodecs.getTypedReaders());
/* 787 */     applyDefaultConfig(customCodecs.getObjectReaders());
/* 788 */     applyDefaultConfig(customCodecs.getTypedWriters());
/* 789 */     applyDefaultConfig(customCodecs.getObjectWriters());
/* 790 */     customCodecs.getDefaultConfigConsumers().forEach(consumer -> consumer.accept(this));
/*     */   }
/*     */   
/*     */   private void applyDefaultConfig(Map<?, Boolean> readers) {
/* 794 */     readers.entrySet().stream()
/* 795 */       .filter(Map.Entry::getValue)
/* 796 */       .map(Map.Entry::getKey)
/* 797 */       .forEach(this::initCodec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Decoder<?> getJackson2JsonDecoder() {
/* 804 */     if (this.jackson2JsonDecoder == null) {
/* 805 */       this.jackson2JsonDecoder = (Decoder<?>)new Jackson2JsonDecoder();
/*     */     }
/* 807 */     return this.jackson2JsonDecoder;
/*     */   }
/*     */   
/*     */   protected Encoder<?> getJackson2JsonEncoder() {
/* 811 */     if (this.jackson2JsonEncoder == null) {
/* 812 */       this.jackson2JsonEncoder = (Encoder<?>)new Jackson2JsonEncoder();
/*     */     }
/* 814 */     return this.jackson2JsonEncoder;
/*     */   }
/*     */   
/*     */   protected Decoder<?> getKotlinSerializationJsonDecoder() {
/* 818 */     if (this.kotlinSerializationJsonDecoder == null) {
/* 819 */       this.kotlinSerializationJsonDecoder = (Decoder<?>)new KotlinSerializationJsonDecoder();
/*     */     }
/* 821 */     return this.kotlinSerializationJsonDecoder;
/*     */   }
/*     */   
/*     */   protected Encoder<?> getKotlinSerializationJsonEncoder() {
/* 825 */     if (this.kotlinSerializationJsonEncoder == null) {
/* 826 */       this.kotlinSerializationJsonEncoder = (Encoder<?>)new KotlinSerializationJsonEncoder();
/*     */     }
/* 828 */     return this.kotlinSerializationJsonEncoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class DefaultMultipartCodecs
/*     */     implements CodecConfigurer.MultipartCodecs
/*     */   {
/* 837 */     private final List<HttpMessageWriter<?>> writers = new ArrayList<>();
/*     */ 
/*     */     
/*     */     DefaultMultipartCodecs() {}
/*     */ 
/*     */     
/*     */     DefaultMultipartCodecs(DefaultMultipartCodecs other) {
/* 844 */       this.writers.addAll(other.writers);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CodecConfigurer.MultipartCodecs encoder(Encoder<?> encoder) {
/* 850 */       writer((HttpMessageWriter<?>)new EncoderHttpMessageWriter(encoder));
/* 851 */       BaseDefaultCodecs.this.initTypedWriters();
/* 852 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CodecConfigurer.MultipartCodecs writer(HttpMessageWriter<?> writer) {
/* 857 */       this.writers.add(writer);
/* 858 */       BaseDefaultCodecs.this.initTypedWriters();
/* 859 */       return this;
/*     */     }
/*     */     
/*     */     List<HttpMessageWriter<?>> getWriters() {
/* 863 */       return this.writers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\BaseDefaultCodecs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */