/*    */ package org.springframework.http.codec.support;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.codec.CodecConfigurer;
/*    */ import org.springframework.http.codec.ServerCodecConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultServerCodecConfigurer
/*    */   extends BaseCodecConfigurer
/*    */   implements ServerCodecConfigurer
/*    */ {
/*    */   public DefaultServerCodecConfigurer() {
/* 31 */     super(new ServerDefaultCodecsImpl());
/*    */   }
/*    */   
/*    */   private DefaultServerCodecConfigurer(BaseCodecConfigurer other) {
/* 35 */     super(other);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerCodecConfigurer.ServerDefaultCodecs defaultCodecs() {
/* 41 */     return (ServerCodecConfigurer.ServerDefaultCodecs)super.defaultCodecs();
/*    */   }
/*    */ 
/*    */   
/*    */   public DefaultServerCodecConfigurer clone() {
/* 46 */     return new DefaultServerCodecConfigurer(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BaseDefaultCodecs cloneDefaultCodecs() {
/* 51 */     return new ServerDefaultCodecsImpl((ServerDefaultCodecsImpl)defaultCodecs());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\support\DefaultServerCodecConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */