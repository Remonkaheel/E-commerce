package org.springframework.http.codec;

import org.springframework.core.codec.Encoder;

public interface ServerDefaultCodecs extends CodecConfigurer.DefaultCodecs {
  void serverSentEventEncoder(Encoder<?> paramEncoder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerCodecConfigurer$ServerDefaultCodecs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */