/*    */ package org.springframework.http.codec.cbor;
/*    */ 
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.cbor.Cbor;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.KotlinSerializationBinaryDecoder;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationCborDecoder
/*    */   extends KotlinSerializationBinaryDecoder<Cbor>
/*    */ {
/*    */   public KotlinSerializationCborDecoder() {
/* 43 */     this((Cbor)Cbor.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationCborDecoder(Cbor cbor) {
/* 47 */     super((BinaryFormat)cbor, new MimeType[] { (MimeType)MediaType.APPLICATION_CBOR });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\cbor\KotlinSerializationCborDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */