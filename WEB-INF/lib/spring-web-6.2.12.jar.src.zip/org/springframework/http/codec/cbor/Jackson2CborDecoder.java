/*    */ package org.springframework.http.codec.cbor;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.dataformat.cbor.CBORFactory;
/*    */ import java.util.Map;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.json.AbstractJackson2Decoder;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MimeType;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jackson2CborDecoder
/*    */   extends AbstractJackson2Decoder
/*    */ {
/*    */   public Jackson2CborDecoder() {
/* 47 */     this(Jackson2ObjectMapperBuilder.cbor().build(), new MimeType[] { (MimeType)MediaType.APPLICATION_CBOR });
/*    */   }
/*    */   
/*    */   public Jackson2CborDecoder(ObjectMapper mapper, MimeType... mimeTypes) {
/* 51 */     super(mapper, mimeTypes);
/* 52 */     Assert.isAssignable(CBORFactory.class, mapper.getFactory().getClass());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<Object> decode(Publisher<DataBuffer> input, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 58 */     throw new UnsupportedOperationException("Does not support stream decoding yet");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\cbor\Jackson2CborDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */