/*    */ package org.springframework.http.codec.cbor;
/*    */ 
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.cbor.Cbor;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.KotlinSerializationBinaryEncoder;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationCborEncoder
/*    */   extends KotlinSerializationBinaryEncoder<Cbor>
/*    */ {
/*    */   public KotlinSerializationCborEncoder() {
/* 39 */     this((Cbor)Cbor.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationCborEncoder(Cbor cbor) {
/* 43 */     super((BinaryFormat)cbor, new MimeType[] { (MimeType)MediaType.APPLICATION_CBOR });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\cbor\KotlinSerializationCborEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */