/*    */ package org.springframework.http.codec;
/*    */ 
/*    */ import org.springframework.core.codec.Encoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ServerCodecConfigurer
/*    */   extends CodecConfigurer
/*    */ {
/*    */   static ServerCodecConfigurer create() {
/* 76 */     return CodecConfigurerFactory.<ServerCodecConfigurer>create(ServerCodecConfigurer.class);
/*    */   }
/*    */   
/*    */   ServerCodecConfigurer clone();
/*    */   
/*    */   ServerDefaultCodecs defaultCodecs();
/*    */   
/*    */   public static interface ServerDefaultCodecs extends CodecConfigurer.DefaultCodecs {
/*    */     void serverSentEventEncoder(Encoder<?> param1Encoder);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerCodecConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */