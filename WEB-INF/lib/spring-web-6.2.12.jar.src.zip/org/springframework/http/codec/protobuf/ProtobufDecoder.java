/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ import com.google.protobuf.CodedInputStream;
/*     */ import com.google.protobuf.ExtensionRegistry;
/*     */ import com.google.protobuf.ExtensionRegistryLite;
/*     */ import com.google.protobuf.Message;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtobufDecoder
/*     */   extends ProtobufCodecSupport
/*     */   implements Decoder<Message>
/*     */ {
/*     */   protected static final int DEFAULT_MESSAGE_MAX_SIZE = 262144;
/*  79 */   private static final ConcurrentMap<Class<?>, Method> methodCache = (ConcurrentMap<Class<?>, Method>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */   
/*     */   private final ExtensionRegistry extensionRegistry;
/*     */   
/*  84 */   private int maxMessageSize = 262144;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufDecoder() {
/*  91 */     this(ExtensionRegistry.newInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufDecoder(ExtensionRegistry extensionRegistry) {
/* 100 */     Assert.notNull(extensionRegistry, "ExtensionRegistry must not be null");
/* 101 */     this.extensionRegistry = extensionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxMessageSize(int maxMessageSize) {
/* 111 */     this.maxMessageSize = maxMessageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxMessageSize() {
/* 119 */     return this.maxMessageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 125 */     return (Message.class.isAssignableFrom(elementType.toClass()) && supportsMimeType(mimeType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Message> decode(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 132 */     MessageDecoderFunction decoderFunction = new MessageDecoderFunction(elementType, this.maxMessageSize);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     Objects.requireNonNull(decoderFunction); return Flux.from(inputStream).flatMapIterable(decoderFunction).doOnTerminate(decoderFunction::discard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Message> decodeToMono(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 144 */     return DataBufferUtils.join(inputStream, this.maxMessageSize)
/* 145 */       .map(dataBuffer -> decode(dataBuffer, elementType, mimeType, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message decode(DataBuffer dataBuffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) throws DecodingException {
/*     */     try {
/* 153 */       Message.Builder builder = getMessageBuilder(targetType.toClass());
/* 154 */       ByteBuffer byteBuffer = ByteBuffer.allocate(dataBuffer.readableByteCount());
/* 155 */       dataBuffer.toByteBuffer(byteBuffer);
/* 156 */       builder.mergeFrom(CodedInputStream.newInstance(byteBuffer), (ExtensionRegistryLite)this.extensionRegistry);
/* 157 */       return builder.build();
/*     */     }
/* 159 */     catch (IOException ex) {
/* 160 */       throw new DecodingException("I/O error while parsing input stream", ex);
/*     */     }
/* 162 */     catch (Exception ex) {
/* 163 */       throw new DecodingException("Could not read Protobuf message: " + ex.getMessage(), ex);
/*     */     } finally {
/*     */       
/* 166 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Message.Builder getMessageBuilder(Class<?> clazz) throws Exception {
/* 176 */     Method method = methodCache.get(clazz);
/* 177 */     if (method == null) {
/* 178 */       method = clazz.getMethod("newBuilder", new Class[0]);
/* 179 */       methodCache.put(clazz, method);
/*     */     } 
/* 181 */     return (Message.Builder)method.invoke(clazz, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes() {
/* 186 */     return getMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   private class MessageDecoderFunction
/*     */     implements Function<DataBuffer, Iterable<? extends Message>>
/*     */   {
/*     */     private final ResolvableType elementType;
/*     */     
/*     */     private final int maxMessageSize;
/*     */     
/*     */     @Nullable
/*     */     private DataBuffer output;
/*     */     
/*     */     private int messageBytesToRead;
/*     */     
/*     */     private int offset;
/*     */     
/*     */     public MessageDecoderFunction(ResolvableType elementType, int maxMessageSize) {
/* 205 */       this.elementType = elementType;
/* 206 */       this.maxMessageSize = maxMessageSize;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterable<? extends Message> apply(DataBuffer input) {
/*     */       try {
/* 213 */         List<Message> messages = new ArrayList<>();
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/* 218 */           if (this.output == null) {
/* 219 */             if (!readMessageSize(input)) {
/* 220 */               return messages;
/*     */             }
/* 222 */             if (this.maxMessageSize > 0 && this.messageBytesToRead > this.maxMessageSize) {
/* 223 */               throw new DataBufferLimitException("The number of bytes to read for message (" + this.messageBytesToRead + ") exceeds the configured limit (" + this.maxMessageSize + ")");
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 228 */             this.output = input.factory().allocateBuffer(this.messageBytesToRead);
/*     */           } 
/*     */           
/* 231 */           int chunkBytesToRead = Math.min(this.messageBytesToRead, input.readableByteCount());
/* 232 */           int remainingBytesToRead = input.readableByteCount() - chunkBytesToRead;
/*     */           
/* 234 */           byte[] bytesToWrite = new byte[chunkBytesToRead];
/* 235 */           input.read(bytesToWrite, 0, chunkBytesToRead);
/* 236 */           this.output.write(bytesToWrite);
/* 237 */           this.messageBytesToRead -= chunkBytesToRead;
/*     */           
/* 239 */           if (this.messageBytesToRead == 0) {
/* 240 */             ByteBuffer byteBuffer = ByteBuffer.allocate(this.output.readableByteCount());
/* 241 */             this.output.toByteBuffer(byteBuffer);
/* 242 */             CodedInputStream stream = CodedInputStream.newInstance(byteBuffer);
/* 243 */             DataBufferUtils.release(this.output);
/* 244 */             this.output = null;
/*     */ 
/*     */             
/* 247 */             Message message = ProtobufDecoder.getMessageBuilder(this.elementType.toClass()).mergeFrom(stream, (ExtensionRegistryLite)ProtobufDecoder.this.extensionRegistry).build();
/* 248 */             messages.add(message);
/*     */           } 
/* 250 */           if (remainingBytesToRead <= 0)
/* 251 */             return messages; 
/*     */         } 
/* 253 */       } catch (DecodingException ex) {
/* 254 */         throw ex;
/*     */       }
/* 256 */       catch (IOException ex) {
/* 257 */         throw new DecodingException("I/O error while parsing input stream", ex);
/*     */       }
/* 259 */       catch (Exception ex) {
/* 260 */         throw new DecodingException("Could not read Protobuf message: " + ex.getMessage(), ex);
/*     */       } finally {
/*     */         
/* 263 */         DataBufferUtils.release(input);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean readMessageSize(DataBuffer input) {
/* 276 */       if (this.offset == 0) {
/* 277 */         if (input.readableByteCount() == 0) {
/* 278 */           return false;
/*     */         }
/* 280 */         int firstByte = input.read();
/* 281 */         if ((firstByte & 0x80) == 0) {
/* 282 */           this.messageBytesToRead = firstByte;
/* 283 */           return true;
/*     */         } 
/* 285 */         this.messageBytesToRead = firstByte & 0x7F;
/* 286 */         this.offset = 7;
/*     */       } 
/*     */       
/* 289 */       if (this.offset < 32) {
/* 290 */         for (; this.offset < 32; this.offset += 7) {
/* 291 */           if (input.readableByteCount() == 0) {
/* 292 */             return false;
/*     */           }
/* 294 */           int b = input.read();
/* 295 */           this.messageBytesToRead |= (b & 0x7F) << this.offset;
/* 296 */           if ((b & 0x80) == 0) {
/* 297 */             this.offset = 0;
/* 298 */             return true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 303 */       for (; this.offset < 64; this.offset += 7) {
/* 304 */         if (input.readableByteCount() == 0) {
/* 305 */           return false;
/*     */         }
/* 307 */         int b = input.read();
/* 308 */         if ((b & 0x80) == 0) {
/* 309 */           this.offset = 0;
/* 310 */           return true;
/*     */         } 
/*     */       } 
/* 313 */       this.offset = 0;
/* 314 */       throw new DecodingException("Cannot parse message size: malformed varint");
/*     */     }
/*     */     
/*     */     public void discard() {
/* 318 */       if (this.output != null)
/* 319 */         DataBufferUtils.release(this.output); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */