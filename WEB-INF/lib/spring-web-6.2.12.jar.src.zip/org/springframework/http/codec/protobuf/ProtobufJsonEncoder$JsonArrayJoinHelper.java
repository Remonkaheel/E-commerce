/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JsonArrayJoinHelper
/*     */ {
/* 149 */   private static final byte[] COMMA_SEPARATOR = new byte[] { 44 };
/*     */   
/* 151 */   private static final byte[] OPEN_BRACKET = new byte[] { 91 };
/*     */   
/* 153 */   private static final byte[] CLOSE_BRACKET = new byte[] { 93 };
/*     */   
/*     */   private boolean firstItemEmitted;
/*     */   
/*     */   public byte[] getDelimiter() {
/* 158 */     if (this.firstItemEmitted) {
/* 159 */       return COMMA_SEPARATOR;
/*     */     }
/* 161 */     this.firstItemEmitted = true;
/* 162 */     return ProtobufJsonEncoder.EMPTY_BYTES;
/*     */   }
/*     */   
/*     */   public byte[] getPrefix() {
/* 166 */     return this.firstItemEmitted ? ProtobufJsonEncoder.EMPTY_BYTES : OPEN_BRACKET;
/*     */   }
/*     */   
/*     */   public byte[] getSuffix() {
/* 170 */     return CLOSE_BRACKET;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufJsonEncoder$JsonArrayJoinHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */