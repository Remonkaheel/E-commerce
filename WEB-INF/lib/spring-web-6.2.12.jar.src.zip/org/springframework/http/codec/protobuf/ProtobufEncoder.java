/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ import com.google.protobuf.Message;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.HttpMessageEncoder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FastByteArrayOutputStream;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtobufEncoder
/*     */   extends ProtobufCodecSupport
/*     */   implements HttpMessageEncoder<Message>
/*     */ {
/*     */   private static final List<MediaType> streamingMediaTypes;
/*     */   
/*     */   static {
/*  63 */     streamingMediaTypes = Arrays.<MimeType>stream(MIME_TYPES).map(mimeType -> new MediaType(mimeType.getType(), mimeType.getSubtype(), Collections.singletonMap("delimited", "true"))).toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  68 */     return (Message.class.isAssignableFrom(elementType.toClass()) && supportsMimeType(mimeType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> encode(Publisher<? extends Message> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  75 */     return Flux.from(inputStream).map(message -> encodeValue(message, bufferFactory, !(inputStream instanceof reactor.core.publisher.Mono)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(Message message, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/*  83 */     return encodeValue(message, bufferFactory, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private DataBuffer encodeValue(Message message, DataBufferFactory bufferFactory, boolean delimited) {
/*  88 */     FastByteArrayOutputStream bos = new FastByteArrayOutputStream();
/*     */     try {
/*  90 */       if (delimited) {
/*  91 */         message.writeDelimitedTo((OutputStream)bos);
/*     */       } else {
/*     */         
/*  94 */         message.writeTo((OutputStream)bos);
/*     */       } 
/*  96 */       byte[] bytes = bos.toByteArrayUnsafe();
/*  97 */       return bufferFactory.wrap(bytes);
/*     */     }
/*  99 */     catch (IOException ex) {
/* 100 */       throw new IllegalStateException("Unexpected I/O error while writing to data buffer", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getStreamingMediaTypes() {
/* 106 */     return streamingMediaTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes() {
/* 111 */     return getMimeTypes();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */