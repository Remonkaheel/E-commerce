/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.util.JsonFormat;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtobufJsonDecoder
/*     */   implements Decoder<Message>
/*     */ {
/*     */   protected static final int DEFAULT_MESSAGE_MAX_SIZE = 262144;
/*  71 */   private static final List<MimeType> defaultMimeTypes = (List)List.of(MediaType.APPLICATION_JSON, new MediaType("application", "*+json"));
/*     */ 
/*     */   
/*  74 */   private static final ConcurrentMap<Class<?>, Method> methodCache = (ConcurrentMap<Class<?>, Method>)new ConcurrentReferenceHashMap();
/*     */   
/*     */   private final JsonFormat.Parser parser;
/*     */   
/*  78 */   private int maxMessageSize = 262144;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufJsonDecoder() {
/*  84 */     this(JsonFormat.parser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufJsonDecoder(JsonFormat.Parser parser) {
/*  91 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxMessageSize() {
/*  98 */     return this.maxMessageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxMessageSize(int maxMessageSize) {
/* 107 */     this.maxMessageSize = maxMessageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDecode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 112 */     return (Message.class.isAssignableFrom(elementType.toClass()) && supportsMimeType(mimeType));
/*     */   }
/*     */   
/*     */   private static boolean supportsMimeType(@Nullable MimeType mimeType) {
/* 116 */     if (mimeType == null) {
/* 117 */       return false;
/*     */     }
/* 119 */     for (MimeType m : defaultMimeTypes) {
/* 120 */       if (m.isCompatibleWith(mimeType)) {
/* 121 */         return true;
/*     */       }
/*     */     } 
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MimeType> getDecodableMimeTypes() {
/* 130 */     return defaultMimeTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Message> decode(Publisher<DataBuffer> inputStream, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 135 */     return Flux.error(new UnsupportedOperationException("Protobuf decoder does not support Flux, use Mono<List<...>> instead."));
/*     */   }
/*     */ 
/*     */   
/*     */   public Message decode(DataBuffer dataBuffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) throws DecodingException {
/*     */     try {
/* 141 */       Message.Builder builder = getMessageBuilder(targetType.toClass());
/* 142 */       this.parser.merge(new InputStreamReader(dataBuffer.asInputStream()), builder);
/* 143 */       return builder.build();
/*     */     }
/* 145 */     catch (Exception ex) {
/* 146 */       throw new DecodingException("Could not read Protobuf message: " + ex.getMessage(), ex);
/*     */     } finally {
/*     */       
/* 149 */       DataBufferUtils.release(dataBuffer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Message.Builder getMessageBuilder(Class<?> clazz) throws Exception {
/* 158 */     Method method = methodCache.get(clazz);
/* 159 */     if (method == null) {
/* 160 */       method = clazz.getMethod("newBuilder", new Class[0]);
/* 161 */       methodCache.put(clazz, method);
/*     */     } 
/* 163 */     return (Message.Builder)method.invoke(clazz, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Message> decodeToMono(Publisher<DataBuffer> inputStream, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 168 */     return DataBufferUtils.join(inputStream, this.maxMessageSize)
/* 169 */       .map(dataBuffer -> decode(dataBuffer, elementType, mimeType, hints))
/* 170 */       .onErrorMap(DataBufferLimitException.class, exc -> new DecodingException("Could not decode JSON as Protobuf message", (Throwable)exc));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufJsonDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */