/*    */ package org.springframework.http.codec.protobuf;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ProtobufCodecSupport
/*    */ {
/* 33 */   static final MimeType[] MIME_TYPES = new MimeType[] { new MimeType("application", "x-protobuf"), new MimeType("application", "octet-stream"), new MimeType("application", "vnd.google.protobuf") };
/*    */ 
/*    */ 
/*    */   
/*    */   static final String DELIMITED_KEY = "delimited";
/*    */ 
/*    */   
/*    */   static final String DELIMITED_VALUE = "true";
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean supportsMimeType(@Nullable MimeType mimeType) {
/* 45 */     if (mimeType == null) {
/* 46 */       return true;
/*    */     }
/* 48 */     for (MimeType m : MIME_TYPES) {
/* 49 */       if (m.isCompatibleWith(mimeType)) {
/* 50 */         return true;
/*    */       }
/*    */     } 
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   protected List<MimeType> getMimeTypes() {
/* 57 */     return Arrays.asList(MIME_TYPES);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufCodecSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */