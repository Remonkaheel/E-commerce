/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.MessageOrBuilder;
/*     */ import com.google.protobuf.util.JsonFormat;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.HttpMessageEncoder;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FastByteArrayOutputStream;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtobufJsonEncoder
/*     */   implements HttpMessageEncoder<Message>
/*     */ {
/*  56 */   private static final byte[] EMPTY_BYTES = new byte[0];
/*     */   
/*  58 */   private static final ResolvableType MESSAGE_TYPE = ResolvableType.forClass(Message.class);
/*     */   
/*  60 */   private static final List<MimeType> defaultMimeTypes = (List)List.of(MediaType.APPLICATION_JSON, new MediaType("application", "*+json"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonFormat.Printer printer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufJsonEncoder() {
/*  71 */     this(JsonFormat.printer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufJsonEncoder(JsonFormat.Printer printer) {
/*  78 */     this.printer = printer;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getStreamingMediaTypes() {
/*  83 */     return List.of(MediaType.APPLICATION_NDJSON);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MimeType> getEncodableMimeTypes() {
/*  88 */     return defaultMimeTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/*  93 */     return (Message.class.isAssignableFrom(elementType.toClass()) && supportsMimeType(mimeType));
/*     */   }
/*     */   
/*     */   private static boolean supportsMimeType(@Nullable MimeType mimeType) {
/*  97 */     if (mimeType == null) {
/*  98 */       return false;
/*     */     }
/* 100 */     for (MimeType m : defaultMimeTypes) {
/* 101 */       if (m.isCompatibleWith(mimeType)) {
/* 102 */         return true;
/*     */       }
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> encode(Publisher<? extends Message> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 110 */     if (inputStream instanceof Mono) {
/* 111 */       return Mono.from(inputStream)
/* 112 */         .map(value -> encodeValue(value, bufferFactory, elementType, mimeType, hints))
/* 113 */         .flux();
/*     */     }
/* 115 */     JsonArrayJoinHelper helper = new JsonArrayJoinHelper();
/*     */ 
/*     */ 
/*     */     
/* 119 */     return Flux.from(inputStream)
/* 120 */       .map(value -> {
/*     */           byte[] prefix = helper.getPrefix();
/*     */           
/*     */           byte[] delimiter = helper.getDelimiter();
/*     */           
/*     */           DataBuffer dataBuffer = encodeValue(value, bufferFactory, MESSAGE_TYPE, mimeType, hints);
/*     */           
/*     */           return (prefix.length > 0) ? bufferFactory.join(List.of(bufferFactory.wrap(prefix), bufferFactory.wrap(delimiter), dataBuffer)) : bufferFactory.join(List.of(bufferFactory.wrap(delimiter), dataBuffer));
/* 128 */         }).switchIfEmpty((Publisher)Mono.fromCallable(() -> bufferFactory.wrap(helper.getPrefix())))
/* 129 */       .concatWith((Publisher)Mono.fromCallable(() -> bufferFactory.wrap(helper.getSuffix())));
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBuffer encodeValue(Message message, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 134 */     FastByteArrayOutputStream bos = new FastByteArrayOutputStream();
/* 135 */     OutputStreamWriter writer = new OutputStreamWriter((OutputStream)bos, StandardCharsets.UTF_8);
/*     */     try {
/* 137 */       this.printer.appendTo((MessageOrBuilder)message, writer);
/* 138 */       writer.flush();
/* 139 */       byte[] bytes = bos.toByteArrayUnsafe();
/* 140 */       return bufferFactory.wrap(bytes);
/*     */     }
/* 142 */     catch (IOException ex) {
/* 143 */       throw new IllegalStateException("Unexpected I/O error while writing to data buffer", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class JsonArrayJoinHelper
/*     */   {
/* 149 */     private static final byte[] COMMA_SEPARATOR = new byte[] { 44 };
/*     */     
/* 151 */     private static final byte[] OPEN_BRACKET = new byte[] { 91 };
/*     */     
/* 153 */     private static final byte[] CLOSE_BRACKET = new byte[] { 93 };
/*     */     
/*     */     private boolean firstItemEmitted;
/*     */     
/*     */     public byte[] getDelimiter() {
/* 158 */       if (this.firstItemEmitted) {
/* 159 */         return COMMA_SEPARATOR;
/*     */       }
/* 161 */       this.firstItemEmitted = true;
/* 162 */       return ProtobufJsonEncoder.EMPTY_BYTES;
/*     */     }
/*     */     
/*     */     public byte[] getPrefix() {
/* 166 */       return this.firstItemEmitted ? ProtobufJsonEncoder.EMPTY_BYTES : OPEN_BRACKET;
/*     */     }
/*     */     
/*     */     public byte[] getSuffix() {
/* 170 */       return CLOSE_BRACKET;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufJsonEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */