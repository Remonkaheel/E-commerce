/*    */ package org.springframework.http.codec.protobuf;
/*    */ 
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.protobuf.ProtoBuf;
/*    */ import org.springframework.http.codec.KotlinSerializationBinaryDecoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationProtobufDecoder
/*    */   extends KotlinSerializationBinaryDecoder<ProtoBuf>
/*    */ {
/*    */   public KotlinSerializationProtobufDecoder() {
/* 42 */     this((ProtoBuf)ProtoBuf.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationProtobufDecoder(ProtoBuf protobuf) {
/* 46 */     super((BinaryFormat)protobuf, ProtobufCodecSupport.MIME_TYPES);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\KotlinSerializationProtobufDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */