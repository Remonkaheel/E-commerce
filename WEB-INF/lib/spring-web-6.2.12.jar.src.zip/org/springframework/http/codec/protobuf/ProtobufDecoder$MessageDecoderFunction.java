/*     */ package org.springframework.http.codec.protobuf;
/*     */ 
/*     */ import com.google.protobuf.CodedInputStream;
/*     */ import com.google.protobuf.ExtensionRegistryLite;
/*     */ import com.google.protobuf.Message;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.DecodingException;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MessageDecoderFunction
/*     */   implements Function<DataBuffer, Iterable<? extends Message>>
/*     */ {
/*     */   private final ResolvableType elementType;
/*     */   private final int maxMessageSize;
/*     */   @Nullable
/*     */   private DataBuffer output;
/*     */   private int messageBytesToRead;
/*     */   private int offset;
/*     */   
/*     */   public MessageDecoderFunction(ResolvableType elementType, int maxMessageSize) {
/* 205 */     this.elementType = elementType;
/* 206 */     this.maxMessageSize = maxMessageSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<? extends Message> apply(DataBuffer input) {
/*     */     try {
/* 213 */       List<Message> messages = new ArrayList<>();
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 218 */         if (this.output == null) {
/* 219 */           if (!readMessageSize(input)) {
/* 220 */             return messages;
/*     */           }
/* 222 */           if (this.maxMessageSize > 0 && this.messageBytesToRead > this.maxMessageSize) {
/* 223 */             throw new DataBufferLimitException("The number of bytes to read for message (" + this.messageBytesToRead + ") exceeds the configured limit (" + this.maxMessageSize + ")");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 228 */           this.output = input.factory().allocateBuffer(this.messageBytesToRead);
/*     */         } 
/*     */         
/* 231 */         int chunkBytesToRead = Math.min(this.messageBytesToRead, input.readableByteCount());
/* 232 */         int remainingBytesToRead = input.readableByteCount() - chunkBytesToRead;
/*     */         
/* 234 */         byte[] bytesToWrite = new byte[chunkBytesToRead];
/* 235 */         input.read(bytesToWrite, 0, chunkBytesToRead);
/* 236 */         this.output.write(bytesToWrite);
/* 237 */         this.messageBytesToRead -= chunkBytesToRead;
/*     */         
/* 239 */         if (this.messageBytesToRead == 0) {
/* 240 */           ByteBuffer byteBuffer = ByteBuffer.allocate(this.output.readableByteCount());
/* 241 */           this.output.toByteBuffer(byteBuffer);
/* 242 */           CodedInputStream stream = CodedInputStream.newInstance(byteBuffer);
/* 243 */           DataBufferUtils.release(this.output);
/* 244 */           this.output = null;
/*     */ 
/*     */           
/* 247 */           Message message = ProtobufDecoder.getMessageBuilder(this.elementType.toClass()).mergeFrom(stream, (ExtensionRegistryLite)ProtobufDecoder.this.extensionRegistry).build();
/* 248 */           messages.add(message);
/*     */         } 
/* 250 */         if (remainingBytesToRead <= 0)
/* 251 */           return messages; 
/*     */       } 
/* 253 */     } catch (DecodingException ex) {
/* 254 */       throw ex;
/*     */     }
/* 256 */     catch (IOException ex) {
/* 257 */       throw new DecodingException("I/O error while parsing input stream", ex);
/*     */     }
/* 259 */     catch (Exception ex) {
/* 260 */       throw new DecodingException("Could not read Protobuf message: " + ex.getMessage(), ex);
/*     */     } finally {
/*     */       
/* 263 */       DataBufferUtils.release(input);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readMessageSize(DataBuffer input) {
/* 276 */     if (this.offset == 0) {
/* 277 */       if (input.readableByteCount() == 0) {
/* 278 */         return false;
/*     */       }
/* 280 */       int firstByte = input.read();
/* 281 */       if ((firstByte & 0x80) == 0) {
/* 282 */         this.messageBytesToRead = firstByte;
/* 283 */         return true;
/*     */       } 
/* 285 */       this.messageBytesToRead = firstByte & 0x7F;
/* 286 */       this.offset = 7;
/*     */     } 
/*     */     
/* 289 */     if (this.offset < 32) {
/* 290 */       for (; this.offset < 32; this.offset += 7) {
/* 291 */         if (input.readableByteCount() == 0) {
/* 292 */           return false;
/*     */         }
/* 294 */         int b = input.read();
/* 295 */         this.messageBytesToRead |= (b & 0x7F) << this.offset;
/* 296 */         if ((b & 0x80) == 0) {
/* 297 */           this.offset = 0;
/* 298 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 303 */     for (; this.offset < 64; this.offset += 7) {
/* 304 */       if (input.readableByteCount() == 0) {
/* 305 */         return false;
/*     */       }
/* 307 */       int b = input.read();
/* 308 */       if ((b & 0x80) == 0) {
/* 309 */         this.offset = 0;
/* 310 */         return true;
/*     */       } 
/*     */     } 
/* 313 */     this.offset = 0;
/* 314 */     throw new DecodingException("Cannot parse message size: malformed varint");
/*     */   }
/*     */   
/*     */   public void discard() {
/* 318 */     if (this.output != null)
/* 319 */       DataBufferUtils.release(this.output); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\protobuf\ProtobufDecoder$MessageDecoderFunction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */