/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.Decoder;
/*     */ import org.springframework.core.codec.StringDecoder;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferLimitException;
/*     */ import org.springframework.core.io.buffer.DefaultDataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSentEventHttpMessageReader
/*     */   implements HttpMessageReader<Object>
/*     */ {
/*  50 */   private static final ResolvableType STRING_TYPE = ResolvableType.forClass(String.class);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Decoder<?> decoder;
/*     */   
/*  56 */   private final StringDecoder lineDecoder = StringDecoder.textPlainOnly();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerSentEventHttpMessageReader() {
/*  64 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerSentEventHttpMessageReader(@Nullable Decoder<?> decoder) {
/*  72 */     this.decoder = decoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Decoder<?> getDecoder() {
/*  81 */     return this.decoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxInMemorySize(int byteCount) {
/*  95 */     this.lineDecoder.setMaxInMemorySize(byteCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxInMemorySize() {
/* 103 */     return this.lineDecoder.getMaxInMemorySize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MediaType> getReadableMediaTypes() {
/* 109 */     return Collections.singletonList(MediaType.TEXT_EVENT_STREAM);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 114 */     return (MediaType.TEXT_EVENT_STREAM.includes(mediaType) || isServerSentEvent(elementType));
/*     */   }
/*     */   
/*     */   private boolean isServerSentEvent(ResolvableType elementType) {
/* 118 */     return ServerSentEvent.class.isAssignableFrom(elementType.toClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<Object> read(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 126 */     LimitTracker limitTracker = new LimitTracker();
/*     */     
/* 128 */     boolean shouldWrap = isServerSentEvent(elementType);
/* 129 */     ResolvableType valueType = shouldWrap ? elementType.getGeneric(new int[0]) : elementType;
/*     */ 
/*     */     
/* 132 */     Objects.requireNonNull(limitTracker); return this.lineDecoder.decode((Publisher)message.getBody(), STRING_TYPE, null, hints).doOnNext(limitTracker::afterLineParsed)
/* 133 */       .bufferUntil(String::isEmpty)
/* 134 */       .concatMap(lines -> {
/*     */           Object event = buildEvent(lines, valueType, shouldWrap, hints);
/*     */           return (event != null) ? (Publisher)Mono.just(event) : (Publisher)Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object buildEvent(List<String> lines, ResolvableType valueType, boolean shouldWrap, Map<String, Object> hints) {
/* 145 */     ServerSentEvent.Builder<Object> sseBuilder = shouldWrap ? ServerSentEvent.<Object>builder() : null;
/* 146 */     StringBuilder data = null;
/* 147 */     StringBuilder comment = null;
/*     */     
/* 149 */     for (String line : lines) {
/* 150 */       if (line.startsWith("data:")) {
/* 151 */         int length = line.length();
/* 152 */         if (length > 5) {
/* 153 */           int index = (line.charAt(5) != ' ') ? 5 : 6;
/* 154 */           if (length > index) {
/* 155 */             data = (data != null) ? data : new StringBuilder();
/* 156 */             data.append(line, index, line.length());
/* 157 */             data.append('\n');
/*     */           } 
/*     */         }  continue;
/*     */       } 
/* 161 */       if (shouldWrap) {
/* 162 */         if (line.startsWith("id:")) {
/* 163 */           sseBuilder.id(line.substring(3).trim()); continue;
/*     */         } 
/* 165 */         if (line.startsWith("event:")) {
/* 166 */           sseBuilder.event(line.substring(6).trim()); continue;
/*     */         } 
/* 168 */         if (line.startsWith("retry:")) {
/* 169 */           sseBuilder.retry(Duration.ofMillis(Long.parseLong(line.substring(6).trim()))); continue;
/*     */         } 
/* 171 */         if (line.startsWith(":")) {
/* 172 */           comment = (comment != null) ? comment : new StringBuilder();
/* 173 */           comment.append(line.substring(1).trim()).append('\n');
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     Object decodedData = (data != null) ? decodeData(data, valueType, hints) : null;
/*     */     
/* 180 */     if (shouldWrap) {
/* 181 */       if (comment != null) {
/* 182 */         sseBuilder.comment(comment.substring(0, comment.length() - 1));
/*     */       }
/* 184 */       if (decodedData != null) {
/* 185 */         sseBuilder.data(decodedData);
/*     */       }
/* 187 */       return sseBuilder.build();
/*     */     } 
/*     */     
/* 190 */     return decodedData;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object decodeData(StringBuilder data, ResolvableType dataType, Map<String, Object> hints) {
/* 196 */     if (String.class == dataType.resolve()) {
/* 197 */       return data.substring(0, data.length() - 1);
/*     */     }
/* 199 */     if (this.decoder == null) {
/* 200 */       throw new CodecException("No SSE decoder configured and the data is not String.");
/*     */     }
/* 202 */     byte[] bytes = data.toString().getBytes(StandardCharsets.UTF_8);
/* 203 */     DefaultDataBuffer defaultDataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
/* 204 */     return this.decoder.decode((DataBuffer)defaultDataBuffer, dataType, (MimeType)MediaType.TEXT_EVENT_STREAM, hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> readMono(ResolvableType elementType, ReactiveHttpInputMessage message, Map<String, Object> hints) {
/* 214 */     if (elementType.resolve() == String.class) {
/* 215 */       Flux<DataBuffer> body = message.getBody();
/* 216 */       return this.lineDecoder.decodeToMono((Publisher)body, elementType, null, null).cast(Object.class);
/*     */     } 
/*     */     
/* 219 */     return Mono.error(new UnsupportedOperationException("ServerSentEventHttpMessageReader only supports reading stream of events as a Flux"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class LimitTracker
/*     */   {
/* 226 */     private int accumulated = 0;
/*     */     
/*     */     public void afterLineParsed(String line) {
/* 229 */       if (ServerSentEventHttpMessageReader.this.getMaxInMemorySize() < 0) {
/*     */         return;
/*     */       }
/* 232 */       if (line.isEmpty()) {
/* 233 */         this.accumulated = 0;
/*     */       }
/* 235 */       if (line.length() > Integer.MAX_VALUE - this.accumulated) {
/* 236 */         raiseLimitException();
/*     */       } else {
/*     */         
/* 239 */         this.accumulated += line.length();
/* 240 */         if (this.accumulated > ServerSentEventHttpMessageReader.this.getMaxInMemorySize()) {
/* 241 */           raiseLimitException();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void raiseLimitException() {
/* 248 */       throw new DataBufferLimitException("Exceeded limit on max bytes to buffer : " + ServerSentEventHttpMessageReader.this.getMaxInMemorySize());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerSentEventHttpMessageReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */