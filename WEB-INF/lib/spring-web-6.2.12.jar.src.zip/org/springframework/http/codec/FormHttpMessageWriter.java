/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormHttpMessageWriter
/*     */   extends LoggingCodecSupport
/*     */   implements HttpMessageWriter<MultiValueMap<String, String>>
/*     */ {
/*  64 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/*  67 */   private static final List<MediaType> MEDIA_TYPES = Collections.singletonList(MediaType.APPLICATION_FORM_URLENCODED);
/*     */ 
/*     */   
/*  70 */   private static final ResolvableType MULTIVALUE_TYPE = ResolvableType.forClassWithGenerics(MultiValueMap.class, new Class[] { String.class, String.class });
/*     */ 
/*     */   
/*  73 */   private Charset defaultCharset = DEFAULT_CHARSET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(Charset charset) {
/*  82 */     Assert.notNull(charset, "Charset must not be null");
/*  83 */     this.defaultCharset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getDefaultCharset() {
/*  90 */     return this.defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MediaType> getWritableMediaTypes() {
/*  96 */     return MEDIA_TYPES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 102 */     if (!MultiValueMap.class.isAssignableFrom(elementType.toClass())) {
/* 103 */       return false;
/*     */     }
/* 105 */     if (MediaType.APPLICATION_FORM_URLENCODED.isCompatibleWith(mediaType))
/*     */     {
/* 107 */       return true;
/*     */     }
/* 109 */     if (mediaType == null)
/*     */     {
/* 111 */       return MULTIVALUE_TYPE.isAssignableFrom(elementType);
/*     */     }
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends MultiValueMap<String, String>> inputStream, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 121 */     mediaType = getMediaType(mediaType);
/* 122 */     message.getHeaders().setContentType(mediaType);
/*     */     
/* 124 */     Charset charset = (mediaType.getCharset() != null) ? mediaType.getCharset() : getDefaultCharset();
/*     */     
/* 126 */     return Mono.from(inputStream).flatMap(form -> {
/*     */           logFormData(form, hints);
/*     */           String value = serializeForm(form, charset);
/*     */           ByteBuffer byteBuffer = charset.encode(value);
/*     */           DataBuffer buffer = message.bufferFactory().wrap(byteBuffer);
/*     */           message.getHeaders().setContentLength(byteBuffer.remaining());
/*     */           return message.writeWith((Publisher)Mono.just(buffer));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MediaType getMediaType(@Nullable MediaType mediaType) {
/* 143 */     if (mediaType == null) {
/* 144 */       return MediaType.APPLICATION_FORM_URLENCODED;
/*     */     }
/*     */ 
/*     */     
/* 148 */     if (mediaType.getCharset() == null && this.defaultCharset != DEFAULT_CHARSET) {
/* 149 */       return new MediaType(mediaType, this.defaultCharset);
/*     */     }
/* 151 */     return mediaType;
/*     */   }
/*     */   
/*     */   private void logFormData(MultiValueMap<String, String> form, Map<String, Object> hints) {
/* 155 */     LogFormatUtils.traceDebug(this.logger, traceOn -> Hints.getLogPrefix(hints) + "Writing " + Hints.getLogPrefix(hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String serializeForm(MultiValueMap<String, String> formData, Charset charset) {
/* 162 */     StringBuilder builder = new StringBuilder();
/* 163 */     formData.forEach((name, values) -> values.forEach(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\FormHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */