package org.springframework.http.codec;

import java.util.function.Consumer;
import org.springframework.core.codec.Decoder;
import org.springframework.core.codec.Encoder;

public interface CustomCodecs {
  void register(Object paramObject);
  
  void registerWithDefaultConfig(Object paramObject);
  
  void registerWithDefaultConfig(Object paramObject, Consumer<CodecConfigurer.DefaultCodecConfig> paramConsumer);
  
  @Deprecated
  void decoder(Decoder<?> paramDecoder);
  
  @Deprecated
  void encoder(Encoder<?> paramEncoder);
  
  @Deprecated
  void reader(HttpMessageReader<?> paramHttpMessageReader);
  
  @Deprecated
  void writer(HttpMessageWriter<?> paramHttpMessageWriter);
  
  @Deprecated
  void withDefaultCodecConfig(Consumer<CodecConfigurer.DefaultCodecConfig> paramConsumer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\CodecConfigurer$CustomCodecs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */