package org.springframework.http.codec;

import org.springframework.core.codec.Decoder;

public interface ClientDefaultCodecs extends CodecConfigurer.DefaultCodecs {
  void serverSentEventDecoder(Decoder<?> paramDecoder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ClientCodecConfigurer$ClientDefaultCodecs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */