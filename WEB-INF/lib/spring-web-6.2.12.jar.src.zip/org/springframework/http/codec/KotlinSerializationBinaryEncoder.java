/*    */ package org.springframework.http.codec;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.KSerializer;
/*    */ import kotlinx.serialization.SerializationStrategy;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.codec.ByteArrayEncoder;
/*    */ import org.springframework.core.codec.Encoder;
/*    */ import org.springframework.core.codec.EncodingException;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MimeType;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KotlinSerializationBinaryEncoder<T extends BinaryFormat>
/*    */   extends KotlinSerializationSupport<T>
/*    */   implements Encoder<Object>
/*    */ {
/* 51 */   private final ByteArrayEncoder byteArrayEncoder = new ByteArrayEncoder();
/*    */   
/*    */   protected KotlinSerializationBinaryEncoder(T format, MimeType... supportedMimeTypes) {
/* 54 */     super(format, supportedMimeTypes);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canEncode(ResolvableType elementType, @Nullable MimeType mimeType) {
/* 59 */     return canSerialize(elementType, mimeType);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<MimeType> getEncodableMimeTypes() {
/* 64 */     return supportedMimeTypes();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<MimeType> getEncodableMimeTypes(ResolvableType elementType) {
/* 69 */     return supportedMimeTypes();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<DataBuffer> encode(Publisher<?> inputStream, DataBufferFactory bufferFactory, ResolvableType elementType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 76 */     if (inputStream instanceof Mono) {
/* 77 */       return Mono.from(inputStream)
/* 78 */         .map(value -> encodeValue(value, bufferFactory, elementType, mimeType, hints))
/* 79 */         .flux();
/*    */     }
/*    */     
/* 82 */     ResolvableType listType = ResolvableType.forClassWithGenerics(List.class, new ResolvableType[] { elementType });
/* 83 */     return Flux.from(inputStream)
/* 84 */       .collectList()
/* 85 */       .map(list -> encodeValue(list, bufferFactory, listType, mimeType, hints))
/* 86 */       .flux();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataBuffer encodeValue(Object value, DataBufferFactory bufferFactory, ResolvableType valueType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints) {
/* 94 */     KSerializer<Object> serializer = serializer(valueType);
/* 95 */     if (serializer == null) {
/* 96 */       throw new EncodingException("Could not find KSerializer for " + String.valueOf(valueType));
/*    */     }
/* 98 */     byte[] bytes = ((BinaryFormat)format()).encodeToByteArray((SerializationStrategy)serializer, value);
/* 99 */     return this.byteArrayEncoder.encodeValue(bytes, bufferFactory, valueType, mimeType, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\KotlinSerializationBinaryEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */