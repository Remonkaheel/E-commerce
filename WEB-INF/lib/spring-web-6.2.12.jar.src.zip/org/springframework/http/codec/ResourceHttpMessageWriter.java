/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.codec.ResourceEncoder;
/*     */ import org.springframework.core.codec.ResourceRegionEncoder;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpMessageWriter
/*     */   implements HttpMessageWriter<Resource>
/*     */ {
/*  74 */   private static final ResolvableType REGION_TYPE = ResolvableType.forClass(ResourceRegion.class);
/*     */   
/*  76 */   private static final Log logger = HttpLogging.forLogName(ResourceHttpMessageWriter.class);
/*     */ 
/*     */   
/*     */   private final ResourceEncoder encoder;
/*     */   
/*     */   private final ResourceRegionEncoder regionEncoder;
/*     */   
/*     */   private final List<MediaType> mediaTypes;
/*     */ 
/*     */   
/*     */   public ResourceHttpMessageWriter() {
/*  87 */     this(8192);
/*     */   }
/*     */   
/*     */   public ResourceHttpMessageWriter(int bufferSize) {
/*  91 */     this.encoder = new ResourceEncoder(bufferSize);
/*  92 */     this.regionEncoder = new ResourceRegionEncoder(bufferSize);
/*  93 */     this.mediaTypes = MediaType.asMediaTypes(this.encoder.getEncodableMimeTypes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/*  99 */     return this.encoder.canEncode(elementType, (MimeType)mediaType);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getWritableMediaTypes() {
/* 104 */     return this.mediaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends Resource> inputStream, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 114 */     return Mono.from(inputStream).flatMap(resource -> writeResource(resource, elementType, mediaType, message, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> writeResource(Resource resource, ResolvableType type, @Nullable MediaType mediaType, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 121 */     return addDefaultHeaders(message, resource, mediaType, hints)
/* 122 */       .then(Mono.defer(() -> {
/*     */             Mono<Void> result = zeroCopy(resource, null, message, hints);
/*     */             if (result != null) {
/*     */               return result;
/*     */             }
/*     */             Mono<Resource> input = Mono.just(resource);
/*     */             DataBufferFactory factory = message.bufferFactory();
/*     */             MediaType contentType = message.getHeaders().getContentType();
/*     */             Flux<DataBuffer> body = this.encoder.encode((Publisher)input, factory, type, (MimeType)contentType, hints).subscribeOn(Schedulers.boundedElastic());
/*     */             if (logger.isDebugEnabled()) {
/*     */               body = body.doOnNext(());
/*     */             }
/*     */             return message.writeWith((Publisher)body);
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> addDefaultHeaders(ReactiveHttpOutputMessage message, Resource resource, @Nullable MediaType contentType, Map<String, Object> hints) {
/* 151 */     return Mono.defer(() -> {
/*     */           HttpHeaders headers = message.getHeaders();
/*     */           MediaType resourceMediaType = getResourceMediaType(contentType, resource, hints);
/*     */           headers.setContentType(resourceMediaType);
/*     */           if (message instanceof ServerHttpResponse) {
/*     */             headers.set("Accept-Ranges", "bytes");
/*     */           }
/*     */           return (headers.getContentLength() >= 0L) ? Mono.empty() : lengthOf(resource).flatMap(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MediaType getResourceMediaType(@Nullable MediaType mediaType, Resource resource, Map<String, Object> hints) {
/* 175 */     if (mediaType != null && mediaType.isConcrete() && !mediaType.equals(MediaType.APPLICATION_OCTET_STREAM)) {
/* 176 */       return mediaType;
/*     */     }
/* 178 */     mediaType = MediaTypeFactory.getMediaType(resource).orElse(MediaType.APPLICATION_OCTET_STREAM);
/* 179 */     if (logger.isDebugEnabled() && !Hints.isLoggingSuppressed(hints)) {
/* 180 */       logger.debug(Hints.getLogPrefix(hints) + "Resource associated with '" + Hints.getLogPrefix(hints) + "'");
/*     */     }
/* 182 */     return mediaType;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Mono<Long> lengthOf(Resource resource) {
/* 187 */     if (InputStreamResource.class != resource.getClass()) {
/* 188 */       Objects.requireNonNull(resource); return Mono.fromCallable(resource::contentLength)
/* 189 */         .filter(length -> (length.longValue() != -1L))
/* 190 */         .onErrorComplete(IOException.class)
/* 191 */         .subscribeOn(Schedulers.boundedElastic());
/*     */     } 
/*     */     
/* 194 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Mono<Void> zeroCopy(Resource resource, @Nullable ResourceRegion region, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 202 */     if (message instanceof ZeroCopyHttpOutputMessage) { ZeroCopyHttpOutputMessage zeroCopyHttpOutputMessage = (ZeroCopyHttpOutputMessage)message; if (resource.isFile()) {
/*     */         try {
/* 204 */           File file = resource.getFile();
/* 205 */           long pos = (region != null) ? region.getPosition() : 0L;
/* 206 */           long count = (region != null) ? region.getCount() : file.length();
/* 207 */           if (logger.isDebugEnabled()) {
/* 208 */             String formatted = (region != null) ? ("region " + pos + "-" + count + " of ") : "";
/* 209 */             logger.debug(Hints.getLogPrefix(hints) + "Zero-copy " + Hints.getLogPrefix(hints) + "[" + formatted + "]");
/*     */           } 
/* 211 */           return zeroCopyHttpOutputMessage.writeWith(file, pos, count);
/*     */         }
/* 213 */         catch (IOException|UnsupportedOperationException iOException) {}
/*     */       } }
/*     */ 
/*     */     
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<? extends Resource> inputStream, @Nullable ResolvableType actualType, ResolvableType elementType, @Nullable MediaType mediaType, ServerHttpRequest request, ServerHttpResponse response, Map<String, Object> hints) {
/*     */     List<HttpRange> ranges;
/* 228 */     HttpHeaders headers = response.getHeaders();
/* 229 */     headers.set("Accept-Ranges", "bytes");
/*     */ 
/*     */     
/*     */     try {
/* 233 */       ranges = request.getHeaders().getRange();
/*     */     }
/* 235 */     catch (IllegalArgumentException ex) {
/* 236 */       return handleInvalidRange(response);
/*     */     } 
/*     */     
/* 239 */     return Mono.from(inputStream).flatMap(resource -> {
/*     */           List<ResourceRegion> regions;
/*     */           
/*     */           if (ranges.isEmpty()) {
/*     */             return writeResource(resource, elementType, mediaType, (ReactiveHttpOutputMessage)response, hints);
/*     */           }
/*     */           response.setStatusCode((HttpStatusCode)HttpStatus.PARTIAL_CONTENT);
/*     */           try {
/*     */             regions = HttpRange.toResourceRegions(ranges, resource);
/* 248 */           } catch (IllegalArgumentException ex) {
/*     */             return handleInvalidRange(response);
/*     */           } 
/*     */           MediaType resourceMediaType = getResourceMediaType(mediaType, resource, hints);
/*     */           if (regions.size() == 1) {
/*     */             ResourceRegion region = regions.get(0);
/*     */             headers.setContentType(resourceMediaType);
/*     */             return lengthOf(resource).flatMap(()).then(writeSingleRegion(region, (ReactiveHttpOutputMessage)response, hints));
/*     */           } 
/*     */           String boundary = MimeTypeUtils.generateMultipartBoundaryString();
/*     */           MediaType multipartType = MediaType.parseMediaType("multipart/byteranges;boundary=" + boundary);
/*     */           headers.setContentType(multipartType);
/*     */           Map<String, Object> allHints = Hints.merge(hints, ResourceRegionEncoder.BOUNDARY_STRING_HINT, boundary);
/*     */           return encodeAndWriteRegions((Publisher<? extends ResourceRegion>)Flux.fromIterable(regions), resourceMediaType, (ReactiveHttpOutputMessage)response, allHints);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Mono<Void> handleInvalidRange(ServerHttpResponse response) {
/* 277 */     response.setStatusCode((HttpStatusCode)HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE);
/* 278 */     return response.setComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> writeSingleRegion(ResourceRegion region, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 284 */     Mono<Void> result = zeroCopy(region.getResource(), region, message, hints);
/* 285 */     if (result != null) {
/* 286 */       return result;
/*     */     }
/*     */     
/* 289 */     Mono mono = Mono.just(region);
/* 290 */     MediaType mediaType = message.getHeaders().getContentType();
/* 291 */     return encodeAndWriteRegions((Publisher<? extends ResourceRegion>)mono, mediaType, message, hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> encodeAndWriteRegions(Publisher<? extends ResourceRegion> publisher, @Nullable MediaType mediaType, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 300 */     Flux<DataBuffer> body = this.regionEncoder.encode(publisher, message.bufferFactory(), REGION_TYPE, (MimeType)mediaType, hints).subscribeOn(Schedulers.boundedElastic());
/*     */     
/* 302 */     return message.writeWith((Publisher)body);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ResourceHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */