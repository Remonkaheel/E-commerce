package org.springframework.http.codec;

import org.springframework.lang.Nullable;

public interface DefaultCodecConfig {
  @Nullable
  Integer maxInMemorySize();
  
  @Nullable
  Boolean isEnableLoggingRequestDetails();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\CodecConfigurer$DefaultCodecConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */