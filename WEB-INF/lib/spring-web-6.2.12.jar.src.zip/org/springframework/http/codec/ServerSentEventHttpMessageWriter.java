/*     */ package org.springframework.http.codec;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.codec.CodecException;
/*     */ import org.springframework.core.codec.Encoder;
/*     */ import org.springframework.core.codec.Hints;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ReactiveHttpOutputMessage;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSentEventHttpMessageWriter
/*     */   implements HttpMessageWriter<Object>
/*     */ {
/*  55 */   private static final MediaType DEFAULT_MEDIA_TYPE = new MediaType("text", "event-stream", StandardCharsets.UTF_8);
/*     */   
/*  57 */   private static final List<MediaType> WRITABLE_MEDIA_TYPES = Collections.singletonList(MediaType.TEXT_EVENT_STREAM);
/*     */   
/*  59 */   private static final Log logger = HttpLogging.forLogName(ServerSentEventHttpMessageWriter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Encoder<?> encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerSentEventHttpMessageWriter() {
/*  71 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerSentEventHttpMessageWriter(@Nullable Encoder<?> encoder) {
/*  80 */     this.encoder = encoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Encoder<?> getEncoder() {
/*  89 */     return this.encoder;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getWritableMediaTypes() {
/*  94 */     return WRITABLE_MEDIA_TYPES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType elementType, @Nullable MediaType mediaType) {
/* 100 */     return (mediaType == null || MediaType.TEXT_EVENT_STREAM.includes(mediaType) || ServerSentEvent.class
/* 101 */       .isAssignableFrom(elementType.toClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<?> input, ResolvableType elementType, @Nullable MediaType mediaType, ReactiveHttpOutputMessage message, Map<String, Object> hints) {
/* 108 */     mediaType = (mediaType != null && mediaType.getCharset() != null) ? mediaType : DEFAULT_MEDIA_TYPE;
/* 109 */     DataBufferFactory bufferFactory = message.bufferFactory();
/*     */     
/* 111 */     message.getHeaders().setContentType(mediaType);
/* 112 */     return message.writeAndFlushWith((Publisher)encode(input, elementType, mediaType, bufferFactory, hints));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Flux<Publisher<DataBuffer>> encode(Publisher<?> input, ResolvableType elementType, MediaType mediaType, DataBufferFactory factory, Map<String, Object> hints) {
/* 119 */     ResolvableType dataType = ServerSentEvent.class.isAssignableFrom(elementType.toClass()) ? elementType.getGeneric(new int[0]) : elementType;
/*     */     
/* 121 */     return Flux.from(input).map(element -> {
/*     */           Flux<DataBuffer> result;
/*     */           ServerSentEvent<?> serverSentEvent = (ServerSentEvent)element;
/*     */           ServerSentEvent<?> sse = (element instanceof ServerSentEvent) ? serverSentEvent : ServerSentEvent.builder().data(element).build();
/*     */           String sseText = sse.format();
/*     */           Object data = sse.data();
/*     */           if (data == null) {
/*     */             result = Flux.just(encodeText(sseText + "\n", mediaType, factory));
/*     */           } else if (data instanceof String) {
/*     */             String text = (String)data;
/*     */             text = StringUtils.replace(text, "\n", "\ndata:");
/*     */             result = Flux.just(encodeText(sseText + sseText + "\n\n", mediaType, factory));
/*     */           } else {
/*     */             result = encodeEvent(sseText, data, dataType, mediaType, factory, hints);
/*     */           } 
/*     */           return (Publisher)result.doOnDiscard(DataBuffer.class, DataBufferUtils::release);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> Flux<DataBuffer> encodeEvent(CharSequence sseText, T data, ResolvableType dataType, MediaType mediaType, DataBufferFactory factory, Map<String, Object> hints) {
/* 149 */     if (this.encoder == null) {
/* 150 */       throw new CodecException("No SSE encoder configured and the data is not String.");
/*     */     }
/*     */     
/* 153 */     return Flux.defer(() -> {
/*     */           DataBuffer startBuffer = encodeText(sseText, mediaType, factory);
/*     */           DataBuffer endBuffer = encodeText("\n\n", mediaType, factory);
/*     */           DataBuffer dataBuffer = this.encoder.encodeValue(data, factory, dataType, (MimeType)mediaType, hints);
/*     */           Hints.touchDataBuffer(dataBuffer, hints, logger);
/*     */           return (Publisher)Flux.just((Object[])new DataBuffer[] { startBuffer, dataBuffer, endBuffer });
/*     */         });
/*     */   }
/*     */   
/*     */   private DataBuffer encodeText(CharSequence text, MediaType mediaType, DataBufferFactory bufferFactory) {
/* 163 */     Assert.notNull(mediaType.getCharset(), "Expected MediaType with charset");
/* 164 */     byte[] bytes = text.toString().getBytes(mediaType.getCharset());
/* 165 */     return bufferFactory.wrap(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> write(Publisher<?> input, ResolvableType actualType, ResolvableType elementType, @Nullable MediaType mediaType, ServerHttpRequest request, ServerHttpResponse response, Map<String, Object> hints) {
/* 173 */     Map<String, Object> allHints = Hints.merge(hints, 
/* 174 */         getEncodeHints(actualType, elementType, mediaType, request, response));
/*     */     
/* 176 */     return write(input, elementType, mediaType, (ReactiveHttpOutputMessage)response, allHints);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getEncodeHints(ResolvableType actualType, ResolvableType elementType, @Nullable MediaType mediaType, ServerHttpRequest request, ServerHttpResponse response) {
/* 182 */     Encoder<?> encoder = this.encoder; if (encoder instanceof HttpMessageEncoder) { HttpMessageEncoder<?> httpMessageEncoder = (HttpMessageEncoder)encoder;
/* 183 */       return httpMessageEncoder.getEncodeHints(actualType, elementType, mediaType, request, response); }
/*     */     
/* 185 */     return Hints.none();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerSentEventHttpMessageWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */