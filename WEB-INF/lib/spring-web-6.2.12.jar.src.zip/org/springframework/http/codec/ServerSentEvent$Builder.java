package org.springframework.http.codec;

import java.time.Duration;
import org.springframework.lang.Nullable;

public interface Builder<T> {
  Builder<T> id(String paramString);
  
  Builder<T> event(String paramString);
  
  Builder<T> retry(Duration paramDuration);
  
  Builder<T> comment(String paramString);
  
  Builder<T> data(@Nullable T paramT);
  
  ServerSentEvent<T> build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\codec\ServerSentEvent$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */