/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<String>
/*     */ {
/*  46 */   private static final MediaType APPLICATION_PLUS_JSON = new MediaType("application", "*+json");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.ISO_8859_1;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile List<Charset> availableCharsets;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean writeAcceptCharset = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public StringHttpMessageConverter() {
/*  65 */     this(DEFAULT_CHARSET);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringHttpMessageConverter(Charset defaultCharset) {
/*  73 */     super(defaultCharset, new MediaType[] { MediaType.TEXT_PLAIN, MediaType.ALL });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteAcceptCharset(boolean writeAcceptCharset) {
/*  84 */     this.writeAcceptCharset = writeAcceptCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/*  90 */     return (String.class == clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String readInternal(Class<? extends String> clazz, HttpInputMessage inputMessage) throws IOException {
/*  95 */     Charset charset = getContentTypeCharset(inputMessage.getHeaders().getContentType());
/*  96 */     long length = inputMessage.getHeaders().getContentLength();
/*     */     
/*  98 */     byte[] bytes = (length >= 0L && length <= 2147483647L) ? inputMessage.getBody().readNBytes((int)length) : inputMessage.getBody().readAllBytes();
/*  99 */     return new String(bytes, charset);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Long getContentLength(String str, @Nullable MediaType contentType) {
/* 104 */     Charset charset = getContentTypeCharset(contentType);
/* 105 */     return Long.valueOf((str.getBytes(charset)).length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addDefaultHeaders(HttpHeaders headers, String s, @Nullable MediaType type) throws IOException {
/* 111 */     if (headers.getContentType() == null && 
/* 112 */       type != null && type.isConcrete() && (type.isCompatibleWith(MediaType.APPLICATION_JSON) || type
/* 113 */       .isCompatibleWith(APPLICATION_PLUS_JSON)))
/*     */     {
/* 115 */       headers.setContentType(type);
/*     */     }
/*     */     
/* 118 */     super.addDefaultHeaders(headers, s, type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeInternal(String str, HttpOutputMessage outputMessage) throws IOException {
/* 123 */     HttpHeaders headers = outputMessage.getHeaders();
/* 124 */     if (this.writeAcceptCharset && headers.get("Accept-Charset") == null) {
/* 125 */       headers.setAcceptCharset(getAcceptedCharsets());
/*     */     }
/* 127 */     Charset charset = getContentTypeCharset(headers.getContentType());
/* 128 */     StreamUtils.copy(str, charset, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Charset> getAcceptedCharsets() {
/* 139 */     List<Charset> charsets = this.availableCharsets;
/* 140 */     if (charsets == null) {
/* 141 */       charsets = new ArrayList<>(Charset.availableCharsets().values());
/* 142 */       this.availableCharsets = charsets;
/*     */     } 
/* 144 */     return charsets;
/*     */   }
/*     */   
/*     */   private Charset getContentTypeCharset(@Nullable MediaType contentType) {
/* 148 */     if (contentType != null) {
/* 149 */       Charset charset1 = contentType.getCharset();
/* 150 */       if (charset1 != null) {
/* 151 */         return charset1;
/*     */       }
/* 153 */       if (contentType.isCompatibleWith(MediaType.APPLICATION_JSON) || contentType
/* 154 */         .isCompatibleWith(APPLICATION_PLUS_JSON))
/*     */       {
/* 156 */         return StandardCharsets.UTF_8;
/*     */       }
/*     */     } 
/* 159 */     Charset charset = getDefaultCharset();
/* 160 */     Assert.state((charset != null), "No default charset");
/* 161 */     return charset;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(String s) {
/* 166 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\StringHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */