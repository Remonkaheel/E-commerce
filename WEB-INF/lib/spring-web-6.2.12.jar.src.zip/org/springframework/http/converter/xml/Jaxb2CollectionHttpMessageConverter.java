/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.xml.StaxUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jaxb2CollectionHttpMessageConverter<T extends Collection>
/*     */   extends AbstractJaxb2HttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*  71 */   private final XMLInputFactory inputFactory = createXmlInputFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Type type, @Nullable Class<?> contextClass, @Nullable MediaType mediaType) {
/*     */     ParameterizedType parameterizedType;
/*     */     Class<?> rawType, typeArgumentClass;
/*  91 */     if (type instanceof ParameterizedType) { parameterizedType = (ParameterizedType)type; }
/*  92 */     else { return false; }
/*     */     
/*  94 */     Type type1 = parameterizedType.getRawType(); if (type1 instanceof Class) { rawType = (Class)type1; }
/*  95 */     else { return false; }
/*     */     
/*  97 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  98 */       return false;
/*     */     }
/* 100 */     if ((parameterizedType.getActualTypeArguments()).length != 1) {
/* 101 */       return false;
/*     */     }
/* 103 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/* 104 */     if (typeArgument instanceof Class) { typeArgumentClass = (Class)typeArgument; }
/* 105 */     else { return false; }
/*     */     
/* 107 */     return ((typeArgumentClass.isAnnotationPresent((Class)XmlRootElement.class) || typeArgumentClass
/* 108 */       .isAnnotationPresent((Class)XmlType.class)) && canRead(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(@Nullable Type type, @Nullable Class<?> clazz, @Nullable MediaType mediaType) {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/* 132 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected T readFromSource(Class<? extends T> clazz, HttpHeaders headers, Source source) throws Exception {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T read(Type type, @Nullable Class<?> contextClass, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 146 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 147 */     T result = createCollection((Class)parameterizedType.getRawType());
/* 148 */     Class<?> elementClass = (Class)parameterizedType.getActualTypeArguments()[0];
/*     */     
/*     */     try {
/* 151 */       Unmarshaller unmarshaller = createUnmarshaller(elementClass);
/* 152 */       Charset detectedCharset = detectCharset(inputMessage.getHeaders());
/*     */ 
/*     */       
/* 155 */       XMLStreamReader streamReader = (detectedCharset != null) ? this.inputFactory.createXMLStreamReader(inputMessage.getBody(), detectedCharset.name()) : this.inputFactory.createXMLStreamReader(inputMessage.getBody());
/* 156 */       int event = moveToFirstChildOfRootElement(streamReader);
/*     */       
/* 158 */       while (event != 8) {
/* 159 */         if (elementClass.isAnnotationPresent((Class)XmlRootElement.class)) {
/* 160 */           result.add(unmarshaller.unmarshal(streamReader));
/*     */         }
/* 162 */         else if (elementClass.isAnnotationPresent((Class)XmlType.class)) {
/* 163 */           result.add(unmarshaller.unmarshal(streamReader, elementClass).getValue());
/*     */         }
/*     */         else {
/*     */           
/* 167 */           throw new HttpMessageNotReadableException("Cannot unmarshal to [" + String.valueOf(elementClass) + "]", inputMessage);
/*     */         } 
/*     */         
/* 170 */         event = moveToNextElement(streamReader);
/*     */       } 
/* 172 */       return result;
/*     */     }
/* 174 */     catch (XMLStreamException ex) {
/* 175 */       throw new HttpMessageNotReadableException("Failed to read XML stream: " + ex
/* 176 */           .getMessage(), ex, inputMessage);
/*     */     }
/* 178 */     catch (UnmarshalException ex) {
/* 179 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + String.valueOf(elementClass) + "]: " + String.valueOf(ex), ex, inputMessage);
/*     */     
/*     */     }
/* 182 */     catch (JAXBException ex) {
/* 183 */       throw new HttpMessageConversionException("Invalid JAXB setup: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T createCollection(Class<?> collectionClass) {
/* 195 */     if (!collectionClass.isInterface()) {
/*     */       try {
/* 197 */         return (T)ReflectionUtils.accessibleConstructor(collectionClass, new Class[0]).newInstance(new Object[0]);
/*     */       }
/* 199 */       catch (Throwable ex) {
/* 200 */         throw new IllegalArgumentException("Could not instantiate collection class: " + collectionClass
/* 201 */             .getName(), ex);
/*     */       } 
/*     */     }
/* 204 */     if (List.class == collectionClass) {
/* 205 */       return (T)new ArrayList();
/*     */     }
/* 207 */     if (SortedSet.class == collectionClass) {
/* 208 */       return (T)new TreeSet();
/*     */     }
/*     */     
/* 211 */     return (T)new LinkedHashSet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int moveToFirstChildOfRootElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 217 */     int event = streamReader.next();
/* 218 */     while (event != 1) {
/* 219 */       event = streamReader.next();
/*     */     }
/*     */ 
/*     */     
/* 223 */     event = streamReader.next();
/* 224 */     while (event != 1 && event != 8) {
/* 225 */       event = streamReader.next();
/*     */     }
/* 227 */     return event;
/*     */   }
/*     */   
/*     */   private int moveToNextElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 231 */     int event = streamReader.getEventType();
/* 232 */     while (event != 1 && event != 8) {
/* 233 */       event = streamReader.next();
/*     */     }
/* 235 */     return event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(T t, @Nullable Type type, @Nullable MediaType contentType, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 242 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws Exception {
/* 247 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLInputFactory createXmlInputFactory() {
/* 259 */     return StaxUtils.createDefensiveInputFactory();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\Jaxb2CollectionHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */