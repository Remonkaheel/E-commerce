/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.oxm.Unmarshaller;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarshallingHttpMessageConverter
/*     */   extends AbstractXmlHttpMessageConverter<Object>
/*     */ {
/*     */   @Nullable
/*     */   private Marshaller marshaller;
/*     */   @Nullable
/*     */   private Unmarshaller unmarshaller;
/*     */   
/*     */   public MarshallingHttpMessageConverter() {}
/*     */   
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller) {
/*  70 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  71 */     this.marshaller = marshaller;
/*     */ 
/*     */     
/*  74 */     if (marshaller instanceof Unmarshaller) { Unmarshaller _unmarshaller = (Unmarshaller)marshaller;
/*  75 */       this.unmarshaller = _unmarshaller; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller, Unmarshaller unmarshaller) {
/*  86 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  87 */     Assert.notNull(unmarshaller, "Unmarshaller must not be null");
/*  88 */     this.marshaller = marshaller;
/*  89 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarshaller(Marshaller marshaller) {
/*  97 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnmarshaller(Unmarshaller unmarshaller) {
/* 104 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 110 */     return (canRead(mediaType) && this.unmarshaller != null && this.unmarshaller.supports(clazz));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 115 */     return (canWrite(mediaType) && this.marshaller != null && this.marshaller.supports(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/* 121 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws Exception {
/* 126 */     Assert.state((this.unmarshaller != null), "Property 'unmarshaller' is required");
/* 127 */     Object result = this.unmarshaller.unmarshal(source);
/* 128 */     if (!clazz.isInstance(result)) {
/* 129 */       throw new TypeMismatchException(result, clazz);
/*     */     }
/* 131 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeToResult(Object o, HttpHeaders headers, Result result) throws Exception {
/* 136 */     Assert.state((this.marshaller != null), "Property 'marshaller' is required");
/* 137 */     this.marshaller.marshal(o, result);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Object o) {
/* 142 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\MarshallingHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */