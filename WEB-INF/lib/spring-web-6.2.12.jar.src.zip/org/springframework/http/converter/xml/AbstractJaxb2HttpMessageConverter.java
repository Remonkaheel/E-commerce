/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJaxb2HttpMessageConverter<T>
/*     */   extends AbstractXmlHttpMessageConverter<T>
/*     */ {
/*  44 */   private final ConcurrentMap<Class<?>, JAXBContext> jaxbContexts = new ConcurrentHashMap<>(64);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Marshaller createMarshaller(Class<?> clazz) {
/*     */     try {
/*  55 */       JAXBContext jaxbContext = getJaxbContext(clazz);
/*  56 */       Marshaller marshaller = jaxbContext.createMarshaller();
/*  57 */       customizeMarshaller(marshaller);
/*  58 */       return marshaller;
/*     */     }
/*  60 */     catch (JAXBException ex) {
/*  61 */       throw new HttpMessageConversionException("Could not create Marshaller for class [" + String.valueOf(clazz) + "]: " + ex
/*  62 */           .getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeMarshaller(Marshaller marshaller) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Unmarshaller createUnmarshaller(Class<?> clazz) {
/*     */     try {
/*  84 */       JAXBContext jaxbContext = getJaxbContext(clazz);
/*  85 */       Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
/*  86 */       customizeUnmarshaller(unmarshaller);
/*  87 */       return unmarshaller;
/*     */     }
/*  89 */     catch (JAXBException ex) {
/*  90 */       throw new HttpMessageConversionException("Could not create Unmarshaller for class [" + String.valueOf(clazz) + "]: " + ex
/*  91 */           .getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeUnmarshaller(Unmarshaller unmarshaller) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JAXBContext getJaxbContext(Class<?> clazz) {
/* 112 */     return this.jaxbContexts.computeIfAbsent(clazz, key -> {
/*     */           
/*     */           try {
/*     */             return JAXBContext.newInstance(new Class[] { clazz });
/* 116 */           } catch (JAXBException ex) {
/*     */             throw new HttpMessageConversionException("Could not create JAXBContext for class [" + String.valueOf(clazz) + "]: " + ex.getMessage(), ex);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Charset detectCharset(HttpHeaders httpHeaders) {
/* 131 */     MediaType contentType = httpHeaders.getContentType();
/* 132 */     if (contentType != null && contentType.getCharset() != null) {
/* 133 */       return contentType.getCharset();
/*     */     }
/*     */     
/* 136 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\AbstractJaxb2HttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */