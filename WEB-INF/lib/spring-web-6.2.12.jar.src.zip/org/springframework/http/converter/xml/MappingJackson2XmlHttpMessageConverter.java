/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.dataformat.xml.XmlMapper;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingJackson2XmlHttpMessageConverter
/*    */   extends AbstractJackson2HttpMessageConverter
/*    */ {
/* 48 */   private static final List<MediaType> problemDetailMediaTypes = Collections.singletonList(MediaType.APPLICATION_PROBLEM_XML);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MappingJackson2XmlHttpMessageConverter() {
/* 56 */     this(Jackson2ObjectMapperBuilder.xml().build());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MappingJackson2XmlHttpMessageConverter(ObjectMapper objectMapper) {
/* 66 */     super(objectMapper, new MediaType[] { new MediaType("application", "xml", StandardCharsets.UTF_8), new MediaType("text", "xml", StandardCharsets.UTF_8), new MediaType("application", "*+xml", StandardCharsets.UTF_8) });
/*    */ 
/*    */     
/* 69 */     Assert.isInstanceOf(XmlMapper.class, objectMapper, "XmlMapper required");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setObjectMapper(ObjectMapper objectMapper) {
/* 79 */     Assert.isInstanceOf(XmlMapper.class, objectMapper, "XmlMapper required");
/* 80 */     super.setObjectMapper(objectMapper);
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<MediaType> getMediaTypesForProblemDetail() {
/* 85 */     return problemDetailMediaTypes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\MappingJackson2XmlHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */