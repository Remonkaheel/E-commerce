/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.MarshalException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jaxb2RootElementHttpMessageConverter
/*     */   extends AbstractJaxb2HttpMessageConverter<Object>
/*     */ {
/*     */   private boolean supportDtd = false;
/*     */   private boolean processExternalEntities = false;
/*     */   @Nullable
/*     */   private volatile SAXParserFactory sourceParserFactory;
/*     */   
/*     */   public void setSupportDtd(boolean supportDtd) {
/*  84 */     this.supportDtd = supportDtd;
/*  85 */     this.sourceParserFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupportDtd() {
/*  92 */     return this.supportDtd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessExternalEntities(boolean processExternalEntities) {
/* 102 */     this.processExternalEntities = processExternalEntities;
/* 103 */     if (processExternalEntities) {
/* 104 */       this.supportDtd = true;
/*     */     }
/* 106 */     this.sourceParserFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProcessExternalEntities() {
/* 113 */     return this.processExternalEntities;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 119 */     return ((clazz.isAnnotationPresent((Class)XmlRootElement.class) || clazz.isAnnotationPresent((Class)XmlType.class)) && 
/* 120 */       canRead(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 126 */     boolean supportedType = (JAXBElement.class.isAssignableFrom(clazz) || AnnotationUtils.findAnnotation(clazz, XmlRootElement.class) != null);
/* 127 */     return (supportedType && canWrite(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/* 133 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws Exception {
/*     */     try {
/* 139 */       source = processSource(source, detectCharset(headers));
/* 140 */       Unmarshaller unmarshaller = createUnmarshaller(clazz);
/* 141 */       if (clazz.isAnnotationPresent((Class)XmlRootElement.class)) {
/* 142 */         return unmarshaller.unmarshal(source);
/*     */       }
/*     */       
/* 145 */       JAXBElement<?> jaxbElement = unmarshaller.unmarshal(source, clazz);
/* 146 */       return jaxbElement.getValue();
/*     */     
/*     */     }
/* 149 */     catch (NullPointerException ex) {
/* 150 */       if (!isSupportDtd()) {
/* 151 */         throw new IllegalStateException("NPE while unmarshalling. This can happen due to the presence of DTD declarations which are disabled.", ex);
/*     */       }
/*     */       
/* 154 */       throw ex;
/*     */     }
/* 156 */     catch (UnmarshalException ex) {
/* 157 */       throw ex;
/*     */     }
/* 159 */     catch (JAXBException ex) {
/* 160 */       throw new HttpMessageConversionException("Invalid JAXB setup: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Source processSource(Source source, @Nullable Charset charset) {
/* 172 */     if (source instanceof StreamSource) { StreamSource streamSource = (StreamSource)source;
/* 173 */       InputSource inputSource = new InputSource(streamSource.getInputStream());
/* 174 */       if (charset != null) {
/* 175 */         inputSource.setEncoding(charset.name());
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 180 */         SAXParserFactory saxParserFactory = this.sourceParserFactory;
/* 181 */         if (saxParserFactory == null) {
/* 182 */           saxParserFactory = SAXParserFactory.newInstance();
/* 183 */           saxParserFactory.setNamespaceAware(true);
/* 184 */           saxParserFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", 
/* 185 */               !isSupportDtd());
/* 186 */           saxParserFactory.setFeature("http://xml.org/sax/features/external-general-entities", 
/* 187 */               isProcessExternalEntities());
/* 188 */           this.sourceParserFactory = saxParserFactory;
/*     */         } 
/* 190 */         SAXParser saxParser = saxParserFactory.newSAXParser();
/* 191 */         XMLReader xmlReader = saxParser.getXMLReader();
/* 192 */         if (!isProcessExternalEntities()) {
/* 193 */           xmlReader.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */         }
/* 195 */         return new SAXSource(xmlReader, inputSource);
/*     */       }
/* 197 */       catch (SAXException|javax.xml.parsers.ParserConfigurationException ex) {
/* 198 */         this.logger.warn("Processing of external entities could not be disabled", ex);
/* 199 */         return source;
/*     */       }  }
/*     */ 
/*     */     
/* 203 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeToResult(Object value, HttpHeaders headers, Result result) throws Exception {
/*     */     try {
/* 210 */       Class<?> clazz = getMarshallerType(value);
/* 211 */       Marshaller marshaller = createMarshaller(clazz);
/* 212 */       setCharset(headers.getContentType(), marshaller);
/* 213 */       marshaller.marshal(value, result);
/*     */     }
/* 215 */     catch (MarshalException ex) {
/* 216 */       throw ex;
/*     */     }
/* 218 */     catch (JAXBException ex) {
/* 219 */       throw new HttpMessageConversionException("Invalid JAXB setup: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class<?> getMarshallerType(Object value) {
/* 224 */     if (value instanceof JAXBElement) { JAXBElement<?> jaxbElement = (JAXBElement)value;
/* 225 */       return jaxbElement.getDeclaredType(); }
/*     */ 
/*     */     
/* 228 */     return ClassUtils.getUserClass(value);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCharset(@Nullable MediaType contentType, Marshaller marshaller) throws PropertyException {
/* 233 */     if (contentType != null && contentType.getCharset() != null) {
/* 234 */       marshaller.setProperty("jaxb.encoding", contentType.getCharset().name());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Object o) {
/* 240 */     return true;
/*     */   }
/*     */   
/*     */   private static final EntityResolver NO_OP_ENTITY_RESOLVER = (publicId, systemId) -> new InputSource(new StringReader(""));
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\Jaxb2RootElementHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */