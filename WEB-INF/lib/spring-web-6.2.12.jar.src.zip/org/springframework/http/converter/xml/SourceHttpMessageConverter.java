/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceHttpMessageConverter<T extends Source>
/*     */   extends AbstractHttpMessageConverter<T>
/*     */ {
/*     */   private static final EntityResolver NO_OP_ENTITY_RESOLVER = (publicId, systemId) -> new InputSource(new StringReader(""));
/*     */   private static final XMLResolver NO_OP_XML_RESOLVER = (publicID, systemID, base, ns) -> InputStream.nullInputStream();
/*  78 */   private static final Set<Class<?>> SUPPORTED_CLASSES = Set.of(DOMSource.class, SAXSource.class, StAXSource.class, StreamSource.class, Source.class);
/*     */ 
/*     */ 
/*     */   
/*  82 */   private final TransformerFactory transformerFactory = TransformerFactory.newInstance();
/*     */ 
/*     */   
/*     */   private boolean supportDtd = false;
/*     */ 
/*     */   
/*     */   private boolean processExternalEntities = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile DocumentBuilderFactory documentBuilderFactory;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile SAXParserFactory saxParserFactory;
/*     */   
/*     */   @Nullable
/*     */   private volatile XMLInputFactory xmlInputFactory;
/*     */ 
/*     */   
/*     */   public SourceHttpMessageConverter() {
/* 103 */     super(new MediaType[] { MediaType.APPLICATION_XML, MediaType.TEXT_XML, new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportDtd(boolean supportDtd) {
/* 112 */     this.supportDtd = supportDtd;
/* 113 */     this.documentBuilderFactory = null;
/* 114 */     this.saxParserFactory = null;
/* 115 */     this.xmlInputFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupportDtd() {
/* 122 */     return this.supportDtd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessExternalEntities(boolean processExternalEntities) {
/* 132 */     this.processExternalEntities = processExternalEntities;
/* 133 */     if (processExternalEntities) {
/* 134 */       this.supportDtd = true;
/*     */     }
/* 136 */     this.documentBuilderFactory = null;
/* 137 */     this.saxParserFactory = null;
/* 138 */     this.xmlInputFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProcessExternalEntities() {
/* 145 */     return this.processExternalEntities;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 151 */     return SUPPORTED_CLASSES.contains(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 159 */     InputStream body = StreamUtils.nonClosing(inputMessage.getBody());
/* 160 */     if (DOMSource.class == clazz) {
/* 161 */       return (T)readDOMSource(body, inputMessage);
/*     */     }
/* 163 */     if (SAXSource.class == clazz) {
/* 164 */       return (T)readSAXSource(body, inputMessage);
/*     */     }
/* 166 */     if (StAXSource.class == clazz) {
/* 167 */       return (T)readStAXSource(body, inputMessage);
/*     */     }
/* 169 */     if (StreamSource.class == clazz || Source.class == clazz) {
/* 170 */       return (T)readStreamSource(body);
/*     */     }
/*     */     
/* 173 */     throw new HttpMessageNotReadableException("Could not read class [" + String.valueOf(clazz) + "]. Only DOMSource, SAXSource, StAXSource, and StreamSource are supported.", inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DOMSource readDOMSource(InputStream body, HttpInputMessage inputMessage) throws IOException {
/*     */     try {
/* 182 */       DocumentBuilderFactory builderFactory = this.documentBuilderFactory;
/* 183 */       if (builderFactory == null) {
/* 184 */         builderFactory = DocumentBuilderFactory.newInstance();
/* 185 */         builderFactory.setNamespaceAware(true);
/* 186 */         builderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", 
/* 187 */             !isSupportDtd());
/* 188 */         builderFactory.setFeature("http://xml.org/sax/features/external-general-entities", 
/* 189 */             isProcessExternalEntities());
/* 190 */         this.documentBuilderFactory = builderFactory;
/*     */       } 
/* 192 */       DocumentBuilder builder = builderFactory.newDocumentBuilder();
/* 193 */       if (!isProcessExternalEntities()) {
/* 194 */         builder.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */       }
/* 196 */       Document document = builder.parse(body);
/* 197 */       return new DOMSource(document);
/*     */     }
/* 199 */     catch (NullPointerException ex) {
/* 200 */       if (!isSupportDtd()) {
/* 201 */         throw new HttpMessageNotReadableException("NPE while unmarshalling: This can happen due to the presence of DTD declarations which are disabled.", ex, inputMessage);
/*     */       }
/*     */       
/* 204 */       throw ex;
/*     */     }
/* 206 */     catch (ParserConfigurationException ex) {
/* 207 */       throw new HttpMessageNotReadableException("Could not set feature: " + ex
/* 208 */           .getMessage(), ex, inputMessage);
/*     */     }
/* 210 */     catch (SAXException ex) {
/* 211 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex
/* 212 */           .getMessage(), ex, inputMessage);
/*     */     } 
/*     */   }
/*     */   
/*     */   private SAXSource readSAXSource(InputStream body, HttpInputMessage inputMessage) throws IOException {
/*     */     try {
/* 218 */       SAXParserFactory parserFactory = this.saxParserFactory;
/* 219 */       if (parserFactory == null) {
/* 220 */         parserFactory = SAXParserFactory.newInstance();
/* 221 */         parserFactory.setNamespaceAware(true);
/* 222 */         parserFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", 
/* 223 */             !isSupportDtd());
/* 224 */         parserFactory.setFeature("http://xml.org/sax/features/external-general-entities", 
/* 225 */             isProcessExternalEntities());
/* 226 */         this.saxParserFactory = parserFactory;
/*     */       } 
/* 228 */       SAXParser saxParser = parserFactory.newSAXParser();
/* 229 */       XMLReader xmlReader = saxParser.getXMLReader();
/* 230 */       if (!isProcessExternalEntities()) {
/* 231 */         xmlReader.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */       }
/* 233 */       byte[] bytes = StreamUtils.copyToByteArray(body);
/* 234 */       return new SAXSource(xmlReader, new InputSource(new ByteArrayInputStream(bytes)));
/*     */     }
/* 236 */     catch (SAXException|ParserConfigurationException ex) {
/* 237 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex
/* 238 */           .getMessage(), ex, inputMessage);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Source readStAXSource(InputStream body, HttpInputMessage inputMessage) {
/*     */     try {
/* 244 */       XMLInputFactory inputFactory = this.xmlInputFactory;
/* 245 */       if (inputFactory == null) {
/* 246 */         inputFactory = XMLInputFactory.newInstance();
/* 247 */         inputFactory.setProperty("javax.xml.stream.supportDTD", Boolean.valueOf(isSupportDtd()));
/* 248 */         inputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", Boolean.valueOf(isProcessExternalEntities()));
/* 249 */         if (!isProcessExternalEntities()) {
/* 250 */           inputFactory.setXMLResolver(NO_OP_XML_RESOLVER);
/*     */         }
/* 252 */         this.xmlInputFactory = inputFactory;
/*     */       } 
/* 254 */       XMLStreamReader streamReader = inputFactory.createXMLStreamReader(body);
/* 255 */       return new StAXSource(streamReader);
/*     */     }
/* 257 */     catch (XMLStreamException ex) {
/* 258 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex
/* 259 */           .getMessage(), ex, inputMessage);
/*     */     } 
/*     */   }
/*     */   
/*     */   private StreamSource readStreamSource(InputStream body) throws IOException {
/* 264 */     byte[] bytes = StreamUtils.copyToByteArray(body);
/* 265 */     return new StreamSource(new ByteArrayInputStream(bytes));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Long getContentLength(T t, @Nullable MediaType contentType) {
/* 271 */     if (t instanceof DOMSource) {
/*     */       try {
/* 273 */         CountingOutputStream os = new CountingOutputStream();
/* 274 */         transform((Source)t, new StreamResult(os));
/* 275 */         return Long.valueOf(os.count);
/*     */       }
/* 277 */       catch (TransformerException transformerException) {}
/*     */     }
/*     */ 
/*     */     
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*     */     try {
/* 288 */       Result result = new StreamResult(outputMessage.getBody());
/* 289 */       transform((Source)t, result);
/*     */     }
/* 291 */     catch (TransformerException ex) {
/* 292 */       throw new HttpMessageNotWritableException("Could not transform [" + String.valueOf(t) + "] to output message", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void transform(Source source, Result result) throws TransformerException {
/* 297 */     this.transformerFactory.newTransformer().transform(source, result);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(T t) {
/* 302 */     return t instanceof DOMSource;
/*     */   }
/*     */   
/*     */   private static class CountingOutputStream
/*     */     extends OutputStream
/*     */   {
/* 308 */     long count = 0L;
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {
/* 312 */       this.count++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 317 */       this.count += b.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/* 322 */       this.count += len;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\xml\SourceHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */