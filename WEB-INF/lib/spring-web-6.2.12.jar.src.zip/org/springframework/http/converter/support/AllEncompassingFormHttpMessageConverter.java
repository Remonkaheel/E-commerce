/*     */ package org.springframework.http.converter.support;
/*     */ 
/*     */ import org.springframework.http.converter.FormHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.cbor.KotlinSerializationCborHttpMessageConverter;
/*     */ import org.springframework.http.converter.cbor.MappingJackson2CborHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.JsonbHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.KotlinSerializationJsonHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.protobuf.KotlinSerializationProtobufHttpMessageConverter;
/*     */ import org.springframework.http.converter.smile.MappingJackson2SmileHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.yaml.MappingJackson2YamlHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllEncompassingFormHttpMessageConverter
/*     */   extends FormHttpMessageConverter
/*     */ {
/*     */   private static final boolean jaxb2Present;
/*     */   private static final boolean jackson2Present;
/*     */   private static final boolean jackson2XmlPresent;
/*     */   private static final boolean jackson2SmilePresent;
/*     */   private static final boolean jackson2CborPresent;
/*     */   private static final boolean jackson2YamlPresent;
/*     */   private static final boolean gsonPresent;
/*     */   private static final boolean jsonbPresent;
/*     */   private static final boolean kotlinSerializationCborPresent;
/*     */   private static final boolean kotlinSerializationJsonPresent;
/*     */   private static final boolean kotlinSerializationProtobufPresent;
/*     */   
/*     */   static {
/*  68 */     ClassLoader classLoader = AllEncompassingFormHttpMessageConverter.class.getClassLoader();
/*  69 */     jaxb2Present = ClassUtils.isPresent("jakarta.xml.bind.Binder", classLoader);
/*     */     
/*  71 */     jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", classLoader) && ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", classLoader));
/*  72 */     jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", classLoader);
/*  73 */     jackson2SmilePresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.smile.SmileFactory", classLoader);
/*  74 */     jackson2CborPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.cbor.CBORFactory", classLoader);
/*  75 */     jackson2YamlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.yaml.YAMLFactory", classLoader);
/*  76 */     gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", classLoader);
/*  77 */     jsonbPresent = ClassUtils.isPresent("jakarta.json.bind.Jsonb", classLoader);
/*  78 */     kotlinSerializationCborPresent = ClassUtils.isPresent("kotlinx.serialization.cbor.Cbor", classLoader);
/*  79 */     kotlinSerializationJsonPresent = ClassUtils.isPresent("kotlinx.serialization.json.Json", classLoader);
/*  80 */     kotlinSerializationProtobufPresent = ClassUtils.isPresent("kotlinx.serialization.protobuf.ProtoBuf", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AllEncompassingFormHttpMessageConverter() {
/*  86 */     if (jaxb2Present && !jackson2XmlPresent) {
/*  87 */       addPartConverter((HttpMessageConverter)new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/*     */     
/*  90 */     if (kotlinSerializationJsonPresent) {
/*  91 */       addPartConverter((HttpMessageConverter)new KotlinSerializationJsonHttpMessageConverter());
/*     */     }
/*  93 */     if (jackson2Present) {
/*  94 */       addPartConverter((HttpMessageConverter)new MappingJackson2HttpMessageConverter());
/*     */     }
/*  96 */     else if (gsonPresent) {
/*  97 */       addPartConverter((HttpMessageConverter)new GsonHttpMessageConverter());
/*     */     }
/*  99 */     else if (jsonbPresent) {
/* 100 */       addPartConverter((HttpMessageConverter)new JsonbHttpMessageConverter());
/*     */     } 
/*     */     
/* 103 */     if (jackson2XmlPresent) {
/* 104 */       addPartConverter((HttpMessageConverter)new MappingJackson2XmlHttpMessageConverter());
/*     */     }
/*     */     
/* 107 */     if (jackson2SmilePresent) {
/* 108 */       addPartConverter((HttpMessageConverter)new MappingJackson2SmileHttpMessageConverter());
/*     */     }
/*     */     
/* 111 */     if (jackson2CborPresent) {
/* 112 */       addPartConverter((HttpMessageConverter)new MappingJackson2CborHttpMessageConverter());
/*     */     }
/*     */     
/* 115 */     if (jackson2YamlPresent) {
/* 116 */       addPartConverter((HttpMessageConverter)new MappingJackson2YamlHttpMessageConverter());
/*     */     }
/*     */     
/* 119 */     if (kotlinSerializationCborPresent) {
/* 120 */       addPartConverter((HttpMessageConverter)new KotlinSerializationCborHttpMessageConverter());
/*     */     }
/*     */     
/* 123 */     if (kotlinSerializationProtobufPresent)
/* 124 */       addPartConverter((HttpMessageConverter)new KotlinSerializationProtobufHttpMessageConverter()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\support\AllEncompassingFormHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */