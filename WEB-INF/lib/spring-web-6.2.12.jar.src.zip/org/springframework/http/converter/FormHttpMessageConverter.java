/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.ContentDisposition;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormHttpMessageConverter
/*     */   implements HttpMessageConverter<MultiValueMap<String, ?>>
/*     */ {
/* 168 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */   
/* 171 */   private List<MediaType> supportedMediaTypes = new ArrayList<>();
/*     */   
/* 173 */   private List<HttpMessageConverter<?>> partConverters = new ArrayList<>();
/*     */   
/* 175 */   private Charset charset = DEFAULT_CHARSET;
/*     */   
/*     */   @Nullable
/*     */   private Charset multipartCharset;
/*     */ 
/*     */   
/*     */   public FormHttpMessageConverter() {
/* 182 */     this.supportedMediaTypes.add(MediaType.APPLICATION_FORM_URLENCODED);
/* 183 */     this.supportedMediaTypes.add(MediaType.MULTIPART_FORM_DATA);
/* 184 */     this.supportedMediaTypes.add(MediaType.MULTIPART_MIXED);
/* 185 */     this.supportedMediaTypes.add(MediaType.MULTIPART_RELATED);
/*     */     
/* 187 */     this.partConverters.add(new ByteArrayHttpMessageConverter());
/* 188 */     this.partConverters.add(new StringHttpMessageConverter());
/* 189 */     this.partConverters.add(new ResourceHttpMessageConverter());
/*     */     
/* 191 */     applyDefaultCharset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes) {
/* 201 */     Assert.notNull(supportedMediaTypes, "'supportedMediaTypes' must not be null");
/*     */     
/* 203 */     this.supportedMediaTypes = new ArrayList<>(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSupportedMediaTypes(MediaType... supportedMediaTypes) {
/* 215 */     Assert.notNull(supportedMediaTypes, "'supportedMediaTypes' must not be null");
/* 216 */     Assert.noNullElements((Object[])supportedMediaTypes, "'supportedMediaTypes' must not contain null elements");
/* 217 */     Collections.addAll(this.supportedMediaTypes, supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MediaType> getSupportedMediaTypes() {
/* 227 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPartConverters(List<HttpMessageConverter<?>> partConverters) {
/* 235 */     Assert.notEmpty(partConverters, "'partConverters' must not be empty");
/* 236 */     this.partConverters = partConverters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HttpMessageConverter<?>> getPartConverters() {
/* 245 */     return Collections.unmodifiableList(this.partConverters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPartConverter(HttpMessageConverter<?> partConverter) {
/* 253 */     Assert.notNull(partConverter, "'partConverter' must not be null");
/* 254 */     this.partConverters.add(partConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(@Nullable Charset charset) {
/* 271 */     if (charset != this.charset) {
/* 272 */       this.charset = (charset != null) ? charset : DEFAULT_CHARSET;
/* 273 */       applyDefaultCharset();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyDefaultCharset() {
/* 281 */     for (HttpMessageConverter<?> candidate : this.partConverters) {
/* 282 */       if (candidate instanceof AbstractHttpMessageConverter) { AbstractHttpMessageConverter<?> converter = (AbstractHttpMessageConverter)candidate;
/*     */         
/* 284 */         if (converter.getDefaultCharset() != null) {
/* 285 */           converter.setDefaultCharset(this.charset);
/*     */         } }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMultipartCharset(Charset charset) {
/* 302 */     this.multipartCharset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 308 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 309 */       return false;
/*     */     }
/* 311 */     if (mediaType == null) {
/* 312 */       return true;
/*     */     }
/* 314 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 315 */       if (supportedMediaType.getType().equalsIgnoreCase("multipart")) {
/*     */         continue;
/*     */       }
/*     */       
/* 319 */       if (supportedMediaType.includes(mediaType)) {
/* 320 */         return true;
/*     */       }
/*     */     } 
/* 323 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 328 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 329 */       return false;
/*     */     }
/* 331 */     if (mediaType == null || MediaType.ALL.equals(mediaType)) {
/* 332 */       return true;
/*     */     }
/* 334 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 335 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 336 */         return true;
/*     */       }
/*     */     } 
/* 339 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> read(@Nullable Class<? extends MultiValueMap<String, ?>> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 346 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/*     */     
/* 348 */     Charset charset = (contentType != null && contentType.getCharset() != null) ? contentType.getCharset() : this.charset;
/* 349 */     String body = StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */     
/* 351 */     String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
/* 352 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap(pairs.length);
/*     */     try {
/* 354 */       for (String pair : pairs) {
/* 355 */         int idx = pair.indexOf('=');
/* 356 */         if (idx == -1) {
/* 357 */           linkedMultiValueMap.add(URLDecoder.decode(pair, charset), null);
/*     */         } else {
/*     */           
/* 360 */           String name = URLDecoder.decode(pair.substring(0, idx), charset);
/* 361 */           String value = URLDecoder.decode(pair.substring(idx + 1), charset);
/* 362 */           linkedMultiValueMap.add(name, value);
/*     */         }
/*     */       
/*     */       } 
/* 366 */     } catch (IllegalArgumentException ex) {
/* 367 */       throw new HttpMessageNotReadableException("Could not decode HTTP form payload", ex, inputMessage);
/*     */     } 
/* 369 */     return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(MultiValueMap<String, ?> map, @Nullable MediaType contentType, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 377 */     if (isMultipart(map, contentType)) {
/* 378 */       writeMultipart((MultiValueMap)map, contentType, outputMessage);
/*     */     } else {
/*     */       
/* 381 */       writeForm((MultiValueMap)map, contentType, outputMessage);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isMultipart(MultiValueMap<String, ?> map, @Nullable MediaType contentType) {
/* 387 */     if (contentType != null) {
/* 388 */       return contentType.getType().equalsIgnoreCase("multipart");
/*     */     }
/* 390 */     for (List<?> values : (Iterable<List<?>>)map.values()) {
/* 391 */       for (Object value : values) {
/* 392 */         if (value != null && !(value instanceof String)) {
/* 393 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeForm(MultiValueMap<String, Object> formData, @Nullable MediaType mediaType, HttpOutputMessage outputMessage) throws IOException {
/* 403 */     mediaType = getFormContentType(mediaType);
/* 404 */     outputMessage.getHeaders().setContentType(mediaType);
/*     */     
/* 406 */     Charset charset = (mediaType.getCharset() != null) ? mediaType.getCharset() : this.charset;
/*     */     
/* 408 */     final byte[] bytes = serializeForm(formData, charset).getBytes(charset);
/* 409 */     outputMessage.getHeaders().setContentLength(bytes.length);
/*     */     
/* 411 */     if (outputMessage instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/* 412 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */           {
/*     */             public void writeTo(OutputStream outputStream) throws IOException {
/* 415 */               StreamUtils.copy(bytes, outputStream);
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean repeatable() {
/* 420 */               return true;
/*     */             }
/*     */           }); }
/*     */     else
/*     */     
/* 425 */     { StreamUtils.copy(bytes, outputMessage.getBody()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MediaType getFormContentType(@Nullable MediaType contentType) {
/* 437 */     if (contentType == null) {
/* 438 */       return MediaType.APPLICATION_FORM_URLENCODED;
/*     */     }
/*     */ 
/*     */     
/* 442 */     if (contentType.getCharset() == null && this.charset != DEFAULT_CHARSET) {
/* 443 */       return new MediaType(contentType, this.charset);
/*     */     }
/* 445 */     return contentType;
/*     */   }
/*     */   
/*     */   protected String serializeForm(MultiValueMap<String, Object> formData, Charset charset) {
/* 449 */     StringBuilder builder = new StringBuilder();
/* 450 */     formData.forEach((name, values) -> {
/*     */           if (name == null) {
/*     */             Assert.isTrue(CollectionUtils.isEmpty(values), ());
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           values.forEach(());
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 467 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMultipart(MultiValueMap<String, Object> parts, @Nullable MediaType contentType, HttpOutputMessage outputMessage) throws IOException {
/* 477 */     if (contentType == null) {
/* 478 */       contentType = MediaType.MULTIPART_FORM_DATA;
/*     */     }
/*     */     
/* 481 */     Map<String, String> parameters = new LinkedHashMap<>(contentType.getParameters().size() + 2);
/* 482 */     parameters.putAll(contentType.getParameters());
/*     */     
/* 484 */     byte[] boundary = generateMultipartBoundary();
/* 485 */     if (!isFilenameCharsetSet() && 
/* 486 */       !this.charset.equals(StandardCharsets.UTF_8) && 
/* 487 */       !this.charset.equals(StandardCharsets.US_ASCII)) {
/* 488 */       parameters.put("charset", this.charset.name());
/*     */     }
/*     */     
/* 491 */     parameters.put("boundary", new String(boundary, StandardCharsets.US_ASCII));
/*     */ 
/*     */     
/* 494 */     contentType = new MediaType(contentType, parameters);
/* 495 */     outputMessage.getHeaders().setContentType(contentType);
/*     */     
/* 497 */     if (outputMessage instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/* 498 */       streamingOutputMessage.setBody(outputStream -> {
/*     */             writeParts(outputStream, parts, boundary);
/*     */             
/*     */             writeEnd(outputStream, boundary);
/*     */           }); }
/*     */     else
/* 504 */     { writeParts(outputMessage.getBody(), parts, boundary);
/* 505 */       writeEnd(outputMessage.getBody(), boundary); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFilenameCharsetSet() {
/* 515 */     return (this.multipartCharset != null);
/*     */   }
/*     */   
/*     */   private void writeParts(OutputStream os, MultiValueMap<String, Object> parts, byte[] boundary) throws IOException {
/* 519 */     for (Map.Entry<String, List<Object>> entry : (Iterable<Map.Entry<String, List<Object>>>)parts.entrySet()) {
/* 520 */       String name = entry.getKey();
/* 521 */       for (Object part : entry.getValue()) {
/* 522 */         if (part != null) {
/* 523 */           writeBoundary(os, boundary);
/* 524 */           writePart(name, getHttpEntity(part), os);
/* 525 */           writeNewLine(os);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writePart(String name, HttpEntity<?> partEntity, OutputStream os) throws IOException {
/* 533 */     Object partBody = partEntity.getBody();
/* 534 */     if (partBody == null) {
/* 535 */       throw new IllegalStateException("Empty body for part '" + name + "': " + String.valueOf(partEntity));
/*     */     }
/* 537 */     Class<?> partType = partBody.getClass();
/* 538 */     HttpHeaders partHeaders = partEntity.getHeaders();
/* 539 */     MediaType partContentType = partHeaders.getContentType();
/* 540 */     for (HttpMessageConverter<?> messageConverter : this.partConverters) {
/* 541 */       if (messageConverter.canWrite(partType, partContentType)) {
/* 542 */         Charset charset = isFilenameCharsetSet() ? StandardCharsets.US_ASCII : this.charset;
/* 543 */         HttpOutputMessage multipartMessage = new MultipartHttpOutputMessage(os, charset);
/* 544 */         String filename = getFilename(partBody);
/*     */         
/* 546 */         ContentDisposition.Builder cd = ContentDisposition.formData().name(name);
/* 547 */         if (filename != null) {
/* 548 */           cd.filename(filename, this.multipartCharset);
/*     */         }
/* 550 */         multipartMessage.getHeaders().setContentDisposition(cd.build());
/* 551 */         if (!partHeaders.isEmpty()) {
/* 552 */           multipartMessage.getHeaders().putAll((Map)partHeaders);
/*     */         }
/* 554 */         messageConverter.write(partBody, partContentType, multipartMessage);
/*     */         return;
/*     */       } 
/*     */     } 
/* 558 */     throw new HttpMessageNotWritableException("Could not write request: no suitable HttpMessageConverter found for request type [" + partType
/* 559 */         .getName() + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] generateMultipartBoundary() {
/* 568 */     return MimeTypeUtils.generateMultipartBoundary();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpEntity<?> getHttpEntity(Object part) {
/* 578 */     HttpEntity<?> httpEntity = (HttpEntity)part; return (part instanceof HttpEntity) ? httpEntity : new HttpEntity(part);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getFilename(Object part) {
/* 591 */     if (part instanceof Resource) { Resource resource = (Resource)part;
/* 592 */       return resource.getFilename(); }
/*     */ 
/*     */     
/* 595 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeBoundary(OutputStream os, byte[] boundary) throws IOException {
/* 601 */     os.write(45);
/* 602 */     os.write(45);
/* 603 */     os.write(boundary);
/* 604 */     writeNewLine(os);
/*     */   }
/*     */   
/*     */   private static void writeEnd(OutputStream os, byte[] boundary) throws IOException {
/* 608 */     os.write(45);
/* 609 */     os.write(45);
/* 610 */     os.write(boundary);
/* 611 */     os.write(45);
/* 612 */     os.write(45);
/* 613 */     writeNewLine(os);
/*     */   }
/*     */   
/*     */   private static void writeNewLine(OutputStream os) throws IOException {
/* 617 */     os.write(13);
/* 618 */     os.write(10);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MultipartHttpOutputMessage
/*     */     implements HttpOutputMessage
/*     */   {
/*     */     private final OutputStream outputStream;
/*     */ 
/*     */     
/*     */     private final Charset charset;
/*     */ 
/*     */     
/* 632 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     
/*     */     private boolean headersWritten = false;
/*     */     
/*     */     public MultipartHttpOutputMessage(OutputStream outputStream, Charset charset) {
/* 637 */       this.outputStream = new FormHttpMessageConverter.MultipartOutputStream(outputStream);
/* 638 */       this.charset = charset;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 643 */       return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public OutputStream getBody() throws IOException {
/* 648 */       writeHeaders();
/* 649 */       return this.outputStream;
/*     */     }
/*     */     
/*     */     private void writeHeaders() throws IOException {
/* 653 */       if (!this.headersWritten) {
/* 654 */         for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)this.headers.entrySet()) {
/* 655 */           byte[] headerName = getBytes(entry.getKey());
/* 656 */           for (String headerValueString : entry.getValue()) {
/* 657 */             byte[] headerValue = getBytes(headerValueString);
/* 658 */             this.outputStream.write(headerName);
/* 659 */             this.outputStream.write(58);
/* 660 */             this.outputStream.write(32);
/* 661 */             this.outputStream.write(headerValue);
/* 662 */             FormHttpMessageConverter.writeNewLine(this.outputStream);
/*     */           } 
/*     */         } 
/* 665 */         FormHttpMessageConverter.writeNewLine(this.outputStream);
/* 666 */         this.headersWritten = true;
/*     */       } 
/*     */     }
/*     */     
/*     */     private byte[] getBytes(String name) {
/* 671 */       return name.getBytes(this.charset);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MultipartOutputStream
/*     */     extends FilterOutputStream
/*     */   {
/*     */     public MultipartOutputStream(OutputStream out) {
/* 683 */       super(out);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int off, int let) throws IOException {
/* 688 */       this.out.write(b, off, let);
/*     */     }
/*     */     
/*     */     public void flush() {}
/*     */     
/*     */     public void close() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\FormHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */