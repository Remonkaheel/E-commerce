/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayHttpMessageConverter
/*    */   extends AbstractHttpMessageConverter<byte[]>
/*    */ {
/*    */   public ByteArrayHttpMessageConverter() {
/* 44 */     super(new MediaType[] { MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 50 */     return (byte[].class == clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] readInternal(Class<? extends byte[]> clazz, HttpInputMessage message) throws IOException {
/* 55 */     long length = message.getHeaders().getContentLength();
/* 56 */     return (length >= 0L && length < 2147483647L) ? 
/* 57 */       message.getBody().readNBytes((int)length) : message.getBody().readAllBytes();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Long getContentLength(byte[] bytes, @Nullable MediaType contentType) {
/* 62 */     return Long.valueOf(bytes.length);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void writeInternal(byte[] bytes, HttpOutputMessage outputMessage) throws IOException {
/* 67 */     StreamUtils.copy(bytes, outputMessage.getBody());
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean supportsRepeatableWrites(byte[] bytes) {
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\ByteArrayHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */