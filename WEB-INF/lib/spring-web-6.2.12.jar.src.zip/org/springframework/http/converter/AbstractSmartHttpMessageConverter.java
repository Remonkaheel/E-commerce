/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSmartHttpMessageConverter<T>
/*     */   extends AbstractHttpMessageConverter<T>
/*     */   implements SmartHttpMessageConverter<T>
/*     */ {
/*     */   protected AbstractSmartHttpMessageConverter() {}
/*     */   
/*     */   protected AbstractSmartHttpMessageConverter(MediaType supportedMediaType) {
/*  53 */     super(supportedMediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractSmartHttpMessageConverter(MediaType... supportedMediaTypes) {
/*  61 */     super(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType type, @Nullable MediaType mediaType) {
/*  72 */     Class<?> clazz = type.resolve();
/*  73 */     return (clazz != null) ? canRead(clazz, mediaType) : canRead(mediaType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType type, Class<?> clazz, @Nullable MediaType mediaType) {
/*  78 */     return canWrite(clazz, mediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(final T t, final ResolvableType type, @Nullable MediaType contentType, HttpOutputMessage outputMessage, @Nullable final Map<String, Object> hints) throws IOException, HttpMessageNotWritableException {
/*  90 */     final HttpHeaders headers = outputMessage.getHeaders();
/*  91 */     addDefaultHeaders(headers, t, contentType);
/*     */     
/*  93 */     if (outputMessage instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/*  94 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */           {
/*     */             public void writeTo(final OutputStream outputStream) throws IOException {
/*  97 */               AbstractSmartHttpMessageConverter.this.writeInternal(t, type, new HttpOutputMessage()
/*     */                   {
/*     */                     public OutputStream getBody() {
/* 100 */                       return outputStream;
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public HttpHeaders getHeaders() {
/* 105 */                       return headers;
/*     */                     }
/*     */                   },  hints);
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean repeatable() {
/* 112 */               return AbstractSmartHttpMessageConverter.this.supportsRepeatableWrites(t);
/*     */             }
/*     */           }); }
/*     */     else
/*     */     
/* 117 */     { writeInternal(t, type, outputMessage, hints);
/* 118 */       outputMessage.getBody().flush(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 126 */     writeInternal(t, ResolvableType.NONE, outputMessage, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void writeInternal(T paramT, ResolvableType paramResolvableType, HttpOutputMessage paramHttpOutputMessage, @Nullable Map<String, Object> paramMap) throws IOException, HttpMessageNotWritableException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 146 */     return read(ResolvableType.forClass(clazz), inputMessage, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\AbstractSmartHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */