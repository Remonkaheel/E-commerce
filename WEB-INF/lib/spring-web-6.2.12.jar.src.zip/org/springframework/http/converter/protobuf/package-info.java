package org.springframework.http.converter.protobuf;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\protobuf\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */