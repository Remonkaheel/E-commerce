/*     */ package org.springframework.http.converter.protobuf;
/*     */ 
/*     */ import com.google.protobuf.CodedOutputStream;
/*     */ import com.google.protobuf.ExtensionRegistry;
/*     */ import com.google.protobuf.ExtensionRegistryLite;
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.MessageOrBuilder;
/*     */ import com.google.protobuf.TextFormat;
/*     */ import com.google.protobuf.util.JsonFormat;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtobufHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<Message>
/*     */ {
/*  78 */   public static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final MediaType PROTOBUF = new MediaType("application", "x-protobuf", DEFAULT_CHARSET);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String X_PROTOBUF_SCHEMA_HEADER = "X-Protobuf-Schema";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String X_PROTOBUF_MESSAGE_HEADER = "X-Protobuf-Message";
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final boolean protobufJsonFormatPresent = ClassUtils.isPresent("com.google.protobuf.util.JsonFormat", ProtobufHttpMessageConverter.class.getClassLoader());
/*     */   
/*  97 */   private static final Map<Class<?>, Method> methodCache = (Map<Class<?>, Method>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   final ExtensionRegistry extensionRegistry;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final ProtobufFormatSupport protobufFormatSupport;
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufHttpMessageConverter() {
/* 110 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtobufHttpMessageConverter(ExtensionRegistry extensionRegistry) {
/* 119 */     this(null, extensionRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ProtobufHttpMessageConverter(@Nullable ProtobufFormatSupport formatSupport, @Nullable ExtensionRegistry extensionRegistry) {
/* 125 */     if (formatSupport != null) {
/* 126 */       this.protobufFormatSupport = formatSupport;
/*     */     }
/* 128 */     else if (protobufJsonFormatPresent) {
/* 129 */       this.protobufFormatSupport = new ProtobufJavaUtilSupport(null, null);
/*     */     } else {
/*     */       
/* 132 */       this.protobufFormatSupport = null;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     (new MediaType[2])[0] = PROTOBUF; (new MediaType[2])[1] = MediaType.TEXT_PLAIN; setSupportedMediaTypes(Arrays.asList((this.protobufFormatSupport != null) ? this.protobufFormatSupport.supportedMediaTypes() : new MediaType[2]));
/*     */     
/* 138 */     this.extensionRegistry = (extensionRegistry == null) ? ExtensionRegistry.newInstance() : extensionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/* 144 */     return Message.class.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MediaType getDefaultContentType(Message message) {
/* 149 */     return PROTOBUF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Message readInternal(Class<? extends Message> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 156 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 157 */     if (contentType == null) {
/* 158 */       contentType = PROTOBUF;
/*     */     }
/* 160 */     Charset charset = contentType.getCharset();
/* 161 */     if (charset == null) {
/* 162 */       charset = DEFAULT_CHARSET;
/*     */     }
/*     */     
/* 165 */     Message.Builder builder = getMessageBuilder(clazz);
/* 166 */     if (PROTOBUF.isCompatibleWith(contentType)) {
/* 167 */       builder.mergeFrom(inputMessage.getBody(), (ExtensionRegistryLite)this.extensionRegistry);
/*     */     }
/* 169 */     else if (MediaType.TEXT_PLAIN.isCompatibleWith(contentType)) {
/* 170 */       InputStreamReader reader = new InputStreamReader(inputMessage.getBody(), charset);
/* 171 */       TextFormat.merge(reader, this.extensionRegistry, builder);
/*     */     }
/* 173 */     else if (this.protobufFormatSupport != null) {
/* 174 */       this.protobufFormatSupport.merge(inputMessage
/* 175 */           .getBody(), charset, contentType, this.extensionRegistry, builder);
/*     */     } 
/* 177 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Message.Builder getMessageBuilder(Class<? extends Message> clazz) {
/*     */     try {
/* 186 */       Method method = methodCache.get(clazz);
/* 187 */       if (method == null) {
/* 188 */         method = clazz.getMethod("newBuilder", new Class[0]);
/* 189 */         methodCache.put(clazz, method);
/*     */       } 
/* 191 */       return (Message.Builder)method.invoke(clazz, new Object[0]);
/*     */     }
/* 193 */     catch (Exception ex) {
/* 194 */       throw new HttpMessageConversionException("Invalid Protobuf Message type: no invocable newBuilder() method on " + String.valueOf(clazz), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canWrite(@Nullable MediaType mediaType) {
/* 202 */     return (super.canWrite(mediaType) || (this.protobufFormatSupport != null && this.protobufFormatSupport
/* 203 */       .supportsWriteOnly(mediaType)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(Message message, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 210 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 211 */     if (contentType == null) {
/* 212 */       contentType = getDefaultContentType(message);
/* 213 */       Assert.state((contentType != null), "No content type");
/*     */     } 
/* 215 */     Charset charset = contentType.getCharset();
/* 216 */     if (charset == null) {
/* 217 */       charset = DEFAULT_CHARSET;
/*     */     }
/*     */     
/* 220 */     if (PROTOBUF.isCompatibleWith(contentType)) {
/* 221 */       setProtoHeader(outputMessage, message);
/* 222 */       CodedOutputStream codedOutputStream = CodedOutputStream.newInstance(outputMessage.getBody());
/* 223 */       message.writeTo(codedOutputStream);
/* 224 */       codedOutputStream.flush();
/*     */     }
/* 226 */     else if (MediaType.TEXT_PLAIN.isCompatibleWith(contentType)) {
/* 227 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputMessage.getBody(), charset);
/* 228 */       TextFormat.printer().print((MessageOrBuilder)message, outputStreamWriter);
/* 229 */       outputStreamWriter.flush();
/* 230 */       outputMessage.getBody().flush();
/*     */     }
/* 232 */     else if (this.protobufFormatSupport != null) {
/* 233 */       this.protobufFormatSupport.print(message, outputMessage.getBody(), contentType, charset);
/* 234 */       outputMessage.getBody().flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setProtoHeader(HttpOutputMessage response, Message message) {
/* 245 */     response.getHeaders().set("X-Protobuf-Schema", message.getDescriptorForType().getFile().getName());
/* 246 */     response.getHeaders().set("X-Protobuf-Message", message.getDescriptorForType().getFullName());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Message message) {
/* 251 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static interface ProtobufFormatSupport
/*     */   {
/*     */     MediaType[] supportedMediaTypes();
/*     */ 
/*     */ 
/*     */     
/*     */     boolean supportsWriteOnly(@Nullable MediaType param1MediaType);
/*     */ 
/*     */ 
/*     */     
/*     */     void merge(InputStream param1InputStream, Charset param1Charset, MediaType param1MediaType, ExtensionRegistry param1ExtensionRegistry, Message.Builder param1Builder) throws IOException, HttpMessageConversionException;
/*     */ 
/*     */ 
/*     */     
/*     */     void print(Message param1Message, OutputStream param1OutputStream, MediaType param1MediaType, Charset param1Charset) throws IOException, HttpMessageConversionException;
/*     */   }
/*     */ 
/*     */   
/*     */   static class ProtobufJavaUtilSupport
/*     */     implements ProtobufFormatSupport
/*     */   {
/*     */     private final JsonFormat.Parser parser;
/*     */     
/*     */     private final JsonFormat.Printer printer;
/*     */ 
/*     */     
/*     */     public ProtobufJavaUtilSupport(@Nullable JsonFormat.Parser parser, @Nullable JsonFormat.Printer printer) {
/* 283 */       this.parser = (parser != null) ? parser : JsonFormat.parser();
/* 284 */       this.printer = (printer != null) ? printer : JsonFormat.printer();
/*     */     }
/*     */ 
/*     */     
/*     */     public MediaType[] supportedMediaTypes() {
/* 289 */       return new MediaType[] { ProtobufHttpMessageConverter.PROTOBUF, MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON };
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supportsWriteOnly(@Nullable MediaType mediaType) {
/* 294 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void merge(InputStream input, Charset charset, MediaType contentType, ExtensionRegistry extensionRegistry, Message.Builder builder) throws IOException, HttpMessageConversionException {
/* 302 */       if (contentType.isCompatibleWith(MediaType.APPLICATION_JSON)) {
/* 303 */         InputStreamReader reader = new InputStreamReader(input, charset);
/* 304 */         this.parser.merge(reader, builder);
/*     */       } else {
/*     */         
/* 307 */         throw new HttpMessageConversionException("protobuf-java-util does not support parsing " + String.valueOf(contentType));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void print(Message message, OutputStream output, MediaType contentType, Charset charset) throws IOException, HttpMessageConversionException {
/* 316 */       if (contentType.isCompatibleWith(MediaType.APPLICATION_JSON)) {
/* 317 */         OutputStreamWriter writer = new OutputStreamWriter(output, charset);
/* 318 */         this.printer.appendTo((MessageOrBuilder)message, writer);
/* 319 */         writer.flush();
/*     */       } else {
/*     */         
/* 322 */         throw new HttpMessageConversionException("protobuf-java-util does not support printing " + String.valueOf(contentType));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\protobuf\ProtobufHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */