/*    */ package org.springframework.http.converter.protobuf;
/*    */ 
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.protobuf.ProtoBuf;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.KotlinSerializationBinaryHttpMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationProtobufHttpMessageConverter
/*    */   extends KotlinSerializationBinaryHttpMessageConverter<ProtoBuf>
/*    */ {
/*    */   public KotlinSerializationProtobufHttpMessageConverter() {
/* 41 */     this((ProtoBuf)ProtoBuf.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationProtobufHttpMessageConverter(ProtoBuf protobuf) {
/* 45 */     super((BinaryFormat)protobuf, new MediaType[] { MediaType.APPLICATION_PROTOBUF, MediaType.APPLICATION_OCTET_STREAM, new MediaType("application", "vnd.google.protobuf") });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\protobuf\KotlinSerializationProtobufHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */