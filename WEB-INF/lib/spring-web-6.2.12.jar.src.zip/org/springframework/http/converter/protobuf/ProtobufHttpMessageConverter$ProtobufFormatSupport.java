package org.springframework.http.converter.protobuf;

import com.google.protobuf.ExtensionRegistry;
import com.google.protobuf.Message;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.lang.Nullable;

interface ProtobufFormatSupport {
  MediaType[] supportedMediaTypes();
  
  boolean supportsWriteOnly(@Nullable MediaType paramMediaType);
  
  void merge(InputStream paramInputStream, Charset paramCharset, MediaType paramMediaType, ExtensionRegistry paramExtensionRegistry, Message.Builder paramBuilder) throws IOException, HttpMessageConversionException;
  
  void print(Message paramMessage, OutputStream paramOutputStream, MediaType paramMediaType, Charset paramCharset) throws IOException, HttpMessageConversionException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\protobuf\ProtobufHttpMessageConverter$ProtobufFormatSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */