/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.dataformat.cbor.CBORFactory;
/*     */ import com.fasterxml.jackson.dataformat.smile.SmileFactory;
/*     */ import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
/*     */ import com.fasterxml.jackson.dataformat.xml.XmlFactory;
/*     */ import com.fasterxml.jackson.dataformat.xml.XmlMapper;
/*     */ import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.StaxUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jackson2ObjectMapperBuilder
/*     */ {
/* 107 */   private static final boolean jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", Jackson2ObjectMapperBuilder.class
/* 108 */       .getClassLoader());
/*     */ 
/*     */   
/* 111 */   private final Map<Class<?>, Class<?>> mixIns = new LinkedHashMap<>();
/*     */   
/* 113 */   private final Map<Class<?>, JsonSerializer<?>> serializers = new LinkedHashMap<>();
/*     */   
/* 115 */   private final Map<Class<?>, JsonDeserializer<?>> deserializers = new LinkedHashMap<>();
/*     */   
/* 117 */   private final Map<PropertyAccessor, JsonAutoDetect.Visibility> visibilities = new LinkedHashMap<>();
/*     */   
/* 119 */   private final Map<Object, Boolean> features = new LinkedHashMap<>();
/*     */   
/*     */   private boolean createXmlMapper = false;
/*     */   
/*     */   @Nullable
/*     */   private JsonFactory factory;
/*     */   
/*     */   @Nullable
/*     */   private DateFormat dateFormat;
/*     */   
/*     */   @Nullable
/*     */   private Locale locale;
/*     */   
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */   
/*     */   @Nullable
/*     */   private AnnotationIntrospector annotationIntrospector;
/*     */   
/*     */   @Nullable
/*     */   private PropertyNamingStrategy propertyNamingStrategy;
/*     */   
/*     */   @Nullable
/*     */   private TypeResolverBuilder<?> defaultTyping;
/*     */   
/*     */   @Nullable
/*     */   private JsonInclude.Value serializationInclusion;
/*     */   
/*     */   @Nullable
/*     */   private FilterProvider filters;
/*     */   
/*     */   @Nullable
/*     */   private List<Module> modules;
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends Module>[] moduleClasses;
/*     */   
/*     */   private boolean findModulesViaServiceLoader = false;
/*     */   
/*     */   private boolean findWellKnownModules = true;
/*     */   
/* 160 */   private ClassLoader moduleClassLoader = getClass().getClassLoader();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private HandlerInstantiator handlerInstantiator;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean defaultUseWrapper;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Consumer<ObjectMapper> configurer;
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder createXmlMapper(boolean createXmlMapper) {
/* 181 */     this.createXmlMapper = createXmlMapper;
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder factory(JsonFactory factory) {
/* 191 */     this.factory = factory;
/* 192 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder dateFormat(DateFormat dateFormat) {
/* 202 */     this.dateFormat = dateFormat;
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder simpleDateFormat(String format) {
/* 213 */     this.dateFormat = new SimpleDateFormat(format);
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder locale(Locale locale) {
/* 223 */     this.locale = locale;
/* 224 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder locale(String localeString) {
/* 234 */     this.locale = StringUtils.parseLocale(localeString);
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder timeZone(TimeZone timeZone) {
/* 244 */     this.timeZone = timeZone;
/* 245 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder timeZone(String timeZoneString) {
/* 255 */     this.timeZone = StringUtils.parseTimeZoneString(timeZoneString);
/* 256 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder annotationIntrospector(AnnotationIntrospector annotationIntrospector) {
/* 263 */     this.annotationIntrospector = annotationIntrospector;
/* 264 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder annotationIntrospector(Function<AnnotationIntrospector, AnnotationIntrospector> pairingFunction) {
/* 280 */     this.annotationIntrospector = pairingFunction.apply(this.annotationIntrospector);
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder propertyNamingStrategy(PropertyNamingStrategy propertyNamingStrategy) {
/* 289 */     this.propertyNamingStrategy = propertyNamingStrategy;
/* 290 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder defaultTyping(TypeResolverBuilder<?> typeResolverBuilder) {
/* 298 */     this.defaultTyping = typeResolverBuilder;
/* 299 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder serializationInclusion(JsonInclude.Include inclusion) {
/* 307 */     return serializationInclusion(JsonInclude.Value.construct(inclusion, inclusion));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder serializationInclusion(JsonInclude.Value serializationInclusion) {
/* 316 */     this.serializationInclusion = serializationInclusion;
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder filters(FilterProvider filters) {
/* 326 */     this.filters = filters;
/* 327 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder mixIn(Class<?> target, Class<?> mixinSource) {
/* 339 */     this.mixIns.put(target, mixinSource);
/* 340 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder mixIns(Map<Class<?>, Class<?>> mixIns) {
/* 352 */     this.mixIns.putAll(mixIns);
/* 353 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder serializers(JsonSerializer<?>... serializers) {
/* 362 */     for (JsonSerializer<?> serializer : serializers) {
/* 363 */       Class<?> handledType = serializer.handledType();
/* 364 */       if (handledType == null || handledType == Object.class) {
/* 365 */         throw new IllegalArgumentException("Unknown handled type in " + serializer.getClass().getName());
/*     */       }
/* 367 */       this.serializers.put(serializer.handledType(), serializer);
/*     */     } 
/* 369 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder serializerByType(Class<?> type, JsonSerializer<?> serializer) {
/* 378 */     this.serializers.put(type, serializer);
/* 379 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder serializersByType(Map<Class<?>, JsonSerializer<?>> serializers) {
/* 387 */     this.serializers.putAll(serializers);
/* 388 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder deserializers(JsonDeserializer<?>... deserializers) {
/* 398 */     for (JsonDeserializer<?> deserializer : deserializers) {
/* 399 */       Class<?> handledType = deserializer.handledType();
/* 400 */       if (handledType == null || handledType == Object.class) {
/* 401 */         throw new IllegalArgumentException("Unknown handled type in " + deserializer.getClass().getName());
/*     */       }
/* 403 */       this.deserializers.put(deserializer.handledType(), deserializer);
/*     */     } 
/* 405 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder deserializerByType(Class<?> type, JsonDeserializer<?> deserializer) {
/* 413 */     this.deserializers.put(type, deserializer);
/* 414 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder deserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers) {
/* 421 */     this.deserializers.putAll(deserializers);
/* 422 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder autoDetectFields(boolean autoDetectFields) {
/* 429 */     this.features.put(MapperFeature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/* 430 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder autoDetectGettersSetters(boolean autoDetectGettersSetters) {
/* 439 */     this.features.put(MapperFeature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 440 */     this.features.put(MapperFeature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 441 */     this.features.put(MapperFeature.AUTO_DETECT_IS_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 442 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder defaultViewInclusion(boolean defaultViewInclusion) {
/* 449 */     this.features.put(MapperFeature.DEFAULT_VIEW_INCLUSION, Boolean.valueOf(defaultViewInclusion));
/* 450 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder failOnUnknownProperties(boolean failOnUnknownProperties) {
/* 457 */     this.features.put(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, Boolean.valueOf(failOnUnknownProperties));
/* 458 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder failOnEmptyBeans(boolean failOnEmptyBeans) {
/* 465 */     this.features.put(SerializationFeature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/* 466 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder indentOutput(boolean indentOutput) {
/* 473 */     this.features.put(SerializationFeature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/* 474 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder defaultUseWrapper(boolean defaultUseWrapper) {
/* 483 */     this.defaultUseWrapper = Boolean.valueOf(defaultUseWrapper);
/* 484 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder visibility(PropertyAccessor accessor, JsonAutoDetect.Visibility visibility) {
/* 494 */     this.visibilities.put(accessor, visibility);
/* 495 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder featuresToEnable(Object... featuresToEnable) {
/* 507 */     for (Object feature : featuresToEnable) {
/* 508 */       this.features.put(feature, Boolean.TRUE);
/*     */     }
/* 510 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder featuresToDisable(Object... featuresToDisable) {
/* 522 */     for (Object feature : featuresToDisable) {
/* 523 */       this.features.put(feature, Boolean.FALSE);
/*     */     }
/* 525 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder modules(Module... modules) {
/* 542 */     return modules(Arrays.asList(modules));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder modules(List<Module> modules) {
/* 552 */     this.modules = new ArrayList<>(modules);
/* 553 */     this.findModulesViaServiceLoader = false;
/* 554 */     this.findWellKnownModules = false;
/* 555 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder modules(Consumer<List<Module>> consumer) {
/* 567 */     this.modules = (this.modules != null) ? this.modules : new ArrayList<>();
/* 568 */     this.findModulesViaServiceLoader = false;
/* 569 */     this.findWellKnownModules = false;
/* 570 */     consumer.accept(this.modules);
/* 571 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder modulesToInstall(Module... modules) {
/* 588 */     this.modules = new ArrayList<>(Arrays.asList(modules));
/* 589 */     this.findWellKnownModules = true;
/* 590 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder modulesToInstall(Consumer<List<Module>> consumer) {
/* 602 */     this.modules = (this.modules != null) ? this.modules : new ArrayList<>();
/* 603 */     this.findWellKnownModules = true;
/* 604 */     consumer.accept(this.modules);
/* 605 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final Jackson2ObjectMapperBuilder modulesToInstall(Class<? extends Module>... modules) {
/* 623 */     this.moduleClasses = modules;
/* 624 */     this.findWellKnownModules = true;
/* 625 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder findModulesViaServiceLoader(boolean findModules) {
/* 636 */     this.findModulesViaServiceLoader = findModules;
/* 637 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder moduleClassLoader(ClassLoader moduleClassLoader) {
/* 644 */     this.moduleClassLoader = moduleClassLoader;
/* 645 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder handlerInstantiator(HandlerInstantiator handlerInstantiator) {
/* 655 */     this.handlerInstantiator = handlerInstantiator;
/* 656 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder applicationContext(ApplicationContext applicationContext) {
/* 666 */     this.applicationContext = applicationContext;
/* 667 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jackson2ObjectMapperBuilder postConfigurer(Consumer<ObjectMapper> configurer) {
/* 679 */     this.configurer = (this.configurer != null) ? this.configurer.andThen(configurer) : configurer;
/* 680 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ObjectMapper> T build() {
/*     */     ObjectMapper mapper;
/* 694 */     if (this.createXmlMapper) {
/*     */ 
/*     */       
/* 697 */       mapper = (this.defaultUseWrapper != null) ? (new XmlObjectMapperInitializer()).create(this.defaultUseWrapper.booleanValue(), this.factory) : (new XmlObjectMapperInitializer()).create(this.factory);
/*     */     } else {
/*     */       
/* 700 */       mapper = (this.factory != null) ? new ObjectMapper(this.factory) : new ObjectMapper();
/*     */     } 
/* 702 */     configure(mapper);
/* 703 */     return (T)mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(ObjectMapper objectMapper) {
/* 712 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*     */     
/* 714 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 715 */     if (this.findModulesViaServiceLoader) {
/* 716 */       ObjectMapper.findModules(this.moduleClassLoader).forEach(module -> registerModule(module, modulesToRegister));
/*     */     }
/* 718 */     else if (this.findWellKnownModules) {
/* 719 */       registerWellKnownModulesIfAvailable((MultiValueMap<Object, Module>)linkedMultiValueMap);
/*     */     } 
/*     */     
/* 722 */     if (this.modules != null) {
/* 723 */       this.modules.forEach(module -> registerModule(module, modulesToRegister));
/*     */     }
/* 725 */     if (this.moduleClasses != null) {
/* 726 */       for (Class<? extends Module> moduleClass : this.moduleClasses) {
/* 727 */         registerModule((Module)BeanUtils.instantiateClass(moduleClass), (MultiValueMap<Object, Module>)linkedMultiValueMap);
/*     */       }
/*     */     }
/* 730 */     List<Module> modules = new ArrayList<>();
/* 731 */     for (List<Module> nestedModules : (Iterable<List<Module>>)linkedMultiValueMap.values()) {
/* 732 */       modules.addAll(nestedModules);
/*     */     }
/* 734 */     objectMapper.registerModules(modules);
/*     */     
/* 736 */     if (this.dateFormat != null) {
/* 737 */       objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/* 739 */     if (this.locale != null) {
/* 740 */       objectMapper.setLocale(this.locale);
/*     */     }
/* 742 */     if (this.timeZone != null) {
/* 743 */       objectMapper.setTimeZone(this.timeZone);
/*     */     }
/*     */     
/* 746 */     if (this.annotationIntrospector != null) {
/* 747 */       objectMapper.setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/* 749 */     if (this.propertyNamingStrategy != null) {
/* 750 */       objectMapper.setPropertyNamingStrategy(this.propertyNamingStrategy);
/*     */     }
/* 752 */     if (this.defaultTyping != null) {
/* 753 */       objectMapper.setDefaultTyping(this.defaultTyping);
/*     */     }
/* 755 */     if (this.serializationInclusion != null) {
/* 756 */       objectMapper.setDefaultPropertyInclusion(this.serializationInclusion);
/*     */     }
/*     */     
/* 759 */     if (this.filters != null) {
/* 760 */       objectMapper.setFilterProvider(this.filters);
/*     */     }
/*     */     
/* 763 */     if (jackson2XmlPresent) {
/* 764 */       objectMapper.addMixIn(ProblemDetail.class, ProblemDetailJacksonXmlMixin.class);
/*     */     } else {
/*     */       
/* 767 */       objectMapper.addMixIn(ProblemDetail.class, ProblemDetailJacksonMixin.class);
/*     */     } 
/* 769 */     Objects.requireNonNull(objectMapper); this.mixIns.forEach(objectMapper::addMixIn);
/*     */     
/* 771 */     if (!this.serializers.isEmpty() || !this.deserializers.isEmpty()) {
/* 772 */       SimpleModule module = new SimpleModule();
/* 773 */       addSerializers(module);
/* 774 */       addDeserializers(module);
/* 775 */       objectMapper.registerModule((Module)module);
/*     */     } 
/*     */     
/* 778 */     Objects.requireNonNull(objectMapper); this.visibilities.forEach(objectMapper::setVisibility);
/*     */     
/* 780 */     customizeDefaultFeatures(objectMapper);
/* 781 */     this.features.forEach((feature, enabled) -> configureFeature(objectMapper, feature, enabled.booleanValue()));
/*     */     
/* 783 */     if (this.handlerInstantiator != null) {
/* 784 */       objectMapper.setHandlerInstantiator(this.handlerInstantiator);
/*     */     }
/* 786 */     else if (this.applicationContext != null) {
/* 787 */       objectMapper.setHandlerInstantiator(new SpringHandlerInstantiator(this.applicationContext
/* 788 */             .getAutowireCapableBeanFactory()));
/*     */     } 
/*     */     
/* 791 */     if (this.configurer != null) {
/* 792 */       this.configurer.accept(objectMapper);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerModule(Module module, MultiValueMap<Object, Module> modulesToRegister) {
/* 797 */     if (module.getTypeId() == null) {
/* 798 */       modulesToRegister.add(SimpleModule.class.getName(), module);
/*     */     } else {
/*     */       
/* 801 */       modulesToRegister.set(module.getTypeId(), module);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void customizeDefaultFeatures(ObjectMapper objectMapper) {
/* 809 */     if (!this.features.containsKey(MapperFeature.DEFAULT_VIEW_INCLUSION)) {
/* 810 */       configureFeature(objectMapper, MapperFeature.DEFAULT_VIEW_INCLUSION, false);
/*     */     }
/* 812 */     if (!this.features.containsKey(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 813 */       configureFeature(objectMapper, DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> void addSerializers(SimpleModule module) {
/* 819 */     this.serializers.forEach((type, serializer) -> module.addSerializer(type, serializer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void addDeserializers(SimpleModule module) {
/* 825 */     this.deserializers.forEach((type, deserializer) -> module.addDeserializer(type, deserializer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureFeature(ObjectMapper objectMapper, Object feature, boolean enabled) {
/* 831 */     if (feature instanceof JsonParser.Feature) { JsonParser.Feature jsonParserFeature = (JsonParser.Feature)feature;
/* 832 */       objectMapper.configure(jsonParserFeature, enabled); }
/*     */     
/* 834 */     else if (feature instanceof JsonGenerator.Feature) { JsonGenerator.Feature jsonGeneratorFeature = (JsonGenerator.Feature)feature;
/* 835 */       objectMapper.configure(jsonGeneratorFeature, enabled); }
/*     */     
/* 837 */     else if (feature instanceof SerializationFeature) { SerializationFeature serializationFeature = (SerializationFeature)feature;
/* 838 */       objectMapper.configure(serializationFeature, enabled); }
/*     */     
/* 840 */     else if (feature instanceof DeserializationFeature) { DeserializationFeature deserializationFeature = (DeserializationFeature)feature;
/* 841 */       objectMapper.configure(deserializationFeature, enabled); }
/*     */     
/* 843 */     else if (feature instanceof DatatypeFeature) { DatatypeFeature datatypeFeature = (DatatypeFeature)feature;
/* 844 */       objectMapper.configure(datatypeFeature, enabled); }
/*     */     
/* 846 */     else if (feature instanceof MapperFeature) { MapperFeature mapperFeature = (MapperFeature)feature;
/* 847 */       objectMapper.configure(mapperFeature, enabled); }
/*     */     else
/*     */     
/* 850 */     { throw new IllegalArgumentException("Unknown feature class: " + feature.getClass().getName()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerWellKnownModulesIfAvailable(MultiValueMap<Object, Module> modulesToRegister) {
/*     */     try {
/* 858 */       Class<? extends Module> jdk8ModuleClass = ClassUtils.forName("com.fasterxml.jackson.datatype.jdk8.Jdk8Module", this.moduleClassLoader);
/* 859 */       Module jdk8Module = (Module)BeanUtils.instantiateClass(jdk8ModuleClass);
/* 860 */       modulesToRegister.set(jdk8Module.getTypeId(), jdk8Module);
/*     */     }
/* 862 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 868 */       Class<? extends Module> parameterNamesModuleClass = ClassUtils.forName("com.fasterxml.jackson.module.paramnames.ParameterNamesModule", this.moduleClassLoader);
/* 869 */       Module parameterNamesModule = (Module)BeanUtils.instantiateClass(parameterNamesModuleClass);
/* 870 */       modulesToRegister.set(parameterNamesModule.getTypeId(), parameterNamesModule);
/*     */     }
/* 872 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 878 */       Class<? extends Module> javaTimeModuleClass = ClassUtils.forName("com.fasterxml.jackson.datatype.jsr310.JavaTimeModule", this.moduleClassLoader);
/* 879 */       Module javaTimeModule = (Module)BeanUtils.instantiateClass(javaTimeModuleClass);
/* 880 */       modulesToRegister.set(javaTimeModule.getTypeId(), javaTimeModule);
/*     */     }
/* 882 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 887 */     if (KotlinDetector.isKotlinPresent()) {
/*     */       
/*     */       try {
/* 890 */         Class<? extends Module> kotlinModuleClass = ClassUtils.forName("com.fasterxml.jackson.module.kotlin.KotlinModule", this.moduleClassLoader);
/* 891 */         Module kotlinModule = (Module)BeanUtils.instantiateClass(kotlinModuleClass);
/* 892 */         modulesToRegister.set(kotlinModule.getTypeId(), kotlinModule);
/*     */       }
/* 894 */       catch (ClassNotFoundException classNotFoundException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Jackson2ObjectMapperBuilder json() {
/* 908 */     return new Jackson2ObjectMapperBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Jackson2ObjectMapperBuilder xml() {
/* 916 */     return (new Jackson2ObjectMapperBuilder()).createXmlMapper(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Jackson2ObjectMapperBuilder smile() {
/* 925 */     return (new Jackson2ObjectMapperBuilder()).factory((new SmileFactoryInitializer()).create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Jackson2ObjectMapperBuilder cbor() {
/* 934 */     return (new Jackson2ObjectMapperBuilder()).factory((new CborFactoryInitializer()).create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Jackson2ObjectMapperBuilder yaml() {
/* 943 */     return (new Jackson2ObjectMapperBuilder()).factory((new YamlFactoryInitializer()).create());
/*     */   }
/*     */ 
/*     */   
/*     */   private static class XmlObjectMapperInitializer
/*     */   {
/*     */     public ObjectMapper create(@Nullable JsonFactory factory) {
/* 950 */       if (factory != null) {
/* 951 */         return (ObjectMapper)new XmlMapper((XmlFactory)factory);
/*     */       }
/*     */       
/* 954 */       return (ObjectMapper)new XmlMapper(StaxUtils.createDefensiveInputFactory());
/*     */     }
/*     */ 
/*     */     
/*     */     public ObjectMapper create(boolean defaultUseWrapper, @Nullable JsonFactory factory) {
/* 959 */       JacksonXmlModule module = new JacksonXmlModule();
/* 960 */       module.setDefaultUseWrapper(defaultUseWrapper);
/* 961 */       if (factory != null) {
/* 962 */         return (ObjectMapper)new XmlMapper((XmlFactory)factory, module);
/*     */       }
/*     */       
/* 965 */       return (ObjectMapper)new XmlMapper(new XmlFactory(StaxUtils.createDefensiveInputFactory()), module);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SmileFactoryInitializer
/*     */   {
/*     */     public JsonFactory create() {
/* 974 */       return (JsonFactory)new SmileFactory();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CborFactoryInitializer
/*     */   {
/*     */     public JsonFactory create() {
/* 982 */       return (JsonFactory)new CBORFactory();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class YamlFactoryInitializer
/*     */   {
/*     */     public JsonFactory create() {
/* 989 */       return (JsonFactory)new YAMLFactory();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\Jackson2ObjectMapperBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */