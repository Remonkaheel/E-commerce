/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import kotlinx.serialization.StringFormat;
/*    */ import kotlinx.serialization.json.Json;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.KotlinSerializationStringHttpMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationJsonHttpMessageConverter
/*    */   extends KotlinSerializationStringHttpMessageConverter<Json>
/*    */ {
/*    */   public KotlinSerializationJsonHttpMessageConverter() {
/* 47 */     this((Json)Json.Default);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public KotlinSerializationJsonHttpMessageConverter(Json json) {
/* 54 */     super((StringFormat)json, new MediaType[] { MediaType.APPLICATION_JSON, new MediaType("application", "*+json") });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\KotlinSerializationJsonHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */