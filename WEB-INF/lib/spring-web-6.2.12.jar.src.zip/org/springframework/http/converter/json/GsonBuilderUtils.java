/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonDeserializer;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonParseException;
/*    */ import com.google.gson.JsonPrimitive;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import com.google.gson.JsonSerializer;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Base64;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GsonBuilderUtils
/*    */ {
/*    */   public static GsonBuilder gsonBuilderWithBase64EncodedByteArrays() {
/* 51 */     GsonBuilder builder = new GsonBuilder();
/* 52 */     builder.registerTypeHierarchyAdapter(byte[].class, new Base64TypeAdapter());
/* 53 */     return builder;
/*    */   }
/*    */ 
/*    */   
/*    */   private static class Base64TypeAdapter
/*    */     implements JsonSerializer<byte[]>, JsonDeserializer<byte[]>
/*    */   {
/*    */     public JsonElement serialize(byte[] src, Type typeOfSrc, JsonSerializationContext context) {
/* 61 */       return (JsonElement)new JsonPrimitive(Base64.getEncoder().encodeToString(src));
/*    */     }
/*    */ 
/*    */     
/*    */     public byte[] deserialize(JsonElement json, Type type, JsonDeserializationContext cxt) {
/* 66 */       return Base64.getDecoder().decode(json.getAsString());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\GsonBuilderUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */