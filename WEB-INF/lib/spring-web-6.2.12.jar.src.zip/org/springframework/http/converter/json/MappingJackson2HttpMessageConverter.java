/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingJackson2HttpMessageConverter
/*     */   extends AbstractJackson2HttpMessageConverter
/*     */ {
/*  51 */   private static final List<MediaType> problemDetailMediaTypes = Collections.singletonList(MediaType.APPLICATION_PROBLEM_JSON);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String jsonPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingJackson2HttpMessageConverter() {
/*  63 */     this(Jackson2ObjectMapperBuilder.json().build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingJackson2HttpMessageConverter(ObjectMapper objectMapper) {
/*  72 */     super(objectMapper, new MediaType[] { MediaType.APPLICATION_JSON, new MediaType("application", "*+json") });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJsonPrefix(String jsonPrefix) {
/*  82 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefixJson(boolean prefixJson) {
/*  93 */     this.jsonPrefix = prefixJson ? ")]}', " : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MediaType> getMediaTypesForProblemDetail() {
/*  99 */     return problemDetailMediaTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePrefix(JsonGenerator generator, Object object) throws IOException {
/* 104 */     if (this.jsonPrefix != null)
/* 105 */       generator.writeRaw(this.jsonPrefix); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\MappingJackson2HttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */