/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.util.DefaultIndenter;
/*     */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ProblemDetail;
/*     */ import org.springframework.http.converter.AbstractGenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2HttpMessageConverter
/*     */   extends AbstractGenericHttpMessageConverter<Object>
/*     */ {
/*  87 */   private static final Map<String, JsonEncoding> ENCODINGS = CollectionUtils.newHashMap((JsonEncoding.values()).length); protected ObjectMapper defaultObjectMapper; @Nullable
/*  88 */   private Map<Class<?>, Map<MediaType, ObjectMapper>> objectMapperRegistrations; static { for (JsonEncoding encoding : JsonEncoding.values()) {
/*  89 */       ENCODINGS.put(encoding.getJavaName(), encoding);
/*     */     }
/*  91 */     ENCODINGS.put("US-ASCII", JsonEncoding.UTF8); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final PrettyPrinter ssePrettyPrinter;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper) {
/* 108 */     this.defaultObjectMapper = objectMapper;
/* 109 */     DefaultPrettyPrinter prettyPrinter = new DefaultPrettyPrinter();
/* 110 */     prettyPrinter.indentObjectsWith((DefaultPrettyPrinter.Indenter)new DefaultIndenter("  ", "\ndata:"));
/* 111 */     this.ssePrettyPrinter = (PrettyPrinter)prettyPrinter;
/*     */   }
/*     */   
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType supportedMediaType) {
/* 115 */     this(objectMapper);
/* 116 */     setSupportedMediaTypes(Collections.singletonList(supportedMediaType));
/*     */   }
/*     */   
/*     */   protected AbstractJackson2HttpMessageConverter(ObjectMapper objectMapper, MediaType... supportedMediaTypes) {
/* 120 */     this(objectMapper);
/* 121 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes) {
/* 127 */     super.setSupportedMediaTypes(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjectMapper(ObjectMapper objectMapper) {
/* 143 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/* 144 */     this.defaultObjectMapper = objectMapper;
/* 145 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMapper getObjectMapper() {
/* 152 */     return this.defaultObjectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerObjectMappersForType(Class<?> clazz, Consumer<Map<MediaType, ObjectMapper>> registrar) {
/* 172 */     if (this.objectMapperRegistrations == null) {
/* 173 */       this.objectMapperRegistrations = new LinkedHashMap<>();
/*     */     }
/*     */     
/* 176 */     Map<MediaType, ObjectMapper> registrations = this.objectMapperRegistrations.computeIfAbsent(clazz, c -> new LinkedHashMap<>());
/* 177 */     registrar.accept(registrations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<MediaType, ObjectMapper> getObjectMappersForType(Class<?> clazz) {
/* 188 */     for (Map.Entry<Class<?>, Map<MediaType, ObjectMapper>> entry : getObjectMapperRegistrations().entrySet()) {
/* 189 */       if (((Class)entry.getKey()).isAssignableFrom(clazz)) {
/* 190 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 193 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getSupportedMediaTypes(Class<?> clazz) {
/* 198 */     List<MediaType> result = null;
/* 199 */     for (Map.Entry<Class<?>, Map<MediaType, ObjectMapper>> entry : getObjectMapperRegistrations().entrySet()) {
/* 200 */       if (((Class)entry.getKey()).isAssignableFrom(clazz)) {
/* 201 */         result = (result != null) ? result : new ArrayList<>(((Map)entry.getValue()).size());
/* 202 */         result.addAll(((Map)entry.getValue()).keySet());
/*     */       } 
/*     */     } 
/* 205 */     if (!CollectionUtils.isEmpty(result)) {
/* 206 */       return result;
/*     */     }
/* 208 */     return ProblemDetail.class.isAssignableFrom(clazz) ? 
/* 209 */       getMediaTypesForProblemDetail() : getSupportedMediaTypes();
/*     */   }
/*     */   
/*     */   private Map<Class<?>, Map<MediaType, ObjectMapper>> getObjectMapperRegistrations() {
/* 213 */     return (this.objectMapperRegistrations != null) ? this.objectMapperRegistrations : Collections.<Class<?>, Map<MediaType, ObjectMapper>>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MediaType> getMediaTypesForProblemDetail() {
/* 222 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrettyPrint(boolean prettyPrint) {
/* 235 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 236 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */   private void configurePrettyPrint() {
/* 240 */     if (this.prettyPrint != null) {
/* 241 */       this.defaultObjectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 248 */     return canRead(clazz, (Class<?>)null, mediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Type type, @Nullable Class<?> contextClass, @Nullable MediaType mediaType) {
/* 254 */     if (!canRead(mediaType)) {
/* 255 */       return false;
/*     */     }
/* 257 */     JavaType javaType = getJavaType(type, contextClass);
/* 258 */     ObjectMapper objectMapper = selectObjectMapper(javaType.getRawClass(), mediaType);
/* 259 */     if (objectMapper == null) {
/* 260 */       return false;
/*     */     }
/* 262 */     AtomicReference<Throwable> causeRef = new AtomicReference<>();
/* 263 */     if (objectMapper.canDeserialize(javaType, causeRef)) {
/* 264 */       return true;
/*     */     }
/* 266 */     logWarningIfNecessary((Type)javaType, causeRef.get());
/* 267 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 273 */     if (!canWrite(mediaType)) {
/* 274 */       return false;
/*     */     }
/* 276 */     if (mediaType != null && mediaType.getCharset() != null) {
/* 277 */       Charset charset = mediaType.getCharset();
/* 278 */       if (!ENCODINGS.containsKey(charset.name())) {
/* 279 */         return false;
/*     */       }
/*     */     } 
/* 282 */     ObjectMapper objectMapper = selectObjectMapper(clazz, mediaType);
/* 283 */     if (objectMapper == null) {
/* 284 */       return false;
/*     */     }
/* 286 */     AtomicReference<Throwable> causeRef = new AtomicReference<>();
/* 287 */     if (objectMapper.canSerialize(clazz, causeRef)) {
/* 288 */       return true;
/*     */     }
/* 290 */     logWarningIfNecessary(clazz, causeRef.get());
/* 291 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ObjectMapper selectObjectMapper(Class<?> targetType, @Nullable MediaType targetMediaType) {
/* 301 */     if (targetMediaType == null || CollectionUtils.isEmpty(this.objectMapperRegistrations)) {
/* 302 */       return this.defaultObjectMapper;
/*     */     }
/* 304 */     for (Map.Entry<Class<?>, Map<MediaType, ObjectMapper>> typeEntry : getObjectMapperRegistrations().entrySet()) {
/* 305 */       if (((Class)typeEntry.getKey()).isAssignableFrom(targetType)) {
/* 306 */         for (Map.Entry<MediaType, ObjectMapper> objectMapperEntry : (Iterable<Map.Entry<MediaType, ObjectMapper>>)((Map)typeEntry.getValue()).entrySet()) {
/* 307 */           if (((MediaType)objectMapperEntry.getKey()).includes(targetMediaType)) {
/* 308 */             return objectMapperEntry.getValue();
/*     */           }
/*     */         } 
/*     */         
/* 312 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 316 */     return this.defaultObjectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logWarningIfNecessary(Type type, @Nullable Throwable cause) {
/* 328 */     if (cause == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 334 */     boolean debugLevel = (cause instanceof com.fasterxml.jackson.databind.JsonMappingException && cause.getMessage() != null && cause.getMessage().startsWith("Cannot find"));
/*     */     
/* 336 */     if (debugLevel ? this.logger.isDebugEnabled() : this.logger.isWarnEnabled()) {
/* 337 */       String msg = "Failed to evaluate Jackson " + ((type instanceof JavaType) ? "de" : "") + "serialization for type [" + String.valueOf(type) + "]";
/*     */       
/* 339 */       if (debugLevel) {
/* 340 */         this.logger.debug(msg, cause);
/*     */       }
/* 342 */       else if (this.logger.isDebugEnabled()) {
/* 343 */         this.logger.warn(msg, cause);
/*     */       } else {
/*     */         
/* 346 */         this.logger.warn(msg + ": " + msg);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object read(Type type, @Nullable Class<?> contextClass, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 355 */     JavaType javaType = getJavaType(type, contextClass);
/* 356 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 363 */     JavaType javaType = getJavaType(clazz, (Class<?>)null);
/* 364 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */   
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) throws IOException {
/* 368 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 369 */     Charset charset = getCharset(contentType);
/*     */     
/* 371 */     ObjectMapper objectMapper = selectObjectMapper(javaType.getRawClass(), contentType);
/* 372 */     Assert.state((objectMapper != null), () -> "No ObjectMapper for " + String.valueOf(javaType));
/*     */ 
/*     */ 
/*     */     
/* 376 */     boolean isUnicode = (ENCODINGS.containsKey(charset.name()) || "UTF-16".equals(charset.name()) || "UTF-32".equals(charset.name()));
/*     */     try {
/* 378 */       InputStream inputStream = StreamUtils.nonClosing(inputMessage.getBody());
/* 379 */       if (inputMessage instanceof MappingJacksonInputMessage) { MappingJacksonInputMessage mappingJacksonInputMessage = (MappingJacksonInputMessage)inputMessage;
/* 380 */         Class<?> deserializationView = mappingJacksonInputMessage.getDeserializationView();
/* 381 */         if (deserializationView != null) {
/* 382 */           ObjectReader objectReader1 = objectMapper.readerWithView(deserializationView).forType(javaType);
/* 383 */           objectReader1 = customizeReader(objectReader1, javaType);
/* 384 */           if (isUnicode) {
/* 385 */             return objectReader1.readValue(inputStream);
/*     */           }
/*     */           
/* 388 */           Reader reader1 = new InputStreamReader(inputStream, charset);
/* 389 */           return objectReader1.readValue(reader1);
/*     */         }  }
/*     */ 
/*     */ 
/*     */       
/* 394 */       ObjectReader objectReader = objectMapper.reader().forType(javaType);
/* 395 */       objectReader = customizeReader(objectReader, javaType);
/* 396 */       if (isUnicode) {
/* 397 */         return objectReader.readValue(inputStream);
/*     */       }
/*     */       
/* 400 */       Reader reader = new InputStreamReader(inputStream, charset);
/* 401 */       return objectReader.readValue(reader);
/*     */     
/*     */     }
/* 404 */     catch (InvalidDefinitionException ex) {
/* 405 */       throw new HttpMessageConversionException("Type definition error: " + String.valueOf(ex.getType()), ex);
/*     */     }
/* 407 */     catch (JsonProcessingException ex) {
/* 408 */       throw new HttpMessageNotReadableException("JSON parse error: " + ex.getOriginalMessage(), ex, inputMessage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectReader customizeReader(ObjectReader reader, JavaType javaType) {
/* 421 */     return reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Charset getCharset(@Nullable MediaType contentType) {
/* 433 */     if (contentType != null && contentType.getCharset() != null) {
/* 434 */       return contentType.getCharset();
/*     */     }
/*     */     
/* 437 */     return StandardCharsets.UTF_8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(Object object, @Nullable Type type, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 445 */     MediaType contentType = outputMessage.getHeaders().getContentType();
/* 446 */     JsonEncoding encoding = getJsonEncoding(contentType);
/*     */     
/* 448 */     MappingJacksonValue mappingJacksonValue = (MappingJacksonValue)object;
/* 449 */     Class<?> clazz = (object instanceof MappingJacksonValue) ? mappingJacksonValue.getValue().getClass() : object.getClass();
/* 450 */     ObjectMapper objectMapper = selectObjectMapper(clazz, contentType);
/* 451 */     Assert.state((objectMapper != null), () -> "No ObjectMapper for " + clazz.getName());
/*     */     
/* 453 */     OutputStream outputStream = StreamUtils.nonClosing(outputMessage.getBody()); 
/* 454 */     try { JsonGenerator generator = objectMapper.getFactory().createGenerator(outputStream, encoding); 
/* 455 */       try { writePrefix(generator, object);
/*     */         
/* 457 */         Object value = object;
/* 458 */         Class<?> serializationView = null;
/* 459 */         FilterProvider filters = null;
/* 460 */         JavaType javaType = null;
/*     */         
/* 462 */         if (object instanceof MappingJacksonValue) { MappingJacksonValue mappingJacksonValue1 = (MappingJacksonValue)object;
/* 463 */           value = mappingJacksonValue1.getValue();
/* 464 */           serializationView = mappingJacksonValue1.getSerializationView();
/* 465 */           filters = mappingJacksonValue1.getFilters(); }
/*     */         
/* 467 */         if (type != null && TypeUtils.isAssignable(type, value.getClass())) {
/* 468 */           javaType = getJavaType(type, (Class<?>)null);
/*     */         }
/*     */ 
/*     */         
/* 472 */         ObjectWriter objectWriter = (serializationView != null) ? objectMapper.writerWithView(serializationView) : objectMapper.writer();
/* 473 */         if (filters != null) {
/* 474 */           objectWriter = objectWriter.with(filters);
/*     */         }
/* 476 */         if (javaType != null && (javaType.isContainerType() || javaType.isTypeOrSubTypeOf(Optional.class))) {
/* 477 */           objectWriter = objectWriter.forType(javaType);
/*     */         }
/* 479 */         SerializationConfig config = objectWriter.getConfig();
/* 480 */         if (contentType != null && contentType.isCompatibleWith(MediaType.TEXT_EVENT_STREAM) && config
/* 481 */           .isEnabled(SerializationFeature.INDENT_OUTPUT)) {
/* 482 */           objectWriter = objectWriter.with(this.ssePrettyPrinter);
/*     */         }
/* 484 */         objectWriter = customizeWriter(objectWriter, javaType, contentType);
/* 485 */         objectWriter.writeValue(generator, value);
/*     */         
/* 487 */         writeSuffix(generator, object);
/* 488 */         generator.flush();
/* 489 */         if (generator != null) generator.close();  } catch (Throwable throwable) { if (generator != null)
/* 490 */           try { generator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (InvalidDefinitionException ex)
/* 491 */     { throw new HttpMessageConversionException("Type definition error: " + String.valueOf(ex.getType()), ex); }
/*     */     
/* 493 */     catch (JsonProcessingException ex)
/* 494 */     { throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getOriginalMessage(), ex); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectWriter customizeWriter(ObjectWriter writer, @Nullable JavaType javaType, @Nullable MediaType contentType) {
/* 510 */     return writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writePrefix(JsonGenerator generator, Object object) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeSuffix(JsonGenerator generator, Object object) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType getJavaType(Type type, @Nullable Class<?> contextClass) {
/* 537 */     return this.defaultObjectMapper.constructType(GenericTypeResolver.resolveType(type, contextClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonEncoding getJsonEncoding(@Nullable MediaType contentType) {
/* 546 */     if (contentType != null && contentType.getCharset() != null) {
/* 547 */       Charset charset = contentType.getCharset();
/* 548 */       JsonEncoding encoding = ENCODINGS.get(charset.name());
/* 549 */       if (encoding != null) {
/* 550 */         return encoding;
/*     */       }
/*     */     } 
/* 553 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MediaType getDefaultContentType(Object object) throws IOException {
/* 559 */     if (object instanceof MappingJacksonValue) { MappingJacksonValue mappingJacksonValue = (MappingJacksonValue)object;
/* 560 */       object = mappingJacksonValue.getValue(); }
/*     */     
/* 562 */     return super.getDefaultContentType(object);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Long getContentLength(Object object, @Nullable MediaType contentType) throws IOException {
/* 568 */     if (object instanceof MappingJacksonValue) { MappingJacksonValue mappingJacksonValue = (MappingJacksonValue)object;
/* 569 */       object = mappingJacksonValue.getValue(); }
/*     */     
/* 571 */     return super.getContentLength(object, contentType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Object o) {
/* 576 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\AbstractJackson2HttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */