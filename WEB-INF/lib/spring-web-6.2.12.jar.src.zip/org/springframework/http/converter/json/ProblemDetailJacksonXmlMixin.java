package org.springframework.http.converter.json;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import java.net.URI;
import java.util.Map;
import org.springframework.lang.Nullable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JacksonXmlRootElement(localName = "problem", namespace = "urn:ietf:rfc:7807")
public interface ProblemDetailJacksonXmlMixin {
  public static final String NAMESPACE = "urn:ietf:rfc:7807";
  
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  URI getType();
  
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  String getTitle();
  
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  int getStatus();
  
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  String getDetail();
  
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  URI getInstance();
  
  @JsonAnySetter
  void setProperty(String paramString, @Nullable Object paramObject);
  
  @JsonAnyGetter
  @JacksonXmlProperty(namespace = "urn:ietf:rfc:7807")
  Map<String, Object> getProperties();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\ProblemDetailJacksonXmlMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */