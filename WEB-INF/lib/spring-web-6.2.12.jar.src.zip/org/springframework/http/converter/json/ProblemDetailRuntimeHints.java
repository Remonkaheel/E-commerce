/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import org.springframework.aot.hint.BindingReflectionHintsRegistrar;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.http.ProblemDetail;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProblemDetailRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 38 */     BindingReflectionHintsRegistrar bindingRegistrar = new BindingReflectionHintsRegistrar();
/* 39 */     bindingRegistrar.registerReflectionHints(hints.reflection(), new Type[] { ProblemDetail.class });
/* 40 */     if (ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", classLoader)) {
/* 41 */       bindingRegistrar.registerReflectionHints(hints.reflection(), new Type[] { ProblemDetailJacksonXmlMixin.class });
/*    */     }
/* 43 */     else if (ClassUtils.isPresent("com.fasterxml.jackson.annotation.JacksonAnnotation", classLoader)) {
/* 44 */       bindingRegistrar.registerReflectionHints(hints.reflection(), new Type[] { ProblemDetailJacksonMixin.class });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\ProblemDetailRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */