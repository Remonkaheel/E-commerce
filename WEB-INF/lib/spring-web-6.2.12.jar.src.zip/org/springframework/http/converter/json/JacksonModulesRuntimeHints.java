/*    */ package org.springframework.http.converter.json;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JacksonModulesRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   private static final Consumer<TypeHint.Builder> asJacksonModule;
/*    */   
/*    */   static {
/* 37 */     asJacksonModule = (builder -> builder.onReachableType(Jackson2ObjectMapperBuilder.class).withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 43 */     hints.reflection()
/* 44 */       .registerTypeIfPresent(classLoader, "com.fasterxml.jackson.datatype.jdk8.Jdk8Module", asJacksonModule)
/*    */       
/* 46 */       .registerTypeIfPresent(classLoader, "com.fasterxml.jackson.datatype.jsr310.JavaTimeModule", asJacksonModule)
/*    */       
/* 48 */       .registerTypeIfPresent(classLoader, "com.fasterxml.jackson.module.kotlin.KotlinModule", asJacksonModule);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\JacksonModulesRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */