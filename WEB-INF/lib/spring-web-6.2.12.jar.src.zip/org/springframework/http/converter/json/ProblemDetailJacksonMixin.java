package org.springframework.http.converter.json;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Map;
import org.springframework.lang.Nullable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public interface ProblemDetailJacksonMixin {
  @JsonAnySetter
  void setProperty(String paramString, @Nullable Object paramObject);
  
  @JsonAnyGetter
  Map<String, Object> getProperties();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\json\ProblemDetailJacksonMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */