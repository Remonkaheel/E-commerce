/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import kotlinx.serialization.DeserializationStrategy;
/*    */ import kotlinx.serialization.KSerializer;
/*    */ import kotlinx.serialization.SerialFormat;
/*    */ import kotlinx.serialization.SerializationException;
/*    */ import kotlinx.serialization.SerializationStrategy;
/*    */ import kotlinx.serialization.StringFormat;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KotlinSerializationStringHttpMessageConverter<T extends StringFormat>
/*    */   extends AbstractKotlinSerializationHttpMessageConverter<T>
/*    */ {
/*    */   protected KotlinSerializationStringHttpMessageConverter(T format, MediaType... supportedMediaTypes) {
/* 53 */     super(format, supportedMediaTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object readInternal(KSerializer<Object> serializer, T format, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 61 */     Charset charset = charset(inputMessage.getHeaders().getContentType());
/* 62 */     String s = StreamUtils.copyToString(inputMessage.getBody(), charset);
/*    */     try {
/* 64 */       return format.decodeFromString((DeserializationStrategy)serializer, s);
/*    */     }
/* 66 */     catch (SerializationException ex) {
/* 67 */       throw new HttpMessageNotReadableException("Could not read " + String.valueOf(format) + ": " + ex.getMessage(), ex, inputMessage);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void writeInternal(Object object, KSerializer<Object> serializer, T format, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*    */     try {
/* 77 */       String s = format.encodeToString((SerializationStrategy)serializer, object);
/* 78 */       Charset charset = charset(outputMessage.getHeaders().getContentType());
/* 79 */       outputMessage.getBody().write(s.getBytes(charset));
/* 80 */       outputMessage.getBody().flush();
/*    */     }
/* 82 */     catch (SerializationException ex) {
/* 83 */       throw new HttpMessageNotWritableException("Could not write " + String.valueOf(format) + ": " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static Charset charset(@Nullable MediaType contentType) {
/* 88 */     if (contentType != null && contentType.getCharset() != null) {
/* 89 */       return contentType.getCharset();
/*    */     }
/* 91 */     return StandardCharsets.UTF_8;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\KotlinSerializationStringHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */