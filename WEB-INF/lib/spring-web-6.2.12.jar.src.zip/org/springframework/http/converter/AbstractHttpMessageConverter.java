/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttpMessageConverter<T>
/*     */   implements HttpMessageConverter<T>
/*     */ {
/*  53 */   protected final Log logger = HttpLogging.forLogName(getClass());
/*     */   
/*  55 */   private List<MediaType> supportedMediaTypes = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Charset defaultCharset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpMessageConverter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpMessageConverter(MediaType supportedMediaType) {
/*  73 */     setSupportedMediaTypes(Collections.singletonList(supportedMediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpMessageConverter(MediaType... supportedMediaTypes) {
/*  81 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpMessageConverter(Charset defaultCharset, MediaType... supportedMediaTypes) {
/*  92 */     this.defaultCharset = defaultCharset;
/*  93 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes) {
/* 101 */     Assert.notEmpty(supportedMediaTypes, "MediaType List must not be empty");
/* 102 */     this.supportedMediaTypes = List.copyOf(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getSupportedMediaTypes() {
/* 107 */     return this.supportedMediaTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(@Nullable Charset defaultCharset) {
/* 115 */     this.defaultCharset = defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Charset getDefaultCharset() {
/* 124 */     return this.defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/* 135 */     return (supports(clazz) && canRead(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canRead(@Nullable MediaType mediaType) {
/* 148 */     if (mediaType == null) {
/* 149 */       return true;
/*     */     }
/* 151 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 152 */       if (supportedMediaType.includes(mediaType)) {
/* 153 */         return true;
/*     */       }
/*     */     } 
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/* 167 */     return (supports(clazz) && canWrite(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canWrite(@Nullable MediaType mediaType) {
/* 179 */     if (mediaType == null || MediaType.ALL.equalsTypeAndSubtype((MimeType)mediaType)) {
/* 180 */       return true;
/*     */     }
/* 182 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 183 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 184 */         return true;
/*     */       }
/*     */     } 
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T read(Class<? extends T> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 198 */     return readInternal(clazz, inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(final T t, @Nullable MediaType contentType, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 209 */     final HttpHeaders headers = outputMessage.getHeaders();
/* 210 */     addDefaultHeaders(headers, t, contentType);
/*     */     
/* 212 */     if (outputMessage instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/* 213 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */           {
/*     */             public void writeTo(final OutputStream outputStream) throws IOException {
/* 216 */               AbstractHttpMessageConverter.this.writeInternal(t, new HttpOutputMessage()
/*     */                   {
/*     */                     public OutputStream getBody() {
/* 219 */                       return outputStream;
/*     */                     }
/*     */                     
/*     */                     public HttpHeaders getHeaders() {
/* 223 */                       return headers;
/*     */                     }
/*     */                   });
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean repeatable() {
/* 230 */               return AbstractHttpMessageConverter.this.supportsRepeatableWrites(t);
/*     */             }
/*     */           }); }
/*     */     else
/*     */     
/* 235 */     { writeInternal(t, outputMessage);
/* 236 */       outputMessage.getBody().flush(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addDefaultHeaders(HttpHeaders headers, T t, @Nullable MediaType contentType) throws IOException {
/* 248 */     if (headers.getContentType() == null) {
/* 249 */       MediaType contentTypeToUse = contentType;
/* 250 */       if (contentType == null || !contentType.isConcrete()) {
/* 251 */         contentTypeToUse = getDefaultContentType(t);
/*     */       }
/* 253 */       else if (MediaType.APPLICATION_OCTET_STREAM.equals(contentType)) {
/* 254 */         MediaType mediaType = getDefaultContentType(t);
/* 255 */         contentTypeToUse = (mediaType != null) ? mediaType : contentTypeToUse;
/*     */       } 
/* 257 */       if (contentTypeToUse != null) {
/* 258 */         if (contentTypeToUse.getCharset() == null) {
/* 259 */           Charset defaultCharset = getDefaultCharset();
/* 260 */           if (defaultCharset != null) {
/* 261 */             contentTypeToUse = new MediaType(contentTypeToUse, defaultCharset);
/*     */           }
/*     */         } 
/* 264 */         headers.setContentType(contentTypeToUse);
/*     */       } 
/*     */     } 
/* 267 */     if (headers.getContentLength() < 0L && !headers.containsKey("Transfer-Encoding")) {
/* 268 */       Long contentLength = getContentLength(t, headers.getContentType());
/* 269 */       if (contentLength != null) {
/* 270 */         headers.setContentLength(contentLength.longValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected MediaType getDefaultContentType(T t) throws IOException {
/* 286 */     List<MediaType> mediaTypes = getSupportedMediaTypes();
/* 287 */     return !mediaTypes.isEmpty() ? mediaTypes.get(0) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Long getContentLength(T t, @Nullable MediaType contentType) throws IOException {
/* 299 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(T t) {
/* 313 */     return false;
/*     */   }
/*     */   
/*     */   protected abstract boolean supports(Class<?> paramClass);
/*     */   
/*     */   protected abstract T readInternal(Class<? extends T> paramClass, HttpInputMessage paramHttpInputMessage) throws IOException, HttpMessageNotReadableException;
/*     */   
/*     */   protected abstract void writeInternal(T paramT, HttpOutputMessage paramHttpOutputMessage) throws IOException, HttpMessageNotWritableException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\AbstractHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */