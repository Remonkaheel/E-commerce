/*    */ package org.springframework.http.converter.cbor;
/*    */ 
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.cbor.Cbor;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.KotlinSerializationBinaryHttpMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KotlinSerializationCborHttpMessageConverter
/*    */   extends KotlinSerializationBinaryHttpMessageConverter<Cbor>
/*    */ {
/*    */   public KotlinSerializationCborHttpMessageConverter() {
/* 39 */     this((Cbor)Cbor.Default);
/*    */   }
/*    */   
/*    */   public KotlinSerializationCborHttpMessageConverter(Cbor cbor) {
/* 43 */     super((BinaryFormat)cbor, new MediaType[] { MediaType.APPLICATION_CBOR });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\cbor\KotlinSerializationCborHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */