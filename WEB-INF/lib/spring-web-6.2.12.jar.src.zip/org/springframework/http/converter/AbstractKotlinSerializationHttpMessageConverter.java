/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KType;
/*     */ import kotlin.reflect.full.KCallables;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import kotlinx.serialization.KSerializer;
/*     */ import kotlinx.serialization.SerialFormat;
/*     */ import kotlinx.serialization.SerializersKt;
/*     */ import kotlinx.serialization.descriptors.PolymorphicKind;
/*     */ import kotlinx.serialization.descriptors.SerialDescriptor;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractKotlinSerializationHttpMessageConverter<T extends SerialFormat>
/*     */   extends AbstractSmartHttpMessageConverter<Object>
/*     */ {
/*  62 */   private final Map<KType, KSerializer<Object>> kTypeSerializerCache = (Map<KType, KSerializer<Object>>)new ConcurrentReferenceHashMap();
/*     */   
/*  64 */   private final Map<Type, KSerializer<Object>> typeSerializerCache = (Map<Type, KSerializer<Object>>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final T format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractKotlinSerializationHttpMessageConverter(T format, MediaType... supportedMediaTypes) {
/*  76 */     super(supportedMediaTypes);
/*  77 */     this.format = format;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<MediaType> getSupportedMediaTypes(Class<?> clazz) {
/*  82 */     return getSupportedMediaTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/*  87 */     return (serializer(ResolvableType.forClass(clazz)) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(ResolvableType type, @Nullable MediaType mediaType) {
/*  92 */     if (!ResolvableType.NONE.equals(type) && serializer(type) != null) {
/*  93 */       return canRead(mediaType);
/*     */     }
/*     */     
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(ResolvableType type, Class<?> clazz, @Nullable MediaType mediaType) {
/* 102 */     if (!ResolvableType.NONE.equals(type) && serializer(type) != null) {
/* 103 */       return canWrite(mediaType);
/*     */     }
/*     */     
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object read(ResolvableType type, HttpInputMessage inputMessage, @Nullable Map<String, Object> hints) throws IOException, HttpMessageNotReadableException {
/* 114 */     KSerializer<Object> serializer = serializer(type);
/* 115 */     if (serializer == null) {
/* 116 */       throw new HttpMessageNotReadableException("Could not find KSerializer for " + String.valueOf(type), inputMessage);
/*     */     }
/* 118 */     return readInternal(serializer, this.format, inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object readInternal(KSerializer<Object> paramKSerializer, T paramT, HttpInputMessage paramHttpInputMessage) throws IOException, HttpMessageNotReadableException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void writeInternal(Object object, ResolvableType type, HttpOutputMessage outputMessage, @Nullable Map<String, Object> hints) throws IOException, HttpMessageNotWritableException {
/* 131 */     ResolvableType resolvableType = ResolvableType.NONE.equals(type) ? ResolvableType.forInstance(object) : type;
/* 132 */     KSerializer<Object> serializer = serializer(resolvableType);
/* 133 */     if (serializer == null) {
/* 134 */       throw new HttpMessageNotWritableException("Could not find KSerializer for " + String.valueOf(resolvableType));
/*     */     }
/* 136 */     writeInternal(object, serializer, this.format, outputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void writeInternal(Object paramObject, KSerializer<Object> paramKSerializer, T paramT, HttpOutputMessage paramHttpOutputMessage) throws IOException, HttpMessageNotWritableException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private KSerializer<Object> serializer(ResolvableType resolvableType) {
/* 154 */     Object object = resolvableType.getSource(); if (object instanceof MethodParameter) { MethodParameter parameter = (MethodParameter)object;
/* 155 */       Method method = parameter.getMethod();
/* 156 */       Assert.notNull(method, "Method must not be null");
/* 157 */       if (KotlinDetector.isKotlinType(method.getDeclaringClass())) {
/* 158 */         KFunction<?> function = ReflectJvmMapping.getKotlinFunction(method);
/* 159 */         if (function != null) {
/*     */           
/* 161 */           KType kType = (parameter.getParameterIndex() == -1) ? function.getReturnType() : ((KParameter)KCallables.getValueParameters((KCallable)function).get(parameter.getParameterIndex())).getType();
/* 162 */           KSerializer<Object> kSerializer = this.kTypeSerializerCache.get(kType);
/* 163 */           if (kSerializer == null) {
/*     */             try {
/* 165 */               kSerializer = SerializersKt.serializerOrNull(this.format.getSerializersModule(), kType);
/*     */             }
/* 167 */             catch (IllegalArgumentException illegalArgumentException) {}
/*     */             
/* 169 */             if (kSerializer != null) {
/* 170 */               if (hasPolymorphism(kSerializer.getDescriptor(), new HashSet<>())) {
/* 171 */                 return null;
/*     */               }
/* 173 */               this.kTypeSerializerCache.put(kType, kSerializer);
/*     */             } 
/*     */           } 
/* 176 */           return kSerializer;
/*     */         } 
/*     */       }  }
/*     */     
/* 180 */     Type type = resolvableType.getType();
/* 181 */     KSerializer<Object> serializer = this.typeSerializerCache.get(type);
/* 182 */     if (serializer == null) {
/*     */       try {
/* 184 */         serializer = SerializersKt.serializerOrNull(this.format.getSerializersModule(), type);
/*     */       }
/* 186 */       catch (IllegalArgumentException illegalArgumentException) {}
/*     */       
/* 188 */       if (serializer != null) {
/* 189 */         if (hasPolymorphism(serializer.getDescriptor(), new HashSet<>())) {
/* 190 */           return null;
/*     */         }
/* 192 */         this.typeSerializerCache.put(type, serializer);
/*     */       } 
/*     */     } 
/* 195 */     return serializer;
/*     */   }
/*     */   
/*     */   private boolean hasPolymorphism(SerialDescriptor descriptor, Set<String> alreadyProcessed) {
/* 199 */     alreadyProcessed.add(descriptor.getSerialName());
/* 200 */     if (descriptor.getKind().equals(PolymorphicKind.OPEN.INSTANCE)) {
/* 201 */       return true;
/*     */     }
/* 203 */     for (int i = 0; i < descriptor.getElementsCount(); i++) {
/* 204 */       SerialDescriptor elementDescriptor = descriptor.getElementDescriptor(i);
/* 205 */       if (!alreadyProcessed.contains(elementDescriptor.getSerialName()) && hasPolymorphism(elementDescriptor, alreadyProcessed)) {
/* 206 */         return true;
/*     */       }
/*     */     } 
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Object object) {
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\AbstractKotlinSerializationHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */