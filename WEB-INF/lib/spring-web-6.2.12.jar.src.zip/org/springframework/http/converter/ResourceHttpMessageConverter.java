/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<Resource>
/*     */ {
/*     */   private final boolean supportsReadStreaming;
/*     */   
/*     */   public ResourceHttpMessageConverter() {
/*  57 */     super(MediaType.ALL);
/*  58 */     this.supportsReadStreaming = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceHttpMessageConverter(boolean supportsReadStreaming) {
/*  68 */     super(MediaType.ALL);
/*  69 */     this.supportsReadStreaming = supportsReadStreaming;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/*  75 */     return Resource.class.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Resource readInternal(Class<? extends Resource> clazz, final HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/*  82 */     if (this.supportsReadStreaming && InputStreamResource.class == clazz) {
/*  83 */       return (Resource)new InputStreamResource(inputMessage.getBody())
/*     */         {
/*     */           @Nullable
/*     */           public String getFilename() {
/*  87 */             return inputMessage.getHeaders().getContentDisposition().getFilename();
/*     */           }
/*     */           
/*     */           public long contentLength() throws IOException {
/*  91 */             long length = inputMessage.getHeaders().getContentLength();
/*  92 */             return (length != -1L) ? length : super.contentLength();
/*     */           }
/*     */         };
/*     */     }
/*  96 */     if (Resource.class == clazz || ByteArrayResource.class.isAssignableFrom(clazz)) {
/*  97 */       byte[] body = StreamUtils.copyToByteArray(inputMessage.getBody());
/*  98 */       return (Resource)new ByteArrayResource(body)
/*     */         {
/*     */           @Nullable
/*     */           public String getFilename() {
/* 102 */             return inputMessage.getHeaders().getContentDisposition().getFilename();
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 107 */     throw new HttpMessageNotReadableException("Unsupported resource class: " + String.valueOf(clazz), inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(Resource resource, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 115 */     writeContent(resource, outputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefaultHeaders(HttpOutputMessage message, Resource resource, @Nullable MediaType contentType) throws IOException {
/* 125 */     addDefaultHeaders(message.getHeaders(), resource, contentType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MediaType getDefaultContentType(Resource resource) {
/* 130 */     return MediaTypeFactory.getMediaType(resource).orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Long getContentLength(Resource resource, @Nullable MediaType contentType) throws IOException {
/* 138 */     if (InputStreamResource.class == resource.getClass()) {
/* 139 */       return null;
/*     */     }
/* 141 */     long contentLength = resource.contentLength();
/* 142 */     return (contentLength < 0L) ? null : Long.valueOf(contentLength);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Resource resource) {
/* 147 */     return !(resource instanceof InputStreamResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeContent(Resource resource, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*     */     try {
/* 157 */       InputStream in = resource.getInputStream();
/*     */       
/* 159 */       try { OutputStream out = outputMessage.getBody();
/* 160 */         in.transferTo(out);
/* 161 */         out.flush(); }
/*     */       
/* 163 */       catch (NullPointerException nullPointerException)
/*     */       
/*     */       { 
/*     */         try {
/*     */           
/* 168 */           in.close();
/*     */         }
/* 170 */         catch (Throwable throwable) {} } finally { try { in.close(); } catch (Throwable throwable) {}
/*     */          }
/*     */ 
/*     */     
/*     */     }
/* 175 */     catch (FileNotFoundException fileNotFoundException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\ResourceHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */