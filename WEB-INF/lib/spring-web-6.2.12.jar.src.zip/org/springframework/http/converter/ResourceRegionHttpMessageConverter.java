/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collection;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceRegion;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceRegionHttpMessageConverter
/*     */   extends AbstractGenericHttpMessageConverter<Object>
/*     */ {
/*     */   public ResourceRegionHttpMessageConverter() {
/*  52 */     super(MediaType.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(Class<?> clazz, @Nullable MediaType mediaType) {
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(Type type, @Nullable Class<?> contextClass, @Nullable MediaType mediaType) {
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object read(Type type, @Nullable Class<?> contextClass, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceRegion readInternal(Class<?> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/*  77 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Class<?> clazz, @Nullable MediaType mediaType) {
/*  82 */     return canWrite(clazz, null, mediaType);
/*     */   }
/*     */   public boolean canWrite(@Nullable Type type, @Nullable Class<?> clazz, @Nullable MediaType mediaType) {
/*     */     ParameterizedType parameterizedType;
/*     */     Class<?> rawType, typeArgumentClass;
/*  87 */     if (type instanceof ParameterizedType) { parameterizedType = (ParameterizedType)type; }
/*  88 */     else { if (type instanceof Class) { Class<?> c = (Class)type; if (ResourceRegion.class.isAssignableFrom(c)); }  return false; }
/*     */     
/*  90 */     Type type1 = parameterizedType.getRawType(); if (type1 instanceof Class) { rawType = (Class)type1; }
/*  91 */     else { return false; }
/*     */     
/*  93 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  94 */       return false;
/*     */     }
/*  96 */     if ((parameterizedType.getActualTypeArguments()).length != 1) {
/*  97 */       return false;
/*     */     }
/*  99 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/* 100 */     if (typeArgument instanceof Class) { typeArgumentClass = (Class)typeArgument; }
/* 101 */     else { return false; }
/*     */     
/* 103 */     return ResourceRegion.class.isAssignableFrom(typeArgumentClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(Object object, @Nullable Type type, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 110 */     if (object instanceof ResourceRegion) { ResourceRegion resourceRegion = (ResourceRegion)object;
/* 111 */       writeResourceRegion(resourceRegion, outputMessage); }
/*     */     
/*     */     else
/*     */     
/* 115 */     { Collection<ResourceRegion> regions = (Collection<ResourceRegion>)object;
/* 116 */       if (regions.size() == 1) {
/* 117 */         writeResourceRegion(regions.iterator().next(), outputMessage);
/*     */       } else {
/*     */         
/* 120 */         writeResourceRegionCollection(regions, outputMessage);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected MediaType getDefaultContentType(Object object) {
/* 127 */     Resource resource = null;
/* 128 */     if (object instanceof ResourceRegion) { ResourceRegion resourceRegion = (ResourceRegion)object;
/* 129 */       resource = resourceRegion.getResource(); }
/*     */     
/*     */     else
/*     */     
/* 133 */     { Collection<ResourceRegion> regions = (Collection<ResourceRegion>)object;
/* 134 */       if (!regions.isEmpty()) {
/* 135 */         resource = ((ResourceRegion)regions.iterator().next()).getResource();
/*     */       } }
/*     */     
/* 138 */     return MediaTypeFactory.getMediaType(resource).orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsRepeatableWrites(Object object) {
/* 143 */     if (object instanceof ResourceRegion) { ResourceRegion resourceRegion = (ResourceRegion)object;
/* 144 */       return supportsRepeatableWrites(resourceRegion); }
/*     */ 
/*     */ 
/*     */     
/* 148 */     Collection<ResourceRegion> regions = (Collection<ResourceRegion>)object;
/* 149 */     for (ResourceRegion region : regions) {
/* 150 */       if (!supportsRepeatableWrites(region)) {
/* 151 */         return false;
/*     */       }
/*     */     } 
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean supportsRepeatableWrites(ResourceRegion region) {
/* 159 */     return !(region.getResource() instanceof org.springframework.core.io.InputStreamResource);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeResourceRegion(ResourceRegion region, HttpOutputMessage outputMessage) throws IOException {
/* 164 */     Assert.notNull(region, "ResourceRegion must not be null");
/* 165 */     HttpHeaders responseHeaders = outputMessage.getHeaders();
/*     */     
/* 167 */     long start = region.getPosition();
/* 168 */     long end = start + region.getCount() - 1L;
/* 169 */     long resourceLength = region.getResource().contentLength();
/* 170 */     end = Math.min(end, resourceLength - 1L);
/* 171 */     long rangeLength = end - start + 1L;
/* 172 */     responseHeaders.add("Content-Range", "bytes " + start + "-" + end + "/" + resourceLength);
/* 173 */     responseHeaders.setContentLength(rangeLength);
/*     */     
/* 175 */     InputStream in = region.getResource().getInputStream();
/*     */ 
/*     */     
/*     */     try {
/* 179 */       StreamUtils.copyRange(in, outputMessage.getBody(), start, end);
/*     */     } finally {
/*     */       
/*     */       try {
/* 183 */         in.close();
/*     */       }
/* 185 */       catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeResourceRegionCollection(Collection<ResourceRegion> resourceRegions, HttpOutputMessage outputMessage) throws IOException {
/* 195 */     Assert.notNull(resourceRegions, "Collection of ResourceRegion should not be null");
/* 196 */     HttpHeaders responseHeaders = outputMessage.getHeaders();
/*     */     
/* 198 */     MediaType contentType = responseHeaders.getContentType();
/* 199 */     String boundaryString = MimeTypeUtils.generateMultipartBoundaryString();
/* 200 */     responseHeaders.set("Content-Type", "multipart/byteranges; boundary=" + boundaryString);
/* 201 */     OutputStream out = outputMessage.getBody();
/*     */     
/* 203 */     Resource resource = null;
/* 204 */     InputStream in = null;
/* 205 */     long inputStreamPosition = 0L;
/*     */     
/*     */     try {
/* 208 */       for (ResourceRegion region : resourceRegions) {
/* 209 */         long start = region.getPosition() - inputStreamPosition;
/* 210 */         if (start < 0L || resource != region.getResource()) {
/* 211 */           if (in != null) {
/* 212 */             in.close();
/*     */           }
/* 214 */           resource = region.getResource();
/* 215 */           in = resource.getInputStream();
/* 216 */           inputStreamPosition = 0L;
/* 217 */           start = region.getPosition();
/*     */         } 
/* 219 */         long end = start + region.getCount() - 1L;
/*     */         
/* 221 */         println(out);
/* 222 */         print(out, "--" + boundaryString);
/* 223 */         println(out);
/* 224 */         if (contentType != null) {
/* 225 */           print(out, "Content-Type: " + String.valueOf(contentType));
/* 226 */           println(out);
/*     */         } 
/* 228 */         long resourceLength = region.getResource().contentLength();
/* 229 */         end = Math.min(end, resourceLength - inputStreamPosition - 1L);
/* 230 */         print(out, "Content-Range: bytes " + region
/* 231 */             .getPosition() + "-" + region.getPosition() + region.getCount() - 1L + "/" + resourceLength);
/*     */         
/* 233 */         println(out);
/* 234 */         println(out);
/*     */         
/* 236 */         StreamUtils.copyRange(in, out, start, end);
/* 237 */         inputStreamPosition += end + 1L;
/*     */       } 
/*     */     } finally {
/*     */       
/*     */       try {
/* 242 */         if (in != null) {
/* 243 */           in.close();
/*     */         }
/*     */       }
/* 246 */       catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 251 */     println(out);
/* 252 */     print(out, "--" + boundaryString + "--");
/*     */   }
/*     */   
/*     */   private static void println(OutputStream os) throws IOException {
/* 256 */     os.write(13);
/* 257 */     os.write(10);
/*     */   }
/*     */   
/*     */   private static void print(OutputStream os, String buf) throws IOException {
/* 261 */     os.write(buf.getBytes(StandardCharsets.US_ASCII));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\ResourceRegionHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */