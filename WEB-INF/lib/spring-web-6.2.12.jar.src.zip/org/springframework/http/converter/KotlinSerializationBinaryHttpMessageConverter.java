/*    */ package org.springframework.http.converter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import kotlinx.serialization.BinaryFormat;
/*    */ import kotlinx.serialization.DeserializationStrategy;
/*    */ import kotlinx.serialization.KSerializer;
/*    */ import kotlinx.serialization.SerialFormat;
/*    */ import kotlinx.serialization.SerializationException;
/*    */ import kotlinx.serialization.SerializationStrategy;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpOutputMessage;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KotlinSerializationBinaryHttpMessageConverter<T extends BinaryFormat>
/*    */   extends AbstractKotlinSerializationHttpMessageConverter<T>
/*    */ {
/*    */   protected KotlinSerializationBinaryHttpMessageConverter(T format, MediaType... supportedMediaTypes) {
/* 49 */     super(format, supportedMediaTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object readInternal(KSerializer<Object> serializer, T format, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 56 */     byte[] bytes = StreamUtils.copyToByteArray(inputMessage.getBody());
/*    */     try {
/* 58 */       return format.decodeFromByteArray((DeserializationStrategy)serializer, bytes);
/*    */     }
/* 60 */     catch (SerializationException ex) {
/* 61 */       throw new HttpMessageNotReadableException("Could not read " + String.valueOf(format) + ": " + ex.getMessage(), ex, inputMessage);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void writeInternal(Object object, KSerializer<Object> serializer, T format, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*    */     try {
/* 71 */       byte[] bytes = format.encodeToByteArray((SerializationStrategy)serializer, object);
/* 72 */       outputMessage.getBody().write(bytes);
/* 73 */       outputMessage.getBody().flush();
/*    */     }
/* 75 */     catch (SerializationException ex) {
/* 76 */       throw new HttpMessageNotWritableException("Could not write " + String.valueOf(format) + ": " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\KotlinSerializationBinaryHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */