/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGenericHttpMessageConverter<T>
/*     */   extends AbstractHttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*     */   protected AbstractGenericHttpMessageConverter() {}
/*     */   
/*     */   protected AbstractGenericHttpMessageConverter(MediaType supportedMediaType) {
/*  53 */     super(supportedMediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractGenericHttpMessageConverter(MediaType... supportedMediaTypes) {
/*  61 */     super(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractGenericHttpMessageConverter(Charset defaultCharset, MediaType... supportedMediaTypes) {
/*  72 */     super(defaultCharset, supportedMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(Type type, @Nullable Class<?> contextClass, @Nullable MediaType mediaType) {
/*  83 */     Class<?> clazz = (Class)type; return (type instanceof Class) ? canRead(clazz, mediaType) : canRead(mediaType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(@Nullable Type type, Class<?> clazz, @Nullable MediaType mediaType) {
/*  88 */     return canWrite(clazz, mediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(final T t, @Nullable final Type type, @Nullable MediaType contentType, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*  99 */     final HttpHeaders headers = outputMessage.getHeaders();
/* 100 */     addDefaultHeaders(headers, t, contentType);
/*     */     
/* 102 */     if (outputMessage instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)outputMessage;
/* 103 */       streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */           {
/*     */             public void writeTo(final OutputStream outputStream) throws IOException {
/* 106 */               AbstractGenericHttpMessageConverter.this.writeInternal(t, type, new HttpOutputMessage()
/*     */                   {
/*     */                     public OutputStream getBody() {
/* 109 */                       return outputStream;
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public HttpHeaders getHeaders() {
/* 114 */                       return headers;
/*     */                     }
/*     */                   });
/*     */             }
/*     */ 
/*     */             
/*     */             public boolean repeatable() {
/* 121 */               return AbstractGenericHttpMessageConverter.this.supportsRepeatableWrites(t);
/*     */             }
/*     */           }); }
/*     */     else
/*     */     
/* 126 */     { writeInternal(t, type, outputMessage);
/* 127 */       outputMessage.getBody().flush(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/* 135 */     writeInternal(t, (Type)null, outputMessage);
/*     */   }
/*     */   
/*     */   protected abstract void writeInternal(T paramT, @Nullable Type paramType, HttpOutputMessage paramHttpOutputMessage) throws IOException, HttpMessageNotWritableException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\converter\AbstractGenericHttpMessageConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */