/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletServerHttpResponse
/*     */   implements ServerHttpResponse
/*     */ {
/*     */   private final HttpServletResponse servletResponse;
/*     */   private final HttpHeaders headers;
/*     */   private boolean headersWritten = false;
/*     */   private boolean bodyUsed = false;
/*     */   @Nullable
/*     */   private HttpHeaders readOnlyHeaders;
/*     */   
/*     */   public ServletServerHttpResponse(HttpServletResponse servletResponse) {
/*  61 */     Assert.notNull(servletResponse, "HttpServletResponse must not be null");
/*  62 */     this.servletResponse = servletResponse;
/*  63 */     this.headers = new ServletResponseHttpHeaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletResponse getServletResponse() {
/*  71 */     return this.servletResponse;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusCode(HttpStatusCode status) {
/*  76 */     Assert.notNull(status, "HttpStatusCode must not be null");
/*  77 */     this.servletResponse.setStatus(status.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  82 */     if (this.readOnlyHeaders != null) {
/*  83 */       return this.readOnlyHeaders;
/*     */     }
/*  85 */     if (this.headersWritten) {
/*  86 */       this.readOnlyHeaders = HttpHeaders.readOnlyHttpHeaders(this.headers);
/*  87 */       return this.readOnlyHeaders;
/*     */     } 
/*     */     
/*  90 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getBody() throws IOException {
/*  96 */     this.bodyUsed = true;
/*  97 */     writeHeaders();
/*  98 */     return (OutputStream)this.servletResponse.getOutputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 103 */     writeHeaders();
/* 104 */     if (this.bodyUsed) {
/* 105 */       this.servletResponse.flushBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 111 */     writeHeaders();
/*     */   }
/*     */   
/*     */   private void writeHeaders() {
/* 115 */     if (!this.headersWritten) {
/* 116 */       getHeaders().forEach((headerName, headerValues) -> {
/*     */             for (String headerValue : headerValues) {
/*     */               this.servletResponse.addHeader(headerName, headerValue);
/*     */             }
/*     */           });
/*     */       
/* 122 */       MediaType contentTypeHeader = this.headers.getContentType();
/* 123 */       if (this.servletResponse.getContentType() == null && contentTypeHeader != null) {
/* 124 */         this.servletResponse.setContentType(contentTypeHeader.toString());
/*     */       }
/* 126 */       if (this.servletResponse.getCharacterEncoding() == null && contentTypeHeader != null && contentTypeHeader
/* 127 */         .getCharset() != null) {
/* 128 */         this.servletResponse.setCharacterEncoding(contentTypeHeader.getCharset().name());
/*     */       }
/* 130 */       long contentLength = getHeaders().getContentLength();
/* 131 */       if (contentLength != -1L) {
/* 132 */         this.servletResponse.setContentLengthLong(contentLength);
/*     */       }
/* 134 */       this.headersWritten = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ServletResponseHttpHeaders
/*     */     extends HttpHeaders
/*     */   {
/*     */     private static final long serialVersionUID = 3410708522401046302L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 156 */       return (super.containsKey(key) || get(key) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getFirst(String headerName) {
/* 162 */       if (headerName.equalsIgnoreCase("Content-Type")) {
/*     */         
/* 164 */         String str = super.getFirst(headerName);
/* 165 */         return (str != null) ? str : ServletServerHttpResponse.this.servletResponse.getContentType();
/*     */       } 
/*     */       
/* 168 */       String value = ServletServerHttpResponse.this.servletResponse.getHeader(headerName);
/* 169 */       return (value != null) ? value : super.getFirst(headerName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<String> get(Object key) {
/* 176 */       Assert.isInstanceOf(String.class, key, "Key must be a String-based header name");
/*     */       
/* 178 */       String headerName = (String)key;
/* 179 */       if (headerName.equalsIgnoreCase("Content-Type")) {
/*     */         
/* 181 */         String value = getFirst(headerName);
/* 182 */         return (value != null) ? Collections.<String>singletonList(value) : null;
/*     */       } 
/*     */       
/* 185 */       Collection<String> values1 = ServletServerHttpResponse.this.servletResponse.getHeaders(headerName);
/* 186 */       if (ServletServerHttpResponse.this.headersWritten) {
/* 187 */         return new ArrayList<>(values1);
/*     */       }
/* 189 */       boolean isEmpty1 = CollectionUtils.isEmpty(values1);
/*     */       
/* 191 */       List<String> values2 = super.get(key);
/* 192 */       boolean isEmpty2 = CollectionUtils.isEmpty(values2);
/*     */       
/* 194 */       if (isEmpty1 && isEmpty2) {
/* 195 */         return null;
/*     */       }
/*     */       
/* 198 */       List<String> values = new ArrayList<>();
/* 199 */       if (!isEmpty1) {
/* 200 */         values.addAll(values1);
/*     */       }
/* 202 */       if (!isEmpty2) {
/* 203 */         values.addAll(values2);
/*     */       }
/* 205 */       return values;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\ServletServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */