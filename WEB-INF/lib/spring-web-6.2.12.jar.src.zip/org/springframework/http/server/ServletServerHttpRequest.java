/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*  65 */   protected static final Charset FORM_CHARSET = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpServletRequest servletRequest;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private URI uri;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private HttpHeaders headers;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<String, Object> attributes;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ServerHttpAsyncRequestControl asyncRequestControl;
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest) {
/*  90 */     Assert.notNull(servletRequest, "HttpServletRequest must not be null");
/*  91 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletRequest getServletRequest() {
/*  99 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/* 104 */     return HttpMethod.valueOf(this.servletRequest.getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 109 */     if (this.uri == null) {
/* 110 */       this.uri = initURI(this.servletRequest);
/*     */     }
/* 112 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI initURI(HttpServletRequest servletRequest) {
/* 122 */     String urlString = null;
/* 123 */     String query = null;
/* 124 */     boolean hasQuery = false;
/*     */     try {
/* 126 */       StringBuffer requestURL = servletRequest.getRequestURL();
/* 127 */       query = servletRequest.getQueryString();
/* 128 */       hasQuery = StringUtils.hasText(query);
/* 129 */       if (hasQuery) {
/* 130 */         requestURL.append('?').append(query);
/*     */       }
/* 132 */       urlString = requestURL.toString();
/* 133 */       return new URI(urlString);
/*     */     }
/* 135 */     catch (URISyntaxException ex) {
/* 136 */       if (hasQuery) {
/*     */         
/*     */         try {
/* 139 */           query = UriComponentsBuilder.fromUriString("?" + query).build().toUri().getRawQuery();
/* 140 */           return new URI(servletRequest.getRequestURL().toString() + "?" + servletRequest.getRequestURL().toString());
/*     */         }
/* 142 */         catch (URISyntaxException ex2) {
/*     */           
/*     */           try {
/* 145 */             return new URI(servletRequest.getRequestURL().toString());
/*     */           }
/* 147 */           catch (URISyntaxException uRISyntaxException) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 152 */       throw new IllegalStateException("Could not resolve HttpServletRequest as URI: " + urlString, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 159 */     if (this.headers == null) {
/* 160 */       this.headers = new HttpHeaders();
/*     */       
/* 162 */       for (Enumeration<?> names = this.servletRequest.getHeaderNames(); names.hasMoreElements(); ) {
/* 163 */         String headerName = (String)names.nextElement();
/* 164 */         Enumeration<?> headerValues = this.servletRequest.getHeaders(headerName);
/* 165 */         while (headerValues.hasMoreElements()) {
/* 166 */           String headerValue = (String)headerValues.nextElement();
/* 167 */           this.headers.add(headerName, headerValue);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 174 */         MediaType contentType = this.headers.getContentType();
/* 175 */         if (contentType == null) {
/* 176 */           String requestContentType = this.servletRequest.getContentType();
/* 177 */           if (StringUtils.hasLength(requestContentType)) {
/* 178 */             contentType = MediaType.parseMediaType(requestContentType);
/* 179 */             if (contentType.isConcrete()) {
/* 180 */               this.headers.setContentType(contentType);
/*     */             }
/*     */           } 
/*     */         } 
/* 184 */         if (contentType != null && contentType.getCharset() == null) {
/* 185 */           String requestEncoding = this.servletRequest.getCharacterEncoding();
/* 186 */           if (StringUtils.hasLength(requestEncoding)) {
/* 187 */             Charset charSet = Charset.forName(requestEncoding);
/* 188 */             LinkedCaseInsensitiveMap<String, String> linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap();
/* 189 */             linkedCaseInsensitiveMap.putAll(contentType.getParameters());
/* 190 */             linkedCaseInsensitiveMap.put("charset", charSet.toString());
/* 191 */             MediaType mediaType = new MediaType(contentType.getType(), contentType.getSubtype(), (Map)linkedCaseInsensitiveMap);
/* 192 */             this.headers.setContentType(mediaType);
/*     */           }
/*     */         
/*     */         } 
/* 196 */       } catch (InvalidMediaTypeException invalidMediaTypeException) {}
/*     */ 
/*     */ 
/*     */       
/* 200 */       if (this.headers.getContentLength() < 0L) {
/* 201 */         int requestContentLength = this.servletRequest.getContentLength();
/* 202 */         if (requestContentLength != -1) {
/* 203 */           this.headers.setContentLength(requestContentLength);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal getPrincipal() {
/* 213 */     return this.servletRequest.getUserPrincipal();
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress getLocalAddress() {
/* 218 */     return new InetSocketAddress(this.servletRequest.getLocalAddr(), this.servletRequest.getLocalPort());
/*     */   }
/*     */ 
/*     */   
/*     */   public InetSocketAddress getRemoteAddress() {
/* 223 */     String addressOrHost = this.servletRequest.getRemoteAddr();
/* 224 */     addressOrHost = (addressOrHost != null) ? addressOrHost : this.servletRequest.getRemoteHost();
/* 225 */     return new InetSocketAddress(addressOrHost, this.servletRequest.getRemotePort());
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 230 */     Map<String, Object> attributes = this.attributes;
/* 231 */     if (attributes == null) {
/* 232 */       attributes = new AttributesMap();
/* 233 */       this.attributes = attributes;
/*     */     } 
/* 235 */     return attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBody() throws IOException {
/* 240 */     if (isFormPost(this.servletRequest) && this.servletRequest.getQueryString() == null) {
/* 241 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */     
/* 244 */     return (InputStream)this.servletRequest.getInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerHttpAsyncRequestControl getAsyncRequestControl(ServerHttpResponse response) {
/* 250 */     if (this.asyncRequestControl == null) {
/* 251 */       ServletServerHttpResponse servletServerResponse; if (response instanceof ServletServerHttpResponse) { servletServerResponse = (ServletServerHttpResponse)response; }
/* 252 */       else { throw new IllegalArgumentException("Response must be a ServletServerHttpResponse: " + 
/* 253 */             String.valueOf(response.getClass())); }
/*     */       
/* 255 */       this.asyncRequestControl = new ServletServerHttpAsyncRequestControl(this, servletServerResponse);
/*     */     } 
/* 257 */     return this.asyncRequestControl;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isFormPost(HttpServletRequest request) {
/* 262 */     String contentType = request.getContentType();
/* 263 */     return (contentType != null && contentType.contains("application/x-www-form-urlencoded") && HttpMethod.POST
/* 264 */       .matches(request.getMethod()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream getBodyFromServletRequestParameters(HttpServletRequest request) throws IOException {
/* 274 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
/* 275 */     Charset charset = getFormCharset();
/* 276 */     Writer writer = new OutputStreamWriter(bos, charset);
/*     */     
/* 278 */     Map<String, String[]> form = request.getParameterMap();
/* 279 */     for (Iterator<Map.Entry<String, String[]>> entryItr = form.entrySet().iterator(); entryItr.hasNext(); ) {
/* 280 */       Map.Entry<String, String[]> entry = entryItr.next();
/* 281 */       List<String> values = Arrays.asList(entry.getValue());
/* 282 */       for (Iterator<String> valueItr = values.iterator(); valueItr.hasNext(); ) {
/* 283 */         String value = valueItr.next();
/* 284 */         writer.write(URLEncoder.encode(entry.getKey(), charset));
/* 285 */         if (value != null) {
/* 286 */           writer.write(61);
/* 287 */           writer.write(URLEncoder.encode(value, charset));
/* 288 */           if (valueItr.hasNext()) {
/* 289 */             writer.write(38);
/*     */           }
/*     */         } 
/*     */       } 
/* 293 */       if (entryItr.hasNext()) {
/* 294 */         writer.append('&');
/*     */       }
/*     */     } 
/* 297 */     writer.flush();
/*     */     
/* 299 */     byte[] bytes = bos.toByteArray();
/* 300 */     if (bytes.length > 0 && getHeaders().containsKey("Content-Length")) {
/* 301 */       getHeaders().setContentLength(bytes.length);
/*     */     }
/*     */     
/* 304 */     return new ByteArrayInputStream(bytes);
/*     */   }
/*     */   
/*     */   private Charset getFormCharset() {
/*     */     try {
/* 309 */       MediaType contentType = getHeaders().getContentType();
/* 310 */       if (contentType != null && contentType.getCharset() != null) {
/* 311 */         return contentType.getCharset();
/*     */       }
/*     */     }
/* 314 */     catch (Exception exception) {}
/*     */ 
/*     */     
/* 317 */     return FORM_CHARSET;
/*     */   }
/*     */ 
/*     */   
/*     */   private final class AttributesMap
/*     */     extends AbstractMap<String, Object>
/*     */   {
/*     */     @Nullable
/*     */     private transient Set<String> keySet;
/*     */     
/*     */     @Nullable
/*     */     private transient Collection<Object> values;
/*     */     
/*     */     @Nullable
/*     */     private transient Set<Map.Entry<String, Object>> entrySet;
/*     */ 
/*     */     
/*     */     public int size() {
/* 335 */       int size = 0;
/* 336 */       for (Enumeration<?> names = ServletServerHttpRequest.this.servletRequest.getAttributeNames(); names.hasMoreElements(); names.nextElement()) {
/* 337 */         size++;
/*     */       }
/* 339 */       return size;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object get(Object key) {
/* 345 */       if (key instanceof String) { String name = (String)key;
/* 346 */         return ServletServerHttpRequest.this.servletRequest.getAttribute(name); }
/*     */ 
/*     */       
/* 349 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object put(String key, Object value) {
/* 356 */       Object old = get(key);
/* 357 */       ServletServerHttpRequest.this.servletRequest.setAttribute(key, value);
/* 358 */       return old;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object remove(Object key) {
/* 364 */       if (key instanceof String) { String name = (String)key;
/* 365 */         Object old = get(key);
/* 366 */         ServletServerHttpRequest.this.servletRequest.removeAttribute(name);
/* 367 */         return old; }
/*     */ 
/*     */       
/* 370 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/* 376 */       for (Enumeration<String> names = ServletServerHttpRequest.this.servletRequest.getAttributeNames(); names.hasMoreElements(); ) {
/* 377 */         String name = names.nextElement();
/* 378 */         ServletServerHttpRequest.this.servletRequest.removeAttribute(name);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> keySet() {
/* 384 */       Set<String> keySet = this.keySet;
/* 385 */       if (keySet == null) {
/* 386 */         keySet = new AbstractSet<String>()
/*     */           {
/*     */             public Iterator<String> iterator() {
/* 389 */               return ServletServerHttpRequest.this.servletRequest.getAttributeNames().asIterator();
/*     */             }
/*     */ 
/*     */             
/*     */             public int size() {
/* 394 */               return ServletServerHttpRequest.AttributesMap.this.size();
/*     */             }
/*     */           };
/* 397 */         this.keySet = keySet;
/*     */       } 
/* 399 */       return keySet;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<Object> values() {
/* 404 */       Collection<Object> values = this.values;
/* 405 */       if (values == null) {
/* 406 */         values = new AbstractCollection()
/*     */           {
/*     */             public Iterator<Object> iterator() {
/* 409 */               final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/* 410 */               return new Iterator()
/*     */                 {
/*     */                   public boolean hasNext() {
/* 413 */                     return e.hasMoreElements();
/*     */                   }
/*     */ 
/*     */                   
/*     */                   public Object next() {
/* 418 */                     String name = e.nextElement();
/* 419 */                     return ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */                   }
/*     */                 };
/*     */             }
/*     */ 
/*     */             
/*     */             public int size() {
/* 426 */               return ServletServerHttpRequest.AttributesMap.this.size();
/*     */             }
/*     */           };
/* 429 */         this.values = values;
/*     */       } 
/* 431 */       return values;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet() {
/* 436 */       Set<Map.Entry<String, Object>> entrySet = this.entrySet;
/* 437 */       if (entrySet == null) {
/* 438 */         entrySet = new AbstractSet<Map.Entry<String, Object>>()
/*     */           {
/*     */             public Iterator<Map.Entry<String, Object>> iterator() {
/* 441 */               final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/* 442 */               return new Iterator<Map.Entry<String, Object>>()
/*     */                 {
/*     */                   public boolean hasNext() {
/* 445 */                     return e.hasMoreElements();
/*     */                   }
/*     */ 
/*     */                   
/*     */                   public Map.Entry<String, Object> next() {
/* 450 */                     String name = e.nextElement();
/* 451 */                     Object value = ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/* 452 */                     return new AbstractMap.SimpleImmutableEntry<>(name, value);
/*     */                   }
/*     */                 };
/*     */             }
/*     */ 
/*     */             
/*     */             public int size() {
/* 459 */               return ServletServerHttpRequest.AttributesMap.this.size();
/*     */             }
/*     */           };
/* 462 */         this.entrySet = entrySet;
/*     */       } 
/* 464 */       return entrySet;
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends AbstractSet<String> {
/*     */     public Iterator<String> iterator() {
/*     */       return ServletServerHttpRequest.this.servletRequest.getAttributeNames().asIterator();
/*     */     }
/*     */     
/*     */     public int size() {
/*     */       return ServletServerHttpRequest.AttributesMap.this.size();
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends AbstractCollection<Object> {
/*     */     public Iterator<Object> iterator() {
/*     */       final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/*     */       return new Iterator() {
/*     */           public boolean hasNext() {
/*     */             return e.hasMoreElements();
/*     */           }
/*     */           
/*     */           public Object next() {
/*     */             String name = e.nextElement();
/*     */             return ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public int size() {
/*     */       return ServletServerHttpRequest.AttributesMap.this.size();
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Iterator<Object> {
/*     */     public boolean hasNext() {
/*     */       return e.hasMoreElements();
/*     */     }
/*     */     
/*     */     public Object next() {
/*     */       String name = e.nextElement();
/*     */       return ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends AbstractSet<Map.Entry<String, Object>> {
/*     */     public Iterator<Map.Entry<String, Object>> iterator() {
/*     */       final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/*     */       return new Iterator<Map.Entry<String, Object>>() {
/*     */           public boolean hasNext() {
/*     */             return e.hasMoreElements();
/*     */           }
/*     */           
/*     */           public Map.Entry<String, Object> next() {
/*     */             String name = e.nextElement();
/*     */             Object value = ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */             return new AbstractMap.SimpleImmutableEntry<>(name, value);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public int size() {
/*     */       return ServletServerHttpRequest.AttributesMap.this.size();
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Iterator<Map.Entry<String, Object>> {
/*     */     public boolean hasNext() {
/*     */       return e.hasMoreElements();
/*     */     }
/*     */     
/*     */     public Map.Entry<String, Object> next() {
/*     */       String name = e.nextElement();
/*     */       Object value = ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */       return new AbstractMap.SimpleImmutableEntry<>(name, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\ServletServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */