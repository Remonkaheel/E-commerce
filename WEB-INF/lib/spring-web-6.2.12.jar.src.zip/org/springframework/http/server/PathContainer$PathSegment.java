package org.springframework.http.server;

import org.springframework.util.MultiValueMap;

public interface PathSegment extends PathContainer.Element {
  String valueToMatch();
  
  char[] valueToMatchAsChars();
  
  MultiValueMap<String, String> parameters();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\PathContainer$PathSegment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */