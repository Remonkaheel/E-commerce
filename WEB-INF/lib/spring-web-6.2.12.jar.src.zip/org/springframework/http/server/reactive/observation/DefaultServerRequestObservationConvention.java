/*     */ package org.springframework.http.server.reactive.observation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultServerRequestObservationConvention
/*     */   implements ServerRequestObservationConvention
/*     */ {
/*     */   private static final String DEFAULT_NAME = "http.server.requests";
/*  43 */   private static final KeyValue METHOD_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, "UNKNOWN");
/*     */   
/*  45 */   private static final KeyValue STATUS_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, "UNKNOWN");
/*     */   
/*  47 */   private static final KeyValue HTTP_OUTCOME_SUCCESS = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "SUCCESS");
/*     */   
/*  49 */   private static final KeyValue HTTP_OUTCOME_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "UNKNOWN");
/*     */   
/*  51 */   private static final KeyValue URI_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "UNKNOWN");
/*     */   
/*  53 */   private static final KeyValue URI_ROOT = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "root");
/*     */   
/*  55 */   private static final KeyValue URI_NOT_FOUND = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "NOT_FOUND");
/*     */   
/*  57 */   private static final KeyValue URI_REDIRECTION = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "REDIRECTION");
/*     */   
/*  59 */   private static final KeyValue EXCEPTION_NONE = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, "none");
/*     */   
/*  61 */   private static final KeyValue HTTP_URL_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, "UNKNOWN");
/*     */   
/*  63 */   private static final Set<HttpMethod> HTTP_METHODS = Set.of(HttpMethod.values());
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultServerRequestObservationConvention() {
/*  73 */     this("http.server.requests");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultServerRequestObservationConvention(String name) {
/*  81 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  87 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getContextualName(ServerRequestObservationContext context) {
/*  93 */     if (context.getCarrier() != null) {
/*  94 */       String httpMethod = ((ServerHttpRequest)context.getCarrier()).getMethod().name().toLowerCase(Locale.ROOT);
/*  95 */       return (context.getPathPattern() != null) ? ("http " + 
/*  96 */         httpMethod + " " + context.getPathPattern()) : ("http " + 
/*     */         
/*  98 */         httpMethod);
/*     */     } 
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getLowCardinalityKeyValues(ServerRequestObservationContext context) {
/* 106 */     return KeyValues.of(new KeyValue[] { exception(context), method(context), outcome(context), status(context), uri(context) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getHighCardinalityKeyValues(ServerRequestObservationContext context) {
/* 112 */     return KeyValues.of(new KeyValue[] { httpUrl(context) });
/*     */   }
/*     */   
/*     */   protected KeyValue method(ServerRequestObservationContext context) {
/* 116 */     if (context.getCarrier() != null) {
/* 117 */       HttpMethod method = ((ServerHttpRequest)context.getCarrier()).getMethod();
/* 118 */       if (HTTP_METHODS.contains(method)) {
/* 119 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, method.name());
/*     */       }
/*     */     } 
/* 122 */     return METHOD_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue status(ServerRequestObservationContext context) {
/* 126 */     if (context.isConnectionAborted() && (context.getResponse() == null || !((ServerHttpResponse)context.getResponse()).isCommitted())) {
/* 127 */       return STATUS_UNKNOWN;
/*     */     }
/* 129 */     return (context.getResponse() != null && ((ServerHttpResponse)context.getResponse()).getStatusCode() != null) ? 
/* 130 */       KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, Integer.toString(((ServerHttpResponse)context.getResponse()).getStatusCode().value())) : 
/* 131 */       STATUS_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue uri(ServerRequestObservationContext context) {
/* 135 */     if (context.getCarrier() != null) {
/* 136 */       String pattern = context.getPathPattern();
/* 137 */       if (pattern != null) {
/* 138 */         if (pattern.isEmpty()) {
/* 139 */           return URI_ROOT;
/*     */         }
/* 141 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, pattern);
/*     */       } 
/* 143 */       if (context.getResponse() != null && ((ServerHttpResponse)context.getResponse()).getStatusCode() != null) {
/* 144 */         HttpStatus status = HttpStatus.resolve(((ServerHttpResponse)context.getResponse()).getStatusCode().value());
/* 145 */         if (status != null) {
/* 146 */           if (status.is3xxRedirection()) {
/* 147 */             return URI_REDIRECTION;
/*     */           }
/* 149 */           if (status == HttpStatus.NOT_FOUND) {
/* 150 */             return URI_NOT_FOUND;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 155 */     return URI_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue exception(ServerRequestObservationContext context) {
/* 159 */     Throwable error = context.getError();
/* 160 */     if (error != null) {
/* 161 */       String simpleName = error.getClass().getSimpleName();
/* 162 */       return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, StringUtils.hasText(simpleName) ? 
/* 163 */           simpleName : error.getClass().getName());
/*     */     } 
/* 165 */     return EXCEPTION_NONE;
/*     */   }
/*     */   
/*     */   protected KeyValue outcome(ServerRequestObservationContext context) {
/* 169 */     if (context.isConnectionAborted()) {
/* 170 */       return HTTP_OUTCOME_UNKNOWN;
/*     */     }
/* 172 */     if (context.getResponse() != null && ((ServerHttpResponse)context.getResponse()).getStatusCode() != null) {
/* 173 */       return HttpOutcome.forStatus(((ServerHttpResponse)context.getResponse()).getStatusCode());
/*     */     }
/* 175 */     return HTTP_OUTCOME_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue httpUrl(ServerRequestObservationContext context) {
/* 179 */     if (context.getCarrier() != null) {
/* 180 */       return KeyValue.of(ServerHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, ((ServerHttpRequest)context.getCarrier()).getPath().toString());
/*     */     }
/* 182 */     return HTTP_URL_UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   static class HttpOutcome
/*     */   {
/*     */     static KeyValue forStatus(HttpStatusCode statusCode) {
/* 189 */       if (statusCode.is2xxSuccessful()) {
/* 190 */         return DefaultServerRequestObservationConvention.HTTP_OUTCOME_SUCCESS;
/*     */       }
/* 192 */       if (statusCode instanceof HttpStatus) { HttpStatus status = (HttpStatus)statusCode;
/* 193 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, status.series().name()); }
/*     */ 
/*     */       
/* 196 */       return DefaultServerRequestObservationConvention.HTTP_OUTCOME_UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\observation\DefaultServerRequestObservationConvention.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */