/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TomcatHeadersAdapter
/*     */   implements MultiValueMap<String, String>
/*     */ {
/*     */   private final MimeHeaders headers;
/*     */   
/*     */   TomcatHeadersAdapter(MimeHeaders headers) {
/*  52 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirst(String key) {
/*  58 */     return this.headers.getHeader(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String key, @Nullable String value) {
/*  63 */     this.headers.addValue(key).setString(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(String key, List<? extends String> values) {
/*  68 */     values.forEach(value -> add(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(MultiValueMap<String, String> values) {
/*  73 */     values.forEach(this::addAll);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String key, @Nullable String value) {
/*  78 */     this.headers.setValue(key).setString(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Map<String, String> values) {
/*  83 */     values.forEach(this::set);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toSingleValueMap() {
/*  88 */     Map<String, String> singleValueMap = CollectionUtils.newLinkedHashMap(this.headers.size());
/*  89 */     keySet().forEach(key -> singleValueMap.put(key, getFirst(key)));
/*  90 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  95 */     Enumeration<String> names = this.headers.names();
/*  96 */     Set<String> deduplicated = new LinkedHashSet<>();
/*  97 */     while (names.hasMoreElements()) {
/*  98 */       deduplicated.add(((String)names.nextElement()).toLowerCase(Locale.ROOT));
/*     */     }
/* 100 */     return deduplicated.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 105 */     return (this.headers.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 110 */     if (key instanceof String) { String headerName = (String)key;
/* 111 */       return (this.headers.findHeader(headerName, 0) != -1); }
/*     */     
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 118 */     if (value instanceof String) { String text = (String)value;
/* 119 */       MessageBytes messageBytes = MessageBytes.newInstance();
/* 120 */       messageBytes.setString(text);
/* 121 */       for (int i = 0; i < this.headers.size(); i++) {
/* 122 */         if (this.headers.getValue(i).equals(messageBytes)) {
/* 123 */           return true;
/*     */         }
/*     */       }  }
/*     */     
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> get(Object key) {
/* 133 */     if (containsKey(key)) {
/* 134 */       return Collections.list(this.headers.values((String)key));
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> put(String key, List<String> value) {
/* 142 */     List<String> previousValues = get(key);
/* 143 */     this.headers.removeHeader(key);
/* 144 */     value.forEach(v -> this.headers.addValue(key).setString(v));
/* 145 */     return previousValues;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> remove(Object key) {
/* 151 */     if (key instanceof String) { String headerName = (String)key;
/* 152 */       List<String> previousValues = get(key);
/* 153 */       this.headers.removeHeader(headerName);
/* 154 */       return previousValues; }
/*     */     
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map) {
/* 161 */     map.forEach(this::put);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 167 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 172 */     return new HeaderNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<List<String>> values() {
/* 177 */     return keySet().stream().map(this::get).toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 182 */     return new AbstractSet<Map.Entry<String, List<String>>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, List<String>>> iterator() {
/* 185 */           return new TomcatHeadersAdapter.EntryIterator();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 190 */           return TomcatHeadersAdapter.this.size();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     return HttpHeaders.formatHeaders(this);
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<String, List<String>>>
/*     */   {
/* 204 */     private final Enumeration<String> names = TomcatHeadersAdapter.this.headers.names();
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 208 */       return this.names.hasMoreElements();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, List<String>> next() {
/* 213 */       return new TomcatHeadersAdapter.HeaderEntry(this.names.nextElement());
/*     */     }
/*     */   }
/*     */   
/*     */   private final class HeaderEntry
/*     */     implements Map.Entry<String, List<String>>
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     HeaderEntry(String key) {
/* 223 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 228 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<String> getValue() {
/* 234 */       return TomcatHeadersAdapter.this.get(this.key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public List<String> setValue(List<String> value) {
/* 240 */       List<String> previous = getValue();
/* 241 */       TomcatHeadersAdapter.this.headers.removeHeader(this.key);
/* 242 */       TomcatHeadersAdapter.this.addAll(this.key, value);
/* 243 */       return previous;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class HeaderNames
/*     */     extends AbstractSet<String>
/*     */   {
/*     */     public Iterator<String> iterator() {
/* 252 */       return new TomcatHeadersAdapter.HeaderNamesIterator(TomcatHeadersAdapter.this.headers.names());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 257 */       Enumeration<String> names = TomcatHeadersAdapter.this.headers.names();
/* 258 */       int size = 0;
/* 259 */       while (names.hasMoreElements()) {
/* 260 */         names.nextElement();
/* 261 */         size++;
/*     */       } 
/* 263 */       return size;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class HeaderNamesIterator
/*     */     implements Iterator<String>
/*     */   {
/*     */     private final Enumeration<String> enumeration;
/*     */     @Nullable
/*     */     private String currentName;
/*     */     
/*     */     private HeaderNamesIterator(Enumeration<String> enumeration) {
/* 275 */       this.enumeration = enumeration;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 280 */       return this.enumeration.hasMoreElements();
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 285 */       this.currentName = this.enumeration.nextElement();
/* 286 */       return this.currentName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 291 */       if (this.currentName == null) {
/* 292 */         throw new IllegalStateException("No current Header in iterator");
/*     */       }
/*     */       
/* 295 */       boolean found = false;
/* 296 */       for (int i = 0; i < TomcatHeadersAdapter.this.headers.size(); i++) {
/* 297 */         if (TomcatHeadersAdapter.this.headers.getName(i).equalsIgnoreCase(this.currentName)) {
/* 298 */           TomcatHeadersAdapter.this.headers.removeHeader(i--);
/* 299 */           found = true;
/*     */         } 
/*     */       } 
/* 302 */       if (!found)
/* 303 */         throw new IllegalStateException("Header not present: " + this.currentName); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\TomcatHeadersAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */