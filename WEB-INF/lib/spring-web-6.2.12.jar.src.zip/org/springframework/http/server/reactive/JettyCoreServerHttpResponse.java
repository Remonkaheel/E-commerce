/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import org.eclipse.jetty.http.HttpCookie;
/*     */ import org.eclipse.jetty.http.HttpField;
/*     */ import org.eclipse.jetty.http.HttpFields;
/*     */ import org.eclipse.jetty.io.Content;
/*     */ import org.eclipse.jetty.server.HttpCookieUtils;
/*     */ import org.eclipse.jetty.server.Response;
/*     */ import org.eclipse.jetty.util.Callback;
/*     */ import org.eclipse.jetty.util.IteratingCallback;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.JettyDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.support.JettyHeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JettyCoreServerHttpResponse
/*     */   extends AbstractServerHttpResponse
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*     */   private final Response response;
/*     */   
/*     */   public JettyCoreServerHttpResponse(Response response, JettyDataBufferFactory dataBufferFactory) {
/*  59 */     super((DataBufferFactory)dataBufferFactory, new HttpHeaders((MultiValueMap)new JettyHeadersAdapter((HttpFields)response.getHeaders())));
/*  60 */     this.response = response;
/*     */ 
/*     */     
/*  63 */     for (ListIterator<HttpField> it = this.response.getHeaders().listIterator(); it.hasNext(); ) {
/*  64 */       HttpField field = it.next();
/*  65 */       if (field instanceof HttpCookieUtils.SetCookieHttpField) { HttpCookieUtils.SetCookieHttpField setCookieHttpField = (HttpCookieUtils.SetCookieHttpField)field;
/*  66 */         HttpCookie httpCookie = setCookieHttpField.getHttpCookie();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  74 */         ResponseCookie responseCookie = ResponseCookie.from(httpCookie.getName(), httpCookie.getValue()).httpOnly(httpCookie.isHttpOnly()).domain(httpCookie.getDomain()).maxAge(httpCookie.getMaxAge()).sameSite(httpCookie.getSameSite().name()).secure(httpCookie.isSecure()).partitioned(httpCookie.isPartitioned()).build();
/*  75 */         addCookie(responseCookie);
/*  76 */         it.remove(); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeWithInternal(Publisher<? extends DataBuffer> body) {
/*  84 */     return Flux.from(body)
/*  85 */       .concatMap(this::sendDataBuffer)
/*  86 */       .then();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeAndFlushWithInternal(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/*  91 */     return Flux.from(body).concatMap(this::writeWithInternal).then();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyStatusCode() {
/*  96 */     HttpStatusCode status = getStatusCode();
/*  97 */     if (status != null) {
/*  98 */       this.response.setStatus(status.value());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {}
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 108 */     getCookies().values().stream()
/* 109 */       .flatMap(Collection::stream)
/* 110 */       .forEach(cookie -> Response.addCookie(this.response, new ResponseHttpCookie(cookie)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 115 */     Callback.Completable callback = new Callback.Completable();
/* 116 */     Mono<Void> mono = Mono.fromFuture((CompletableFuture)callback);
/*     */     try {
/* 118 */       Content.copy(Content.Source.from(null, file, position, count), (Content.Sink)this.response, (Callback)callback);
/*     */     }
/* 120 */     catch (Throwable th) {
/* 121 */       callback.failed(th);
/*     */     } 
/* 123 */     return doCommit(() -> mono);
/*     */   }
/*     */   
/*     */   private Mono<Void> sendDataBuffer(final DataBuffer dataBuffer) {
/* 127 */     return Mono.defer(() -> {
/*     */           final DataBuffer.ByteBufferIterator byteBufferIterator = dataBuffer.readableByteBuffers();
/*     */           final Callback.Completable callback = new Callback.Completable();
/*     */           (new IteratingCallback()
/*     */             {
/*     */               protected IteratingCallback.Action process() {
/* 133 */                 if (!byteBufferIterator.hasNext()) {
/* 134 */                   return IteratingCallback.Action.SUCCEEDED;
/*     */                 }
/* 136 */                 JettyCoreServerHttpResponse.this.response.write(false, (ByteBuffer)byteBufferIterator.next(), (Callback)this);
/* 137 */                 return IteratingCallback.Action.SCHEDULED;
/*     */               }
/*     */ 
/*     */               
/*     */               protected void onCompleteSuccess() {
/* 142 */                 byteBufferIterator.close();
/* 143 */                 DataBufferUtils.release(dataBuffer);
/* 144 */                 callback.complete(null);
/*     */               }
/*     */ 
/*     */               
/*     */               protected void onCompleteFailure(Throwable cause) {
/* 149 */                 byteBufferIterator.close();
/* 150 */                 DataBufferUtils.release(dataBuffer);
/* 151 */                 callback.failed(cause);
/*     */               }
/*     */             }).iterate();
/*     */           return Mono.fromFuture((CompletableFuture)callback);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeResponse() {
/* 162 */     return (T)this.response;
/*     */   }
/*     */   
/*     */   private static class ResponseHttpCookie
/*     */     implements HttpCookie
/*     */   {
/*     */     private final ResponseCookie responseCookie;
/*     */     
/*     */     ResponseHttpCookie(ResponseCookie responseCookie) {
/* 171 */       this.responseCookie = responseCookie;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 176 */       return this.responseCookie.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 181 */       return this.responseCookie.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getVersion() {
/* 186 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getMaxAge() {
/* 191 */       return this.responseCookie.getMaxAge().toSeconds();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getComment() {
/* 197 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getDomain() {
/* 203 */       return this.responseCookie.getDomain();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getPath() {
/* 209 */       return this.responseCookie.getPath();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSecure() {
/* 214 */       return this.responseCookie.isSecure();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public HttpCookie.SameSite getSameSite() {
/* 221 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isHttpOnly() {
/* 226 */       return this.responseCookie.isHttpOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isPartitioned() {
/* 231 */       return this.responseCookie.isPartitioned();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, String> getAttributes() {
/* 236 */       return Collections.emptyMap();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyCoreServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */