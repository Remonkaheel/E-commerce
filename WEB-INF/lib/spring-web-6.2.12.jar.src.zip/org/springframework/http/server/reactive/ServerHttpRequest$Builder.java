package org.springframework.http.server.reactive;

import java.net.InetSocketAddress;
import java.net.URI;
import java.util.function.Consumer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

public interface Builder {
  Builder method(HttpMethod paramHttpMethod);
  
  Builder uri(URI paramURI);
  
  Builder path(String paramString);
  
  Builder contextPath(String paramString);
  
  Builder header(String paramString, String... paramVarArgs);
  
  Builder headers(Consumer<HttpHeaders> paramConsumer);
  
  Builder sslInfo(SslInfo paramSslInfo);
  
  Builder remoteAddress(InetSocketAddress paramInetSocketAddress);
  
  ServerHttpRequest build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServerHttpRequest$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */