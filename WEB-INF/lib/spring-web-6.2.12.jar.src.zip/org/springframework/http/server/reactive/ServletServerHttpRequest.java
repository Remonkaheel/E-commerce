/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncEvent;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.ReadListener;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServletServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*  65 */   static final DataBuffer EOF_BUFFER = (DataBuffer)DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
/*     */ 
/*     */   
/*     */   private final HttpServletRequest request;
/*     */   
/*     */   private final ServletInputStream inputStream;
/*     */   
/*     */   private final RequestBodyPublisher bodyPublisher;
/*     */   
/*  74 */   private final Object cookieLock = new Object();
/*     */ 
/*     */   
/*     */   private final DataBufferFactory bufferFactory;
/*     */ 
/*     */   
/*     */   private final byte[] buffer;
/*     */ 
/*     */   
/*     */   private final AsyncListener asyncListener;
/*     */ 
/*     */   
/*     */   public ServletServerHttpRequest(HttpServletRequest request, AsyncContext asyncContext, String servletPath, DataBufferFactory bufferFactory, int bufferSize) throws IOException, URISyntaxException {
/*  87 */     this(createDefaultHttpHeaders(request), request, asyncContext, servletPath, bufferFactory, bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletServerHttpRequest(MultiValueMap<String, String> headers, HttpServletRequest request, AsyncContext asyncContext, String servletPath, DataBufferFactory bufferFactory, int bufferSize) throws IOException, URISyntaxException {
/*  94 */     super(HttpMethod.valueOf(request.getMethod()), initUri(request), request
/*  95 */         .getContextPath() + request.getContextPath(), initHeaders(headers, request));
/*     */     
/*  97 */     Assert.notNull(bufferFactory, "'bufferFactory' must not be null");
/*  98 */     Assert.isTrue((bufferSize > 0), "'bufferSize' must be greater than 0");
/*     */     
/* 100 */     this.request = request;
/* 101 */     this.bufferFactory = bufferFactory;
/* 102 */     this.buffer = new byte[bufferSize];
/*     */     
/* 104 */     this.asyncListener = new RequestAsyncListener();
/*     */ 
/*     */     
/* 107 */     this.inputStream = request.getInputStream();
/* 108 */     this.bodyPublisher = new RequestBodyPublisher(this.inputStream);
/* 109 */     this.bodyPublisher.registerReadListener();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MultiValueMap<String, String> createDefaultHttpHeaders(HttpServletRequest request) {
/* 115 */     MultiValueMap<String, String> headers = CollectionUtils.toMultiValueMap((Map)new LinkedCaseInsensitiveMap(8, Locale.ROOT));
/* 116 */     for (Enumeration<?> names = request.getHeaderNames(); names.hasMoreElements(); ) {
/* 117 */       String name = (String)names.nextElement();
/* 118 */       for (Enumeration<?> values = request.getHeaders(name); values.hasMoreElements();) {
/* 119 */         headers.add(name, values.nextElement());
/*     */       }
/*     */     } 
/* 122 */     return headers;
/*     */   }
/*     */ 
/*     */   
/*     */   private static URI initUri(HttpServletRequest servletRequest) {
/* 127 */     Assert.notNull(servletRequest, "'request' must not be null");
/* 128 */     String urlString = null;
/* 129 */     String query = null;
/* 130 */     boolean hasQuery = false;
/*     */     try {
/* 132 */       StringBuffer requestURL = servletRequest.getRequestURL();
/* 133 */       query = servletRequest.getQueryString();
/* 134 */       hasQuery = StringUtils.hasText(query);
/* 135 */       if (hasQuery) {
/* 136 */         requestURL.append('?').append(query);
/*     */       }
/* 138 */       urlString = requestURL.toString();
/* 139 */       return new URI(urlString);
/*     */     }
/* 141 */     catch (URISyntaxException ex) {
/* 142 */       if (hasQuery) {
/*     */         
/*     */         try {
/* 145 */           query = UriComponentsBuilder.fromUriString("?" + query).build().toUri().getRawQuery();
/* 146 */           return new URI(servletRequest.getRequestURL().toString() + "?" + servletRequest.getRequestURL().toString());
/*     */         }
/* 148 */         catch (URISyntaxException ex2) {
/*     */           
/*     */           try {
/* 151 */             return new URI(servletRequest.getRequestURL().toString());
/*     */           }
/* 153 */           catch (URISyntaxException uRISyntaxException) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 158 */       throw new IllegalStateException("Could not resolve HttpServletRequest as URI: " + urlString, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MultiValueMap<String, String> initHeaders(MultiValueMap<String, String> headerValues, HttpServletRequest request) {
/* 167 */     HttpHeaders headers = null;
/* 168 */     MediaType contentType = null;
/* 169 */     if (!StringUtils.hasLength((String)headerValues.getFirst("Content-Type"))) {
/* 170 */       String requestContentType = request.getContentType();
/* 171 */       if (StringUtils.hasLength(requestContentType)) {
/* 172 */         contentType = MediaType.parseMediaType(requestContentType);
/* 173 */         headers = new HttpHeaders(headerValues);
/* 174 */         headers.setContentType(contentType);
/*     */       } 
/*     */     } 
/* 177 */     if (contentType != null && contentType.getCharset() == null) {
/* 178 */       String encoding = request.getCharacterEncoding();
/* 179 */       if (StringUtils.hasLength(encoding)) {
/* 180 */         LinkedCaseInsensitiveMap<String, String> linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap();
/* 181 */         linkedCaseInsensitiveMap.putAll(contentType.getParameters());
/* 182 */         linkedCaseInsensitiveMap.put("charset", Charset.forName(encoding).toString());
/* 183 */         headers.setContentType(new MediaType(contentType, (Map)linkedCaseInsensitiveMap));
/*     */       } 
/*     */     } 
/* 186 */     if (headerValues.getFirst("Content-Type") == null) {
/* 187 */       int contentLength = request.getContentLength();
/* 188 */       if (contentLength != -1) {
/* 189 */         headers = (headers != null) ? headers : new HttpHeaders(headerValues);
/* 190 */         headers.setContentLength(contentLength);
/*     */       } 
/*     */     } 
/* 193 */     return (headers != null) ? (MultiValueMap<String, String>)headers : headerValues;
/*     */   }
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/*     */     Cookie[] cookies;
/* 198 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*     */     
/* 200 */     synchronized (this.cookieLock) {
/* 201 */       cookies = this.request.getCookies();
/*     */     } 
/* 203 */     if (cookies != null) {
/* 204 */       for (Cookie cookie : cookies) {
/* 205 */         String name = cookie.getName();
/* 206 */         HttpCookie httpCookie = new HttpCookie(name, cookie.getValue());
/* 207 */         linkedMultiValueMap.add(name, httpCookie);
/*     */       } 
/*     */     }
/* 210 */     return (MultiValueMap<String, HttpCookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public InetSocketAddress getLocalAddress() {
/* 216 */     return new InetSocketAddress(this.request.getLocalAddr(), this.request.getLocalPort());
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public InetSocketAddress getRemoteAddress() {
/* 222 */     return new InetSocketAddress(this.request.getRemoteHost(), this.request.getRemotePort());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected SslInfo initSslInfo() {
/* 228 */     X509Certificate[] certificates = getX509Certificates();
/* 229 */     return (certificates != null) ? new DefaultSslInfo(getSslSessionId(), certificates) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getSslSessionId() {
/* 234 */     return (String)this.request.getAttribute("jakarta.servlet.request.ssl_session_id");
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private X509Certificate[] getX509Certificates() {
/* 239 */     return (X509Certificate[])this.request.getAttribute("jakarta.servlet.request.X509Certificate");
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 244 */     return Flux.from(this.bodyPublisher);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 250 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AsyncListener getAsyncListener() {
/* 260 */     return this.asyncListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ServletInputStream getInputStream() {
/* 267 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataBuffer readFromInputStream() throws IOException {
/* 278 */     int read = this.inputStream.read(this.buffer);
/* 279 */     logBytesRead(read);
/*     */     
/* 281 */     if (read > 0) {
/* 282 */       DataBuffer dataBuffer = this.bufferFactory.allocateBuffer(read);
/* 283 */       dataBuffer.write(this.buffer, 0, read);
/* 284 */       return dataBuffer;
/*     */     } 
/*     */     
/* 287 */     if (read == -1) {
/* 288 */       return EOF_BUFFER;
/*     */     }
/*     */     
/* 291 */     return AbstractListenerReadPublisher.EMPTY_BUFFER;
/*     */   }
/*     */   
/*     */   protected final void logBytesRead(int read) {
/* 295 */     Log rsReadLogger = AbstractListenerReadPublisher.rsReadLogger;
/* 296 */     if (rsReadLogger.isTraceEnabled()) {
/* 297 */       rsReadLogger.trace(getLogPrefix() + "Read " + getLogPrefix() + read);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class RequestAsyncListener
/*     */     implements AsyncListener
/*     */   {
/*     */     public void onStartAsync(AsyncEvent event) {}
/*     */ 
/*     */     
/*     */     public void onTimeout(AsyncEvent event) {
/* 310 */       Throwable ex = event.getThrowable();
/* 311 */       ex = (ex != null) ? ex : new IllegalStateException("Async operation timeout.");
/* 312 */       ServletServerHttpRequest.this.bodyPublisher.onError(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(AsyncEvent event) {
/* 317 */       ServletServerHttpRequest.this.bodyPublisher.onError(event.getThrowable());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete(AsyncEvent event) {
/* 322 */       ServletServerHttpRequest.this.bodyPublisher.onAllDataRead();
/*     */     }
/*     */   }
/*     */   
/*     */   private class RequestBodyPublisher
/*     */     extends AbstractListenerReadPublisher<DataBuffer>
/*     */   {
/*     */     private final ServletInputStream inputStream;
/*     */     
/*     */     public RequestBodyPublisher(ServletInputStream inputStream) {
/* 332 */       super(ServletServerHttpRequest.this.getLogPrefix());
/* 333 */       this.inputStream = inputStream;
/*     */     }
/*     */     
/*     */     public void registerReadListener() throws IOException {
/* 337 */       this.inputStream.setReadListener(new RequestBodyPublisherReadListener());
/*     */     }
/*     */ 
/*     */     
/*     */     protected void checkOnDataAvailable() {
/* 342 */       if (this.inputStream.isReady() && !this.inputStream.isFinished()) {
/* 343 */         onDataAvailable();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected DataBuffer read() throws IOException {
/* 350 */       if (this.inputStream.isReady()) {
/* 351 */         DataBuffer dataBuffer = ServletServerHttpRequest.this.readFromInputStream();
/* 352 */         if (dataBuffer == ServletServerHttpRequest.EOF_BUFFER) {
/*     */           
/* 354 */           onAllDataRead();
/* 355 */           dataBuffer = null;
/*     */         } 
/* 357 */         return dataBuffer;
/*     */       } 
/* 359 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void readingPaused() {}
/*     */ 
/*     */ 
/*     */     
/*     */     protected void discardData() {}
/*     */ 
/*     */ 
/*     */     
/*     */     private class RequestBodyPublisherReadListener
/*     */       implements ReadListener
/*     */     {
/*     */       public void onDataAvailable() throws IOException {
/* 377 */         ServletServerHttpRequest.RequestBodyPublisher.this.onDataAvailable();
/*     */       }
/*     */ 
/*     */       
/*     */       public void onAllDataRead() throws IOException {
/* 382 */         ServletServerHttpRequest.RequestBodyPublisher.this.onAllDataRead();
/*     */       }
/*     */       
/*     */       public void onError(Throwable throwable)
/*     */       {
/* 387 */         ServletServerHttpRequest.RequestBodyPublisher.this.onError(throwable); } } } private class RequestBodyPublisherReadListener implements ReadListener { public void onError(Throwable throwable) { this.this$1.onError(throwable); }
/*     */ 
/*     */     
/*     */     public void onDataAvailable() throws IOException {
/*     */       this.this$1.onDataAvailable();
/*     */     }
/*     */     
/*     */     public void onAllDataRead() throws IOException {
/*     */       this.this$1.onAllDataRead();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServletServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */