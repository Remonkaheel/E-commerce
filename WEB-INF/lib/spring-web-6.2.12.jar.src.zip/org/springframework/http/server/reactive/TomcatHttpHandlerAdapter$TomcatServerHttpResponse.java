/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.catalina.connector.CoyoteOutputStream;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.connector.ResponseFacade;
/*     */ import org.apache.coyote.Response;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TomcatServerHttpResponse
/*     */   extends ServletServerHttpResponse
/*     */ {
/*     */   private static final Field COYOTE_RESPONSE_FIELD;
/*     */   
/*     */   static {
/* 170 */     Field field = ReflectionUtils.findField(ResponseFacade.class, "response");
/* 171 */     Assert.state((field != null), "Incompatible Tomcat implementation");
/* 172 */     ReflectionUtils.makeAccessible(field);
/* 173 */     COYOTE_RESPONSE_FIELD = field;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TomcatServerHttpResponse(HttpServletResponse response, AsyncContext context, DataBufferFactory factory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/* 179 */     super(createTomcatHttpHeaders(response), response, context, factory, bufferSize, request);
/*     */   }
/*     */   
/*     */   private static HttpHeaders createTomcatHttpHeaders(HttpServletResponse response) {
/* 183 */     ResponseFacade responseFacade = getResponseFacade(response);
/*     */     
/* 185 */     Response connectorResponse = (Response)ReflectionUtils.getField(COYOTE_RESPONSE_FIELD, responseFacade);
/* 186 */     Assert.state((connectorResponse != null), "No Tomcat connector response");
/* 187 */     Response tomcatResponse = connectorResponse.getCoyoteResponse();
/* 188 */     TomcatHeadersAdapter headers = new TomcatHeadersAdapter(tomcatResponse.getMimeHeaders());
/* 189 */     return new HttpHeaders(headers);
/*     */   }
/*     */   
/*     */   private static ResponseFacade getResponseFacade(HttpServletResponse response) {
/* 193 */     if (response instanceof ResponseFacade) { ResponseFacade facade = (ResponseFacade)response;
/* 194 */       return facade; }
/*     */     
/* 196 */     if (response instanceof HttpServletResponseWrapper) { HttpServletResponseWrapper wrapper = (HttpServletResponseWrapper)response;
/* 197 */       HttpServletResponse wrappedResponse = (HttpServletResponse)wrapper.getResponse();
/* 198 */       return getResponseFacade(wrappedResponse); }
/*     */ 
/*     */     
/* 201 */     throw new IllegalArgumentException("Cannot convert [" + String.valueOf(response.getClass()) + "] to org.apache.catalina.connector.ResponseFacade");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 208 */     adaptHeaders(true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int writeToOutputStream(DataBuffer dataBuffer) throws IOException {
/* 213 */     ServletOutputStream servletOutputStream = getOutputStream(); if (servletOutputStream instanceof CoyoteOutputStream) { CoyoteOutputStream coyoteOutputStream = (CoyoteOutputStream)servletOutputStream;
/* 214 */       int len = 0;
/* 215 */       DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 216 */       try { while (iterator.hasNext() && coyoteOutputStream.isReady()) {
/* 217 */           ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 218 */           len += byteBuffer.remaining();
/* 219 */           coyoteOutputStream.write(byteBuffer);
/*     */         } 
/* 221 */         if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 222 */           try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return len; }
/*     */ 
/*     */     
/* 225 */     return super.writeToOutputStream(dataBuffer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\TomcatHttpHandlerAdapter$TomcatServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */