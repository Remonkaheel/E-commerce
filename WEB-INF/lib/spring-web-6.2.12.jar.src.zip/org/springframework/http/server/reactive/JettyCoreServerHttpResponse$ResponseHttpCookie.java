/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jetty.http.HttpCookie;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResponseHttpCookie
/*     */   implements HttpCookie
/*     */ {
/*     */   private final ResponseCookie responseCookie;
/*     */   
/*     */   ResponseHttpCookie(ResponseCookie responseCookie) {
/* 171 */     this.responseCookie = responseCookie;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 176 */     return this.responseCookie.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 181 */     return this.responseCookie.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVersion() {
/* 186 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMaxAge() {
/* 191 */     return this.responseCookie.getMaxAge().toSeconds();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getComment() {
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getDomain() {
/* 203 */     return this.responseCookie.getDomain();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPath() {
/* 209 */     return this.responseCookie.getPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSecure() {
/* 214 */     return this.responseCookie.isSecure();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HttpCookie.SameSite getSameSite() {
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHttpOnly() {
/* 226 */     return this.responseCookie.isHttpOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPartitioned() {
/* 231 */     return this.responseCookie.isPartitioned();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getAttributes() {
/* 236 */     return Collections.emptyMap();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyCoreServerHttpResponse$ResponseHttpCookie.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */