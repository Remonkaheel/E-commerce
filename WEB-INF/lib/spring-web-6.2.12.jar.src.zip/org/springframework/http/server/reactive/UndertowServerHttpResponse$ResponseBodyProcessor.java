/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.xnio.channels.StreamSinkChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResponseBodyProcessor
/*     */   extends AbstractListenerWriteProcessor<DataBuffer>
/*     */ {
/*     */   private final StreamSinkChannel channel;
/*     */   @Nullable
/*     */   private volatile ByteBuffer byteBuffer;
/*     */   private volatile boolean writePossible;
/*     */   
/*     */   public ResponseBodyProcessor(StreamSinkChannel channel) {
/* 176 */     super(paramUndertowServerHttpResponse.request.getLogPrefix());
/* 177 */     Assert.notNull(channel, "StreamSinkChannel must not be null");
/* 178 */     this.channel = channel;
/* 179 */     this.channel.getWriteSetter().set(c -> {
/*     */           this.writePossible = true;
/*     */           onWritePossible();
/*     */         });
/* 183 */     this.channel.suspendWrites();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isWritePossible() {
/* 188 */     this.channel.resumeWrites();
/* 189 */     return this.writePossible;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean write(DataBuffer dataBuffer) throws IOException {
/* 194 */     ByteBuffer buffer = this.byteBuffer;
/* 195 */     if (buffer == null) {
/* 196 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 200 */     this.writePossible = false;
/*     */ 
/*     */     
/* 203 */     int total = buffer.remaining();
/* 204 */     int written = writeByteBuffer(buffer);
/*     */     
/* 206 */     if (rsWriteLogger.isTraceEnabled()) {
/* 207 */       rsWriteLogger.trace(getLogPrefix() + "Wrote " + getLogPrefix() + " of " + written + " bytes");
/*     */     }
/* 209 */     if (written != total) {
/* 210 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 214 */     this.writePossible = true;
/*     */     
/* 216 */     DataBufferUtils.release(dataBuffer);
/* 217 */     this.byteBuffer = null;
/* 218 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private int writeByteBuffer(ByteBuffer byteBuffer) throws IOException {
/* 223 */     int written, totalWritten = 0;
/*     */     do {
/* 225 */       written = this.channel.write(byteBuffer);
/* 226 */       totalWritten += written;
/*     */     }
/* 228 */     while (byteBuffer.hasRemaining() && written > 0);
/* 229 */     return totalWritten;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataReceived(DataBuffer dataBuffer) {
/* 234 */     super.dataReceived(dataBuffer);
/* 235 */     ByteBuffer byteBuffer = ByteBuffer.allocate(dataBuffer.readableByteCount());
/* 236 */     dataBuffer.toByteBuffer(byteBuffer);
/* 237 */     this.byteBuffer = byteBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isDataEmpty(DataBuffer dataBuffer) {
/* 242 */     return (dataBuffer.readableByteCount() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writingComplete() {
/* 247 */     this.channel.getWriteSetter().set(null);
/* 248 */     this.channel.resumeWrites();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writingFailed(Throwable ex) {
/* 253 */     cancel();
/* 254 */     onError(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void discardData(DataBuffer dataBuffer) {
/* 259 */     DataBufferUtils.release(dataBuffer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowServerHttpResponse$ResponseBodyProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */