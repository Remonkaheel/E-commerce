/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import io.netty5.handler.codec.http.HttpResponseStatus;
/*    */ import java.net.URISyntaxException;
/*    */ import java.util.function.BiFunction;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*    */ import org.springframework.http.HttpLogging;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty5.http.server.HttpServerRequest;
/*    */ import reactor.netty5.http.server.HttpServerResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactorNetty2HttpHandlerAdapter
/*    */   implements BiFunction<HttpServerRequest, HttpServerResponse, Mono<Void>>
/*    */ {
/* 43 */   private static final Log logger = HttpLogging.forLogName(ReactorNetty2HttpHandlerAdapter.class);
/*    */ 
/*    */   
/*    */   private final HttpHandler httpHandler;
/*    */ 
/*    */   
/*    */   public ReactorNetty2HttpHandlerAdapter(HttpHandler httpHandler) {
/* 50 */     Assert.notNull(httpHandler, "HttpHandler must not be null");
/* 51 */     this.httpHandler = httpHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> apply(HttpServerRequest reactorRequest, HttpServerResponse reactorResponse) {
/* 57 */     Netty5DataBufferFactory bufferFactory = new Netty5DataBufferFactory(reactorResponse.alloc());
/*    */     try {
/* 59 */       ReactorNetty2ServerHttpRequest request = new ReactorNetty2ServerHttpRequest(reactorRequest, bufferFactory);
/* 60 */       ServerHttpResponse response = new ReactorNetty2ServerHttpResponse(reactorResponse, (DataBufferFactory)bufferFactory);
/*    */       
/* 62 */       if (request.getMethod() == HttpMethod.HEAD) {
/* 63 */         response = new HttpHeadResponseDecorator(response);
/*    */       }
/*    */       
/* 66 */       return this.httpHandler.handle(request, response)
/* 67 */         .doOnError(ex -> logger.trace(request.getLogPrefix() + "Failed to complete: " + request.getLogPrefix()))
/* 68 */         .doOnSuccess(aVoid -> logger.trace(request.getLogPrefix() + "Handling completed"));
/*    */     }
/* 70 */     catch (URISyntaxException ex) {
/* 71 */       if (logger.isDebugEnabled()) {
/* 72 */         logger.debug("Failed to get request URI: " + ex.getMessage());
/*    */       }
/* 74 */       reactorResponse.status(HttpResponseStatus.BAD_REQUEST);
/* 75 */       return Mono.empty();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorNetty2HttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */