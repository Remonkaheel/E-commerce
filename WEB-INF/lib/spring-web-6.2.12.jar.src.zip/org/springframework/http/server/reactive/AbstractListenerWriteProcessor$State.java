/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum State
/*     */ {
/* 356 */   UNSUBSCRIBED
/*     */   {
/*     */     public <T> void onSubscribe(AbstractListenerWriteProcessor<T> processor, Subscription subscription) {
/* 359 */       Assert.notNull(subscription, "Subscription must not be null");
/* 360 */       if (processor.changeState(this, REQUESTED)) {
/* 361 */         processor.subscription = subscription;
/* 362 */         subscription.request(1L);
/*     */       } else {
/*     */         
/* 365 */         super.onSubscribe(processor, subscription);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 372 */       processor.changeStateToComplete(this);
/*     */     }
/*     */   },
/*     */   
/* 376 */   REQUESTED
/*     */   {
/*     */     public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {
/* 379 */       if (processor.isDataEmpty(data)) {
/* 380 */         Assert.state((processor.subscription != null), "No subscription");
/* 381 */         processor.subscription.request(1L);
/*     */       } else {
/*     */         
/* 384 */         processor.dataReceived(data);
/* 385 */         processor.changeStateToReceived(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 390 */       processor.readyToCompleteAfterLastWrite = true;
/* 391 */       processor.changeStateToReceived(this);
/*     */     }
/*     */   },
/*     */   
/* 395 */   RECEIVED
/*     */   {
/*     */     public <T> void onWritePossible(AbstractListenerWriteProcessor<T> processor)
/*     */     {
/* 399 */       if (processor.readyToCompleteAfterLastWrite) {
/* 400 */         processor.changeStateToComplete(RECEIVED);
/*     */       }
/* 402 */       else if (processor.changeState(this, WRITING)) {
/* 403 */         T data = processor.currentData;
/* 404 */         Assert.state((data != null), "No data");
/*     */         try {
/* 406 */           if (processor.write(data)) {
/* 407 */             if (processor.changeState(WRITING, REQUESTED)) {
/* 408 */               processor.currentData = null;
/* 409 */               if (processor.sourceCompleted) {
/* 410 */                 processor.readyToCompleteAfterLastWrite = true;
/* 411 */                 processor.changeStateToReceived(REQUESTED);
/*     */               } else {
/*     */                 
/* 414 */                 processor.writingPaused();
/* 415 */                 Assert.state((processor.subscription != null), "No subscription");
/* 416 */                 processor.subscription.request(1L);
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             
/* 421 */             processor.changeStateToReceived(WRITING);
/*     */           }
/*     */         
/* 424 */         } catch (IOException ex) {
/* 425 */           processor.writingFailed(ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 432 */       processor.sourceCompleted = true;
/*     */       
/* 434 */       if (processor.state.get() == State.REQUESTED) {
/* 435 */         processor.changeStateToComplete(State.REQUESTED);
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 440 */   WRITING
/*     */   {
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 443 */       processor.sourceCompleted = true;
/*     */       
/* 445 */       if (processor.state.get() == State.REQUESTED) {
/* 446 */         processor.changeStateToComplete(State.REQUESTED);
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 451 */   COMPLETED
/*     */   {
/*     */     public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {}
/*     */   };
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void onSubscribe(AbstractListenerWriteProcessor<T> processor, Subscription subscription) {
/* 467 */     subscription.cancel();
/*     */   }
/*     */   
/*     */   public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {
/* 471 */     processor.discardData(data);
/* 472 */     processor.cancel();
/* 473 */     processor.onError(new IllegalStateException("Illegal onNext without demand"));
/*     */   }
/*     */   
/*     */   public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {
/* 477 */     if (processor.changeState(this, COMPLETED)) {
/* 478 */       processor.discardCurrentData();
/* 479 */       processor.writingComplete();
/* 480 */       processor.resultPublisher.publishError(ex);
/*     */     } else {
/*     */       
/* 483 */       ((State)processor.state.get()).onError(processor, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 488 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   public <T> void onWritePossible(AbstractListenerWriteProcessor<T> processor) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteProcessor$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */