/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import jakarta.servlet.AsyncContext;
/*    */ import jakarta.servlet.ServletOutputStream;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.eclipse.jetty.ee10.servlet.HttpOutput;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Jetty12ServerHttpResponse
/*    */   extends ServletServerHttpResponse
/*    */ {
/*    */   Jetty12ServerHttpResponse(HttpServletResponse response, AsyncContext asyncContext, DataBufferFactory bufferFactory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/* 62 */     super(response, asyncContext, bufferFactory, bufferSize, request);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int writeToOutputStream(DataBuffer dataBuffer) throws IOException {
/* 67 */     ServletOutputStream servletOutputStream = getOutputStream();
/* 68 */     if (servletOutputStream instanceof HttpOutput) { HttpOutput httpOutput = (HttpOutput)servletOutputStream;
/* 69 */       int len = 0;
/* 70 */       DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 71 */       try { while (iterator.hasNext() && httpOutput.isReady()) {
/* 72 */           ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 73 */           len += byteBuffer.remaining();
/* 74 */           httpOutput.write(byteBuffer);
/*    */         } 
/* 76 */         if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 77 */           try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return len; }
/*    */     
/* 79 */     return super.writeToOutputStream(dataBuffer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyHttpHandlerAdapter$Jetty12ServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */