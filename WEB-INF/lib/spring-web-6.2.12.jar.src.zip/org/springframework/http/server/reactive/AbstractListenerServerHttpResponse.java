/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.reactivestreams.Processor;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractListenerServerHttpResponse
/*    */   extends AbstractServerHttpResponse
/*    */ {
/* 37 */   private final AtomicBoolean writeCalled = new AtomicBoolean();
/*    */ 
/*    */   
/*    */   public AbstractListenerServerHttpResponse(DataBufferFactory bufferFactory) {
/* 41 */     super(bufferFactory);
/*    */   }
/*    */   
/*    */   public AbstractListenerServerHttpResponse(DataBufferFactory bufferFactory, HttpHeaders headers) {
/* 45 */     super(bufferFactory, headers);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final Mono<Void> writeWithInternal(Publisher<? extends DataBuffer> body) {
/* 51 */     return writeAndFlushWithInternal((Publisher<? extends Publisher<? extends DataBuffer>>)Mono.just(body));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final Mono<Void> writeAndFlushWithInternal(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 58 */     if (!this.writeCalled.compareAndSet(false, true)) {
/* 59 */       return Mono.error(new IllegalStateException("writeWith() or writeAndFlushWith() has already been called"));
/*    */     }
/*    */     
/* 62 */     Processor<? super Publisher<? extends DataBuffer>, Void> processor = createBodyFlushProcessor();
/* 63 */     return Mono.from(subscriber -> {
/*    */           body.subscribe((Subscriber)processor);
/*    */           processor.subscribe(subscriber);
/*    */         });
/*    */   }
/*    */   
/*    */   protected abstract Processor<? super Publisher<? extends DataBuffer>, Void> createBodyFlushProcessor();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */