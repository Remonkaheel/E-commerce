/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncEvent;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.WriteListener;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServletServerHttpResponse
/*     */   extends AbstractListenerServerHttpResponse
/*     */ {
/*  53 */   private static final boolean IS_SERVLET61 = (ReflectionUtils.findField(HttpServletResponse.class, "SC_PERMANENT_REDIRECT") != null);
/*     */ 
/*     */   
/*     */   private final HttpServletResponse response;
/*     */ 
/*     */   
/*     */   private final ServletOutputStream outputStream;
/*     */   
/*     */   private final int bufferSize;
/*     */   
/*     */   @Nullable
/*     */   private volatile ResponseBodyFlushProcessor bodyFlushProcessor;
/*     */   
/*     */   @Nullable
/*     */   private volatile ResponseBodyProcessor bodyProcessor;
/*     */   
/*     */   private volatile boolean flushOnNext;
/*     */   
/*     */   private final ServletServerHttpRequest request;
/*     */   
/*     */   private final ResponseAsyncListener asyncListener;
/*     */ 
/*     */   
/*     */   public ServletServerHttpResponse(HttpServletResponse response, AsyncContext asyncContext, DataBufferFactory bufferFactory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/*  77 */     this(new HttpHeaders(), response, asyncContext, bufferFactory, bufferSize, request);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletServerHttpResponse(HttpHeaders headers, HttpServletResponse response, AsyncContext asyncContext, DataBufferFactory bufferFactory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/*  83 */     super(bufferFactory, headers);
/*     */     
/*  85 */     Assert.notNull(response, "HttpServletResponse must not be null");
/*  86 */     Assert.notNull(bufferFactory, "DataBufferFactory must not be null");
/*  87 */     Assert.isTrue((bufferSize > 0), "Buffer size must be greater than 0");
/*     */     
/*  89 */     this.response = response;
/*  90 */     this.outputStream = response.getOutputStream();
/*  91 */     this.bufferSize = bufferSize;
/*  92 */     this.request = request;
/*     */     
/*  94 */     this.asyncListener = new ResponseAsyncListener();
/*     */ 
/*     */     
/*  97 */     response.getOutputStream().setWriteListener(new ResponseBodyWriteListener());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeResponse() {
/* 104 */     return (T)this.response;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/* 109 */     HttpStatusCode status = super.getStatusCode();
/* 110 */     return (status != null) ? status : HttpStatusCode.valueOf(this.response.getStatus());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Integer getRawStatusCode() {
/* 117 */     Integer status = super.getRawStatusCode();
/* 118 */     return Integer.valueOf((status != null) ? status.intValue() : this.response.getStatus());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyStatusCode() {
/* 123 */     HttpStatusCode status = super.getStatusCode();
/* 124 */     if (status != null) {
/* 125 */       this.response.setStatus(status.value());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 131 */     getHeaders().forEach((headerName, headerValues) -> {
/*     */           for (String headerValue : headerValues) {
/*     */             this.response.addHeader(headerName, headerValue);
/*     */           }
/*     */         });
/*     */     
/* 137 */     adaptHeaders(false);
/*     */   }
/*     */   
/*     */   protected void adaptHeaders(boolean removeAdaptedHeaders) {
/* 141 */     MediaType contentType = null;
/*     */     try {
/* 143 */       contentType = getHeaders().getContentType();
/*     */     }
/* 145 */     catch (Exception ex) {
/* 146 */       String rawContentType = getHeaders().getFirst("Content-Type");
/* 147 */       this.response.setContentType(rawContentType);
/*     */     } 
/* 149 */     if (this.response.getContentType() == null && contentType != null) {
/* 150 */       this.response.setContentType(contentType.toString());
/*     */     }
/*     */     
/* 153 */     Charset charset = (contentType != null) ? contentType.getCharset() : null;
/* 154 */     if (this.response.getCharacterEncoding() == null && charset != null) {
/* 155 */       this.response.setCharacterEncoding(charset.name());
/*     */     }
/*     */     
/* 158 */     long contentLength = getHeaders().getContentLength();
/* 159 */     if (contentLength != -1L) {
/* 160 */       this.response.setContentLengthLong(contentLength);
/*     */     }
/*     */     
/* 163 */     if (removeAdaptedHeaders) {
/* 164 */       getHeaders().remove("Content-Type");
/* 165 */       getHeaders().remove("Content-Length");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 171 */     for (String name : getCookies().keySet()) {
/* 172 */       for (ResponseCookie httpCookie : getCookies().get(name)) {
/* 173 */         Cookie cookie = new Cookie(name, httpCookie.getValue());
/* 174 */         if (!httpCookie.getMaxAge().isNegative()) {
/* 175 */           cookie.setMaxAge((int)httpCookie.getMaxAge().getSeconds());
/*     */         }
/* 177 */         if (httpCookie.getDomain() != null) {
/* 178 */           cookie.setDomain(httpCookie.getDomain());
/*     */         }
/* 180 */         if (httpCookie.getPath() != null) {
/* 181 */           cookie.setPath(httpCookie.getPath());
/*     */         }
/* 183 */         if (httpCookie.getSameSite() != null) {
/* 184 */           cookie.setAttribute("SameSite", httpCookie.getSameSite());
/*     */         }
/* 186 */         cookie.setSecure(httpCookie.isSecure());
/* 187 */         cookie.setHttpOnly(httpCookie.isHttpOnly());
/* 188 */         if (httpCookie.isPartitioned()) {
/* 189 */           if (IS_SERVLET61) {
/* 190 */             cookie.setAttribute("Partitioned", "");
/*     */           } else {
/*     */             
/* 193 */             cookie.setAttribute("Partitioned", "true");
/*     */           } 
/*     */         }
/* 196 */         this.response.addCookie(cookie);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AsyncListener getAsyncListener() {
/* 208 */     return this.asyncListener;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Processor<? super Publisher<? extends DataBuffer>, Void> createBodyFlushProcessor() {
/* 213 */     ResponseBodyFlushProcessor processor = new ResponseBodyFlushProcessor();
/* 214 */     this.bodyFlushProcessor = processor;
/* 215 */     return processor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ServletOutputStream getOutputStream() {
/* 222 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int writeToOutputStream(DataBuffer dataBuffer) throws IOException {
/* 232 */     ServletOutputStream outputStream = this.outputStream;
/* 233 */     InputStream input = dataBuffer.asInputStream();
/* 234 */     int bytesWritten = 0;
/* 235 */     byte[] buffer = new byte[this.bufferSize];
/*     */     int bytesRead;
/* 237 */     while (outputStream.isReady() && (bytesRead = input.read(buffer)) != -1) {
/* 238 */       outputStream.write(buffer, 0, bytesRead);
/* 239 */       bytesWritten += bytesRead;
/*     */     } 
/* 241 */     return bytesWritten;
/*     */   }
/*     */   
/*     */   private void flush() throws IOException {
/* 245 */     ServletOutputStream outputStream = this.outputStream;
/* 246 */     if (outputStream.isReady()) {
/*     */       try {
/* 248 */         outputStream.flush();
/* 249 */         this.flushOnNext = false;
/*     */       }
/* 251 */       catch (IOException ex) {
/* 252 */         this.flushOnNext = true;
/* 253 */         throw ex;
/*     */       } 
/*     */     } else {
/*     */       
/* 257 */       this.flushOnNext = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isWritePossible() {
/* 262 */     return this.outputStream.isReady();
/*     */   }
/*     */ 
/*     */   
/*     */   private final class ResponseAsyncListener
/*     */     implements AsyncListener
/*     */   {
/*     */     public void onStartAsync(AsyncEvent event) {}
/*     */ 
/*     */     
/*     */     public void onTimeout(AsyncEvent event) {
/* 273 */       Throwable ex = event.getThrowable();
/* 274 */       ex = (ex != null) ? ex : new IllegalStateException("Async operation timeout.");
/* 275 */       handleError(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(AsyncEvent event) {
/* 280 */       handleError(event.getThrowable());
/*     */     }
/*     */     
/*     */     public void handleError(Throwable ex) {
/* 284 */       ServletServerHttpResponse.ResponseBodyFlushProcessor flushProcessor = ServletServerHttpResponse.this.bodyFlushProcessor;
/* 285 */       ServletServerHttpResponse.ResponseBodyProcessor processor = ServletServerHttpResponse.this.bodyProcessor;
/* 286 */       if (flushProcessor != null) {
/*     */         
/* 288 */         flushProcessor.cancel();
/*     */         
/* 290 */         if (processor != null) {
/* 291 */           processor.cancel();
/* 292 */           processor.onError(ex);
/*     */         } 
/*     */         
/* 295 */         flushProcessor.onError(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete(AsyncEvent event) {
/* 301 */       ServletServerHttpResponse.ResponseBodyFlushProcessor flushProcessor = ServletServerHttpResponse.this.bodyFlushProcessor;
/* 302 */       ServletServerHttpResponse.ResponseBodyProcessor processor = ServletServerHttpResponse.this.bodyProcessor;
/* 303 */       if (flushProcessor != null) {
/*     */         
/* 305 */         flushProcessor.cancel();
/*     */         
/* 307 */         if (processor != null) {
/* 308 */           processor.cancel();
/* 309 */           processor.onComplete();
/*     */         } 
/*     */         
/* 312 */         flushProcessor.onComplete();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ResponseBodyWriteListener
/*     */     implements WriteListener
/*     */   {
/*     */     public void onWritePossible() {
/* 322 */       ServletServerHttpResponse.ResponseBodyProcessor processor = ServletServerHttpResponse.this.bodyProcessor;
/* 323 */       if (processor != null) {
/* 324 */         processor.onWritePossible();
/*     */       } else {
/*     */         
/* 327 */         ServletServerHttpResponse.ResponseBodyFlushProcessor flushProcessor = ServletServerHttpResponse.this.bodyFlushProcessor;
/* 328 */         if (flushProcessor != null) {
/* 329 */           flushProcessor.onFlushPossible();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 336 */       ServletServerHttpResponse.this.asyncListener.handleError(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ResponseBodyFlushProcessor
/*     */     extends AbstractListenerWriteFlushProcessor<DataBuffer>
/*     */   {
/*     */     public ResponseBodyFlushProcessor() {
/* 344 */       super(ServletServerHttpResponse.this.request.getLogPrefix());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Processor<? super DataBuffer, Void> createWriteProcessor() {
/* 349 */       ServletServerHttpResponse.ResponseBodyProcessor processor = new ServletServerHttpResponse.ResponseBodyProcessor();
/* 350 */       ServletServerHttpResponse.this.bodyProcessor = processor;
/* 351 */       return processor;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void flush() throws IOException {
/* 356 */       if (rsWriteFlushLogger.isTraceEnabled()) {
/* 357 */         rsWriteFlushLogger.trace(getLogPrefix() + "flushing");
/*     */       }
/* 359 */       ServletServerHttpResponse.this.flush();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isWritePossible() {
/* 364 */       return ServletServerHttpResponse.this.isWritePossible();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isFlushPending() {
/* 369 */       return ServletServerHttpResponse.this.flushOnNext;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ResponseBodyProcessor
/*     */     extends AbstractListenerWriteProcessor<DataBuffer>
/*     */   {
/*     */     public ResponseBodyProcessor() {
/* 378 */       super(ServletServerHttpResponse.this.request.getLogPrefix());
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isWritePossible() {
/* 383 */       return ServletServerHttpResponse.this.isWritePossible();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isDataEmpty(DataBuffer dataBuffer) {
/* 388 */       return (dataBuffer.readableByteCount() == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean write(DataBuffer dataBuffer) throws IOException {
/* 393 */       if (ServletServerHttpResponse.this.flushOnNext) {
/* 394 */         if (rsWriteLogger.isTraceEnabled()) {
/* 395 */           rsWriteLogger.trace(getLogPrefix() + "flushing");
/*     */         }
/* 397 */         ServletServerHttpResponse.this.flush();
/*     */       } 
/*     */       
/* 400 */       boolean ready = ServletServerHttpResponse.this.isWritePossible();
/* 401 */       int remaining = dataBuffer.readableByteCount();
/* 402 */       if (ready && remaining > 0) {
/*     */         
/* 404 */         int written = ServletServerHttpResponse.this.writeToOutputStream(dataBuffer);
/* 405 */         if (rsWriteLogger.isTraceEnabled()) {
/* 406 */           rsWriteLogger.trace(getLogPrefix() + "Wrote " + getLogPrefix() + " of " + written + " bytes");
/*     */         }
/* 408 */         if (written == remaining) {
/* 409 */           DataBufferUtils.release(dataBuffer);
/* 410 */           return true;
/*     */         }
/*     */       
/*     */       }
/* 414 */       else if (rsWriteLogger.isTraceEnabled()) {
/* 415 */         rsWriteLogger.trace(getLogPrefix() + "ready: " + getLogPrefix() + ", remaining: " + ready);
/*     */       } 
/*     */ 
/*     */       
/* 419 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void writingComplete() {
/* 424 */       ServletServerHttpResponse.this.bodyProcessor = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void discardData(DataBuffer dataBuffer) {
/* 429 */       DataBufferUtils.release(dataBuffer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServletServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */