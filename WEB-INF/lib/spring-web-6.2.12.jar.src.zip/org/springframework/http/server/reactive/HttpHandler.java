package org.springframework.http.server.reactive;

import reactor.core.publisher.Mono;

public interface HttpHandler {
  Mono<Void> handle(ServerHttpRequest paramServerHttpRequest, ServerHttpResponse paramServerHttpResponse);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\HttpHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */