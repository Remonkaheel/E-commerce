/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.log.LogDelegateFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractListenerWriteFlushProcessor<T>
/*     */   implements Processor<Publisher<? extends T>, Void>
/*     */ {
/*  54 */   protected static final Log rsWriteFlushLogger = LogDelegateFactory.getHiddenLog(AbstractListenerWriteFlushProcessor.class);
/*     */ 
/*     */   
/*  57 */   private final AtomicReference<State> state = new AtomicReference<>(State.UNSUBSCRIBED);
/*     */   
/*     */   @Nullable
/*     */   private Subscription subscription;
/*     */   
/*     */   private volatile boolean sourceCompleted;
/*     */   
/*     */   @Nullable
/*     */   private volatile AbstractListenerWriteProcessor<?> currentWriteProcessor;
/*     */   
/*     */   private final WriteResultPublisher resultPublisher;
/*     */   
/*     */   private final String logPrefix;
/*     */ 
/*     */   
/*     */   public AbstractListenerWriteFlushProcessor() {
/*  73 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractListenerWriteFlushProcessor(String logPrefix) {
/*  81 */     this.logPrefix = logPrefix;
/*  82 */     this.resultPublisher = new WriteResultPublisher(logPrefix + "[WFP] ", () -> {
/*     */           cancel();
/*     */           State oldState = this.state.getAndSet(State.COMPLETED);
/*     */           if (rsWriteFlushLogger.isTraceEnabled()) {
/*     */             rsWriteFlushLogger.trace(getLogPrefix() + getLogPrefix() + " -> " + String.valueOf(oldState));
/*     */           }
/*     */           AbstractListenerWriteProcessor<?> writeProcessor = this.currentWriteProcessor;
/*     */           if (writeProcessor != null) {
/*     */             writeProcessor.cancelAndSetCompleted();
/*     */           }
/*     */           this.currentWriteProcessor = null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLogPrefix() {
/* 105 */     return this.logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription subscription) {
/* 113 */     ((State)this.state.get()).onSubscribe(this, subscription);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(Publisher<? extends T> publisher) {
/* 118 */     if (rsWriteFlushLogger.isTraceEnabled()) {
/* 119 */       rsWriteFlushLogger.trace(getLogPrefix() + "onNext: \"write\" Publisher");
/*     */     }
/* 121 */     ((State)this.state.get()).onNext(this, publisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(Throwable ex) {
/* 130 */     State state = this.state.get();
/* 131 */     if (rsWriteFlushLogger.isTraceEnabled()) {
/* 132 */       rsWriteFlushLogger.trace(getLogPrefix() + "onError: " + getLogPrefix() + " [" + String.valueOf(ex) + "]");
/*     */     }
/* 134 */     state.onError(this, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 143 */     State state = this.state.get();
/* 144 */     if (rsWriteFlushLogger.isTraceEnabled()) {
/* 145 */       rsWriteFlushLogger.trace(getLogPrefix() + "onComplete [" + getLogPrefix() + "]");
/*     */     }
/* 147 */     state.onComplete(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void onFlushPossible() {
/* 156 */     ((State)this.state.get()).onFlushPossible(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cancel() {
/* 167 */     if (rsWriteFlushLogger.isTraceEnabled()) {
/* 168 */       rsWriteFlushLogger.trace(getLogPrefix() + "cancel [" + getLogPrefix() + "]");
/*     */     }
/* 170 */     if (this.subscription != null) {
/* 171 */       this.subscription.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void subscribe(Subscriber<? super Void> subscriber) {
/* 180 */     this.resultPublisher.subscribe(subscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flushingFailed(Throwable t) {
/* 217 */     cancel();
/* 218 */     onError(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean changeState(State oldState, State newState) {
/* 225 */     boolean result = this.state.compareAndSet(oldState, newState);
/* 226 */     if (result && rsWriteFlushLogger.isTraceEnabled()) {
/* 227 */       rsWriteFlushLogger.trace(getLogPrefix() + getLogPrefix() + " -> " + String.valueOf(oldState));
/*     */     }
/* 229 */     return result;
/*     */   }
/*     */   
/*     */   private void flushIfPossible() {
/* 233 */     boolean result = isWritePossible();
/* 234 */     if (rsWriteFlushLogger.isTraceEnabled()) {
/* 235 */       rsWriteFlushLogger.trace(getLogPrefix() + "isWritePossible[" + getLogPrefix() + "]");
/*     */     }
/* 237 */     if (result) {
/* 238 */       onFlushPossible();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Processor<? super T, Void> createWriteProcessor();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isWritePossible();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void flush() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isFlushPending();
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 261 */     UNSUBSCRIBED
/*     */     {
/*     */       public <T> void onSubscribe(AbstractListenerWriteFlushProcessor<T> processor, Subscription subscription) {
/* 264 */         Assert.notNull(subscription, "Subscription must not be null");
/* 265 */         if (processor.changeState(this, REQUESTED)) {
/* 266 */           processor.subscription = subscription;
/* 267 */           subscription.request(1L);
/*     */         } else {
/*     */           
/* 270 */           super.onSubscribe(processor, subscription);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 277 */         if (processor.changeState(this, COMPLETED)) {
/* 278 */           processor.resultPublisher.publishComplete();
/*     */         } else {
/*     */           
/* 281 */           ((State)processor.state.get()).onComplete(processor);
/*     */         }
/*     */       
/*     */       }
/*     */     },
/* 286 */     REQUESTED
/*     */     {
/*     */       
/*     */       public <T> void onNext(AbstractListenerWriteFlushProcessor<T> processor, Publisher<? extends T> currentPublisher)
/*     */       {
/* 291 */         if (processor.changeState(this, RECEIVED)) {
/* 292 */           Processor<? super T, Void> writeProcessor = processor.createWriteProcessor();
/* 293 */           processor.currentWriteProcessor = (AbstractListenerWriteProcessor)writeProcessor;
/* 294 */           currentPublisher.subscribe((Subscriber)writeProcessor);
/* 295 */           writeProcessor.subscribe(new WriteResultSubscriber(processor));
/*     */         } 
/*     */       }
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 300 */         if (processor.changeState(this, COMPLETED)) {
/* 301 */           processor.resultPublisher.publishComplete();
/*     */         } else {
/*     */           
/* 304 */           ((State)processor.state.get()).onComplete(processor);
/*     */         }
/*     */       
/*     */       }
/*     */     },
/* 309 */     RECEIVED
/*     */     {
/*     */       public <T> void writeComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/*     */         try {
/* 313 */           processor.flush();
/*     */         }
/* 315 */         catch (Throwable ex) {
/* 316 */           processor.flushingFailed(ex);
/*     */           return;
/*     */         } 
/* 319 */         if (processor.changeState(this, REQUESTED)) {
/* 320 */           if (processor.sourceCompleted) {
/* 321 */             handleSourceCompleted(processor);
/*     */           } else {
/*     */             
/* 324 */             Assert.state((processor.subscription != null), "No subscription");
/* 325 */             processor.subscription.request(1L);
/*     */           } 
/*     */         }
/*     */       }
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 331 */         processor.sourceCompleted = true;
/*     */         
/* 333 */         if (processor.state.get() == State.REQUESTED) {
/* 334 */           handleSourceCompleted(processor);
/*     */         }
/*     */       }
/*     */       
/*     */       private <T> void handleSourceCompleted(AbstractListenerWriteFlushProcessor<T> processor) {
/* 339 */         if (processor.isFlushPending()) {
/*     */           
/* 341 */           processor.changeState(State.REQUESTED, State.FLUSHING);
/* 342 */           processor.flushIfPossible();
/*     */         }
/* 344 */         else if (processor.changeState(State.REQUESTED, State.COMPLETED)) {
/* 345 */           processor.resultPublisher.publishComplete();
/*     */         } else {
/*     */           
/* 348 */           ((State)processor.state.get()).onComplete(processor);
/*     */         }
/*     */       
/*     */       }
/*     */     },
/* 353 */     FLUSHING
/*     */     {
/*     */       public <T> void onFlushPossible(AbstractListenerWriteFlushProcessor<T> processor) {
/*     */         try {
/* 357 */           processor.flush();
/*     */         }
/* 359 */         catch (Throwable ex) {
/* 360 */           processor.flushingFailed(ex);
/*     */           return;
/*     */         } 
/* 363 */         if (processor.changeState(this, COMPLETED)) {
/* 364 */           processor.resultPublisher.publishComplete();
/*     */         } else {
/*     */           
/* 367 */           ((State)processor.state.get()).onComplete(processor);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */     },
/* 380 */     COMPLETED
/*     */     {
/*     */       public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable t) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */     };
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onSubscribe(AbstractListenerWriteFlushProcessor<T> proc, Subscription subscription) {
/* 397 */       subscription.cancel();
/*     */     }
/*     */     
/*     */     public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {
/* 401 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable ex) {
/* 405 */       if (processor.changeState(this, COMPLETED)) {
/* 406 */         processor.resultPublisher.publishError(ex);
/*     */       } else {
/*     */         
/* 409 */         ((State)processor.state.get()).onError(processor, ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 414 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     public <T> void writeComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 418 */       throw new IllegalStateException(toString());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onFlushPossible(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */ 
/*     */ 
/*     */     
/*     */     private static class WriteResultSubscriber
/*     */       implements Subscriber<Void>
/*     */     {
/*     */       private final AbstractListenerWriteFlushProcessor<?> processor;
/*     */ 
/*     */ 
/*     */       
/*     */       public WriteResultSubscriber(AbstractListenerWriteFlushProcessor<?> processor) {
/* 436 */         this.processor = processor;
/*     */       }
/*     */ 
/*     */       
/*     */       public void onSubscribe(Subscription subscription) {
/* 441 */         subscription.request(Long.MAX_VALUE);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void onNext(Void aVoid) {}
/*     */ 
/*     */       
/*     */       public void onError(Throwable ex) {
/* 450 */         if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled()) {
/* 451 */           AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor
/* 452 */               .getLogPrefix() + "current \"write\" Publisher failed: " + this.processor.getLogPrefix());
/*     */         }
/* 454 */         this.processor.currentWriteProcessor = null;
/* 455 */         this.processor.cancel();
/* 456 */         this.processor.onError(ex);
/*     */       }
/*     */ 
/*     */       
/*     */       public void onComplete() {
/* 461 */         if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled()) {
/* 462 */           AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor
/* 463 */               .getLogPrefix() + "current \"write\" Publisher completed");
/*     */         }
/* 465 */         this.processor.currentWriteProcessor = null;
/* 466 */         ((AbstractListenerWriteFlushProcessor.State)this.processor.state.get()).writeComplete(this.processor);
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 471 */         return this.processor.getClass().getSimpleName() + "-WriteResultSubscriber"; } } } enum null { public <T> void onSubscribe(AbstractListenerWriteFlushProcessor<T> processor, Subscription subscription) { Assert.notNull(subscription, "Subscription must not be null"); if (processor.changeState(this, REQUESTED)) { processor.subscription = subscription; subscription.request(1L); } else { super.onSubscribe(processor, subscription); }  } public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) { if (processor.changeState(this, COMPLETED)) { processor.resultPublisher.publishComplete(); } else { ((AbstractListenerWriteFlushProcessor.State)processor.state.get()).onComplete(processor); }  } } enum null { public <T> void onNext(AbstractListenerWriteFlushProcessor<T> processor, Publisher<? extends T> currentPublisher) { if (processor.changeState(this, RECEIVED)) { Processor<? super T, Void> writeProcessor = processor.createWriteProcessor(); processor.currentWriteProcessor = (AbstractListenerWriteProcessor)writeProcessor; currentPublisher.subscribe((Subscriber)writeProcessor); writeProcessor.subscribe(new AbstractListenerWriteFlushProcessor.State.WriteResultSubscriber(processor)); }  } public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) { if (processor.changeState(this, COMPLETED)) { processor.resultPublisher.publishComplete(); } else { ((AbstractListenerWriteFlushProcessor.State)processor.state.get()).onComplete(processor); }  } } enum null { public <T> void writeComplete(AbstractListenerWriteFlushProcessor<T> processor) { try { processor.flush(); } catch (Throwable ex) { processor.flushingFailed(ex); return; }  if (processor.changeState(this, REQUESTED)) if (processor.sourceCompleted) { handleSourceCompleted(processor); } else { Assert.state((processor.subscription != null), "No subscription"); processor.subscription.request(1L); }   } public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) { processor.sourceCompleted = true; if (processor.state.get() == AbstractListenerWriteFlushProcessor.State.REQUESTED) handleSourceCompleted(processor);  } private <T> void handleSourceCompleted(AbstractListenerWriteFlushProcessor<T> processor) { if (processor.isFlushPending()) { processor.changeState(AbstractListenerWriteFlushProcessor.State.REQUESTED, AbstractListenerWriteFlushProcessor.State.FLUSHING); processor.flushIfPossible(); } else if (processor.changeState(AbstractListenerWriteFlushProcessor.State.REQUESTED, AbstractListenerWriteFlushProcessor.State.COMPLETED)) { processor.resultPublisher.publishComplete(); } else { ((AbstractListenerWriteFlushProcessor.State)processor.state.get()).onComplete(processor); }  } } enum null { public <T> void onFlushPossible(AbstractListenerWriteFlushProcessor<T> processor) { try { processor.flush(); } catch (Throwable ex) { processor.flushingFailed(ex); return; }  if (processor.changeState(this, COMPLETED)) { processor.resultPublisher.publishComplete(); } else { ((AbstractListenerWriteFlushProcessor.State)processor.state.get()).onComplete(processor); }  } public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {} public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {} } enum null { public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {} public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable t) {} public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {} } private static class WriteResultSubscriber implements Subscriber<Void> { public String toString() { return this.processor.getClass().getSimpleName() + "-WriteResultSubscriber"; }
/*     */ 
/*     */     
/*     */     private final AbstractListenerWriteFlushProcessor<?> processor;
/*     */     
/*     */     public WriteResultSubscriber(AbstractListenerWriteFlushProcessor<?> processor) {
/*     */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/*     */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */     
/*     */     public void onNext(Void aVoid) {}
/*     */     
/*     */     public void onError(Throwable ex) {
/*     */       if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled())
/*     */         AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor.getLogPrefix() + "current \"write\" Publisher failed: " + this.processor.getLogPrefix()); 
/*     */       this.processor.currentWriteProcessor = null;
/*     */       this.processor.cancel();
/*     */       this.processor.onError(ex);
/*     */     }
/*     */     
/*     */     public void onComplete() {
/*     */       if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled())
/*     */         AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor.getLogPrefix() + "current \"write\" Publisher completed"); 
/*     */       this.processor.currentWriteProcessor = null;
/*     */       ((AbstractListenerWriteFlushProcessor.State)this.processor.state.get()).writeComplete(this.processor);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteFlushProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */