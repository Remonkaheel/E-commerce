/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Operators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum State
/*     */ {
/* 161 */   UNSUBSCRIBED
/*     */   {
/*     */     void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/* 164 */       Assert.notNull(subscriber, "Subscriber must not be null");
/* 165 */       if (publisher.changeState(this, SUBSCRIBING)) {
/* 166 */         Subscription subscription = new WriteResultPublisher.WriteResultSubscription(publisher);
/* 167 */         publisher.subscriber = subscriber;
/* 168 */         subscriber.onSubscribe(subscription);
/* 169 */         publisher.changeState(SUBSCRIBING, SUBSCRIBED);
/*     */         
/* 171 */         if (publisher.completedBeforeSubscribed) {
/* 172 */           ((State)publisher.state.get()).publishComplete(publisher);
/*     */         }
/* 174 */         Throwable ex = publisher.errorBeforeSubscribed;
/* 175 */         if (ex != null) {
/* 176 */           ((State)publisher.state.get()).publishError(publisher, ex);
/*     */         }
/*     */       } else {
/*     */         
/* 180 */         throw new IllegalStateException(toString());
/*     */       } 
/*     */     }
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {
/* 185 */       publisher.completedBeforeSubscribed = true;
/* 186 */       if (State.SUBSCRIBED == publisher.state.get()) {
/* 187 */         ((State)publisher.state.get()).publishComplete(publisher);
/*     */       }
/*     */     }
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable ex) {
/* 192 */       publisher.errorBeforeSubscribed = ex;
/* 193 */       if (State.SUBSCRIBED == publisher.state.get()) {
/* 194 */         ((State)publisher.state.get()).publishError(publisher, ex);
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 199 */   SUBSCRIBING
/*     */   {
/*     */     void request(WriteResultPublisher publisher, long n) {
/* 202 */       Operators.validate(n);
/*     */     }
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {
/* 206 */       publisher.completedBeforeSubscribed = true;
/* 207 */       if (State.SUBSCRIBED == publisher.state.get()) {
/* 208 */         ((State)publisher.state.get()).publishComplete(publisher);
/*     */       }
/*     */     }
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable ex) {
/* 213 */       publisher.errorBeforeSubscribed = ex;
/* 214 */       if (State.SUBSCRIBED == publisher.state.get()) {
/* 215 */         ((State)publisher.state.get()).publishError(publisher, ex);
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 220 */   SUBSCRIBED
/*     */   {
/*     */     void request(WriteResultPublisher publisher, long n) {
/* 223 */       Operators.validate(n);
/*     */     }
/*     */   },
/*     */   
/* 227 */   COMPLETED
/*     */   {
/*     */     void request(WriteResultPublisher publisher, long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     void cancel(WriteResultPublisher publisher) {}
/*     */ 
/*     */ 
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {}
/*     */ 
/*     */ 
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable t) {}
/*     */   };
/*     */ 
/*     */ 
/*     */   
/*     */   void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/* 247 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   void request(WriteResultPublisher publisher, long n) {
/* 251 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   void cancel(WriteResultPublisher publisher) {
/* 255 */     if (publisher.changeState(this, COMPLETED)) {
/* 256 */       publisher.cancelTask.run();
/*     */     } else {
/*     */       
/* 259 */       ((State)publisher.state.get()).cancel(publisher);
/*     */     } 
/*     */   }
/*     */   
/*     */   void publishComplete(WriteResultPublisher publisher) {
/* 264 */     if (publisher.changeState(this, COMPLETED)) {
/* 265 */       Subscriber<? super Void> s = publisher.subscriber;
/* 266 */       Assert.state((s != null), "No subscriber");
/* 267 */       s.onComplete();
/*     */     } else {
/*     */       
/* 270 */       ((State)publisher.state.get()).publishComplete(publisher);
/*     */     } 
/*     */   }
/*     */   
/*     */   void publishError(WriteResultPublisher publisher, Throwable t) {
/* 275 */     if (publisher.changeState(this, COMPLETED)) {
/* 276 */       Subscriber<? super Void> s = publisher.subscriber;
/* 277 */       Assert.state((s != null), "No subscriber");
/* 278 */       s.onError(t);
/*     */     } else {
/*     */       
/* 281 */       ((State)publisher.state.get()).publishError(publisher, t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\WriteResultPublisher$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */