/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*  48 */   private static final Pattern QUERY_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */ 
/*     */   
/*     */   private final URI uri;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final String contextPath;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private RequestPath path;
/*     */ 
/*     */   
/*     */   private final HttpHeaders headers;
/*     */ 
/*     */   
/*     */   private final HttpMethod method;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MultiValueMap<String, String> queryParams;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private MultiValueMap<String, HttpCookie> cookies;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SslInfo sslInfo;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String id;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String logPrefix;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Supplier<Map<String, Object>> attributesSupplier;
/*     */ 
/*     */   
/*     */   public AbstractServerHttpRequest(HttpMethod method, URI uri, @Nullable String contextPath, MultiValueMap<String, String> headers) {
/*  93 */     Assert.notNull(method, "Method must not be null");
/*  94 */     Assert.notNull(uri, "Uri must not be null");
/*  95 */     Assert.notNull(headers, "Headers must not be null");
/*     */     
/*  97 */     this.method = method;
/*  98 */     this.uri = uri;
/*  99 */     this.contextPath = contextPath;
/* 100 */     this.headers = HttpHeaders.readOnlyHttpHeaders(headers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 106 */     if (this.id == null) {
/* 107 */       this.id = initId();
/* 108 */       if (this.id == null) {
/* 109 */         this.id = ObjectUtils.getIdentityHexString(this);
/*     */       }
/*     */     } 
/* 112 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String initId() {
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/* 127 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 132 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 137 */     if (this.attributesSupplier != null) {
/* 138 */       return this.attributesSupplier.get();
/*     */     }
/*     */     
/* 141 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestPath getPath() {
/* 147 */     if (this.path == null) {
/* 148 */       this.path = RequestPath.parse(this.uri, this.contextPath);
/*     */     }
/* 150 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 155 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> getQueryParams() {
/* 160 */     if (this.queryParams == null) {
/* 161 */       this.queryParams = CollectionUtils.unmodifiableMultiValueMap(initQueryParams());
/*     */     }
/* 163 */     return this.queryParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, String> initQueryParams() {
/* 174 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 175 */     String query = getURI().getRawQuery();
/* 176 */     if (query != null) {
/* 177 */       Matcher matcher = QUERY_PATTERN.matcher(query);
/* 178 */       while (matcher.find()) {
/* 179 */         String name = decodeQueryParam(matcher.group(1));
/* 180 */         String eq = matcher.group(2);
/* 181 */         String value = matcher.group(3);
/* 182 */         value = (value != null) ? decodeQueryParam(value) : (StringUtils.hasLength(eq) ? "" : null);
/* 183 */         linkedMultiValueMap.add(name, value);
/*     */       } 
/*     */     } 
/* 186 */     return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */   }
/*     */   
/*     */   private String decodeQueryParam(String value) {
/* 190 */     return URLDecoder.decode(value, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, HttpCookie> getCookies() {
/* 195 */     if (this.cookies == null) {
/* 196 */       this.cookies = CollectionUtils.unmodifiableMultiValueMap(initCookies());
/*     */     }
/* 198 */     return this.cookies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract MultiValueMap<String, HttpCookie> initCookies();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SslInfo getSslInfo() {
/* 215 */     if (this.sslInfo == null) {
/* 216 */       this.sslInfo = initSslInfo();
/*     */     }
/* 218 */     return this.sslInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract SslInfo initSslInfo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract <T> T getNativeRequest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getLogPrefix() {
/* 241 */     if (this.logPrefix == null) {
/* 242 */       this.logPrefix = "[" + initLogPrefix() + "] ";
/*     */     }
/* 244 */     return this.logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String initLogPrefix() {
/* 253 */     return getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributesSupplier(Supplier<Map<String, Object>> attributesSupplier) {
/* 262 */     this.attributesSupplier = attributesSupplier;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */