/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.connector.ByteBufferPool;
/*     */ import io.undertow.connector.PooledByteBuffer;
/*     */ import io.undertow.server.ExchangeCompletionListener;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import io.undertow.server.handlers.Cookie;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.xnio.channels.StreamSourceChannel;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndertowServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*  56 */   private static final AtomicLong logPrefixIndex = new AtomicLong();
/*     */ 
/*     */   
/*     */   private final HttpServerExchange exchange;
/*     */ 
/*     */   
/*     */   private final RequestBodyPublisher body;
/*     */ 
/*     */ 
/*     */   
/*     */   public UndertowServerHttpRequest(HttpServerExchange exchange, DataBufferFactory bufferFactory) throws URISyntaxException {
/*  67 */     super(HttpMethod.valueOf(exchange.getRequestMethod().toString()), initUri(exchange), "", new UndertowHeadersAdapter(exchange
/*  68 */           .getRequestHeaders()));
/*  69 */     this.exchange = exchange;
/*  70 */     this.body = new RequestBodyPublisher(exchange, bufferFactory);
/*  71 */     this.body.registerListeners(exchange);
/*     */   }
/*     */   
/*     */   private static URI initUri(HttpServerExchange exchange) throws URISyntaxException {
/*  75 */     Assert.notNull(exchange, "HttpServerExchange is required");
/*  76 */     String requestURL = exchange.getRequestURL();
/*  77 */     String query = exchange.getQueryString();
/*  78 */     String requestUriAndQuery = StringUtils.hasLength(query) ? (requestURL + "?" + requestURL) : requestURL;
/*  79 */     return new URI(requestUriAndQuery);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/*  84 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  85 */     for (Cookie cookie : this.exchange.requestCookies()) {
/*  86 */       HttpCookie httpCookie = new HttpCookie(cookie.getName(), cookie.getValue());
/*  87 */       linkedMultiValueMap.add(cookie.getName(), httpCookie);
/*     */     } 
/*  89 */     return (MultiValueMap<String, HttpCookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/*  95 */     return this.exchange.getDestinationAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 101 */     return this.exchange.getSourceAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected SslInfo initSslInfo() {
/* 107 */     SSLSession session = this.exchange.getConnection().getSslSession();
/* 108 */     if (session != null) {
/* 109 */       return new DefaultSslInfo(session);
/*     */     }
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 116 */     return Flux.from(this.body);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 122 */     return (T)this.exchange;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String initId() {
/* 127 */     return ObjectUtils.getIdentityHexString(this.exchange.getConnection()) + "-" + ObjectUtils.getIdentityHexString(this.exchange.getConnection());
/*     */   }
/*     */ 
/*     */   
/*     */   private class RequestBodyPublisher
/*     */     extends AbstractListenerReadPublisher<DataBuffer>
/*     */   {
/*     */     private final StreamSourceChannel channel;
/*     */     
/*     */     private final DataBufferFactory bufferFactory;
/*     */     
/*     */     private final ByteBufferPool byteBufferPool;
/*     */     
/*     */     public RequestBodyPublisher(HttpServerExchange exchange, DataBufferFactory bufferFactory) {
/* 141 */       super(UndertowServerHttpRequest.this.getLogPrefix());
/* 142 */       this.channel = exchange.getRequestChannel();
/* 143 */       this.bufferFactory = bufferFactory;
/* 144 */       this.byteBufferPool = exchange.getConnection().getByteBufferPool();
/*     */     }
/*     */     
/*     */     private void registerListeners(HttpServerExchange exchange) {
/* 148 */       exchange.addExchangeCompleteListener((ex, next) -> {
/*     */             onAllDataRead();
/*     */             next.proceed();
/*     */           });
/* 152 */       this.channel.getReadSetter().set(c -> onDataAvailable());
/* 153 */       this.channel.getCloseSetter().set(c -> onAllDataRead());
/* 154 */       this.channel.resumeReads();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void checkOnDataAvailable() {
/* 159 */       this.channel.resumeReads();
/*     */       
/* 161 */       onDataAvailable();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void readingPaused() {
/* 166 */       this.channel.suspendReads();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected DataBuffer read() throws IOException {
/* 172 */       PooledByteBuffer pooledByteBuffer = this.byteBufferPool.allocate();
/* 173 */       PooledByteBuffer pooledByteBuffer1 = pooledByteBuffer; try {
/* 174 */         ByteBuffer byteBuffer = pooledByteBuffer.getBuffer();
/* 175 */         int read = this.channel.read(byteBuffer);
/*     */         
/* 177 */         if (rsReadLogger.isTraceEnabled()) {
/* 178 */           rsReadLogger.trace(getLogPrefix() + "Read " + getLogPrefix() + read);
/*     */         }
/*     */         
/* 181 */         if (read > 0)
/* 182 */         { byteBuffer.flip();
/* 183 */           DataBuffer dataBuffer1 = this.bufferFactory.allocateBuffer(read);
/* 184 */           dataBuffer1.write(new ByteBuffer[] { byteBuffer });
/* 185 */           DataBuffer dataBuffer2 = dataBuffer1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 191 */           if (pooledByteBuffer1 != null) pooledByteBuffer1.close();  return dataBuffer2; }  if (read == -1) onAllDataRead();  DataBuffer dataBuffer = null; if (pooledByteBuffer1 != null) pooledByteBuffer1.close(); 
/*     */         return dataBuffer;
/*     */       } catch (Throwable throwable) {
/*     */         if (pooledByteBuffer1 != null)
/*     */           try {
/*     */             pooledByteBuffer1.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           }  
/*     */         throw throwable;
/*     */       } 
/*     */     }
/*     */     
/*     */     protected void discardData() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */