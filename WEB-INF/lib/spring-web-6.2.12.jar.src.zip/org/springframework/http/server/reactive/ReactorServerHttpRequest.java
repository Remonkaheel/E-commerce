/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.NettyDataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.support.Netty4HeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.netty.ChannelOperationsId;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.server.HttpServerRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*  54 */   private static final Log logger = HttpLogging.forLogName(ReactorServerHttpRequest.class);
/*     */ 
/*     */   
/*  57 */   private static final AtomicLong logPrefixIndex = new AtomicLong();
/*     */ 
/*     */   
/*     */   private final HttpServerRequest request;
/*     */ 
/*     */   
/*     */   private final NettyDataBufferFactory bufferFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorServerHttpRequest(HttpServerRequest request, NettyDataBufferFactory bufferFactory) throws URISyntaxException {
/*  68 */     super(HttpMethod.valueOf(request.method().name()), 
/*  69 */         ReactorUriHelper.createUri(request), request.forwardedPrefix(), (MultiValueMap<String, String>)new Netty4HeadersAdapter(request
/*  70 */           .requestHeaders()));
/*  71 */     Assert.notNull(bufferFactory, "DataBufferFactory must not be null");
/*  72 */     this.request = request;
/*  73 */     this.bufferFactory = bufferFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/*  78 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  79 */     for (CharSequence name : this.request.allCookies().keySet()) {
/*  80 */       for (Cookie cookie : this.request.allCookies().get(name)) {
/*  81 */         HttpCookie httpCookie = new HttpCookie(name.toString(), cookie.value());
/*  82 */         linkedMultiValueMap.add(name.toString(), httpCookie);
/*     */       } 
/*     */     } 
/*  85 */     return (MultiValueMap<String, HttpCookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/*  91 */     return this.request.hostAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/*  97 */     return this.request.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected SslInfo initSslInfo() {
/* 103 */     Channel channel = ((Connection)this.request).channel();
/* 104 */     SslHandler sslHandler = (SslHandler)channel.pipeline().get(SslHandler.class);
/* 105 */     if (sslHandler == null && channel.parent() != null) {
/* 106 */       sslHandler = (SslHandler)channel.parent().pipeline().get(SslHandler.class);
/*     */     }
/* 108 */     if (sslHandler != null) {
/* 109 */       SSLSession session = sslHandler.engine().getSession();
/* 110 */       return new DefaultSslInfo(session);
/*     */     } 
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 117 */     Objects.requireNonNull(this.bufferFactory); return this.request.receive().retain().map(this.bufferFactory::wrap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 123 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String initId() {
/* 129 */     HttpServerRequest httpServerRequest = this.request; if (httpServerRequest instanceof Connection) { Connection connection = (Connection)httpServerRequest;
/* 130 */       return connection.channel().id().asShortText() + "-" + connection.channel().id().asShortText(); }
/*     */ 
/*     */     
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String initLogPrefix() {
/* 138 */     String id = null;
/* 139 */     HttpServerRequest httpServerRequest = this.request; if (httpServerRequest instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpServerRequest;
/* 140 */       id = logger.isDebugEnabled() ? operationsId.asLongText() : operationsId.asShortText(); }
/*     */     
/* 142 */     if (id != null) {
/* 143 */       return id;
/*     */     }
/* 145 */     httpServerRequest = this.request; if (httpServerRequest instanceof Connection) { Connection connection = (Connection)httpServerRequest;
/* 146 */       return connection.channel().id().asShortText() + "-" + connection.channel().id().asShortText(); }
/*     */ 
/*     */     
/* 149 */     return getId();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */