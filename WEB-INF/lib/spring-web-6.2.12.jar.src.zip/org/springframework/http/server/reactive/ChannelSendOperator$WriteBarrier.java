/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WriteBarrier
/*     */   implements CoreSubscriber<T>, Subscription, Publisher<T>
/*     */ {
/*     */   private final ChannelSendOperator<T>.WriteCompletionBarrier writeCompletionBarrier;
/*     */   @Nullable
/*     */   private Subscription subscription;
/*     */   @Nullable
/*     */   private T item;
/*     */   @Nullable
/*     */   private Throwable error;
/*     */   private boolean completed = false;
/*     */   private long demandBeforeReadyToWrite;
/* 147 */   private ChannelSendOperator.State state = ChannelSendOperator.State.NEW;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Subscriber<? super T> writeSubscriber;
/*     */ 
/*     */   
/*     */   WriteBarrier(CoreSubscriber<? super Void> completionSubscriber) {
/* 155 */     this.writeCompletionBarrier = new ChannelSendOperator.WriteCompletionBarrier(paramChannelSendOperator, completionSubscriber, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 163 */     if (Operators.validate(this.subscription, s)) {
/* 164 */       this.subscription = s;
/* 165 */       this.writeCompletionBarrier.connect();
/* 166 */       s.request(1L);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(T item) {
/* 172 */     if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 173 */       requiredWriteSubscriber().onNext(item);
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     synchronized (this) {
/* 178 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 179 */         requiredWriteSubscriber().onNext(item);
/*     */       }
/* 181 */       else if (this.state == ChannelSendOperator.State.NEW) {
/* 182 */         Publisher<Void> result; this.item = item;
/* 183 */         this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/*     */         
/*     */         try {
/* 186 */           result = ChannelSendOperator.this.writeFunction.apply(this);
/*     */         }
/* 188 */         catch (Throwable ex) {
/* 189 */           this.writeCompletionBarrier.onError(ex);
/*     */           return;
/*     */         } 
/* 192 */         result.subscribe((Subscriber)this.writeCompletionBarrier);
/*     */       } else {
/*     */         
/* 195 */         if (this.subscription != null) {
/* 196 */           this.subscription.cancel();
/*     */         }
/* 198 */         this.writeCompletionBarrier.onError(new IllegalStateException("Unexpected item."));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Subscriber<? super T> requiredWriteSubscriber() {
/* 204 */     Assert.state((this.writeSubscriber != null), "No write subscriber");
/* 205 */     return this.writeSubscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable ex) {
/* 210 */     if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 211 */       requiredWriteSubscriber().onError(ex);
/*     */       return;
/*     */     } 
/* 214 */     synchronized (this) {
/* 215 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 216 */         requiredWriteSubscriber().onError(ex);
/*     */       }
/* 218 */       else if (this.state == ChannelSendOperator.State.NEW) {
/* 219 */         this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/* 220 */         this.writeCompletionBarrier.onError(ex);
/*     */       } else {
/*     */         
/* 223 */         this.error = ex;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 230 */     if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 231 */       requiredWriteSubscriber().onComplete();
/*     */       return;
/*     */     } 
/* 234 */     synchronized (this) {
/* 235 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 236 */         requiredWriteSubscriber().onComplete();
/*     */       }
/* 238 */       else if (this.state == ChannelSendOperator.State.NEW) {
/* 239 */         Publisher<Void> result; this.completed = true;
/* 240 */         this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/*     */         
/*     */         try {
/* 243 */           result = ChannelSendOperator.this.writeFunction.apply(this);
/*     */         }
/* 245 */         catch (Throwable ex) {
/* 246 */           this.writeCompletionBarrier.onError(ex);
/*     */           return;
/*     */         } 
/* 249 */         result.subscribe((Subscriber)this.writeCompletionBarrier);
/*     */       } else {
/*     */         
/* 252 */         this.completed = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 259 */     return this.writeCompletionBarrier.currentContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 267 */     Subscription s = this.subscription;
/* 268 */     if (s == null) {
/*     */       return;
/*     */     }
/* 271 */     if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 272 */       s.request(n);
/*     */       return;
/*     */     } 
/* 275 */     synchronized (this) {
/* 276 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 277 */         s.request(n);
/*     */         return;
/*     */       } 
/* 280 */       if (this.writeSubscriber != null) {
/* 281 */         if (this.state == ChannelSendOperator.State.EMITTING_CACHED_SIGNALS) {
/* 282 */           this.demandBeforeReadyToWrite = n;
/*     */           return;
/*     */         } 
/*     */         try {
/* 286 */           this.state = ChannelSendOperator.State.EMITTING_CACHED_SIGNALS;
/* 287 */           if (emitCachedSignals()) {
/*     */             return;
/*     */           }
/* 290 */           n = n + this.demandBeforeReadyToWrite - 1L;
/* 291 */           if (n == 0L) {
/*     */             return;
/*     */           }
/*     */         } finally {
/*     */           
/* 296 */           this.state = ChannelSendOperator.State.READY_TO_WRITE;
/*     */         } 
/*     */       } 
/*     */     } 
/* 300 */     s.request(n);
/*     */   }
/*     */   
/*     */   private boolean emitCachedSignals() {
/* 304 */     Throwable error = this.error;
/* 305 */     if (error != null) {
/*     */       try {
/* 307 */         requiredWriteSubscriber().onError(error);
/*     */       } finally {
/*     */         
/* 310 */         releaseCachedItem();
/*     */       } 
/* 312 */       return true;
/*     */     } 
/* 314 */     T item = this.item;
/* 315 */     this.item = null;
/* 316 */     if (item != null) {
/* 317 */       requiredWriteSubscriber().onNext(item);
/*     */     }
/* 319 */     if (this.completed) {
/* 320 */       requiredWriteSubscriber().onComplete();
/* 321 */       return true;
/*     */     } 
/* 323 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 328 */     Subscription s = this.subscription;
/* 329 */     if (s != null) {
/* 330 */       this.subscription = null;
/*     */       try {
/* 332 */         s.cancel();
/*     */       } finally {
/*     */         
/* 335 */         releaseCachedItem();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void releaseCachedItem() {
/* 341 */     synchronized (this) {
/* 342 */       Object item = this.item;
/* 343 */       if (item instanceof DataBuffer) { DataBuffer dataBuffer = (DataBuffer)item;
/* 344 */         DataBufferUtils.release(dataBuffer); }
/*     */       
/* 346 */       this.item = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(Subscriber<? super T> writeSubscriber) {
/* 355 */     synchronized (this) {
/* 356 */       Assert.state((this.writeSubscriber == null), "Only one write subscriber supported");
/* 357 */       this.writeSubscriber = writeSubscriber;
/* 358 */       if (this.error != null || this.completed) {
/* 359 */         this.writeSubscriber.onSubscribe(Operators.emptySubscription());
/* 360 */         emitCachedSignals();
/*     */       } else {
/*     */         
/* 363 */         this.writeSubscriber.onSubscribe(this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ChannelSendOperator$WriteBarrier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */