/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WriteResultSubscription
/*     */   implements Subscription
/*     */ {
/*     */   private final WriteResultPublisher publisher;
/*     */   
/*     */   public WriteResultSubscription(WriteResultPublisher publisher) {
/* 117 */     this.publisher = publisher;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void request(long n) {
/* 122 */     if (WriteResultPublisher.rsWriteResultLogger.isTraceEnabled()) {
/* 123 */       WriteResultPublisher.rsWriteResultLogger.trace(this.publisher.logPrefix + "request " + this.publisher.logPrefix);
/*     */     }
/*     */     
/* 126 */     getState().request(this.publisher, n);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void cancel() {
/* 131 */     WriteResultPublisher.State state = getState();
/* 132 */     if (WriteResultPublisher.rsWriteResultLogger.isTraceEnabled()) {
/* 133 */       WriteResultPublisher.rsWriteResultLogger.trace(this.publisher.logPrefix + "cancel [" + this.publisher.logPrefix + "]");
/*     */     }
/* 135 */     state.cancel(this.publisher);
/*     */   }
/*     */   
/*     */   private WriteResultPublisher.State getState() {
/* 139 */     return this.publisher.state.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\WriteResultPublisher$WriteResultSubscription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */