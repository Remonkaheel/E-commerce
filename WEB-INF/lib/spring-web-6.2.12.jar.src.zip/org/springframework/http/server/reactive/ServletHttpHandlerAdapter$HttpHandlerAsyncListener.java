/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncEvent;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpHandlerAsyncListener
/*     */   implements AsyncListener
/*     */ {
/*     */   private final AsyncListener requestAsyncListener;
/*     */   private final AsyncListener responseAsyncListener;
/*     */   private final Runnable handlerDisposeTask;
/*     */   private final AtomicBoolean completionFlag;
/*     */   private final String logPrefix;
/*     */   
/*     */   public HttpHandlerAsyncListener(AsyncListener requestAsyncListener, AsyncListener responseAsyncListener, Runnable handlerDisposeTask, AtomicBoolean completionFlag, String logPrefix) {
/* 271 */     this.requestAsyncListener = requestAsyncListener;
/* 272 */     this.responseAsyncListener = responseAsyncListener;
/* 273 */     this.handlerDisposeTask = handlerDisposeTask;
/* 274 */     this.completionFlag = completionFlag;
/* 275 */     this.logPrefix = logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onStartAsync(AsyncEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onTimeout(AsyncEvent event) {
/* 286 */     if (ServletHttpHandlerAdapter.logger.isDebugEnabled()) {
/* 287 */       ServletHttpHandlerAdapter.logger.debug(this.logPrefix + "AsyncEvent onTimeout");
/*     */     }
/* 289 */     delegateTimeout(this.requestAsyncListener, event);
/* 290 */     delegateTimeout(this.responseAsyncListener, event);
/* 291 */     handleTimeoutOrError(event);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(AsyncEvent event) {
/* 296 */     Throwable ex = event.getThrowable();
/* 297 */     if (ServletHttpHandlerAdapter.logger.isDebugEnabled()) {
/* 298 */       ServletHttpHandlerAdapter.logger.debug(this.logPrefix + "AsyncEvent onError: " + this.logPrefix);
/*     */     }
/* 300 */     delegateError(this.requestAsyncListener, event);
/* 301 */     delegateError(this.responseAsyncListener, event);
/* 302 */     handleTimeoutOrError(event);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete(AsyncEvent event) {
/* 307 */     delegateComplete(this.requestAsyncListener, event);
/* 308 */     delegateComplete(this.responseAsyncListener, event);
/*     */   }
/*     */   
/*     */   private static void delegateTimeout(AsyncListener listener, AsyncEvent event) {
/*     */     try {
/* 313 */       listener.onTimeout(event);
/*     */     }
/* 315 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void delegateError(AsyncListener listener, AsyncEvent event) {
/*     */     try {
/* 322 */       listener.onError(event);
/*     */     }
/* 324 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void delegateComplete(AsyncListener listener, AsyncEvent event) {
/*     */     try {
/* 331 */       listener.onComplete(event);
/*     */     }
/* 333 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleTimeoutOrError(AsyncEvent event) {
/* 339 */     AsyncContext context = event.getAsyncContext();
/* 340 */     ServletHttpHandlerAdapter.runIfAsyncNotComplete(context, this.completionFlag, () -> {
/*     */           try {
/*     */             this.handlerDisposeTask.run();
/*     */           } finally {
/*     */             context.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServletHttpHandlerAdapter$HttpHandlerAsyncListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */