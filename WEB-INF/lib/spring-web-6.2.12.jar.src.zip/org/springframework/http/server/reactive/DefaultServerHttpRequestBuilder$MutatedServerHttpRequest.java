/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MutatedServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*     */   @Nullable
/*     */   private final SslInfo sslInfo;
/*     */   @Nullable
/*     */   private final InetSocketAddress remoteAddress;
/*     */   private final Flux<DataBuffer> body;
/*     */   private final ServerHttpRequest originalRequest;
/*     */   
/*     */   public MutatedServerHttpRequest(URI uri, @Nullable String contextPath, HttpMethod method, @Nullable SslInfo sslInfo, @Nullable InetSocketAddress remoteAddress, HttpHeaders headers, Flux<DataBuffer> body, ServerHttpRequest originalRequest) {
/* 199 */     super(method, uri, contextPath, (MultiValueMap<String, String>)headers);
/* 200 */     this.remoteAddress = (remoteAddress != null) ? remoteAddress : originalRequest.getRemoteAddress();
/* 201 */     this.sslInfo = (sslInfo != null) ? sslInfo : originalRequest.getSslInfo();
/* 202 */     this.body = body;
/* 203 */     this.originalRequest = originalRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/* 208 */     return this.originalRequest.getCookies();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/* 214 */     return this.originalRequest.getLocalAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 220 */     return this.remoteAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected SslInfo initSslInfo() {
/* 226 */     return this.sslInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 231 */     return this.body;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 236 */     return ServerHttpRequestDecorator.getNativeRequest(this.originalRequest);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 241 */     return this.originalRequest.getId();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\DefaultServerHttpRequestBuilder$MutatedServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */