/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.netty5.channel.Channel;
/*     */ import io.netty5.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty5.handler.codec.http.headers.HttpCookiePair;
/*     */ import io.netty5.handler.ssl.SslHandler;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.support.Netty5HeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.netty5.ChannelOperationsId;
/*     */ import reactor.netty5.Connection;
/*     */ import reactor.netty5.http.server.HttpServerRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorNetty2ServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*  58 */   private static final Log logger = HttpLogging.forLogName(ReactorNetty2ServerHttpRequest.class);
/*     */ 
/*     */   
/*  61 */   private static final AtomicLong logPrefixIndex = new AtomicLong();
/*     */ 
/*     */   
/*     */   private final HttpServerRequest request;
/*     */ 
/*     */   
/*     */   private final Netty5DataBufferFactory bufferFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNetty2ServerHttpRequest(HttpServerRequest request, Netty5DataBufferFactory bufferFactory) throws URISyntaxException {
/*  72 */     super(HttpMethod.valueOf(request.method().name()), initUri(request), "", (MultiValueMap<String, String>)new Netty5HeadersAdapter(request
/*  73 */           .requestHeaders()));
/*  74 */     Assert.notNull(bufferFactory, "DataBufferFactory must not be null");
/*  75 */     this.request = request;
/*  76 */     this.bufferFactory = bufferFactory;
/*     */   }
/*     */   
/*     */   private static URI initUri(HttpServerRequest request) throws URISyntaxException {
/*  80 */     Assert.notNull(request, "HttpServerRequest must not be null");
/*  81 */     return new URI(String.valueOf(resolveBaseUrl(request)) + String.valueOf(resolveBaseUrl(request)));
/*     */   }
/*     */   
/*     */   private static URI resolveBaseUrl(HttpServerRequest request) throws URISyntaxException {
/*  85 */     String scheme = getScheme(request);
/*     */     
/*  87 */     InetSocketAddress hostAddress = request.hostAddress();
/*  88 */     if (hostAddress != null) {
/*  89 */       return new URI(scheme, null, hostAddress.getHostString(), hostAddress.getPort(), null, null, null);
/*     */     }
/*     */     
/*  92 */     CharSequence charSequence = request.requestHeaders().get((CharSequence)HttpHeaderNames.HOST);
/*  93 */     if (charSequence != null) {
/*  94 */       int portIndex; String header = charSequence.toString();
/*     */       
/*  96 */       if (header.startsWith("[")) {
/*  97 */         portIndex = header.indexOf(':', header.indexOf(']'));
/*     */       } else {
/*     */         
/* 100 */         portIndex = header.indexOf(':');
/*     */       } 
/* 102 */       if (portIndex != -1) {
/*     */         try {
/* 104 */           return new URI(scheme, null, header.substring(0, portIndex), 
/* 105 */               Integer.parseInt(header, portIndex + 1, header.length(), 10), null, null, null);
/*     */         }
/* 107 */         catch (NumberFormatException ex) {
/* 108 */           throw new URISyntaxException(header, "Unable to parse port", portIndex);
/*     */         } 
/*     */       }
/*     */       
/* 112 */       return new URI(scheme, header, null, null);
/*     */     } 
/*     */ 
/*     */     
/* 116 */     throw new IllegalStateException("Neither local hostAddress nor HOST header available");
/*     */   }
/*     */   
/*     */   private static String getScheme(HttpServerRequest request) {
/* 120 */     return request.scheme();
/*     */   }
/*     */   
/*     */   private static String resolveRequestUri(HttpServerRequest request) {
/* 124 */     String uri = request.uri();
/* 125 */     for (int i = 0; i < uri.length(); i++) {
/* 126 */       char c = uri.charAt(i);
/* 127 */       if (c == '/' || c == '?' || c == '#') {
/*     */         break;
/*     */       }
/* 130 */       if (c == ':' && i + 2 < uri.length() && 
/* 131 */         uri.charAt(i + 1) == '/' && uri.charAt(i + 2) == '/') {
/* 132 */         for (int j = i + 3; j < uri.length(); j++) {
/* 133 */           c = uri.charAt(j);
/* 134 */           if (c == '/' || c == '?' || c == '#') {
/* 135 */             return uri.substring(j);
/*     */           }
/*     */         } 
/* 138 */         return "";
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     return uri;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/* 147 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 148 */     for (CharSequence name : this.request.allCookies().keySet()) {
/* 149 */       for (HttpCookiePair cookie : this.request.allCookies().get(name)) {
/* 150 */         CharSequence cookieValue = cookie.value();
/* 151 */         HttpCookie httpCookie = new HttpCookie(name.toString(), (cookieValue != null) ? cookieValue.toString() : null);
/* 152 */         linkedMultiValueMap.add(name.toString(), httpCookie);
/*     */       } 
/*     */     } 
/* 155 */     return (MultiValueMap<String, HttpCookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/* 161 */     return this.request.hostAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 167 */     return this.request.remoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected SslInfo initSslInfo() {
/* 173 */     Channel channel = ((Connection)this.request).channel();
/* 174 */     SslHandler sslHandler = (SslHandler)channel.pipeline().get(SslHandler.class);
/* 175 */     if (sslHandler == null && channel.parent() != null) {
/* 176 */       sslHandler = (SslHandler)channel.parent().pipeline().get(SslHandler.class);
/*     */     }
/* 178 */     if (sslHandler != null) {
/* 179 */       SSLSession session = sslHandler.engine().getSession();
/* 180 */       return new DefaultSslInfo(session);
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 187 */     Objects.requireNonNull(this.bufferFactory); return this.request.receive().transferOwnership().map(this.bufferFactory::wrap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 193 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String initId() {
/* 199 */     HttpServerRequest httpServerRequest = this.request; if (httpServerRequest instanceof Connection) { Connection connection = (Connection)httpServerRequest;
/* 200 */       return connection.channel().id().asShortText() + "-" + connection.channel().id().asShortText(); }
/*     */ 
/*     */     
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String initLogPrefix() {
/* 208 */     String id = null;
/* 209 */     HttpServerRequest httpServerRequest = this.request; if (httpServerRequest instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpServerRequest;
/* 210 */       id = logger.isDebugEnabled() ? operationsId.asLongText() : operationsId.asShortText(); }
/*     */     
/* 212 */     if (id != null) {
/* 213 */       return id;
/*     */     }
/* 215 */     httpServerRequest = this.request; if (httpServerRequest instanceof Connection) { Connection connection = (Connection)httpServerRequest;
/* 216 */       return connection.channel().id().asShortText() + "-" + connection.channel().id().asShortText(); }
/*     */ 
/*     */     
/* 219 */     return getId();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorNetty2ServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */