/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.catalina.connector.CoyoteInputStream;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.RequestFacade;
/*     */ import org.apache.coyote.Request;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TomcatServerHttpRequest
/*     */   extends ServletServerHttpRequest
/*     */ {
/*     */   private static final Field COYOTE_REQUEST_FIELD;
/*     */   private final int bufferSize;
/*     */   private final DataBufferFactory factory;
/*     */   
/*     */   static {
/*  89 */     Field field = ReflectionUtils.findField(RequestFacade.class, "request");
/*  90 */     Assert.state((field != null), "Incompatible Tomcat implementation");
/*  91 */     ReflectionUtils.makeAccessible(field);
/*  92 */     COYOTE_REQUEST_FIELD = field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TomcatServerHttpRequest(HttpServletRequest request, AsyncContext context, String servletPath, DataBufferFactory factory, int bufferSize) throws IOException, URISyntaxException {
/*  99 */     super(createTomcatHttpHeaders(request), request, context, servletPath, factory, bufferSize);
/* 100 */     this.factory = factory;
/* 101 */     this.bufferSize = bufferSize;
/*     */   }
/*     */   
/*     */   private static MultiValueMap<String, String> createTomcatHttpHeaders(HttpServletRequest request) {
/* 105 */     RequestFacade requestFacade = getRequestFacade(request);
/*     */     
/* 107 */     Request connectorRequest = (Request)ReflectionUtils.getField(COYOTE_REQUEST_FIELD, requestFacade);
/* 108 */     Assert.state((connectorRequest != null), "No Tomcat connector request");
/* 109 */     Request tomcatRequest = connectorRequest.getCoyoteRequest();
/* 110 */     return new TomcatHeadersAdapter(tomcatRequest.getMimeHeaders());
/*     */   }
/*     */   
/*     */   private static RequestFacade getRequestFacade(HttpServletRequest request) {
/* 114 */     if (request instanceof RequestFacade) { RequestFacade facade = (RequestFacade)request;
/* 115 */       return facade; }
/*     */     
/* 117 */     if (request instanceof HttpServletRequestWrapper) { HttpServletRequestWrapper wrapper = (HttpServletRequestWrapper)request;
/* 118 */       HttpServletRequest wrappedRequest = (HttpServletRequest)wrapper.getRequest();
/* 119 */       return getRequestFacade(wrappedRequest); }
/*     */ 
/*     */     
/* 122 */     throw new IllegalArgumentException("Cannot convert [" + String.valueOf(request.getClass()) + "] to org.apache.catalina.connector.RequestFacade");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataBuffer readFromInputStream() throws IOException {
/* 129 */     ServletInputStream servletInputStream = getInputStream(); if (servletInputStream instanceof CoyoteInputStream) { CoyoteInputStream coyoteInputStream = (CoyoteInputStream)servletInputStream;
/* 130 */       DataBuffer dataBuffer = this.factory.allocateBuffer(this.bufferSize);
/* 131 */       int read = -1;
/*     */       try {
/* 133 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.writableByteBuffers(); 
/* 134 */         try { Assert.state(iterator.hasNext(), "No ByteBuffer available");
/* 135 */           ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 136 */           read = coyoteInputStream.read(byteBuffer);
/* 137 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 138 */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  logBytesRead(read);
/* 139 */         if (read > 0) {
/* 140 */           dataBuffer.writePosition(read);
/* 141 */           return dataBuffer;
/*     */         } 
/* 143 */         if (read == -1) {
/* 144 */           return EOF_BUFFER;
/*     */         }
/*     */         
/* 147 */         return AbstractListenerReadPublisher.EMPTY_BUFFER;
/*     */       }
/*     */       finally {
/*     */         
/* 151 */         if (read <= 0) {
/* 152 */           DataBufferUtils.release(dataBuffer);
/*     */         }
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 158 */     return super.readFromInputStream();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\TomcatHttpHandlerAdapter$TomcatServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */