/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelId;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.codec.http.cookie.CookieHeaderNames;
/*     */ import io.netty.handler.codec.http.cookie.DefaultCookie;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.NettyDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.support.Netty4HeadersAdapter;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.ChannelOperationsId;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.server.HttpServerResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorServerHttpResponse
/*     */   extends AbstractServerHttpResponse
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*  53 */   private static final Log logger = LogFactory.getLog(ReactorServerHttpResponse.class);
/*     */ 
/*     */   
/*     */   private final HttpServerResponse response;
/*     */ 
/*     */   
/*     */   public ReactorServerHttpResponse(HttpServerResponse response, DataBufferFactory bufferFactory) {
/*  60 */     super(bufferFactory, new HttpHeaders((MultiValueMap)new Netty4HeadersAdapter(((HttpServerResponse)Objects.<HttpServerResponse>requireNonNull(response, "HttpServerResponse must not be null"))
/*  61 */             .responseHeaders())));
/*  62 */     this.response = response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeResponse() {
/*  69 */     return (T)this.response;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  74 */     HttpStatusCode status = super.getStatusCode();
/*  75 */     return (status != null) ? status : HttpStatusCode.valueOf(this.response.status().code());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Integer getRawStatusCode() {
/*  82 */     Integer status = super.getRawStatusCode();
/*  83 */     return Integer.valueOf((status != null) ? status.intValue() : this.response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyStatusCode() {
/*  88 */     HttpStatusCode status = super.getStatusCode();
/*  89 */     if (status != null) {
/*  90 */       this.response.status(status.value());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeWithInternal(Publisher<? extends DataBuffer> publisher) {
/*  96 */     return this.response.send(toByteBufs(publisher)).then();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeAndFlushWithInternal(Publisher<? extends Publisher<? extends DataBuffer>> publisher) {
/* 101 */     return this.response.sendGroups((Publisher)Flux.from(publisher).map(this::toByteBufs)).then();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {}
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 110 */     for (String name : getCookies().keySet()) {
/* 111 */       for (ResponseCookie httpCookie : getCookies().get(name)) {
/* 112 */         DefaultCookie cookie = new DefaultCookie(name, httpCookie.getValue());
/* 113 */         if (!httpCookie.getMaxAge().isNegative()) {
/* 114 */           cookie.setMaxAge(httpCookie.getMaxAge().getSeconds());
/*     */         }
/* 116 */         if (httpCookie.getDomain() != null) {
/* 117 */           cookie.setDomain(httpCookie.getDomain());
/*     */         }
/* 119 */         if (httpCookie.getPath() != null) {
/* 120 */           cookie.setPath(httpCookie.getPath());
/*     */         }
/* 122 */         cookie.setSecure(httpCookie.isSecure());
/* 123 */         cookie.setHttpOnly(httpCookie.isHttpOnly());
/* 124 */         cookie.setPartitioned(httpCookie.isPartitioned());
/* 125 */         if (httpCookie.getSameSite() != null) {
/* 126 */           cookie.setSameSite(CookieHeaderNames.SameSite.valueOf(httpCookie.getSameSite()));
/*     */         }
/* 128 */         this.response.addCookie((Cookie)cookie);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 135 */     return doCommit(() -> this.response.sendFile(file, position, count).then());
/*     */   }
/*     */   
/*     */   private Publisher<ByteBuf> toByteBufs(Publisher<? extends DataBuffer> dataBuffers) {
/* 139 */     return (dataBuffers instanceof Mono) ? 
/* 140 */       (Publisher<ByteBuf>)Mono.from(dataBuffers).map(NettyDataBufferFactory::toByteBuf) : 
/* 141 */       (Publisher<ByteBuf>)Flux.from(dataBuffers).map(NettyDataBufferFactory::toByteBuf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void touchDataBuffer(DataBuffer buffer) {
/* 146 */     if (logger.isDebugEnabled()) {
/* 147 */       HttpServerResponse httpServerResponse = this.response; if (httpServerResponse instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpServerResponse;
/* 148 */         DataBufferUtils.touch(buffer, "Channel id: " + operationsId.asLongText()); }
/*     */       else
/*     */       
/* 151 */       { this.response.withConnection(connection -> {
/*     */               ChannelId id = connection.channel().id();
/*     */               DataBufferUtils.touch(buffer, "Channel id: " + id.asShortText());
/*     */             }); }
/*     */     
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */