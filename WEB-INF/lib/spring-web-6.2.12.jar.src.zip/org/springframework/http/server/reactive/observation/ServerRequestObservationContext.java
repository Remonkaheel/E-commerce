/*     */ package org.springframework.http.server.reactive.observation;
/*     */ 
/*     */ import io.micrometer.observation.transport.RequestReplyReceiverContext;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerRequestObservationContext
/*     */   extends RequestReplyReceiverContext<ServerHttpRequest, ServerHttpResponse>
/*     */ {
/*  47 */   public static final String CURRENT_OBSERVATION_CONTEXT_ATTRIBUTE = ServerRequestObservationContext.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, Object> attributes;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String pathPattern;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean connectionAborted;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerRequestObservationContext(ServerHttpRequest request, ServerHttpResponse response, Map<String, Object> attributes) {
/*  67 */     super((req, key) -> req.getHeaders().getFirst(key));
/*  68 */     setCarrier(request);
/*  69 */     setResponse(response);
/*  70 */     this.attributes = Collections.unmodifiableMap(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  78 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPathPattern() {
/*  89 */     return this.pathPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathPattern(@Nullable String pathPattern) {
/*  98 */     this.pathPattern = pathPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConnectionAborted() {
/* 108 */     return this.connectionAborted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionAborted(boolean connectionAborted) {
/* 118 */     this.connectionAborted = connectionAborted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<ServerRequestObservationContext> findCurrent(Map<String, Object> attributes) {
/* 130 */     return Optional.ofNullable((ServerRequestObservationContext)attributes
/* 131 */         .get(CURRENT_OBSERVATION_CONTEXT_ATTRIBUTE));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\observation\ServerRequestObservationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */