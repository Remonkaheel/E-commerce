/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import java.io.IOException;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HandlerResultSubscriber
/*     */   implements Subscriber<Void>
/*     */ {
/*     */   private final HttpServerExchange exchange;
/*     */   private final String logPrefix;
/*     */   
/*     */   public HandlerResultSubscriber(HttpServerExchange exchange, UndertowServerHttpRequest request) {
/* 101 */     this.exchange = exchange;
/* 102 */     this.logPrefix = request.getLogPrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription subscription) {
/* 107 */     subscription.request(Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNext(Void aVoid) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onError(Throwable ex) {
/* 117 */     UndertowHttpHandlerAdapter.logger.trace(this.logPrefix + "Failed to complete: " + this.logPrefix);
/* 118 */     if (this.exchange.isResponseStarted()) {
/*     */       try {
/* 120 */         UndertowHttpHandlerAdapter.logger.debug(this.logPrefix + "Closing connection");
/* 121 */         this.exchange.getConnection().close();
/*     */       }
/* 123 */       catch (IOException iOException) {}
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 128 */       UndertowHttpHandlerAdapter.logger.debug(this.logPrefix + "Setting HttpServerExchange status to 500 Server Error");
/* 129 */       this.exchange.setStatusCode(500);
/* 130 */       this.exchange.endExchange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 136 */     UndertowHttpHandlerAdapter.logger.trace(this.logPrefix + "Handling completed");
/* 137 */     this.exchange.endExchange();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowHttpHandlerAdapter$HandlerResultSubscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */