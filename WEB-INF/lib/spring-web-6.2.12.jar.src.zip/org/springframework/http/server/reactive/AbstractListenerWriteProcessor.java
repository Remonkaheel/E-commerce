/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.log.LogDelegateFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractListenerWriteProcessor<T>
/*     */   implements Processor<T, Void>
/*     */ {
/*  56 */   protected static final Log rsWriteLogger = LogDelegateFactory.getHiddenLog(AbstractListenerWriteProcessor.class);
/*     */ 
/*     */   
/*  59 */   private final AtomicReference<State> state = new AtomicReference<>(State.UNSUBSCRIBED);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Subscription subscription;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile T currentData;
/*     */ 
/*     */   
/*     */   private volatile boolean sourceCompleted;
/*     */ 
/*     */   
/*     */   private volatile boolean readyToCompleteAfterLastWrite;
/*     */ 
/*     */   
/*     */   private final WriteResultPublisher resultPublisher;
/*     */ 
/*     */   
/*     */   private final String logPrefix;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractListenerWriteProcessor() {
/*  84 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractListenerWriteProcessor(String logPrefix) {
/*  94 */     this.resultPublisher = new WriteResultPublisher(logPrefix + "[WP] ", this::cancelAndSetCompleted);
/*  95 */     this.logPrefix = StringUtils.hasText(logPrefix) ? logPrefix : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLogPrefix() {
/* 104 */     return this.logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription subscription) {
/* 112 */     ((State)this.state.get()).onSubscribe(this, subscription);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(T data) {
/* 117 */     if (rsWriteLogger.isTraceEnabled()) {
/* 118 */       rsWriteLogger.trace(getLogPrefix() + "onNext: " + getLogPrefix());
/*     */     }
/* 120 */     ((State)this.state.get()).onNext(this, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(Throwable ex) {
/* 129 */     State state = this.state.get();
/* 130 */     if (rsWriteLogger.isTraceEnabled()) {
/* 131 */       rsWriteLogger.trace(getLogPrefix() + "onError: " + getLogPrefix() + " [" + String.valueOf(ex) + "]");
/*     */     }
/* 133 */     state.onError(this, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 142 */     State state = this.state.get();
/* 143 */     if (rsWriteLogger.isTraceEnabled()) {
/* 144 */       rsWriteLogger.trace(getLogPrefix() + "onComplete [" + getLogPrefix() + "]");
/*     */     }
/* 146 */     state.onComplete(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onWritePossible() {
/* 155 */     State state = this.state.get();
/* 156 */     if (rsWriteLogger.isTraceEnabled()) {
/* 157 */       rsWriteLogger.trace(getLogPrefix() + "onWritePossible [" + getLogPrefix() + "]");
/*     */     }
/* 159 */     state.onWritePossible(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 170 */     if (rsWriteLogger.isTraceEnabled()) {
/* 171 */       rsWriteLogger.trace(getLogPrefix() + "cancel [" + getLogPrefix() + "]");
/*     */     }
/* 173 */     if (this.subscription != null) {
/* 174 */       this.subscription.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void cancelAndSetCompleted() {
/* 184 */     cancel();
/*     */     while (true) {
/* 186 */       State prev = this.state.get();
/* 187 */       if (prev == State.COMPLETED) {
/*     */         break;
/*     */       }
/* 190 */       if (this.state.compareAndSet(prev, State.COMPLETED)) {
/* 191 */         if (rsWriteLogger.isTraceEnabled()) {
/* 192 */           rsWriteLogger.trace(getLogPrefix() + getLogPrefix() + " -> " + String.valueOf(prev));
/*     */         }
/* 194 */         if (prev != State.WRITING) {
/* 195 */           discardCurrentData();
/*     */         }
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void subscribe(Subscriber<? super Void> subscriber) {
/* 206 */     this.resultPublisher.subscribe(subscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isDataEmpty(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataReceived(T data) {
/* 224 */     T prev = this.currentData;
/* 225 */     if (prev != null) {
/*     */ 
/*     */ 
/*     */       
/* 229 */       discardData(data);
/* 230 */       cancel();
/* 231 */       onError(new IllegalStateException("Received new data while current not processed yet."));
/*     */     } 
/* 233 */     this.currentData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isWritePossible();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean write(T paramT) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void writingPaused() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writingComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writingFailed(Throwable ex) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void discardData(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean changeState(State oldState, State newState) {
/* 295 */     boolean result = this.state.compareAndSet(oldState, newState);
/* 296 */     if (result && rsWriteLogger.isTraceEnabled()) {
/* 297 */       rsWriteLogger.trace(getLogPrefix() + getLogPrefix() + " -> " + String.valueOf(oldState));
/*     */     }
/* 299 */     return result;
/*     */   }
/*     */   
/*     */   private void changeStateToReceived(State oldState) {
/* 303 */     if (changeState(oldState, State.RECEIVED)) {
/* 304 */       writeIfPossible();
/*     */     }
/*     */   }
/*     */   
/*     */   private void changeStateToComplete(State oldState) {
/* 309 */     if (changeState(oldState, State.COMPLETED)) {
/* 310 */       discardCurrentData();
/* 311 */       writingComplete();
/* 312 */       this.resultPublisher.publishComplete();
/*     */     } else {
/*     */       
/* 315 */       ((State)this.state.get()).onComplete(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeIfPossible() {
/* 320 */     boolean result = isWritePossible();
/* 321 */     if (!result && rsWriteLogger.isTraceEnabled()) {
/* 322 */       rsWriteLogger.trace(getLogPrefix() + "isWritePossible false");
/*     */     }
/* 324 */     if (result) {
/* 325 */       onWritePossible();
/*     */     }
/*     */   }
/*     */   
/*     */   private void discardCurrentData() {
/* 330 */     T data = this.currentData;
/* 331 */     this.currentData = null;
/* 332 */     if (data != null) {
/* 333 */       discardData(data);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 356 */     UNSUBSCRIBED
/*     */     {
/*     */       public <T> void onSubscribe(AbstractListenerWriteProcessor<T> processor, Subscription subscription) {
/* 359 */         Assert.notNull(subscription, "Subscription must not be null");
/* 360 */         if (processor.changeState(this, REQUESTED)) {
/* 361 */           processor.subscription = subscription;
/* 362 */           subscription.request(1L);
/*     */         } else {
/*     */           
/* 365 */           super.onSubscribe(processor, subscription);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 372 */         processor.changeStateToComplete(this);
/*     */       }
/*     */     },
/*     */     
/* 376 */     REQUESTED
/*     */     {
/*     */       public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {
/* 379 */         if (processor.isDataEmpty(data)) {
/* 380 */           Assert.state((processor.subscription != null), "No subscription");
/* 381 */           processor.subscription.request(1L);
/*     */         } else {
/*     */           
/* 384 */           processor.dataReceived(data);
/* 385 */           processor.changeStateToReceived(this);
/*     */         } 
/*     */       }
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 390 */         processor.readyToCompleteAfterLastWrite = true;
/* 391 */         processor.changeStateToReceived(this);
/*     */       }
/*     */     },
/*     */     
/* 395 */     RECEIVED
/*     */     {
/*     */       public <T> void onWritePossible(AbstractListenerWriteProcessor<T> processor)
/*     */       {
/* 399 */         if (processor.readyToCompleteAfterLastWrite) {
/* 400 */           processor.changeStateToComplete(RECEIVED);
/*     */         }
/* 402 */         else if (processor.changeState(this, WRITING)) {
/* 403 */           T data = processor.currentData;
/* 404 */           Assert.state((data != null), "No data");
/*     */           try {
/* 406 */             if (processor.write(data)) {
/* 407 */               if (processor.changeState(WRITING, REQUESTED)) {
/* 408 */                 processor.currentData = null;
/* 409 */                 if (processor.sourceCompleted) {
/* 410 */                   processor.readyToCompleteAfterLastWrite = true;
/* 411 */                   processor.changeStateToReceived(REQUESTED);
/*     */                 } else {
/*     */                   
/* 414 */                   processor.writingPaused();
/* 415 */                   Assert.state((processor.subscription != null), "No subscription");
/* 416 */                   processor.subscription.request(1L);
/*     */                 } 
/*     */               } 
/*     */             } else {
/*     */               
/* 421 */               processor.changeStateToReceived(WRITING);
/*     */             }
/*     */           
/* 424 */           } catch (IOException ex) {
/* 425 */             processor.writingFailed(ex);
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 432 */         processor.sourceCompleted = true;
/*     */         
/* 434 */         if (processor.state.get() == State.REQUESTED) {
/* 435 */           processor.changeStateToComplete(State.REQUESTED);
/*     */         
/*     */         }
/*     */       }
/*     */     },
/* 440 */     WRITING
/*     */     {
/*     */       public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 443 */         processor.sourceCompleted = true;
/*     */         
/* 445 */         if (processor.state.get() == State.REQUESTED) {
/* 446 */           processor.changeStateToComplete(State.REQUESTED);
/*     */         
/*     */         }
/*     */       }
/*     */     },
/* 451 */     COMPLETED
/*     */     {
/*     */       public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {}
/*     */     };
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onSubscribe(AbstractListenerWriteProcessor<T> processor, Subscription subscription) {
/* 467 */       subscription.cancel();
/*     */     }
/*     */     
/*     */     public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {
/* 471 */       processor.discardData(data);
/* 472 */       processor.cancel();
/* 473 */       processor.onError(new IllegalStateException("Illegal onNext without demand"));
/*     */     }
/*     */     
/*     */     public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {
/* 477 */       if (processor.changeState(this, COMPLETED)) {
/* 478 */         processor.discardCurrentData();
/* 479 */         processor.writingComplete();
/* 480 */         processor.resultPublisher.publishError(ex);
/*     */       } else {
/*     */         
/* 483 */         ((State)processor.state.get()).onError(processor, ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/* 488 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     public <T> void onWritePossible(AbstractListenerWriteProcessor<T> processor) {}
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public <T> void onSubscribe(AbstractListenerWriteProcessor<T> processor, Subscription subscription) {
/*     */       Assert.notNull(subscription, "Subscription must not be null");
/*     */       if (processor.changeState(this, REQUESTED)) {
/*     */         processor.subscription = subscription;
/*     */         subscription.request(1L);
/*     */       } else {
/*     */         super.onSubscribe(processor, subscription);
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/*     */       processor.changeStateToComplete(this);
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {
/*     */       if (processor.isDataEmpty(data)) {
/*     */         Assert.state((processor.subscription != null), "No subscription");
/*     */         processor.subscription.request(1L);
/*     */       } else {
/*     */         processor.dataReceived(data);
/*     */         processor.changeStateToReceived(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/*     */       processor.readyToCompleteAfterLastWrite = true;
/*     */       processor.changeStateToReceived(this);
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public <T> void onWritePossible(AbstractListenerWriteProcessor<T> processor) {
/*     */       if (processor.readyToCompleteAfterLastWrite) {
/*     */         processor.changeStateToComplete(RECEIVED);
/*     */       } else if (processor.changeState(this, WRITING)) {
/*     */         T data = processor.currentData;
/*     */         Assert.state((data != null), "No data");
/*     */         try {
/*     */           if (processor.write(data)) {
/*     */             if (processor.changeState(WRITING, REQUESTED)) {
/*     */               processor.currentData = null;
/*     */               if (processor.sourceCompleted) {
/*     */                 processor.readyToCompleteAfterLastWrite = true;
/*     */                 processor.changeStateToReceived(REQUESTED);
/*     */               } else {
/*     */                 processor.writingPaused();
/*     */                 Assert.state((processor.subscription != null), "No subscription");
/*     */                 processor.subscription.request(1L);
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             processor.changeStateToReceived(WRITING);
/*     */           } 
/*     */         } catch (IOException ex) {
/*     */           processor.writingFailed(ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/*     */       processor.sourceCompleted = true;
/*     */       if (processor.state.get() == AbstractListenerWriteProcessor.State.REQUESTED)
/*     */         processor.changeStateToComplete(AbstractListenerWriteProcessor.State.REQUESTED); 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {
/*     */       processor.sourceCompleted = true;
/*     */       if (processor.state.get() == AbstractListenerWriteProcessor.State.REQUESTED)
/*     */         processor.changeStateToComplete(AbstractListenerWriteProcessor.State.REQUESTED); 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {}
/*     */     
/*     */     public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {}
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */