/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.connector.ByteBufferPool;
/*     */ import io.undertow.connector.PooledByteBuffer;
/*     */ import io.undertow.server.ExchangeCompletionListener;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.xnio.channels.StreamSourceChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RequestBodyPublisher
/*     */   extends AbstractListenerReadPublisher<DataBuffer>
/*     */ {
/*     */   private final StreamSourceChannel channel;
/*     */   private final DataBufferFactory bufferFactory;
/*     */   private final ByteBufferPool byteBufferPool;
/*     */   
/*     */   public RequestBodyPublisher(HttpServerExchange exchange, DataBufferFactory bufferFactory) {
/* 141 */     super(paramUndertowServerHttpRequest.getLogPrefix());
/* 142 */     this.channel = exchange.getRequestChannel();
/* 143 */     this.bufferFactory = bufferFactory;
/* 144 */     this.byteBufferPool = exchange.getConnection().getByteBufferPool();
/*     */   }
/*     */   
/*     */   private void registerListeners(HttpServerExchange exchange) {
/* 148 */     exchange.addExchangeCompleteListener((ex, next) -> {
/*     */           onAllDataRead();
/*     */           next.proceed();
/*     */         });
/* 152 */     this.channel.getReadSetter().set(c -> onDataAvailable());
/* 153 */     this.channel.getCloseSetter().set(c -> onAllDataRead());
/* 154 */     this.channel.resumeReads();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkOnDataAvailable() {
/* 159 */     this.channel.resumeReads();
/*     */     
/* 161 */     onDataAvailable();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readingPaused() {
/* 166 */     this.channel.suspendReads();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected DataBuffer read() throws IOException {
/* 172 */     PooledByteBuffer pooledByteBuffer = this.byteBufferPool.allocate();
/* 173 */     PooledByteBuffer pooledByteBuffer1 = pooledByteBuffer; try {
/* 174 */       ByteBuffer byteBuffer = pooledByteBuffer.getBuffer();
/* 175 */       int read = this.channel.read(byteBuffer);
/*     */       
/* 177 */       if (rsReadLogger.isTraceEnabled()) {
/* 178 */         rsReadLogger.trace(getLogPrefix() + "Read " + getLogPrefix() + read);
/*     */       }
/*     */       
/* 181 */       if (read > 0)
/* 182 */       { byteBuffer.flip();
/* 183 */         DataBuffer dataBuffer1 = this.bufferFactory.allocateBuffer(read);
/* 184 */         dataBuffer1.write(new ByteBuffer[] { byteBuffer });
/* 185 */         DataBuffer dataBuffer2 = dataBuffer1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         if (pooledByteBuffer1 != null) pooledByteBuffer1.close();  return dataBuffer2; }  if (read == -1) onAllDataRead();  DataBuffer dataBuffer = null; if (pooledByteBuffer1 != null) pooledByteBuffer1.close(); 
/*     */       return dataBuffer;
/*     */     } catch (Throwable throwable) {
/*     */       if (pooledByteBuffer1 != null)
/*     */         try {
/*     */           pooledByteBuffer1.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void discardData() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowServerHttpRequest$RequestBodyPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */