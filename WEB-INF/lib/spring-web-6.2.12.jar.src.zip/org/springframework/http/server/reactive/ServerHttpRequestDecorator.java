/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerHttpRequestDecorator
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   private final ServerHttpRequest delegate;
/*     */   
/*     */   public ServerHttpRequestDecorator(ServerHttpRequest delegate) {
/*  47 */     Assert.notNull(delegate, "Delegate is required");
/*  48 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest getDelegate() {
/*  53 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  61 */     return getDelegate().getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  66 */     return getDelegate().getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  71 */     return getDelegate().getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  76 */     return getDelegate().getAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestPath getPath() {
/*  81 */     return getDelegate().getPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> getQueryParams() {
/*  86 */     return getDelegate().getQueryParams();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  91 */     return getDelegate().getHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, HttpCookie> getCookies() {
/*  96 */     return getDelegate().getCookies();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/* 102 */     return getDelegate().getLocalAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 108 */     return getDelegate().getRemoteAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SslInfo getSslInfo() {
/* 114 */     return getDelegate().getSslInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 119 */     return getDelegate().getBody();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return getClass().getSimpleName() + " [delegate=" + getClass().getSimpleName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getNativeRequest(ServerHttpRequest request) {
/* 137 */     if (request instanceof AbstractServerHttpRequest) { AbstractServerHttpRequest abstractServerHttpRequest = (AbstractServerHttpRequest)request;
/* 138 */       return abstractServerHttpRequest.getNativeRequest(); }
/*     */     
/* 140 */     if (request instanceof ServerHttpRequestDecorator) { ServerHttpRequestDecorator serverHttpRequestDecorator = (ServerHttpRequestDecorator)request;
/* 141 */       return getNativeRequest(serverHttpRequestDecorator.getDelegate()); }
/*     */ 
/*     */     
/* 144 */     throw new IllegalArgumentException("Cannot find native request in " + request.getClass().getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServerHttpRequestDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */