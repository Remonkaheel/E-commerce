/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.ReactiveHttpOutputMessage;
/*    */ import org.springframework.http.ResponseCookie;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ServerHttpResponse
/*    */   extends ReactiveHttpOutputMessage
/*    */ {
/*    */   boolean setStatusCode(@Nullable HttpStatusCode paramHttpStatusCode);
/*    */   
/*    */   @Nullable
/*    */   HttpStatusCode getStatusCode();
/*    */   
/*    */   default boolean setRawStatusCode(@Nullable Integer value) {
/* 60 */     return setStatusCode((value != null) ? HttpStatusCode.valueOf(value.intValue()) : null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "6.0", forRemoval = true)
/*    */   @Nullable
/*    */   default Integer getRawStatusCode() {
/* 73 */     HttpStatusCode httpStatus = getStatusCode();
/* 74 */     return (httpStatus != null) ? Integer.valueOf(httpStatus.value()) : null;
/*    */   }
/*    */   
/*    */   MultiValueMap<String, ResponseCookie> getCookies();
/*    */   
/*    */   void addCookie(ResponseCookie paramResponseCookie);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */