/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncEvent;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Servlet;
/*     */ import jakarta.servlet.ServletConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletHttpHandlerAdapter
/*     */   implements Servlet
/*     */ {
/*  59 */   private static final Log logger = HttpLogging.forLogName(ServletHttpHandlerAdapter.class);
/*     */   
/*     */   private static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*  63 */   private static final String WRITE_ERROR_ATTRIBUTE_NAME = ServletHttpHandlerAdapter.class.getName() + ".ERROR";
/*     */ 
/*     */   
/*     */   private final HttpHandler httpHandler;
/*     */   
/*  68 */   private int bufferSize = 8192;
/*     */   
/*     */   @Nullable
/*     */   private String servletPath;
/*     */   
/*  73 */   private DataBufferFactory dataBufferFactory = (DataBufferFactory)DefaultDataBufferFactory.sharedInstance;
/*     */ 
/*     */   
/*     */   public ServletHttpHandlerAdapter(HttpHandler httpHandler) {
/*  77 */     Assert.notNull(httpHandler, "HttpHandler must not be null");
/*  78 */     this.httpHandler = httpHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferSize(int bufferSize) {
/*  87 */     Assert.isTrue((bufferSize > 0), "Buffer size must be larger than zero");
/*  88 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/*  95 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getServletPath() {
/* 107 */     return this.servletPath;
/*     */   }
/*     */   
/*     */   public void setDataBufferFactory(DataBufferFactory dataBufferFactory) {
/* 111 */     Assert.notNull(dataBufferFactory, "DataBufferFactory must not be null");
/* 112 */     this.dataBufferFactory = dataBufferFactory;
/*     */   }
/*     */   
/*     */   public DataBufferFactory getDataBufferFactory() {
/* 116 */     return this.dataBufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ServletConfig config) {
/* 124 */     this.servletPath = getServletPath(config);
/*     */   }
/*     */   
/*     */   private String getServletPath(ServletConfig config) {
/* 128 */     String name = config.getServletName();
/* 129 */     ServletRegistration registration = config.getServletContext().getServletRegistration(name);
/* 130 */     if (registration == null) {
/* 131 */       throw new IllegalStateException("ServletRegistration not found for Servlet '" + name + "'");
/*     */     }
/*     */     
/* 134 */     Collection<String> mappings = registration.getMappings();
/* 135 */     if (mappings.size() == 1) {
/* 136 */       String mapping = mappings.iterator().next();
/* 137 */       if (mapping.equals("/")) {
/* 138 */         return "";
/*     */       }
/* 140 */       if (mapping.endsWith("/*")) {
/* 141 */         String path = mapping.substring(0, mapping.length() - 2);
/* 142 */         if (!path.isEmpty() && logger.isDebugEnabled()) {
/* 143 */           logger.debug("Found servlet mapping prefix '" + path + "' for '" + name + "'");
/*     */         }
/* 145 */         return path;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     throw new IllegalArgumentException("Expected a single Servlet mapping: either the default Servlet mapping (i.e. '/'), or a path based mapping (for example, '/*', '/foo/*'). Actual mappings: " + String.valueOf(mappings) + " for Servlet '" + name + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
/*     */     ServletServerHttpRequest httpRequest;
/*     */     AsyncListener requestListener;
/*     */     String logPrefix;
/* 159 */     if (DispatcherType.ASYNC == request.getDispatcherType()) {
/* 160 */       Throwable ex = (Throwable)request.getAttribute(WRITE_ERROR_ATTRIBUTE_NAME);
/* 161 */       throw new ServletException("Failed to create response content", ex);
/*     */     } 
/*     */ 
/*     */     
/* 165 */     AsyncContext asyncContext = request.startAsync();
/* 166 */     asyncContext.setTimeout(-1L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 172 */       httpRequest = createRequest((HttpServletRequest)request, asyncContext);
/* 173 */       requestListener = httpRequest.getAsyncListener();
/* 174 */       logPrefix = httpRequest.getLogPrefix();
/*     */     }
/* 176 */     catch (URISyntaxException ex) {
/* 177 */       if (logger.isDebugEnabled()) {
/* 178 */         logger.debug("Failed to get request  URL: " + ex.getMessage());
/*     */       }
/* 180 */       ((HttpServletResponse)response).setStatus(400);
/* 181 */       asyncContext.complete();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 186 */     ServletServerHttpResponse wrappedResponse = createResponse((HttpServletResponse)response, asyncContext, httpRequest);
/* 187 */     ServerHttpResponse httpResponse = wrappedResponse;
/* 188 */     AsyncListener responseListener = wrappedResponse.getAsyncListener();
/* 189 */     if (httpRequest.getMethod() == HttpMethod.HEAD) {
/* 190 */       httpResponse = new HttpHeadResponseDecorator(httpResponse);
/*     */     }
/*     */     
/* 193 */     AtomicBoolean completionFlag = new AtomicBoolean();
/* 194 */     HandlerResultSubscriber subscriber = new HandlerResultSubscriber(asyncContext, completionFlag, logPrefix);
/*     */     
/* 196 */     asyncContext.addListener(new HttpHandlerAsyncListener(requestListener, responseListener, subscriber, completionFlag, logPrefix));
/*     */ 
/*     */     
/* 199 */     this.httpHandler.handle(httpRequest, httpResponse).subscribe(subscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpRequest createRequest(HttpServletRequest request, AsyncContext context) throws IOException, URISyntaxException {
/* 205 */     Assert.state((this.servletPath != null), "Servlet path is not initialized");
/* 206 */     return new ServletServerHttpRequest(request, context, this.servletPath, 
/* 207 */         getDataBufferFactory(), getBufferSize());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpResponse createResponse(HttpServletResponse response, AsyncContext context, ServletServerHttpRequest request) throws IOException {
/* 213 */     return new ServletServerHttpResponse(response, context, getDataBufferFactory(), getBufferSize(), request);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServletInfo() {
/* 218 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ServletConfig getServletConfig() {
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */   
/*     */   private static void runIfAsyncNotComplete(AsyncContext asyncContext, AtomicBoolean isCompleted, Runnable task) {
/*     */     try {
/* 234 */       if (asyncContext.getRequest().isAsyncStarted() && isCompleted.compareAndSet(false, true)) {
/* 235 */         task.run();
/*     */       }
/*     */     }
/* 238 */     catch (IllegalStateException illegalStateException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class HttpHandlerAsyncListener
/*     */     implements AsyncListener
/*     */   {
/*     */     private final AsyncListener requestAsyncListener;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final AsyncListener responseAsyncListener;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Runnable handlerDisposeTask;
/*     */ 
/*     */ 
/*     */     
/*     */     private final AtomicBoolean completionFlag;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String logPrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public HttpHandlerAsyncListener(AsyncListener requestAsyncListener, AsyncListener responseAsyncListener, Runnable handlerDisposeTask, AtomicBoolean completionFlag, String logPrefix) {
/* 271 */       this.requestAsyncListener = requestAsyncListener;
/* 272 */       this.responseAsyncListener = responseAsyncListener;
/* 273 */       this.handlerDisposeTask = handlerDisposeTask;
/* 274 */       this.completionFlag = completionFlag;
/* 275 */       this.logPrefix = logPrefix;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onStartAsync(AsyncEvent event) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onTimeout(AsyncEvent event) {
/* 286 */       if (ServletHttpHandlerAdapter.logger.isDebugEnabled()) {
/* 287 */         ServletHttpHandlerAdapter.logger.debug(this.logPrefix + "AsyncEvent onTimeout");
/*     */       }
/* 289 */       delegateTimeout(this.requestAsyncListener, event);
/* 290 */       delegateTimeout(this.responseAsyncListener, event);
/* 291 */       handleTimeoutOrError(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(AsyncEvent event) {
/* 296 */       Throwable ex = event.getThrowable();
/* 297 */       if (ServletHttpHandlerAdapter.logger.isDebugEnabled()) {
/* 298 */         ServletHttpHandlerAdapter.logger.debug(this.logPrefix + "AsyncEvent onError: " + this.logPrefix);
/*     */       }
/* 300 */       delegateError(this.requestAsyncListener, event);
/* 301 */       delegateError(this.responseAsyncListener, event);
/* 302 */       handleTimeoutOrError(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete(AsyncEvent event) {
/* 307 */       delegateComplete(this.requestAsyncListener, event);
/* 308 */       delegateComplete(this.responseAsyncListener, event);
/*     */     }
/*     */     
/*     */     private static void delegateTimeout(AsyncListener listener, AsyncEvent event) {
/*     */       try {
/* 313 */         listener.onTimeout(event);
/*     */       }
/* 315 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void delegateError(AsyncListener listener, AsyncEvent event) {
/*     */       try {
/* 322 */         listener.onError(event);
/*     */       }
/* 324 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void delegateComplete(AsyncListener listener, AsyncEvent event) {
/*     */       try {
/* 331 */         listener.onComplete(event);
/*     */       }
/* 333 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void handleTimeoutOrError(AsyncEvent event) {
/* 339 */       AsyncContext context = event.getAsyncContext();
/* 340 */       ServletHttpHandlerAdapter.runIfAsyncNotComplete(context, this.completionFlag, () -> {
/*     */             try {
/*     */               this.handlerDisposeTask.run();
/*     */             } finally {
/*     */               context.complete();
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HandlerResultSubscriber
/*     */     implements Subscriber<Void>, Runnable
/*     */   {
/*     */     private final AsyncContext asyncContext;
/*     */     
/*     */     private final AtomicBoolean completionFlag;
/*     */     
/*     */     private final String logPrefix;
/*     */     
/*     */     @Nullable
/*     */     private volatile Subscription subscription;
/*     */     
/*     */     public HandlerResultSubscriber(AsyncContext asyncContext, AtomicBoolean completionFlag, String logPrefix) {
/* 364 */       this.asyncContext = asyncContext;
/* 365 */       this.completionFlag = completionFlag;
/* 366 */       this.logPrefix = logPrefix;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 371 */       this.subscription = subscription;
/* 372 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Void aVoid) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 382 */       if (ServletHttpHandlerAdapter.logger.isTraceEnabled()) {
/* 383 */         ServletHttpHandlerAdapter.logger.trace(this.logPrefix + "onError: " + this.logPrefix);
/*     */       }
/* 385 */       ServletHttpHandlerAdapter.runIfAsyncNotComplete(this.asyncContext, this.completionFlag, () -> {
/*     */             if (this.asyncContext.getResponse().isCommitted()) {
/*     */               ServletHttpHandlerAdapter.logger.trace(this.logPrefix + "Dispatch to container, to raise the error on servlet thread");
/*     */               this.asyncContext.getRequest().setAttribute(ServletHttpHandlerAdapter.WRITE_ERROR_ATTRIBUTE_NAME, ex);
/*     */               this.asyncContext.dispatch();
/*     */             } else {
/*     */               try {
/*     */                 ServletHttpHandlerAdapter.logger.trace(this.logPrefix + "Setting ServletResponse status to 500 Server Error");
/*     */                 this.asyncContext.getResponse().resetBuffer();
/*     */                 ((HttpServletResponse)this.asyncContext.getResponse()).setStatus(500);
/*     */               } finally {
/*     */                 this.asyncContext.complete();
/*     */               } 
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 406 */       if (ServletHttpHandlerAdapter.logger.isTraceEnabled()) {
/* 407 */         ServletHttpHandlerAdapter.logger.trace(this.logPrefix + "onComplete");
/*     */       }
/* 409 */       Objects.requireNonNull(this.asyncContext); ServletHttpHandlerAdapter.runIfAsyncNotComplete(this.asyncContext, this.completionFlag, this.asyncContext::complete);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 414 */       Subscription s = this.subscription;
/* 415 */       if (s != null)
/* 416 */         s.cancel(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServletHttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */