/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.netty5.buffer.Buffer;
/*     */ import io.netty5.channel.ChannelId;
/*     */ import io.netty5.handler.codec.http.headers.DefaultHttpSetCookie;
/*     */ import io.netty5.handler.codec.http.headers.HttpSetCookie;
/*     */ import java.nio.file.Path;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.support.Netty5HeadersAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty5.ChannelOperationsId;
/*     */ import reactor.netty5.Connection;
/*     */ import reactor.netty5.http.server.HttpServerResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorNetty2ServerHttpResponse
/*     */   extends AbstractServerHttpResponse
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(ReactorNetty2ServerHttpResponse.class);
/*     */ 
/*     */   
/*     */   private final HttpServerResponse response;
/*     */ 
/*     */   
/*     */   public ReactorNetty2ServerHttpResponse(HttpServerResponse response, DataBufferFactory bufferFactory) {
/*  61 */     super(bufferFactory, new HttpHeaders((MultiValueMap)new Netty5HeadersAdapter(response.responseHeaders())));
/*  62 */     Assert.notNull(response, "HttpServerResponse must not be null");
/*  63 */     this.response = response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeResponse() {
/*  70 */     return (T)this.response;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  75 */     HttpStatusCode status = super.getStatusCode();
/*  76 */     return (status != null) ? status : HttpStatusCode.valueOf(this.response.status().code());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Integer getRawStatusCode() {
/*  83 */     Integer status = super.getRawStatusCode();
/*  84 */     return Integer.valueOf((status != null) ? status.intValue() : this.response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyStatusCode() {
/*  89 */     HttpStatusCode status = super.getStatusCode();
/*  90 */     if (status != null) {
/*  91 */       this.response.status(status.value());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeWithInternal(Publisher<? extends DataBuffer> publisher) {
/*  97 */     return this.response.send(toByteBufs(publisher)).then();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> writeAndFlushWithInternal(Publisher<? extends Publisher<? extends DataBuffer>> publisher) {
/* 102 */     return this.response.sendGroups((Publisher)Flux.from(publisher).map(this::toByteBufs)).then();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {}
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 111 */     for (String name : getCookies().keySet()) {
/* 112 */       for (ResponseCookie httpCookie : getCookies().get(name)) {
/* 113 */         Long maxAge = !httpCookie.getMaxAge().isNegative() ? Long.valueOf(httpCookie.getMaxAge().getSeconds()) : null;
/* 114 */         HttpSetCookie.SameSite sameSite = (httpCookie.getSameSite() != null) ? HttpSetCookie.SameSite.valueOf(httpCookie.getSameSite()) : null;
/*     */ 
/*     */         
/* 117 */         DefaultHttpSetCookie cookie = new DefaultHttpSetCookie(name, httpCookie.getValue(), httpCookie.getPath(), httpCookie.getDomain(), null, maxAge, sameSite, false, httpCookie.isSecure(), httpCookie.isHttpOnly());
/* 118 */         this.response.addCookie((HttpSetCookie)cookie);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 125 */     return doCommit(() -> this.response.sendFile(file, position, count).then());
/*     */   }
/*     */   
/*     */   private Publisher<Buffer> toByteBufs(Publisher<? extends DataBuffer> dataBuffers) {
/* 129 */     return (dataBuffers instanceof Mono) ? 
/* 130 */       (Publisher<Buffer>)Mono.from(dataBuffers).map(Netty5DataBufferFactory::toBuffer) : 
/* 131 */       (Publisher<Buffer>)Flux.from(dataBuffers).map(Netty5DataBufferFactory::toBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void touchDataBuffer(DataBuffer buffer) {
/* 136 */     if (logger.isDebugEnabled()) {
/* 137 */       HttpServerResponse httpServerResponse = this.response; if (httpServerResponse instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpServerResponse;
/* 138 */         DataBufferUtils.touch(buffer, "Channel id: " + operationsId.asLongText()); }
/*     */       else
/*     */       
/* 141 */       { this.response.withConnection(connection -> {
/*     */               ChannelId id = connection.channel().id();
/*     */               DataBufferUtils.touch(buffer, "Channel id: " + id.asShortText());
/*     */             }); }
/*     */     
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorNetty2ServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */