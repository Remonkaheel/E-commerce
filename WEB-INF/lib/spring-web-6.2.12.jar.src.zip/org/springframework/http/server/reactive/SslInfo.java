package org.springframework.http.server.reactive;

import java.security.cert.X509Certificate;
import org.springframework.lang.Nullable;

public interface SslInfo {
  @Nullable
  String getSessionId();
  
  @Nullable
  X509Certificate[] getPeerCertificates();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\SslInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */