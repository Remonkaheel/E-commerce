/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpLogging;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UndertowHttpHandlerAdapter
/*     */   implements HttpHandler
/*     */ {
/*  43 */   private static final Log logger = HttpLogging.forLogName(UndertowHttpHandlerAdapter.class);
/*     */ 
/*     */   
/*     */   private final HttpHandler httpHandler;
/*     */   
/*  48 */   private DataBufferFactory bufferFactory = (DataBufferFactory)DefaultDataBufferFactory.sharedInstance;
/*     */ 
/*     */   
/*     */   public UndertowHttpHandlerAdapter(HttpHandler httpHandler) {
/*  52 */     Assert.notNull(httpHandler, "HttpHandler must not be null");
/*  53 */     this.httpHandler = httpHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDataBufferFactory(DataBufferFactory bufferFactory) {
/*  58 */     Assert.notNull(bufferFactory, "DataBufferFactory must not be null");
/*  59 */     this.bufferFactory = bufferFactory;
/*     */   }
/*     */   
/*     */   public DataBufferFactory getDataBufferFactory() {
/*  63 */     return this.bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRequest(HttpServerExchange exchange) {
/*  69 */     exchange.dispatch(() -> {
/*     */           UndertowServerHttpRequest request = null;
/*     */           
/*     */           try {
/*     */             request = new UndertowServerHttpRequest(exchange, getDataBufferFactory());
/*  74 */           } catch (URISyntaxException ex) {
/*     */             if (logger.isWarnEnabled()) {
/*     */               logger.debug("Failed to get request URI: " + ex.getMessage());
/*     */             }
/*     */             exchange.setStatusCode(400);
/*     */             return;
/*     */           } 
/*     */           ServerHttpResponse response = new UndertowServerHttpResponse(exchange, getDataBufferFactory(), request);
/*     */           if (request.getMethod() == HttpMethod.HEAD) {
/*     */             response = new HttpHeadResponseDecorator(response);
/*     */           }
/*     */           HandlerResultSubscriber resultSubscriber = new HandlerResultSubscriber(exchange, request);
/*     */           this.httpHandler.handle(request, response).subscribe(resultSubscriber);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class HandlerResultSubscriber
/*     */     implements Subscriber<Void>
/*     */   {
/*     */     private final HttpServerExchange exchange;
/*     */     
/*     */     private final String logPrefix;
/*     */ 
/*     */     
/*     */     public HandlerResultSubscriber(HttpServerExchange exchange, UndertowServerHttpRequest request) {
/* 101 */       this.exchange = exchange;
/* 102 */       this.logPrefix = request.getLogPrefix();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 107 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Void aVoid) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 117 */       UndertowHttpHandlerAdapter.logger.trace(this.logPrefix + "Failed to complete: " + this.logPrefix);
/* 118 */       if (this.exchange.isResponseStarted()) {
/*     */         try {
/* 120 */           UndertowHttpHandlerAdapter.logger.debug(this.logPrefix + "Closing connection");
/* 121 */           this.exchange.getConnection().close();
/*     */         }
/* 123 */         catch (IOException iOException) {}
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 128 */         UndertowHttpHandlerAdapter.logger.debug(this.logPrefix + "Setting HttpServerExchange status to 500 Server Error");
/* 129 */         this.exchange.setStatusCode(500);
/* 130 */         this.exchange.endExchange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 136 */       UndertowHttpHandlerAdapter.logger.trace(this.logPrefix + "Handling completed");
/* 137 */       this.exchange.endExchange();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowHttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */