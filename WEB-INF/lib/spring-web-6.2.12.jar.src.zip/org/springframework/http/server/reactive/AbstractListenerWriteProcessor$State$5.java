/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ enum null {
/*     */   public <T> void onNext(AbstractListenerWriteProcessor<T> processor, T data) {}
/*     */   
/*     */   public <T> void onError(AbstractListenerWriteProcessor<T> processor, Throwable ex) {}
/*     */   
/*     */   public <T> void onComplete(AbstractListenerWriteProcessor<T> processor) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteProcessor$State$5.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */