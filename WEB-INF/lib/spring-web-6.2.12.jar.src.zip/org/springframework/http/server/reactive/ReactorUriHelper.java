/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty.http.server.HttpServerRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ReactorUriHelper
/*     */ {
/*     */   public static URI createUri(HttpServerRequest request) throws URISyntaxException {
/*  35 */     Assert.notNull(request, "HttpServerRequest must not be null");
/*     */     
/*  37 */     StringBuilder builder = new StringBuilder();
/*  38 */     String scheme = request.scheme();
/*  39 */     builder.append(scheme);
/*  40 */     builder.append("://");
/*     */     
/*  42 */     appendHostName(request, builder);
/*     */     
/*  44 */     int port = request.hostPort();
/*  45 */     if (((scheme.equals("http") || scheme.equals("ws")) && port != 80) || ((scheme
/*  46 */       .equals("https") || scheme.equals("wss")) && port != 443)) {
/*  47 */       builder.append(':');
/*  48 */       builder.append(port);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     String prefix = request.forwardedPrefix();
/*  55 */     if (prefix != null && !prefix.isEmpty()) {
/*  56 */       builder.append(prefix);
/*     */     }
/*     */     
/*  59 */     appendRequestUri(request, builder);
/*     */     
/*  61 */     return new URI(builder.toString());
/*     */   }
/*     */   
/*     */   private static void appendHostName(HttpServerRequest request, StringBuilder builder) {
/*  65 */     String hostName = request.hostName();
/*  66 */     boolean ipv6 = (hostName.indexOf(':') != -1);
/*  67 */     boolean brackets = (ipv6 && !hostName.startsWith("[") && !hostName.endsWith("]"));
/*  68 */     if (brackets) {
/*  69 */       builder.append('[');
/*     */     }
/*  71 */     if (encoded(hostName, ipv6)) {
/*  72 */       builder.append(hostName);
/*     */     } else {
/*     */       
/*  75 */       for (int i = 0; i < hostName.length(); i++) {
/*  76 */         char c = hostName.charAt(i);
/*  77 */         if (isAllowedInHost(c, ipv6)) {
/*  78 */           builder.append(c);
/*     */         } else {
/*     */           
/*  81 */           builder.append('%');
/*  82 */           char hex1 = Character.toUpperCase(Character.forDigit(c >> 4 & 0xF, 16));
/*  83 */           char hex2 = Character.toUpperCase(Character.forDigit(c & 0xF, 16));
/*  84 */           builder.append(hex1);
/*  85 */           builder.append(hex2);
/*     */         } 
/*     */       } 
/*     */     } 
/*  89 */     if (brackets) {
/*  90 */       builder.append(']');
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean encoded(String hostName, boolean ipv6) {
/*  95 */     int length = hostName.length();
/*  96 */     for (int i = 0; i < length; i++) {
/*  97 */       char c = hostName.charAt(i);
/*  98 */       if (c == '%') {
/*  99 */         if (i + 2 < length) {
/* 100 */           char hex1 = hostName.charAt(i + 1);
/* 101 */           char hex2 = hostName.charAt(i + 2);
/* 102 */           int u = Character.digit(hex1, 16);
/* 103 */           int l = Character.digit(hex2, 16);
/* 104 */           if (u == -1 || l == -1) {
/* 105 */             return false;
/*     */           }
/* 107 */           i += 2;
/*     */         } else {
/*     */           
/* 110 */           return false;
/*     */         }
/*     */       
/* 113 */       } else if (!isAllowedInHost(c, ipv6)) {
/* 114 */         return false;
/*     */       } 
/*     */     } 
/* 117 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isAllowedInHost(char c, boolean ipv6) {
/* 121 */     return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || '-' == c || '.' == c || '_' == c || '~' == c || '!' == c || '$' == c || '&' == c || '\'' == c || '(' == c || ')' == c || '*' == c || '+' == c || ',' == c || ';' == c || '=' == c || (ipv6 && ('[' == c || ']' == c || ':' == c)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendRequestUri(HttpServerRequest request, StringBuilder builder) {
/* 131 */     String uri = request.uri();
/* 132 */     int length = uri.length();
/* 133 */     for (int i = 0; i < length; i++) {
/* 134 */       char c = uri.charAt(i);
/* 135 */       if (c == '/' || c == '?' || c == '#') {
/*     */         break;
/*     */       }
/* 138 */       if (c == ':' && i + 2 < length && 
/* 139 */         uri.charAt(i + 1) == '/' && uri.charAt(i + 2) == '/') {
/* 140 */         for (int j = i + 3; j < length; j++) {
/* 141 */           c = uri.charAt(j);
/* 142 */           if (c == '/' || c == '?' || c == '#') {
/* 143 */             builder.append(uri, j, length);
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/* 151 */     builder.append(uri);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ReactorUriHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */