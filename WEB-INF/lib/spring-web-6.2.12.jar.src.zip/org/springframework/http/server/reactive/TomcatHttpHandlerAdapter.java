/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.catalina.connector.CoyoteInputStream;
/*     */ import org.apache.catalina.connector.CoyoteOutputStream;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.RequestFacade;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.connector.ResponseFacade;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.coyote.Response;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatHttpHandlerAdapter
/*     */   extends ServletHttpHandlerAdapter
/*     */ {
/*     */   public TomcatHttpHandlerAdapter(HttpHandler httpHandler) {
/*  58 */     super(httpHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpRequest createRequest(HttpServletRequest request, AsyncContext asyncContext) throws IOException, URISyntaxException {
/*  66 */     Assert.state((getServletPath() != null), "Servlet path is not initialized");
/*  67 */     return new TomcatServerHttpRequest(request, asyncContext, 
/*  68 */         getServletPath(), getDataBufferFactory(), getBufferSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletServerHttpResponse createResponse(HttpServletResponse response, AsyncContext asyncContext, ServletServerHttpRequest request) throws IOException {
/*  75 */     return new TomcatServerHttpResponse(response, asyncContext, 
/*  76 */         getDataBufferFactory(), getBufferSize(), request);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class TomcatServerHttpRequest
/*     */     extends ServletServerHttpRequest
/*     */   {
/*     */     private static final Field COYOTE_REQUEST_FIELD;
/*     */     
/*     */     private final int bufferSize;
/*     */     private final DataBufferFactory factory;
/*     */     
/*     */     static {
/*  89 */       Field field = ReflectionUtils.findField(RequestFacade.class, "request");
/*  90 */       Assert.state((field != null), "Incompatible Tomcat implementation");
/*  91 */       ReflectionUtils.makeAccessible(field);
/*  92 */       COYOTE_REQUEST_FIELD = field;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TomcatServerHttpRequest(HttpServletRequest request, AsyncContext context, String servletPath, DataBufferFactory factory, int bufferSize) throws IOException, URISyntaxException {
/*  99 */       super(createTomcatHttpHeaders(request), request, context, servletPath, factory, bufferSize);
/* 100 */       this.factory = factory;
/* 101 */       this.bufferSize = bufferSize;
/*     */     }
/*     */     
/*     */     private static MultiValueMap<String, String> createTomcatHttpHeaders(HttpServletRequest request) {
/* 105 */       RequestFacade requestFacade = getRequestFacade(request);
/*     */       
/* 107 */       Request connectorRequest = (Request)ReflectionUtils.getField(COYOTE_REQUEST_FIELD, requestFacade);
/* 108 */       Assert.state((connectorRequest != null), "No Tomcat connector request");
/* 109 */       Request tomcatRequest = connectorRequest.getCoyoteRequest();
/* 110 */       return new TomcatHeadersAdapter(tomcatRequest.getMimeHeaders());
/*     */     }
/*     */     
/*     */     private static RequestFacade getRequestFacade(HttpServletRequest request) {
/* 114 */       if (request instanceof RequestFacade) { RequestFacade facade = (RequestFacade)request;
/* 115 */         return facade; }
/*     */       
/* 117 */       if (request instanceof HttpServletRequestWrapper) { HttpServletRequestWrapper wrapper = (HttpServletRequestWrapper)request;
/* 118 */         HttpServletRequest wrappedRequest = (HttpServletRequest)wrapper.getRequest();
/* 119 */         return getRequestFacade(wrappedRequest); }
/*     */ 
/*     */       
/* 122 */       throw new IllegalArgumentException("Cannot convert [" + String.valueOf(request.getClass()) + "] to org.apache.catalina.connector.RequestFacade");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DataBuffer readFromInputStream() throws IOException {
/* 129 */       ServletInputStream servletInputStream = getInputStream(); if (servletInputStream instanceof CoyoteInputStream) { CoyoteInputStream coyoteInputStream = (CoyoteInputStream)servletInputStream;
/* 130 */         DataBuffer dataBuffer = this.factory.allocateBuffer(this.bufferSize);
/* 131 */         int read = -1;
/*     */         try {
/* 133 */           DataBuffer.ByteBufferIterator iterator = dataBuffer.writableByteBuffers(); 
/* 134 */           try { Assert.state(iterator.hasNext(), "No ByteBuffer available");
/* 135 */             ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 136 */             read = coyoteInputStream.read(byteBuffer);
/* 137 */             if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 138 */               try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  logBytesRead(read);
/* 139 */           if (read > 0) {
/* 140 */             dataBuffer.writePosition(read);
/* 141 */             return dataBuffer;
/*     */           } 
/* 143 */           if (read == -1) {
/* 144 */             return EOF_BUFFER;
/*     */           }
/*     */           
/* 147 */           return AbstractListenerReadPublisher.EMPTY_BUFFER;
/*     */         }
/*     */         finally {
/*     */           
/* 151 */           if (read <= 0) {
/* 152 */             DataBufferUtils.release(dataBuffer);
/*     */           }
/*     */         }  }
/*     */ 
/*     */ 
/*     */       
/* 158 */       return super.readFromInputStream();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class TomcatServerHttpResponse
/*     */     extends ServletServerHttpResponse
/*     */   {
/*     */     private static final Field COYOTE_RESPONSE_FIELD;
/*     */ 
/*     */     
/*     */     static {
/* 170 */       Field field = ReflectionUtils.findField(ResponseFacade.class, "response");
/* 171 */       Assert.state((field != null), "Incompatible Tomcat implementation");
/* 172 */       ReflectionUtils.makeAccessible(field);
/* 173 */       COYOTE_RESPONSE_FIELD = field;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     TomcatServerHttpResponse(HttpServletResponse response, AsyncContext context, DataBufferFactory factory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/* 179 */       super(createTomcatHttpHeaders(response), response, context, factory, bufferSize, request);
/*     */     }
/*     */     
/*     */     private static HttpHeaders createTomcatHttpHeaders(HttpServletResponse response) {
/* 183 */       ResponseFacade responseFacade = getResponseFacade(response);
/*     */       
/* 185 */       Response connectorResponse = (Response)ReflectionUtils.getField(COYOTE_RESPONSE_FIELD, responseFacade);
/* 186 */       Assert.state((connectorResponse != null), "No Tomcat connector response");
/* 187 */       Response tomcatResponse = connectorResponse.getCoyoteResponse();
/* 188 */       TomcatHeadersAdapter headers = new TomcatHeadersAdapter(tomcatResponse.getMimeHeaders());
/* 189 */       return new HttpHeaders(headers);
/*     */     }
/*     */     
/*     */     private static ResponseFacade getResponseFacade(HttpServletResponse response) {
/* 193 */       if (response instanceof ResponseFacade) { ResponseFacade facade = (ResponseFacade)response;
/* 194 */         return facade; }
/*     */       
/* 196 */       if (response instanceof HttpServletResponseWrapper) { HttpServletResponseWrapper wrapper = (HttpServletResponseWrapper)response;
/* 197 */         HttpServletResponse wrappedResponse = (HttpServletResponse)wrapper.getResponse();
/* 198 */         return getResponseFacade(wrappedResponse); }
/*     */ 
/*     */       
/* 201 */       throw new IllegalArgumentException("Cannot convert [" + String.valueOf(response.getClass()) + "] to org.apache.catalina.connector.ResponseFacade");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void applyHeaders() {
/* 208 */       adaptHeaders(true);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int writeToOutputStream(DataBuffer dataBuffer) throws IOException {
/* 213 */       ServletOutputStream servletOutputStream = getOutputStream(); if (servletOutputStream instanceof CoyoteOutputStream) { CoyoteOutputStream coyoteOutputStream = (CoyoteOutputStream)servletOutputStream;
/* 214 */         int len = 0;
/* 215 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 216 */         try { while (iterator.hasNext() && coyoteOutputStream.isReady()) {
/* 217 */             ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 218 */             len += byteBuffer.remaining();
/* 219 */             coyoteOutputStream.write(byteBuffer);
/*     */           } 
/* 221 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 222 */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return len; }
/*     */ 
/*     */       
/* 225 */       return super.writeToOutputStream(dataBuffer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\TomcatHttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */