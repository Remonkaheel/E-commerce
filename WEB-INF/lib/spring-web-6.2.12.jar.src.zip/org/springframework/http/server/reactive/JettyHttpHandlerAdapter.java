/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import jakarta.servlet.AsyncContext;
/*    */ import jakarta.servlet.ServletOutputStream;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.eclipse.jetty.ee10.servlet.HttpOutput;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JettyHttpHandlerAdapter
/*    */   extends ServletHttpHandlerAdapter
/*    */ {
/*    */   public JettyHttpHandlerAdapter(HttpHandler httpHandler) {
/* 43 */     super(httpHandler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ServletServerHttpResponse createResponse(HttpServletResponse response, AsyncContext context, ServletServerHttpRequest request) throws IOException {
/* 51 */     return new Jetty12ServerHttpResponse(response, context, 
/* 52 */         getDataBufferFactory(), getBufferSize(), request);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class Jetty12ServerHttpResponse
/*    */     extends ServletServerHttpResponse
/*    */   {
/*    */     Jetty12ServerHttpResponse(HttpServletResponse response, AsyncContext asyncContext, DataBufferFactory bufferFactory, int bufferSize, ServletServerHttpRequest request) throws IOException {
/* 62 */       super(response, asyncContext, bufferFactory, bufferSize, request);
/*    */     }
/*    */ 
/*    */     
/*    */     protected int writeToOutputStream(DataBuffer dataBuffer) throws IOException {
/* 67 */       ServletOutputStream servletOutputStream = getOutputStream();
/* 68 */       if (servletOutputStream instanceof HttpOutput) { HttpOutput httpOutput = (HttpOutput)servletOutputStream;
/* 69 */         int len = 0;
/* 70 */         DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers(); 
/* 71 */         try { while (iterator.hasNext() && httpOutput.isReady()) {
/* 72 */             ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 73 */             len += byteBuffer.remaining();
/* 74 */             httpOutput.write(byteBuffer);
/*    */           } 
/* 76 */           if (iterator != null) iterator.close();  } catch (Throwable throwable) { if (iterator != null)
/* 77 */             try { iterator.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return len; }
/*    */       
/* 79 */       return super.writeToOutputStream(dataBuffer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyHttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */