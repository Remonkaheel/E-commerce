/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.log.LogDelegateFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Operators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WriteResultPublisher
/*     */   implements Publisher<Void>
/*     */ {
/*  49 */   private static final Log rsWriteResultLogger = LogDelegateFactory.getHiddenLog(WriteResultPublisher.class);
/*     */ 
/*     */   
/*  52 */   private final AtomicReference<State> state = new AtomicReference<>(State.UNSUBSCRIBED);
/*     */   
/*     */   private final Runnable cancelTask;
/*     */   
/*     */   @Nullable
/*     */   private volatile Subscriber<? super Void> subscriber;
/*     */   
/*     */   private volatile boolean completedBeforeSubscribed;
/*     */   
/*     */   @Nullable
/*     */   private volatile Throwable errorBeforeSubscribed;
/*     */   
/*     */   private final String logPrefix;
/*     */ 
/*     */   
/*     */   public WriteResultPublisher(String logPrefix, Runnable cancelTask) {
/*  68 */     this.cancelTask = cancelTask;
/*  69 */     this.logPrefix = logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void subscribe(Subscriber<? super Void> subscriber) {
/*  75 */     if (rsWriteResultLogger.isTraceEnabled()) {
/*  76 */       rsWriteResultLogger.trace(this.logPrefix + "got subscriber " + this.logPrefix);
/*     */     }
/*  78 */     ((State)this.state.get()).subscribe(this, subscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publishComplete() {
/*  85 */     State state = this.state.get();
/*  86 */     if (rsWriteResultLogger.isTraceEnabled()) {
/*  87 */       rsWriteResultLogger.trace(this.logPrefix + "completed [" + this.logPrefix + "]");
/*     */     }
/*  89 */     state.publishComplete(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publishError(Throwable t) {
/*  96 */     State state = this.state.get();
/*  97 */     if (rsWriteResultLogger.isTraceEnabled()) {
/*  98 */       rsWriteResultLogger.trace(this.logPrefix + "failed: " + this.logPrefix + " [" + String.valueOf(t) + "]");
/*     */     }
/* 100 */     state.publishError(this, t);
/*     */   }
/*     */   
/*     */   private boolean changeState(State oldState, State newState) {
/* 104 */     return this.state.compareAndSet(oldState, newState);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class WriteResultSubscription
/*     */     implements Subscription
/*     */   {
/*     */     private final WriteResultPublisher publisher;
/*     */ 
/*     */ 
/*     */     
/*     */     public WriteResultSubscription(WriteResultPublisher publisher) {
/* 117 */       this.publisher = publisher;
/*     */     }
/*     */ 
/*     */     
/*     */     public final void request(long n) {
/* 122 */       if (WriteResultPublisher.rsWriteResultLogger.isTraceEnabled()) {
/* 123 */         WriteResultPublisher.rsWriteResultLogger.trace(this.publisher.logPrefix + "request " + this.publisher.logPrefix);
/*     */       }
/*     */       
/* 126 */       getState().request(this.publisher, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void cancel() {
/* 131 */       WriteResultPublisher.State state = getState();
/* 132 */       if (WriteResultPublisher.rsWriteResultLogger.isTraceEnabled()) {
/* 133 */         WriteResultPublisher.rsWriteResultLogger.trace(this.publisher.logPrefix + "cancel [" + this.publisher.logPrefix + "]");
/*     */       }
/* 135 */       state.cancel(this.publisher);
/*     */     }
/*     */     
/*     */     private WriteResultPublisher.State getState() {
/* 139 */       return this.publisher.state.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 161 */     UNSUBSCRIBED
/*     */     {
/*     */       void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/* 164 */         Assert.notNull(subscriber, "Subscriber must not be null");
/* 165 */         if (publisher.changeState(this, SUBSCRIBING)) {
/* 166 */           Subscription subscription = new WriteResultPublisher.WriteResultSubscription(publisher);
/* 167 */           publisher.subscriber = subscriber;
/* 168 */           subscriber.onSubscribe(subscription);
/* 169 */           publisher.changeState(SUBSCRIBING, SUBSCRIBED);
/*     */           
/* 171 */           if (publisher.completedBeforeSubscribed) {
/* 172 */             ((State)publisher.state.get()).publishComplete(publisher);
/*     */           }
/* 174 */           Throwable ex = publisher.errorBeforeSubscribed;
/* 175 */           if (ex != null) {
/* 176 */             ((State)publisher.state.get()).publishError(publisher, ex);
/*     */           }
/*     */         } else {
/*     */           
/* 180 */           throw new IllegalStateException(toString());
/*     */         } 
/*     */       }
/*     */       
/*     */       void publishComplete(WriteResultPublisher publisher) {
/* 185 */         publisher.completedBeforeSubscribed = true;
/* 186 */         if (State.SUBSCRIBED == publisher.state.get()) {
/* 187 */           ((State)publisher.state.get()).publishComplete(publisher);
/*     */         }
/*     */       }
/*     */       
/*     */       void publishError(WriteResultPublisher publisher, Throwable ex) {
/* 192 */         publisher.errorBeforeSubscribed = ex;
/* 193 */         if (State.SUBSCRIBED == publisher.state.get()) {
/* 194 */           ((State)publisher.state.get()).publishError(publisher, ex);
/*     */         
/*     */         }
/*     */       }
/*     */     },
/* 199 */     SUBSCRIBING
/*     */     {
/*     */       void request(WriteResultPublisher publisher, long n) {
/* 202 */         Operators.validate(n);
/*     */       }
/*     */       
/*     */       void publishComplete(WriteResultPublisher publisher) {
/* 206 */         publisher.completedBeforeSubscribed = true;
/* 207 */         if (State.SUBSCRIBED == publisher.state.get()) {
/* 208 */           ((State)publisher.state.get()).publishComplete(publisher);
/*     */         }
/*     */       }
/*     */       
/*     */       void publishError(WriteResultPublisher publisher, Throwable ex) {
/* 213 */         publisher.errorBeforeSubscribed = ex;
/* 214 */         if (State.SUBSCRIBED == publisher.state.get()) {
/* 215 */           ((State)publisher.state.get()).publishError(publisher, ex);
/*     */         
/*     */         }
/*     */       }
/*     */     },
/* 220 */     SUBSCRIBED
/*     */     {
/*     */       void request(WriteResultPublisher publisher, long n) {
/* 223 */         Operators.validate(n);
/*     */       }
/*     */     },
/*     */     
/* 227 */     COMPLETED
/*     */     {
/*     */       void request(WriteResultPublisher publisher, long n) {}
/*     */ 
/*     */ 
/*     */       
/*     */       void cancel(WriteResultPublisher publisher) {}
/*     */ 
/*     */ 
/*     */       
/*     */       void publishComplete(WriteResultPublisher publisher) {}
/*     */ 
/*     */ 
/*     */       
/*     */       void publishError(WriteResultPublisher publisher, Throwable t) {}
/*     */     };
/*     */ 
/*     */ 
/*     */     
/*     */     void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/* 247 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     void request(WriteResultPublisher publisher, long n) {
/* 251 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     void cancel(WriteResultPublisher publisher) {
/* 255 */       if (publisher.changeState(this, COMPLETED)) {
/* 256 */         publisher.cancelTask.run();
/*     */       } else {
/*     */         
/* 259 */         ((State)publisher.state.get()).cancel(publisher);
/*     */       } 
/*     */     }
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {
/* 264 */       if (publisher.changeState(this, COMPLETED)) {
/* 265 */         Subscriber<? super Void> s = publisher.subscriber;
/* 266 */         Assert.state((s != null), "No subscriber");
/* 267 */         s.onComplete();
/*     */       } else {
/*     */         
/* 270 */         ((State)publisher.state.get()).publishComplete(publisher);
/*     */       } 
/*     */     }
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable t) {
/* 275 */       if (publisher.changeState(this, COMPLETED)) {
/* 276 */         Subscriber<? super Void> s = publisher.subscriber;
/* 277 */         Assert.state((s != null), "No subscriber");
/* 278 */         s.onError(t);
/*     */       } else {
/*     */         
/* 281 */         ((State)publisher.state.get()).publishError(publisher, t);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/*     */       Assert.notNull(subscriber, "Subscriber must not be null");
/*     */       if (publisher.changeState(this, SUBSCRIBING)) {
/*     */         Subscription subscription = new WriteResultPublisher.WriteResultSubscription(publisher);
/*     */         publisher.subscriber = subscriber;
/*     */         subscriber.onSubscribe(subscription);
/*     */         publisher.changeState(SUBSCRIBING, SUBSCRIBED);
/*     */         if (publisher.completedBeforeSubscribed)
/*     */           ((WriteResultPublisher.State)publisher.state.get()).publishComplete(publisher); 
/*     */         Throwable ex = publisher.errorBeforeSubscribed;
/*     */         if (ex != null)
/*     */           ((WriteResultPublisher.State)publisher.state.get()).publishError(publisher, ex); 
/*     */       } else {
/*     */         throw new IllegalStateException(toString());
/*     */       } 
/*     */     }
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {
/*     */       publisher.completedBeforeSubscribed = true;
/*     */       if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get())
/*     */         ((WriteResultPublisher.State)publisher.state.get()).publishComplete(publisher); 
/*     */     }
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable ex) {
/*     */       publisher.errorBeforeSubscribed = ex;
/*     */       if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get())
/*     */         ((WriteResultPublisher.State)publisher.state.get()).publishError(publisher, ex); 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     void request(WriteResultPublisher publisher, long n) {
/*     */       Operators.validate(n);
/*     */     }
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {
/*     */       publisher.completedBeforeSubscribed = true;
/*     */       if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get())
/*     */         ((WriteResultPublisher.State)publisher.state.get()).publishComplete(publisher); 
/*     */     }
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable ex) {
/*     */       publisher.errorBeforeSubscribed = ex;
/*     */       if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get())
/*     */         ((WriteResultPublisher.State)publisher.state.get()).publishError(publisher, ex); 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     void request(WriteResultPublisher publisher, long n) {
/*     */       Operators.validate(n);
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     void request(WriteResultPublisher publisher, long n) {}
/*     */     
/*     */     void cancel(WriteResultPublisher publisher) {}
/*     */     
/*     */     void publishComplete(WriteResultPublisher publisher) {}
/*     */     
/*     */     void publishError(WriteResultPublisher publisher, Throwable t) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\WriteResultPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */