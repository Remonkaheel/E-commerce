/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.core.log.LogDelegateFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Operators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractListenerReadPublisher<T>
/*     */   implements Publisher<T>
/*     */ {
/*  60 */   protected static Log rsReadLogger = LogDelegateFactory.getHiddenLog(AbstractListenerReadPublisher.class);
/*     */   
/*  62 */   static final DataBuffer EMPTY_BUFFER = (DataBuffer)DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
/*     */ 
/*     */   
/*  65 */   private final AtomicReference<State> state = new AtomicReference<>(State.UNSUBSCRIBED);
/*     */ 
/*     */   
/*     */   private volatile long demand;
/*     */ 
/*     */   
/*  71 */   private static final AtomicLongFieldUpdater<AbstractListenerReadPublisher> DEMAND_FIELD_UPDATER = AtomicLongFieldUpdater.newUpdater(AbstractListenerReadPublisher.class, "demand");
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile Subscriber<? super T> subscriber;
/*     */ 
/*     */   
/*     */   private volatile boolean completionPending;
/*     */   
/*     */   @Nullable
/*     */   private volatile Throwable errorPending;
/*     */   
/*     */   private final String logPrefix;
/*     */ 
/*     */   
/*     */   public AbstractListenerReadPublisher() {
/*  87 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractListenerReadPublisher(String logPrefix) {
/*  95 */     this.logPrefix = logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLogPrefix() {
/* 104 */     return this.logPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(Subscriber<? super T> subscriber) {
/* 112 */     ((State)this.state.get()).subscribe(this, subscriber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onDataAvailable() {
/* 124 */     rsReadLogger.trace(getLogPrefix() + "onDataAvailable");
/* 125 */     ((State)this.state.get()).onDataAvailable(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAllDataRead() {
/* 133 */     State state = this.state.get();
/* 134 */     if (rsReadLogger.isTraceEnabled()) {
/* 135 */       rsReadLogger.trace(getLogPrefix() + "onAllDataRead [" + getLogPrefix() + "]");
/*     */     }
/* 137 */     state.onAllDataRead(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(Throwable ex) {
/* 145 */     State state = this.state.get();
/* 146 */     if (rsReadLogger.isTraceEnabled()) {
/* 147 */       rsReadLogger.trace(getLogPrefix() + "onError: " + getLogPrefix() + " [" + String.valueOf(ex) + "]");
/*     */     }
/* 149 */     state.onError(this, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void checkOnDataAvailable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract T read() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void readingPaused();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void discardData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readAndPublish() throws IOException {
/*     */     long r;
/* 197 */     while ((r = this.demand) > 0L && this.state.get() != State.COMPLETED) {
/* 198 */       T data = read();
/* 199 */       if (data == EMPTY_BUFFER) {
/* 200 */         if (rsReadLogger.isTraceEnabled())
/* 201 */           rsReadLogger.trace(getLogPrefix() + "0 bytes read, trying again"); 
/*     */         continue;
/*     */       } 
/* 204 */       if (data != null) {
/* 205 */         if (r != Long.MAX_VALUE) {
/* 206 */           DEMAND_FIELD_UPDATER.addAndGet(this, -1L);
/*     */         }
/* 208 */         Subscriber<? super T> subscriber = this.subscriber;
/* 209 */         Assert.state((subscriber != null), "No subscriber");
/* 210 */         if (rsReadLogger.isTraceEnabled()) {
/* 211 */           rsReadLogger.trace(getLogPrefix() + "Publishing " + getLogPrefix());
/*     */         }
/* 213 */         subscriber.onNext(data);
/*     */         continue;
/*     */       } 
/* 216 */       if (rsReadLogger.isTraceEnabled()) {
/* 217 */         rsReadLogger.trace(getLogPrefix() + "No more to read");
/*     */       }
/* 219 */       return true;
/*     */     } 
/*     */     
/* 222 */     return false;
/*     */   }
/*     */   
/*     */   private boolean changeState(State oldState, State newState) {
/* 226 */     boolean result = this.state.compareAndSet(oldState, newState);
/* 227 */     if (result && rsReadLogger.isTraceEnabled()) {
/* 228 */       rsReadLogger.trace(getLogPrefix() + getLogPrefix() + " -> " + String.valueOf(oldState));
/*     */     }
/* 230 */     return result;
/*     */   }
/*     */   
/*     */   private void changeToDemandState(State oldState) {
/* 234 */     if (changeState(oldState, State.DEMAND))
/*     */     {
/*     */ 
/*     */       
/* 238 */       if (oldState != State.READING) {
/* 239 */         checkOnDataAvailable();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean handlePendingCompletionOrError() {
/* 245 */     State state = this.state.get();
/* 246 */     if (state == State.DEMAND || state == State.NO_DEMAND) {
/* 247 */       if (this.completionPending) {
/* 248 */         rsReadLogger.trace(getLogPrefix() + "Processing pending completion");
/* 249 */         ((State)this.state.get()).onAllDataRead(this);
/* 250 */         return true;
/*     */       } 
/* 252 */       Throwable ex = this.errorPending;
/* 253 */       if (ex != null) {
/* 254 */         if (rsReadLogger.isTraceEnabled()) {
/* 255 */           rsReadLogger.trace(getLogPrefix() + "Processing pending completion with error: " + getLogPrefix());
/*     */         }
/* 257 */         ((State)this.state.get()).onError(this, ex);
/* 258 */         return true;
/*     */       } 
/*     */     } 
/* 261 */     return false;
/*     */   }
/*     */   
/*     */   private Subscription createSubscription() {
/* 265 */     return new ReadSubscription();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ReadSubscription
/*     */     implements Subscription
/*     */   {
/*     */     public void request(long n) {
/* 277 */       if (AbstractListenerReadPublisher.rsReadLogger.isTraceEnabled()) {
/* 278 */         AbstractListenerReadPublisher.rsReadLogger.trace(AbstractListenerReadPublisher.this.getLogPrefix() + "request " + AbstractListenerReadPublisher.this.getLogPrefix());
/*     */       }
/* 280 */       ((AbstractListenerReadPublisher.State)AbstractListenerReadPublisher.this.state.get()).request(AbstractListenerReadPublisher.this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 285 */       AbstractListenerReadPublisher.State state = AbstractListenerReadPublisher.this.state.get();
/* 286 */       if (AbstractListenerReadPublisher.rsReadLogger.isTraceEnabled()) {
/* 287 */         AbstractListenerReadPublisher.rsReadLogger.trace(AbstractListenerReadPublisher.this.getLogPrefix() + "cancel [" + AbstractListenerReadPublisher.this.getLogPrefix() + "]");
/*     */       }
/* 289 */       state.cancel(AbstractListenerReadPublisher.this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 314 */     UNSUBSCRIBED
/*     */     {
/*     */       <T> void subscribe(AbstractListenerReadPublisher<T> publisher, Subscriber<? super T> subscriber) {
/* 317 */         Assert.notNull(publisher, "Publisher must not be null");
/* 318 */         Assert.notNull(subscriber, "Subscriber must not be null");
/* 319 */         if (publisher.changeState(this, SUBSCRIBING)) {
/* 320 */           Subscription subscription = publisher.createSubscription();
/* 321 */           publisher.subscriber = subscriber;
/* 322 */           subscriber.onSubscribe(subscription);
/* 323 */           publisher.changeState(SUBSCRIBING, NO_DEMAND);
/* 324 */           publisher.handlePendingCompletionOrError();
/*     */         } else {
/*     */           
/* 327 */           throw new IllegalStateException("Failed to transition to SUBSCRIBING, subscriber: " + String.valueOf(subscriber));
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 334 */         publisher.completionPending = true;
/* 335 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 340 */         publisher.errorPending = ex;
/* 341 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 349 */     SUBSCRIBING
/*     */     {
/*     */       <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 352 */         if (Operators.validate(n)) {
/* 353 */           Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/* 354 */           publisher.changeToDemandState(this);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 360 */         publisher.completionPending = true;
/* 361 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 366 */         publisher.errorPending = ex;
/* 367 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 372 */         publisher.completionPending = true;
/* 373 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */     },
/*     */     
/* 377 */     NO_DEMAND
/*     */     {
/*     */       <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 380 */         if (Operators.validate(n)) {
/* 381 */           Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/* 382 */           publisher.changeToDemandState(this);
/*     */         }
/*     */       
/*     */       }
/*     */     },
/* 387 */     DEMAND
/*     */     {
/*     */       <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 390 */         if (Operators.validate(n)) {
/* 391 */           Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */           
/* 393 */           publisher.changeToDemandState(NO_DEMAND);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onDataAvailable(AbstractListenerReadPublisher<T> publisher) {
/* 399 */         if (publisher.changeState(this, READING)) {
/*     */           try {
/* 401 */             boolean demandAvailable = publisher.readAndPublish();
/* 402 */             if (demandAvailable) {
/* 403 */               publisher.changeToDemandState(READING);
/* 404 */               publisher.handlePendingCompletionOrError();
/*     */             } else {
/*     */               
/* 407 */               publisher.readingPaused();
/* 408 */               if (publisher.changeState(READING, NO_DEMAND) && 
/* 409 */                 !publisher.handlePendingCompletionOrError())
/*     */               {
/* 411 */                 long r = publisher.demand;
/* 412 */                 if (r > 0L) {
/* 413 */                   publisher.changeToDemandState(NO_DEMAND);
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/*     */           
/* 419 */           } catch (IOException ex) {
/* 420 */             publisher.onError(ex);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       }
/*     */     },
/* 427 */     READING
/*     */     {
/*     */       <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 430 */         if (Operators.validate(n)) {
/* 431 */           Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */           
/* 433 */           publisher.changeToDemandState(NO_DEMAND);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 439 */         publisher.completionPending = true;
/* 440 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 445 */         publisher.errorPending = ex;
/* 446 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */ 
/*     */       
/*     */       <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 451 */         publisher.discardData();
/* 452 */         publisher.completionPending = true;
/* 453 */         publisher.handlePendingCompletionOrError();
/*     */       }
/*     */     },
/*     */     
/* 457 */     COMPLETED
/*     */     {
/*     */       <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {}
/*     */ 
/*     */ 
/*     */       
/*     */       <T> void cancel(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */ 
/*     */       
/*     */       <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */ 
/*     */       
/*     */       <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {}
/*     */     };
/*     */ 
/*     */ 
/*     */     
/*     */     <T> void subscribe(AbstractListenerReadPublisher<T> publisher, Subscriber<? super T> subscriber) {
/* 477 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 481 */       throw new IllegalStateException(toString());
/*     */     }
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 485 */       if (publisher.changeState(this, COMPLETED)) {
/* 486 */         publisher.discardData();
/*     */       } else {
/*     */         
/* 489 */         ((State)publisher.state.get()).cancel(publisher);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onDataAvailable(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 498 */       if (publisher.changeState(this, COMPLETED)) {
/* 499 */         Subscriber<? super T> s = publisher.subscriber;
/* 500 */         if (s != null) {
/* 501 */           s.onComplete();
/*     */         }
/*     */       } else {
/*     */         
/* 505 */         ((State)publisher.state.get()).onAllDataRead(publisher);
/*     */       } 
/*     */     }
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {
/* 510 */       if (publisher.changeState(this, COMPLETED)) {
/* 511 */         publisher.discardData();
/* 512 */         Subscriber<? super T> s = publisher.subscriber;
/* 513 */         if (s != null) {
/* 514 */           s.onError(t);
/*     */         }
/*     */       } else {
/*     */         
/* 518 */         ((State)publisher.state.get()).onError(publisher, t);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void subscribe(AbstractListenerReadPublisher<T> publisher, Subscriber<? super T> subscriber) {
/*     */       Assert.notNull(publisher, "Publisher must not be null");
/*     */       Assert.notNull(subscriber, "Subscriber must not be null");
/*     */       if (publisher.changeState(this, SUBSCRIBING)) {
/*     */         Subscription subscription = publisher.createSubscription();
/*     */         publisher.subscriber = subscriber;
/*     */         subscriber.onSubscribe(subscription);
/*     */         publisher.changeState(SUBSCRIBING, NO_DEMAND);
/*     */         publisher.handlePendingCompletionOrError();
/*     */       } else {
/*     */         throw new IllegalStateException("Failed to transition to SUBSCRIBING, subscriber: " + String.valueOf(subscriber));
/*     */       } 
/*     */     }
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/*     */       publisher.completionPending = true;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/*     */       publisher.errorPending = ex;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/*     */       if (Operators.validate(n)) {
/*     */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         publisher.changeToDemandState(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/*     */       publisher.completionPending = true;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/*     */       publisher.errorPending = ex;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/*     */       publisher.completionPending = true;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/*     */       if (Operators.validate(n)) {
/*     */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         publisher.changeToDemandState(this);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/*     */       if (Operators.validate(n)) {
/*     */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         publisher.changeToDemandState(NO_DEMAND);
/*     */       } 
/*     */     }
/*     */     
/*     */     <T> void onDataAvailable(AbstractListenerReadPublisher<T> publisher) {
/*     */       if (publisher.changeState(this, READING))
/*     */         try {
/*     */           boolean demandAvailable = publisher.readAndPublish();
/*     */           if (demandAvailable) {
/*     */             publisher.changeToDemandState(READING);
/*     */             publisher.handlePendingCompletionOrError();
/*     */           } else {
/*     */             publisher.readingPaused();
/*     */             if (publisher.changeState(READING, NO_DEMAND) && !publisher.handlePendingCompletionOrError()) {
/*     */               long r = publisher.demand;
/*     */               if (r > 0L)
/*     */                 publisher.changeToDemandState(NO_DEMAND); 
/*     */             } 
/*     */           } 
/*     */         } catch (IOException ex) {
/*     */           publisher.onError(ex);
/*     */         }  
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/*     */       if (Operators.validate(n)) {
/*     */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         publisher.changeToDemandState(NO_DEMAND);
/*     */       } 
/*     */     }
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/*     */       publisher.completionPending = true;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/*     */       publisher.errorPending = ex;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/*     */       publisher.discardData();
/*     */       publisher.completionPending = true;
/*     */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {}
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {}
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {}
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerReadPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */