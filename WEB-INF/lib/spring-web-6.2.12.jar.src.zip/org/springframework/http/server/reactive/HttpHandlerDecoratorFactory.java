package org.springframework.http.server.reactive;

import java.util.function.Function;

public interface HttpHandlerDecoratorFactory extends Function<HttpHandler, HttpHandler> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\HttpHandlerDecoratorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */