/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import io.undertow.server.handlers.Cookie;
/*     */ import io.undertow.server.handlers.CookieImpl;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.xnio.channels.StreamSinkChannel;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndertowServerHttpResponse
/*     */   extends AbstractListenerServerHttpResponse
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*     */   private final HttpServerExchange exchange;
/*     */   private final UndertowServerHttpRequest request;
/*     */   @Nullable
/*     */   private StreamSinkChannel responseChannel;
/*     */   
/*     */   UndertowServerHttpResponse(HttpServerExchange exchange, DataBufferFactory bufferFactory, UndertowServerHttpRequest request) {
/*  66 */     super(bufferFactory, createHeaders(exchange));
/*  67 */     this.exchange = exchange;
/*  68 */     this.request = request;
/*     */   }
/*     */   
/*     */   private static HttpHeaders createHeaders(HttpServerExchange exchange) {
/*  72 */     Assert.notNull(exchange, "HttpServerExchange must not be null");
/*  73 */     UndertowHeadersAdapter headersMap = new UndertowHeadersAdapter(exchange.getResponseHeaders());
/*  74 */     return new HttpHeaders(headersMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeResponse() {
/*  81 */     return (T)this.exchange;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  86 */     HttpStatusCode status = super.getStatusCode();
/*  87 */     return (status != null) ? status : HttpStatusCode.valueOf(this.exchange.getStatusCode());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Integer getRawStatusCode() {
/*  94 */     Integer status = super.getRawStatusCode();
/*  95 */     return Integer.valueOf((status != null) ? status.intValue() : this.exchange.getStatusCode());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyStatusCode() {
/* 100 */     HttpStatusCode status = super.getStatusCode();
/* 101 */     if (status != null) {
/* 102 */       this.exchange.setStatusCode(status.value());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {}
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 112 */     for (String name : getCookies().keySet()) {
/* 113 */       for (ResponseCookie httpCookie : getCookies().get(name)) {
/* 114 */         CookieImpl cookieImpl = new CookieImpl(name, httpCookie.getValue());
/* 115 */         if (!httpCookie.getMaxAge().isNegative()) {
/* 116 */           cookieImpl.setMaxAge(Integer.valueOf((int)httpCookie.getMaxAge().getSeconds()));
/*     */         }
/* 118 */         if (httpCookie.getDomain() != null) {
/* 119 */           cookieImpl.setDomain(httpCookie.getDomain());
/*     */         }
/* 121 */         if (httpCookie.getPath() != null) {
/* 122 */           cookieImpl.setPath(httpCookie.getPath());
/*     */         }
/* 124 */         cookieImpl.setSecure(httpCookie.isSecure());
/* 125 */         cookieImpl.setHttpOnly(httpCookie.isHttpOnly());
/*     */         
/* 127 */         cookieImpl.setSameSiteMode(httpCookie.getSameSite());
/* 128 */         this.exchange.setResponseCookie((Cookie)cookieImpl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 135 */     return doCommit(() -> Mono.create(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Processor<? super Publisher<? extends DataBuffer>, Void> createBodyFlushProcessor() {
/* 153 */     return new ResponseBodyFlushProcessor();
/*     */   }
/*     */   
/*     */   private ResponseBodyProcessor createBodyProcessor() {
/* 157 */     if (this.responseChannel == null) {
/* 158 */       this.responseChannel = this.exchange.getResponseChannel();
/*     */     }
/* 160 */     return new ResponseBodyProcessor(this.responseChannel);
/*     */   }
/*     */ 
/*     */   
/*     */   private class ResponseBodyProcessor
/*     */     extends AbstractListenerWriteProcessor<DataBuffer>
/*     */   {
/*     */     private final StreamSinkChannel channel;
/*     */     
/*     */     @Nullable
/*     */     private volatile ByteBuffer byteBuffer;
/*     */     
/*     */     private volatile boolean writePossible;
/*     */ 
/*     */     
/*     */     public ResponseBodyProcessor(StreamSinkChannel channel) {
/* 176 */       super(UndertowServerHttpResponse.this.request.getLogPrefix());
/* 177 */       Assert.notNull(channel, "StreamSinkChannel must not be null");
/* 178 */       this.channel = channel;
/* 179 */       this.channel.getWriteSetter().set(c -> {
/*     */             this.writePossible = true;
/*     */             onWritePossible();
/*     */           });
/* 183 */       this.channel.suspendWrites();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isWritePossible() {
/* 188 */       this.channel.resumeWrites();
/* 189 */       return this.writePossible;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean write(DataBuffer dataBuffer) throws IOException {
/* 194 */       ByteBuffer buffer = this.byteBuffer;
/* 195 */       if (buffer == null) {
/* 196 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 200 */       this.writePossible = false;
/*     */ 
/*     */       
/* 203 */       int total = buffer.remaining();
/* 204 */       int written = writeByteBuffer(buffer);
/*     */       
/* 206 */       if (rsWriteLogger.isTraceEnabled()) {
/* 207 */         rsWriteLogger.trace(getLogPrefix() + "Wrote " + getLogPrefix() + " of " + written + " bytes");
/*     */       }
/* 209 */       if (written != total) {
/* 210 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 214 */       this.writePossible = true;
/*     */       
/* 216 */       DataBufferUtils.release(dataBuffer);
/* 217 */       this.byteBuffer = null;
/* 218 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     private int writeByteBuffer(ByteBuffer byteBuffer) throws IOException {
/* 223 */       int written, totalWritten = 0;
/*     */       do {
/* 225 */         written = this.channel.write(byteBuffer);
/* 226 */         totalWritten += written;
/*     */       }
/* 228 */       while (byteBuffer.hasRemaining() && written > 0);
/* 229 */       return totalWritten;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void dataReceived(DataBuffer dataBuffer) {
/* 234 */       super.dataReceived(dataBuffer);
/* 235 */       ByteBuffer byteBuffer = ByteBuffer.allocate(dataBuffer.readableByteCount());
/* 236 */       dataBuffer.toByteBuffer(byteBuffer);
/* 237 */       this.byteBuffer = byteBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isDataEmpty(DataBuffer dataBuffer) {
/* 242 */       return (dataBuffer.readableByteCount() == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void writingComplete() {
/* 247 */       this.channel.getWriteSetter().set(null);
/* 248 */       this.channel.resumeWrites();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void writingFailed(Throwable ex) {
/* 253 */       cancel();
/* 254 */       onError(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void discardData(DataBuffer dataBuffer) {
/* 259 */       DataBufferUtils.release(dataBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ResponseBodyFlushProcessor
/*     */     extends AbstractListenerWriteFlushProcessor<DataBuffer>
/*     */   {
/*     */     public ResponseBodyFlushProcessor() {
/* 267 */       super(UndertowServerHttpResponse.this.request.getLogPrefix());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Processor<? super DataBuffer, Void> createWriteProcessor() {
/* 272 */       return UndertowServerHttpResponse.this.createBodyProcessor();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void flush() throws IOException {
/* 277 */       StreamSinkChannel channel = UndertowServerHttpResponse.this.responseChannel;
/* 278 */       if (channel != null) {
/* 279 */         if (rsWriteFlushLogger.isTraceEnabled()) {
/* 280 */           rsWriteFlushLogger.trace(getLogPrefix() + "flush");
/*     */         }
/* 282 */         channel.flush();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isWritePossible() {
/* 288 */       StreamSinkChannel channel = UndertowServerHttpResponse.this.responseChannel;
/* 289 */       if (channel != null) {
/*     */         
/* 291 */         channel.resumeWrites();
/* 292 */         return true;
/*     */       } 
/* 294 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isFlushPending() {
/* 299 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class TransferBodyListener
/*     */   {
/*     */     private final FileChannel source;
/*     */     
/*     */     private final MonoSink<Void> sink;
/*     */     
/*     */     private long position;
/*     */     
/*     */     private long count;
/*     */ 
/*     */     
/*     */     public TransferBodyListener(FileChannel source, long position, long count, MonoSink<Void> sink) {
/* 316 */       this.source = source;
/* 317 */       this.sink = sink;
/* 318 */       this.position = position;
/* 319 */       this.count = count;
/*     */     }
/*     */     
/*     */     public void transfer(StreamSinkChannel destination) {
/*     */       try {
/* 324 */         while (this.count > 0L) {
/* 325 */           long len = destination.transferFrom(this.source, this.position, this.count);
/* 326 */           if (len != 0L) {
/* 327 */             this.position += len;
/* 328 */             this.count -= len;
/*     */             continue;
/*     */           } 
/* 331 */           destination.resumeWrites();
/*     */           
/*     */           return;
/*     */         } 
/* 335 */         this.sink.success();
/*     */       }
/* 337 */       catch (IOException ex) {
/* 338 */         this.sink.error(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void closeSource() {
/*     */       try {
/* 345 */         this.source.close();
/*     */       }
/* 347 */       catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */