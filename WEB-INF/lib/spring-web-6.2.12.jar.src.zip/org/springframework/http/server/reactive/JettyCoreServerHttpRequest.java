/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.jetty.http.HttpCookie;
/*     */ import org.eclipse.jetty.io.Content;
/*     */ import org.eclipse.jetty.io.EndPoint;
/*     */ import org.eclipse.jetty.server.Request;
/*     */ import org.reactivestreams.FlowAdapters;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.JettyDataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.support.JettyHeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JettyCoreServerHttpRequest
/*     */   extends AbstractServerHttpRequest
/*     */ {
/*     */   private final JettyDataBufferFactory dataBufferFactory;
/*     */   private final Request request;
/*     */   
/*     */   public JettyCoreServerHttpRequest(Request request, JettyDataBufferFactory dataBufferFactory) {
/*  56 */     super(HttpMethod.valueOf(request.getMethod()), request
/*  57 */         .getHttpURI().toURI(), request
/*  58 */         .getContext().getContextPath(), (MultiValueMap<String, String>)new HttpHeaders((MultiValueMap)new JettyHeadersAdapter(request
/*  59 */             .getHeaders())));
/*  60 */     this.dataBufferFactory = dataBufferFactory;
/*  61 */     this.request = request;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultiValueMap<String, HttpCookie> initCookies() {
/*  67 */     List<HttpCookie> httpCookies = Request.getCookies(this.request);
/*  68 */     if (httpCookies.isEmpty()) {
/*  69 */       return CollectionUtils.toMultiValueMap(Collections.emptyMap());
/*     */     }
/*  71 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/*  72 */     for (HttpCookie c : httpCookies) {
/*  73 */       linkedMultiValueMap.add(c.getName(), new HttpCookie(c.getName(), c.getValue()));
/*     */     }
/*  75 */     return (MultiValueMap<String, HttpCookie>)linkedMultiValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SslInfo initSslInfo() {
/*  81 */     if (this.request.getConnectionMetaData().isSecure()) {
/*  82 */       Object object = this.request.getAttribute("org.eclipse.jetty.io.Endpoint.SslSessionData"); if (object instanceof EndPoint.SslSessionData) { EndPoint.SslSessionData sessionData = (EndPoint.SslSessionData)object;
/*  83 */         return new DefaultSslInfo(sessionData.sslSessionId(), sessionData.peerCertificates()); }
/*     */     
/*  85 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  91 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String initId() {
/*  96 */     return this.request.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress() {
/* 102 */     SocketAddress localAddress = this.request.getConnectionMetaData().getLocalSocketAddress();
/* 103 */     InetSocketAddress inet = (InetSocketAddress)localAddress; return (localAddress instanceof InetSocketAddress) ? inet : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress() {
/* 109 */     SocketAddress remoteAddress = this.request.getConnectionMetaData().getRemoteSocketAddress();
/* 110 */     InetSocketAddress inet = (InetSocketAddress)remoteAddress; return (remoteAddress instanceof InetSocketAddress) ? inet : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 117 */     return Flux.from(FlowAdapters.toPublisher(Content.Source.asPublisher((Content.Source)this.request)))
/* 118 */       .map(chunk -> {
/*     */           chunk.retain();
/*     */           return (DataBuffer)this.dataBufferFactory.wrap(chunk);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyCoreServerHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */