/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ enum null {
/*     */   <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {}
/*     */   
/*     */   <T> void cancel(AbstractListenerReadPublisher<T> publisher) {}
/*     */   
/*     */   <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {}
/*     */   
/*     */   <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerReadPublisher$State$6.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */