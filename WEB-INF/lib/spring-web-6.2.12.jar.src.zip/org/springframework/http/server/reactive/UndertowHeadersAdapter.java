/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import io.undertow.util.HeaderMap;
/*     */ import io.undertow.util.HeaderValues;
/*     */ import io.undertow.util.HttpString;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndertowHeadersAdapter
/*     */   implements MultiValueMap<String, String>
/*     */ {
/*     */   private final HeaderMap headers;
/*     */   
/*     */   UndertowHeadersAdapter(HeaderMap headers) {
/*  49 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirst(String key) {
/*  55 */     return this.headers.getFirst(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String key, @Nullable String value) {
/*  60 */     this.headers.add(HttpString.tryFromString(key), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(String key, List<? extends String> values) {
/*  66 */     this.headers.addAll(HttpString.tryFromString(key), values);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(MultiValueMap<String, String> values) {
/*  71 */     values.forEach((key, list) -> this.headers.addAll(HttpString.tryFromString(key), list));
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String key, @Nullable String value) {
/*  76 */     this.headers.put(HttpString.tryFromString(key), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Map<String, String> values) {
/*  81 */     values.forEach((key, list) -> this.headers.put(HttpString.tryFromString(key), list));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toSingleValueMap() {
/*  86 */     Map<String, String> singleValueMap = CollectionUtils.newLinkedHashMap(this.headers.size());
/*  87 */     this.headers.forEach(values -> singleValueMap.put(values.getHeaderName().toString(), values.getFirst()));
/*     */     
/*  89 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  94 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  99 */     return (this.headers.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 104 */     if (key instanceof String) { String headerName = (String)key; if (this.headers.contains(headerName)); }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 111 */     Objects.requireNonNull(this.headers); return (value instanceof String && this.headers.getHeaderNames().stream().map(this.headers::get)
/* 112 */       .anyMatch(values -> values.contains(value)));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> get(Object key) {
/* 118 */     String headerName = (String)key; return (key instanceof String) ? (List<String>)this.headers.get(headerName) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> put(String key, List<String> value) {
/* 124 */     HeaderValues previousValues = this.headers.get(key);
/* 125 */     this.headers.putAll(HttpString.tryFromString(key), value);
/* 126 */     return (List<String>)previousValues;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> remove(Object key) {
/* 132 */     if (key instanceof String) { String headerName = (String)key;
/* 133 */       Collection<String> removed = this.headers.remove(headerName);
/* 134 */       if (removed != null) {
/* 135 */         return new ArrayList<>(removed);
/*     */       } }
/*     */     
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map) {
/* 143 */     map.forEach((key, values) -> this.headers.putAll(HttpString.tryFromString(key), values));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 149 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 154 */     return new HeaderNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<List<String>> values() {
/* 160 */     Objects.requireNonNull(this.headers); return (Collection<List<String>>)this.headers.getHeaderNames().stream().map(this.headers::get)
/* 161 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 166 */     return new AbstractSet<Map.Entry<String, List<String>>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, List<String>>> iterator() {
/* 169 */           return new UndertowHeadersAdapter.EntryIterator();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 174 */           return UndertowHeadersAdapter.this.headers.size();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 182 */     return HttpHeaders.formatHeaders(this);
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<String, List<String>>>
/*     */   {
/* 188 */     private final Iterator<HttpString> names = UndertowHeadersAdapter.this.headers.getHeaderNames().iterator();
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 192 */       return this.names.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, List<String>> next() {
/* 197 */       return new UndertowHeadersAdapter.HeaderEntry(this.names.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private class HeaderEntry
/*     */     implements Map.Entry<String, List<String>>
/*     */   {
/*     */     private final HttpString key;
/*     */     
/*     */     HeaderEntry(HttpString key) {
/* 207 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 212 */       return this.key.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getValue() {
/* 217 */       return (List<String>)UndertowHeadersAdapter.this.headers.get(this.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> setValue(List<String> value) {
/* 222 */       HeaderValues headerValues = UndertowHeadersAdapter.this.headers.get(this.key);
/* 223 */       UndertowHeadersAdapter.this.headers.putAll(this.key, value);
/* 224 */       return (List<String>)headerValues;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class HeaderNames
/*     */     extends AbstractSet<String>
/*     */   {
/*     */     public Iterator<String> iterator() {
/* 233 */       return new UndertowHeadersAdapter.HeaderNamesIterator(UndertowHeadersAdapter.this.headers.getHeaderNames().iterator());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 238 */       return UndertowHeadersAdapter.this.headers.getHeaderNames().size();
/*     */     }
/*     */   }
/*     */   
/*     */   private final class HeaderNamesIterator
/*     */     implements Iterator<String>
/*     */   {
/*     */     private final Iterator<HttpString> iterator;
/*     */     @Nullable
/*     */     private String currentName;
/*     */     
/*     */     private HeaderNamesIterator(Iterator<HttpString> iterator) {
/* 250 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 255 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 260 */       this.currentName = ((HttpString)this.iterator.next()).toString();
/* 261 */       return this.currentName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 266 */       if (this.currentName == null) {
/* 267 */         throw new IllegalStateException("No current Header in iterator");
/*     */       }
/* 269 */       if (!UndertowHeadersAdapter.this.headers.contains(this.currentName)) {
/* 270 */         throw new IllegalStateException("Header not present: " + this.currentName);
/*     */       }
/* 272 */       UndertowHeadersAdapter.this.headers.remove(this.currentName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\UndertowHeadersAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */