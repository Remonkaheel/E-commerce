/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerHttpResponseDecorator
/*     */   implements ServerHttpResponse
/*     */ {
/*     */   private final ServerHttpResponse delegate;
/*     */   
/*     */   public ServerHttpResponseDecorator(ServerHttpResponse delegate) {
/*  46 */     Assert.notNull(delegate, "Delegate is required");
/*  47 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpResponse getDelegate() {
/*  52 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setStatusCode(@Nullable HttpStatusCode status) {
/*  60 */     return getDelegate().setStatusCode(status);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HttpStatusCode getStatusCode() {
/*  66 */     return getDelegate().getStatusCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setRawStatusCode(@Nullable Integer value) {
/*  71 */     return getDelegate().setRawStatusCode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Integer getRawStatusCode() {
/*  79 */     return getDelegate().getRawStatusCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  84 */     return getDelegate().getHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies() {
/*  89 */     return getDelegate().getCookies();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCookie(ResponseCookie cookie) {
/*  94 */     getDelegate().addCookie(cookie);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  99 */     return getDelegate().bufferFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCommit(Supplier<? extends Mono<Void>> action) {
/* 104 */     getDelegate().beforeCommit(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCommitted() {
/* 109 */     return getDelegate().isCommitted();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 114 */     return getDelegate().writeWith(body);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 119 */     return getDelegate().writeAndFlushWith(body);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 124 */     return getDelegate().setComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getNativeResponse(ServerHttpResponse response) {
/* 137 */     if (response instanceof AbstractServerHttpResponse) { AbstractServerHttpResponse abstractServerHttpResponse = (AbstractServerHttpResponse)response;
/* 138 */       return abstractServerHttpResponse.getNativeResponse(); }
/*     */     
/* 140 */     if (response instanceof ServerHttpResponseDecorator) { ServerHttpResponseDecorator serverHttpResponseDecorator = (ServerHttpResponseDecorator)response;
/* 141 */       return getNativeResponse(serverHttpResponseDecorator.getDelegate()); }
/*     */ 
/*     */     
/* 144 */     throw new IllegalArgumentException("Can't find native response in " + response
/* 145 */         .getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return getClass().getSimpleName() + " [delegate=" + getClass().getSimpleName() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\ServerHttpResponseDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */