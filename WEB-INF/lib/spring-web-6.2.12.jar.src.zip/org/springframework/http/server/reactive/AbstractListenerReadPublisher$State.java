/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Operators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum State
/*     */ {
/* 314 */   UNSUBSCRIBED
/*     */   {
/*     */     <T> void subscribe(AbstractListenerReadPublisher<T> publisher, Subscriber<? super T> subscriber) {
/* 317 */       Assert.notNull(publisher, "Publisher must not be null");
/* 318 */       Assert.notNull(subscriber, "Subscriber must not be null");
/* 319 */       if (publisher.changeState(this, SUBSCRIBING)) {
/* 320 */         Subscription subscription = publisher.createSubscription();
/* 321 */         publisher.subscriber = subscriber;
/* 322 */         subscriber.onSubscribe(subscription);
/* 323 */         publisher.changeState(SUBSCRIBING, NO_DEMAND);
/* 324 */         publisher.handlePendingCompletionOrError();
/*     */       } else {
/*     */         
/* 327 */         throw new IllegalStateException("Failed to transition to SUBSCRIBING, subscriber: " + String.valueOf(subscriber));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 334 */       publisher.completionPending = true;
/* 335 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 340 */       publisher.errorPending = ex;
/* 341 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   SUBSCRIBING
/*     */   {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 352 */       if (Operators.validate(n)) {
/* 353 */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/* 354 */         publisher.changeToDemandState(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 360 */       publisher.completionPending = true;
/* 361 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 366 */       publisher.errorPending = ex;
/* 367 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 372 */       publisher.completionPending = true;
/* 373 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   },
/*     */   
/* 377 */   NO_DEMAND
/*     */   {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 380 */       if (Operators.validate(n)) {
/* 381 */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/* 382 */         publisher.changeToDemandState(this);
/*     */       }
/*     */     
/*     */     }
/*     */   },
/* 387 */   DEMAND
/*     */   {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 390 */       if (Operators.validate(n)) {
/* 391 */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         
/* 393 */         publisher.changeToDemandState(NO_DEMAND);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onDataAvailable(AbstractListenerReadPublisher<T> publisher) {
/* 399 */       if (publisher.changeState(this, READING)) {
/*     */         try {
/* 401 */           boolean demandAvailable = publisher.readAndPublish();
/* 402 */           if (demandAvailable) {
/* 403 */             publisher.changeToDemandState(READING);
/* 404 */             publisher.handlePendingCompletionOrError();
/*     */           } else {
/*     */             
/* 407 */             publisher.readingPaused();
/* 408 */             if (publisher.changeState(READING, NO_DEMAND) && 
/* 409 */               !publisher.handlePendingCompletionOrError())
/*     */             {
/* 411 */               long r = publisher.demand;
/* 412 */               if (r > 0L) {
/* 413 */                 publisher.changeToDemandState(NO_DEMAND);
/*     */               }
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 419 */         } catch (IOException ex) {
/* 420 */           publisher.onError(ex);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     }
/*     */   },
/* 427 */   READING
/*     */   {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 430 */       if (Operators.validate(n)) {
/* 431 */         Operators.addCap(AbstractListenerReadPublisher.DEMAND_FIELD_UPDATER, publisher, n);
/*     */         
/* 433 */         publisher.changeToDemandState(NO_DEMAND);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 439 */       publisher.completionPending = true;
/* 440 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable ex) {
/* 445 */       publisher.errorPending = ex;
/* 446 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */ 
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 451 */       publisher.discardData();
/* 452 */       publisher.completionPending = true;
/* 453 */       publisher.handlePendingCompletionOrError();
/*     */     }
/*     */   },
/*     */   
/* 457 */   COMPLETED
/*     */   {
/*     */     <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     <T> void cancel(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */ 
/*     */     
/*     */     <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */ 
/*     */     
/*     */     <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {}
/*     */   };
/*     */ 
/*     */ 
/*     */   
/*     */   <T> void subscribe(AbstractListenerReadPublisher<T> publisher, Subscriber<? super T> subscriber) {
/* 477 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   <T> void request(AbstractListenerReadPublisher<T> publisher, long n) {
/* 481 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   <T> void cancel(AbstractListenerReadPublisher<T> publisher) {
/* 485 */     if (publisher.changeState(this, COMPLETED)) {
/* 486 */       publisher.discardData();
/*     */     } else {
/*     */       
/* 489 */       ((State)publisher.state.get()).cancel(publisher);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   <T> void onDataAvailable(AbstractListenerReadPublisher<T> publisher) {}
/*     */ 
/*     */   
/*     */   <T> void onAllDataRead(AbstractListenerReadPublisher<T> publisher) {
/* 498 */     if (publisher.changeState(this, COMPLETED)) {
/* 499 */       Subscriber<? super T> s = publisher.subscriber;
/* 500 */       if (s != null) {
/* 501 */         s.onComplete();
/*     */       }
/*     */     } else {
/*     */       
/* 505 */       ((State)publisher.state.get()).onAllDataRead(publisher);
/*     */     } 
/*     */   }
/*     */   
/*     */   <T> void onError(AbstractListenerReadPublisher<T> publisher, Throwable t) {
/* 510 */     if (publisher.changeState(this, COMPLETED)) {
/* 511 */       publisher.discardData();
/* 512 */       Subscriber<? super T> s = publisher.subscriber;
/* 513 */       if (s != null) {
/* 514 */         s.onError(t);
/*     */       }
/*     */     } else {
/*     */       
/* 518 */       ((State)publisher.state.get()).onError(publisher, t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerReadPublisher$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */