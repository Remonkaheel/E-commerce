/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ 
/*     */ enum null {
/*     */   public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {}
/*     */   
/*     */   public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable t) {}
/*     */   
/*     */   public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteFlushProcessor$State$5.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */