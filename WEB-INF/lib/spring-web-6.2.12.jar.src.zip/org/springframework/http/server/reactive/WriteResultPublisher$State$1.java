/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   void subscribe(WriteResultPublisher publisher, Subscriber<? super Void> subscriber) {
/* 164 */     Assert.notNull(subscriber, "Subscriber must not be null");
/* 165 */     if (publisher.changeState(this, SUBSCRIBING)) {
/* 166 */       Subscription subscription = new WriteResultPublisher.WriteResultSubscription(publisher);
/* 167 */       publisher.subscriber = subscriber;
/* 168 */       subscriber.onSubscribe(subscription);
/* 169 */       publisher.changeState(SUBSCRIBING, SUBSCRIBED);
/*     */       
/* 171 */       if (publisher.completedBeforeSubscribed) {
/* 172 */         ((WriteResultPublisher.State)publisher.state.get()).publishComplete(publisher);
/*     */       }
/* 174 */       Throwable ex = publisher.errorBeforeSubscribed;
/* 175 */       if (ex != null) {
/* 176 */         ((WriteResultPublisher.State)publisher.state.get()).publishError(publisher, ex);
/*     */       }
/*     */     } else {
/*     */       
/* 180 */       throw new IllegalStateException(toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   void publishComplete(WriteResultPublisher publisher) {
/* 185 */     publisher.completedBeforeSubscribed = true;
/* 186 */     if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get()) {
/* 187 */       ((WriteResultPublisher.State)publisher.state.get()).publishComplete(publisher);
/*     */     }
/*     */   }
/*     */   
/*     */   void publishError(WriteResultPublisher publisher, Throwable ex) {
/* 192 */     publisher.errorBeforeSubscribed = ex;
/* 193 */     if (WriteResultPublisher.State.SUBSCRIBED == publisher.state.get())
/* 194 */       ((WriteResultPublisher.State)publisher.state.get()).publishError(publisher, ex); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\WriteResultPublisher$State$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */