/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.eclipse.jetty.server.Handler;
/*    */ import org.eclipse.jetty.server.Request;
/*    */ import org.eclipse.jetty.server.Response;
/*    */ import org.eclipse.jetty.util.Callback;
/*    */ import org.springframework.core.io.buffer.JettyDataBufferFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JettyCoreHttpHandlerAdapter
/*    */   extends Handler.Abstract.NonBlocking
/*    */ {
/*    */   private final HttpHandler httpHandler;
/* 39 */   private JettyDataBufferFactory dataBufferFactory = new JettyDataBufferFactory();
/*    */ 
/*    */   
/*    */   public JettyCoreHttpHandlerAdapter(HttpHandler httpHandler) {
/* 43 */     this.httpHandler = httpHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDataBufferFactory(JettyDataBufferFactory dataBufferFactory) {
/* 48 */     Assert.notNull(dataBufferFactory, "DataBufferFactory must not be null");
/* 49 */     this.dataBufferFactory = dataBufferFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handle(Request request, Response response, Callback callback) throws Exception {
/* 57 */     Objects.requireNonNull(callback); Objects.requireNonNull(callback); this.httpHandler.handle(new JettyCoreServerHttpRequest(request, this.dataBufferFactory), new JettyCoreServerHttpResponse(response, this.dataBufferFactory)).subscribe(unused -> {  }callback::failed, callback::succeeded);
/* 58 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\JettyCoreHttpHandlerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */