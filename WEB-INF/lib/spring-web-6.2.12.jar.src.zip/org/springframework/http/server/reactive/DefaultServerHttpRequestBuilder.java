/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultServerHttpRequestBuilder
/*     */   implements ServerHttpRequest.Builder
/*     */ {
/*     */   private URI uri;
/*     */   private final HttpHeaders headers;
/*     */   private HttpMethod httpMethod;
/*     */   @Nullable
/*     */   private String uriPath;
/*     */   @Nullable
/*     */   private String contextPath;
/*     */   @Nullable
/*     */   private SslInfo sslInfo;
/*     */   @Nullable
/*     */   private InetSocketAddress remoteAddress;
/*     */   private final Flux<DataBuffer> body;
/*     */   private final ServerHttpRequest originalRequest;
/*     */   
/*     */   public DefaultServerHttpRequestBuilder(ServerHttpRequest original) {
/*  70 */     Assert.notNull(original, "ServerHttpRequest is required");
/*     */     
/*  72 */     this.uri = original.getURI();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.headers = new HttpHeaders();
/*  78 */     this.headers.addAll((MultiValueMap)original.getHeaders());
/*  79 */     this.httpMethod = original.getMethod();
/*  80 */     this.contextPath = original.getPath().contextPath().value();
/*  81 */     this.remoteAddress = original.getRemoteAddress();
/*  82 */     this.body = original.getBody();
/*  83 */     this.originalRequest = original;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder method(HttpMethod httpMethod) {
/*  89 */     Assert.notNull(httpMethod, "HttpMethod must not be null");
/*  90 */     this.httpMethod = httpMethod;
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder uri(URI uri) {
/*  96 */     this.uri = uri;
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder path(String path) {
/* 102 */     Assert.isTrue(path.startsWith("/"), () -> "The path does not have a leading slash: " + path);
/* 103 */     this.uriPath = path;
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder contextPath(String contextPath) {
/* 109 */     this.contextPath = contextPath;
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder header(String headerName, String... headerValues) {
/* 115 */     this.headers.put(headerName, Arrays.asList(headerValues));
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) {
/* 121 */     Assert.notNull(headersConsumer, "'headersConsumer' must not be null");
/* 122 */     headersConsumer.accept(this.headers);
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder sslInfo(SslInfo sslInfo) {
/* 128 */     this.sslInfo = sslInfo;
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest.Builder remoteAddress(InetSocketAddress remoteAddress) {
/* 134 */     this.remoteAddress = remoteAddress;
/* 135 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest build() {
/* 140 */     return new MutatedServerHttpRequest(getUriToUse(), this.contextPath, this.httpMethod, this.sslInfo, this.remoteAddress, this.headers, this.body, this.originalRequest);
/*     */   }
/*     */ 
/*     */   
/*     */   private URI getUriToUse() {
/* 145 */     if (this.uriPath == null) {
/* 146 */       return this.uri;
/*     */     }
/*     */     
/* 149 */     StringBuilder uriBuilder = new StringBuilder();
/* 150 */     if (this.uri.getScheme() != null) {
/* 151 */       uriBuilder.append(this.uri.getScheme()).append(':');
/*     */     }
/* 153 */     if (this.uri.getRawUserInfo() != null || this.uri.getHost() != null) {
/* 154 */       uriBuilder.append("//");
/* 155 */       if (this.uri.getRawUserInfo() != null) {
/* 156 */         uriBuilder.append(this.uri.getRawUserInfo()).append('@');
/*     */       }
/* 158 */       if (this.uri.getHost() != null) {
/* 159 */         uriBuilder.append(this.uri.getHost());
/*     */       }
/* 161 */       if (this.uri.getPort() != -1) {
/* 162 */         uriBuilder.append(':').append(this.uri.getPort());
/*     */       }
/*     */     } 
/* 165 */     if (StringUtils.hasLength(this.uriPath)) {
/* 166 */       uriBuilder.append(this.uriPath);
/*     */     }
/* 168 */     if (this.uri.getRawQuery() != null) {
/* 169 */       uriBuilder.append('?').append(this.uri.getRawQuery());
/*     */     }
/* 171 */     if (this.uri.getRawFragment() != null) {
/* 172 */       uriBuilder.append('#').append(this.uri.getRawFragment());
/*     */     }
/*     */     try {
/* 175 */       return new URI(uriBuilder.toString());
/*     */     }
/* 177 */     catch (URISyntaxException ex) {
/* 178 */       throw new IllegalStateException("Invalid URI path: \"" + this.uriPath + "\"", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MutatedServerHttpRequest
/*     */     extends AbstractServerHttpRequest
/*     */   {
/*     */     @Nullable
/*     */     private final SslInfo sslInfo;
/*     */     
/*     */     @Nullable
/*     */     private final InetSocketAddress remoteAddress;
/*     */     
/*     */     private final Flux<DataBuffer> body;
/*     */     
/*     */     private final ServerHttpRequest originalRequest;
/*     */ 
/*     */     
/*     */     public MutatedServerHttpRequest(URI uri, @Nullable String contextPath, HttpMethod method, @Nullable SslInfo sslInfo, @Nullable InetSocketAddress remoteAddress, HttpHeaders headers, Flux<DataBuffer> body, ServerHttpRequest originalRequest) {
/* 199 */       super(method, uri, contextPath, (MultiValueMap<String, String>)headers);
/* 200 */       this.remoteAddress = (remoteAddress != null) ? remoteAddress : originalRequest.getRemoteAddress();
/* 201 */       this.sslInfo = (sslInfo != null) ? sslInfo : originalRequest.getSslInfo();
/* 202 */       this.body = body;
/* 203 */       this.originalRequest = originalRequest;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MultiValueMap<String, HttpCookie> initCookies() {
/* 208 */       return this.originalRequest.getCookies();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public InetSocketAddress getLocalAddress() {
/* 214 */       return this.originalRequest.getLocalAddress();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public InetSocketAddress getRemoteAddress() {
/* 220 */       return this.remoteAddress;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected SslInfo initSslInfo() {
/* 226 */       return this.sslInfo;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<DataBuffer> getBody() {
/* 231 */       return this.body;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T getNativeRequest() {
/* 236 */       return ServerHttpRequestDecorator.getNativeRequest(this.originalRequest);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getId() {
/* 241 */       return this.originalRequest.getId();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\DefaultServerHttpRequestBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */