/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractServerHttpResponse
/*     */   implements ServerHttpResponse
/*     */ {
/*     */   private final DataBufferFactory dataBufferFactory;
/*     */   @Nullable
/*     */   private HttpStatusCode statusCode;
/*     */   private final HttpHeaders headers;
/*     */   private final MultiValueMap<String, ResponseCookie> cookies;
/*     */   
/*     */   private enum State
/*     */   {
/*  58 */     NEW, COMMITTING, COMMIT_ACTION_FAILED, COMMITTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private final AtomicReference<State> state = new AtomicReference<>(State.NEW);
/*     */   
/*  72 */   private final List<Supplier<? extends Mono<Void>>> commitActions = new CopyOnWriteArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   private HttpHeaders readOnlyHeaders;
/*     */ 
/*     */   
/*     */   public AbstractServerHttpResponse(DataBufferFactory dataBufferFactory) {
/*  79 */     this(dataBufferFactory, new HttpHeaders());
/*     */   }
/*     */   
/*     */   public AbstractServerHttpResponse(DataBufferFactory dataBufferFactory, HttpHeaders headers) {
/*  83 */     Assert.notNull(dataBufferFactory, "DataBufferFactory must not be null");
/*  84 */     Assert.notNull(headers, "HttpHeaders must not be null");
/*  85 */     this.dataBufferFactory = dataBufferFactory;
/*  86 */     this.headers = headers;
/*  87 */     this.cookies = (MultiValueMap<String, ResponseCookie>)new LinkedMultiValueMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final DataBufferFactory bufferFactory() {
/*  93 */     return this.dataBufferFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setStatusCode(@Nullable HttpStatusCode status) {
/*  98 */     if (this.state.get() == State.COMMITTED) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     this.statusCode = status;
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HttpStatusCode getStatusCode() {
/* 110 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setRawStatusCode(@Nullable Integer statusCode) {
/* 115 */     return setStatusCode((statusCode != null) ? HttpStatusCode.valueOf(statusCode.intValue()) : null);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 120 */     if (this.readOnlyHeaders != null) {
/* 121 */       return this.readOnlyHeaders;
/*     */     }
/* 123 */     if (this.state.get() == State.COMMITTED) {
/* 124 */       this.readOnlyHeaders = HttpHeaders.readOnlyHttpHeaders(this.headers);
/* 125 */       return this.readOnlyHeaders;
/*     */     } 
/*     */     
/* 128 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies() {
/* 134 */     return (this.state.get() == State.COMMITTED) ? 
/* 135 */       CollectionUtils.unmodifiableMultiValueMap(this.cookies) : this.cookies;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCookie(ResponseCookie cookie) {
/* 140 */     Assert.notNull(cookie, "ResponseCookie must not be null");
/*     */     
/* 142 */     if (this.state.get() == State.COMMITTED) {
/* 143 */       throw new IllegalStateException("Can't add the cookie " + String.valueOf(cookie) + "because the HTTP response has already been committed");
/*     */     }
/*     */ 
/*     */     
/* 147 */     getCookies().add(cookie.getName(), cookie);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeCommit(Supplier<? extends Mono<Void>> action) {
/* 161 */     this.commitActions.add(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCommitted() {
/* 166 */     State state = this.state.get();
/* 167 */     return (state != State.NEW && state != State.COMMIT_ACTION_FAILED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 175 */     if (body instanceof Mono) {
/* 176 */       return ((Mono)body)
/* 177 */         .flatMap(buffer -> {
/*     */             touchDataBuffer(buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             AtomicBoolean subscribed = new AtomicBoolean();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return doCommit(()).doOnError(()).doOnCancel(());
/* 198 */           }).doOnError(t -> getHeaders().clearContentHeaders())
/* 199 */         .doOnDiscard(DataBuffer.class, DataBufferUtils::release);
/*     */     }
/*     */     
/* 202 */     return (new ChannelSendOperator(body, inner -> doCommit(())))
/* 203 */       .doOnError(t -> getHeaders().clearContentHeaders());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 209 */     return (new ChannelSendOperator(body, inner -> doCommit(())))
/* 210 */       .doOnError(t -> getHeaders().clearContentHeaders());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 215 */     return !isCommitted() ? doCommit(null) : Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> doCommit() {
/* 223 */     return doCommit(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> doCommit(@Nullable Supplier<? extends Mono<Void>> writeAction) {
/* 233 */     Flux<Void> allActions = Flux.empty();
/* 234 */     if (this.state.compareAndSet(State.NEW, State.COMMITTING)) {
/* 235 */       if (!this.commitActions.isEmpty())
/*     */       {
/* 237 */         allActions = Flux.concat((Publisher)Flux.fromIterable(this.commitActions).map(Supplier::get)).doOnError(ex -> {
/*     */               
/*     */               if (this.state.compareAndSet(State.COMMITTING, State.COMMIT_ACTION_FAILED)) {
/*     */                 getHeaders().clearContentHeaders();
/*     */               }
/*     */             });
/*     */       }
/* 244 */     } else if (!this.state.compareAndSet(State.COMMIT_ACTION_FAILED, State.COMMITTING)) {
/*     */ 
/*     */ 
/*     */       
/* 248 */       return Mono.empty();
/*     */     } 
/*     */     
/* 251 */     allActions = allActions.concatWith((Publisher)Mono.fromRunnable(() -> {
/*     */             applyStatusCode();
/*     */             
/*     */             applyHeaders();
/*     */             applyCookies();
/*     */             this.state.set(State.COMMITTED);
/*     */           }));
/* 258 */     if (writeAction != null) {
/* 259 */       allActions = allActions.concatWith((Publisher)writeAction.get());
/*     */     }
/*     */     
/* 262 */     return allActions.then();
/*     */   }
/*     */   
/*     */   protected void touchDataBuffer(DataBuffer buffer) {}
/*     */   
/*     */   public abstract <T> T getNativeResponse();
/*     */   
/*     */   protected abstract Mono<Void> writeWithInternal(Publisher<? extends DataBuffer> paramPublisher);
/*     */   
/*     */   protected abstract Mono<Void> writeAndFlushWithInternal(Publisher<? extends Publisher<? extends DataBuffer>> paramPublisher);
/*     */   
/*     */   protected abstract void applyStatusCode();
/*     */   
/*     */   protected abstract void applyHeaders();
/*     */   
/*     */   protected abstract void applyCookies();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */