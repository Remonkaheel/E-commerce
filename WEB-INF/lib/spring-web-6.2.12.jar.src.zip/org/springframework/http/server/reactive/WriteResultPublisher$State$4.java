/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ enum null {
/*     */   void request(WriteResultPublisher publisher, long n) {}
/*     */   
/*     */   void cancel(WriteResultPublisher publisher) {}
/*     */   
/*     */   void publishComplete(WriteResultPublisher publisher) {}
/*     */   
/*     */   void publishError(WriteResultPublisher publisher, Throwable t) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\WriteResultPublisher$State$4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */