/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import org.reactivestreams.Processor;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum State
/*     */ {
/* 261 */   UNSUBSCRIBED
/*     */   {
/*     */     public <T> void onSubscribe(AbstractListenerWriteFlushProcessor<T> processor, Subscription subscription) {
/* 264 */       Assert.notNull(subscription, "Subscription must not be null");
/* 265 */       if (processor.changeState(this, REQUESTED)) {
/* 266 */         processor.subscription = subscription;
/* 267 */         subscription.request(1L);
/*     */       } else {
/*     */         
/* 270 */         super.onSubscribe(processor, subscription);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 277 */       if (processor.changeState(this, COMPLETED)) {
/* 278 */         processor.resultPublisher.publishComplete();
/*     */       } else {
/*     */         
/* 281 */         ((State)processor.state.get()).onComplete(processor);
/*     */       }
/*     */     
/*     */     }
/*     */   },
/* 286 */   REQUESTED
/*     */   {
/*     */     
/*     */     public <T> void onNext(AbstractListenerWriteFlushProcessor<T> processor, Publisher<? extends T> currentPublisher)
/*     */     {
/* 291 */       if (processor.changeState(this, RECEIVED)) {
/* 292 */         Processor<? super T, Void> writeProcessor = processor.createWriteProcessor();
/* 293 */         processor.currentWriteProcessor = (AbstractListenerWriteProcessor)writeProcessor;
/* 294 */         currentPublisher.subscribe((Subscriber)writeProcessor);
/* 295 */         writeProcessor.subscribe(new WriteResultSubscriber(processor));
/*     */       } 
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 300 */       if (processor.changeState(this, COMPLETED)) {
/* 301 */         processor.resultPublisher.publishComplete();
/*     */       } else {
/*     */         
/* 304 */         ((State)processor.state.get()).onComplete(processor);
/*     */       }
/*     */     
/*     */     }
/*     */   },
/* 309 */   RECEIVED
/*     */   {
/*     */     public <T> void writeComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/*     */       try {
/* 313 */         processor.flush();
/*     */       }
/* 315 */       catch (Throwable ex) {
/* 316 */         processor.flushingFailed(ex);
/*     */         return;
/*     */       } 
/* 319 */       if (processor.changeState(this, REQUESTED)) {
/* 320 */         if (processor.sourceCompleted) {
/* 321 */           handleSourceCompleted(processor);
/*     */         } else {
/*     */           
/* 324 */           Assert.state((processor.subscription != null), "No subscription");
/* 325 */           processor.subscription.request(1L);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 331 */       processor.sourceCompleted = true;
/*     */       
/* 333 */       if (processor.state.get() == State.REQUESTED) {
/* 334 */         handleSourceCompleted(processor);
/*     */       }
/*     */     }
/*     */     
/*     */     private <T> void handleSourceCompleted(AbstractListenerWriteFlushProcessor<T> processor) {
/* 339 */       if (processor.isFlushPending()) {
/*     */         
/* 341 */         processor.changeState(State.REQUESTED, State.FLUSHING);
/* 342 */         processor.flushIfPossible();
/*     */       }
/* 344 */       else if (processor.changeState(State.REQUESTED, State.COMPLETED)) {
/* 345 */         processor.resultPublisher.publishComplete();
/*     */       } else {
/*     */         
/* 348 */         ((State)processor.state.get()).onComplete(processor);
/*     */       }
/*     */     
/*     */     }
/*     */   },
/* 353 */   FLUSHING
/*     */   {
/*     */     public <T> void onFlushPossible(AbstractListenerWriteFlushProcessor<T> processor) {
/*     */       try {
/* 357 */         processor.flush();
/*     */       }
/* 359 */       catch (Throwable ex) {
/* 360 */         processor.flushingFailed(ex);
/*     */         return;
/*     */       } 
/* 363 */       if (processor.changeState(this, COMPLETED)) {
/* 364 */         processor.resultPublisher.publishComplete();
/*     */       } else {
/*     */         
/* 367 */         ((State)processor.state.get()).onComplete(processor);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */   },
/* 380 */   COMPLETED
/*     */   {
/*     */     public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable t) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */   };
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void onSubscribe(AbstractListenerWriteFlushProcessor<T> proc, Subscription subscription) {
/* 397 */     subscription.cancel();
/*     */   }
/*     */   
/*     */   public <T> void onNext(AbstractListenerWriteFlushProcessor<T> proc, Publisher<? extends T> pub) {
/* 401 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   public <T> void onError(AbstractListenerWriteFlushProcessor<T> processor, Throwable ex) {
/* 405 */     if (processor.changeState(this, COMPLETED)) {
/* 406 */       processor.resultPublisher.publishError(ex);
/*     */     } else {
/*     */       
/* 409 */       ((State)processor.state.get()).onError(processor, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public <T> void onComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 414 */     throw new IllegalStateException(toString());
/*     */   }
/*     */   
/*     */   public <T> void writeComplete(AbstractListenerWriteFlushProcessor<T> processor) {
/* 418 */     throw new IllegalStateException(toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void onFlushPossible(AbstractListenerWriteFlushProcessor<T> processor) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WriteResultSubscriber
/*     */     implements Subscriber<Void>
/*     */   {
/*     */     private final AbstractListenerWriteFlushProcessor<?> processor;
/*     */ 
/*     */ 
/*     */     
/*     */     public WriteResultSubscriber(AbstractListenerWriteFlushProcessor<?> processor) {
/* 436 */       this.processor = processor;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 441 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Void aVoid) {}
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 450 */       if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled()) {
/* 451 */         AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor
/* 452 */             .getLogPrefix() + "current \"write\" Publisher failed: " + this.processor.getLogPrefix());
/*     */       }
/* 454 */       this.processor.currentWriteProcessor = null;
/* 455 */       this.processor.cancel();
/* 456 */       this.processor.onError(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 461 */       if (AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.isTraceEnabled()) {
/* 462 */         AbstractListenerWriteFlushProcessor.rsWriteFlushLogger.trace(this.processor
/* 463 */             .getLogPrefix() + "current \"write\" Publisher completed");
/*     */       }
/* 465 */       this.processor.currentWriteProcessor = null;
/* 466 */       ((AbstractListenerWriteFlushProcessor.State)this.processor.state.get()).writeComplete(this.processor);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 471 */       return this.processor.getClass().getSimpleName() + "-WriteResultSubscriber";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\reactive\AbstractListenerWriteFlushProcessor$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */