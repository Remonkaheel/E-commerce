package org.springframework.http.server;

public interface Element {
  String value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\PathContainer$Element.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */