/*     */ package org.springframework.http.server.observation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultServerRequestObservationConvention
/*     */   implements ServerRequestObservationConvention
/*     */ {
/*     */   private static final String DEFAULT_NAME = "http.server.requests";
/*  45 */   private static final KeyValue METHOD_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, "UNKNOWN");
/*     */   
/*  47 */   private static final KeyValue STATUS_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, "UNKNOWN");
/*     */   
/*  49 */   private static final KeyValue HTTP_OUTCOME_SUCCESS = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "SUCCESS");
/*     */   
/*  51 */   private static final KeyValue HTTP_OUTCOME_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "UNKNOWN");
/*     */   
/*  53 */   private static final KeyValue URI_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "UNKNOWN");
/*     */   
/*  55 */   private static final KeyValue URI_ROOT = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "root");
/*     */   
/*  57 */   private static final KeyValue URI_NOT_FOUND = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "NOT_FOUND");
/*     */   
/*  59 */   private static final KeyValue URI_REDIRECTION = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, "REDIRECTION");
/*     */   
/*  61 */   private static final KeyValue EXCEPTION_NONE = KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, "none");
/*     */   
/*  63 */   private static final KeyValue HTTP_URL_UNKNOWN = KeyValue.of(ServerHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, "UNKNOWN");
/*     */   
/*  65 */   private static final Set<String> HTTP_METHODS = (Set<String>)Stream.<HttpMethod>of(HttpMethod.values()).map(HttpMethod::name).collect(Collectors.toUnmodifiableSet());
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultServerRequestObservationConvention() {
/*  75 */     this("http.server.requests");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultServerRequestObservationConvention(String name) {
/*  83 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  89 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getContextualName(ServerRequestObservationContext context) {
/*  95 */     if (context.getCarrier() != null) {
/*  96 */       String httpMethod = ((HttpServletRequest)context.getCarrier()).getMethod().toLowerCase(Locale.ROOT);
/*  97 */       return (context.getPathPattern() != null) ? ("http " + 
/*  98 */         httpMethod + " " + context.getPathPattern()) : ("http " + 
/*     */         
/* 100 */         httpMethod);
/*     */     } 
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getLowCardinalityKeyValues(ServerRequestObservationContext context) {
/* 108 */     return KeyValues.of(new KeyValue[] { exception(context), method(context), outcome(context), status(context), uri(context) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getHighCardinalityKeyValues(ServerRequestObservationContext context) {
/* 114 */     return KeyValues.of(new KeyValue[] { httpUrl(context) });
/*     */   }
/*     */   
/*     */   protected KeyValue method(ServerRequestObservationContext context) {
/* 118 */     if (context.getCarrier() != null) {
/* 119 */       String httpMethod = ((HttpServletRequest)context.getCarrier()).getMethod();
/* 120 */       if (HTTP_METHODS.contains(httpMethod)) {
/* 121 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, httpMethod);
/*     */       }
/*     */     } 
/* 124 */     return METHOD_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue status(ServerRequestObservationContext context) {
/* 128 */     return (context.getResponse() != null) ? 
/* 129 */       KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, Integer.toString(((HttpServletResponse)context.getResponse()).getStatus())) : 
/* 130 */       STATUS_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue uri(ServerRequestObservationContext context) {
/* 134 */     if (context.getCarrier() != null) {
/* 135 */       String pattern = context.getPathPattern();
/* 136 */       if (pattern != null) {
/* 137 */         if (pattern.isEmpty()) {
/* 138 */           return URI_ROOT;
/*     */         }
/* 140 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.URI, pattern);
/*     */       } 
/* 142 */       if (context.getResponse() != null) {
/* 143 */         HttpStatus status = HttpStatus.resolve(((HttpServletResponse)context.getResponse()).getStatus());
/* 144 */         if (status != null) {
/* 145 */           if (status.is3xxRedirection()) {
/* 146 */             return URI_REDIRECTION;
/*     */           }
/* 148 */           if (status == HttpStatus.NOT_FOUND) {
/* 149 */             return URI_NOT_FOUND;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     return URI_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue exception(ServerRequestObservationContext context) {
/* 158 */     Throwable error = context.getError();
/* 159 */     if (error != null) {
/* 160 */       String simpleName = error.getClass().getSimpleName();
/* 161 */       return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, 
/* 162 */           StringUtils.hasText(simpleName) ? simpleName : error.getClass().getName());
/*     */     } 
/* 164 */     return EXCEPTION_NONE;
/*     */   }
/*     */   
/*     */   protected KeyValue outcome(ServerRequestObservationContext context) {
/*     */     try {
/* 169 */       if (context.getResponse() != null) {
/* 170 */         HttpStatusCode statusCode = HttpStatusCode.valueOf(((HttpServletResponse)context.getResponse()).getStatus());
/* 171 */         return HttpOutcome.forStatus(statusCode);
/*     */       }
/*     */     
/* 174 */     } catch (IllegalArgumentException ex) {
/* 175 */       return HTTP_OUTCOME_UNKNOWN;
/*     */     } 
/* 177 */     return HTTP_OUTCOME_UNKNOWN;
/*     */   }
/*     */   
/*     */   protected KeyValue httpUrl(ServerRequestObservationContext context) {
/* 181 */     if (context.getCarrier() != null) {
/* 182 */       return KeyValue.of(ServerHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, ((HttpServletRequest)context.getCarrier()).getRequestURI());
/*     */     }
/* 184 */     return HTTP_URL_UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   static class HttpOutcome
/*     */   {
/*     */     static KeyValue forStatus(HttpStatusCode statusCode) {
/* 191 */       if (statusCode.is2xxSuccessful()) {
/* 192 */         return DefaultServerRequestObservationConvention.HTTP_OUTCOME_SUCCESS;
/*     */       }
/* 194 */       if (statusCode instanceof HttpStatus) { HttpStatus status = (HttpStatus)statusCode;
/* 195 */         return KeyValue.of(ServerHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, status.series().name()); }
/*     */ 
/*     */       
/* 198 */       return DefaultServerRequestObservationConvention.HTTP_OUTCOME_UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\observation\DefaultServerRequestObservationConvention.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */