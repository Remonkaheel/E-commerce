/*    */ package org.springframework.http.server.observation;
/*    */ 
/*    */ import io.micrometer.common.docs.KeyName;
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationConvention;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   public Class<? extends ObservationConvention<? extends Observation.Context>> getDefaultConvention() {
/* 43 */     return (Class)DefaultServerRequestObservationConvention.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyName[] getLowCardinalityKeyNames() {
/* 48 */     return (KeyName[])ServerHttpObservationDocumentation.LowCardinalityKeyNames.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyName[] getHighCardinalityKeyNames() {
/* 53 */     return (KeyName[])ServerHttpObservationDocumentation.HighCardinalityKeyNames.values();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\observation\ServerHttpObservationDocumentation$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */