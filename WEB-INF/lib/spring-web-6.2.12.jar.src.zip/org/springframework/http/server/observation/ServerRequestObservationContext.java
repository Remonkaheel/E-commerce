/*    */ package org.springframework.http.server.observation;
/*    */ 
/*    */ import io.micrometer.observation.transport.RequestReplyReceiverContext;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerRequestObservationContext
/*    */   extends RequestReplyReceiverContext<HttpServletRequest, HttpServletResponse>
/*    */ {
/*    */   @Nullable
/*    */   private String pathPattern;
/*    */   
/*    */   public ServerRequestObservationContext(HttpServletRequest request, HttpServletResponse response) {
/* 40 */     super(HttpServletRequest::getHeader);
/* 41 */     setCarrier(request);
/* 42 */     setResponse(response);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getPathPattern() {
/* 47 */     return this.pathPattern;
/*    */   }
/*    */   
/*    */   public void setPathPattern(@Nullable String pathPattern) {
/* 51 */     this.pathPattern = pathPattern;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\observation\ServerRequestObservationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */