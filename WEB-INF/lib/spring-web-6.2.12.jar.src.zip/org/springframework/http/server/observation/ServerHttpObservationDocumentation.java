/*     */ package org.springframework.http.server.observation;
/*     */ 
/*     */ import io.micrometer.common.docs.KeyName;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.docs.ObservationDocumentation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ServerHttpObservationDocumentation
/*     */   implements ObservationDocumentation
/*     */ {
/*  40 */   HTTP_SERVLET_SERVER_REQUESTS
/*     */   {
/*     */     public Class<? extends ObservationConvention<? extends Observation.Context>> getDefaultConvention() {
/*  43 */       return (Class)DefaultServerRequestObservationConvention.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public KeyName[] getLowCardinalityKeyNames() {
/*  48 */       return (KeyName[])LowCardinalityKeyNames.values();
/*     */     }
/*     */ 
/*     */     
/*     */     public KeyName[] getHighCardinalityKeyNames() {
/*  53 */       return (KeyName[])HighCardinalityKeyNames.values();
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum LowCardinalityKeyNames
/*     */     implements KeyName
/*     */   {
/*  64 */     METHOD
/*     */     {
/*     */       public String asString() {
/*  67 */         return "method";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     STATUS
/*     */     {
/*     */       public String asString() {
/*  79 */         return "status";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     URI
/*     */     {
/*     */       public String asString() {
/*  92 */         return "uri";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     EXCEPTION
/*     */     {
/*     */       public String asString() {
/* 103 */         return "exception";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     OUTCOME
/*     */     {
/*     */       public String asString() {
/* 114 */         return "outcome"; } }; } enum null { public String asString() { return "method"; } } enum null { public String asString() { return "status"; } } enum null { public String asString() { return "uri"; } } enum null { public String asString() { return "exception"; } } enum null { public String asString() { return "outcome"; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum HighCardinalityKeyNames
/*     */     implements KeyName
/*     */   {
/* 124 */     HTTP_URL
/*     */     {
/*     */       public String asString() {
/* 127 */         return "http.url"; } }; } enum null { public String asString() { return "http.url"; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\observation\ServerHttpObservationDocumentation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */