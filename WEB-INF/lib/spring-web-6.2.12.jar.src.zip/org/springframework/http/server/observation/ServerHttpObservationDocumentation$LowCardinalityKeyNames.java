/*     */ package org.springframework.http.server.observation;
/*     */ 
/*     */ import io.micrometer.common.docs.KeyName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum LowCardinalityKeyNames
/*     */   implements KeyName
/*     */ {
/*  64 */   METHOD
/*     */   {
/*     */     public String asString() {
/*  67 */       return "method";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   STATUS
/*     */   {
/*     */     public String asString() {
/*  79 */       return "status";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   URI
/*     */   {
/*     */     public String asString() {
/*  92 */       return "uri";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   EXCEPTION
/*     */   {
/*     */     public String asString() {
/* 103 */       return "exception";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   OUTCOME
/*     */   {
/*     */     public String asString() {
/* 114 */       return "outcome";
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\observation\ServerHttpObservationDocumentation$LowCardinalityKeyNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */