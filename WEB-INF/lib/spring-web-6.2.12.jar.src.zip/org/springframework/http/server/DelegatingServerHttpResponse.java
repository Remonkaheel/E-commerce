/*    */ package org.springframework.http.server;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingServerHttpResponse
/*    */   implements ServerHttpResponse
/*    */ {
/*    */   private final ServerHttpResponse delegate;
/*    */   
/*    */   public DelegatingServerHttpResponse(ServerHttpResponse delegate) {
/* 42 */     Assert.notNull(delegate, "Delegate must not be null");
/* 43 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerHttpResponse getDelegate() {
/* 51 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStatusCode(HttpStatusCode status) {
/* 56 */     this.delegate.setStatusCode(status);
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {
/* 61 */     this.delegate.flush();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 66 */     this.delegate.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public OutputStream getBody() throws IOException {
/* 71 */     return this.delegate.getBody();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders getHeaders() {
/* 76 */     return this.delegate.getHeaders();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\DelegatingServerHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */