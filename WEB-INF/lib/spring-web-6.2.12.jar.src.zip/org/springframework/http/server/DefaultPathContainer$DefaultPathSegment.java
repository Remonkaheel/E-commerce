/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultPathSegment
/*     */   implements PathContainer.PathSegment
/*     */ {
/* 225 */   private static final MultiValueMap<String, String> EMPTY_PARAMS = CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)new LinkedMultiValueMap());
/*     */ 
/*     */   
/*     */   private final String value;
/*     */ 
/*     */   
/*     */   private final String valueToMatch;
/*     */ 
/*     */   
/*     */   private final MultiValueMap<String, String> parameters;
/*     */ 
/*     */   
/*     */   static DefaultPathSegment from(String value, DefaultPathContainer.DefaultSeparator separator) {
/* 238 */     String valueToMatch = value.contains(separator.encodedSequence()) ? value.replaceAll(separator.encodedSequence(), separator.value()) : value;
/* 239 */     return from(value, valueToMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DefaultPathSegment from(String value, String valueToMatch) {
/* 246 */     return new DefaultPathSegment(value, valueToMatch, EMPTY_PARAMS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DefaultPathSegment from(String value, String valueToMatch, MultiValueMap<String, String> params) {
/* 253 */     return new DefaultPathSegment(value, valueToMatch, CollectionUtils.unmodifiableMultiValueMap(params));
/*     */   }
/*     */   
/*     */   private DefaultPathSegment(String value, String valueToMatch, MultiValueMap<String, String> params) {
/* 257 */     this.value = value;
/* 258 */     this.valueToMatch = valueToMatch;
/* 259 */     this.parameters = params;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String value() {
/* 265 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String valueToMatch() {
/* 270 */     return this.valueToMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] valueToMatchAsChars() {
/* 275 */     return this.valueToMatch.toCharArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, String> parameters() {
/* 280 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 285 */     if (this != other) { if (other instanceof PathContainer.PathSegment) { PathContainer.PathSegment that = (PathContainer.PathSegment)other; if (this.value.equals(that.value())); }  return false; }
/*     */   
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 290 */     return this.value.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 295 */     return "[value='" + this.value + "']";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\DefaultPathContainer$DefaultPathSegment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */