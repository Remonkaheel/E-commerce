/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultPathContainer
/*     */   implements PathContainer
/*     */ {
/*  44 */   private static final PathContainer EMPTY_PATH = new DefaultPathContainer("", Collections.emptyList());
/*     */   
/*  46 */   private static final Map<Character, DefaultSeparator> SEPARATORS = new HashMap<>(2); private final String path;
/*     */   
/*     */   static {
/*  49 */     SEPARATORS.put(Character.valueOf('/'), new DefaultSeparator('/', "%2F"));
/*  50 */     SEPARATORS.put(Character.valueOf('.'), new DefaultSeparator('.', "%2E"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<PathContainer.Element> elements;
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultPathContainer(String path, List<PathContainer.Element> elements) {
/*  60 */     this.path = path;
/*  61 */     this.elements = Collections.unmodifiableList(elements);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String value() {
/*  67 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PathContainer.Element> elements() {
/*  72 */     return this.elements;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  78 */     if (this != other) { if (other instanceof PathContainer) { PathContainer that = (PathContainer)other; if (value().equals(that.value())); }  return false; }
/*     */   
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  83 */     return this.path.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     return value();
/*     */   }
/*     */   
/*     */   static PathContainer createFromUrlPath(String path, PathContainer.Options options) {
/*     */     int begin;
/*  93 */     if (path.isEmpty()) {
/*  94 */       return EMPTY_PATH;
/*     */     }
/*  96 */     char separator = options.separator();
/*  97 */     DefaultSeparator separatorElement = SEPARATORS.get(Character.valueOf(separator));
/*  98 */     if (separatorElement == null) {
/*  99 */       throw new IllegalArgumentException("Unexpected separator: '" + separator + "'");
/*     */     }
/* 101 */     List<PathContainer.Element> elements = new ArrayList<>();
/*     */     
/* 103 */     if (path.charAt(0) == separator) {
/* 104 */       begin = 1;
/* 105 */       elements.add(separatorElement);
/*     */     } else {
/*     */       
/* 108 */       begin = 0;
/*     */     } 
/* 110 */     while (begin < path.length()) {
/* 111 */       int end = path.indexOf(separator, begin);
/* 112 */       String segment = (end != -1) ? path.substring(begin, end) : path.substring(begin);
/* 113 */       if (!segment.isEmpty()) {
/* 114 */         elements.add(options.shouldDecodeAndParseSegments() ? 
/* 115 */             decodeAndParsePathSegment(segment) : 
/* 116 */             DefaultPathSegment.from(segment, separatorElement));
/*     */       }
/* 118 */       if (end == -1) {
/*     */         break;
/*     */       }
/* 121 */       elements.add(separatorElement);
/* 122 */       begin = end + 1;
/*     */     } 
/* 124 */     return new DefaultPathContainer(path, elements);
/*     */   }
/*     */   
/*     */   private static PathContainer.PathSegment decodeAndParsePathSegment(String segment) {
/* 128 */     Charset charset = StandardCharsets.UTF_8;
/* 129 */     int index = segment.indexOf(';');
/* 130 */     if (index == -1) {
/* 131 */       String str = StringUtils.uriDecode(segment, charset);
/* 132 */       return DefaultPathSegment.from(segment, str);
/*     */     } 
/*     */     
/* 135 */     String valueToMatch = StringUtils.uriDecode(segment.substring(0, index), charset);
/* 136 */     String pathParameterContent = segment.substring(index);
/* 137 */     MultiValueMap<String, String> parameters = parsePathParams(pathParameterContent, charset);
/* 138 */     return DefaultPathSegment.from(segment, valueToMatch, parameters);
/*     */   }
/*     */ 
/*     */   
/*     */   private static MultiValueMap<String, String> parsePathParams(String input, Charset charset) {
/* 143 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 144 */     int begin = 1;
/* 145 */     while (begin < input.length()) {
/* 146 */       int end = input.indexOf(';', begin);
/* 147 */       String param = (end != -1) ? input.substring(begin, end) : input.substring(begin);
/* 148 */       parsePathParamValues(param, charset, (MultiValueMap<String, String>)linkedMultiValueMap);
/* 149 */       if (end == -1) {
/*     */         break;
/*     */       }
/* 152 */       begin = end + 1;
/*     */     } 
/* 154 */     return (MultiValueMap<String, String>)linkedMultiValueMap;
/*     */   }
/*     */   
/*     */   private static void parsePathParamValues(String input, Charset charset, MultiValueMap<String, String> output) {
/* 158 */     if (StringUtils.hasText(input)) {
/* 159 */       int index = input.indexOf('=');
/* 160 */       if (index != -1) {
/* 161 */         String name = input.substring(0, index);
/* 162 */         name = StringUtils.uriDecode(name, charset);
/* 163 */         if (StringUtils.hasText(name)) {
/* 164 */           String value = input.substring(index + 1);
/* 165 */           for (String v : StringUtils.commaDelimitedListToStringArray(value)) {
/* 166 */             output.add(name, StringUtils.uriDecode(v, charset));
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 171 */         String name = StringUtils.uriDecode(input, charset);
/* 172 */         if (StringUtils.hasText(name)) {
/* 173 */           output.add(input, "");
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static PathContainer subPath(PathContainer container, int fromIndex, int toIndex) {
/* 180 */     List<PathContainer.Element> elements = container.elements();
/* 181 */     if (fromIndex == 0 && toIndex == elements.size()) {
/* 182 */       return container;
/*     */     }
/* 184 */     if (fromIndex == toIndex) {
/* 185 */       return EMPTY_PATH;
/*     */     }
/*     */     
/* 188 */     Assert.isTrue((fromIndex >= 0 && fromIndex < elements.size()), () -> "Invalid fromIndex: " + fromIndex);
/* 189 */     Assert.isTrue((toIndex >= 0 && toIndex <= elements.size()), () -> "Invalid toIndex: " + toIndex);
/* 190 */     Assert.isTrue((fromIndex < toIndex), () -> "fromIndex: " + fromIndex + " should be < toIndex " + toIndex);
/*     */     
/* 192 */     List<PathContainer.Element> subList = elements.subList(fromIndex, toIndex);
/* 193 */     String path = subList.stream().map(PathContainer.Element::value).collect(Collectors.joining(""));
/* 194 */     return new DefaultPathContainer(path, subList);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultSeparator
/*     */     implements PathContainer.Separator
/*     */   {
/*     */     private final String separator;
/*     */     
/*     */     private final String encodedSequence;
/*     */     
/*     */     DefaultSeparator(char separator, String encodedSequence) {
/* 206 */       this.separator = String.valueOf(separator);
/* 207 */       this.encodedSequence = encodedSequence;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String value() {
/* 213 */       return this.separator;
/*     */     }
/*     */     
/*     */     public String encodedSequence() {
/* 217 */       return this.encodedSequence;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DefaultPathSegment
/*     */     implements PathContainer.PathSegment
/*     */   {
/* 225 */     private static final MultiValueMap<String, String> EMPTY_PARAMS = CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)new LinkedMultiValueMap());
/*     */ 
/*     */     
/*     */     private final String value;
/*     */ 
/*     */     
/*     */     private final String valueToMatch;
/*     */ 
/*     */     
/*     */     private final MultiValueMap<String, String> parameters;
/*     */ 
/*     */     
/*     */     static DefaultPathSegment from(String value, DefaultPathContainer.DefaultSeparator separator) {
/* 238 */       String valueToMatch = value.contains(separator.encodedSequence()) ? value.replaceAll(separator.encodedSequence(), separator.value()) : value;
/* 239 */       return from(value, valueToMatch);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static DefaultPathSegment from(String value, String valueToMatch) {
/* 246 */       return new DefaultPathSegment(value, valueToMatch, EMPTY_PARAMS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static DefaultPathSegment from(String value, String valueToMatch, MultiValueMap<String, String> params) {
/* 253 */       return new DefaultPathSegment(value, valueToMatch, CollectionUtils.unmodifiableMultiValueMap(params));
/*     */     }
/*     */     
/*     */     private DefaultPathSegment(String value, String valueToMatch, MultiValueMap<String, String> params) {
/* 257 */       this.value = value;
/* 258 */       this.valueToMatch = valueToMatch;
/* 259 */       this.parameters = params;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String value() {
/* 265 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String valueToMatch() {
/* 270 */       return this.valueToMatch;
/*     */     }
/*     */ 
/*     */     
/*     */     public char[] valueToMatchAsChars() {
/* 275 */       return this.valueToMatch.toCharArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiValueMap<String, String> parameters() {
/* 280 */       return this.parameters;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 285 */       if (this != other) { if (other instanceof PathContainer.PathSegment) { PathContainer.PathSegment that = (PathContainer.PathSegment)other; if (this.value.equals(that.value())); }  return false; }
/*     */     
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 290 */       return this.value.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 295 */       return "[value='" + this.value + "']";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\DefaultPathContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */