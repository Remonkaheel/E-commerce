/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AttributesMap
/*     */   extends AbstractMap<String, Object>
/*     */ {
/*     */   @Nullable
/*     */   private transient Set<String> keySet;
/*     */   @Nullable
/*     */   private transient Collection<Object> values;
/*     */   @Nullable
/*     */   private transient Set<Map.Entry<String, Object>> entrySet;
/*     */   
/*     */   public int size() {
/* 335 */     int size = 0;
/* 336 */     for (Enumeration<?> names = ServletServerHttpRequest.this.servletRequest.getAttributeNames(); names.hasMoreElements(); names.nextElement()) {
/* 337 */       size++;
/*     */     }
/* 339 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(Object key) {
/* 345 */     if (key instanceof String) { String name = (String)key;
/* 346 */       return ServletServerHttpRequest.this.servletRequest.getAttribute(name); }
/*     */ 
/*     */     
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object put(String key, Object value) {
/* 356 */     Object old = get(key);
/* 357 */     ServletServerHttpRequest.this.servletRequest.setAttribute(key, value);
/* 358 */     return old;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object remove(Object key) {
/* 364 */     if (key instanceof String) { String name = (String)key;
/* 365 */       Object old = get(key);
/* 366 */       ServletServerHttpRequest.this.servletRequest.removeAttribute(name);
/* 367 */       return old; }
/*     */ 
/*     */     
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 376 */     for (Enumeration<String> names = ServletServerHttpRequest.this.servletRequest.getAttributeNames(); names.hasMoreElements(); ) {
/* 377 */       String name = names.nextElement();
/* 378 */       ServletServerHttpRequest.this.servletRequest.removeAttribute(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 384 */     Set<String> keySet = this.keySet;
/* 385 */     if (keySet == null) {
/* 386 */       keySet = new AbstractSet<String>()
/*     */         {
/*     */           public Iterator<String> iterator() {
/* 389 */             return ServletServerHttpRequest.this.servletRequest.getAttributeNames().asIterator();
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 394 */             return ServletServerHttpRequest.AttributesMap.this.size();
/*     */           }
/*     */         };
/* 397 */       this.keySet = keySet;
/*     */     } 
/* 399 */     return keySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> values() {
/* 404 */     Collection<Object> values = this.values;
/* 405 */     if (values == null) {
/* 406 */       values = new AbstractCollection()
/*     */         {
/*     */           public Iterator<Object> iterator() {
/* 409 */             final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/* 410 */             return new Iterator()
/*     */               {
/*     */                 public boolean hasNext() {
/* 413 */                   return e.hasMoreElements();
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Object next() {
/* 418 */                   String name = e.nextElement();
/* 419 */                   return ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 426 */             return ServletServerHttpRequest.AttributesMap.this.size();
/*     */           }
/*     */         };
/* 429 */       this.values = values;
/*     */     } 
/* 431 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 436 */     Set<Map.Entry<String, Object>> entrySet = this.entrySet;
/* 437 */     if (entrySet == null) {
/* 438 */       entrySet = new AbstractSet<Map.Entry<String, Object>>()
/*     */         {
/*     */           public Iterator<Map.Entry<String, Object>> iterator() {
/* 441 */             final Enumeration<String> e = ServletServerHttpRequest.this.servletRequest.getAttributeNames();
/* 442 */             return new Iterator<Map.Entry<String, Object>>()
/*     */               {
/*     */                 public boolean hasNext() {
/* 445 */                   return e.hasMoreElements();
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Map.Entry<String, Object> next() {
/* 450 */                   String name = e.nextElement();
/* 451 */                   Object value = ServletServerHttpRequest.this.servletRequest.getAttribute(name);
/* 452 */                   return new AbstractMap.SimpleImmutableEntry<>(name, value);
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 459 */             return ServletServerHttpRequest.AttributesMap.this.size();
/*     */           }
/*     */         };
/* 462 */       this.entrySet = entrySet;
/*     */     } 
/* 464 */     return entrySet;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\server\ServletServerHttpRequest$AttributesMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */