/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.eclipse.jetty.client.HttpClient;
/*     */ import org.eclipse.jetty.client.Request;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, InitializingBean, DisposableBean
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   private final boolean defaultClient;
/*  45 */   private long readTimeout = 10000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactory() {
/*  52 */     this(new HttpClient(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpRequestFactory(HttpClient httpClient) {
/*  60 */     this(httpClient, false);
/*     */   }
/*     */   
/*     */   private JettyClientHttpRequestFactory(HttpClient httpClient, boolean defaultClient) {
/*  64 */     this.httpClient = httpClient;
/*  65 */     this.defaultClient = defaultClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(int connectTimeout) {
/*  75 */     Assert.isTrue((connectTimeout >= 0), "Timeout must be a non-negative value");
/*  76 */     this.httpClient.setConnectTimeout(connectTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/*  85 */     Assert.notNull(connectTimeout, "ConnectTimeout must not be null");
/*  86 */     this.httpClient.setConnectTimeout(connectTimeout.toMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(long readTimeout) {
/*  94 */     Assert.isTrue((readTimeout > 0L), "Timeout must be a positive value");
/*  95 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/* 103 */     Assert.notNull(readTimeout, "ReadTimeout must not be null");
/* 104 */     this.readTimeout = readTimeout.toMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 109 */     startHttpClient();
/*     */   }
/*     */   
/*     */   private void startHttpClient() throws Exception {
/* 113 */     if (!this.httpClient.isStarted()) {
/* 114 */       this.httpClient.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 120 */     if (this.defaultClient && 
/* 121 */       !this.httpClient.isStopped()) {
/* 122 */       this.httpClient.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/*     */     try {
/* 130 */       startHttpClient();
/*     */     }
/* 132 */     catch (Exception ex) {
/* 133 */       throw new IOException("Could not start HttpClient: " + ex.getMessage(), ex);
/*     */     } 
/*     */     
/* 136 */     Request request = this.httpClient.newRequest(uri).method(httpMethod.name());
/* 137 */     request.timeout(this.readTimeout, TimeUnit.MILLISECONDS);
/* 138 */     return new JettyClientHttpRequest(request, this.readTimeout);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JettyClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */