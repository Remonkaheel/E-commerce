/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import reactor.netty.http.client.HttpClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2", forRemoval = true)
/*    */ public class ReactorNettyClientRequestFactory
/*    */   extends ReactorClientHttpRequestFactory
/*    */ {
/*    */   public ReactorNettyClientRequestFactory() {}
/*    */   
/*    */   public ReactorNettyClientRequestFactory(HttpClient httpClient) {
/* 47 */     super(httpClient);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReactorNettyClientRequestFactory(ReactorResourceFactory resourceFactory, Function<HttpClient, HttpClient> mapper) {
/* 55 */     super(resourceFactory, mapper);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ReactorNettyClientRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */