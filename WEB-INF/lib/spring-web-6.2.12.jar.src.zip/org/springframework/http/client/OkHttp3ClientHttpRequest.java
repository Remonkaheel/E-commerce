/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import okhttp3.MediaType;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.RequestBody;
/*     */ import okhttp3.internal.http.HttpMethod;
/*     */ import okio.BufferedSink;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.1", forRemoval = true)
/*     */ class OkHttp3ClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*     */   private final OkHttpClient client;
/*     */   private final URI uri;
/*     */   private final HttpMethod method;
/*     */   
/*     */   public OkHttp3ClientHttpRequest(OkHttpClient client, URI uri, HttpMethod method) {
/*  56 */     this.client = client;
/*  57 */     this.uri = uri;
/*  58 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  64 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  69 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/*     */     RequestBody requestBody;
/*  77 */     if (body != null) {
/*  78 */       requestBody = new BodyRequestBody(headers, body);
/*     */     }
/*  80 */     else if (HttpMethod.requiresRequestBody(getMethod().name())) {
/*  81 */       String header = headers.getFirst("Content-Type");
/*  82 */       MediaType contentType = (header != null) ? MediaType.parse(header) : null;
/*  83 */       requestBody = RequestBody.create(contentType, new byte[0]);
/*     */     } else {
/*     */       
/*  86 */       requestBody = null;
/*     */     } 
/*     */     
/*  89 */     Request.Builder builder = (new Request.Builder()).url(this.uri.toURL());
/*  90 */     builder.method(this.method.name(), requestBody);
/*  91 */     headers.forEach((headerName, headerValues) -> {
/*     */           for (String headerValue : headerValues) {
/*     */             builder.addHeader(headerName, headerValue);
/*     */           }
/*     */         });
/*  96 */     Request request = builder.build();
/*  97 */     return new OkHttp3ClientHttpResponse(this.client.newCall(request).execute());
/*     */   }
/*     */ 
/*     */   
/*     */   private static class BodyRequestBody
/*     */     extends RequestBody
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private final StreamingHttpOutputMessage.Body body;
/*     */     
/*     */     public BodyRequestBody(HttpHeaders headers, StreamingHttpOutputMessage.Body body) {
/* 109 */       this.headers = headers;
/* 110 */       this.body = body;
/*     */     }
/*     */ 
/*     */     
/*     */     public long contentLength() {
/* 115 */       return this.headers.getContentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public MediaType contentType() {
/* 121 */       String contentType = this.headers.getFirst("Content-Type");
/* 122 */       if (StringUtils.hasText(contentType)) {
/* 123 */         return MediaType.parse(contentType);
/*     */       }
/*     */       
/* 126 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeTo(BufferedSink sink) throws IOException {
/* 132 */       this.body.writeTo(sink.outputStream());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isOneShot() {
/* 137 */       return !this.body.repeatable();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OkHttp3ClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */