/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.time.Duration;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory
/*     */ {
/*     */   private static final int DEFAULT_CHUNK_SIZE = 4096;
/*     */   @Nullable
/*     */   private Proxy proxy;
/*  48 */   private int chunkSize = 4096;
/*     */   
/*  50 */   private int connectTimeout = -1;
/*     */   
/*  52 */   private int readTimeout = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxy(Proxy proxy) {
/*  59 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public void setBufferRequestBody(boolean bufferRequestBody) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChunkSize(int chunkSize) {
/*  78 */     this.chunkSize = chunkSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(int connectTimeout) {
/*  88 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/*  99 */     Assert.notNull(connectTimeout, "ConnectTimeout must not be null");
/* 100 */     this.connectTimeout = (int)connectTimeout.toMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(int readTimeout) {
/* 110 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/* 121 */     Assert.notNull(readTimeout, "ReadTimeout must not be null");
/* 122 */     this.readTimeout = (int)readTimeout.toMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public void setOutputStreaming(boolean outputStreaming) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/* 142 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 143 */     prepareConnection(connection, httpMethod.name());
/*     */     
/* 145 */     return new SimpleClientHttpRequest(connection, this.chunkSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpURLConnection openConnection(URL url, @Nullable Proxy proxy) throws IOException {
/*     */     HttpURLConnection httpUrlConnection;
/* 158 */     URLConnection urlConnection = (proxy != null) ? url.openConnection(proxy) : url.openConnection();
/* 159 */     if (urlConnection instanceof HttpURLConnection) { httpUrlConnection = (HttpURLConnection)urlConnection; }
/* 160 */     else { throw new IllegalStateException("HttpURLConnection required for [" + String.valueOf(url) + "] but got: " + String.valueOf(urlConnection)); }
/*     */ 
/*     */     
/* 163 */     return httpUrlConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
/* 174 */     if (this.connectTimeout >= 0) {
/* 175 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 177 */     if (this.readTimeout >= 0) {
/* 178 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 183 */     boolean mayWrite = ("POST".equals(httpMethod) || "PUT".equals(httpMethod) || "PATCH".equals(httpMethod) || "DELETE".equals(httpMethod));
/*     */     
/* 185 */     connection.setDoInput(true);
/* 186 */     connection.setInstanceFollowRedirects("GET".equals(httpMethod));
/* 187 */     connection.setDoOutput(mayWrite);
/* 188 */     connection.setRequestMethod(httpMethod);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\SimpleClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */