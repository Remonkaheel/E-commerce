/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.eclipse.jetty.client.InputStreamResponseListener;
/*     */ import org.eclipse.jetty.client.OutputStreamRequestContent;
/*     */ import org.eclipse.jetty.client.Request;
/*     */ import org.eclipse.jetty.client.Response;
/*     */ import org.eclipse.jetty.http.HttpFields;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JettyClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*     */   private static final int CHUNK_SIZE = 1024;
/*     */   private final Request request;
/*     */   private final long readTimeout;
/*     */   
/*     */   public JettyClientHttpRequest(Request request, long readTimeout) {
/*  57 */     this.request = request;
/*  58 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  63 */     return HttpMethod.valueOf(this.request.getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  68 */     return this.request.getURI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/*  74 */     if (!headers.isEmpty()) {
/*  75 */       this.request.headers(httpFields -> headers.forEach(()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     String contentType = null;
/*  84 */     if (headers.getContentType() != null) {
/*  85 */       contentType = headers.getContentType().toString();
/*     */     }
/*     */     try {
/*  88 */       InputStreamResponseListener responseListener = new InputStreamResponseListener();
/*  89 */       if (body != null)
/*  90 */       { OutputStreamRequestContent requestContent = new OutputStreamRequestContent(contentType);
/*  91 */         this.request.body((Request.Content)requestContent)
/*  92 */           .send((Response.CompleteListener)responseListener);
/*     */         
/*  94 */         OutputStream outputStream = new BufferedOutputStream(requestContent.getOutputStream(), 1024); 
/*  95 */         try { body.writeTo(StreamUtils.nonClosing(outputStream));
/*  96 */           outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/*     */          }
/*  99 */       else { this.request.send((Response.CompleteListener)responseListener); }
/*     */       
/* 101 */       Response response = responseListener.get(this.readTimeout, TimeUnit.MILLISECONDS);
/* 102 */       return new JettyClientHttpResponse(response, responseListener.getInputStream());
/*     */     }
/* 104 */     catch (InterruptedException ex) {
/* 105 */       Thread.currentThread().interrupt();
/* 106 */       throw new IOException("Request was interrupted: " + ex.getMessage(), ex);
/*     */     }
/* 108 */     catch (ExecutionException ex) {
/* 109 */       Throwable cause = ex.getCause();
/*     */       
/* 111 */       if (cause instanceof UncheckedIOException) { UncheckedIOException uioEx = (UncheckedIOException)cause;
/* 112 */         throw uioEx.getCause(); }
/*     */       
/* 114 */       if (cause instanceof RuntimeException) { RuntimeException rtEx = (RuntimeException)cause;
/* 115 */         throw rtEx; }
/*     */       
/* 117 */       if (cause instanceof IOException) { IOException ioEx = (IOException)cause;
/* 118 */         throw ioEx; }
/*     */ 
/*     */       
/* 121 */       throw new IOException(cause.getMessage(), cause);
/*     */     
/*     */     }
/* 124 */     catch (TimeoutException ex) {
/* 125 */       throw new IOException("Request timed out: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JettyClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */