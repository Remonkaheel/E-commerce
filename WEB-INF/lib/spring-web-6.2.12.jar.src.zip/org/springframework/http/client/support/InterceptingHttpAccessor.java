/*     */ package org.springframework.http.client.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpRequestInterceptor;
/*     */ import org.springframework.http.client.InterceptingClientHttpRequestFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InterceptingHttpAccessor
/*     */   extends HttpAccessor
/*     */ {
/*  47 */   private final List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile ClientHttpRequestFactory interceptingRequestFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterceptors(List<ClientHttpRequestInterceptor> interceptors) {
/*  65 */     Assert.noNullElements(interceptors, "'interceptors' must not contain null elements");
/*     */     
/*  67 */     if (this.interceptors != interceptors) {
/*  68 */       this.interceptors.clear();
/*  69 */       this.interceptors.addAll(interceptors);
/*  70 */       AnnotationAwareOrderComparator.sort(this.interceptors);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ClientHttpRequestInterceptor> getInterceptors() {
/*  82 */     return this.interceptors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRequestFactory(ClientHttpRequestFactory requestFactory) {
/*  87 */     super.setRequestFactory(requestFactory);
/*  88 */     this.interceptingRequestFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequestFactory getRequestFactory() {
/*  98 */     List<ClientHttpRequestInterceptor> interceptors = getInterceptors();
/*  99 */     if (!CollectionUtils.isEmpty(interceptors)) {
/* 100 */       InterceptingClientHttpRequestFactory interceptingClientHttpRequestFactory; ClientHttpRequestFactory factory = this.interceptingRequestFactory;
/* 101 */       if (factory == null) {
/* 102 */         interceptingClientHttpRequestFactory = new InterceptingClientHttpRequestFactory(super.getRequestFactory(), interceptors);
/* 103 */         this.interceptingRequestFactory = (ClientHttpRequestFactory)interceptingClientHttpRequestFactory;
/*     */       } 
/* 105 */       return (ClientHttpRequestFactory)interceptingClientHttpRequestFactory;
/*     */     } 
/*     */     
/* 108 */     return super.getRequestFactory();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\support\InterceptingHttpAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */