/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.reactivestreams.FlowAdapters;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.HttpClientRequest;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReactorClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   private final HttpMethod method;
/*     */   private final URI uri;
/*     */   @Nullable
/*     */   private final Duration exchangeTimeout;
/*     */   
/*     */   public ReactorClientHttpRequest(HttpClient httpClient, HttpMethod method, URI uri) {
/*  68 */     this.httpClient = httpClient;
/*  69 */     this.method = method;
/*  70 */     this.uri = uri;
/*  71 */     this.exchangeTimeout = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReactorClientHttpRequest(HttpClient httpClient, HttpMethod method, URI uri, @Nullable Duration exchangeTimeout) {
/*  78 */     this.httpClient = httpClient;
/*  79 */     this.method = method;
/*  80 */     this.uri = uri;
/*  81 */     this.exchangeTimeout = exchangeTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public ReactorClientHttpRequest(HttpClient httpClient, URI uri, HttpMethod method, @Nullable Duration exchangeTimeout, @Nullable Duration readTimeout) {
/*  96 */     this.httpClient = httpClient;
/*  97 */     this.method = method;
/*  98 */     this.uri = uri;
/*  99 */     this.exchangeTimeout = exchangeTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/* 105 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 110 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/* 118 */     HttpClient.RequestSender sender = this.httpClient.request(HttpMethod.valueOf(this.method.name()));
/*     */     
/* 120 */     sender = this.uri.isAbsolute() ? (HttpClient.RequestSender)sender.uri(this.uri) : (HttpClient.RequestSender)sender.uri(this.uri.toString());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 126 */       Mono<ReactorClientHttpResponse> mono = sender.send((request, outbound) -> send(headers, body, request, outbound)).responseConnection((response, conn) -> Mono.just(new ReactorClientHttpResponse(response, conn))).next();
/*     */ 
/*     */       
/* 129 */       ReactorClientHttpResponse clientResponse = (this.exchangeTimeout != null) ? (ReactorClientHttpResponse)mono.block(this.exchangeTimeout) : (ReactorClientHttpResponse)mono.block();
/*     */       
/* 131 */       if (clientResponse == null) {
/* 132 */         throw new IOException("HTTP exchange resulted in no result");
/*     */       }
/*     */       
/* 135 */       return clientResponse;
/*     */     }
/* 137 */     catch (RuntimeException ex) {
/* 138 */       throw convertException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Publisher<Void> send(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body, HttpClientRequest request, NettyOutbound outbound) {
/* 145 */     headers.forEach((key, value) -> request.requestHeaders().set(key, value));
/*     */     
/* 147 */     if (body == null)
/*     */     {
/*     */       
/* 150 */       return (Publisher<Void>)Mono.empty();
/*     */     }
/*     */     
/* 153 */     AtomicReference<Executor> executorRef = new AtomicReference<>();
/*     */     
/* 155 */     return (Publisher<Void>)outbound
/* 156 */       .withConnection(connection -> executorRef.set(connection.channel().eventLoop()))
/* 157 */       .send(FlowAdapters.toPublisher(new OutputStreamPublisher(os -> body.writeTo(StreamUtils.nonClosing(os)), new ByteBufMapper(outbound), executorRef
/*     */             
/* 159 */             .getAndSet(null), null)));
/*     */   }
/*     */   
/*     */   static IOException convertException(RuntimeException ex) {
/* 163 */     Throwable cause = ex.getCause();
/* 164 */     if (cause instanceof IOException) { IOException ioEx = (IOException)cause;
/* 165 */       return ioEx; }
/*     */     
/* 167 */     if (cause instanceof UncheckedIOException) { UncheckedIOException uioEx = (UncheckedIOException)cause;
/* 168 */       IOException ioEx = uioEx.getCause();
/* 169 */       if (ioEx != null) {
/* 170 */         return ioEx;
/*     */       } }
/*     */     
/* 173 */     return new IOException(ex.getMessage(), (cause != null) ? cause : ex);
/*     */   }
/*     */   
/*     */   private static final class ByteBufMapper
/*     */     implements OutputStreamPublisher.ByteMapper<ByteBuf>
/*     */   {
/*     */     private final ByteBufAllocator allocator;
/*     */     
/*     */     public ByteBufMapper(NettyOutbound outbound) {
/* 182 */       this.allocator = outbound.alloc();
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf map(int b) {
/* 187 */       ByteBuf buf = this.allocator.buffer(1);
/* 188 */       buf.writeByte(b);
/* 189 */       return buf;
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuf map(byte[] b, int off, int len) {
/* 194 */       ByteBuf buf = this.allocator.buffer(len);
/* 195 */       buf.writeBytes(b, off, len);
/* 196 */       return buf;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ReactorClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */