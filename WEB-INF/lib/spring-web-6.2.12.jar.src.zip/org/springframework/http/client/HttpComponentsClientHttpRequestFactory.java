/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiFunction;
/*     */ import org.apache.hc.client5.http.classic.HttpClient;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpDelete;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpGet;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpHead;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpOptions;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpPatch;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpPost;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpPut;
/*     */ import org.apache.hc.client5.http.classic.methods.HttpTrace;
/*     */ import org.apache.hc.client5.http.config.Configurable;
/*     */ import org.apache.hc.client5.http.config.RequestConfig;
/*     */ import org.apache.hc.client5.http.impl.classic.HttpClients;
/*     */ import org.apache.hc.client5.http.protocol.HttpClientContext;
/*     */ import org.apache.hc.core5.http.ClassicHttpRequest;
/*     */ import org.apache.hc.core5.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpComponentsClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private HttpClient httpClient;
/*     */   @Nullable
/*     */   private BiFunction<HttpMethod, URI, HttpContext> httpContextFactory;
/*  72 */   private long connectTimeout = -1L;
/*     */   
/*  74 */   private long connectionRequestTimeout = -1L;
/*     */   
/*  76 */   private long readTimeout = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactory() {
/*  84 */     this.httpClient = (HttpClient)HttpClients.createSystem();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequestFactory(HttpClient httpClient) {
/*  93 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpClient(HttpClient httpClient) {
/* 102 */     Assert.notNull(httpClient, "HttpClient must not be null");
/* 103 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient getHttpClient() {
/* 111 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(int connectTimeout) {
/* 128 */     Assert.isTrue((connectTimeout >= 0), "Timeout must be a non-negative value");
/* 129 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 147 */     Assert.notNull(connectTimeout, "ConnectTimeout must not be null");
/* 148 */     Assert.isTrue(!connectTimeout.isNegative(), "Timeout must be a non-negative value");
/* 149 */     this.connectTimeout = connectTimeout.toMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionRequestTimeout(int connectionRequestTimeout) {
/* 163 */     Assert.isTrue((connectionRequestTimeout >= 0), "Timeout must be a non-negative value");
/* 164 */     this.connectionRequestTimeout = connectionRequestTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionRequestTimeout(Duration connectionRequestTimeout) {
/* 179 */     Assert.notNull(connectionRequestTimeout, "ConnectionRequestTimeout must not be null");
/* 180 */     Assert.isTrue(!connectionRequestTimeout.isNegative(), "Timeout must be a non-negative value");
/* 181 */     this.connectionRequestTimeout = connectionRequestTimeout.toMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(int readTimeout) {
/* 194 */     Assert.isTrue((readTimeout >= 0), "Timeout must be a non-negative value");
/* 195 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/* 208 */     Assert.notNull(readTimeout, "ReadTimeout must not be null");
/* 209 */     Assert.isTrue(!readTimeout.isNegative(), "Timeout must be a non-negative value");
/* 210 */     this.readTimeout = readTimeout.toMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public void setBufferRequestBody(boolean bufferRequestBody) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpContextFactory(BiFunction<HttpMethod, URI, HttpContext> httpContextFactory) {
/* 236 */     this.httpContextFactory = httpContextFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/*     */     HttpClientContext httpClientContext;
/* 243 */     HttpClient client = getHttpClient();
/*     */     
/* 245 */     ClassicHttpRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 246 */     postProcessHttpRequest(httpRequest);
/* 247 */     HttpContext context = createHttpContext(httpMethod, uri);
/* 248 */     if (context == null) {
/* 249 */       httpClientContext = HttpClientContext.create();
/*     */     }
/*     */ 
/*     */     
/* 253 */     if (!hasCustomRequestConfig((HttpContext)httpClientContext)) {
/* 254 */       RequestConfig config = null;
/*     */       
/* 256 */       if (httpRequest instanceof Configurable) { Configurable configurable = (Configurable)httpRequest;
/* 257 */         config = configurable.getConfig(); }
/*     */       
/* 259 */       if (config == null) {
/* 260 */         config = createRequestConfig(client);
/*     */       }
/* 262 */       if (config != null) {
/* 263 */         if (httpClientContext instanceof HttpClientContext) { HttpClientContext clientContext = httpClientContext;
/* 264 */           clientContext.setRequestConfig(config); }
/*     */         
/* 266 */         httpClientContext.setAttribute("http.request-config", config);
/*     */       } 
/*     */     } 
/* 269 */     return new HttpComponentsClientHttpRequest(client, httpRequest, (HttpContext)httpClientContext);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean hasCustomRequestConfig(HttpContext context) {
/* 274 */     if (context instanceof HttpClientContext) { HttpClientContext clientContext = (HttpClientContext)context;
/*     */ 
/*     */       
/* 277 */       RequestConfig requestConfig = clientContext.getRequestConfig();
/* 278 */       return (requestConfig != null && !requestConfig.equals(RequestConfig.DEFAULT)); }
/*     */ 
/*     */     
/* 281 */     return (context.getAttribute("http.request-config") != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected RequestConfig createRequestConfig(Object client) {
/* 298 */     if (client instanceof Configurable) { Configurable configurableClient = (Configurable)client;
/* 299 */       RequestConfig clientRequestConfig = configurableClient.getConfig();
/* 300 */       return mergeRequestConfig(clientRequestConfig); }
/*     */     
/* 302 */     return mergeRequestConfig(RequestConfig.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RequestConfig mergeRequestConfig(RequestConfig clientConfig) {
/* 314 */     if (this.connectTimeout == -1L && this.connectionRequestTimeout == -1L && this.readTimeout == -1L) {
/* 315 */       return clientConfig;
/*     */     }
/*     */     
/* 318 */     RequestConfig.Builder builder = RequestConfig.copy(clientConfig);
/* 319 */     if (this.connectTimeout >= 0L) {
/* 320 */       builder.setConnectTimeout(this.connectTimeout, TimeUnit.MILLISECONDS);
/*     */     }
/* 322 */     if (this.connectionRequestTimeout >= 0L) {
/* 323 */       builder.setConnectionRequestTimeout(this.connectionRequestTimeout, TimeUnit.MILLISECONDS);
/*     */     }
/* 325 */     if (this.readTimeout >= 0L) {
/* 326 */       builder.setResponseTimeout(this.readTimeout, TimeUnit.MILLISECONDS);
/*     */     }
/* 328 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassicHttpRequest createHttpUriRequest(HttpMethod httpMethod, URI uri) {
/* 338 */     if (HttpMethod.GET.equals(httpMethod)) {
/* 339 */       return (ClassicHttpRequest)new HttpGet(uri);
/*     */     }
/* 341 */     if (HttpMethod.HEAD.equals(httpMethod)) {
/* 342 */       return (ClassicHttpRequest)new HttpHead(uri);
/*     */     }
/* 344 */     if (HttpMethod.POST.equals(httpMethod)) {
/* 345 */       return (ClassicHttpRequest)new HttpPost(uri);
/*     */     }
/* 347 */     if (HttpMethod.PUT.equals(httpMethod)) {
/* 348 */       return (ClassicHttpRequest)new HttpPut(uri);
/*     */     }
/* 350 */     if (HttpMethod.PATCH.equals(httpMethod)) {
/* 351 */       return (ClassicHttpRequest)new HttpPatch(uri);
/*     */     }
/* 353 */     if (HttpMethod.DELETE.equals(httpMethod)) {
/* 354 */       return (ClassicHttpRequest)new HttpDelete(uri);
/*     */     }
/* 356 */     if (HttpMethod.OPTIONS.equals(httpMethod)) {
/* 357 */       return (ClassicHttpRequest)new HttpOptions(uri);
/*     */     }
/* 359 */     if (HttpMethod.TRACE.equals(httpMethod)) {
/* 360 */       return (ClassicHttpRequest)new HttpTrace(uri);
/*     */     }
/* 362 */     throw new IllegalArgumentException("Invalid HTTP method: " + String.valueOf(httpMethod));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessHttpRequest(ClassicHttpRequest request) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri) {
/* 383 */     return (this.httpContextFactory != null) ? this.httpContextFactory.apply(httpMethod, uri) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 393 */     HttpClient httpClient = getHttpClient();
/* 394 */     if (httpClient instanceof Closeable) { Closeable closeable = (Closeable)httpClient;
/* 395 */       closeable.close(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\HttpComponentsClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */