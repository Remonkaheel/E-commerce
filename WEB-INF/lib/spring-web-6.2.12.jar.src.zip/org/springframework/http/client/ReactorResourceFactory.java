/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty.http.HttpResources;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorResourceFactory
/*     */   implements ApplicationContextAware, InitializingBean, DisposableBean, SmartLifecycle
/*     */ {
/*     */   private boolean useGlobalResources = true;
/*     */   @Nullable
/*     */   private Consumer<HttpResources> globalResourcesConsumer;
/*     */   private Supplier<ConnectionProvider> connectionProviderSupplier = () -> ConnectionProvider.create("webflux", 500);
/*     */   @Nullable
/*     */   private volatile ConnectionProvider connectionProvider;
/*     */   private Supplier<LoopResources> loopResourcesSupplier = () -> LoopResources.create("webflux-http");
/*     */   @Nullable
/*     */   private volatile LoopResources loopResources;
/*     */   private boolean manageConnectionProvider = false;
/*     */   private boolean manageLoopResources = false;
/*  75 */   private Duration shutdownQuietPeriod = Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_QUIET_PERIOD);
/*     */   
/*  77 */   private Duration shutdownTimeout = Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_TIMEOUT);
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   private volatile boolean running;
/*     */   
/*  84 */   private final Object lifecycleMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseGlobalResources(boolean useGlobalResources) {
/*  97 */     this.useGlobalResources = useGlobalResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseGlobalResources() {
/* 105 */     return this.useGlobalResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGlobalResourcesConsumer(Consumer<HttpResources> consumer) {
/* 116 */     this.useGlobalResources = true;
/* 117 */     this
/* 118 */       .globalResourcesConsumer = (this.globalResourcesConsumer != null) ? this.globalResourcesConsumer.andThen(consumer) : consumer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProviderSupplier(Supplier<ConnectionProvider> supplier) {
/* 131 */     this.connectionProviderSupplier = supplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProvider(ConnectionProvider connectionProvider) {
/* 140 */     this.connectionProvider = connectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionProvider getConnectionProvider() {
/* 149 */     if (this.connectionProvider == null) {
/* 150 */       start();
/*     */     }
/* 152 */     ConnectionProvider connectionProvider = this.connectionProvider;
/* 153 */     Assert.state((connectionProvider != null), "ConnectionProvider not initialized");
/* 154 */     return connectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoopResourcesSupplier(Supplier<LoopResources> supplier) {
/* 167 */     this.loopResourcesSupplier = supplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoopResources(LoopResources loopResources) {
/* 176 */     this.loopResources = loopResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoopResources getLoopResources() {
/* 185 */     if (this.loopResources == null) {
/* 186 */       start();
/*     */     }
/* 188 */     LoopResources loopResources = this.loopResources;
/* 189 */     Assert.state((loopResources != null), "LoopResources not initialized");
/* 190 */     return loopResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShutdownQuietPeriod(Duration shutdownQuietPeriod) {
/* 205 */     Assert.notNull(shutdownQuietPeriod, "shutdownQuietPeriod should not be null");
/* 206 */     this.shutdownQuietPeriod = shutdownQuietPeriod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShutdownTimeout(Duration shutdownTimeout) {
/* 221 */     Assert.notNull(shutdownTimeout, "shutdownTimeout should not be null");
/* 222 */     this.shutdownTimeout = shutdownTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 233 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 245 */     if (this.applicationContext == null) {
/* 246 */       start();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 258 */     if (this.applicationContext == null) {
/* 259 */       stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/* 265 */     synchronized (this.lifecycleMonitor) {
/* 266 */       if (!this.running) {
/* 267 */         if (this.useGlobalResources) {
/* 268 */           Assert.isTrue((this.loopResources == null && this.connectionProvider == null), "'useGlobalResources' is mutually exclusive with explicitly configured resources");
/*     */           
/* 270 */           HttpResources httpResources = HttpResources.get();
/* 271 */           if (this.globalResourcesConsumer != null) {
/* 272 */             this.globalResourcesConsumer.accept(httpResources);
/*     */           }
/* 274 */           this.connectionProvider = (ConnectionProvider)httpResources;
/* 275 */           this.loopResources = (LoopResources)httpResources;
/*     */         } else {
/*     */           
/* 278 */           if (this.loopResources == null) {
/* 279 */             this.manageLoopResources = true;
/* 280 */             this.loopResources = this.loopResourcesSupplier.get();
/*     */           } 
/* 282 */           if (this.connectionProvider == null) {
/* 283 */             this.manageConnectionProvider = true;
/* 284 */             this.connectionProvider = this.connectionProviderSupplier.get();
/*     */           } 
/*     */         } 
/* 287 */         this.running = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 295 */     synchronized (this.lifecycleMonitor) {
/* 296 */       if (this.running) {
/* 297 */         if (this.useGlobalResources) {
/* 298 */           HttpResources.disposeLoopsAndConnectionsLater(this.shutdownQuietPeriod, this.shutdownTimeout).block();
/* 299 */           this.connectionProvider = null;
/* 300 */           this.loopResources = null;
/*     */         } else {
/*     */           
/*     */           try {
/* 304 */             ConnectionProvider provider = this.connectionProvider;
/* 305 */             if (provider != null && this.manageConnectionProvider) {
/* 306 */               this.connectionProvider = null;
/* 307 */               provider.disposeLater().block();
/*     */             }
/*     */           
/* 310 */           } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 315 */             LoopResources resources = this.loopResources;
/* 316 */             if (resources != null && this.manageLoopResources) {
/* 317 */               this.loopResources = null;
/* 318 */               resources.disposeLater(this.shutdownQuietPeriod, this.shutdownTimeout).block();
/*     */             }
/*     */           
/* 321 */           } catch (Throwable throwable) {}
/*     */         } 
/*     */ 
/*     */         
/* 325 */         this.running = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 332 */     return this.running;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPhase() {
/* 338 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ReactorResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */