/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.hc.client5.http.classic.HttpClient;
/*     */ import org.apache.hc.core5.function.Supplier;
/*     */ import org.apache.hc.core5.http.ClassicHttpRequest;
/*     */ import org.apache.hc.core5.http.ClassicHttpResponse;
/*     */ import org.apache.hc.core5.http.Header;
/*     */ import org.apache.hc.core5.http.HttpEntity;
/*     */ import org.apache.hc.core5.http.Method;
/*     */ import org.apache.hc.core5.http.io.entity.NullEntity;
/*     */ import org.apache.hc.core5.http.protocol.HttpContext;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpComponentsClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   private final ClassicHttpRequest httpRequest;
/*     */   private final HttpContext httpContext;
/*     */   
/*     */   HttpComponentsClientHttpRequest(HttpClient client, ClassicHttpRequest request, HttpContext context) {
/*  64 */     this.httpClient = client;
/*  65 */     this.httpRequest = request;
/*  66 */     this.httpContext = context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  72 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*     */     try {
/*  78 */       return this.httpRequest.getUri();
/*     */     }
/*  80 */     catch (URISyntaxException ex) {
/*  81 */       throw new IllegalStateException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   HttpContext getHttpContext() {
/*  86 */     return this.httpContext;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/*  91 */     addHeaders(this.httpRequest, headers);
/*     */     
/*  93 */     if (body != null) {
/*  94 */       this.httpRequest.setEntity(new BodyEntity(headers, body));
/*     */     }
/*  96 */     else if (!Method.isSafe(this.httpRequest.getMethod())) {
/*  97 */       this.httpRequest.setEntity((HttpEntity)NullEntity.INSTANCE);
/*     */     } 
/*  99 */     ClassicHttpResponse httpResponse = this.httpClient.executeOpen(null, this.httpRequest, this.httpContext);
/* 100 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addHeaders(ClassicHttpRequest httpRequest, HttpHeaders headers) {
/* 109 */     headers.forEach((headerName, headerValues) -> {
/*     */           if ("Cookie".equalsIgnoreCase(headerName)) {
/*     */             String headerValue = StringUtils.collectionToDelimitedString(headerValues, "; ");
/*     */             httpRequest.addHeader(headerName, headerValue);
/*     */           } else if (!"Content-Length".equalsIgnoreCase(headerName) && !"Transfer-Encoding".equalsIgnoreCase(headerName)) {
/*     */             for (String headerValue : headerValues) {
/*     */               httpRequest.addHeader(headerName, headerValue);
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BodyEntity
/*     */     implements HttpEntity
/*     */   {
/*     */     private final HttpHeaders headers;
/*     */     
/*     */     private final StreamingHttpOutputMessage.Body body;
/*     */ 
/*     */     
/*     */     public BodyEntity(HttpHeaders headers, StreamingHttpOutputMessage.Body body) {
/* 132 */       this.headers = headers;
/* 133 */       this.body = body;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getContentLength() {
/* 139 */       return this.headers.getContentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getContentType() {
/* 145 */       return this.headers.getFirst("Content-Type");
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getContent() {
/* 150 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeTo(OutputStream outStream) throws IOException {
/* 155 */       this.body.writeTo(outStream);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRepeatable() {
/* 160 */       return this.body.repeatable();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isStreaming() {
/* 165 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Supplier<List<? extends Header>> getTrailers() {
/* 171 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getContentEncoding() {
/* 177 */       return this.headers.getFirst("Content-Encoding");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isChunked() {
/* 182 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Set<String> getTrailerNames() {
/* 188 */       return null;
/*     */     }
/*     */     
/*     */     public void close() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\HttpComponentsClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */