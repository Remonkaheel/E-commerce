/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.hc.core5.http.ClassicHttpResponse;
/*    */ import org.apache.hc.core5.http.HttpEntity;
/*    */ import org.apache.hc.core5.http.HttpMessage;
/*    */ import org.apache.hc.core5.http.io.entity.EntityUtils;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.support.HttpComponentsHeadersAdapter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpComponentsClientHttpResponse
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final ClassicHttpResponse httpResponse;
/*    */   @Nullable
/*    */   private HttpHeaders headers;
/*    */   
/*    */   HttpComponentsClientHttpResponse(ClassicHttpResponse httpResponse) {
/* 52 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusCode getStatusCode() {
/* 58 */     return HttpStatusCode.valueOf(this.httpResponse.getCode());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStatusText() {
/* 63 */     return this.httpResponse.getReasonPhrase();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders getHeaders() {
/* 68 */     if (this.headers == null) {
/* 69 */       HttpComponentsHeadersAdapter httpComponentsHeadersAdapter = new HttpComponentsHeadersAdapter((HttpMessage)this.httpResponse);
/* 70 */       this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)httpComponentsHeadersAdapter);
/*    */     } 
/* 72 */     return this.headers;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getBody() throws IOException {
/* 77 */     HttpEntity entity = this.httpResponse.getEntity();
/* 78 */     return (entity != null) ? entity.getContent() : InputStream.nullInputStream();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() {
/*    */     try {
/*    */       try {
/* 87 */         EntityUtils.consume(this.httpResponse.getEntity());
/*    */       } finally {
/*    */         
/* 90 */         this.httpResponse.close();
/*    */       }
/*    */     
/* 93 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\HttpComponentsClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */