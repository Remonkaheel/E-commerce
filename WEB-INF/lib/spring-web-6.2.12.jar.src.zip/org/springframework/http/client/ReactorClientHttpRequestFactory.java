/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, SmartLifecycle
/*     */ {
/*  49 */   private static final Log logger = LogFactory.getLog(ReactorClientHttpRequestFactory.class);
/*     */   static {
/*  51 */     defaultInitializer = (client -> client.compress(true).responseTimeout(Duration.ofSeconds(10L)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Function<HttpClient, HttpClient> defaultInitializer;
/*     */   
/*     */   @Nullable
/*     */   private final ReactorResourceFactory resourceFactory;
/*     */   
/*     */   @Nullable
/*     */   private final Function<HttpClient, HttpClient> mapper;
/*     */   
/*     */   @Nullable
/*     */   private Integer connectTimeout;
/*     */   
/*     */   @Nullable
/*     */   private Duration readTimeout;
/*     */   
/*     */   @Nullable
/*     */   private Duration exchangeTimeout;
/*     */   @Nullable
/*     */   private volatile HttpClient httpClient;
/*  73 */   private final Object lifecycleMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactory() {
/*  81 */     this(defaultInitializer.apply(HttpClient.create()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactory(HttpClient client) {
/*  89 */     Assert.notNull(client, "HttpClient must not be null");
/*  90 */     this.resourceFactory = null;
/*  91 */     this.mapper = null;
/*  92 */     this.httpClient = client;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpRequestFactory(ReactorResourceFactory resourceFactory, Function<HttpClient, HttpClient> mapper) {
/* 112 */     this.resourceFactory = resourceFactory;
/* 113 */     this.mapper = mapper;
/* 114 */     if (resourceFactory.isRunning()) {
/* 115 */       this.httpClient = createHttpClient(resourceFactory, mapper);
/*     */     }
/*     */   }
/*     */   
/*     */   private HttpClient createHttpClient(ReactorResourceFactory factory, Function<HttpClient, HttpClient> mapper) {
/* 120 */     HttpClient client = HttpClient.create(factory.getConnectionProvider());
/* 121 */     client = defaultInitializer.<HttpClient>andThen(mapper).apply(client);
/* 122 */     client = (HttpClient)client.runOn(factory.getLoopResources());
/* 123 */     if (this.connectTimeout != null) {
/* 124 */       client = (HttpClient)client.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, this.connectTimeout);
/*     */     }
/* 126 */     if (this.readTimeout != null) {
/* 127 */       client = client.responseTimeout(this.readTimeout);
/*     */     }
/* 129 */     return client;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(int connectTimeout) {
/* 144 */     Assert.isTrue((connectTimeout >= 0), "Timeout must be a non-negative value");
/* 145 */     this.connectTimeout = Integer.valueOf(connectTimeout);
/* 146 */     HttpClient httpClient = this.httpClient;
/* 147 */     if (httpClient != null) {
/* 148 */       this.httpClient = (HttpClient)httpClient.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, this.connectTimeout);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 156 */     Assert.notNull(connectTimeout, "ConnectTimeout must not be null");
/* 157 */     setConnectTimeout((int)connectTimeout.toMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration timeout) {
/* 167 */     Assert.notNull(timeout, "ReadTimeout must not be null");
/* 168 */     Assert.isTrue((timeout.toMillis() > 0L), "Timeout must be a positive value");
/* 169 */     this.readTimeout = timeout;
/* 170 */     HttpClient httpClient = this.httpClient;
/* 171 */     if (httpClient != null) {
/* 172 */       this.httpClient = httpClient.responseTimeout(timeout);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(long readTimeout) {
/* 180 */     setReadTimeout(Duration.ofMillis(readTimeout));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public void setExchangeTimeout(long exchangeTimeout) {
/* 194 */     Assert.isTrue((exchangeTimeout > 0L), "Timeout must be a positive value");
/* 195 */     this.exchangeTimeout = Duration.ofMillis(exchangeTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public void setExchangeTimeout(Duration exchangeTimeout) {
/* 209 */     Assert.notNull(exchangeTimeout, "ExchangeTimeout must not be null");
/* 210 */     setExchangeTimeout((int)exchangeTimeout.toMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/* 216 */     HttpClient client = this.httpClient;
/* 217 */     if (client == null) {
/* 218 */       Assert.state((this.resourceFactory != null && this.mapper != null), "Expected HttpClient or ResourceFactory and mapper");
/*     */       
/* 220 */       client = createHttpClient(this.resourceFactory, this.mapper);
/*     */     } 
/* 222 */     return new ReactorClientHttpRequest(client, httpMethod, uri, this.exchangeTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 228 */     if (this.resourceFactory != null && this.mapper != null) {
/* 229 */       synchronized (this.lifecycleMonitor) {
/* 230 */         if (this.httpClient == null) {
/* 231 */           this.httpClient = createHttpClient(this.resourceFactory, this.mapper);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 236 */       logger.warn("Restarting a ReactorClientHttpRequestFactory bean is only supported with externally managed Reactor Netty resources");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 243 */     if (this.resourceFactory != null && this.mapper != null) {
/* 244 */       synchronized (this.lifecycleMonitor) {
/* 245 */         this.httpClient = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 252 */     return (this.httpClient != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPhase() {
/* 257 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ReactorClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */