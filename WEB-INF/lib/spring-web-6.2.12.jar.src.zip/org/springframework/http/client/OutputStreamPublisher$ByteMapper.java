package org.springframework.http.client;

public interface ByteMapper<T> {
  T map(int paramInt);
  
  T map(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OutputStreamPublisher$ByteMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */