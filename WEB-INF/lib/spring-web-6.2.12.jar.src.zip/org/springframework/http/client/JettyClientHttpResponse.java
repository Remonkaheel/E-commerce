/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.eclipse.jetty.client.Response;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.support.JettyHeadersAdapter;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyClientHttpResponse
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final Response response;
/*    */   private final InputStream body;
/*    */   private final HttpHeaders headers;
/*    */   
/*    */   public JettyClientHttpResponse(Response response, InputStream inputStream) {
/* 46 */     this.response = response;
/* 47 */     this.body = inputStream;
/*    */     
/* 49 */     JettyHeadersAdapter jettyHeadersAdapter = new JettyHeadersAdapter(response.getHeaders());
/* 50 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)jettyHeadersAdapter);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusCode getStatusCode() throws IOException {
/* 56 */     return HttpStatusCode.valueOf(this.response.getStatus());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStatusText() throws IOException {
/* 61 */     return this.response.getReason();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders getHeaders() {
/* 66 */     return this.headers;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getBody() throws IOException {
/* 71 */     return this.body;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/*    */     try {
/* 77 */       this.body.close();
/*    */     }
/* 79 */     catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JettyClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */