/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*     */   private final HttpResponse<InputStream> response;
/*     */   private final HttpHeaders headers;
/*     */   private final InputStream body;
/*     */   
/*     */   public JdkClientHttpResponse(HttpResponse<InputStream> response, @Nullable InputStream body) {
/*  53 */     this.response = response;
/*  54 */     this.headers = adaptHeaders(response);
/*  55 */     this.body = (body != null) ? body : InputStream.nullInputStream();
/*     */   }
/*     */   
/*     */   private static HttpHeaders adaptHeaders(HttpResponse<?> response) {
/*  59 */     Map<String, List<String>> rawHeaders = response.headers().map();
/*  60 */     LinkedCaseInsensitiveMap linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap(rawHeaders.size(), Locale.ROOT);
/*  61 */     MultiValueMap<String, String> multiValueMap = CollectionUtils.toMultiValueMap((Map)linkedCaseInsensitiveMap);
/*  62 */     multiValueMap.putAll(rawHeaders);
/*  63 */     return HttpHeaders.readOnlyHttpHeaders(multiValueMap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  69 */     return HttpStatusCode.valueOf(this.response.statusCode());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusText() {
/*  75 */     HttpStatusCode httpStatusCode = getStatusCode(); if (httpStatusCode instanceof HttpStatus) { HttpStatus status = (HttpStatus)httpStatusCode;
/*  76 */       return status.getReasonPhrase(); }
/*     */ 
/*     */     
/*  79 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  85 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBody() throws IOException {
/*  90 */     return this.body;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/*     */       try {
/*  97 */         StreamUtils.drain(this.body);
/*     */       } finally {
/*     */         
/* 100 */         this.body.close();
/*     */       }
/*     */     
/* 103 */     } catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JdkClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */