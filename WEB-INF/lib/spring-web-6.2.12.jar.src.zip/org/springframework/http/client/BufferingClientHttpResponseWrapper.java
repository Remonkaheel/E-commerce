/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BufferingClientHttpResponseWrapper
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final ClientHttpResponse response;
/*    */   @Nullable
/*    */   private byte[] body;
/*    */   
/*    */   BufferingClientHttpResponseWrapper(ClientHttpResponse response) {
/* 44 */     this.response = response;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusCode getStatusCode() throws IOException {
/* 50 */     return this.response.getStatusCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStatusText() throws IOException {
/* 55 */     return this.response.getStatusText();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders getHeaders() {
/* 60 */     return this.response.getHeaders();
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getBody() throws IOException {
/* 65 */     if (this.body == null) {
/* 66 */       this.body = StreamUtils.copyToByteArray(this.response.getBody());
/*    */     }
/* 68 */     return new ByteArrayInputStream(this.body);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 73 */     this.response.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\BufferingClientHttpResponseWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */