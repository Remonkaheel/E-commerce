/*     */ package org.springframework.http.client.observation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultClientRequestObservationConvention
/*     */   implements ClientRequestObservationConvention
/*     */ {
/*     */   private static final String DEFAULT_NAME = "http.client.requests";
/*  46 */   private static final Pattern PATTERN_BEFORE_PATH = Pattern.compile("^https?://[^/]+");
/*     */   
/*  48 */   private static final KeyValue URI_NONE = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.URI, "none");
/*     */   
/*  50 */   private static final KeyValue METHOD_NONE = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, "none");
/*     */   
/*  52 */   private static final KeyValue STATUS_IO_ERROR = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, "IO_ERROR");
/*     */   
/*  54 */   private static final KeyValue STATUS_CLIENT_ERROR = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, "CLIENT_ERROR");
/*     */   
/*  56 */   private static final KeyValue HTTP_OUTCOME_SUCCESS = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "SUCCESS");
/*     */   
/*  58 */   private static final KeyValue HTTP_OUTCOME_UNKNOWN = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, "UNKNOWN");
/*     */   
/*  60 */   private static final KeyValue CLIENT_NAME_NONE = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.CLIENT_NAME, "none");
/*     */   
/*  62 */   private static final KeyValue EXCEPTION_NONE = KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, "none");
/*     */   
/*  64 */   private static final KeyValue HTTP_URL_NONE = KeyValue.of(ClientHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, "none");
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultClientRequestObservationConvention() {
/*  73 */     this("http.client.requests");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultClientRequestObservationConvention(String name) {
/*  81 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  86 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getContextualName(ClientRequestObservationContext context) {
/*  92 */     ClientHttpRequest request = (ClientHttpRequest)context.getCarrier();
/*  93 */     return (request != null) ? ("http " + request.getMethod().name().toLowerCase(Locale.ROOT)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getLowCardinalityKeyValues(ClientRequestObservationContext context) {
/*  99 */     return KeyValues.of(new KeyValue[] { clientName(context), exception(context), method(context), outcome(context), status(context), uri(context) });
/*     */   }
/*     */   
/*     */   protected KeyValue uri(ClientRequestObservationContext context) {
/* 103 */     if (context.getUriTemplate() != null) {
/* 104 */       return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.URI, extractPath(context.getUriTemplate()));
/*     */     }
/* 106 */     return URI_NONE;
/*     */   }
/*     */   
/*     */   private static String extractPath(String uriTemplate) {
/* 110 */     String path = PATTERN_BEFORE_PATH.matcher(uriTemplate).replaceFirst("");
/* 111 */     return path.startsWith("/") ? path : ("/" + path);
/*     */   }
/*     */   
/*     */   protected KeyValue method(ClientRequestObservationContext context) {
/* 115 */     if (context.getCarrier() != null) {
/* 116 */       return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.METHOD, ((ClientHttpRequest)context.getCarrier()).getMethod().name());
/*     */     }
/*     */     
/* 119 */     return METHOD_NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected KeyValue status(ClientRequestObservationContext context) {
/* 124 */     ClientHttpResponse response = (ClientHttpResponse)context.getResponse();
/* 125 */     if (response == null) {
/* 126 */       return STATUS_CLIENT_ERROR;
/*     */     }
/*     */     try {
/* 129 */       return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.STATUS, String.valueOf(response.getStatusCode().value()));
/*     */     }
/* 131 */     catch (IOException ex) {
/* 132 */       return STATUS_IO_ERROR;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected KeyValue clientName(ClientRequestObservationContext context) {
/* 137 */     if (context.getCarrier() != null && ((ClientHttpRequest)context.getCarrier()).getURI().getHost() != null) {
/* 138 */       return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.CLIENT_NAME, ((ClientHttpRequest)context.getCarrier()).getURI().getHost());
/*     */     }
/* 140 */     return CLIENT_NAME_NONE;
/*     */   }
/*     */   
/*     */   protected KeyValue exception(ClientRequestObservationContext context) {
/* 144 */     Throwable error = context.getError();
/* 145 */     if (error != null) {
/* 146 */       String simpleName = error.getClass().getSimpleName();
/* 147 */       return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.EXCEPTION, 
/* 148 */           StringUtils.hasText(simpleName) ? simpleName : error.getClass().getName());
/*     */     } 
/* 150 */     return EXCEPTION_NONE;
/*     */   }
/*     */   
/*     */   protected KeyValue outcome(ClientRequestObservationContext context) {
/* 154 */     if (context.getResponse() != null) {
/*     */       try {
/* 156 */         return HttpOutcome.forStatus(((ClientHttpResponse)context.getResponse()).getStatusCode());
/*     */       }
/* 158 */       catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 162 */     return HTTP_OUTCOME_UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getHighCardinalityKeyValues(ClientRequestObservationContext context) {
/* 168 */     return KeyValues.of(new KeyValue[] { requestUri(context) });
/*     */   }
/*     */   
/*     */   protected KeyValue requestUri(ClientRequestObservationContext context) {
/* 172 */     if (context.getCarrier() != null) {
/* 173 */       return KeyValue.of(ClientHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL, ((ClientHttpRequest)context.getCarrier()).getURI().toASCIIString());
/*     */     }
/* 175 */     return HTTP_URL_NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   static class HttpOutcome
/*     */   {
/*     */     static KeyValue forStatus(HttpStatusCode statusCode) {
/* 182 */       if (statusCode.is2xxSuccessful()) {
/* 183 */         return DefaultClientRequestObservationConvention.HTTP_OUTCOME_SUCCESS;
/*     */       }
/* 185 */       if (statusCode instanceof HttpStatus) { HttpStatus status = (HttpStatus)statusCode;
/* 186 */         return KeyValue.of(ClientHttpObservationDocumentation.LowCardinalityKeyNames.OUTCOME, status.series().name()); }
/*     */ 
/*     */       
/* 189 */       return DefaultClientRequestObservationConvention.HTTP_OUTCOME_UNKNOWN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\observation\DefaultClientRequestObservationConvention.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */