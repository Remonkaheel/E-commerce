/*     */ package org.springframework.http.client.observation;
/*     */ 
/*     */ import io.micrometer.common.docs.KeyName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum LowCardinalityKeyNames
/*     */   implements KeyName
/*     */ {
/*  67 */   METHOD
/*     */   {
/*     */     public String asString() {
/*  70 */       return "method";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   URI
/*     */   {
/*     */     public String asString() {
/*  82 */       return "uri";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   STATUS
/*     */   {
/*     */     public String asString() {
/*  93 */       return "status";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   CLIENT_NAME
/*     */   {
/*     */     public String asString() {
/* 104 */       return "client.name";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   EXCEPTION
/*     */   {
/*     */     public String asString() {
/* 115 */       return "exception";
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   OUTCOME
/*     */   {
/*     */     public String asString() {
/* 126 */       return "outcome";
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\observation\ClientHttpObservationDocumentation$LowCardinalityKeyNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */