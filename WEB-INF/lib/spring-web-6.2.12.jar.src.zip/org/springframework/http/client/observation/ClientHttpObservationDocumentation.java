/*     */ package org.springframework.http.client.observation;
/*     */ 
/*     */ import io.micrometer.common.docs.KeyName;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.docs.ObservationDocumentation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ClientHttpObservationDocumentation
/*     */   implements ObservationDocumentation
/*     */ {
/*  43 */   HTTP_CLIENT_EXCHANGES
/*     */   {
/*     */     public Class<? extends ObservationConvention<? extends Observation.Context>> getDefaultConvention() {
/*  46 */       return (Class)DefaultClientRequestObservationConvention.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public KeyName[] getLowCardinalityKeyNames() {
/*  51 */       return (KeyName[])LowCardinalityKeyNames.values();
/*     */     }
/*     */ 
/*     */     
/*     */     public KeyName[] getHighCardinalityKeyNames() {
/*  56 */       return new KeyName[] { HighCardinalityKeyNames.HTTP_URL };
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum LowCardinalityKeyNames
/*     */     implements KeyName
/*     */   {
/*  67 */     METHOD
/*     */     {
/*     */       public String asString() {
/*  70 */         return "method";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     URI
/*     */     {
/*     */       public String asString() {
/*  82 */         return "uri";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     STATUS
/*     */     {
/*     */       public String asString() {
/*  93 */         return "status";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     CLIENT_NAME
/*     */     {
/*     */       public String asString() {
/* 104 */         return "client.name";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     EXCEPTION
/*     */     {
/*     */       public String asString() {
/* 115 */         return "exception";
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     OUTCOME
/*     */     {
/*     */       public String asString() {
/* 126 */         return "outcome"; } }; } enum null { public String asString() { return "method"; } } enum null { public String asString() { return "uri"; } } enum null { public String asString() { return "status"; } } enum null { public String asString() { return "client.name"; } } enum null { public String asString() { return "exception"; } } enum null { public String asString() { return "outcome"; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum HighCardinalityKeyNames
/*     */     implements KeyName
/*     */   {
/* 137 */     HTTP_URL
/*     */     {
/*     */       public String asString() {
/* 140 */         return "http.url"; } }; } enum null { public String asString() { return "http.url"; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\observation\ClientHttpObservationDocumentation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */