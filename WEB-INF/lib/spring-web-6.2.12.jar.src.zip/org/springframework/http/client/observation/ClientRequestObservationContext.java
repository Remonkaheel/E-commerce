/*    */ package org.springframework.http.client.observation;
/*    */ 
/*    */ import io.micrometer.observation.transport.RequestReplySenderContext;
/*    */ import org.springframework.http.client.ClientHttpRequest;
/*    */ import org.springframework.http.client.ClientHttpResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientRequestObservationContext
/*    */   extends RequestReplySenderContext<ClientHttpRequest, ClientHttpResponse>
/*    */ {
/*    */   @Nullable
/*    */   private String uriTemplate;
/*    */   
/*    */   public ClientRequestObservationContext(ClientHttpRequest request) {
/* 46 */     super(ClientRequestObservationContext::setRequestHeader);
/* 47 */     setCarrier(request);
/*    */   }
/*    */   
/*    */   private static void setRequestHeader(@Nullable ClientHttpRequest request, String name, String value) {
/* 51 */     if (request != null) {
/* 52 */       request.getHeaders().set(name, value);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUriTemplate(@Nullable String uriTemplate) {
/* 61 */     this.uriTemplate = uriTemplate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getUriTemplate() {
/* 69 */     return this.uriTemplate;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\observation\ClientRequestObservationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */