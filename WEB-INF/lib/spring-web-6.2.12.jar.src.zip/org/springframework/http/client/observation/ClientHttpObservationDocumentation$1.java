/*    */ package org.springframework.http.client.observation;
/*    */ 
/*    */ import io.micrometer.common.docs.KeyName;
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationConvention;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum null
/*    */ {
/*    */   public Class<? extends ObservationConvention<? extends Observation.Context>> getDefaultConvention() {
/* 46 */     return (Class)DefaultClientRequestObservationConvention.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyName[] getLowCardinalityKeyNames() {
/* 51 */     return (KeyName[])ClientHttpObservationDocumentation.LowCardinalityKeyNames.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyName[] getHighCardinalityKeyNames() {
/* 56 */     return new KeyName[] { ClientHttpObservationDocumentation.HighCardinalityKeyNames.HTTP_URL };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\observation\ClientHttpObservationDocumentation$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */