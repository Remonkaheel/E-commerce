/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.net.URI;
/*     */ import java.net.http.HttpClient;
/*     */ import java.net.http.HttpRequest;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.net.http.HttpTimeoutException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*  58 */   private static final OutputStreamPublisher.ByteMapper<ByteBuffer> BYTE_MAPPER = new ByteBufferMapper();
/*     */   
/*  60 */   private static final Set<String> DISALLOWED_HEADERS = disallowedHeaders();
/*     */ 
/*     */   
/*     */   private final HttpClient httpClient;
/*     */ 
/*     */   
/*     */   private final HttpMethod method;
/*     */ 
/*     */   
/*     */   private final URI uri;
/*     */   
/*     */   private final Executor executor;
/*     */   
/*     */   @Nullable
/*     */   private final Duration timeout;
/*     */ 
/*     */   
/*     */   public JdkClientHttpRequest(HttpClient httpClient, URI uri, HttpMethod method, Executor executor, @Nullable Duration readTimeout) {
/*  78 */     this.httpClient = httpClient;
/*  79 */     this.uri = uri;
/*  80 */     this.method = method;
/*  81 */     this.executor = executor;
/*  82 */     this.timeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  88 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  93 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/* 100 */     CompletableFuture<HttpResponse<InputStream>> responseFuture = null;
/* 101 */     TimeoutHandler timeoutHandler = null;
/*     */     try {
/* 103 */       HttpRequest request = buildRequest(headers, body);
/* 104 */       responseFuture = this.httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofInputStream());
/*     */       
/* 106 */       if (this.timeout != null) {
/* 107 */         timeoutHandler = new TimeoutHandler(responseFuture, this.timeout);
/* 108 */         HttpResponse<InputStream> httpResponse = responseFuture.get();
/* 109 */         InputStream inputStream = timeoutHandler.wrapInputStream(httpResponse);
/* 110 */         return new JdkClientHttpResponse(httpResponse, inputStream);
/*     */       } 
/*     */       
/* 113 */       HttpResponse<InputStream> response = responseFuture.get();
/* 114 */       return new JdkClientHttpResponse(response, response.body());
/*     */     
/*     */     }
/* 117 */     catch (InterruptedException ex) {
/* 118 */       Thread.currentThread().interrupt();
/* 119 */       responseFuture.cancel(true);
/* 120 */       throw new IOException("Request was interrupted: " + ex.getMessage(), ex);
/*     */     }
/* 122 */     catch (ExecutionException ex) {
/* 123 */       Throwable cause = ex.getCause();
/*     */       
/* 125 */       if (cause instanceof CancellationException) { CancellationException ce = (CancellationException)cause;
/* 126 */         if (timeoutHandler != null) {
/* 127 */           timeoutHandler.handleCancellationException(ce);
/*     */         }
/* 129 */         throw new IOException("Request cancelled", cause); }
/*     */       
/* 131 */       if (cause instanceof UncheckedIOException) { UncheckedIOException uioEx = (UncheckedIOException)cause;
/* 132 */         throw uioEx.getCause(); }
/*     */       
/* 134 */       if (cause instanceof RuntimeException) { RuntimeException rtEx = (RuntimeException)cause;
/* 135 */         throw rtEx; }
/*     */       
/* 137 */       if (cause instanceof IOException) { IOException ioEx = (IOException)cause;
/* 138 */         throw ioEx; }
/*     */ 
/*     */       
/* 141 */       throw new IOException(cause.getMessage(), cause);
/*     */     
/*     */     }
/* 144 */     catch (CancellationException ex) {
/* 145 */       if (timeoutHandler != null) {
/* 146 */         timeoutHandler.handleCancellationException(ex);
/*     */       }
/* 148 */       throw new IOException("Request cancelled", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private HttpRequest buildRequest(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) {
/* 153 */     HttpRequest.Builder builder = HttpRequest.newBuilder().uri(this.uri);
/*     */     
/* 155 */     headers.forEach((headerName, headerValues) -> {
/*     */           if (!DISALLOWED_HEADERS.contains(headerName.toLowerCase(Locale.ROOT))) {
/*     */             for (String headerValue : headerValues) {
/*     */               builder.header(headerName, headerValue);
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 163 */     if (body != null)
/* 164 */     { builder.method(this.method.name(), bodyPublisher(headers, body)); }
/*     */     else
/*     */     
/* 167 */     { switch (this.method.name())
/*     */       { case "GET":
/* 169 */           builder.GET();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 178 */           return builder.build();case "DELETE": builder.DELETE(); return builder.build(); }  builder.method(this.method.name(), HttpRequest.BodyPublishers.noBody()); }  return builder.build();
/*     */   }
/*     */   
/*     */   private HttpRequest.BodyPublisher bodyPublisher(HttpHeaders headers, StreamingHttpOutputMessage.Body body) {
/* 182 */     Flow.Publisher<ByteBuffer> publisher = new OutputStreamPublisher<>(os -> body.writeTo(StreamUtils.nonClosing(os)), BYTE_MAPPER, this.executor, null);
/*     */ 
/*     */     
/* 185 */     long contentLength = headers.getContentLength();
/* 186 */     if (contentLength > 0L) {
/* 187 */       return HttpRequest.BodyPublishers.fromPublisher(publisher, contentLength);
/*     */     }
/* 189 */     if (contentLength == 0L) {
/* 190 */       return HttpRequest.BodyPublishers.noBody();
/*     */     }
/*     */     
/* 193 */     return HttpRequest.BodyPublishers.fromPublisher(publisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set<String> disallowedHeaders() {
/* 205 */     TreeSet<String> headers = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
/* 206 */     headers.addAll(Set.of("connection", "content-length", "expect", "host", "upgrade"));
/*     */     
/* 208 */     String headersToAllow = System.getProperty("jdk.httpclient.allowRestrictedHeaders");
/* 209 */     if (headersToAllow != null) {
/* 210 */       Set<String> toAllow = StringUtils.commaDelimitedListToSet(headersToAllow);
/* 211 */       headers.removeAll(toAllow);
/*     */     } 
/* 213 */     return Collections.unmodifiableSet(headers);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ByteBufferMapper
/*     */     implements OutputStreamPublisher.ByteMapper<ByteBuffer>
/*     */   {
/*     */     public ByteBuffer map(int b) {
/* 221 */       ByteBuffer byteBuffer = ByteBuffer.allocate(1);
/* 222 */       byteBuffer.put((byte)b);
/* 223 */       byteBuffer.flip();
/* 224 */       return byteBuffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public ByteBuffer map(byte[] b, int off, int len) {
/* 229 */       ByteBuffer byteBuffer = ByteBuffer.allocate(len);
/* 230 */       byteBuffer.put(b, off, len);
/* 231 */       byteBuffer.flip();
/* 232 */       return byteBuffer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class TimeoutHandler
/*     */   {
/*     */     private final CompletableFuture<Void> timeoutFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     private final AtomicBoolean timeout = new AtomicBoolean(false);
/*     */ 
/*     */     
/*     */     private TimeoutHandler(CompletableFuture<HttpResponse<InputStream>> future, Duration timeout) {
/* 252 */       this
/* 253 */         .timeoutFuture = (new CompletableFuture<>()).completeOnTimeout(null, timeout.toMillis(), TimeUnit.MILLISECONDS);
/*     */       
/* 255 */       this.timeoutFuture.thenRun(() -> {
/*     */             this.timeout.set(true);
/*     */             
/*     */             if (future.cancel(true) || future.isCompletedExceptionally() || !future.isDone()) {
/*     */               return;
/*     */             }
/*     */             try {
/*     */               ((InputStream)((HttpResponse<InputStream>)future.get()).body()).close();
/* 263 */             } catch (Exception exception) {}
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public InputStream wrapInputStream(HttpResponse<InputStream> response) {
/* 271 */       InputStream body = response.body();
/* 272 */       if (body == null) {
/* 273 */         return body;
/*     */       }
/* 275 */       return new FilterInputStream(body)
/*     */         {
/*     */           public void close() throws IOException
/*     */           {
/* 279 */             JdkClientHttpRequest.TimeoutHandler.this.timeoutFuture.cancel(false);
/* 280 */             super.close();
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public void handleCancellationException(CancellationException ex) throws HttpTimeoutException {
/* 286 */       if (this.timeout.get())
/* 287 */         throw new HttpTimeoutException(ex.getMessage()); 
/*     */     }
/*     */   }
/*     */   
/*     */   class null extends FilterInputStream {
/*     */     null(InputStream in) {
/*     */       super(in);
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/*     */       JdkClientHttpRequest.TimeoutHandler.this.timeoutFuture.cancel(false);
/*     */       super.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JdkClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */