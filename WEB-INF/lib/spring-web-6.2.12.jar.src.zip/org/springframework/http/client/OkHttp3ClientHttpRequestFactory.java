/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Cache;
/*     */ import okhttp3.OkHttpClient;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.1", forRemoval = true)
/*     */ public class OkHttp3ClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private OkHttpClient client;
/*     */   private final boolean defaultClient;
/*     */   
/*     */   public OkHttp3ClientHttpRequestFactory() {
/*  54 */     this.client = new OkHttpClient();
/*  55 */     this.defaultClient = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OkHttp3ClientHttpRequestFactory(OkHttpClient client) {
/*  63 */     Assert.notNull(client, "OkHttpClient must not be null");
/*  64 */     this.client = client;
/*  65 */     this.defaultClient = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(int readTimeout) {
/*  74 */     this
/*     */       
/*  76 */       .client = this.client.newBuilder().readTimeout(readTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/*  85 */     this
/*     */       
/*  87 */       .client = this.client.newBuilder().readTimeout(readTimeout).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteTimeout(int writeTimeout) {
/*  95 */     this
/*     */       
/*  97 */       .client = this.client.newBuilder().writeTimeout(writeTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteTimeout(Duration writeTimeout) {
/* 106 */     this
/*     */       
/* 108 */       .client = this.client.newBuilder().writeTimeout(writeTimeout).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(int connectTimeout) {
/* 116 */     this
/*     */       
/* 118 */       .client = this.client.newBuilder().connectTimeout(connectTimeout, TimeUnit.MILLISECONDS).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 127 */     this
/*     */       
/* 129 */       .client = this.client.newBuilder().connectTimeout(connectTimeout).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) {
/* 136 */     return new OkHttp3ClientHttpRequest(this.client, uri, httpMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws IOException {
/* 142 */     if (this.defaultClient) {
/*     */       
/* 144 */       Cache cache = this.client.cache();
/* 145 */       if (cache != null) {
/* 146 */         cache.close();
/*     */       }
/* 148 */       this.client.dispatcher().executorService().shutdown();
/* 149 */       this.client.connectionPool().evictAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OkHttp3ClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */