/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.Exceptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SubscriberInputStream<T>
/*     */   extends InputStream
/*     */   implements Flow.Subscriber<T>
/*     */ {
/*  63 */   private static final Log logger = LogFactory.getLog(SubscriberInputStream.class);
/*     */   
/*  65 */   private static final Object READY = new Object();
/*     */   
/*  67 */   private static final byte[] DONE = new byte[0];
/*     */   
/*  69 */   private static final byte[] CLOSED = new byte[0];
/*     */ 
/*     */   
/*     */   private final Function<T, byte[]> mapper;
/*     */   
/*     */   private final Consumer<T> onDiscardHandler;
/*     */   
/*     */   private final int prefetch;
/*     */   
/*     */   private final int limit;
/*     */   
/*     */   private final ReentrantLock lock;
/*     */   
/*     */   private final Queue<T> queue;
/*     */   
/*  84 */   private final AtomicReference<Object> parkedThread = new AtomicReference();
/*     */   
/*  86 */   private final AtomicInteger workAmount = new AtomicInteger();
/*     */ 
/*     */ 
/*     */   
/*     */   volatile boolean closed;
/*     */ 
/*     */   
/*     */   private int consumed;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private byte[] available;
/*     */ 
/*     */   
/*     */   private int position;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Flow.Subscription subscription;
/*     */ 
/*     */   
/*     */   private boolean done;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Throwable error;
/*     */ 
/*     */ 
/*     */   
/*     */   SubscriberInputStream(Function<T, byte[]> mapper, Consumer<T> onDiscardHandler, int demand) {
/* 116 */     Assert.notNull(mapper, "mapper must not be null");
/* 117 */     Assert.notNull(onDiscardHandler, "onDiscardHandler must not be null");
/* 118 */     Assert.isTrue((demand > 0), "demand must be greater than 0");
/*     */     
/* 120 */     this.mapper = mapper;
/* 121 */     this.onDiscardHandler = onDiscardHandler;
/* 122 */     this.prefetch = demand;
/* 123 */     this.limit = (demand == Integer.MAX_VALUE) ? Integer.MAX_VALUE : (demand - (demand >> 2));
/* 124 */     this.queue = new ArrayBlockingQueue<>(demand);
/* 125 */     this.lock = new ReentrantLock(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSubscribe(Flow.Subscription subscription) {
/* 131 */     if (this.subscription != null) {
/* 132 */       subscription.cancel();
/*     */       
/*     */       return;
/*     */     } 
/* 136 */     this.subscription = subscription;
/* 137 */     subscription.request((this.prefetch == Integer.MAX_VALUE) ? Long.MAX_VALUE : this.prefetch);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T buffer) {
/* 142 */     Assert.notNull(buffer, "Buffer must not be null");
/*     */     
/* 144 */     if (this.done) {
/* 145 */       discard(buffer);
/*     */       
/*     */       return;
/*     */     } 
/* 149 */     if (!this.queue.offer(buffer)) {
/* 150 */       discard(buffer);
/* 151 */       this.error = new RuntimeException("Buffer overflow");
/* 152 */       this.done = true;
/*     */     } 
/*     */     
/* 155 */     int previousWorkState = addWork();
/* 156 */     if (previousWorkState == Integer.MIN_VALUE) {
/* 157 */       T value = this.queue.poll();
/* 158 */       if (value != null) {
/* 159 */         discard(value);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 164 */     if (previousWorkState == 0) {
/* 165 */       resume();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable throwable) {
/* 171 */     if (this.done) {
/*     */       return;
/*     */     }
/* 174 */     this.error = throwable;
/* 175 */     this.done = true;
/*     */     
/* 177 */     if (addWork() == 0) {
/* 178 */       resume();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 184 */     if (this.done) {
/*     */       return;
/*     */     }
/*     */     
/* 188 */     this.done = true;
/*     */     
/* 190 */     if (addWork() == 0) {
/* 191 */       resume();
/*     */     }
/*     */   }
/*     */   
/*     */   int addWork() {
/*     */     while (true) {
/* 197 */       int produced = this.workAmount.getPlain();
/*     */       
/* 199 */       if (produced == Integer.MIN_VALUE) {
/* 200 */         return Integer.MIN_VALUE;
/*     */       }
/*     */       
/* 203 */       int nextProduced = (produced == Integer.MAX_VALUE) ? 1 : (produced + 1);
/*     */       
/* 205 */       if (this.workAmount.weakCompareAndSetRelease(produced, nextProduced)) {
/* 206 */         return produced;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resume() {
/* 212 */     if (this.parkedThread != READY) {
/* 213 */       Object old = this.parkedThread.getAndSet(READY);
/* 214 */       if (old != READY) {
/* 215 */         LockSupport.unpark((Thread)old);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 224 */     if (!this.lock.tryLock()) {
/* 225 */       if (this.closed) {
/* 226 */         return -1;
/*     */       }
/* 228 */       throw new ConcurrentModificationException("Concurrent access is not allowed");
/*     */     } 
/*     */     
/*     */     try {
/* 232 */       byte[] next = getNextOrAwait();
/*     */       
/* 234 */       if (next == DONE) {
/* 235 */         this.closed = true;
/* 236 */         cleanAndFinalize();
/* 237 */         if (this.error == null) {
/* 238 */           return -1;
/*     */         }
/*     */         
/* 241 */         throw Exceptions.propagate(this.error);
/*     */       } 
/*     */       
/* 244 */       if (next == CLOSED) {
/* 245 */         cleanAndFinalize();
/* 246 */         return -1;
/*     */       } 
/*     */       
/* 249 */       return next[this.position++] & 0xFF;
/*     */     }
/* 251 */     catch (Throwable ex) {
/* 252 */       this.closed = true;
/* 253 */       requiredSubscriber().cancel();
/* 254 */       cleanAndFinalize();
/* 255 */       throw Exceptions.propagate(ex);
/*     */     } finally {
/*     */       
/* 258 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 264 */     Objects.checkFromIndexSize(off, len, b.length);
/* 265 */     if (len == 0) {
/* 266 */       return 0;
/*     */     }
/*     */     
/* 269 */     if (!this.lock.tryLock()) {
/* 270 */       if (this.closed) {
/* 271 */         return -1;
/*     */       }
/* 273 */       throw new ConcurrentModificationException("concurrent access is disallowed");
/*     */     } 
/*     */     try {
/*     */       int j;
/* 277 */       for (j = 0; j < len; ) {
/* 278 */         byte[] next = getNextOrAwait();
/*     */         
/* 280 */         if (next == DONE) {
/* 281 */           cleanAndFinalize();
/* 282 */           if (this.error == null) {
/* 283 */             this.closed = true;
/* 284 */             return (j == 0) ? -1 : j;
/*     */           } 
/*     */           
/* 287 */           if (j == 0) {
/* 288 */             this.closed = true;
/* 289 */             throw Exceptions.propagate(this.error);
/*     */           } 
/*     */           
/* 292 */           return j;
/*     */         } 
/*     */         
/* 295 */         if (next == CLOSED) {
/* 296 */           requiredSubscriber().cancel();
/* 297 */           cleanAndFinalize();
/* 298 */           return -1;
/*     */         } 
/* 300 */         int i = this.position;
/* 301 */         for (; i < next.length && j < len; i++, j++) {
/* 302 */           b[off + j] = next[i];
/*     */         }
/* 304 */         this.position = i;
/*     */       } 
/*     */       
/* 307 */       j = len; return j;
/*     */     }
/* 309 */     catch (Throwable ex) {
/* 310 */       this.closed = true;
/* 311 */       requiredSubscriber().cancel();
/* 312 */       cleanAndFinalize();
/* 313 */       throw Exceptions.propagate(ex);
/*     */     } finally {
/*     */       
/* 316 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   byte[] getNextOrAwait() {
/* 321 */     if (this.available == null || this.available.length - this.position == 0) {
/* 322 */       this.available = null;
/*     */       
/* 324 */       int actualWorkAmount = this.workAmount.getAcquire();
/*     */       while (true) {
/* 326 */         if (this.closed) {
/* 327 */           return CLOSED;
/*     */         }
/*     */         
/* 330 */         boolean done = this.done;
/* 331 */         T buffer = this.queue.poll();
/* 332 */         if (buffer != null) {
/* 333 */           int consumed = ++this.consumed;
/* 334 */           this.position = 0;
/* 335 */           this.available = Objects.<byte[]>requireNonNull(this.mapper.apply(buffer));
/* 336 */           if (consumed == this.limit) {
/* 337 */             this.consumed = 0;
/* 338 */             requiredSubscriber().request(this.limit);
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/* 343 */         if (done) {
/* 344 */           return DONE;
/*     */         }
/*     */         
/* 347 */         actualWorkAmount = this.workAmount.addAndGet(-actualWorkAmount);
/* 348 */         if (actualWorkAmount == 0) {
/* 349 */           await();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 354 */     return this.available;
/*     */   }
/*     */   void cleanAndFinalize() {
/*     */     int workAmount;
/* 358 */     this.available = null;
/*     */     
/*     */     do {
/* 361 */       workAmount = this.workAmount.getPlain();
/*     */       T value;
/* 363 */       while ((value = this.queue.poll()) != null) {
/* 364 */         discard(value);
/*     */       }
/*     */     }
/* 367 */     while (!this.workAmount.weakCompareAndSetPlain(workAmount, -2147483648));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 375 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */     
/* 379 */     this.closed = true;
/*     */     
/* 381 */     if (!this.lock.tryLock()) {
/* 382 */       if (addWork() == 0) {
/* 383 */         resume();
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 389 */       requiredSubscriber().cancel();
/* 390 */       cleanAndFinalize();
/*     */     } finally {
/*     */       
/* 393 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Flow.Subscription requiredSubscriber() {
/* 398 */     Assert.state((this.subscription != null), "Subscriber must be subscribed to use InputStream");
/* 399 */     return this.subscription;
/*     */   }
/*     */   
/*     */   void discard(T buffer) {
/*     */     try {
/* 404 */       this.onDiscardHandler.accept(buffer);
/*     */     }
/* 406 */     catch (Throwable ex) {
/* 407 */       if (logger.isDebugEnabled()) {
/* 408 */         logger.debug("Failed to release " + buffer.getClass().getSimpleName() + ": " + String.valueOf(buffer), ex);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void await() {
/* 414 */     Thread toUnpark = Thread.currentThread();
/*     */     
/*     */     while (true) {
/* 417 */       Object current = this.parkedThread.get();
/* 418 */       if (current == READY) {
/*     */         break;
/*     */       }
/*     */       
/* 422 */       if (current != null && current != toUnpark) {
/* 423 */         throw new IllegalStateException("Only one (Virtual)Thread can await!");
/*     */       }
/*     */       
/* 426 */       if (this.parkedThread.compareAndSet(null, toUnpark)) {
/* 427 */         LockSupport.park();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 433 */     this.parkedThread.lazySet(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\SubscriberInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */