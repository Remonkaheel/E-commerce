/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractClientHttpRequest
/*    */   implements ClientHttpRequest
/*    */ {
/* 37 */   private final HttpHeaders headers = new HttpHeaders();
/*    */ 
/*    */   
/*    */   private boolean executed = false;
/*    */   
/*    */   @Nullable
/*    */   private HttpHeaders readOnlyHeaders;
/*    */   
/*    */   @Nullable
/*    */   private Map<String, Object> attributes;
/*    */ 
/*    */   
/*    */   public final HttpHeaders getHeaders() {
/* 50 */     if (this.readOnlyHeaders != null) {
/* 51 */       return this.readOnlyHeaders;
/*    */     }
/* 53 */     if (this.executed) {
/* 54 */       this.readOnlyHeaders = HttpHeaders.readOnlyHttpHeaders(this.headers);
/* 55 */       return this.readOnlyHeaders;
/*    */     } 
/*    */     
/* 58 */     return this.headers;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final OutputStream getBody() throws IOException {
/* 64 */     assertNotExecuted();
/* 65 */     return getBodyInternal(this.headers);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getAttributes() {
/* 70 */     Map<String, Object> attributes = this.attributes;
/* 71 */     if (attributes == null) {
/* 72 */       attributes = new LinkedHashMap<>();
/* 73 */       this.attributes = attributes;
/*    */     } 
/* 75 */     return attributes;
/*    */   }
/*    */ 
/*    */   
/*    */   public final ClientHttpResponse execute() throws IOException {
/* 80 */     assertNotExecuted();
/* 81 */     ClientHttpResponse result = executeInternal(this.headers);
/* 82 */     this.executed = true;
/* 83 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void assertNotExecuted() {
/* 91 */     Assert.state(!this.executed, "ClientHttpRequest already executed");
/*    */   }
/*    */   
/*    */   protected abstract OutputStream getBodyInternal(HttpHeaders paramHttpHeaders) throws IOException;
/*    */   
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders) throws IOException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\AbstractClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */