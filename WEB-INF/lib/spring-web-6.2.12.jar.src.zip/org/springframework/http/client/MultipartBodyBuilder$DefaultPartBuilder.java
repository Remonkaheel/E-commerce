/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultPartBuilder
/*     */   implements MultipartBodyBuilder.PartBuilder
/*     */ {
/*     */   private final String name;
/*     */   @Nullable
/*     */   protected HttpHeaders headers;
/*     */   @Nullable
/*     */   protected final Object body;
/*     */   
/*     */   public DefaultPartBuilder(String name, @Nullable HttpHeaders headers, @Nullable Object body) {
/* 286 */     this.name = name;
/* 287 */     this.headers = headers;
/* 288 */     this.body = body;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBodyBuilder.PartBuilder contentType(MediaType contentType) {
/* 293 */     initHeadersIfNecessary().setContentType(contentType);
/* 294 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBodyBuilder.PartBuilder filename(String filename) {
/* 299 */     initHeadersIfNecessary().setContentDispositionFormData(this.name, filename);
/* 300 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBodyBuilder.PartBuilder header(String headerName, String... headerValues) {
/* 305 */     initHeadersIfNecessary().addAll(headerName, Arrays.asList(headerValues));
/* 306 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBodyBuilder.PartBuilder headers(Consumer<HttpHeaders> headersConsumer) {
/* 311 */     headersConsumer.accept(initHeadersIfNecessary());
/* 312 */     return this;
/*     */   }
/*     */   
/*     */   private HttpHeaders initHeadersIfNecessary() {
/* 316 */     if (this.headers == null) {
/* 317 */       this.headers = new HttpHeaders();
/*     */     }
/* 319 */     return this.headers;
/*     */   }
/*     */   
/*     */   public HttpEntity<?> build() {
/* 323 */     return new HttpEntity(this.body, (MultiValueMap)this.headers);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\MultipartBodyBuilder$DefaultPartBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */