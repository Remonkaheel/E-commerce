/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleClientHttpRequest
/*     */   extends AbstractStreamingClientHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int chunkSize;
/*     */   
/*     */   SimpleClientHttpRequest(HttpURLConnection connection, int chunkSize) {
/*  46 */     this.connection = connection;
/*  47 */     this.chunkSize = chunkSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  52 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*     */     try {
/*  58 */       return this.connection.getURL().toURI();
/*     */     }
/*  60 */     catch (URISyntaxException ex) {
/*  61 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers, @Nullable StreamingHttpOutputMessage.Body body) throws IOException {
/*  67 */     if (this.connection.getDoOutput()) {
/*  68 */       long contentLength = headers.getContentLength();
/*  69 */       if (contentLength >= 0L) {
/*  70 */         this.connection.setFixedLengthStreamingMode(contentLength);
/*     */       } else {
/*     */         
/*  73 */         this.connection.setChunkedStreamingMode(this.chunkSize);
/*     */       } 
/*     */     } 
/*     */     
/*  77 */     addHeaders(this.connection, headers);
/*     */     
/*  79 */     this.connection.connect();
/*     */     
/*  81 */     if (this.connection.getDoOutput() && body != null)
/*  82 */     { OutputStream os = this.connection.getOutputStream(); 
/*  83 */       try { body.writeTo(os);
/*  84 */         if (os != null) os.close();  } catch (Throwable throwable) { if (os != null)
/*     */           try { os.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */             throw throwable; }
/*     */        }
/*  88 */     else { this.connection.getResponseCode(); }
/*     */     
/*  90 */     return new SimpleClientHttpResponse(this.connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addHeaders(HttpURLConnection connection, HttpHeaders headers) {
/* 100 */     String method = connection.getRequestMethod();
/* 101 */     if ((method.equals("PUT") || method.equals("DELETE")) && 
/* 102 */       !StringUtils.hasText(headers.getFirst("Accept")))
/*     */     {
/*     */       
/* 105 */       headers.set("Accept", "*/*");
/*     */     }
/*     */     
/* 108 */     headers.forEach((headerName, headerValues) -> {
/*     */           if ("Cookie".equalsIgnoreCase(headerName)) {
/*     */             String headerValue = StringUtils.collectionToDelimitedString(headerValues, "; ");
/*     */             connection.setRequestProperty(headerName, headerValue);
/*     */           } else {
/*     */             for (String headerValue : headerValues) {
/*     */               String actualHeaderValue = (headerValue != null) ? headerValue : "";
/*     */               connection.addRequestProperty(headerName, actualHeaderValue);
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\SimpleClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */