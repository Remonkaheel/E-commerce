/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OutputStreamSubscription<T>
/*     */   extends OutputStream
/*     */   implements Flow.Subscription
/*     */ {
/* 125 */   private static final Object READY = new Object();
/*     */   
/*     */   private final Flow.Subscriber<? super T> actual;
/*     */   
/*     */   private final OutputStreamPublisher.OutputStreamHandler outputStreamHandler;
/*     */   
/*     */   private final OutputStreamPublisher.ByteMapper<T> byteMapper;
/*     */   
/*     */   private final int chunkSize;
/*     */   
/* 135 */   private final AtomicLong requested = new AtomicLong();
/*     */   
/* 137 */   private final AtomicReference<Object> parkedThread = new AtomicReference();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile Throwable error;
/*     */ 
/*     */   
/*     */   private long produced;
/*     */ 
/*     */   
/*     */   OutputStreamSubscription(Flow.Subscriber<? super T> actual, OutputStreamPublisher.OutputStreamHandler outputStreamHandler, OutputStreamPublisher.ByteMapper<T> byteMapper, int chunkSize) {
/* 148 */     this.actual = actual;
/* 149 */     this.outputStreamHandler = outputStreamHandler;
/* 150 */     this.byteMapper = byteMapper;
/* 151 */     this.chunkSize = chunkSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 156 */     checkDemandAndAwaitIfNeeded();
/* 157 */     T next = this.byteMapper.map(b);
/* 158 */     this.actual.onNext(next);
/* 159 */     this.produced++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 164 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 169 */     checkDemandAndAwaitIfNeeded();
/* 170 */     T next = this.byteMapper.map(b, off, len);
/* 171 */     this.actual.onNext(next);
/* 172 */     this.produced++;
/*     */   }
/*     */   
/*     */   private void checkDemandAndAwaitIfNeeded() throws IOException {
/* 176 */     long r = this.requested.get();
/*     */     
/* 178 */     if (isTerminated(r) || isCancelled(r)) {
/* 179 */       throw new IOException("Subscription has been terminated");
/*     */     }
/*     */     
/* 182 */     long p = this.produced;
/* 183 */     if (p == r) {
/* 184 */       if (p > 0L) {
/* 185 */         r = tryProduce(p);
/* 186 */         this.produced = 0L;
/*     */       } 
/*     */       
/*     */       while (true) {
/* 190 */         if (isTerminated(r) || isCancelled(r)) {
/* 191 */           throw new IOException("Subscription has been terminated");
/*     */         }
/*     */         
/* 194 */         if (r != 0L) {
/*     */           return;
/*     */         }
/*     */         
/* 198 */         await();
/*     */         
/* 200 */         r = this.requested.get();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeHandler() {
/*     */     try {
/* 210 */       OutputStream outputStream = new BufferedOutputStream(this, this.chunkSize); 
/* 211 */       try { this.outputStreamHandler.handle(outputStream);
/* 212 */         outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 213 */     } catch (Exception ex) {
/* 214 */       long l = tryTerminate();
/* 215 */       if (isCancelled(l)) {
/*     */         return;
/*     */       }
/* 218 */       if (isTerminated(l)) {
/*     */         
/* 220 */         Throwable error = this.error;
/* 221 */         if (error != null) {
/* 222 */           this.actual.onError(error);
/*     */           return;
/*     */         } 
/*     */       } 
/* 226 */       this.actual.onError(ex);
/*     */       
/*     */       return;
/*     */     } 
/* 230 */     long previousState = tryTerminate();
/* 231 */     if (isCancelled(previousState)) {
/*     */       return;
/*     */     }
/* 234 */     if (isTerminated(previousState)) {
/*     */       
/* 236 */       Throwable error = this.error;
/* 237 */       if (error != null) {
/* 238 */         this.actual.onError(error);
/*     */         return;
/*     */       } 
/*     */     } 
/* 242 */     this.actual.onComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 248 */     if (n <= 0L) {
/* 249 */       this.error = new IllegalArgumentException("request should be a positive number");
/* 250 */       long previousState = tryTerminate();
/* 251 */       if (isTerminated(previousState) || isCancelled(previousState)) {
/*     */         return;
/*     */       }
/* 254 */       if (previousState > 0L) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 259 */       resume();
/*     */       
/*     */       return;
/*     */     } 
/* 263 */     if (addCap(n) == 0L)
/*     */     {
/* 265 */       resume();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 271 */     long previousState = tryCancel();
/* 272 */     if (isCancelled(previousState) || previousState > 0L) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 277 */     resume();
/*     */   }
/*     */   
/*     */   private void await() {
/* 281 */     Thread toUnpark = Thread.currentThread();
/*     */     
/*     */     while (true) {
/* 284 */       Object current = this.parkedThread.get();
/* 285 */       if (current == READY) {
/*     */         break;
/*     */       }
/*     */       
/* 289 */       if (current != null && current != toUnpark) {
/* 290 */         throw new IllegalStateException("Only one (Virtual)Thread can await!");
/*     */       }
/*     */       
/* 293 */       if (this.parkedThread.compareAndSet(null, toUnpark)) {
/* 294 */         LockSupport.park();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 300 */     this.parkedThread.lazySet(null);
/*     */   }
/*     */   
/*     */   private void resume() {
/* 304 */     if (this.parkedThread.get() != READY) {
/* 305 */       Object old = this.parkedThread.getAndSet(READY);
/* 306 */       if (old != READY) {
/* 307 */         LockSupport.unpark((Thread)old);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private long tryCancel() {
/*     */     while (true) {
/* 314 */       long r = this.requested.get();
/* 315 */       if (isCancelled(r)) {
/* 316 */         return r;
/*     */       }
/* 318 */       if (this.requested.compareAndSet(r, Long.MIN_VALUE)) {
/* 319 */         return r;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private long tryTerminate() {
/*     */     while (true) {
/* 326 */       long r = this.requested.get();
/* 327 */       if (isCancelled(r) || isTerminated(r)) {
/* 328 */         return r;
/*     */       }
/* 330 */       if (this.requested.compareAndSet(r, -1L)) {
/* 331 */         return r;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private long tryProduce(long n) {
/*     */     while (true) {
/* 338 */       long current = this.requested.get();
/* 339 */       if (isTerminated(current) || isCancelled(current)) {
/* 340 */         return current;
/*     */       }
/* 342 */       if (current == Long.MAX_VALUE) {
/* 343 */         return Long.MAX_VALUE;
/*     */       }
/* 345 */       long update = current - n;
/* 346 */       if (update < 0L) {
/* 347 */         update = 0L;
/*     */       }
/* 349 */       if (this.requested.compareAndSet(current, update)) {
/* 350 */         return update;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private long addCap(long n) {
/*     */     while (true) {
/* 357 */       long r = this.requested.get();
/* 358 */       if (isTerminated(r) || isCancelled(r) || r == Long.MAX_VALUE) {
/* 359 */         return r;
/*     */       }
/* 361 */       long u = addCap(r, n);
/* 362 */       if (this.requested.compareAndSet(r, u)) {
/* 363 */         return r;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isTerminated(long state) {
/* 369 */     return (state == -1L);
/*     */   }
/*     */   
/*     */   private static boolean isCancelled(long state) {
/* 373 */     return (state == Long.MIN_VALUE);
/*     */   }
/*     */   
/*     */   private static long addCap(long a, long b) {
/* 377 */     long res = a + b;
/* 378 */     if (res < 0L) {
/* 379 */       return Long.MAX_VALUE;
/*     */     }
/* 381 */     return res;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OutputStreamPublisher$OutputStreamSubscription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */