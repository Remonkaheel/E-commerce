/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.http.HttpClient;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   private final Executor executor;
/*     */   @Nullable
/*     */   private Duration readTimeout;
/*     */   
/*     */   public JdkClientHttpRequestFactory() {
/*  52 */     this(HttpClient.newHttpClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpRequestFactory(HttpClient httpClient) {
/*  61 */     Assert.notNull(httpClient, "HttpClient is required");
/*  62 */     this.httpClient = httpClient;
/*  63 */     this.executor = httpClient.executor().orElseGet(org.springframework.core.task.SimpleAsyncTaskExecutor::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpRequestFactory(HttpClient httpClient, Executor executor) {
/*  73 */     Assert.notNull(httpClient, "HttpClient is required");
/*  74 */     Assert.notNull(executor, "Executor must not be null");
/*  75 */     this.httpClient = httpClient;
/*  76 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(int readTimeout) {
/*  87 */     this.readTimeout = Duration.ofMillis(readTimeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/*  96 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/* 102 */     return new JdkClientHttpRequest(this.httpClient, uri, httpMethod, this.executor, this.readTimeout);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\JdkClientHttpRequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */