/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import okhttp3.MediaType;
/*     */ import okhttp3.RequestBody;
/*     */ import okio.BufferedSink;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BodyRequestBody
/*     */   extends RequestBody
/*     */ {
/*     */   private final HttpHeaders headers;
/*     */   private final StreamingHttpOutputMessage.Body body;
/*     */   
/*     */   public BodyRequestBody(HttpHeaders headers, StreamingHttpOutputMessage.Body body) {
/* 109 */     this.headers = headers;
/* 110 */     this.body = body;
/*     */   }
/*     */ 
/*     */   
/*     */   public long contentLength() {
/* 115 */     return this.headers.getContentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MediaType contentType() {
/* 121 */     String contentType = this.headers.getFirst("Content-Type");
/* 122 */     if (StringUtils.hasText(contentType)) {
/* 123 */       return MediaType.parse(contentType);
/*     */     }
/*     */     
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(BufferedSink sink) throws IOException {
/* 132 */     this.body.writeTo(sink.outputStream());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOneShot() {
/* 137 */     return !this.body.repeatable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OkHttp3ClientHttpRequest$BodyRequestBody.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */