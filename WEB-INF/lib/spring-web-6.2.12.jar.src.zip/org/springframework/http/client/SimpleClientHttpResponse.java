/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.util.Objects;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   @Nullable
/*     */   private HttpHeaders headers;
/*     */   @Nullable
/*     */   private InputStream responseStream;
/*     */   
/*     */   SimpleClientHttpResponse(HttpURLConnection connection) {
/*  50 */     this.connection = connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() throws IOException {
/*  56 */     return HttpStatusCode.valueOf(this.connection.getResponseCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatusText() throws IOException {
/*  61 */     String result = this.connection.getResponseMessage();
/*  62 */     return (result != null) ? result : "";
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  67 */     if (this.headers == null) {
/*  68 */       this.headers = new HttpHeaders();
/*     */       
/*  70 */       String name = this.connection.getHeaderFieldKey(0);
/*  71 */       if (StringUtils.hasLength(name)) {
/*  72 */         this.headers.add(name, this.connection.getHeaderField(0));
/*     */       }
/*  74 */       int i = 1;
/*     */       while (true) {
/*  76 */         name = this.connection.getHeaderFieldKey(i);
/*  77 */         if (!StringUtils.hasLength(name)) {
/*     */           break;
/*     */         }
/*  80 */         this.headers.add(name, this.connection.getHeaderField(i));
/*  81 */         i++;
/*     */       } 
/*     */     } 
/*  84 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBody() throws IOException {
/*  89 */     if (this.responseStream == null) {
/*  90 */       if (this.connection.getResponseCode() >= 400) {
/*  91 */         InputStream errorStream = this.connection.getErrorStream();
/*  92 */         this.responseStream = (errorStream != null) ? errorStream : InputStream.nullInputStream();
/*     */       } else {
/*     */         
/*  95 */         this.responseStream = this.connection.getInputStream();
/*     */       } 
/*     */     }
/*  98 */     return this.responseStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 104 */       if (this.responseStream == null) {
/* 105 */         getBody();
/*     */       }
/* 107 */       Objects.requireNonNull(this.responseStream);
/* 108 */       StreamUtils.drain(this.responseStream);
/* 109 */       this.responseStream.close();
/*     */     }
/* 111 */     catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\SimpleClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */