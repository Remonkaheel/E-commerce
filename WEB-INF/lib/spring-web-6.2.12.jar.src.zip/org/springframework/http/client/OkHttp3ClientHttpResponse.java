/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import okhttp3.Response;
/*    */ import okhttp3.ResponseBody;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.1", forRemoval = true)
/*    */ class OkHttp3ClientHttpResponse
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final Response response;
/*    */   @Nullable
/*    */   private volatile HttpHeaders headers;
/*    */   
/*    */   public OkHttp3ClientHttpResponse(Response response) {
/* 50 */     Assert.notNull(response, "Response must not be null");
/* 51 */     this.response = response;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusCode getStatusCode() throws IOException {
/* 57 */     return HttpStatusCode.valueOf(this.response.code());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStatusText() {
/* 62 */     return this.response.message();
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getBody() throws IOException {
/* 67 */     ResponseBody body = this.response.body();
/* 68 */     return (body != null) ? body.byteStream() : InputStream.nullInputStream();
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpHeaders getHeaders() {
/* 73 */     HttpHeaders headers = this.headers;
/* 74 */     if (headers == null) {
/* 75 */       headers = new HttpHeaders();
/* 76 */       for (String headerName : this.response.headers().names()) {
/* 77 */         for (String headerValue : this.response.headers(headerName)) {
/* 78 */           headers.add(headerName, headerValue);
/*    */         }
/*    */       } 
/* 81 */       this.headers = headers;
/*    */     } 
/* 83 */     return headers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 88 */     ResponseBody body = this.response.body();
/* 89 */     if (body != null)
/* 90 */       body.close(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OkHttp3ClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */