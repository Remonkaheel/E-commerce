/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import org.springframework.http.HttpInputMessage;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ClientHttpResponse
/*    */   extends HttpInputMessage, Closeable
/*    */ {
/*    */   HttpStatusCode getStatusCode() throws IOException;
/*    */   
/*    */   @Deprecated(since = "6.0", forRemoval = true)
/*    */   default int getRawStatusCode() throws IOException {
/* 55 */     return getStatusCode().value();
/*    */   }
/*    */   
/*    */   String getStatusText() throws IOException;
/*    */   
/*    */   void close();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */