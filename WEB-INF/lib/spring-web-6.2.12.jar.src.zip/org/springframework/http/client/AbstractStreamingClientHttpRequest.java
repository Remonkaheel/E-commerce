/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.StreamingHttpOutputMessage;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.FastByteArrayOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractStreamingClientHttpRequest
/*    */   extends AbstractClientHttpRequest
/*    */   implements StreamingHttpOutputMessage
/*    */ {
/*    */   @Nullable
/*    */   private StreamingHttpOutputMessage.Body body;
/*    */   @Nullable
/*    */   private FastByteArrayOutputStream bodyStream;
/*    */   
/*    */   protected final OutputStream getBodyInternal(HttpHeaders headers) {
/* 48 */     Assert.state((this.body == null), "Invoke either getBody or setBody; not both");
/*    */     
/* 50 */     if (this.bodyStream == null) {
/* 51 */       this.bodyStream = new FastByteArrayOutputStream(1024);
/*    */     }
/* 53 */     return (OutputStream)this.bodyStream;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setBody(StreamingHttpOutputMessage.Body body) {
/* 58 */     Assert.notNull(body, "Body must not be null");
/* 59 */     assertNotExecuted();
/* 60 */     Assert.state((this.bodyStream == null), "Invoke either getBody or setBody; not both");
/*    */     
/* 62 */     this.body = body;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException {
/* 68 */     if (this.body == null && this.bodyStream != null) {
/* 69 */       this.body = (outputStream -> this.bodyStream.writeTo(outputStream));
/*    */     }
/* 71 */     return executeInternal(headers, this.body);
/*    */   }
/*    */   
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders, @Nullable StreamingHttpOutputMessage.Body paramBody) throws IOException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\AbstractStreamingClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */