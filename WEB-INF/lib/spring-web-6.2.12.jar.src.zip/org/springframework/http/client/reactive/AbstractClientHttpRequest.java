/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractClientHttpRequest
/*     */   implements ClientHttpRequest
/*     */ {
/*     */   private final HttpHeaders headers;
/*     */   private final MultiValueMap<String, HttpCookie> cookies;
/*     */   private final Map<String, Object> attributes;
/*     */   
/*     */   private enum State
/*     */   {
/*  54 */     NEW, COMMITTING, COMMITTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private final AtomicReference<State> state = new AtomicReference<>(State.NEW);
/*     */   
/*  65 */   private final List<Supplier<? extends Publisher<Void>>> commitActions = new ArrayList<>(4);
/*     */   
/*     */   @Nullable
/*     */   private HttpHeaders readOnlyHeaders;
/*     */ 
/*     */   
/*     */   public AbstractClientHttpRequest() {
/*  72 */     this(new HttpHeaders());
/*     */   }
/*     */   
/*     */   public AbstractClientHttpRequest(HttpHeaders headers) {
/*  76 */     Assert.notNull(headers, "HttpHeaders must not be null");
/*  77 */     this.headers = headers;
/*  78 */     this.cookies = (MultiValueMap<String, HttpCookie>)new LinkedMultiValueMap();
/*  79 */     this.attributes = new LinkedHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  85 */     if (this.readOnlyHeaders != null) {
/*  86 */       return this.readOnlyHeaders;
/*     */     }
/*  88 */     if (State.COMMITTED.equals(this.state.get())) {
/*  89 */       this.readOnlyHeaders = initReadOnlyHeaders();
/*  90 */       return this.readOnlyHeaders;
/*     */     } 
/*     */     
/*  93 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpHeaders initReadOnlyHeaders() {
/* 104 */     return HttpHeaders.readOnlyHttpHeaders(this.headers);
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, HttpCookie> getCookies() {
/* 109 */     if (State.COMMITTED.equals(this.state.get())) {
/* 110 */       return CollectionUtils.unmodifiableMultiValueMap(this.cookies);
/*     */     }
/* 112 */     return this.cookies;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 117 */     if (State.COMMITTED.equals(this.state.get())) {
/* 118 */       return Collections.unmodifiableMap(this.attributes);
/*     */     }
/* 120 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCommit(Supplier<? extends Mono<Void>> action) {
/* 125 */     Assert.notNull(action, "Action must not be null");
/* 126 */     this.commitActions.add(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCommitted() {
/* 131 */     return (this.state.get() != State.NEW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> doCommit() {
/* 139 */     return doCommit(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> doCommit(@Nullable Supplier<? extends Publisher<Void>> writeAction) {
/* 149 */     if (!this.state.compareAndSet(State.NEW, State.COMMITTING)) {
/* 150 */       return Mono.empty();
/*     */     }
/*     */     
/* 153 */     this.commitActions.add(() -> Mono.fromRunnable(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (writeAction != null) {
/* 162 */       this.commitActions.add(writeAction);
/*     */     }
/*     */     
/* 165 */     List<Publisher<Void>> actions = new ArrayList<>(this.commitActions.size());
/* 166 */     for (Supplier<? extends Publisher<Void>> commitAction : this.commitActions) {
/* 167 */       actions.add(commitAction.get());
/*     */     }
/*     */     
/* 170 */     return Flux.concat(actions).then();
/*     */   }
/*     */   
/*     */   protected void applyAttributes() {}
/*     */   
/*     */   protected abstract void applyHeaders();
/*     */   
/*     */   protected abstract void applyCookies();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\AbstractClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */