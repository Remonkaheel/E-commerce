/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.http.HttpRequest;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.time.Duration;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.adapter.JdkFlowAdapter;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkClientHttpRequest
/*     */   extends AbstractClientHttpRequest
/*     */ {
/*     */   private final HttpMethod method;
/*     */   private final URI uri;
/*     */   private final DataBufferFactory bufferFactory;
/*     */   private final HttpRequest.Builder builder;
/*     */   
/*     */   public JdkClientHttpRequest(HttpMethod httpMethod, URI uri, DataBufferFactory bufferFactory, @Nullable Duration readTimeout) {
/*  64 */     Assert.notNull(httpMethod, "HttpMethod is required");
/*  65 */     Assert.notNull(uri, "URI is required");
/*  66 */     Assert.notNull(bufferFactory, "DataBufferFactory is required");
/*     */     
/*  68 */     this.method = httpMethod;
/*  69 */     this.uri = uri;
/*  70 */     this.bufferFactory = bufferFactory;
/*  71 */     this.builder = HttpRequest.newBuilder(uri);
/*  72 */     if (readTimeout != null) {
/*  73 */       this.builder.timeout(readTimeout);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  80 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  85 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  90 */     return this.bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  96 */     return (T)this.builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 102 */     for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)getHeaders().entrySet()) {
/* 103 */       if (((String)entry.getKey()).equalsIgnoreCase("Content-Length")) {
/*     */         continue;
/*     */       }
/*     */       
/* 107 */       for (String value : entry.getValue()) {
/* 108 */         this.builder.header(entry.getKey(), value);
/*     */       }
/*     */     } 
/* 111 */     if (!getHeaders().containsKey("Accept")) {
/* 112 */       this.builder.header("Accept", "*/*");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 118 */     MultiValueMap<String, HttpCookie> cookies = getCookies();
/* 119 */     if (cookies.isEmpty()) {
/*     */       return;
/*     */     }
/* 122 */     this.builder.header("Cookie", cookies.values().stream()
/* 123 */         .flatMap(Collection::stream).map(HttpCookie::toString).collect(Collectors.joining(";")));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 128 */     return doCommit(() -> {
/*     */           this.builder.method(this.method.name(), toBodyPublisher(body));
/*     */           return (Publisher)Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpRequest.BodyPublisher toBodyPublisher(Publisher<? extends DataBuffer> body) {
/* 137 */     Publisher<ByteBuffer> byteBufferBody = (body instanceof Mono) ? (Publisher<ByteBuffer>)Mono.from(body).map(this::toByteBuffer) : (Publisher<ByteBuffer>)Flux.from(body).map(this::toByteBuffer);
/*     */     
/* 139 */     Flow.Publisher<ByteBuffer> bodyFlow = JdkFlowAdapter.publisherToFlowPublisher(byteBufferBody);
/*     */     
/* 141 */     return (getHeaders().getContentLength() > 0L) ? 
/* 142 */       HttpRequest.BodyPublishers.fromPublisher(bodyFlow, getHeaders().getContentLength()) : 
/* 143 */       HttpRequest.BodyPublishers.fromPublisher(bodyFlow);
/*     */   }
/*     */   
/*     */   private ByteBuffer toByteBuffer(DataBuffer dataBuffer) {
/* 147 */     ByteBuffer byteBuffer = ByteBuffer.allocate(dataBuffer.readableByteCount());
/* 148 */     dataBuffer.toByteBuffer(byteBuffer);
/* 149 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 154 */     return writeWith((Publisher<? extends DataBuffer>)Flux.from(body).flatMap(Function.identity()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 159 */     return doCommit(() -> {
/*     */           this.builder.method(this.method.name(), HttpRequest.BodyPublishers.noBody());
/*     */           return (Publisher)Mono.empty();
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JdkClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */