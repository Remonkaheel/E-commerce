/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty5.buffer.Buffer;
/*     */ import io.netty5.handler.codec.http.headers.DefaultHttpCookiePair;
/*     */ import io.netty5.handler.codec.http.headers.HttpCookiePair;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.support.Netty5HeadersAdapter;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty5.NettyOutbound;
/*     */ import reactor.netty5.channel.ChannelOperations;
/*     */ import reactor.netty5.http.client.HttpClientRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorNetty2ClientHttpRequest
/*     */   extends AbstractClientHttpRequest
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*     */   private final HttpMethod httpMethod;
/*     */   private final URI uri;
/*     */   private final HttpClientRequest request;
/*     */   private final NettyOutbound outbound;
/*     */   private final Netty5DataBufferFactory bufferFactory;
/*     */   
/*     */   public ReactorNetty2ClientHttpRequest(HttpMethod method, URI uri, HttpClientRequest request, NettyOutbound outbound) {
/*  64 */     this.httpMethod = method;
/*  65 */     this.uri = uri;
/*  66 */     this.request = request;
/*  67 */     this.outbound = outbound;
/*  68 */     this.bufferFactory = new Netty5DataBufferFactory(outbound.alloc());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  74 */     return this.httpMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  79 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  84 */     return (DataBufferFactory)this.bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  90 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/*  95 */     return doCommit(() -> {
/*     */           if (body instanceof Mono) {
/*     */             Mono<Buffer> bufferMono = Mono.from(body).map(Netty5DataBufferFactory::toBuffer);
/*     */             return (Publisher)this.outbound.send((Publisher)bufferMono).then();
/*     */           } 
/*     */           Flux<Buffer> bufferFlux = Flux.from(body).map(Netty5DataBufferFactory::toBuffer);
/*     */           return (Publisher)this.outbound.send((Publisher)bufferFlux).then();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 111 */     Flux flux = Flux.from(body).map(ReactorNetty2ClientHttpRequest::toBuffers);
/* 112 */     return doCommit(() -> this.outbound.sendGroups(buffers).then());
/*     */   }
/*     */   
/*     */   private static Publisher<Buffer> toBuffers(Publisher<? extends DataBuffer> dataBuffers) {
/* 116 */     return (Publisher<Buffer>)Flux.from(dataBuffers).map(Netty5DataBufferFactory::toBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 121 */     return doCommit(() -> this.outbound.sendFile(file, position, count).then());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 128 */     return doCommit(null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 133 */     getHeaders().forEach((key, value) -> this.request.requestHeaders().set(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 138 */     getCookies().values().forEach(values -> values.forEach(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyAttributes() {
/* 151 */     if (!getAttributes().isEmpty()) {
/* 152 */       ((ChannelOperations)this.request).channel()
/* 153 */         .attr(ReactorNetty2ClientHttpConnector.ATTRIBUTES_KEY).set(getAttributes());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpHeaders initReadOnlyHeaders() {
/* 159 */     return HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new Netty5HeadersAdapter(this.request.requestHeaders()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorNetty2ClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */