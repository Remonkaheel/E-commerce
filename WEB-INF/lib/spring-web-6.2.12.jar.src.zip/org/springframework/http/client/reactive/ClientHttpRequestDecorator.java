/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientHttpRequestDecorator
/*     */   implements ClientHttpRequest
/*     */ {
/*     */   private final ClientHttpRequest delegate;
/*     */   
/*     */   public ClientHttpRequestDecorator(ClientHttpRequest delegate) {
/*  47 */     Assert.notNull(delegate, "Delegate is required");
/*  48 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientHttpRequest getDelegate() {
/*  53 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  61 */     return this.delegate.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  66 */     return this.delegate.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  71 */     return this.delegate.getHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, HttpCookie> getCookies() {
/*  76 */     return this.delegate.getCookies();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  81 */     return this.delegate.getAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  86 */     return this.delegate.bufferFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  91 */     return this.delegate.getNativeRequest();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCommit(Supplier<? extends Mono<Void>> action) {
/*  96 */     this.delegate.beforeCommit(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCommitted() {
/* 101 */     return this.delegate.isCommitted();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 106 */     return this.delegate.writeWith(body);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 111 */     return this.delegate.writeAndFlushWith(body);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 116 */     return this.delegate.setComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return getClass().getSimpleName() + " [delegate=" + getClass().getSimpleName() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ClientHttpRequestDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */