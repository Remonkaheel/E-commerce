package org.springframework.http.client.reactive;

import org.springframework.http.client.ReactorResourceFactory;

@Deprecated(since = "6.1")
public class ReactorResourceFactory extends ReactorResourceFactory {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */