/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty5.buffer.Buffer;
/*     */ import io.netty5.handler.codec.http.headers.DefaultHttpSetCookie;
/*     */ import io.netty5.handler.codec.http.headers.HttpSetCookie;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.Netty5DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.support.Netty5HeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.netty5.ChannelOperationsId;
/*     */ import reactor.netty5.Connection;
/*     */ import reactor.netty5.NettyInbound;
/*     */ import reactor.netty5.http.client.HttpClientResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorNetty2ClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(ReactorNetty2ClientHttpResponse.class);
/*     */ 
/*     */   
/*     */   private final HttpClientResponse response;
/*     */   
/*     */   private final HttpHeaders headers;
/*     */   
/*     */   private final NettyInbound inbound;
/*     */   
/*     */   private final Netty5DataBufferFactory bufferFactory;
/*     */   
/*  68 */   private final AtomicInteger state = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNetty2ClientHttpResponse(HttpClientResponse response, Connection connection) {
/*  77 */     this.response = response;
/*  78 */     Netty5HeadersAdapter netty5HeadersAdapter = new Netty5HeadersAdapter(response.responseHeaders());
/*  79 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)netty5HeadersAdapter);
/*  80 */     this.inbound = connection.inbound();
/*  81 */     this.bufferFactory = new Netty5DataBufferFactory(connection.outbound().alloc());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  87 */     String id = null;
/*  88 */     HttpClientResponse httpClientResponse = this.response; if (httpClientResponse instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpClientResponse;
/*  89 */       id = logger.isDebugEnabled() ? operationsId.asLongText() : operationsId.asShortText(); }
/*     */     
/*  91 */     if (id == null) { httpClientResponse = this.response; if (httpClientResponse instanceof Connection) { Connection connection = (Connection)httpClientResponse;
/*  92 */         id = connection.channel().id().asShortText(); }
/*     */        }
/*  94 */      return (id != null) ? id : ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/*  99 */     return this.inbound.receive()
/* 100 */       .doOnSubscribe(s -> {
/*     */           if (this.state.compareAndSet(0, 1)) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/*     */           if (this.state.get() == 2) {
/*     */             throw new IllegalStateException("The client response body has been released already due to cancellation.");
/*     */           }
/* 109 */         }).map(buffer -> this.bufferFactory.wrap(buffer.split()));
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 114 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/* 119 */     return HttpStatusCode.valueOf(this.response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies() {
/* 124 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 125 */     this.response.cookies().values().stream()
/* 126 */       .flatMap(Collection::stream)
/* 127 */       .forEach(cookie -> result.add(cookie.name().toString(), ResponseCookie.fromClientResponse(cookie.name().toString(), cookie.value().toString()).domain(toString(cookie.domain())).path(toString(cookie.path())).maxAge(toLong(cookie.maxAge())).secure(cookie.isSecure()).httpOnly(cookie.isHttpOnly()).sameSite(getSameSite(cookie)).build()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     return CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)linkedMultiValueMap);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String toString(@Nullable CharSequence value) {
/* 141 */     return (value != null) ? value.toString() : null;
/*     */   }
/*     */   
/*     */   private static long toLong(@Nullable Long value) {
/* 145 */     return (value != null) ? value.longValue() : -1L;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String getSameSite(HttpSetCookie cookie) {
/* 150 */     if (cookie instanceof DefaultHttpSetCookie) { DefaultHttpSetCookie defaultCookie = (DefaultHttpSetCookie)cookie; if (defaultCookie.sameSite() != null)
/* 151 */         return defaultCookie.sameSite().name();  }
/*     */     
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void releaseAfterCancel(HttpMethod method) {
/* 164 */     if (mayHaveBody(method) && this.state.compareAndSet(0, 2)) {
/* 165 */       if (logger.isDebugEnabled()) {
/* 166 */         logger.debug("[" + getId() + "]Releasing body, not yet subscribed.");
/*     */       }
/* 168 */       this.inbound.receive().doOnNext(buffer -> {  }).subscribe(buffer -> {
/*     */           
/*     */           }ex -> {
/*     */           
/*     */           });
/* 173 */     }  } private boolean mayHaveBody(HttpMethod method) { int code = getStatusCode().value();
/* 174 */     return ((code < 100 || code >= 200) && code != 204 && code != 205 && 
/* 175 */       !method.equals(HttpMethod.HEAD) && getHeaders().getContentLength() != 0L); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "ReactorNetty2ClientHttpResponse{request=[" + this.response
/* 181 */       .method().name() + " " + this.response.uri() + "],status=" + 
/* 182 */       String.valueOf(getStatusCode()) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorNetty2ClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */