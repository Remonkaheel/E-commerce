/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jetty.client.HttpClient;
/*     */ import org.eclipse.jetty.client.Request;
/*     */ import org.eclipse.jetty.reactive.client.ReactiveResponse;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.JettyDataBufferFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyClientHttpConnector
/*     */   implements ClientHttpConnector
/*     */ {
/*     */   private final HttpClient httpClient;
/*  45 */   private JettyDataBufferFactory bufferFactory = new JettyDataBufferFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnector() {
/*  52 */     this(new HttpClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnector(HttpClient httpClient) {
/*  59 */     this(httpClient, (JettyResourceFactory)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JettyClientHttpConnector(HttpClient httpClient, @Nullable JettyResourceFactory resourceFactory) {
/*  70 */     Assert.notNull(httpClient, "HttpClient is required");
/*  71 */     if (resourceFactory != null) {
/*  72 */       httpClient.setExecutor(resourceFactory.getExecutor());
/*  73 */       httpClient.setByteBufferPool(resourceFactory.getByteBufferPool());
/*  74 */       httpClient.setScheduler(resourceFactory.getScheduler());
/*     */     } 
/*  76 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JettyClientHttpConnector(JettyResourceFactory resourceFactory, @Nullable Consumer<HttpClient> customizer) {
/*  88 */     this(new HttpClient(), resourceFactory);
/*  89 */     if (customizer != null) {
/*  90 */       customizer.accept(this.httpClient);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferFactory(JettyDataBufferFactory bufferFactory) {
/*  99 */     this.bufferFactory = bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientHttpResponse> connect(HttpMethod method, URI uri, Function<? super ClientHttpRequest, Mono<Void>> requestCallback) {
/* 107 */     if (!uri.isAbsolute()) {
/* 108 */       return Mono.error(new IllegalArgumentException("URI is not absolute: " + String.valueOf(uri)));
/*     */     }
/*     */     
/* 111 */     if (!this.httpClient.isStarted()) {
/*     */       try {
/* 113 */         this.httpClient.start();
/*     */       }
/* 115 */       catch (Exception ex) {
/* 116 */         return Mono.error(ex);
/*     */       } 
/*     */     }
/*     */     
/* 120 */     Request jettyRequest = this.httpClient.newRequest(uri).method(method.toString());
/* 121 */     JettyClientHttpRequest request = new JettyClientHttpRequest(jettyRequest, (DataBufferFactory)this.bufferFactory);
/*     */     
/* 123 */     return ((Mono)requestCallback.apply(request)).then(execute(request));
/*     */   }
/*     */   
/*     */   private Mono<ClientHttpResponse> execute(JettyClientHttpRequest request) {
/* 127 */     return Mono.fromDirect(request.toReactiveRequest()
/* 128 */         .response((reactiveResponse, chunkPublisher) -> {
/*     */             Objects.requireNonNull(this.bufferFactory);
/*     */             Flux<DataBuffer> content = Flux.from(chunkPublisher).map(this.bufferFactory::wrap);
/*     */             return (Publisher)Mono.just(new JettyClientHttpResponse(reactiveResponse, content));
/*     */           }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JettyClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */