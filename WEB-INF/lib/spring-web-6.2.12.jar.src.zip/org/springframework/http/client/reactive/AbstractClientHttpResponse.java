/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*     */   private final HttpStatusCode statusCode;
/*     */   private final HttpHeaders headers;
/*     */   private final MultiValueMap<String, ResponseCookie> cookies;
/*     */   private final Flux<DataBuffer> body;
/*     */   
/*     */   protected AbstractClientHttpResponse(HttpStatusCode statusCode, HttpHeaders headers, MultiValueMap<String, ResponseCookie> cookies, Flux<DataBuffer> body) {
/*  55 */     Assert.notNull(statusCode, "StatusCode must not be null");
/*  56 */     Assert.notNull(headers, "Headers must not be null");
/*  57 */     Assert.notNull(body, "Body must not be null");
/*     */     
/*  59 */     this.statusCode = statusCode;
/*  60 */     this.headers = headers;
/*  61 */     this.cookies = cookies;
/*  62 */     this.body = Flux.from(new SingleSubscriberPublisher<>((Publisher<DataBuffer>)body));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  68 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  73 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies() {
/*  78 */     return this.cookies;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/*  83 */     return this.body;
/*     */   }
/*     */   
/*     */   private static final class SingleSubscriberPublisher<T>
/*     */     implements Publisher<T>
/*     */   {
/*  89 */     private static final Subscription NO_OP_SUBSCRIPTION = new Subscription()
/*     */       {
/*     */         public void request(long l) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void cancel() {}
/*     */       };
/*     */ 
/*     */     
/*     */     private final Publisher<T> delegate;
/*     */     
/* 101 */     private final AtomicBoolean subscribed = new AtomicBoolean();
/*     */ 
/*     */     
/*     */     public SingleSubscriberPublisher(Publisher<T> delegate) {
/* 105 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Subscriber<? super T> subscriber) {
/* 110 */       Objects.requireNonNull(subscriber, "Subscriber must not be null");
/* 111 */       if (this.subscribed.compareAndSet(false, true)) {
/* 112 */         this.delegate.subscribe(subscriber);
/*     */       } else {
/*     */         
/* 115 */         subscriber.onSubscribe(NO_OP_SUBSCRIPTION);
/* 116 */         subscriber.onError(new IllegalStateException("The client response body can only be consumed once"));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Subscription {
/*     */     public void request(long l) {}
/*     */     
/*     */     public void cancel() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\AbstractClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */