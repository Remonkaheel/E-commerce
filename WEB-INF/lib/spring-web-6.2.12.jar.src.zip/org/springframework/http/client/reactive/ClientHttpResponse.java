/*    */ package org.springframework.http.client.reactive;
/*    */ 
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.ReactiveHttpInputMessage;
/*    */ import org.springframework.http.ResponseCookie;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ClientHttpResponse
/*    */   extends ReactiveHttpInputMessage
/*    */ {
/*    */   default String getId() {
/* 40 */     return ObjectUtils.getIdentityHexString(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HttpStatusCode getStatusCode();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "6.0", forRemoval = true)
/*    */   default int getRawStatusCode() {
/* 58 */     return getStatusCode().value();
/*    */   }
/*    */   
/*    */   MultiValueMap<String, ResponseCookie> getCookies();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */