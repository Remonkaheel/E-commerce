package org.springframework.http.client.reactive;

import java.net.URI;
import java.util.Map;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.util.MultiValueMap;

public interface ClientHttpRequest extends ReactiveHttpOutputMessage {
  HttpMethod getMethod();
  
  URI getURI();
  
  MultiValueMap<String, HttpCookie> getCookies();
  
  Map<String, Object> getAttributes();
  
  <T> T getNativeRequest();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */