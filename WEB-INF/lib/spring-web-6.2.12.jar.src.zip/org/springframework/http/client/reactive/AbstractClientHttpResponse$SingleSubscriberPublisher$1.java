package org.springframework.http.client.reactive;

import org.reactivestreams.Subscription;

class null implements Subscription {
  public void request(long l) {}
  
  public void cancel() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\AbstractClientHttpResponse$SingleSubscriberPublisher$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */