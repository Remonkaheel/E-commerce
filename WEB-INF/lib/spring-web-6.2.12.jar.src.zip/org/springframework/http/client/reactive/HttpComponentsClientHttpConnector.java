/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
/*     */ import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
/*     */ import org.apache.hc.client5.http.protocol.HttpClientContext;
/*     */ import org.apache.hc.core5.concurrent.FutureCallback;
/*     */ import org.apache.hc.core5.http.HttpResponse;
/*     */ import org.apache.hc.core5.http.Message;
/*     */ import org.apache.hc.core5.http.nio.AsyncRequestProducer;
/*     */ import org.apache.hc.core5.http.nio.AsyncResponseConsumer;
/*     */ import org.apache.hc.core5.http.protocol.HttpContext;
/*     */ import org.apache.hc.core5.reactive.ReactiveResponseConsumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpComponentsClientHttpConnector
/*     */   implements ClientHttpConnector, Closeable
/*     */ {
/*     */   private final CloseableHttpAsyncClient client;
/*     */   private final BiFunction<HttpMethod, URI, ? extends HttpClientContext> contextProvider;
/*  59 */   private DataBufferFactory dataBufferFactory = (DataBufferFactory)DefaultDataBufferFactory.sharedInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnector() {
/*  66 */     this(HttpAsyncClients.createDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnector(CloseableHttpAsyncClient client) {
/*  74 */     this(client, (method, uri) -> HttpClientContext.create());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpConnector(CloseableHttpAsyncClient client, BiFunction<HttpMethod, URI, ? extends HttpClientContext> contextProvider) {
/*  87 */     Assert.notNull(client, "Client must not be null");
/*  88 */     Assert.notNull(contextProvider, "ContextProvider must not be null");
/*     */     
/*  90 */     this.contextProvider = contextProvider;
/*  91 */     this.client = client;
/*  92 */     this.client.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferFactory(DataBufferFactory bufferFactory) {
/* 100 */     this.dataBufferFactory = bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientHttpResponse> connect(HttpMethod method, URI uri, Function<? super ClientHttpRequest, Mono<Void>> requestCallback) {
/* 108 */     HttpClientContext context = this.contextProvider.apply(method, uri);
/*     */     
/* 110 */     HttpComponentsClientHttpRequest request = new HttpComponentsClientHttpRequest(method, uri, context, this.dataBufferFactory);
/*     */ 
/*     */     
/* 113 */     return ((Mono)requestCallback.apply(request)).then(Mono.defer(() -> execute(request, context)));
/*     */   }
/*     */   
/*     */   private Mono<ClientHttpResponse> execute(HttpComponentsClientHttpRequest request, HttpClientContext context) {
/* 117 */     AsyncRequestProducer requestProducer = request.toRequestProducer();
/*     */     
/* 119 */     return Mono.create(sink -> {
/*     */           ReactiveResponseConsumer reactiveResponseConsumer = new ReactiveResponseConsumer(new ResponseCallback(sink, this.dataBufferFactory, context));
/*     */           this.client.execute(requestProducer, (AsyncResponseConsumer)reactiveResponseConsumer, (HttpContext)context, new ResultCallback(sink));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 128 */     this.client.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResponseCallback
/*     */     implements FutureCallback<Message<HttpResponse, Publisher<ByteBuffer>>>
/*     */   {
/*     */     private final MonoSink<ClientHttpResponse> sink;
/*     */ 
/*     */     
/*     */     private final DataBufferFactory dataBufferFactory;
/*     */ 
/*     */     
/*     */     private final HttpClientContext context;
/*     */ 
/*     */     
/*     */     public ResponseCallback(MonoSink<ClientHttpResponse> sink, DataBufferFactory dataBufferFactory, HttpClientContext context) {
/* 146 */       this.sink = sink;
/* 147 */       this.dataBufferFactory = dataBufferFactory;
/* 148 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void completed(Message<HttpResponse, Publisher<ByteBuffer>> result) {
/* 153 */       this.sink.success(new HttpComponentsClientHttpResponse(this.dataBufferFactory, result, this.context));
/*     */     }
/*     */ 
/*     */     
/*     */     public void failed(Exception ex) {
/* 158 */       this.sink.error((ex instanceof org.apache.hc.core5.http.HttpStreamResetException && ex.getCause() != null) ? ex.getCause() : ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancelled() {
/* 163 */       this.sink.error(new CancellationException());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResultCallback
/*     */     implements FutureCallback<Void>
/*     */   {
/*     */     private final MonoSink<?> sink;
/*     */ 
/*     */     
/*     */     public ResultCallback(MonoSink<?> sink) {
/* 176 */       this.sink = sink;
/*     */     }
/*     */ 
/*     */     
/*     */     public void completed(Void result) {
/* 181 */       this.sink.success();
/*     */     }
/*     */ 
/*     */     
/*     */     public void failed(Exception ex) {
/* 186 */       this.sink.error((ex instanceof org.apache.hc.core5.http.HttpStreamResetException && ex.getCause() != null) ? ex.getCause() : ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancelled() {
/* 191 */       this.sink.error(new CancellationException());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\HttpComponentsClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */