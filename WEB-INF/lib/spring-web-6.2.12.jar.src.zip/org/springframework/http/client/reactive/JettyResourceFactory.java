/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import org.eclipse.jetty.io.ArrayByteBufferPool;
/*     */ import org.eclipse.jetty.io.ByteBufferPool;
/*     */ import org.eclipse.jetty.util.ProcessorUtils;
/*     */ import org.eclipse.jetty.util.component.LifeCycle;
/*     */ import org.eclipse.jetty.util.thread.QueuedThreadPool;
/*     */ import org.eclipse.jetty.util.thread.ScheduledExecutorScheduler;
/*     */ import org.eclipse.jetty.util.thread.Scheduler;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyResourceFactory
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private Executor executor;
/*     */   @Nullable
/*     */   private ByteBufferPool byteBufferPool;
/*     */   @Nullable
/*     */   private Scheduler scheduler;
/*  58 */   private String threadPrefix = "jetty-http";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExecutor(@Nullable Executor executor) {
/*  67 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteBufferPool(@Nullable ByteBufferPool byteBufferPool) {
/*  76 */     this.byteBufferPool = byteBufferPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScheduler(@Nullable Scheduler scheduler) {
/*  85 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThreadPrefix(String threadPrefix) {
/*  96 */     Assert.notNull(threadPrefix, "Thread prefix is required");
/*  97 */     this.threadPrefix = threadPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Executor getExecutor() {
/* 105 */     return this.executor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ByteBufferPool getByteBufferPool() {
/* 113 */     return this.byteBufferPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Scheduler getScheduler() {
/* 121 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 126 */     String name = this.threadPrefix + "@" + this.threadPrefix;
/* 127 */     if (this.executor == null) {
/* 128 */       QueuedThreadPool threadPool = new QueuedThreadPool();
/* 129 */       threadPool.setName(name);
/* 130 */       this.executor = (Executor)threadPool;
/*     */     } 
/* 132 */     if (this.byteBufferPool == null) {
/*     */       
/* 134 */       Executor executor1 = this.executor; ThreadPool.SizedThreadPool sizedThreadPool = (ThreadPool.SizedThreadPool)executor1;
/*     */       
/* 136 */       this.byteBufferPool = (ByteBufferPool)new ArrayByteBufferPool(0, 2048, 65536, (executor1 instanceof ThreadPool.SizedThreadPool) ? (sizedThreadPool.getMaxThreads() / 2) : (ProcessorUtils.availableProcessors() * 2));
/*     */     } 
/* 138 */     if (this.scheduler == null) {
/* 139 */       this.scheduler = (Scheduler)new ScheduledExecutorScheduler(name + "-scheduler", false);
/*     */     }
/*     */     
/* 142 */     Executor executor = this.executor; if (executor instanceof LifeCycle) { LifeCycle lifeCycle = (LifeCycle)executor;
/* 143 */       lifeCycle.start(); }
/*     */     
/* 145 */     this.scheduler.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/*     */     try {
/* 151 */       Executor executor = this.executor; if (executor instanceof LifeCycle) { LifeCycle lifeCycle = (LifeCycle)executor;
/* 152 */         lifeCycle.stop(); }
/*     */ 
/*     */     
/* 155 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/*     */     try {
/* 159 */       if (this.scheduler != null) {
/* 160 */         this.scheduler.stop();
/*     */       }
/*     */     }
/* 163 */     catch (Throwable throwable) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JettyResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */