/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.client.ReactorResourceFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.HttpClientRequest;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorClientHttpConnector
/*     */   implements ClientHttpConnector, SmartLifecycle
/*     */ {
/*  60 */   public static final AttributeKey<Map<String, Object>> ATTRIBUTES_KEY = AttributeKey.valueOf(ReactorClientHttpRequest.class.getName() + ".ATTRIBUTES");
/*     */   
/*  62 */   private static final Log logger = LogFactory.getLog(ReactorClientHttpConnector.class);
/*     */   static {
/*  64 */     defaultInitializer = (client -> client.compress(true));
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Function<HttpClient, HttpClient> defaultInitializer;
/*     */   
/*     */   @Nullable
/*     */   private final ReactorResourceFactory resourceFactory;
/*     */   
/*     */   @Nullable
/*     */   private final Function<HttpClient, HttpClient> mapper;
/*     */   @Nullable
/*     */   private volatile HttpClient httpClient;
/*     */   private boolean lazyStart = false;
/*  78 */   private final Object lifecycleMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnector() {
/*  86 */     this.httpClient = defaultInitializer.apply(HttpClient.create());
/*  87 */     this.resourceFactory = null;
/*  88 */     this.mapper = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnector(HttpClient httpClient) {
/*  97 */     Assert.notNull(httpClient, "HttpClient is required");
/*  98 */     this.httpClient = httpClient;
/*  99 */     this.resourceFactory = null;
/* 100 */     this.mapper = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpConnector(ReactorResourceFactory resourceFactory, Function<HttpClient, HttpClient> mapper) {
/* 122 */     this.resourceFactory = resourceFactory;
/* 123 */     this.mapper = mapper;
/* 124 */     if (resourceFactory.isRunning()) {
/* 125 */       this.httpClient = createHttpClient(resourceFactory, mapper);
/*     */     } else {
/*     */       
/* 128 */       this.lazyStart = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static HttpClient createHttpClient(ReactorResourceFactory factory, Function<HttpClient, HttpClient> mapper) {
/* 133 */     return defaultInitializer.<HttpClient>andThen(mapper).andThen(httpClient -> (HttpClient)httpClient.runOn(factory.getLoopResources()))
/* 134 */       .apply(HttpClient.create(factory.getConnectionProvider()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientHttpResponse> connect(HttpMethod method, URI uri, Function<? super ClientHttpRequest, Mono<Void>> requestCallback) {
/* 142 */     HttpClient httpClient = this.httpClient;
/* 143 */     if (httpClient == null) {
/* 144 */       Assert.state((this.resourceFactory != null && this.mapper != null), "Illegal configuration");
/* 145 */       if (this.resourceFactory.isRunning())
/*     */       {
/*     */         
/* 148 */         synchronized (this.lifecycleMonitor) {
/* 149 */           httpClient = this.httpClient;
/* 150 */           if (httpClient == null && this.lazyStart) {
/* 151 */             httpClient = createHttpClient(this.resourceFactory, this.mapper);
/* 152 */             this.httpClient = httpClient;
/* 153 */             this.lazyStart = false;
/*     */           } 
/*     */         } 
/*     */       }
/* 157 */       if (httpClient == null) {
/* 158 */         httpClient = createHttpClient(this.resourceFactory, this.mapper);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 163 */     HttpClient.RequestSender requestSender = httpClient.request(HttpMethod.valueOf(method.name()));
/*     */     
/* 165 */     requestSender = setUri(requestSender, uri);
/* 166 */     AtomicReference<ReactorClientHttpResponse> responseRef = new AtomicReference<>();
/*     */     
/* 168 */     return requestSender
/* 169 */       .send((request, outbound) -> (Publisher)requestCallback.apply(adaptRequest(method, uri, request, outbound)))
/* 170 */       .responseConnection((response, connection) -> {
/*     */           responseRef.set(new ReactorClientHttpResponse(response, connection));
/*     */           
/*     */           return (Publisher)Mono.just(responseRef.get());
/* 174 */         }).next()
/* 175 */       .doOnCancel(() -> {
/*     */           ReactorClientHttpResponse response = responseRef.get();
/*     */           if (response != null) {
/*     */             response.releaseAfterCancel(method);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private static HttpClient.RequestSender setUri(HttpClient.RequestSender requestSender, URI uri) {
/* 184 */     if (uri.isAbsolute()) {
/*     */       try {
/* 186 */         return (HttpClient.RequestSender)requestSender.uri(uri);
/*     */       }
/* 188 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 192 */     return (HttpClient.RequestSender)requestSender.uri(uri.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ReactorClientHttpRequest adaptRequest(HttpMethod method, URI uri, HttpClientRequest request, NettyOutbound nettyOutbound) {
/* 198 */     return new ReactorClientHttpRequest(method, uri, request, nettyOutbound);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 204 */     if (this.resourceFactory != null && this.mapper != null) {
/* 205 */       synchronized (this.lifecycleMonitor) {
/* 206 */         if (this.httpClient == null) {
/* 207 */           this.httpClient = createHttpClient(this.resourceFactory, this.mapper);
/* 208 */           this.lazyStart = false;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 213 */       logger.warn("Restarting a ReactorClientHttpConnector bean is only supported with externally managed Reactor Netty resources");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 220 */     if (this.resourceFactory != null && this.mapper != null) {
/* 221 */       synchronized (this.lifecycleMonitor) {
/* 222 */         this.httpClient = null;
/* 223 */         this.lazyStart = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 230 */     return (this.httpClient != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPhase() {
/* 236 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */