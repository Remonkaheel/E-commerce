/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jetty.client.Request;
/*     */ import org.eclipse.jetty.http.HttpCookie;
/*     */ import org.eclipse.jetty.http.HttpFields;
/*     */ import org.eclipse.jetty.io.Content;
/*     */ import org.eclipse.jetty.reactive.client.ReactiveRequest;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.support.JettyHeadersAdapter;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JettyClientHttpRequest
/*     */   extends AbstractClientHttpRequest
/*     */ {
/*     */   private final Request jettyRequest;
/*     */   private final DataBufferFactory bufferFactory;
/*     */   private final ReactiveRequest.Builder builder;
/*     */   
/*     */   public JettyClientHttpRequest(Request jettyRequest, DataBufferFactory bufferFactory) {
/*  59 */     this.jettyRequest = jettyRequest;
/*  60 */     this.bufferFactory = bufferFactory;
/*  61 */     this.builder = ReactiveRequest.newBuilder(this.jettyRequest).abortOnCancel(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  67 */     return HttpMethod.valueOf(this.jettyRequest.getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  72 */     return this.jettyRequest.getURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/*  77 */     return doCommit();
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  82 */     return this.bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  88 */     return (T)this.jettyRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/*  93 */     return Mono.create(sink -> {
/*     */           Objects.requireNonNull(sink);
/*     */           
/*     */           ReactiveRequest.Content content = (ReactiveRequest.Content)Flux.from(body).concatMapIterable(this::toContentChunks).concatWith((Publisher)Mono.just(Content.Chunk.EOF)).doOnError(sink::error).as(());
/*     */           
/*     */           this.builder.content(content);
/*     */           
/*     */           sink.success();
/* 101 */         }).then(doCommit());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 106 */     return writeWith((Publisher<? extends DataBuffer>)Flux.from(body)
/* 107 */         .flatMap(Function.identity())
/* 108 */         .doOnDiscard(DataBuffer.class, DataBufferUtils::release));
/*     */   }
/*     */   
/*     */   private String getContentType() {
/* 112 */     MediaType contentType = getHeaders().getContentType();
/* 113 */     return (contentType != null) ? contentType.toString() : "application/octet-stream";
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Content.Chunk> toContentChunks(DataBuffer dataBuffer) {
/* 118 */     List<Content.Chunk> result = new ArrayList<>(1);
/* 119 */     DataBuffer.ByteBufferIterator iterator = dataBuffer.readableByteBuffers();
/* 120 */     while (iterator.hasNext()) {
/* 121 */       ByteBuffer byteBuffer = (ByteBuffer)iterator.next();
/* 122 */       boolean last = !iterator.hasNext();
/* 123 */       Content.Chunk chunk = Content.Chunk.from(byteBuffer, false, () -> {
/*     */             if (last) {
/*     */               iterator.close();
/*     */               DataBufferUtils.release(dataBuffer);
/*     */             } 
/*     */           });
/* 129 */       result.add(chunk);
/*     */     } 
/* 131 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 138 */     Objects.requireNonNull(this.jettyRequest); getCookies().values().stream().flatMap(Collection::stream).map(cookie -> HttpCookie.build(cookie.getName(), cookie.getValue()).build()).forEach(this.jettyRequest::cookie);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 143 */     HttpHeaders headers = getHeaders();
/* 144 */     this.jettyRequest.headers(fields -> {
/*     */           headers.forEach(());
/*     */           if (!headers.containsKey("Accept")) {
/*     */             fields.add("Accept", "*/*");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpHeaders initReadOnlyHeaders() {
/* 154 */     return HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new JettyHeadersAdapter(this.jettyRequest.getHeaders()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyAttributes() {
/* 159 */     getAttributes().forEach((key, value) -> {
/*     */           if (this.jettyRequest.getAttributes().get(key) == null) {
/*     */             this.jettyRequest.attribute(key, value);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public ReactiveRequest toReactiveRequest() {
/* 167 */     return this.builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JettyClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */