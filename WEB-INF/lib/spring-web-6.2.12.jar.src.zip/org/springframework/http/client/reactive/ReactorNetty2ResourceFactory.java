/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.netty5.http.HttpResources;
/*     */ import reactor.netty5.resources.ConnectionProvider;
/*     */ import reactor.netty5.resources.LoopResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorNetty2ResourceFactory
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   private boolean useGlobalResources = true;
/*     */   @Nullable
/*     */   private Consumer<HttpResources> globalResourcesConsumer;
/*     */   private Supplier<ConnectionProvider> connectionProviderSupplier = () -> ConnectionProvider.create("webflux", 500);
/*     */   @Nullable
/*     */   private ConnectionProvider connectionProvider;
/*     */   private Supplier<LoopResources> loopResourcesSupplier = () -> LoopResources.create("webflux-http");
/*     */   @Nullable
/*     */   private LoopResources loopResources;
/*     */   private boolean manageConnectionProvider = false;
/*     */   private boolean manageLoopResources = false;
/*  67 */   private Duration shutdownQuietPeriod = Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_QUIET_PERIOD);
/*     */   
/*  69 */   private Duration shutdownTimeout = Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_TIMEOUT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseGlobalResources(boolean useGlobalResources) {
/*  82 */     this.useGlobalResources = useGlobalResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseGlobalResources() {
/*  90 */     return this.useGlobalResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGlobalResourcesConsumer(Consumer<HttpResources> consumer) {
/* 101 */     this.useGlobalResources = true;
/* 102 */     this
/* 103 */       .globalResourcesConsumer = (this.globalResourcesConsumer != null) ? this.globalResourcesConsumer.andThen(consumer) : consumer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProviderSupplier(Supplier<ConnectionProvider> supplier) {
/* 116 */     this.connectionProviderSupplier = supplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProvider(ConnectionProvider connectionProvider) {
/* 125 */     this.connectionProvider = connectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionProvider getConnectionProvider() {
/* 132 */     Assert.state((this.connectionProvider != null), "ConnectionProvider not initialized yet");
/* 133 */     return this.connectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoopResourcesSupplier(Supplier<LoopResources> supplier) {
/* 146 */     this.loopResourcesSupplier = supplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoopResources(LoopResources loopResources) {
/* 155 */     this.loopResources = loopResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoopResources getLoopResources() {
/* 162 */     Assert.state((this.loopResources != null), "LoopResources not initialized yet");
/* 163 */     return this.loopResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShutdownQuietPeriod(Duration shutdownQuietPeriod) {
/* 178 */     Assert.notNull(shutdownQuietPeriod, "shutdownQuietPeriod should not be null");
/* 179 */     this.shutdownQuietPeriod = shutdownQuietPeriod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShutdownTimeout(Duration shutdownTimeout) {
/* 194 */     Assert.notNull(shutdownTimeout, "shutdownTimeout should not be null");
/* 195 */     this.shutdownTimeout = shutdownTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 201 */     if (this.useGlobalResources) {
/* 202 */       Assert.isTrue((this.loopResources == null && this.connectionProvider == null), "'useGlobalResources' is mutually exclusive with explicitly configured resources");
/*     */       
/* 204 */       HttpResources httpResources = HttpResources.get();
/* 205 */       if (this.globalResourcesConsumer != null) {
/* 206 */         this.globalResourcesConsumer.accept(httpResources);
/*     */       }
/* 208 */       this.connectionProvider = (ConnectionProvider)httpResources;
/* 209 */       this.loopResources = (LoopResources)httpResources;
/*     */     } else {
/*     */       
/* 212 */       if (this.loopResources == null) {
/* 213 */         this.manageLoopResources = true;
/* 214 */         this.loopResources = this.loopResourcesSupplier.get();
/*     */       } 
/* 216 */       if (this.connectionProvider == null) {
/* 217 */         this.manageConnectionProvider = true;
/* 218 */         this.connectionProvider = this.connectionProviderSupplier.get();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 225 */     if (this.useGlobalResources) {
/* 226 */       HttpResources.disposeLoopsAndConnectionsLater(this.shutdownQuietPeriod, this.shutdownTimeout).block();
/*     */     } else {
/*     */       
/*     */       try {
/* 230 */         ConnectionProvider provider = this.connectionProvider;
/* 231 */         if (provider != null && this.manageConnectionProvider) {
/* 232 */           provider.disposeLater().block();
/*     */         }
/*     */       }
/* 235 */       catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 240 */         LoopResources resources = this.loopResources;
/* 241 */         if (resources != null && this.manageLoopResources) {
/* 242 */           resources.disposeLater(this.shutdownQuietPeriod, this.shutdownTimeout).block();
/*     */         }
/*     */       }
/* 245 */       catch (Throwable throwable) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorNetty2ResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */