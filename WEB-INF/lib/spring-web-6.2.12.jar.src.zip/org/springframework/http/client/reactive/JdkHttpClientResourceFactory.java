/*    */ package org.springframework.http.client.reactive;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.scheduling.concurrent.CustomizableThreadFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkHttpClientResourceFactory
/*    */   implements InitializingBean, DisposableBean
/*    */ {
/*    */   @Nullable
/*    */   private Executor executor;
/* 47 */   private String threadPrefix = "jdk-http";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExecutor(@Nullable Executor executor) {
/* 59 */     this.executor = executor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Executor getExecutor() {
/* 67 */     return this.executor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setThreadPrefix(String threadPrefix) {
/* 78 */     Assert.notNull(threadPrefix, "Thread prefix is required");
/* 79 */     this.threadPrefix = threadPrefix;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws Exception {
/* 85 */     if (this.executor == null) {
/* 86 */       String name = this.threadPrefix + "@" + this.threadPrefix;
/* 87 */       this.executor = Executors.newCachedThreadPool((ThreadFactory)new CustomizableThreadFactory(name));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() throws Exception {
/* 93 */     Executor executor = this.executor; if (executor instanceof ExecutorService) { ExecutorService executorService = (ExecutorService)executor;
/* 94 */       executorService.shutdown(); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JdkHttpClientResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */