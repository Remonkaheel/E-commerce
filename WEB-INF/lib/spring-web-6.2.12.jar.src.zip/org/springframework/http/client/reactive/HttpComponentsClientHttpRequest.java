/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.apache.hc.client5.http.protocol.HttpClientContext;
/*     */ import org.apache.hc.core5.http.ContentType;
/*     */ import org.apache.hc.core5.http.HttpMessage;
/*     */ import org.apache.hc.core5.http.HttpRequest;
/*     */ import org.apache.hc.core5.http.message.BasicHttpRequest;
/*     */ import org.apache.hc.core5.http.nio.AsyncEntityProducer;
/*     */ import org.apache.hc.core5.http.nio.AsyncRequestProducer;
/*     */ import org.apache.hc.core5.http.nio.support.BasicRequestProducer;
/*     */ import org.apache.hc.core5.reactive.ReactiveEntityProducer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.support.HttpComponentsHeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpComponentsClientHttpRequest
/*     */   extends AbstractClientHttpRequest
/*     */ {
/*     */   private final HttpRequest httpRequest;
/*     */   private final DataBufferFactory dataBufferFactory;
/*     */   private final HttpClientContext context;
/*     */   @Nullable
/*     */   private Flux<ByteBuffer> byteBufferFlux;
/*  65 */   private transient long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpComponentsClientHttpRequest(HttpMethod method, URI uri, HttpClientContext context, DataBufferFactory dataBufferFactory) {
/*  71 */     this.context = context;
/*  72 */     this.httpRequest = (HttpRequest)new BasicHttpRequest(method.name(), uri);
/*  73 */     this.dataBufferFactory = dataBufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  79 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*     */     try {
/*  85 */       return this.httpRequest.getUri();
/*     */     }
/*  87 */     catch (URISyntaxException ex) {
/*  88 */       throw new IllegalArgumentException("Invalid URI syntax: " + ex.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  94 */     return this.dataBufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/* 100 */     return (T)this.httpRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/* 105 */     return doCommit(() -> {
/*     */           this.byteBufferFlux = Flux.from(body).map(());
/*     */           return (Publisher)Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 117 */     return writeWith((Publisher<? extends DataBuffer>)Flux.from(body).flatMap(Function.identity()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 122 */     return doCommit();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 127 */     HttpHeaders headers = getHeaders();
/*     */     
/* 129 */     headers.entrySet()
/* 130 */       .stream()
/* 131 */       .filter(entry -> !"Content-Length".equals(entry.getKey()))
/* 132 */       .forEach(entry -> ((List)entry.getValue()).forEach(()));
/*     */     
/* 134 */     if (!this.httpRequest.containsHeader("Accept")) {
/* 135 */       this.httpRequest.addHeader("Accept", "*/*");
/*     */     }
/*     */     
/* 138 */     this.contentLength = headers.getContentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 143 */     if (getCookies().isEmpty()) {
/*     */       return;
/*     */     }
/* 146 */     if (!CollectionUtils.isEmpty((Map)getCookies())) {
/* 147 */       this.httpRequest.setHeader("Cookie", serializeCookies());
/*     */     }
/*     */   }
/*     */   
/*     */   private String serializeCookies() {
/* 152 */     boolean first = true;
/* 153 */     StringBuilder sb = new StringBuilder();
/* 154 */     for (List<HttpCookie> cookies : (Iterable<List<HttpCookie>>)getCookies().values()) {
/* 155 */       for (HttpCookie cookie : cookies) {
/* 156 */         if (!first) {
/* 157 */           sb.append("; ");
/*     */         } else {
/*     */           
/* 160 */           first = false;
/*     */         } 
/* 162 */         sb.append(cookie.getName()).append("=").append(cookie.getValue());
/*     */       } 
/*     */     } 
/* 165 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyAttributes() {
/* 173 */     getAttributes().forEach((key, value) -> {
/*     */           if (this.context.getAttribute(key) == null) {
/*     */             this.context.setAttribute(key, value);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpHeaders initReadOnlyHeaders() {
/* 182 */     return HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new HttpComponentsHeadersAdapter((HttpMessage)this.httpRequest));
/*     */   }
/*     */   
/*     */   public AsyncRequestProducer toRequestProducer() {
/* 186 */     ReactiveEntityProducer reactiveEntityProducer = null;
/*     */     
/* 188 */     if (this.byteBufferFlux != null) {
/* 189 */       String contentEncoding = getHeaders().getFirst("Content-Encoding");
/* 190 */       ContentType contentType = null;
/* 191 */       if (getHeaders().getContentType() != null) {
/* 192 */         contentType = ContentType.parse(getHeaders().getContentType().toString());
/*     */       }
/* 194 */       reactiveEntityProducer = new ReactiveEntityProducer((Publisher)this.byteBufferFlux, this.contentLength, contentType, contentEncoding);
/*     */     } 
/*     */ 
/*     */     
/* 198 */     return (AsyncRequestProducer)new BasicRequestProducer(this.httpRequest, (AsyncEntityProducer)reactiveEntityProducer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\HttpComponentsClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */