/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleSubscriberPublisher<T>
/*     */   implements Publisher<T>
/*     */ {
/*  89 */   private static final Subscription NO_OP_SUBSCRIPTION = new Subscription()
/*     */     {
/*     */       public void request(long l) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void cancel() {}
/*     */     };
/*     */ 
/*     */   
/*     */   private final Publisher<T> delegate;
/*     */   
/* 101 */   private final AtomicBoolean subscribed = new AtomicBoolean();
/*     */ 
/*     */   
/*     */   public SingleSubscriberPublisher(Publisher<T> delegate) {
/* 105 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(Subscriber<? super T> subscriber) {
/* 110 */     Objects.requireNonNull(subscriber, "Subscriber must not be null");
/* 111 */     if (this.subscribed.compareAndSet(false, true)) {
/* 112 */       this.delegate.subscribe(subscriber);
/*     */     } else {
/*     */       
/* 115 */       subscriber.onSubscribe(NO_OP_SUBSCRIPTION);
/* 116 */       subscriber.onError(new IllegalStateException("The client response body can only be consumed once"));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\AbstractClientHttpResponse$SingleSubscriberPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */