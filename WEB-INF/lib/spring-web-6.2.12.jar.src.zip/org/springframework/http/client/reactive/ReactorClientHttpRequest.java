/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.codec.http.cookie.DefaultCookie;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.NettyDataBufferFactory;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.ZeroCopyHttpOutputMessage;
/*     */ import org.springframework.http.support.Netty4HeadersAdapter;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.http.client.HttpClientRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorClientHttpRequest
/*     */   extends AbstractClientHttpRequest
/*     */   implements ZeroCopyHttpOutputMessage
/*     */ {
/*     */   private final HttpMethod httpMethod;
/*     */   private final URI uri;
/*     */   private final HttpClientRequest request;
/*     */   private final NettyOutbound outbound;
/*     */   private final NettyDataBufferFactory bufferFactory;
/*     */   
/*     */   public ReactorClientHttpRequest(HttpMethod method, URI uri, HttpClientRequest request, NettyOutbound outbound) {
/*  61 */     this.httpMethod = method;
/*  62 */     this.uri = uri;
/*  63 */     this.request = request;
/*  64 */     this.outbound = outbound;
/*  65 */     this.bufferFactory = new NettyDataBufferFactory(outbound.alloc());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  71 */     return this.httpMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  76 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataBufferFactory bufferFactory() {
/*  81 */     return (DataBufferFactory)this.bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getNativeRequest() {
/*  87 */     return (T)this.request;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
/*  92 */     return doCommit(() -> {
/*     */           if (body instanceof Mono) {
/*     */             Mono<ByteBuf> byteBufMono = Mono.from(body).map(NettyDataBufferFactory::toByteBuf);
/*     */             return (Publisher)this.outbound.send((Publisher)byteBufMono).then();
/*     */           } 
/*     */           Flux<ByteBuf> byteBufFlux = Flux.from(body).map(NettyDataBufferFactory::toByteBuf);
/*     */           return (Publisher)this.outbound.send((Publisher)byteBufFlux).then();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body) {
/* 108 */     Flux flux = Flux.from(body).map(ReactorClientHttpRequest::toByteBufs);
/* 109 */     return doCommit(() -> this.outbound.sendGroups(byteBufs).then());
/*     */   }
/*     */   
/*     */   private static Publisher<ByteBuf> toByteBufs(Publisher<? extends DataBuffer> dataBuffers) {
/* 113 */     return (Publisher<ByteBuf>)Flux.from(dataBuffers).map(NettyDataBufferFactory::toByteBuf);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeWith(Path file, long position, long count) {
/* 118 */     return doCommit(() -> this.outbound.sendFile(file, position, count).then());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> setComplete() {
/* 125 */     return doCommit(null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyHeaders() {
/* 130 */     getHeaders().forEach((key, value) -> this.request.requestHeaders().set(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyCookies() {
/* 135 */     getCookies().values().forEach(values -> values.forEach(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyAttributes() {
/* 148 */     if (!getAttributes().isEmpty()) {
/* 149 */       ((ChannelOperations)this.request).channel()
/* 150 */         .attr(ReactorClientHttpConnector.ATTRIBUTES_KEY).set(getAttributes());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected HttpHeaders initReadOnlyHeaders() {
/* 156 */     return HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new Netty4HeadersAdapter(this.request.requestHeaders()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */