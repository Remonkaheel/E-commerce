/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import org.apache.hc.client5.http.protocol.HttpClientContext;
/*     */ import org.apache.hc.core5.concurrent.FutureCallback;
/*     */ import org.apache.hc.core5.http.HttpResponse;
/*     */ import org.apache.hc.core5.http.Message;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResponseCallback
/*     */   implements FutureCallback<Message<HttpResponse, Publisher<ByteBuffer>>>
/*     */ {
/*     */   private final MonoSink<ClientHttpResponse> sink;
/*     */   private final DataBufferFactory dataBufferFactory;
/*     */   private final HttpClientContext context;
/*     */   
/*     */   public ResponseCallback(MonoSink<ClientHttpResponse> sink, DataBufferFactory dataBufferFactory, HttpClientContext context) {
/* 146 */     this.sink = sink;
/* 147 */     this.dataBufferFactory = dataBufferFactory;
/* 148 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void completed(Message<HttpResponse, Publisher<ByteBuffer>> result) {
/* 153 */     this.sink.success(new HttpComponentsClientHttpResponse(this.dataBufferFactory, result, this.context));
/*     */   }
/*     */ 
/*     */   
/*     */   public void failed(Exception ex) {
/* 158 */     this.sink.error((ex instanceof org.apache.hc.core5.http.HttpStreamResetException && ex.getCause() != null) ? ex.getCause() : ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelled() {
/* 163 */     this.sink.error(new CancellationException());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\HttpComponentsClientHttpConnector$ResponseCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */