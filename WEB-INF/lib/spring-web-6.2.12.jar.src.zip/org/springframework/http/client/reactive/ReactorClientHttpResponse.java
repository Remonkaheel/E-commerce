/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.handler.codec.http.cookie.Cookie;
/*     */ import io.netty.handler.codec.http.cookie.DefaultCookie;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.NettyDataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.support.Netty4HeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.netty.ChannelOperationsId;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactorClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(ReactorClientHttpResponse.class);
/*     */ 
/*     */   
/*     */   private final HttpClientResponse response;
/*     */   
/*     */   private final HttpHeaders headers;
/*     */   
/*     */   private final NettyInbound inbound;
/*     */   
/*     */   private final NettyDataBufferFactory bufferFactory;
/*     */   
/*  68 */   private final AtomicInteger state = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorClientHttpResponse(HttpClientResponse response, Connection connection) {
/*  77 */     this.response = response;
/*  78 */     Netty4HeadersAdapter netty4HeadersAdapter = new Netty4HeadersAdapter(response.responseHeaders());
/*  79 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)netty4HeadersAdapter);
/*  80 */     this.inbound = connection.inbound();
/*  81 */     this.bufferFactory = new NettyDataBufferFactory(connection.outbound().alloc());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ReactorClientHttpResponse(HttpClientResponse response, NettyInbound inbound, ByteBufAllocator alloc) {
/*  90 */     this.response = response;
/*  91 */     Netty4HeadersAdapter netty4HeadersAdapter = new Netty4HeadersAdapter(response.responseHeaders());
/*  92 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)netty4HeadersAdapter);
/*  93 */     this.inbound = inbound;
/*  94 */     this.bufferFactory = new NettyDataBufferFactory(alloc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 100 */     String id = null;
/* 101 */     HttpClientResponse httpClientResponse = this.response; if (httpClientResponse instanceof ChannelOperationsId) { ChannelOperationsId operationsId = (ChannelOperationsId)httpClientResponse;
/* 102 */       id = logger.isDebugEnabled() ? operationsId.asLongText() : operationsId.asShortText(); }
/*     */     
/* 104 */     if (id == null) { httpClientResponse = this.response; if (httpClientResponse instanceof Connection) { Connection connection = (Connection)httpClientResponse;
/* 105 */         id = connection.channel().id().asShortText(); }
/*     */        }
/* 107 */      return (id != null) ? id : ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<DataBuffer> getBody() {
/* 112 */     return this.inbound.receive()
/* 113 */       .doOnSubscribe(s -> {
/*     */           if (this.state.compareAndSet(0, 1)) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/*     */           if (this.state.get() == 2) {
/*     */             throw new IllegalStateException("The client response body has been released already due to cancellation.");
/*     */           }
/* 122 */         }).map(byteBuf -> {
/*     */           byteBuf.retain();
/*     */           return (DataBuffer)this.bufferFactory.wrap(byteBuf);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 130 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/* 135 */     return HttpStatusCode.valueOf(this.response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies() {
/* 140 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 141 */     this.response.cookies().values().stream()
/* 142 */       .flatMap(Collection::stream)
/* 143 */       .forEach(cookie -> result.add(cookie.name(), ResponseCookie.fromClientResponse(cookie.name(), cookie.value()).domain(cookie.domain()).path(cookie.path()).maxAge(cookie.maxAge()).secure(cookie.isSecure()).httpOnly(cookie.isHttpOnly()).sameSite(getSameSite(cookie)).partitioned(getPartitioned(cookie)).build()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     return CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)linkedMultiValueMap);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static String getSameSite(Cookie cookie) {
/* 158 */     if (cookie instanceof DefaultCookie) { DefaultCookie defaultCookie = (DefaultCookie)cookie; if (defaultCookie.sameSite() != null)
/* 159 */         return defaultCookie.sameSite().name();  }
/*     */     
/* 161 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean getPartitioned(Cookie cookie) {
/* 165 */     if (cookie instanceof DefaultCookie) { DefaultCookie defaultCookie = (DefaultCookie)cookie;
/* 166 */       return defaultCookie.isPartitioned(); }
/*     */     
/* 168 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void releaseAfterCancel(HttpMethod method) {
/* 179 */     if (mayHaveBody(method) && this.state.compareAndSet(0, 2)) {
/* 180 */       if (logger.isDebugEnabled()) {
/* 181 */         logger.debug("[" + getId() + "]Releasing body, not yet subscribed.");
/*     */       }
/* 183 */       this.inbound.receive().doOnNext(byteBuf -> {  }).subscribe(byteBuf -> {
/*     */           
/*     */           }ex -> {
/*     */           
/*     */           });
/* 188 */     }  } private boolean mayHaveBody(HttpMethod method) { int code = getStatusCode().value();
/* 189 */     return ((code < 100 || code >= 200) && code != 204 && code != 205 && 
/* 190 */       !method.equals(HttpMethod.HEAD) && getHeaders().getContentLength() != 0L); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     return "ReactorClientHttpResponse{request=[" + this.response
/* 196 */       .method().name() + " " + this.response.uri() + "],status=" + 
/* 197 */       String.valueOf(getStatusCode()) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */