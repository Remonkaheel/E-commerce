package org.springframework.http.client.reactive;

import java.net.URI;
import java.util.function.Function;
import org.springframework.http.HttpMethod;
import reactor.core.publisher.Mono;

public interface ClientHttpConnector {
  Mono<ClientHttpResponse> connect(HttpMethod paramHttpMethod, URI paramURI, Function<? super ClientHttpRequest, Mono<Void>> paramFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */