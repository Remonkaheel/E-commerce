/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import io.netty5.handler.codec.http.HttpMethod;
/*     */ import io.netty5.util.AttributeKey;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty5.Connection;
/*     */ import reactor.netty5.NettyOutbound;
/*     */ import reactor.netty5.http.client.HttpClient;
/*     */ import reactor.netty5.http.client.HttpClientRequest;
/*     */ import reactor.netty5.http.client.HttpClientResponse;
/*     */ import reactor.netty5.resources.ConnectionProvider;
/*     */ import reactor.netty5.resources.LoopResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorNetty2ClientHttpConnector
/*     */   implements ClientHttpConnector
/*     */ {
/*  51 */   public static final AttributeKey<Map<String, Object>> ATTRIBUTES_KEY = AttributeKey.valueOf(ReactorNetty2ClientHttpRequest.class.getName() + ".ATTRIBUTES");
/*     */   static {
/*  53 */     defaultInitializer = (client -> client.compress(true));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Function<HttpClient, HttpClient> defaultInitializer;
/*     */ 
/*     */   
/*     */   private final HttpClient httpClient;
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNetty2ClientHttpConnector() {
/*  66 */     this.httpClient = defaultInitializer.apply(HttpClient.create().wiretap(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNetty2ClientHttpConnector(ReactorNetty2ResourceFactory factory, Function<HttpClient, HttpClient> mapper) {
/*  86 */     ConnectionProvider provider = factory.getConnectionProvider();
/*  87 */     Assert.notNull(provider, "No ConnectionProvider: is ReactorNetty2ResourceFactory not initialized yet?");
/*  88 */     this
/*  89 */       .httpClient = defaultInitializer.<HttpClient>andThen(mapper).<HttpClient>andThen(applyLoopResources(factory)).apply(HttpClient.create(provider));
/*     */   }
/*     */   
/*     */   private static Function<HttpClient, HttpClient> applyLoopResources(ReactorNetty2ResourceFactory factory) {
/*  93 */     return httpClient -> {
/*     */         LoopResources resources = factory.getLoopResources();
/*     */         Assert.notNull(resources, "No LoopResources: is ReactorNetty2ResourceFactory not initialized yet?");
/*     */         return (HttpClient)httpClient.runOn(resources);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorNetty2ClientHttpConnector(HttpClient httpClient) {
/* 107 */     Assert.notNull(httpClient, "HttpClient is required");
/* 108 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientHttpResponse> connect(HttpMethod method, URI uri, Function<? super ClientHttpRequest, Mono<Void>> requestCallback) {
/* 116 */     AtomicReference<ReactorNetty2ClientHttpResponse> responseRef = new AtomicReference<>();
/*     */ 
/*     */     
/* 119 */     HttpClient.RequestSender requestSender = this.httpClient.request(HttpMethod.valueOf(method.name()));
/*     */     
/* 121 */     requestSender = uri.isAbsolute() ? (HttpClient.RequestSender)requestSender.uri(uri) : (HttpClient.RequestSender)requestSender.uri(uri.toString());
/*     */     
/* 123 */     return requestSender
/* 124 */       .send((request, outbound) -> (Publisher)requestCallback.apply(adaptRequest(method, uri, request, outbound)))
/* 125 */       .responseConnection((response, connection) -> {
/*     */           responseRef.set(new ReactorNetty2ClientHttpResponse(response, connection));
/*     */           
/*     */           return (Publisher)Mono.just(responseRef.get());
/* 129 */         }).next()
/* 130 */       .doOnCancel(() -> {
/*     */           ReactorNetty2ClientHttpResponse response = responseRef.get();
/*     */           if (response != null) {
/*     */             response.releaseAfterCancel(method);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ReactorNetty2ClientHttpRequest adaptRequest(HttpMethod method, URI uri, HttpClientRequest request, NettyOutbound nettyOutbound) {
/* 141 */     return new ReactorNetty2ClientHttpRequest(method, uri, request, nettyOutbound);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\ReactorNetty2ClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */