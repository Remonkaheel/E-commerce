/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.time.Duration;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.hc.client5.http.cookie.Cookie;
/*     */ import org.apache.hc.client5.http.cookie.CookieOrigin;
/*     */ import org.apache.hc.client5.http.cookie.CookieSpec;
/*     */ import org.apache.hc.client5.http.cookie.MalformedCookieException;
/*     */ import org.apache.hc.client5.http.protocol.HttpClientContext;
/*     */ import org.apache.hc.core5.http.Header;
/*     */ import org.apache.hc.core5.http.HttpMessage;
/*     */ import org.apache.hc.core5.http.HttpResponse;
/*     */ import org.apache.hc.core5.http.Message;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.support.HttpComponentsHeadersAdapter;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpComponentsClientHttpResponse
/*     */   extends AbstractClientHttpResponse
/*     */ {
/*     */   public HttpComponentsClientHttpResponse(DataBufferFactory dataBufferFactory, Message<HttpResponse, Publisher<ByteBuffer>> message, HttpClientContext context) {
/*  60 */     super(HttpStatusCode.valueOf(((HttpResponse)message.getHead()).getCode()), 
/*  61 */         HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new HttpComponentsHeadersAdapter((HttpMessage)message.getHead())), 
/*  62 */         adaptCookies((HttpResponse)message.getHead(), context), 
/*  63 */         Flux.from((Publisher)message.getBody()).map(dataBufferFactory::wrap));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MultiValueMap<String, ResponseCookie> adaptCookies(HttpResponse response, HttpClientContext context) {
/*  70 */     LinkedMultiValueMap<String, ResponseCookie> result = new LinkedMultiValueMap();
/*     */     
/*  72 */     CookieSpec cookieSpec = context.getCookieSpec();
/*  73 */     if (cookieSpec == null) {
/*  74 */       return (MultiValueMap<String, ResponseCookie>)result;
/*     */     }
/*     */     
/*  77 */     CookieOrigin cookieOrigin = context.getCookieOrigin();
/*  78 */     Iterator<Header> itr = response.headerIterator("Set-Cookie");
/*  79 */     while (itr.hasNext()) {
/*  80 */       Header header = itr.next();
/*     */       try {
/*  82 */         List<Cookie> cookies = cookieSpec.parse(header, cookieOrigin);
/*  83 */         for (Cookie cookie : cookies) {
/*     */           try {
/*  85 */             cookieSpec.validate(cookie, cookieOrigin);
/*  86 */             result.add(cookie.getName(), 
/*  87 */                 ResponseCookie.fromClientResponse(cookie.getName(), cookie.getValue())
/*  88 */                 .domain(cookie.getDomain())
/*  89 */                 .path(cookie.getPath())
/*  90 */                 .maxAge(getMaxAgeSeconds(cookie))
/*  91 */                 .secure(cookie.isSecure())
/*  92 */                 .httpOnly(cookie.containsAttribute("httponly"))
/*  93 */                 .partitioned(cookie.containsAttribute("partitioned"))
/*  94 */                 .sameSite(cookie.getAttribute("samesite"))
/*  95 */                 .build());
/*     */           }
/*  97 */           catch (MalformedCookieException malformedCookieException) {}
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 102 */       catch (MalformedCookieException malformedCookieException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 107 */     return (MultiValueMap<String, ResponseCookie>)result;
/*     */   }
/*     */   
/*     */   private static long getMaxAgeSeconds(Cookie cookie) {
/* 111 */     String expiresAttribute = cookie.getAttribute("expires");
/* 112 */     String maxAgeAttribute = cookie.getAttribute("max-age");
/* 113 */     if (maxAgeAttribute != null) {
/* 114 */       return Long.parseLong(maxAgeAttribute);
/*     */     }
/*     */     
/* 117 */     if (expiresAttribute != null) {
/*     */       try {
/* 119 */         ZonedDateTime expiresDate = ZonedDateTime.parse(expiresAttribute, DateTimeFormatter.RFC_1123_DATE_TIME);
/* 120 */         return Duration.between(ZonedDateTime.now(expiresDate.getZone()), expiresDate).toSeconds();
/*     */       }
/* 122 */       catch (DateTimeParseException dateTimeParseException) {}
/*     */     }
/*     */ 
/*     */     
/* 126 */     return -1L;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\HttpComponentsClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */