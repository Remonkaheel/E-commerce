/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.http.HttpClient;
/*     */ import java.net.http.HttpRequest;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkClientHttpConnector
/*     */   implements ClientHttpConnector
/*     */ {
/*     */   private final HttpClient httpClient;
/*  51 */   private DataBufferFactory bufferFactory = (DataBufferFactory)DefaultDataBufferFactory.sharedInstance;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Duration readTimeout;
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpConnector() {
/*  61 */     this(HttpClient.newHttpClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpConnector(HttpClient httpClient) {
/*  68 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpConnector(HttpClient.Builder clientBuilder, @Nullable JdkHttpClientResourceFactory resourceFactory) {
/*  81 */     if (resourceFactory != null) {
/*  82 */       Executor executor = resourceFactory.getExecutor();
/*  83 */       clientBuilder.executor(executor);
/*     */     } 
/*  85 */     this.httpClient = clientBuilder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferFactory(DataBufferFactory bufferFactory) {
/*  94 */     Assert.notNull(bufferFactory, "DataBufferFactory is required");
/*  95 */     this.bufferFactory = bufferFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/* 105 */     Assert.notNull(readTimeout, "readTimeout is required");
/* 106 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ClientHttpResponse> connect(HttpMethod method, URI uri, Function<? super ClientHttpRequest, Mono<Void>> requestCallback) {
/* 114 */     JdkClientHttpRequest jdkClientHttpRequest = new JdkClientHttpRequest(method, uri, this.bufferFactory, this.readTimeout);
/*     */ 
/*     */     
/* 117 */     return ((Mono)requestCallback.apply(jdkClientHttpRequest)).then(Mono.defer(() -> {
/*     */             HttpRequest httpRequest = jdkClientHttpRequest.<HttpRequest>getNativeRequest();
/*     */             CompletableFuture<HttpResponse<Flow.Publisher<List<ByteBuffer>>>> future = this.httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofPublisher());
/*     */             return Mono.fromCompletionStage(future).map(());
/*     */           }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JdkClientHttpConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */