/*    */ package org.springframework.http.client.reactive;
/*    */ 
/*    */ import java.net.HttpCookie;
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.eclipse.jetty.http.HttpField;
/*    */ import org.eclipse.jetty.reactive.client.ReactiveResponse;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.ResponseCookie;
/*    */ import org.springframework.http.support.JettyHeadersAdapter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyClientHttpResponse
/*    */   extends AbstractClientHttpResponse
/*    */ {
/* 48 */   private static final Pattern SAME_SITE_PATTERN = Pattern.compile("(?i).*SameSite=(Strict|Lax|None).*");
/*    */ 
/*    */ 
/*    */   
/*    */   public JettyClientHttpResponse(ReactiveResponse reactiveResponse, Flux<DataBuffer> content) {
/* 53 */     super(HttpStatusCode.valueOf(reactiveResponse.getStatus()), 
/* 54 */         adaptHeaders(reactiveResponse), 
/* 55 */         adaptCookies(reactiveResponse), content);
/*    */   }
/*    */ 
/*    */   
/*    */   private static HttpHeaders adaptHeaders(ReactiveResponse response) {
/* 60 */     JettyHeadersAdapter jettyHeadersAdapter = new JettyHeadersAdapter(response.getHeaders());
/* 61 */     return HttpHeaders.readOnlyHttpHeaders((MultiValueMap)jettyHeadersAdapter);
/*    */   }
/*    */   private static MultiValueMap<String, ResponseCookie> adaptCookies(ReactiveResponse response) {
/* 64 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 65 */     List<HttpField> cookieHeaders = response.getHeaders().getFields("Set-Cookie");
/* 66 */     cookieHeaders.forEach(header -> HttpCookie.parse(header.getValue()).forEach(()));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 77 */     return CollectionUtils.unmodifiableMultiValueMap((MultiValueMap)linkedMultiValueMap);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   private static String parseSameSite(String headerValue) {
/* 82 */     Matcher matcher = SAME_SITE_PATTERN.matcher(headerValue);
/* 83 */     return matcher.matches() ? matcher.group(1) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JettyClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */