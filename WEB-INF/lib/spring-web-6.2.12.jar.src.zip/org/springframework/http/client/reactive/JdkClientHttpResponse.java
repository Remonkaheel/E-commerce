/*     */ package org.springframework.http.client.reactive;
/*     */ 
/*     */ import java.net.HttpCookie;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Flow;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.MultiValueMapAdapter;
/*     */ import reactor.adapter.JdkFlowAdapter;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkClientHttpResponse
/*     */   extends AbstractClientHttpResponse
/*     */ {
/*  55 */   private static final Pattern SAME_SITE_PATTERN = Pattern.compile("(?i).*SameSite=(Strict|Lax|None).*");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClientHttpResponse(HttpResponse<Flow.Publisher<List<ByteBuffer>>> response, DataBufferFactory bufferFactory) {
/*  62 */     super(HttpStatusCode.valueOf(response.statusCode()), 
/*  63 */         adaptHeaders(response), 
/*  64 */         adaptCookies(response), 
/*  65 */         adaptBody(response, bufferFactory));
/*     */   }
/*     */ 
/*     */   
/*     */   private static HttpHeaders adaptHeaders(HttpResponse<Flow.Publisher<List<ByteBuffer>>> response) {
/*  70 */     Map<String, List<String>> rawHeaders = response.headers().map();
/*  71 */     LinkedCaseInsensitiveMap linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap(rawHeaders.size(), Locale.ROOT);
/*  72 */     MultiValueMap<String, String> multiValueMap = CollectionUtils.toMultiValueMap((Map)linkedCaseInsensitiveMap);
/*  73 */     multiValueMap.putAll(rawHeaders);
/*  74 */     return HttpHeaders.readOnlyHttpHeaders(multiValueMap);
/*     */   }
/*     */   
/*     */   private static MultiValueMap<String, ResponseCookie> adaptCookies(HttpResponse<Flow.Publisher<List<ByteBuffer>>> response) {
/*  78 */     return (MultiValueMap<String, ResponseCookie>)response.headers().allValues("Set-Cookie").stream()
/*  79 */       .flatMap(header -> {
/*     */           Matcher matcher = SAME_SITE_PATTERN.matcher(header);
/*     */           
/*     */           String sameSite = matcher.matches() ? matcher.group(1) : null;
/*     */           return HttpCookie.parse(header).stream().map(());
/*  84 */         }).collect(LinkedMultiValueMap::new, (cookies, cookie) -> cookies.add(cookie.getName(), cookie), MultiValueMapAdapter::addAll);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResponseCookie toResponseCookie(HttpCookie cookie, @Nullable String sameSite) {
/*  90 */     return ResponseCookie.from(cookie.getName(), cookie.getValue())
/*  91 */       .domain(cookie.getDomain())
/*  92 */       .httpOnly(cookie.isHttpOnly())
/*  93 */       .maxAge(cookie.getMaxAge())
/*  94 */       .path(cookie.getPath())
/*  95 */       .secure(cookie.getSecure())
/*  96 */       .sameSite(sameSite)
/*  97 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Flux<DataBuffer> adaptBody(HttpResponse<Flow.Publisher<List<ByteBuffer>>> response, DataBufferFactory bufferFactory) {
/* 103 */     Objects.requireNonNull(bufferFactory); return JdkFlowAdapter.flowPublisherToFlux(response.body()).flatMapIterable(Function.identity()).map(bufferFactory::wrap)
/* 104 */       .doOnDiscard(DataBuffer.class, DataBufferUtils::release)
/* 105 */       .cache(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\reactive\JdkClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */