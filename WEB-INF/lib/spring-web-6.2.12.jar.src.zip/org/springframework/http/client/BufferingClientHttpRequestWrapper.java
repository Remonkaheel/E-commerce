/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.net.URI;
/*    */ import java.util.Map;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.StreamingHttpOutputMessage;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BufferingClientHttpRequestWrapper
/*    */   extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequest request;
/*    */   
/*    */   BufferingClientHttpRequestWrapper(ClientHttpRequest request) {
/* 40 */     this.request = request;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpMethod getMethod() {
/* 46 */     return this.request.getMethod();
/*    */   }
/*    */ 
/*    */   
/*    */   public URI getURI() {
/* 51 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, final byte[] bufferedOutput) throws IOException {
/* 56 */     this.request.getHeaders().putAll((Map)headers);
/*    */     
/* 58 */     if (bufferedOutput.length > 0) {
/* 59 */       ClientHttpRequest clientHttpRequest = this.request; if (clientHttpRequest instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingHttpOutputMessage = (StreamingHttpOutputMessage)clientHttpRequest;
/* 60 */         streamingHttpOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*    */             {
/*    */               public void writeTo(OutputStream outputStream) throws IOException {
/* 63 */                 StreamUtils.copy(bufferedOutput, outputStream);
/*    */               }
/*    */ 
/*    */               
/*    */               public boolean repeatable() {
/* 68 */                 return true;
/*    */               }
/*    */             }); }
/*    */       else
/*    */       
/* 73 */       { StreamUtils.copy(bufferedOutput, this.request.getBody()); }
/*    */     
/*    */     } 
/*    */     
/* 77 */     ClientHttpResponse response = this.request.execute();
/* 78 */     return new BufferingClientHttpResponseWrapper(response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\BufferingClientHttpRequestWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */