/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.time.Duration;
/*     */ import org.reactivestreams.FlowAdapters;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.support.Netty4HeadersAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.client.HttpClientResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReactorClientHttpResponse
/*     */   implements ClientHttpResponse
/*     */ {
/*     */   private final HttpClientResponse response;
/*     */   private final Connection connection;
/*     */   private final HttpHeaders headers;
/*     */   @Nullable
/*     */   private volatile InputStream body;
/*     */   
/*     */   public ReactorClientHttpResponse(HttpClientResponse response, Connection connection) {
/*  61 */     this.response = response;
/*  62 */     this.connection = connection;
/*  63 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new Netty4HeadersAdapter(response
/*  64 */           .responseHeaders()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public ReactorClientHttpResponse(HttpClientResponse response, Connection connection, @Nullable Duration readTimeout) {
/*  77 */     this.response = response;
/*  78 */     this.connection = connection;
/*  79 */     this.headers = HttpHeaders.readOnlyHttpHeaders((MultiValueMap)new Netty4HeadersAdapter(response.responseHeaders()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpStatusCode getStatusCode() {
/*  85 */     return HttpStatusCode.valueOf(this.response.status().code());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatusText() {
/*  90 */     return this.response.status().reasonPhrase();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/*  95 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBody() throws IOException {
/* 100 */     InputStream body = this.body;
/* 101 */     if (body != null) {
/* 102 */       return body;
/*     */     }
/*     */     try {
/* 105 */       SubscriberInputStream<ByteBuf> is = new SubscriberInputStream<>(byteBuf -> { byte[] bytes = new byte[byteBuf.readableBytes()]; byteBuf.readBytes(bytes); byteBuf.release(); return bytes; }ReferenceCounted::release, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       this.connection.inbound().receive().retain().subscribe(FlowAdapters.toSubscriber(is));
/* 114 */       this.body = is;
/* 115 */       return is;
/*     */     }
/* 117 */     catch (RuntimeException ex) {
/* 118 */       throw ReactorClientHttpRequest.convertException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 125 */       InputStream body = getBody();
/* 126 */       StreamUtils.drain(body);
/* 127 */       body.close();
/*     */     }
/* 129 */     catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ReactorClientHttpResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */