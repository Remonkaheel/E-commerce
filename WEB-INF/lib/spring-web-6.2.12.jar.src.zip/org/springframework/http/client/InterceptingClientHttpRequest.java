/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.StreamingHttpOutputMessage;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InterceptingClientHttpRequest
/*     */   extends AbstractBufferingClientHttpRequest
/*     */ {
/*     */   private final ClientHttpRequestFactory requestFactory;
/*     */   private final List<ClientHttpRequestInterceptor> interceptors;
/*     */   private final HttpMethod method;
/*     */   private final URI uri;
/*     */   
/*     */   protected InterceptingClientHttpRequest(ClientHttpRequestFactory requestFactory, List<ClientHttpRequestInterceptor> interceptors, URI uri, HttpMethod method) {
/*  52 */     this.requestFactory = requestFactory;
/*  53 */     this.interceptors = interceptors;
/*  54 */     this.method = method;
/*  55 */     this.uri = uri;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMethod getMethod() {
/*  61 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/*  66 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException {
/*  71 */     InterceptingRequestExecution requestExecution = new InterceptingRequestExecution();
/*  72 */     return requestExecution.execute(this, bufferedOutput);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class InterceptingRequestExecution
/*     */     implements ClientHttpRequestExecution
/*     */   {
/*  81 */     private final Iterator<ClientHttpRequestInterceptor> iterator = InterceptingClientHttpRequest.this.interceptors.iterator();
/*     */ 
/*     */ 
/*     */     
/*     */     public ClientHttpResponse execute(HttpRequest request, final byte[] body) throws IOException {
/*  86 */       if (this.iterator.hasNext()) {
/*  87 */         ClientHttpRequestInterceptor nextInterceptor = this.iterator.next();
/*  88 */         return nextInterceptor.intercept(request, body, this);
/*     */       } 
/*     */       
/*  91 */       HttpMethod method = request.getMethod();
/*  92 */       ClientHttpRequest delegate = InterceptingClientHttpRequest.this.requestFactory.createRequest(request.getURI(), method);
/*  93 */       request.getHeaders().forEach((key, value) -> delegate.getHeaders().addAll(key, value));
/*  94 */       request.getAttributes().forEach((key, value) -> delegate.getAttributes().put(key, value));
/*  95 */       if (body.length > 0) {
/*  96 */         long contentLength = delegate.getHeaders().getContentLength();
/*  97 */         if (contentLength > -1L && contentLength != body.length) {
/*  98 */           delegate.getHeaders().setContentLength(body.length);
/*     */         }
/* 100 */         if (delegate instanceof StreamingHttpOutputMessage) { StreamingHttpOutputMessage streamingOutputMessage = (StreamingHttpOutputMessage)delegate;
/* 101 */           streamingOutputMessage.setBody(new StreamingHttpOutputMessage.Body()
/*     */               {
/*     */                 public void writeTo(OutputStream outputStream) throws IOException {
/* 104 */                   StreamUtils.copy(body, outputStream);
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public boolean repeatable() {
/* 109 */                   return true;
/*     */                 }
/*     */               }); }
/*     */         else
/*     */         
/* 114 */         { StreamUtils.copy(body, delegate.getBody()); }
/*     */       
/*     */       } 
/* 117 */       return delegate.execute();
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements StreamingHttpOutputMessage.Body {
/*     */     public void writeTo(OutputStream outputStream) throws IOException {
/*     */       StreamUtils.copy(body, outputStream);
/*     */     }
/*     */     
/*     */     public boolean repeatable() {
/*     */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\InterceptingClientHttpRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */