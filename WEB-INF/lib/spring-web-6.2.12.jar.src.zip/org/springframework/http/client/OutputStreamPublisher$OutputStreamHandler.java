package org.springframework.http.client;

import java.io.OutputStream;

@FunctionalInterface
public interface OutputStreamHandler {
  void handle(OutputStream paramOutputStream) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\OutputStreamPublisher$OutputStreamHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */