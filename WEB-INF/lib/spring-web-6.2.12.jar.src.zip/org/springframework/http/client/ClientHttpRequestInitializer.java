package org.springframework.http.client;

@FunctionalInterface
public interface ClientHttpRequestInitializer {
  void initialize(ClientHttpRequest paramClientHttpRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\ClientHttpRequestInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */