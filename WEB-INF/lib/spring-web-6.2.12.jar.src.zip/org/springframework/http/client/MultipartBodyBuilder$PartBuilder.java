package org.springframework.http.client;

import java.util.function.Consumer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public interface PartBuilder {
  PartBuilder contentType(MediaType paramMediaType);
  
  PartBuilder filename(String paramString);
  
  PartBuilder header(String paramString, String... paramVarArgs);
  
  PartBuilder headers(Consumer<HttpHeaders> paramConsumer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\client\MultipartBodyBuilder$PartBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */