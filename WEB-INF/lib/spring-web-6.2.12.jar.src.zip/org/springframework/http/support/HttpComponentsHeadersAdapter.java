/*     */ package org.springframework.http.support;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.hc.core5.http.Header;
/*     */ import org.apache.hc.core5.http.HttpMessage;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpComponentsHeadersAdapter
/*     */   implements MultiValueMap<String, String>
/*     */ {
/*     */   private final HttpMessage message;
/*     */   private final Set<String> headerNames;
/*     */   
/*     */   public HttpComponentsHeadersAdapter(HttpMessage message) {
/*  58 */     Assert.notNull(message, "Message must not be null");
/*  59 */     this.message = message;
/*  60 */     this.headerNames = Collections.newSetFromMap((Map<String, Boolean>)new LinkedCaseInsensitiveMap((message
/*  61 */           .getHeaders()).length, Locale.ROOT));
/*  62 */     for (Header header : message.getHeaders()) {
/*  63 */       this.headerNames.add(header.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getFirst(String key) {
/*  71 */     Header header = this.message.getFirstHeader(key);
/*  72 */     return (header != null) ? header.getValue() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String key, @Nullable String value) {
/*  77 */     this.headerNames.add(key);
/*  78 */     this.message.addHeader(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(String key, List<? extends String> values) {
/*  83 */     values.forEach(value -> add(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(MultiValueMap<String, String> values) {
/*  88 */     values.forEach(this::addAll);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String key, @Nullable String value) {
/*  93 */     this.headerNames.add(key);
/*  94 */     this.message.setHeader(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Map<String, String> values) {
/*  99 */     values.forEach(this::set);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toSingleValueMap() {
/* 104 */     LinkedCaseInsensitiveMap linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap((this.message.getHeaders()).length, Locale.ROOT);
/* 105 */     this.message.headerIterator().forEachRemaining(h -> map.putIfAbsent(h.getName(), h.getValue()));
/* 106 */     return (Map<String, String>)linkedCaseInsensitiveMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 111 */     return this.headerNames.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 116 */     return ((this.message.getHeaders()).length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 121 */     if (key instanceof String) { String headerName = (String)key; if (this.message.containsHeader(headerName)); }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 126 */     return (value instanceof String && 
/* 127 */       Arrays.<Header>stream(this.message.getHeaders()).anyMatch(h -> h.getValue().equals(value)));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> get(Object key) {
/* 133 */     List<String> values = null;
/* 134 */     if (containsKey(key)) {
/* 135 */       Header[] headers = this.message.getHeaders((String)key);
/* 136 */       values = new ArrayList<>(headers.length);
/* 137 */       for (Header header : headers) {
/* 138 */         values.add(header.getValue());
/*     */       }
/*     */     } 
/* 141 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> put(String key, List<String> values) {
/* 147 */     List<String> oldValues = remove(key);
/* 148 */     values.forEach(value -> add(key, value));
/* 149 */     return oldValues;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> remove(Object key) {
/* 155 */     if (key instanceof String) { String headerName = (String)key;
/* 156 */       List<String> oldValues = get(key);
/* 157 */       this.headerNames.remove(headerName);
/* 158 */       this.message.removeHeaders(headerName);
/* 159 */       return oldValues; }
/*     */     
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map) {
/* 166 */     map.forEach(this::put);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 171 */     this.headerNames.clear();
/* 172 */     this.message.setHeaders(new Header[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 177 */     return new HeaderNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<List<String>> values() {
/* 182 */     Collection<List<String>> values = new ArrayList<>((this.message.getHeaders()).length);
/* 183 */     for (String headerName : keySet()) {
/* 184 */       values.add(get(headerName));
/*     */     }
/* 186 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 191 */     return new AbstractSet<Map.Entry<String, List<String>>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, List<String>>> iterator() {
/* 194 */           return new HttpComponentsHeadersAdapter.EntryIterator();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 199 */           return HttpComponentsHeadersAdapter.this.size();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 207 */     return HttpHeaders.formatHeaders(this);
/*     */   }
/*     */   
/*     */   private class HeaderNames
/*     */     extends AbstractSet<String>
/*     */   {
/*     */     public Iterator<String> iterator() {
/* 214 */       return new HttpComponentsHeadersAdapter.HeaderNamesIterator(HttpComponentsHeadersAdapter.this.headerNames.iterator());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 219 */       return HttpComponentsHeadersAdapter.this.headerNames.size();
/*     */     }
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<String, List<String>>> {
/* 225 */     private final Iterator<String> iterator = HttpComponentsHeadersAdapter.this.keySet().iterator();
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 229 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, List<String>> next() {
/* 234 */       return new HttpComponentsHeadersAdapter.HeaderEntry(this.iterator.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private class HeaderEntry
/*     */     implements Map.Entry<String, List<String>>
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     HeaderEntry(String key) {
/* 244 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 249 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getValue() {
/* 254 */       List<String> values = HttpComponentsHeadersAdapter.this.get(this.key);
/* 255 */       return (values != null) ? values : Collections.<String>emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> setValue(List<String> value) {
/* 260 */       List<String> previousValues = getValue();
/* 261 */       HttpComponentsHeadersAdapter.this.put(this.key, value);
/* 262 */       return previousValues;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class HeaderNamesIterator
/*     */     implements Iterator<String>
/*     */   {
/*     */     private final Iterator<String> iterator;
/*     */     @Nullable
/*     */     private String currentName;
/*     */     
/*     */     private HeaderNamesIterator(Iterator<String> iterator) {
/* 274 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 279 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 284 */       this.currentName = this.iterator.next();
/* 285 */       return this.currentName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 290 */       if (this.currentName == null) {
/* 291 */         throw new IllegalStateException("No current Header in iterator");
/*     */       }
/* 293 */       if (!HttpComponentsHeadersAdapter.this.message.containsHeader(this.currentName)) {
/* 294 */         throw new IllegalStateException("Header not present: " + this.currentName);
/*     */       }
/* 296 */       HttpComponentsHeadersAdapter.this.headerNames.remove(this.currentName);
/* 297 */       HttpComponentsHeadersAdapter.this.message.removeHeaders(this.currentName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\support\HttpComponentsHeadersAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */