/*     */ package org.springframework.http.support;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jetty.http.HttpField;
/*     */ import org.eclipse.jetty.http.HttpFields;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JettyHeadersAdapter
/*     */   implements MultiValueMap<String, String>
/*     */ {
/*     */   private final HttpFields headers;
/*     */   @Nullable
/*     */   private final HttpFields.Mutable mutable;
/*     */   
/*     */   public JettyHeadersAdapter(HttpFields headers) {
/*  61 */     Assert.notNull(headers, "Headers must not be null");
/*  62 */     this.headers = headers;
/*  63 */     HttpFields.Mutable m = (HttpFields.Mutable)headers; this.mutable = (headers instanceof HttpFields.Mutable) ? m : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirst(String key) {
/*  69 */     return this.headers.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String key, @Nullable String value) {
/*  74 */     if (value != null) {
/*  75 */       HttpFields.Mutable mutableHttpFields = mutableFields();
/*  76 */       mutableHttpFields.add(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(String key, List<? extends String> values) {
/*  82 */     values.forEach(value -> add(key, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(MultiValueMap<String, String> values) {
/*  87 */     values.forEach(this::addAll);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String key, @Nullable String value) {
/*  92 */     HttpFields.Mutable mutableHttpFields = mutableFields();
/*  93 */     if (value != null) {
/*  94 */       mutableHttpFields.put(key, value);
/*     */     } else {
/*     */       
/*  97 */       mutableHttpFields.remove(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Map<String, String> values) {
/* 103 */     values.forEach(this::set);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> toSingleValueMap() {
/* 109 */     LinkedCaseInsensitiveMap linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap(this.headers.size(), Locale.ROOT);
/* 110 */     Iterator<HttpField> iterator = this.headers.iterator();
/* 111 */     iterator.forEachRemaining(field -> {
/*     */           if (!singleValueMap.containsKey(field.getName())) {
/*     */             singleValueMap.put(field.getName(), field.getValue());
/*     */           }
/*     */         });
/* 116 */     return (Map<String, String>)linkedCaseInsensitiveMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 121 */     return this.headers.getFieldNamesCollection().size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 126 */     return (this.headers.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 131 */     if (key instanceof String) { String name = (String)key; if (this.headers.contains(name)); }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 136 */     if (value instanceof String) { String searchString = (String)value;
/* 137 */       for (HttpField field : this.headers) {
/* 138 */         if (field.contains(searchString)) {
/* 139 */           return true;
/*     */         }
/*     */       }  }
/*     */     
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> get(Object key) {
/* 149 */     List<String> list = null;
/* 150 */     if (key instanceof String) { String name = (String)key;
/* 151 */       for (HttpField f : this.headers) {
/* 152 */         if (f.is(name)) {
/* 153 */           if (list == null) {
/* 154 */             list = new ArrayList<>();
/*     */           }
/* 156 */           list.add(f.getValue());
/*     */         } 
/*     */       }  }
/*     */     
/* 160 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> put(String key, List<String> value) {
/* 166 */     HttpFields.Mutable mutableHttpFields = mutableFields();
/* 167 */     List<String> oldValues = get(key);
/*     */     
/* 169 */     if (oldValues == null)
/* 170 */     { switch (value.size())
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 0:
/* 183 */           return oldValues;
/*     */         case 1:
/*     */           mutableHttpFields.add(key, value.get(0)); }  mutableHttpFields.add(key, value); }  switch (value.size()) { case 0:
/*     */         mutableHttpFields.remove(key);
/*     */       case 1:
/*     */         mutableHttpFields.put(key, value.get(0)); }
/* 189 */      mutableHttpFields.put(key, value); } @Nullable public List<String> remove(Object key) { HttpFields.Mutable mutableHttpFields = mutableFields();
/* 190 */     List<String> list = null;
/* 191 */     if (key instanceof String) { String name = (String)key;
/* 192 */       for (ListIterator<HttpField> i = mutableHttpFields.listIterator(); i.hasNext(); ) {
/* 193 */         HttpField f = i.next();
/* 194 */         if (f.is(name)) {
/* 195 */           if (list == null) {
/* 196 */             list = new ArrayList<>();
/*     */           }
/* 198 */           list.add(f.getValue());
/* 199 */           i.remove();
/*     */         } 
/*     */       }  }
/*     */     
/* 203 */     return list; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map) {
/* 208 */     map.forEach(this::put);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 213 */     HttpFields.Mutable mutableHttpFields = mutableFields();
/* 214 */     mutableHttpFields.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 219 */     return new HeaderNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<List<String>> values() {
/* 225 */     Objects.requireNonNull(this.headers); return this.headers.getFieldNamesCollection().stream().map(this.headers::getValuesList).toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 230 */     return new AbstractSet<Map.Entry<String, List<String>>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, List<String>>> iterator() {
/* 233 */           return new JettyHeadersAdapter.EntryIterator();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 238 */           return JettyHeadersAdapter.this.headers.getFieldNamesCollection().size();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private HttpFields.Mutable mutableFields() {
/* 244 */     if (this.mutable == null) {
/* 245 */       throw new IllegalStateException("Immutable headers");
/*     */     }
/* 247 */     return this.mutable;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 252 */     return HttpHeaders.formatHeaders(this);
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<String, List<String>>>
/*     */   {
/* 258 */     private final Iterator<String> names = JettyHeadersAdapter.this.headers.getFieldNamesCollection().iterator();
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 262 */       return this.names.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, List<String>> next() {
/* 267 */       return new JettyHeadersAdapter.HeaderEntry(this.names.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private class HeaderEntry
/*     */     implements Map.Entry<String, List<String>>
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     HeaderEntry(String key) {
/* 277 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 282 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getValue() {
/* 287 */       return JettyHeadersAdapter.this.headers.getValuesList(this.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> setValue(List<String> value) {
/* 292 */       HttpFields.Mutable mutableHttpFields = JettyHeadersAdapter.this.mutableFields();
/* 293 */       List<String> previousValues = JettyHeadersAdapter.this.headers.getValuesList(this.key);
/* 294 */       mutableHttpFields.put(this.key, value);
/* 295 */       return previousValues;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class HeaderNames
/*     */     extends AbstractSet<String>
/*     */   {
/*     */     public Iterator<String> iterator() {
/* 304 */       return new JettyHeadersAdapter.HeaderNamesIterator(JettyHeadersAdapter.this.headers.getFieldNamesCollection().iterator());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 309 */       return JettyHeadersAdapter.this.headers.getFieldNamesCollection().size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class HeaderNamesIterator
/*     */     implements Iterator<String>
/*     */   {
/*     */     private final Iterator<String> iterator;
/*     */     @Nullable
/*     */     private String currentName;
/*     */     
/*     */     private HeaderNamesIterator(Iterator<String> iterator) {
/* 322 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 327 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 332 */       this.currentName = this.iterator.next();
/* 333 */       return this.currentName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 338 */       HttpFields.Mutable mutableHttpFields = JettyHeadersAdapter.this.mutableFields();
/* 339 */       if (this.currentName == null) {
/* 340 */         throw new IllegalStateException("No current Header in iterator");
/*     */       }
/* 342 */       if (!JettyHeadersAdapter.this.headers.contains(this.currentName)) {
/* 343 */         throw new IllegalStateException("Header not present: " + this.currentName);
/*     */       }
/* 345 */       mutableHttpFields.remove(this.currentName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\support\JettyHeadersAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */