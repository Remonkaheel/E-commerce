/*     */ package org.springframework.http.support;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Netty4HeadersAdapter
/*     */   implements MultiValueMap<String, String>
/*     */ {
/*     */   private final HttpHeaders headers;
/*     */   
/*     */   public Netty4HeadersAdapter(HttpHeaders headers) {
/*  52 */     Assert.notNull(headers, "Headers must not be null");
/*  53 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getFirst(String key) {
/*  60 */     return this.headers.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String key, @Nullable String value) {
/*  65 */     if (value != null) {
/*  66 */       this.headers.add(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(String key, List<? extends String> values) {
/*  72 */     this.headers.add(key, values);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAll(MultiValueMap<String, String> values) {
/*  77 */     Objects.requireNonNull(this.headers); values.forEach(this.headers::add);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String key, @Nullable String value) {
/*  82 */     if (value != null) {
/*  83 */       this.headers.set(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Map<String, String> values) {
/*  89 */     Objects.requireNonNull(this.headers); values.forEach(this.headers::set);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> toSingleValueMap() {
/*  95 */     LinkedCaseInsensitiveMap linkedCaseInsensitiveMap = new LinkedCaseInsensitiveMap(this.headers.size(), Locale.ROOT);
/*  96 */     this.headers.entries()
/*  97 */       .forEach(entry -> {
/*     */           if (!singleValueMap.containsKey(entry.getKey())) {
/*     */             singleValueMap.put((String)entry.getKey(), (String)entry.getValue());
/*     */           }
/*     */         });
/* 102 */     return (Map<String, String>)linkedCaseInsensitiveMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 107 */     return this.headers.names().size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 112 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 117 */     if (key instanceof String) { String headerName = (String)key; if (this.headers.contains(headerName)); }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 122 */     return (value instanceof String && this.headers
/* 123 */       .entries().stream()
/* 124 */       .anyMatch(entry -> value.equals(entry.getValue())));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> get(Object key) {
/* 130 */     if (containsKey(key)) {
/* 131 */       return this.headers.getAll((String)key);
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> put(String key, @Nullable List<String> value) {
/* 139 */     List<String> previousValues = this.headers.getAll(key);
/* 140 */     this.headers.set(key, value);
/* 141 */     return previousValues;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List<String> remove(Object key) {
/* 147 */     if (key instanceof String) { String headerName = (String)key;
/* 148 */       List<String> previousValues = this.headers.getAll(headerName);
/* 149 */       this.headers.remove(headerName);
/* 150 */       return previousValues; }
/*     */     
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends List<String>> map) {
/* 157 */     Objects.requireNonNull(this.headers); map.forEach(this.headers::set);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 162 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 167 */     return new HeaderNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<List<String>> values() {
/* 173 */     Objects.requireNonNull(this.headers); return this.headers.names().stream().map(this.headers::getAll).toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 178 */     return new AbstractSet<Map.Entry<String, List<String>>>()
/*     */       {
/*     */         public Iterator<Map.Entry<String, List<String>>> iterator() {
/* 181 */           return new Netty4HeadersAdapter.EntryIterator();
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 186 */           return Netty4HeadersAdapter.this.headers.size();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 194 */     return HttpHeaders.formatHeaders(this);
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     implements Iterator<Map.Entry<String, List<String>>>
/*     */   {
/* 200 */     private final Iterator<String> names = Netty4HeadersAdapter.this.headers.names().iterator();
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 204 */       return this.names.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, List<String>> next() {
/* 209 */       return new Netty4HeadersAdapter.HeaderEntry(this.names.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private class HeaderEntry
/*     */     implements Map.Entry<String, List<String>>
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     HeaderEntry(String key) {
/* 219 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 224 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getValue() {
/* 229 */       return Netty4HeadersAdapter.this.headers.getAll(this.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> setValue(List<String> value) {
/* 234 */       List<String> previousValues = Netty4HeadersAdapter.this.headers.getAll(this.key);
/* 235 */       Netty4HeadersAdapter.this.headers.set(this.key, value);
/* 236 */       return previousValues;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class HeaderNames
/*     */     extends AbstractSet<String>
/*     */   {
/*     */     public Iterator<String> iterator() {
/* 245 */       return new Netty4HeadersAdapter.HeaderNamesIterator(Netty4HeadersAdapter.this.headers.names().iterator());
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 250 */       return Netty4HeadersAdapter.this.headers.names().size();
/*     */     }
/*     */   }
/*     */   
/*     */   private final class HeaderNamesIterator
/*     */     implements Iterator<String>
/*     */   {
/*     */     private final Iterator<String> iterator;
/*     */     @Nullable
/*     */     private String currentName;
/*     */     
/*     */     private HeaderNamesIterator(Iterator<String> iterator) {
/* 262 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 267 */       return this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() {
/* 272 */       this.currentName = this.iterator.next();
/* 273 */       return this.currentName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 278 */       if (this.currentName == null) {
/* 279 */         throw new IllegalStateException("No current Header in iterator");
/*     */       }
/* 281 */       if (!Netty4HeadersAdapter.this.headers.contains(this.currentName)) {
/* 282 */         throw new IllegalStateException("Header not present: " + this.currentName);
/*     */       }
/* 284 */       Netty4HeadersAdapter.this.headers.remove(this.currentName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-web-6.2.12.jar!\org\springframework\http\support\Netty4HeadersAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */