package org.springframework.transaction;

public interface ReactiveTransaction extends TransactionExecution {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\ReactiveTransaction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */