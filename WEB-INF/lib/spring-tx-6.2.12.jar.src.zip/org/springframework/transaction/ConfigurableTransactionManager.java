/*    */ package org.springframework.transaction;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ConfigurableTransactionManager
/*    */   extends TransactionManager
/*    */ {
/*    */   void setTransactionExecutionListeners(Collection<TransactionExecutionListener> paramCollection);
/*    */   
/*    */   Collection<TransactionExecutionListener> getTransactionExecutionListeners();
/*    */   
/*    */   default void addListener(TransactionExecutionListener listener) {
/* 51 */     getTransactionExecutionListeners().add(listener);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\ConfigurableTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */