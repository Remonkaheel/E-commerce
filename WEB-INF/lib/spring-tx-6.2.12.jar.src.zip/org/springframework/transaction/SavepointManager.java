package org.springframework.transaction;

public interface SavepointManager {
  Object createSavepoint() throws TransactionException;
  
  void rollbackToSavepoint(Object paramObject) throws TransactionException;
  
  void releaseSavepoint(Object paramObject) throws TransactionException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\SavepointManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */