/*    */ package org.springframework.transaction.event;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.EventListenerFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionalEventListenerFactory
/*    */   implements EventListenerFactory, Ordered
/*    */ {
/* 36 */   private int order = 50;
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 40 */     this.order = order;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 45 */     return this.order;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supportsMethod(Method method) {
/* 51 */     return AnnotatedElementUtils.hasAnnotation(method, TransactionalEventListener.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public ApplicationListener<?> createApplicationListener(String beanName, Class<?> type, Method method) {
/* 56 */     return new TransactionalApplicationListenerMethodAdapter(beanName, type, method);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalEventListenerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */