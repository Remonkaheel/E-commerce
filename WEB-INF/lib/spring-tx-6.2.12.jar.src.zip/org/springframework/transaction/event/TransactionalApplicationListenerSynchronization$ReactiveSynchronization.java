/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.transaction.reactive.TransactionSynchronization;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReactiveSynchronization<AE extends ApplicationEvent>
/*     */   extends TransactionalApplicationListenerSynchronization<AE>
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   public ReactiveSynchronization(AE event, TransactionalApplicationListener<AE> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/* 137 */     super(event, listener, callbacks);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> beforeCommit(boolean readOnly) {
/* 142 */     if (getTransactionPhase() == TransactionPhase.BEFORE_COMMIT) {
/* 143 */       return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */     }
/* 145 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> afterCompletion(int status) {
/* 150 */     TransactionPhase phase = getTransactionPhase();
/* 151 */     if (phase == TransactionPhase.AFTER_COMMIT && status == 0) {
/* 152 */       return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */     }
/* 154 */     if (phase == TransactionPhase.AFTER_ROLLBACK && status == 1) {
/* 155 */       return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */     }
/* 157 */     if (phase == TransactionPhase.AFTER_COMPLETION) {
/* 158 */       return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */     }
/* 160 */     return Mono.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListenerSynchronization$ReactiveSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */