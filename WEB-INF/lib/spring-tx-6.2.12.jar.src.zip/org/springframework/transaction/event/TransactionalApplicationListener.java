/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.PayloadApplicationEvent;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TransactionalApplicationListener<E extends ApplicationEvent>
/*     */   extends ApplicationListener<E>, Ordered
/*     */ {
/*     */   default int getOrder() {
/*  61 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean supportsAsyncExecution() {
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getListenerId() {
/*  84 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default TransactionPhase getTransactionPhase() {
/*  92 */     return TransactionPhase.AFTER_COMMIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addCallback(SynchronizationCallback paramSynchronizationCallback);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processEvent(E paramE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> TransactionalApplicationListener<PayloadApplicationEvent<T>> forPayload(Consumer<T> consumer) {
/* 122 */     return forPayload(TransactionPhase.AFTER_COMMIT, consumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> TransactionalApplicationListener<PayloadApplicationEvent<T>> forPayload(TransactionPhase phase, Consumer<T> consumer) {
/* 137 */     TransactionalApplicationListenerAdapter<PayloadApplicationEvent<T>> listener = new TransactionalApplicationListenerAdapter<>(event -> consumer.accept(event.getPayload()));
/*     */     
/* 139 */     listener.setTransactionPhase(phase);
/* 140 */     return listener;
/*     */   }
/*     */   
/*     */   public static interface SynchronizationCallback {
/*     */     default void preProcessEvent(ApplicationEvent event) {}
/*     */     
/*     */     default void postProcessEvent(ApplicationEvent event, @Nullable Throwable ex) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */