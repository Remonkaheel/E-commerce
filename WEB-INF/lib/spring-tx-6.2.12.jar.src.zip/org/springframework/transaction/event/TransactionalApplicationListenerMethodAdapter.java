/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.event.ApplicationListenerMethodAdapter;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionalApplicationListenerMethodAdapter
/*     */   extends ApplicationListenerMethodAdapter
/*     */   implements TransactionalApplicationListener<ApplicationEvent>
/*     */ {
/*     */   private final TransactionPhase transactionPhase;
/*  52 */   private final List<TransactionalApplicationListener.SynchronizationCallback> callbacks = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionalApplicationListenerMethodAdapter(String beanName, Class<?> targetClass, Method method) {
/*  62 */     super(beanName, targetClass, method);
/*     */     
/*  64 */     TransactionalEventListener eventAnn = (TransactionalEventListener)AnnotatedElementUtils.findMergedAnnotation(getTargetMethod(), TransactionalEventListener.class);
/*  65 */     if (eventAnn == null) {
/*  66 */       throw new IllegalStateException("No TransactionalEventListener annotation found on method: " + String.valueOf(method));
/*     */     }
/*  68 */     this.transactionPhase = eventAnn.phase();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionPhase getTransactionPhase() {
/*  74 */     return this.transactionPhase;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCallback(TransactionalApplicationListener.SynchronizationCallback callback) {
/*  79 */     Assert.notNull(callback, "SynchronizationCallback must not be null");
/*  80 */     this.callbacks.add(callback);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(ApplicationEvent event) {
/*  86 */     if (TransactionalApplicationListenerSynchronization.register(event, this, this.callbacks)) {
/*  87 */       if (this.logger.isDebugEnabled()) {
/*  88 */         this.logger.debug("Registered transaction synchronization for " + String.valueOf(event));
/*     */       }
/*     */     }
/*  91 */     else if (isDefaultExecution()) {
/*  92 */       if (getTransactionPhase() == TransactionPhase.AFTER_ROLLBACK && this.logger.isWarnEnabled()) {
/*  93 */         this.logger.warn("Processing " + String.valueOf(event) + " as a fallback execution on AFTER_ROLLBACK phase");
/*     */       }
/*  95 */       processEvent(event);
/*     */ 
/*     */     
/*     */     }
/*  99 */     else if (this.logger.isDebugEnabled()) {
/* 100 */       this.logger.debug("No transaction is active - skipping " + String.valueOf(event));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListenerMethodAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */