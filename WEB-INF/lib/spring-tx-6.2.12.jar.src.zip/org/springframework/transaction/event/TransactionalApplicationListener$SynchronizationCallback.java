package org.springframework.transaction.event;

import org.springframework.context.ApplicationEvent;
import org.springframework.lang.Nullable;

public interface SynchronizationCallback {
  default void preProcessEvent(ApplicationEvent event) {}
  
  default void postProcessEvent(ApplicationEvent event, @Nullable Throwable ex) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListener$SynchronizationCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */