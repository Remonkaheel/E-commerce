package org.springframework.transaction.event;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.AliasFor;

@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@EventListener
public @interface TransactionalEventListener {
  TransactionPhase phase() default TransactionPhase.AFTER_COMMIT;
  
  @AliasFor(annotation = EventListener.class, attribute = "classes")
  Class<?>[] value() default {};
  
  @AliasFor(annotation = EventListener.class, attribute = "classes")
  Class<?>[] classes() default {};
  
  @AliasFor(annotation = EventListener.class, attribute = "condition")
  String condition() default "";
  
  @AliasFor(annotation = EventListener.class, attribute = "defaultExecution")
  boolean fallbackExecution() default false;
  
  @AliasFor(annotation = EventListener.class, attribute = "id")
  String id() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalEventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */