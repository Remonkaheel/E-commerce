/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionalApplicationListenerAdapter<E extends ApplicationEvent>
/*     */   implements TransactionalApplicationListener<E>, Ordered
/*     */ {
/*     */   private final ApplicationListener<E> targetListener;
/*  49 */   private int order = Integer.MAX_VALUE;
/*     */   
/*  51 */   private TransactionPhase transactionPhase = TransactionPhase.AFTER_COMMIT;
/*     */   
/*  53 */   private String listenerId = "";
/*     */   
/*  55 */   private final List<TransactionalApplicationListener.SynchronizationCallback> callbacks = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionalApplicationListenerAdapter(ApplicationListener<E> targetListener) {
/*  65 */     this.targetListener = targetListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int order) {
/*  73 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  81 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionPhase(TransactionPhase transactionPhase) {
/*  89 */     this.transactionPhase = transactionPhase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionPhase getTransactionPhase() {
/*  97 */     return this.transactionPhase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListenerId(String listenerId) {
/* 105 */     this.listenerId = listenerId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getListenerId() {
/* 113 */     return this.listenerId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCallback(TransactionalApplicationListener.SynchronizationCallback callback) {
/* 118 */     Assert.notNull(callback, "SynchronizationCallback must not be null");
/* 119 */     this.callbacks.add(callback);
/*     */   }
/*     */ 
/*     */   
/*     */   public void processEvent(E event) {
/* 124 */     this.targetListener.onApplicationEvent((ApplicationEvent)event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(E event) {
/* 130 */     TransactionalApplicationListenerSynchronization.register(event, this, this.callbacks);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListenerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */