/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PlatformSynchronization<AE extends ApplicationEvent>
/*     */   extends TransactionalApplicationListenerSynchronization<AE>
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   public PlatformSynchronization(AE event, TransactionalApplicationListener<AE> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/* 104 */     super(event, listener, callbacks);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCommit(boolean readOnly) {
/* 109 */     if (getTransactionPhase() == TransactionPhase.BEFORE_COMMIT) {
/* 110 */       processEventWithCallbacks();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterCompletion(int status) {
/* 116 */     TransactionPhase phase = getTransactionPhase();
/* 117 */     if (phase == TransactionPhase.AFTER_COMMIT && status == 0) {
/* 118 */       processEventWithCallbacks();
/*     */     }
/* 120 */     else if (phase == TransactionPhase.AFTER_ROLLBACK && status == 1) {
/* 121 */       processEventWithCallbacks();
/*     */     }
/* 123 */     else if (phase == TransactionPhase.AFTER_COMPLETION) {
/* 124 */       processEventWithCallbacks();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListenerSynchronization$PlatformSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */