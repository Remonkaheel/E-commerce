/*     */ package org.springframework.transaction.event;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.transaction.reactive.TransactionContext;
/*     */ import org.springframework.transaction.reactive.TransactionSynchronization;
/*     */ import org.springframework.transaction.reactive.TransactionSynchronizationManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TransactionalApplicationListenerSynchronization<E extends ApplicationEvent>
/*     */   implements Ordered
/*     */ {
/*     */   private final E event;
/*     */   private final TransactionalApplicationListener<E> listener;
/*     */   private final List<TransactionalApplicationListener.SynchronizationCallback> callbacks;
/*     */   
/*     */   public TransactionalApplicationListenerSynchronization(E event, TransactionalApplicationListener<E> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/*  47 */     this.event = event;
/*  48 */     this.listener = listener;
/*  49 */     this.callbacks = callbacks;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  55 */     return this.listener.getOrder();
/*     */   }
/*     */   
/*     */   public TransactionPhase getTransactionPhase() {
/*  59 */     return this.listener.getTransactionPhase();
/*     */   }
/*     */   
/*     */   public void processEventWithCallbacks() {
/*  63 */     this.callbacks.forEach(callback -> callback.preProcessEvent((ApplicationEvent)this.event));
/*     */     try {
/*  65 */       this.listener.processEvent(this.event);
/*     */     }
/*  67 */     catch (RuntimeException|Error ex) {
/*  68 */       this.callbacks.forEach(callback -> callback.postProcessEvent((ApplicationEvent)this.event, ex));
/*  69 */       throw ex;
/*     */     } 
/*  71 */     this.callbacks.forEach(callback -> callback.postProcessEvent((ApplicationEvent)this.event, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends ApplicationEvent> boolean register(E event, TransactionalApplicationListener<E> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/*  79 */     if (TransactionSynchronizationManager.isSynchronizationActive() && 
/*  80 */       TransactionSynchronizationManager.isActualTransactionActive()) {
/*  81 */       TransactionSynchronizationManager.registerSynchronization(new PlatformSynchronization<>(event, listener, callbacks));
/*     */       
/*  83 */       return true;
/*     */     } 
/*  85 */     Object object = event.getSource(); if (object instanceof TransactionContext) { TransactionContext txContext = (TransactionContext)object;
/*  86 */       TransactionSynchronizationManager rtsm = new TransactionSynchronizationManager(txContext);
/*     */       
/*  88 */       if (rtsm.isSynchronizationActive() && rtsm.isActualTransactionActive()) {
/*  89 */         rtsm.registerSynchronization(new ReactiveSynchronization<>(event, listener, callbacks));
/*  90 */         return true;
/*     */       }  }
/*     */     
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PlatformSynchronization<AE extends ApplicationEvent>
/*     */     extends TransactionalApplicationListenerSynchronization<AE>
/*     */     implements TransactionSynchronization
/*     */   {
/*     */     public PlatformSynchronization(AE event, TransactionalApplicationListener<AE> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/* 104 */       super(event, listener, callbacks);
/*     */     }
/*     */ 
/*     */     
/*     */     public void beforeCommit(boolean readOnly) {
/* 109 */       if (getTransactionPhase() == TransactionPhase.BEFORE_COMMIT) {
/* 110 */         processEventWithCallbacks();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterCompletion(int status) {
/* 116 */       TransactionPhase phase = getTransactionPhase();
/* 117 */       if (phase == TransactionPhase.AFTER_COMMIT && status == 0) {
/* 118 */         processEventWithCallbacks();
/*     */       }
/* 120 */       else if (phase == TransactionPhase.AFTER_ROLLBACK && status == 1) {
/* 121 */         processEventWithCallbacks();
/*     */       }
/* 123 */       else if (phase == TransactionPhase.AFTER_COMPLETION) {
/* 124 */         processEventWithCallbacks();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ReactiveSynchronization<AE extends ApplicationEvent>
/*     */     extends TransactionalApplicationListenerSynchronization<AE>
/*     */     implements TransactionSynchronization
/*     */   {
/*     */     public ReactiveSynchronization(AE event, TransactionalApplicationListener<AE> listener, List<TransactionalApplicationListener.SynchronizationCallback> callbacks) {
/* 137 */       super(event, listener, callbacks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> beforeCommit(boolean readOnly) {
/* 142 */       if (getTransactionPhase() == TransactionPhase.BEFORE_COMMIT) {
/* 143 */         return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */       }
/* 145 */       return Mono.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> afterCompletion(int status) {
/* 150 */       TransactionPhase phase = getTransactionPhase();
/* 151 */       if (phase == TransactionPhase.AFTER_COMMIT && status == 0) {
/* 152 */         return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */       }
/* 154 */       if (phase == TransactionPhase.AFTER_ROLLBACK && status == 1) {
/* 155 */         return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */       }
/* 157 */       if (phase == TransactionPhase.AFTER_COMPLETION) {
/* 158 */         return Mono.fromRunnable(this::processEventWithCallbacks);
/*     */       }
/* 160 */       return Mono.empty();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\event\TransactionalApplicationListenerSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */