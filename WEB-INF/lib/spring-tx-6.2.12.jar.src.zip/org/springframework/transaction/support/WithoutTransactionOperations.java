/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionException;
/*    */ import org.springframework.transaction.TransactionStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WithoutTransactionOperations
/*    */   implements TransactionOperations
/*    */ {
/* 35 */   static final WithoutTransactionOperations INSTANCE = new WithoutTransactionOperations();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T execute(TransactionCallback<T> action) throws TransactionException {
/* 45 */     return action.doInTransaction(new SimpleTransactionStatus(false));
/*    */   }
/*    */ 
/*    */   
/*    */   public void executeWithoutResult(Consumer<TransactionStatus> action) throws TransactionException {
/* 50 */     action.accept(new SimpleTransactionStatus(false));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\WithoutTransactionOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */