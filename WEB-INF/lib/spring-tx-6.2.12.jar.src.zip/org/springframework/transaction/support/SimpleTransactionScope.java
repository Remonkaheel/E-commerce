/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.Scope;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleTransactionScope
/*     */   implements Scope
/*     */ {
/*     */   public Object get(String name, ObjectFactory<?> objectFactory) {
/*  47 */     ScopedObjectsHolder scopedObjects = (ScopedObjectsHolder)TransactionSynchronizationManager.getResource(this);
/*  48 */     if (scopedObjects == null) {
/*  49 */       scopedObjects = new ScopedObjectsHolder();
/*  50 */       TransactionSynchronizationManager.registerSynchronization(new CleanupSynchronization(scopedObjects));
/*  51 */       TransactionSynchronizationManager.bindResource(this, scopedObjects);
/*     */     } 
/*     */ 
/*     */     
/*  55 */     Object scopedObject = scopedObjects.scopedInstances.get(name);
/*  56 */     if (scopedObject == null) {
/*  57 */       scopedObject = objectFactory.getObject();
/*  58 */       scopedObjects.scopedInstances.put(name, scopedObject);
/*     */     } 
/*  60 */     return scopedObject;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object remove(String name) {
/*  66 */     ScopedObjectsHolder scopedObjects = (ScopedObjectsHolder)TransactionSynchronizationManager.getResource(this);
/*  67 */     if (scopedObjects != null) {
/*  68 */       scopedObjects.destructionCallbacks.remove(name);
/*  69 */       return scopedObjects.scopedInstances.remove(name);
/*     */     } 
/*     */     
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDestructionCallback(String name, Runnable callback) {
/*  78 */     ScopedObjectsHolder scopedObjects = (ScopedObjectsHolder)TransactionSynchronizationManager.getResource(this);
/*  79 */     if (scopedObjects != null) {
/*  80 */       scopedObjects.destructionCallbacks.put(name, callback);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveContextualObject(String key) {
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getConversationId() {
/*  93 */     return TransactionSynchronizationManager.getCurrentTransactionName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ScopedObjectsHolder
/*     */   {
/* 102 */     final Map<String, Object> scopedInstances = new HashMap<>();
/*     */     
/* 104 */     final Map<String, Runnable> destructionCallbacks = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   private class CleanupSynchronization
/*     */     implements TransactionSynchronization
/*     */   {
/*     */     private final SimpleTransactionScope.ScopedObjectsHolder scopedObjects;
/*     */     
/*     */     public CleanupSynchronization(SimpleTransactionScope.ScopedObjectsHolder scopedObjects) {
/* 113 */       this.scopedObjects = scopedObjects;
/*     */     }
/*     */ 
/*     */     
/*     */     public void suspend() {
/* 118 */       TransactionSynchronizationManager.unbindResource(SimpleTransactionScope.this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void resume() {
/* 123 */       TransactionSynchronizationManager.bindResource(SimpleTransactionScope.this, this.scopedObjects);
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterCompletion(int status) {
/* 128 */       TransactionSynchronizationManager.unbindResourceIfPossible(SimpleTransactionScope.this);
/* 129 */       for (Runnable callback : this.scopedObjects.destructionCallbacks.values()) {
/* 130 */         callback.run();
/*     */       }
/* 132 */       this.scopedObjects.destructionCallbacks.clear();
/* 133 */       this.scopedObjects.scopedInstances.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\SimpleTransactionScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */