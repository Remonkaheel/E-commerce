/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceHolderSynchronization<H extends ResourceHolder, K>
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   private final H resourceHolder;
/*     */   private final K resourceKey;
/*     */   private volatile boolean holderActive = true;
/*     */   
/*     */   public ResourceHolderSynchronization(H resourceHolder, K resourceKey) {
/*  45 */     this.resourceHolder = resourceHolder;
/*  46 */     this.resourceKey = resourceKey;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void suspend() {
/*  52 */     if (this.holderActive) {
/*  53 */       TransactionSynchronizationManager.unbindResource(this.resourceKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void resume() {
/*  59 */     if (this.holderActive) {
/*  60 */       TransactionSynchronizationManager.bindResource(this.resourceKey, this.resourceHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/*  66 */     flushResource(this.resourceHolder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeCommit(boolean readOnly) {}
/*     */ 
/*     */   
/*     */   public void beforeCompletion() {
/*  75 */     if (shouldUnbindAtCompletion()) {
/*  76 */       TransactionSynchronizationManager.unbindResource(this.resourceKey);
/*  77 */       this.holderActive = false;
/*  78 */       if (shouldReleaseBeforeCompletion()) {
/*  79 */         releaseResource(this.resourceHolder, this.resourceKey);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterCommit() {
/*  86 */     if (!shouldReleaseBeforeCompletion()) {
/*  87 */       processResourceAfterCommit(this.resourceHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterCompletion(int status) {
/*  93 */     if (shouldUnbindAtCompletion()) {
/*  94 */       boolean releaseNecessary = false;
/*  95 */       if (this.holderActive) {
/*     */ 
/*     */         
/*  98 */         this.holderActive = false;
/*  99 */         TransactionSynchronizationManager.unbindResourceIfPossible(this.resourceKey);
/* 100 */         this.resourceHolder.unbound();
/* 101 */         releaseNecessary = true;
/*     */       } else {
/*     */         
/* 104 */         releaseNecessary = shouldReleaseAfterCompletion(this.resourceHolder);
/*     */       } 
/* 106 */       if (releaseNecessary) {
/* 107 */         releaseResource(this.resourceHolder, this.resourceKey);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 112 */       cleanupResource(this.resourceHolder, this.resourceKey, (status == 0));
/*     */     } 
/* 114 */     this.resourceHolder.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldUnbindAtCompletion() {
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldReleaseBeforeCompletion() {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldReleaseAfterCompletion(H resourceHolder) {
/* 148 */     return !shouldReleaseBeforeCompletion();
/*     */   }
/*     */   
/*     */   protected void flushResource(H resourceHolder) {}
/*     */   
/*     */   protected void processResourceAfterCommit(H resourceHolder) {}
/*     */   
/*     */   protected void releaseResource(H resourceHolder, K resourceKey) {}
/*     */   
/*     */   protected void cleanupResource(H resourceHolder, K resourceKey, boolean committed) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\ResourceHolderSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */