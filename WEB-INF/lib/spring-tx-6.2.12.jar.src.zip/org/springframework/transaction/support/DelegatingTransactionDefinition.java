/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionDefinition;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DelegatingTransactionDefinition
/*    */   implements TransactionDefinition, Serializable
/*    */ {
/*    */   private final TransactionDefinition targetDefinition;
/*    */   
/*    */   public DelegatingTransactionDefinition(TransactionDefinition targetDefinition) {
/* 45 */     Assert.notNull(targetDefinition, "Target definition must not be null");
/* 46 */     this.targetDefinition = targetDefinition;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPropagationBehavior() {
/* 52 */     return this.targetDefinition.getPropagationBehavior();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIsolationLevel() {
/* 57 */     return this.targetDefinition.getIsolationLevel();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getTimeout() {
/* 62 */     return this.targetDefinition.getTimeout();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isReadOnly() {
/* 67 */     return this.targetDefinition.isReadOnly();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getName() {
/* 73 */     return this.targetDefinition.getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 79 */     return this.targetDefinition.equals(other);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 84 */     return this.targetDefinition.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return this.targetDefinition.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\DelegatingTransactionDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */