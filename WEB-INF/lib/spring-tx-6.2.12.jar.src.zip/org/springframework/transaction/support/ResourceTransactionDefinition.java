package org.springframework.transaction.support;

import org.springframework.transaction.TransactionDefinition;

public interface ResourceTransactionDefinition extends TransactionDefinition {
  boolean isLocalResource();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\ResourceTransactionDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */