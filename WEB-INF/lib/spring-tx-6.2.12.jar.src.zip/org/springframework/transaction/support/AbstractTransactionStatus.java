/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.TransactionUsageException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTransactionStatus
/*     */   implements TransactionStatus
/*     */ {
/*     */   private boolean rollbackOnly = false;
/*     */   private boolean completed = false;
/*     */   @Nullable
/*     */   private Object savepoint;
/*     */   
/*     */   public void setRollbackOnly() {
/*  63 */     if (this.completed) {
/*  64 */       throw new IllegalStateException("Transaction completed");
/*     */     }
/*  66 */     this.rollbackOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRollbackOnly() {
/*  78 */     return (isLocalRollbackOnly() || isGlobalRollbackOnly());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocalRollbackOnly() {
/*  87 */     return this.rollbackOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGlobalRollbackOnly() {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompleted() {
/* 103 */     this.completed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompleted() {
/* 108 */     return this.completed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSavepoint() {
/* 118 */     return (this.savepoint != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSavepoint(@Nullable Object savepoint) {
/* 126 */     this.savepoint = savepoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getSavepoint() {
/* 134 */     return this.savepoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createAndHoldSavepoint() throws TransactionException {
/* 144 */     Object savepoint = getSavepointManager().createSavepoint();
/* 145 */     TransactionSynchronizationUtils.triggerSavepoint(savepoint);
/* 146 */     setSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollbackToHeldSavepoint() throws TransactionException {
/* 156 */     Object savepoint = getSavepoint();
/* 157 */     if (savepoint == null) {
/* 158 */       throw new TransactionUsageException("Cannot roll back to savepoint - no savepoint associated with current transaction");
/*     */     }
/*     */     
/* 161 */     TransactionSynchronizationUtils.triggerSavepointRollback(savepoint);
/* 162 */     getSavepointManager().rollbackToSavepoint(savepoint);
/* 163 */     getSavepointManager().releaseSavepoint(savepoint);
/* 164 */     setSavepoint(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseHeldSavepoint() throws TransactionException {
/* 172 */     Object savepoint = getSavepoint();
/* 173 */     if (savepoint == null) {
/* 174 */       throw new TransactionUsageException("Cannot release savepoint - no savepoint associated with current transaction");
/*     */     }
/*     */     
/* 177 */     getSavepointManager().releaseSavepoint(savepoint);
/* 178 */     setSavepoint(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createSavepoint() throws TransactionException {
/* 194 */     Object savepoint = getSavepointManager().createSavepoint();
/* 195 */     TransactionSynchronizationUtils.triggerSavepoint(savepoint);
/* 196 */     return savepoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollbackToSavepoint(Object savepoint) throws TransactionException {
/* 207 */     TransactionSynchronizationUtils.triggerSavepointRollback(savepoint);
/* 208 */     getSavepointManager().rollbackToSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(Object savepoint) throws TransactionException {
/* 219 */     getSavepointManager().releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SavepointManager getSavepointManager() {
/* 229 */     throw new NestedTransactionNotSupportedException("This transaction does not support savepoints");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\AbstractTransactionStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */