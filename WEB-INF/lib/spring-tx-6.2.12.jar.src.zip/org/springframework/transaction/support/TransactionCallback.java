package org.springframework.transaction.support;

import org.springframework.lang.Nullable;
import org.springframework.transaction.TransactionStatus;

@FunctionalInterface
public interface TransactionCallback<T> {
  @Nullable
  T doInTransaction(TransactionStatus paramTransactionStatus);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */