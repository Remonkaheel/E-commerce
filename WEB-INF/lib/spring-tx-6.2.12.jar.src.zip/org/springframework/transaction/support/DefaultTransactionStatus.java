/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTransactionStatus
/*     */   extends AbstractTransactionStatus
/*     */ {
/*     */   @Nullable
/*     */   private final String transactionName;
/*     */   @Nullable
/*     */   private final Object transaction;
/*     */   private final boolean newTransaction;
/*     */   private final boolean newSynchronization;
/*     */   private final boolean nested;
/*     */   private final boolean readOnly;
/*     */   private final boolean debug;
/*     */   @Nullable
/*     */   private final Object suspendedResources;
/*     */   
/*     */   public DefaultTransactionStatus(@Nullable String transactionName, @Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean nested, boolean readOnly, boolean debug, @Nullable Object suspendedResources) {
/*  95 */     this.transactionName = transactionName;
/*  96 */     this.transaction = transaction;
/*  97 */     this.newTransaction = newTransaction;
/*  98 */     this.newSynchronization = newSynchronization;
/*  99 */     this.nested = nested;
/* 100 */     this.readOnly = readOnly;
/* 101 */     this.debug = debug;
/* 102 */     this.suspendedResources = suspendedResources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public DefaultTransactionStatus(@Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean readOnly, boolean debug, @Nullable Object suspendedResources) {
/* 109 */     this(null, transaction, newTransaction, newSynchronization, false, readOnly, debug, suspendedResources);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransactionName() {
/* 115 */     return (this.transactionName != null) ? this.transactionName : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransaction() {
/* 123 */     Assert.state((this.transaction != null), "No transaction active");
/* 124 */     return this.transaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasTransaction() {
/* 129 */     return (this.transaction != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNewTransaction() {
/* 134 */     return (hasTransaction() && this.newTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNewSynchronization() {
/* 141 */     return this.newSynchronization;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 146 */     return this.nested;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 151 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebug() {
/* 160 */     return this.debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSuspendedResources() {
/* 169 */     return this.suspendedResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGlobalRollbackOnly() {
/* 186 */     Object object = this.transaction; if (object instanceof SmartTransactionObject) { SmartTransactionObject smartTransactionObject = (SmartTransactionObject)object; if (smartTransactionObject
/* 187 */         .isRollbackOnly()); }
/*     */     
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SavepointManager getSavepointManager() {
/*     */     SavepointManager savepointManager;
/* 198 */     Object transaction = this.transaction;
/* 199 */     if (transaction instanceof SavepointManager) { savepointManager = (SavepointManager)transaction; }
/* 200 */     else { throw new NestedTransactionNotSupportedException("Transaction object [" + String.valueOf(this.transaction) + "] does not support savepoints"); }
/*     */ 
/*     */     
/* 203 */     return savepointManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransactionSavepointManager() {
/* 213 */     return this.transaction instanceof SavepointManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 223 */     Object object = this.transaction; if (object instanceof SmartTransactionObject) { SmartTransactionObject smartTransactionObject = (SmartTransactionObject)object;
/* 224 */       smartTransactionObject.flush(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\DefaultTransactionStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */