/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTransactionStatus
/*    */   extends AbstractTransactionStatus
/*    */ {
/*    */   private final boolean newTransaction;
/*    */   
/*    */   public SimpleTransactionStatus() {
/* 45 */     this(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SimpleTransactionStatus(boolean newTransaction) {
/* 53 */     this.newTransaction = newTransaction;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isNewTransaction() {
/* 59 */     return this.newTransaction;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\SimpleTransactionStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */