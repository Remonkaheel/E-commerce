/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TransactionCallbackWithoutResult
/*    */   implements TransactionCallback<Object>
/*    */ {
/*    */   @Nullable
/*    */   public final Object doInTransaction(TransactionStatus status) {
/* 36 */     doInTransactionWithoutResult(status);
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract void doInTransactionWithoutResult(TransactionStatus paramTransactionStatus);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionCallbackWithoutResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */