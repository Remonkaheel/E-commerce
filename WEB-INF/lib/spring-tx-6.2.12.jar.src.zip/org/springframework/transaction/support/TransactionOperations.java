/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionException;
/*    */ import org.springframework.transaction.TransactionStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TransactionOperations
/*    */ {
/*    */   default void executeWithoutResult(Consumer<TransactionStatus> action) throws TransactionException {
/* 67 */     execute(status -> {
/*    */           action.accept(status);
/*    */           return null;
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TransactionOperations withoutTransaction() {
/* 89 */     return WithoutTransactionOperations.INSTANCE;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   <T> T execute(TransactionCallback<T> paramTransactionCallback) throws TransactionException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */