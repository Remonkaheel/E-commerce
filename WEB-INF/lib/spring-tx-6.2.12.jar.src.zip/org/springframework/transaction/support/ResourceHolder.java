package org.springframework.transaction.support;

public interface ResourceHolder {
  void reset();
  
  void unbound();
  
  boolean isVoid();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\ResourceHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */