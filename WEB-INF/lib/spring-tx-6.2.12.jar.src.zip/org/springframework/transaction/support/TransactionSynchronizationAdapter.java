/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "5.3")
/*    */ public abstract class TransactionSynchronizationAdapter
/*    */   implements TransactionSynchronization, Ordered
/*    */ {
/*    */   public int getOrder() {
/* 40 */     return Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   public void suspend() {}
/*    */   
/*    */   public void resume() {}
/*    */   
/*    */   public void flush() {}
/*    */   
/*    */   public void beforeCommit(boolean readOnly) {}
/*    */   
/*    */   public void beforeCompletion() {}
/*    */   
/*    */   public void afterCommit() {}
/*    */   
/*    */   public void afterCompletion(int status) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionSynchronizationAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */