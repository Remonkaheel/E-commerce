/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedObject;
/*     */ import org.springframework.core.InfrastructureProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransactionSynchronizationUtils
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationUtils.class);
/*     */   
/*  43 */   private static final boolean aopPresent = ClassUtils.isPresent("org.springframework.aop.scope.ScopedObject", TransactionSynchronizationUtils.class
/*  44 */       .getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean sameResourceFactory(ResourceTransactionManager tm, Object resourceFactory) {
/*  54 */     return unwrapResourceIfNecessary(tm.getResourceFactory()).equals(unwrapResourceIfNecessary(resourceFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object unwrapResourceIfNecessary(Object resource) {
/*  64 */     Assert.notNull(resource, "Resource must not be null");
/*  65 */     Object resourceRef = resource;
/*     */     
/*  67 */     if (resourceRef instanceof InfrastructureProxy) { InfrastructureProxy infrastructureProxy = (InfrastructureProxy)resourceRef;
/*  68 */       resourceRef = infrastructureProxy.getWrappedObject(); }
/*     */     
/*  70 */     if (aopPresent)
/*     */     {
/*  72 */       resourceRef = ScopedProxyUnwrapper.unwrapIfNecessary(resourceRef);
/*     */     }
/*  74 */     return resourceRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void triggerFlush() {
/*  84 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/*  85 */       for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations()) {
/*  86 */         synchronization.flush();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void triggerSavepoint(Object savepoint) {
/*  98 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/*  99 */       for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations()) {
/* 100 */         synchronization.savepoint(savepoint);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void triggerSavepointRollback(Object savepoint) {
/* 112 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 113 */       for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations()) {
/* 114 */         synchronization.savepointRollback(savepoint);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void triggerBeforeCommit(boolean readOnly) {
/* 126 */     for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations()) {
/* 127 */       synchronization.beforeCommit(readOnly);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void triggerBeforeCompletion() {
/* 136 */     for (TransactionSynchronization synchronization : TransactionSynchronizationManager.getSynchronizations()) {
/*     */       try {
/* 138 */         synchronization.beforeCompletion();
/*     */       }
/* 140 */       catch (Throwable ex) {
/* 141 */         logger.error("TransactionSynchronization.beforeCompletion threw exception", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void triggerAfterCommit() {
/* 153 */     invokeAfterCommit(TransactionSynchronizationManager.getSynchronizations());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeAfterCommit(@Nullable List<TransactionSynchronization> synchronizations) {
/* 163 */     if (synchronizations != null) {
/* 164 */       for (TransactionSynchronization synchronization : synchronizations) {
/* 165 */         synchronization.afterCommit();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void triggerAfterCompletion(int completionStatus) {
/* 181 */     List<TransactionSynchronization> synchronizations = TransactionSynchronizationManager.getSynchronizations();
/* 182 */     invokeAfterCompletion(synchronizations, completionStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeAfterCompletion(@Nullable List<TransactionSynchronization> synchronizations, int completionStatus) {
/* 199 */     if (synchronizations != null) {
/* 200 */       for (TransactionSynchronization synchronization : synchronizations) {
/*     */         try {
/* 202 */           synchronization.afterCompletion(completionStatus);
/*     */         }
/* 204 */         catch (Throwable ex) {
/* 205 */           logger.error("TransactionSynchronization.afterCompletion threw exception", ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ScopedProxyUnwrapper
/*     */   {
/*     */     public static Object unwrapIfNecessary(Object resource) {
/* 218 */       if (resource instanceof ScopedObject) { ScopedObject scopedObject = (ScopedObject)resource;
/* 219 */         return scopedObject.getTargetObject(); }
/*     */ 
/*     */       
/* 222 */       return resource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionSynchronizationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */