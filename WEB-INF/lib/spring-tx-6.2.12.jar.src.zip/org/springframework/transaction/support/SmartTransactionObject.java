/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.io.Flushable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SmartTransactionObject
/*    */   extends Flushable
/*    */ {
/*    */   default boolean isRollbackOnly() {
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   default void flush() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\SmartTransactionObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */