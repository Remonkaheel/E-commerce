/*    */ package org.springframework.transaction.support;
/*    */ 
/*    */ import java.io.Flushable;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TransactionSynchronization
/*    */   extends Ordered, Flushable
/*    */ {
/*    */   public static final int STATUS_COMMITTED = 0;
/*    */   public static final int STATUS_ROLLED_BACK = 1;
/*    */   public static final int STATUS_UNKNOWN = 2;
/*    */   
/*    */   default int getOrder() {
/* 63 */     return Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   default void suspend() {}
/*    */   
/*    */   default void resume() {}
/*    */   
/*    */   default void flush() {}
/*    */   
/*    */   default void savepoint(Object savepoint) {}
/*    */   
/*    */   default void savepointRollback(Object savepoint) {}
/*    */   
/*    */   default void beforeCommit(boolean readOnly) {}
/*    */   
/*    */   default void beforeCompletion() {}
/*    */   
/*    */   default void afterCommit() {}
/*    */   
/*    */   default void afterCompletion(int status) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */