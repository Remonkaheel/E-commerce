/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionTemplate
/*     */   extends DefaultTransactionDefinition
/*     */   implements TransactionOperations, InitializingBean
/*     */ {
/*  69 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PlatformTransactionManager transactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionTemplate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionTemplate(PlatformTransactionManager transactionManager) {
/*  89 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionTemplate(PlatformTransactionManager transactionManager, TransactionDefinition transactionDefinition) {
/* 100 */     super(transactionDefinition);
/* 101 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionManager(@Nullable PlatformTransactionManager transactionManager) {
/* 109 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PlatformTransactionManager getTransactionManager() {
/* 117 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 122 */     if (this.transactionManager == null) {
/* 123 */       throw new IllegalArgumentException("Property 'transactionManager' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T execute(TransactionCallback<T> action) throws TransactionException {
/*     */     T result;
/* 131 */     Assert.state((this.transactionManager != null), "No PlatformTransactionManager set");
/*     */     
/* 133 */     PlatformTransactionManager platformTransactionManager = this.transactionManager; if (platformTransactionManager instanceof CallbackPreferringPlatformTransactionManager) { CallbackPreferringPlatformTransactionManager cpptm = (CallbackPreferringPlatformTransactionManager)platformTransactionManager;
/* 134 */       return cpptm.execute(this, action); }
/*     */ 
/*     */     
/* 137 */     TransactionStatus status = this.transactionManager.getTransaction(this);
/*     */     
/*     */     try {
/* 140 */       result = action.doInTransaction(status);
/*     */     }
/* 142 */     catch (RuntimeException|Error ex) {
/*     */       
/* 144 */       rollbackOnException(status, ex);
/* 145 */       throw ex;
/*     */     }
/* 147 */     catch (Throwable ex) {
/*     */       
/* 149 */       rollbackOnException(status, ex);
/* 150 */       throw new UndeclaredThrowableException(ex, "TransactionCallback threw undeclared checked exception");
/*     */     } 
/* 152 */     this.transactionManager.commit(status);
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rollbackOnException(TransactionStatus status, Throwable ex) throws TransactionException {
/* 164 */     Assert.state((this.transactionManager != null), "No PlatformTransactionManager set");
/*     */     
/* 166 */     this.logger.debug("Initiating transaction rollback on application exception", ex);
/*     */     try {
/* 168 */       this.transactionManager.rollback(status);
/*     */     }
/* 170 */     catch (TransactionSystemException ex2) {
/* 171 */       this.logger.error("Application exception overridden by rollback exception", ex);
/* 172 */       ex2.initApplicationException(ex);
/* 173 */       throw ex2;
/*     */     }
/* 175 */     catch (RuntimeException|Error ex2) {
/* 176 */       this.logger.error("Application exception overridden by rollback exception", ex);
/* 177 */       throw ex2;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: if_acmpeq -> 36
/*     */     //   5: aload_0
/*     */     //   6: aload_1
/*     */     //   7: invokespecial equals : (Ljava/lang/Object;)Z
/*     */     //   10: ifeq -> 40
/*     */     //   13: aload_1
/*     */     //   14: instanceof org/springframework/transaction/support/TransactionTemplate
/*     */     //   17: ifeq -> 36
/*     */     //   20: aload_1
/*     */     //   21: checkcast org/springframework/transaction/support/TransactionTemplate
/*     */     //   24: astore_2
/*     */     //   25: aload_0
/*     */     //   26: invokevirtual getTransactionManager : ()Lorg/springframework/transaction/PlatformTransactionManager;
/*     */     //   29: aload_2
/*     */     //   30: invokevirtual getTransactionManager : ()Lorg/springframework/transaction/PlatformTransactionManager;
/*     */     //   33: if_acmpne -> 40
/*     */     //   36: iconst_1
/*     */     //   37: goto -> 41
/*     */     //   40: iconst_0
/*     */     //   41: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #184	-> 0
/*     */     //   #185	-> 26
/*     */     //   #184	-> 41
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   25	11	2	template	Lorg/springframework/transaction/support/TransactionTemplate;
/*     */     //   0	42	0	this	Lorg/springframework/transaction/support/TransactionTemplate;
/*     */     //   0	42	1	other	Ljava/lang/Object;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */