/*      */ package org.springframework.transaction.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.transaction.ConfigurableTransactionManager;
/*      */ import org.springframework.transaction.IllegalTransactionStateException;
/*      */ import org.springframework.transaction.InvalidTimeoutException;
/*      */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*      */ import org.springframework.transaction.PlatformTransactionManager;
/*      */ import org.springframework.transaction.TransactionDefinition;
/*      */ import org.springframework.transaction.TransactionException;
/*      */ import org.springframework.transaction.TransactionExecution;
/*      */ import org.springframework.transaction.TransactionExecutionListener;
/*      */ import org.springframework.transaction.TransactionStatus;
/*      */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*      */ import org.springframework.transaction.UnexpectedRollbackException;
/*      */ import org.springframework.util.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractPlatformTransactionManager
/*      */   implements PlatformTransactionManager, ConfigurableTransactionManager, Serializable
/*      */ {
/*      */   public static final int SYNCHRONIZATION_ALWAYS = 0;
/*      */   public static final int SYNCHRONIZATION_ON_ACTUAL_TRANSACTION = 1;
/*      */   public static final int SYNCHRONIZATION_NEVER = 2;
/*  121 */   static final Map<String, Integer> constants = Map.of("SYNCHRONIZATION_ALWAYS", 
/*  122 */       Integer.valueOf(0), "SYNCHRONIZATION_ON_ACTUAL_TRANSACTION", 
/*  123 */       Integer.valueOf(1), "SYNCHRONIZATION_NEVER", 
/*  124 */       Integer.valueOf(2));
/*      */ 
/*      */ 
/*      */   
/*  128 */   protected transient Log logger = LogFactory.getLog(getClass());
/*      */   
/*  130 */   private int transactionSynchronization = 0;
/*      */   
/*  132 */   private int defaultTimeout = -1;
/*      */   
/*      */   private boolean nestedTransactionAllowed = false;
/*      */   
/*      */   private boolean validateExistingTransaction = false;
/*      */   
/*      */   private boolean globalRollbackOnParticipationFailure = true;
/*      */   
/*      */   private boolean failEarlyOnGlobalRollbackOnly = false;
/*      */   
/*      */   private boolean rollbackOnCommitFailure = false;
/*      */   
/*  144 */   private Collection<TransactionExecutionListener> transactionExecutionListeners = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTransactionSynchronizationName(String constantName) {
/*  157 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/*  158 */     Integer transactionSynchronization = constants.get(constantName);
/*  159 */     Assert.notNull(transactionSynchronization, "Only transaction synchronization constants allowed");
/*  160 */     this.transactionSynchronization = transactionSynchronization.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTransactionSynchronization(int transactionSynchronization) {
/*  176 */     this.transactionSynchronization = transactionSynchronization;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTransactionSynchronization() {
/*  184 */     return this.transactionSynchronization;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDefaultTimeout(int defaultTimeout) {
/*  196 */     if (defaultTimeout < -1) {
/*  197 */       throw new InvalidTimeoutException("Invalid default timeout", defaultTimeout);
/*      */     }
/*  199 */     this.defaultTimeout = defaultTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getDefaultTimeout() {
/*  209 */     return this.defaultTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setNestedTransactionAllowed(boolean nestedTransactionAllowed) {
/*  218 */     this.nestedTransactionAllowed = nestedTransactionAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isNestedTransactionAllowed() {
/*  225 */     return this.nestedTransactionAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setValidateExistingTransaction(boolean validateExistingTransaction) {
/*  243 */     this.validateExistingTransaction = validateExistingTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isValidateExistingTransaction() {
/*  252 */     return this.validateExistingTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setGlobalRollbackOnParticipationFailure(boolean globalRollbackOnParticipationFailure) {
/*  288 */     this.globalRollbackOnParticipationFailure = globalRollbackOnParticipationFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isGlobalRollbackOnParticipationFailure() {
/*  296 */     return this.globalRollbackOnParticipationFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFailEarlyOnGlobalRollbackOnly(boolean failEarlyOnGlobalRollbackOnly) {
/*  316 */     this.failEarlyOnGlobalRollbackOnly = failEarlyOnGlobalRollbackOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isFailEarlyOnGlobalRollbackOnly() {
/*  325 */     return this.failEarlyOnGlobalRollbackOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setRollbackOnCommitFailure(boolean rollbackOnCommitFailure) {
/*  338 */     this.rollbackOnCommitFailure = rollbackOnCommitFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isRollbackOnCommitFailure() {
/*  346 */     return this.rollbackOnCommitFailure;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTransactionExecutionListeners(Collection<TransactionExecutionListener> listeners) {
/*  351 */     this.transactionExecutionListeners = listeners;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Collection<TransactionExecutionListener> getTransactionExecutionListeners() {
/*  356 */     return this.transactionExecutionListeners;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TransactionStatus getTransaction(@Nullable TransactionDefinition definition) throws TransactionException {
/*  377 */     TransactionDefinition def = (definition != null) ? definition : TransactionDefinition.withDefaults();
/*      */     
/*  379 */     Object transaction = doGetTransaction();
/*  380 */     boolean debugEnabled = this.logger.isDebugEnabled();
/*      */     
/*  382 */     if (isExistingTransaction(transaction))
/*      */     {
/*  384 */       return handleExistingTransaction(def, transaction, debugEnabled);
/*      */     }
/*      */ 
/*      */     
/*  388 */     if (def.getTimeout() < -1) {
/*  389 */       throw new InvalidTimeoutException("Invalid transaction timeout", def.getTimeout());
/*      */     }
/*      */ 
/*      */     
/*  393 */     if (def.getPropagationBehavior() == 2) {
/*  394 */       throw new IllegalTransactionStateException("No existing transaction found for transaction marked with propagation 'mandatory'");
/*      */     }
/*      */     
/*  397 */     if (def.getPropagationBehavior() == 0 || def
/*  398 */       .getPropagationBehavior() == 3 || def
/*  399 */       .getPropagationBehavior() == 6) {
/*  400 */       SuspendedResourcesHolder suspendedResources = suspend(null);
/*  401 */       if (debugEnabled) {
/*  402 */         this.logger.debug("Creating new transaction with name [" + def.getName() + "]: " + String.valueOf(def));
/*      */       }
/*      */       try {
/*  405 */         return startTransaction(def, transaction, false, debugEnabled, suspendedResources);
/*      */       }
/*  407 */       catch (RuntimeException|Error ex) {
/*  408 */         resume(null, suspendedResources);
/*  409 */         throw ex;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  414 */     if (def.getIsolationLevel() != -1 && this.logger.isWarnEnabled()) {
/*  415 */       this.logger.warn("Custom isolation level specified but no actual transaction initiated; isolation level will effectively be ignored: " + String.valueOf(def));
/*      */     }
/*      */     
/*  418 */     boolean newSynchronization = (getTransactionSynchronization() == 0);
/*  419 */     return prepareTransactionStatus(def, null, true, newSynchronization, debugEnabled, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TransactionStatus handleExistingTransaction(TransactionDefinition definition, Object transaction, boolean debugEnabled) throws TransactionException {
/*  430 */     if (definition.getPropagationBehavior() == 5) {
/*  431 */       throw new IllegalTransactionStateException("Existing transaction found for transaction marked with propagation 'never'");
/*      */     }
/*      */ 
/*      */     
/*  435 */     if (definition.getPropagationBehavior() == 4) {
/*  436 */       if (debugEnabled) {
/*  437 */         this.logger.debug("Suspending current transaction");
/*      */       }
/*  439 */       Object suspendedResources = suspend(transaction);
/*  440 */       boolean bool = (getTransactionSynchronization() == 0);
/*  441 */       return prepareTransactionStatus(definition, null, false, bool, debugEnabled, suspendedResources);
/*      */     } 
/*      */ 
/*      */     
/*  445 */     if (definition.getPropagationBehavior() == 3) {
/*  446 */       if (debugEnabled) {
/*  447 */         this.logger.debug("Suspending current transaction, creating new transaction with name [" + definition
/*  448 */             .getName() + "]");
/*      */       }
/*  450 */       SuspendedResourcesHolder suspendedResources = suspend(transaction);
/*      */       try {
/*  452 */         return startTransaction(definition, transaction, false, debugEnabled, suspendedResources);
/*      */       }
/*  454 */       catch (RuntimeException|Error beginEx) {
/*  455 */         resumeAfterBeginException(transaction, suspendedResources, beginEx);
/*  456 */         throw beginEx;
/*      */       } 
/*      */     } 
/*      */     
/*  460 */     if (definition.getPropagationBehavior() == 6) {
/*  461 */       if (!isNestedTransactionAllowed()) {
/*  462 */         throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions by default - specify 'nestedTransactionAllowed' property with value 'true'");
/*      */       }
/*      */ 
/*      */       
/*  466 */       if (debugEnabled) {
/*  467 */         this.logger.debug("Creating nested transaction with name [" + definition.getName() + "]");
/*      */       }
/*  469 */       if (useSavepointForNestedTransaction()) {
/*      */ 
/*      */ 
/*      */         
/*  473 */         DefaultTransactionStatus status = newTransactionStatus(definition, transaction, false, false, true, debugEnabled, null);
/*      */         
/*  475 */         this.transactionExecutionListeners.forEach(listener -> listener.beforeBegin((TransactionExecution)status));
/*      */         try {
/*  477 */           status.createAndHoldSavepoint();
/*      */         }
/*  479 */         catch (RuntimeException|Error ex) {
/*  480 */           this.transactionExecutionListeners.forEach(listener -> listener.afterBegin((TransactionExecution)status, ex));
/*  481 */           throw ex;
/*      */         } 
/*  483 */         this.transactionExecutionListeners.forEach(listener -> listener.afterBegin((TransactionExecution)status, null));
/*  484 */         return status;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  490 */       return startTransaction(definition, transaction, true, debugEnabled, null);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     if (debugEnabled) {
/*  497 */       this.logger.debug("Participating in existing transaction");
/*      */     }
/*  499 */     if (isValidateExistingTransaction()) {
/*  500 */       if (definition.getIsolationLevel() != -1) {
/*  501 */         Integer currentIsolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  502 */         if (currentIsolationLevel == null || currentIsolationLevel.intValue() != definition.getIsolationLevel()) {
/*  503 */           throw new IllegalTransactionStateException("Participating transaction with definition [" + String.valueOf(definition) + "] specifies isolation level which is incompatible with existing transaction: " + (
/*      */               
/*  505 */               (currentIsolationLevel != null) ? 
/*  506 */               DefaultTransactionDefinition.getIsolationLevelName(currentIsolationLevel.intValue()) : 
/*  507 */               "(unknown)"));
/*      */         }
/*      */       } 
/*  510 */       if (!definition.isReadOnly() && 
/*  511 */         TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
/*  512 */         throw new IllegalTransactionStateException("Participating transaction with definition [" + String.valueOf(definition) + "] is not marked as read-only but existing transaction is");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  517 */     boolean newSynchronization = (getTransactionSynchronization() != 2);
/*  518 */     return prepareTransactionStatus(definition, transaction, false, newSynchronization, debugEnabled, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TransactionStatus startTransaction(TransactionDefinition definition, Object transaction, boolean nested, boolean debugEnabled, @Nullable SuspendedResourcesHolder suspendedResources) {
/*  527 */     boolean newSynchronization = (getTransactionSynchronization() != 2);
/*  528 */     DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, nested, debugEnabled, suspendedResources);
/*      */     
/*  530 */     this.transactionExecutionListeners.forEach(listener -> listener.beforeBegin((TransactionExecution)status));
/*      */     try {
/*  532 */       doBegin(transaction, definition);
/*      */     }
/*  534 */     catch (RuntimeException|Error ex) {
/*  535 */       this.transactionExecutionListeners.forEach(listener -> listener.afterBegin((TransactionExecution)status, ex));
/*  536 */       throw ex;
/*      */     } 
/*  538 */     prepareSynchronization(status, definition);
/*  539 */     this.transactionExecutionListeners.forEach(listener -> listener.afterBegin((TransactionExecution)status, null));
/*  540 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DefaultTransactionStatus prepareTransactionStatus(TransactionDefinition definition, @Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean debug, @Nullable Object suspendedResources) {
/*  553 */     DefaultTransactionStatus status = newTransactionStatus(definition, transaction, newTransaction, newSynchronization, false, debug, suspendedResources);
/*      */     
/*  555 */     prepareSynchronization(status, definition);
/*  556 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DefaultTransactionStatus newTransactionStatus(TransactionDefinition definition, @Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean nested, boolean debug, @Nullable Object suspendedResources) {
/*  567 */     boolean actualNewSynchronization = (newSynchronization && !TransactionSynchronizationManager.isSynchronizationActive());
/*  568 */     return new DefaultTransactionStatus(definition.getName(), transaction, newTransaction, actualNewSynchronization, nested, definition
/*  569 */         .isReadOnly(), debug, suspendedResources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareSynchronization(DefaultTransactionStatus status, TransactionDefinition definition) {
/*  576 */     if (status.isNewSynchronization()) {
/*  577 */       TransactionSynchronizationManager.setActualTransactionActive(status.hasTransaction());
/*  578 */       TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(
/*  579 */           (definition.getIsolationLevel() != -1) ? 
/*  580 */           Integer.valueOf(definition.getIsolationLevel()) : null);
/*  581 */       TransactionSynchronizationManager.setCurrentTransactionReadOnly(definition.isReadOnly());
/*  582 */       TransactionSynchronizationManager.setCurrentTransactionName(definition.getName());
/*  583 */       TransactionSynchronizationManager.initSynchronization();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int determineTimeout(TransactionDefinition definition) {
/*  597 */     if (definition.getTimeout() != -1) {
/*  598 */       return definition.getTimeout();
/*      */     }
/*  600 */     return getDefaultTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected final SuspendedResourcesHolder suspend(@Nullable Object transaction) throws TransactionException {
/*  616 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/*  617 */       List<TransactionSynchronization> suspendedSynchronizations = doSuspendSynchronization();
/*      */       try {
/*  619 */         Object suspendedResources = null;
/*  620 */         if (transaction != null) {
/*  621 */           suspendedResources = doSuspend(transaction);
/*      */         }
/*  623 */         String name = TransactionSynchronizationManager.getCurrentTransactionName();
/*  624 */         TransactionSynchronizationManager.setCurrentTransactionName(null);
/*  625 */         boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/*  626 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(false);
/*  627 */         Integer isolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  628 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(null);
/*  629 */         boolean wasActive = TransactionSynchronizationManager.isActualTransactionActive();
/*  630 */         TransactionSynchronizationManager.setActualTransactionActive(false);
/*  631 */         return new SuspendedResourcesHolder(suspendedResources, suspendedSynchronizations, name, readOnly, isolationLevel, wasActive);
/*      */       
/*      */       }
/*  634 */       catch (RuntimeException|Error ex) {
/*      */         
/*  636 */         doResumeSynchronization(suspendedSynchronizations);
/*  637 */         throw ex;
/*      */       } 
/*      */     } 
/*  640 */     if (transaction != null) {
/*      */       
/*  642 */       Object suspendedResources = doSuspend(transaction);
/*  643 */       return new SuspendedResourcesHolder(suspendedResources);
/*      */     } 
/*      */ 
/*      */     
/*  647 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void resume(@Nullable Object transaction, @Nullable SuspendedResourcesHolder resourcesHolder) throws TransactionException {
/*  664 */     if (resourcesHolder != null) {
/*  665 */       Object suspendedResources = resourcesHolder.suspendedResources;
/*  666 */       if (suspendedResources != null) {
/*  667 */         doResume(transaction, suspendedResources);
/*      */       }
/*  669 */       List<TransactionSynchronization> suspendedSynchronizations = resourcesHolder.suspendedSynchronizations;
/*  670 */       if (suspendedSynchronizations != null) {
/*  671 */         TransactionSynchronizationManager.setActualTransactionActive(resourcesHolder.wasActive);
/*  672 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(resourcesHolder.isolationLevel);
/*  673 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(resourcesHolder.readOnly);
/*  674 */         TransactionSynchronizationManager.setCurrentTransactionName(resourcesHolder.name);
/*  675 */         doResumeSynchronization(suspendedSynchronizations);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resumeAfterBeginException(Object transaction, @Nullable SuspendedResourcesHolder suspendedResources, Throwable beginEx) {
/*      */     try {
/*  687 */       resume(transaction, suspendedResources);
/*      */     }
/*  689 */     catch (RuntimeException|Error resumeEx) {
/*  690 */       String exMessage = "Inner transaction begin exception overridden by outer transaction resume exception";
/*  691 */       this.logger.error(exMessage, beginEx);
/*  692 */       throw resumeEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<TransactionSynchronization> doSuspendSynchronization() {
/*  703 */     List<TransactionSynchronization> suspendedSynchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  704 */     for (TransactionSynchronization synchronization : suspendedSynchronizations) {
/*  705 */       synchronization.suspend();
/*      */     }
/*  707 */     TransactionSynchronizationManager.clearSynchronization();
/*  708 */     return suspendedSynchronizations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doResumeSynchronization(List<TransactionSynchronization> suspendedSynchronizations) {
/*  717 */     TransactionSynchronizationManager.initSynchronization();
/*  718 */     for (TransactionSynchronization synchronization : suspendedSynchronizations) {
/*  719 */       synchronization.resume();
/*  720 */       TransactionSynchronizationManager.registerSynchronization(synchronization);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void commit(TransactionStatus status) throws TransactionException {
/*  736 */     if (status.isCompleted()) {
/*  737 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*      */     }
/*      */ 
/*      */     
/*  741 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  742 */     if (defStatus.isLocalRollbackOnly()) {
/*  743 */       if (defStatus.isDebug()) {
/*  744 */         this.logger.debug("Transactional code has requested rollback");
/*      */       }
/*  746 */       processRollback(defStatus, false);
/*      */       
/*      */       return;
/*      */     } 
/*  750 */     if (!shouldCommitOnGlobalRollbackOnly() && defStatus.isGlobalRollbackOnly()) {
/*  751 */       if (defStatus.isDebug()) {
/*  752 */         this.logger.debug("Global transaction is marked as rollback-only but transactional code requested commit");
/*      */       }
/*  754 */       processRollback(defStatus, true);
/*      */       
/*      */       return;
/*      */     } 
/*  758 */     processCommit(defStatus);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processCommit(DefaultTransactionStatus status) throws TransactionException {
/*      */     try {
/*  769 */       boolean beforeCompletionInvoked = false;
/*  770 */       boolean commitListenerInvoked = false;
/*      */       
/*      */       try {
/*  773 */         boolean unexpectedRollback = false;
/*  774 */         prepareForCommit(status);
/*  775 */         triggerBeforeCommit(status);
/*  776 */         triggerBeforeCompletion(status);
/*  777 */         beforeCompletionInvoked = true;
/*      */         
/*  779 */         if (status.hasSavepoint()) {
/*  780 */           if (status.isDebug()) {
/*  781 */             this.logger.debug("Releasing transaction savepoint");
/*      */           }
/*  783 */           unexpectedRollback = status.isGlobalRollbackOnly();
/*  784 */           this.transactionExecutionListeners.forEach(listener -> listener.beforeCommit((TransactionExecution)status));
/*  785 */           commitListenerInvoked = true;
/*  786 */           status.releaseHeldSavepoint();
/*      */         }
/*  788 */         else if (status.isNewTransaction()) {
/*  789 */           if (status.isDebug()) {
/*  790 */             this.logger.debug("Initiating transaction commit");
/*      */           }
/*  792 */           unexpectedRollback = status.isGlobalRollbackOnly();
/*  793 */           this.transactionExecutionListeners.forEach(listener -> listener.beforeCommit((TransactionExecution)status));
/*  794 */           commitListenerInvoked = true;
/*  795 */           doCommit(status);
/*      */         }
/*  797 */         else if (isFailEarlyOnGlobalRollbackOnly()) {
/*  798 */           unexpectedRollback = status.isGlobalRollbackOnly();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  803 */         if (unexpectedRollback) {
/*  804 */           throw new UnexpectedRollbackException("Transaction silently rolled back because it has been marked as rollback-only");
/*      */         
/*      */         }
/*      */       }
/*  808 */       catch (UnexpectedRollbackException ex) {
/*  809 */         triggerAfterCompletion(status, 1);
/*  810 */         this.transactionExecutionListeners.forEach(listener -> listener.afterRollback((TransactionExecution)status, null));
/*  811 */         throw ex;
/*      */       }
/*  813 */       catch (TransactionException ex) {
/*  814 */         if (isRollbackOnCommitFailure()) {
/*  815 */           doRollbackOnCommitException(status, (Throwable)ex);
/*      */         } else {
/*      */           
/*  818 */           triggerAfterCompletion(status, 2);
/*  819 */           if (commitListenerInvoked) {
/*  820 */             this.transactionExecutionListeners.forEach(listener -> listener.afterCommit((TransactionExecution)status, (Throwable)ex));
/*      */           }
/*      */         } 
/*  823 */         throw ex;
/*      */       }
/*  825 */       catch (RuntimeException|Error ex) {
/*  826 */         if (!beforeCompletionInvoked) {
/*  827 */           triggerBeforeCompletion(status);
/*      */         }
/*  829 */         doRollbackOnCommitException(status, ex);
/*  830 */         throw ex;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  836 */         triggerAfterCommit(status);
/*      */       } finally {
/*      */         
/*  839 */         triggerAfterCompletion(status, 0);
/*  840 */         if (commitListenerInvoked) {
/*  841 */           this.transactionExecutionListeners.forEach(listener -> listener.afterCommit((TransactionExecution)status, null));
/*      */         }
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  847 */       cleanupAfterCompletion(status);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void rollback(TransactionStatus status) throws TransactionException {
/*  860 */     if (status.isCompleted()) {
/*  861 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*      */     }
/*      */ 
/*      */     
/*  865 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  866 */     processRollback(defStatus, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processRollback(DefaultTransactionStatus status, boolean unexpected) {
/*      */     try {
/*  877 */       boolean unexpectedRollback = unexpected;
/*  878 */       boolean rollbackListenerInvoked = false;
/*      */       
/*      */       try {
/*  881 */         triggerBeforeCompletion(status);
/*      */         
/*  883 */         if (status.hasSavepoint()) {
/*  884 */           if (status.isDebug()) {
/*  885 */             this.logger.debug("Rolling back transaction to savepoint");
/*      */           }
/*  887 */           this.transactionExecutionListeners.forEach(listener -> listener.beforeRollback((TransactionExecution)status));
/*  888 */           rollbackListenerInvoked = true;
/*  889 */           status.rollbackToHeldSavepoint();
/*      */         }
/*  891 */         else if (status.isNewTransaction()) {
/*  892 */           if (status.isDebug()) {
/*  893 */             this.logger.debug("Initiating transaction rollback");
/*      */           }
/*  895 */           this.transactionExecutionListeners.forEach(listener -> listener.beforeRollback((TransactionExecution)status));
/*  896 */           rollbackListenerInvoked = true;
/*  897 */           doRollback(status);
/*      */         }
/*      */         else {
/*      */           
/*  901 */           if (status.hasTransaction()) {
/*  902 */             if (status.isLocalRollbackOnly() || isGlobalRollbackOnParticipationFailure()) {
/*  903 */               if (status.isDebug()) {
/*  904 */                 this.logger.debug("Participating transaction failed - marking existing transaction as rollback-only");
/*      */               }
/*  906 */               doSetRollbackOnly(status);
/*      */             
/*      */             }
/*  909 */             else if (status.isDebug()) {
/*  910 */               this.logger.debug("Participating transaction failed - letting transaction originator decide on rollback");
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  915 */             this.logger.debug("Should roll back transaction but cannot - no transaction available");
/*      */           } 
/*      */           
/*  918 */           if (!isFailEarlyOnGlobalRollbackOnly()) {
/*  919 */             unexpectedRollback = false;
/*      */           }
/*      */         }
/*      */       
/*  923 */       } catch (RuntimeException|Error ex) {
/*  924 */         triggerAfterCompletion(status, 2);
/*  925 */         if (rollbackListenerInvoked) {
/*  926 */           this.transactionExecutionListeners.forEach(listener -> listener.afterRollback((TransactionExecution)status, ex));
/*      */         }
/*  928 */         throw ex;
/*      */       } 
/*      */       
/*  931 */       triggerAfterCompletion(status, 1);
/*  932 */       if (rollbackListenerInvoked) {
/*  933 */         this.transactionExecutionListeners.forEach(listener -> listener.afterRollback((TransactionExecution)status, null));
/*      */       }
/*      */ 
/*      */       
/*  937 */       if (unexpectedRollback) {
/*  938 */         throw new UnexpectedRollbackException("Transaction rolled back because it has been marked as rollback-only");
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/*  943 */       cleanupAfterCompletion(status);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doRollbackOnCommitException(DefaultTransactionStatus status, Throwable ex) throws TransactionException {
/*      */     try {
/*  956 */       if (status.isNewTransaction()) {
/*  957 */         if (status.isDebug()) {
/*  958 */           this.logger.debug("Initiating transaction rollback after commit exception", ex);
/*      */         }
/*  960 */         doRollback(status);
/*      */       }
/*  962 */       else if (status.hasTransaction() && isGlobalRollbackOnParticipationFailure()) {
/*  963 */         if (status.isDebug()) {
/*  964 */           this.logger.debug("Marking existing transaction as rollback-only after commit exception", ex);
/*      */         }
/*  966 */         doSetRollbackOnly(status);
/*      */       }
/*      */     
/*  969 */     } catch (RuntimeException|Error rbex) {
/*  970 */       this.logger.error("Commit exception overridden by rollback exception", ex);
/*  971 */       triggerAfterCompletion(status, 2);
/*  972 */       this.transactionExecutionListeners.forEach(listener -> listener.afterRollback((TransactionExecution)status, rbex));
/*  973 */       throw rbex;
/*      */     } 
/*  975 */     triggerAfterCompletion(status, 1);
/*  976 */     this.transactionExecutionListeners.forEach(listener -> listener.afterRollback((TransactionExecution)status, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void triggerBeforeCommit(DefaultTransactionStatus status) {
/*  985 */     if (status.isNewSynchronization()) {
/*  986 */       TransactionSynchronizationUtils.triggerBeforeCommit(status.isReadOnly());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void triggerBeforeCompletion(DefaultTransactionStatus status) {
/*  995 */     if (status.isNewSynchronization()) {
/*  996 */       TransactionSynchronizationUtils.triggerBeforeCompletion();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void triggerAfterCommit(DefaultTransactionStatus status) {
/* 1005 */     if (status.isNewSynchronization()) {
/* 1006 */       TransactionSynchronizationUtils.triggerAfterCommit();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void triggerAfterCompletion(DefaultTransactionStatus status, int completionStatus) {
/* 1016 */     if (status.isNewSynchronization()) {
/* 1017 */       List<TransactionSynchronization> synchronizations = TransactionSynchronizationManager.getSynchronizations();
/* 1018 */       TransactionSynchronizationManager.clearSynchronization();
/* 1019 */       if (!status.hasTransaction() || status.isNewTransaction()) {
/*      */ 
/*      */         
/* 1022 */         invokeAfterCompletion(synchronizations, completionStatus);
/*      */       }
/* 1024 */       else if (!synchronizations.isEmpty()) {
/*      */ 
/*      */ 
/*      */         
/* 1028 */         registerAfterCompletionWithExistingTransaction(status.getTransaction(), synchronizations);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void invokeAfterCompletion(List<TransactionSynchronization> synchronizations, int completionStatus) {
/* 1047 */     TransactionSynchronizationUtils.invokeAfterCompletion(synchronizations, completionStatus);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanupAfterCompletion(DefaultTransactionStatus status) {
/* 1057 */     status.setCompleted();
/* 1058 */     if (status.isNewSynchronization()) {
/* 1059 */       TransactionSynchronizationManager.clear();
/*      */     }
/* 1061 */     if (status.isNewTransaction()) {
/* 1062 */       doCleanupAfterCompletion(status.getTransaction());
/*      */     }
/* 1064 */     if (status.getSuspendedResources() != null) {
/* 1065 */       if (status.isDebug()) {
/* 1066 */         this.logger.debug("Resuming suspended transaction after completion of inner transaction");
/*      */       }
/* 1068 */       Object transaction = status.hasTransaction() ? status.getTransaction() : null;
/* 1069 */       resume(transaction, (SuspendedResourcesHolder)status.getSuspendedResources());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isExistingTransaction(Object transaction) throws TransactionException {
/* 1118 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useSavepointForNestedTransaction() {
/* 1138 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object doSuspend(Object transaction) throws TransactionException {
/* 1177 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + 
/* 1178 */         getClass().getName() + "] does not support transaction suspension");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doResume(@Nullable Object transaction, Object suspendedResources) throws TransactionException {
/* 1195 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + 
/* 1196 */         getClass().getName() + "] does not support transaction suspension");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean shouldCommitOnGlobalRollbackOnly() {
/* 1229 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareForCommit(DefaultTransactionStatus status) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetRollbackOnly(DefaultTransactionStatus status) throws TransactionException {
/* 1277 */     throw new IllegalTransactionStateException("Participating in existing transactions is not supported - when 'isExistingTransaction' returns true, appropriate 'doSetRollbackOnly' behavior must be provided");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations) throws TransactionException {
/* 1300 */     this.logger.debug("Cannot register Spring after-completion synchronization with existing transaction - processing Spring after-completion callbacks immediately, with outcome status 'unknown'");
/*      */     
/* 1302 */     invokeAfterCompletion(synchronizations, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCleanupAfterCompletion(Object transaction) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 1322 */     ois.defaultReadObject();
/*      */ 
/*      */     
/* 1325 */     this.logger = LogFactory.getLog(getClass());
/*      */   }
/*      */ 
/*      */   
/*      */   protected abstract Object doGetTransaction() throws TransactionException;
/*      */ 
/*      */   
/*      */   protected abstract void doBegin(Object paramObject, TransactionDefinition paramTransactionDefinition) throws TransactionException;
/*      */   
/*      */   protected abstract void doCommit(DefaultTransactionStatus paramDefaultTransactionStatus) throws TransactionException;
/*      */   
/*      */   protected abstract void doRollback(DefaultTransactionStatus paramDefaultTransactionStatus) throws TransactionException;
/*      */   
/*      */   protected static final class SuspendedResourcesHolder
/*      */   {
/*      */     @Nullable
/*      */     private final Object suspendedResources;
/*      */     @Nullable
/*      */     private List<TransactionSynchronization> suspendedSynchronizations;
/*      */     @Nullable
/*      */     private String name;
/*      */     private boolean readOnly;
/*      */     @Nullable
/*      */     private Integer isolationLevel;
/*      */     private boolean wasActive;
/*      */     
/*      */     private SuspendedResourcesHolder(Object suspendedResources) {
/* 1352 */       this.suspendedResources = suspendedResources;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private SuspendedResourcesHolder(@Nullable Object suspendedResources, List<TransactionSynchronization> suspendedSynchronizations, @Nullable String name, boolean readOnly, @Nullable Integer isolationLevel, boolean wasActive) {
/* 1359 */       this.suspendedResources = suspendedResources;
/* 1360 */       this.suspendedSynchronizations = suspendedSynchronizations;
/* 1361 */       this.name = name;
/* 1362 */       this.readOnly = readOnly;
/* 1363 */       this.isolationLevel = isolationLevel;
/* 1364 */       this.wasActive = wasActive;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\AbstractPlatformTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */