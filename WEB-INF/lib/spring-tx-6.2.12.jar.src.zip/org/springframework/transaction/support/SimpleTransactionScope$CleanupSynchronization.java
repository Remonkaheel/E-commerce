/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CleanupSynchronization
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   private final SimpleTransactionScope.ScopedObjectsHolder scopedObjects;
/*     */   
/*     */   public CleanupSynchronization(SimpleTransactionScope.ScopedObjectsHolder scopedObjects) {
/* 113 */     this.scopedObjects = scopedObjects;
/*     */   }
/*     */ 
/*     */   
/*     */   public void suspend() {
/* 118 */     TransactionSynchronizationManager.unbindResource(SimpleTransactionScope.this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resume() {
/* 123 */     TransactionSynchronizationManager.bindResource(SimpleTransactionScope.this, this.scopedObjects);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterCompletion(int status) {
/* 128 */     TransactionSynchronizationManager.unbindResourceIfPossible(SimpleTransactionScope.this);
/* 129 */     for (Runnable callback : this.scopedObjects.destructionCallbacks.values()) {
/* 130 */       callback.run();
/*     */     }
/* 132 */     this.scopedObjects.destructionCallbacks.clear();
/* 133 */     this.scopedObjects.scopedInstances.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\SimpleTransactionScope$CleanupSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */