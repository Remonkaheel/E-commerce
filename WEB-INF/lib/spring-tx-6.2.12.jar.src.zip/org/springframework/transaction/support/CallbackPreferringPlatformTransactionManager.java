package org.springframework.transaction.support;

import org.springframework.lang.Nullable;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;

public interface CallbackPreferringPlatformTransactionManager extends PlatformTransactionManager {
  @Nullable
  <T> T execute(@Nullable TransactionDefinition paramTransactionDefinition, TransactionCallback<T> paramTransactionCallback) throws TransactionException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\CallbackPreferringPlatformTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */