/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.Date;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.TransactionTimedOutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceHolderSupport
/*     */   implements ResourceHolder
/*     */ {
/*     */   private boolean synchronizedWithTransaction = false;
/*     */   private boolean rollbackOnly = false;
/*     */   @Nullable
/*     */   private Date deadline;
/*  45 */   private int referenceCount = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isVoid = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSynchronizedWithTransaction(boolean synchronizedWithTransaction) {
/*  54 */     this.synchronizedWithTransaction = synchronizedWithTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynchronizedWithTransaction() {
/*  61 */     return this.synchronizedWithTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollbackOnly() {
/*  68 */     this.rollbackOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetRollbackOnly() {
/*  79 */     this.rollbackOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRollbackOnly() {
/*  86 */     return this.rollbackOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutInSeconds(int seconds) {
/*  94 */     setTimeoutInMillis(seconds * 1000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutInMillis(long millis) {
/* 102 */     this.deadline = new Date(System.currentTimeMillis() + millis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTimeout() {
/* 109 */     return (this.deadline != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Date getDeadline() {
/* 118 */     return this.deadline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeToLiveInSeconds() {
/* 128 */     double diff = getTimeToLiveInMillis() / 1000.0D;
/* 129 */     int secs = (int)Math.ceil(diff);
/* 130 */     checkTransactionTimeout((secs <= 0));
/* 131 */     return secs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTimeToLiveInMillis() throws TransactionTimedOutException {
/* 140 */     if (this.deadline == null) {
/* 141 */       throw new IllegalStateException("No timeout specified for this resource holder");
/*     */     }
/* 143 */     long timeToLive = this.deadline.getTime() - System.currentTimeMillis();
/* 144 */     checkTransactionTimeout((timeToLive <= 0L));
/* 145 */     return timeToLive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkTransactionTimeout(boolean deadlineReached) throws TransactionTimedOutException {
/* 153 */     if (deadlineReached) {
/* 154 */       setRollbackOnly();
/* 155 */       throw new TransactionTimedOutException("Transaction timed out: deadline was " + String.valueOf(this.deadline));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requested() {
/* 164 */     this.referenceCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void released() {
/* 172 */     this.referenceCount--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 179 */     return (this.referenceCount > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 186 */     this.synchronizedWithTransaction = false;
/* 187 */     this.rollbackOnly = false;
/* 188 */     this.deadline = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 196 */     clear();
/* 197 */     this.referenceCount = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void unbound() {
/* 202 */     this.isVoid = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVoid() {
/* 207 */     return this.isVoid;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\ResourceHolderSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */