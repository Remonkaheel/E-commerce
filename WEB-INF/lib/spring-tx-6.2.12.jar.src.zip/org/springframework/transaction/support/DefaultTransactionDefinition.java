/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTransactionDefinition
/*     */   implements TransactionDefinition, Serializable
/*     */ {
/*     */   public static final String PREFIX_PROPAGATION = "PROPAGATION_";
/*     */   public static final String PREFIX_ISOLATION = "ISOLATION_";
/*     */   public static final String PREFIX_TIMEOUT = "timeout_";
/*     */   public static final String READ_ONLY_MARKER = "readOnly";
/*  58 */   static final Map<String, Integer> propagationConstants = Map.of("PROPAGATION_REQUIRED", 
/*  59 */       Integer.valueOf(0), "PROPAGATION_SUPPORTS", 
/*  60 */       Integer.valueOf(1), "PROPAGATION_MANDATORY", 
/*  61 */       Integer.valueOf(2), "PROPAGATION_REQUIRES_NEW", 
/*  62 */       Integer.valueOf(3), "PROPAGATION_NOT_SUPPORTED", 
/*  63 */       Integer.valueOf(4), "PROPAGATION_NEVER", 
/*  64 */       Integer.valueOf(5), "PROPAGATION_NESTED", 
/*  65 */       Integer.valueOf(6));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   static final Map<String, Integer> isolationConstants = Map.of("ISOLATION_DEFAULT", 
/*  73 */       Integer.valueOf(-1), "ISOLATION_READ_UNCOMMITTED", 
/*  74 */       Integer.valueOf(1), "ISOLATION_READ_COMMITTED", 
/*  75 */       Integer.valueOf(2), "ISOLATION_REPEATABLE_READ", 
/*  76 */       Integer.valueOf(4), "ISOLATION_SERIALIZABLE", 
/*  77 */       Integer.valueOf(8));
/*     */ 
/*     */   
/*  80 */   private int propagationBehavior = 0;
/*     */   
/*  82 */   private int isolationLevel = -1;
/*     */   
/*  84 */   private int timeout = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readOnly = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionDefinition() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionDefinition(TransactionDefinition other) {
/* 113 */     this.propagationBehavior = other.getPropagationBehavior();
/* 114 */     this.isolationLevel = other.getIsolationLevel();
/* 115 */     this.timeout = other.getTimeout();
/* 116 */     this.readOnly = other.isReadOnly();
/* 117 */     this.name = other.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionDefinition(int propagationBehavior) {
/* 130 */     this.propagationBehavior = propagationBehavior;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPropagationBehaviorName(String constantName) throws IllegalArgumentException {
/* 144 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/* 145 */     Integer propagationBehavior = propagationConstants.get(constantName);
/* 146 */     Assert.notNull(propagationBehavior, "Only propagation behavior constants allowed");
/* 147 */     this.propagationBehavior = propagationBehavior.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPropagationBehavior(int propagationBehavior) {
/* 166 */     Assert.isTrue(propagationConstants.containsValue(Integer.valueOf(propagationBehavior)), "Only values of propagation constants allowed");
/*     */     
/* 168 */     this.propagationBehavior = propagationBehavior;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getPropagationBehavior() {
/* 173 */     return this.propagationBehavior;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIsolationLevelName(String constantName) throws IllegalArgumentException {
/* 186 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/* 187 */     Integer isolationLevel = isolationConstants.get(constantName);
/* 188 */     Assert.notNull(isolationLevel, "Only isolation constants allowed");
/* 189 */     this.isolationLevel = isolationLevel.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIsolationLevel(int isolationLevel) {
/* 208 */     Assert.isTrue(isolationConstants.containsValue(Integer.valueOf(isolationLevel)), "Only values of isolation constants allowed");
/*     */     
/* 210 */     this.isolationLevel = isolationLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIsolationLevel() {
/* 215 */     return this.isolationLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTimeout(int timeout) {
/* 229 */     if (timeout < -1) {
/* 230 */       throw new IllegalArgumentException("Timeout must be a non-negative integer or TIMEOUT_DEFAULT");
/*     */     }
/* 232 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getTimeout() {
/* 237 */     return this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setReadOnly(boolean readOnly) {
/* 255 */     this.readOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isReadOnly() {
/* 260 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setName(String name) {
/* 269 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String getName() {
/* 275 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 285 */     return (this == other || (other instanceof TransactionDefinition && toString().equals(other.toString())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 294 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 311 */     return getDefinitionDescription().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final StringBuilder getDefinitionDescription() {
/* 319 */     StringBuilder result = new StringBuilder();
/* 320 */     result.append(getPropagationBehaviorName(this.propagationBehavior));
/* 321 */     result.append(',');
/* 322 */     result.append(getIsolationLevelName(this.isolationLevel));
/* 323 */     if (this.timeout != -1) {
/* 324 */       result.append(',');
/* 325 */       result.append("timeout_").append(this.timeout);
/*     */     } 
/* 327 */     if (this.readOnly) {
/* 328 */       result.append(',');
/* 329 */       result.append("readOnly");
/*     */     } 
/* 331 */     return result;
/*     */   }
/*     */   
/*     */   private static String getPropagationBehaviorName(int propagationBehavior) {
/* 335 */     switch (propagationBehavior) { case 0: 
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 4: 
/*     */       case 5:
/*     */       
/*     */       case 6:
/* 343 */        }  throw new IllegalArgumentException("Unsupported propagation behavior: " + propagationBehavior);
/*     */   }
/*     */ 
/*     */   
/*     */   static String getIsolationLevelName(int isolationLevel) {
/* 348 */     switch (isolationLevel) { case -1: 
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 4:
/*     */       
/*     */       case 8:
/* 354 */        }  throw new IllegalArgumentException("Unsupported isolation level: " + isolationLevel);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\DefaultTransactionDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */