/*     */ package org.springframework.transaction.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransactionSynchronizationManager
/*     */ {
/*  76 */   private static final ThreadLocal<Map<Object, Object>> resources = (ThreadLocal<Map<Object, Object>>)new NamedThreadLocal("Transactional resources");
/*     */ 
/*     */   
/*  79 */   private static final ThreadLocal<Set<TransactionSynchronization>> synchronizations = (ThreadLocal<Set<TransactionSynchronization>>)new NamedThreadLocal("Transaction synchronizations");
/*     */ 
/*     */   
/*  82 */   private static final ThreadLocal<String> currentTransactionName = (ThreadLocal<String>)new NamedThreadLocal("Current transaction name");
/*     */ 
/*     */   
/*  85 */   private static final ThreadLocal<Boolean> currentTransactionReadOnly = (ThreadLocal<Boolean>)new NamedThreadLocal("Current transaction read-only status");
/*     */ 
/*     */   
/*  88 */   private static final ThreadLocal<Integer> currentTransactionIsolationLevel = (ThreadLocal<Integer>)new NamedThreadLocal("Current transaction isolation level");
/*     */ 
/*     */   
/*  91 */   private static final ThreadLocal<Boolean> actualTransactionActive = (ThreadLocal<Boolean>)new NamedThreadLocal("Actual transaction active");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<Object, Object> getResourceMap() {
/* 109 */     Map<Object, Object> map = resources.get();
/* 110 */     return (map != null) ? Collections.<Object, Object>unmodifiableMap(map) : Collections.<Object, Object>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasResource(Object key) {
/* 120 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 121 */     Object value = doGetResource(actualKey);
/* 122 */     return (value != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object getResource(Object key) {
/* 134 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 135 */     return doGetResource(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Object doGetResource(Object actualKey) {
/* 143 */     Map<Object, Object> map = resources.get();
/* 144 */     if (map == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     Object value = map.get(actualKey);
/*     */     
/* 149 */     if (value instanceof ResourceHolder) { ResourceHolder resourceHolder = (ResourceHolder)value; if (resourceHolder.isVoid()) {
/* 150 */         map.remove(actualKey);
/*     */         
/* 152 */         if (map.isEmpty()) {
/* 153 */           resources.remove();
/*     */         }
/* 155 */         value = null;
/*     */       }  }
/* 157 */      return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void bindResource(Object key, Object value) throws IllegalStateException {
/* 168 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 169 */     Assert.notNull(value, "Value must not be null");
/* 170 */     Map<Object, Object> map = resources.get();
/*     */     
/* 172 */     if (map == null) {
/* 173 */       map = new HashMap<>();
/* 174 */       resources.set(map);
/*     */     } 
/* 176 */     Object oldValue = map.put(actualKey, value);
/*     */     
/* 178 */     if (oldValue instanceof ResourceHolder) { ResourceHolder resourceHolder = (ResourceHolder)oldValue; if (resourceHolder.isVoid())
/* 179 */         oldValue = null;  }
/*     */     
/* 181 */     if (oldValue != null) {
/* 182 */       throw new IllegalStateException("Already value [" + String.valueOf(oldValue) + "] for key [" + String.valueOf(actualKey) + "] bound to thread");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object unbindResource(Object key) throws IllegalStateException {
/* 195 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 196 */     Object value = doUnbindResource(actualKey);
/* 197 */     if (value == null) {
/* 198 */       throw new IllegalStateException("No value for key [" + String.valueOf(actualKey) + "] bound to thread");
/*     */     }
/* 200 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object unbindResourceIfPossible(Object key) {
/* 210 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 211 */     return doUnbindResource(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Object doUnbindResource(Object actualKey) {
/* 219 */     Map<Object, Object> map = resources.get();
/* 220 */     if (map == null) {
/* 221 */       return null;
/*     */     }
/* 223 */     Object value = map.remove(actualKey);
/*     */     
/* 225 */     if (map.isEmpty()) {
/* 226 */       resources.remove();
/*     */     }
/*     */     
/* 229 */     if (value instanceof ResourceHolder) { ResourceHolder resourceHolder = (ResourceHolder)value; if (resourceHolder.isVoid())
/* 230 */         value = null;  }
/*     */     
/* 232 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynchronizationActive() {
/* 246 */     return (synchronizations.get() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initSynchronization() throws IllegalStateException {
/* 255 */     if (isSynchronizationActive()) {
/* 256 */       throw new IllegalStateException("Cannot activate transaction synchronization - already active");
/*     */     }
/* 258 */     synchronizations.set(new LinkedHashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerSynchronization(TransactionSynchronization synchronization) throws IllegalStateException {
/* 274 */     Assert.notNull(synchronization, "TransactionSynchronization must not be null");
/* 275 */     Set<TransactionSynchronization> synchs = synchronizations.get();
/* 276 */     if (synchs == null) {
/* 277 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/* 279 */     synchs.add(synchronization);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<TransactionSynchronization> getSynchronizations() throws IllegalStateException {
/* 290 */     Set<TransactionSynchronization> synchs = synchronizations.get();
/* 291 */     if (synchs == null) {
/* 292 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (synchs.isEmpty()) {
/* 298 */       return Collections.emptyList();
/*     */     }
/* 300 */     if (synchs.size() == 1) {
/* 301 */       return Collections.singletonList(synchs.iterator().next());
/*     */     }
/*     */ 
/*     */     
/* 305 */     List<TransactionSynchronization> sortedSynchs = new ArrayList<>(synchs);
/* 306 */     OrderComparator.sort(sortedSynchs);
/* 307 */     return Collections.unmodifiableList(sortedSynchs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearSynchronization() throws IllegalStateException {
/* 317 */     if (!isSynchronizationActive()) {
/* 318 */       throw new IllegalStateException("Cannot deactivate transaction synchronization - not active");
/*     */     }
/* 320 */     synchronizations.remove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCurrentTransactionName(@Nullable String name) {
/* 335 */     currentTransactionName.set(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String getCurrentTransactionName() {
/* 346 */     return currentTransactionName.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCurrentTransactionReadOnly(boolean readOnly) {
/* 357 */     currentTransactionReadOnly.set(readOnly ? Boolean.TRUE : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCurrentTransactionReadOnly() {
/* 373 */     return (currentTransactionReadOnly.get() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCurrentTransactionIsolationLevel(@Nullable Integer isolationLevel) {
/* 393 */     currentTransactionIsolationLevel.set(isolationLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Integer getCurrentTransactionIsolationLevel() {
/* 415 */     return currentTransactionIsolationLevel.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setActualTransactionActive(boolean active) {
/* 425 */     actualTransactionActive.set(active ? Boolean.TRUE : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isActualTransactionActive() {
/* 440 */     return (actualTransactionActive.get() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/* 454 */     synchronizations.remove();
/* 455 */     currentTransactionName.remove();
/* 456 */     currentTransactionReadOnly.remove();
/* 457 */     currentTransactionIsolationLevel.remove();
/* 458 */     actualTransactionActive.remove();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\TransactionSynchronizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */