package org.springframework.transaction.support;

import org.springframework.transaction.PlatformTransactionManager;

public interface ResourceTransactionManager extends PlatformTransactionManager {
  Object getResourceFactory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\support\ResourceTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */