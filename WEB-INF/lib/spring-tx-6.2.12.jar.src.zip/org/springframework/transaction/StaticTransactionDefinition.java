/*    */ package org.springframework.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StaticTransactionDefinition
/*    */   implements TransactionDefinition
/*    */ {
/* 28 */   static final StaticTransactionDefinition INSTANCE = new StaticTransactionDefinition();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\StaticTransactionDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */