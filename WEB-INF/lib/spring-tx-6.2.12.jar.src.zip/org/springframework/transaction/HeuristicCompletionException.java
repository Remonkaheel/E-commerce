/*    */ package org.springframework.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeuristicCompletionException
/*    */   extends TransactionException
/*    */ {
/*    */   public static final int STATE_UNKNOWN = 0;
/*    */   public static final int STATE_COMMITTED = 1;
/*    */   public static final int STATE_ROLLED_BACK = 2;
/*    */   public static final int STATE_MIXED = 3;
/*    */   private final int outcomeState;
/*    */   
/*    */   public static String getStateString(int state) {
/* 52 */     switch (state) { case 1: case 2: case 3:  }  return 
/*    */ 
/*    */ 
/*    */       
/* 56 */       "unknown";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HeuristicCompletionException(int outcomeState, Throwable cause) {
/* 73 */     super("Heuristic completion: outcome state is " + getStateString(outcomeState), cause);
/* 74 */     this.outcomeState = outcomeState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOutcomeState() {
/* 86 */     return this.outcomeState;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\HeuristicCompletionException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */