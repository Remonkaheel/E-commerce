/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionSynchronizationManager
/*     */ {
/*     */   private final TransactionContext transactionContext;
/*     */   
/*     */   public TransactionSynchronizationManager(TransactionContext transactionContext) {
/*  76 */     Assert.notNull(transactionContext, "TransactionContext must not be null");
/*  77 */     this.transactionContext = transactionContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<TransactionSynchronizationManager> forCurrentTransaction() {
/*  89 */     return TransactionContextManager.currentContext().map(TransactionSynchronizationManager::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasResource(Object key) {
/*  99 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 100 */     Object value = doGetResource(actualKey);
/* 101 */     return (value != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getResource(Object key) {
/* 112 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 113 */     return doGetResource(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object doGetResource(Object actualKey) {
/* 121 */     return this.transactionContext.getResources().get(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindResource(Object key, Object value) throws IllegalStateException {
/* 131 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 132 */     Assert.notNull(value, "Value must not be null");
/* 133 */     Map<Object, Object> map = this.transactionContext.getResources();
/* 134 */     Object oldValue = map.put(actualKey, value);
/* 135 */     if (oldValue != null) {
/* 136 */       throw new IllegalStateException("Already value [" + String.valueOf(oldValue) + "] for key [" + String.valueOf(actualKey) + "] bound to context");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object unbindResource(Object key) throws IllegalStateException {
/* 148 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 149 */     Object value = doUnbindResource(actualKey);
/* 150 */     if (value == null) {
/* 151 */       throw new IllegalStateException("No value for key [" + String.valueOf(actualKey) + "] bound to context");
/*     */     }
/* 153 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object unbindResourceIfPossible(Object key) {
/* 163 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 164 */     return doUnbindResource(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object doUnbindResource(Object actualKey) {
/* 172 */     Map<Object, Object> map = this.transactionContext.getResources();
/* 173 */     return map.remove(actualKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynchronizationActive() {
/* 187 */     return (this.transactionContext.getSynchronizations() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initSynchronization() throws IllegalStateException {
/* 196 */     if (isSynchronizationActive()) {
/* 197 */       throw new IllegalStateException("Cannot activate transaction synchronization - already active");
/*     */     }
/* 199 */     this.transactionContext.setSynchronizations(new LinkedHashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerSynchronization(TransactionSynchronization synchronization) throws IllegalStateException {
/* 215 */     Assert.notNull(synchronization, "TransactionSynchronization must not be null");
/* 216 */     Set<TransactionSynchronization> synchs = this.transactionContext.getSynchronizations();
/* 217 */     if (synchs == null) {
/* 218 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/* 220 */     synchs.add(synchronization);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TransactionSynchronization> getSynchronizations() throws IllegalStateException {
/* 231 */     Set<TransactionSynchronization> synchs = this.transactionContext.getSynchronizations();
/* 232 */     if (synchs == null) {
/* 233 */       throw new IllegalStateException("Transaction synchronization is not active");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 238 */     if (synchs.isEmpty()) {
/* 239 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */     
/* 243 */     List<TransactionSynchronization> sortedSynchs = new ArrayList<>(synchs);
/* 244 */     AnnotationAwareOrderComparator.sort(sortedSynchs);
/* 245 */     return Collections.unmodifiableList(sortedSynchs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSynchronization() throws IllegalStateException {
/* 255 */     if (!isSynchronizationActive()) {
/* 256 */       throw new IllegalStateException("Cannot deactivate transaction synchronization - not active");
/*     */     }
/* 258 */     this.transactionContext.setSynchronizations(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentTransactionName(@Nullable String name) {
/* 273 */     this.transactionContext.setCurrentTransactionName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getCurrentTransactionName() {
/* 284 */     return this.transactionContext.getCurrentTransactionName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentTransactionReadOnly(boolean readOnly) {
/* 295 */     this.transactionContext.setCurrentTransactionReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentTransactionReadOnly() {
/* 310 */     return this.transactionContext.isCurrentTransactionReadOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentTransactionIsolationLevel(@Nullable Integer isolationLevel) {
/* 326 */     this.transactionContext.setCurrentTransactionIsolationLevel(isolationLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer getCurrentTransactionIsolationLevel() {
/* 344 */     return this.transactionContext.getCurrentTransactionIsolationLevel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActualTransactionActive(boolean active) {
/* 354 */     this.transactionContext.setActualTransactionActive(active);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActualTransactionActive() {
/* 369 */     return this.transactionContext.isActualTransactionActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 382 */     this.transactionContext.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionSynchronizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */