/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.aop.scope.ScopedObject;
/*     */ import org.springframework.core.InfrastructureProxy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TransactionSynchronizationUtils
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationUtils.class);
/*     */   
/*  45 */   private static final boolean aopPresent = ClassUtils.isPresent("org.springframework.aop.scope.ScopedObject", TransactionSynchronizationUtils.class
/*  46 */       .getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object unwrapResourceIfNecessary(Object resource) {
/*  55 */     Assert.notNull(resource, "Resource must not be null");
/*  56 */     Object resourceRef = resource;
/*     */     
/*  58 */     if (resourceRef instanceof InfrastructureProxy) { InfrastructureProxy infrastructureProxy = (InfrastructureProxy)resourceRef;
/*  59 */       resourceRef = infrastructureProxy.getWrappedObject(); }
/*     */     
/*  61 */     if (aopPresent)
/*     */     {
/*  63 */       resourceRef = ScopedProxyUnwrapper.unwrapIfNecessary(resourceRef);
/*     */     }
/*  65 */     return resourceRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> triggerBeforeCommit(Collection<TransactionSynchronization> synchronizations, boolean readOnly) {
/*  76 */     return Flux.fromIterable(synchronizations).concatMap(it -> it.beforeCommit(readOnly)).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> triggerBeforeCompletion(Collection<TransactionSynchronization> synchronizations) {
/*  86 */     return Flux.fromIterable(synchronizations)
/*  87 */       .concatMap(TransactionSynchronization::beforeCompletion).onErrorContinue((t, o) -> logger.error("TransactionSynchronization.beforeCompletion threw exception", t))
/*  88 */       .then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> invokeAfterCommit(Collection<TransactionSynchronization> synchronizations) {
/*  98 */     return Flux.fromIterable(synchronizations)
/*  99 */       .concatMap(TransactionSynchronization::afterCommit)
/* 100 */       .then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> invokeAfterCompletion(Collection<TransactionSynchronization> synchronizations, int completionStatus) {
/* 117 */     return Flux.fromIterable(synchronizations).concatMap(it -> it.afterCompletion(completionStatus))
/* 118 */       .onErrorContinue((t, o) -> logger.error("TransactionSynchronization.afterCompletion threw exception", t)).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ScopedProxyUnwrapper
/*     */   {
/*     */     public static Object unwrapIfNecessary(Object resource) {
/* 128 */       if (resource instanceof ScopedObject) { ScopedObject scopedObject = (ScopedObject)resource;
/* 129 */         return scopedObject.getTargetObject(); }
/*     */ 
/*     */       
/* 132 */       return resource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionSynchronizationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */