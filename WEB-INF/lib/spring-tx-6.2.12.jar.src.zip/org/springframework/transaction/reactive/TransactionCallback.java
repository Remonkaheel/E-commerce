package org.springframework.transaction.reactive;

import org.reactivestreams.Publisher;
import org.springframework.transaction.ReactiveTransaction;

@FunctionalInterface
public interface TransactionCallback<T> {
  Publisher<T> doInTransaction(ReactiveTransaction paramReactiveTransaction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */