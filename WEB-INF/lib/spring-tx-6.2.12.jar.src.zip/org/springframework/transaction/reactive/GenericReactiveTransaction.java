/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.ReactiveTransaction;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericReactiveTransaction
/*     */   implements ReactiveTransaction
/*     */ {
/*     */   @Nullable
/*     */   private final String transactionName;
/*     */   @Nullable
/*     */   private final Object transaction;
/*     */   private final boolean newTransaction;
/*     */   private final boolean newSynchronization;
/*     */   private final boolean nested;
/*     */   private final boolean readOnly;
/*     */   private final boolean debug;
/*     */   @Nullable
/*     */   private final Object suspendedResources;
/*     */   private boolean rollbackOnly = false;
/*     */   private boolean completed = false;
/*     */   
/*     */   public GenericReactiveTransaction(@Nullable String transactionName, @Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean nested, boolean readOnly, boolean debug, @Nullable Object suspendedResources) {
/*  89 */     this.transactionName = transactionName;
/*  90 */     this.transaction = transaction;
/*  91 */     this.newTransaction = newTransaction;
/*  92 */     this.newSynchronization = newSynchronization;
/*  93 */     this.nested = nested;
/*  94 */     this.readOnly = readOnly;
/*  95 */     this.debug = debug;
/*  96 */     this.suspendedResources = suspendedResources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public GenericReactiveTransaction(@Nullable Object transaction, boolean newTransaction, boolean newSynchronization, boolean readOnly, boolean debug, @Nullable Object suspendedResources) {
/* 103 */     this(null, transaction, newTransaction, newSynchronization, false, readOnly, debug, suspendedResources);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransactionName() {
/* 109 */     return (this.transactionName != null) ? this.transactionName : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransaction() {
/* 117 */     Assert.state((this.transaction != null), "No transaction active");
/* 118 */     return this.transaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasTransaction() {
/* 123 */     return (this.transaction != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNewTransaction() {
/* 128 */     return (hasTransaction() && this.newTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNewSynchronization() {
/* 135 */     return this.newSynchronization;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 140 */     return this.nested;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 145 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebug() {
/* 154 */     return this.debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSuspendedResources() {
/* 163 */     return this.suspendedResources;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRollbackOnly() {
/* 168 */     if (this.completed) {
/* 169 */       throw new IllegalStateException("Transaction completed");
/*     */     }
/* 171 */     this.rollbackOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRollbackOnly() {
/* 181 */     return this.rollbackOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompleted() {
/* 188 */     this.completed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompleted() {
/* 193 */     return this.completed;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\GenericReactiveTransaction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */