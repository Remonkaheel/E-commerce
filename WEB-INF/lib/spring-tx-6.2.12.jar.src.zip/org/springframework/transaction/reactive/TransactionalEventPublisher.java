/*    */ package org.springframework.transaction.reactive;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.PayloadApplicationEvent;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionalEventPublisher
/*    */ {
/*    */   private final ApplicationEventPublisher eventPublisher;
/*    */   
/*    */   public TransactionalEventPublisher(ApplicationEventPublisher eventPublisher) {
/* 60 */     this.eventPublisher = eventPublisher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> publishEvent(Function<TransactionContext, ApplicationEvent> eventCreationFunction) {
/* 73 */     Objects.requireNonNull(this.eventPublisher); return TransactionContextManager.currentContext().map(eventCreationFunction).doOnSuccess(this.eventPublisher::publishEvent).then();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> publishEvent(Object payload) {
/* 82 */     if (payload instanceof ApplicationEvent) {
/* 83 */       return Mono.error(new IllegalArgumentException("Cannot publish ApplicationEvent with transactional source - publish payload object or use publishEvent(Function<Object, ApplicationEvent>"));
/*    */     }
/*    */     
/* 86 */     return publishEvent(source -> new PayloadApplicationEvent(source, payload));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */