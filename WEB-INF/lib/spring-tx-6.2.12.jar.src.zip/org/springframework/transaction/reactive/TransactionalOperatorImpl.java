/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.ReactiveTransaction;
/*     */ import org.springframework.transaction.ReactiveTransactionManager;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TransactionalOperatorImpl
/*     */   implements TransactionalOperator
/*     */ {
/*  45 */   private static final Log logger = LogFactory.getLog(TransactionalOperatorImpl.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ReactiveTransactionManager transactionManager;
/*     */ 
/*     */ 
/*     */   
/*     */   private final TransactionDefinition transactionDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TransactionalOperatorImpl(ReactiveTransactionManager transactionManager, TransactionDefinition transactionDefinition) {
/*  60 */     Assert.notNull(transactionManager, "ReactiveTransactionManager must not be null");
/*  61 */     Assert.notNull(transactionDefinition, "TransactionDefinition must not be null");
/*  62 */     this.transactionManager = transactionManager;
/*  63 */     this.transactionDefinition = transactionDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveTransactionManager getTransactionManager() {
/*  71 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Flux<T> execute(TransactionCallback<T> action) throws TransactionException {
/*  76 */     return TransactionContextManager.currentContext().flatMapMany(context -> {
/*     */           Objects.requireNonNull(action);
/*     */           
/*     */           Objects.requireNonNull(this.transactionManager);
/*     */           
/*     */           Objects.requireNonNull(this.transactionManager);
/*     */           
/*     */           return (Publisher)Flux.usingWhen((Publisher)this.transactionManager.getReactiveTransaction(this.transactionDefinition), action::doInTransaction, this.transactionManager::commit, this::rollbackOnException, this.transactionManager::rollback).onErrorMap(this::unwrapIfResourceCleanupFailure);
/*  84 */         }).contextWrite(TransactionContextManager.getOrCreateContext())
/*  85 */       .contextWrite(TransactionContextManager.getOrCreateContextHolder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> rollbackOnException(ReactiveTransaction status, Throwable ex) throws TransactionException {
/*  95 */     logger.debug("Initiating transaction rollback on application exception", ex);
/*  96 */     return this.transactionManager.rollback(status).onErrorMap(ex2 -> {
/*     */           logger.error("Application exception overridden by rollback exception", ex);
/*     */           if (ex2 instanceof TransactionSystemException) {
/*     */             TransactionSystemException tse = (TransactionSystemException)ex2;
/*     */             tse.initApplicationException(ex);
/*     */           } else {
/*     */             ex2.addSuppressed(ex);
/*     */           } 
/*     */           return ex2;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Throwable unwrapIfResourceCleanupFailure(Throwable ex) {
/* 115 */     if (ex instanceof RuntimeException && ex.getCause() != null) {
/* 116 */       String msg = ex.getMessage();
/* 117 */       if (msg != null && msg.startsWith("Async resource cleanup failed")) {
/* 118 */         return ex.getCause();
/*     */       }
/*     */     } 
/* 121 */     return ex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: if_acmpeq -> 36
/*     */     //   5: aload_0
/*     */     //   6: aload_1
/*     */     //   7: invokespecial equals : (Ljava/lang/Object;)Z
/*     */     //   10: ifeq -> 40
/*     */     //   13: aload_1
/*     */     //   14: instanceof org/springframework/transaction/reactive/TransactionalOperatorImpl
/*     */     //   17: ifeq -> 36
/*     */     //   20: aload_1
/*     */     //   21: checkcast org/springframework/transaction/reactive/TransactionalOperatorImpl
/*     */     //   24: astore_2
/*     */     //   25: aload_0
/*     */     //   26: invokevirtual getTransactionManager : ()Lorg/springframework/transaction/ReactiveTransactionManager;
/*     */     //   29: aload_2
/*     */     //   30: invokevirtual getTransactionManager : ()Lorg/springframework/transaction/ReactiveTransactionManager;
/*     */     //   33: if_acmpne -> 40
/*     */     //   36: iconst_1
/*     */     //   37: goto -> 41
/*     */     //   40: iconst_0
/*     */     //   41: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #127	-> 0
/*     */     //   #128	-> 26
/*     */     //   #127	-> 41
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   25	11	2	toi	Lorg/springframework/transaction/reactive/TransactionalOperatorImpl;
/*     */     //   0	42	0	this	Lorg/springframework/transaction/reactive/TransactionalOperatorImpl;
/*     */     //   0	42	1	other	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 133 */     return getTransactionManager().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalOperatorImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */