/*    */ package org.springframework.transaction.reactive;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ResultKt;
/*    */ import kotlin.Unit;
/*    */ import kotlin.coroutines.Continuation;
/*    */ import kotlin.coroutines.CoroutineContext;
/*    */ import kotlin.coroutines.EmptyCoroutineContext;
/*    */ import kotlin.coroutines.intrinsics.IntrinsicsKt;
/*    */ import kotlin.coroutines.jvm.internal.ContinuationImpl;
/*    */ import kotlin.coroutines.jvm.internal.DebugMetadata;
/*    */ import kotlin.coroutines.jvm.internal.SuspendLambda;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.functions.Function2;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import kotlinx.coroutines.CoroutineScope;
/*    */ import kotlinx.coroutines.flow.Flow;
/*    */ import kotlinx.coroutines.reactive.ReactiveFlowKt;
/*    */ import kotlinx.coroutines.reactor.MonoKt;
/*    */ import kotlinx.coroutines.reactor.ReactorFlowKt;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.transaction.ReactiveTransaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000,\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\032<\020\000\032\002H\001\"\004\b\000\020\001*\0020\0022\"\020\003\032\036\b\001\022\004\022\0020\005\022\n\022\b\022\004\022\002H\0010\006\022\006\022\004\030\0010\0070\004H@¢\006\002\020\b\0322\020\t\032\b\022\004\022\002H\0010\n\"\b\b\000\020\001*\0020\007*\b\022\004\022\002H\0010\n2\006\020\013\032\0020\0022\b\b\002\020\f\032\0020\r¨\006\016"}, d2 = {"executeAndAwait", "T", "Lorg/springframework/transaction/reactive/TransactionalOperator;", "f", "Lkotlin/Function2;", "Lorg/springframework/transaction/ReactiveTransaction;", "Lkotlin/coroutines/Continuation;", "", "(Lorg/springframework/transaction/reactive/TransactionalOperator;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "transactional", "Lkotlinx/coroutines/flow/Flow;", "operator", "context", "Lkotlin/coroutines/CoroutineContext;", "spring-tx"})
/*    */ @SourceDebugExtension({"SMAP\nTransactionalOperatorExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TransactionalOperatorExtensions.kt\norg/springframework/transaction/reactive/TransactionalOperatorExtensionsKt\n+ 2 CoroutineScope.kt\nkotlinx/coroutines/CoroutineScopeKt\n*L\n1#1,53:1\n326#2:54\n*S KotlinDebug\n*F\n+ 1 TransactionalOperatorExtensions.kt\norg/springframework/transaction/reactive/TransactionalOperatorExtensionsKt\n*L\n49#1:54\n*E\n"})
/*    */ public final class TransactionalOperatorExtensionsKt
/*    */ {
/*    */   @NotNull
/*    */   public static final <T> Flow<T> transactional(@NotNull Flow $this$transactional, @NotNull TransactionalOperator operator, @NotNull CoroutineContext context) {
/* 38 */     Intrinsics.checkNotNullParameter($this$transactional, "<this>"); Intrinsics.checkNotNullParameter(operator, "operator"); Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNullExpressionValue(operator.transactional(ReactorFlowKt.asFlux($this$transactional, context)), "operator.transactional(asFlux(context))"); return ReactiveFlowKt.asFlow((Publisher)operator.transactional(ReactorFlowKt.asFlux($this$transactional, context)));
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static final <T> Object executeAndAwait(@NotNull TransactionalOperator $this$executeAndAwait, @NotNull Function2 f, @NotNull Continuation<? super T> paramContinuation) {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: instanceof org/springframework/transaction/reactive/TransactionalOperatorExtensionsKt$executeAndAwait$1
/*    */     //   4: ifeq -> 39
/*    */     //   7: aload_2
/*    */     //   8: checkcast org/springframework/transaction/reactive/TransactionalOperatorExtensionsKt$executeAndAwait$1
/*    */     //   11: astore #6
/*    */     //   13: aload #6
/*    */     //   15: getfield label : I
/*    */     //   18: ldc -2147483648
/*    */     //   20: iand
/*    */     //   21: ifeq -> 39
/*    */     //   24: aload #6
/*    */     //   26: dup
/*    */     //   27: getfield label : I
/*    */     //   30: ldc -2147483648
/*    */     //   32: isub
/*    */     //   33: putfield label : I
/*    */     //   36: goto -> 49
/*    */     //   39: new org/springframework/transaction/reactive/TransactionalOperatorExtensionsKt$executeAndAwait$1
/*    */     //   42: dup
/*    */     //   43: aload_2
/*    */     //   44: invokespecial <init> : (Lkotlin/coroutines/Continuation;)V
/*    */     //   47: astore #6
/*    */     //   49: aload #6
/*    */     //   51: getfield result : Ljava/lang/Object;
/*    */     //   54: astore #5
/*    */     //   56: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
/*    */     //   59: astore #7
/*    */     //   61: aload #6
/*    */     //   63: getfield label : I
/*    */     //   66: tableswitch default -> 198, 0 -> 88, 1 -> 183
/*    */     //   88: aload #5
/*    */     //   90: invokestatic throwOnFailure : (Ljava/lang/Object;)V
/*    */     //   93: iconst_0
/*    */     //   94: istore #4
/*    */     //   96: aload #6
/*    */     //   98: invokeinterface getContext : ()Lkotlin/coroutines/CoroutineContext;
/*    */     //   103: nop
/*    */     //   104: getstatic kotlinx/coroutines/Job.Key : Lkotlinx/coroutines/Job$Key;
/*    */     //   107: checkcast kotlin/coroutines/CoroutineContext$Key
/*    */     //   110: invokeinterface minusKey : (Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext;
/*    */     //   115: astore_3
/*    */     //   116: aload_0
/*    */     //   117: aload_3
/*    */     //   118: aload_1
/*    */     //   119: <illegal opcode> doInTransaction : (Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;)Lorg/springframework/transaction/reactive/TransactionCallback;
/*    */     //   124: invokeinterface execute : (Lorg/springframework/transaction/reactive/TransactionCallback;)Lreactor/core/publisher/Flux;
/*    */     //   129: getstatic org/springframework/transaction/reactive/TransactionalOperatorExtensionsKt$executeAndAwait$3.INSTANCE : Lorg/springframework/transaction/reactive/TransactionalOperatorExtensionsKt$executeAndAwait$3;
/*    */     //   132: checkcast kotlin/jvm/functions/Function1
/*    */     //   135: <illegal opcode> apply : (Lkotlin/jvm/functions/Function1;)Ljava/util/function/Function;
/*    */     //   140: invokevirtual map : (Ljava/util/function/Function;)Lreactor/core/publisher/Flux;
/*    */     //   143: invokestatic empty : ()Ljava/util/Optional;
/*    */     //   146: invokevirtual defaultIfEmpty : (Ljava/lang/Object;)Lreactor/core/publisher/Flux;
/*    */     //   149: astore #4
/*    */     //   151: aload #4
/*    */     //   153: ldc 'execute { status -> mono…IfEmpty(Optional.empty())'
/*    */     //   155: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   158: aload #4
/*    */     //   160: checkcast org/reactivestreams/Publisher
/*    */     //   163: aload #6
/*    */     //   165: aload #6
/*    */     //   167: iconst_1
/*    */     //   168: putfield label : I
/*    */     //   171: invokestatic awaitLast : (Lorg/reactivestreams/Publisher;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
/*    */     //   174: dup
/*    */     //   175: aload #7
/*    */     //   177: if_acmpne -> 190
/*    */     //   180: aload #7
/*    */     //   182: areturn
/*    */     //   183: aload #5
/*    */     //   185: invokestatic throwOnFailure : (Ljava/lang/Object;)V
/*    */     //   188: aload #5
/*    */     //   190: checkcast java/util/Optional
/*    */     //   193: aconst_null
/*    */     //   194: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   197: areturn
/*    */     //   198: new java/lang/IllegalStateException
/*    */     //   201: dup
/*    */     //   202: ldc 'call to 'resume' before 'invoke' with coroutine'
/*    */     //   204: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   207: athrow
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #48	-> 59
/*    */     //   #49	-> 93
/*    */     //   #54	-> 96
/*    */     //   #54	-> 103
/*    */     //   #49	-> 104
/*    */     //   #50	-> 116
/*    */     //   #51	-> 143
/*    */     //   #50	-> 151
/*    */     //   #51	-> 165
/*    */     //   #48	-> 180
/*    */     //   #51	-> 190
/*    */     //   #50	-> 197
/*    */     //   #48	-> 198
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   93	11	0	$this$executeAndAwait	Lorg/springframework/transaction/reactive/TransactionalOperator;
/*    */     //   104	31	0	$this$executeAndAwait	Lorg/springframework/transaction/reactive/TransactionalOperator;
/*    */     //   93	11	1	f	Lkotlin/jvm/functions/Function2;
/*    */     //   104	31	1	f	Lkotlin/jvm/functions/Function2;
/*    */     //   116	19	3	context	Lkotlin/coroutines/CoroutineContext;
/*    */     //   96	8	4	$i$f$currentCoroutineContext	I
/*    */     //   49	149	6	$continuation	Lkotlin/coroutines/Continuation;
/*    */     //   56	142	5	$result	Ljava/lang/Object;
/*    */   }
/*    */ 
/*    */   
/*    */   private static final Publisher executeAndAwait$lambda$0(CoroutineContext $context, Function2<? super ReactiveTransaction, ? super Continuation<? super T>, ? extends Object> $f, ReactiveTransaction status)
/*    */   {
/* 50 */     Intrinsics.checkNotNullParameter($context, "$context"); Intrinsics.checkNotNullParameter($f, "$f"); return (Publisher)MonoKt.mono($context, new TransactionalOperatorExtensionsKt$executeAndAwait$2$1($f, status, null)); } private static final Optional executeAndAwait$lambda$1(Function1 $tmp0, Object p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (Optional)$tmp0.invoke(p0); } @DebugMetadata(f = "TransactionalOperatorExtensions.kt", l = {50}, i = {}, s = {}, n = {}, m = "invokeSuspend", c = "org.springframework.transaction.reactive.TransactionalOperatorExtensionsKt$executeAndAwait$2$1") @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\b\002\n\002\030\002\020\000\032\004\030\001H\001\"\004\b\000\020\001*\0020\002H@"}, d2 = {"<anonymous>", "T", "Lkotlinx/coroutines/CoroutineScope;"}) static final class TransactionalOperatorExtensionsKt$executeAndAwait$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super T>, Object> { int label; TransactionalOperatorExtensionsKt$executeAndAwait$2$1(Function2<ReactiveTransaction, Continuation<? super T>, Object> $f, ReactiveTransaction $status, Continuation $completion) { super(2, $completion); } @NotNull public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<? super TransactionalOperatorExtensionsKt$executeAndAwait$2$1> $completion) { return (Continuation<Unit>)new TransactionalOperatorExtensionsKt$executeAndAwait$2$1(this.$f, this.$status, $completion); } @Nullable public final Object invokeSuspend(@NotNull Object $result) { Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED(); switch (this.label) { case 0: ResultKt.throwOnFailure(SYNTHETIC_LOCAL_VARIABLE_1); Intrinsics.checkNotNullExpressionValue(this.$status, "status"); this.label = 1; return (this.$f.invoke(this.$status, this) == object) ? object : this.$f.invoke(this.$status, this);case 1: ResultKt.throwOnFailure(SYNTHETIC_LOCAL_VARIABLE_1); return SYNTHETIC_LOCAL_VARIABLE_1; }  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); } @Nullable public final Object invoke(@NotNull CoroutineScope p1, @Nullable Continuation<?> p2) { return ((TransactionalOperatorExtensionsKt$executeAndAwait$2$1)create(p1, p2)).invokeSuspend(Unit.INSTANCE); } } @DebugMetadata(f = "TransactionalOperatorExtensions.kt", l = {51}, i = {}, s = {}, n = {}, m = "executeAndAwait", c = "org.springframework.transaction.reactive.TransactionalOperatorExtensionsKt") @Metadata(mv = {1, 7, 0}, k = 3, xi = 48) static final class TransactionalOperatorExtensionsKt$executeAndAwait$1<T> extends ContinuationImpl { int label; TransactionalOperatorExtensionsKt$executeAndAwait$1(Continuation $completion) { super($completion); } @Nullable public final Object invokeSuspend(@NotNull Object $result) { this.result = $result; this.label |= Integer.MIN_VALUE; return TransactionalOperatorExtensionsKt.executeAndAwait(null, null, (Continuation)this); } } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\005\020\000\032\026\022\004\022\002H\002 \003*\n\022\004\022\002H\002\030\0010\0010\001\"\004\b\000\020\0022\016\020\004\032\n \003*\004\030\001H\002H\002H\n¢\006\004\b\005\020\006"}, d2 = {"<anonymous>", "Ljava/util/Optional;", "T", "kotlin.jvm.PlatformType", "value", "invoke", "(Ljava/lang/Object;)Ljava/util/Optional;"}) static final class TransactionalOperatorExtensionsKt$executeAndAwait$3 extends Lambda implements Function1<T, Optional<T>> { public final Optional<T> invoke(Object value) { return Optional.ofNullable((T)value); }
/*    */ 
/*    */     
/*    */     public static final TransactionalOperatorExtensionsKt$executeAndAwait$3 INSTANCE = new TransactionalOperatorExtensionsKt$executeAndAwait$3();
/*    */     
/*    */     TransactionalOperatorExtensionsKt$executeAndAwait$3() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalOperatorExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */