/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.transaction.ReactiveTransaction;
/*     */ import org.springframework.transaction.ReactiveTransactionManager;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TransactionalOperator
/*     */ {
/*     */   default <T> Flux<T> transactional(Flux<T> flux) {
/*  63 */     return execute(it -> flux);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> Mono<T> transactional(Mono<T> mono) {
/*  74 */     return execute(it -> mono).singleOrEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TransactionalOperator create(ReactiveTransactionManager transactionManager) {
/* 100 */     return create(transactionManager, TransactionDefinition.withDefaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TransactionalOperator create(ReactiveTransactionManager transactionManager, TransactionDefinition transactionDefinition) {
/* 113 */     return new TransactionalOperatorImpl(transactionManager, transactionDefinition);
/*     */   }
/*     */   
/*     */   <T> Flux<T> execute(TransactionCallback<T> paramTransactionCallback) throws TransactionException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalOperator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */