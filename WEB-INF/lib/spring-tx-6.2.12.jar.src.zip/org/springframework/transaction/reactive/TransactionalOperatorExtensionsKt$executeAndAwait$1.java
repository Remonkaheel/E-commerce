package org.springframework.transaction.reactive;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@DebugMetadata(f = "TransactionalOperatorExtensions.kt", l = {51}, i = {}, s = {}, n = {}, m = "executeAndAwait", c = "org.springframework.transaction.reactive.TransactionalOperatorExtensionsKt")
@Metadata(mv = {1, 7, 0}, k = 3, xi = 48)
final class TransactionalOperatorExtensionsKt$executeAndAwait$1<T> extends ContinuationImpl {
  int label;
  
  TransactionalOperatorExtensionsKt$executeAndAwait$1(Continuation $completion) {
    super($completion);
  }
  
  @Nullable
  public final Object invokeSuspend(@NotNull Object $result) {
    this.result = $result;
    this.label |= Integer.MIN_VALUE;
    return TransactionalOperatorExtensionsKt.executeAndAwait(null, null, (Continuation)this);
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalOperatorExtensionsKt$executeAndAwait$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */