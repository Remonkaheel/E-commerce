/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.transaction.NoTransactionException;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransactionContextManager
/*     */ {
/*     */   public static Mono<TransactionContext> currentContext() {
/*  53 */     return Mono.deferContextual(ctx -> {
/*     */           if (ctx.hasKey(TransactionContext.class)) {
/*     */             return Mono.just(ctx.get(TransactionContext.class));
/*     */           }
/*     */           if (ctx.hasKey(TransactionContextHolder.class)) {
/*     */             TransactionContextHolder holder = (TransactionContextHolder)ctx.get(TransactionContextHolder.class);
/*     */             if (holder.hasContext()) {
/*     */               return Mono.just(holder.currentContext());
/*     */             }
/*     */           } 
/*     */           return Mono.error((Throwable)new NoTransactionInContextException());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Context, Context> createTransactionContext() {
/*  75 */     return context -> context.put(TransactionContext.class, new TransactionContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Context, Context> getOrCreateContext() {
/*  86 */     return context -> {
/*     */         TransactionContextHolder holder = (TransactionContextHolder)context.get(TransactionContextHolder.class);
/*     */         return holder.hasContext() ? context.put(TransactionContext.class, holder.currentContext()) : context.put(TransactionContext.class, holder.createContext());
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function<Context, Context> getOrCreateContextHolder() {
/* 104 */     return context -> !context.hasKey(TransactionContextHolder.class) ? context.put(TransactionContextHolder.class, new TransactionContextHolder(new ArrayDeque<>())) : context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NoTransactionInContextException
/*     */     extends NoTransactionException
/*     */   {
/*     */     public NoTransactionInContextException() {
/* 120 */       super("No transaction in context");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 126 */       return (Throwable)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionContextManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */