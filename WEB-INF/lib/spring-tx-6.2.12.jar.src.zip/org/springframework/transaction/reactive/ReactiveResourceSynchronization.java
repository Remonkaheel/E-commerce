/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReactiveResourceSynchronization<O, K>
/*     */   implements TransactionSynchronization
/*     */ {
/*     */   private final O resourceObject;
/*     */   private final K resourceKey;
/*     */   private final TransactionSynchronizationManager synchronizationManager;
/*     */   private volatile boolean holderActive = true;
/*     */   
/*     */   public ReactiveResourceSynchronization(O resourceObject, K resourceKey, TransactionSynchronizationManager synchronizationManager) {
/*  52 */     this.resourceObject = resourceObject;
/*  53 */     this.resourceKey = resourceKey;
/*  54 */     this.synchronizationManager = synchronizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> suspend() {
/*  60 */     if (this.holderActive) {
/*  61 */       this.synchronizationManager.unbindResource(this.resourceKey);
/*     */     }
/*  63 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> resume() {
/*  68 */     if (this.holderActive) {
/*  69 */       this.synchronizationManager.bindResource(this.resourceKey, this.resourceObject);
/*     */     }
/*  71 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> beforeCommit(boolean readOnly) {
/*  76 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> beforeCompletion() {
/*  81 */     if (shouldUnbindAtCompletion()) {
/*  82 */       this.synchronizationManager.unbindResource(this.resourceKey);
/*  83 */       this.holderActive = false;
/*  84 */       if (shouldReleaseBeforeCompletion()) {
/*  85 */         return releaseResource(this.resourceObject, this.resourceKey);
/*     */       }
/*     */     } 
/*  88 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> afterCommit() {
/*  93 */     if (!shouldReleaseBeforeCompletion()) {
/*  94 */       return processResourceAfterCommit(this.resourceObject);
/*     */     }
/*  96 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> afterCompletion(int status) {
/* 101 */     return Mono.defer(() -> {
/*     */           Mono<Void> sync = Mono.empty();
/*     */           if (shouldUnbindAtCompletion()) {
/*     */             boolean releaseNecessary = false;
/*     */             if (this.holderActive) {
/*     */               this.holderActive = false;
/*     */               this.synchronizationManager.unbindResourceIfPossible(this.resourceKey);
/*     */               releaseNecessary = true;
/*     */             } else {
/*     */               releaseNecessary = shouldReleaseAfterCompletion(this.resourceObject);
/*     */             } 
/*     */             if (releaseNecessary) {
/*     */               sync = releaseResource(this.resourceObject, this.resourceKey);
/*     */             }
/*     */           } else {
/*     */             sync = cleanupResource(this.resourceObject, this.resourceKey, (status == 0));
/*     */           } 
/*     */           return sync;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldUnbindAtCompletion() {
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldReleaseBeforeCompletion() {
/* 147 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldReleaseAfterCompletion(O resourceHolder) {
/* 158 */     return !shouldReleaseBeforeCompletion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> processResourceAfterCommit(O resourceHolder) {
/* 168 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> releaseResource(O resourceHolder, K resourceKey) {
/* 177 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> cleanupResource(O resourceHolder, K resourceKey, boolean committed) {
/* 188 */     return Mono.empty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\ReactiveResourceSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */