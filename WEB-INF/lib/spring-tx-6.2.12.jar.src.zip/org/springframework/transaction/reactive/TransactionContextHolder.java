/*    */ package org.springframework.transaction.reactive;
/*    */ 
/*    */ import java.util.Deque;
/*    */ import org.springframework.transaction.NoTransactionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TransactionContextHolder
/*    */ {
/*    */   private final Deque<TransactionContext> transactionStack;
/*    */   
/*    */   TransactionContextHolder(Deque<TransactionContext> transactionStack) {
/* 38 */     this.transactionStack = transactionStack;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TransactionContext currentContext() {
/* 47 */     TransactionContext context = this.transactionStack.peek();
/* 48 */     if (context == null) {
/* 49 */       throw new NoTransactionException("No transaction in context");
/*    */     }
/* 51 */     return context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TransactionContext createContext() {
/* 58 */     TransactionContext context = this.transactionStack.peek();
/* 59 */     if (context != null) {
/* 60 */       context = new TransactionContext(context);
/*    */     } else {
/*    */       
/* 63 */       context = new TransactionContext();
/*    */     } 
/* 65 */     this.transactionStack.push(context);
/* 66 */     return context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean hasContext() {
/* 74 */     return !this.transactionStack.isEmpty();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionContextHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */