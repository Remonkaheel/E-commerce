/*      */ package org.springframework.transaction.reactive;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.transaction.ConfigurableTransactionManager;
/*      */ import org.springframework.transaction.IllegalTransactionStateException;
/*      */ import org.springframework.transaction.InvalidTimeoutException;
/*      */ import org.springframework.transaction.ReactiveTransaction;
/*      */ import org.springframework.transaction.ReactiveTransactionManager;
/*      */ import org.springframework.transaction.TransactionDefinition;
/*      */ import org.springframework.transaction.TransactionExecution;
/*      */ import org.springframework.transaction.TransactionExecutionListener;
/*      */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractReactiveTransactionManager
/*      */   implements ReactiveTransactionManager, ConfigurableTransactionManager, Serializable
/*      */ {
/*   87 */   protected transient Log logger = LogFactory.getLog(getClass());
/*      */   
/*   89 */   private Collection<TransactionExecutionListener> transactionExecutionListeners = new ArrayList<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTransactionExecutionListeners(Collection<TransactionExecutionListener> listeners) {
/*   94 */     this.transactionExecutionListeners = listeners;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Collection<TransactionExecutionListener> getTransactionExecutionListeners() {
/*   99 */     return this.transactionExecutionListeners;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<ReactiveTransaction> getReactiveTransaction(@Nullable TransactionDefinition definition) {
/*  118 */     TransactionDefinition def = (definition != null) ? definition : TransactionDefinition.withDefaults();
/*      */     
/*  120 */     return TransactionSynchronizationManager.forCurrentTransaction().flatMap(synchronizationManager -> {
/*      */           Object transaction = doGetTransaction(synchronizationManager);
/*      */           boolean debugEnabled = this.logger.isDebugEnabled();
/*      */           if (isExistingTransaction(transaction)) {
/*      */             return handleExistingTransaction(synchronizationManager, def, transaction, debugEnabled);
/*      */           }
/*      */           if (def.getTimeout() < -1) {
/*      */             return Mono.error((Throwable)new InvalidTimeoutException("Invalid transaction timeout", def.getTimeout()));
/*      */           }
/*      */           if (def.getPropagationBehavior() == 2) {
/*      */             return Mono.error((Throwable)new IllegalTransactionStateException("No existing transaction found for transaction marked with propagation 'mandatory'"));
/*      */           }
/*      */           if (def.getPropagationBehavior() == 0 || def.getPropagationBehavior() == 3 || def.getPropagationBehavior() == 6) {
/*      */             return TransactionContextManager.currentContext().map(TransactionSynchronizationManager::new).flatMap(());
/*      */           }
/*      */           if (def.getIsolationLevel() != -1 && this.logger.isWarnEnabled()) {
/*      */             this.logger.warn("Custom isolation level specified but no actual transaction initiated; isolation level will effectively be ignored: " + String.valueOf(def));
/*      */           }
/*      */           return Mono.just(prepareReactiveTransaction(synchronizationManager, def, null, true, debugEnabled, null));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<ReactiveTransaction> handleExistingTransaction(TransactionSynchronizationManager synchronizationManager, TransactionDefinition definition, Object transaction, boolean debugEnabled) {
/*  188 */     if (definition.getPropagationBehavior() == 5) {
/*  189 */       return Mono.error((Throwable)new IllegalTransactionStateException("Existing transaction found for transaction marked with propagation 'never'"));
/*      */     }
/*      */ 
/*      */     
/*  193 */     if (definition.getPropagationBehavior() == 4) {
/*  194 */       if (debugEnabled) {
/*  195 */         this.logger.debug("Suspending current transaction");
/*      */       }
/*  197 */       Mono<SuspendedResourcesHolder> suspend = suspend(synchronizationManager, transaction);
/*  198 */       return suspend.map(suspendedResources -> prepareReactiveTransaction(synchronizationManager, definition, null, false, debugEnabled, suspendedResources))
/*      */         
/*  200 */         .switchIfEmpty(Mono.fromSupplier(() -> prepareReactiveTransaction(synchronizationManager, definition, null, false, debugEnabled, null)))
/*      */         
/*  202 */         .cast(ReactiveTransaction.class);
/*      */     } 
/*      */     
/*  205 */     if (definition.getPropagationBehavior() == 3) {
/*  206 */       if (debugEnabled) {
/*  207 */         this.logger.debug("Suspending current transaction, creating new transaction with name [" + definition
/*  208 */             .getName() + "]");
/*      */       }
/*  210 */       Mono<SuspendedResourcesHolder> suspendedResources = suspend(synchronizationManager, transaction);
/*  211 */       return suspendedResources.flatMap(suspendedResourcesHolder -> {
/*      */             GenericReactiveTransaction status = newReactiveTransaction(synchronizationManager, definition, transaction, true, false, debugEnabled, suspendedResourcesHolder);
/*      */ 
/*      */ 
/*      */             
/*      */             this.transactionExecutionListeners.forEach(());
/*      */ 
/*      */ 
/*      */             
/*      */             return doBegin(synchronizationManager, transaction, definition).doOnSuccess(()).doOnError(()).thenReturn(status).doOnSuccess(()).onErrorResume(ErrorPredicates.RUNTIME_OR_ERROR, ());
/*      */           });
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  226 */     if (definition.getPropagationBehavior() == 6) {
/*  227 */       if (debugEnabled) {
/*  228 */         this.logger.debug("Creating nested transaction with name [" + definition.getName() + "]");
/*      */       }
/*      */       
/*  231 */       GenericReactiveTransaction status = newReactiveTransaction(synchronizationManager, definition, transaction, true, true, debugEnabled, null);
/*      */       
/*  233 */       return doBegin(synchronizationManager, transaction, definition).doOnSuccess(ignore -> prepareSynchronization(synchronizationManager, status, definition))
/*  234 */         .thenReturn(status);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  239 */     if (debugEnabled) {
/*  240 */       this.logger.debug("Participating in existing transaction");
/*      */     }
/*  242 */     return Mono.just(prepareReactiveTransaction(synchronizationManager, definition, transaction, false, debugEnabled, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GenericReactiveTransaction prepareReactiveTransaction(TransactionSynchronizationManager synchronizationManager, TransactionDefinition definition, @Nullable Object transaction, boolean newTransaction, boolean debug, @Nullable Object suspendedResources) {
/*  256 */     GenericReactiveTransaction status = newReactiveTransaction(synchronizationManager, definition, transaction, newTransaction, false, debug, suspendedResources);
/*      */     
/*  258 */     prepareSynchronization(synchronizationManager, status, definition);
/*  259 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GenericReactiveTransaction newReactiveTransaction(TransactionSynchronizationManager synchronizationManager, TransactionDefinition definition, @Nullable Object transaction, boolean newTransaction, boolean nested, boolean debug, @Nullable Object suspendedResources) {
/*  270 */     return new GenericReactiveTransaction(definition.getName(), transaction, newTransaction, 
/*  271 */         !synchronizationManager.isSynchronizationActive(), nested, definition
/*  272 */         .isReadOnly(), debug, suspendedResources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareSynchronization(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status, TransactionDefinition definition) {
/*  281 */     if (status.isNewSynchronization()) {
/*  282 */       synchronizationManager.setActualTransactionActive(status.hasTransaction());
/*  283 */       synchronizationManager.setCurrentTransactionIsolationLevel(
/*  284 */           (definition.getIsolationLevel() != -1) ? 
/*  285 */           Integer.valueOf(definition.getIsolationLevel()) : null);
/*  286 */       synchronizationManager.setCurrentTransactionReadOnly(definition.isReadOnly());
/*  287 */       synchronizationManager.setCurrentTransactionName(definition.getName());
/*  288 */       synchronizationManager.initSynchronization();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<SuspendedResourcesHolder> suspend(TransactionSynchronizationManager synchronizationManager, @Nullable Object transaction) {
/*  307 */     if (synchronizationManager.isSynchronizationActive()) {
/*  308 */       Mono<List<TransactionSynchronization>> suspendedSynchronizations = doSuspendSynchronization(synchronizationManager);
/*  309 */       return suspendedSynchronizations.flatMap(synchronizations -> {
/*      */             Mono<Optional<Object>> suspendedResources = (transaction != null) ? doSuspend(synchronizationManager, transaction).map(Optional::of).defaultIfEmpty(Optional.empty()) : Mono.just(Optional.empty());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             return suspendedResources.map(()).onErrorResume(ErrorPredicates.RUNTIME_OR_ERROR, ());
/*      */           });
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  329 */     if (transaction != null) {
/*      */ 
/*      */       
/*  332 */       Mono<Optional<Object>> suspendedResources = doSuspend(synchronizationManager, transaction).map(Optional::of).defaultIfEmpty(Optional.empty());
/*  333 */       return suspendedResources.map(it -> new SuspendedResourcesHolder(it.orElse(null)));
/*      */     } 
/*      */ 
/*      */     
/*  337 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> resume(TransactionSynchronizationManager synchronizationManager, @Nullable Object transaction, @Nullable SuspendedResourcesHolder resourcesHolder) {
/*  355 */     Mono<Void> resume = Mono.empty();
/*      */     
/*  357 */     if (resourcesHolder != null) {
/*  358 */       Object suspendedResources = resourcesHolder.suspendedResources;
/*  359 */       if (suspendedResources != null) {
/*  360 */         resume = doResume(synchronizationManager, transaction, suspendedResources);
/*      */       }
/*  362 */       List<TransactionSynchronization> suspendedSynchronizations = resourcesHolder.suspendedSynchronizations;
/*  363 */       if (suspendedSynchronizations != null) {
/*  364 */         synchronizationManager.setActualTransactionActive(resourcesHolder.wasActive);
/*  365 */         synchronizationManager.setCurrentTransactionIsolationLevel(resourcesHolder.isolationLevel);
/*  366 */         synchronizationManager.setCurrentTransactionReadOnly(resourcesHolder.readOnly);
/*  367 */         synchronizationManager.setCurrentTransactionName(resourcesHolder.name);
/*  368 */         return resume.then(doResumeSynchronization(synchronizationManager, suspendedSynchronizations));
/*      */       } 
/*      */     } 
/*      */     
/*  372 */     return resume;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> resumeAfterBeginException(TransactionSynchronizationManager synchronizationManager, Object transaction, @Nullable SuspendedResourcesHolder suspendedResources, Throwable beginEx) {
/*  381 */     String exMessage = "Inner transaction begin exception overridden by outer transaction resume exception";
/*  382 */     return resume(synchronizationManager, transaction, suspendedResources).doOnError(ErrorPredicates.RUNTIME_OR_ERROR, ex -> this.logger.error(exMessage, beginEx));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<List<TransactionSynchronization>> doSuspendSynchronization(TransactionSynchronizationManager synchronizationManager) {
/*  395 */     List<TransactionSynchronization> suspendedSynchronizations = synchronizationManager.getSynchronizations();
/*  396 */     return Flux.fromIterable(suspendedSynchronizations)
/*  397 */       .concatMap(TransactionSynchronization::suspend)
/*  398 */       .then(Mono.defer(() -> {
/*      */             synchronizationManager.clearSynchronization();
/*      */             return Mono.just(suspendedSynchronizations);
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> doResumeSynchronization(TransactionSynchronizationManager synchronizationManager, List<TransactionSynchronization> suspendedSynchronizations) {
/*  413 */     synchronizationManager.initSynchronization();
/*  414 */     return Flux.fromIterable(suspendedSynchronizations)
/*  415 */       .concatMap(synchronization -> synchronization.resume().doOnSuccess(()))
/*  416 */       .then();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> commit(ReactiveTransaction transaction) {
/*  431 */     if (transaction.isCompleted()) {
/*  432 */       return Mono.error((Throwable)new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction"));
/*      */     }
/*      */ 
/*      */     
/*  436 */     return TransactionSynchronizationManager.forCurrentTransaction().flatMap(synchronizationManager -> {
/*      */           GenericReactiveTransaction reactiveTx = (GenericReactiveTransaction)transaction;
/*      */           if (reactiveTx.isRollbackOnly()) {
/*      */             if (reactiveTx.isDebug()) {
/*      */               this.logger.debug("Transactional code has requested rollback");
/*      */             }
/*      */             return processRollback(synchronizationManager, reactiveTx);
/*      */           } 
/*      */           return processCommit(synchronizationManager, reactiveTx);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> processCommit(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  457 */     AtomicBoolean beforeCompletionInvoked = new AtomicBoolean();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  506 */     Mono<Void> commit = prepareForCommit(synchronizationManager, status).then(triggerBeforeCommit(synchronizationManager, status)).then(triggerBeforeCompletion(synchronizationManager, status)).then(Mono.defer(() -> { beforeCompletionInvoked.set(true); if (status.isNewTransaction()) { if (status.isDebug()) this.logger.debug("Initiating transaction commit");  this.transactionExecutionListeners.forEach(()); return doCommit(synchronizationManager, status); }  return Mono.empty(); })).onErrorResume(ex -> { Mono<Void> propagateException = Mono.error(ex); Mono<Void> result = propagateException; if (ErrorPredicates.UNEXPECTED_ROLLBACK.test(ex)) { result = triggerAfterCompletion(synchronizationManager, status, 1).then(Mono.defer(())); } else if (ErrorPredicates.TRANSACTION_EXCEPTION.test(ex)) { result = triggerAfterCompletion(synchronizationManager, status, 2).then(Mono.defer(())); } else if (ErrorPredicates.RUNTIME_OR_ERROR.test(ex)) { Mono<Void> mono = Mono.empty(); if (!beforeCompletionInvoked.get()) mono = triggerBeforeCompletion(synchronizationManager, status);  result = mono.then(doRollbackOnCommitException(synchronizationManager, status, ex)).then(propagateException); }  return result; }).then(Mono.defer(() -> triggerAfterCommit(synchronizationManager, status).onErrorResume(()).then(triggerAfterCompletion(synchronizationManager, status, 0)).then(Mono.defer(()))));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  516 */     return commit
/*  517 */       .onErrorResume(ex -> cleanupAfterCompletion(synchronizationManager, status).then(Mono.error(ex)))
/*  518 */       .then(cleanupAfterCompletion(synchronizationManager, status));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> rollback(ReactiveTransaction transaction) {
/*  529 */     if (transaction.isCompleted()) {
/*  530 */       return Mono.error((Throwable)new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction"));
/*      */     }
/*      */     
/*  533 */     return TransactionSynchronizationManager.forCurrentTransaction().flatMap(synchronizationManager -> {
/*      */           GenericReactiveTransaction reactiveTx = (GenericReactiveTransaction)transaction;
/*      */           return processRollback(synchronizationManager, reactiveTx);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> processRollback(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  548 */     return triggerBeforeCompletion(synchronizationManager, status).then(Mono.defer(() -> {
/*      */             if (status.isNewTransaction()) {
/*      */               if (status.isDebug()) {
/*      */                 this.logger.debug("Initiating transaction rollback");
/*      */               }
/*      */               
/*      */               this.transactionExecutionListeners.forEach(());
/*      */               
/*      */               return doRollback(synchronizationManager, status);
/*      */             } 
/*      */             
/*      */             Mono<Void> beforeCompletion = Mono.empty();
/*      */             
/*      */             if (status.hasTransaction()) {
/*      */               if (status.isDebug()) {
/*      */                 this.logger.debug("Participating transaction failed - marking existing transaction as rollback-only");
/*      */               }
/*      */               beforeCompletion = doSetRollbackOnly(synchronizationManager, status);
/*      */             } else {
/*      */               this.logger.debug("Should roll back transaction but cannot - no transaction available");
/*      */             } 
/*      */             return beforeCompletion;
/*  570 */           })).onErrorResume(ErrorPredicates.RUNTIME_OR_ERROR, ex -> triggerAfterCompletion(synchronizationManager, status, 2).then(Mono.defer(())).then(Mono.error(ex)))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  579 */       .then(Mono.defer(() -> triggerAfterCompletion(synchronizationManager, status, 1)))
/*  580 */       .then(Mono.defer(() -> {
/*      */             if (status.isNewTransaction()) {
/*      */               this.transactionExecutionListeners.forEach(());
/*      */             }
/*      */             
/*      */             return Mono.empty();
/*  586 */           })).onErrorResume(ex -> cleanupAfterCompletion(synchronizationManager, status).then(Mono.error(ex)))
/*  587 */       .then(cleanupAfterCompletion(synchronizationManager, status));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> doRollbackOnCommitException(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status, Throwable ex) {
/*  600 */     return Mono.defer(() -> {
/*      */           if (status.isNewTransaction()) {
/*      */             if (status.isDebug()) {
/*      */               this.logger.debug("Initiating transaction rollback after commit exception", ex);
/*      */             }
/*      */             return doRollback(synchronizationManager, status);
/*      */           } 
/*      */           if (status.hasTransaction()) {
/*      */             if (status.isDebug()) {
/*      */               this.logger.debug("Marking existing transaction as rollback-only after commit exception", ex);
/*      */             }
/*      */             return doSetRollbackOnly(synchronizationManager, status);
/*      */           } 
/*      */           return Mono.empty();
/*  614 */         }).onErrorResume(ErrorPredicates.RUNTIME_OR_ERROR, rbex -> {
/*      */           this.logger.error("Commit exception overridden by rollback exception", ex);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return triggerAfterCompletion(synchronizationManager, status, 2).then(Mono.defer(())).then(Mono.error(rbex));
/*  622 */         }).then(Mono.defer(() -> triggerAfterCompletion(synchronizationManager, status, 1)))
/*  623 */       .then(Mono.defer(() -> {
/*      */             this.transactionExecutionListeners.forEach(());
/*      */             return Mono.empty();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> triggerBeforeCommit(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  638 */     if (status.isNewSynchronization()) {
/*  639 */       return TransactionSynchronizationUtils.triggerBeforeCommit(synchronizationManager
/*  640 */           .getSynchronizations(), status.isReadOnly());
/*      */     }
/*  642 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> triggerBeforeCompletion(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  653 */     if (status.isNewSynchronization()) {
/*  654 */       return TransactionSynchronizationUtils.triggerBeforeCompletion(synchronizationManager.getSynchronizations());
/*      */     }
/*  656 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> triggerAfterCommit(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  667 */     if (status.isNewSynchronization()) {
/*  668 */       return TransactionSynchronizationUtils.invokeAfterCommit(synchronizationManager.getSynchronizations());
/*      */     }
/*  670 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> triggerAfterCompletion(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status, int completionStatus) {
/*  682 */     if (status.isNewSynchronization()) {
/*  683 */       List<TransactionSynchronization> synchronizations = synchronizationManager.getSynchronizations();
/*  684 */       synchronizationManager.clearSynchronization();
/*  685 */       if (!status.hasTransaction() || status.isNewTransaction())
/*      */       {
/*      */         
/*  688 */         return invokeAfterCompletion(synchronizationManager, synchronizations, completionStatus);
/*      */       }
/*  690 */       if (!synchronizations.isEmpty())
/*      */       {
/*      */ 
/*      */         
/*  694 */         return registerAfterCompletionWithExistingTransaction(synchronizationManager, status
/*  695 */             .getTransaction(), synchronizations);
/*      */       }
/*      */     } 
/*  698 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> invokeAfterCompletion(TransactionSynchronizationManager synchronizationManager, List<TransactionSynchronization> synchronizations, int completionStatus) {
/*  718 */     return TransactionSynchronizationUtils.invokeAfterCompletion(synchronizations, completionStatus);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Mono<Void> cleanupAfterCompletion(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  731 */     return Mono.defer(() -> {
/*      */           status.setCompleted();
/*      */           if (status.isNewSynchronization()) {
/*      */             synchronizationManager.clear();
/*      */           }
/*      */           Mono<Void> cleanup = Mono.empty();
/*      */           if (status.isNewTransaction()) {
/*      */             cleanup = doCleanupAfterCompletion(synchronizationManager, status.getTransaction());
/*      */           }
/*      */           if (status.getSuspendedResources() != null) {
/*      */             if (status.isDebug()) {
/*      */               this.logger.debug("Resuming suspended transaction after completion of inner transaction");
/*      */             }
/*      */             Object transaction = status.hasTransaction() ? status.getTransaction() : null;
/*      */             return cleanup.then(resume(synchronizationManager, transaction, (SuspendedResourcesHolder)status.getSuspendedResources()));
/*      */           } 
/*      */           return cleanup;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isExistingTransaction(Object transaction) {
/*  796 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Object> doSuspend(TransactionSynchronizationManager synchronizationManager, Object transaction) {
/*  836 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + 
/*  837 */         getClass().getName() + "] does not support transaction suspension");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Void> doResume(TransactionSynchronizationManager synchronizationManager, @Nullable Object transaction, Object suspendedResources) {
/*  856 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + 
/*  857 */         getClass().getName() + "] does not support transaction suspension");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Void> prepareForCommit(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  873 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Void> doSetRollbackOnly(TransactionSynchronizationManager synchronizationManager, GenericReactiveTransaction status) {
/*  913 */     throw new IllegalTransactionStateException("Participating in existing transactions is not supported - when 'isExistingTransaction' returns true, appropriate 'doSetRollbackOnly' behavior must be provided");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Void> registerAfterCompletionWithExistingTransaction(TransactionSynchronizationManager synchronizationManager, Object transaction, List<TransactionSynchronization> synchronizations) {
/*  936 */     this.logger.debug("Cannot register Spring after-completion synchronization with existing transaction - processing Spring after-completion callbacks immediately, with outcome status 'unknown'");
/*      */     
/*  938 */     return invokeAfterCompletion(synchronizationManager, synchronizations, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<Void> doCleanupAfterCompletion(TransactionSynchronizationManager synchronizationManager, Object transaction) {
/*  952 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/*  962 */     ois.defaultReadObject();
/*      */ 
/*      */     
/*  965 */     this.logger = LogFactory.getLog(getClass());
/*      */   }
/*      */ 
/*      */   
/*      */   protected abstract Object doGetTransaction(TransactionSynchronizationManager paramTransactionSynchronizationManager);
/*      */ 
/*      */   
/*      */   protected abstract Mono<Void> doBegin(TransactionSynchronizationManager paramTransactionSynchronizationManager, Object paramObject, TransactionDefinition paramTransactionDefinition);
/*      */   
/*      */   protected abstract Mono<Void> doCommit(TransactionSynchronizationManager paramTransactionSynchronizationManager, GenericReactiveTransaction paramGenericReactiveTransaction);
/*      */   
/*      */   protected abstract Mono<Void> doRollback(TransactionSynchronizationManager paramTransactionSynchronizationManager, GenericReactiveTransaction paramGenericReactiveTransaction);
/*      */   
/*      */   protected static final class SuspendedResourcesHolder
/*      */   {
/*      */     @Nullable
/*      */     private final Object suspendedResources;
/*      */     @Nullable
/*      */     private List<TransactionSynchronization> suspendedSynchronizations;
/*      */     @Nullable
/*      */     private String name;
/*      */     private boolean readOnly;
/*      */     @Nullable
/*      */     private Integer isolationLevel;
/*      */     private boolean wasActive;
/*      */     
/*      */     private SuspendedResourcesHolder(@Nullable Object suspendedResources) {
/*  992 */       this.suspendedResources = suspendedResources;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private SuspendedResourcesHolder(@Nullable Object suspendedResources, List<TransactionSynchronization> suspendedSynchronizations, @Nullable String name, boolean readOnly, @Nullable Integer isolationLevel, boolean wasActive) {
/*  999 */       this.suspendedResources = suspendedResources;
/* 1000 */       this.suspendedSynchronizations = suspendedSynchronizations;
/* 1001 */       this.name = name;
/* 1002 */       this.readOnly = readOnly;
/* 1003 */       this.isolationLevel = isolationLevel;
/* 1004 */       this.wasActive = wasActive;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum ErrorPredicates
/*      */     implements Predicate<Throwable>
/*      */   {
/* 1017 */     RUNTIME_OR_ERROR
/*      */     {
/*      */       public boolean test(Throwable throwable) {
/* 1020 */         return (throwable instanceof RuntimeException || throwable instanceof Error);
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1027 */     TRANSACTION_EXCEPTION
/*      */     {
/*      */       public boolean test(Throwable throwable) {
/* 1030 */         return throwable instanceof org.springframework.transaction.TransactionException;
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1037 */     UNEXPECTED_ROLLBACK
/*      */     {
/*      */       public boolean test(Throwable throwable) {
/* 1040 */         return throwable instanceof org.springframework.transaction.UnexpectedRollbackException; } }; public abstract boolean test(Throwable param1Throwable); } enum null { public boolean test(Throwable throwable) { return (throwable instanceof RuntimeException || throwable instanceof Error); } } enum null { public boolean test(Throwable throwable) { return throwable instanceof org.springframework.transaction.TransactionException; } } enum null { public boolean test(Throwable throwable) { return throwable instanceof org.springframework.transaction.UnexpectedRollbackException; }
/*      */      }
/*      */ 
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\AbstractReactiveTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */