/*     */ package org.springframework.transaction.reactive;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionContext
/*     */ {
/*     */   @Nullable
/*     */   private final TransactionContext parent;
/*  42 */   private final Map<Object, Object> resources = new LinkedHashMap<>();
/*     */   
/*     */   @Nullable
/*     */   private Set<TransactionSynchronization> synchronizations;
/*     */   
/*     */   @Nullable
/*     */   private volatile String currentTransactionName;
/*     */   
/*     */   private volatile boolean currentTransactionReadOnly;
/*     */   
/*     */   @Nullable
/*     */   private volatile Integer currentTransactionIsolationLevel;
/*     */   
/*     */   private volatile boolean actualTransactionActive;
/*     */ 
/*     */   
/*     */   TransactionContext() {
/*  59 */     this(null);
/*     */   }
/*     */   
/*     */   TransactionContext(@Nullable TransactionContext parent) {
/*  63 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionContext getParent() {
/*  69 */     return this.parent;
/*     */   }
/*     */   
/*     */   public Map<Object, Object> getResources() {
/*  73 */     return this.resources;
/*     */   }
/*     */   
/*     */   public void setSynchronizations(@Nullable Set<TransactionSynchronization> synchronizations) {
/*  77 */     this.synchronizations = synchronizations;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Set<TransactionSynchronization> getSynchronizations() {
/*  82 */     return this.synchronizations;
/*     */   }
/*     */   
/*     */   public void setCurrentTransactionName(@Nullable String currentTransactionName) {
/*  86 */     this.currentTransactionName = currentTransactionName;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getCurrentTransactionName() {
/*  91 */     return this.currentTransactionName;
/*     */   }
/*     */   
/*     */   public void setCurrentTransactionReadOnly(boolean currentTransactionReadOnly) {
/*  95 */     this.currentTransactionReadOnly = currentTransactionReadOnly;
/*     */   }
/*     */   
/*     */   public boolean isCurrentTransactionReadOnly() {
/*  99 */     return this.currentTransactionReadOnly;
/*     */   }
/*     */   
/*     */   public void setCurrentTransactionIsolationLevel(@Nullable Integer currentTransactionIsolationLevel) {
/* 103 */     this.currentTransactionIsolationLevel = currentTransactionIsolationLevel;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Integer getCurrentTransactionIsolationLevel() {
/* 108 */     return this.currentTransactionIsolationLevel;
/*     */   }
/*     */   
/*     */   public void setActualTransactionActive(boolean actualTransactionActive) {
/* 112 */     this.actualTransactionActive = actualTransactionActive;
/*     */   }
/*     */   
/*     */   public boolean isActualTransactionActive() {
/* 116 */     return this.actualTransactionActive;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 121 */     this.synchronizations = null;
/* 122 */     this.currentTransactionName = null;
/* 123 */     this.currentTransactionReadOnly = false;
/* 124 */     this.currentTransactionIsolationLevel = null;
/* 125 */     this.actualTransactionActive = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */