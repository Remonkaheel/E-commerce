/*    */ package org.springframework.transaction.reactive;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\005\020\000\032\026\022\004\022\002H\002 \003*\n\022\004\022\002H\002\030\0010\0010\001\"\004\b\000\020\0022\016\020\004\032\n \003*\004\030\001H\002H\002H\n¢\006\004\b\005\020\006"}, d2 = {"<anonymous>", "Ljava/util/Optional;", "T", "kotlin.jvm.PlatformType", "value", "invoke", "(Ljava/lang/Object;)Ljava/util/Optional;"})
/*    */ final class TransactionalOperatorExtensionsKt$executeAndAwait$3
/*    */   extends Lambda
/*    */   implements Function1<T, Optional<T>>
/*    */ {
/*    */   public static final TransactionalOperatorExtensionsKt$executeAndAwait$3 INSTANCE = new TransactionalOperatorExtensionsKt$executeAndAwait$3();
/*    */   
/*    */   TransactionalOperatorExtensionsKt$executeAndAwait$3() {
/*    */     super(1);
/*    */   }
/*    */   
/*    */   public final Optional<T> invoke(Object value) {
/* 50 */     return Optional.ofNullable((T)value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\reactive\TransactionalOperatorExtensionsKt$executeAndAwait$3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */