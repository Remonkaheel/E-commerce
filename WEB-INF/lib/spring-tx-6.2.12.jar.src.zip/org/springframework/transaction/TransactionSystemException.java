/*    */ package org.springframework.transaction;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionSystemException
/*    */   extends TransactionException
/*    */ {
/*    */   @Nullable
/*    */   private Throwable applicationException;
/*    */   
/*    */   public TransactionSystemException(String msg) {
/* 41 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TransactionSystemException(String msg, Throwable cause) {
/* 50 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initApplicationException(Throwable ex) {
/* 62 */     Assert.notNull(ex, "Application exception must not be null");
/* 63 */     if (this.applicationException != null) {
/* 64 */       throw new IllegalStateException("Already holding an application exception: " + String.valueOf(this.applicationException));
/*    */     }
/* 66 */     this.applicationException = ex;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public final Throwable getApplicationException() {
/* 76 */     return this.applicationException;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Throwable getOriginalException() {
/* 86 */     return (this.applicationException != null) ? this.applicationException : getCause();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(@Nullable Class<?> exType) {
/* 91 */     return (super.contains(exType) || (exType != null && exType.isInstance(this.applicationException)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\TransactionSystemException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */