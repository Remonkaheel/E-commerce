/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTransactionAttribute
/*     */   extends DefaultTransactionDefinition
/*     */   implements TransactionAttribute
/*     */ {
/*     */   @Nullable
/*     */   private String descriptor;
/*     */   @Nullable
/*     */   private String timeoutString;
/*     */   @Nullable
/*     */   private String qualifier;
/*  50 */   private Collection<String> labels = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionAttribute() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionAttribute(TransactionAttribute other) {
/*  74 */     super(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTransactionAttribute(int propagationBehavior) {
/*  87 */     super(propagationBehavior);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescriptor(@Nullable String descriptor) {
/*  97 */     this.descriptor = descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getDescriptor() {
/* 107 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeoutString(@Nullable String timeoutString) {
/* 118 */     this.timeoutString = timeoutString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTimeoutString() {
/* 130 */     return this.timeoutString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(@Nullable String qualifier) {
/* 141 */     this.qualifier = qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getQualifier() {
/* 151 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabels(Collection<String> labels) {
/* 162 */     this.labels = labels;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getLabels() {
/* 167 */     return this.labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rollbackOn(Throwable ex) {
/* 186 */     return (ex instanceof RuntimeException || ex instanceof Error);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveAttributeStrings(@Nullable StringValueResolver resolver) {
/* 198 */     String timeoutString = this.timeoutString;
/* 199 */     if (StringUtils.hasText(timeoutString)) {
/* 200 */       if (resolver != null) {
/* 201 */         timeoutString = resolver.resolveStringValue(timeoutString);
/*     */       }
/* 203 */       if (StringUtils.hasLength(timeoutString)) {
/*     */         try {
/* 205 */           setTimeout(Integer.parseInt(timeoutString));
/*     */         }
/* 207 */         catch (RuntimeException ex) {
/* 208 */           throw new IllegalArgumentException("Invalid timeoutString value \"" + timeoutString + "\"; " + String.valueOf(ex));
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 214 */     if (resolver != null) {
/* 215 */       if (this.qualifier != null) {
/* 216 */         this.qualifier = resolver.resolveStringValue(this.qualifier);
/*     */       }
/* 218 */       Set<String> resolvedLabels = CollectionUtils.newLinkedHashSet(this.labels.size());
/* 219 */       for (String label : this.labels) {
/* 220 */         resolvedLabels.add(resolver.resolveStringValue(label));
/*     */       }
/* 222 */       this.labels = resolvedLabels;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final StringBuilder getAttributeDescription() {
/* 231 */     StringBuilder result = getDefinitionDescription();
/* 232 */     if (StringUtils.hasText(this.qualifier)) {
/* 233 */       result.append("; '").append(this.qualifier).append('\'');
/*     */     }
/* 235 */     if (!this.labels.isEmpty()) {
/* 236 */       result.append("; ").append(this.labels);
/*     */     }
/* 238 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\DefaultTransactionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */