/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.TransactionManager;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TransactionAttributeSourcePointcut
/*     */   extends StaticMethodMatcherPointcut
/*     */   implements Serializable
/*     */ {
/*     */   @Nullable
/*     */   private TransactionAttributeSource transactionAttributeSource;
/*     */   
/*     */   public TransactionAttributeSourcePointcut() {
/*  45 */     setClassFilter(new TransactionAttributeSourceClassFilter());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransactionAttributeSource(@Nullable TransactionAttributeSource transactionAttributeSource) {
/*  50 */     this.transactionAttributeSource = transactionAttributeSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/*  55 */     return (this.transactionAttributeSource == null || this.transactionAttributeSource
/*  56 */       .hasTransactionAttribute(method, targetClass));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  61 */     if (this != other) { if (other instanceof TransactionAttributeSourcePointcut) { TransactionAttributeSourcePointcut that = (TransactionAttributeSourcePointcut)other;
/*  62 */         if (ObjectUtils.nullSafeEquals(this.transactionAttributeSource, that.transactionAttributeSource)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/*  67 */     return TransactionAttributeSourcePointcut.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  72 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class TransactionAttributeSourceClassFilter
/*     */     implements ClassFilter
/*     */   {
/*     */     public boolean matches(Class<?> clazz) {
/*  84 */       if (TransactionalProxy.class.isAssignableFrom(clazz) || TransactionManager.class
/*  85 */         .isAssignableFrom(clazz) || PersistenceExceptionTranslator.class
/*  86 */         .isAssignableFrom(clazz)) {
/*  87 */         return false;
/*     */       }
/*  89 */       return (TransactionAttributeSourcePointcut.this.transactionAttributeSource == null || TransactionAttributeSourcePointcut.this.transactionAttributeSource.isCandidateClass(clazz));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private TransactionAttributeSource getTransactionAttributeSource() {
/*  94 */       return TransactionAttributeSourcePointcut.this.transactionAttributeSource;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/*  99 */       if (this != other) { if (other instanceof TransactionAttributeSourceClassFilter) { TransactionAttributeSourceClassFilter that = (TransactionAttributeSourceClassFilter)other;
/* 100 */           if (ObjectUtils.nullSafeEquals(getTransactionAttributeSource(), that.getTransactionAttributeSource())); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 105 */       return TransactionAttributeSourceClassFilter.class.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 110 */       return TransactionAttributeSourceClassFilter.class.getName() + ": " + TransactionAttributeSourceClassFilter.class.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttributeSourcePointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */