/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodMapTransactionAttributeSource
/*     */   implements TransactionAttributeSource, EmbeddedValueResolverAware, BeanClassLoaderAware, InitializingBean
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<String, TransactionAttribute> methodMap;
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   
/*     */   @Nullable
/*  62 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   
/*     */   private boolean eagerlyInitialized = false;
/*     */   
/*     */   private boolean initialized = false;
/*     */   
/*  69 */   private final Map<Method, TransactionAttribute> transactionAttributeMap = new HashMap<>();
/*     */ 
/*     */   
/*  72 */   private final Map<Method, String> methodNameMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethodMap(Map<String, TransactionAttribute> methodMap) {
/*  88 */     this.methodMap = methodMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/*  93 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/*  98 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 109 */     initMethodMap(this.methodMap);
/* 110 */     this.eagerlyInitialized = true;
/* 111 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initMethodMap(@Nullable Map<String, TransactionAttribute> methodMap) {
/* 120 */     if (methodMap != null) {
/* 121 */       methodMap.forEach(this::addTransactionalMethod);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransactionalMethod(String name, TransactionAttribute attr) {
/* 134 */     Assert.notNull(name, "Name must not be null");
/* 135 */     int lastDotIndex = name.lastIndexOf('.');
/* 136 */     if (lastDotIndex == -1) {
/* 137 */       throw new IllegalArgumentException("'" + name + "' is not a valid method name: format is <fully-qualified class name>.<method-name>");
/*     */     }
/*     */     
/* 140 */     String className = name.substring(0, lastDotIndex);
/* 141 */     String methodName = name.substring(lastDotIndex + 1);
/* 142 */     Class<?> clazz = ClassUtils.resolveClassName(className, this.beanClassLoader);
/* 143 */     addTransactionalMethod(clazz, methodName, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransactionalMethod(Class<?> clazz, String mappedName, TransactionAttribute attr) {
/* 154 */     Assert.notNull(clazz, "Class must not be null");
/* 155 */     Assert.notNull(mappedName, "Mapped name must not be null");
/* 156 */     String name = clazz.getName() + "." + clazz.getName();
/*     */     
/* 158 */     Method[] methods = clazz.getDeclaredMethods();
/* 159 */     List<Method> matchingMethods = new ArrayList<>();
/* 160 */     for (Method method : methods) {
/* 161 */       if (isMatch(method.getName(), mappedName)) {
/* 162 */         matchingMethods.add(method);
/*     */       }
/*     */     } 
/* 165 */     if (matchingMethods.isEmpty()) {
/* 166 */       throw new IllegalArgumentException("Could not find method '" + mappedName + "' on class [" + clazz
/* 167 */           .getName() + "]");
/*     */     }
/*     */ 
/*     */     
/* 171 */     for (Method method : matchingMethods) {
/* 172 */       String regMethodName = this.methodNameMap.get(method);
/* 173 */       if (regMethodName == null || (!regMethodName.equals(name) && regMethodName.length() <= name.length())) {
/*     */ 
/*     */         
/* 176 */         if (this.logger.isDebugEnabled() && regMethodName != null) {
/* 177 */           this.logger.debug("Replacing attribute for transactional method [" + String.valueOf(method) + "]: current name '" + name + "' is more specific than '" + regMethodName + "'");
/*     */         }
/*     */         
/* 180 */         this.methodNameMap.put(method, name);
/* 181 */         addTransactionalMethod(method, attr);
/*     */         continue;
/*     */       } 
/* 184 */       if (this.logger.isDebugEnabled()) {
/* 185 */         this.logger.debug("Keeping attribute for transactional method [" + String.valueOf(method) + "]: current name '" + name + "' is not more specific than '" + regMethodName + "'");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransactionalMethod(Method method, TransactionAttribute attr) {
/* 198 */     Assert.notNull(method, "Method must not be null");
/* 199 */     Assert.notNull(attr, "TransactionAttribute must not be null");
/* 200 */     if (this.logger.isDebugEnabled()) {
/* 201 */       this.logger.debug("Adding transactional method [" + String.valueOf(method) + "] with attribute [" + String.valueOf(attr) + "]");
/*     */     }
/* 203 */     if (this.embeddedValueResolver != null && attr instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)attr;
/* 204 */       dta.resolveAttributeStrings(this.embeddedValueResolver); }
/*     */     
/* 206 */     this.transactionAttributeMap.put(method, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, String mappedName) {
/* 219 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 226 */     if (this.eagerlyInitialized) {
/* 227 */       return this.transactionAttributeMap.get(method);
/*     */     }
/*     */     
/* 230 */     synchronized (this.transactionAttributeMap) {
/* 231 */       if (!this.initialized) {
/* 232 */         initMethodMap(this.methodMap);
/* 233 */         this.initialized = true;
/*     */       } 
/* 235 */       return this.transactionAttributeMap.get(method);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 243 */     if (this != other) { if (other instanceof MethodMapTransactionAttributeSource) { MethodMapTransactionAttributeSource otherTas = (MethodMapTransactionAttributeSource)other;
/* 244 */         if (ObjectUtils.nullSafeEquals(this.methodMap, otherTas.methodMap)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 249 */     return MethodMapTransactionAttributeSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\MethodMapTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */