/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeTransactionAttributeSource
/*    */   implements TransactionAttributeSource, Serializable
/*    */ {
/*    */   private final TransactionAttributeSource[] transactionAttributeSources;
/*    */   
/*    */   public CompositeTransactionAttributeSource(TransactionAttributeSource... transactionAttributeSources) {
/* 43 */     Assert.notNull(transactionAttributeSources, "TransactionAttributeSource array must not be null");
/* 44 */     this.transactionAttributeSources = transactionAttributeSources;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final TransactionAttributeSource[] getTransactionAttributeSources() {
/* 52 */     return this.transactionAttributeSources;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCandidateClass(Class<?> targetClass) {
/* 58 */     for (TransactionAttributeSource source : this.transactionAttributeSources) {
/* 59 */       if (source.isCandidateClass(targetClass)) {
/* 60 */         return true;
/*    */       }
/*    */     } 
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 68 */     for (TransactionAttributeSource source : this.transactionAttributeSources) {
/* 69 */       if (source.hasTransactionAttribute(method, targetClass)) {
/* 70 */         return true;
/*    */       }
/*    */     } 
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 79 */     for (TransactionAttributeSource source : this.transactionAttributeSources) {
/* 80 */       TransactionAttribute attr = source.getTransactionAttribute(method, targetClass);
/* 81 */       if (attr != null) {
/* 82 */         return attr;
/*    */       }
/*    */     } 
/* 85 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\CompositeTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */