package org.springframework.transaction.interceptor;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */