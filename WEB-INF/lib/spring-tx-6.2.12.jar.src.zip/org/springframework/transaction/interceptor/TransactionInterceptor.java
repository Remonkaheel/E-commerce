/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionInterceptor
/*     */   extends TransactionAspectSupport
/*     */   implements MethodInterceptor, Serializable
/*     */ {
/*     */   public TransactionInterceptor() {}
/*     */   
/*     */   public TransactionInterceptor(TransactionManager ptm, TransactionAttributeSource tas) {
/*  76 */     setTransactionManager(ptm);
/*  77 */     setTransactionAttributeSource(tas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public TransactionInterceptor(PlatformTransactionManager ptm, TransactionAttributeSource tas) {
/*  91 */     setTransactionManager((TransactionManager)ptm);
/*  92 */     setTransactionAttributeSource(tas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public TransactionInterceptor(PlatformTransactionManager ptm, Properties attributes) {
/* 105 */     setTransactionManager((TransactionManager)ptm);
/* 106 */     setTransactionAttributes(attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 116 */     Class<?> targetClass = (invocation.getThis() != null) ? AopUtils.getTargetClass(invocation.getThis()) : null;
/*     */ 
/*     */     
/* 119 */     Objects.requireNonNull(invocation); return invokeWithinTransaction(invocation.getMethod(), targetClass, invocation::proceed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream oos) throws IOException {
/* 129 */     oos.defaultWriteObject();
/*     */ 
/*     */     
/* 132 */     oos.writeObject(getTransactionManagerBeanName());
/* 133 */     oos.writeObject(getTransactionManager());
/* 134 */     oos.writeObject(getTransactionAttributeSource());
/* 135 */     oos.writeObject(getBeanFactory());
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 140 */     ois.defaultReadObject();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     setTransactionManagerBeanName((String)ois.readObject());
/* 146 */     setTransactionManager((TransactionManager)ois.readObject());
/* 147 */     setTransactionAttributeSource((TransactionAttributeSource)ois.readObject());
/* 148 */     setBeanFactory((BeanFactory)ois.readObject());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */