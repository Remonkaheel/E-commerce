/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.TransactionManager;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TransactionAttributeSourceClassFilter
/*     */   implements ClassFilter
/*     */ {
/*     */   public boolean matches(Class<?> clazz) {
/*  84 */     if (TransactionalProxy.class.isAssignableFrom(clazz) || TransactionManager.class
/*  85 */       .isAssignableFrom(clazz) || PersistenceExceptionTranslator.class
/*  86 */       .isAssignableFrom(clazz)) {
/*  87 */       return false;
/*     */     }
/*  89 */     return (TransactionAttributeSourcePointcut.this.transactionAttributeSource == null || TransactionAttributeSourcePointcut.this.transactionAttributeSource.isCandidateClass(clazz));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private TransactionAttributeSource getTransactionAttributeSource() {
/*  94 */     return TransactionAttributeSourcePointcut.this.transactionAttributeSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  99 */     if (this != other) { if (other instanceof TransactionAttributeSourceClassFilter) { TransactionAttributeSourceClassFilter that = (TransactionAttributeSourceClassFilter)other;
/* 100 */         if (ObjectUtils.nullSafeEquals(getTransactionAttributeSource(), that.getTransactionAttributeSource())); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 105 */     return TransactionAttributeSourceClassFilter.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 110 */     return TransactionAttributeSourceClassFilter.class.getName() + ": " + TransactionAttributeSourceClassFilter.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttributeSourcePointcut$TransactionAttributeSourceClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */