/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.support.DelegatingTransactionDefinition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DelegatingTransactionAttribute
/*    */   extends DelegatingTransactionDefinition
/*    */   implements TransactionAttribute, Serializable
/*    */ {
/*    */   private final TransactionAttribute targetAttribute;
/*    */   
/*    */   public DelegatingTransactionAttribute(TransactionAttribute targetAttribute) {
/* 47 */     super(targetAttribute);
/* 48 */     this.targetAttribute = targetAttribute;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getQualifier() {
/* 55 */     return this.targetAttribute.getQualifier();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<String> getLabels() {
/* 60 */     return this.targetAttribute.getLabels();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean rollbackOn(Throwable ex) {
/* 65 */     return this.targetAttribute.rollbackOn(ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\DelegatingTransactionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */