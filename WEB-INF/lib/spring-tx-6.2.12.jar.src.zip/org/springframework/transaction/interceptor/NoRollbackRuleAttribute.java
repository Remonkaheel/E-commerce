/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoRollbackRuleAttribute
/*    */   extends RollbackRuleAttribute
/*    */ {
/*    */   public NoRollbackRuleAttribute(Class<?> exceptionType) {
/* 40 */     super(exceptionType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoRollbackRuleAttribute(String exceptionPattern) {
/* 53 */     super(exceptionPattern);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 58 */     return "No" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\NoRollbackRuleAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */