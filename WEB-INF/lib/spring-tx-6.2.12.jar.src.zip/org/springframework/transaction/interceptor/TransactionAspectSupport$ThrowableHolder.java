package org.springframework.transaction.interceptor;

import org.springframework.lang.Nullable;

class ThrowableHolder {
  @Nullable
  public Throwable throwable;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAspectSupport$ThrowableHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */