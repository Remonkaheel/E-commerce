/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatchAlwaysTransactionAttributeSource
/*    */   implements TransactionAttributeSource, Serializable
/*    */ {
/* 42 */   private TransactionAttribute transactionAttribute = new DefaultTransactionAttribute();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransactionAttribute(TransactionAttribute transactionAttribute) {
/* 52 */     if (transactionAttribute instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)transactionAttribute;
/* 53 */       dta.resolveAttributeStrings(null); }
/*    */     
/* 55 */     this.transactionAttribute = transactionAttribute;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 62 */     return ClassUtils.isUserLevelMethod(method) ? this.transactionAttribute : null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 68 */     if (this != other) { if (other instanceof MatchAlwaysTransactionAttributeSource) { MatchAlwaysTransactionAttributeSource that = (MatchAlwaysTransactionAttributeSource)other;
/* 69 */         if (ObjectUtils.nullSafeEquals(this.transactionAttribute, that.transactionAttribute)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 74 */     return MatchAlwaysTransactionAttributeSource.class.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return getClass().getName() + ": " + getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\MatchAlwaysTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */