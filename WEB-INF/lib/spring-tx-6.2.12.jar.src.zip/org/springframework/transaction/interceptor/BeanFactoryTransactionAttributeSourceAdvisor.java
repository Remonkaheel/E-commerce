/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractBeanFactoryPointcutAdvisor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanFactoryTransactionAttributeSourceAdvisor
/*    */   extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/* 36 */   private final TransactionAttributeSourcePointcut pointcut = new TransactionAttributeSourcePointcut();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransactionAttributeSource(TransactionAttributeSource transactionAttributeSource) {
/* 46 */     this.pointcut.setTransactionAttributeSource(transactionAttributeSource);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClassFilter(ClassFilter classFilter) {
/* 54 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 59 */     return (Pointcut)this.pointcut;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\BeanFactoryTransactionAttributeSourceAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */