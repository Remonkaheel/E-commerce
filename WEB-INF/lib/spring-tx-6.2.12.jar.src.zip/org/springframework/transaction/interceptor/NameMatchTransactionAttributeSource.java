/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameMatchTransactionAttributeSource
/*     */   implements TransactionAttributeSource, EmbeddedValueResolverAware, InitializingBean, Serializable
/*     */ {
/*  54 */   protected static final Log logger = LogFactory.getLog(NameMatchTransactionAttributeSource.class);
/*     */ 
/*     */   
/*  57 */   private final Map<String, TransactionAttribute> nameMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNameMap(Map<String, TransactionAttribute> nameMap) {
/*  70 */     nameMap.forEach(this::addTransactionalMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Properties transactionAttributes) {
/*  82 */     TransactionAttributeEditor tae = new TransactionAttributeEditor();
/*  83 */     Enumeration<?> propNames = transactionAttributes.propertyNames();
/*  84 */     while (propNames.hasMoreElements()) {
/*  85 */       String methodName = (String)propNames.nextElement();
/*  86 */       String value = transactionAttributes.getProperty(methodName);
/*  87 */       tae.setAsText(value);
/*  88 */       TransactionAttribute attr = (TransactionAttribute)tae.getValue();
/*  89 */       addTransactionalMethod(methodName, attr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransactionalMethod(String methodName, TransactionAttribute attr) {
/* 101 */     if (logger.isDebugEnabled()) {
/* 102 */       logger.debug("Adding transactional method [" + methodName + "] with attribute [" + String.valueOf(attr) + "]");
/*     */     }
/* 104 */     if (this.embeddedValueResolver != null && attr instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)attr;
/* 105 */       dta.resolveAttributeStrings(this.embeddedValueResolver); }
/*     */     
/* 107 */     this.nameMap.put(methodName, attr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/* 112 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 117 */     for (TransactionAttribute attr : this.nameMap.values()) {
/* 118 */       if (attr instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)attr;
/* 119 */         dta.resolveAttributeStrings(this.embeddedValueResolver); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 128 */     if (!ClassUtils.isUserLevelMethod(method)) {
/* 129 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 133 */     String methodName = method.getName();
/* 134 */     TransactionAttribute attr = this.nameMap.get(methodName);
/*     */     
/* 136 */     if (attr == null) {
/*     */       
/* 138 */       String bestNameMatch = null;
/* 139 */       for (String mappedName : this.nameMap.keySet()) {
/* 140 */         if (isMatch(methodName, mappedName) && (bestNameMatch == null || bestNameMatch
/* 141 */           .length() <= mappedName.length())) {
/* 142 */           attr = this.nameMap.get(mappedName);
/* 143 */           bestNameMatch = mappedName;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     return attr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, String mappedName) {
/* 161 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 167 */     if (this != other) { if (other instanceof NameMatchTransactionAttributeSource) { NameMatchTransactionAttributeSource otherTas = (NameMatchTransactionAttributeSource)other;
/* 168 */         if (ObjectUtils.nullSafeEquals(this.nameMap, otherTas.nameMap)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 173 */     return NameMatchTransactionAttributeSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\NameMatchTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */