/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuleBasedTransactionAttribute
/*     */   extends DefaultTransactionAttribute
/*     */   implements Serializable
/*     */ {
/*     */   public static final String PREFIX_ROLLBACK_RULE = "-";
/*     */   public static final String PREFIX_COMMIT_RULE = "+";
/*     */   @Nullable
/*     */   private List<RollbackRuleAttribute> rollbackRules;
/*     */   
/*     */   public RuleBasedTransactionAttribute() {}
/*     */   
/*     */   public RuleBasedTransactionAttribute(RuleBasedTransactionAttribute other) {
/*  75 */     super(other);
/*  76 */     this.rollbackRules = (other.rollbackRules != null) ? new ArrayList<>(other.rollbackRules) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleBasedTransactionAttribute(int propagationBehavior, List<RollbackRuleAttribute> rollbackRules) {
/*  90 */     super(propagationBehavior);
/*  91 */     this.rollbackRules = rollbackRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollbackRules(List<RollbackRuleAttribute> rollbackRules) {
/* 102 */     this.rollbackRules = rollbackRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RollbackRuleAttribute> getRollbackRules() {
/* 110 */     if (this.rollbackRules == null) {
/* 111 */       this.rollbackRules = new ArrayList<>();
/*     */     }
/* 113 */     return this.rollbackRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rollbackOn(Throwable ex) {
/* 125 */     RollbackRuleAttribute winner = null;
/* 126 */     int deepest = Integer.MAX_VALUE;
/*     */     
/* 128 */     if (this.rollbackRules != null) {
/* 129 */       for (RollbackRuleAttribute rule : this.rollbackRules) {
/* 130 */         int depth = rule.getDepth(ex);
/* 131 */         if (depth >= 0 && depth < deepest) {
/* 132 */           deepest = depth;
/* 133 */           winner = rule;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 139 */     if (winner == null) {
/* 140 */       return super.rollbackOn(ex);
/*     */     }
/*     */     
/* 143 */     return !(winner instanceof NoRollbackRuleAttribute);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     StringBuilder result = getAttributeDescription();
/* 150 */     if (this.rollbackRules != null) {
/* 151 */       for (RollbackRuleAttribute rule : this.rollbackRules) {
/* 152 */         String sign = (rule instanceof NoRollbackRuleAttribute) ? "+" : "-";
/* 153 */         result.append(',').append(sign).append(rule.getExceptionName());
/*     */       } 
/*     */     }
/* 156 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\RuleBasedTransactionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */