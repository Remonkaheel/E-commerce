package org.springframework.transaction.interceptor;

import java.util.Collection;
import org.springframework.lang.Nullable;
import org.springframework.transaction.TransactionDefinition;

public interface TransactionAttribute extends TransactionDefinition {
  @Nullable
  String getQualifier();
  
  Collection<String> getLabels();
  
  boolean rollbackOn(Throwable paramThrowable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */