/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollbackRuleAttribute
/*     */   implements Serializable
/*     */ {
/*  65 */   public static final RollbackRuleAttribute ROLLBACK_ON_RUNTIME_EXCEPTIONS = new RollbackRuleAttribute(RuntimeException.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final RollbackRuleAttribute ROLLBACK_ON_ALL_EXCEPTIONS = new RollbackRuleAttribute(Exception.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String exceptionPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Class<? extends Throwable> exceptionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RollbackRuleAttribute(Class<?> exceptionType) {
/* 109 */     Assert.notNull(exceptionType, "'exceptionType' cannot be null");
/* 110 */     if (!Throwable.class.isAssignableFrom(exceptionType)) {
/* 111 */       throw new IllegalArgumentException("Cannot construct rollback rule from [" + exceptionType
/* 112 */           .getName() + "]: it's not a Throwable");
/*     */     }
/* 114 */     this.exceptionPattern = exceptionType.getName();
/* 115 */     this.exceptionType = (Class)exceptionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RollbackRuleAttribute(String exceptionPattern) {
/* 133 */     Assert.hasText(exceptionPattern, "'exceptionPattern' cannot be null or empty");
/* 134 */     this.exceptionPattern = exceptionPattern;
/* 135 */     this.exceptionType = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExceptionName() {
/* 144 */     return this.exceptionPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDepth(Throwable exception) {
/* 166 */     return getDepth(exception.getClass(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getDepth(Class<?> exceptionType, int depth) {
/* 171 */     if (this.exceptionType != null) {
/* 172 */       if (this.exceptionType.equals(exceptionType))
/*     */       {
/* 174 */         return depth;
/*     */       }
/*     */     }
/* 177 */     else if (exceptionType.getName().contains(this.exceptionPattern)) {
/*     */       
/* 179 */       return depth;
/*     */     } 
/*     */     
/* 182 */     if (exceptionType == Throwable.class) {
/* 183 */       return -1;
/*     */     }
/* 185 */     return getDepth(exceptionType.getSuperclass(), depth + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 191 */     if (this != other) { if (other instanceof RollbackRuleAttribute) { RollbackRuleAttribute that = (RollbackRuleAttribute)other; if (this.exceptionPattern
/* 192 */           .equals(that.exceptionPattern)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 197 */     return this.exceptionPattern.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return "RollbackRuleAttribute with pattern [" + this.exceptionPattern + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\RollbackRuleAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */