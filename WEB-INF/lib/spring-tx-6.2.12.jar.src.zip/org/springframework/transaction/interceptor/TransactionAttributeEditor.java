/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionAttributeEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text) throws IllegalArgumentException {
/* 50 */     if (StringUtils.hasLength(text)) {
/*    */       
/* 52 */       String[] tokens = StringUtils.commaDelimitedListToStringArray(text);
/* 53 */       RuleBasedTransactionAttribute attr = new RuleBasedTransactionAttribute();
/* 54 */       for (String token : tokens) {
/*    */         
/* 56 */         String trimmedToken = token.strip();
/*    */         
/* 58 */         if (StringUtils.containsWhitespace(trimmedToken)) {
/* 59 */           throw new IllegalArgumentException("Transaction attribute token contains illegal whitespace: [" + trimmedToken + "]");
/*    */         }
/*    */ 
/*    */         
/* 63 */         if (trimmedToken.startsWith("PROPAGATION_")) {
/* 64 */           attr.setPropagationBehaviorName(trimmedToken);
/*    */         }
/* 66 */         else if (trimmedToken.startsWith("ISOLATION_")) {
/* 67 */           attr.setIsolationLevelName(trimmedToken);
/*    */         }
/* 69 */         else if (trimmedToken.startsWith("timeout_")) {
/* 70 */           String value = trimmedToken.substring("timeout_".length());
/* 71 */           attr.setTimeoutString(value);
/*    */         }
/* 73 */         else if (trimmedToken.equals("readOnly")) {
/* 74 */           attr.setReadOnly(true);
/*    */         }
/* 76 */         else if (trimmedToken.startsWith("+")) {
/* 77 */           attr.getRollbackRules().add(new NoRollbackRuleAttribute(trimmedToken.substring(1)));
/*    */         }
/* 79 */         else if (trimmedToken.startsWith("-")) {
/* 80 */           attr.getRollbackRules().add(new RollbackRuleAttribute(trimmedToken.substring(1)));
/*    */         } else {
/*    */           
/* 83 */           throw new IllegalArgumentException("Invalid transaction attribute token: [" + trimmedToken + "]");
/*    */         } 
/*    */       } 
/* 86 */       attr.resolveAttributeStrings((StringValueResolver)null);
/* 87 */       setValue(attr);
/*    */     } else {
/*    */       
/* 90 */       setValue(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttributeEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */