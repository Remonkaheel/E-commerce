/*     */ package org.springframework.transaction.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFallbackTransactionAttributeSource
/*     */   implements TransactionAttributeSource, EmbeddedValueResolverAware
/*     */ {
/*  58 */   private static final TransactionAttribute NULL_TRANSACTION_ATTRIBUTE = new DefaultTransactionAttribute()
/*     */     {
/*     */       public String toString() {
/*  61 */         return "null";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private transient StringValueResolver embeddedValueResolver;
/*     */ 
/*     */ 
/*     */   
/*  81 */   private final Map<Object, TransactionAttribute> attributeCache = new ConcurrentHashMap<>(1024);
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/*  86 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/*  92 */     return (getTransactionAttribute(method, targetClass, false) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/*  98 */     return getTransactionAttribute(method, targetClass, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TransactionAttribute getTransactionAttribute(Method method, @Nullable Class<?> targetClass, boolean cacheNull) {
/* 114 */     if (ReflectionUtils.isObjectMethod(method)) {
/* 115 */       return null;
/*     */     }
/*     */     
/* 118 */     Object cacheKey = getCacheKey(method, targetClass);
/* 119 */     TransactionAttribute cached = this.attributeCache.get(cacheKey);
/*     */     
/* 121 */     if (cached != null) {
/* 122 */       return (cached != NULL_TRANSACTION_ATTRIBUTE) ? cached : null;
/*     */     }
/*     */     
/* 125 */     TransactionAttribute txAttr = computeTransactionAttribute(method, targetClass);
/* 126 */     if (txAttr != null) {
/* 127 */       String methodIdentification = ClassUtils.getQualifiedMethodName(method, targetClass);
/* 128 */       if (txAttr instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)txAttr;
/* 129 */         dta.setDescriptor(methodIdentification);
/* 130 */         dta.resolveAttributeStrings(this.embeddedValueResolver); }
/*     */       
/* 132 */       if (this.logger.isTraceEnabled()) {
/* 133 */         this.logger.trace("Adding transactional method '" + methodIdentification + "' with attribute: " + String.valueOf(txAttr));
/*     */       }
/* 135 */       this.attributeCache.put(cacheKey, txAttr);
/*     */     }
/* 137 */     else if (cacheNull) {
/* 138 */       this.attributeCache.put(cacheKey, NULL_TRANSACTION_ATTRIBUTE);
/*     */     } 
/* 140 */     return txAttr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getCacheKey(Method method, @Nullable Class<?> targetClass) {
/* 153 */     return new MethodClassKey(method, targetClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TransactionAttribute computeTransactionAttribute(Method method, @Nullable Class<?> targetClass) {
/* 166 */     if (allowPublicMethodsOnly() && !Modifier.isPublic(method.getModifiers())) {
/* 167 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 172 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/*     */ 
/*     */     
/* 175 */     TransactionAttribute txAttr = findTransactionAttribute(specificMethod);
/* 176 */     if (txAttr != null) {
/* 177 */       return txAttr;
/*     */     }
/*     */ 
/*     */     
/* 181 */     txAttr = findTransactionAttribute(specificMethod.getDeclaringClass());
/* 182 */     if (txAttr != null && ClassUtils.isUserLevelMethod(method)) {
/* 183 */       return txAttr;
/*     */     }
/*     */     
/* 186 */     if (specificMethod != method) {
/*     */       
/* 188 */       txAttr = findTransactionAttribute(method);
/* 189 */       if (txAttr != null) {
/* 190 */         return txAttr;
/*     */       }
/*     */       
/* 193 */       txAttr = findTransactionAttribute(method.getDeclaringClass());
/* 194 */       if (txAttr != null && ClassUtils.isUserLevelMethod(method)) {
/* 195 */         return txAttr;
/*     */       }
/*     */     } 
/*     */     
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract TransactionAttribute findTransactionAttribute(Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract TransactionAttribute findTransactionAttribute(Method paramMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPublicMethodsOnly() {
/* 226 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\AbstractFallbackTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */