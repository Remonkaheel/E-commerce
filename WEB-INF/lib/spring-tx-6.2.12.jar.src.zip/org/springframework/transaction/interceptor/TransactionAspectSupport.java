/*      */ package org.springframework.transaction.interceptor;
/*      */ 
/*      */ import io.vavr.control.Try;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Future;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.ReactiveAdapter;
/*      */ import org.springframework.core.ReactiveAdapterRegistry;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.transaction.NoTransactionException;
/*      */ import org.springframework.transaction.PlatformTransactionManager;
/*      */ import org.springframework.transaction.ReactiveTransaction;
/*      */ import org.springframework.transaction.ReactiveTransactionManager;
/*      */ import org.springframework.transaction.TransactionManager;
/*      */ import org.springframework.transaction.TransactionStatus;
/*      */ import org.springframework.transaction.TransactionSystemException;
/*      */ import org.springframework.transaction.reactive.TransactionContext;
/*      */ import org.springframework.transaction.reactive.TransactionContextManager;
/*      */ import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ConcurrentReferenceHashMap;
/*      */ import org.springframework.util.StringUtils;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class TransactionAspectSupport
/*      */   implements BeanFactoryAware, InitializingBean
/*      */ {
/*  100 */   private static final Object DEFAULT_TRANSACTION_MANAGER_KEY = new Object();
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/*      */ 
/*      */   
/*  107 */   private static final boolean reactiveStreamsPresent = ClassUtils.isPresent("org.reactivestreams.Publisher", TransactionAspectSupport.class
/*  108 */       .getClassLoader());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private static final boolean vavrPresent = ClassUtils.isPresent("io.vavr.control.Try", TransactionAspectSupport.class
/*  114 */       .getClassLoader());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   private static final ThreadLocal<TransactionInfo> transactionInfoHolder = (ThreadLocal<TransactionInfo>)new NamedThreadLocal("Current aspect-driven transaction");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected static TransactionInfo currentTransactionInfo() throws NoTransactionException {
/*  145 */     return transactionInfoHolder.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TransactionStatus currentTransactionStatus() throws NoTransactionException {
/*  163 */     TransactionInfo info = currentTransactionInfo();
/*  164 */     if (info == null || info.transactionStatus == null) {
/*  165 */       throw new NoTransactionException("No transaction aspect-managed TransactionStatus in scope");
/*      */     }
/*  167 */     return info.transactionStatus;
/*      */   }
/*      */ 
/*      */   
/*  171 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*      */   @Nullable
/*      */   private final ReactiveAdapterRegistry reactiveAdapterRegistry;
/*      */   
/*      */   @Nullable
/*      */   private String transactionManagerBeanName;
/*      */   
/*      */   @Nullable
/*      */   private TransactionManager transactionManager;
/*      */   
/*      */   @Nullable
/*      */   private TransactionAttributeSource transactionAttributeSource;
/*      */   
/*      */   @Nullable
/*      */   private BeanFactory beanFactory;
/*      */   
/*  188 */   private final ConcurrentMap<Object, TransactionManager> transactionManagerCache = (ConcurrentMap<Object, TransactionManager>)new ConcurrentReferenceHashMap(4);
/*      */ 
/*      */   
/*  191 */   private final ConcurrentMap<Method, ReactiveTransactionSupport> transactionSupportCache = (ConcurrentMap<Method, ReactiveTransactionSupport>)new ConcurrentReferenceHashMap(1024);
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionAspectSupport() {
/*  196 */     if (reactiveStreamsPresent) {
/*  197 */       this.reactiveAdapterRegistry = ReactiveAdapterRegistry.getSharedInstance();
/*      */     } else {
/*      */       
/*  200 */       this.reactiveAdapterRegistry = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionManagerBeanName(@Nullable String transactionManagerBeanName) {
/*  211 */     this.transactionManagerBeanName = transactionManagerBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected final String getTransactionManagerBeanName() {
/*  219 */     return this.transactionManagerBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionManager(@Nullable TransactionManager transactionManager) {
/*  232 */     this.transactionManager = transactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public TransactionManager getTransactionManager() {
/*  242 */     return this.transactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionAttributes(Properties transactionAttributes) {
/*  258 */     NameMatchTransactionAttributeSource tas = new NameMatchTransactionAttributeSource();
/*  259 */     tas.setProperties(transactionAttributes);
/*  260 */     this.transactionAttributeSource = tas;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionAttributeSources(TransactionAttributeSource... transactionAttributeSources) {
/*  272 */     this.transactionAttributeSource = new CompositeTransactionAttributeSource(transactionAttributeSources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionAttributeSource(@Nullable TransactionAttributeSource transactionAttributeSource) {
/*  285 */     this.transactionAttributeSource = transactionAttributeSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public TransactionAttributeSource getTransactionAttributeSource() {
/*  293 */     return this.transactionAttributeSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanFactory(@Nullable BeanFactory beanFactory) {
/*  301 */     this.beanFactory = beanFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected final BeanFactory getBeanFactory() {
/*  309 */     return this.beanFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterPropertiesSet() {
/*  317 */     if (getTransactionManager() == null && this.beanFactory == null) {
/*  318 */       throw new IllegalStateException("Set the 'transactionManager' property or make sure to run within a BeanFactory containing a TransactionManager bean!");
/*      */     }
/*      */ 
/*      */     
/*  322 */     if (getTransactionAttributeSource() == null) {
/*  323 */       throw new IllegalStateException("Either 'transactionAttributeSource' or 'transactionAttributes' is required: If there are no transactional methods, then don't use a transaction aspect.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object invokeWithinTransaction(Method method, @Nullable Class<?> targetClass, InvocationCallback invocation) throws Throwable {
/*      */     CallbackPreferringPlatformTransactionManager cpptm;
/*      */     Object result;
/*  346 */     TransactionAttributeSource tas = getTransactionAttributeSource();
/*  347 */     TransactionAttribute txAttr = (tas != null) ? tas.getTransactionAttribute(method, targetClass) : null;
/*  348 */     TransactionManager tm = determineTransactionManager(txAttr, targetClass);
/*      */     
/*  350 */     if (this.reactiveAdapterRegistry != null && tm instanceof ReactiveTransactionManager) { ReactiveTransactionManager rtm = (ReactiveTransactionManager)tm;
/*  351 */       boolean isSuspendingFunction = KotlinDetector.isSuspendingFunction(method);
/*      */       
/*  353 */       boolean hasSuspendingFlowReturnType = (isSuspendingFunction && "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName()));
/*      */       
/*  355 */       ReactiveTransactionSupport txSupport = this.transactionSupportCache.computeIfAbsent(method, key -> {
/*      */             Class<?> reactiveType = isSuspendingFunction ? (hasSuspendingFlowReturnType ? Flux.class : Mono.class) : method.getReturnType();
/*      */             
/*      */             ReactiveAdapter adapter = this.reactiveAdapterRegistry.getAdapter(reactiveType);
/*      */             
/*      */             if (adapter == null) {
/*      */               throw new IllegalStateException("Cannot apply reactive transaction to non-reactive return type [" + String.valueOf(method.getReturnType()) + "] with specified transaction manager: " + String.valueOf(tm));
/*      */             }
/*      */             
/*      */             return new ReactiveTransactionSupport(adapter);
/*      */           });
/*  366 */       return txSupport.invokeWithinTransaction(method, targetClass, invocation, txAttr, rtm); }
/*      */ 
/*      */     
/*  369 */     PlatformTransactionManager ptm = asPlatformTransactionManager(tm);
/*  370 */     String joinpointIdentification = methodIdentification(method, targetClass, txAttr);
/*      */     
/*  372 */     if (txAttr != null && ptm instanceof CallbackPreferringPlatformTransactionManager) { cpptm = (CallbackPreferringPlatformTransactionManager)ptm; }
/*      */     else
/*  374 */     { Object retVal; TransactionInfo txInfo = createTransactionIfNecessary(ptm, txAttr, joinpointIdentification);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  380 */         retVal = invocation.proceedWithInvocation();
/*      */       }
/*  382 */       catch (Throwable ex) {
/*      */         
/*  384 */         completeTransactionAfterThrowing(txInfo, ex);
/*  385 */         throw ex;
/*      */       } finally {
/*      */         
/*  388 */         cleanupTransactionInfo(txInfo);
/*      */       } 
/*      */       
/*  391 */       if (retVal != null && txAttr != null)
/*  392 */       { TransactionStatus status = txInfo.getTransactionStatus();
/*  393 */         if (status != null)
/*  394 */         { if (retVal instanceof Future) { Future<?> future = (Future)retVal; if (future.isDone())
/*      */             { try {
/*  396 */                 future.get();
/*      */               }
/*  398 */               catch (ExecutionException ex) {
/*  399 */                 Throwable cause = ex.getCause();
/*  400 */                 Assert.state((cause != null), "Cause must not be null");
/*  401 */                 if (txAttr.rollbackOn(cause)) {
/*  402 */                   status.setRollbackOnly();
/*      */                 }
/*      */               }
/*  405 */               catch (InterruptedException ex) {
/*  406 */                 Thread.currentThread().interrupt();
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  416 */               commitTransactionAfterReturning(txInfo);
/*  417 */               return retVal; }  }  if (vavrPresent && VavrDelegate.isVavrTry(retVal)) retVal = VavrDelegate.evaluateTryFailure(retVal, txAttr, status);  }  }  commitTransactionAfterReturning(txInfo); return retVal; }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  422 */     ThrowableHolder throwableHolder = new ThrowableHolder();
/*      */ 
/*      */     
/*      */     try {
/*  426 */       result = cpptm.execute(txAttr, status -> {
/*      */             TransactionInfo txInfo = prepareTransactionInfo(ptm, txAttr, joinpointIdentification, status);
/*      */             
/*      */             try {
/*      */               Object retVal = invocation.proceedWithInvocation();
/*      */               
/*      */               if (retVal != null && vavrPresent && VavrDelegate.isVavrTry(retVal)) {
/*      */                 retVal = VavrDelegate.evaluateTryFailure(retVal, txAttr, status);
/*      */               }
/*      */               return retVal;
/*  436 */             } catch (Throwable ex) {
/*      */               if (txAttr.rollbackOn(ex)) {
/*      */                 if (ex instanceof RuntimeException) {
/*      */                   RuntimeException runtimeException = (RuntimeException)ex;
/*      */ 
/*      */                   
/*      */                   throw runtimeException;
/*      */                 } 
/*      */ 
/*      */                 
/*      */                 throw new ThrowableHolderException(ex);
/*      */               } 
/*      */ 
/*      */               
/*      */               throwableHolder.throwable = ex;
/*      */               
/*      */               return null;
/*      */             } finally {
/*      */               cleanupTransactionInfo(txInfo);
/*      */             } 
/*      */           });
/*  457 */     } catch (ThrowableHolderException ex) {
/*  458 */       throw ex.getCause();
/*      */     }
/*  460 */     catch (TransactionSystemException ex2) {
/*  461 */       if (throwableHolder.throwable != null) {
/*  462 */         this.logger.error("Application exception overridden by commit exception", throwableHolder.throwable);
/*  463 */         ex2.initApplicationException(throwableHolder.throwable);
/*      */       } 
/*  465 */       throw ex2;
/*      */     }
/*  467 */     catch (Throwable ex2) {
/*  468 */       if (throwableHolder.throwable != null) {
/*  469 */         this.logger.error("Application exception overridden by commit exception", throwableHolder.throwable);
/*      */       }
/*  471 */       throw ex2;
/*      */     } 
/*      */ 
/*      */     
/*  475 */     if (throwableHolder.throwable != null) {
/*  476 */       throw throwableHolder.throwable;
/*      */     }
/*  478 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearTransactionManagerCache() {
/*  486 */     this.transactionManagerCache.clear();
/*  487 */     this.beanFactory = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TransactionManager determineTransactionManager(@Nullable TransactionAttribute txAttr, @Nullable Class<?> targetClass) {
/*  500 */     TransactionManager tm = determineTransactionManager(txAttr);
/*  501 */     if (tm != null) {
/*  502 */       return tm;
/*      */     }
/*      */ 
/*      */     
/*  506 */     if (txAttr == null || this.beanFactory == null) {
/*  507 */       return getTransactionManager();
/*      */     }
/*      */     
/*  510 */     String qualifier = txAttr.getQualifier();
/*  511 */     if (StringUtils.hasText(qualifier)) {
/*  512 */       return determineQualifiedTransactionManager(this.beanFactory, qualifier);
/*      */     }
/*  514 */     if (targetClass != null) {
/*      */       
/*  516 */       String typeQualifier = BeanFactoryAnnotationUtils.getQualifierValue(targetClass);
/*  517 */       if (StringUtils.hasText(typeQualifier)) {
/*      */         try {
/*  519 */           return determineQualifiedTransactionManager(this.beanFactory, typeQualifier);
/*      */         }
/*  521 */         catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  527 */     if (StringUtils.hasText(this.transactionManagerBeanName)) {
/*  528 */       return determineQualifiedTransactionManager(this.beanFactory, this.transactionManagerBeanName);
/*      */     }
/*      */     
/*  531 */     TransactionManager defaultTransactionManager = getTransactionManager();
/*  532 */     if (defaultTransactionManager == null) {
/*  533 */       defaultTransactionManager = this.transactionManagerCache.get(DEFAULT_TRANSACTION_MANAGER_KEY);
/*  534 */       if (defaultTransactionManager == null) {
/*  535 */         defaultTransactionManager = (TransactionManager)this.beanFactory.getBean(TransactionManager.class);
/*  536 */         this.transactionManagerCache.putIfAbsent(DEFAULT_TRANSACTION_MANAGER_KEY, defaultTransactionManager);
/*      */       } 
/*      */     } 
/*      */     
/*  540 */     return defaultTransactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Nullable
/*      */   protected TransactionManager determineTransactionManager(@Nullable TransactionAttribute txAttr) {
/*  551 */     return null;
/*      */   }
/*      */   
/*      */   private TransactionManager determineQualifiedTransactionManager(BeanFactory beanFactory, String qualifier) {
/*  555 */     TransactionManager txManager = this.transactionManagerCache.get(qualifier);
/*  556 */     if (txManager == null) {
/*  557 */       txManager = (TransactionManager)BeanFactoryAnnotationUtils.qualifiedBeanOfType(beanFactory, TransactionManager.class, qualifier);
/*      */       
/*  559 */       this.transactionManagerCache.putIfAbsent(qualifier, txManager);
/*      */     } 
/*  561 */     return txManager;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private PlatformTransactionManager asPlatformTransactionManager(@Nullable Object transactionManager) {
/*  566 */     if (transactionManager == null) {
/*  567 */       return null;
/*      */     }
/*  569 */     if (transactionManager instanceof PlatformTransactionManager) { PlatformTransactionManager ptm = (PlatformTransactionManager)transactionManager;
/*  570 */       return ptm; }
/*      */ 
/*      */     
/*  573 */     throw new IllegalStateException("Specified transaction manager is not a PlatformTransactionManager: " + String.valueOf(transactionManager));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String methodIdentification(Method method, @Nullable Class<?> targetClass, @Nullable TransactionAttribute txAttr) {
/*  581 */     String methodIdentification = methodIdentification(method, targetClass);
/*  582 */     if (methodIdentification == null) {
/*  583 */       if (txAttr instanceof DefaultTransactionAttribute) { DefaultTransactionAttribute dta = (DefaultTransactionAttribute)txAttr;
/*  584 */         methodIdentification = dta.getDescriptor(); }
/*      */       
/*  586 */       if (methodIdentification == null) {
/*  587 */         methodIdentification = ClassUtils.getQualifiedMethodName(method, targetClass);
/*      */       }
/*      */     } 
/*  590 */     return methodIdentification;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected String methodIdentification(Method method, @Nullable Class<?> targetClass) {
/*  607 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionInfo createTransactionIfNecessary(@Nullable PlatformTransactionManager tm, @Nullable TransactionAttribute txAttr, final String joinpointIdentification) {
/*  627 */     if (txAttr != null && txAttr.getName() == null) {
/*  628 */       txAttr = new DelegatingTransactionAttribute(txAttr)
/*      */         {
/*      */           public String getName() {
/*  631 */             return joinpointIdentification;
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*  636 */     TransactionStatus status = null;
/*  637 */     if (txAttr != null) {
/*  638 */       if (tm != null) {
/*  639 */         status = tm.getTransaction(txAttr);
/*      */       
/*      */       }
/*  642 */       else if (this.logger.isDebugEnabled()) {
/*  643 */         this.logger.debug("Skipping transactional joinpoint [" + joinpointIdentification + "] because no transaction manager has been configured");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  648 */     return prepareTransactionInfo(tm, txAttr, joinpointIdentification, status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionInfo prepareTransactionInfo(@Nullable PlatformTransactionManager tm, @Nullable TransactionAttribute txAttr, String joinpointIdentification, @Nullable TransactionStatus status) {
/*  663 */     TransactionInfo txInfo = new TransactionInfo(tm, txAttr, joinpointIdentification);
/*  664 */     if (txAttr != null) {
/*      */       
/*  666 */       if (this.logger.isTraceEnabled()) {
/*  667 */         this.logger.trace("Getting transaction for [" + txInfo.getJoinpointIdentification() + "]");
/*      */       }
/*      */       
/*  670 */       txInfo.newTransactionStatus(status);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  675 */     else if (this.logger.isTraceEnabled()) {
/*  676 */       this.logger.trace("No need to create transaction for [" + joinpointIdentification + "]: This method is not transactional.");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  684 */     txInfo.bindToThread();
/*  685 */     return txInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void commitTransactionAfterReturning(@Nullable TransactionInfo txInfo) {
/*  694 */     if (txInfo != null && txInfo.getTransactionStatus() != null) {
/*  695 */       if (this.logger.isTraceEnabled()) {
/*  696 */         this.logger.trace("Completing transaction for [" + txInfo.getJoinpointIdentification() + "]");
/*      */       }
/*  698 */       txInfo.getTransactionManager().commit(txInfo.getTransactionStatus());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completeTransactionAfterThrowing(@Nullable TransactionInfo txInfo, Throwable ex) {
/*  709 */     if (txInfo != null && txInfo.getTransactionStatus() != null) {
/*  710 */       if (this.logger.isTraceEnabled()) {
/*  711 */         this.logger.trace("Completing transaction for [" + txInfo.getJoinpointIdentification() + "] after exception: " + String.valueOf(ex));
/*      */       }
/*      */       
/*  714 */       if (txInfo.transactionAttribute != null && txInfo.transactionAttribute.rollbackOn(ex)) {
/*      */         try {
/*  716 */           txInfo.getTransactionManager().rollback(txInfo.getTransactionStatus());
/*      */         }
/*  718 */         catch (TransactionSystemException ex2) {
/*  719 */           this.logger.error("Application exception overridden by rollback exception", ex);
/*  720 */           ex2.initApplicationException(ex);
/*  721 */           throw ex2;
/*      */         }
/*  723 */         catch (RuntimeException|Error ex2) {
/*  724 */           this.logger.error("Application exception overridden by rollback exception", ex);
/*  725 */           throw ex2;
/*      */         } 
/*      */       } else {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/*  732 */           txInfo.getTransactionManager().commit(txInfo.getTransactionStatus());
/*      */         }
/*  734 */         catch (TransactionSystemException ex2) {
/*  735 */           this.logger.error("Application exception overridden by commit exception", ex);
/*  736 */           ex2.initApplicationException(ex);
/*  737 */           throw ex2;
/*      */         }
/*  739 */         catch (RuntimeException|Error ex2) {
/*  740 */           this.logger.error("Application exception overridden by commit exception", ex);
/*  741 */           throw ex2;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupTransactionInfo(@Nullable TransactionInfo txInfo) {
/*  753 */     if (txInfo != null) {
/*  754 */       txInfo.restoreThreadLocalStatus();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class TransactionInfo
/*      */   {
/*      */     @Nullable
/*      */     private final PlatformTransactionManager transactionManager;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private final TransactionAttribute transactionAttribute;
/*      */ 
/*      */     
/*      */     private final String joinpointIdentification;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private TransactionStatus transactionStatus;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private TransactionInfo oldTransactionInfo;
/*      */ 
/*      */     
/*      */     public TransactionInfo(@Nullable PlatformTransactionManager transactionManager, @Nullable TransactionAttribute transactionAttribute, String joinpointIdentification) {
/*  782 */       this.transactionManager = transactionManager;
/*  783 */       this.transactionAttribute = transactionAttribute;
/*  784 */       this.joinpointIdentification = joinpointIdentification;
/*      */     }
/*      */     
/*      */     public PlatformTransactionManager getTransactionManager() {
/*  788 */       Assert.state((this.transactionManager != null), "No PlatformTransactionManager set");
/*  789 */       return this.transactionManager;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public TransactionAttribute getTransactionAttribute() {
/*  794 */       return this.transactionAttribute;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getJoinpointIdentification() {
/*  802 */       return this.joinpointIdentification;
/*      */     }
/*      */     
/*      */     public void newTransactionStatus(@Nullable TransactionStatus status) {
/*  806 */       this.transactionStatus = status;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public TransactionStatus getTransactionStatus() {
/*  811 */       return this.transactionStatus;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasTransaction() {
/*  819 */       return (this.transactionStatus != null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void bindToThread() {
/*  825 */       this.oldTransactionInfo = TransactionAspectSupport.transactionInfoHolder.get();
/*  826 */       TransactionAspectSupport.transactionInfoHolder.set(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void restoreThreadLocalStatus() {
/*  832 */       TransactionAspectSupport.transactionInfoHolder.set(this.oldTransactionInfo);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  837 */       return (this.transactionAttribute != null) ? this.transactionAttribute.toString() : "No transaction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ThrowableHolder
/*      */   {
/*      */     @Nullable
/*      */     public Throwable throwable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ThrowableHolderException
/*      */     extends RuntimeException
/*      */   {
/*      */     public ThrowableHolderException(Throwable throwable) {
/*  872 */       super(throwable);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  877 */       Throwable cause = getCause();
/*  878 */       Assert.state((cause != null), "Cause must not be null");
/*  879 */       return cause.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class VavrDelegate
/*      */   {
/*      */     public static boolean isVavrTry(Object retVal) {
/*  890 */       return retVal instanceof Try;
/*      */     }
/*      */     
/*      */     public static Object evaluateTryFailure(Object retVal, TransactionAttribute txAttr, TransactionStatus status) {
/*  894 */       return ((Try)retVal).onFailure(ex -> {
/*      */             if (txAttr.rollbackOn(ex)) {
/*      */               status.setRollbackOnly();
/*      */             }
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ReactiveTransactionSupport
/*      */   {
/*      */     private final ReactiveAdapter adapter;
/*      */ 
/*      */ 
/*      */     
/*      */     public ReactiveTransactionSupport(ReactiveAdapter adapter) {
/*  912 */       this.adapter = adapter;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Object invokeWithinTransaction(Method method, @Nullable Class<?> targetClass, TransactionAspectSupport.InvocationCallback invocation, @Nullable TransactionAttribute txAttr, ReactiveTransactionManager rtm) {
/*  918 */       String joinpointIdentification = TransactionAspectSupport.this.methodIdentification(method, targetClass, txAttr);
/*      */ 
/*      */       
/*  921 */       if (Mono.class.isAssignableFrom(method.getReturnType()) || (KotlinDetector.isSuspendingFunction(method) && 
/*  922 */         !"kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName())))
/*      */       {
/*  924 */         return TransactionContextManager.currentContext().flatMap(context -> Mono.usingWhen((Publisher)createTransactionIfNecessary(rtm, txAttr, joinpointIdentification), (), this::commitTransactionAfterReturning, this::completeTransactionAfterThrowing, this::rollbackTransactionOnCancel).onErrorMap(this::unwrapIfResourceCleanupFailure))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  939 */           .contextWrite(TransactionContextManager.getOrCreateContext())
/*  940 */           .contextWrite(TransactionContextManager.getOrCreateContextHolder());
/*      */       }
/*      */ 
/*      */       
/*  944 */       return this.adapter.fromPublisher((Publisher)TransactionContextManager.currentContext().flatMapMany(context -> Flux.usingWhen((Publisher)createTransactionIfNecessary(rtm, txAttr, joinpointIdentification), (), this::commitTransactionAfterReturning, this::completeTransactionAfterThrowing, this::rollbackTransactionOnCancel).onErrorMap(this::unwrapIfResourceCleanupFailure))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  959 */           .contextWrite(TransactionContextManager.getOrCreateContext())
/*  960 */           .contextWrite(TransactionContextManager.getOrCreateContextHolder()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Mono<TransactionAspectSupport.ReactiveTransactionInfo> createTransactionIfNecessary(ReactiveTransactionManager tm, @Nullable TransactionAttribute txAttr, final String joinpointIdentification) {
/*  968 */       if (txAttr != null && txAttr.getName() == null) {
/*  969 */         txAttr = new DelegatingTransactionAttribute(txAttr)
/*      */           {
/*      */             public String getName() {
/*  972 */               return joinpointIdentification;
/*      */             }
/*      */           };
/*      */       }
/*      */       
/*  977 */       TransactionAttribute attrToUse = txAttr;
/*  978 */       Mono<ReactiveTransaction> tx = (attrToUse != null) ? tm.getReactiveTransaction(attrToUse) : Mono.empty();
/*  979 */       return tx.map(it -> prepareTransactionInfo(tm, attrToUse, joinpointIdentification, it)).switchIfEmpty(
/*  980 */           Mono.defer(() -> Mono.just(prepareTransactionInfo(tm, attrToUse, joinpointIdentification, null))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TransactionAspectSupport.ReactiveTransactionInfo prepareTransactionInfo(@Nullable ReactiveTransactionManager tm, @Nullable TransactionAttribute txAttr, String joinpointIdentification, @Nullable ReactiveTransaction transaction) {
/*  987 */       TransactionAspectSupport.ReactiveTransactionInfo txInfo = new TransactionAspectSupport.ReactiveTransactionInfo(tm, txAttr, joinpointIdentification);
/*  988 */       if (txAttr != null) {
/*      */         
/*  990 */         if (TransactionAspectSupport.this.logger.isTraceEnabled()) {
/*  991 */           TransactionAspectSupport.this.logger.trace("Getting transaction for [" + txInfo.getJoinpointIdentification() + "]");
/*      */         }
/*      */         
/*  994 */         txInfo.newReactiveTransaction(transaction);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  999 */       else if (TransactionAspectSupport.this.logger.isTraceEnabled()) {
/* 1000 */         TransactionAspectSupport.this.logger.trace("Don't need to create transaction for [" + joinpointIdentification + "]: This method isn't transactional.");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1005 */       return txInfo;
/*      */     }
/*      */     
/*      */     private Mono<Void> commitTransactionAfterReturning(@Nullable TransactionAspectSupport.ReactiveTransactionInfo txInfo) {
/* 1009 */       if (txInfo != null && txInfo.getReactiveTransaction() != null) {
/* 1010 */         if (TransactionAspectSupport.this.logger.isTraceEnabled()) {
/* 1011 */           TransactionAspectSupport.this.logger.trace("Completing transaction for [" + txInfo.getJoinpointIdentification() + "]");
/*      */         }
/* 1013 */         return txInfo.getTransactionManager().commit(txInfo.getReactiveTransaction());
/*      */       } 
/* 1015 */       return Mono.empty();
/*      */     }
/*      */     
/*      */     private Mono<Void> rollbackTransactionOnCancel(@Nullable TransactionAspectSupport.ReactiveTransactionInfo txInfo) {
/* 1019 */       if (txInfo != null && txInfo.getReactiveTransaction() != null) {
/* 1020 */         if (TransactionAspectSupport.this.logger.isTraceEnabled()) {
/* 1021 */           TransactionAspectSupport.this.logger.trace("Rolling back transaction for [" + txInfo.getJoinpointIdentification() + "] after cancellation");
/*      */         }
/* 1023 */         return txInfo.getTransactionManager().rollback(txInfo.getReactiveTransaction());
/*      */       } 
/* 1025 */       return Mono.empty();
/*      */     }
/*      */     
/*      */     private Mono<Void> completeTransactionAfterThrowing(@Nullable TransactionAspectSupport.ReactiveTransactionInfo txInfo, Throwable ex) {
/* 1029 */       if (txInfo != null && txInfo.getReactiveTransaction() != null) {
/* 1030 */         if (TransactionAspectSupport.this.logger.isTraceEnabled()) {
/* 1031 */           TransactionAspectSupport.this.logger.trace("Completing transaction for [" + txInfo.getJoinpointIdentification() + "] after exception: " + String.valueOf(ex));
/*      */         }
/*      */         
/* 1034 */         if (txInfo.transactionAttribute != null && txInfo.transactionAttribute.rollbackOn(ex)) {
/* 1035 */           return txInfo.getTransactionManager().rollback(txInfo.getReactiveTransaction()).onErrorMap(ex2 -> {
/*      */                 TransactionAspectSupport.this.logger.error("Application exception overridden by rollback exception", ex);
/*      */                 
/*      */                 if (ex2 instanceof TransactionSystemException) {
/*      */                   TransactionSystemException systemException = (TransactionSystemException)ex2;
/*      */                   
/*      */                   systemException.initApplicationException(ex);
/*      */                 } else {
/*      */                   ex2.addSuppressed(ex);
/*      */                 } 
/*      */                 
/*      */                 return ex2;
/*      */               });
/*      */         }
/*      */         
/* 1050 */         return txInfo.getTransactionManager().commit(txInfo.getReactiveTransaction()).onErrorMap(ex2 -> {
/*      */               TransactionAspectSupport.this.logger.error("Application exception overridden by commit exception", ex);
/*      */               
/*      */               if (ex2 instanceof TransactionSystemException) {
/*      */                 TransactionSystemException systemException = (TransactionSystemException)ex2;
/*      */                 
/*      */                 systemException.initApplicationException(ex);
/*      */               } else {
/*      */                 ex2.addSuppressed(ex);
/*      */               } 
/*      */               return ex2;
/*      */             });
/*      */       } 
/* 1063 */       return Mono.empty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Throwable unwrapIfResourceCleanupFailure(Throwable ex) {
/* 1072 */       if (ex instanceof RuntimeException && ex.getCause() != null) {
/* 1073 */         String msg = ex.getMessage();
/* 1074 */         if (msg != null && msg.startsWith("Async resource cleanup failed")) {
/* 1075 */           return ex.getCause();
/*      */         }
/*      */       } 
/* 1078 */       return ex;
/*      */     }
/*      */   }
/*      */   
/*      */   class null extends DelegatingTransactionAttribute {
/*      */     null(TransactionAttribute targetAttribute) {
/*      */       super(targetAttribute);
/*      */     }
/*      */     
/*      */     public String getName() {
/*      */       return joinpointIdentification;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class ReactiveTransactionInfo {
/*      */     @Nullable
/*      */     private final ReactiveTransactionManager transactionManager;
/*      */     @Nullable
/*      */     private final TransactionAttribute transactionAttribute;
/*      */     private final String joinpointIdentification;
/*      */     @Nullable
/*      */     private ReactiveTransaction reactiveTransaction;
/*      */     
/*      */     public ReactiveTransactionInfo(@Nullable ReactiveTransactionManager transactionManager, @Nullable TransactionAttribute transactionAttribute, String joinpointIdentification) {
/* 1102 */       this.transactionManager = transactionManager;
/* 1103 */       this.transactionAttribute = transactionAttribute;
/* 1104 */       this.joinpointIdentification = joinpointIdentification;
/*      */     }
/*      */     
/*      */     public ReactiveTransactionManager getTransactionManager() {
/* 1108 */       Assert.state((this.transactionManager != null), "No ReactiveTransactionManager set");
/* 1109 */       return this.transactionManager;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public TransactionAttribute getTransactionAttribute() {
/* 1114 */       return this.transactionAttribute;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getJoinpointIdentification() {
/* 1122 */       return this.joinpointIdentification;
/*      */     }
/*      */     
/*      */     public void newReactiveTransaction(@Nullable ReactiveTransaction transaction) {
/* 1126 */       this.reactiveTransaction = transaction;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public ReactiveTransaction getReactiveTransaction() {
/* 1131 */       return this.reactiveTransaction;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1136 */       return (this.transactionAttribute != null) ? this.transactionAttribute.toString() : "No transaction";
/*      */     }
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   protected static interface InvocationCallback {
/*      */     @Nullable
/*      */     Object proceedWithInvocation() throws Throwable;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAspectSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */