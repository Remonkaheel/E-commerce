/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionAttributeSourceAdvisor
/*    */   extends AbstractPointcutAdvisor
/*    */ {
/*    */   @Nullable
/*    */   private TransactionInterceptor transactionInterceptor;
/* 46 */   private final TransactionAttributeSourcePointcut pointcut = new TransactionAttributeSourcePointcut();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TransactionAttributeSourceAdvisor() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TransactionAttributeSourceAdvisor(TransactionInterceptor interceptor) {
/* 60 */     setTransactionInterceptor(interceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransactionInterceptor(TransactionInterceptor interceptor) {
/* 68 */     Assert.notNull(interceptor, "TransactionInterceptor must not be null");
/* 69 */     this.transactionInterceptor = interceptor;
/* 70 */     this.pointcut.setTransactionAttributeSource(interceptor.getTransactionAttributeSource());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClassFilter(ClassFilter classFilter) {
/* 78 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Advice getAdvice() {
/* 84 */     Assert.state((this.transactionInterceptor != null), "No TransactionInterceptor set");
/* 85 */     return (Advice)this.transactionInterceptor;
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 90 */     return (Pointcut)this.pointcut;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttributeSourceAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */