/*    */ package org.springframework.transaction.interceptor;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionAttributeSourceEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text) throws IllegalArgumentException {
/* 54 */     MethodMapTransactionAttributeSource source = new MethodMapTransactionAttributeSource();
/* 55 */     if (StringUtils.hasLength(text)) {
/*    */       
/* 57 */       PropertiesEditor propertiesEditor = new PropertiesEditor();
/* 58 */       propertiesEditor.setAsText(text);
/* 59 */       Properties props = (Properties)propertiesEditor.getValue();
/*    */ 
/*    */       
/* 62 */       TransactionAttributeEditor tae = new TransactionAttributeEditor();
/* 63 */       Enumeration<?> propNames = props.propertyNames();
/* 64 */       while (propNames.hasMoreElements()) {
/* 65 */         String name = (String)propNames.nextElement();
/* 66 */         String value = props.getProperty(name);
/*    */         
/* 68 */         tae.setAsText(value);
/* 69 */         TransactionAttribute attr = (TransactionAttribute)tae.getValue();
/*    */         
/* 71 */         source.addTransactionalMethod(name, attr);
/*    */       } 
/*    */     } 
/* 74 */     setValue(source);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\interceptor\TransactionAttributeSourceEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */