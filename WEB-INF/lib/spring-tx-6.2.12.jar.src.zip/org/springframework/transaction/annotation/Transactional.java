package org.springframework.transaction.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.aot.hint.annotation.Reflective;
import org.springframework.core.annotation.AliasFor;

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Reflective
public @interface Transactional {
  @AliasFor("transactionManager")
  String value() default "";
  
  @AliasFor("value")
  String transactionManager() default "";
  
  String[] label() default {};
  
  Propagation propagation() default Propagation.REQUIRED;
  
  Isolation isolation() default Isolation.DEFAULT;
  
  int timeout() default -1;
  
  String timeoutString() default "";
  
  boolean readOnly() default false;
  
  Class<? extends Throwable>[] rollbackFor() default {};
  
  String[] rollbackForClassName() default {};
  
  Class<? extends Throwable>[] noRollbackFor() default {};
  
  String[] noRollbackForClassName() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\Transactional.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */