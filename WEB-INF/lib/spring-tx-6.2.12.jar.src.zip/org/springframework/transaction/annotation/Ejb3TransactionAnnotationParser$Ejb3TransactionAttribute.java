/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import jakarta.ejb.ApplicationException;
/*    */ import jakarta.ejb.TransactionAttributeType;
/*    */ import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Ejb3TransactionAttribute
/*    */   extends DefaultTransactionAttribute
/*    */ {
/*    */   public Ejb3TransactionAttribute(TransactionAttributeType type) {
/* 81 */     setPropagationBehaviorName("PROPAGATION_" + type.name());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean rollbackOn(Throwable ex) {
/* 86 */     ApplicationException ann = ex.getClass().<ApplicationException>getAnnotation(ApplicationException.class);
/* 87 */     return (ann != null) ? ann.rollback() : super.rollbackOn(ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\Ejb3TransactionAnnotationParser$Ejb3TransactionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */