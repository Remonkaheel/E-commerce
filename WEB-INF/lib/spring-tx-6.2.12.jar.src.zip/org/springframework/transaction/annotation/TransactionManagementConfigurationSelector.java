/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionManagementConfigurationSelector
/*    */   extends AdviceModeImportSelector<EnableTransactionManagement>
/*    */ {
/*    */   protected String[] selectImports(AdviceMode adviceMode) {
/* 48 */     switch (adviceMode) { default: throw new IncompatibleClassChangeError();
/* 49 */       case PROXY: (new String[2])[0] = AutoProxyRegistrar.class.getName(); (new String[2])[1] = ProxyTransactionManagementConfiguration.class
/* 50 */           .getName();
/* 51 */       case ASPECTJ: break; }  return new String[] { determineTransactionAspectClass() };
/*    */   }
/*    */ 
/*    */   
/*    */   private String determineTransactionAspectClass() {
/* 56 */     return ClassUtils.isPresent("jakarta.transaction.Transactional", getClass().getClassLoader()) ? 
/* 57 */       "org.springframework.transaction.aspectj.AspectJJtaTransactionManagementConfiguration" : 
/* 58 */       "org.springframework.transaction.aspectj.AspectJTransactionManagementConfiguration";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionManagementConfigurationSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */