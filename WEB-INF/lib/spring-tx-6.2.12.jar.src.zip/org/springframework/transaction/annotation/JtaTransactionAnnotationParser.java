/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import jakarta.transaction.Transactional;
/*    */ import java.io.Serializable;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JtaTransactionAnnotationParser
/*    */   implements TransactionAnnotationParser, Serializable
/*    */ {
/*    */   public boolean isCandidateClass(Class<?> targetClass) {
/* 46 */     return AnnotationUtils.isCandidateClass(targetClass, Transactional.class);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement element) {
/* 52 */     AnnotationAttributes attributes = AnnotatedElementUtils.getMergedAnnotationAttributes(element, Transactional.class);
/*    */     
/* 54 */     if (attributes != null) {
/* 55 */       return parseTransactionAnnotation(attributes);
/*    */     }
/*    */     
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public TransactionAttribute parseTransactionAnnotation(Transactional ann) {
/* 63 */     return parseTransactionAnnotation(AnnotationUtils.getAnnotationAttributes((Annotation)ann, false, false));
/*    */   }
/*    */   
/*    */   protected TransactionAttribute parseTransactionAnnotation(AnnotationAttributes attributes) {
/* 67 */     RuleBasedTransactionAttribute rbta = new RuleBasedTransactionAttribute();
/*    */     
/* 69 */     rbta.setPropagationBehaviorName("PROPAGATION_" + 
/* 70 */         String.valueOf(attributes.getEnum("value")));
/*    */     
/* 72 */     List<RollbackRuleAttribute> rollbackRules = new ArrayList<>();
/* 73 */     for (Class<?> rbRule : attributes.getClassArray("rollbackOn")) {
/* 74 */       rollbackRules.add(new RollbackRuleAttribute(rbRule));
/*    */     }
/* 76 */     for (Class<?> rbRule : attributes.getClassArray("dontRollbackOn")) {
/* 77 */       rollbackRules.add(new NoRollbackRuleAttribute(rbRule));
/*    */     }
/* 79 */     rbta.setRollbackRules(rollbackRules);
/*    */     
/* 81 */     return (TransactionAttribute)rbta;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 87 */     return other instanceof JtaTransactionAnnotationParser;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 92 */     return JtaTransactionAnnotationParser.class.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\JtaTransactionAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */