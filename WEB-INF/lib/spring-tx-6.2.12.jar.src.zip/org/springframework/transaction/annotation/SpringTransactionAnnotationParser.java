/*     */ package org.springframework.transaction.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*     */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringTransactionAnnotationParser
/*     */   implements TransactionAnnotationParser, Serializable
/*     */ {
/*     */   public boolean isCandidateClass(Class<?> targetClass) {
/*  50 */     return AnnotationUtils.isCandidateClass(targetClass, Transactional.class);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement element) {
/*  56 */     AnnotationAttributes attributes = AnnotatedElementUtils.findMergedAnnotationAttributes(element, Transactional.class, false, false);
/*     */     
/*  58 */     if (attributes != null) {
/*  59 */       return parseTransactionAnnotation(attributes);
/*     */     }
/*     */     
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TransactionAttribute parseTransactionAnnotation(Transactional ann) {
/*  67 */     return parseTransactionAnnotation(AnnotationUtils.getAnnotationAttributes(ann, false, false));
/*     */   }
/*     */   
/*     */   protected TransactionAttribute parseTransactionAnnotation(AnnotationAttributes attributes) {
/*  71 */     RuleBasedTransactionAttribute rbta = new RuleBasedTransactionAttribute();
/*     */     
/*  73 */     Propagation propagation = (Propagation)attributes.getEnum("propagation");
/*  74 */     rbta.setPropagationBehavior(propagation.value());
/*  75 */     Isolation isolation = (Isolation)attributes.getEnum("isolation");
/*  76 */     rbta.setIsolationLevel(isolation.value());
/*     */     
/*  78 */     rbta.setTimeout(attributes.getNumber("timeout").intValue());
/*  79 */     String timeoutString = attributes.getString("timeoutString");
/*  80 */     Assert.isTrue((!StringUtils.hasText(timeoutString) || rbta.getTimeout() < 0), "Specify 'timeout' or 'timeoutString', not both");
/*     */     
/*  82 */     rbta.setTimeoutString(timeoutString);
/*     */     
/*  84 */     rbta.setReadOnly(attributes.getBoolean("readOnly"));
/*  85 */     rbta.setQualifier(attributes.getString("value"));
/*  86 */     rbta.setLabels(Set.of(attributes.getStringArray("label")));
/*     */     
/*  88 */     List<RollbackRuleAttribute> rollbackRules = new ArrayList<>();
/*  89 */     for (Class<?> rbRule : attributes.getClassArray("rollbackFor")) {
/*  90 */       rollbackRules.add(new RollbackRuleAttribute(rbRule));
/*     */     }
/*  92 */     for (String rbRule : attributes.getStringArray("rollbackForClassName")) {
/*  93 */       rollbackRules.add(new RollbackRuleAttribute(rbRule));
/*     */     }
/*  95 */     for (Class<?> rbRule : attributes.getClassArray("noRollbackFor")) {
/*  96 */       rollbackRules.add(new NoRollbackRuleAttribute(rbRule));
/*     */     }
/*  98 */     for (String rbRule : attributes.getStringArray("noRollbackForClassName")) {
/*  99 */       rollbackRules.add(new NoRollbackRuleAttribute(rbRule));
/*     */     }
/* 101 */     rbta.setRollbackRules(rollbackRules);
/*     */     
/* 103 */     return (TransactionAttribute)rbta;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 109 */     return other instanceof SpringTransactionAnnotationParser;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return SpringTransactionAnnotationParser.class.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\SpringTransactionAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */