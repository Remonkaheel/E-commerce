/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportRuntimeHints;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor;
/*    */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*    */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ @ImportRuntimeHints({TransactionRuntimeHints.class})
/*    */ public class ProxyTransactionManagementConfiguration
/*    */   extends AbstractTransactionManagementConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.transaction.config.internalTransactionAdvisor"})
/*    */   @Role(2)
/*    */   public BeanFactoryTransactionAttributeSourceAdvisor transactionAdvisor(TransactionAttributeSource transactionAttributeSource, TransactionInterceptor transactionInterceptor) {
/* 49 */     BeanFactoryTransactionAttributeSourceAdvisor advisor = new BeanFactoryTransactionAttributeSourceAdvisor();
/* 50 */     advisor.setTransactionAttributeSource(transactionAttributeSource);
/* 51 */     advisor.setAdvice((Advice)transactionInterceptor);
/* 52 */     if (this.enableTx != null) {
/* 53 */       advisor.setOrder(((Integer)this.enableTx.getNumber("order")).intValue());
/*    */     }
/* 55 */     return advisor;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public TransactionInterceptor transactionInterceptor(TransactionAttributeSource transactionAttributeSource) {
/* 61 */     TransactionInterceptor interceptor = new TransactionInterceptor();
/* 62 */     interceptor.setTransactionAttributeSource(transactionAttributeSource);
/* 63 */     if (this.txManager != null) {
/* 64 */       interceptor.setTransactionManager(this.txManager);
/*    */     }
/* 66 */     return interceptor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\ProxyTransactionManagementConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */