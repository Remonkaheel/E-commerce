/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.core.annotation.MergedAnnotations;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TransactionBeanRegistrationAotProcessor
/*    */   implements BeanRegistrationAotProcessor
/*    */ {
/*    */   private static final String JAKARTA_TRANSACTIONAL_CLASS_NAME = "jakarta.transaction.Transactional";
/*    */   
/*    */   @Nullable
/*    */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 52 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 53 */     if (isTransactional(beanClass)) {
/* 54 */       return new AotContribution(beanClass);
/*    */     }
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   private boolean isTransactional(Class<?> beanClass) {
/* 60 */     Set<AnnotatedElement> elements = new LinkedHashSet<>();
/* 61 */     elements.add(beanClass);
/* 62 */     Objects.requireNonNull(elements); ReflectionUtils.doWithMethods(beanClass, elements::add);
/* 63 */     for (Class<?> interfaceClass : ClassUtils.getAllInterfacesForClass(beanClass)) {
/* 64 */       elements.add(interfaceClass);
/* 65 */       Objects.requireNonNull(elements); ReflectionUtils.doWithMethods(interfaceClass, elements::add);
/*    */     } 
/* 67 */     return elements.stream().anyMatch(element -> {
/*    */           MergedAnnotations mergedAnnotations = MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY);
/* 69 */           return (mergedAnnotations.isPresent(Transactional.class) || mergedAnnotations.isPresent("jakarta.transaction.Transactional"));
/*    */         });
/*    */   }
/*    */   
/*    */   private static class AotContribution
/*    */     implements BeanRegistrationAotContribution
/*    */   {
/*    */     private final Class<?> beanClass;
/*    */     
/*    */     public AotContribution(Class<?> beanClass) {
/* 79 */       this.beanClass = beanClass;
/*    */     }
/*    */ 
/*    */     
/*    */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 84 */       RuntimeHints runtimeHints = generationContext.getRuntimeHints();
/* 85 */       Class<?>[] proxyInterfaces = ClassUtils.getAllInterfacesForClass(this.beanClass);
/* 86 */       for (Class<?> proxyInterface : proxyInterfaces) {
/* 87 */         runtimeHints.reflection().registerType(proxyInterface, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS });
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */