/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ 


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionManagementConfigurationSelector$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */