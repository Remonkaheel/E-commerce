/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AotContribution
/*    */   implements BeanRegistrationAotContribution
/*    */ {
/*    */   private final Class<?> beanClass;
/*    */   
/*    */   public AotContribution(Class<?> beanClass) {
/* 79 */     this.beanClass = beanClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 84 */     RuntimeHints runtimeHints = generationContext.getRuntimeHints();
/* 85 */     Class<?>[] proxyInterfaces = ClassUtils.getAllInterfacesForClass(this.beanClass);
/* 86 */     for (Class<?> proxyInterface : proxyInterfaces) {
/* 87 */       runtimeHints.reflection().registerType(proxyInterface, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionBeanRegistrationAotProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */