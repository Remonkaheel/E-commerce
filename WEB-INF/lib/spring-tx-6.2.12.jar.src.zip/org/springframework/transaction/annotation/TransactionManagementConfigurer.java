package org.springframework.transaction.annotation;

import org.springframework.transaction.TransactionManager;

public interface TransactionManagementConfigurer {
  TransactionManager annotationDrivenTransactionManager();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionManagementConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */