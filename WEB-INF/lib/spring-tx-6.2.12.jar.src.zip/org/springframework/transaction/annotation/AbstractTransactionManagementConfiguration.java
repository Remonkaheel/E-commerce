/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionManager;
/*    */ import org.springframework.transaction.event.TransactionalEventListenerFactory;
/*    */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*    */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractTransactionManagementConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   @Nullable
/*    */   protected AnnotationAttributes enableTx;
/*    */   @Nullable
/*    */   protected TransactionManager txManager;
/*    */   
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/* 62 */     this.enableTx = AnnotationAttributes.fromMap(importMetadata
/* 63 */         .getAnnotationAttributes(EnableTransactionManagement.class.getName()));
/* 64 */     if (this.enableTx == null) {
/* 65 */       throw new IllegalArgumentException("@EnableTransactionManagement is not present on importing class " + importMetadata
/* 66 */           .getClassName());
/*    */     }
/*    */   }
/*    */   
/*    */   @Autowired(required = false)
/*    */   void setConfigurers(Collection<TransactionManagementConfigurer> configurers) {
/* 72 */     if (CollectionUtils.isEmpty(configurers)) {
/*    */       return;
/*    */     }
/* 75 */     if (configurers.size() > 1) {
/* 76 */       throw new IllegalStateException("Only one TransactionManagementConfigurer may exist");
/*    */     }
/* 78 */     TransactionManagementConfigurer configurer = configurers.iterator().next();
/* 79 */     this.txManager = configurer.annotationDrivenTransactionManager();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public TransactionAttributeSource transactionAttributeSource() {
/* 87 */     AnnotationTransactionAttributeSource tas = new AnnotationTransactionAttributeSource(false);
/*    */     
/* 89 */     if (this.enableTx != null && this.enableTx.getEnum("rollbackOn") == RollbackOn.ALL_EXCEPTIONS) {
/* 90 */       tas.addDefaultRollbackRule(RollbackRuleAttribute.ROLLBACK_ON_ALL_EXCEPTIONS);
/*    */     }
/* 92 */     return (TransactionAttributeSource)tas;
/*    */   }
/*    */   
/*    */   @Bean(name = {"org.springframework.transaction.config.internalTransactionalEventListenerFactory"})
/*    */   @Role(2)
/*    */   public static TransactionalEventListenerFactory transactionalEventListenerFactory() {
/* 98 */     return new RestrictedTransactionalEventListenerFactory();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\AbstractTransactionManagementConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */