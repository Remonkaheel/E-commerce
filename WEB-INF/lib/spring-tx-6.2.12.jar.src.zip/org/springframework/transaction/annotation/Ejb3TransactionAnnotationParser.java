/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import jakarta.ejb.ApplicationException;
/*    */ import jakarta.ejb.TransactionAttribute;
/*    */ import jakarta.ejb.TransactionAttributeType;
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
/*    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ejb3TransactionAnnotationParser
/*    */   implements TransactionAnnotationParser, Serializable
/*    */ {
/*    */   public boolean isCandidateClass(Class<?> targetClass) {
/* 43 */     return AnnotationUtils.isCandidateClass(targetClass, TransactionAttribute.class);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement element) {
/* 49 */     TransactionAttribute ann = element.<TransactionAttribute>getAnnotation(TransactionAttribute.class);
/* 50 */     if (ann != null) {
/* 51 */       return parseTransactionAnnotation(ann);
/*    */     }
/*    */     
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public TransactionAttribute parseTransactionAnnotation(TransactionAttribute ann) {
/* 59 */     return (TransactionAttribute)new Ejb3TransactionAttribute(ann.value());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 65 */     return other instanceof Ejb3TransactionAnnotationParser;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     return Ejb3TransactionAnnotationParser.class.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class Ejb3TransactionAttribute
/*    */     extends DefaultTransactionAttribute
/*    */   {
/*    */     public Ejb3TransactionAttribute(TransactionAttributeType type) {
/* 81 */       setPropagationBehaviorName("PROPAGATION_" + type.name());
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean rollbackOn(Throwable ex) {
/* 86 */       ApplicationException ann = ex.getClass().<ApplicationException>getAnnotation(ApplicationException.class);
/* 87 */       return (ann != null) ? ann.rollback() : super.rollbackOn(ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\Ejb3TransactionAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */