/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.transaction.event.TransactionPhase;
/*    */ import org.springframework.transaction.event.TransactionalApplicationListenerMethodAdapter;
/*    */ import org.springframework.transaction.event.TransactionalEventListenerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestrictedTransactionalEventListenerFactory
/*    */   extends TransactionalEventListenerFactory
/*    */ {
/*    */   public ApplicationListener<?> createApplicationListener(String beanName, Class<?> type, Method method) {
/* 42 */     TransactionalApplicationListenerMethodAdapter adapter = new TransactionalApplicationListenerMethodAdapter(beanName, type, method);
/*    */     
/* 44 */     if (adapter.getTransactionPhase() != TransactionPhase.BEFORE_COMMIT) {
/* 45 */       Transactional txAnn = (Transactional)AnnotatedElementUtils.findMergedAnnotation(method, Transactional.class);
/* 46 */       if (txAnn == null) {
/* 47 */         txAnn = (Transactional)AnnotatedElementUtils.findMergedAnnotation(type, Transactional.class);
/*    */       }
/* 49 */       if (txAnn != null) {
/* 50 */         Propagation propagation = txAnn.propagation();
/* 51 */         if (propagation != Propagation.REQUIRES_NEW && propagation != Propagation.NOT_SUPPORTED) {
/* 52 */           throw new IllegalStateException("@TransactionalEventListener method must not be annotated with @Transactional unless when declared as REQUIRES_NEW or NOT_SUPPORTED: " + String.valueOf(method));
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 57 */     return (ApplicationListener<?>)adapter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\RestrictedTransactionalEventListenerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */