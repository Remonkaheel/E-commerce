/*     */ package org.springframework.transaction.annotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Propagation
/*     */ {
/*  37 */   REQUIRED(0),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   SUPPORTS(1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   MANDATORY(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   REQUIRES_NEW(3),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   NOT_SUPPORTED(4),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   NEVER(5),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   NESTED(6);
/*     */ 
/*     */   
/*     */   private final int value;
/*     */ 
/*     */   
/*     */   Propagation(int value) {
/* 104 */     this.value = value;
/*     */   }
/*     */   
/*     */   public int value() {
/* 108 */     return this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\Propagation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */