/*     */ package org.springframework.transaction.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.interceptor.AbstractFallbackTransactionAttributeSource;
/*     */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*     */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationTransactionAttributeSource
/*     */   extends AbstractFallbackTransactionAttributeSource
/*     */   implements Serializable
/*     */ {
/*     */   private static final boolean jtaPresent;
/*     */   private static final boolean ejb3Present;
/*     */   private final Set<TransactionAnnotationParser> annotationParsers;
/*     */   
/*     */   static {
/*  67 */     ClassLoader classLoader = AnnotationTransactionAttributeSource.class.getClassLoader();
/*  68 */     jtaPresent = ClassUtils.isPresent("jakarta.transaction.Transactional", classLoader);
/*  69 */     ejb3Present = ClassUtils.isPresent("jakarta.ejb.TransactionAttribute", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean publicMethodsOnly = true;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<RollbackRuleAttribute> defaultRollbackRules;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTransactionAttributeSource() {
/*  86 */     if (jtaPresent || ejb3Present) {
/*  87 */       this.annotationParsers = CollectionUtils.newLinkedHashSet(3);
/*  88 */       this.annotationParsers.add(new SpringTransactionAnnotationParser());
/*  89 */       if (jtaPresent) {
/*  90 */         this.annotationParsers.add(new JtaTransactionAnnotationParser());
/*     */       }
/*  92 */       if (ejb3Present) {
/*  93 */         this.annotationParsers.add(new Ejb3TransactionAnnotationParser());
/*     */       }
/*     */     } else {
/*     */       
/*  97 */       this.annotationParsers = Collections.singleton(new SpringTransactionAnnotationParser());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTransactionAttributeSource(boolean publicMethodsOnly) {
/* 112 */     this();
/* 113 */     this.publicMethodsOnly = publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser annotationParser) {
/* 121 */     Assert.notNull(annotationParser, "TransactionAnnotationParser must not be null");
/* 122 */     this.annotationParsers = Collections.singleton(annotationParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser... annotationParsers) {
/* 130 */     Assert.notEmpty((Object[])annotationParsers, "At least one TransactionAnnotationParser needs to be specified");
/* 131 */     this.annotationParsers = Set.of(annotationParsers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicMethodsOnly(boolean publicMethodsOnly) {
/* 142 */     this.publicMethodsOnly = publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefaultRollbackRule(RollbackRuleAttribute rollbackRule) {
/* 160 */     if (this.defaultRollbackRules == null) {
/* 161 */       this.defaultRollbackRules = new LinkedHashSet<>();
/*     */     }
/* 163 */     this.defaultRollbackRules.add(rollbackRule);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCandidateClass(Class<?> targetClass) {
/* 169 */     for (TransactionAnnotationParser parser : this.annotationParsers) {
/* 170 */       if (parser.isCandidateClass(targetClass)) {
/* 171 */         return true;
/*     */       }
/*     */     } 
/* 174 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TransactionAttribute findTransactionAttribute(Class<?> clazz) {
/* 180 */     return determineTransactionAttribute(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TransactionAttribute findTransactionAttribute(Method method) {
/* 186 */     return determineTransactionAttribute(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TransactionAttribute determineTransactionAttribute(AnnotatedElement element) {
/* 201 */     for (TransactionAnnotationParser parser : this.annotationParsers) {
/* 202 */       TransactionAttribute attr = parser.parseTransactionAnnotation(element);
/* 203 */       if (attr != null) {
/* 204 */         if (this.defaultRollbackRules != null && attr instanceof RuleBasedTransactionAttribute) { RuleBasedTransactionAttribute ruleAttr = (RuleBasedTransactionAttribute)attr;
/* 205 */           ruleAttr.getRollbackRules().addAll(this.defaultRollbackRules); }
/*     */         
/* 207 */         return attr;
/*     */       } 
/*     */     } 
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPublicMethodsOnly() {
/* 219 */     return this.publicMethodsOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 225 */     if (this != other) { if (other instanceof AnnotationTransactionAttributeSource) { AnnotationTransactionAttributeSource otherTas = (AnnotationTransactionAttributeSource)other; if (this.annotationParsers
/* 226 */           .equals(otherTas.annotationParsers) && this.publicMethodsOnly == otherTas.publicMethodsOnly); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   }
/*     */   public int hashCode() {
/* 232 */     return this.annotationParsers.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\AnnotationTransactionAttributeSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */