/*    */ package org.springframework.transaction.annotation;
/*    */ 
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TransactionAnnotationParser
/*    */ {
/*    */   default boolean isCandidateClass(Class<?> targetClass) {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   TransactionAttribute parseTransactionAnnotation(AnnotatedElement paramAnnotatedElement);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\annotation\TransactionAnnotationParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */