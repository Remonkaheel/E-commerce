/*    */ package org.springframework.transaction.config;
/*    */ 
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.TransactionSystemException;
/*    */ import org.springframework.transaction.jta.JtaTransactionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.0")
/*    */ public class JtaTransactionManagerFactoryBean
/*    */   implements FactoryBean<JtaTransactionManager>, InitializingBean
/*    */ {
/* 35 */   private final JtaTransactionManager transactionManager = new JtaTransactionManager();
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws TransactionSystemException {
/* 40 */     this.transactionManager.afterPropertiesSet();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public JtaTransactionManager getObject() {
/* 46 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 51 */     return this.transactionManager.getClass();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 56 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\JtaTransactionManagerFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */