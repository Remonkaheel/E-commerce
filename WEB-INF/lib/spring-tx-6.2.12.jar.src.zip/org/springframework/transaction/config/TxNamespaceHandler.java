/*    */ package org.springframework.transaction.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TxNamespaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   static final String TRANSACTION_MANAGER_ATTRIBUTE = "transaction-manager";
/*    */   static final String DEFAULT_TRANSACTION_MANAGER_BEAN_NAME = "transactionManager";
/*    */   
/*    */   static String getTransactionManagerName(Element element) {
/* 48 */     return element.hasAttribute("transaction-manager") ? 
/* 49 */       element.getAttribute("transaction-manager") : "transactionManager";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 55 */     registerBeanDefinitionParser("advice", (BeanDefinitionParser)new TxAdviceBeanDefinitionParser());
/* 56 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 57 */     registerBeanDefinitionParser("jta-transaction-manager", (BeanDefinitionParser)new JtaTransactionManagerBeanDefinitionParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\TxNamespaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */