/*     */ package org.springframework.transaction.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
/*     */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/*     */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/*     */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TxAdviceBeanDefinitionParser
/*     */   extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String METHOD_ELEMENT = "method";
/*     */   private static final String METHOD_NAME_ATTRIBUTE = "name";
/*     */   private static final String ATTRIBUTES_ELEMENT = "attributes";
/*     */   private static final String TIMEOUT_ATTRIBUTE = "timeout";
/*     */   private static final String READ_ONLY_ATTRIBUTE = "read-only";
/*     */   private static final String PROPAGATION_ATTRIBUTE = "propagation";
/*     */   private static final String ISOLATION_ATTRIBUTE = "isolation";
/*     */   private static final String ROLLBACK_FOR_ATTRIBUTE = "rollback-for";
/*     */   private static final String NO_ROLLBACK_FOR_ATTRIBUTE = "no-rollback-for";
/*     */   
/*     */   protected Class<?> getBeanClass(Element element) {
/*  71 */     return TransactionInterceptor.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/*  76 */     builder.addPropertyReference("transactionManager", TxNamespaceHandler.getTransactionManagerName(element));
/*     */     
/*  78 */     List<Element> txAttributes = DomUtils.getChildElementsByTagName(element, "attributes");
/*  79 */     if (txAttributes.size() > 1) {
/*  80 */       parserContext.getReaderContext().error("Element <attributes> is allowed at most once inside element <advice>", element);
/*     */     
/*     */     }
/*  83 */     else if (txAttributes.size() == 1) {
/*     */       
/*  85 */       Element attributeSourceElement = txAttributes.get(0);
/*  86 */       RootBeanDefinition attributeSourceDefinition = parseAttributeSource(attributeSourceElement, parserContext);
/*  87 */       builder.addPropertyValue("transactionAttributeSource", attributeSourceDefinition);
/*     */     }
/*     */     else {
/*     */       
/*  91 */       builder.addPropertyValue("transactionAttributeSource", new RootBeanDefinition("org.springframework.transaction.annotation.AnnotationTransactionAttributeSource"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private RootBeanDefinition parseAttributeSource(Element attrEle, ParserContext parserContext) {
/*  97 */     List<Element> methods = DomUtils.getChildElementsByTagName(attrEle, "method");
/*     */     
/*  99 */     ManagedMap<TypedStringValue, RuleBasedTransactionAttribute> transactionAttributeMap = new ManagedMap(methods.size());
/* 100 */     transactionAttributeMap.setSource(parserContext.extractSource(attrEle));
/*     */     
/* 102 */     for (Element methodEle : methods) {
/* 103 */       String name = methodEle.getAttribute("name");
/* 104 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 105 */       nameHolder.setSource(parserContext.extractSource(methodEle));
/*     */       
/* 107 */       RuleBasedTransactionAttribute attribute = new RuleBasedTransactionAttribute();
/* 108 */       String propagation = methodEle.getAttribute("propagation");
/* 109 */       String isolation = methodEle.getAttribute("isolation");
/* 110 */       String timeout = methodEle.getAttribute("timeout");
/* 111 */       String readOnly = methodEle.getAttribute("read-only");
/* 112 */       if (StringUtils.hasText(propagation)) {
/* 113 */         attribute.setPropagationBehaviorName("PROPAGATION_" + propagation);
/*     */       }
/* 115 */       if (StringUtils.hasText(isolation)) {
/* 116 */         attribute.setIsolationLevelName("ISOLATION_" + isolation);
/*     */       }
/* 118 */       if (StringUtils.hasText(timeout)) {
/* 119 */         attribute.setTimeoutString(timeout);
/*     */       }
/* 121 */       if (StringUtils.hasText(readOnly)) {
/* 122 */         attribute.setReadOnly(Boolean.parseBoolean(methodEle.getAttribute("read-only")));
/*     */       }
/*     */       
/* 125 */       List<RollbackRuleAttribute> rollbackRules = new ArrayList<>(1);
/* 126 */       if (methodEle.hasAttribute("rollback-for")) {
/* 127 */         String rollbackForValue = methodEle.getAttribute("rollback-for");
/* 128 */         addRollbackRuleAttributesTo(rollbackRules, rollbackForValue);
/*     */       } 
/* 130 */       if (methodEle.hasAttribute("no-rollback-for")) {
/* 131 */         String noRollbackForValue = methodEle.getAttribute("no-rollback-for");
/* 132 */         addNoRollbackRuleAttributesTo(rollbackRules, noRollbackForValue);
/*     */       } 
/* 134 */       attribute.setRollbackRules(rollbackRules);
/*     */       
/* 136 */       transactionAttributeMap.put(nameHolder, attribute);
/*     */     } 
/*     */     
/* 139 */     RootBeanDefinition attributeSourceDefinition = new RootBeanDefinition(NameMatchTransactionAttributeSource.class);
/* 140 */     attributeSourceDefinition.setSource(parserContext.extractSource(attrEle));
/* 141 */     attributeSourceDefinition.getPropertyValues().add("nameMap", transactionAttributeMap);
/* 142 */     return attributeSourceDefinition;
/*     */   }
/*     */   
/*     */   private void addRollbackRuleAttributesTo(List<RollbackRuleAttribute> rollbackRules, String rollbackForValue) {
/* 146 */     String[] exceptionTypeNames = StringUtils.commaDelimitedListToStringArray(rollbackForValue);
/* 147 */     for (String typeName : exceptionTypeNames) {
/* 148 */       rollbackRules.add(new RollbackRuleAttribute(typeName.strip()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addNoRollbackRuleAttributesTo(List<RollbackRuleAttribute> rollbackRules, String noRollbackForValue) {
/* 153 */     String[] exceptionTypeNames = StringUtils.commaDelimitedListToStringArray(noRollbackForValue);
/* 154 */     for (String typeName : exceptionTypeNames)
/* 155 */       rollbackRules.add(new NoRollbackRuleAttribute(typeName.strip())); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\TxAdviceBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */