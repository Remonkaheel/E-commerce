/*     */ package org.springframework.transaction.config;
/*     */ 
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.event.TransactionalEventListenerFactory;
/*     */ import org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor;
/*     */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  63 */     registerTransactionalEventListenerFactory(parserContext);
/*  64 */     String mode = element.getAttribute("mode");
/*  65 */     if ("aspectj".equals(mode)) {
/*     */       
/*  67 */       registerTransactionAspect(element, parserContext);
/*  68 */       if (ClassUtils.isPresent("jakarta.transaction.Transactional", getClass().getClassLoader())) {
/*  69 */         registerJtaTransactionAspect(element, parserContext);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  74 */       AopAutoProxyConfigurer.configureAutoProxyCreator(element, parserContext);
/*     */     } 
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   private void registerTransactionAspect(Element element, ParserContext parserContext) {
/*  80 */     String txAspectBeanName = "org.springframework.transaction.config.internalTransactionAspect";
/*  81 */     String txAspectClassName = "org.springframework.transaction.aspectj.AnnotationTransactionAspect";
/*  82 */     if (!parserContext.getRegistry().containsBeanDefinition(txAspectBeanName)) {
/*  83 */       RootBeanDefinition def = new RootBeanDefinition();
/*  84 */       def.setBeanClassName(txAspectClassName);
/*  85 */       def.setFactoryMethodName("aspectOf");
/*  86 */       registerTransactionManager(element, (BeanDefinition)def);
/*  87 */       parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, txAspectBeanName));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerJtaTransactionAspect(Element element, ParserContext parserContext) {
/*  92 */     String txAspectBeanName = "org.springframework.transaction.config.internalJtaTransactionAspect";
/*  93 */     String txAspectClassName = "org.springframework.transaction.aspectj.JtaAnnotationTransactionAspect";
/*  94 */     if (!parserContext.getRegistry().containsBeanDefinition(txAspectBeanName)) {
/*  95 */       RootBeanDefinition def = new RootBeanDefinition();
/*  96 */       def.setBeanClassName(txAspectClassName);
/*  97 */       def.setFactoryMethodName("aspectOf");
/*  98 */       registerTransactionManager(element, (BeanDefinition)def);
/*  99 */       parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, txAspectBeanName));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void registerTransactionManager(Element element, BeanDefinition def) {
/* 104 */     def.getPropertyValues().add("transactionManagerBeanName", 
/* 105 */         TxNamespaceHandler.getTransactionManagerName(element));
/*     */   }
/*     */   
/*     */   private void registerTransactionalEventListenerFactory(ParserContext parserContext) {
/* 109 */     RootBeanDefinition def = new RootBeanDefinition();
/* 110 */     def.setBeanClass(TransactionalEventListenerFactory.class);
/* 111 */     parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, "org.springframework.transaction.config.internalTransactionalEventListenerFactory"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AopAutoProxyConfigurer
/*     */   {
/*     */     public static void configureAutoProxyCreator(Element element, ParserContext parserContext) {
/* 122 */       AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(parserContext, element);
/*     */       
/* 124 */       String txAdvisorBeanName = "org.springframework.transaction.config.internalTransactionAdvisor";
/* 125 */       if (!parserContext.getRegistry().containsBeanDefinition(txAdvisorBeanName)) {
/* 126 */         Object eleSource = parserContext.extractSource(element);
/*     */ 
/*     */         
/* 129 */         RootBeanDefinition sourceDef = new RootBeanDefinition("org.springframework.transaction.annotation.AnnotationTransactionAttributeSource");
/*     */         
/* 131 */         sourceDef.setSource(eleSource);
/* 132 */         sourceDef.setRole(2);
/* 133 */         String sourceName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)sourceDef);
/*     */ 
/*     */         
/* 136 */         RootBeanDefinition interceptorDef = new RootBeanDefinition(TransactionInterceptor.class);
/* 137 */         interceptorDef.setSource(eleSource);
/* 138 */         interceptorDef.setRole(2);
/* 139 */         AnnotationDrivenBeanDefinitionParser.registerTransactionManager(element, (BeanDefinition)interceptorDef);
/* 140 */         interceptorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 141 */         String interceptorName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)interceptorDef);
/*     */ 
/*     */         
/* 144 */         RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryTransactionAttributeSourceAdvisor.class);
/* 145 */         advisorDef.setSource(eleSource);
/* 146 */         advisorDef.setRole(2);
/* 147 */         advisorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 148 */         advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 149 */         if (element.hasAttribute("order")) {
/* 150 */           advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */         }
/* 152 */         parserContext.getRegistry().registerBeanDefinition(txAdvisorBeanName, (BeanDefinition)advisorDef);
/*     */         
/* 154 */         CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/* 155 */         compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)sourceDef, sourceName));
/* 156 */         compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)interceptorDef, interceptorName));
/* 157 */         compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)advisorDef, txAdvisorBeanName));
/* 158 */         parserContext.registerComponent((ComponentDefinition)compositeDef);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\AnnotationDrivenBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */