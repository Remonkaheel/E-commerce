package org.springframework.transaction.config;

public abstract class TransactionManagementConfigUtils {
  public static final String TRANSACTION_ADVISOR_BEAN_NAME = "org.springframework.transaction.config.internalTransactionAdvisor";
  
  public static final String TRANSACTION_ASPECT_BEAN_NAME = "org.springframework.transaction.config.internalTransactionAspect";
  
  public static final String TRANSACTION_ASPECT_CLASS_NAME = "org.springframework.transaction.aspectj.AnnotationTransactionAspect";
  
  public static final String TRANSACTION_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.transaction.aspectj.AspectJTransactionManagementConfiguration";
  
  public static final String JTA_TRANSACTION_ASPECT_BEAN_NAME = "org.springframework.transaction.config.internalJtaTransactionAspect";
  
  public static final String JTA_TRANSACTION_ASPECT_CLASS_NAME = "org.springframework.transaction.aspectj.JtaAnnotationTransactionAspect";
  
  public static final String JTA_TRANSACTION_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.transaction.aspectj.AspectJJtaTransactionManagementConfiguration";
  
  public static final String TRANSACTIONAL_EVENT_LISTENER_FACTORY_BEAN_NAME = "org.springframework.transaction.config.internalTransactionalEventListenerFactory";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\TransactionManagementConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */