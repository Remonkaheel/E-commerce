/*     */ package org.springframework.transaction.config;
/*     */ 
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.transaction.interceptor.BeanFactoryTransactionAttributeSourceAdvisor;
/*     */ import org.springframework.transaction.interceptor.TransactionInterceptor;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AopAutoProxyConfigurer
/*     */ {
/*     */   public static void configureAutoProxyCreator(Element element, ParserContext parserContext) {
/* 122 */     AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(parserContext, element);
/*     */     
/* 124 */     String txAdvisorBeanName = "org.springframework.transaction.config.internalTransactionAdvisor";
/* 125 */     if (!parserContext.getRegistry().containsBeanDefinition(txAdvisorBeanName)) {
/* 126 */       Object eleSource = parserContext.extractSource(element);
/*     */ 
/*     */       
/* 129 */       RootBeanDefinition sourceDef = new RootBeanDefinition("org.springframework.transaction.annotation.AnnotationTransactionAttributeSource");
/*     */       
/* 131 */       sourceDef.setSource(eleSource);
/* 132 */       sourceDef.setRole(2);
/* 133 */       String sourceName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)sourceDef);
/*     */ 
/*     */       
/* 136 */       RootBeanDefinition interceptorDef = new RootBeanDefinition(TransactionInterceptor.class);
/* 137 */       interceptorDef.setSource(eleSource);
/* 138 */       interceptorDef.setRole(2);
/* 139 */       AnnotationDrivenBeanDefinitionParser.registerTransactionManager(element, (BeanDefinition)interceptorDef);
/* 140 */       interceptorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 141 */       String interceptorName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)interceptorDef);
/*     */ 
/*     */       
/* 144 */       RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryTransactionAttributeSourceAdvisor.class);
/* 145 */       advisorDef.setSource(eleSource);
/* 146 */       advisorDef.setRole(2);
/* 147 */       advisorDef.getPropertyValues().add("transactionAttributeSource", new RuntimeBeanReference(sourceName));
/* 148 */       advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 149 */       if (element.hasAttribute("order")) {
/* 150 */         advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */       }
/* 152 */       parserContext.getRegistry().registerBeanDefinition(txAdvisorBeanName, (BeanDefinition)advisorDef);
/*     */       
/* 154 */       CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/* 155 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)sourceDef, sourceName));
/* 156 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)interceptorDef, interceptorName));
/* 157 */       compositeDef.addNestedComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)advisorDef, txAdvisorBeanName));
/* 158 */       parserContext.registerComponent((ComponentDefinition)compositeDef);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\config\AnnotationDrivenBeanDefinitionParser$AopAutoProxyConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */