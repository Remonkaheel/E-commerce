/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import jakarta.transaction.NotSupportedException;
/*    */ import jakarta.transaction.SystemException;
/*    */ import jakarta.transaction.Transaction;
/*    */ import jakarta.transaction.TransactionManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTransactionFactory
/*    */   implements TransactionFactory
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */   
/*    */   public SimpleTransactionFactory(TransactionManager transactionManager) {
/* 49 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 50 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Transaction createTransaction(@Nullable String name, int timeout) throws NotSupportedException, SystemException {
/* 56 */     if (timeout >= 0) {
/* 57 */       this.transactionManager.setTransactionTimeout(timeout);
/*    */     }
/* 59 */     this.transactionManager.begin();
/* 60 */     return new ManagedTransactionAdapter(this.transactionManager);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsResourceAdapterManagedTransactions() {
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\SimpleTransactionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */