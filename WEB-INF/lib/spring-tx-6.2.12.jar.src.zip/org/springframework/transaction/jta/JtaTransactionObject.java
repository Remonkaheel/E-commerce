/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import jakarta.transaction.SystemException;
/*    */ import jakarta.transaction.UserTransaction;
/*    */ import org.springframework.transaction.TransactionSystemException;
/*    */ import org.springframework.transaction.support.SmartTransactionObject;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JtaTransactionObject
/*    */   implements SmartTransactionObject
/*    */ {
/*    */   private final UserTransaction userTransaction;
/*    */   boolean resetTransactionTimeout = false;
/*    */   
/*    */   public JtaTransactionObject(UserTransaction userTransaction) {
/* 51 */     this.userTransaction = userTransaction;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final UserTransaction getUserTransaction() {
/* 58 */     return this.userTransaction;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isRollbackOnly() {
/*    */     try {
/* 68 */       int jtaStatus = this.userTransaction.getStatus();
/* 69 */       return (jtaStatus == 1 || jtaStatus == 4);
/*    */     }
/* 71 */     catch (SystemException ex) {
/* 72 */       throw new TransactionSystemException("JTA failure on getStatus", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void flush() {
/* 83 */     TransactionSynchronizationUtils.triggerFlush();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\JtaTransactionObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */