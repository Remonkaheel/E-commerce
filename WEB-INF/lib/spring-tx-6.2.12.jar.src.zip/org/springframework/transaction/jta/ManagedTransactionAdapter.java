/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import jakarta.transaction.HeuristicMixedException;
/*    */ import jakarta.transaction.HeuristicRollbackException;
/*    */ import jakarta.transaction.RollbackException;
/*    */ import jakarta.transaction.Synchronization;
/*    */ import jakarta.transaction.SystemException;
/*    */ import jakarta.transaction.Transaction;
/*    */ import jakarta.transaction.TransactionManager;
/*    */ import javax.transaction.xa.XAResource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagedTransactionAdapter
/*    */   implements Transaction
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */   
/*    */   public ManagedTransactionAdapter(TransactionManager transactionManager) throws SystemException {
/* 49 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 50 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final TransactionManager getTransactionManager() {
/* 57 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, SystemException {
/* 64 */     this.transactionManager.commit();
/*    */   }
/*    */ 
/*    */   
/*    */   public void rollback() throws SystemException {
/* 69 */     this.transactionManager.rollback();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRollbackOnly() throws SystemException {
/* 74 */     this.transactionManager.setRollbackOnly();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStatus() throws SystemException {
/* 79 */     return this.transactionManager.getStatus();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean enlistResource(XAResource xaRes) throws RollbackException, SystemException {
/* 84 */     return this.transactionManager.getTransaction().enlistResource(xaRes);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean delistResource(XAResource xaRes, int flag) throws SystemException {
/* 89 */     return this.transactionManager.getTransaction().delistResource(xaRes, flag);
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerSynchronization(Synchronization sync) throws RollbackException, SystemException {
/* 94 */     this.transactionManager.getTransaction().registerSynchronization(sync);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\ManagedTransactionAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */