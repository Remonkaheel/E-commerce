/*     */ package org.springframework.transaction.jta;
/*     */ 
/*     */ import jakarta.transaction.Synchronization;
/*     */ import jakarta.transaction.TransactionManager;
/*     */ import jakarta.transaction.UserTransaction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringJtaSynchronizationAdapter
/*     */   implements Synchronization
/*     */ {
/*  47 */   protected static final Log logger = LogFactory.getLog(SpringJtaSynchronizationAdapter.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final TransactionSynchronization springSynchronization;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private UserTransaction jtaTransaction;
/*     */ 
/*     */   
/*     */   private boolean beforeCompletionCalled = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization) {
/*  63 */     Assert.notNull(springSynchronization, "TransactionSynchronization must not be null");
/*  64 */     this.springSynchronization = springSynchronization;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0.12")
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization, @Nullable UserTransaction jtaUserTransaction) {
/*  82 */     this(springSynchronization);
/*  83 */     this.jtaTransaction = jtaUserTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0.12")
/*     */   public SpringJtaSynchronizationAdapter(TransactionSynchronization springSynchronization, @Nullable TransactionManager jtaTransactionManager) {
/* 101 */     this(springSynchronization);
/* 102 */     this
/* 103 */       .jtaTransaction = (jtaTransactionManager != null) ? new UserTransactionAdapter(jtaTransactionManager) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeCompletion() {
/*     */     try {
/* 115 */       boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/* 116 */       this.springSynchronization.beforeCommit(readOnly);
/*     */     }
/* 118 */     catch (RuntimeException|Error ex) {
/* 119 */       setRollbackOnlyIfPossible();
/* 120 */       throw ex;
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 126 */       this.beforeCompletionCalled = true;
/* 127 */       this.springSynchronization.beforeCompletion();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setRollbackOnlyIfPossible() {
/* 135 */     if (this.jtaTransaction != null) {
/*     */       try {
/* 137 */         this.jtaTransaction.setRollbackOnly();
/*     */       }
/* 139 */       catch (UnsupportedOperationException ex) {
/*     */         
/* 141 */         logger.debug("JTA transaction handle does not support setRollbackOnly method - relying on JTA provider to mark the transaction as rollback-only based on the exception thrown from beforeCompletion", ex);
/*     */ 
/*     */       
/*     */       }
/* 145 */       catch (Throwable ex) {
/* 146 */         logger.error("Could not set JTA transaction rollback-only", ex);
/*     */       } 
/*     */     } else {
/*     */       
/* 150 */       logger.debug("No JTA transaction handle available and/or running on WebLogic - relying on JTA provider to mark the transaction as rollback-only based on the exception thrown from beforeCompletion");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterCompletion(int status) {
/* 166 */     if (!this.beforeCompletionCalled)
/*     */     {
/*     */       
/* 169 */       this.springSynchronization.beforeCompletion();
/*     */     }
/*     */     
/* 172 */     switch (status) {
/*     */       case 3:
/* 174 */         this.springSynchronization.afterCompletion(0); return;
/*     */       case 4:
/* 176 */         this.springSynchronization.afterCompletion(1); return;
/*     */     } 
/* 178 */     this.springSynchronization.afterCompletion(2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\SpringJtaSynchronizationAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */