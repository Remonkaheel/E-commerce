/*      */ package org.springframework.transaction.jta;
/*      */ 
/*      */ import jakarta.transaction.HeuristicMixedException;
/*      */ import jakarta.transaction.HeuristicRollbackException;
/*      */ import jakarta.transaction.InvalidTransactionException;
/*      */ import jakarta.transaction.NotSupportedException;
/*      */ import jakarta.transaction.RollbackException;
/*      */ import jakarta.transaction.SystemException;
/*      */ import jakarta.transaction.Transaction;
/*      */ import jakarta.transaction.TransactionManager;
/*      */ import jakarta.transaction.TransactionSynchronizationRegistry;
/*      */ import jakarta.transaction.UserTransaction;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import javax.naming.NamingException;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.jndi.JndiTemplate;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.transaction.CannotCreateTransactionException;
/*      */ import org.springframework.transaction.HeuristicCompletionException;
/*      */ import org.springframework.transaction.IllegalTransactionStateException;
/*      */ import org.springframework.transaction.InvalidIsolationLevelException;
/*      */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*      */ import org.springframework.transaction.TransactionDefinition;
/*      */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*      */ import org.springframework.transaction.TransactionSystemException;
/*      */ import org.springframework.transaction.UnexpectedRollbackException;
/*      */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*      */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*      */ import org.springframework.transaction.support.TransactionSynchronization;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JtaTransactionManager
/*      */   extends AbstractPlatformTransactionManager
/*      */   implements TransactionFactory, InitializingBean, Serializable
/*      */ {
/*      */   public static final String DEFAULT_USER_TRANSACTION_NAME = "java:comp/UserTransaction";
/*  130 */   public static final String[] FALLBACK_TRANSACTION_MANAGER_NAMES = new String[] { "java:comp/TransactionManager", "java:appserver/TransactionManager", "java:pm/TransactionManager", "java:/TransactionManager" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DEFAULT_TRANSACTION_SYNCHRONIZATION_REGISTRY_NAME = "java:comp/TransactionSynchronizationRegistry";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   private transient JndiTemplate jndiTemplate = new JndiTemplate();
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private transient UserTransaction userTransaction;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String userTransactionName;
/*      */ 
/*      */   
/*      */   private boolean autodetectUserTransaction = true;
/*      */ 
/*      */   
/*      */   private boolean cacheUserTransaction = true;
/*      */ 
/*      */   
/*      */   private boolean userTransactionObtainedFromJndi = false;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private transient TransactionManager transactionManager;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String transactionManagerName;
/*      */ 
/*      */   
/*      */   private boolean autodetectTransactionManager = true;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private transient TransactionSynchronizationRegistry transactionSynchronizationRegistry;
/*      */   
/*      */   @Nullable
/*      */   private String transactionSynchronizationRegistryName;
/*      */   
/*      */   private boolean autodetectTransactionSynchronizationRegistry = true;
/*      */   
/*      */   private boolean allowCustomIsolationLevels = false;
/*      */ 
/*      */   
/*      */   public JtaTransactionManager() {
/*  185 */     setNestedTransactionAllowed(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JtaTransactionManager(UserTransaction userTransaction) {
/*  193 */     this();
/*  194 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*  195 */     this.userTransaction = userTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JtaTransactionManager(UserTransaction userTransaction, TransactionManager transactionManager) {
/*  204 */     this();
/*  205 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*  206 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*  207 */     this.userTransaction = userTransaction;
/*  208 */     this.transactionManager = transactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JtaTransactionManager(TransactionManager transactionManager) {
/*  216 */     this();
/*  217 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*  218 */     this.transactionManager = transactionManager;
/*  219 */     this.userTransaction = buildUserTransaction(transactionManager);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJndiTemplate(JndiTemplate jndiTemplate) {
/*  228 */     Assert.notNull(jndiTemplate, "JndiTemplate must not be null");
/*  229 */     this.jndiTemplate = jndiTemplate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JndiTemplate getJndiTemplate() {
/*  236 */     return this.jndiTemplate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJndiEnvironment(@Nullable Properties jndiEnvironment) {
/*  245 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Properties getJndiEnvironment() {
/*  253 */     return this.jndiTemplate.getEnvironment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserTransaction(@Nullable UserTransaction userTransaction) {
/*  265 */     this.userTransaction = userTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public UserTransaction getUserTransaction() {
/*  273 */     return this.userTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUserTransactionName(String userTransactionName) {
/*  285 */     this.userTransactionName = userTransactionName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutodetectUserTransaction(boolean autodetectUserTransaction) {
/*  299 */     this.autodetectUserTransaction = autodetectUserTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheUserTransaction(boolean cacheUserTransaction) {
/*  315 */     this.cacheUserTransaction = cacheUserTransaction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionManager(@Nullable TransactionManager transactionManager) {
/*  329 */     this.transactionManager = transactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public TransactionManager getTransactionManager() {
/*  337 */     return this.transactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionManagerName(String transactionManagerName) {
/*  351 */     this.transactionManagerName = transactionManagerName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutodetectTransactionManager(boolean autodetectTransactionManager) {
/*  367 */     this.autodetectTransactionManager = autodetectTransactionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionSynchronizationRegistry(@Nullable TransactionSynchronizationRegistry transactionSynchronizationRegistry) {
/*  382 */     this.transactionSynchronizationRegistry = transactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public TransactionSynchronizationRegistry getTransactionSynchronizationRegistry() {
/*  390 */     return this.transactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionSynchronizationRegistryName(String transactionSynchronizationRegistryName) {
/*  401 */     this.transactionSynchronizationRegistryName = transactionSynchronizationRegistryName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutodetectTransactionSynchronizationRegistry(boolean autodetectTransactionSynchronizationRegistry) {
/*  415 */     this.autodetectTransactionSynchronizationRegistry = autodetectTransactionSynchronizationRegistry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowCustomIsolationLevels(boolean allowCustomIsolationLevels) {
/*  428 */     this.allowCustomIsolationLevels = allowCustomIsolationLevels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterPropertiesSet() throws TransactionSystemException {
/*  438 */     initUserTransactionAndTransactionManager();
/*  439 */     checkUserTransactionAndTransactionManager();
/*  440 */     initTransactionSynchronizationRegistry();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initUserTransactionAndTransactionManager() throws TransactionSystemException {
/*  448 */     if (this.userTransaction == null)
/*      */     {
/*  450 */       if (StringUtils.hasLength(this.userTransactionName)) {
/*  451 */         this.userTransaction = lookupUserTransaction(this.userTransactionName);
/*  452 */         this.userTransactionObtainedFromJndi = true;
/*      */       } else {
/*      */         
/*  455 */         this.userTransaction = retrieveUserTransaction();
/*  456 */         if (this.userTransaction == null && this.autodetectUserTransaction)
/*      */         {
/*  458 */           this.userTransaction = findUserTransaction();
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  463 */     if (this.transactionManager == null)
/*      */     {
/*  465 */       if (StringUtils.hasLength(this.transactionManagerName)) {
/*  466 */         this.transactionManager = lookupTransactionManager(this.transactionManagerName);
/*      */       } else {
/*      */         
/*  469 */         this.transactionManager = retrieveTransactionManager();
/*  470 */         if (this.transactionManager == null && this.autodetectTransactionManager)
/*      */         {
/*      */           
/*  473 */           this.transactionManager = findTransactionManager(this.userTransaction);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  479 */     if (this.userTransaction == null && this.transactionManager != null) {
/*  480 */       this.userTransaction = buildUserTransaction(this.transactionManager);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkUserTransactionAndTransactionManager() throws IllegalStateException {
/*  491 */     if (this.userTransaction != null) {
/*  492 */       if (this.logger.isDebugEnabled()) {
/*  493 */         this.logger.debug("Using JTA UserTransaction: " + String.valueOf(this.userTransaction));
/*      */       }
/*      */     } else {
/*      */       
/*  497 */       throw new IllegalStateException("No JTA UserTransaction available - specify either 'userTransaction' or 'userTransactionName' or 'transactionManager' or 'transactionManagerName'");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  502 */     if (this.transactionManager != null) {
/*  503 */       if (this.logger.isDebugEnabled()) {
/*  504 */         this.logger.debug("Using JTA TransactionManager: " + String.valueOf(this.transactionManager));
/*      */       }
/*      */     } else {
/*      */       
/*  508 */       this.logger.warn("No JTA TransactionManager found: transaction suspension not available");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initTransactionSynchronizationRegistry() {
/*  519 */     if (this.transactionSynchronizationRegistry == null)
/*      */     {
/*  521 */       if (StringUtils.hasLength(this.transactionSynchronizationRegistryName)) {
/*  522 */         this
/*  523 */           .transactionSynchronizationRegistry = lookupTransactionSynchronizationRegistry(this.transactionSynchronizationRegistryName);
/*      */       } else {
/*      */         
/*  526 */         this.transactionSynchronizationRegistry = retrieveTransactionSynchronizationRegistry();
/*  527 */         if (this.transactionSynchronizationRegistry == null && this.autodetectTransactionSynchronizationRegistry)
/*      */         {
/*      */           
/*  530 */           this
/*  531 */             .transactionSynchronizationRegistry = findTransactionSynchronizationRegistry(this.userTransaction, this.transactionManager);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  536 */     if (this.transactionSynchronizationRegistry != null && 
/*  537 */       this.logger.isDebugEnabled()) {
/*  538 */       this.logger.debug("Using JTA TransactionSynchronizationRegistry: " + String.valueOf(this.transactionSynchronizationRegistry));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected UserTransaction buildUserTransaction(TransactionManager transactionManager) {
/*  550 */     if (transactionManager instanceof UserTransaction) { UserTransaction ut = (UserTransaction)transactionManager;
/*  551 */       return ut; }
/*      */ 
/*      */     
/*  554 */     return new UserTransactionAdapter(transactionManager);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected UserTransaction lookupUserTransaction(String userTransactionName) throws TransactionSystemException {
/*      */     try {
/*  571 */       if (this.logger.isDebugEnabled()) {
/*  572 */         this.logger.debug("Retrieving JTA UserTransaction from JNDI location [" + userTransactionName + "]");
/*      */       }
/*  574 */       return (UserTransaction)getJndiTemplate().lookup(userTransactionName, UserTransaction.class);
/*      */     }
/*  576 */     catch (NamingException ex) {
/*  577 */       throw new TransactionSystemException("JTA UserTransaction is not available at JNDI location [" + userTransactionName + "]", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionManager lookupTransactionManager(String transactionManagerName) throws TransactionSystemException {
/*      */     try {
/*  595 */       if (this.logger.isDebugEnabled()) {
/*  596 */         this.logger.debug("Retrieving JTA TransactionManager from JNDI location [" + transactionManagerName + "]");
/*      */       }
/*  598 */       return (TransactionManager)getJndiTemplate().lookup(transactionManagerName, TransactionManager.class);
/*      */     }
/*  600 */     catch (NamingException ex) {
/*  601 */       throw new TransactionSystemException("JTA TransactionManager is not available at JNDI location [" + transactionManagerName + "]", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TransactionSynchronizationRegistry lookupTransactionSynchronizationRegistry(String registryName) throws TransactionSystemException {
/*      */     try {
/*  618 */       if (this.logger.isDebugEnabled()) {
/*  619 */         this.logger.debug("Retrieving JTA TransactionSynchronizationRegistry from JNDI location [" + registryName + "]");
/*      */       }
/*  621 */       return (TransactionSynchronizationRegistry)getJndiTemplate().lookup(registryName, TransactionSynchronizationRegistry.class);
/*      */     }
/*  623 */     catch (NamingException ex) {
/*  624 */       throw new TransactionSystemException("JTA TransactionSynchronizationRegistry is not available at JNDI location [" + registryName + "]", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected UserTransaction retrieveUserTransaction() throws TransactionSystemException {
/*  640 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TransactionManager retrieveTransactionManager() throws TransactionSystemException {
/*  654 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TransactionSynchronizationRegistry retrieveTransactionSynchronizationRegistry() throws TransactionSystemException {
/*  667 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected UserTransaction findUserTransaction() {
/*  678 */     String jndiName = "java:comp/UserTransaction";
/*      */     try {
/*  680 */       UserTransaction ut = (UserTransaction)getJndiTemplate().lookup(jndiName, UserTransaction.class);
/*  681 */       if (this.logger.isDebugEnabled()) {
/*  682 */         this.logger.debug("JTA UserTransaction found at default JNDI location [" + jndiName + "]");
/*      */       }
/*  684 */       this.userTransactionObtainedFromJndi = true;
/*  685 */       return ut;
/*      */     }
/*  687 */     catch (NamingException ex) {
/*  688 */       if (this.logger.isDebugEnabled()) {
/*  689 */         this.logger.debug("No JTA UserTransaction found at default JNDI location [" + jndiName + "]", ex);
/*      */       }
/*  691 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TransactionManager findTransactionManager(@Nullable UserTransaction ut) {
/*  705 */     if (ut instanceof TransactionManager) { TransactionManager tm = (TransactionManager)ut;
/*  706 */       if (this.logger.isDebugEnabled()) {
/*  707 */         this.logger.debug("JTA UserTransaction object [" + String.valueOf(ut) + "] implements TransactionManager");
/*      */       }
/*  709 */       return tm; }
/*      */ 
/*      */ 
/*      */     
/*  713 */     for (String jndiName : FALLBACK_TRANSACTION_MANAGER_NAMES) {
/*      */       try {
/*  715 */         TransactionManager tm = (TransactionManager)getJndiTemplate().lookup(jndiName, TransactionManager.class);
/*  716 */         if (this.logger.isDebugEnabled()) {
/*  717 */           this.logger.debug("JTA TransactionManager found at fallback JNDI location [" + jndiName + "]");
/*      */         }
/*  719 */         return tm;
/*      */       }
/*  721 */       catch (NamingException ex) {
/*  722 */         if (this.logger.isDebugEnabled()) {
/*  723 */           this.logger.debug("No JTA TransactionManager found at fallback JNDI location [" + jndiName + "]", ex);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  729 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TransactionSynchronizationRegistry findTransactionSynchronizationRegistry(@Nullable UserTransaction ut, @Nullable TransactionManager tm) throws TransactionSystemException {
/*  747 */     if (this.userTransactionObtainedFromJndi) {
/*      */ 
/*      */       
/*  750 */       String jndiName = "java:comp/TransactionSynchronizationRegistry";
/*      */       try {
/*  752 */         TransactionSynchronizationRegistry tsr = (TransactionSynchronizationRegistry)getJndiTemplate().lookup(jndiName, TransactionSynchronizationRegistry.class);
/*  753 */         if (this.logger.isDebugEnabled()) {
/*  754 */           this.logger.debug("JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]");
/*      */         }
/*  756 */         return tsr;
/*      */       }
/*  758 */       catch (NamingException ex) {
/*  759 */         if (this.logger.isDebugEnabled()) {
/*  760 */           this.logger.debug("No JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]", ex);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  765 */     if (ut instanceof TransactionSynchronizationRegistry) { TransactionSynchronizationRegistry tsr = (TransactionSynchronizationRegistry)ut;
/*  766 */       return tsr; }
/*      */     
/*  768 */     if (tm instanceof TransactionSynchronizationRegistry) { TransactionSynchronizationRegistry tsr = (TransactionSynchronizationRegistry)tm;
/*  769 */       return tsr; }
/*      */ 
/*      */     
/*  772 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object doGetTransaction() {
/*  788 */     UserTransaction ut = getUserTransaction();
/*  789 */     if (ut == null) {
/*  790 */       throw new CannotCreateTransactionException("No JTA UserTransaction available - programmatic PlatformTransactionManager.getTransaction usage not supported");
/*      */     }
/*      */     
/*  793 */     if (!this.cacheUserTransaction) {
/*  794 */       ut = lookupUserTransaction(
/*  795 */           (this.userTransactionName != null) ? this.userTransactionName : "java:comp/UserTransaction");
/*      */     }
/*  797 */     return doGetJtaTransaction(ut);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JtaTransactionObject doGetJtaTransaction(UserTransaction ut) {
/*  808 */     return new JtaTransactionObject(ut);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isExistingTransaction(Object transaction) {
/*  813 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  815 */       return (txObject.getUserTransaction().getStatus() != 6);
/*      */     }
/*  817 */     catch (SystemException ex) {
/*  818 */       throw new TransactionSystemException("JTA failure on getStatus", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useSavepointForNestedTransaction() {
/*  832 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doBegin(Object transaction, TransactionDefinition definition) {
/*  838 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  840 */       doJtaBegin(txObject, definition);
/*      */     }
/*  842 */     catch (NotSupportedException|UnsupportedOperationException ex) {
/*  843 */       throw new NestedTransactionNotSupportedException("JTA implementation does not support nested transactions", ex);
/*      */     
/*      */     }
/*  846 */     catch (SystemException ex) {
/*  847 */       throw new CannotCreateTransactionException("JTA failure on begin", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition) throws NotSupportedException, SystemException {
/*  874 */     applyIsolationLevel(txObject, definition.getIsolationLevel());
/*  875 */     int timeout = determineTimeout(definition);
/*  876 */     applyTimeout(txObject, timeout);
/*  877 */     txObject.getUserTransaction().begin();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyIsolationLevel(JtaTransactionObject txObject, int isolationLevel) throws InvalidIsolationLevelException, SystemException {
/*  897 */     if (!this.allowCustomIsolationLevels && isolationLevel != -1) {
/*  898 */       throw new InvalidIsolationLevelException("JtaTransactionManager does not support custom isolation levels by default - switch 'allowCustomIsolationLevels' to 'true'");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyTimeout(JtaTransactionObject txObject, int timeout) throws SystemException {
/*  915 */     if (timeout > -1) {
/*  916 */       txObject.getUserTransaction().setTransactionTimeout(timeout);
/*  917 */       if (timeout > 0) {
/*  918 */         txObject.resetTransactionTimeout = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object doSuspend(Object transaction) {
/*  926 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  928 */       return doJtaSuspend(txObject);
/*      */     }
/*  930 */     catch (SystemException ex) {
/*  931 */       throw new TransactionSystemException("JTA failure on suspend", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object doJtaSuspend(JtaTransactionObject txObject) throws SystemException {
/*  945 */     if (getTransactionManager() == null) {
/*  946 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*      */     }
/*      */ 
/*      */     
/*  950 */     return getTransactionManager().suspend();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doResume(@Nullable Object transaction, Object suspendedResources) {
/*  955 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*      */     try {
/*  957 */       doJtaResume(txObject, suspendedResources);
/*      */     }
/*  959 */     catch (InvalidTransactionException ex) {
/*  960 */       throw new IllegalTransactionStateException("Tried to resume invalid JTA transaction", ex);
/*      */     }
/*  962 */     catch (IllegalStateException ex) {
/*  963 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/*  965 */     catch (SystemException ex) {
/*  966 */       throw new TransactionSystemException("JTA failure on resume", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doJtaResume(@Nullable JtaTransactionObject txObject, Object suspendedTransaction) throws InvalidTransactionException, SystemException {
/*  983 */     if (getTransactionManager() == null) {
/*  984 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*      */     }
/*      */ 
/*      */     
/*  988 */     getTransactionManager().resume((Transaction)suspendedTransaction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean shouldCommitOnGlobalRollbackOnly() {
/*  998 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doCommit(DefaultTransactionStatus status) {
/* 1003 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*      */     try {
/* 1005 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1006 */       if (jtaStatus == 6)
/*      */       {
/*      */ 
/*      */         
/* 1010 */         throw new UnexpectedRollbackException("JTA transaction already completed - probably rolled back");
/*      */       }
/* 1012 */       if (jtaStatus == 4) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1017 */           txObject.getUserTransaction().rollback();
/*      */         }
/* 1019 */         catch (IllegalStateException ex) {
/* 1020 */           if (this.logger.isDebugEnabled()) {
/* 1021 */             this.logger.debug("Rollback failure with transaction already marked as rolled back: " + String.valueOf(ex));
/*      */           }
/*      */         } 
/* 1024 */         throw new UnexpectedRollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*      */       } 
/* 1026 */       txObject.getUserTransaction().commit();
/*      */     }
/* 1028 */     catch (RollbackException ex) {
/* 1029 */       throw new UnexpectedRollbackException("JTA transaction unexpectedly rolled back (maybe due to a timeout)", ex);
/*      */     
/*      */     }
/* 1032 */     catch (HeuristicMixedException ex) {
/* 1033 */       throw new HeuristicCompletionException(3, ex);
/*      */     }
/* 1035 */     catch (HeuristicRollbackException ex) {
/* 1036 */       throw new HeuristicCompletionException(2, ex);
/*      */     }
/* 1038 */     catch (IllegalStateException ex) {
/* 1039 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/* 1041 */     catch (SystemException ex) {
/* 1042 */       throw new TransactionSystemException("JTA failure on commit", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doRollback(DefaultTransactionStatus status) {
/* 1048 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*      */     try {
/* 1050 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1051 */       if (jtaStatus != 6) {
/*      */         try {
/* 1053 */           txObject.getUserTransaction().rollback();
/*      */         }
/* 1055 */         catch (IllegalStateException ex) {
/* 1056 */           if (jtaStatus == 4) {
/*      */             
/* 1058 */             if (this.logger.isDebugEnabled()) {
/* 1059 */               this.logger.debug("Rollback failure with transaction already marked as rolled back: " + String.valueOf(ex));
/*      */             }
/*      */           } else {
/*      */             
/* 1063 */             throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */           }
/*      */         
/*      */         } 
/*      */       }
/* 1068 */     } catch (SystemException ex) {
/* 1069 */       throw new TransactionSystemException("JTA failure on rollback", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doSetRollbackOnly(DefaultTransactionStatus status) {
/* 1075 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/* 1076 */     if (status.isDebug()) {
/* 1077 */       this.logger.debug("Setting JTA transaction rollback-only");
/*      */     }
/*      */     try {
/* 1080 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1081 */       if (jtaStatus != 6 && jtaStatus != 4) {
/* 1082 */         txObject.getUserTransaction().setRollbackOnly();
/*      */       }
/*      */     }
/* 1085 */     catch (IllegalStateException ex) {
/* 1086 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*      */     }
/* 1088 */     catch (SystemException ex) {
/* 1089 */       throw new TransactionSystemException("JTA failure on setRollbackOnly", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations) {
/* 1098 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/* 1099 */     this.logger.debug("Registering after-completion synchronization with existing JTA transaction");
/*      */     try {
/* 1101 */       doRegisterAfterCompletionWithJtaTransaction(txObject, synchronizations);
/*      */     }
/* 1103 */     catch (SystemException ex) {
/* 1104 */       throw new TransactionSystemException("JTA failure on registerSynchronization", ex);
/*      */     }
/* 1106 */     catch (Exception ex) {
/*      */       
/* 1108 */       if (ex instanceof RollbackException || ex.getCause() instanceof RollbackException) {
/* 1109 */         this.logger.debug("Participating in existing JTA transaction that has been marked for rollback: cannot register Spring after-completion callbacks with outer JTA transaction - immediately performing Spring after-completion callbacks with outcome status 'rollback'. Original exception: " + String.valueOf(ex));
/*      */ 
/*      */ 
/*      */         
/* 1113 */         invokeAfterCompletion(synchronizations, 1);
/*      */       } else {
/*      */         
/* 1116 */         this.logger.debug("Participating in existing JTA transaction, but unexpected internal transaction state encountered: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'Original exception: " + String.valueOf(ex));
/*      */ 
/*      */ 
/*      */         
/* 1120 */         invokeAfterCompletion(synchronizations, 2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRegisterAfterCompletionWithJtaTransaction(JtaTransactionObject txObject, List<TransactionSynchronization> synchronizations) throws RollbackException, SystemException {
/* 1145 */     int jtaStatus = txObject.getUserTransaction().getStatus();
/* 1146 */     if (jtaStatus == 6) {
/* 1147 */       throw new RollbackException("JTA transaction already completed - probably rolled back");
/*      */     }
/* 1149 */     if (jtaStatus == 4) {
/* 1150 */       throw new RollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*      */     }
/*      */     
/* 1153 */     if (this.transactionSynchronizationRegistry != null) {
/*      */       
/* 1155 */       this.transactionSynchronizationRegistry.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*      */ 
/*      */     
/*      */     }
/* 1159 */     else if (getTransactionManager() != null) {
/*      */       
/* 1161 */       Transaction transaction = getTransactionManager().getTransaction();
/* 1162 */       if (transaction == null) {
/* 1163 */         throw new IllegalStateException("No JTA Transaction available");
/*      */       }
/* 1165 */       transaction.registerSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1170 */       this.logger.warn("Participating in existing JTA transaction, but no JTA TransactionManager available: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'");
/*      */ 
/*      */       
/* 1173 */       invokeAfterCompletion(synchronizations, 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doCleanupAfterCompletion(Object transaction) {
/* 1179 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/* 1180 */     if (txObject.resetTransactionTimeout) {
/*      */       try {
/* 1182 */         txObject.getUserTransaction().setTransactionTimeout(0);
/*      */       }
/* 1184 */       catch (SystemException ex) {
/* 1185 */         this.logger.debug("Failed to reset transaction timeout after JTA completion", (Throwable)ex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Transaction createTransaction(@Nullable String name, int timeout) throws NotSupportedException, SystemException {
/* 1197 */     TransactionManager tm = getTransactionManager();
/* 1198 */     Assert.state((tm != null), "No JTA TransactionManager available");
/* 1199 */     if (timeout >= 0) {
/* 1200 */       tm.setTransactionTimeout(timeout);
/*      */     }
/* 1202 */     tm.begin();
/* 1203 */     return new ManagedTransactionAdapter(tm);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResourceAdapterManagedTransactions() {
/* 1208 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 1218 */     ois.defaultReadObject();
/*      */ 
/*      */     
/* 1221 */     this.jndiTemplate = new JndiTemplate();
/*      */ 
/*      */     
/* 1224 */     initUserTransactionAndTransactionManager();
/* 1225 */     initTransactionSynchronizationRegistry();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\JtaTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */