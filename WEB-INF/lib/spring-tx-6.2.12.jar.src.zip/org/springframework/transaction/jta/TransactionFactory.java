package org.springframework.transaction.jta;

import jakarta.transaction.NotSupportedException;
import jakarta.transaction.SystemException;
import jakarta.transaction.Transaction;
import org.springframework.lang.Nullable;

public interface TransactionFactory {
  Transaction createTransaction(@Nullable String paramString, int paramInt) throws NotSupportedException, SystemException;
  
  boolean supportsResourceAdapterManagedTransactions();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\TransactionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */