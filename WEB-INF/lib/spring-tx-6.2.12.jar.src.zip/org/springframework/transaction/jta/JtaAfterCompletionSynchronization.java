/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import jakarta.transaction.Synchronization;
/*    */ import java.util.List;
/*    */ import org.springframework.transaction.support.TransactionSynchronization;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JtaAfterCompletionSynchronization
/*    */   implements Synchronization
/*    */ {
/*    */   private final List<TransactionSynchronization> synchronizations;
/*    */   
/*    */   public JtaAfterCompletionSynchronization(List<TransactionSynchronization> synchronizations) {
/* 49 */     this.synchronizations = synchronizations;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforeCompletion() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterCompletion(int status) {
/* 59 */     switch (status) {
/*    */       case 3:
/*    */         try {
/* 62 */           TransactionSynchronizationUtils.invokeAfterCommit(this.synchronizations);
/*    */         } finally {
/*    */           
/* 65 */           TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 0);
/*    */         } 
/*    */         return;
/*    */       
/*    */       case 4:
/* 70 */         TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 1);
/*    */         return;
/*    */     } 
/*    */     
/* 74 */     TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\JtaAfterCompletionSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */