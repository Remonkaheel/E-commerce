/*    */ package org.springframework.transaction.jta;
/*    */ 
/*    */ import jakarta.transaction.HeuristicMixedException;
/*    */ import jakarta.transaction.HeuristicRollbackException;
/*    */ import jakarta.transaction.NotSupportedException;
/*    */ import jakarta.transaction.RollbackException;
/*    */ import jakarta.transaction.SystemException;
/*    */ import jakarta.transaction.TransactionManager;
/*    */ import jakarta.transaction.UserTransaction;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserTransactionAdapter
/*    */   implements UserTransaction
/*    */ {
/*    */   private final TransactionManager transactionManager;
/*    */   
/*    */   public UserTransactionAdapter(TransactionManager transactionManager) {
/* 56 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/* 57 */     this.transactionManager = transactionManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final TransactionManager getTransactionManager() {
/* 64 */     return this.transactionManager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransactionTimeout(int timeout) throws SystemException {
/* 70 */     this.transactionManager.setTransactionTimeout(timeout);
/*    */   }
/*    */ 
/*    */   
/*    */   public void begin() throws NotSupportedException, SystemException {
/* 75 */     this.transactionManager.begin();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, SystemException {
/* 82 */     this.transactionManager.commit();
/*    */   }
/*    */ 
/*    */   
/*    */   public void rollback() throws SecurityException, SystemException {
/* 87 */     this.transactionManager.rollback();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRollbackOnly() throws SystemException {
/* 92 */     this.transactionManager.setRollbackOnly();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStatus() throws SystemException {
/* 97 */     return this.transactionManager.getStatus();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\jta\UserTransactionAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */