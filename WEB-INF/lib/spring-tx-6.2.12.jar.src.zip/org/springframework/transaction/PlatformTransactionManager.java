package org.springframework.transaction;

import org.springframework.lang.Nullable;

public interface PlatformTransactionManager extends TransactionManager {
  TransactionStatus getTransaction(@Nullable TransactionDefinition paramTransactionDefinition) throws TransactionException;
  
  void commit(TransactionStatus paramTransactionStatus) throws TransactionException;
  
  void rollback(TransactionStatus paramTransactionStatus) throws TransactionException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\PlatformTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */