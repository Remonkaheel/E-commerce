package org.springframework.transaction;

import org.springframework.lang.Nullable;

public interface TransactionExecutionListener {
  default void beforeBegin(TransactionExecution transaction) {}
  
  default void afterBegin(TransactionExecution transaction, @Nullable Throwable beginFailure) {}
  
  default void beforeCommit(TransactionExecution transaction) {}
  
  default void afterCommit(TransactionExecution transaction, @Nullable Throwable commitFailure) {}
  
  default void beforeRollback(TransactionExecution transaction) {}
  
  default void afterRollback(TransactionExecution transaction, @Nullable Throwable rollbackFailure) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\TransactionExecutionListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */