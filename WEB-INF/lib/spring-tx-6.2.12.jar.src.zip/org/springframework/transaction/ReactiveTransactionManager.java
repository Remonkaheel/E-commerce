package org.springframework.transaction;

import org.springframework.lang.Nullable;
import reactor.core.publisher.Mono;

public interface ReactiveTransactionManager extends TransactionManager {
  Mono<ReactiveTransaction> getReactiveTransaction(@Nullable TransactionDefinition paramTransactionDefinition);
  
  Mono<Void> commit(ReactiveTransaction paramReactiveTransaction);
  
  Mono<Void> rollback(ReactiveTransaction paramReactiveTransaction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\ReactiveTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */