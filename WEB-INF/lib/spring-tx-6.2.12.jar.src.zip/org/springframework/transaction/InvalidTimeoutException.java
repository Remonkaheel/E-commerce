/*    */ package org.springframework.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTimeoutException
/*    */   extends TransactionUsageException
/*    */ {
/*    */   private final int timeout;
/*    */   
/*    */   public InvalidTimeoutException(String msg, int timeout) {
/* 39 */     super(msg);
/* 40 */     this.timeout = timeout;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getTimeout() {
/* 47 */     return this.timeout;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\transaction\InvalidTimeoutException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */