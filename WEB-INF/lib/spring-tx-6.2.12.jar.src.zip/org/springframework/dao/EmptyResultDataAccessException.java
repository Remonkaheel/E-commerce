/*    */ package org.springframework.dao;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyResultDataAccessException
/*    */   extends IncorrectResultSizeDataAccessException
/*    */ {
/*    */   public EmptyResultDataAccessException(int expectedSize) {
/* 37 */     super(expectedSize, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EmptyResultDataAccessException(@Nullable String msg, int expectedSize) {
/* 46 */     super(msg, expectedSize, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EmptyResultDataAccessException(@Nullable String msg, int expectedSize, Throwable ex) {
/* 56 */     super(msg, expectedSize, 0, ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\EmptyResultDataAccessException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */