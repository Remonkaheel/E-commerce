/*    */ package org.springframework.dao;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PermissionDeniedDataAccessException
/*    */   extends NonTransientDataAccessException
/*    */ {
/*    */   public PermissionDeniedDataAccessException(String msg, Throwable cause) {
/* 36 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\PermissionDeniedDataAccessException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */