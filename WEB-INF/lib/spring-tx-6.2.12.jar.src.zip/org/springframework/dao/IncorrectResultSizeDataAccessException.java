/*     */ package org.springframework.dao;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IncorrectResultSizeDataAccessException
/*     */   extends DataRetrievalFailureException
/*     */ {
/*     */   private final int expectedSize;
/*     */   private final int actualSize;
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(int expectedSize) {
/*  43 */     super("Incorrect result size: expected " + expectedSize);
/*  44 */     this.expectedSize = expectedSize;
/*  45 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(int expectedSize, int actualSize) {
/*  54 */     super("Incorrect result size: expected " + expectedSize + ", actual " + actualSize);
/*  55 */     this.expectedSize = expectedSize;
/*  56 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize) {
/*  65 */     super(msg);
/*  66 */     this.expectedSize = expectedSize;
/*  67 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(@Nullable String msg, int expectedSize, @Nullable Throwable ex) {
/*  77 */     super(msg, ex);
/*  78 */     this.expectedSize = expectedSize;
/*  79 */     this.actualSize = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(@Nullable String msg, int expectedSize, int actualSize) {
/*  89 */     super(msg);
/*  90 */     this.expectedSize = expectedSize;
/*  91 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncorrectResultSizeDataAccessException(@Nullable String msg, int expectedSize, int actualSize, @Nullable Throwable ex) {
/* 102 */     super(msg, ex);
/* 103 */     this.expectedSize = expectedSize;
/* 104 */     this.actualSize = actualSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExpectedSize() {
/* 112 */     return this.expectedSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActualSize() {
/* 119 */     return this.actualSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\IncorrectResultSizeDataAccessException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */