/*     */ package org.springframework.dao.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DataAccessUtils
/*     */ {
/*     */   @Nullable
/*     */   public static <T> T singleResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/*  55 */     if (CollectionUtils.isEmpty(results)) {
/*  56 */       return null;
/*     */     }
/*  58 */     if (results.size() > 1) {
/*  59 */       throw new IncorrectResultSizeDataAccessException(1, results.size());
/*     */     }
/*  61 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> T singleResult(@Nullable Stream<T> results) throws IncorrectResultSizeDataAccessException {
/*  76 */     if (results == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     Stream<T> stream = results; try {
/*  80 */       List<T> resultList = results.limit(2L).toList();
/*  81 */       if (resultList.size() > 1) {
/*  82 */         throw new IncorrectResultSizeDataAccessException(1);
/*     */       }
/*  84 */       E e = !resultList.isEmpty() ? (E)resultList.get(0) : null;
/*  85 */       if (stream != null) stream.close(); 
/*     */       return (T)e;
/*     */     } catch (Throwable throwable) {
/*     */       if (stream != null)
/*     */         try {
/*     */           stream.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static <T> T singleResult(@Nullable Iterator<T> results) throws IncorrectResultSizeDataAccessException {
/* 100 */     if (results == null) {
/* 101 */       return null;
/*     */     }
/* 103 */     E e = results.hasNext() ? (E)results.next() : null;
/* 104 */     if (results.hasNext()) {
/* 105 */       throw new IncorrectResultSizeDataAccessException(1);
/*     */     }
/* 107 */     return (T)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Optional<T> optionalResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/* 121 */     return Optional.ofNullable(singleResult(results));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Optional<T> optionalResult(@Nullable Stream<T> results) throws IncorrectResultSizeDataAccessException {
/* 135 */     return Optional.ofNullable(singleResult(results));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Optional<T> optionalResult(@Nullable Iterator<T> results) throws IncorrectResultSizeDataAccessException {
/* 149 */     return Optional.ofNullable(singleResult(results));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T requiredSingleResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/* 164 */     if (CollectionUtils.isEmpty(results)) {
/* 165 */       throw new EmptyResultDataAccessException(1);
/*     */     }
/* 167 */     if (results.size() > 1) {
/* 168 */       throw new IncorrectResultSizeDataAccessException(1, results.size());
/*     */     }
/* 170 */     T result = results.iterator().next();
/* 171 */     if (result == null) {
/* 172 */       throw new TypeMismatchDataAccessException("Result value is null but no null value expected");
/*     */     }
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> T nullableSingleResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/* 193 */     if (CollectionUtils.isEmpty(results)) {
/* 194 */       throw new EmptyResultDataAccessException(1);
/*     */     }
/* 196 */     if (results.size() > 1) {
/* 197 */       throw new IncorrectResultSizeDataAccessException(1, results.size());
/*     */     }
/* 199 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> T uniqueResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/* 214 */     if (CollectionUtils.isEmpty(results)) {
/* 215 */       return null;
/*     */     }
/* 217 */     if (!CollectionUtils.hasUniqueObject(results)) {
/* 218 */       throw new IncorrectResultSizeDataAccessException(1, results.size());
/*     */     }
/* 220 */     return results.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T requiredUniqueResult(@Nullable Collection<T> results) throws IncorrectResultSizeDataAccessException {
/* 236 */     if (CollectionUtils.isEmpty(results)) {
/* 237 */       throw new EmptyResultDataAccessException(1);
/*     */     }
/* 239 */     if (!CollectionUtils.hasUniqueObject(results)) {
/* 240 */       throw new IncorrectResultSizeDataAccessException(1, results.size());
/*     */     }
/* 242 */     T result = results.iterator().next();
/* 243 */     if (result == null) {
/* 244 */       throw new TypeMismatchDataAccessException("Result value is null but no null value expected");
/*     */     }
/* 246 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T objectResult(@Nullable Collection<?> results, @Nullable Class<T> requiredType) throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException {
/* 268 */     Object result = requiredUniqueResult(results);
/* 269 */     if (requiredType != null && !requiredType.isInstance(result)) {
/* 270 */       if (String.class == requiredType)
/* 271 */       { result = result.toString(); }
/*     */       
/* 273 */       else if (Number.class.isAssignableFrom(requiredType) && result instanceof Number) { Number number = (Number)result;
/*     */         try {
/* 275 */           result = NumberUtils.convertNumberToTargetClass(number, requiredType);
/*     */         }
/* 277 */         catch (IllegalArgumentException ex) {
/* 278 */           throw new TypeMismatchDataAccessException(ex.getMessage());
/*     */         }  }
/*     */       else
/*     */       
/* 282 */       { throw new TypeMismatchDataAccessException("Result object is of type [" + result
/* 283 */             .getClass().getName() + "] and could not be converted to required type [" + requiredType
/* 284 */             .getName() + "]"); }
/*     */     
/*     */     }
/* 287 */     return (T)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intResult(@Nullable Collection<?> results) throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException {
/* 307 */     return ((Number)objectResult(results, Number.class)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longResult(@Nullable Collection<?> results) throws IncorrectResultSizeDataAccessException, TypeMismatchDataAccessException {
/* 327 */     return ((Number)objectResult(results, Number.class)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException translateIfNecessary(RuntimeException rawException, PersistenceExceptionTranslator pet) {
/* 342 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/* 343 */     DataAccessException dae = pet.translateExceptionIfPossible(rawException);
/* 344 */     return (dae != null) ? (RuntimeException)dae : rawException;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\support\DataAccessUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */