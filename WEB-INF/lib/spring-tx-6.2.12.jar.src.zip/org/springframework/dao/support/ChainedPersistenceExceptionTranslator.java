/*    */ package org.springframework.dao.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChainedPersistenceExceptionTranslator
/*    */   implements PersistenceExceptionTranslator
/*    */ {
/* 38 */   private final List<PersistenceExceptionTranslator> delegates = new ArrayList<>(4);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void addDelegate(PersistenceExceptionTranslator pet) {
/* 45 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/* 46 */     this.delegates.add(pet);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final PersistenceExceptionTranslator[] getDelegates() {
/* 53 */     return this.delegates.<PersistenceExceptionTranslator>toArray(new PersistenceExceptionTranslator[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public DataAccessException translateExceptionIfPossible(RuntimeException ex) {
/* 60 */     for (PersistenceExceptionTranslator pet : this.delegates) {
/* 61 */       DataAccessException translatedDex = pet.translateExceptionIfPossible(ex);
/* 62 */       if (translatedDex != null) {
/* 63 */         return translatedDex;
/*    */       }
/*    */     } 
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\support\ChainedPersistenceExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */