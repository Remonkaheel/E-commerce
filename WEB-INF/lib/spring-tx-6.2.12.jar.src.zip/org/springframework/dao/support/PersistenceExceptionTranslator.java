package org.springframework.dao.support;

import org.springframework.dao.DataAccessException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface PersistenceExceptionTranslator {
  @Nullable
  DataAccessException translateExceptionIfPossible(RuntimeException paramRuntimeException);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\support\PersistenceExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */