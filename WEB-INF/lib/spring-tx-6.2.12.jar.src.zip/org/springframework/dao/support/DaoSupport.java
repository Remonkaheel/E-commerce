/*    */ package org.springframework.dao.support;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanInitializationException;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DaoSupport
/*    */   implements InitializingBean
/*    */ {
/* 38 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void afterPropertiesSet() throws IllegalArgumentException, BeanInitializationException {
/* 44 */     checkDaoConfig();
/*    */ 
/*    */     
/*    */     try {
/* 48 */       initDao();
/*    */     }
/* 50 */     catch (Exception ex) {
/* 51 */       throw new BeanInitializationException("Initialization of DAO failed", ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void checkDaoConfig() throws IllegalArgumentException;
/*    */   
/*    */   protected void initDao() throws Exception {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\support\DaoSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */