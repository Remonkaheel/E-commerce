/*     */ package org.springframework.dao.support;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationNotAllowedException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceExceptionTranslationInterceptor
/*     */   implements MethodInterceptor, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private volatile PersistenceExceptionTranslator persistenceExceptionTranslator;
/*     */   private boolean alwaysTranslate = false;
/*     */   @Nullable
/*     */   private ListableBeanFactory beanFactory;
/*     */   
/*     */   public PersistenceExceptionTranslationInterceptor() {}
/*     */   
/*     */   public PersistenceExceptionTranslationInterceptor(PersistenceExceptionTranslator pet) {
/*  72 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/*  73 */     this.persistenceExceptionTranslator = pet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceExceptionTranslationInterceptor(ListableBeanFactory beanFactory) {
/*  83 */     Assert.notNull(beanFactory, "ListableBeanFactory must not be null");
/*  84 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceExceptionTranslator(PersistenceExceptionTranslator pet) {
/*  95 */     this.persistenceExceptionTranslator = pet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysTranslate(boolean alwaysTranslate) {
/* 111 */     this.alwaysTranslate = alwaysTranslate;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 116 */     if (this.persistenceExceptionTranslator == null) {
/*     */       ListableBeanFactory lbf;
/* 118 */       if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 119 */       else { throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory"); }
/*     */ 
/*     */       
/* 122 */       this.beanFactory = lbf;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 128 */     if (this.persistenceExceptionTranslator == null && this.beanFactory == null) {
/* 129 */       throw new IllegalArgumentException("Property 'persistenceExceptionTranslator' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/*     */     try {
/* 138 */       return mi.proceed();
/*     */     }
/* 140 */     catch (RuntimeException ex) {
/*     */       
/* 142 */       if (!this.alwaysTranslate && ReflectionUtils.declaresException(mi.getMethod(), ex.getClass())) {
/* 143 */         throw ex;
/*     */       }
/*     */       
/* 146 */       PersistenceExceptionTranslator translator = this.persistenceExceptionTranslator;
/* 147 */       if (translator == null) {
/* 148 */         Assert.state((this.beanFactory != null), "Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory");
/*     */         
/*     */         try {
/* 151 */           translator = detectPersistenceExceptionTranslators(this.beanFactory);
/*     */         }
/* 153 */         catch (BeanCreationNotAllowedException ex2) {
/*     */ 
/*     */           
/* 156 */           throw ex;
/*     */         } 
/* 158 */         this.persistenceExceptionTranslator = translator;
/*     */       } 
/* 160 */       throw DataAccessUtils.translateIfNecessary(ex, translator);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceExceptionTranslator detectPersistenceExceptionTranslators(ListableBeanFactory bf) {
/* 174 */     ChainedPersistenceExceptionTranslator cpet = new ChainedPersistenceExceptionTranslator();
/* 175 */     Objects.requireNonNull(cpet); bf.getBeanProvider(PersistenceExceptionTranslator.class, false).orderedStream().forEach(cpet::addDelegate);
/* 176 */     return cpet;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\support\PersistenceExceptionTranslationInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */