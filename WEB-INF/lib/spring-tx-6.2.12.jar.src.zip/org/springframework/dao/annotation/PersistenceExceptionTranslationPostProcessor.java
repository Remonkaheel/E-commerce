/*    */ package org.springframework.dao.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.framework.autoproxy.AbstractBeanFactoryAwareAdvisingPostProcessor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.stereotype.Repository;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceExceptionTranslationPostProcessor
/*    */   extends AbstractBeanFactoryAwareAdvisingPostProcessor
/*    */ {
/* 65 */   private Class<? extends Annotation> repositoryAnnotationType = (Class)Repository.class;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRepositoryAnnotationType(Class<? extends Annotation> repositoryAnnotationType) {
/* 77 */     Assert.notNull(repositoryAnnotationType, "'repositoryAnnotationType' must not be null");
/* 78 */     this.repositoryAnnotationType = repositoryAnnotationType;
/*    */   }
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/*    */     ListableBeanFactory lbf;
/* 83 */     super.setBeanFactory(beanFactory);
/*    */     
/* 85 */     if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 86 */     else { throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory"); }
/*    */ 
/*    */     
/* 89 */     this.advisor = (Advisor)new PersistenceExceptionTranslationAdvisor(lbf, this.repositoryAnnotationType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\annotation\PersistenceExceptionTranslationPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */