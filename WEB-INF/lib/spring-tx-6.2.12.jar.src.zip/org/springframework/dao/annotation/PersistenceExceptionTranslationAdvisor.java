/*    */ package org.springframework.dao.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*    */ import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.dao.support.PersistenceExceptionTranslationInterceptor;
/*    */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceExceptionTranslationAdvisor
/*    */   extends AbstractPointcutAdvisor
/*    */ {
/*    */   private final PersistenceExceptionTranslationInterceptor advice;
/*    */   private final AnnotationMatchingPointcut pointcut;
/*    */   
/*    */   public PersistenceExceptionTranslationAdvisor(PersistenceExceptionTranslator persistenceExceptionTranslator, Class<? extends Annotation> repositoryAnnotationType) {
/* 58 */     this.advice = new PersistenceExceptionTranslationInterceptor(persistenceExceptionTranslator);
/* 59 */     this.pointcut = new AnnotationMatchingPointcut(repositoryAnnotationType, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   PersistenceExceptionTranslationAdvisor(ListableBeanFactory beanFactory, Class<? extends Annotation> repositoryAnnotationType) {
/* 71 */     this.advice = new PersistenceExceptionTranslationInterceptor(beanFactory);
/* 72 */     this.pointcut = new AnnotationMatchingPointcut(repositoryAnnotationType, true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Advice getAdvice() {
/* 78 */     return (Advice)this.advice;
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 83 */     return (Pointcut)this.pointcut;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\annotation\PersistenceExceptionTranslationAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */