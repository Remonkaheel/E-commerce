/*    */ package org.springframework.dao;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class UncategorizedDataAccessException
/*    */   extends NonTransientDataAccessException
/*    */ {
/*    */   public UncategorizedDataAccessException(@Nullable String msg, @Nullable Throwable cause) {
/* 37 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\dao\UncategorizedDataAccessException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */