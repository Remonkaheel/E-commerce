/*     */ package org.springframework.jca.support;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.BootstrapContext;
/*     */ import jakarta.resource.spi.ResourceAdapter;
/*     */ import jakarta.resource.spi.XATerminator;
/*     */ import jakarta.resource.spi.work.WorkManager;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceAdapterFactoryBean
/*     */   implements FactoryBean<ResourceAdapter>, InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private ResourceAdapter resourceAdapter;
/*     */   @Nullable
/*     */   private BootstrapContext bootstrapContext;
/*     */   @Nullable
/*     */   private WorkManager workManager;
/*     */   @Nullable
/*     */   private XATerminator xaTerminator;
/*     */   
/*     */   public void setResourceAdapterClass(Class<? extends ResourceAdapter> resourceAdapterClass) {
/*  74 */     this.resourceAdapter = (ResourceAdapter)BeanUtils.instantiateClass(resourceAdapterClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceAdapter(ResourceAdapter resourceAdapter) {
/*  84 */     this.resourceAdapter = resourceAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBootstrapContext(BootstrapContext bootstrapContext) {
/*  95 */     this.bootstrapContext = bootstrapContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkManager(WorkManager workManager) {
/* 103 */     this.workManager = workManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXaTerminator(XATerminator xaTerminator) {
/* 111 */     this.xaTerminator = xaTerminator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws ResourceException {
/* 121 */     if (this.resourceAdapter == null) {
/* 122 */       throw new IllegalArgumentException("'resourceAdapter' or 'resourceAdapterClass' is required");
/*     */     }
/* 124 */     if (this.bootstrapContext == null) {
/* 125 */       this.bootstrapContext = new SimpleBootstrapContext(this.workManager, this.xaTerminator);
/*     */     }
/* 127 */     this.resourceAdapter.start(this.bootstrapContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceAdapter getObject() {
/* 134 */     return this.resourceAdapter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<? extends ResourceAdapter> getObjectType() {
/* 139 */     return (this.resourceAdapter != null) ? (Class)this.resourceAdapter.getClass() : ResourceAdapter.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 154 */     if (this.resourceAdapter != null)
/* 155 */       this.resourceAdapter.stop(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\support\ResourceAdapterFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */