/*     */ package org.springframework.jca.support;
/*     */ 
/*     */ import jakarta.resource.spi.BootstrapContext;
/*     */ import jakarta.resource.spi.UnavailableException;
/*     */ import jakarta.resource.spi.XATerminator;
/*     */ import jakarta.resource.spi.work.WorkContext;
/*     */ import jakarta.resource.spi.work.WorkManager;
/*     */ import jakarta.transaction.TransactionSynchronizationRegistry;
/*     */ import java.util.Timer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleBootstrapContext
/*     */   implements BootstrapContext
/*     */ {
/*     */   @Nullable
/*     */   private final WorkManager workManager;
/*     */   @Nullable
/*     */   private XATerminator xaTerminator;
/*     */   @Nullable
/*     */   private TransactionSynchronizationRegistry transactionSynchronizationRegistry;
/*     */   
/*     */   public SimpleBootstrapContext(@Nullable WorkManager workManager) {
/*  61 */     this.workManager = workManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleBootstrapContext(@Nullable WorkManager workManager, @Nullable XATerminator xaTerminator) {
/*  70 */     this.workManager = workManager;
/*  71 */     this.xaTerminator = xaTerminator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleBootstrapContext(@Nullable WorkManager workManager, @Nullable XATerminator xaTerminator, @Nullable TransactionSynchronizationRegistry transactionSynchronizationRegistry) {
/*  86 */     this.workManager = workManager;
/*  87 */     this.xaTerminator = xaTerminator;
/*  88 */     this.transactionSynchronizationRegistry = transactionSynchronizationRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WorkManager getWorkManager() {
/*  94 */     Assert.state((this.workManager != null), "No WorkManager available");
/*  95 */     return this.workManager;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public XATerminator getXATerminator() {
/* 101 */     return this.xaTerminator;
/*     */   }
/*     */ 
/*     */   
/*     */   public Timer createTimer() throws UnavailableException {
/* 106 */     return new Timer();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isContextSupported(Class<? extends WorkContext> workContextClass) {
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TransactionSynchronizationRegistry getTransactionSynchronizationRegistry() {
/* 117 */     return this.transactionSynchronizationRegistry;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\support\SimpleBootstrapContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */