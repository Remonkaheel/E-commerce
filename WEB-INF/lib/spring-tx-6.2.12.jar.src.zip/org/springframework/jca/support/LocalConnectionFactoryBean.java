/*     */ package org.springframework.jca.support;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.ConnectionManager;
/*     */ import jakarta.resource.spi.ManagedConnectionFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalConnectionFactoryBean
/*     */   implements FactoryBean<Object>, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private ManagedConnectionFactory managedConnectionFactory;
/*     */   @Nullable
/*     */   private ConnectionManager connectionManager;
/*     */   @Nullable
/*     */   private Object connectionFactory;
/*     */   
/*     */   public void setManagedConnectionFactory(ManagedConnectionFactory managedConnectionFactory) {
/*  99 */     this.managedConnectionFactory = managedConnectionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionManager(ConnectionManager connectionManager) {
/* 111 */     this.connectionManager = connectionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws ResourceException {
/* 116 */     if (this.managedConnectionFactory == null) {
/* 117 */       throw new IllegalArgumentException("Property 'managedConnectionFactory' is required");
/*     */     }
/* 119 */     if (this.connectionManager != null) {
/* 120 */       this.connectionFactory = this.managedConnectionFactory.createConnectionFactory(this.connectionManager);
/*     */     } else {
/*     */       
/* 123 */       this.connectionFactory = this.managedConnectionFactory.createConnectionFactory();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() {
/* 131 */     return this.connectionFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 137 */     return (this.connectionFactory != null) ? this.connectionFactory.getClass() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 142 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\support\LocalConnectionFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */