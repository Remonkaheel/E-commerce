/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.UnavailableException;
/*     */ import jakarta.resource.spi.endpoint.MessageEndpoint;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericMessageEndpointFactory
/*     */   extends AbstractMessageEndpointFactory
/*     */ {
/*     */   @Nullable
/*     */   private Object messageListener;
/*     */   
/*     */   public void setMessageListener(Object messageListener) {
/*  67 */     this.messageListener = messageListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getMessageListener() {
/*  75 */     Assert.state((this.messageListener != null), "No message listener set");
/*  76 */     return this.messageListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource) throws UnavailableException {
/*  86 */     GenericMessageEndpoint endpoint = (GenericMessageEndpoint)super.createEndpoint(xaResource);
/*  87 */     Object target = getMessageListener();
/*  88 */     ProxyFactory proxyFactory = new ProxyFactory(target);
/*  89 */     DelegatingIntroductionInterceptor introduction = new DelegatingIntroductionInterceptor(endpoint);
/*  90 */     introduction.suppressInterface(MethodInterceptor.class);
/*  91 */     proxyFactory.addAdvice((Advice)introduction);
/*  92 */     return (MessageEndpoint)proxyFactory.getProxy(target.getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMessageEndpointFactory.AbstractMessageEndpoint createEndpointInternal() throws UnavailableException {
/* 100 */     return new GenericMessageEndpoint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class GenericMessageEndpoint
/*     */     extends AbstractMessageEndpointFactory.AbstractMessageEndpoint
/*     */     implements MethodInterceptor
/*     */   {
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation methodInvocation) throws Throwable {
/* 113 */       Throwable endpointEx = null;
/* 114 */       boolean applyDeliveryCalls = !hasBeforeDeliveryBeenCalled();
/* 115 */       if (applyDeliveryCalls) {
/*     */         try {
/* 117 */           beforeDelivery(null);
/*     */         }
/* 119 */         catch (ResourceException ex) {
/* 120 */           throw adaptExceptionIfNecessary(methodInvocation, ex);
/*     */         } 
/*     */       }
/*     */       try {
/* 124 */         return methodInvocation.proceed();
/*     */       }
/* 126 */       catch (Throwable ex) {
/* 127 */         endpointEx = ex;
/* 128 */         onEndpointException(ex);
/* 129 */         throw ex;
/*     */       } finally {
/*     */         
/* 132 */         if (applyDeliveryCalls) {
/*     */           try {
/* 134 */             afterDelivery();
/*     */           }
/* 136 */           catch (ResourceException ex) {
/* 137 */             if (endpointEx == null) {
/* 138 */               throw adaptExceptionIfNecessary(methodInvocation, ex);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private Exception adaptExceptionIfNecessary(MethodInvocation methodInvocation, ResourceException ex) {
/* 146 */       if (ReflectionUtils.declaresException(methodInvocation.getMethod(), ex.getClass())) {
/* 147 */         return (Exception)ex;
/*     */       }
/*     */       
/* 150 */       return new GenericMessageEndpointFactory.InternalResourceException(ex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected ClassLoader getEndpointClassLoader() {
/* 156 */       return GenericMessageEndpointFactory.this.getMessageListener().getClass().getClassLoader();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class InternalResourceException
/*     */     extends RuntimeException
/*     */   {
/*     */     public InternalResourceException(ResourceException cause) {
/* 173 */       super((Throwable)cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\endpoint\GenericMessageEndpointFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */