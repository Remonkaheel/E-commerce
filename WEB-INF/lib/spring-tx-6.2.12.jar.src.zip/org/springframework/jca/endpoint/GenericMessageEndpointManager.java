/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.ActivationSpec;
/*     */ import jakarta.resource.spi.ResourceAdapter;
/*     */ import jakarta.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericMessageEndpointManager
/*     */   implements SmartLifecycle, InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private ResourceAdapter resourceAdapter;
/*     */   @Nullable
/*     */   private MessageEndpointFactory messageEndpointFactory;
/*     */   @Nullable
/*     */   private ActivationSpec activationSpec;
/*     */   private boolean autoStartup = true;
/* 166 */   private int phase = Integer.MAX_VALUE;
/*     */   
/*     */   private volatile boolean running;
/*     */   
/* 170 */   private final Object lifecycleMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceAdapter(@Nullable ResourceAdapter resourceAdapter) {
/* 177 */     this.resourceAdapter = resourceAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceAdapter getResourceAdapter() {
/* 185 */     return this.resourceAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageEndpointFactory(@Nullable MessageEndpointFactory messageEndpointFactory) {
/* 197 */     this.messageEndpointFactory = messageEndpointFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MessageEndpointFactory getMessageEndpointFactory() {
/* 205 */     return this.messageEndpointFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActivationSpec(@Nullable ActivationSpec activationSpec) {
/* 214 */     this.activationSpec = activationSpec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ActivationSpec getActivationSpec() {
/* 222 */     return this.activationSpec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoStartup(boolean autoStartup) {
/* 232 */     this.autoStartup = autoStartup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoStartup() {
/* 241 */     return this.autoStartup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPhase(int phase) {
/* 252 */     this.phase = phase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPhase() {
/* 260 */     return this.phase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws ResourceException {
/* 269 */     if (getResourceAdapter() == null) {
/* 270 */       throw new IllegalArgumentException("Property 'resourceAdapter' is required");
/*     */     }
/* 272 */     if (getMessageEndpointFactory() == null) {
/* 273 */       throw new IllegalArgumentException("Property 'messageEndpointFactory' is required");
/*     */     }
/* 275 */     ActivationSpec activationSpec = getActivationSpec();
/* 276 */     if (activationSpec == null) {
/* 277 */       throw new IllegalArgumentException("Property 'activationSpec' is required");
/*     */     }
/*     */     
/* 280 */     if (activationSpec.getResourceAdapter() == null) {
/* 281 */       activationSpec.setResourceAdapter(getResourceAdapter());
/*     */     }
/* 283 */     else if (activationSpec.getResourceAdapter() != getResourceAdapter()) {
/* 284 */       throw new IllegalArgumentException("ActivationSpec [" + String.valueOf(activationSpec) + "] is associated with a different ResourceAdapter: " + 
/* 285 */           String.valueOf(activationSpec.getResourceAdapter()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 294 */     synchronized (this.lifecycleMonitor) {
/* 295 */       if (!this.running) {
/* 296 */         ResourceAdapter resourceAdapter = getResourceAdapter();
/* 297 */         Assert.state((resourceAdapter != null), "No ResourceAdapter set");
/*     */         try {
/* 299 */           resourceAdapter.endpointActivation(getMessageEndpointFactory(), getActivationSpec());
/*     */         }
/* 301 */         catch (ResourceException ex) {
/* 302 */           throw new IllegalStateException("Could not activate message endpoint", ex);
/*     */         } 
/* 304 */         this.running = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 314 */     synchronized (this.lifecycleMonitor) {
/* 315 */       if (this.running) {
/* 316 */         ResourceAdapter resourceAdapter = getResourceAdapter();
/* 317 */         Assert.state((resourceAdapter != null), "No ResourceAdapter set");
/* 318 */         resourceAdapter.endpointDeactivation(getMessageEndpointFactory(), getActivationSpec());
/* 319 */         this.running = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(Runnable callback) {
/* 326 */     synchronized (this.lifecycleMonitor) {
/* 327 */       stop();
/* 328 */       callback.run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 337 */     return this.running;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 345 */     stop();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\endpoint\GenericMessageEndpointManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */