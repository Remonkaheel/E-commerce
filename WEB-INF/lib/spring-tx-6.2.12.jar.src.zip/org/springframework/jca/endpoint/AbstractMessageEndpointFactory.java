/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.ApplicationServerInternalException;
/*     */ import jakarta.resource.spi.UnavailableException;
/*     */ import jakarta.resource.spi.endpoint.MessageEndpoint;
/*     */ import jakarta.resource.spi.endpoint.MessageEndpointFactory;
/*     */ import jakarta.transaction.Transaction;
/*     */ import jakarta.transaction.TransactionManager;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.jta.SimpleTransactionFactory;
/*     */ import org.springframework.transaction.jta.TransactionFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageEndpointFactory
/*     */   implements MessageEndpointFactory, BeanNameAware
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private TransactionFactory transactionFactory;
/*     */   
/*     */   @Nullable
/*     */   private String transactionName;
/*     */   
/*  60 */   private int transactionTimeout = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionManager(Object transactionManager) {
/*  80 */     if (transactionManager instanceof TransactionFactory) { TransactionFactory factory = (TransactionFactory)transactionManager;
/*  81 */       this.transactionFactory = factory; }
/*     */     
/*  83 */     else if (transactionManager instanceof TransactionManager) { TransactionManager manager = (TransactionManager)transactionManager;
/*  84 */       this.transactionFactory = (TransactionFactory)new SimpleTransactionFactory(manager); }
/*     */     else
/*     */     
/*  87 */     { throw new IllegalArgumentException("Transaction manager [" + String.valueOf(transactionManager) + "] is neither a [org.springframework.transaction.jta.TransactionFactory} nor a [jakarta.transaction.TransactionManager]"); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionFactory(TransactionFactory transactionFactory) {
/* 106 */     this.transactionFactory = transactionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionName(String transactionName) {
/* 115 */     this.transactionName = transactionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionTimeout(int transactionTimeout) {
/* 125 */     this.transactionTimeout = transactionTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanName(String beanName) {
/* 134 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getActivationName() {
/* 146 */     return this.beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getEndpointClass() {
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeliveryTransacted(Method method) throws NoSuchMethodException {
/* 167 */     return (this.transactionFactory != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource) throws UnavailableException {
/* 177 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/* 178 */     endpoint.initXAResource(xaResource);
/* 179 */     return endpoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageEndpoint createEndpoint(XAResource xaResource, long timeout) throws UnavailableException {
/* 189 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/* 190 */     endpoint.initXAResource(xaResource);
/* 191 */     return endpoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract AbstractMessageEndpoint createEndpointInternal() throws UnavailableException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract class AbstractMessageEndpoint
/*     */     implements MessageEndpoint
/*     */   {
/*     */     @Nullable
/*     */     private AbstractMessageEndpointFactory.TransactionDelegate transactionDelegate;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean beforeDeliveryCalled = false;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private ClassLoader previousContextClassLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void initXAResource(XAResource xaResource) {
/* 222 */       this.transactionDelegate = new AbstractMessageEndpointFactory.TransactionDelegate(xaResource);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void beforeDelivery(@Nullable Method method) throws ResourceException {
/* 237 */       this.beforeDeliveryCalled = true;
/* 238 */       Assert.state((this.transactionDelegate != null), "Not initialized");
/*     */       try {
/* 240 */         this.transactionDelegate.beginTransaction();
/*     */       }
/* 242 */       catch (Throwable ex) {
/* 243 */         throw new ApplicationServerInternalException("Failed to begin transaction", ex);
/*     */       } 
/* 245 */       Thread currentThread = Thread.currentThread();
/* 246 */       this.previousContextClassLoader = currentThread.getContextClassLoader();
/* 247 */       currentThread.setContextClassLoader(getEndpointClassLoader());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract ClassLoader getEndpointClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final boolean hasBeforeDeliveryBeenCalled() {
/* 263 */       return this.beforeDeliveryCalled;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void onEndpointException(Throwable ex) {
/* 274 */       Assert.state((this.transactionDelegate != null), "Not initialized");
/* 275 */       this.transactionDelegate.setRollbackOnly();
/* 276 */       AbstractMessageEndpointFactory.this.logger.debug("Transaction marked as rollback-only after endpoint exception", ex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void afterDelivery() throws ResourceException {
/* 288 */       Assert.state((this.transactionDelegate != null), "Not initialized");
/* 289 */       this.beforeDeliveryCalled = false;
/* 290 */       Thread.currentThread().setContextClassLoader(this.previousContextClassLoader);
/* 291 */       this.previousContextClassLoader = null;
/*     */       try {
/* 293 */         this.transactionDelegate.endTransaction();
/*     */       }
/* 295 */       catch (Throwable ex) {
/* 296 */         AbstractMessageEndpointFactory.this.logger.warn("Failed to complete transaction after endpoint delivery", ex);
/* 297 */         throw new ApplicationServerInternalException("Failed to complete transaction", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void release() {
/* 303 */       if (this.transactionDelegate != null) {
/*     */         try {
/* 305 */           this.transactionDelegate.setRollbackOnly();
/* 306 */           this.transactionDelegate.endTransaction();
/*     */         }
/* 308 */         catch (Throwable ex) {
/* 309 */           AbstractMessageEndpointFactory.this.logger.warn("Could not complete unfinished transaction on endpoint release", ex);
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class TransactionDelegate
/*     */   {
/*     */     @Nullable
/*     */     private final XAResource xaResource;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Transaction transaction;
/*     */ 
/*     */     
/*     */     private boolean rollbackOnly;
/*     */ 
/*     */     
/*     */     public TransactionDelegate(XAResource xaResource) {
/* 331 */       if (xaResource == null && AbstractMessageEndpointFactory.this.transactionFactory != null && 
/* 332 */         !AbstractMessageEndpointFactory.this.transactionFactory.supportsResourceAdapterManagedTransactions()) {
/* 333 */         throw new IllegalStateException("ResourceAdapter-provided XAResource is required for transaction management. Check your ResourceAdapter's configuration.");
/*     */       }
/*     */       
/* 336 */       this.xaResource = xaResource;
/*     */     }
/*     */     
/*     */     public void beginTransaction() throws Exception {
/* 340 */       if (AbstractMessageEndpointFactory.this.transactionFactory != null && this.xaResource != null) {
/* 341 */         this.transaction = AbstractMessageEndpointFactory.this.transactionFactory.createTransaction(AbstractMessageEndpointFactory.this.transactionName, AbstractMessageEndpointFactory.this.transactionTimeout);
/* 342 */         this.transaction.enlistResource(this.xaResource);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void setRollbackOnly() {
/* 347 */       if (this.transaction != null) {
/* 348 */         this.rollbackOnly = true;
/*     */       }
/*     */     }
/*     */     
/*     */     public void endTransaction() throws Exception {
/* 353 */       if (this.transaction != null)
/*     */         try {
/* 355 */           if (this.rollbackOnly) {
/* 356 */             this.transaction.rollback();
/*     */           } else {
/*     */             
/* 359 */             this.transaction.commit();
/*     */           } 
/*     */         } finally {
/*     */           
/* 363 */           this.transaction = null;
/* 364 */           this.rollbackOnly = false;
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\endpoint\AbstractMessageEndpointFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */