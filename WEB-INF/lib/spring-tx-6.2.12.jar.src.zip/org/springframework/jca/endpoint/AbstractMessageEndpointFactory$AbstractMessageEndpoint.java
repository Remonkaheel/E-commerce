/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import jakarta.resource.spi.ApplicationServerInternalException;
/*     */ import jakarta.resource.spi.endpoint.MessageEndpoint;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessageEndpoint
/*     */   implements MessageEndpoint
/*     */ {
/*     */   @Nullable
/*     */   private AbstractMessageEndpointFactory.TransactionDelegate transactionDelegate;
/*     */   private boolean beforeDeliveryCalled = false;
/*     */   @Nullable
/*     */   private ClassLoader previousContextClassLoader;
/*     */   
/*     */   void initXAResource(XAResource xaResource) {
/* 222 */     this.transactionDelegate = new AbstractMessageEndpointFactory.TransactionDelegate(AbstractMessageEndpointFactory.this, xaResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeDelivery(@Nullable Method method) throws ResourceException {
/* 237 */     this.beforeDeliveryCalled = true;
/* 238 */     Assert.state((this.transactionDelegate != null), "Not initialized");
/*     */     try {
/* 240 */       this.transactionDelegate.beginTransaction();
/*     */     }
/* 242 */     catch (Throwable ex) {
/* 243 */       throw new ApplicationServerInternalException("Failed to begin transaction", ex);
/*     */     } 
/* 245 */     Thread currentThread = Thread.currentThread();
/* 246 */     this.previousContextClassLoader = currentThread.getContextClassLoader();
/* 247 */     currentThread.setContextClassLoader(getEndpointClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ClassLoader getEndpointClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasBeforeDeliveryBeenCalled() {
/* 263 */     return this.beforeDeliveryCalled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onEndpointException(Throwable ex) {
/* 274 */     Assert.state((this.transactionDelegate != null), "Not initialized");
/* 275 */     this.transactionDelegate.setRollbackOnly();
/* 276 */     AbstractMessageEndpointFactory.this.logger.debug("Transaction marked as rollback-only after endpoint exception", ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterDelivery() throws ResourceException {
/* 288 */     Assert.state((this.transactionDelegate != null), "Not initialized");
/* 289 */     this.beforeDeliveryCalled = false;
/* 290 */     Thread.currentThread().setContextClassLoader(this.previousContextClassLoader);
/* 291 */     this.previousContextClassLoader = null;
/*     */     try {
/* 293 */       this.transactionDelegate.endTransaction();
/*     */     }
/* 295 */     catch (Throwable ex) {
/* 296 */       AbstractMessageEndpointFactory.this.logger.warn("Failed to complete transaction after endpoint delivery", ex);
/* 297 */       throw new ApplicationServerInternalException("Failed to complete transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 303 */     if (this.transactionDelegate != null)
/*     */       try {
/* 305 */         this.transactionDelegate.setRollbackOnly();
/* 306 */         this.transactionDelegate.endTransaction();
/*     */       }
/* 308 */       catch (Throwable ex) {
/* 309 */         AbstractMessageEndpointFactory.this.logger.warn("Could not complete unfinished transaction on endpoint release", ex);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\endpoint\AbstractMessageEndpointFactory$AbstractMessageEndpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */