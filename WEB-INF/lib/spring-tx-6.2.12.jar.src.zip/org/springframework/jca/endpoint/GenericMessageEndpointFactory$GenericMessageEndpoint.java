/*     */ package org.springframework.jca.endpoint;
/*     */ 
/*     */ import jakarta.resource.ResourceException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GenericMessageEndpoint
/*     */   extends AbstractMessageEndpointFactory.AbstractMessageEndpoint
/*     */   implements MethodInterceptor
/*     */ {
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation methodInvocation) throws Throwable {
/* 113 */     Throwable endpointEx = null;
/* 114 */     boolean applyDeliveryCalls = !hasBeforeDeliveryBeenCalled();
/* 115 */     if (applyDeliveryCalls) {
/*     */       try {
/* 117 */         beforeDelivery(null);
/*     */       }
/* 119 */       catch (ResourceException ex) {
/* 120 */         throw adaptExceptionIfNecessary(methodInvocation, ex);
/*     */       } 
/*     */     }
/*     */     try {
/* 124 */       return methodInvocation.proceed();
/*     */     }
/* 126 */     catch (Throwable ex) {
/* 127 */       endpointEx = ex;
/* 128 */       onEndpointException(ex);
/* 129 */       throw ex;
/*     */     } finally {
/*     */       
/* 132 */       if (applyDeliveryCalls) {
/*     */         try {
/* 134 */           afterDelivery();
/*     */         }
/* 136 */         catch (ResourceException ex) {
/* 137 */           if (endpointEx == null) {
/* 138 */             throw adaptExceptionIfNecessary(methodInvocation, ex);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Exception adaptExceptionIfNecessary(MethodInvocation methodInvocation, ResourceException ex) {
/* 146 */     if (ReflectionUtils.declaresException(methodInvocation.getMethod(), ex.getClass())) {
/* 147 */       return (Exception)ex;
/*     */     }
/*     */     
/* 150 */     return new GenericMessageEndpointFactory.InternalResourceException(ex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassLoader getEndpointClassLoader() {
/* 156 */     return GenericMessageEndpointFactory.this.getMessageListener().getClass().getClassLoader();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-tx-6.2.12.jar!\org\springframework\jca\endpoint\GenericMessageEndpointFactory$GenericMessageEndpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */