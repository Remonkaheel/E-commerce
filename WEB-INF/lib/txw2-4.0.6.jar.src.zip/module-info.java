module com.sun.xml.txw2 {
  requires java.base;
  requires transitive java.xml;
  
  exports com.sun.xml.txw2;
  exports com.sun.xml.txw2.annotation;
  exports com.sun.xml.txw2.output;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */