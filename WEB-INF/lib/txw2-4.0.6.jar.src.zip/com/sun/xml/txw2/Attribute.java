/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Attribute
/*    */ {
/*    */   final String nsUri;
/*    */   final String localName;
/*    */   Attribute next;
/* 28 */   final StringBuilder value = new StringBuilder();
/*    */   
/*    */   Attribute(String nsUri, String localName) {
/* 31 */     assert nsUri != null && localName != null;
/*    */     
/* 33 */     this.nsUri = nsUri;
/* 34 */     this.localName = localName;
/*    */   }
/*    */   
/*    */   boolean hasName(String nsUri, String localName) {
/* 38 */     return (this.localName.equals(localName) && this.nsUri.equals(nsUri));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Attribute.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */