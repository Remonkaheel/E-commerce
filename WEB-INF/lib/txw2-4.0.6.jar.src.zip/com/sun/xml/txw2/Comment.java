/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Comment
/*    */   extends Content
/*    */ {
/* 22 */   private final StringBuilder buffer = new StringBuilder();
/*    */   
/*    */   public Comment(Document document, NamespaceResolver nsResolver, Object obj) {
/* 25 */     document.writeValue(obj, nsResolver, this.buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   boolean concludesPendingStartTag() {
/* 30 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   void accept(ContentVisitor visitor) {
/* 35 */     visitor.onComment(this.buffer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Comment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */