/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndentingXMLStreamWriter
/*     */   extends DelegatingXMLStreamWriter
/*     */ {
/*  21 */   private static final Object SEEN_NOTHING = new Object();
/*  22 */   private static final Object SEEN_ELEMENT = new Object();
/*  23 */   private static final Object SEEN_DATA = new Object();
/*     */   
/*  25 */   private Object state = SEEN_NOTHING;
/*  26 */   private Stack<Object> stateStack = new Stack();
/*     */   
/*  28 */   private String indentStep = "  ";
/*  29 */   private int depth = 0;
/*     */   
/*     */   public IndentingXMLStreamWriter(XMLStreamWriter writer) {
/*  32 */     super(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getIndentStep() {
/*  51 */     return this.indentStep.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setIndentStep(int indentStep) {
/*  67 */     StringBuilder s = new StringBuilder();
/*  68 */     while (indentStep > 0) { s.append(' '); indentStep--; }
/*  69 */      setIndentStep(s.toString());
/*     */   }
/*     */   
/*     */   public void setIndentStep(String s) {
/*  73 */     this.indentStep = s;
/*     */   }
/*     */   
/*     */   private void onStartElement() throws XMLStreamException {
/*  77 */     this.stateStack.push(SEEN_ELEMENT);
/*  78 */     this.state = SEEN_NOTHING;
/*  79 */     if (this.depth > 0) {
/*  80 */       super.writeCharacters("\n");
/*     */     }
/*  82 */     doIndent();
/*  83 */     this.depth++;
/*     */   }
/*     */   
/*     */   private void onEndElement() throws XMLStreamException {
/*  87 */     this.depth--;
/*  88 */     if (this.state == SEEN_ELEMENT) {
/*  89 */       super.writeCharacters("\n");
/*  90 */       doIndent();
/*     */     } 
/*  92 */     this.state = this.stateStack.pop();
/*     */   }
/*     */   
/*     */   private void onEmptyElement() throws XMLStreamException {
/*  96 */     this.state = SEEN_ELEMENT;
/*  97 */     if (this.depth > 0) {
/*  98 */       super.writeCharacters("\n");
/*     */     }
/* 100 */     doIndent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doIndent() throws XMLStreamException {
/* 111 */     if (this.depth > 0) {
/* 112 */       for (int i = 0; i < this.depth; i++) {
/* 113 */         super.writeCharacters(this.indentStep);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartDocument() throws XMLStreamException {
/* 120 */     super.writeStartDocument();
/* 121 */     super.writeCharacters("\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartDocument(String version) throws XMLStreamException {
/* 126 */     super.writeStartDocument(version);
/* 127 */     super.writeCharacters("\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartDocument(String encoding, String version) throws XMLStreamException {
/* 132 */     super.writeStartDocument(encoding, version);
/* 133 */     super.writeCharacters("\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartElement(String localName) throws XMLStreamException {
/* 138 */     onStartElement();
/* 139 */     super.writeStartElement(localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartElement(String namespaceURI, String localName) throws XMLStreamException {
/* 144 */     onStartElement();
/* 145 */     super.writeStartElement(namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/* 150 */     onStartElement();
/* 151 */     super.writeStartElement(prefix, localName, namespaceURI);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String namespaceURI, String localName) throws XMLStreamException {
/* 156 */     onEmptyElement();
/* 157 */     super.writeEmptyElement(namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/* 162 */     onEmptyElement();
/* 163 */     super.writeEmptyElement(prefix, localName, namespaceURI);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String localName) throws XMLStreamException {
/* 168 */     onEmptyElement();
/* 169 */     super.writeEmptyElement(localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndElement() throws XMLStreamException {
/* 174 */     onEndElement();
/* 175 */     super.writeEndElement();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeCharacters(String text) throws XMLStreamException {
/* 180 */     this.state = SEEN_DATA;
/* 181 */     super.writeCharacters(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeCharacters(char[] text, int start, int len) throws XMLStreamException {
/* 186 */     this.state = SEEN_DATA;
/* 187 */     super.writeCharacters(text, start, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeCData(String data) throws XMLStreamException {
/* 192 */     this.state = SEEN_DATA;
/* 193 */     super.writeCData(data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\IndentingXMLStreamWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */