/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import com.sun.xml.txw2.TxwException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaxSerializer
/*     */   implements XmlSerializer
/*     */ {
/*     */   private final XMLStreamWriter out;
/*     */   
/*     */   public StaxSerializer(XMLStreamWriter writer) {
/*  30 */     this(writer, true);
/*     */   }
/*     */   
/*     */   public StaxSerializer(XMLStreamWriter writer, boolean indenting) {
/*  34 */     if (indenting)
/*  35 */       writer = new IndentingXMLStreamWriter(writer); 
/*  36 */     this.out = writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {
/*     */     try {
/*  42 */       this.out.writeStartDocument();
/*  43 */     } catch (XMLStreamException e) {
/*  44 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(String uri, String localName, String prefix) {
/*     */     try {
/*  51 */       this.out.writeStartElement(prefix, localName, uri);
/*  52 */     } catch (XMLStreamException e) {
/*  53 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/*     */     try {
/*  60 */       this.out.writeAttribute(prefix, uri, localName, value.toString());
/*  61 */     } catch (XMLStreamException e) {
/*  62 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeXmlns(String prefix, String uri) {
/*     */     try {
/*  69 */       if (prefix.length() == 0) {
/*  70 */         this.out.setDefaultNamespace(uri);
/*     */       } else {
/*  72 */         this.out.setPrefix(prefix, uri);
/*     */       } 
/*     */ 
/*     */       
/*  76 */       this.out.writeNamespace(prefix, uri);
/*  77 */     } catch (XMLStreamException e) {
/*  78 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endStartTag(String uri, String localName, String prefix) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag() {
/*     */     try {
/*  90 */       this.out.writeEndElement();
/*  91 */     } catch (XMLStreamException e) {
/*  92 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(StringBuilder text) {
/*     */     try {
/*  99 */       this.out.writeCharacters(text.toString());
/* 100 */     } catch (XMLStreamException e) {
/* 101 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cdata(StringBuilder text) {
/*     */     try {
/* 108 */       this.out.writeCData(text.toString());
/* 109 */     } catch (XMLStreamException e) {
/* 110 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(StringBuilder comment) {
/*     */     try {
/* 117 */       this.out.writeComment(comment.toString());
/* 118 */     } catch (XMLStreamException e) {
/* 119 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() {
/*     */     try {
/* 126 */       this.out.writeEndDocument();
/* 127 */       this.out.flush();
/* 128 */     } catch (XMLStreamException e) {
/* 129 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/*     */     try {
/* 136 */       this.out.flush();
/* 137 */     } catch (XMLStreamException e) {
/* 138 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\StaxSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */