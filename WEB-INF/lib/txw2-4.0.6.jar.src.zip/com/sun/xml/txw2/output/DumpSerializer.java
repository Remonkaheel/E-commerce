/*    */ package com.sun.xml.txw2.output;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DumpSerializer
/*    */   implements XmlSerializer
/*    */ {
/*    */   private final PrintStream out;
/*    */   
/*    */   public DumpSerializer(PrintStream out) {
/* 26 */     this.out = out;
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginStartTag(String uri, String localName, String prefix) {
/* 31 */     this.out.println("<" + prefix + ":" + localName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/* 36 */     this.out.println("@" + prefix + ":" + localName + "=" + value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeXmlns(String prefix, String uri) {
/* 41 */     this.out.println("xmlns:" + prefix + "=" + uri);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endStartTag(String uri, String localName, String prefix) {
/* 46 */     this.out.println('>');
/*    */   }
/*    */ 
/*    */   
/*    */   public void endTag() {
/* 51 */     this.out.println("</  >");
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(StringBuilder text) {
/* 56 */     this.out.println(text);
/*    */   }
/*    */ 
/*    */   
/*    */   public void cdata(StringBuilder text) {
/* 61 */     this.out.println("<![CDATA[");
/* 62 */     this.out.println(text);
/* 63 */     this.out.println("]]>");
/*    */   }
/*    */ 
/*    */   
/*    */   public void comment(StringBuilder comment) {
/* 68 */     this.out.println("<!--");
/* 69 */     this.out.println(comment);
/* 70 */     this.out.println("-->");
/*    */   }
/*    */ 
/*    */   
/*    */   public void startDocument() {
/* 75 */     this.out.println("<?xml?>");
/*    */   }
/*    */ 
/*    */   
/*    */   public void endDocument() {
/* 80 */     this.out.println("done");
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() {
/* 85 */     this.out.println("flush");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\DumpSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */