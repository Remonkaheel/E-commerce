/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import com.sun.xml.txw2.TxwException;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamSerializer
/*     */   implements XmlSerializer
/*     */ {
/*     */   private final SaxSerializer serializer;
/*     */   private final XMLWriter writer;
/*     */   
/*     */   public StreamSerializer(OutputStream out) {
/*  37 */     this(createWriter(out));
/*     */   }
/*     */   
/*     */   public StreamSerializer(OutputStream out, String encoding) throws UnsupportedEncodingException {
/*  41 */     this(createWriter(out, encoding));
/*     */   }
/*     */   
/*     */   public StreamSerializer(Writer out) {
/*  45 */     this(new StreamResult(out));
/*     */   }
/*     */ 
/*     */   
/*     */   public StreamSerializer(StreamResult streamResult) {
/*  50 */     final OutputStream[] autoClose = new OutputStream[1];
/*     */     
/*  52 */     if (streamResult.getWriter() != null) {
/*  53 */       this.writer = createWriter(streamResult.getWriter());
/*  54 */     } else if (streamResult.getOutputStream() != null) {
/*  55 */       this.writer = createWriter(streamResult.getOutputStream());
/*  56 */     } else if (streamResult.getSystemId() != null) {
/*  57 */       String fileURL = streamResult.getSystemId();
/*     */       
/*  59 */       fileURL = convertURL(fileURL);
/*     */       
/*     */       try {
/*  62 */         FileOutputStream fos = new FileOutputStream(fileURL);
/*  63 */         autoClose[0] = fos;
/*  64 */         this.writer = createWriter(fos);
/*  65 */       } catch (IOException e) {
/*  66 */         throw new TxwException(e);
/*     */       } 
/*     */     } else {
/*  69 */       throw new IllegalArgumentException();
/*     */     } 
/*     */     
/*  72 */     this.serializer = new SaxSerializer(this.writer, this.writer, false)
/*     */       {
/*     */         public void endDocument() {
/*  75 */           super.endDocument();
/*  76 */           if (autoClose[0] != null) {
/*     */             try {
/*  78 */               autoClose[0].close();
/*  79 */             } catch (IOException e) {
/*  80 */               throw new TxwException(e);
/*     */             } 
/*  82 */             autoClose[0] = null;
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private StreamSerializer(XMLWriter writer) {
/*  89 */     this.writer = writer;
/*     */     
/*  91 */     this.serializer = new SaxSerializer(writer, writer, false);
/*     */   }
/*     */   
/*     */   private String convertURL(String url) {
/*  95 */     url = url.replace('\\', '/');
/*  96 */     url = url.replaceAll("//", "/");
/*  97 */     url = url.replaceAll("//", "/");
/*  98 */     if (url.startsWith("file:/"))
/*  99 */       if (url.substring(6).indexOf(":") > 0) {
/* 100 */         url = url.substring(6);
/*     */       } else {
/* 102 */         url = url.substring(5);
/*     */       }  
/* 104 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() {
/* 110 */     this.serializer.startDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(String uri, String localName, String prefix) {
/* 115 */     this.serializer.beginStartTag(uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/* 120 */     this.serializer.writeAttribute(uri, localName, prefix, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeXmlns(String prefix, String uri) {
/* 125 */     this.serializer.writeXmlns(prefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag(String uri, String localName, String prefix) {
/* 130 */     this.serializer.endStartTag(uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag() {
/* 135 */     this.serializer.endTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(StringBuilder text) {
/* 140 */     this.serializer.text(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cdata(StringBuilder text) {
/* 145 */     this.serializer.cdata(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(StringBuilder comment) {
/* 150 */     this.serializer.comment(comment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() {
/* 155 */     this.serializer.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/* 160 */     this.serializer.flush();
/*     */     try {
/* 162 */       this.writer.flush();
/* 163 */     } catch (IOException e) {
/* 164 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static XMLWriter createWriter(Writer w) {
/* 171 */     DataWriter dw = new DataWriter(new BufferedWriter(w));
/* 172 */     dw.setIndentStep("  ");
/* 173 */     return dw;
/*     */   }
/*     */   
/*     */   private static XMLWriter createWriter(OutputStream os, String encoding) throws UnsupportedEncodingException {
/* 177 */     XMLWriter writer = createWriter(new OutputStreamWriter(os, encoding));
/* 178 */     writer.setEncoding(encoding);
/* 179 */     return writer;
/*     */   }
/*     */   
/*     */   private static XMLWriter createWriter(OutputStream os) {
/*     */     try {
/* 184 */       return createWriter(os, "UTF-8");
/* 185 */     } catch (UnsupportedEncodingException e) {
/*     */       
/* 187 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\StreamSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */