/*    */ package com.sun.xml.txw2.output;
/*    */ 
/*    */ import com.sun.xml.txw2.TypedXmlWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TXWSerializer
/*    */   implements XmlSerializer
/*    */ {
/*    */   public final TypedXmlWriter txw;
/*    */   
/*    */   public TXWSerializer(TypedXmlWriter txw) {
/* 26 */     this.txw = txw;
/*    */   }
/*    */ 
/*    */   
/*    */   public void startDocument() {
/* 31 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endDocument() {
/* 36 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginStartTag(String uri, String localName, String prefix) {
/* 41 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/* 46 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeXmlns(String prefix, String uri) {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endStartTag(String uri, String localName, String prefix) {
/* 56 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endTag() {
/* 61 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(StringBuilder text) {
/* 66 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void cdata(StringBuilder text) {
/* 71 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void comment(StringBuilder comment) {
/* 76 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() {
/* 81 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\TXWSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */