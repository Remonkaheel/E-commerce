/*    */ package com.sun.xml.txw2.output;
/*    */ 
/*    */ import com.sun.xml.txw2.TypedXmlWriter;
/*    */ import javax.xml.transform.Result;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TXWResult
/*    */   implements Result
/*    */ {
/*    */   private String systemId;
/*    */   private TypedXmlWriter writer;
/*    */   
/*    */   public TXWResult(TypedXmlWriter writer) {
/* 33 */     this.writer = writer;
/*    */   }
/*    */   
/*    */   public TypedXmlWriter getWriter() {
/* 37 */     return this.writer;
/*    */   }
/*    */   
/*    */   public void setWriter(TypedXmlWriter writer) {
/* 41 */     this.writer = writer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSystemId() {
/* 46 */     return this.systemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSystemId(String systemId) {
/* 51 */     this.systemId = systemId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\TXWResult.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */