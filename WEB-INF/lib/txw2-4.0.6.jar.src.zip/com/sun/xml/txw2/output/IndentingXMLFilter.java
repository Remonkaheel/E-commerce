/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.XMLFilterImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndentingXMLFilter
/*     */   extends XMLFilterImpl
/*     */   implements LexicalHandler
/*     */ {
/*     */   private LexicalHandler lexical;
/*     */   
/*     */   public IndentingXMLFilter() {}
/*     */   
/*     */   public IndentingXMLFilter(ContentHandler handler) {
/*  33 */     setContentHandler(handler);
/*     */   }
/*     */   
/*     */   public IndentingXMLFilter(ContentHandler handler, LexicalHandler lexical) {
/*  37 */     setContentHandler(handler);
/*  38 */     setLexicalHandler(lexical);
/*     */   }
/*     */   
/*     */   public LexicalHandler getLexicalHandler() {
/*  42 */     return this.lexical;
/*     */   }
/*     */   
/*     */   public void setLexicalHandler(LexicalHandler lexical) {
/*  46 */     this.lexical = lexical;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getIndentStep() {
/*  67 */     return this.indentStep.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setIndentStep(int indentStep) {
/*  84 */     StringBuilder s = new StringBuilder();
/*  85 */     while (indentStep > 0) { s.append(' '); indentStep--; }
/*  86 */      setIndentStep(s.toString());
/*     */   }
/*     */   
/*     */   public void setIndentStep(String s) {
/*  90 */     this.indentStep = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
/* 122 */     this.stateStack.push(SEEN_ELEMENT);
/* 123 */     this.state = SEEN_NOTHING;
/* 124 */     if (this.depth > 0) {
/* 125 */       writeNewLine();
/*     */     }
/* 127 */     doIndent();
/* 128 */     super.startElement(uri, localName, qName, atts);
/* 129 */     this.depth++;
/*     */   }
/*     */   
/*     */   private void writeNewLine() throws SAXException {
/* 133 */     super.characters(NEWLINE, 0, NEWLINE.length);
/*     */   }
/*     */   
/* 136 */   private static final char[] NEWLINE = new char[] { '\n' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 161 */     this.depth--;
/* 162 */     if (this.state == SEEN_ELEMENT) {
/* 163 */       writeNewLine();
/* 164 */       doIndent();
/*     */     } 
/* 166 */     super.endElement(uri, localName, qName);
/* 167 */     this.state = this.stateStack.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 218 */     this.state = SEEN_DATA;
/* 219 */     super.characters(ch, start, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/* 224 */     if (this.depth > 0) {
/* 225 */       writeNewLine();
/*     */     }
/* 227 */     doIndent();
/* 228 */     if (this.lexical != null) {
/* 229 */       this.lexical.comment(ch, start, length);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {
/* 234 */     if (this.lexical != null) {
/* 235 */       this.lexical.startDTD(name, publicId, systemId);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endDTD() throws SAXException {
/* 240 */     if (this.lexical != null) {
/* 241 */       this.lexical.endDTD();
/*     */     }
/*     */   }
/*     */   
/*     */   public void startEntity(String name) throws SAXException {
/* 246 */     if (this.lexical != null) {
/* 247 */       this.lexical.startEntity(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endEntity(String name) throws SAXException {
/* 252 */     if (this.lexical != null) {
/* 253 */       this.lexical.endEntity(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startCDATA() throws SAXException {
/* 258 */     if (this.lexical != null) {
/* 259 */       this.lexical.startCDATA();
/*     */     }
/*     */   }
/*     */   
/*     */   public void endCDATA() throws SAXException {
/* 264 */     if (this.lexical != null) {
/* 265 */       this.lexical.endCDATA();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doIndent() throws SAXException {
/* 283 */     if (this.depth > 0) {
/* 284 */       char[] ch = this.indentStep.toCharArray();
/* 285 */       for (int i = 0; i < this.depth; i++) {
/* 286 */         characters(ch, 0, ch.length);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   private static final Object SEEN_NOTHING = new Object();
/* 296 */   private static final Object SEEN_ELEMENT = new Object();
/* 297 */   private static final Object SEEN_DATA = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   private Object state = SEEN_NOTHING;
/* 305 */   private Stack<Object> stateStack = new Stack();
/*     */   
/* 307 */   private String indentStep = "";
/* 308 */   private int depth = 0;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\IndentingXMLFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */