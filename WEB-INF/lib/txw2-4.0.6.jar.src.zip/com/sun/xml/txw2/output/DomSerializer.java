/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import com.sun.xml.txw2.TxwException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DomSerializer
/*     */   implements XmlSerializer
/*     */ {
/*     */   private final SaxSerializer serializer;
/*     */   
/*     */   public DomSerializer(Node node) {
/*  43 */     Dom2SaxAdapter adapter = new Dom2SaxAdapter(node);
/*  44 */     this.serializer = new SaxSerializer(adapter, adapter, false);
/*     */   }
/*     */   
/*     */   public DomSerializer(DOMResult domResult) {
/*  48 */     Node node = domResult.getNode();
/*     */     
/*  50 */     if (node == null) {
/*     */       try {
/*  52 */         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  53 */         dbf.setNamespaceAware(true);
/*  54 */         DocumentBuilder db = dbf.newDocumentBuilder();
/*  55 */         Document doc = db.newDocument();
/*  56 */         domResult.setNode(doc);
/*  57 */         this.serializer = new SaxSerializer(new Dom2SaxAdapter(doc), null, false);
/*  58 */       } catch (ParserConfigurationException pce) {
/*  59 */         throw new TxwException(pce);
/*     */       } 
/*     */     } else {
/*  62 */       this.serializer = new SaxSerializer(new Dom2SaxAdapter(node), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() {
/*  69 */     this.serializer.startDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(String uri, String localName, String prefix) {
/*  74 */     this.serializer.beginStartTag(uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/*  79 */     this.serializer.writeAttribute(uri, localName, prefix, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeXmlns(String prefix, String uri) {
/*  84 */     this.serializer.writeXmlns(prefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag(String uri, String localName, String prefix) {
/*  89 */     this.serializer.endStartTag(uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag() {
/*  94 */     this.serializer.endTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(StringBuilder text) {
/*  99 */     this.serializer.text(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cdata(StringBuilder text) {
/* 104 */     this.serializer.cdata(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(StringBuilder comment) {
/* 109 */     this.serializer.comment(comment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() {
/* 114 */     this.serializer.endDocument();
/*     */   }
/*     */   
/*     */   public void flush() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\DomSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */