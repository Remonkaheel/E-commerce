/*     */ package com.sun.xml.txw2.output;
/*     */ 
/*     */ import com.sun.xml.txw2.TxwException;
/*     */ import java.util.Stack;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaxSerializer
/*     */   implements XmlSerializer
/*     */ {
/*     */   private final ContentHandler writer;
/*     */   private final LexicalHandler lexical;
/*     */   
/*     */   public SaxSerializer(ContentHandler handler) {
/*  33 */     this(handler, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SaxSerializer(ContentHandler handler, LexicalHandler lex) {
/*  46 */     this(handler, lex, true);
/*     */   }
/*     */   
/*     */   public SaxSerializer(ContentHandler handler, LexicalHandler lex, boolean indenting) {
/*  50 */     if (!indenting) {
/*  51 */       this.writer = handler;
/*  52 */       this.lexical = lex;
/*     */     } else {
/*  54 */       IndentingXMLFilter indenter = new IndentingXMLFilter(handler, lex);
/*  55 */       this.writer = indenter;
/*  56 */       this.lexical = indenter;
/*     */     } 
/*     */   }
/*     */   
/*     */   public SaxSerializer(SAXResult result) {
/*  61 */     this(result.getHandler(), result.getLexicalHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() {
/*     */     try {
/*  70 */       this.writer.startDocument();
/*  71 */     } catch (SAXException e) {
/*  72 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  78 */   private final Stack<String> prefixBindings = new Stack<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeXmlns(String prefix, String uri) {
/*  83 */     if (prefix == null) {
/*  84 */       prefix = "";
/*     */     }
/*     */     
/*  87 */     if (prefix.equals("xml")) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     this.prefixBindings.add(uri);
/*  92 */     this.prefixBindings.add(prefix);
/*     */   }
/*     */ 
/*     */   
/*  96 */   private final Stack<String> elementBindings = new Stack<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginStartTag(String uri, String localName, String prefix) {
/* 101 */     this.elementBindings.add(getQName(prefix, localName));
/* 102 */     this.elementBindings.add(localName);
/* 103 */     this.elementBindings.add(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private final AttributesImpl attrs = new AttributesImpl();
/*     */ 
/*     */   
/*     */   public void writeAttribute(String uri, String localName, String prefix, StringBuilder value) {
/* 113 */     this.attrs.addAttribute(uri, localName, 
/*     */         
/* 115 */         getQName(prefix, localName), "CDATA", value
/*     */         
/* 117 */         .toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag(String uri, String localName, String prefix) {
/*     */     try {
/* 123 */       while (this.prefixBindings.size() != 0) {
/* 124 */         this.writer.startPrefixMapping(this.prefixBindings.pop(), this.prefixBindings
/* 125 */             .pop());
/*     */       }
/*     */ 
/*     */       
/* 129 */       this.writer.startElement(uri, localName, 
/*     */           
/* 131 */           getQName(prefix, localName), this.attrs);
/*     */ 
/*     */       
/* 134 */       this.attrs.clear();
/* 135 */     } catch (SAXException e) {
/* 136 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag() {
/*     */     try {
/* 143 */       this.writer.endElement(this.elementBindings.pop(), this.elementBindings
/* 144 */           .pop(), this.elementBindings
/* 145 */           .pop());
/*     */     }
/* 147 */     catch (SAXException e) {
/* 148 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(StringBuilder text) {
/*     */     try {
/* 155 */       this.writer.characters(text.toString().toCharArray(), 0, text.length());
/* 156 */     } catch (SAXException e) {
/* 157 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cdata(StringBuilder text) {
/* 163 */     if (this.lexical == null) {
/* 164 */       throw new UnsupportedOperationException("LexicalHandler is needed to write PCDATA");
/*     */     }
/*     */     try {
/* 167 */       this.lexical.startCDATA();
/* 168 */       text(text);
/* 169 */       this.lexical.endCDATA();
/* 170 */     } catch (SAXException e) {
/* 171 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(StringBuilder comment) {
/*     */     try {
/* 178 */       if (this.lexical == null) {
/* 179 */         throw new UnsupportedOperationException("LexicalHandler is needed to write comments");
/*     */       }
/* 181 */       this.lexical.comment(comment.toString().toCharArray(), 0, comment.length());
/* 182 */     } catch (SAXException e) {
/* 183 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() {
/*     */     try {
/* 190 */       this.writer.endDocument();
/* 191 */     } catch (SAXException e) {
/* 192 */       throw new TxwException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getQName(String prefix, String localName) {
/*     */     String qName;
/* 204 */     if (prefix == null || prefix.length() == 0) {
/* 205 */       qName = localName;
/*     */     } else {
/* 207 */       qName = prefix + ":" + prefix;
/*     */     } 
/* 209 */     return qName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\SaxSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */