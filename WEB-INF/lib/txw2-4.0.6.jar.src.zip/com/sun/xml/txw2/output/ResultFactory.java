/*    */ package com.sun.xml.txw2.output;
/*    */ 
/*    */ import javax.xml.transform.Result;
/*    */ import javax.xml.transform.dom.DOMResult;
/*    */ import javax.xml.transform.sax.SAXResult;
/*    */ import javax.xml.transform.stream.StreamResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResultFactory
/*    */ {
/*    */   public static XmlSerializer createSerializer(Result result) {
/* 40 */     if (result instanceof SAXResult)
/* 41 */       return new SaxSerializer((SAXResult)result); 
/* 42 */     if (result instanceof DOMResult)
/* 43 */       return new DomSerializer((DOMResult)result); 
/* 44 */     if (result instanceof StreamResult)
/* 45 */       return new StreamSerializer((StreamResult)result); 
/* 46 */     if (result instanceof TXWResult) {
/* 47 */       return new TXWSerializer(((TXWResult)result).getWriter());
/*    */     }
/* 49 */     throw new UnsupportedOperationException("Unsupported Result type: " + result.getClass().getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\output\ResultFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */