/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TxwException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public TxwException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */   
/*    */   public TxwException(Throwable cause) {
/* 22 */     super(cause);
/*    */   }
/*    */   
/*    */   public TxwException(String message, Throwable cause) {
/* 26 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\TxwException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */