package com.sun.xml.txw2;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\package-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */