/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Cdata
/*    */   extends Text
/*    */ {
/*    */   Cdata(Document document, NamespaceResolver nsResolver, Object obj) {
/* 20 */     super(document, nsResolver, obj);
/*    */   }
/*    */ 
/*    */   
/*    */   void accept(ContentVisitor visitor) {
/* 25 */     visitor.onCdata(this.buffer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Cdata.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */