/*     */ package com.sun.xml.txw2;
/*     */ 
/*     */ import com.sun.xml.txw2.annotation.XmlElement;
/*     */ import com.sun.xml.txw2.annotation.XmlNamespace;
/*     */ import com.sun.xml.txw2.output.TXWSerializer;
/*     */ import com.sun.xml.txw2.output.XmlSerializer;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TXW
/*     */ {
/*     */   static QName getTagName(Class<?> c) {
/*  30 */     String localName = "";
/*  31 */     String nsUri = "##default";
/*     */     
/*  33 */     XmlElement xe = c.<XmlElement>getAnnotation(XmlElement.class);
/*  34 */     if (xe != null) {
/*  35 */       localName = xe.value();
/*  36 */       nsUri = xe.ns();
/*     */     } 
/*     */     
/*  39 */     if (localName.length() == 0) {
/*  40 */       localName = c.getName();
/*  41 */       int idx = localName.lastIndexOf('.');
/*  42 */       if (idx >= 0) {
/*  43 */         localName = localName.substring(idx + 1);
/*     */       }
/*  45 */       localName = "" + Character.toLowerCase(localName.charAt(0)) + Character.toLowerCase(localName.charAt(0));
/*     */     } 
/*     */     
/*  48 */     if (nsUri.equals("##default")) {
/*  49 */       Package pkg = c.getPackage();
/*  50 */       if (pkg != null) {
/*  51 */         XmlNamespace xn = pkg.<XmlNamespace>getAnnotation(XmlNamespace.class);
/*  52 */         if (xn != null)
/*  53 */           nsUri = xn.value(); 
/*     */       } 
/*     */     } 
/*  56 */     if (nsUri.equals("##default")) {
/*  57 */       nsUri = "";
/*     */     }
/*  59 */     return new QName(nsUri, localName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends TypedXmlWriter> T create(Class<T> rootElement, XmlSerializer out) {
/*  77 */     if (out instanceof TXWSerializer) {
/*  78 */       TXWSerializer txws = (TXWSerializer)out;
/*  79 */       return txws.txw._element(rootElement);
/*     */     } 
/*     */     
/*  82 */     Document doc = new Document(out);
/*  83 */     QName n = getTagName(rootElement);
/*  84 */     return (new ContainerElement(doc, null, n.getNamespaceURI(), n.getLocalPart()))._cast(rootElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends TypedXmlWriter> T create(QName tagName, Class<T> rootElement, XmlSerializer out) {
/* 110 */     if (out instanceof TXWSerializer) {
/* 111 */       TXWSerializer txws = (TXWSerializer)out;
/* 112 */       return txws.txw._element(tagName, rootElement);
/*     */     } 
/* 114 */     return (new ContainerElement(new Document(out), null, tagName.getNamespaceURI(), tagName.getLocalPart()))._cast(rootElement);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\TXW.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */