/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalSignatureException
/*    */   extends TxwException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalSignatureException(String message) {
/* 20 */     super(message);
/*    */   }
/*    */   
/*    */   public IllegalSignatureException(String message, Throwable cause) {
/* 24 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public IllegalSignatureException(Throwable cause) {
/* 28 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\IllegalSignatureException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */