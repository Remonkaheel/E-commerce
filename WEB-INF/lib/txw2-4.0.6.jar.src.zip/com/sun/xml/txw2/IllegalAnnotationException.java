/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalAnnotationException
/*    */   extends TxwException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalAnnotationException(String message) {
/* 20 */     super(message);
/*    */   }
/*    */   
/*    */   public IllegalAnnotationException(Throwable cause) {
/* 24 */     super(cause);
/*    */   }
/*    */   
/*    */   public IllegalAnnotationException(String message, Throwable cause) {
/* 28 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\IllegalAnnotationException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */