/*     */ package com.sun.xml.txw2;
/*     */ 
/*     */ import com.sun.xml.txw2.annotation.XmlAttribute;
/*     */ import com.sun.xml.txw2.annotation.XmlCDATA;
/*     */ import com.sun.xml.txw2.annotation.XmlElement;
/*     */ import com.sun.xml.txw2.annotation.XmlNamespace;
/*     */ import com.sun.xml.txw2.annotation.XmlValue;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ContainerElement
/*     */   implements InvocationHandler, TypedXmlWriter
/*     */ {
/*     */   final Document document;
/*     */   StartTag startTag;
/*  40 */   final EndTag endTag = new EndTag();
/*     */ 
/*     */ 
/*     */   
/*     */   private final String nsUri;
/*     */ 
/*     */ 
/*     */   
/*     */   private Content tail;
/*     */ 
/*     */ 
/*     */   
/*     */   private ContainerElement prevOpen;
/*     */ 
/*     */ 
/*     */   
/*     */   private ContainerElement nextOpen;
/*     */ 
/*     */   
/*     */   private final ContainerElement parent;
/*     */ 
/*     */   
/*     */   private ContainerElement lastOpenChild;
/*     */ 
/*     */   
/*     */   private boolean blocked;
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerElement(Document document, ContainerElement parent, String nsUri, String localName) {
/*  70 */     this.parent = parent;
/*  71 */     this.document = document;
/*  72 */     this.nsUri = nsUri;
/*  73 */     this.startTag = new StartTag(this, nsUri, localName);
/*  74 */     this.tail = this.startTag;
/*     */     
/*  76 */     if (isRoot())
/*  77 */       document.setFirstContent(this.startTag); 
/*     */   }
/*     */   
/*     */   private boolean isRoot() {
/*  81 */     return (this.parent == null);
/*     */   }
/*     */   
/*     */   private boolean isCommitted() {
/*  85 */     return (this.tail == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Document getDocument() {
/*  90 */     return this.document;
/*     */   }
/*     */   
/*     */   boolean isBlocked() {
/*  94 */     return (this.blocked && !isCommitted());
/*     */   }
/*     */ 
/*     */   
/*     */   public void block() {
/*  99 */     this.blocked = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 104 */     if (method.getDeclaringClass() == TypedXmlWriter.class || method.getDeclaringClass() == Object.class) {
/*     */       
/*     */       try {
/* 107 */         return method.invoke(this, args);
/* 108 */       } catch (InvocationTargetException e) {
/* 109 */         throw e.getTargetException();
/*     */       } 
/*     */     }
/*     */     
/* 113 */     XmlAttribute xa = method.<XmlAttribute>getAnnotation(XmlAttribute.class);
/* 114 */     XmlValue xv = method.<XmlValue>getAnnotation(XmlValue.class);
/* 115 */     XmlElement xe = method.<XmlElement>getAnnotation(XmlElement.class);
/*     */ 
/*     */     
/* 118 */     if (xa != null) {
/* 119 */       if (xv != null || xe != null) {
/* 120 */         throw new IllegalAnnotationException(method.toString());
/*     */       }
/* 122 */       addAttribute(xa, method, args);
/* 123 */       return proxy;
/*     */     } 
/* 125 */     if (xv != null) {
/* 126 */       if (xe != null) {
/* 127 */         throw new IllegalAnnotationException(method.toString());
/*     */       }
/* 129 */       _pcdata(args);
/* 130 */       return proxy;
/*     */     } 
/*     */     
/* 133 */     return addElement(xe, method, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAttribute(XmlAttribute xa, Method method, Object[] args) {
/* 140 */     assert xa != null;
/*     */     
/* 142 */     checkStartTag();
/*     */     
/* 144 */     String localName = xa.value();
/* 145 */     if (xa.value().length() == 0) {
/* 146 */       localName = method.getName();
/*     */     }
/* 148 */     _attribute(xa.ns(), localName, args);
/*     */   }
/*     */   
/*     */   private void checkStartTag() {
/* 152 */     if (this.startTag == null) {
/* 153 */       throw new IllegalStateException("start tag has already been written");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object addElement(XmlElement e, Method method, Object[] args) {
/* 161 */     Class<?> rt = method.getReturnType();
/*     */ 
/*     */     
/* 164 */     String nsUri = "##default";
/* 165 */     String localName = method.getName();
/*     */     
/* 167 */     if (e != null) {
/*     */       
/* 169 */       if (e.value().length() != 0)
/* 170 */         localName = e.value(); 
/* 171 */       nsUri = e.ns();
/*     */     } 
/*     */     
/* 174 */     if (nsUri.equals("##default")) {
/*     */       
/* 176 */       Class<?> c = method.getDeclaringClass();
/* 177 */       XmlElement ce = c.<XmlElement>getAnnotation(XmlElement.class);
/* 178 */       if (ce != null) {
/* 179 */         nsUri = ce.ns();
/*     */       }
/*     */       
/* 182 */       if (nsUri.equals("##default"))
/*     */       {
/* 184 */         nsUri = getNamespace(c.getPackage());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 189 */     if (rt == void.class) {
/*     */ 
/*     */       
/* 192 */       boolean isCDATA = (method.getAnnotation(XmlCDATA.class) != null);
/*     */       
/* 194 */       StartTag st = new StartTag(this.document, nsUri, localName);
/* 195 */       addChild(st);
/* 196 */       for (Object arg : args) {
/*     */         Text text;
/* 198 */         if (isCDATA) { text = new Cdata(this.document, st, arg); }
/* 199 */         else { text = new Pcdata(this.document, st, arg); }
/* 200 */          addChild(text);
/*     */       } 
/* 202 */       addChild(new EndTag());
/* 203 */       return null;
/*     */     } 
/* 205 */     if (TypedXmlWriter.class.isAssignableFrom(rt))
/*     */     {
/* 207 */       return _element(nsUri, localName, rt);
/*     */     }
/*     */     
/* 210 */     throw new IllegalSignatureException("Illegal return type: " + rt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getNamespace(Package pkg) {
/*     */     String nsUri;
/* 217 */     if (pkg == null) return "";
/*     */ 
/*     */     
/* 220 */     XmlNamespace ns = pkg.<XmlNamespace>getAnnotation(XmlNamespace.class);
/* 221 */     if (ns != null) {
/* 222 */       nsUri = ns.value();
/*     */     } else {
/* 224 */       nsUri = "";
/* 225 */     }  return nsUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addChild(Content child) {
/* 232 */     this.tail.setNext(this.document, child);
/* 233 */     this.tail = child;
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit() {
/* 238 */     commit(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit(boolean includingAllPredecessors) {
/* 243 */     _commit(includingAllPredecessors);
/* 244 */     this.document.flush();
/*     */   }
/*     */   
/*     */   private void _commit(boolean includingAllPredecessors) {
/* 248 */     if (isCommitted())
/*     */       return; 
/* 250 */     addChild(this.endTag);
/* 251 */     if (isRoot())
/* 252 */       addChild(new EndDocument()); 
/* 253 */     this.tail = null;
/*     */ 
/*     */     
/* 256 */     if (includingAllPredecessors) {
/* 257 */       for (ContainerElement e = this; e != null; e = e.parent) {
/* 258 */         while (e.prevOpen != null) {
/* 259 */           e.prevOpen._commit(false);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 266 */     while (this.lastOpenChild != null) {
/* 267 */       this.lastOpenChild._commit(false);
/*     */     }
/*     */     
/* 270 */     if (this.parent != null) {
/* 271 */       if (this.parent.lastOpenChild == this) {
/* 272 */         assert this.nextOpen == null : "this must be the last one";
/* 273 */         this.parent.lastOpenChild = this.prevOpen;
/*     */       } else {
/* 275 */         assert this.nextOpen.prevOpen == this;
/* 276 */         this.nextOpen.prevOpen = this.prevOpen;
/*     */       } 
/* 278 */       if (this.prevOpen != null) {
/* 279 */         assert this.prevOpen.nextOpen == this;
/* 280 */         this.prevOpen.nextOpen = this.nextOpen;
/*     */       } 
/*     */     } 
/*     */     
/* 284 */     this.nextOpen = null;
/* 285 */     this.prevOpen = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void _attribute(String localName, Object value) {
/* 290 */     _attribute("", localName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void _attribute(String nsUri, String localName, Object value) {
/* 295 */     checkStartTag();
/* 296 */     this.startTag.addAttribute(nsUri, localName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void _attribute(QName attributeName, Object value) {
/* 301 */     _attribute(attributeName.getNamespaceURI(), attributeName.getLocalPart(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void _namespace(String uri) {
/* 306 */     _namespace(uri, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void _namespace(String uri, String prefix) {
/* 311 */     if (prefix == null)
/* 312 */       throw new IllegalArgumentException(); 
/* 313 */     checkStartTag();
/* 314 */     this.startTag.addNamespaceDecl(uri, prefix, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void _namespace(String uri, boolean requirePrefix) {
/* 319 */     checkStartTag();
/* 320 */     this.startTag.addNamespaceDecl(uri, null, requirePrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void _pcdata(Object value) {
/* 327 */     addChild(new Pcdata(this.document, this.startTag, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void _cdata(Object value) {
/* 332 */     addChild(new Cdata(this.document, this.startTag, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void _comment(Object value) throws UnsupportedOperationException {
/* 337 */     addChild(new Comment(this.document, this.startTag, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends TypedXmlWriter> T _element(String localName, Class<T> contentModel) {
/* 342 */     return _element(this.nsUri, localName, contentModel);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends TypedXmlWriter> T _element(QName tagName, Class<T> contentModel) {
/* 347 */     return _element(tagName.getNamespaceURI(), tagName.getLocalPart(), contentModel);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends TypedXmlWriter> T _element(Class<T> contentModel) {
/* 352 */     return _element(TXW.getTagName(contentModel), contentModel);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends TypedXmlWriter> T _cast(Class<T> facadeType) {
/* 357 */     return facadeType.cast(Proxy.newProxyInstance(facadeType.getClassLoader(), new Class[] { facadeType }, this));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends TypedXmlWriter> T _element(String nsUri, String localName, Class<T> contentModel) {
/* 362 */     ContainerElement child = new ContainerElement(this.document, this, nsUri, localName);
/* 363 */     addChild(child.startTag);
/* 364 */     this.tail = child.endTag;
/*     */ 
/*     */     
/* 367 */     if (this.lastOpenChild != null) {
/* 368 */       assert this.lastOpenChild.parent == this;
/*     */       
/* 370 */       assert child.prevOpen == null;
/* 371 */       assert child.nextOpen == null;
/* 372 */       child.prevOpen = this.lastOpenChild;
/* 373 */       assert this.lastOpenChild.nextOpen == null;
/* 374 */       this.lastOpenChild.nextOpen = child;
/*     */     } 
/*     */     
/* 377 */     this.lastOpenChild = child;
/*     */     
/* 379 */     return child._cast(contentModel);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\ContainerElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */