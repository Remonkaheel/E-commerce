/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Content
/*    */ {
/*    */   private Content next;
/*    */   
/*    */   final Content getNext() {
/* 23 */     return this.next;
/*    */   }
/*    */   
/*    */   final void setNext(Document doc, Content next) {
/* 27 */     assert next != null;
/* 28 */     assert this.next == null : "next of " + this + " is already set to " + this.next;
/* 29 */     this.next = next;
/* 30 */     doc.run();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isReadyToCommit() {
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   abstract boolean concludesPendingStartTag();
/*    */   
/*    */   abstract void accept(ContentVisitor paramContentVisitor);
/*    */   
/*    */   public void written() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Content.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */