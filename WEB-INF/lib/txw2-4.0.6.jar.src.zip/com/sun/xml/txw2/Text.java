/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Text
/*    */   extends Content
/*    */ {
/* 22 */   protected final StringBuilder buffer = new StringBuilder();
/*    */   
/*    */   protected Text(Document document, NamespaceResolver nsResolver, Object obj) {
/* 25 */     document.writeValue(obj, nsResolver, this.buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   boolean concludesPendingStartTag() {
/* 30 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Text.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */