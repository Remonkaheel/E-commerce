/*     */ package com.sun.xml.txw2;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface DatatypeWriter<DT>
/*     */ {
/*  46 */   public static final List<DatatypeWriter<Object>> BUILTIN = Collections.unmodifiableList(new AbstractList<DatatypeWriter<Object>>()
/*     */       {
/*  48 */         private DatatypeWriter<Object>[] BUILTIN_ARRAY = new DatatypeWriter[] { new DatatypeWriter<String>()
/*     */             {
/*     */               
/*     */               public Class<String> getType()
/*     */               {
/*  53 */                 return String.class;
/*     */               }
/*     */ 
/*     */               
/*     */               public void print(String s, NamespaceResolver resolver, StringBuilder buf) {
/*  58 */                 buf.append(s);
/*     */               }
/*     */             }, new DatatypeWriter<Integer>()
/*     */             {
/*     */               public Class<Integer> getType()
/*     */               {
/*  64 */                 return Integer.class;
/*     */               }
/*     */ 
/*     */               
/*     */               public void print(Integer i, NamespaceResolver resolver, StringBuilder buf) {
/*  69 */                 buf.append(i);
/*     */               }
/*     */             }, new DatatypeWriter<Float>()
/*     */             {
/*     */               public Class<Float> getType()
/*     */               {
/*  75 */                 return Float.class;
/*     */               }
/*     */ 
/*     */               
/*     */               public void print(Float f, NamespaceResolver resolver, StringBuilder buf) {
/*  80 */                 buf.append(f);
/*     */               }
/*     */             }, new DatatypeWriter<Double>()
/*     */             {
/*     */               public Class<Double> getType()
/*     */               {
/*  86 */                 return Double.class;
/*     */               }
/*     */ 
/*     */               
/*     */               public void print(Double d, NamespaceResolver resolver, StringBuilder buf) {
/*  91 */                 buf.append(d);
/*     */               }
/*     */             }, new DatatypeWriter<QName>()
/*     */             {
/*     */               public Class<QName> getType()
/*     */               {
/*  97 */                 return QName.class;
/*     */               }
/*     */ 
/*     */               
/*     */               public void print(QName qn, NamespaceResolver resolver, StringBuilder buf) {
/* 102 */                 String p = resolver.getPrefix(qn.getNamespaceURI());
/* 103 */                 if (p.length() != 0)
/* 104 */                   buf.append(p).append(':'); 
/* 105 */                 buf.append(qn.getLocalPart());
/*     */               }
/*     */             } };
/*     */ 
/*     */ 
/*     */         
/*     */         public DatatypeWriter<Object> get(int n) {
/* 112 */           return this.BUILTIN_ARRAY[n];
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 117 */           return this.BUILTIN_ARRAY.length;
/*     */         }
/*     */       });
/*     */   
/*     */   Class<DT> getType();
/*     */   
/*     */   void print(DT paramDT, NamespaceResolver paramNamespaceResolver, StringBuilder paramStringBuilder);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\DatatypeWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */