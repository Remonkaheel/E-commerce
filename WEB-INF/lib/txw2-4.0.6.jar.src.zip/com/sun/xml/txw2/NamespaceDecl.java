/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NamespaceDecl
/*    */ {
/*    */   final String uri;
/*    */   boolean requirePrefix;
/*    */   final String dummyPrefix;
/*    */   final char uniqueId;
/*    */   String prefix;
/*    */   boolean declared;
/*    */   NamespaceDecl next;
/*    */   
/*    */   NamespaceDecl(char uniqueId, String uri, String prefix, boolean requirePrefix) {
/* 47 */     this.dummyPrefix = (new StringBuilder(2)).append(false).append(uniqueId).toString();
/* 48 */     this.uri = uri;
/* 49 */     this.prefix = prefix;
/* 50 */     this.requirePrefix = requirePrefix;
/* 51 */     this.uniqueId = uniqueId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\NamespaceDecl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */