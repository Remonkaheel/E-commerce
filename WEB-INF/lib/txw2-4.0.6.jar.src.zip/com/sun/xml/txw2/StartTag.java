/*     */ package com.sun.xml.txw2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StartTag
/*     */   extends Content
/*     */   implements NamespaceResolver
/*     */ {
/*     */   private String uri;
/*     */   private final String localName;
/*     */   private Attribute firstAtt;
/*     */   private Attribute lastAtt;
/*     */   private ContainerElement owner;
/*     */   private NamespaceDecl firstNs;
/*     */   private NamespaceDecl lastNs;
/*     */   final Document document;
/*     */   
/*     */   public StartTag(ContainerElement owner, String uri, String localName) {
/*  61 */     this(owner.document, uri, localName);
/*  62 */     this.owner = owner;
/*     */   }
/*     */   
/*     */   public StartTag(Document document, String uri, String localName) {
/*  66 */     assert uri != null;
/*  67 */     assert localName != null;
/*     */     
/*  69 */     this.uri = uri;
/*  70 */     this.localName = localName;
/*  71 */     this.document = document;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     addNamespaceDecl(uri, null, false);
/*     */   }
/*     */   
/*     */   public void addAttribute(String nsUri, String localName, Object arg) {
/*  80 */     checkWritable();
/*     */     
/*     */     Attribute a;
/*     */     
/*  84 */     for (a = this.firstAtt; a != null && 
/*  85 */       !a.hasName(nsUri, localName); a = a.next);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (a == null) {
/*  92 */       a = new Attribute(nsUri, localName);
/*  93 */       if (this.lastAtt == null) {
/*  94 */         assert this.firstAtt == null;
/*  95 */         this.firstAtt = this.lastAtt = a;
/*     */       } else {
/*  97 */         assert this.firstAtt != null;
/*  98 */         this.lastAtt.next = a;
/*  99 */         this.lastAtt = a;
/*     */       } 
/* 101 */       if (nsUri.length() > 0) {
/* 102 */         addNamespaceDecl(nsUri, null, true);
/*     */       }
/*     */     } 
/* 105 */     this.document.writeValue(arg, this, a.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceDecl addNamespaceDecl(String uri, String prefix, boolean requirePrefix) {
/* 128 */     checkWritable();
/*     */     
/* 130 */     if (uri == null)
/* 131 */       throw new IllegalArgumentException(); 
/* 132 */     if (uri.length() == 0) {
/* 133 */       if (requirePrefix)
/* 134 */         throw new IllegalArgumentException("The empty namespace cannot have a non-empty prefix"); 
/* 135 */       if (prefix != null && prefix.length() > 0)
/* 136 */         throw new IllegalArgumentException("The empty namespace can be only bound to the empty prefix"); 
/* 137 */       prefix = "";
/*     */     } 
/*     */ 
/*     */     
/* 141 */     for (NamespaceDecl n = this.firstNs; n != null; n = n.next) {
/* 142 */       if (uri.equals(n.uri)) {
/* 143 */         if (prefix == null) {
/*     */           
/* 145 */           n.requirePrefix |= requirePrefix;
/* 146 */           return n;
/*     */         } 
/* 148 */         if (n.prefix == null) {
/*     */           
/* 150 */           n.prefix = prefix;
/* 151 */           n.requirePrefix |= requirePrefix;
/* 152 */           return n;
/*     */         } 
/* 154 */         if (prefix.equals(n.prefix)) {
/*     */           
/* 156 */           n.requirePrefix |= requirePrefix;
/* 157 */           return n;
/*     */         } 
/*     */       } 
/* 160 */       if (prefix != null && n.prefix != null && n.prefix.equals(prefix)) {
/* 161 */         throw new IllegalArgumentException("Prefix '" + prefix + "' is already bound to '" + n.uri + "'");
/*     */       }
/*     */     } 
/*     */     
/* 165 */     NamespaceDecl ns = new NamespaceDecl(this.document.assignNewId(), uri, prefix, requirePrefix);
/* 166 */     if (this.lastNs == null) {
/* 167 */       assert this.firstNs == null;
/* 168 */       this.firstNs = this.lastNs = ns;
/*     */     } else {
/* 170 */       assert this.firstNs != null;
/* 171 */       this.lastNs.next = ns;
/* 172 */       this.lastNs = ns;
/*     */     } 
/* 174 */     return ns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkWritable() {
/* 181 */     if (isWritten()) {
/* 182 */       throw new IllegalStateException("The start tag of " + this.localName + " has already been written. If you need out of order writing, see the TypedXmlWriter.block method");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWritten() {
/* 191 */     return (this.uri == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isReadyToCommit() {
/* 200 */     if (this.owner != null && this.owner.isBlocked()) {
/* 201 */       return false;
/*     */     }
/* 203 */     for (Content c = getNext(); c != null; c = c.getNext()) {
/* 204 */       if (c.concludesPendingStartTag())
/* 205 */         return true; 
/*     */     } 
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void written() {
/* 212 */     this.firstAtt = this.lastAtt = null;
/* 213 */     this.uri = null;
/* 214 */     if (this.owner != null) {
/* 215 */       assert this.owner.startTag == this;
/* 216 */       this.owner.startTag = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean concludesPendingStartTag() {
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept(ContentVisitor visitor) {
/* 227 */     visitor.onStartTag(this.uri, this.localName, this.firstAtt, this.firstNs);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix(String nsUri) {
/* 232 */     NamespaceDecl ns = addNamespaceDecl(nsUri, null, false);
/* 233 */     if (ns.prefix != null)
/*     */     {
/* 235 */       return ns.prefix; } 
/* 236 */     return ns.dummyPrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\StartTag.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */