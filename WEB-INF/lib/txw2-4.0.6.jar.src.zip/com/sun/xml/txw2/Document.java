/*     */ package com.sun.xml.txw2;
/*     */ 
/*     */ import com.sun.xml.txw2.output.XmlSerializer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Document
/*     */ {
/*     */   private final XmlSerializer out;
/*     */   private boolean started = false;
/*  41 */   private Content current = null;
/*     */   
/*  43 */   private final Map<Class<?>, DatatypeWriter<Object>> datatypeWriters = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private int iota = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private final NamespaceSupport inscopeNamespace = new NamespaceSupport();
/*     */ 
/*     */   
/*     */   private NamespaceDecl activeNamespaces;
/*     */ 
/*     */   
/*     */   private final ContentVisitor visitor;
/*     */   
/*     */   private final StringBuilder prefixSeed;
/*     */   
/*     */   private int prefixIota;
/*     */   
/*     */   static final char MAGIC = '\000';
/*     */ 
/*     */   
/*     */   void flush() {
/*  69 */     this.out.flush();
/*     */   }
/*     */   
/*     */   void setFirstContent(Content c) {
/*  73 */     assert this.current == null;
/*  74 */     this.current = new StartDocument();
/*  75 */     this.current.setNext(this, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDatatypeWriter(DatatypeWriter<Object> dw) {
/*  90 */     this.datatypeWriters.put(dw.getType(), dw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void run() {
/*     */     while (true) {
/*  98 */       Content next = this.current.getNext();
/*  99 */       if (next == null || !next.isReadyToCommit())
/*     */         return; 
/* 101 */       next.accept(this.visitor);
/* 102 */       next.written();
/* 103 */       this.current = next;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeValue(Object obj, NamespaceResolver nsResolver, StringBuilder buf) {
/* 114 */     if (obj == null) {
/* 115 */       throw new IllegalArgumentException("argument contains null");
/*     */     }
/* 117 */     if (obj instanceof Object[]) {
/* 118 */       for (Object o : (Object[])obj)
/* 119 */         writeValue(o, nsResolver, buf); 
/*     */       return;
/*     */     } 
/* 122 */     if (obj instanceof Iterable) {
/* 123 */       for (Object o : obj) {
/* 124 */         writeValue(o, nsResolver, buf);
/*     */       }
/*     */       return;
/*     */     } 
/* 128 */     if (buf.length() > 0) {
/* 129 */       buf.append(' ');
/*     */     }
/* 131 */     Class<?> c = obj.getClass();
/* 132 */     while (c != null) {
/* 133 */       DatatypeWriter<Object> dw = this.datatypeWriters.get(c);
/* 134 */       if (dw != null) {
/* 135 */         dw.print(obj, nsResolver, buf);
/*     */         return;
/*     */       } 
/* 138 */       c = c.getSuperclass();
/*     */     } 
/*     */ 
/*     */     
/* 142 */     buf.append(obj);
/*     */   }
/*     */   
/*     */   Document(XmlSerializer out) {
/* 146 */     this.visitor = new ContentVisitor()
/*     */       {
/*     */ 
/*     */         
/*     */         public void onStartDocument()
/*     */         {
/* 152 */           throw new IllegalStateException();
/*     */         }
/*     */ 
/*     */         
/*     */         public void onEndDocument() {
/* 157 */           Document.this.out.endDocument();
/*     */         }
/*     */ 
/*     */         
/*     */         public void onEndTag() {
/* 162 */           Document.this.out.endTag();
/* 163 */           Document.this.inscopeNamespace.popContext();
/* 164 */           Document.this.activeNamespaces = null;
/*     */         }
/*     */ 
/*     */         
/*     */         public void onPcdata(StringBuilder buffer) {
/* 169 */           if (Document.this.activeNamespaces != null)
/* 170 */             buffer = Document.this.fixPrefix(buffer); 
/* 171 */           Document.this.out.text(buffer);
/*     */         }
/*     */ 
/*     */         
/*     */         public void onCdata(StringBuilder buffer) {
/* 176 */           if (Document.this.activeNamespaces != null)
/* 177 */             buffer = Document.this.fixPrefix(buffer); 
/* 178 */           Document.this.out.cdata(buffer);
/*     */         }
/*     */ 
/*     */         
/*     */         public void onComment(StringBuilder buffer) {
/* 183 */           if (Document.this.activeNamespaces != null)
/* 184 */             buffer = Document.this.fixPrefix(buffer); 
/* 185 */           Document.this.out.comment(buffer);
/*     */         }
/*     */ 
/*     */         
/*     */         public void onStartTag(String nsUri, String localName, Attribute attributes, NamespaceDecl namespaces) {
/* 190 */           assert nsUri != null;
/* 191 */           assert localName != null;
/*     */           
/* 193 */           Document.this.activeNamespaces = namespaces;
/*     */           
/* 195 */           if (!Document.this.started) {
/* 196 */             Document.this.started = true;
/* 197 */             Document.this.out.startDocument();
/*     */           } 
/*     */           
/* 200 */           Document.this.inscopeNamespace.pushContext();
/*     */           
/*     */           NamespaceDecl ns;
/* 203 */           for (ns = namespaces; ns != null; ns = ns.next) {
/* 204 */             ns.declared = false;
/*     */             
/* 206 */             if (ns.prefix != null) {
/* 207 */               String uri = Document.this.inscopeNamespace.getURI(ns.prefix);
/* 208 */               if (uri == null || !uri.equals(ns.uri)) {
/*     */ 
/*     */ 
/*     */                 
/* 212 */                 Document.this.inscopeNamespace.declarePrefix(ns.prefix, ns.uri);
/* 213 */                 ns.declared = true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 219 */           for (ns = namespaces; ns != null; ns = ns.next) {
/* 220 */             if (ns.prefix == null) {
/* 221 */               if (Document.this.inscopeNamespace.getURI("").equals(ns.uri)) {
/* 222 */                 ns.prefix = "";
/*     */               } else {
/* 224 */                 String p = Document.this.inscopeNamespace.getPrefix(ns.uri);
/* 225 */                 if (p == null) {
/*     */                   
/* 227 */                   while (Document.this.inscopeNamespace.getURI(p = Document.this.newPrefix()) != null);
/*     */                   
/* 229 */                   ns.declared = true;
/* 230 */                   Document.this.inscopeNamespace.declarePrefix(p, ns.uri);
/*     */                 } 
/* 232 */                 ns.prefix = p;
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 238 */           assert namespaces.uri.equals(nsUri);
/* 239 */           assert namespaces.prefix != null : "a prefix must have been all allocated";
/* 240 */           Document.this.out.beginStartTag(nsUri, localName, namespaces.prefix);
/*     */ 
/*     */           
/* 243 */           for (ns = namespaces; ns != null; ns = ns.next) {
/* 244 */             if (ns.declared) {
/* 245 */               Document.this.out.writeXmlns(ns.prefix, ns.uri);
/*     */             }
/*     */           } 
/*     */           
/* 249 */           for (Attribute a = attributes; a != null; a = a.next) {
/*     */             String prefix;
/* 251 */             if (a.nsUri.length() == 0) { prefix = ""; }
/* 252 */             else { prefix = Document.this.inscopeNamespace.getPrefix(a.nsUri); }
/* 253 */              Document.this.out.writeAttribute(a.nsUri, a.localName, prefix, Document.this.fixPrefix(a.value));
/*     */           } 
/*     */           
/* 256 */           Document.this.out.endStartTag(nsUri, localName, namespaces.prefix);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     this.prefixSeed = new StringBuilder("ns");
/*     */     
/* 265 */     this.prefixIota = 0;
/*     */     this.out = out;
/*     */     for (DatatypeWriter<Object> dw : DatatypeWriter.BUILTIN)
/*     */       this.datatypeWriters.put(dw.getType(), dw); 
/*     */   }
/*     */   private String newPrefix() {
/* 271 */     this.prefixSeed.setLength(2);
/* 272 */     this.prefixSeed.append(++this.prefixIota);
/* 273 */     return this.prefixSeed.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringBuilder fixPrefix(StringBuilder buf) {
/* 284 */     assert this.activeNamespaces != null;
/*     */ 
/*     */     
/* 287 */     int len = buf.length(); int i;
/* 288 */     for (i = 0; i < len && 
/* 289 */       buf.charAt(i) != '\000'; i++);
/*     */ 
/*     */ 
/*     */     
/* 293 */     if (i == len) {
/* 294 */       return buf;
/*     */     }
/* 296 */     while (i < len) {
/* 297 */       char uriIdx = buf.charAt(i + 1);
/* 298 */       NamespaceDecl ns = this.activeNamespaces;
/* 299 */       while (ns != null && ns.uniqueId != uriIdx)
/* 300 */         ns = ns.next; 
/* 301 */       if (ns == null) {
/* 302 */         throw new IllegalStateException("Unexpected use of prefixes " + buf);
/*     */       }
/* 304 */       int length = 2;
/* 305 */       String prefix = ns.prefix;
/* 306 */       if (prefix.length() == 0) {
/* 307 */         if (buf.length() <= i + 2 || buf.charAt(i + 2) != ':')
/* 308 */           throw new IllegalStateException("Unexpected use of prefixes " + buf); 
/* 309 */         length = 3;
/*     */       } 
/*     */       
/* 312 */       buf.replace(i, i + length, prefix);
/* 313 */       len += prefix.length() - length;
/*     */       
/* 315 */       while (i < len && buf.charAt(i) != '\000') {
/* 316 */         i++;
/*     */       }
/*     */     } 
/* 319 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char assignNewId() {
/* 328 */     return (char)this.iota++;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\Document.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */