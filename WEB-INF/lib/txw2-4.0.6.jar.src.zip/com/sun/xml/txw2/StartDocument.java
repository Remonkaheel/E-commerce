/*    */ package com.sun.xml.txw2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StartDocument
/*    */   extends Content
/*    */ {
/*    */   boolean concludesPendingStartTag() {
/* 19 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   void accept(ContentVisitor visitor) {
/* 24 */     visitor.onStartDocument();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\txw2-4.0.6.jar!\com\sun\xml\txw2\StartDocument.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */