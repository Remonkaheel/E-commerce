package org.glassfish.jaxb.core.unmarshaller;

import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

public interface InfosetScanner<XmlNode> {
  void scan(XmlNode paramXmlNode) throws SAXException;
  
  void setContentHandler(ContentHandler paramContentHandler);
  
  ContentHandler getContentHandler();
  
  XmlNode getCurrentElement();
  
  LocatorEx getLocator();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\cor\\unmarshaller\InfosetScanner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */