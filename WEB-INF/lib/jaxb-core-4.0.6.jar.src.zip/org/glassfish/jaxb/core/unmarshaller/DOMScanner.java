/*     */ package org.glassfish.jaxb.core.unmarshaller;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import jakarta.xml.bind.helpers.ValidationEventLocatorImpl;
/*     */ import java.util.Enumeration;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ import org.xml.sax.helpers.NamespaceSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMScanner
/*     */   implements LocatorEx, InfosetScanner<Node>
/*     */ {
/*  49 */   private Node currentNode = null;
/*     */ 
/*     */   
/*  52 */   private final AttributesImpl atts = new AttributesImpl();
/*     */ 
/*     */   
/*  55 */   private ContentHandler receiver = null;
/*     */   
/*  57 */   private Locator locator = (Locator)this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocator(Locator loc) {
/*  67 */     this.locator = loc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void scan(Node node) throws SAXException {
/*  72 */     if (node instanceof Document) {
/*  73 */       scan((Document)node);
/*     */     } else {
/*  75 */       scan((Element)node);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void scan(Document doc) throws SAXException {
/*  80 */     scan(doc.getDocumentElement());
/*     */   }
/*     */   
/*     */   public void scan(Element e) throws SAXException {
/*  84 */     setCurrentLocation(e);
/*     */     
/*  86 */     this.receiver.setDocumentLocator(this.locator);
/*  87 */     this.receiver.startDocument();
/*     */     
/*  89 */     NamespaceSupport nss = new NamespaceSupport();
/*  90 */     buildNamespaceSupport(nss, e.getParentNode());
/*     */     
/*  92 */     for (Enumeration<String> en = nss.getPrefixes(); en.hasMoreElements(); ) {
/*  93 */       String prefix = en.nextElement();
/*  94 */       this.receiver.startPrefixMapping(prefix, nss.getURI(prefix));
/*     */     } 
/*     */     
/*  97 */     String defaultUri = nss.getURI("");
/*  98 */     if (defaultUri != null && !defaultUri.isEmpty()) {
/*  99 */       this.receiver.startPrefixMapping("", defaultUri);
/*     */     }
/*     */     
/* 102 */     visit(e);
/*     */     
/* 104 */     for (Enumeration<String> enumeration1 = nss.getPrefixes(); enumeration1.hasMoreElements(); ) {
/* 105 */       String prefix = enumeration1.nextElement();
/* 106 */       this.receiver.endPrefixMapping(prefix);
/*     */     } 
/* 108 */     if (defaultUri != null && !defaultUri.isEmpty()) {
/* 109 */       this.receiver.endPrefixMapping("");
/*     */     }
/*     */ 
/*     */     
/* 113 */     setCurrentLocation(e);
/* 114 */     this.receiver.endDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "2.0", forRemoval = true)
/*     */   public void parse(Element e, ContentHandler handler) throws SAXException {
/* 127 */     this.receiver = handler;
/*     */     
/* 129 */     setCurrentLocation(e);
/* 130 */     this.receiver.startDocument();
/*     */     
/* 132 */     this.receiver.setDocumentLocator(this.locator);
/* 133 */     visit(e);
/*     */     
/* 135 */     setCurrentLocation(e);
/* 136 */     this.receiver.endDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "2.0", forRemoval = true)
/*     */   public void parseWithContext(Element e, ContentHandler handler) throws SAXException {
/* 148 */     setContentHandler(handler);
/* 149 */     scan(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildNamespaceSupport(NamespaceSupport nss, Node node) {
/* 156 */     if (node == null || node.getNodeType() != 1) {
/*     */       return;
/*     */     }
/* 159 */     buildNamespaceSupport(nss, node.getParentNode());
/*     */     
/* 161 */     nss.pushContext();
/* 162 */     NamedNodeMap atts = node.getAttributes();
/* 163 */     for (int i = 0; i < atts.getLength(); i++) {
/* 164 */       Attr a = (Attr)atts.item(i);
/* 165 */       if ("xmlns".equals(a.getPrefix())) {
/* 166 */         nss.declarePrefix(a.getLocalName(), a.getValue());
/*     */       
/*     */       }
/* 169 */       else if ("xmlns".equals(a.getName())) {
/* 170 */         nss.declarePrefix("", a.getValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Element e) throws SAXException {
/* 180 */     setCurrentLocation(e);
/* 181 */     NamedNodeMap attributes = e.getAttributes();
/*     */     
/* 183 */     this.atts.clear();
/* 184 */     int len = (attributes == null) ? 0 : attributes.getLength();
/*     */     
/* 186 */     for (int i = len - 1; i >= 0; i--) {
/* 187 */       Attr a = (Attr)attributes.item(i);
/* 188 */       String name = a.getName();
/*     */       
/* 190 */       if (name.startsWith("xmlns")) {
/* 191 */         if (name.length() == 5) {
/* 192 */           this.receiver.startPrefixMapping("", a.getValue());
/*     */         } else {
/* 194 */           String localName = a.getLocalName();
/* 195 */           if (localName == null)
/*     */           {
/* 197 */             localName = name.substring(6);
/*     */           }
/* 199 */           this.receiver.startPrefixMapping(localName, a.getValue());
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 204 */         String str1 = a.getNamespaceURI();
/* 205 */         if (str1 == null) str1 = "";
/*     */         
/* 207 */         String str2 = a.getLocalName();
/* 208 */         if (str2 == null) str2 = a.getName();
/*     */ 
/*     */         
/* 211 */         this.atts.addAttribute(str1, str2, a
/*     */ 
/*     */             
/* 214 */             .getName(), "CDATA", a
/*     */             
/* 216 */             .getValue());
/*     */       } 
/*     */     } 
/* 219 */     String uri = e.getNamespaceURI();
/* 220 */     if (uri == null) uri = ""; 
/* 221 */     String local = e.getLocalName();
/* 222 */     String qname = e.getTagName();
/* 223 */     if (local == null) local = qname; 
/* 224 */     this.receiver.startElement(uri, local, qname, this.atts);
/*     */ 
/*     */     
/* 227 */     NodeList children = e.getChildNodes();
/* 228 */     int clen = children.getLength(); int j;
/* 229 */     for (j = 0; j < clen; j++) {
/* 230 */       visit(children.item(j));
/*     */     }
/*     */ 
/*     */     
/* 234 */     setCurrentLocation(e);
/* 235 */     this.receiver.endElement(uri, local, qname);
/*     */ 
/*     */     
/* 238 */     for (j = len - 1; j >= 0; j--) {
/* 239 */       Attr a = (Attr)attributes.item(j);
/* 240 */       String name = a.getName();
/* 241 */       if (name.startsWith("xmlns"))
/* 242 */         if (name.length() == 5) {
/* 243 */           this.receiver.endPrefixMapping("");
/*     */         } else {
/* 245 */           this.receiver.endPrefixMapping(a.getLocalName());
/*     */         }  
/*     */     } 
/*     */   } private void visit(Node n) throws SAXException {
/*     */     String value;
/*     */     ProcessingInstruction pi;
/* 251 */     setCurrentLocation(n);
/*     */ 
/*     */     
/* 254 */     switch (n.getNodeType()) {
/*     */       case 3:
/*     */       case 4:
/* 257 */         value = n.getNodeValue();
/* 258 */         this.receiver.characters(value.toCharArray(), 0, value.length());
/*     */         break;
/*     */       case 1:
/* 261 */         visit((Element)n);
/*     */         break;
/*     */       case 5:
/* 264 */         this.receiver.skippedEntity(n.getNodeName());
/*     */         break;
/*     */       case 7:
/* 267 */         pi = (ProcessingInstruction)n;
/* 268 */         this.receiver.processingInstruction(pi.getTarget(), pi.getData());
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setCurrentLocation(Node currNode) {
/* 274 */     this.currentNode = currNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getCurrentLocation() {
/* 282 */     return this.currentNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getCurrentElement() {
/* 287 */     return this.currentNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocatorEx getLocator() {
/* 292 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContentHandler(ContentHandler handler) {
/* 297 */     this.receiver = handler;
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentHandler getContentHandler() {
/* 302 */     return this.receiver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPublicId() {
/* 308 */     return null;
/*     */   } public String getSystemId() {
/* 310 */     return null;
/*     */   } public int getLineNumber() {
/* 312 */     return -1;
/*     */   } public int getColumnNumber() {
/* 314 */     return -1;
/*     */   }
/*     */   
/*     */   public ValidationEventLocator getLocation() {
/* 318 */     return (ValidationEventLocator)new ValidationEventLocatorImpl(getCurrentLocation());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\cor\\unmarshaller\DOMScanner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */