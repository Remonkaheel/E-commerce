/*     */ package org.glassfish.jaxb.core.v2.model.nav;
/*     */ 
/*     */ import java.lang.reflect.MalformedParameterizedTypeException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParameterizedTypeImpl
/*     */   implements ParameterizedType
/*     */ {
/*     */   private Type[] actualTypeArguments;
/*     */   private Class<?> rawType;
/*     */   private Type ownerType;
/*     */   
/*     */   ParameterizedTypeImpl(Class<?> rawType, Type[] actualTypeArguments, Type ownerType) {
/*  32 */     this.actualTypeArguments = actualTypeArguments;
/*  33 */     this.rawType = rawType;
/*  34 */     if (ownerType != null) {
/*  35 */       this.ownerType = ownerType;
/*     */     } else {
/*  37 */       this.ownerType = rawType.getDeclaringClass();
/*     */     } 
/*  39 */     validateConstructorArguments();
/*     */   }
/*     */   
/*     */   private void validateConstructorArguments() {
/*  43 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])this.rawType.getTypeParameters();
/*     */     
/*  45 */     if (arrayOfTypeVariable.length != this.actualTypeArguments.length) {
/*  46 */       throw new MalformedParameterizedTypeException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type[] getActualTypeArguments() {
/*  57 */     return (Type[])this.actualTypeArguments.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRawType() {
/*  62 */     return this.rawType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getOwnerType() {
/*  67 */     return this.ownerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  79 */     if (o instanceof ParameterizedType) {
/*     */       
/*  81 */       ParameterizedType that = (ParameterizedType)o;
/*     */       
/*  83 */       if (this == that) {
/*  84 */         return true;
/*     */       }
/*  86 */       Type thatOwner = that.getOwnerType();
/*  87 */       Type thatRawType = that.getRawType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       return (
/* 112 */         Objects.equals(this.ownerType, thatOwner) && 
/* 113 */         Objects.equals(this.rawType, thatRawType) && 
/* 114 */         Arrays.equals((Object[])this.actualTypeArguments, (Object[])that
/* 115 */           .getActualTypeArguments()));
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     return Arrays.hashCode((Object[])this.actualTypeArguments) ^ (
/* 123 */       (this.ownerType == null) ? 0 : this.ownerType.hashCode()) ^ (
/* 124 */       (this.rawType == null) ? 0 : this.rawType.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 131 */     if (this.ownerType != null)
/* 132 */     { if (this.ownerType instanceof Class) {
/* 133 */         sb.append(((Class)this.ownerType).getName());
/*     */       } else {
/* 135 */         sb.append(this.ownerType);
/*     */       } 
/* 137 */       sb.append(".");
/*     */       
/* 139 */       if (this.ownerType instanceof ParameterizedTypeImpl) {
/*     */ 
/*     */         
/* 142 */         sb.append(this.rawType.getName().replace(((ParameterizedTypeImpl)this.ownerType).rawType.getName() + "$", ""));
/*     */       } else {
/*     */         
/* 145 */         sb.append(this.rawType.getName());
/*     */       }  }
/* 147 */     else { sb.append(this.rawType.getName()); }
/*     */     
/* 149 */     if (this.actualTypeArguments != null && this.actualTypeArguments.length > 0) {
/*     */       
/* 151 */       sb.append("<");
/* 152 */       boolean first = true;
/* 153 */       for (Type t : this.actualTypeArguments) {
/* 154 */         if (!first)
/* 155 */           sb.append(", "); 
/* 156 */         if (t instanceof Class) {
/* 157 */           sb.append(((Class)t).getName());
/*     */         } else {
/* 159 */           sb.append(t.toString());
/* 160 */         }  first = false;
/*     */       } 
/* 162 */       sb.append(">");
/*     */     } 
/*     */     
/* 165 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\nav\ParameterizedTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */