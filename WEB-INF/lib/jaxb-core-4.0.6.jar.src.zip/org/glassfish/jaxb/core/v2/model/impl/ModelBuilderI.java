package org.glassfish.jaxb.core.v2.model.impl;

import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
import org.glassfish.jaxb.core.v2.model.nav.Navigator;

public interface ModelBuilderI<T, C, F, M> {
  Navigator<T, C, F, M> getNavigator();
  
  AnnotationReader<T, C, F, M> getReader();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\impl\ModelBuilderI.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */