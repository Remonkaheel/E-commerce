/*    */ package org.glassfish.jaxb.core.v2.runtime.unmarshaller;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEventLocator;
/*    */ import java.net.URL;
/*    */ import org.w3c.dom.Node;
/*    */ import org.xml.sax.Locator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface LocatorEx
/*    */   extends Locator
/*    */ {
/*    */   ValidationEventLocator getLocation();
/*    */   
/*    */   public static final class Snapshot
/*    */     implements LocatorEx, ValidationEventLocator
/*    */   {
/*    */     private final int columnNumber;
/*    */     private final int lineNumber;
/*    */     private final int offset;
/*    */     private final String systemId;
/*    */     private final String publicId;
/*    */     private final URL url;
/*    */     private final Object object;
/*    */     private final Node node;
/*    */     
/*    */     public Snapshot(LocatorEx loc) {
/* 43 */       this.columnNumber = loc.getColumnNumber();
/* 44 */       this.lineNumber = loc.getLineNumber();
/* 45 */       this.systemId = loc.getSystemId();
/* 46 */       this.publicId = loc.getPublicId();
/*    */       
/* 48 */       ValidationEventLocator vel = loc.getLocation();
/* 49 */       this.offset = vel.getOffset();
/* 50 */       this.url = vel.getURL();
/* 51 */       this.object = vel.getObject();
/* 52 */       this.node = vel.getNode();
/*    */     }
/*    */ 
/*    */     
/*    */     public Object getObject() {
/* 57 */       return this.object;
/*    */     }
/*    */ 
/*    */     
/*    */     public Node getNode() {
/* 62 */       return this.node;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getOffset() {
/* 67 */       return this.offset;
/*    */     }
/*    */ 
/*    */     
/*    */     public URL getURL() {
/* 72 */       return this.url;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getColumnNumber() {
/* 77 */       return this.columnNumber;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getLineNumber() {
/* 82 */       return this.lineNumber;
/*    */     }
/*    */ 
/*    */     
/*    */     public String getSystemId() {
/* 87 */       return this.systemId;
/*    */     }
/*    */ 
/*    */     
/*    */     public String getPublicId() {
/* 92 */       return this.publicId;
/*    */     }
/*    */ 
/*    */     
/*    */     public ValidationEventLocator getLocation() {
/* 97 */       return this;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\runtim\\unmarshaller\LocatorEx.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */