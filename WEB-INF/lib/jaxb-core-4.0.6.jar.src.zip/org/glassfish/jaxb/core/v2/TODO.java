package org.glassfish.jaxb.core.v2;

public abstract class TODO {
  public static void checkSpec() {}
  
  public static void checkSpec(String comment) {}
  
  public static void prototype() {}
  
  public static void prototype(String comment) {}
  
  public static void schemaGenerator(String comment) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\TODO.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */