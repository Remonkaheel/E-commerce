/*    */ package org.glassfish.jaxb.core.v2.model.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PropertyKind
/*    */ {
/* 26 */   VALUE(true, false, 2147483647),
/* 27 */   ATTRIBUTE(false, false, 2147483647),
/* 28 */   ELEMENT(true, true, 0),
/* 29 */   REFERENCE(false, true, 1),
/* 30 */   MAP(false, true, 2);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean canHaveXmlMimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isOrdered;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int propertyIndex;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   PropertyKind(boolean canHaveExpectedContentType, boolean isOrdered, int propertyIndex) {
/* 51 */     this.canHaveXmlMimeType = canHaveExpectedContentType;
/* 52 */     this.isOrdered = isOrdered;
/* 53 */     this.propertyIndex = propertyIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\PropertyKind.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */