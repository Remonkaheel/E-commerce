package org.glassfish.jaxb.core.v2.model.core;

import org.glassfish.jaxb.core.v2.model.annotation.Locatable;

public interface TypeInfo<T, C> extends Locatable {
  T getType();
  
  boolean canBeReferencedByIDREF();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\TypeInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */