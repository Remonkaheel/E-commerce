package org.glassfish.jaxb.core.v2.model.core;

import java.util.Collection;

public interface ElementInfo<T, C> extends Element<T, C> {
  ElementPropertyInfo<T, C> getProperty();
  
  NonElement<T, C> getContentType();
  
  T getContentInMemoryType();
  
  T getType();
  
  ElementInfo<T, C> getSubstitutionHead();
  
  Collection<? extends ElementInfo<T, C>> getSubstitutionMembers();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\ElementInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */