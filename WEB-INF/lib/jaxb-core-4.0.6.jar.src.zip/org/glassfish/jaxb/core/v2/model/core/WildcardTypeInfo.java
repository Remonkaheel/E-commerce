package org.glassfish.jaxb.core.v2.model.core;

public interface WildcardTypeInfo<T, C> extends TypeInfo<T, C> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\WildcardTypeInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */