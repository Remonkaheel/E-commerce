package org.glassfish.jaxb.core.v2.schemagen.episode;

import com.sun.xml.txw2.annotation.XmlNamespace;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\schemagen\episode\package-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */