/*    */ package org.glassfish.jaxb.core.v2.model.util;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.TODO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayInfoUtil
/*    */ {
/*    */   public static QName calcArrayTypeName(QName n) {
/*    */     String uri;
/* 32 */     if (n.getNamespaceURI().equals("http://www.w3.org/2001/XMLSchema")) {
/* 33 */       TODO.checkSpec("this URI");
/* 34 */       uri = "http://jaxb.dev.java.net/array";
/*    */     } else {
/* 36 */       uri = n.getNamespaceURI();
/* 37 */     }  return new QName(uri, n.getLocalPart() + "Array");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\mode\\util\ArrayInfoUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */