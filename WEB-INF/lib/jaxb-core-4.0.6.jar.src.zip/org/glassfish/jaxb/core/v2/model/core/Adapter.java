/*    */ package org.glassfish.jaxb.core.v2.model.core;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter<TypeT, ClassDeclT>
/*    */ {
/*    */   public final ClassDeclT adapterType;
/*    */   public final TypeT defaultType;
/*    */   public final TypeT customType;
/*    */   
/*    */   public Adapter(XmlJavaTypeAdapter spec, AnnotationReader<TypeT, ClassDeclT, ?, ?> reader, Navigator<TypeT, ClassDeclT, ?, ?> nav) {
/* 53 */     this((ClassDeclT)nav.asDecl(reader.getClassValue((Annotation)spec, "value")), nav);
/*    */   }
/*    */   
/*    */   public Adapter(ClassDeclT adapterType, Navigator<TypeT, ClassDeclT, ?, ?> nav) {
/* 57 */     this.adapterType = adapterType;
/* 58 */     TypeT baseClass = (TypeT)nav.getBaseClass(nav.use(adapterType), nav.asDecl(XmlAdapter.class));
/*    */ 
/*    */     
/* 61 */     assert baseClass != null;
/*    */     
/* 63 */     if (nav.isParameterizedType(baseClass)) {
/* 64 */       this.defaultType = (TypeT)nav.getTypeArgument(baseClass, 0);
/*    */     } else {
/* 66 */       this.defaultType = (TypeT)nav.ref(Object.class);
/*    */     } 
/* 68 */     if (nav.isParameterizedType(baseClass)) {
/* 69 */       this.customType = (TypeT)nav.getTypeArgument(baseClass, 1);
/*    */     } else {
/* 71 */       this.customType = (TypeT)nav.ref(Object.class);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\Adapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */