package org.glassfish.jaxb.core.v2.schemagen.episode;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;

@XmlElement("bindings")
public interface Bindings extends TypedXmlWriter {
  @XmlElement
  Bindings bindings();
  
  @XmlElement("class")
  Klass klass();
  
  Klass typesafeEnumClass();
  
  @XmlElement
  SchemaBindings schemaBindings();
  
  @XmlAttribute
  void scd(String paramString);
  
  @XmlAttribute
  void version(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\schemagen\episode\Bindings.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */