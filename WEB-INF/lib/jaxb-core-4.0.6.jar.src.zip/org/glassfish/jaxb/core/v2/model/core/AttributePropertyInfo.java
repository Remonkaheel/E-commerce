package org.glassfish.jaxb.core.v2.model.core;

import javax.xml.namespace.QName;

public interface AttributePropertyInfo<T, C> extends PropertyInfo<T, C>, NonElementRef<T, C> {
  NonElement<T, C> getTarget();
  
  boolean isRequired();
  
  QName getXmlName();
  
  Adapter<T, C> getAdapter();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\AttributePropertyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */