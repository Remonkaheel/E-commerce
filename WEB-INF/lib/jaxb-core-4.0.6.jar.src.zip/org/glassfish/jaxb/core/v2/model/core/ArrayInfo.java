package org.glassfish.jaxb.core.v2.model.core;

public interface ArrayInfo<T, C> extends NonElement<T, C> {
  NonElement<T, C> getItemType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\ArrayInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */