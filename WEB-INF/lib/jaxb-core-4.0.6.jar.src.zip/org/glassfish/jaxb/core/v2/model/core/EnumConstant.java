package org.glassfish.jaxb.core.v2.model.core;

public interface EnumConstant<T, C> {
  EnumLeafInfo<T, C> getEnclosingClass();
  
  String getLexicalValue();
  
  String getName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\EnumConstant.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */