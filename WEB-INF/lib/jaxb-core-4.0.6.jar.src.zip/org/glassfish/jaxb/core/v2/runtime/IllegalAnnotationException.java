/*     */ package org.glassfish.jaxb.core.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IllegalAnnotationException
/*     */   extends JAXBException
/*     */ {
/*     */   private final transient List<List<Location>> pos;
/*     */   private static final long serialVersionUID = 407680563506515709L;
/*     */   
/*     */   public IllegalAnnotationException(String message, Locatable src) {
/*  39 */     super(message);
/*  40 */     this.pos = build(new Locatable[] { src });
/*     */   }
/*     */   
/*     */   public IllegalAnnotationException(String message, Annotation src) {
/*  44 */     this(message, cast(src));
/*     */   }
/*     */   
/*     */   public IllegalAnnotationException(String message, Locatable src1, Locatable src2) {
/*  48 */     super(message);
/*  49 */     this.pos = build(new Locatable[] { src1, src2 });
/*     */   }
/*     */   
/*     */   public IllegalAnnotationException(String message, Annotation src1, Annotation src2) {
/*  53 */     this(message, cast(src1), cast(src2));
/*     */   }
/*     */   
/*     */   public IllegalAnnotationException(String message, Annotation src1, Locatable src2) {
/*  57 */     this(message, cast(src1), src2);
/*     */   }
/*     */   
/*     */   public IllegalAnnotationException(String message, Throwable cause, Locatable src) {
/*  61 */     super(message, cause);
/*  62 */     this.pos = build(new Locatable[] { src });
/*     */   }
/*     */   
/*     */   private static Locatable cast(Annotation a) {
/*  66 */     if (a instanceof Locatable) {
/*  67 */       return (Locatable)a;
/*     */     }
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   private List<List<Location>> build(Locatable... srcs) {
/*  73 */     List<List<Location>> r = new ArrayList<>();
/*  74 */     for (Locatable l : srcs) {
/*  75 */       if (l != null) {
/*  76 */         List<Location> ll = convert(l);
/*  77 */         if (ll != null && !ll.isEmpty())
/*  78 */           r.add(ll); 
/*     */       } 
/*     */     } 
/*  81 */     return Collections.unmodifiableList(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Location> convert(Locatable src) {
/*  88 */     if (src == null) return null;
/*     */     
/*  90 */     List<Location> r = new ArrayList<>();
/*  91 */     for (; src != null; src = src.getUpstream())
/*  92 */       r.add(src.getLocation()); 
/*  93 */     return Collections.unmodifiableList(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<List<Location>> getSourcePos() {
/* 149 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     StringBuilder sb = new StringBuilder(getMessage());
/*     */     
/* 165 */     for (List<Location> locs : this.pos) {
/* 166 */       sb.append("\n\tthis problem is related to the following location:");
/* 167 */       for (Location loc : locs) {
/* 168 */         sb.append("\n\t\tat ").append(loc.toString());
/*     */       }
/*     */     } 
/* 171 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\runtime\IllegalAnnotationException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */