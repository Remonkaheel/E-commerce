/*     */ package org.glassfish.jaxb.core.v2.util;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditDistance
/*     */ {
/*  34 */   private static final WeakHashMap<AbstractMap.SimpleEntry<String, String>, Integer> CACHE = new WeakHashMap<>();
/*     */   
/*     */   private int[] cost;
/*     */   
/*     */   private int[] back;
/*     */   
/*     */   private final String a;
/*     */   private final String b;
/*     */   
/*     */   public static int editDistance(String a, String b) {
/*  44 */     AbstractMap.SimpleEntry<String, String> entry = new AbstractMap.SimpleEntry<>(a, b);
/*  45 */     Integer result = null;
/*  46 */     if (CACHE.containsKey(entry)) {
/*  47 */       result = CACHE.get(entry);
/*     */     }
/*  49 */     if (result == null) {
/*  50 */       result = Integer.valueOf((new EditDistance(a, b)).calc());
/*  51 */       CACHE.put(entry, result);
/*     */     } 
/*  53 */     return result.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findNearest(String key, String[] group) {
/*  63 */     return findNearest(key, Arrays.asList(group));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findNearest(String key, Collection<String> group) {
/*  73 */     int c = Integer.MAX_VALUE;
/*  74 */     String r = null;
/*     */     
/*  76 */     for (String s : group) {
/*  77 */       int ed = editDistance(key, s);
/*  78 */       if (c > ed) {
/*  79 */         c = ed;
/*  80 */         r = s;
/*     */       } 
/*     */     } 
/*  83 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EditDistance(String a, String b) {
/*  95 */     this.a = a;
/*  96 */     this.b = b;
/*  97 */     this.cost = new int[a.length() + 1];
/*  98 */     this.back = new int[a.length() + 1];
/*     */     
/* 100 */     for (int i = 0; i <= a.length(); i++) {
/* 101 */       this.cost[i] = i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void flip() {
/* 108 */     int[] t = this.cost;
/* 109 */     this.cost = this.back;
/* 110 */     this.back = t;
/*     */   }
/*     */   
/*     */   private int min(int a, int b, int c) {
/* 114 */     return Math.min(a, Math.min(b, c));
/*     */   }
/*     */   
/*     */   private int calc() {
/* 118 */     for (int j = 0; j < this.b.length(); j++) {
/* 119 */       flip();
/* 120 */       this.cost[0] = j + 1;
/* 121 */       for (int i = 0; i < this.a.length(); i++) {
/* 122 */         int match = (this.a.charAt(i) == this.b.charAt(j)) ? 0 : 1;
/* 123 */         this.cost[i + 1] = min(this.back[i] + match, this.cost[i] + 1, this.back[i + 1] + 1);
/*     */       } 
/*     */     } 
/* 126 */     return this.cost[this.a.length()];
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v\\util\EditDistance.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */