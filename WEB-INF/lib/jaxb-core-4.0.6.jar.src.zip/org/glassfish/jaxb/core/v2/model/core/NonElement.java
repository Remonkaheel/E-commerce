/*    */ package org.glassfish.jaxb.core.v2.model.core;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NonElement<T, C>
/*    */   extends TypeInfo<T, C>
/*    */ {
/* 26 */   public static final QName ANYTYPE_NAME = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
/*    */   
/*    */   QName getTypeName();
/*    */   
/*    */   boolean isSimpleType();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\NonElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */