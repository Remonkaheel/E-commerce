/*    */ package org.glassfish.jaxb.core.v2.runtime;
/*    */ 
/*    */ import jakarta.activation.DataHandler;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwaRefAdapterMarker
/*    */   extends XmlAdapter<String, DataHandler>
/*    */ {
/*    */   public DataHandler unmarshal(String v) throws Exception {
/* 31 */     throw new IllegalStateException("Not implemented");
/*    */   }
/*    */ 
/*    */   
/*    */   public String marshal(DataHandler v) throws Exception {
/* 36 */     throw new IllegalStateException("Not implemented");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\runtime\SwaRefAdapterMarker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */