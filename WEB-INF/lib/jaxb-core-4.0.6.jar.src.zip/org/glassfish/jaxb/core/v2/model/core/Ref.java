/*    */ package org.glassfish.jaxb.core.v2.model.core;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlList;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*    */ import org.glassfish.jaxb.core.v2.model.impl.ModelBuilderI;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Ref<T, C>
/*    */ {
/*    */   public final T type;
/*    */   public final Adapter<T, C> adapter;
/*    */   public final boolean valueList;
/*    */   
/*    */   public Ref(T type) {
/* 45 */     this(type, null, false);
/*    */   }
/*    */   public Ref(T type, Adapter<T, C> adapter, boolean valueList) {
/*    */     TypeT typeT;
/* 49 */     this.adapter = adapter;
/* 50 */     if (adapter != null)
/* 51 */       typeT = adapter.defaultType; 
/* 52 */     this.type = (T)typeT;
/* 53 */     this.valueList = valueList;
/*    */   }
/*    */   
/*    */   public Ref(ModelBuilderI<T, C, ?, ?> builder, T type, XmlJavaTypeAdapter xjta, XmlList xl) {
/* 57 */     this(builder.getReader(), builder.getNavigator(), type, xjta, xl);
/*    */   }
/*    */ 
/*    */   
/*    */   public Ref(AnnotationReader<T, C, ?, ?> reader, Navigator<T, C, ?, ?> nav, T type, XmlJavaTypeAdapter xjta, XmlList xl) {
/*    */     TypeT typeT;
/* 63 */     Adapter<T, C> adapter = null;
/* 64 */     if (xjta != null) {
/* 65 */       adapter = new Adapter<>(xjta, reader, nav);
/* 66 */       typeT = adapter.defaultType;
/*    */     } 
/*    */     
/* 69 */     this.type = (T)typeT;
/* 70 */     this.adapter = adapter;
/* 71 */     this.valueList = (xl != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\Ref.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */