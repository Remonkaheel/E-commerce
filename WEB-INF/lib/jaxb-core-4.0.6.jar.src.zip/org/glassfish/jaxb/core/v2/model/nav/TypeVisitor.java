/*    */ package org.glassfish.jaxb.core.v2.model.nav;
/*    */ 
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ import java.lang.reflect.TypeVariable;
/*    */ import java.lang.reflect.WildcardType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class TypeVisitor<T, P>
/*    */ {
/*    */   public final T visit(Type t, P param) {
/* 24 */     assert t != null;
/*    */     
/* 26 */     if (t instanceof Class)
/* 27 */       return onClass((Class)t, param); 
/* 28 */     if (t instanceof ParameterizedType)
/* 29 */       return onParameterizdType((ParameterizedType)t, param); 
/* 30 */     if (t instanceof GenericArrayType)
/* 31 */       return onGenericArray((GenericArrayType)t, param); 
/* 32 */     if (t instanceof WildcardType)
/* 33 */       return onWildcard((WildcardType)t, param); 
/* 34 */     if (t instanceof TypeVariable) {
/* 35 */       return onVariable((TypeVariable)t, param);
/*    */     }
/*    */     
/*    */     assert false;
/* 39 */     throw new IllegalArgumentException();
/*    */   }
/*    */   
/*    */   protected abstract T onClass(Class<?> paramClass, P paramP);
/*    */   
/*    */   protected abstract T onParameterizdType(ParameterizedType paramParameterizedType, P paramP);
/*    */   
/*    */   protected abstract T onGenericArray(GenericArrayType paramGenericArrayType, P paramP);
/*    */   
/*    */   protected abstract T onVariable(TypeVariable paramTypeVariable, P paramP);
/*    */   
/*    */   protected abstract T onWildcard(WildcardType paramWildcardType, P paramP);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\nav\TypeVisitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */