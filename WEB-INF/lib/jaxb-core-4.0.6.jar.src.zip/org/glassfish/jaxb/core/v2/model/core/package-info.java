package org.glassfish.jaxb.core.v2.model.core;

import jakarta.xml.bind.annotation.XmlNsForm;
import jakarta.xml.bind.annotation.XmlSchema;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\package-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */