/*     */ package org.glassfish.jaxb.core.v2;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassFactory
/*     */ {
/*  40 */   private static final Class[] emptyClass = new Class[0];
/*  41 */   private static final Object[] emptyObject = new Object[0];
/*     */   
/*  43 */   private static final Logger logger = Utils.getClassLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static final Map<Class, WeakReference<Constructor>> constructorClassCache = Collections.synchronizedMap(new WeakHashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static void cleanCache() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create0(final Class<T> clazz) throws IllegalAccessException, InvocationTargetException, InstantiationException {
/*  64 */     Constructor<T> cons = null;
/*  65 */     WeakReference<Constructor> consRef = constructorClassCache.get(clazz);
/*  66 */     if (consRef != null)
/*  67 */       cons = consRef.get(); 
/*  68 */     if (cons == null) {
/*  69 */       if (System.getSecurityManager() == null) {
/*  70 */         cons = tryGetDeclaredConstructor(clazz);
/*     */       } else {
/*  72 */         cons = AccessController.<Constructor<T>>doPrivileged((PrivilegedAction)new PrivilegedAction<Constructor<Constructor<T>>>()
/*     */             {
/*     */               public Constructor<T> run() {
/*  75 */                 return ClassFactory.tryGetDeclaredConstructor(clazz);
/*     */               }
/*     */             });
/*     */       } 
/*     */       
/*  80 */       int classMod = clazz.getModifiers();
/*     */       
/*  82 */       if (!Modifier.isPublic(classMod) || !Modifier.isPublic(cons.getModifiers())) {
/*     */         
/*     */         try {
/*  85 */           cons.setAccessible(true);
/*  86 */         } catch (SecurityException e) {
/*     */           
/*  88 */           logger.log(Level.FINE, "Unable to make the constructor of " + clazz + " accessible", e);
/*  89 */           throw e;
/*     */         } 
/*     */       }
/*     */       
/*  93 */       constructorClassCache.put(clazz, new WeakReference<>(cons));
/*     */     } 
/*     */     
/*  96 */     return cons.newInstance(emptyObject);
/*     */   }
/*     */   
/*     */   private static <T> Constructor<T> tryGetDeclaredConstructor(Class<T> clazz) {
/*     */     try {
/* 101 */       return clazz.getDeclaredConstructor(emptyClass);
/* 102 */     } catch (NoSuchMethodException e) {
/* 103 */       NoSuchMethodError exp; logger.log(Level.INFO, "No default constructor found on " + clazz, e);
/*     */       
/* 105 */       if (clazz.getDeclaringClass() != null && !Modifier.isStatic(clazz.getModifiers())) {
/*     */         
/* 107 */         exp = new NoSuchMethodError(Messages.NO_DEFAULT_CONSTRUCTOR_IN_INNER_CLASS.format(new Object[] { clazz.getName() }));
/*     */       } else {
/* 109 */         exp = new NoSuchMethodError(e.getMessage());
/*     */       } 
/* 111 */       exp.initCause(e);
/* 112 */       throw exp;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create(Class<T> clazz) {
/*     */     try {
/* 122 */       return create0(clazz);
/* 123 */     } catch (InstantiationException e) {
/* 124 */       logger.log(Level.INFO, "failed to create a new instance of " + clazz, e);
/* 125 */       throw new InstantiationError(e.toString());
/* 126 */     } catch (IllegalAccessException e) {
/* 127 */       logger.log(Level.INFO, "failed to create a new instance of " + clazz, e);
/* 128 */       throw new IllegalAccessError(e.toString());
/* 129 */     } catch (InvocationTargetException e) {
/* 130 */       Throwable target = e.getTargetException();
/*     */ 
/*     */ 
/*     */       
/* 134 */       if (target instanceof RuntimeException) {
/* 135 */         throw (RuntimeException)target;
/*     */       }
/*     */       
/* 138 */       if (target instanceof Error) {
/* 139 */         throw (Error)target;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 144 */       throw new IllegalStateException(target);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object create(Method method) {
/*     */     try {
/* 154 */       return method.invoke(null, emptyObject);
/* 155 */     } catch (InvocationTargetException ive) {
/* 156 */       Throwable target = ive.getTargetException();
/*     */       
/* 158 */       if (target instanceof RuntimeException) {
/* 159 */         throw (RuntimeException)target;
/*     */       }
/* 161 */       if (target instanceof Error) {
/* 162 */         throw (Error)target;
/*     */       }
/* 164 */       throw new IllegalStateException(target);
/* 165 */     } catch (IllegalAccessException e) {
/* 166 */       logger.log(Level.INFO, "failed to create a new instance of " + method.getReturnType().getName(), e);
/* 167 */       throw new IllegalAccessError(e.toString());
/* 168 */     } catch (IllegalArgumentException|NullPointerException|ExceptionInInitializerError iae) {
/* 169 */       logger.log(Level.INFO, "failed to create a new instance of " + method.getReturnType().getName(), iae);
/* 170 */       Throwable errorMsg = iae;
/*     */ 
/*     */ 
/*     */       
/* 174 */       NoSuchMethodError exp = new NoSuchMethodError(errorMsg.getMessage());
/* 175 */       exp.initCause(errorMsg);
/* 176 */       throw exp;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Class<? extends T> inferImplClass(Class<T> fieldType, Class[] knownImplClasses) {
/* 186 */     if (!fieldType.isInterface()) {
/* 187 */       return fieldType;
/*     */     }
/* 189 */     for (Class<?> impl : knownImplClasses) {
/* 190 */       if (fieldType.isAssignableFrom(impl)) {
/* 191 */         return impl.asSubclass(fieldType);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 197 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\ClassFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */