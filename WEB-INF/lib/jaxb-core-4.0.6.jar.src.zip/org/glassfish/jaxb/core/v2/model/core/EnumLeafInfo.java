package org.glassfish.jaxb.core.v2.model.core;

public interface EnumLeafInfo<T, C> extends LeafInfo<T, C> {
  C getClazz();
  
  NonElement<T, C> getBaseType();
  
  Iterable<? extends EnumConstant<?, ?>> getConstants();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\EnumLeafInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */