/*     */ package org.glassfish.jaxb.core.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeUtil
/*     */ {
/*     */   public static final Map<Class<?>, Class<?>> boxToPrimitive;
/*     */   public static final Map<Class<?>, Class<?>> primitiveToBox;
/*     */   
/*     */   public static final class ToStringAdapter
/*     */     extends XmlAdapter<String, Object>
/*     */   {
/*     */     public Object unmarshal(String s) {
/*  39 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String marshal(Object o) {
/*  44 */       if (o == null) return null; 
/*  45 */       return o.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  63 */     Map<Class<?>, Class<?>> b = new HashMap<>();
/*  64 */     b.put(byte.class, Byte.class);
/*  65 */     b.put(short.class, Short.class);
/*  66 */     b.put(int.class, Integer.class);
/*  67 */     b.put(long.class, Long.class);
/*  68 */     b.put(char.class, Character.class);
/*  69 */     b.put(boolean.class, Boolean.class);
/*  70 */     b.put(float.class, Float.class);
/*  71 */     b.put(double.class, Double.class);
/*  72 */     b.put(void.class, Void.class);
/*     */     
/*  74 */     primitiveToBox = Collections.unmodifiableMap(b);
/*     */     
/*  76 */     Map<Class<?>, Class<?>> p = new HashMap<>();
/*  77 */     for (Map.Entry<Class<?>, Class<?>> e : b.entrySet()) {
/*  78 */       p.put(e.getValue(), e.getKey());
/*     */     }
/*  80 */     boxToPrimitive = Collections.unmodifiableMap(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTypeName(Object o) {
/* 123 */     return o.getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\runtime\RuntimeUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */