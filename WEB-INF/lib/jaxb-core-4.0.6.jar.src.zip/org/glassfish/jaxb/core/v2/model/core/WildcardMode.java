/*    */ package org.glassfish.jaxb.core.v2.model.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum WildcardMode
/*    */ {
/* 19 */   STRICT(false, true), SKIP(true, false), LAX(true, true);
/*    */   
/*    */   public final boolean allowTypedObject;
/*    */   public final boolean allowDom;
/*    */   
/*    */   WildcardMode(boolean allowDom, boolean allowTypedObject) {
/* 25 */     this.allowDom = allowDom;
/* 26 */     this.allowTypedObject = allowTypedObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\WildcardMode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */