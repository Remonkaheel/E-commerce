/*     */ package org.glassfish.jaxb.core.v2.model.nav;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.GenericDeclaration;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReflectionNavigator
/*     */   implements Navigator<Type, Class<?>, Field, Method>
/*     */ {
/*  37 */   private static final ReflectionNavigator INSTANCE = new ReflectionNavigator();
/*     */   
/*     */   static ReflectionNavigator getInstance() {
/*  40 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getSuperClass(Class<?> clazz) {
/*  49 */     if (clazz == Object.class) {
/*  50 */       return null;
/*     */     }
/*  52 */     Class<?> sc = clazz.getSuperclass();
/*  53 */     if (sc == null) {
/*  54 */       sc = Object.class;
/*     */     }
/*  56 */     return sc;
/*     */   }
/*     */   
/*  59 */   private static final TypeVisitor<Type, Class<?>> baseClassFinder = new TypeVisitor<Type, Class<?>>()
/*     */     {
/*     */       
/*     */       public Type onClass(Class<?> c, Class<?> sup)
/*     */       {
/*  64 */         if (sup == c) {
/*  65 */           return sup;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  70 */         Type sc = c.getGenericSuperclass();
/*  71 */         if (sc != null) {
/*  72 */           Type r = visit(sc, sup);
/*  73 */           if (r != null) {
/*  74 */             return r;
/*     */           }
/*     */         } 
/*     */         
/*  78 */         for (Type i : c.getGenericInterfaces()) {
/*  79 */           Type r = visit(i, sup);
/*  80 */           if (r != null) {
/*  81 */             return r;
/*     */           }
/*     */         } 
/*     */         
/*  85 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       public Type onParameterizdType(ParameterizedType p, Class<?> sup) {
/*  90 */         Class<?> raw = (Class)p.getRawType();
/*  91 */         if (raw == sup)
/*     */         {
/*  93 */           return p;
/*     */         }
/*     */         
/*  96 */         Type r = raw.getGenericSuperclass();
/*  97 */         if (r != null) {
/*  98 */           r = visit(bind(r, raw, p), sup);
/*     */         }
/* 100 */         if (r != null) {
/* 101 */           return r;
/*     */         }
/* 103 */         for (Type i : raw.getGenericInterfaces()) {
/* 104 */           r = visit(bind(i, raw, p), sup);
/* 105 */           if (r != null) {
/* 106 */             return r;
/*     */           }
/*     */         } 
/* 109 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Type onGenericArray(GenericArrayType g, Class<?> sup) {
/* 116 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       public Type onVariable(TypeVariable v, Class<?> sup) {
/* 121 */         return visit(v.getBounds()[0], sup);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public Type onWildcard(WildcardType w, Class<?> sup) {
/* 127 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Type bind(Type t, GenericDeclaration decl, ParameterizedType args) {
/* 137 */         return ReflectionNavigator.binder.visit(t, new ReflectionNavigator.BinderArg(decl, args.getActualTypeArguments()));
/*     */       }
/*     */     };
/*     */   
/*     */   private static class BinderArg
/*     */   {
/*     */     final TypeVariable[] params;
/*     */     final Type[] args;
/*     */     
/*     */     BinderArg(TypeVariable[] params, Type[] args) {
/* 147 */       this.params = params;
/* 148 */       this.args = args;
/* 149 */       assert params.length == args.length;
/*     */     }
/*     */     
/*     */     public BinderArg(GenericDeclaration decl, Type[] args) {
/* 153 */       this((TypeVariable[])decl.getTypeParameters(), args);
/*     */     }
/*     */     
/*     */     Type replace(TypeVariable v) {
/* 157 */       for (int i = 0; i < this.params.length; i++) {
/* 158 */         if (this.params[i].equals(v)) {
/* 159 */           return this.args[i];
/*     */         }
/*     */       } 
/* 162 */       return v;
/*     */     } }
/*     */   
/* 165 */   private static final TypeVisitor<Type, BinderArg> binder = new TypeVisitor<Type, BinderArg>()
/*     */     {
/*     */       public Type onClass(Class<?> c, ReflectionNavigator.BinderArg args)
/*     */       {
/* 169 */         return c;
/*     */       }
/*     */       
/*     */       public Type onParameterizdType(ParameterizedType p, ReflectionNavigator.BinderArg args) {
/*     */         int j;
/* 174 */         Type[] params = p.getActualTypeArguments();
/*     */         
/* 176 */         boolean different = false;
/* 177 */         for (int i = 0; i < params.length; i++) {
/* 178 */           Type t = params[i];
/* 179 */           params[i] = visit(t, args);
/* 180 */           j = different | ((t != params[i]) ? 1 : 0);
/*     */         } 
/*     */         
/* 183 */         Type newOwner = p.getOwnerType();
/* 184 */         if (newOwner != null) {
/* 185 */           newOwner = visit(newOwner, args);
/*     */         }
/* 187 */         j |= (p.getOwnerType() != newOwner) ? 1 : 0;
/*     */         
/* 189 */         if (j == 0) {
/* 190 */           return p;
/*     */         }
/*     */         
/* 193 */         return new ParameterizedTypeImpl((Class)p.getRawType(), params, newOwner);
/*     */       }
/*     */ 
/*     */       
/*     */       public Type onGenericArray(GenericArrayType g, ReflectionNavigator.BinderArg types) {
/* 198 */         Type c = visit(g.getGenericComponentType(), types);
/* 199 */         if (c == g.getGenericComponentType()) {
/* 200 */           return g;
/*     */         }
/*     */         
/* 203 */         return new GenericArrayTypeImpl(c);
/*     */       }
/*     */ 
/*     */       
/*     */       public Type onVariable(TypeVariable v, ReflectionNavigator.BinderArg types) {
/* 208 */         return types.replace(v);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Type onWildcard(WildcardType w, ReflectionNavigator.BinderArg types) {
/*     */         int j;
/* 216 */         Type[] lb = w.getLowerBounds();
/* 217 */         Type[] ub = w.getUpperBounds();
/* 218 */         boolean diff = false;
/*     */         int i;
/* 220 */         for (i = 0; i < lb.length; i++) {
/* 221 */           Type t = lb[i];
/* 222 */           lb[i] = visit(t, types);
/* 223 */           j = diff | ((t != lb[i]) ? 1 : 0);
/*     */         } 
/*     */         
/* 226 */         for (i = 0; i < ub.length; i++) {
/* 227 */           Type t = ub[i];
/* 228 */           ub[i] = visit(t, types);
/* 229 */           j |= (t != ub[i]) ? 1 : 0;
/*     */         } 
/*     */         
/* 232 */         if (j == 0) {
/* 233 */           return w;
/*     */         }
/*     */         
/* 236 */         return new WildcardTypeImpl(lb, ub);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public Type getBaseClass(Type t, Class<?> sup) {
/* 242 */     return baseClassFinder.visit(t, sup);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName(Class<?> clazz) {
/* 247 */     return clazz.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTypeName(Type type) {
/* 252 */     if (type instanceof Class) {
/* 253 */       Class<?> c = (Class)type;
/* 254 */       if (c.isArray()) {
/* 255 */         return getTypeName(c.getComponentType()) + "[]";
/*     */       }
/* 257 */       return c.getName();
/*     */     } 
/* 259 */     return type.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassShortName(Class<?> clazz) {
/* 264 */     return clazz.getSimpleName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<? extends Field> getDeclaredFields(final Class<?> clazz) {
/* 269 */     Field[] fields = AccessController.<Field[]>doPrivileged((PrivilegedAction)new PrivilegedAction<Field[]>()
/*     */         {
/*     */           public Field[] run() {
/* 272 */             return clazz.getDeclaredFields();
/*     */           }
/*     */         });
/* 275 */     return Arrays.asList(fields);
/*     */   }
/*     */ 
/*     */   
/*     */   public Field getDeclaredField(final Class<?> clazz, final String fieldName) {
/* 280 */     return AccessController.<Field>doPrivileged(new PrivilegedAction<Field>()
/*     */         {
/*     */           public Field run() {
/*     */             try {
/* 284 */               return clazz.getDeclaredField(fieldName);
/* 285 */             } catch (NoSuchFieldException e) {
/* 286 */               return null;
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<? extends Method> getDeclaredMethods(final Class<?> clazz) {
/* 295 */     Method[] methods = AccessController.<Method[]>doPrivileged((PrivilegedAction)new PrivilegedAction<Method[]>()
/*     */         {
/*     */           public Method[] run() {
/* 298 */             return clazz.getDeclaredMethods();
/*     */           }
/*     */         });
/* 301 */     return Arrays.asList(methods);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringClassForField(Field field) {
/* 306 */     return field.getDeclaringClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringClassForMethod(Method method) {
/* 311 */     return method.getDeclaringClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getFieldType(Field field) {
/* 316 */     if (field.getType().isArray()) {
/* 317 */       Class<?> c = field.getType().getComponentType();
/* 318 */       if (c.isPrimitive()) {
/* 319 */         return Array.newInstance(c, 0).getClass();
/*     */       }
/*     */     } 
/* 322 */     return fix(field.getGenericType());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFieldName(Field field) {
/* 327 */     return field.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethodName(Method method) {
/* 332 */     return method.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getReturnType(Method method) {
/* 337 */     return fix(method.getGenericReturnType());
/*     */   }
/*     */ 
/*     */   
/*     */   public Type[] getMethodParameters(Method method) {
/* 342 */     return method.getGenericParameterTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStaticMethod(Method method) {
/* 347 */     return Modifier.isStatic(method.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinalMethod(Method method) {
/* 352 */     return Modifier.isFinal(method.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubClassOf(Type sub, Type sup) {
/* 357 */     return erasure(sup).isAssignableFrom(erasure(sub));
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> ref(Class<?> c) {
/* 362 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> use(Class<?> c) {
/* 367 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> asDecl(Type t) {
/* 372 */     return erasure(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> asDecl(Class<?> c) {
/* 377 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 382 */   private static final TypeVisitor<Class, Void> eraser = new TypeVisitor<Class, Void>()
/*     */     {
/*     */       public Class<?> onClass(Class<?> c, Void v)
/*     */       {
/* 386 */         return c;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public Class<?> onParameterizdType(ParameterizedType p, Void v) {
/* 392 */         return visit(p.getRawType(), null);
/*     */       }
/*     */ 
/*     */       
/*     */       public Class<?> onGenericArray(GenericArrayType g, Void v) {
/* 397 */         return Array.newInstance(
/* 398 */             visit(g.getGenericComponentType(), null), 0)
/* 399 */           .getClass();
/*     */       }
/*     */ 
/*     */       
/*     */       public Class<?> onVariable(TypeVariable tv, Void v) {
/* 404 */         return visit(tv.getBounds()[0], null);
/*     */       }
/*     */ 
/*     */       
/*     */       public Class<?> onWildcard(WildcardType w, Void v) {
/* 409 */         return visit(w.getUpperBounds()[0], null);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Class<T> erasure(Type t) {
/* 430 */     return eraser.visit(t, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAbstract(Class<?> clazz) {
/* 435 */     return Modifier.isAbstract(clazz.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinal(Class<?> clazz) {
/* 440 */     return Modifier.isFinal(clazz.getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type createParameterizedType(Class<?> rawType, Type... arguments) {
/* 447 */     return new ParameterizedTypeImpl(rawType, arguments, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArray(Type t) {
/* 452 */     if (t instanceof Class) {
/* 453 */       Class<?> c = (Class)t;
/* 454 */       return c.isArray();
/*     */     } 
/* 456 */     if (t instanceof GenericArrayType) {
/* 457 */       return true;
/*     */     }
/* 459 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArrayButNotByteArray(Type t) {
/* 464 */     if (t instanceof Class) {
/* 465 */       Class<?> c = (Class)t;
/* 466 */       return (c.isArray() && c != byte[].class);
/*     */     } 
/* 468 */     if (t instanceof GenericArrayType) {
/* 469 */       t = ((GenericArrayType)t).getGenericComponentType();
/* 470 */       return (t != byte.class);
/*     */     } 
/* 472 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getComponentType(Type t) {
/* 477 */     if (t instanceof Class) {
/* 478 */       Class<?> c = (Class)t;
/* 479 */       return c.getComponentType();
/*     */     } 
/* 481 */     if (t instanceof GenericArrayType) {
/* 482 */       return ((GenericArrayType)t).getGenericComponentType();
/*     */     }
/*     */     
/* 485 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getTypeArgument(Type type, int i) {
/* 490 */     if (type instanceof ParameterizedType) {
/* 491 */       ParameterizedType p = (ParameterizedType)type;
/* 492 */       return fix(p.getActualTypeArguments()[i]);
/*     */     } 
/* 494 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParameterizedType(Type type) {
/* 500 */     return type instanceof ParameterizedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimitive(Type type) {
/* 505 */     if (type instanceof Class) {
/* 506 */       Class<?> c = (Class)type;
/* 507 */       return c.isPrimitive();
/*     */     } 
/* 509 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getPrimitive(Class<?> primitiveType) {
/* 514 */     assert primitiveType.isPrimitive();
/* 515 */     return primitiveType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getClassLocation(final Class<?> clazz) {
/* 520 */     return new Location()
/*     */       {
/*     */         public String toString()
/*     */         {
/* 524 */           return clazz.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getFieldLocation(final Field field) {
/* 531 */     return new Location()
/*     */       {
/*     */         public String toString()
/*     */         {
/* 535 */           return field.toString();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getMethodLocation(final Method method) {
/* 542 */     return new Location()
/*     */       {
/*     */         public String toString()
/*     */         {
/* 546 */           return method.toString();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDefaultConstructor(Class<?> c) {
/*     */     try {
/* 554 */       c.getDeclaredConstructor(new Class[0]);
/* 555 */       return true;
/* 556 */     } catch (NoSuchMethodException e) {
/* 557 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStaticField(Field field) {
/* 563 */     return Modifier.isStatic(field.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPublicMethod(Method method) {
/* 568 */     return Modifier.isPublic(method.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPublicField(Field field) {
/* 573 */     return Modifier.isPublic(field.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnum(Class<?> c) {
/* 578 */     return Enum.class.isAssignableFrom(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public Field[] getEnumConstants(Class<?> clazz) {
/*     */     try {
/* 584 */       Object[] values = clazz.getEnumConstants();
/* 585 */       Field[] fields = new Field[values.length];
/* 586 */       for (int i = 0; i < values.length; i++) {
/* 587 */         fields[i] = clazz.getField(((Enum<Enum>)values[i]).name());
/*     */       }
/* 589 */       return fields;
/* 590 */     } catch (NoSuchFieldException e) {
/*     */       
/* 592 */       throw new NoSuchFieldError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getVoidType() {
/* 598 */     return Void.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPackageName(Class<?> clazz) {
/* 603 */     String name = clazz.getName();
/* 604 */     int idx = name.lastIndexOf('.');
/* 605 */     if (idx < 0) {
/* 606 */       return "";
/*     */     }
/* 608 */     return name.substring(0, idx);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> loadObjectFactory(Class<?> referencePoint, String pkg) {
/* 614 */     ClassLoader cl = SecureLoader.getClassClassLoader(referencePoint);
/* 615 */     if (cl == null) {
/* 616 */       cl = SecureLoader.getSystemClassLoader();
/*     */     }
/*     */     try {
/* 619 */       return cl.loadClass(pkg + ".ObjectFactory");
/* 620 */     } catch (ClassNotFoundException e) {
/* 621 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBridgeMethod(Method method) {
/* 627 */     return method.isBridge();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOverriding(Method method, final Class<?> base) {
/* 642 */     final String name = method.getName();
/* 643 */     final Class[] params = method.getParameterTypes();
/*     */     
/* 645 */     return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */         {
/*     */           
/*     */           public Boolean run()
/*     */           {
/* 650 */             Class<?> clazz = base;
/* 651 */             while (clazz != null) {
/*     */               try {
/* 653 */                 Method m = clazz.getDeclaredMethod(name, params);
/* 654 */                 if (m != null) {
/* 655 */                   return Boolean.TRUE;
/*     */                 }
/* 657 */               } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */               
/* 660 */               clazz = clazz.getSuperclass();
/*     */             } 
/* 662 */             return Boolean.FALSE;
/*     */           }
/*     */         })).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface(Class<?> clazz) {
/* 670 */     return clazz.isInterface();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransient(Field f) {
/* 675 */     return Modifier.isTransient(f.getModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInnerClass(Class<?> clazz) {
/* 680 */     return (clazz.getEnclosingClass() != null && !Modifier.isStatic(clazz.getModifiers()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSameType(Type t1, Type t2) {
/* 685 */     return t1.equals(t2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type fix(Type t) {
/* 695 */     if (!(t instanceof GenericArrayType)) {
/* 696 */       return t;
/*     */     }
/*     */     
/* 699 */     GenericArrayType gat = (GenericArrayType)t;
/* 700 */     if (gat.getGenericComponentType() instanceof Class) {
/* 701 */       Class<?> c = (Class)gat.getGenericComponentType();
/* 702 */       return Array.newInstance(c, 0).getClass();
/*     */     } 
/*     */     
/* 705 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\nav\ReflectionNavigator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */