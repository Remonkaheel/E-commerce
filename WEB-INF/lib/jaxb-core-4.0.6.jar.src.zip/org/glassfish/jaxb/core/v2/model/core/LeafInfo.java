package org.glassfish.jaxb.core.v2.model.core;

public interface LeafInfo<T, C> extends MaybeElement<T, C> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\LeafInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */