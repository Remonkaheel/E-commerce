/*    */ package org.glassfish.jaxb.core.v2.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FlattenIterator<T>
/*    */   implements Iterator<T>
/*    */ {
/*    */   private final Iterator<? extends Map<?, ? extends T>> parent;
/* 26 */   private Iterator<? extends T> child = null;
/*    */   private T next;
/*    */   
/*    */   public FlattenIterator(Iterable<? extends Map<?, ? extends T>> core) {
/* 30 */     this.parent = core.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove() {
/* 36 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 41 */     getNext();
/* 42 */     return (this.next != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public T next() {
/* 47 */     T r = this.next;
/* 48 */     this.next = null;
/* 49 */     if (r == null)
/* 50 */       throw new NoSuchElementException(); 
/* 51 */     return r;
/*    */   }
/*    */   
/*    */   private void getNext() {
/* 55 */     if (this.next != null)
/*    */       return; 
/* 57 */     if (this.child != null && this.child.hasNext()) {
/* 58 */       this.next = this.child.next();
/*    */       
/*    */       return;
/*    */     } 
/* 62 */     if (this.parent.hasNext()) {
/* 63 */       this.child = ((Map)this.parent.next()).values().iterator();
/* 64 */       getNext();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v\\util\FlattenIterator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */