/*    */ package org.glassfish.jaxb.core.v2;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Messages
/*    */ {
/*    */   private static final ResourceBundle rb;
/* 20 */   ILLEGAL_ENTRY,
/* 21 */   ERROR_LOADING_CLASS,
/* 22 */   INVALID_PROPERTY_VALUE,
/* 23 */   UNSUPPORTED_PROPERTY,
/* 24 */   BROKEN_CONTEXTPATH,
/* 25 */   NO_DEFAULT_CONSTRUCTOR_IN_INNER_CLASS,
/* 26 */   INVALID_TYPE_IN_MAP,
/* 27 */   INVALID_JAXP_IMPLEMENTATION,
/* 28 */   JAXP_SUPPORTED_PROPERTY,
/* 29 */   JAXP_UNSUPPORTED_PROPERTY,
/* 30 */   JAXP_XML_SECURITY_DISABLED,
/* 31 */   JAXP_EXTERNAL_ACCESS_CONFIGURED;
/*    */   
/*    */   static {
/* 34 */     rb = ResourceBundle.getBundle(Messages.class.getName());
/*    */   }
/*    */   public String toString() {
/* 37 */     return format(new Object[0]);
/*    */   }
/*    */   
/*    */   public String format(Object... args) {
/* 41 */     return MessageFormat.format(rb.getString(name()), args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */