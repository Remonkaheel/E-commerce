package org.glassfish.jaxb.core.v2.model.core;

import com.sun.istack.Nullable;
import jakarta.activation.MimeType;
import java.util.Collection;
import javax.xml.namespace.QName;
import org.glassfish.jaxb.core.v2.model.annotation.AnnotationSource;

public interface PropertyInfo<T, C> extends AnnotationSource {
  TypeInfo<T, C> parent();
  
  String getName();
  
  String displayName();
  
  boolean isCollection();
  
  Collection<? extends TypeInfo<T, C>> ref();
  
  PropertyKind kind();
  
  Adapter<T, C> getAdapter();
  
  ID id();
  
  MimeType getExpectedMimeType();
  
  boolean inlineBinaryData();
  
  @Nullable
  QName getSchemaType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\core\PropertyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */