/*    */ package org.glassfish.jaxb.core.v2.model.nav;
/*    */ 
/*    */ import java.lang.reflect.GenericArrayType;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GenericArrayTypeImpl
/*    */   implements GenericArrayType
/*    */ {
/*    */   private Type genericComponentType;
/*    */   
/*    */   GenericArrayTypeImpl(Type ct) {
/* 23 */     assert ct != null;
/* 24 */     this.genericComponentType = ct;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Type getGenericComponentType() {
/* 37 */     return this.genericComponentType;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     Type componentType = getGenericComponentType();
/* 43 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 45 */     if (componentType instanceof Class) {
/* 46 */       sb.append(((Class)componentType).getName());
/*    */     } else {
/* 48 */       sb.append(componentType.toString());
/* 49 */     }  sb.append("[]");
/* 50 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 55 */     if (o instanceof GenericArrayType) {
/* 56 */       GenericArrayType that = (GenericArrayType)o;
/*    */       
/* 58 */       Type thatComponentType = that.getGenericComponentType();
/* 59 */       return this.genericComponentType.equals(thatComponentType);
/*    */     } 
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 66 */     return this.genericComponentType.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\nav\GenericArrayTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */