package org.glassfish.jaxb.core.v2.schemagen.episode;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;

public interface Klass extends TypedXmlWriter {
  @XmlAttribute
  void ref(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\schemagen\episode\Klass.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */