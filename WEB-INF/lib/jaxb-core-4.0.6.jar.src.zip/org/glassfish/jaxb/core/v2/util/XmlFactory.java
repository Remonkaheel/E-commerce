/*     */ package org.glassfish.jaxb.core.v2.util;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.validation.SchemaFactory;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import javax.xml.xpath.XPathFactoryConfigurationException;
/*     */ import org.glassfish.jaxb.core.v2.Messages;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlFactory
/*     */ {
/*  41 */   private static final Logger LOGGER = Logger.getLogger(XmlFactory.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DISABLE_XML_SECURITY = "org.glassfish.jaxb.disableXmlSecurity";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static final boolean XML_SECURITY_DISABLED = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */       {
/*     */         public Boolean run()
/*     */         {
/*  56 */           return Boolean.valueOf(Boolean.getBoolean("org.glassfish.jaxb.disableXmlSecurity"));
/*     */         }
/*     */       })).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isXMLSecurityDisabled(boolean runtimeSetting) {
/*  64 */     return (XML_SECURITY_DISABLED || runtimeSetting);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaFactory createSchemaFactory(String language, boolean disableSecureProcessing) throws IllegalStateException {
/*     */     try {
/*  74 */       SchemaFactory factory = SchemaFactory.newInstance(language);
/*  75 */       if (LOGGER.isLoggable(Level.FINE)) {
/*  76 */         LOGGER.log(Level.FINE, "SchemaFactory instance: {0}", factory);
/*     */       }
/*  78 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", !isXMLSecurityDisabled(disableSecureProcessing));
/*  79 */       return factory;
/*  80 */     } catch (SAXNotRecognizedException|org.xml.sax.SAXNotSupportedException ex) {
/*  81 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/*  82 */       throw new IllegalStateException(ex);
/*  83 */     } catch (AbstractMethodError er) {
/*  84 */       LOGGER.log(Level.SEVERE, (String)null, er);
/*  85 */       throw new IllegalStateException(Messages.INVALID_JAXP_IMPLEMENTATION.format(new Object[0]), er);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SAXParserFactory createParserFactory(boolean disableSecureProcessing) throws IllegalStateException {
/*     */     try {
/*  96 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/*  97 */       if (LOGGER.isLoggable(Level.FINE)) {
/*  98 */         LOGGER.log(Level.FINE, "SAXParserFactory instance: {0}", factory);
/*     */       }
/* 100 */       factory.setNamespaceAware(true);
/* 101 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", !isXMLSecurityDisabled(disableSecureProcessing));
/* 102 */       return factory;
/* 103 */     } catch (ParserConfigurationException|SAXNotRecognizedException|org.xml.sax.SAXNotSupportedException ex) {
/* 104 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/* 105 */       throw new IllegalStateException(ex);
/* 106 */     } catch (AbstractMethodError er) {
/* 107 */       LOGGER.log(Level.SEVERE, (String)null, er);
/* 108 */       throw new IllegalStateException(Messages.INVALID_JAXP_IMPLEMENTATION.format(new Object[0]), er);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XPathFactory createXPathFactory(boolean disableSecureProcessing) throws IllegalStateException {
/*     */     try {
/* 118 */       XPathFactory factory = XPathFactory.newInstance();
/* 119 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 120 */         LOGGER.log(Level.FINE, "XPathFactory instance: {0}", factory);
/*     */       }
/* 122 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", !isXMLSecurityDisabled(disableSecureProcessing));
/* 123 */       return factory;
/* 124 */     } catch (XPathFactoryConfigurationException ex) {
/* 125 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/* 126 */       throw new IllegalStateException(ex);
/* 127 */     } catch (AbstractMethodError er) {
/* 128 */       LOGGER.log(Level.SEVERE, (String)null, er);
/* 129 */       throw new IllegalStateException(Messages.INVALID_JAXP_IMPLEMENTATION.format(new Object[0]), er);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransformerFactory createTransformerFactory(boolean disableSecureProcessing) throws IllegalStateException {
/*     */     try {
/* 139 */       TransformerFactory factory = TransformerFactory.newInstance();
/* 140 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 141 */         LOGGER.log(Level.FINE, "TransformerFactory instance: {0}", factory);
/*     */       }
/* 143 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", !isXMLSecurityDisabled(disableSecureProcessing));
/* 144 */       return factory;
/* 145 */     } catch (TransformerConfigurationException ex) {
/* 146 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/* 147 */       throw new IllegalStateException(ex);
/* 148 */     } catch (AbstractMethodError er) {
/* 149 */       LOGGER.log(Level.SEVERE, (String)null, er);
/* 150 */       throw new IllegalStateException(Messages.INVALID_JAXP_IMPLEMENTATION.format(new Object[0]), er);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DocumentBuilderFactory createDocumentBuilderFactory(boolean disableSecureProcessing) throws IllegalStateException {
/*     */     try {
/* 161 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 162 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 163 */         LOGGER.log(Level.FINE, "DocumentBuilderFactory instance: {0}", factory);
/*     */       }
/* 165 */       factory.setNamespaceAware(true);
/* 166 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", !isXMLSecurityDisabled(disableSecureProcessing));
/* 167 */       return factory;
/* 168 */     } catch (ParserConfigurationException ex) {
/* 169 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/* 170 */       throw new IllegalStateException(ex);
/* 171 */     } catch (AbstractMethodError er) {
/* 172 */       LOGGER.log(Level.SEVERE, (String)null, er);
/* 173 */       throw new IllegalStateException(Messages.INVALID_JAXP_IMPLEMENTATION.format(new Object[0]), er);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaFactory allowExternalAccess(SchemaFactory sf, String value, boolean disableSecureProcessing) {
/* 180 */     if (isXMLSecurityDisabled(disableSecureProcessing)) {
/* 181 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 182 */         LOGGER.log(Level.FINE, Messages.JAXP_XML_SECURITY_DISABLED.format(new Object[0]));
/*     */       }
/* 184 */       return sf;
/*     */     } 
/*     */     
/* 187 */     if (System.getProperty("javax.xml.accessExternalSchema") != null) {
/* 188 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 189 */         LOGGER.log(Level.FINE, Messages.JAXP_EXTERNAL_ACCESS_CONFIGURED.format(new Object[0]));
/*     */       }
/* 191 */       return sf;
/*     */     } 
/*     */     
/*     */     try {
/* 195 */       sf.setProperty("http://javax.xml.XMLConstants/property/accessExternalSchema", value);
/* 196 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 197 */         LOGGER.log(Level.FINE, Messages.JAXP_SUPPORTED_PROPERTY.format(new Object[] { "http://javax.xml.XMLConstants/property/accessExternalSchema" }));
/*     */       }
/* 199 */     } catch (SAXException se) {
/*     */       
/* 201 */       if (LOGGER.isLoggable(Level.CONFIG)) {
/* 202 */         LOGGER.log(Level.CONFIG, Messages.JAXP_UNSUPPORTED_PROPERTY.format(new Object[] { "http://javax.xml.XMLConstants/property/accessExternalSchema" }, ), se);
/*     */       }
/*     */     } 
/* 205 */     return sf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaFactory allowExternalDTDAccess(SchemaFactory sf, String value, boolean disableSecureProcessing) {
/* 211 */     if (isXMLSecurityDisabled(disableSecureProcessing)) {
/* 212 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 213 */         LOGGER.log(Level.FINE, Messages.JAXP_XML_SECURITY_DISABLED.format(new Object[0]));
/*     */       }
/* 215 */       return sf;
/*     */     } 
/*     */     
/* 218 */     if (System.getProperty("javax.xml.accessExternalDTD") != null) {
/* 219 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 220 */         LOGGER.log(Level.FINE, Messages.JAXP_EXTERNAL_ACCESS_CONFIGURED.format(new Object[0]));
/*     */       }
/* 222 */       return sf;
/*     */     } 
/*     */     
/*     */     try {
/* 226 */       sf.setProperty("http://javax.xml.XMLConstants/property/accessExternalDTD", value);
/* 227 */       if (LOGGER.isLoggable(Level.FINE)) {
/* 228 */         LOGGER.log(Level.FINE, Messages.JAXP_SUPPORTED_PROPERTY.format(new Object[] { "http://javax.xml.XMLConstants/property/accessExternalDTD" }));
/*     */       }
/* 230 */     } catch (SAXException se) {
/*     */       
/* 232 */       if (LOGGER.isLoggable(Level.CONFIG)) {
/* 233 */         LOGGER.log(Level.CONFIG, Messages.JAXP_UNSUPPORTED_PROPERTY.format(new Object[] { "http://javax.xml.XMLConstants/property/accessExternalDTD" }, ), se);
/*     */       }
/*     */     } 
/* 236 */     return sf;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v\\util\XmlFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */