package org.glassfish.jaxb.core.v2.model.annotation;

import java.lang.annotation.Annotation;

public interface AnnotationSource {
  <A extends Annotation> A readAnnotation(Class<A> paramClass);
  
  boolean hasAnnotation(Class<? extends Annotation> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\annotation\AnnotationSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */