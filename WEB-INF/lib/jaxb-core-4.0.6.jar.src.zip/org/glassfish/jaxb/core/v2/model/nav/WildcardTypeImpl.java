/*    */ package org.glassfish.jaxb.core.v2.model.nav;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import java.lang.reflect.WildcardType;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WildcardTypeImpl
/*    */   implements WildcardType
/*    */ {
/*    */   private final Type[] ub;
/*    */   private final Type[] lb;
/*    */   
/*    */   public WildcardTypeImpl(Type[] ub, Type[] lb) {
/* 26 */     this.ub = ub;
/* 27 */     this.lb = lb;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type[] getUpperBounds() {
/* 32 */     return this.ub;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type[] getLowerBounds() {
/* 37 */     return this.lb;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 42 */     return Arrays.hashCode((Object[])this.lb) ^ Arrays.hashCode((Object[])this.ub);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 47 */     if (obj instanceof WildcardType) {
/* 48 */       WildcardType that = (WildcardType)obj;
/* 49 */       return (Arrays.equals((Object[])that.getLowerBounds(), (Object[])this.lb) && 
/* 50 */         Arrays.equals((Object[])that.getUpperBounds(), (Object[])this.ub));
/*    */     } 
/* 52 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\model\nav\WildcardTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */