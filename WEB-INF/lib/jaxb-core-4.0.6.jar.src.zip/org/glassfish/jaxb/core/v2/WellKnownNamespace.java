package org.glassfish.jaxb.core.v2;

public abstract class WellKnownNamespace {
  public static final String XOP = "http://www.w3.org/2004/08/xop/include";
  
  public static final String SWA_URI = "http://ws-i.org/profiles/basic/1.1/xsd";
  
  public static final String XML_MIME_URI = "http://www.w3.org/2005/05/xmlmime";
  
  public static final String JAXB = "https://jakarta.ee/xml/ns/jaxb";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\v2\WellKnownNamespace.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */