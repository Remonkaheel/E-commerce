package org.glassfish.jaxb.core.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Deprecated
public @interface XmlIsSet {
  String value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\annotation\XmlIsSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */