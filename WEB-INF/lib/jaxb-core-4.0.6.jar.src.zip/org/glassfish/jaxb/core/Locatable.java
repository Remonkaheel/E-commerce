package org.glassfish.jaxb.core;

import org.xml.sax.Locator;

public interface Locatable {
  Locator sourceLocation();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\Locatable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */