/*    */ package org.glassfish.jaxb.core;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Utils
/*    */ {
/*    */   public static Logger getClassLogger() {
/*    */     try {
/* 28 */       return Logger.getLogger(StackHelper.getCallerClassName());
/* 29 */     } catch (SecurityException e) {
/* 30 */       return Logger.getLogger("org.glassfish.jaxb.core");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getSystemProperty(String name) {
/*    */     try {
/* 39 */       return System.getProperty(name);
/* 40 */     } catch (SecurityException e) {
/* 41 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\Utils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */