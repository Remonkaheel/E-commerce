/*    */ package org.glassfish.jaxb.core.marshaller;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */ {
/*    */   public static final String NOT_MARSHALLABLE = "MarshallerImpl.NotMarshallable";
/*    */   public static final String UNSUPPORTED_RESULT = "MarshallerImpl.UnsupportedResult";
/*    */   public static final String UNSUPPORTED_ENCODING = "MarshallerImpl.UnsupportedEncoding";
/*    */   public static final String NULL_WRITER = "MarshallerImpl.NullWriterParam";
/*    */   public static final String ASSERT_FAILED = "SAXMarshaller.AssertFailed";
/*    */   @Deprecated(since = "2.0", forRemoval = true)
/*    */   public static final String ERR_MISSING_OBJECT = "SAXMarshaller.MissingObject";
/*    */   @Deprecated(since = "2.0", forRemoval = true)
/*    */   public static final String ERR_DANGLING_IDREF = "SAXMarshaller.DanglingIDREF";
/*    */   @Deprecated(since = "2.0", forRemoval = true)
/*    */   public static final String ERR_NOT_IDENTIFIABLE = "SAXMarshaller.NotIdentifiable";
/*    */   public static final String DOM_IMPL_DOESNT_SUPPORT_CREATELEMENTNS = "SAX2DOMEx.DomImplDoesntSupportCreateElementNs";
/*    */   
/*    */   public static String format(String property) {
/* 26 */     return format(property, (Object[])null);
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1) {
/* 30 */     return format(property, new Object[] { arg1 });
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1, Object arg2) {
/* 34 */     return format(property, new Object[] { arg1, arg2 });
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1, Object arg2, Object arg3) {
/* 38 */     return format(property, new Object[] { arg1, arg2, arg3 });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String format(String property, Object[] args) {
/* 45 */     String text = ResourceBundle.getBundle(Messages.class.getName()).getString(property);
/* 46 */     return MessageFormat.format(text, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\marshaller\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */