/*     */ package org.glassfish.jaxb.core.marshaller;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import java.util.Stack;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.glassfish.jaxb.core.util.Which;
/*     */ import org.glassfish.jaxb.core.v2.util.XmlFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAX2DOMEx
/*     */   implements ContentHandler
/*     */ {
/*  38 */   private Node node = null;
/*     */   private boolean isConsolidate;
/*  40 */   protected final Stack<Node> nodeStack = new Stack<>();
/*  41 */   private final FinalArrayList<String> unprocessedNamespaces = new FinalArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Document document;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAX2DOMEx(Node node) {
/*  52 */     this(node, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAX2DOMEx(Node node, boolean isConsolidate) {
/*  60 */     this.node = node;
/*  61 */     this.isConsolidate = isConsolidate;
/*  62 */     this.nodeStack.push(this.node);
/*     */     
/*  64 */     if (node instanceof Document) {
/*  65 */       this.document = (Document)node;
/*     */     } else {
/*  67 */       this.document = node.getOwnerDocument();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAX2DOMEx(DocumentBuilderFactory f) throws ParserConfigurationException {
/*  75 */     f.setValidating(false);
/*  76 */     this.document = f.newDocumentBuilder().newDocument();
/*  77 */     this.node = this.document;
/*  78 */     this.nodeStack.push(this.document);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SAX2DOMEx() throws ParserConfigurationException {
/*  87 */     DocumentBuilderFactory factory = XmlFactory.createDocumentBuilderFactory(false);
/*  88 */     factory.setValidating(false);
/*     */     
/*  90 */     this.document = factory.newDocumentBuilder().newDocument();
/*  91 */     this.node = this.document;
/*  92 */     this.nodeStack.push(this.document);
/*     */   }
/*     */   
/*     */   public final Element getCurrentElement() {
/*  96 */     return (Element)this.nodeStack.peek();
/*     */   }
/*     */   
/*     */   public Node getDOM() {
/* 100 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() {}
/*     */ 
/*     */   
/*     */   public void endDocument() {}
/*     */ 
/*     */   
/*     */   protected void namespace(Element element, String prefix, String uri) {
/*     */     String qname;
/* 113 */     if ("".equals(prefix) || prefix == null) {
/* 114 */       qname = "xmlns";
/*     */     } else {
/* 116 */       qname = "xmlns:" + prefix;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     if (element.hasAttributeNS("http://www.w3.org/2000/xmlns/", qname))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       element.removeAttributeNS("http://www.w3.org/2000/xmlns/", qname);
/*     */     }
/*     */ 
/*     */     
/* 134 */     element.setAttributeNS("http://www.w3.org/2000/xmlns/", qname, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(String namespace, String localName, String qName, Attributes attrs) {
/* 139 */     Node parent = this.nodeStack.peek();
/*     */ 
/*     */ 
/*     */     
/* 143 */     Element element = this.document.createElementNS(namespace, qName);
/*     */     
/* 145 */     if (element == null)
/*     */     {
/*     */       
/* 148 */       throw new AssertionError(
/* 149 */           Messages.format("SAX2DOMEx.DomImplDoesntSupportCreateElementNs", this.document
/* 150 */             .getClass().getName(), 
/* 151 */             Which.which(this.document.getClass())));
/*     */     }
/*     */ 
/*     */     
/* 155 */     for (int i = 0; i < this.unprocessedNamespaces.size(); i += 2) {
/* 156 */       String prefix = (String)this.unprocessedNamespaces.get(i);
/* 157 */       String uri = (String)this.unprocessedNamespaces.get(i + 1);
/*     */       
/* 159 */       namespace(element, prefix, uri);
/*     */     } 
/* 161 */     this.unprocessedNamespaces.clear();
/*     */ 
/*     */     
/* 164 */     if (attrs != null) {
/* 165 */       int length = attrs.getLength();
/* 166 */       for (int j = 0; j < length; j++) {
/* 167 */         String namespaceuri = attrs.getURI(j);
/* 168 */         String value = attrs.getValue(j);
/* 169 */         String qname = attrs.getQName(j);
/* 170 */         element.setAttributeNS(namespaceuri, qname, value);
/*     */       } 
/*     */     } 
/*     */     
/* 174 */     parent.appendChild(element);
/*     */     
/* 176 */     this.nodeStack.push(element);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String namespace, String localName, String qName) {
/* 181 */     this.nodeStack.pop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/* 186 */     characters(new String(ch, start, length));
/*     */   }
/*     */   protected Text characters(String s) {
/*     */     Text text;
/* 190 */     Node parent = this.nodeStack.peek();
/* 191 */     Node lastChild = parent.getLastChild();
/*     */     
/* 193 */     if (this.isConsolidate && lastChild != null && lastChild.getNodeType() == 3) {
/* 194 */       text = (Text)lastChild;
/* 195 */       text.appendData(s);
/*     */     } else {
/* 197 */       text = this.document.createTextNode(s);
/* 198 */       parent.appendChild(text);
/*     */     } 
/* 200 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) {}
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/* 209 */     Node parent = this.nodeStack.peek();
/* 210 */     Node n = this.document.createProcessingInstruction(target, data);
/* 211 */     parent.appendChild(n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) {}
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) {
/* 224 */     this.unprocessedNamespaces.add(prefix);
/* 225 */     this.unprocessedNamespaces.add(uri);
/*     */   }
/*     */   
/*     */   public void endPrefixMapping(String prefix) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\marshaller\SAX2DOMEx.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */