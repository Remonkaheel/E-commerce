/*    */ package org.glassfish.jaxb.core.marshaller;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DumbEscapeHandler
/*    */   implements CharacterEscapeHandler
/*    */ {
/* 30 */   public static final CharacterEscapeHandler theInstance = new DumbEscapeHandler();
/*    */ 
/*    */   
/*    */   public void escape(char[] ch, int start, int length, boolean isAttVal, Writer out) throws IOException {
/* 34 */     int limit = start + length;
/* 35 */     for (int i = start; i < limit; i++) {
/* 36 */       switch (ch[i]) {
/*    */         case '&':
/* 38 */           out.write("&amp;");
/*    */           break;
/*    */         case '<':
/* 41 */           out.write("&lt;");
/*    */           break;
/*    */         case '>':
/* 44 */           out.write("&gt;");
/*    */           break;
/*    */         case '"':
/* 47 */           if (isAttVal) {
/* 48 */             out.write("&quot;"); break;
/*    */           } 
/* 50 */           out.write(34);
/*    */           break;
/*    */         
/*    */         default:
/* 54 */           if (ch[i] > '') {
/* 55 */             out.write("&#");
/* 56 */             out.write(Integer.toString(ch[i]));
/* 57 */             out.write(59); break;
/*    */           } 
/* 59 */           out.write(ch[i]);
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\marshaller\DumbEscapeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */