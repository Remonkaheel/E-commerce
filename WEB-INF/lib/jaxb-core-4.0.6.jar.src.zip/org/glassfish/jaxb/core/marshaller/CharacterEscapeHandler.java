package org.glassfish.jaxb.core.marshaller;

import java.io.IOException;
import java.io.Writer;

public interface CharacterEscapeHandler {
  void escape(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\marshaller\CharacterEscapeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */