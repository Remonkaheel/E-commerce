/*    */ package org.glassfish.jaxb.core.marshaller;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinimumEscapeHandler
/*    */   implements CharacterEscapeHandler
/*    */ {
/* 27 */   public static final CharacterEscapeHandler theInstance = new MinimumEscapeHandler();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void escape(char[] ch, int start, int length, boolean isAttVal, Writer out) throws IOException {
/* 34 */     int limit = start + length;
/* 35 */     for (int i = start; i < limit; i++) {
/* 36 */       char c = ch[i];
/* 37 */       if (c == '&' || c == '<' || c == '>' || c == '\r' || (c == '\n' && isAttVal) || (c == '"' && isAttVal)) {
/* 38 */         if (i != start)
/* 39 */           out.write(ch, start, i - start); 
/* 40 */         start = i + 1;
/* 41 */         switch (ch[i]) {
/*    */           case '&':
/* 43 */             out.write("&amp;");
/*    */             break;
/*    */           case '<':
/* 46 */             out.write("&lt;");
/*    */             break;
/*    */           case '>':
/* 49 */             out.write("&gt;");
/*    */             break;
/*    */           case '"':
/* 52 */             out.write("&quot;");
/*    */             break;
/*    */           case '\n':
/*    */           case '\r':
/* 56 */             out.write("&#");
/* 57 */             out.write(Integer.toString(c));
/* 58 */             out.write(59);
/*    */             break;
/*    */           default:
/* 61 */             throw new IllegalArgumentException("Cannot escape: '" + c + "'");
/*    */         } 
/*    */       
/*    */       } 
/*    */     } 
/* 66 */     if (start != limit)
/* 67 */       out.write(ch, start, limit - start); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\marshaller\MinimumEscapeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */