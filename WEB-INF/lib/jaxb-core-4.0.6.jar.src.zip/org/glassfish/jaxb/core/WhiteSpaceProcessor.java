/*     */ package org.glassfish.jaxb.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WhiteSpaceProcessor
/*     */ {
/*     */   public static String replace(String text) {
/*  45 */     return replace(text).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence replace(CharSequence text) {
/*  52 */     int i = text.length() - 1;
/*     */ 
/*     */     
/*  55 */     while (i >= 0 && !isWhiteSpaceExceptSpace(text.charAt(i))) {
/*  56 */       i--;
/*     */     }
/*  58 */     if (i < 0)
/*     */     {
/*  60 */       return text;
/*     */     }
/*     */ 
/*     */     
/*  64 */     StringBuilder buf = new StringBuilder(text);
/*     */     
/*  66 */     buf.setCharAt(i--, ' ');
/*  67 */     for (; i >= 0; i--) {
/*  68 */       if (isWhiteSpaceExceptSpace(buf.charAt(i)))
/*  69 */         buf.setCharAt(i, ' '); 
/*     */     } 
/*  71 */     return new String(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence trim(CharSequence text) {
/*  79 */     int len = text.length();
/*  80 */     int start = 0;
/*     */     
/*  82 */     while (start < len && isWhiteSpace(text.charAt(start))) {
/*  83 */       start++;
/*     */     }
/*  85 */     int end = len - 1;
/*     */     
/*  87 */     while (end > start && isWhiteSpace(text.charAt(end))) {
/*  88 */       end--;
/*     */     }
/*  90 */     if (start == 0 && end == len - 1) {
/*  91 */       return text;
/*     */     }
/*  93 */     return text.subSequence(start, end + 1);
/*     */   }
/*     */   
/*     */   public static String collapse(String text) {
/*  97 */     return collapse(text).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence collapse(CharSequence text) {
/* 106 */     int len = text.length();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     int s = 0;
/* 112 */     while (s < len && 
/* 113 */       !isWhiteSpace(text.charAt(s)))
/*     */     {
/* 115 */       s++;
/*     */     }
/* 117 */     if (s == len)
/*     */     {
/* 119 */       return text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 124 */     StringBuilder result = new StringBuilder(len);
/*     */     
/* 126 */     if (s != 0) {
/* 127 */       for (int j = 0; j < s; j++)
/* 128 */         result.append(text.charAt(j)); 
/* 129 */       result.append(' ');
/*     */     } 
/*     */     
/* 132 */     boolean inStripMode = true;
/* 133 */     for (int i = s + 1; i < len; i++) {
/* 134 */       char ch = text.charAt(i);
/* 135 */       boolean b = isWhiteSpace(ch);
/* 136 */       if (!inStripMode || !b) {
/*     */ 
/*     */         
/* 139 */         inStripMode = b;
/* 140 */         if (inStripMode) {
/* 141 */           result.append(' ');
/*     */         } else {
/* 143 */           result.append(ch);
/*     */         } 
/*     */       } 
/*     */     } 
/* 147 */     len = result.length();
/* 148 */     if (len > 0 && result.charAt(len - 1) == ' ') {
/* 149 */       result.setLength(len - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWhiteSpace(CharSequence s) {
/* 161 */     for (int i = s.length() - 1; i >= 0; i--) {
/* 162 */       if (!isWhiteSpace(s.charAt(i)))
/* 163 */         return false; 
/* 164 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWhiteSpace(char ch) {
/* 171 */     if (ch > ' ') return false;
/*     */ 
/*     */     
/* 174 */     return (ch == '\t' || ch == '\n' || ch == '\r' || ch == ' ');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isWhiteSpaceExceptSpace(char ch) {
/* 184 */     if (ch >= ' ') return false;
/*     */ 
/*     */     
/* 187 */     return (ch == '\t' || ch == '\n' || ch == '\r');
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\WhiteSpaceProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */