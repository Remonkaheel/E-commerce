/*    */ package org.glassfish.jaxb.core;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StackHelper
/*    */ {
/*    */   static String getCallerClassName() {
/* 31 */     return StackWalker.getInstance()
/* 32 */       .<String>walk(frames -> (String)frames.map(StackWalker.StackFrame::getClassName).skip(2L).findFirst().get());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\StackHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */