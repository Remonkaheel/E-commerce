/*    */ package org.glassfish.jaxb.core.util;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SecureLoader
/*    */ {
/*    */   static ClassLoader getContextClassLoader() {
/* 22 */     if (System.getSecurityManager() == null) {
/* 23 */       return Thread.currentThread().getContextClassLoader();
/*    */     }
/* 25 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*    */         {
/*    */           public ClassLoader run()
/*    */           {
/* 29 */             return Thread.currentThread().getContextClassLoader();
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   static ClassLoader getClassClassLoader(final Class<?> c) {
/* 36 */     if (System.getSecurityManager() == null) {
/* 37 */       return c.getClassLoader();
/*    */     }
/* 39 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*    */         {
/*    */           public ClassLoader run()
/*    */           {
/* 43 */             return c.getClassLoader();
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   static ClassLoader getSystemClassLoader() {
/* 50 */     if (System.getSecurityManager() == null) {
/* 51 */       return ClassLoader.getSystemClassLoader();
/*    */     }
/* 53 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*    */         {
/*    */           public ClassLoader run()
/*    */           {
/* 57 */             return ClassLoader.getSystemClassLoader();
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\cor\\util\SecureLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */