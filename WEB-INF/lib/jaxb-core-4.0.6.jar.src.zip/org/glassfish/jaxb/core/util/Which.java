/*    */ package org.glassfish.jaxb.core.util;
/*    */ 
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Which
/*    */ {
/*    */   public static String which(Class<?> clazz) {
/* 26 */     return which(clazz.getName(), SecureLoader.getClassClassLoader(clazz));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String which(String classname, ClassLoader loader) {
/* 38 */     String classnameAsResource = classname.replace('.', '/') + ".class";
/*    */     
/* 40 */     if (loader == null) {
/* 41 */       loader = SecureLoader.getSystemClassLoader();
/*    */     }
/*    */     
/* 44 */     URL it = loader.getResource(classnameAsResource);
/* 45 */     if (it != null) {
/* 46 */       return it.toString();
/*    */     }
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\cor\\util\Which.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */