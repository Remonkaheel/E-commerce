/*     */ package org.glassfish.jaxb.core.api.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameUtil
/*     */ {
/*     */   protected static final int UPPER_LETTER = 0;
/*     */   protected static final int LOWER_LETTER = 1;
/*     */   protected static final int OTHER_LETTER = 2;
/*     */   protected static final int DIGIT = 3;
/*     */   protected static final int OTHER = 4;
/*     */   
/*     */   protected boolean isPunct(char c) {
/*  29 */     return (c == '-' || c == '.' || c == ':' || c == '_' || c == '·' || c == '·' || c == '۝' || c == '۞');
/*     */   }
/*     */   
/*     */   protected static boolean isDigit(char c) {
/*  33 */     return ((c >= '0' && c <= '9') || Character.isDigit(c));
/*     */   }
/*     */   
/*     */   protected static boolean isUpper(char c) {
/*  37 */     return ((c >= 'A' && c <= 'Z') || Character.isUpperCase(c));
/*     */   }
/*     */   
/*     */   protected static boolean isLower(char c) {
/*  41 */     return ((c >= 'a' && c <= 'z') || Character.isLowerCase(c));
/*     */   }
/*     */   
/*     */   protected boolean isLetter(char c) {
/*  45 */     return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || Character.isLetter(c));
/*     */   }
/*     */ 
/*     */   
/*     */   private String toLowerCase(String s) {
/*  50 */     return s.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */   
/*     */   private String toUpperCase(char c) {
/*  55 */     return String.valueOf(c).toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */   
/*     */   private String toUpperCase(String s) {
/*  60 */     return s.toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String capitalize(String s) {
/*  68 */     if (!isLower(s.charAt(0)))
/*  69 */       return s; 
/*  70 */     StringBuilder sb = new StringBuilder(s.length());
/*  71 */     sb.append(toUpperCase(s.charAt(0)));
/*  72 */     sb.append(toLowerCase(s.substring(1)));
/*  73 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private int nextBreak(String s, int start) {
/*  78 */     int n = s.length();
/*     */     
/*  80 */     char c1 = s.charAt(start);
/*  81 */     int t1 = classify(c1);
/*     */     
/*  83 */     for (int i = start + 1; i < n; i++) {
/*     */ 
/*     */       
/*  86 */       int t0 = t1;
/*     */       
/*  88 */       c1 = s.charAt(i);
/*  89 */       t1 = classify(c1);
/*     */       
/*  91 */       switch (actionTable[t0 * 5 + t1]) {
/*     */         case 0:
/*  93 */           if (isPunct(c1)) return i; 
/*     */           break;
/*     */         case 1:
/*  96 */           if (i < n - 1) {
/*  97 */             char c2 = s.charAt(i + 1);
/*  98 */             if (isLower(c2))
/*  99 */               return i; 
/*     */           } 
/*     */           break;
/*     */         case 2:
/* 103 */           return i;
/*     */       } 
/*     */     } 
/* 106 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private static final byte[] actionTable = new byte[25];
/*     */ 
/*     */   
/*     */   private static final byte ACTION_CHECK_PUNCT = 0;
/*     */ 
/*     */   
/*     */   private static final byte ACTION_CHECK_C2 = 1;
/*     */   
/*     */   private static final byte ACTION_BREAK = 2;
/*     */   
/*     */   private static final byte ACTION_NOBREAK = 3;
/*     */ 
/*     */   
/*     */   private static byte decideAction(int t0, int t1) {
/* 135 */     if (t0 == 4 && t1 == 4) return 0; 
/* 136 */     if ((((t0 == 3) ? 1 : 0) ^ ((t1 == 3) ? 1 : 0)) != 0) return 2; 
/* 137 */     if (t0 == 1 && t1 != 1) return 2; 
/* 138 */     if ((((t0 <= 2) ? 1 : 0) ^ ((t1 <= 2) ? 1 : 0)) != 0) return 2; 
/* 139 */     if ((((t0 == 2) ? 1 : 0) ^ ((t1 == 2) ? 1 : 0)) != 0) return 2;
/*     */     
/* 141 */     if (t0 == 0 && t1 == 0) return 1;
/*     */     
/* 143 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 148 */     for (int t0 = 0; t0 < 5; t0++) {
/* 149 */       for (int t1 = 0; t1 < 5; t1++) {
/* 150 */         actionTable[t0 * 5 + t1] = decideAction(t0, t1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int classify(char c0) {
/* 157 */     switch (Character.getType(c0)) { case 1:
/* 158 */         return 0;
/* 159 */       case 2: return 1;
/*     */       case 3: case 4:
/*     */       case 5:
/* 162 */         return 2;
/* 163 */       case 9: return 3; }
/* 164 */      return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> toWordList(String s) {
/* 179 */     ArrayList<String> ss = new ArrayList<>();
/* 180 */     int n = s.length(); int i;
/* 181 */     for (i = 0; i < n; ) {
/*     */ 
/*     */       
/* 184 */       while (i < n && 
/* 185 */         isPunct(s.charAt(i)))
/*     */       {
/* 187 */         i++;
/*     */       }
/* 189 */       if (i >= n) {
/*     */         break;
/*     */       }
/* 192 */       int b = nextBreak(s, i);
/* 193 */       String w = (b == -1) ? s.substring(i) : s.substring(i, b);
/* 194 */       ss.add(escape(capitalize(w)));
/* 195 */       if (b == -1)
/* 196 */         break;  i = b;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     return ss;
/*     */   }
/*     */   
/*     */   protected String toMixedCaseName(List<String> ss, boolean startUpper) {
/* 207 */     StringBuilder sb = new StringBuilder();
/* 208 */     if (!ss.isEmpty()) {
/* 209 */       sb.append(startUpper ? ss.get(0) : toLowerCase(ss.get(0)));
/* 210 */       for (int i = 1; i < ss.size(); i++)
/* 211 */         sb.append(ss.get(i)); 
/*     */     } 
/* 213 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toMixedCaseVariableName(String[] ss, boolean startUpper, boolean cdrUpper) {
/* 219 */     if (cdrUpper)
/* 220 */       for (int i = 1; i < ss.length; i++)
/* 221 */         ss[i] = capitalize(ss[i]);  
/* 222 */     StringBuilder sb = new StringBuilder();
/* 223 */     if (ss.length > 0) {
/* 224 */       sb.append(startUpper ? ss[0] : toLowerCase(ss[0]));
/* 225 */       for (int i = 1; i < ss.length; i++)
/* 226 */         sb.append(ss[i]); 
/*     */     } 
/* 228 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toConstantName(String s) {
/* 240 */     return toConstantName(toWordList(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toConstantName(List<String> ss) {
/* 251 */     StringBuilder sb = new StringBuilder();
/* 252 */     if (!ss.isEmpty()) {
/* 253 */       sb.append(toUpperCase(ss.get(0)));
/* 254 */       for (int i = 1; i < ss.size(); i++) {
/* 255 */         sb.append('_');
/* 256 */         sb.append(toUpperCase(ss.get(i)));
/*     */       } 
/*     */     } 
/* 259 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void escape(StringBuilder sb, String s, int start) {
/* 278 */     int n = s.length();
/* 279 */     for (int i = start; i < n; i++) {
/* 280 */       char c = s.charAt(i);
/* 281 */       if (Character.isJavaIdentifierPart(c)) {
/* 282 */         sb.append(c);
/*     */       } else {
/* 284 */         sb.append('_');
/* 285 */         if (c <= '\017') { sb.append("000"); }
/* 286 */         else if (c <= 'ÿ') { sb.append("00"); }
/* 287 */         else if (c <= '࿿') { sb.append('0'); }
/* 288 */          sb.append(Integer.toString(c, 16));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escape(String s) {
/* 298 */     int n = s.length();
/* 299 */     for (int i = 0; i < n; i++) {
/* 300 */       if (!Character.isJavaIdentifierPart(s.charAt(i))) {
/* 301 */         StringBuilder sb = new StringBuilder(s.substring(0, i));
/* 302 */         escape(sb, s, i);
/* 303 */         return sb.toString();
/*     */       } 
/* 305 */     }  return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\api\impl\NameUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */