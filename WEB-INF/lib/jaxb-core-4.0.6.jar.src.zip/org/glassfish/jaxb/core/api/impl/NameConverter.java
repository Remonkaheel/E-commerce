/*     */ package org.glassfish.jaxb.core.api.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.lang.model.SourceVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface NameConverter
/*     */ {
/*  79 */   public static final NameConverter standard = new Standard();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Standard
/*     */     extends NameUtil
/*     */     implements NameConverter
/*     */   {
/*     */     public String toClassName(String s) {
/*  91 */       return toMixedCaseName(toWordList(s), true);
/*     */     }
/*     */     
/*     */     public String toVariableName(String s) {
/*  95 */       return toMixedCaseName(toWordList(s), false);
/*     */     }
/*     */     
/*     */     public String toInterfaceName(String token) {
/*  99 */       return toClassName(token);
/*     */     }
/*     */     
/*     */     public String toPropertyName(String s) {
/* 103 */       String prop = toClassName(s);
/*     */ 
/*     */       
/* 106 */       if (prop.equals("Class"))
/* 107 */         prop = "Clazz"; 
/* 108 */       return prop;
/*     */     }
/*     */     
/*     */     public String toConstantName(String token) {
/* 112 */       return super.toConstantName(token);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toPackageName(String nsUri) {
/* 125 */       int idx = nsUri.indexOf(':');
/* 126 */       String scheme = "";
/* 127 */       if (idx >= 0) {
/* 128 */         scheme = nsUri.substring(0, idx);
/* 129 */         if (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("urn")) {
/* 130 */           nsUri = nsUri.substring(idx + 1);
/*     */         }
/*     */       } 
/*     */       
/* 134 */       ArrayList<String> tokens = tokenize(nsUri, "/: ");
/* 135 */       if (tokens.size() == 0) {
/* 136 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 140 */       if (tokens.size() > 1) {
/*     */ 
/*     */ 
/*     */         
/* 144 */         String lastToken = tokens.get(tokens.size() - 1);
/* 145 */         idx = lastToken.lastIndexOf('.');
/* 146 */         if (idx > 0) {
/* 147 */           lastToken = lastToken.substring(0, idx);
/* 148 */           tokens.set(tokens.size() - 1, lastToken);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 153 */       String domain = tokens.get(0);
/* 154 */       idx = domain.indexOf(':');
/* 155 */       if (idx >= 0) domain = domain.substring(0, idx); 
/* 156 */       ArrayList<String> r = reverse(tokenize(domain, scheme.equals("urn") ? ".-" : "."));
/* 157 */       if (((String)r.get(r.size() - 1)).equalsIgnoreCase("www"))
/*     */       {
/* 159 */         r.remove(r.size() - 1);
/*     */       }
/*     */ 
/*     */       
/* 163 */       tokens.addAll(1, r);
/* 164 */       tokens.remove(0);
/*     */ 
/*     */       
/* 167 */       for (int i = 0; i < tokens.size(); i++) {
/*     */ 
/*     */         
/* 170 */         String token = tokens.get(i);
/* 171 */         token = removeIllegalIdentifierChars(token);
/*     */ 
/*     */         
/* 174 */         if (SourceVersion.isKeyword(token.toLowerCase())) {
/* 175 */           token = "_" + token;
/*     */         }
/*     */         
/* 178 */         tokens.set(i, token.toLowerCase());
/*     */       } 
/*     */ 
/*     */       
/* 182 */       return combine(tokens, '.');
/*     */     }
/*     */ 
/*     */     
/*     */     private static String removeIllegalIdentifierChars(String token) {
/* 187 */       StringBuilder newToken = new StringBuilder(token.length() + 1);
/* 188 */       for (int i = 0; i < token.length(); i++) {
/* 189 */         char c = token.charAt(i);
/* 190 */         if (i == 0 && !Character.isJavaIdentifierStart(c)) {
/* 191 */           newToken.append('_');
/*     */         }
/* 193 */         if (!Character.isJavaIdentifierPart(c)) {
/* 194 */           newToken.append('_');
/*     */         } else {
/* 196 */           newToken.append(c);
/*     */         } 
/*     */       } 
/* 199 */       return newToken.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     private static ArrayList<String> tokenize(String str, String sep) {
/* 204 */       StringTokenizer tokens = new StringTokenizer(str, sep);
/* 205 */       ArrayList<String> r = new ArrayList<>();
/*     */       
/* 207 */       while (tokens.hasMoreTokens()) {
/* 208 */         r.add(tokens.nextToken());
/*     */       }
/* 210 */       return r;
/*     */     }
/*     */     
/*     */     private static <T> ArrayList<T> reverse(List<T> a) {
/* 214 */       ArrayList<T> r = new ArrayList<>();
/*     */       
/* 216 */       for (int i = a.size() - 1; i >= 0; i--) {
/* 217 */         r.add(a.get(i));
/*     */       }
/* 219 */       return r;
/*     */     }
/*     */     
/*     */     private static String combine(List<String> r, char sep) {
/* 223 */       StringBuilder buf = new StringBuilder(r.get(0));
/*     */       
/* 225 */       for (int i = 1; i < r.size(); i++) {
/* 226 */         buf.append(sep);
/* 227 */         buf.append(r.get(i));
/*     */       } 
/*     */       
/* 230 */       return buf.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public static final NameConverter jaxrpcCompatible = new Standard()
/*     */     {
/*     */       protected boolean isPunct(char c) {
/* 243 */         return (c == '.' || c == '-' || c == ';' || c == '·' || c == '·' || c == '۝' || c == '۞');
/*     */       }
/*     */ 
/*     */       
/*     */       protected boolean isLetter(char c) {
/* 248 */         return (super.isLetter(c) || c == '_');
/*     */       }
/*     */ 
/*     */       
/*     */       protected int classify(char c0) {
/* 253 */         if (c0 == '_') return 2; 
/* 254 */         return super.classify(c0);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public static final NameConverter smart = new Standard()
/*     */     {
/*     */       public String toConstantName(String token) {
/* 264 */         String name = super.toConstantName(token);
/* 265 */         if (!SourceVersion.isKeyword(name)) {
/* 266 */           return name;
/*     */         }
/* 268 */         return "_" + name;
/*     */       }
/*     */     };
/*     */   
/*     */   String toClassName(String paramString);
/*     */   
/*     */   String toInterfaceName(String paramString);
/*     */   
/*     */   String toPropertyName(String paramString);
/*     */   
/*     */   String toConstantName(String paramString);
/*     */   
/*     */   String toVariableName(String paramString);
/*     */   
/*     */   String toPackageName(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-core-4.0.6.jar!\org\glassfish\jaxb\core\api\impl\NameConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */