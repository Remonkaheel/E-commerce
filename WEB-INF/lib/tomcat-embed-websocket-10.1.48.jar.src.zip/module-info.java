open module org.apache.tomcat.embed.websocket {
  requires transitive java.base;
  requires java.naming;
  requires transitive org.apache.tomcat.embed.core;
  
  exports jakarta.websocket;
  exports jakarta.websocket.server;
  exports org.apache.tomcat.websocket;
  exports org.apache.tomcat.websocket.server;
  
  uses jakarta.websocket.ContainerProvider;
  uses jakarta.websocket.server.ServerEndpointConfig$Configurator;
  
  provides jakarta.websocket.ContainerProvider with org.apache.tomcat.websocket.WsContainerProvider;
  provides jakarta.websocket.server.ServerEndpointConfig$Configurator with org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */