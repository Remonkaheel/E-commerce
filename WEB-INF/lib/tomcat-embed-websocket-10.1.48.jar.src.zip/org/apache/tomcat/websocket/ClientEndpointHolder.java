package org.apache.tomcat.websocket;

import jakarta.websocket.DeploymentException;
import jakarta.websocket.Endpoint;
import org.apache.tomcat.InstanceManager;

public interface ClientEndpointHolder {
  String getClassName();
  
  Endpoint getInstance(InstanceManager paramInstanceManager) throws DeploymentException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\ClientEndpointHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */