/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.ClientEndpointConfig;
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import jakarta.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.pojo.PojoEndpointClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 31 */   private static final StringManager sm = StringManager.getManager(PojoHolder.class);
/*    */   
/*    */   private final Object pojo;
/*    */   
/*    */   private final ClientEndpointConfig clientEndpointConfig;
/*    */   
/*    */   public PojoHolder(Object pojo, ClientEndpointConfig clientEndpointConfig) {
/* 38 */     this.pojo = pojo;
/* 39 */     this.clientEndpointConfig = clientEndpointConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 45 */     return this.pojo.getClass().getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException {
/* 51 */     if (instanceManager != null) {
/*    */       try {
/* 53 */         instanceManager.newInstance(this.pojo);
/* 54 */       } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 55 */         throw new DeploymentException(sm.getString("clientEndpointHolder.instanceRegistrationFailed"), e);
/*    */       } 
/*    */     }
/* 58 */     return (Endpoint)new PojoEndpointClient(this.pojo, this.clientEndpointConfig.getDecoders(), instanceManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\PojoHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */