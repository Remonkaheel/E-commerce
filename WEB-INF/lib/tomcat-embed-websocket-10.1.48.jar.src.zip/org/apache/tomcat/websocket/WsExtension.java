/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.Extension;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsExtension
/*    */   implements Extension
/*    */ {
/*    */   private final String name;
/* 27 */   private final List<Extension.Parameter> parameters = new ArrayList<>();
/*    */   
/*    */   WsExtension(String name) {
/* 30 */     this.name = name;
/*    */   }
/*    */   
/*    */   void addParameter(Extension.Parameter parameter) {
/* 34 */     this.parameters.add(parameter);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 39 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Extension.Parameter> getParameters() {
/* 44 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsExtension.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */