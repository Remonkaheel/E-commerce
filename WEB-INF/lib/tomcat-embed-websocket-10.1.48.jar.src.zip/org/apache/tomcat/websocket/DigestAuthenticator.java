/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthenticator
/*     */   extends Authenticator
/*     */ {
/*  34 */   private static final StringManager sm = StringManager.getManager(DigestAuthenticator.class);
/*     */   
/*     */   public static final String schemeName = "digest";
/*  37 */   private static final Object cnonceGeneratorLock = new Object();
/*     */   private static volatile SecureRandom cnonceGenerator;
/*  39 */   private int nonceCount = 0;
/*     */ 
/*     */   
/*     */   private long cNonce;
/*     */ 
/*     */   
/*     */   public String getAuthorization(String requestUri, String authenticateHeader, String userName, String userPassword, String userRealm) throws AuthenticationException {
/*  46 */     validateUsername(userName);
/*  47 */     validatePassword(userPassword);
/*     */     
/*  49 */     Map<String, String> parameterMap = parseAuthenticateHeader(authenticateHeader);
/*  50 */     String realm = parameterMap.get("realm");
/*     */     
/*  52 */     validateRealm(userRealm, realm);
/*     */     
/*  54 */     String nonce = parameterMap.get("nonce");
/*  55 */     String messageQop = parameterMap.get("qop");
/*  56 */     String algorithm = (parameterMap.get("algorithm") == null) ? "MD5" : parameterMap.get("algorithm");
/*  57 */     String opaque = parameterMap.get("opaque");
/*     */     
/*  59 */     StringBuilder challenge = new StringBuilder();
/*     */     
/*  61 */     if (!messageQop.isEmpty()) {
/*  62 */       if (cnonceGenerator == null) {
/*  63 */         synchronized (cnonceGeneratorLock) {
/*  64 */           if (cnonceGenerator == null) {
/*  65 */             cnonceGenerator = new SecureRandom();
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/*  70 */       this.cNonce = cnonceGenerator.nextLong();
/*  71 */       this.nonceCount++;
/*     */     } 
/*     */     
/*  74 */     challenge.append("Digest ");
/*  75 */     challenge.append("username =\"").append(userName).append("\",");
/*  76 */     challenge.append("realm=\"").append(realm).append("\",");
/*  77 */     challenge.append("nonce=\"").append(nonce).append("\",");
/*  78 */     challenge.append("uri=\"").append(requestUri).append("\",");
/*     */     
/*     */     try {
/*  81 */       challenge.append("response=\"");
/*  82 */       challenge.append(
/*  83 */           calculateRequestDigest(requestUri, userName, userPassword, realm, nonce, messageQop, algorithm));
/*  84 */       challenge.append("\",");
/*     */     
/*     */     }
/*  87 */     catch (NoSuchAlgorithmException e) {
/*  88 */       throw new AuthenticationException(sm.getString("digestAuthenticator.algorithm", new Object[] { e.getMessage() }));
/*     */     } 
/*     */     
/*  91 */     challenge.append("algorithm=").append(algorithm).append(",");
/*  92 */     challenge.append("opaque=\"").append(opaque).append("\",");
/*     */     
/*  94 */     if (!messageQop.isEmpty()) {
/*  95 */       challenge.append("qop=\"").append(messageQop).append("\"");
/*  96 */       challenge.append(",cnonce=\"").append(this.cNonce).append("\",");
/*  97 */       challenge.append("nc=").append(String.format("%08X", new Object[] { Integer.valueOf(this.nonceCount) }));
/*     */     } 
/*     */     
/* 100 */     return challenge.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String calculateRequestDigest(String requestUri, String userName, String password, String realm, String nonce, String qop, String algorithm) throws NoSuchAlgorithmException {
/*     */     String A1;
/* 107 */     boolean session = false;
/* 108 */     if (algorithm.endsWith("-sess")) {
/* 109 */       algorithm = algorithm.substring(0, algorithm.length() - 5);
/* 110 */       session = true;
/*     */     } 
/*     */     
/* 113 */     StringBuilder preDigest = new StringBuilder();
/*     */ 
/*     */     
/* 116 */     if (session) {
/* 117 */       A1 = encode(algorithm, userName + ":" + userName + ":" + realm) + ":" + encode(algorithm, userName + ":" + userName + ":" + realm) + ":" + nonce;
/*     */     } else {
/* 119 */       A1 = userName + ":" + userName + ":" + realm;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     String A2 = "GET:" + requestUri;
/*     */     
/* 128 */     preDigest.append(encode(algorithm, A1));
/* 129 */     preDigest.append(':');
/* 130 */     preDigest.append(nonce);
/*     */     
/* 132 */     if (qop.toLowerCase(Locale.ENGLISH).contains("auth")) {
/* 133 */       preDigest.append(':');
/* 134 */       preDigest.append(String.format("%08X", new Object[] { Integer.valueOf(this.nonceCount) }));
/* 135 */       preDigest.append(':');
/* 136 */       preDigest.append(String.valueOf(this.cNonce));
/* 137 */       preDigest.append(':');
/* 138 */       preDigest.append(qop);
/*     */     } 
/*     */     
/* 141 */     preDigest.append(':');
/* 142 */     preDigest.append(encode(algorithm, A2));
/*     */     
/* 144 */     return encode(algorithm, preDigest.toString());
/*     */   }
/*     */   
/*     */   private String encode(String algorithm, String value) throws NoSuchAlgorithmException {
/* 148 */     byte[] bytesOfMessage = value.getBytes(StandardCharsets.ISO_8859_1);
/* 149 */     MessageDigest md = MessageDigest.getInstance(algorithm);
/* 150 */     byte[] thedigest = md.digest(bytesOfMessage);
/*     */     
/* 152 */     return HexUtils.toHexString(thedigest);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemeName() {
/* 157 */     return "digest";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\DigestAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */