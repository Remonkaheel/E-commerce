package org.apache.tomcat.websocket;

import jakarta.websocket.Extension;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

public interface Transformation {
  void setNext(Transformation paramTransformation);
  
  boolean validateRsvBits(int paramInt);
  
  Extension getExtensionResponse();
  
  TransformationResult getMoreData(byte paramByte, boolean paramBoolean, int paramInt, ByteBuffer paramByteBuffer) throws IOException;
  
  boolean validateRsv(int paramInt, byte paramByte);
  
  List<MessagePart> sendMessagePart(List<MessagePart> paramList) throws IOException;
  
  void close();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\Transformation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */