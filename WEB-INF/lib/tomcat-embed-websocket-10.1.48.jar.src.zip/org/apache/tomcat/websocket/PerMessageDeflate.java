/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import jakarta.websocket.Extension;
/*     */ import jakarta.websocket.SendHandler;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.Inflater;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerMessageDeflate
/*     */   implements Transformation
/*     */ {
/*  35 */   private static final StringManager sm = StringManager.getManager(PerMessageDeflate.class);
/*     */   
/*     */   private static final String SERVER_NO_CONTEXT_TAKEOVER = "server_no_context_takeover";
/*     */   
/*     */   private static final String CLIENT_NO_CONTEXT_TAKEOVER = "client_no_context_takeover";
/*     */   private static final String SERVER_MAX_WINDOW_BITS = "server_max_window_bits";
/*     */   private static final String CLIENT_MAX_WINDOW_BITS = "client_max_window_bits";
/*     */   private static final int RSV_BITMASK = 4;
/*  43 */   private static final byte[] EOM_BYTES = new byte[] { 0, 0, -1, -1 };
/*     */   
/*     */   public static final String NAME = "permessage-deflate";
/*     */   
/*  47 */   public static final TransformationBuilder BUILDER = new TransformationBuilder()
/*     */     {
/*     */       public Transformation build(List<List<Extension.Parameter>> preferences, boolean isServer) {
/*  50 */         return PerMessageDeflate.build(preferences, isServer);
/*     */       }
/*     */     };
/*     */   
/*     */   private final boolean serverContextTakeover;
/*     */   private final int serverMaxWindowBits;
/*     */   private final boolean clientContextTakeover;
/*     */   private final int clientMaxWindowBits;
/*     */   private final boolean isServer;
/*  59 */   private final Inflater inflater = new Inflater(true);
/*  60 */   private final ByteBuffer readBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*  61 */   private final Deflater deflater = new Deflater(-1, true);
/*  62 */   private final byte[] EOM_BUFFER = new byte[EOM_BYTES.length + 1];
/*     */   
/*     */   private volatile Transformation next;
/*     */   private volatile boolean skipDecompression = false;
/*  66 */   private volatile ByteBuffer writeBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*     */   
/*     */   private volatile boolean firstCompressedFrameWritten = false;
/*     */   
/*     */   private volatile boolean emptyMessage = true;
/*     */   
/*     */   static PerMessageDeflate build(List<List<Extension.Parameter>> preferences, boolean isServer) {
/*  73 */     for (List<Extension.Parameter> preference : preferences) {
/*  74 */       boolean ok = true;
/*  75 */       boolean serverContextTakeover = true;
/*  76 */       int serverMaxWindowBits = -1;
/*  77 */       boolean clientContextTakeover = true;
/*  78 */       int clientMaxWindowBits = -1;
/*     */       
/*  80 */       for (Extension.Parameter param : preference) {
/*  81 */         if ("server_no_context_takeover".equals(param.getName())) {
/*  82 */           if (serverContextTakeover) {
/*  83 */             serverContextTakeover = false;
/*     */             continue;
/*     */           } 
/*  86 */           throw new IllegalArgumentException(sm
/*  87 */               .getString("perMessageDeflate.duplicateParameter", new Object[] { "server_no_context_takeover" }));
/*     */         } 
/*  89 */         if ("client_no_context_takeover".equals(param.getName())) {
/*  90 */           if (clientContextTakeover) {
/*  91 */             clientContextTakeover = false;
/*     */             continue;
/*     */           } 
/*  94 */           throw new IllegalArgumentException(sm
/*  95 */               .getString("perMessageDeflate.duplicateParameter", new Object[] { "client_no_context_takeover" }));
/*     */         } 
/*  97 */         if ("server_max_window_bits".equals(param.getName())) {
/*  98 */           if (serverMaxWindowBits == -1) {
/*  99 */             serverMaxWindowBits = Integer.parseInt(param.getValue());
/* 100 */             if (serverMaxWindowBits < 8 || serverMaxWindowBits > 15) {
/* 101 */               throw new IllegalArgumentException(sm.getString("perMessageDeflate.invalidWindowSize", new Object[] { "server_max_window_bits", 
/* 102 */                       Integer.valueOf(serverMaxWindowBits) }));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 107 */             if (isServer && serverMaxWindowBits != 15) {
/* 108 */               ok = false;
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 117 */           throw new IllegalArgumentException(sm
/* 118 */               .getString("perMessageDeflate.duplicateParameter", new Object[] { "server_max_window_bits" }));
/*     */         } 
/* 120 */         if ("client_max_window_bits".equals(param.getName())) {
/* 121 */           if (clientMaxWindowBits == -1) {
/* 122 */             if (param.getValue() == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 127 */               clientMaxWindowBits = 15;
/*     */             } else {
/* 129 */               clientMaxWindowBits = Integer.parseInt(param.getValue());
/* 130 */               if (clientMaxWindowBits < 8 || clientMaxWindowBits > 15) {
/* 131 */                 throw new IllegalArgumentException(sm.getString("perMessageDeflate.invalidWindowSize", new Object[] { "client_max_window_bits", 
/* 132 */                         Integer.valueOf(clientMaxWindowBits) }));
/*     */               }
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 138 */             if (!isServer && clientMaxWindowBits != 15) {
/* 139 */               ok = false;
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 148 */           throw new IllegalArgumentException(sm
/* 149 */               .getString("perMessageDeflate.duplicateParameter", new Object[] { "client_max_window_bits" }));
/*     */         } 
/*     */ 
/*     */         
/* 153 */         throw new IllegalArgumentException(sm
/* 154 */             .getString("perMessageDeflate.unknownParameter", new Object[] { param.getName() }));
/*     */       } 
/*     */       
/* 157 */       if (ok) {
/* 158 */         return new PerMessageDeflate(serverContextTakeover, serverMaxWindowBits, clientContextTakeover, clientMaxWindowBits, isServer);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PerMessageDeflate(boolean serverContextTakeover, int serverMaxWindowBits, boolean clientContextTakeover, int clientMaxWindowBits, boolean isServer) {
/* 169 */     this.serverContextTakeover = serverContextTakeover;
/* 170 */     this.serverMaxWindowBits = serverMaxWindowBits;
/* 171 */     this.clientContextTakeover = clientContextTakeover;
/* 172 */     this.clientMaxWindowBits = clientMaxWindowBits;
/* 173 */     this.isServer = isServer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest) throws IOException {
/* 181 */     if (Util.isControl(opCode)) {
/* 182 */       return this.next.getMoreData(opCode, fin, rsv, dest);
/*     */     }
/*     */     
/* 185 */     if (!Util.isContinuation(opCode))
/*     */     {
/* 187 */       this.skipDecompression = ((rsv & 0x4) == 0);
/*     */     }
/*     */ 
/*     */     
/* 191 */     if (this.skipDecompression) {
/* 192 */       return this.next.getMoreData(opCode, fin, rsv, dest);
/*     */     }
/*     */ 
/*     */     
/* 196 */     boolean usedEomBytes = false;
/*     */     
/* 198 */     while (dest.remaining() > 0 || usedEomBytes) {
/*     */       int written;
/*     */       try {
/* 201 */         written = this.inflater.inflate(dest.array(), dest.arrayOffset() + dest.position(), dest.remaining());
/* 202 */       } catch (DataFormatException e) {
/* 203 */         throw new IOException(sm.getString("perMessageDeflate.deflateFailed"), e);
/* 204 */       } catch (IllegalStateException|NullPointerException e) {
/*     */         
/* 206 */         throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */       } 
/* 208 */       dest.position(dest.position() + written);
/*     */       
/* 210 */       if (this.inflater.needsInput() && !usedEomBytes) {
/* 211 */         this.readBuffer.clear();
/* 212 */         TransformationResult nextResult = this.next.getMoreData(opCode, fin, rsv ^ 0x4, this.readBuffer);
/* 213 */         this.inflater.setInput(this.readBuffer.array(), this.readBuffer.arrayOffset(), this.readBuffer.position());
/* 214 */         if (dest.hasRemaining()) {
/* 215 */           if (TransformationResult.UNDERFLOW.equals(nextResult))
/* 216 */             return nextResult; 
/* 217 */           if (TransformationResult.END_OF_FRAME.equals(nextResult) && this.readBuffer.position() == 0) {
/* 218 */             if (fin) {
/* 219 */               this.inflater.setInput(EOM_BYTES);
/* 220 */               usedEomBytes = true; continue;
/*     */             } 
/* 222 */             return TransformationResult.END_OF_FRAME;
/*     */           }  continue;
/*     */         } 
/* 225 */         if (this.readBuffer.position() > 0)
/* 226 */           return TransformationResult.OVERFLOW; 
/* 227 */         if (fin) {
/* 228 */           this.inflater.setInput(EOM_BYTES);
/* 229 */           usedEomBytes = true;
/*     */         }  continue;
/* 231 */       }  if (written == 0) {
/* 232 */         if (fin && ((this.isServer && !this.clientContextTakeover) || (!this.isServer && !this.serverContextTakeover))) {
/*     */           try {
/* 234 */             this.inflater.reset();
/* 235 */           } catch (NullPointerException e) {
/* 236 */             throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */           } 
/*     */         }
/* 239 */         return TransformationResult.END_OF_FRAME;
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     return TransformationResult.OVERFLOW;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateRsv(int rsv, byte opCode) {
/* 249 */     if (Util.isControl(opCode)) {
/* 250 */       if ((rsv & 0x4) != 0) {
/* 251 */         return false;
/*     */       }
/* 253 */       if (this.next == null) {
/* 254 */         return true;
/*     */       }
/* 256 */       return this.next.validateRsv(rsv, opCode);
/*     */     } 
/*     */ 
/*     */     
/* 260 */     int rsvNext = rsv;
/* 261 */     if ((rsv & 0x4) != 0) {
/* 262 */       rsvNext = rsv ^ 0x4;
/*     */     }
/* 264 */     if (this.next == null) {
/* 265 */       return true;
/*     */     }
/* 267 */     return this.next.validateRsv(rsvNext, opCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extension getExtensionResponse() {
/* 275 */     Extension result = new WsExtension("permessage-deflate");
/*     */     
/* 277 */     List<Extension.Parameter> params = result.getParameters();
/*     */     
/* 279 */     if (!this.serverContextTakeover) {
/* 280 */       params.add(new WsExtensionParameter("server_no_context_takeover", null));
/*     */     }
/* 282 */     if (this.serverMaxWindowBits != -1) {
/* 283 */       params.add(new WsExtensionParameter("server_max_window_bits", Integer.toString(this.serverMaxWindowBits)));
/*     */     }
/* 285 */     if (!this.clientContextTakeover) {
/* 286 */       params.add(new WsExtensionParameter("client_no_context_takeover", null));
/*     */     }
/* 288 */     if (this.clientMaxWindowBits != -1) {
/* 289 */       params.add(new WsExtensionParameter("client_max_window_bits", Integer.toString(this.clientMaxWindowBits)));
/*     */     }
/*     */     
/* 292 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNext(Transformation t) {
/* 298 */     if (this.next == null) {
/* 299 */       this.next = t;
/*     */     } else {
/* 301 */       this.next.setNext(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateRsvBits(int i) {
/* 308 */     if ((i & 0x4) != 0) {
/* 309 */       return false;
/*     */     }
/* 311 */     if (this.next == null) {
/* 312 */       return true;
/*     */     }
/* 314 */     return this.next.validateRsvBits(i | 0x4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MessagePart> sendMessagePart(List<MessagePart> uncompressedParts) throws IOException {
/* 321 */     List<MessagePart> allCompressedParts = new ArrayList<>();
/*     */     
/* 323 */     for (MessagePart uncompressedPart : uncompressedParts) {
/* 324 */       byte opCode = uncompressedPart.getOpCode();
/* 325 */       if (Util.isControl(opCode)) {
/*     */ 
/*     */         
/* 328 */         allCompressedParts.add(uncompressedPart);
/*     */         
/*     */         continue;
/*     */       } 
/* 332 */       if (uncompressedPart.getPayload().limit() != 0) {
/* 333 */         this.emptyMessage = false;
/*     */       }
/* 335 */       if (this.emptyMessage && uncompressedPart.isFin()) {
/*     */ 
/*     */         
/* 338 */         allCompressedParts.add(uncompressedPart); continue;
/*     */       } 
/* 340 */       List<MessagePart> compressedParts = new ArrayList<>();
/* 341 */       ByteBuffer uncompressedPayload = uncompressedPart.getPayload();
/* 342 */       SendHandler uncompressedIntermediateHandler = uncompressedPart.getIntermediateHandler();
/*     */       
/* 344 */       if (uncompressedPayload.hasArray()) {
/* 345 */         this.deflater.setInput(uncompressedPayload.array(), uncompressedPayload
/* 346 */             .arrayOffset() + uncompressedPayload.position(), uncompressedPayload
/* 347 */             .remaining());
/*     */       } else {
/* 349 */         byte[] bytes = new byte[uncompressedPayload.remaining()];
/* 350 */         uncompressedPayload.get(bytes);
/* 351 */         this.deflater.setInput(bytes, 0, bytes.length);
/*     */       } 
/*     */       
/* 354 */       int flush = uncompressedPart.isFin() ? 2 : 0;
/* 355 */       boolean deflateRequired = true;
/*     */       
/* 357 */       while (deflateRequired) {
/* 358 */         MessagePart compressedPart; ByteBuffer compressedPayload = this.writeBuffer;
/*     */         
/*     */         try {
/* 361 */           int written = this.deflater.deflate(compressedPayload.array(), compressedPayload
/* 362 */               .arrayOffset() + compressedPayload.position(), compressedPayload
/* 363 */               .remaining(), flush);
/* 364 */           compressedPayload.position(compressedPayload.position() + written);
/* 365 */         } catch (IllegalStateException|NullPointerException e) {
/*     */           
/* 367 */           throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */         } 
/*     */         
/* 370 */         if (!uncompressedPart.isFin() && compressedPayload.hasRemaining() && this.deflater.needsInput()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 382 */         this.writeBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*     */ 
/*     */         
/* 385 */         compressedPayload.flip();
/*     */         
/* 387 */         boolean fin = uncompressedPart.isFin();
/* 388 */         boolean full = (compressedPayload.limit() == compressedPayload.capacity());
/* 389 */         boolean needsInput = this.deflater.needsInput();
/* 390 */         long blockingWriteTimeoutExpiry = uncompressedPart.getBlockingWriteTimeoutExpiry();
/*     */         
/* 392 */         if (fin && !full && needsInput) {
/*     */           
/* 394 */           compressedPayload.limit(compressedPayload.limit() - EOM_BYTES.length);
/* 395 */           compressedPart = new MessagePart(true, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */ 
/*     */           
/* 398 */           deflateRequired = false;
/* 399 */           startNewMessage();
/* 400 */         } else if (full && !needsInput) {
/*     */ 
/*     */           
/* 403 */           compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */         
/*     */         }
/* 406 */         else if (!fin && full) {
/*     */ 
/*     */           
/* 409 */           compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */ 
/*     */           
/* 412 */           deflateRequired = false;
/* 413 */         } else if (fin && full) {
/*     */           int eomBufferWritten;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 423 */             eomBufferWritten = this.deflater.deflate(this.EOM_BUFFER, 0, this.EOM_BUFFER.length, 2);
/* 424 */           } catch (NullPointerException e) {
/* 425 */             throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */           } 
/* 427 */           if (eomBufferWritten < this.EOM_BUFFER.length)
/*     */           {
/* 429 */             compressedPayload.limit(compressedPayload.limit() - EOM_BYTES.length + eomBufferWritten);
/* 430 */             compressedPart = new MessagePart(true, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */ 
/*     */             
/* 433 */             deflateRequired = false;
/* 434 */             startNewMessage();
/*     */           }
/*     */           else
/*     */           {
/* 438 */             this.writeBuffer.put(this.EOM_BUFFER, 0, eomBufferWritten);
/* 439 */             compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 444 */           throw new IllegalStateException(sm.getString("perMessageDeflate.invalidState"));
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 449 */         compressedParts.add(compressedPart);
/*     */       } 
/*     */       
/* 452 */       SendHandler uncompressedEndHandler = uncompressedPart.getEndHandler();
/* 453 */       int size = compressedParts.size();
/* 454 */       if (size > 0) {
/* 455 */         ((MessagePart)compressedParts.get(size - 1)).setEndHandler(uncompressedEndHandler);
/*     */       }
/*     */       
/* 458 */       allCompressedParts.addAll(compressedParts);
/*     */     } 
/*     */ 
/*     */     
/* 462 */     if (this.next == null) {
/* 463 */       return allCompressedParts;
/*     */     }
/* 465 */     return this.next.sendMessagePart(allCompressedParts);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void startNewMessage() throws IOException {
/* 471 */     this.firstCompressedFrameWritten = false;
/* 472 */     this.emptyMessage = true;
/* 473 */     if ((this.isServer && !this.serverContextTakeover) || (!this.isServer && !this.clientContextTakeover)) {
/*     */       try {
/* 475 */         this.deflater.reset();
/* 476 */       } catch (NullPointerException e) {
/* 477 */         throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private int getRsv(MessagePart uncompressedMessagePart) {
/* 484 */     int result = uncompressedMessagePart.getRsv();
/* 485 */     if (!this.firstCompressedFrameWritten) {
/* 486 */       result += 4;
/* 487 */       this.firstCompressedFrameWritten = true;
/*     */     } 
/* 489 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 496 */     this.next.close();
/* 497 */     this.inflater.end();
/* 498 */     this.deflater.end();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\PerMessageDeflate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */