/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.Extension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsExtensionParameter
/*    */   implements Extension.Parameter
/*    */ {
/*    */   private final String name;
/*    */   private final String value;
/*    */   
/*    */   WsExtensionParameter(String name, String value) {
/* 27 */     this.name = name;
/* 28 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 33 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 38 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsExtensionParameter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */