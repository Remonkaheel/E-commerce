/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import jakarta.websocket.ContainerProvider;
/*    */ import jakarta.websocket.WebSocketContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ContainerProvider.class)
/*    */ public class WsContainerProvider
/*    */   extends ContainerProvider
/*    */ {
/*    */   protected WebSocketContainer getContainer() {
/* 27 */     return new WsWebSocketContainer();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsContainerProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */