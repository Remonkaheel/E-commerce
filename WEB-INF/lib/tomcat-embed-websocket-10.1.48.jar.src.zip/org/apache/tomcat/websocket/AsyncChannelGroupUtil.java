/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.nio.channels.AsynchronousChannelGroup;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.ThreadPoolExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncChannelGroupUtil
/*     */ {
/*  38 */   private static final StringManager sm = StringManager.getManager(AsyncChannelGroupUtil.class);
/*     */   
/*  40 */   private static AsynchronousChannelGroup group = null;
/*  41 */   private static int usageCount = 0;
/*  42 */   private static final Object lock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AsynchronousChannelGroup register() {
/*  51 */     synchronized (lock) {
/*  52 */       if (usageCount == 0) {
/*  53 */         group = createAsynchronousChannelGroup();
/*     */       }
/*  55 */       usageCount++;
/*  56 */       return group;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void unregister() {
/*  62 */     synchronized (lock) {
/*  63 */       usageCount--;
/*  64 */       if (usageCount == 0) {
/*  65 */         group.shutdown();
/*  66 */         group = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AsynchronousChannelGroup createAsynchronousChannelGroup() {
/*  75 */     Thread currentThread = Thread.currentThread();
/*  76 */     ClassLoader original = currentThread.getContextClassLoader();
/*     */     
/*     */     try {
/*  79 */       currentThread.setContextClassLoader(AsyncIOThreadFactory.class.getClassLoader());
/*     */ 
/*     */ 
/*     */       
/*  83 */       int initialSize = Runtime.getRuntime().availableProcessors();
/*  84 */       ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue(), new AsyncIOThreadFactory());
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       currentThread.setContextClassLoader(original);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AsyncIOThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     static {
/* 105 */       NewThreadPrivilegedAction.load();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/* 115 */       return AccessController.<Thread>doPrivileged(new NewThreadPrivilegedAction(r));
/*     */     }
/*     */ 
/*     */     
/*     */     private static class NewThreadPrivilegedAction
/*     */       implements PrivilegedAction<Thread>
/*     */     {
/* 122 */       private static AtomicInteger count = new AtomicInteger(0);
/*     */       
/*     */       private final Runnable r;
/*     */       
/*     */       NewThreadPrivilegedAction(Runnable r) {
/* 127 */         this.r = r;
/*     */       }
/*     */       
/*     */       private static void load() {}
/*     */       
/* 132 */       public Thread run() { Thread t = new Thread(this.r);
/* 133 */         t.setName("WebSocketClient-AsyncIO-" + count.incrementAndGet());
/* 134 */         t.setContextClassLoader(getClass().getClassLoader());
/* 135 */         t.setDaemon(true);
/* 136 */         return t; } } } private static class NewThreadPrivilegedAction implements PrivilegedAction<Thread> { public Thread run() { Thread t = new Thread(this.r); t.setName("WebSocketClient-AsyncIO-" + count.incrementAndGet()); t.setContextClassLoader(getClass().getClassLoader()); t.setDaemon(true); return t; }
/*     */ 
/*     */     
/*     */     private static AtomicInteger count = new AtomicInteger(0);
/*     */     private final Runnable r;
/*     */     
/*     */     NewThreadPrivilegedAction(Runnable r) {
/*     */       this.r = r;
/*     */     }
/*     */     
/*     */     private static void load() {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\AsyncChannelGroupUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */