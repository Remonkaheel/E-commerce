/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.RemoteEndpoint;
/*    */ import jakarta.websocket.SendHandler;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.concurrent.Future;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsRemoteEndpointAsync
/*    */   extends WsRemoteEndpointBase
/*    */   implements RemoteEndpoint.Async
/*    */ {
/*    */   WsRemoteEndpointAsync(WsRemoteEndpointImplBase base) {
/* 28 */     super(base);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long getSendTimeout() {
/* 34 */     return this.base.getSendTimeout();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSendTimeout(long timeout) {
/* 40 */     this.base.setSendTimeout(timeout);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendText(String text, SendHandler completion) {
/* 46 */     this.base.sendStringByCompletion(text, completion);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Future<Void> sendText(String text) {
/* 52 */     return this.base.sendStringByFuture(text);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Future<Void> sendBinary(ByteBuffer data) {
/* 58 */     return this.base.sendBytesByFuture(data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendBinary(ByteBuffer data, SendHandler completion) {
/* 64 */     this.base.sendBytesByCompletion(data, completion);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Future<Void> sendObject(Object obj) {
/* 70 */     return this.base.sendObjectByFuture(obj);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendObject(Object obj, SendHandler completion) {
/* 76 */     this.base.sendObjectByCompletion(obj, completion);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsRemoteEndpointAsync.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */