/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.Decoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderEntry
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   private final Class<? extends Decoder> decoderClazz;
/*    */   
/*    */   public DecoderEntry(Class<?> clazz, Class<? extends Decoder> decoderClazz) {
/* 27 */     this.clazz = clazz;
/* 28 */     this.decoderClazz = decoderClazz;
/*    */   }
/*    */   
/*    */   public Class<?> getClazz() {
/* 32 */     return this.clazz;
/*    */   }
/*    */   
/*    */   public Class<? extends Decoder> getDecoderClazz() {
/* 36 */     return this.decoderClazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\DecoderEntry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */