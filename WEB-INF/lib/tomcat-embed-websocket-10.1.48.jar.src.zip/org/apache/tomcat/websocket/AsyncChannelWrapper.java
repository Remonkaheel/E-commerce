package org.apache.tomcat.websocket;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLException;

public interface AsyncChannelWrapper {
  Future<Integer> read(ByteBuffer paramByteBuffer);
  
  <B, A extends B> void read(ByteBuffer paramByteBuffer, A paramA, CompletionHandler<Integer, B> paramCompletionHandler);
  
  Future<Integer> write(ByteBuffer paramByteBuffer);
  
  <B, A extends B> void write(ByteBuffer[] paramArrayOfByteBuffer, int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, A paramA, CompletionHandler<Long, B> paramCompletionHandler);
  
  void close();
  
  Future<Void> handshake() throws SSLException;
  
  SocketAddress getLocalAddress() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\AsyncChannelWrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */