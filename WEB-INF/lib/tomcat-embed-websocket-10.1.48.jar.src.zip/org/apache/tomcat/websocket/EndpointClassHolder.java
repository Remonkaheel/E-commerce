/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import jakarta.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndpointClassHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 29 */   private static final StringManager sm = StringManager.getManager(EndpointClassHolder.class);
/*    */   
/*    */   private final Class<? extends Endpoint> clazz;
/*    */ 
/*    */   
/*    */   public EndpointClassHolder(Class<? extends Endpoint> clazz) {
/* 35 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 41 */     return this.clazz.getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException {
/*    */     try {
/* 48 */       if (instanceManager == null) {
/* 49 */         return this.clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       }
/* 51 */       return (Endpoint)instanceManager.newInstance(this.clazz);
/*    */     }
/* 53 */     catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 54 */       throw new DeploymentException(sm.getString("clientEndpointHolder.instanceCreationFailed"), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\EndpointClassHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */