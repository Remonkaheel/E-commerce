/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.PongMessage;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsPongMessage
/*    */   implements PongMessage
/*    */ {
/*    */   private final ByteBuffer applicationData;
/*    */   
/*    */   public WsPongMessage(ByteBuffer applicationData) {
/* 29 */     byte[] dst = new byte[applicationData.limit()];
/* 30 */     applicationData.get(dst);
/* 31 */     this.applicationData = ByteBuffer.wrap(dst);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteBuffer getApplicationData() {
/* 37 */     return this.applicationData;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsPongMessage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */