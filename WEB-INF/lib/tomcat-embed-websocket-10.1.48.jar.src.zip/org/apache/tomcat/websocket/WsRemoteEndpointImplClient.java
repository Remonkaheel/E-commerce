/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.SendHandler;
/*    */ import jakarta.websocket.SendResult;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsRemoteEndpointImplClient
/*    */   extends WsRemoteEndpointImplBase
/*    */ {
/*    */   private final AsyncChannelWrapper channel;
/* 32 */   private final ReentrantLock lock = new ReentrantLock();
/*    */   
/*    */   public WsRemoteEndpointImplClient(AsyncChannelWrapper channel) {
/* 35 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isMasked() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doWrite(SendHandler handler, long blockingWriteTimeoutExpiry, ByteBuffer... data) {
/* 48 */     for (ByteBuffer byteBuffer : data) {
/* 49 */       long timeout; if (blockingWriteTimeoutExpiry == -1L) {
/* 50 */         timeout = getSendTimeout();
/* 51 */         if (timeout < 1L) {
/* 52 */           timeout = Long.MAX_VALUE;
/*    */         }
/*    */       } else {
/* 55 */         timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/* 56 */         if (timeout < 0L) {
/* 57 */           SendResult sr = new SendResult(new IOException(sm.getString("wsRemoteEndpoint.writeTimeout")));
/* 58 */           handler.onResult(sr);
/*    */           
/*    */           return;
/*    */         } 
/*    */       } 
/*    */       try {
/* 64 */         this.channel.write(byteBuffer).get(timeout, TimeUnit.MILLISECONDS);
/* 65 */       } catch (InterruptedException|java.util.concurrent.ExecutionException|java.util.concurrent.TimeoutException e) {
/* 66 */         handler.onResult(new SendResult(e));
/*    */         return;
/*    */       } 
/*    */     } 
/* 70 */     handler.onResult(SENDRESULT_OK);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doClose() {
/* 76 */     this.channel.close();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ReentrantLock getLock() {
/* 82 */     return this.lock;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsRemoteEndpointImplClient.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */