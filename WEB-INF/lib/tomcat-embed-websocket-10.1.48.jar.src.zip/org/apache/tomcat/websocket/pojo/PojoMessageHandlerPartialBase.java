/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import jakarta.websocket.MessageHandler;
/*    */ import jakarta.websocket.Session;
/*    */ import java.lang.reflect.Method;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.apache.tomcat.websocket.WsSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PojoMessageHandlerPartialBase<T>
/*    */   extends PojoMessageHandlerBase<T>
/*    */   implements MessageHandler.Partial<T>
/*    */ {
/*    */   private final int indexBoolean;
/*    */   
/*    */   public PojoMessageHandlerPartialBase(Object pojo, Method method, Session session, Object[] params, int indexPayload, boolean convert, int indexBoolean, int indexSession, long maxMessageSize) {
/* 42 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/* 43 */     this.indexBoolean = indexBoolean;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void onMessage(T message, boolean last) {
/* 49 */     if (this.params.length == 1 && this.params[0] instanceof jakarta.websocket.DecodeException) {
/* 50 */       ((WsSession)this.session).getLocal().onError(this.session, (Throwable)this.params[0]);
/*    */       return;
/*    */     } 
/* 53 */     Object[] parameters = (Object[])this.params.clone();
/* 54 */     if (this.indexBoolean != -1) {
/* 55 */       parameters[this.indexBoolean] = Boolean.valueOf(last);
/*    */     }
/* 57 */     if (this.indexSession != -1) {
/* 58 */       parameters[this.indexSession] = this.session;
/*    */     }
/* 60 */     if (this.convert) {
/* 61 */       parameters[this.indexPayload] = ((ByteBuffer)message).array();
/*    */     } else {
/* 63 */       parameters[this.indexPayload] = message;
/*    */     } 
/* 65 */     Object result = null;
/*    */     try {
/* 67 */       result = this.method.invoke(this.pojo, parameters);
/* 68 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 69 */       handlePojoMethodException(e);
/*    */     } 
/* 71 */     processResult(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerPartialBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */