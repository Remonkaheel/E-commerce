/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoPathParam
/*    */ {
/* 32 */   private static final StringManager sm = StringManager.getManager(PojoPathParam.class);
/*    */   
/*    */   private final Class<?> type;
/*    */   
/*    */   private final String name;
/*    */   
/*    */   public PojoPathParam(Class<?> type, String name) throws DeploymentException {
/* 39 */     if (name != null)
/*    */     {
/* 41 */       validateType(type);
/*    */     }
/* 43 */     this.type = type;
/* 44 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getType() {
/* 49 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 54 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   private static void validateType(Class<?> type) throws DeploymentException {
/* 59 */     if (String.class == type) {
/*    */       return;
/*    */     }
/* 62 */     if (Util.isPrimitive(type)) {
/*    */       return;
/*    */     }
/* 65 */     throw new DeploymentException(sm.getString("pojoPathParam.wrongType", new Object[] { type.getName() }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoPathParam.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */