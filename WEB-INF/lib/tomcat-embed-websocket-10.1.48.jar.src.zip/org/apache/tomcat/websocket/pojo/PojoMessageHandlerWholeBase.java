/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import jakarta.websocket.DecodeException;
/*     */ import jakarta.websocket.Decoder;
/*     */ import jakarta.websocket.MessageHandler;
/*     */ import jakarta.websocket.Session;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PojoMessageHandlerWholeBase<T>
/*     */   extends PojoMessageHandlerBase<T>
/*     */   implements MessageHandler.Whole<T>
/*     */ {
/*  46 */   private final Log log = LogFactory.getLog(PojoMessageHandlerWholeBase.class);
/*  47 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerWholeBase.class);
/*     */   
/*  49 */   protected final List<Decoder> decoders = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public PojoMessageHandlerWholeBase(Object pojo, Method method, Session session, Object[] params, int indexPayload, boolean convert, int indexSession, long maxMessageSize) {
/*  53 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Decoder createDecoderInstance(Class<? extends Decoder> clazz) throws ReflectiveOperationException, NamingException {
/*  59 */     InstanceManager instanceManager = ((WsSession)this.session).getInstanceManager();
/*  60 */     if (instanceManager == null) {
/*  61 */       return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     }
/*  63 */     return (Decoder)instanceManager.newInstance(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onMessage(T message) {
/*     */     Object payload;
/*  71 */     if (this.params.length == 1 && this.params[0] instanceof DecodeException) {
/*  72 */       ((WsSession)this.session).getLocal().onError(this.session, (Throwable)this.params[0]);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  79 */       payload = decode(message);
/*  80 */     } catch (DecodeException de) {
/*  81 */       ((WsSession)this.session).getLocal().onError(this.session, (Throwable)de);
/*     */       
/*     */       return;
/*     */     } 
/*  85 */     if (payload == null)
/*     */     {
/*  87 */       if (this.convert) {
/*  88 */         payload = convert(message);
/*     */       } else {
/*  90 */         payload = message;
/*     */       } 
/*     */     }
/*     */     
/*  94 */     Object[] parameters = (Object[])this.params.clone();
/*  95 */     if (this.indexSession != -1) {
/*  96 */       parameters[this.indexSession] = this.session;
/*     */     }
/*  98 */     parameters[this.indexPayload] = payload;
/*     */     
/* 100 */     Object result = null;
/*     */     try {
/* 102 */       result = this.method.invoke(this.pojo, parameters);
/* 103 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 104 */       handlePojoMethodException(e);
/*     */     } 
/* 106 */     processResult(result);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onClose() {
/* 111 */     InstanceManager instanceManager = ((WsSession)this.session).getInstanceManager();
/*     */     
/* 113 */     for (Decoder decoder : this.decoders) {
/* 114 */       decoder.destroy();
/* 115 */       if (instanceManager != null) {
/*     */         try {
/* 117 */           instanceManager.destroyInstance(decoder);
/* 118 */         } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 119 */           this.log.warn(sm.getString("pojoMessageHandlerWholeBase.decodeDestroyFailed", new Object[] { decoder.getClass() }), e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object convert(T message) {
/* 127 */     return message;
/*     */   }
/*     */   
/*     */   protected abstract Object decode(T paramT) throws DecodeException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerWholeBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */