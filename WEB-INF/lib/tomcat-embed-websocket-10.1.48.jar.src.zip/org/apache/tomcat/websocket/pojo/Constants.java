package org.apache.tomcat.websocket.pojo;

public class Constants {
  public static final String POJO_METHOD_MAPPING_KEY = "org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\Constants.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */