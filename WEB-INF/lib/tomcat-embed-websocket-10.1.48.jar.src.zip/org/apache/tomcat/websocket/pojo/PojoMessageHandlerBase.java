/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import jakarta.websocket.MessageHandler;
/*     */ import jakarta.websocket.RemoteEndpoint;
/*     */ import jakarta.websocket.Session;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.WrappedMessageHandler;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PojoMessageHandlerBase<T>
/*     */   implements WrappedMessageHandler
/*     */ {
/*  42 */   private final Log log = LogFactory.getLog(PojoMessageHandlerBase.class);
/*  43 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerBase.class);
/*     */   
/*     */   protected final Object pojo;
/*     */   
/*     */   protected final Method method;
/*     */   protected final Session session;
/*     */   protected final Object[] params;
/*     */   protected final int indexPayload;
/*     */   protected final boolean convert;
/*     */   protected final int indexSession;
/*     */   protected final long maxMessageSize;
/*     */   
/*     */   public PojoMessageHandlerBase(Object pojo, Method method, Session session, Object[] params, int indexPayload, boolean convert, int indexSession, long maxMessageSize) {
/*  56 */     this.pojo = pojo;
/*  57 */     this.method = method;
/*     */ 
/*     */     
/*     */     try {
/*  61 */       this.method.setAccessible(true);
/*  62 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.session = session;
/*  67 */     this.params = params;
/*  68 */     this.indexPayload = indexPayload;
/*  69 */     this.convert = convert;
/*  70 */     this.indexSession = indexSession;
/*  71 */     this.maxMessageSize = maxMessageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void processResult(Object result) {
/*  76 */     if (result == null) {
/*     */       return;
/*     */     }
/*     */     
/*  80 */     RemoteEndpoint.Basic remoteEndpoint = this.session.getBasicRemote();
/*     */     try {
/*  82 */       if (result instanceof String) {
/*  83 */         remoteEndpoint.sendText((String)result);
/*  84 */       } else if (result instanceof ByteBuffer) {
/*  85 */         remoteEndpoint.sendBinary((ByteBuffer)result);
/*  86 */       } else if (result instanceof byte[]) {
/*  87 */         remoteEndpoint.sendBinary(ByteBuffer.wrap((byte[])result));
/*     */       } else {
/*  89 */         remoteEndpoint.sendObject(result);
/*     */       } 
/*  91 */     } catch (IOException|jakarta.websocket.EncodeException ioe) {
/*  92 */       throw new IllegalStateException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageHandler getWrappedHandler() {
/* 103 */     if (this.pojo instanceof MessageHandler) {
/* 104 */       return (MessageHandler)this.pojo;
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getMaxMessageSize() {
/* 113 */     return this.maxMessageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void handlePojoMethodException(Throwable t) {
/* 118 */     t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 119 */     ExceptionUtils.handleThrowable(t);
/* 120 */     if (t instanceof jakarta.websocket.EncodeException)
/* 121 */     { if (this.log.isDebugEnabled()) {
/* 122 */         this.log.debug(sm.getString("pojoMessageHandlerBase.encodeFail", new Object[] { this.pojo.getClass().getName(), this.session.getId() }), t);
/*     */       }
/*     */       
/* 125 */       ((WsSession)this.session).getLocal().onError(this.session, t); }
/* 126 */     else { if (t instanceof RuntimeException) {
/* 127 */         throw (RuntimeException)t;
/*     */       }
/* 129 */       throw new RuntimeException(t.getMessage(), t); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */