/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import jakarta.websocket.EndpointConfig;
/*    */ import jakarta.websocket.Session;
/*    */ import jakarta.websocket.server.ServerEndpointConfig;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoEndpointServer
/*    */   extends PojoEndpointBase
/*    */ {
/*    */   public PojoEndpointServer(Map<String, String> pathParameters, Object pojo) {
/* 32 */     super(pathParameters);
/* 33 */     setPojo(pojo);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onOpen(Session session, EndpointConfig endpointConfig) {
/* 40 */     ServerEndpointConfig sec = (ServerEndpointConfig)endpointConfig;
/*    */ 
/*    */     
/* 43 */     PojoMethodMapping methodMapping = (PojoMethodMapping)sec.getUserProperties().get("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping");
/* 44 */     setMethodMapping(methodMapping);
/*    */     
/* 46 */     doOnOpen(session, endpointConfig);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointServer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */