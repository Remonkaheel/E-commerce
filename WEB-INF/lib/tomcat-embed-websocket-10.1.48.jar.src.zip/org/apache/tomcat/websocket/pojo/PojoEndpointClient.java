/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import jakarta.websocket.Decoder;
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import jakarta.websocket.EndpointConfig;
/*    */ import jakarta.websocket.Session;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoEndpointClient
/*    */   extends PojoEndpointBase
/*    */ {
/*    */   public PojoEndpointClient(Object pojo, List<Class<? extends Decoder>> decoders, InstanceManager instanceManager) throws DeploymentException {
/* 37 */     super(Collections.emptyMap());
/* 38 */     setPojo(pojo);
/* 39 */     setMethodMapping(new PojoMethodMapping(pojo.getClass(), decoders, null, instanceManager));
/*    */   }
/*    */ 
/*    */   
/*    */   public void onOpen(Session session, EndpointConfig config) {
/* 44 */     doOnOpen(session, config);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointClient.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */