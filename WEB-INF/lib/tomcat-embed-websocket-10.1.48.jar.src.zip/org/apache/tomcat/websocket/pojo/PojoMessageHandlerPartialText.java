/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import jakarta.websocket.Session;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoMessageHandlerPartialText
/*    */   extends PojoMessageHandlerPartialBase<String>
/*    */ {
/*    */   public PojoMessageHandlerPartialText(Object pojo, Method method, Session session, Object[] params, int indexPayload, boolean convert, int indexBoolean, int indexSession, long maxMessageSize) {
/* 30 */     super(pojo, method, session, params, indexPayload, convert, indexBoolean, indexSession, maxMessageSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerPartialText.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */