/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import jakarta.websocket.CloseReason;
/*     */ import jakarta.websocket.Endpoint;
/*     */ import jakarta.websocket.EndpointConfig;
/*     */ import jakarta.websocket.MessageHandler;
/*     */ import jakarta.websocket.Session;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PojoEndpointBase
/*     */   extends Endpoint
/*     */ {
/*  41 */   private final Log log = LogFactory.getLog(PojoEndpointBase.class);
/*  42 */   private static final StringManager sm = StringManager.getManager(PojoEndpointBase.class);
/*     */   
/*     */   private Object pojo;
/*     */   
/*     */   private final Map<String, String> pathParameters;
/*     */   private PojoMethodMapping methodMapping;
/*     */   
/*     */   protected PojoEndpointBase(Map<String, String> pathParameters) {
/*  50 */     this.pathParameters = pathParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void doOnOpen(Session session, EndpointConfig config) {
/*  55 */     PojoMethodMapping methodMapping = getMethodMapping();
/*  56 */     Object pojo = getPojo();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     for (MessageHandler mh : methodMapping.getMessageHandlers(pojo, this.pathParameters, session, config)) {
/*  62 */       session.addMessageHandler(mh);
/*     */     }
/*     */     
/*  65 */     if (methodMapping.getOnOpen() != null) {
/*     */       try {
/*  67 */         methodMapping.getOnOpen().invoke(pojo, methodMapping.getOnOpenArgs(this.pathParameters, session, config));
/*     */       }
/*  69 */       catch (IllegalAccessException e) {
/*     */         
/*  71 */         this.log.error(sm.getString("pojoEndpointBase.onOpenFail", new Object[] { pojo.getClass().getName() }), e);
/*  72 */         handleOnOpenOrCloseError(session, e);
/*  73 */       } catch (InvocationTargetException e) {
/*  74 */         Throwable cause = e.getCause();
/*  75 */         handleOnOpenOrCloseError(session, cause);
/*  76 */       } catch (Throwable t) {
/*  77 */         handleOnOpenOrCloseError(session, t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleOnOpenOrCloseError(Session session, Throwable t) {
/*  85 */     ExceptionUtils.handleThrowable(t);
/*     */ 
/*     */     
/*  88 */     onError(session, t);
/*     */     try {
/*  90 */       session.close();
/*  91 */     } catch (IOException ioe) {
/*  92 */       this.log.warn(sm.getString("pojoEndpointBase.closeSessionFail"), ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onClose(Session session, CloseReason closeReason) {
/*  99 */     if (this.methodMapping.getOnClose() != null) {
/*     */       try {
/* 101 */         this.methodMapping.getOnClose().invoke(this.pojo, this.methodMapping
/* 102 */             .getOnCloseArgs(this.pathParameters, session, closeReason));
/* 103 */       } catch (Throwable t) {
/* 104 */         this.log.error(sm.getString("pojoEndpointBase.onCloseFail", new Object[] { this.pojo.getClass().getName() }), t);
/* 105 */         handleOnOpenOrCloseError(session, t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 110 */     Set<MessageHandler> messageHandlers = session.getMessageHandlers();
/* 111 */     for (MessageHandler messageHandler : messageHandlers) {
/* 112 */       if (messageHandler instanceof PojoMessageHandlerWholeBase) {
/* 113 */         ((PojoMessageHandlerWholeBase)messageHandler).onClose();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(Session session, Throwable throwable) {
/* 122 */     if (this.methodMapping.getOnError() == null) {
/* 123 */       this.log.error(sm.getString("pojoEndpointBase.onError", new Object[] { this.pojo.getClass().getName() }), throwable);
/*     */     } else {
/*     */       try {
/* 126 */         this.methodMapping.getOnError().invoke(this.pojo, this.methodMapping
/* 127 */             .getOnErrorArgs(this.pathParameters, session, throwable));
/* 128 */       } catch (Throwable t) {
/* 129 */         ExceptionUtils.handleThrowable(t);
/* 130 */         this.log.error(sm.getString("pojoEndpointBase.onErrorFail", new Object[] { this.pojo.getClass().getName() }), t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object getPojo() {
/* 136 */     return this.pojo;
/*     */   }
/*     */   
/*     */   protected void setPojo(Object pojo) {
/* 140 */     this.pojo = pojo;
/*     */   }
/*     */ 
/*     */   
/*     */   protected PojoMethodMapping getMethodMapping() {
/* 145 */     return this.methodMapping;
/*     */   }
/*     */   
/*     */   protected void setMethodMapping(PojoMethodMapping methodMapping) {
/* 149 */     this.methodMapping = methodMapping;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */