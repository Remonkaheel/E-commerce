/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.MessageHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageHandlerResult
/*    */ {
/*    */   private final MessageHandler handler;
/*    */   private final MessageHandlerResultType type;
/*    */   
/*    */   public MessageHandlerResult(MessageHandler handler, MessageHandlerResultType type) {
/* 28 */     this.handler = handler;
/* 29 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageHandler getHandler() {
/* 34 */     return this.handler;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageHandlerResultType getType() {
/* 39 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\MessageHandlerResult.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */