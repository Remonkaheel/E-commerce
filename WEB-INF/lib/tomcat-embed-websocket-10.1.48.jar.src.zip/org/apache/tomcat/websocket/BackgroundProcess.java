package org.apache.tomcat.websocket;

public interface BackgroundProcess {
  void backgroundProcess();
  
  void setProcessPeriod(int paramInt);
  
  int getProcessPeriod();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\BackgroundProcess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */