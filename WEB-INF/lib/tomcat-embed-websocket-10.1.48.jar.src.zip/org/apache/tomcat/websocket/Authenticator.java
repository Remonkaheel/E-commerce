/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Authenticator
/*     */ {
/*  31 */   private static final StringManager sm = StringManager.getManager(Authenticator.class);
/*     */   
/*  33 */   private static final Pattern pattern = Pattern.compile("(\\w+)\\s*=\\s*(\"([^\"]+)\"|([^,=\"]+))\\s*,?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getAuthorization(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) throws AuthenticationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getSchemeName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> parseAuthenticateHeader(String authenticateHeader) {
/*  71 */     Matcher m = pattern.matcher(authenticateHeader);
/*  72 */     Map<String, String> parameterMap = new HashMap<>();
/*     */     
/*  74 */     while (m.find()) {
/*  75 */       String key = m.group(1);
/*  76 */       String qtedValue = m.group(3);
/*  77 */       String value = m.group(4);
/*     */       
/*  79 */       parameterMap.put(key, (qtedValue != null) ? qtedValue : value);
/*     */     } 
/*     */ 
/*     */     
/*  83 */     return parameterMap;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateUsername(String userName) throws AuthenticationException {
/*  88 */     if (userName == null) {
/*  89 */       throw new AuthenticationException(sm.getString("authenticator.nullUserName"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validatePassword(String password) throws AuthenticationException {
/*  95 */     if (password == null) {
/*  96 */       throw new AuthenticationException(sm.getString("authenticator.nullPassword"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateRealm(String userRealm, String serverRealm) throws AuthenticationException {
/* 102 */     if (userRealm == null) {
/*     */       return;
/*     */     }
/*     */     
/* 106 */     userRealm = userRealm.trim();
/* 107 */     if (userRealm.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (serverRealm != null) {
/* 116 */       serverRealm = serverRealm.trim();
/* 117 */       if (userRealm.equals(serverRealm)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 122 */     throw new AuthenticationException(sm.getString("authenticator.realmMismatch", new Object[] { userRealm, serverRealm }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\Authenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */