/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.SendHandler;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessagePart
/*    */ {
/*    */   private final boolean fin;
/*    */   private final int rsv;
/*    */   private final byte opCode;
/*    */   private final ByteBuffer payload;
/*    */   private final SendHandler intermediateHandler;
/*    */   private volatile SendHandler endHandler;
/*    */   private final long blockingWriteTimeoutExpiry;
/*    */   
/*    */   MessagePart(boolean fin, int rsv, byte opCode, ByteBuffer payload, SendHandler intermediateHandler, SendHandler endHandler, long blockingWriteTimeoutExpiry) {
/* 34 */     this.fin = fin;
/* 35 */     this.rsv = rsv;
/* 36 */     this.opCode = opCode;
/* 37 */     this.payload = payload;
/* 38 */     this.intermediateHandler = intermediateHandler;
/* 39 */     this.endHandler = endHandler;
/* 40 */     this.blockingWriteTimeoutExpiry = blockingWriteTimeoutExpiry;
/*    */   }
/*    */   
/*    */   public boolean isFin() {
/* 44 */     return this.fin;
/*    */   }
/*    */   
/*    */   public int getRsv() {
/* 48 */     return this.rsv;
/*    */   }
/*    */   
/*    */   public byte getOpCode() {
/* 52 */     return this.opCode;
/*    */   }
/*    */   
/*    */   public ByteBuffer getPayload() {
/* 56 */     return this.payload;
/*    */   }
/*    */   
/*    */   public SendHandler getIntermediateHandler() {
/* 60 */     return this.intermediateHandler;
/*    */   }
/*    */   
/*    */   public SendHandler getEndHandler() {
/* 64 */     return this.endHandler;
/*    */   }
/*    */   
/*    */   public void setEndHandler(SendHandler endHandler) {
/* 68 */     this.endHandler = endHandler;
/*    */   }
/*    */   
/*    */   public long getBlockingWriteTimeoutExpiry() {
/* 72 */     return this.blockingWriteTimeoutExpiry;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\MessagePart.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */