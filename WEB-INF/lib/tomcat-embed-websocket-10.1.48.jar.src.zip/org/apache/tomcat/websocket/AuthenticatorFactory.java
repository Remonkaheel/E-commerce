/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorFactory
/*    */ {
/*    */   public static Authenticator getAuthenticator(String authScheme) {
/* 36 */     Authenticator auth = null;
/* 37 */     switch (authScheme.toLowerCase(Locale.ENGLISH))
/*    */     
/*    */     { case "basic":
/* 40 */         auth = new BasicAuthenticator();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 52 */         return auth;case "digest": auth = new DigestAuthenticator(); return auth; }  auth = loadAuthenticators(authScheme); return auth;
/*    */   }
/*    */ 
/*    */   
/*    */   private static Authenticator loadAuthenticators(String authScheme) {
/* 57 */     ServiceLoader<Authenticator> serviceLoader = ServiceLoader.load(Authenticator.class);
/*    */     
/* 59 */     for (Authenticator auth : serviceLoader) {
/* 60 */       if (auth.getSchemeName().equalsIgnoreCase(authScheme)) {
/* 61 */         return auth;
/*    */       }
/*    */     } 
/*    */     
/* 65 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\AuthenticatorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */