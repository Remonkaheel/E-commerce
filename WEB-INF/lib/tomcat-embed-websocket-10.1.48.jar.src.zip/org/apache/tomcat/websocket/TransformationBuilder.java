package org.apache.tomcat.websocket;

import jakarta.websocket.Extension;
import java.util.List;

public interface TransformationBuilder {
  Transformation build(List<List<Extension.Parameter>> paramList, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\TransformationBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */