/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import jakarta.websocket.CloseReason;
/*     */ import jakarta.websocket.Decoder;
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import jakarta.websocket.Encoder;
/*     */ import jakarta.websocket.EndpointConfig;
/*     */ import jakarta.websocket.Extension;
/*     */ import jakarta.websocket.MessageHandler;
/*     */ import jakarta.websocket.PongMessage;
/*     */ import jakarta.websocket.Session;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerPartialBinary;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerWholeBinary;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerWholeText;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*  64 */   private static final StringManager sm = StringManager.getManager(Util.class);
/*  65 */   private static final Queue<SecureRandom> randoms = new ConcurrentLinkedQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isControl(byte opCode) {
/*  73 */     return ((opCode & 0x8) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isText(byte opCode) {
/*  78 */     return (opCode == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isContinuation(byte opCode) {
/*  83 */     return (opCode == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   static CloseReason.CloseCode getCloseCode(int code) {
/*  88 */     if (code > 2999 && code < 5000) {
/*  89 */       return CloseReason.CloseCodes.getCloseCode(code);
/*     */     }
/*  91 */     switch (code) {
/*     */       case 1000:
/*  93 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.NORMAL_CLOSURE;
/*     */       case 1001:
/*  95 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.GOING_AWAY;
/*     */       case 1002:
/*  97 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */       case 1003:
/*  99 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.CANNOT_ACCEPT;
/*     */ 
/*     */       
/*     */       case 1004:
/* 103 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */ 
/*     */       
/*     */       case 1005:
/* 107 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */ 
/*     */       
/*     */       case 1006:
/* 111 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */       case 1007:
/* 113 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.NOT_CONSISTENT;
/*     */       case 1008:
/* 115 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.VIOLATED_POLICY;
/*     */       case 1009:
/* 117 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.TOO_BIG;
/*     */       case 1010:
/* 119 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.NO_EXTENSION;
/*     */       case 1011:
/* 121 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.UNEXPECTED_CONDITION;
/*     */ 
/*     */       
/*     */       case 1012:
/* 125 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */ 
/*     */       
/*     */       case 1013:
/* 129 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */ 
/*     */       
/*     */       case 1015:
/* 133 */         return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     } 
/* 135 */     return (CloseReason.CloseCode)CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] generateMask() {
/* 147 */     SecureRandom sr = randoms.poll();
/*     */ 
/*     */     
/* 150 */     if (sr == null) {
/*     */       try {
/* 152 */         sr = SecureRandom.getInstance("SHA1PRNG");
/* 153 */       } catch (NoSuchAlgorithmException e) {
/*     */         
/* 155 */         sr = new SecureRandom();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 160 */     byte[] result = new byte[4];
/* 161 */     sr.nextBytes(result);
/*     */ 
/*     */     
/* 164 */     randoms.add(sr);
/*     */     
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static Class<?> getMessageType(MessageHandler listener) {
/* 171 */     return getGenericType(MessageHandler.class, listener.getClass()).getClazz();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<?> getDecoderType(Class<? extends Decoder> decoder) {
/* 176 */     return getGenericType(Decoder.class, decoder).getClazz();
/*     */   }
/*     */ 
/*     */   
/*     */   static Class<?> getEncoderType(Class<? extends Encoder> encoder) {
/* 181 */     return getGenericType(Encoder.class, encoder).getClazz();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> TypeResult getGenericType(Class<T> type, Class<? extends T> clazz) {
/* 190 */     Type[] interfaces = clazz.getGenericInterfaces();
/* 191 */     for (Type iface : interfaces) {
/*     */       
/* 193 */       if (iface instanceof ParameterizedType) {
/* 194 */         ParameterizedType pi = (ParameterizedType)iface;
/*     */         
/* 196 */         if (pi.getRawType() instanceof Class && 
/* 197 */           type.isAssignableFrom((Class)pi.getRawType())) {
/* 198 */           return getTypeParameter(clazz, pi.getActualTypeArguments()[0]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     Class<? extends T> superClazz = (Class)clazz.getSuperclass();
/* 207 */     if (superClazz == null)
/*     */     {
/* 209 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 212 */     TypeResult superClassTypeResult = getGenericType(type, superClazz);
/* 213 */     int dimension = superClassTypeResult.getDimension();
/* 214 */     if (superClassTypeResult.getIndex() == -1 && dimension == 0)
/*     */     {
/*     */       
/* 217 */       return superClassTypeResult;
/*     */     }
/*     */     
/* 220 */     if (superClassTypeResult.getIndex() > -1) {
/*     */ 
/*     */ 
/*     */       
/* 224 */       ParameterizedType superClassType = (ParameterizedType)clazz.getGenericSuperclass();
/*     */       
/* 226 */       TypeResult result = getTypeParameter(clazz, superClassType.getActualTypeArguments()[superClassTypeResult.getIndex()]);
/* 227 */       result.incrementDimension(superClassTypeResult.getDimension());
/* 228 */       if (result.getClazz() != null && result.getDimension() > 0) {
/* 229 */         superClassTypeResult = result;
/*     */       } else {
/* 231 */         return result;
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     if (superClassTypeResult.getDimension() > 0) {
/* 236 */       Class<?> arrayClazz; StringBuilder className = new StringBuilder();
/* 237 */       className.append("[".repeat(Math.max(0, dimension)));
/* 238 */       className.append('L');
/* 239 */       className.append(superClassTypeResult.getClazz().getCanonicalName());
/* 240 */       className.append(';');
/*     */ 
/*     */       
/*     */       try {
/* 244 */         arrayClazz = Class.forName(className.toString());
/* 245 */       } catch (ClassNotFoundException e) {
/* 246 */         throw new IllegalArgumentException(e);
/*     */       } 
/*     */       
/* 249 */       return new TypeResult(arrayClazz, -1, 0);
/*     */     } 
/*     */ 
/*     */     
/* 253 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypeResult getTypeParameter(Class<?> clazz, Type argType) {
/* 262 */     if (argType instanceof Class)
/* 263 */       return new TypeResult((Class)argType, -1, 0); 
/* 264 */     if (argType instanceof ParameterizedType)
/* 265 */       return new TypeResult((Class)((ParameterizedType)argType).getRawType(), -1, 0); 
/* 266 */     if (argType instanceof GenericArrayType) {
/* 267 */       Type arrayElementType = ((GenericArrayType)argType).getGenericComponentType();
/* 268 */       TypeResult result = getTypeParameter(clazz, arrayElementType);
/* 269 */       result.incrementDimension(1);
/* 270 */       return result;
/*     */     } 
/* 272 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])clazz.getTypeParameters();
/* 273 */     for (int i = 0; i < arrayOfTypeVariable.length; i++) {
/* 274 */       if (arrayOfTypeVariable[i].equals(argType)) {
/* 275 */         return new TypeResult(null, i, 0);
/*     */       }
/*     */     } 
/* 278 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrimitive(Class<?> clazz) {
/* 284 */     if (clazz.isPrimitive()) {
/* 285 */       return true;
/*     */     }
/* 287 */     return (clazz.equals(Boolean.class) || clazz.equals(Byte.class) || clazz.equals(Character.class) || clazz
/* 288 */       .equals(Double.class) || clazz.equals(Float.class) || clazz.equals(Integer.class) || clazz
/* 289 */       .equals(Long.class) || clazz.equals(Short.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object coerceToType(Class<?> type, String value) {
/* 295 */     if (type.equals(String.class))
/* 296 */       return value; 
/* 297 */     if (type.equals(boolean.class) || type.equals(Boolean.class))
/* 298 */       return Boolean.valueOf(value); 
/* 299 */     if (type.equals(byte.class) || type.equals(Byte.class))
/* 300 */       return Byte.valueOf(value); 
/* 301 */     if (type.equals(char.class) || type.equals(Character.class))
/* 302 */       return Character.valueOf(value.charAt(0)); 
/* 303 */     if (type.equals(double.class) || type.equals(Double.class))
/* 304 */       return Double.valueOf(value); 
/* 305 */     if (type.equals(float.class) || type.equals(Float.class))
/* 306 */       return Float.valueOf(value); 
/* 307 */     if (type.equals(int.class) || type.equals(Integer.class))
/* 308 */       return Integer.valueOf(value); 
/* 309 */     if (type.equals(long.class) || type.equals(Long.class))
/* 310 */       return Long.valueOf(value); 
/* 311 */     if (type.equals(short.class) || type.equals(Short.class)) {
/* 312 */       return Short.valueOf(value);
/*     */     }
/* 314 */     throw new IllegalArgumentException(sm.getString("util.invalidType", new Object[] { value, type.getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<DecoderEntry> getDecoders(List<Class<? extends Decoder>> decoderClazzes, InstanceManager instanceManager) throws DeploymentException {
/* 332 */     List<DecoderEntry> result = new ArrayList<>();
/* 333 */     if (decoderClazzes != null) {
/* 334 */       for (Class<? extends Decoder> decoderClazz : decoderClazzes) {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/* 339 */           if (instanceManager == null) {
/* 340 */             Decoder instance = decoderClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */           } else {
/* 342 */             Decoder instance = (Decoder)instanceManager.newInstance(decoderClazz);
/*     */             
/* 344 */             instanceManager.destroyInstance(instance);
/*     */           } 
/* 346 */         } catch (ReflectiveOperationException|IllegalArgumentException|SecurityException|javax.naming.NamingException e) {
/*     */           
/* 348 */           throw new DeploymentException(sm
/* 349 */               .getString("pojoMethodMapping.invalidDecoder", new Object[] { decoderClazz.getName() }), e);
/*     */         } 
/* 351 */         DecoderEntry entry = new DecoderEntry(getDecoderType(decoderClazz), decoderClazz);
/* 352 */         result.add(entry);
/*     */       } 
/*     */     }
/*     */     
/* 356 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Set<MessageHandlerResult> getMessageHandlers(Class<?> target, MessageHandler listener, EndpointConfig endpointConfig, Session session) {
/* 364 */     Set<MessageHandlerResult> results = new HashSet<>(2);
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (String.class.isAssignableFrom(target)) {
/* 369 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.TEXT);
/* 370 */       results.add(result);
/* 371 */     } else if (ByteBuffer.class.isAssignableFrom(target)) {
/* 372 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.BINARY);
/* 373 */       results.add(result);
/* 374 */     } else if (PongMessage.class.isAssignableFrom(target)) {
/* 375 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.PONG);
/* 376 */       results.add(result);
/*     */     
/*     */     }
/* 379 */     else if (byte[].class.isAssignableFrom(target)) {
/* 380 */       boolean whole = MessageHandler.Whole.class.isAssignableFrom(listener.getClass());
/*     */       
/* 382 */       if (whole) {
/*     */       
/*     */       } else {
/*     */       
/*     */       } 
/*     */       
/* 388 */       MessageHandlerResult result = new MessageHandlerResult((MessageHandler)new PojoMessageHandlerPartialBinary(listener, getOnMessagePartialMethod(listener), session, new Object[2], 0, true, 1, -1, -1L), MessageHandlerResultType.BINARY);
/*     */ 
/*     */       
/* 391 */       results.add(result);
/* 392 */     } else if (InputStream.class.isAssignableFrom(target)) {
/*     */ 
/*     */       
/* 395 */       MessageHandlerResult result = new MessageHandlerResult((MessageHandler)new PojoMessageHandlerWholeBinary(listener, getOnMessageMethod(listener), session, endpointConfig, matchDecoders(target, endpointConfig, true, ((WsSession)session).getInstanceManager()), new Object[1], 0, true, -1, true, -1L), MessageHandlerResultType.BINARY);
/*     */ 
/*     */       
/* 398 */       results.add(result);
/* 399 */     } else if (Reader.class.isAssignableFrom(target)) {
/*     */ 
/*     */       
/* 402 */       MessageHandlerResult result = new MessageHandlerResult((MessageHandler)new PojoMessageHandlerWholeText(listener, getOnMessageMethod(listener), session, endpointConfig, matchDecoders(target, endpointConfig, false, ((WsSession)session).getInstanceManager()), new Object[1], 0, true, -1, -1L), MessageHandlerResultType.TEXT);
/*     */ 
/*     */       
/* 405 */       results.add(result);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 410 */       DecoderMatch decoderMatch = matchDecoders(target, endpointConfig, ((WsSession)session).getInstanceManager());
/* 411 */       Method m = getOnMessageMethod(listener);
/* 412 */       if (!decoderMatch.getBinaryDecoders().isEmpty()) {
/*     */ 
/*     */         
/* 415 */         MessageHandlerResult result = new MessageHandlerResult((MessageHandler)new PojoMessageHandlerWholeBinary(listener, m, session, endpointConfig, decoderMatch.getBinaryDecoders(), new Object[1], 0, false, -1, false, -1L), MessageHandlerResultType.BINARY);
/*     */         
/* 417 */         results.add(result);
/*     */       } 
/* 419 */       if (!decoderMatch.getTextDecoders().isEmpty()) {
/*     */ 
/*     */         
/* 422 */         MessageHandlerResult result = new MessageHandlerResult((MessageHandler)new PojoMessageHandlerWholeText(listener, m, session, endpointConfig, decoderMatch.getTextDecoders(), new Object[1], 0, false, -1, -1L), MessageHandlerResultType.TEXT);
/*     */         
/* 424 */         results.add(result);
/*     */       } 
/*     */     } 
/*     */     
/* 428 */     if (results.isEmpty()) {
/* 429 */       throw new IllegalArgumentException(sm.getString("wsSession.unknownHandler", new Object[] { listener, target }));
/*     */     }
/*     */     
/* 432 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<Class<? extends Decoder>> matchDecoders(Class<?> target, EndpointConfig endpointConfig, boolean binary, InstanceManager instanceManager) {
/* 437 */     DecoderMatch decoderMatch = matchDecoders(target, endpointConfig, instanceManager);
/* 438 */     if (binary) {
/* 439 */       if (!decoderMatch.getBinaryDecoders().isEmpty()) {
/* 440 */         return decoderMatch.getBinaryDecoders();
/*     */       }
/* 442 */     } else if (!decoderMatch.getTextDecoders().isEmpty()) {
/* 443 */       return decoderMatch.getTextDecoders();
/*     */     } 
/* 445 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static DecoderMatch matchDecoders(Class<?> target, EndpointConfig endpointConfig, InstanceManager instanceManager) {
/*     */     DecoderMatch decoderMatch;
/*     */     try {
/* 452 */       List<Class<? extends Decoder>> decoders = endpointConfig.getDecoders();
/* 453 */       List<DecoderEntry> decoderEntries = getDecoders(decoders, instanceManager);
/* 454 */       decoderMatch = new DecoderMatch(target, decoderEntries);
/* 455 */     } catch (DeploymentException e) {
/* 456 */       throw new IllegalArgumentException(e);
/*     */     } 
/* 458 */     return decoderMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseExtensionHeader(List<Extension> extensions, String header) {
/* 478 */     String[] unparsedExtensions = header.split(",");
/* 479 */     for (String unparsedExtension : unparsedExtensions) {
/*     */ 
/*     */       
/* 482 */       String[] unparsedParameters = unparsedExtension.split(";");
/* 483 */       WsExtension extension = new WsExtension(unparsedParameters[0].trim());
/*     */       
/* 485 */       for (int i = 1; i < unparsedParameters.length; i++) {
/* 486 */         String name, value; int equalsPos = unparsedParameters[i].indexOf('=');
/*     */ 
/*     */         
/* 489 */         if (equalsPos == -1) {
/* 490 */           name = unparsedParameters[i].trim();
/* 491 */           value = null;
/*     */         } else {
/* 493 */           name = unparsedParameters[i].substring(0, equalsPos).trim();
/* 494 */           value = unparsedParameters[i].substring(equalsPos + 1).trim();
/* 495 */           int len = value.length();
/* 496 */           if (len > 1 && 
/* 497 */             value.charAt(0) == '"' && value.charAt(len - 1) == '"') {
/* 498 */             value = value.substring(1, value.length() - 1);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 504 */         if (containsDelims(name) || containsDelims(value)) {
/* 505 */           throw new IllegalArgumentException(sm.getString("util.notToken", new Object[] { name, value }));
/*     */         }
/* 507 */         if (value != null && (value.indexOf(',') > -1 || value.indexOf(';') > -1 || value.indexOf('"') > -1 || value
/* 508 */           .indexOf('=') > -1)) {
/* 509 */           throw new IllegalArgumentException(sm.getString("util.invalidValue", new Object[] { value }));
/*     */         }
/* 511 */         extension.addParameter(new WsExtensionParameter(name, value));
/*     */       } 
/* 513 */       extensions.add(extension);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean containsDelims(String input) {
/* 519 */     if (input == null || input.isEmpty()) {
/* 520 */       return false;
/*     */     }
/* 522 */     for (char c : input.toCharArray()) {
/* 523 */       switch (c) {
/*     */         case '"':
/*     */         case ',':
/*     */         case ';':
/*     */         case '=':
/* 528 */           return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 534 */     return false;
/*     */   }
/*     */   
/*     */   private static Method getOnMessageMethod(MessageHandler listener) {
/*     */     try {
/* 539 */       return listener.getClass().getMethod("onMessage", new Class[] { Object.class });
/* 540 */     } catch (NoSuchMethodException|SecurityException e) {
/* 541 */       throw new IllegalArgumentException(sm.getString("util.invalidMessageHandler"), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method getOnMessagePartialMethod(MessageHandler listener) {
/*     */     try {
/* 547 */       return listener.getClass().getMethod("onMessage", new Class[] { Object.class, boolean.class });
/* 548 */     } catch (NoSuchMethodException|SecurityException e) {
/* 549 */       throw new IllegalArgumentException(sm.getString("util.invalidMessageHandler"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class DecoderMatch
/*     */   {
/* 556 */     private final List<Class<? extends Decoder>> textDecoders = new ArrayList<>();
/* 557 */     private final List<Class<? extends Decoder>> binaryDecoders = new ArrayList<>();
/*     */     private final Class<?> target;
/*     */     
/*     */     public DecoderMatch(Class<?> target, List<DecoderEntry> decoderEntries) {
/* 561 */       this.target = target;
/* 562 */       for (DecoderEntry decoderEntry : decoderEntries) {
/* 563 */         if (decoderEntry.getClazz().isAssignableFrom(target)) {
/* 564 */           if (Decoder.Binary.class.isAssignableFrom(decoderEntry.getDecoderClazz())) {
/* 565 */             this.binaryDecoders.add(decoderEntry.getDecoderClazz());
/*     */             
/*     */             continue;
/*     */           } 
/* 569 */           if (Decoder.BinaryStream.class.isAssignableFrom(decoderEntry.getDecoderClazz())) {
/* 570 */             this.binaryDecoders.add(decoderEntry.getDecoderClazz());
/*     */             
/*     */             break;
/*     */           } 
/* 574 */           if (Decoder.Text.class.isAssignableFrom(decoderEntry.getDecoderClazz())) {
/* 575 */             this.textDecoders.add(decoderEntry.getDecoderClazz());
/*     */             
/*     */             continue;
/*     */           } 
/* 579 */           if (Decoder.TextStream.class.isAssignableFrom(decoderEntry.getDecoderClazz())) {
/* 580 */             this.textDecoders.add(decoderEntry.getDecoderClazz());
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 585 */           throw new IllegalArgumentException(Util.sm.getString("util.unknownDecoderType"));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Class<? extends Decoder>> getTextDecoders() {
/* 593 */       return this.textDecoders;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Class<? extends Decoder>> getBinaryDecoders() {
/* 598 */       return this.binaryDecoders;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getTarget() {
/* 603 */       return this.target;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasMatches() {
/* 608 */       return (!this.textDecoders.isEmpty() || !this.binaryDecoders.isEmpty());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypeResult
/*     */   {
/*     */     private final Class<?> clazz;
/*     */     private final int index;
/*     */     private int dimension;
/*     */     
/*     */     TypeResult(Class<?> clazz, int index, int dimension) {
/* 619 */       this.clazz = clazz;
/* 620 */       this.index = index;
/* 621 */       this.dimension = dimension;
/*     */     }
/*     */     
/*     */     public Class<?> getClazz() {
/* 625 */       return this.clazz;
/*     */     }
/*     */     
/*     */     public int getIndex() {
/* 629 */       return this.index;
/*     */     }
/*     */     
/*     */     public int getDimension() {
/* 633 */       return this.dimension;
/*     */     }
/*     */     
/*     */     public void incrementDimension(int inc) {
/* 637 */       this.dimension += inc;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\Util.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */