/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicAuthenticator
/*    */   extends Authenticator
/*    */ {
/*    */   public static final String schemeName = "basic";
/*    */   public static final String charsetparam = "charset";
/*    */   
/*    */   public String getAuthorization(String requestUri, String authenticateHeader, String userName, String userPassword, String userRealm) throws AuthenticationException {
/*    */     Charset charset;
/* 36 */     validateUsername(userName);
/* 37 */     validatePassword(userPassword);
/*    */     
/* 39 */     Map<String, String> parameterMap = parseAuthenticateHeader(authenticateHeader);
/* 40 */     String realm = parameterMap.get("realm");
/*    */     
/* 42 */     validateRealm(userRealm, realm);
/*    */     
/* 44 */     String userPass = userName + ":" + userName;
/*    */ 
/*    */     
/* 47 */     if (parameterMap.get("charset") != null && ((String)parameterMap.get("charset")).equalsIgnoreCase("UTF-8")) {
/* 48 */       charset = StandardCharsets.UTF_8;
/*    */     } else {
/* 50 */       charset = StandardCharsets.ISO_8859_1;
/*    */     } 
/*    */     
/* 53 */     String base64 = Base64.getEncoder().encodeToString(userPass.getBytes(charset));
/*    */     
/* 55 */     return " Basic " + base64;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSchemeName() {
/* 60 */     return "basic";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\BasicAuthenticator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */