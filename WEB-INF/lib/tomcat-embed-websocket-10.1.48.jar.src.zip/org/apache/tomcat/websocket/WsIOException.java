/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.CloseReason;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsIOException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final CloseReason closeReason;
/*    */   
/*    */   public WsIOException(CloseReason closeReason) {
/* 34 */     this.closeReason = closeReason;
/*    */   }
/*    */   
/*    */   public CloseReason getCloseReason() {
/* 38 */     return this.closeReason;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsIOException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */