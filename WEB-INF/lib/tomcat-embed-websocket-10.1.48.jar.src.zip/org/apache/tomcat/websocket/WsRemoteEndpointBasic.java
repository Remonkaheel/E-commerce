/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.EncodeException;
/*    */ import jakarta.websocket.RemoteEndpoint;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Writer;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsRemoteEndpointBasic
/*    */   extends WsRemoteEndpointBase
/*    */   implements RemoteEndpoint.Basic
/*    */ {
/*    */   WsRemoteEndpointBasic(WsRemoteEndpointImplBase base) {
/* 30 */     super(base);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendText(String text) throws IOException {
/* 36 */     this.base.sendString(text);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendBinary(ByteBuffer data) throws IOException {
/* 42 */     this.base.sendBytes(data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendText(String fragment, boolean isLast) throws IOException {
/* 48 */     this.base.sendPartialString(fragment, isLast);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendBinary(ByteBuffer partialByte, boolean isLast) throws IOException {
/* 54 */     this.base.sendPartialBytes(partialByte, isLast);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public OutputStream getSendStream() throws IOException {
/* 60 */     return this.base.getSendStream();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Writer getSendWriter() throws IOException {
/* 66 */     return this.base.getSendWriter();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendObject(Object o) throws IOException, EncodeException {
/* 72 */     this.base.sendObject(o);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsRemoteEndpointBasic.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */