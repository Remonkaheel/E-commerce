/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import jakarta.websocket.Endpoint;
/*     */ import jakarta.websocket.Extension;
/*     */ import jakarta.websocket.HandshakeResponse;
/*     */ import jakarta.websocket.server.ServerEndpointConfig;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Base64;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ import org.apache.tomcat.websocket.Constants;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.TransformationFactory;
/*     */ import org.apache.tomcat.websocket.Util;
/*     */ import org.apache.tomcat.websocket.WsHandshakeResponse;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMethodMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpgradeUtil
/*     */ {
/*  53 */   private static final StringManager sm = StringManager.getManager(UpgradeUtil.class.getPackage().getName());
/*  54 */   private static final byte[] WS_ACCEPT = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
/*  55 */     .getBytes(StandardCharsets.ISO_8859_1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWebSocketUpgradeRequest(ServletRequest request, ServletResponse response) {
/*  75 */     return (request instanceof HttpServletRequest && response instanceof HttpServletResponse && 
/*  76 */       headerContainsToken((HttpServletRequest)request, "Upgrade", "websocket") && "GET"
/*     */       
/*  78 */       .equals(((HttpServletRequest)request).getMethod()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void doUpgrade(WsServerContainer sc, HttpServletRequest req, HttpServletResponse resp, ServerEndpointConfig sec, Map<String, String> pathParams) throws ServletException, IOException {
/*     */     List<Extension> installedExtensions, negotiatedExtensionsPhase2;
/*  89 */     if (!headerContainsToken(req, "Connection", "upgrade")) {
/*  90 */       resp.sendError(400);
/*     */       return;
/*     */     } 
/*  93 */     if (!headerContainsToken(req, "Sec-WebSocket-Version", "13")) {
/*  94 */       resp.setStatus(426);
/*  95 */       resp.setHeader("Sec-WebSocket-Version", "13");
/*     */       return;
/*     */     } 
/*  98 */     String key = req.getHeader("Sec-WebSocket-Key");
/*  99 */     if (!validateKey(key)) {
/* 100 */       resp.sendError(400);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 106 */     String origin = req.getHeader("Origin");
/* 107 */     if (!sec.getConfigurator().checkOrigin(origin)) {
/* 108 */       resp.sendError(403);
/*     */       
/*     */       return;
/*     */     } 
/* 112 */     List<String> subProtocols = getTokensFromHeader(req, "Sec-WebSocket-Protocol");
/* 113 */     String subProtocol = sec.getConfigurator().getNegotiatedSubprotocol(sec.getSubprotocols(), subProtocols);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     List<Extension> extensionsRequested = new ArrayList<>();
/* 119 */     Enumeration<String> extHeaders = req.getHeaders("Sec-WebSocket-Extensions");
/* 120 */     while (extHeaders.hasMoreElements()) {
/* 121 */       Util.parseExtensionHeader(extensionsRequested, extHeaders.nextElement());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     if (sec.getExtensions().isEmpty()) {
/* 128 */       installedExtensions = Constants.INSTALLED_EXTENSIONS;
/*     */     } else {
/* 130 */       installedExtensions = new ArrayList<>();
/* 131 */       installedExtensions.addAll(sec.getExtensions());
/* 132 */       installedExtensions.addAll(Constants.INSTALLED_EXTENSIONS);
/*     */     } 
/*     */     
/* 135 */     List<Extension> negotiatedExtensionsPhase1 = sec.getConfigurator().getNegotiatedExtensions(installedExtensions, extensionsRequested);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     List<Transformation> transformations = createTransformations(negotiatedExtensionsPhase1);
/*     */ 
/*     */     
/* 144 */     if (transformations.isEmpty()) {
/* 145 */       negotiatedExtensionsPhase2 = Collections.emptyList();
/*     */     } else {
/* 147 */       negotiatedExtensionsPhase2 = new ArrayList<>(transformations.size());
/* 148 */       for (Transformation t : transformations) {
/* 149 */         negotiatedExtensionsPhase2.add(t.getExtensionResponse());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 154 */     Transformation transformation = null;
/* 155 */     StringBuilder responseHeaderExtensions = new StringBuilder();
/* 156 */     boolean first = true;
/* 157 */     for (Transformation t : transformations) {
/* 158 */       if (first) {
/* 159 */         first = false;
/*     */       } else {
/* 161 */         responseHeaderExtensions.append(',');
/*     */       } 
/* 163 */       append(responseHeaderExtensions, t.getExtensionResponse());
/* 164 */       if (transformation == null) {
/* 165 */         transformation = t; continue;
/*     */       } 
/* 167 */       transformation.setNext(t);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (transformation != null && !transformation.validateRsvBits(0)) {
/* 173 */       throw new ServletException(sm.getString("upgradeUtil.incompatibleRsv"));
/*     */     }
/*     */ 
/*     */     
/* 177 */     resp.setHeader("Upgrade", "websocket");
/* 178 */     resp.setHeader("Connection", "upgrade");
/* 179 */     resp.setHeader("Sec-WebSocket-Accept", getWebSocketAccept(key));
/* 180 */     if (subProtocol != null && !subProtocol.isEmpty())
/*     */     {
/* 182 */       resp.setHeader("Sec-WebSocket-Protocol", subProtocol);
/*     */     }
/* 184 */     if (!transformations.isEmpty()) {
/* 185 */       resp.setHeader("Sec-WebSocket-Extensions", responseHeaderExtensions.toString());
/*     */     }
/*     */ 
/*     */     
/* 189 */     if (!Endpoint.class.isAssignableFrom(sec.getEndpointClass()) && sec.getUserProperties()
/* 190 */       .get("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping") == null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 195 */         PojoMethodMapping methodMapping = new PojoMethodMapping(sec.getEndpointClass(), sec.getDecoders(), sec.getPath(), sc.getInstanceManager(Thread.currentThread().getContextClassLoader()));
/* 196 */         if (methodMapping.getOnClose() != null || methodMapping.getOnOpen() != null || methodMapping
/* 197 */           .getOnError() != null || methodMapping.hasMessageHandlers()) {
/* 198 */           sec.getUserProperties().put("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping", methodMapping);
/*     */         }
/*     */       }
/* 201 */       catch (DeploymentException e) {
/* 202 */         throw new ServletException(sm.getString("upgradeUtil.pojoMapFail", new Object[] { sec.getEndpointClass().getName() }), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 207 */     WsPerSessionServerEndpointConfig perSessionServerEndpointConfig = new WsPerSessionServerEndpointConfig(sec);
/*     */     
/* 209 */     WsHandshakeRequest wsRequest = new WsHandshakeRequest(req, pathParams);
/* 210 */     WsHandshakeResponse wsResponse = new WsHandshakeResponse();
/* 211 */     sec.getConfigurator().modifyHandshake(perSessionServerEndpointConfig, wsRequest, (HandshakeResponse)wsResponse);
/* 212 */     wsRequest.finished();
/*     */ 
/*     */     
/* 215 */     for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)wsResponse.getHeaders().entrySet()) {
/* 216 */       for (String headerValue : entry.getValue()) {
/* 217 */         resp.addHeader(entry.getKey(), headerValue);
/*     */       }
/*     */     } 
/*     */     
/* 221 */     WsHttpUpgradeHandler wsHandler = (WsHttpUpgradeHandler)req.upgrade(WsHttpUpgradeHandler.class);
/* 222 */     wsHandler.preInit(perSessionServerEndpointConfig, sc, wsRequest, negotiatedExtensionsPhase2, subProtocol, transformation, pathParams, req
/* 223 */         .isSecure());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean validateKey(String key) {
/* 233 */     if (key == null) {
/* 234 */       return false;
/*     */     }
/*     */     
/* 237 */     if (key.length() != 24) {
/* 238 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 242 */       byte[] decoded = Base64.getDecoder().decode(key);
/* 243 */       if (decoded.length != 16) {
/* 244 */         return false;
/*     */       }
/* 246 */     } catch (IllegalArgumentException iae) {
/* 247 */       return false;
/*     */     } 
/* 249 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Transformation> createTransformations(List<Extension> negotiatedExtensions) {
/* 255 */     TransformationFactory factory = TransformationFactory.getInstance();
/*     */     
/* 257 */     LinkedHashMap<String, List<List<Extension.Parameter>>> extensionPreferences = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 260 */     List<Transformation> result = new ArrayList<>(negotiatedExtensions.size());
/*     */     
/* 262 */     for (Extension extension : negotiatedExtensions) {
/* 263 */       ((List<List>)extensionPreferences.computeIfAbsent(extension.getName(), k -> new ArrayList()))
/* 264 */         .add(extension.getParameters());
/*     */     }
/*     */     
/* 267 */     for (Map.Entry<String, List<List<Extension.Parameter>>> entry : extensionPreferences.entrySet()) {
/* 268 */       Transformation transformation = factory.create(entry.getKey(), entry.getValue(), true);
/* 269 */       if (transformation != null) {
/* 270 */         result.add(transformation);
/*     */       }
/*     */     } 
/* 273 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void append(StringBuilder sb, Extension extension) {
/* 278 */     if (extension == null || extension.getName() == null || extension.getName().isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 282 */     sb.append(extension.getName());
/*     */     
/* 284 */     for (Extension.Parameter p : extension.getParameters()) {
/* 285 */       sb.append(';');
/* 286 */       sb.append(p.getName());
/* 287 */       if (p.getValue() != null) {
/* 288 */         sb.append('=');
/* 289 */         sb.append(p.getValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean headerContainsToken(HttpServletRequest req, String headerName, String target) {
/* 299 */     Enumeration<String> headers = req.getHeaders(headerName);
/* 300 */     while (headers.hasMoreElements()) {
/* 301 */       String header = headers.nextElement();
/* 302 */       String[] tokens = header.split(",");
/* 303 */       for (String token : tokens) {
/* 304 */         if (target.equalsIgnoreCase(token.trim())) {
/* 305 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 309 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> getTokensFromHeader(HttpServletRequest req, String headerName) {
/* 317 */     List<String> result = new ArrayList<>();
/* 318 */     Enumeration<String> headers = req.getHeaders(headerName);
/* 319 */     while (headers.hasMoreElements()) {
/* 320 */       String header = headers.nextElement();
/* 321 */       String[] tokens = header.split(",");
/* 322 */       for (String token : tokens) {
/* 323 */         result.add(token.trim());
/*     */       }
/*     */     } 
/* 326 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getWebSocketAccept(String key) {
/* 331 */     byte[] digest = ConcurrentMessageDigest.digestSHA1(new byte[][] { key.getBytes(StandardCharsets.ISO_8859_1), WS_ACCEPT });
/* 332 */     return Base64.getEncoder().encodeToString(digest);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\UpgradeUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */