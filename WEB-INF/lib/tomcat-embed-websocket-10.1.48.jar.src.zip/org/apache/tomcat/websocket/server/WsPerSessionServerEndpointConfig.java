/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import jakarta.websocket.Decoder;
/*    */ import jakarta.websocket.Encoder;
/*    */ import jakarta.websocket.Extension;
/*    */ import jakarta.websocket.server.ServerEndpointConfig;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WsPerSessionServerEndpointConfig
/*    */   implements ServerEndpointConfig
/*    */ {
/*    */   private final ServerEndpointConfig perEndpointConfig;
/* 36 */   private final Map<String, Object> perSessionUserProperties = new ConcurrentHashMap<>();
/*    */   
/*    */   WsPerSessionServerEndpointConfig(ServerEndpointConfig perEndpointConfig) {
/* 39 */     this.perEndpointConfig = perEndpointConfig;
/* 40 */     this.perSessionUserProperties.putAll(perEndpointConfig.getUserProperties());
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Class<? extends Encoder>> getEncoders() {
/* 45 */     return this.perEndpointConfig.getEncoders();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Class<? extends Decoder>> getDecoders() {
/* 50 */     return this.perEndpointConfig.getDecoders();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getUserProperties() {
/* 55 */     return this.perSessionUserProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getEndpointClass() {
/* 60 */     return this.perEndpointConfig.getEndpointClass();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 65 */     return this.perEndpointConfig.getPath();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getSubprotocols() {
/* 70 */     return this.perEndpointConfig.getSubprotocols();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Extension> getExtensions() {
/* 75 */     return this.perEndpointConfig.getExtensions();
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerEndpointConfig.Configurator getConfigurator() {
/* 80 */     return this.perEndpointConfig.getConfigurator();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsPerSessionServerEndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */