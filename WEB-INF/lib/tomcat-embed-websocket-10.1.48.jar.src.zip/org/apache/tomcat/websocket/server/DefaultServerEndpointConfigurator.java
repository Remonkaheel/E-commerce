/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import jakarta.websocket.Extension;
/*    */ import jakarta.websocket.HandshakeResponse;
/*    */ import jakarta.websocket.server.HandshakeRequest;
/*    */ import jakarta.websocket.server.ServerEndpointConfig;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ServerEndpointConfig.Configurator.class)
/*    */ public class DefaultServerEndpointConfigurator
/*    */   extends ServerEndpointConfig.Configurator
/*    */ {
/*    */   public <T> T getEndpointInstance(Class<T> clazz) throws InstantiationException {
/*    */     try {
/* 35 */       return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 36 */     } catch (InstantiationException e) {
/* 37 */       throw e;
/* 38 */     } catch (ReflectiveOperationException e) {
/* 39 */       InstantiationException ie = new InstantiationException();
/* 40 */       ie.initCause(e);
/* 41 */       throw ie;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getNegotiatedSubprotocol(List<String> supported, List<String> requested) {
/* 49 */     for (String request : requested) {
/* 50 */       if (supported.contains(request)) {
/* 51 */         return request;
/*    */       }
/*    */     } 
/* 54 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested) {
/* 60 */     Set<String> installedNames = new HashSet<>();
/* 61 */     for (Extension e : installed) {
/* 62 */       installedNames.add(e.getName());
/*    */     }
/* 64 */     List<Extension> result = new ArrayList<>();
/* 65 */     for (Extension request : requested) {
/* 66 */       if (installedNames.contains(request.getName())) {
/* 67 */         result.add(request);
/*    */       }
/*    */     } 
/* 70 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkOrigin(String originHeaderValue) {
/* 76 */     return true;
/*    */   }
/*    */   
/*    */   public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\DefaultServerEndpointConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */