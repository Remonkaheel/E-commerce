package org.apache.tomcat.websocket.server;

interface package-info {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */