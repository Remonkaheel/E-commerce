/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.GenericFilter;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsFilter
/*    */   extends GenericFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private transient WsServerContainer sc;
/*    */   
/*    */   public void init() throws ServletException {
/* 41 */     this.sc = (WsServerContainer)getServletContext().getAttribute("jakarta.websocket.server.ServerContainer");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*    */     String path;
/* 50 */     if (!this.sc.areEndpointsRegistered() || !UpgradeUtil.isWebSocketUpgradeRequest(request, response)) {
/* 51 */       chain.doFilter(request, response);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 56 */     HttpServletRequest req = (HttpServletRequest)request;
/* 57 */     HttpServletResponse resp = (HttpServletResponse)response;
/*    */ 
/*    */ 
/*    */     
/* 61 */     String pathInfo = req.getPathInfo();
/* 62 */     if (pathInfo == null) {
/* 63 */       path = req.getServletPath();
/*    */     } else {
/* 65 */       path = req.getServletPath() + req.getServletPath();
/*    */     } 
/* 67 */     WsMappingResult mappingResult = this.sc.findMapping(path);
/*    */     
/* 69 */     if (mappingResult == null) {
/*    */ 
/*    */       
/* 72 */       chain.doFilter(request, response);
/*    */       
/*    */       return;
/*    */     } 
/* 76 */     UpgradeUtil.doUpgrade(this.sc, req, resp, mappingResult.getConfig(), mappingResult.getPathParams());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */