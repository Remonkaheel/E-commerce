/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.coyote.http11.upgrade.UpgradeInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*     */ import org.apache.tomcat.util.net.SocketEvent;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsFrameBase;
/*     */ import org.apache.tomcat.websocket.WsIOException;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsFrameServer
/*     */   extends WsFrameBase
/*     */ {
/*  37 */   private final Log log = LogFactory.getLog(WsFrameServer.class);
/*  38 */   private static final StringManager sm = StringManager.getManager(WsFrameServer.class);
/*     */   
/*     */   private final SocketWrapperBase<?> socketWrapper;
/*     */   
/*     */   private final UpgradeInfo upgradeInfo;
/*     */   
/*     */   private final ClassLoader applicationClassLoader;
/*     */   
/*     */   public WsFrameServer(SocketWrapperBase<?> socketWrapper, UpgradeInfo upgradeInfo, WsSession wsSession, Transformation transformation, ClassLoader applicationClassLoader) {
/*  47 */     super(wsSession, transformation);
/*  48 */     this.socketWrapper = socketWrapper;
/*  49 */     this.upgradeInfo = upgradeInfo;
/*  50 */     this.applicationClassLoader = applicationClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onDataAvailable() throws IOException {
/*  60 */     if (this.log.isTraceEnabled()) {
/*  61 */       this.log.trace("wsFrameServer.onDataAvailable");
/*     */     }
/*  63 */     if (isOpen() && this.inputBuffer.hasRemaining() && !isSuspended())
/*     */     {
/*     */ 
/*     */       
/*  67 */       processInputBuffer();
/*     */     }
/*     */     
/*  70 */     while (isOpen() && !isSuspended()) {
/*     */       
/*  72 */       this.inputBuffer.mark();
/*  73 */       this.inputBuffer.position(this.inputBuffer.limit()).limit(this.inputBuffer.capacity());
/*  74 */       int read = this.socketWrapper.read(false, this.inputBuffer);
/*  75 */       this.inputBuffer.limit(this.inputBuffer.position()).reset();
/*     */       
/*  77 */       if (read < 0 || this.socketWrapper.isClosed())
/*  78 */         throw new EOFException(); 
/*  79 */       if (read == 0) {
/*     */         return;
/*     */       }
/*  82 */       if (this.log.isTraceEnabled()) {
/*  83 */         this.log.trace(sm.getString("wsFrameServer.bytesRead", new Object[] { Integer.toString(read) }));
/*     */       }
/*  85 */       processInputBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateStats(long payloadLength) {
/*  92 */     this.upgradeInfo.addMsgsReceived(1L);
/*  93 */     this.upgradeInfo.addBytesReceived(payloadLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMasked() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Transformation getTransformation() {
/* 107 */     return super.getTransformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOpen() {
/* 114 */     return super.isOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Log getLog() {
/* 120 */     return this.log;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendMessageText(boolean last) throws WsIOException {
/* 126 */     Thread currentThread = Thread.currentThread();
/* 127 */     ClassLoader cl = currentThread.getContextClassLoader();
/*     */     try {
/* 129 */       currentThread.setContextClassLoader(this.applicationClassLoader);
/* 130 */       super.sendMessageText(last);
/*     */     } finally {
/* 132 */       currentThread.setContextClassLoader(cl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendMessageBinary(ByteBuffer msg, boolean last) throws WsIOException {
/* 139 */     Thread currentThread = Thread.currentThread();
/* 140 */     ClassLoader cl = currentThread.getContextClassLoader();
/*     */     try {
/* 142 */       currentThread.setContextClassLoader(this.applicationClassLoader);
/* 143 */       super.sendMessageBinary(msg, last);
/*     */     } finally {
/* 145 */       currentThread.setContextClassLoader(cl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resumeProcessing() {
/* 152 */     this.socketWrapper.processSocket(SocketEvent.OPEN_READ, true);
/*     */   }
/*     */ 
/*     */   
/*     */   AbstractEndpoint.Handler.SocketState notifyDataAvailable() throws IOException {
/* 157 */     while (isOpen()) {
/* 158 */       switch (getReadState()) {
/*     */         case WAITING:
/* 160 */           if (!changeReadState(WsFrameBase.ReadState.WAITING, WsFrameBase.ReadState.PROCESSING)) {
/*     */             continue;
/*     */           }
/*     */           try {
/* 164 */             return doOnDataAvailable();
/* 165 */           } catch (IOException ioe) {
/* 166 */             changeReadState(WsFrameBase.ReadState.CLOSING);
/* 167 */             throw ioe;
/*     */           } 
/*     */         case SUSPENDING_WAIT:
/* 170 */           if (!changeReadState(WsFrameBase.ReadState.SUSPENDING_WAIT, WsFrameBase.ReadState.SUSPENDED)) {
/*     */             continue;
/*     */           }
/* 173 */           return AbstractEndpoint.Handler.SocketState.SUSPENDED;
/*     */       } 
/* 175 */       throw new IllegalStateException(sm.getString("wsFrameServer.illegalReadState", new Object[] { getReadState() }));
/*     */     } 
/*     */ 
/*     */     
/* 179 */     return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */   }
/*     */ 
/*     */   
/*     */   private AbstractEndpoint.Handler.SocketState doOnDataAvailable() throws IOException {
/* 184 */     onDataAvailable();
/* 185 */     while (isOpen()) {
/* 186 */       switch (getReadState()) {
/*     */         case PROCESSING:
/* 188 */           if (!changeReadState(WsFrameBase.ReadState.PROCESSING, WsFrameBase.ReadState.WAITING)) {
/*     */             continue;
/*     */           }
/* 191 */           return AbstractEndpoint.Handler.SocketState.UPGRADED;
/*     */         case SUSPENDING_PROCESS:
/* 193 */           if (!changeReadState(WsFrameBase.ReadState.SUSPENDING_PROCESS, WsFrameBase.ReadState.SUSPENDED)) {
/*     */             continue;
/*     */           }
/* 196 */           return AbstractEndpoint.Handler.SocketState.SUSPENDED;
/*     */       } 
/* 198 */       throw new IllegalStateException(sm.getString("wsFrameServer.illegalReadState", new Object[] { getReadState() }));
/*     */     } 
/*     */ 
/*     */     
/* 202 */     return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsFrameServer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */