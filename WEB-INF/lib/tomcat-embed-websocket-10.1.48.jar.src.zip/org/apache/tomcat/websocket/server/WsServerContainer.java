/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterRegistration;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.websocket.CloseReason;
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import jakarta.websocket.Encoder;
/*     */ import jakarta.websocket.server.ServerContainer;
/*     */ import jakarta.websocket.server.ServerEndpoint;
/*     */ import jakarta.websocket.server.ServerEndpointConfig;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentSkipListMap;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ import org.apache.tomcat.websocket.WsWebSocketContainer;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMethodMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsServerContainer
/*     */   extends WsWebSocketContainer
/*     */   implements ServerContainer
/*     */ {
/*  61 */   private static final StringManager sm = StringManager.getManager(WsServerContainer.class);
/*     */   
/*  63 */   private static final CloseReason AUTHENTICATED_HTTP_SESSION_CLOSED = new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.VIOLATED_POLICY, "This connection was established under an authenticated HTTP session that has ended.");
/*     */ 
/*     */   
/*  66 */   private final WsWriteTimeout wsWriteTimeout = new WsWriteTimeout();
/*     */   
/*     */   private final ServletContext servletContext;
/*  69 */   private final Map<String, ExactPathMatch> configExactMatchMap = new ConcurrentHashMap<>();
/*  70 */   private final Map<Integer, ConcurrentSkipListMap<String, TemplatePathMatch>> configTemplateMatchMap = new ConcurrentHashMap<>();
/*     */   
/*  72 */   private final Map<String, Set<WsSession>> authenticatedSessions = new ConcurrentHashMap<>();
/*     */   
/*     */   private volatile boolean endpointsRegistered = false;
/*     */   private volatile boolean deploymentFailed = false;
/*     */   
/*     */   WsServerContainer(ServletContext servletContext) {
/*  78 */     this.servletContext = servletContext;
/*  79 */     setInstanceManager((InstanceManager)servletContext.getAttribute(InstanceManager.class.getName()));
/*     */ 
/*     */     
/*  82 */     String value = servletContext.getInitParameter("org.apache.tomcat.websocket.binaryBufferSize");
/*  83 */     if (value != null) {
/*  84 */       setDefaultMaxBinaryMessageBufferSize(Integer.parseInt(value));
/*     */     }
/*     */     
/*  87 */     value = servletContext.getInitParameter("org.apache.tomcat.websocket.textBufferSize");
/*  88 */     if (value != null) {
/*  89 */       setDefaultMaxTextMessageBufferSize(Integer.parseInt(value));
/*     */     }
/*     */     
/*  92 */     FilterRegistration.Dynamic fr = servletContext.addFilter("Tomcat WebSocket (JSR356) Filter", (Filter)new WsFilter());
/*  93 */     if (fr != null) {
/*  94 */       fr.setAsyncSupported(true);
/*     */       
/*  96 */       EnumSet<DispatcherType> types = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
/*     */       
/*  98 */       fr.addMappingForUrlPatterns(types, true, new String[] { "/*" });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEndpoint(ServerEndpointConfig sec) throws DeploymentException {
/* 113 */     addEndpoint(sec, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void addEndpoint(ServerEndpointConfig sec, boolean fromAnnotatedPojo) throws DeploymentException {
/* 119 */     if (this.servletContext == null) {
/* 120 */       throw new DeploymentException(sm.getString("serverContainer.servletContextMissing"));
/*     */     }
/*     */     
/* 123 */     if (this.deploymentFailed) {
/* 124 */       throw new DeploymentException(sm.getString("serverContainer.failedDeployment", new Object[] { this.servletContext
/* 125 */               .getContextPath(), this.servletContext.getVirtualServerName() }));
/*     */     }
/*     */     
/*     */     try {
/* 129 */       String path = sec.getPath();
/*     */ 
/*     */ 
/*     */       
/* 133 */       PojoMethodMapping methodMapping = new PojoMethodMapping(sec.getEndpointClass(), sec.getDecoders(), path, getInstanceManager(Thread.currentThread().getContextClassLoader()));
/* 134 */       if (methodMapping.getOnClose() != null || methodMapping.getOnOpen() != null || methodMapping
/* 135 */         .getOnError() != null || methodMapping.hasMessageHandlers()) {
/* 136 */         sec.getUserProperties().put("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping", methodMapping);
/*     */       }
/*     */ 
/*     */       
/* 140 */       UriTemplate uriTemplate = new UriTemplate(path);
/* 141 */       if (uriTemplate.hasParameters()) {
/* 142 */         Integer key = Integer.valueOf(uriTemplate.getSegmentCount());
/* 143 */         ConcurrentSkipListMap<String, TemplatePathMatch> templateMatches = this.configTemplateMatchMap.get(key);
/* 144 */         if (templateMatches == null) {
/*     */ 
/*     */           
/* 147 */           templateMatches = new ConcurrentSkipListMap<>();
/* 148 */           this.configTemplateMatchMap.putIfAbsent(key, templateMatches);
/* 149 */           templateMatches = this.configTemplateMatchMap.get(key);
/*     */         } 
/* 151 */         TemplatePathMatch newMatch = new TemplatePathMatch(sec, uriTemplate, fromAnnotatedPojo);
/* 152 */         TemplatePathMatch oldMatch = templateMatches.putIfAbsent(uriTemplate.getNormalizedPath(), newMatch);
/* 153 */         if (oldMatch != null)
/*     */         {
/*     */           
/* 156 */           if (oldMatch.isFromAnnotatedPojo() && !newMatch.isFromAnnotatedPojo() && oldMatch
/* 157 */             .getConfig().getEndpointClass() == newMatch.getConfig().getEndpointClass()) {
/*     */             
/* 159 */             templateMatches.put(path, oldMatch);
/*     */           } else {
/*     */             
/* 162 */             throw new DeploymentException(sm.getString("serverContainer.duplicatePaths", new Object[] { path, sec
/* 163 */                     .getEndpointClass(), sec.getEndpointClass() }));
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 168 */         ExactPathMatch newMatch = new ExactPathMatch(sec, fromAnnotatedPojo);
/* 169 */         ExactPathMatch oldMatch = this.configExactMatchMap.put(path, newMatch);
/* 170 */         if (oldMatch != null)
/*     */         {
/*     */           
/* 173 */           if (oldMatch.isFromAnnotatedPojo() && !newMatch.isFromAnnotatedPojo() && oldMatch
/* 174 */             .getConfig().getEndpointClass() == newMatch.getConfig().getEndpointClass()) {
/*     */             
/* 176 */             this.configExactMatchMap.put(path, oldMatch);
/*     */           } else {
/*     */             
/* 179 */             throw new DeploymentException(sm.getString("serverContainer.duplicatePaths", new Object[] { path, oldMatch
/* 180 */                     .getConfig().getEndpointClass(), sec.getEndpointClass() }));
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 185 */       this.endpointsRegistered = true;
/* 186 */     } catch (DeploymentException de) {
/* 187 */       failDeployment();
/* 188 */       throw de;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEndpoint(Class<?> pojo) throws DeploymentException {
/* 201 */     addEndpoint(pojo, false);
/*     */   }
/*     */ 
/*     */   
/*     */   void addEndpoint(Class<?> pojo, boolean fromAnnotatedPojo) throws DeploymentException {
/*     */     ServerEndpointConfig sec;
/* 207 */     if (this.deploymentFailed) {
/* 208 */       throw new DeploymentException(sm.getString("serverContainer.failedDeployment", new Object[] { this.servletContext
/* 209 */               .getContextPath(), this.servletContext.getVirtualServerName() }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 215 */       ServerEndpoint annotation = pojo.<ServerEndpoint>getAnnotation(ServerEndpoint.class);
/* 216 */       if (annotation == null) {
/* 217 */         throw new DeploymentException(sm.getString("serverContainer.missingAnnotation", new Object[] { pojo.getName() }));
/*     */       }
/* 219 */       String path = annotation.value();
/*     */ 
/*     */       
/* 222 */       validateEncoders((Class<? extends Encoder>[])annotation.encoders(), getInstanceManager(Thread.currentThread().getContextClassLoader()));
/*     */ 
/*     */       
/* 225 */       Class<? extends ServerEndpointConfig.Configurator> configuratorClazz = annotation.configurator();
/* 226 */       ServerEndpointConfig.Configurator configurator = null;
/* 227 */       if (!configuratorClazz.equals(ServerEndpointConfig.Configurator.class)) {
/*     */         try {
/* 229 */           configurator = annotation.configurator().getConstructor(new Class[0]).newInstance(new Object[0]);
/* 230 */         } catch (ReflectiveOperationException e) {
/* 231 */           throw new DeploymentException(sm.getString("serverContainer.configuratorFail", new Object[] { annotation
/* 232 */                   .configurator().getName(), pojo.getName() }), e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 237 */       sec = ServerEndpointConfig.Builder.create(pojo, path).decoders(Arrays.asList((Class<?>[][])annotation.decoders())).encoders(Arrays.asList((Class<?>[][])annotation.encoders())).subprotocols(Arrays.asList(annotation.subprotocols())).configurator(configurator).build();
/* 238 */     } catch (DeploymentException de) {
/* 239 */       failDeployment();
/* 240 */       throw de;
/*     */     } 
/*     */     
/* 243 */     addEndpoint(sec, fromAnnotatedPojo);
/*     */   }
/*     */ 
/*     */   
/*     */   void failDeployment() {
/* 248 */     this.deploymentFailed = true;
/*     */ 
/*     */     
/* 251 */     this.endpointsRegistered = false;
/* 252 */     this.configExactMatchMap.clear();
/* 253 */     this.configTemplateMatchMap.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean areEndpointsRegistered() {
/* 258 */     return this.endpointsRegistered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void upgradeHttpToWebSocket(Object httpServletRequest, Object httpServletResponse, ServerEndpointConfig sec, Map<String, String> pathParameters) throws IOException, DeploymentException {
/*     */     try {
/* 266 */       UpgradeUtil.doUpgrade(this, (HttpServletRequest)httpServletRequest, (HttpServletResponse)httpServletResponse, sec, pathParameters);
/*     */     }
/* 268 */     catch (ServletException e) {
/* 269 */       throw new DeploymentException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WsMappingResult findMapping(String path) {
/*     */     UriTemplate pathUriTemplate;
/* 277 */     ExactPathMatch match = this.configExactMatchMap.get(path);
/* 278 */     if (match != null) {
/* 279 */       return new WsMappingResult(match.getConfig(), Collections.emptyMap());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 285 */       pathUriTemplate = new UriTemplate(path);
/* 286 */     } catch (DeploymentException e) {
/*     */       
/* 288 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 292 */     Integer key = Integer.valueOf(pathUriTemplate.getSegmentCount());
/* 293 */     ConcurrentSkipListMap<String, TemplatePathMatch> templateMatches = this.configTemplateMatchMap.get(key);
/*     */     
/* 295 */     if (templateMatches == null)
/*     */     {
/*     */       
/* 298 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 303 */     ServerEndpointConfig sec = null;
/* 304 */     Map<String, String> pathParams = null;
/* 305 */     for (TemplatePathMatch templateMatch : templateMatches.values()) {
/* 306 */       pathParams = templateMatch.getUriTemplate().match(pathUriTemplate);
/* 307 */       if (pathParams != null) {
/* 308 */         sec = templateMatch.getConfig();
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 313 */     if (sec == null)
/*     */     {
/* 315 */       return null;
/*     */     }
/*     */     
/* 318 */     return new WsMappingResult(sec, pathParams);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WsWriteTimeout getTimeout() {
/* 323 */     return this.wsWriteTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstanceManager getInstanceManager(ClassLoader classLoader) {
/* 332 */     return super.getInstanceManager(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerSession(Object key, WsSession wsSession) {
/* 341 */     super.registerSession(key, wsSession);
/* 342 */     if (wsSession.isOpen() && wsSession.getUserPrincipal() != null && wsSession.getHttpSessionId() != null) {
/* 343 */       registerAuthenticatedSession(wsSession, wsSession.getHttpSessionId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void unregisterSession(Object key, WsSession wsSession) {
/* 353 */     if (wsSession.getUserPrincipalInternal() != null && wsSession.getHttpSessionId() != null) {
/* 354 */       unregisterAuthenticatedSession(wsSession, wsSession.getHttpSessionId());
/*     */     }
/* 356 */     super.unregisterSession(key, wsSession);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerAuthenticatedSession(WsSession wsSession, String httpSessionId) {
/* 361 */     Set<WsSession> wsSessions = this.authenticatedSessions.get(httpSessionId);
/* 362 */     if (wsSessions == null) {
/* 363 */       wsSessions = ConcurrentHashMap.newKeySet();
/* 364 */       this.authenticatedSessions.putIfAbsent(httpSessionId, wsSessions);
/* 365 */       wsSessions = this.authenticatedSessions.get(httpSessionId);
/*     */     } 
/* 367 */     wsSessions.add(wsSession);
/*     */   }
/*     */ 
/*     */   
/*     */   private void unregisterAuthenticatedSession(WsSession wsSession, String httpSessionId) {
/* 372 */     Set<WsSession> wsSessions = this.authenticatedSessions.get(httpSessionId);
/*     */     
/* 374 */     if (wsSessions != null) {
/* 375 */       wsSessions.remove(wsSession);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeAuthenticatedSession(String httpSessionId) {
/* 381 */     Set<WsSession> wsSessions = this.authenticatedSessions.remove(httpSessionId);
/*     */     
/* 383 */     if (wsSessions != null && !wsSessions.isEmpty()) {
/* 384 */       for (WsSession wsSession : wsSessions) {
/*     */         try {
/* 386 */           wsSession.close(AUTHENTICATED_HTTP_SESSION_CLOSED);
/* 387 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateEncoders(Class<? extends Encoder>[] encoders, InstanceManager instanceManager) throws DeploymentException {
/* 399 */     for (Class<? extends Encoder> encoder : encoders) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 405 */         if (instanceManager == null) {
/* 406 */           Encoder instance = encoder.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */         } else {
/* 408 */           Encoder instance = (Encoder)instanceManager.newInstance(encoder);
/* 409 */           instanceManager.destroyInstance(instance);
/*     */         } 
/* 411 */       } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 412 */         throw new DeploymentException(sm.getString("serverContainer.encoderFail", new Object[] { encoder.getName() }), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class TemplatePathMatch
/*     */   {
/*     */     private final ServerEndpointConfig config;
/*     */     private final UriTemplate uriTemplate;
/*     */     private final boolean fromAnnotatedPojo;
/*     */     
/*     */     TemplatePathMatch(ServerEndpointConfig config, UriTemplate uriTemplate, boolean fromAnnotatedPojo) {
/* 424 */       this.config = config;
/* 425 */       this.uriTemplate = uriTemplate;
/* 426 */       this.fromAnnotatedPojo = fromAnnotatedPojo;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerEndpointConfig getConfig() {
/* 431 */       return this.config;
/*     */     }
/*     */ 
/*     */     
/*     */     public UriTemplate getUriTemplate() {
/* 436 */       return this.uriTemplate;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFromAnnotatedPojo() {
/* 441 */       return this.fromAnnotatedPojo;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ExactPathMatch
/*     */   {
/*     */     private final ServerEndpointConfig config;
/*     */     private final boolean fromAnnotatedPojo;
/*     */     
/*     */     ExactPathMatch(ServerEndpointConfig config, boolean fromAnnotatedPojo) {
/* 451 */       this.config = config;
/* 452 */       this.fromAnnotatedPojo = fromAnnotatedPojo;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerEndpointConfig getConfig() {
/* 457 */       return this.config;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFromAnnotatedPojo() {
/* 462 */       return this.fromAnnotatedPojo;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsServerContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */