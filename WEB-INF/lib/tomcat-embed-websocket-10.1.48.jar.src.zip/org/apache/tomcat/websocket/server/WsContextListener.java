/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import jakarta.servlet.ServletContextEvent;
/*    */ import jakarta.servlet.ServletContextListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsContextListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextInitialized(ServletContextEvent sce) {
/* 33 */     ServletContext sc = sce.getServletContext();
/*    */ 
/*    */     
/* 36 */     if (sc.getAttribute("jakarta.websocket.server.ServerContainer") == null) {
/* 37 */       WsSci.init(sce.getServletContext(), false);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 43 */     ServletContext sc = sce.getServletContext();
/* 44 */     Object obj = sc.getAttribute("jakarta.websocket.server.ServerContainer");
/* 45 */     if (obj instanceof WsServerContainer)
/* 46 */       ((WsServerContainer)obj).destroy(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */