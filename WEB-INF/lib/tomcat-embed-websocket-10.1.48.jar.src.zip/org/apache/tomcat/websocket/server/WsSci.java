/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.servlet.ServletContainerInitializer;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.annotation.HandlesTypes;
/*     */ import jakarta.websocket.ContainerProvider;
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import jakarta.websocket.Endpoint;
/*     */ import jakarta.websocket.server.ServerApplicationConfig;
/*     */ import jakarta.websocket.server.ServerEndpoint;
/*     */ import jakarta.websocket.server.ServerEndpointConfig;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @HandlesTypes({ServerEndpoint.class, ServerApplicationConfig.class, Endpoint.class})
/*     */ public class WsSci
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> clazzes, ServletContext ctx) throws ServletException {
/*  44 */     WsServerContainer sc = init(ctx, true);
/*     */     
/*  46 */     if (clazzes == null || clazzes.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  51 */     Set<ServerApplicationConfig> serverApplicationConfigs = new HashSet<>();
/*  52 */     Set<Class<? extends Endpoint>> scannedEndpointClazzes = new HashSet<>();
/*  53 */     Set<Class<?>> scannedPojoEndpoints = new HashSet<>();
/*     */ 
/*     */     
/*     */     try {
/*  57 */       String wsPackage = ContainerProvider.class.getName();
/*  58 */       wsPackage = wsPackage.substring(0, wsPackage.lastIndexOf('.') + 1);
/*  59 */       for (Class<?> clazz : clazzes) {
/*  60 */         int modifiers = clazz.getModifiers();
/*  61 */         if (!Modifier.isPublic(modifiers) || Modifier.isAbstract(modifiers) || 
/*  62 */           Modifier.isInterface(modifiers) || !isExported(clazz)) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  68 */         if (clazz.getName().startsWith(wsPackage)) {
/*     */           continue;
/*     */         }
/*  71 */         if (ServerApplicationConfig.class.isAssignableFrom(clazz)) {
/*  72 */           serverApplicationConfigs.add(clazz.getConstructor(new Class[0]).newInstance(new Object[0]));
/*     */         }
/*  74 */         if (Endpoint.class.isAssignableFrom(clazz)) {
/*     */           
/*  76 */           Class<? extends Endpoint> endpoint = (Class)clazz;
/*  77 */           scannedEndpointClazzes.add(endpoint);
/*     */         } 
/*  79 */         if (clazz.isAnnotationPresent((Class)ServerEndpoint.class)) {
/*  80 */           scannedPojoEndpoints.add(clazz);
/*     */         }
/*     */       } 
/*  83 */     } catch (ReflectiveOperationException e) {
/*  84 */       throw new ServletException(e);
/*     */     } 
/*     */ 
/*     */     
/*  88 */     Set<ServerEndpointConfig> filteredEndpointConfigs = new HashSet<>();
/*  89 */     Set<Class<?>> filteredPojoEndpoints = new HashSet<>();
/*     */     
/*  91 */     if (serverApplicationConfigs.isEmpty()) {
/*  92 */       filteredPojoEndpoints.addAll(scannedPojoEndpoints);
/*     */     } else {
/*  94 */       for (ServerApplicationConfig config : serverApplicationConfigs) {
/*  95 */         Set<ServerEndpointConfig> configFilteredEndpoints = config.getEndpointConfigs(scannedEndpointClazzes);
/*  96 */         if (configFilteredEndpoints != null) {
/*  97 */           filteredEndpointConfigs.addAll(configFilteredEndpoints);
/*     */         }
/*  99 */         Set<Class<?>> configFilteredPojos = config.getAnnotatedEndpointClasses(scannedPojoEndpoints);
/* 100 */         if (configFilteredPojos != null) {
/* 101 */           filteredPojoEndpoints.addAll(configFilteredPojos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 108 */       for (ServerEndpointConfig config : filteredEndpointConfigs) {
/* 109 */         sc.addEndpoint(config);
/*     */       }
/*     */       
/* 112 */       for (Class<?> clazz : filteredPojoEndpoints) {
/* 113 */         sc.addEndpoint(clazz, true);
/*     */       }
/* 115 */     } catch (DeploymentException e) {
/* 116 */       throw new ServletException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isExported(Class<?> type) {
/* 122 */     String packageName = type.getPackage().getName();
/* 123 */     Module module = type.getModule();
/* 124 */     return module.isExported(packageName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static WsServerContainer init(ServletContext servletContext, boolean initBySciMechanism) {
/* 130 */     WsServerContainer sc = new WsServerContainer(servletContext);
/*     */     
/* 132 */     servletContext.setAttribute("jakarta.websocket.server.ServerContainer", sc);
/*     */     
/* 134 */     servletContext.addListener((EventListener)new WsSessionListener(sc));
/*     */ 
/*     */     
/* 137 */     if (initBySciMechanism) {
/* 138 */       servletContext.addListener((EventListener)new WsContextListener());
/*     */     }
/*     */     
/* 141 */     return sc;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsSci.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */