/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.websocket.server.HandshakeRequest;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsHandshakeRequest
/*     */   implements HandshakeRequest
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager(WsHandshakeRequest.class);
/*     */   
/*     */   private final URI requestUri;
/*     */   
/*     */   private final Map<String, List<String>> parameterMap;
/*     */   
/*     */   private final String queryString;
/*     */   
/*     */   private final Principal userPrincipal;
/*     */   private final Map<String, List<String>> headers;
/*     */   private final Object httpSession;
/*     */   private volatile HttpServletRequest request;
/*     */   
/*     */   public WsHandshakeRequest(HttpServletRequest request, Map<String, String> pathParams) {
/*  55 */     this.request = request;
/*     */     
/*  57 */     this.queryString = request.getQueryString();
/*  58 */     this.userPrincipal = request.getUserPrincipal();
/*  59 */     this.httpSession = request.getSession(false);
/*  60 */     this.requestUri = buildRequestUri(request);
/*     */ 
/*     */     
/*  63 */     Map<String, String[]> originalParameters = request.getParameterMap();
/*  64 */     Map<String, List<String>> newParameters = new HashMap<>(originalParameters.size());
/*  65 */     for (Map.Entry<String, String[]> entry : originalParameters.entrySet()) {
/*  66 */       newParameters.put(entry.getKey(), Collections.unmodifiableList(Arrays.asList(entry.getValue())));
/*     */     }
/*  68 */     for (Map.Entry<String, String> entry : pathParams.entrySet()) {
/*  69 */       newParameters.put(entry.getKey(), Collections.singletonList(entry.getValue()));
/*     */     }
/*  71 */     this.parameterMap = Collections.unmodifiableMap(newParameters);
/*     */ 
/*     */     
/*  74 */     CaseInsensitiveKeyMap caseInsensitiveKeyMap = new CaseInsensitiveKeyMap();
/*     */     
/*  76 */     Enumeration<String> headerNames = request.getHeaderNames();
/*  77 */     while (headerNames.hasMoreElements()) {
/*  78 */       String headerName = headerNames.nextElement();
/*     */       
/*  80 */       caseInsensitiveKeyMap.put(headerName, Collections.unmodifiableList(Collections.list(request.getHeaders(headerName))));
/*     */     } 
/*     */     
/*  83 */     this.headers = Collections.unmodifiableMap((Map<? extends String, ? extends List<String>>)caseInsensitiveKeyMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getRequestURI() {
/*  88 */     return this.requestUri;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getParameterMap() {
/*  93 */     return this.parameterMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQueryString() {
/*  98 */     return this.queryString;
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal getUserPrincipal() {
/* 103 */     return this.userPrincipal;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getHeaders() {
/* 108 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserInRole(String role) {
/* 113 */     if (this.request == null) {
/* 114 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 117 */     return this.request.isUserInRole(role);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getHttpSession() {
/* 122 */     return this.httpSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void finished() {
/* 131 */     this.request = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URI buildRequestUri(HttpServletRequest req) {
/* 140 */     StringBuilder uri = new StringBuilder();
/* 141 */     String scheme = req.getScheme();
/* 142 */     int port = req.getServerPort();
/* 143 */     if (port < 0)
/*     */     {
/* 145 */       port = 80;
/*     */     }
/*     */     
/* 148 */     if ("http".equals(scheme)) {
/* 149 */       uri.append("ws");
/* 150 */     } else if ("https".equals(scheme)) {
/* 151 */       uri.append("wss");
/* 152 */     } else if ("wss".equals(scheme) || "ws".equals(scheme)) {
/* 153 */       uri.append(scheme);
/*     */     } else {
/*     */       
/* 156 */       throw new IllegalArgumentException(sm.getString("wsHandshakeRequest.unknownScheme", new Object[] { scheme }));
/*     */     } 
/*     */     
/* 159 */     uri.append("://");
/* 160 */     uri.append(req.getServerName());
/*     */     
/* 162 */     if ((scheme.equals("http") && port != 80) || (scheme.equals("ws") && port != 80) || (scheme
/* 163 */       .equals("wss") && port != 443) || (scheme.equals("https") && port != 443)) {
/* 164 */       uri.append(':');
/* 165 */       uri.append(port);
/*     */     } 
/*     */     
/* 168 */     uri.append(req.getRequestURI());
/*     */     
/* 170 */     if (req.getQueryString() != null) {
/* 171 */       uri.append('?');
/* 172 */       uri.append(req.getQueryString());
/*     */     } 
/*     */     
/*     */     try {
/* 176 */       return new URI(uri.toString());
/* 177 */     } catch (URISyntaxException e) {
/*     */       
/* 179 */       throw new IllegalArgumentException(sm.getString("wsHandshakeRequest.invalidUri", new Object[] { uri.toString() }), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsHandshakeRequest.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */