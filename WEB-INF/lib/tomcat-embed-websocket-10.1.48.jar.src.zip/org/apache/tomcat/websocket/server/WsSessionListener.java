/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import jakarta.servlet.http.HttpSessionEvent;
/*    */ import jakarta.servlet.http.HttpSessionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsSessionListener
/*    */   implements HttpSessionListener
/*    */ {
/*    */   private final WsServerContainer wsServerContainer;
/*    */   
/*    */   public WsSessionListener(WsServerContainer wsServerContainer) {
/* 28 */     this.wsServerContainer = wsServerContainer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionDestroyed(HttpSessionEvent se) {
/* 34 */     this.wsServerContainer.closeAuthenticatedSession(se.getSession().getId());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsSessionListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */