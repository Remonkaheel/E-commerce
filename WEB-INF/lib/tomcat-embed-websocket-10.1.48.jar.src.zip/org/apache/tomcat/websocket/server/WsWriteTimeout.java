/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentSkipListSet;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import org.apache.tomcat.websocket.BackgroundProcess;
/*    */ import org.apache.tomcat.websocket.BackgroundProcessManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsWriteTimeout
/*    */   implements BackgroundProcess
/*    */ {
/* 37 */   private final Set<WsRemoteEndpointImplServer> endpoints = new ConcurrentSkipListSet<>(
/* 38 */       Comparator.comparingLong(WsRemoteEndpointImplServer::getTimeoutExpiry));
/* 39 */   private final AtomicInteger count = new AtomicInteger(0);
/* 40 */   private int backgroundProcessCount = 0;
/* 41 */   private volatile int processPeriod = 1;
/*    */ 
/*    */ 
/*    */   
/*    */   public void backgroundProcess() {
/* 46 */     this.backgroundProcessCount++;
/*    */     
/* 48 */     if (this.backgroundProcessCount >= this.processPeriod) {
/* 49 */       this.backgroundProcessCount = 0;
/*    */       
/* 51 */       long now = System.currentTimeMillis();
/* 52 */       for (WsRemoteEndpointImplServer endpoint : this.endpoints) {
/* 53 */         if (endpoint.getTimeoutExpiry() < now)
/*    */         {
/*    */           
/* 56 */           endpoint.onTimeout(false);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setProcessPeriod(int period) {
/* 70 */     this.processPeriod = period;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getProcessPeriod() {
/* 79 */     return this.processPeriod;
/*    */   }
/*    */ 
/*    */   
/*    */   public void register(WsRemoteEndpointImplServer endpoint) {
/* 84 */     boolean result = this.endpoints.add(endpoint);
/* 85 */     if (result) {
/* 86 */       int newCount = this.count.incrementAndGet();
/* 87 */       if (newCount == 1) {
/* 88 */         BackgroundProcessManager.getInstance().register(this);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void unregister(WsRemoteEndpointImplServer endpoint) {
/* 95 */     boolean result = this.endpoints.remove(endpoint);
/* 96 */     if (result) {
/* 97 */       int newCount = this.count.decrementAndGet();
/* 98 */       if (newCount == 0)
/* 99 */         BackgroundProcessManager.getInstance().unregister(this); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsWriteTimeout.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */