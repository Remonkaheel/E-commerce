/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import jakarta.websocket.server.ServerEndpointConfig;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WsMappingResult
/*    */ {
/*    */   private final ServerEndpointConfig config;
/*    */   private final Map<String, String> pathParams;
/*    */   
/*    */   WsMappingResult(ServerEndpointConfig config, Map<String, String> pathParams) {
/* 30 */     this.config = config;
/* 31 */     this.pathParams = pathParams;
/*    */   }
/*    */ 
/*    */   
/*    */   ServerEndpointConfig getConfig() {
/* 36 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   Map<String, String> getPathParams() {
/* 41 */     return this.pathParams;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsMappingResult.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */