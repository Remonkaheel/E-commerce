/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriTemplate
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(UriTemplate.class);
/*     */   
/*     */   private final String normalized;
/*  40 */   private final List<Segment> segments = new ArrayList<>();
/*     */   
/*     */   private final boolean hasParameters;
/*     */ 
/*     */   
/*     */   public UriTemplate(String path) throws DeploymentException {
/*  46 */     if (path == null || !path.startsWith("/") || path.contains("/../") || path.contains("/./") || path
/*  47 */       .contains("//")) {
/*  48 */       throw new DeploymentException(sm.getString("uriTemplate.invalidPath", new Object[] { path }));
/*     */     }
/*     */     
/*  51 */     StringBuilder normalized = new StringBuilder(path.length());
/*  52 */     Set<String> paramNames = new HashSet<>();
/*     */ 
/*     */     
/*  55 */     String[] segments = path.split("/", -1);
/*  56 */     int paramCount = 0;
/*  57 */     int segmentCount = 0;
/*     */     
/*  59 */     for (int i = 0; i < segments.length; i++) {
/*  60 */       String segment = segments[i];
/*  61 */       if (segment.isEmpty()) {
/*  62 */         if (i != 0 && (i != segments.length - 1 || paramCount != 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  71 */           throw new DeploymentException(sm.getString("uriTemplate.emptySegment", new Object[] { path }));
/*     */         }
/*     */       } else {
/*  74 */         normalized.append('/');
/*  75 */         int index = -1;
/*  76 */         if (segment.startsWith("{") && segment.endsWith("}")) {
/*  77 */           index = segmentCount;
/*  78 */           segment = segment.substring(1, segment.length() - 1);
/*  79 */           normalized.append('{');
/*  80 */           normalized.append(paramCount++);
/*  81 */           normalized.append('}');
/*  82 */           if (!paramNames.add(segment)) {
/*  83 */             throw new DeploymentException(sm.getString("uriTemplate.duplicateParameter", new Object[] { segment }));
/*     */           }
/*     */         } else {
/*  86 */           if (segment.contains("{") || segment.contains("}")) {
/*  87 */             throw new DeploymentException(sm.getString("uriTemplate.invalidSegment", new Object[] { segment, path }));
/*     */           }
/*  89 */           normalized.append(segment);
/*     */         } 
/*  91 */         this.segments.add(new Segment(index, segment));
/*  92 */         segmentCount++;
/*     */       } 
/*     */     } 
/*  95 */     this.normalized = normalized.toString();
/*  96 */     this.hasParameters = (paramCount > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> match(UriTemplate candidate) {
/* 102 */     Map<String, String> result = new HashMap<>();
/*     */ 
/*     */     
/* 105 */     if (candidate.getSegmentCount() != getSegmentCount()) {
/* 106 */       return null;
/*     */     }
/*     */     
/* 109 */     Iterator<Segment> targetSegments = this.segments.iterator();
/*     */     
/* 111 */     for (Segment candidateSegment : candidate.getSegments()) {
/* 112 */       Segment targetSegment = targetSegments.next();
/*     */       
/* 114 */       if (targetSegment.getParameterIndex() == -1) {
/*     */         
/* 116 */         if (!targetSegment.getValue().equals(candidateSegment.getValue()))
/*     */         {
/* 118 */           return null;
/*     */         }
/*     */         continue;
/*     */       } 
/* 122 */       result.put(targetSegment.getValue(), candidateSegment.getValue());
/*     */     } 
/*     */ 
/*     */     
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasParameters() {
/* 131 */     return this.hasParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSegmentCount() {
/* 136 */     return this.segments.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNormalizedPath() {
/* 141 */     return this.normalized;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Segment> getSegments() {
/* 146 */     return this.segments;
/*     */   }
/*     */   
/*     */   private static class Segment
/*     */   {
/*     */     private final int parameterIndex;
/*     */     private final String value;
/*     */     
/*     */     Segment(int parameterIndex, String value) {
/* 155 */       this.parameterIndex = parameterIndex;
/* 156 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getParameterIndex() {
/* 161 */       return this.parameterIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 166 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\UriTemplate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */