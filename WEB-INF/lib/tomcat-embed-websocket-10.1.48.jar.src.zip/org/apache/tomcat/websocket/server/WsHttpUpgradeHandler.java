/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import jakarta.servlet.http.WebConnection;
/*     */ import jakarta.websocket.CloseReason;
/*     */ import jakarta.websocket.DeploymentException;
/*     */ import jakarta.websocket.Endpoint;
/*     */ import jakarta.websocket.EndpointConfig;
/*     */ import jakarta.websocket.Extension;
/*     */ import jakarta.websocket.Session;
/*     */ import jakarta.websocket.server.ServerEndpointConfig;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.coyote.http11.upgrade.InternalHttpUpgradeHandler;
/*     */ import org.apache.coyote.http11.upgrade.UpgradeInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint;
/*     */ import org.apache.tomcat.util.net.SSLSupport;
/*     */ import org.apache.tomcat.util.net.SocketEvent;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsIOException;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsHttpUpgradeHandler
/*     */   implements InternalHttpUpgradeHandler
/*     */ {
/*  51 */   private final Log log = LogFactory.getLog(WsHttpUpgradeHandler.class);
/*  52 */   private static final StringManager sm = StringManager.getManager(WsHttpUpgradeHandler.class);
/*     */   
/*     */   private final ClassLoader applicationClassLoader;
/*     */   
/*     */   private SocketWrapperBase<?> socketWrapper;
/*  57 */   private final UpgradeInfo upgradeInfo = new UpgradeInfo();
/*     */   
/*     */   private Endpoint ep;
/*     */   
/*     */   private ServerEndpointConfig serverEndpointConfig;
/*     */   
/*     */   private WsServerContainer webSocketContainer;
/*     */   private WsHandshakeRequest handshakeRequest;
/*     */   private List<Extension> negotiatedExtensions;
/*     */   private String subProtocol;
/*     */   private Transformation transformation;
/*     */   private Map<String, String> pathParameters;
/*     */   private boolean secure;
/*     */   private WebConnection connection;
/*     */   private WsRemoteEndpointImplServer wsRemoteEndpointServer;
/*     */   private WsFrameServer wsFrame;
/*     */   private WsSession wsSession;
/*     */   
/*     */   public WsHttpUpgradeHandler() {
/*  76 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSocketWrapper(SocketWrapperBase<?> socketWrapper) {
/*  82 */     this.socketWrapper = socketWrapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preInit(ServerEndpointConfig serverEndpointConfig, WsServerContainer wsc, WsHandshakeRequest handshakeRequest, List<Extension> negotiatedExtensionsPhase2, String subProtocol, Transformation transformation, Map<String, String> pathParameters, boolean secure) {
/*  89 */     this.serverEndpointConfig = serverEndpointConfig;
/*  90 */     this.webSocketContainer = wsc;
/*  91 */     this.handshakeRequest = handshakeRequest;
/*  92 */     this.negotiatedExtensions = negotiatedExtensionsPhase2;
/*  93 */     this.subProtocol = subProtocol;
/*  94 */     this.transformation = transformation;
/*  95 */     this.pathParameters = pathParameters;
/*  96 */     this.secure = secure;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(WebConnection connection) {
/* 102 */     this.connection = connection;
/* 103 */     if (this.serverEndpointConfig == null) {
/* 104 */       throw new IllegalStateException(sm.getString("wsHttpUpgradeHandler.noPreInit"));
/*     */     }
/*     */     
/* 107 */     String httpSessionId = null;
/* 108 */     Object session = this.handshakeRequest.getHttpSession();
/* 109 */     if (session != null) {
/* 110 */       httpSessionId = ((HttpSession)session).getId();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     Thread t = Thread.currentThread();
/* 117 */     ClassLoader cl = t.getContextClassLoader();
/* 118 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 120 */       this.wsRemoteEndpointServer = new WsRemoteEndpointImplServer(this.socketWrapper, this.upgradeInfo, this.webSocketContainer, connection);
/*     */       
/* 122 */       this
/*     */         
/* 124 */         .wsSession = new WsSession(this.wsRemoteEndpointServer, this.webSocketContainer, this.handshakeRequest.getRequestURI(), this.handshakeRequest.getParameterMap(), this.handshakeRequest.getQueryString(), this.handshakeRequest.getUserPrincipal(), httpSessionId, this.negotiatedExtensions, this.subProtocol, this.pathParameters, this.secure, this.serverEndpointConfig);
/*     */       
/* 126 */       this.ep = this.wsSession.getLocal();
/* 127 */       this.wsFrame = new WsFrameServer(this.socketWrapper, this.upgradeInfo, this.wsSession, this.transformation, this.applicationClassLoader);
/*     */ 
/*     */       
/* 130 */       this.wsRemoteEndpointServer.setTransformation(this.wsFrame.getTransformation());
/* 131 */       this.ep.onOpen((Session)this.wsSession, (EndpointConfig)this.serverEndpointConfig);
/* 132 */       this.webSocketContainer.registerSession(this.serverEndpointConfig.getPath(), this.wsSession);
/* 133 */     } catch (DeploymentException e) {
/* 134 */       throw new IllegalArgumentException(e);
/*     */     } finally {
/* 136 */       t.setContextClassLoader(cl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UpgradeInfo getUpgradeInfo() {
/* 143 */     return this.upgradeInfo;
/*     */   }
/*     */   
/*     */   public AbstractEndpoint.Handler.SocketState upgradeDispatch(SocketEvent status) {
/*     */     CloseReason cr;
/*     */     String msg;
/* 149 */     switch (status) {
/*     */       case OPEN_READ:
/*     */         try {
/* 152 */           return this.wsFrame.notifyDataAvailable();
/* 153 */         } catch (WsIOException ws) {
/* 154 */           close(ws.getCloseReason());
/* 155 */         } catch (IOException ioe) {
/* 156 */           onError(ioe);
/* 157 */           CloseReason closeReason = new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.CLOSED_ABNORMALLY, ioe.getMessage());
/* 158 */           close(closeReason);
/*     */         } 
/* 160 */         return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */       case OPEN_WRITE:
/* 162 */         this.wsRemoteEndpointServer.onWritePossible(false);
/*     */         break;
/*     */       
/*     */       case STOP:
/* 166 */         cr = new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.GOING_AWAY, sm.getString("wsHttpUpgradeHandler.serverStop"));
/*     */         try {
/* 168 */           this.wsSession.close(cr);
/* 169 */         } catch (IOException ioe) {
/* 170 */           onError(ioe);
/* 171 */           cr = new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.CLOSED_ABNORMALLY, ioe.getMessage());
/* 172 */           close(cr);
/* 173 */           return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case ERROR:
/* 178 */         this.wsRemoteEndpointServer.clearHandler(this.socketWrapper.getError(), false);
/* 179 */         msg = sm.getString("wsHttpUpgradeHandler.closeOnError");
/* 180 */         this.wsSession.doClose(new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg));
/*     */ 
/*     */       
/*     */       case DISCONNECT:
/*     */       case TIMEOUT:
/*     */       case CONNECT_FAIL:
/* 186 */         return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (this.wsSession.isClosed()) {
/* 195 */       return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */     }
/* 197 */     return AbstractEndpoint.Handler.SocketState.UPGRADED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void timeoutAsync(long now) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 216 */     WebConnection connection = this.connection;
/* 217 */     if (connection != null) {
/* 218 */       this.connection = null;
/*     */       try {
/* 220 */         connection.close();
/* 221 */       } catch (Exception e) {
/* 222 */         this.log.error(sm.getString("wsHttpUpgradeHandler.destroyFailed"), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void onError(Throwable throwable) {
/* 230 */     Thread t = Thread.currentThread();
/* 231 */     ClassLoader cl = t.getContextClassLoader();
/* 232 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 234 */       this.ep.onError((Session)this.wsSession, throwable);
/*     */     } finally {
/* 236 */       t.setContextClassLoader(cl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void close(CloseReason cr) {
/* 249 */     this.wsRemoteEndpointServer.clearHandler(new EOFException(), true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.wsSession.onClose(cr);
/*     */   }
/*     */   
/*     */   public void setSslSupport(SSLSupport sslSupport) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\server\WsHttpUpgradeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */