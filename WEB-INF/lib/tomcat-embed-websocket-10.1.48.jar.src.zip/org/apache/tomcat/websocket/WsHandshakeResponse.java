/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.HandshakeResponse;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsHandshakeResponse
/*    */   implements HandshakeResponse
/*    */ {
/* 33 */   private final Map<String, List<String>> headers = (Map<String, List<String>>)new CaseInsensitiveKeyMap();
/*    */ 
/*    */ 
/*    */   
/*    */   public WsHandshakeResponse() {}
/*    */ 
/*    */   
/*    */   public WsHandshakeResponse(Map<String, List<String>> headers) {
/* 41 */     for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
/* 42 */       if (this.headers.containsKey(entry.getKey())) {
/* 43 */         ((List)this.headers.get(entry.getKey())).addAll(entry.getValue()); continue;
/*    */       } 
/* 45 */       List<String> values = new ArrayList<>(entry.getValue());
/* 46 */       this.headers.put(entry.getKey(), values);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, List<String>> getHeaders() {
/* 54 */     return this.headers;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsHandshakeResponse.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */