/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadBufferOverflowException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final int minBufferSize;
/*    */   
/*    */   public ReadBufferOverflowException(int minBufferSize) {
/* 28 */     this.minBufferSize = minBufferSize;
/*    */   }
/*    */   
/*    */   public int getMinBufferSize() {
/* 32 */     return this.minBufferSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\ReadBufferOverflowException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */