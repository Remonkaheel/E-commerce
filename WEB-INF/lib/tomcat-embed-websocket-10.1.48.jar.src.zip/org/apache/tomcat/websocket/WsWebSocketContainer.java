/*      */ package org.apache.tomcat.websocket;
/*      */ 
/*      */ import jakarta.websocket.ClientEndpoint;
/*      */ import jakarta.websocket.ClientEndpointConfig;
/*      */ import jakarta.websocket.CloseReason;
/*      */ import jakarta.websocket.DeploymentException;
/*      */ import jakarta.websocket.Endpoint;
/*      */ import jakarta.websocket.EndpointConfig;
/*      */ import jakarta.websocket.Extension;
/*      */ import jakarta.websocket.HandshakeResponse;
/*      */ import jakarta.websocket.Session;
/*      */ import jakarta.websocket.WebSocketContainer;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Proxy;
/*      */ import java.net.ProxySelector;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.URI;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.AsynchronousChannelGroup;
/*      */ import java.nio.channels.AsynchronousSocketChannel;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.KeyStore;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Base64;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.TimeoutException;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.InstanceManagerBindings;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.KeyStoreUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WsWebSocketContainer
/*      */   implements WebSocketContainer, BackgroundProcess
/*      */ {
/*   82 */   private static final StringManager sm = StringManager.getManager(WsWebSocketContainer.class);
/*   83 */   private static final Random RANDOM = new Random();
/*   84 */   private static final byte[] CRLF = new byte[] { 13, 10 };
/*      */   
/*   86 */   private static final byte[] GET_BYTES = "GET ".getBytes(StandardCharsets.ISO_8859_1);
/*   87 */   private static final byte[] ROOT_URI_BYTES = "/".getBytes(StandardCharsets.ISO_8859_1);
/*   88 */   private static final byte[] HTTP_VERSION_BYTES = " HTTP/1.1\r\n".getBytes(StandardCharsets.ISO_8859_1);
/*      */   
/*   90 */   private volatile AsynchronousChannelGroup asynchronousChannelGroup = null;
/*   91 */   private final Object asynchronousChannelGroupLock = new Object();
/*      */   
/*   93 */   private final Log log = LogFactory.getLog(WsWebSocketContainer.class);
/*      */ 
/*      */   
/*   96 */   private final Map<Object, Set<WsSession>> endpointSessionMap = new HashMap<>();
/*   97 */   private final Map<WsSession, WsSession> sessions = new ConcurrentHashMap<>();
/*   98 */   private final Object endPointSessionMapLock = new Object();
/*      */   
/*  100 */   private long defaultAsyncTimeout = -1L;
/*  101 */   private int maxBinaryMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  102 */   private int maxTextMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  103 */   private volatile long defaultMaxSessionIdleTimeout = 0L;
/*  104 */   private int backgroundProcessCount = 0;
/*  105 */   private int processPeriod = Constants.DEFAULT_PROCESS_PERIOD;
/*      */   
/*      */   private InstanceManager instanceManager;
/*      */   
/*      */   protected InstanceManager getInstanceManager(ClassLoader classLoader) {
/*  110 */     if (this.instanceManager != null) {
/*  111 */       return this.instanceManager;
/*      */     }
/*  113 */     return InstanceManagerBindings.get(classLoader);
/*      */   }
/*      */   
/*      */   protected void setInstanceManager(InstanceManager instanceManager) {
/*  117 */     this.instanceManager = instanceManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public Session connectToServer(Object pojo, URI path) throws DeploymentException {
/*  122 */     ClientEndpointConfig config = createClientEndpointConfig(pojo.getClass());
/*  123 */     ClientEndpointHolder holder = new PojoHolder(pojo, config);
/*  124 */     return connectToServerRecursive(holder, config, path, new HashSet<>());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Session connectToServer(Class<?> annotatedEndpointClass, URI path) throws DeploymentException {
/*  130 */     ClientEndpointConfig config = createClientEndpointConfig(annotatedEndpointClass);
/*  131 */     ClientEndpointHolder holder = new PojoClassHolder(annotatedEndpointClass, config);
/*  132 */     return connectToServerRecursive(holder, config, path, new HashSet<>());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ClientEndpointConfig createClientEndpointConfig(Class<?> annotatedEndpointClass) throws DeploymentException {
/*  138 */     ClientEndpoint annotation = annotatedEndpointClass.<ClientEndpoint>getAnnotation(ClientEndpoint.class);
/*  139 */     if (annotation == null) {
/*  140 */       throw new DeploymentException(sm
/*  141 */           .getString("wsWebSocketContainer.missingAnnotation", new Object[] { annotatedEndpointClass.getName() }));
/*      */     }
/*      */     
/*  144 */     Class<? extends ClientEndpointConfig.Configurator> configuratorClazz = annotation.configurator();
/*      */     
/*  146 */     ClientEndpointConfig.Configurator configurator = null;
/*  147 */     if (!ClientEndpointConfig.Configurator.class.equals(configuratorClazz)) {
/*      */       try {
/*  149 */         configurator = configuratorClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  150 */       } catch (ReflectiveOperationException e) {
/*  151 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.defaultConfiguratorFail"), e);
/*      */       } 
/*      */     }
/*      */     
/*  155 */     ClientEndpointConfig.Builder builder = ClientEndpointConfig.Builder.create();
/*      */     
/*  157 */     if (configurator != null) {
/*  158 */       builder.configurator(configurator);
/*      */     }
/*  160 */     return builder.decoders(Arrays.asList((Class<?>[][])annotation.decoders())).encoders(Arrays.asList((Class<?>[][])annotation.encoders()))
/*  161 */       .preferredSubprotocols(Arrays.asList(annotation.subprotocols())).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Session connectToServer(Class<? extends Endpoint> clazz, ClientEndpointConfig clientEndpointConfiguration, URI path) throws DeploymentException {
/*  168 */     ClientEndpointHolder holder = new EndpointClassHolder(clazz);
/*  169 */     return connectToServerRecursive(holder, clientEndpointConfiguration, path, new HashSet<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Session connectToServer(Endpoint endpoint, ClientEndpointConfig clientEndpointConfiguration, URI path) throws DeploymentException {
/*  176 */     ClientEndpointHolder holder = new EndpointHolder(endpoint);
/*  177 */     return connectToServerRecursive(holder, clientEndpointConfiguration, path, new HashSet<>());
/*      */   }
/*      */ 
/*      */   
/*      */   private Session connectToServerRecursive(ClientEndpointHolder clientEndpointHolder, ClientEndpointConfig clientEndpointConfiguration, URI path, Set<URI> redirectSet) throws DeploymentException {
/*      */     URI proxyPath;
/*      */     AsynchronousSocketChannel socketChannel;
/*      */     String subProtocol;
/*  185 */     if (this.log.isTraceEnabled()) {
/*  186 */       this.log.trace(sm.getString("wsWebSocketContainer.connect.entry", new Object[] { clientEndpointHolder.getClassName(), path }));
/*      */     }
/*      */     
/*  189 */     boolean secure = false;
/*  190 */     ByteBuffer proxyConnect = null;
/*      */ 
/*      */ 
/*      */     
/*  194 */     String scheme = path.getScheme();
/*  195 */     if ("ws".equalsIgnoreCase(scheme)) {
/*  196 */       proxyPath = URI.create("http" + path.toString().substring(2));
/*  197 */     } else if ("wss".equalsIgnoreCase(scheme)) {
/*  198 */       proxyPath = URI.create("https" + path.toString().substring(3));
/*  199 */       secure = true;
/*      */     } else {
/*  201 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathWrongScheme", new Object[] { scheme }));
/*      */     } 
/*      */ 
/*      */     
/*  205 */     String host = path.getHost();
/*  206 */     if (host == null) {
/*  207 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathNoHost"));
/*      */     }
/*  209 */     int port = path.getPort();
/*      */     
/*  211 */     SocketAddress sa = null;
/*      */ 
/*      */ 
/*      */     
/*  215 */     List<Proxy> proxies = ProxySelector.getDefault().select(proxyPath);
/*  216 */     Proxy selectedProxy = null;
/*  217 */     for (Proxy proxy : proxies) {
/*  218 */       if (proxy.type().equals(Proxy.Type.HTTP)) {
/*  219 */         sa = proxy.address();
/*  220 */         if (sa instanceof InetSocketAddress) {
/*  221 */           InetSocketAddress inet = (InetSocketAddress)sa;
/*  222 */           if (inet.isUnresolved()) {
/*  223 */             sa = new InetSocketAddress(inet.getHostName(), inet.getPort());
/*      */           }
/*      */         } 
/*  226 */         selectedProxy = proxy;
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/*  233 */     if (port == -1) {
/*  234 */       if ("ws".equalsIgnoreCase(scheme)) {
/*  235 */         port = 80;
/*      */       } else {
/*      */         
/*  238 */         port = 443;
/*      */       } 
/*      */     }
/*      */     
/*  242 */     Map<String, Object> userProperties = clientEndpointConfiguration.getUserProperties();
/*      */ 
/*      */     
/*  245 */     if (sa == null) {
/*  246 */       sa = new InetSocketAddress(host, port);
/*      */     } else {
/*  248 */       proxyConnect = createProxyRequest(host, port, (String)userProperties
/*  249 */           .get("Proxy-Authorization"));
/*      */     } 
/*      */ 
/*      */     
/*  253 */     Map<String, List<String>> reqHeaders = createRequestHeaders(host, port, secure, clientEndpointConfiguration);
/*  254 */     clientEndpointConfiguration.getConfigurator().beforeRequest(reqHeaders);
/*  255 */     if (Constants.DEFAULT_ORIGIN_HEADER_VALUE != null && !reqHeaders.containsKey("Origin")) {
/*  256 */       List<String> originValues = new ArrayList<>(1);
/*  257 */       originValues.add(Constants.DEFAULT_ORIGIN_HEADER_VALUE);
/*  258 */       reqHeaders.put("Origin", originValues);
/*      */     } 
/*  260 */     ByteBuffer request = createRequest(path, reqHeaders);
/*      */ 
/*      */     
/*  263 */     long timeout = 5000L;
/*  264 */     String timeoutValue = (String)userProperties.get("org.apache.tomcat.websocket.IO_TIMEOUT_MS");
/*  265 */     if (timeoutValue != null) {
/*  266 */       timeout = Long.valueOf(timeoutValue).intValue();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  271 */       socketChannel = AsynchronousSocketChannel.open(getAsynchronousChannelGroup());
/*  272 */     } catch (IOException ioe) {
/*  273 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.asynchronousSocketChannelFail"), ioe);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  278 */     ByteBuffer response = ByteBuffer.allocate(getDefaultMaxBinaryMessageBufferSize());
/*      */     
/*  280 */     boolean success = false;
/*  281 */     List<Extension> extensionsAgreed = new ArrayList<>();
/*  282 */     Transformation transformation = null;
/*  283 */     AsyncChannelWrapper channel = null;
/*      */ 
/*      */     
/*      */     try {
/*  287 */       Future<Void> fConnect = socketChannel.connect(sa);
/*      */       
/*  289 */       if (proxyConnect != null) {
/*  290 */         fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*      */         
/*  292 */         channel = new AsyncChannelWrapperNonSecure(socketChannel);
/*  293 */         writeRequest(channel, proxyConnect, timeout);
/*  294 */         HttpResponse httpResponse1 = processResponse(response, channel, timeout);
/*  295 */         if (httpResponse1.status == 407) {
/*  296 */           return processAuthenticationChallenge(clientEndpointHolder, clientEndpointConfiguration, path, redirectSet, userProperties, request, httpResponse1, AuthenticationType.PROXY);
/*      */         }
/*  298 */         if (httpResponse1.getStatus() != 200) {
/*  299 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.proxyConnectFail", new Object[] { selectedProxy, 
/*  300 */                   Integer.toString(httpResponse1.getStatus()) }));
/*      */         }
/*      */       } 
/*      */       
/*  304 */       if (secure) {
/*      */ 
/*      */ 
/*      */         
/*  308 */         SSLEngine sslEngine = createSSLEngine(clientEndpointConfiguration, host, port);
/*  309 */         channel = new AsyncChannelWrapperSecure(socketChannel, sslEngine);
/*  310 */       } else if (channel == null) {
/*      */ 
/*      */         
/*  313 */         channel = new AsyncChannelWrapperNonSecure(socketChannel);
/*      */       } 
/*      */       
/*  316 */       fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*      */       
/*  318 */       Future<Void> fHandshake = channel.handshake();
/*  319 */       fHandshake.get(timeout, TimeUnit.MILLISECONDS);
/*      */       
/*  321 */       if (this.log.isTraceEnabled()) {
/*  322 */         SocketAddress localAddress = null;
/*      */         try {
/*  324 */           localAddress = channel.getLocalAddress();
/*  325 */         } catch (IOException iOException) {}
/*      */ 
/*      */         
/*  328 */         this.log.trace(sm.getString("wsWebSocketContainer.connect.write", new Object[] { Integer.valueOf(request.position()), 
/*  329 */                 Integer.valueOf(request.limit()), localAddress }));
/*      */       } 
/*  331 */       writeRequest(channel, request, timeout);
/*      */       
/*  333 */       HttpResponse httpResponse = processResponse(response, channel, timeout);
/*      */ 
/*      */       
/*  336 */       int maxRedirects = 20;
/*  337 */       String maxRedirectsValue = (String)userProperties.get("org.apache.tomcat.websocket.MAX_REDIRECTIONS");
/*  338 */       if (maxRedirectsValue != null) {
/*  339 */         maxRedirects = Integer.parseInt(maxRedirectsValue);
/*      */       }
/*      */       
/*  342 */       if (httpResponse.status != 101) {
/*  343 */         if (isRedirectStatus(httpResponse.status)) {
/*      */           
/*  345 */           List<String> locationHeader = (List<String>)httpResponse.getHandshakeResponse().getHeaders().get("Location");
/*      */           
/*  347 */           if (locationHeader == null || locationHeader.isEmpty() || locationHeader.get(0) == null || ((String)locationHeader
/*  348 */             .get(0)).isEmpty()) {
/*  349 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.missingLocationHeader", new Object[] {
/*  350 */                     Integer.toString(httpResponse.status)
/*      */                   }));
/*      */           }
/*  353 */           URI redirectLocation = URI.create(locationHeader.get(0)).normalize();
/*      */           
/*  355 */           if (!redirectLocation.isAbsolute()) {
/*  356 */             redirectLocation = path.resolve(redirectLocation);
/*      */           }
/*      */           
/*  359 */           String redirectScheme = redirectLocation.getScheme().toLowerCase(Locale.ENGLISH);
/*      */           
/*  361 */           if (redirectScheme.startsWith("http"))
/*      */           {
/*      */             
/*  364 */             redirectLocation = new URI(redirectScheme.replace("http", "ws"), redirectLocation.getUserInfo(), redirectLocation.getHost(), redirectLocation.getPort(), redirectLocation.getPath(), redirectLocation.getQuery(), redirectLocation.getFragment());
/*      */           }
/*      */           
/*  367 */           if (!redirectSet.add(redirectLocation) || redirectSet.size() > maxRedirects) {
/*  368 */             throw new DeploymentException(sm
/*  369 */                 .getString("wsWebSocketContainer.redirectThreshold", new Object[] {
/*  370 */                     redirectLocation, Integer.toString(redirectSet.size()), Integer.toString(maxRedirects)
/*      */                   }));
/*      */           }
/*  373 */           return connectToServerRecursive(clientEndpointHolder, clientEndpointConfiguration, redirectLocation, redirectSet);
/*      */         } 
/*      */         
/*  376 */         if (httpResponse.status == 401) {
/*  377 */           return processAuthenticationChallenge(clientEndpointHolder, clientEndpointConfiguration, path, redirectSet, userProperties, request, httpResponse, AuthenticationType.WWW);
/*      */         }
/*      */ 
/*      */         
/*  381 */         throw new DeploymentException(sm
/*  382 */             .getString("wsWebSocketContainer.invalidStatus", new Object[] { Integer.toString(httpResponse.status) }));
/*      */       } 
/*      */       
/*  385 */       HandshakeResponse handshakeResponse = httpResponse.getHandshakeResponse();
/*  386 */       clientEndpointConfiguration.getConfigurator().afterResponse(handshakeResponse);
/*      */ 
/*      */       
/*  389 */       List<String> protocolHeaders = (List<String>)handshakeResponse.getHeaders().get("Sec-WebSocket-Protocol");
/*  390 */       if (protocolHeaders == null || protocolHeaders.isEmpty()) {
/*  391 */         subProtocol = null;
/*  392 */       } else if (protocolHeaders.size() == 1) {
/*  393 */         subProtocol = protocolHeaders.get(0);
/*      */       } else {
/*  395 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidSubProtocol"));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  401 */       List<String> extHeaders = (List<String>)handshakeResponse.getHeaders().get("Sec-WebSocket-Extensions");
/*  402 */       if (extHeaders != null) {
/*  403 */         for (String extHeader : extHeaders) {
/*  404 */           Util.parseExtensionHeader(extensionsAgreed, extHeader);
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*  409 */       TransformationFactory factory = TransformationFactory.getInstance();
/*  410 */       for (Extension extension : extensionsAgreed) {
/*  411 */         List<List<Extension.Parameter>> wrapper = new ArrayList<>(1);
/*  412 */         wrapper.add(extension.getParameters());
/*  413 */         Transformation t = factory.create(extension.getName(), wrapper, false);
/*  414 */         if (t == null) {
/*  415 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidExtensionParameters"));
/*      */         }
/*  417 */         if (transformation == null) {
/*  418 */           transformation = t; continue;
/*      */         } 
/*  420 */         transformation.setNext(t);
/*      */       } 
/*      */ 
/*      */       
/*  424 */       success = true;
/*  425 */     } catch (ExecutionException|InterruptedException|javax.net.ssl.SSLException|EOFException|TimeoutException|java.net.URISyntaxException|AuthenticationException e) {
/*      */       
/*  427 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.httpRequestFailed", new Object[] { path }), e);
/*      */     } finally {
/*  429 */       if (!success) {
/*  430 */         if (channel != null) {
/*  431 */           channel.close();
/*      */         } else {
/*      */           try {
/*  434 */             socketChannel.close();
/*  435 */           } catch (IOException iOException) {}
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  443 */     WsRemoteEndpointImplClient wsRemoteEndpointClient = new WsRemoteEndpointImplClient(channel);
/*      */ 
/*      */     
/*  446 */     WsSession wsSession = new WsSession(clientEndpointHolder, wsRemoteEndpointClient, this, extensionsAgreed, subProtocol, Collections.emptyMap(), secure, clientEndpointConfiguration);
/*      */     
/*  448 */     WsFrameClient wsFrameClient = new WsFrameClient(response, channel, wsSession, transformation);
/*      */ 
/*      */     
/*  451 */     wsRemoteEndpointClient.setTransformation(wsFrameClient.getTransformation());
/*      */     
/*  453 */     wsSession.getLocal().onOpen(wsSession, (EndpointConfig)clientEndpointConfiguration);
/*  454 */     registerSession(wsSession.getLocal(), wsSession);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  464 */     wsFrameClient.startInputProcessing();
/*      */     
/*  466 */     return wsSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Session processAuthenticationChallenge(ClientEndpointHolder clientEndpointHolder, ClientEndpointConfig clientEndpointConfiguration, URI path, Set<URI> redirectSet, Map<String, Object> userProperties, ByteBuffer request, HttpResponse httpResponse, AuthenticationType authenticationType) throws DeploymentException, AuthenticationException {
/*  475 */     if (userProperties.get(authenticationType.getAuthorizationHeaderName()) != null) {
/*  476 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.failedAuthentication", new Object[] {
/*  477 */               Integer.valueOf(httpResponse.status), authenticationType.getAuthorizationHeaderName()
/*      */             }));
/*      */     }
/*      */     
/*  481 */     List<String> authenticateHeaders = (List<String>)httpResponse.getHandshakeResponse().getHeaders().get(authenticationType.getAuthenticateHeaderName());
/*      */     
/*  483 */     if (authenticateHeaders == null || authenticateHeaders.isEmpty() || authenticateHeaders.get(0) == null || ((String)authenticateHeaders
/*  484 */       .get(0)).isEmpty()) {
/*  485 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.missingAuthenticateHeader", new Object[] {
/*  486 */               Integer.toString(httpResponse.status), authenticationType.getAuthenticateHeaderName()
/*      */             }));
/*      */     }
/*  489 */     String authScheme = ((String)authenticateHeaders.get(0)).split("\\s+", 2)[0];
/*      */     
/*  491 */     Authenticator auth = AuthenticatorFactory.getAuthenticator(authScheme);
/*      */     
/*  493 */     if (auth == null) {
/*  494 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.unsupportedAuthScheme", new Object[] {
/*  495 */               Integer.valueOf(httpResponse.status), authScheme
/*      */             }));
/*      */     }
/*  498 */     String requestUri = (new String(request.array(), StandardCharsets.ISO_8859_1)).split("\\s", 3)[1];
/*      */     
/*  500 */     userProperties.put(authenticationType.getAuthorizationHeaderName(), auth
/*  501 */         .getAuthorization(requestUri, authenticateHeaders.get(0), (String)userProperties
/*  502 */           .get(authenticationType.getUserNameProperty()), (String)userProperties
/*  503 */           .get(authenticationType.getUserPasswordProperty()), (String)userProperties
/*  504 */           .get(authenticationType.getUserRealmProperty())));
/*      */     
/*  506 */     return connectToServerRecursive(clientEndpointHolder, clientEndpointConfiguration, path, redirectSet);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void writeRequest(AsyncChannelWrapper channel, ByteBuffer request, long timeout) throws TimeoutException, InterruptedException, ExecutionException {
/*  512 */     int toWrite = request.limit();
/*      */     
/*  514 */     Future<Integer> fWrite = channel.write(request);
/*  515 */     Integer thisWrite = fWrite.get(timeout, TimeUnit.MILLISECONDS);
/*  516 */     toWrite -= thisWrite.intValue();
/*      */     
/*  518 */     while (toWrite > 0) {
/*  519 */       fWrite = channel.write(request);
/*  520 */       thisWrite = fWrite.get(timeout, TimeUnit.MILLISECONDS);
/*  521 */       toWrite -= thisWrite.intValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isRedirectStatus(int httpResponseCode) {
/*  528 */     boolean isRedirect = false;
/*      */     
/*  530 */     switch (httpResponseCode) {
/*      */       case 300:
/*      */       case 301:
/*      */       case 302:
/*      */       case 303:
/*      */       case 305:
/*      */       case 307:
/*  537 */         isRedirect = true;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  543 */     return isRedirect;
/*      */   }
/*      */ 
/*      */   
/*      */   private static ByteBuffer createProxyRequest(String host, int port, String authorizationHeader) {
/*  548 */     StringBuilder request = new StringBuilder();
/*  549 */     request.append("CONNECT ");
/*  550 */     request.append(host);
/*  551 */     request.append(':');
/*  552 */     request.append(port);
/*      */     
/*  554 */     request.append(" HTTP/1.1\r\nProxy-Connection: keep-alive\r\nConnection: keepalive\r\nHost: ");
/*  555 */     request.append(host);
/*  556 */     request.append(':');
/*  557 */     request.append(port);
/*      */     
/*  559 */     if (authorizationHeader != null) {
/*  560 */       request.append("\r\n");
/*  561 */       request.append("Proxy-Authorization");
/*  562 */       request.append(':');
/*  563 */       request.append(authorizationHeader);
/*      */     } 
/*      */     
/*  566 */     request.append("\r\n\r\n");
/*      */     
/*  568 */     byte[] bytes = request.toString().getBytes(StandardCharsets.ISO_8859_1);
/*  569 */     return ByteBuffer.wrap(bytes);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void registerSession(Object key, WsSession wsSession) {
/*  574 */     if (!wsSession.isOpen()) {
/*      */       return;
/*      */     }
/*      */     
/*  578 */     synchronized (this.endPointSessionMapLock) {
/*  579 */       if (this.endpointSessionMap.isEmpty()) {
/*  580 */         BackgroundProcessManager.getInstance().register(this);
/*      */       }
/*  582 */       ((Set<WsSession>)this.endpointSessionMap.computeIfAbsent(key, k -> new HashSet())).add(wsSession);
/*      */     } 
/*  584 */     this.sessions.put(wsSession, wsSession);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void unregisterSession(Object key, WsSession wsSession) {
/*  590 */     synchronized (this.endPointSessionMapLock) {
/*  591 */       Set<WsSession> wsSessions = this.endpointSessionMap.get(key);
/*  592 */       if (wsSessions != null) {
/*  593 */         wsSessions.remove(wsSession);
/*  594 */         if (wsSessions.isEmpty()) {
/*  595 */           this.endpointSessionMap.remove(key);
/*      */         }
/*      */       } 
/*  598 */       if (this.endpointSessionMap.isEmpty()) {
/*  599 */         BackgroundProcessManager.getInstance().unregister(this);
/*      */       }
/*      */     } 
/*  602 */     this.sessions.remove(wsSession);
/*      */   }
/*      */ 
/*      */   
/*      */   Set<Session> getOpenSessions(Object key) {
/*  607 */     HashSet<Session> result = new HashSet<>();
/*  608 */     synchronized (this.endPointSessionMapLock) {
/*  609 */       Set<WsSession> sessions = this.endpointSessionMap.get(key);
/*  610 */       if (sessions != null)
/*      */       {
/*  612 */         for (WsSession session : sessions) {
/*  613 */           if (session.isOpen()) {
/*  614 */             result.add(session);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*  619 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, List<String>> createRequestHeaders(String host, int port, boolean secure, ClientEndpointConfig clientEndpointConfiguration) {
/*  625 */     Map<String, List<String>> headers = new HashMap<>();
/*  626 */     List<Extension> extensions = clientEndpointConfiguration.getExtensions();
/*  627 */     List<String> subProtocols = clientEndpointConfiguration.getPreferredSubprotocols();
/*  628 */     Map<String, Object> userProperties = clientEndpointConfiguration.getUserProperties();
/*      */     
/*  630 */     if (userProperties.get("Authorization") != null) {
/*  631 */       List<String> authValues = new ArrayList<>(1);
/*  632 */       authValues.add((String)userProperties.get("Authorization"));
/*  633 */       headers.put("Authorization", authValues);
/*      */     } 
/*      */ 
/*      */     
/*  637 */     List<String> hostValues = new ArrayList<>(1);
/*  638 */     if ((port == 80 && !secure) || (port == 443 && secure)) {
/*      */       
/*  640 */       hostValues.add(host);
/*      */     } else {
/*  642 */       hostValues.add(host + ":" + host);
/*      */     } 
/*      */     
/*  645 */     headers.put("Host", hostValues);
/*      */ 
/*      */     
/*  648 */     List<String> upgradeValues = new ArrayList<>(1);
/*  649 */     upgradeValues.add("websocket");
/*  650 */     headers.put("Upgrade", upgradeValues);
/*      */ 
/*      */     
/*  653 */     List<String> connectionValues = new ArrayList<>(1);
/*  654 */     connectionValues.add("upgrade");
/*  655 */     headers.put("Connection", connectionValues);
/*      */ 
/*      */     
/*  658 */     List<String> wsVersionValues = new ArrayList<>(1);
/*  659 */     wsVersionValues.add("13");
/*  660 */     headers.put("Sec-WebSocket-Version", wsVersionValues);
/*      */ 
/*      */     
/*  663 */     List<String> wsKeyValues = new ArrayList<>(1);
/*  664 */     wsKeyValues.add(generateWsKeyValue());
/*  665 */     headers.put("Sec-WebSocket-Key", wsKeyValues);
/*      */ 
/*      */     
/*  668 */     if (subProtocols != null && !subProtocols.isEmpty()) {
/*  669 */       headers.put("Sec-WebSocket-Protocol", subProtocols);
/*      */     }
/*      */ 
/*      */     
/*  673 */     if (extensions != null) {
/*      */       
/*  675 */       Set<String> installed = TransformationFactory.getInstance().getInstalledExtensionNames();
/*  676 */       List<Extension> availableExtensions = new ArrayList<>(extensions);
/*  677 */       Iterator<Extension> availableExtensionsIter = availableExtensions.iterator();
/*  678 */       while (availableExtensionsIter.hasNext()) {
/*  679 */         Extension e = availableExtensionsIter.next();
/*  680 */         if (!installed.contains(e.getName())) {
/*  681 */           availableExtensionsIter.remove();
/*      */         }
/*      */       } 
/*  684 */       if (!availableExtensions.isEmpty()) {
/*  685 */         headers.put("Sec-WebSocket-Extensions", generateExtensionHeaders(availableExtensions));
/*      */       }
/*      */     } 
/*      */     
/*  689 */     return headers;
/*      */   }
/*      */ 
/*      */   
/*      */   private static List<String> generateExtensionHeaders(List<Extension> extensions) {
/*  694 */     List<String> result = new ArrayList<>(extensions.size());
/*  695 */     for (Extension extension : extensions) {
/*  696 */       StringBuilder header = new StringBuilder();
/*  697 */       header.append(extension.getName());
/*  698 */       for (Extension.Parameter param : extension.getParameters()) {
/*  699 */         header.append(';');
/*  700 */         header.append(param.getName());
/*  701 */         String value = param.getValue();
/*  702 */         if (value != null && !value.isEmpty()) {
/*  703 */           header.append('=');
/*  704 */           header.append(value);
/*      */         } 
/*      */       } 
/*  707 */       result.add(header.toString());
/*      */     } 
/*  709 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static String generateWsKeyValue() {
/*  714 */     byte[] keyBytes = new byte[16];
/*  715 */     RANDOM.nextBytes(keyBytes);
/*  716 */     return Base64.getEncoder().encodeToString(keyBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private static ByteBuffer createRequest(URI uri, Map<String, List<String>> reqHeaders) {
/*  721 */     ByteBuffer result = ByteBuffer.allocate(4096);
/*      */ 
/*      */     
/*  724 */     result.put(GET_BYTES);
/*  725 */     String path = uri.getPath();
/*  726 */     if (null == path || path.isEmpty()) {
/*  727 */       result.put(ROOT_URI_BYTES);
/*      */     } else {
/*  729 */       result.put(uri.getRawPath().getBytes(StandardCharsets.ISO_8859_1));
/*      */     } 
/*  731 */     String query = uri.getRawQuery();
/*  732 */     if (query != null) {
/*  733 */       result.put((byte)63);
/*  734 */       result.put(query.getBytes(StandardCharsets.ISO_8859_1));
/*      */     } 
/*  736 */     result.put(HTTP_VERSION_BYTES);
/*      */ 
/*      */     
/*  739 */     for (Map.Entry<String, List<String>> entry : reqHeaders.entrySet()) {
/*  740 */       result = addHeader(result, entry.getKey(), entry.getValue());
/*      */     }
/*      */ 
/*      */     
/*  744 */     result.put(CRLF);
/*      */     
/*  746 */     result.flip();
/*      */     
/*  748 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static ByteBuffer addHeader(ByteBuffer result, String key, List<String> values) {
/*  753 */     if (values.isEmpty()) {
/*  754 */       return result;
/*      */     }
/*      */     
/*  757 */     result = putWithExpand(result, key.getBytes(StandardCharsets.ISO_8859_1));
/*  758 */     result = putWithExpand(result, ": ".getBytes(StandardCharsets.ISO_8859_1));
/*  759 */     result = putWithExpand(result, StringUtils.join(values).getBytes(StandardCharsets.ISO_8859_1));
/*  760 */     result = putWithExpand(result, CRLF);
/*      */     
/*  762 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static ByteBuffer putWithExpand(ByteBuffer input, byte[] bytes) {
/*  767 */     if (bytes.length > input.remaining()) {
/*      */       int newSize;
/*  769 */       if (bytes.length > input.capacity()) {
/*  770 */         newSize = 2 * bytes.length;
/*      */       } else {
/*  772 */         newSize = input.capacity() * 2;
/*      */       } 
/*  774 */       ByteBuffer expanded = ByteBuffer.allocate(newSize);
/*  775 */       input.flip();
/*  776 */       expanded.put(input);
/*  777 */       input = expanded;
/*      */     } 
/*  779 */     return input.put(bytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpResponse processResponse(ByteBuffer response, AsyncChannelWrapper channel, long timeout) throws InterruptedException, ExecutionException, DeploymentException, EOFException, TimeoutException {
/*  794 */     CaseInsensitiveKeyMap caseInsensitiveKeyMap = new CaseInsensitiveKeyMap();
/*      */     
/*  796 */     int status = 0;
/*  797 */     boolean readStatus = false;
/*  798 */     boolean readHeaders = false;
/*  799 */     String line = null;
/*  800 */     while (!readHeaders) {
/*      */       Integer bytesRead;
/*      */       
/*  803 */       response.clear();
/*      */       
/*  805 */       Future<Integer> read = channel.read(response);
/*      */       
/*      */       try {
/*  808 */         bytesRead = read.get(timeout, TimeUnit.MILLISECONDS);
/*  809 */       } catch (TimeoutException e) {
/*      */         
/*  811 */         TimeoutException te = new TimeoutException(sm.getString("wsWebSocketContainer.responseFail", new Object[] { Integer.toString(status), caseInsensitiveKeyMap }));
/*  812 */         te.initCause(e);
/*  813 */         throw te;
/*      */       } 
/*  815 */       if (bytesRead.intValue() == -1) {
/*  816 */         throw new EOFException(sm
/*  817 */             .getString("wsWebSocketContainer.responseFail", new Object[] { Integer.toString(status), caseInsensitiveKeyMap }));
/*      */       }
/*  819 */       response.flip();
/*  820 */       while (response.hasRemaining() && !readHeaders) {
/*  821 */         if (line == null) {
/*  822 */           line = readLine(response);
/*      */         } else {
/*  824 */           line = line + line;
/*      */         } 
/*  826 */         if ("\r\n".equals(line)) {
/*  827 */           readHeaders = true; continue;
/*  828 */         }  if (line.endsWith("\r\n")) {
/*  829 */           if (readStatus) {
/*  830 */             parseHeaders(line, (Map<String, List<String>>)caseInsensitiveKeyMap);
/*      */           } else {
/*  832 */             status = parseStatus(line);
/*  833 */             readStatus = true;
/*      */           } 
/*  835 */           line = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  840 */     return new HttpResponse(status, new WsHandshakeResponse((Map<String, List<String>>)caseInsensitiveKeyMap));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int parseStatus(String line) throws DeploymentException {
/*  847 */     String[] parts = line.trim().split(" ");
/*      */     
/*  849 */     if (parts.length < 2 || (!"HTTP/1.0".equals(parts[0]) && !"HTTP/1.1".equals(parts[0]))) {
/*  850 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*      */     }
/*      */     try {
/*  853 */       return Integer.parseInt(parts[1]);
/*  854 */     } catch (NumberFormatException nfe) {
/*  855 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseHeaders(String line, Map<String, List<String>> headers) {
/*  863 */     int index = line.indexOf(':');
/*  864 */     if (index == -1) {
/*  865 */       this.log.warn(sm.getString("wsWebSocketContainer.invalidHeader", new Object[] { line }));
/*      */       
/*      */       return;
/*      */     } 
/*  869 */     String headerName = line.substring(0, index).trim().toLowerCase(Locale.ENGLISH);
/*      */ 
/*      */     
/*  872 */     String headerValue = line.substring(index + 1).trim();
/*      */     
/*  874 */     List<String> values = headers.computeIfAbsent(headerName, k -> new ArrayList(1));
/*  875 */     values.add(headerValue);
/*      */   }
/*      */ 
/*      */   
/*      */   private String readLine(ByteBuffer response) {
/*  880 */     StringBuilder sb = new StringBuilder();
/*      */ 
/*      */     
/*  883 */     while (response.hasRemaining()) {
/*  884 */       char c = (char)response.get();
/*  885 */       sb.append(c);
/*  886 */       if (c == '\n') {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  891 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SSLEngine createSSLEngine(ClientEndpointConfig clientEndpointConfig, String host, int port) throws DeploymentException {
/*  899 */     Map<String, Object> userProperties = clientEndpointConfig.getUserProperties();
/*      */     
/*      */     try {
/*  902 */       SSLContext sslContext = clientEndpointConfig.getSSLContext();
/*      */ 
/*      */ 
/*      */       
/*  906 */       if (sslContext == null) {
/*  907 */         sslContext = (SSLContext)userProperties.get("org.apache.tomcat.websocket.SSL_CONTEXT");
/*      */       }
/*      */       
/*  910 */       if (sslContext == null) {
/*      */         
/*  912 */         sslContext = SSLContext.getInstance("TLS");
/*      */ 
/*      */         
/*  915 */         String sslTrustStoreValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE");
/*  916 */         if (sslTrustStoreValue != null) {
/*  917 */           String sslTrustStorePwdValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE_PWD");
/*  918 */           if (sslTrustStorePwdValue == null) {
/*  919 */             sslTrustStorePwdValue = "changeit";
/*      */           }
/*      */           
/*  922 */           File keyStoreFile = new File(sslTrustStoreValue);
/*  923 */           KeyStore ks = KeyStore.getInstance("JKS");
/*  924 */           InputStream is = new FileInputStream(keyStoreFile); 
/*  925 */           try { KeyStoreUtil.load(ks, is, sslTrustStorePwdValue.toCharArray());
/*  926 */             is.close(); } catch (Throwable throwable) { try { is.close(); }
/*      */             catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */              throw throwable; }
/*  929 */            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/*  930 */           tmf.init(ks);
/*      */           
/*  932 */           sslContext.init(null, tmf.getTrustManagers(), null);
/*      */         } else {
/*  934 */           sslContext.init(null, null, null);
/*      */         } 
/*      */       } 
/*      */       
/*  938 */       SSLEngine engine = sslContext.createSSLEngine(host, port);
/*      */       
/*  940 */       String sslProtocolsValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_PROTOCOLS");
/*  941 */       if (sslProtocolsValue != null) {
/*  942 */         engine.setEnabledProtocols(sslProtocolsValue.split(","));
/*      */       }
/*      */       
/*  945 */       engine.setUseClientMode(true);
/*      */ 
/*      */ 
/*      */       
/*  949 */       SSLParameters sslParams = engine.getSSLParameters();
/*      */       
/*  951 */       sslParams.setEndpointIdentificationAlgorithm("HTTPS");
/*      */       
/*  953 */       engine.setSSLParameters(sslParams);
/*      */       
/*  955 */       return engine;
/*  956 */     } catch (Exception e) {
/*  957 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.sslEngineFail"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getDefaultMaxSessionIdleTimeout() {
/*  964 */     return this.defaultMaxSessionIdleTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultMaxSessionIdleTimeout(long timeout) {
/*  970 */     this.defaultMaxSessionIdleTimeout = timeout;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultMaxBinaryMessageBufferSize() {
/*  976 */     return this.maxBinaryMessageBufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultMaxBinaryMessageBufferSize(int max) {
/*  982 */     this.maxBinaryMessageBufferSize = max;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultMaxTextMessageBufferSize() {
/*  988 */     return this.maxTextMessageBufferSize;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultMaxTextMessageBufferSize(int max) {
/*  994 */     this.maxTextMessageBufferSize = max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Extension> getInstalledExtensions() {
/* 1003 */     return TransformationFactory.getInstance().getInstalledExtensions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getDefaultAsyncSendTimeout() {
/* 1012 */     return this.defaultAsyncTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsyncSendTimeout(long timeout) {
/* 1021 */     this.defaultAsyncTimeout = timeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {
/* 1030 */     CloseReason cr = new CloseReason((CloseReason.CloseCode)CloseReason.CloseCodes.GOING_AWAY, sm.getString("wsWebSocketContainer.shutdown"));
/*      */     
/* 1032 */     for (WsSession session : this.sessions.keySet()) {
/*      */       try {
/* 1034 */         session.close(cr);
/* 1035 */       } catch (IOException ioe) {
/* 1036 */         if (this.log.isDebugEnabled()) {
/* 1037 */           this.log.debug(sm.getString("wsWebSocketContainer.sessionCloseFail", new Object[] { session.getId() }), ioe);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1044 */     if (this.asynchronousChannelGroup != null) {
/* 1045 */       synchronized (this.asynchronousChannelGroupLock) {
/* 1046 */         if (this.asynchronousChannelGroup != null) {
/* 1047 */           AsyncChannelGroupUtil.unregister();
/* 1048 */           this.asynchronousChannelGroup = null;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AsynchronousChannelGroup getAsynchronousChannelGroup() {
/* 1058 */     AsynchronousChannelGroup result = this.asynchronousChannelGroup;
/* 1059 */     if (result == null) {
/* 1060 */       synchronized (this.asynchronousChannelGroupLock) {
/* 1061 */         if (this.asynchronousChannelGroup == null) {
/* 1062 */           this.asynchronousChannelGroup = AsyncChannelGroupUtil.register();
/*      */         }
/* 1064 */         result = this.asynchronousChannelGroup;
/*      */       } 
/*      */     }
/* 1067 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundProcess() {
/* 1076 */     this.backgroundProcessCount++;
/* 1077 */     if (this.backgroundProcessCount >= this.processPeriod) {
/* 1078 */       this.backgroundProcessCount = 0;
/*      */ 
/*      */       
/* 1081 */       for (WsSession wsSession : this.sessions.keySet()) {
/* 1082 */         wsSession.checkExpiration();
/* 1083 */         wsSession.checkCloseTimeout();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProcessPeriod(int period) {
/* 1092 */     this.processPeriod = period;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getProcessPeriod() {
/* 1101 */     return this.processPeriod;
/*      */   }
/*      */   
/*      */   private static class HttpResponse
/*      */   {
/*      */     private final int status;
/*      */     private final HandshakeResponse handshakeResponse;
/*      */     
/*      */     HttpResponse(int status, HandshakeResponse handshakeResponse) {
/* 1110 */       this.status = status;
/* 1111 */       this.handshakeResponse = handshakeResponse;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getStatus() {
/* 1116 */       return this.status;
/*      */     }
/*      */ 
/*      */     
/*      */     public HandshakeResponse getHandshakeResponse() {
/* 1121 */       return this.handshakeResponse;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsWebSocketContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */