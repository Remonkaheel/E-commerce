/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BackgroundProcessManager
/*     */ {
/*  33 */   private final Log log = LogFactory.getLog(BackgroundProcessManager.class);
/*  34 */   private static final StringManager sm = StringManager.getManager(BackgroundProcessManager.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private static final BackgroundProcessManager instance = new BackgroundProcessManager();
/*     */ 
/*     */ 
/*     */   
/*     */   public static BackgroundProcessManager getInstance() {
/*  44 */     return instance;
/*     */   }
/*     */   
/*  47 */   private final Set<BackgroundProcess> processes = new HashSet<>();
/*  48 */   private final Object processesLock = new Object();
/*  49 */   private WsBackgroundThread wsBackgroundThread = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(BackgroundProcess process) {
/*  57 */     synchronized (this.processesLock) {
/*  58 */       if (this.processes.isEmpty()) {
/*  59 */         this.wsBackgroundThread = new WsBackgroundThread(this);
/*  60 */         this.wsBackgroundThread.setContextClassLoader(getClass().getClassLoader());
/*  61 */         this.wsBackgroundThread.setDaemon(true);
/*  62 */         this.wsBackgroundThread.start();
/*     */       } 
/*  64 */       this.processes.add(process);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void unregister(BackgroundProcess process) {
/*  70 */     synchronized (this.processesLock) {
/*  71 */       this.processes.remove(process);
/*  72 */       if (this.wsBackgroundThread != null && this.processes.isEmpty()) {
/*  73 */         this.wsBackgroundThread.halt();
/*  74 */         this.wsBackgroundThread = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void process() {
/*     */     Set<BackgroundProcess> currentProcesses;
/*  82 */     synchronized (this.processesLock) {
/*  83 */       currentProcesses = new HashSet<>(this.processes);
/*     */     } 
/*  85 */     for (BackgroundProcess process : currentProcesses) {
/*     */       try {
/*  87 */         process.backgroundProcess();
/*  88 */       } catch (Throwable t) {
/*  89 */         ExceptionUtils.handleThrowable(t);
/*  90 */         this.log.error(sm.getString("backgroundProcessManager.processFailed"), t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getProcessCount() {
/* 100 */     synchronized (this.processesLock) {
/* 101 */       return this.processes.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void shutdown() {
/* 107 */     synchronized (this.processesLock) {
/* 108 */       this.processes.clear();
/* 109 */       if (this.wsBackgroundThread != null) {
/* 110 */         this.wsBackgroundThread.halt();
/* 111 */         this.wsBackgroundThread = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class WsBackgroundThread
/*     */     extends Thread
/*     */   {
/*     */     private final BackgroundProcessManager manager;
/*     */     private volatile boolean running = true;
/*     */     
/*     */     WsBackgroundThread(BackgroundProcessManager manager) {
/* 123 */       setName("WebSocket background processing");
/* 124 */       this.manager = manager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 129 */       while (this.running) {
/*     */         try {
/* 131 */           sleep(1000L);
/* 132 */         } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */         
/* 135 */         this.manager.process();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void halt() {
/* 140 */       setName("WebSocket background processing - stopping");
/* 141 */       this.running = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\BackgroundProcessManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */