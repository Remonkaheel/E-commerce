/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import jakarta.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndpointHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 29 */   private static final StringManager sm = StringManager.getManager(EndpointHolder.class);
/*    */   
/*    */   private final Endpoint endpoint;
/*    */ 
/*    */   
/*    */   public EndpointHolder(Endpoint endpoint) {
/* 35 */     this.endpoint = endpoint;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 41 */     return this.endpoint.getClass().getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException {
/* 47 */     if (instanceManager != null) {
/*    */       try {
/* 49 */         instanceManager.newInstance(this.endpoint);
/* 50 */       } catch (ReflectiveOperationException|javax.naming.NamingException e) {
/* 51 */         throw new DeploymentException(sm.getString("clientEndpointHolder.instanceRegistrationFailed"), e);
/*    */       } 
/*    */     }
/* 54 */     return this.endpoint;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\EndpointHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */