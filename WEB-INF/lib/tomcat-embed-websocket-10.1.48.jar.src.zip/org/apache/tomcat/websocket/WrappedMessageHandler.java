package org.apache.tomcat.websocket;

import jakarta.websocket.MessageHandler;

public interface WrappedMessageHandler {
  long getMaxMessageSize();
  
  MessageHandler getWrappedHandler();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WrappedMessageHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */