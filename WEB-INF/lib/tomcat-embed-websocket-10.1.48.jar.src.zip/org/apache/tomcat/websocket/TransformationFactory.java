/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.Extension;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformationFactory
/*    */ {
/* 30 */   private static final TransformationFactory factory = new TransformationFactory();
/*    */   
/* 32 */   private Map<String, TransformationBuilder> builders = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private TransformationFactory() {
/* 39 */     this.builders.put("permessage-deflate", PerMessageDeflate.BUILDER);
/*    */   }
/*    */ 
/*    */   
/*    */   public static TransformationFactory getInstance() {
/* 44 */     return factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Transformation create(String name, List<List<Extension.Parameter>> preferences, boolean isServer) {
/* 49 */     TransformationBuilder builder = this.builders.get(name);
/* 50 */     if (builder != null) {
/* 51 */       return builder.build(preferences, isServer);
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerExtension(String name, TransformationBuilder builder) {
/* 58 */     this.builders.put(name, builder);
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<String> getInstalledExtensionNames() {
/* 63 */     return new HashSet<>(this.builders.keySet());
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Extension> getInstalledExtensions() {
/* 68 */     Set<Extension> result = new HashSet<>();
/* 69 */     for (String extensionName : this.builders.keySet()) {
/* 70 */       result.add(new WsExtension(extensionName));
/*    */     }
/* 72 */     return Collections.unmodifiableSet(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\TransformationFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */