/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.RemoteEndpoint;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WsRemoteEndpointBase
/*    */   implements RemoteEndpoint
/*    */ {
/*    */   protected final WsRemoteEndpointImplBase base;
/*    */   
/*    */   WsRemoteEndpointBase(WsRemoteEndpointImplBase base) {
/* 30 */     this.base = base;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setBatchingAllowed(boolean batchingAllowed) throws IOException {
/* 36 */     this.base.setBatchingAllowed(batchingAllowed);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean getBatchingAllowed() {
/* 42 */     return this.base.getBatchingAllowed();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void flushBatch() throws IOException {
/* 48 */     this.base.flushBatch();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void sendPing(ByteBuffer applicationData) throws IOException, IllegalArgumentException {
/* 54 */     this.base.sendPing(applicationData);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void sendPong(ByteBuffer applicationData) throws IOException, IllegalArgumentException {
/* 60 */     this.base.sendPong(applicationData);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\WsRemoteEndpointBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */