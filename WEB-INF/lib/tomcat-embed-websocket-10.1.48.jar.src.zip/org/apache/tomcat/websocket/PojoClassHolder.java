/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import jakarta.websocket.ClientEndpointConfig;
/*    */ import jakarta.websocket.DeploymentException;
/*    */ import jakarta.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.pojo.PojoEndpointClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoClassHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 31 */   private static final StringManager sm = StringManager.getManager(PojoClassHolder.class);
/*    */   
/*    */   private final Class<?> pojoClazz;
/*    */   
/*    */   private final ClientEndpointConfig clientEndpointConfig;
/*    */   
/*    */   public PojoClassHolder(Class<?> pojoClazz, ClientEndpointConfig clientEndpointConfig) {
/* 38 */     this.pojoClazz = pojoClazz;
/* 39 */     this.clientEndpointConfig = clientEndpointConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 45 */     return this.pojoClazz.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException {
/*    */     try {
/*    */       Object pojo;
/* 52 */       if (instanceManager == null) {
/* 53 */         pojo = this.pojoClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       } else {
/* 55 */         pojo = instanceManager.newInstance(this.pojoClazz);
/*    */       } 
/* 57 */       return (Endpoint)new PojoEndpointClient(pojo, this.clientEndpointConfig.getDecoders(), instanceManager);
/* 58 */     } catch (ReflectiveOperationException|SecurityException|javax.naming.NamingException e) {
/* 59 */       throw new DeploymentException(sm.getString("clientEndpointHolder.instanceCreationFailed"), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\org\apache\tomcat\websocket\PojoClassHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */