package jakarta.websocket;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.util.concurrent.Future;

public interface RemoteEndpoint {
  void setBatchingAllowed(boolean paramBoolean) throws IOException;
  
  boolean getBatchingAllowed();
  
  void flushBatch() throws IOException;
  
  void sendPing(ByteBuffer paramByteBuffer) throws IOException, IllegalArgumentException;
  
  void sendPong(ByteBuffer paramByteBuffer) throws IOException, IllegalArgumentException;
  
  public static interface Basic extends RemoteEndpoint {
    void sendText(String param1String) throws IOException;
    
    void sendBinary(ByteBuffer param1ByteBuffer) throws IOException;
    
    void sendText(String param1String, boolean param1Boolean) throws IOException;
    
    void sendBinary(ByteBuffer param1ByteBuffer, boolean param1Boolean) throws IOException;
    
    OutputStream getSendStream() throws IOException;
    
    Writer getSendWriter() throws IOException;
    
    void sendObject(Object param1Object) throws IOException, EncodeException;
  }
  
  public static interface Async extends RemoteEndpoint {
    long getSendTimeout();
    
    void setSendTimeout(long param1Long);
    
    void sendText(String param1String, SendHandler param1SendHandler);
    
    Future<Void> sendText(String param1String);
    
    Future<Void> sendBinary(ByteBuffer param1ByteBuffer);
    
    void sendBinary(ByteBuffer param1ByteBuffer, SendHandler param1SendHandler);
    
    Future<Void> sendObject(Object param1Object);
    
    void sendObject(Object param1Object, SendHandler param1SendHandler);
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\RemoteEndpoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */