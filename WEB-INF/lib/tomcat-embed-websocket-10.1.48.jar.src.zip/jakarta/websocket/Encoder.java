package jakarta.websocket;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.ByteBuffer;

public interface Encoder {
  default void init(EndpointConfig endpointConfig) {}
  
  default void destroy() {}
  
  public static interface BinaryStream<T> extends Encoder {
    void encode(T param1T, OutputStream param1OutputStream) throws EncodeException, IOException;
  }
  
  public static interface Binary<T> extends Encoder {
    ByteBuffer encode(T param1T) throws EncodeException;
  }
  
  public static interface TextStream<T> extends Encoder {
    void encode(T param1T, Writer param1Writer) throws EncodeException, IOException;
  }
  
  public static interface Text<T> extends Encoder {
    String encode(T param1T) throws EncodeException;
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\Encoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */