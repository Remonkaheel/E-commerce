/*    */ package jakarta.websocket;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContainerProvider
/*    */ {
/*    */   private static final String DEFAULT_PROVIDER_CLASS_NAME = "org.apache.tomcat.websocket.WsWebSocketContainer";
/*    */   
/*    */   public static WebSocketContainer getWebSocketContainer() {
/* 35 */     WebSocketContainer result = null;
/*    */     
/* 37 */     ServiceLoader<ContainerProvider> serviceLoader = ServiceLoader.load(ContainerProvider.class);
/* 38 */     Iterator<ContainerProvider> iter = serviceLoader.iterator();
/* 39 */     while (result == null && iter.hasNext()) {
/* 40 */       result = ((ContainerProvider)iter.next()).getContainer();
/*    */     }
/*    */ 
/*    */     
/* 44 */     if (result == null) {
/*    */       
/*    */       try {
/*    */         
/* 48 */         Class<WebSocketContainer> clazz = (Class)Class.forName("org.apache.tomcat.websocket.WsWebSocketContainer");
/* 49 */         result = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 50 */       } catch (ReflectiveOperationException|IllegalArgumentException|SecurityException reflectiveOperationException) {}
/*    */     }
/*    */ 
/*    */     
/* 54 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract WebSocketContainer getContainer();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\ContainerProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */