/*     */ package jakarta.websocket;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.SSLContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ClientEndpointConfig
/*     */   extends EndpointConfig
/*     */ {
/*     */   List<String> getPreferredSubprotocols();
/*     */   
/*     */   List<Extension> getExtensions();
/*     */   
/*     */   SSLContext getSSLContext();
/*     */   
/*     */   Configurator getConfigurator();
/*     */   
/*     */   class null
/*     */     extends Configurator {}
/*     */   
/*     */   public static final class Builder
/*     */   {
/*  37 */     private static final ClientEndpointConfig.Configurator DEFAULT_CONFIGURATOR = new ClientEndpointConfig.Configurator() {  }
/*     */     ;
/*     */     private ClientEndpointConfig.Configurator configurator;
/*     */     
/*     */     public static Builder create() {
/*  42 */       return new Builder();
/*     */     }
/*     */     private List<String> preferredSubprotocols; private List<Extension> extensions;
/*     */     private List<Class<? extends Encoder>> encoders;
/*     */     private List<Class<? extends Decoder>> decoders;
/*     */     private SSLContext sslContext;
/*     */     
/*     */     private Builder() {
/*  50 */       this.configurator = DEFAULT_CONFIGURATOR;
/*  51 */       this.preferredSubprotocols = Collections.emptyList();
/*  52 */       this.extensions = Collections.emptyList();
/*  53 */       this.encoders = Collections.emptyList();
/*  54 */       this.decoders = Collections.emptyList();
/*  55 */       this.sslContext = null;
/*     */     }
/*     */     public ClientEndpointConfig build() {
/*  58 */       return new DefaultClientEndpointConfig(this.preferredSubprotocols, this.extensions, this.encoders, this.decoders, this.sslContext, this.configurator);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder configurator(ClientEndpointConfig.Configurator configurator) {
/*  64 */       if (configurator == null) {
/*  65 */         this.configurator = DEFAULT_CONFIGURATOR;
/*     */       } else {
/*  67 */         this.configurator = configurator;
/*     */       } 
/*  69 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder preferredSubprotocols(List<String> preferredSubprotocols) {
/*  74 */       if (preferredSubprotocols == null || preferredSubprotocols.size() == 0) {
/*  75 */         this.preferredSubprotocols = Collections.emptyList();
/*     */       } else {
/*  77 */         this.preferredSubprotocols = Collections.unmodifiableList(preferredSubprotocols);
/*     */       } 
/*  79 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder extensions(List<Extension> extensions) {
/*  84 */       if (extensions == null || extensions.size() == 0) {
/*  85 */         this.extensions = Collections.emptyList();
/*     */       } else {
/*  87 */         this.extensions = Collections.unmodifiableList(extensions);
/*     */       } 
/*  89 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder encoders(List<Class<? extends Encoder>> encoders) {
/*  94 */       if (encoders == null || encoders.size() == 0) {
/*  95 */         this.encoders = Collections.emptyList();
/*     */       } else {
/*  97 */         this.encoders = Collections.unmodifiableList(encoders);
/*     */       } 
/*  99 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder decoders(List<Class<? extends Decoder>> decoders) {
/* 104 */       if (decoders == null || decoders.size() == 0) {
/* 105 */         this.decoders = Collections.emptyList();
/*     */       } else {
/* 107 */         this.decoders = Collections.unmodifiableList(decoders);
/*     */       } 
/* 109 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder sslContext(SSLContext sslContext) {
/* 114 */       this.sslContext = sslContext;
/* 115 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Configurator {
/*     */     public void beforeRequest(Map<String, List<String>> headers) {}
/*     */     
/*     */     public void afterResponse(HandshakeResponse handshakeResponse) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\ClientEndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */