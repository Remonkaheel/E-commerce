package jakarta.websocket;

public interface MessageHandler {
  public static interface Whole<T> extends MessageHandler {
    void onMessage(T param1T);
  }
  
  public static interface Partial<T> extends MessageHandler {
    void onMessage(T param1T, boolean param1Boolean);
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\MessageHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */