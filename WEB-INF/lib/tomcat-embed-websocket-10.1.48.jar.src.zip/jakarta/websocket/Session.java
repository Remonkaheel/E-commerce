package jakarta.websocket;

import java.io.Closeable;
import java.io.IOException;
import java.net.URI;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface Session extends Closeable {
  WebSocketContainer getContainer();
  
  void addMessageHandler(MessageHandler paramMessageHandler) throws IllegalStateException;
  
  Set<MessageHandler> getMessageHandlers();
  
  void removeMessageHandler(MessageHandler paramMessageHandler);
  
  String getProtocolVersion();
  
  String getNegotiatedSubprotocol();
  
  List<Extension> getNegotiatedExtensions();
  
  boolean isSecure();
  
  boolean isOpen();
  
  long getMaxIdleTimeout();
  
  void setMaxIdleTimeout(long paramLong);
  
  void setMaxBinaryMessageBufferSize(int paramInt);
  
  int getMaxBinaryMessageBufferSize();
  
  void setMaxTextMessageBufferSize(int paramInt);
  
  int getMaxTextMessageBufferSize();
  
  RemoteEndpoint.Async getAsyncRemote();
  
  RemoteEndpoint.Basic getBasicRemote();
  
  String getId();
  
  void close() throws IOException;
  
  void close(CloseReason paramCloseReason) throws IOException;
  
  URI getRequestURI();
  
  Map<String, List<String>> getRequestParameterMap();
  
  String getQueryString();
  
  Map<String, String> getPathParameters();
  
  Map<String, Object> getUserProperties();
  
  Principal getUserPrincipal();
  
  Set<Session> getOpenSessions();
  
  <T> void addMessageHandler(Class<T> paramClass, MessageHandler.Partial<T> paramPartial) throws IllegalStateException;
  
  <T> void addMessageHandler(Class<T> paramClass, MessageHandler.Whole<T> paramWhole) throws IllegalStateException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\Session.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */