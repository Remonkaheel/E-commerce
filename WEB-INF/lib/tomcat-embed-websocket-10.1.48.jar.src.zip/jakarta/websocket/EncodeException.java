/*    */ package jakarta.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Object object;
/*    */   
/*    */   public EncodeException(Object object, String message) {
/* 26 */     super(message);
/* 27 */     this.object = object;
/*    */   }
/*    */   
/*    */   public EncodeException(Object object, String message, Throwable cause) {
/* 31 */     super(message, cause);
/* 32 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 36 */     return this.object;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\EncodeException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */