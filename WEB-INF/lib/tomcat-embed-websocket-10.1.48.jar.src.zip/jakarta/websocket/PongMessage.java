package jakarta.websocket;

import java.nio.ByteBuffer;

public interface PongMessage {
  ByteBuffer getApplicationData();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\PongMessage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */