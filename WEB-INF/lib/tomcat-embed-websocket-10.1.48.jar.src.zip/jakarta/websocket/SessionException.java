/*    */ package jakarta.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Session session;
/*    */   
/*    */   public SessionException(String message, Throwable cause, Session session) {
/* 27 */     super(message, cause);
/* 28 */     this.session = session;
/*    */   }
/*    */ 
/*    */   
/*    */   public Session getSession() {
/* 33 */     return this.session;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\SessionException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */