/*    */ package jakarta.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SendResult
/*    */ {
/*    */   private final Throwable exception;
/*    */   private final boolean ok;
/*    */   
/*    */   public SendResult(Throwable exception) {
/* 24 */     this.exception = exception;
/* 25 */     this.ok = (exception == null);
/*    */   }
/*    */   
/*    */   public SendResult() {
/* 29 */     this(null);
/*    */   }
/*    */   
/*    */   public Throwable getException() {
/* 33 */     return this.exception;
/*    */   }
/*    */   
/*    */   public boolean isOK() {
/* 37 */     return this.ok;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\SendResult.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */