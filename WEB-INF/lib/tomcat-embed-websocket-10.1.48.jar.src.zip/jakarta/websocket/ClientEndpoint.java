package jakarta.websocket;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ClientEndpoint {
  String[] subprotocols() default {};
  
  Class<? extends Decoder>[] decoders() default {};
  
  Class<? extends Encoder>[] encoders() default {};
  
  Class<? extends ClientEndpointConfig.Configurator> configurator() default ClientEndpointConfig.Configurator.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\ClientEndpoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */