package jakarta.websocket.server;

import jakarta.websocket.Decoder;
import jakarta.websocket.Encoder;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ServerEndpoint {
  String value();
  
  String[] subprotocols() default {};
  
  Class<? extends Decoder>[] decoders() default {};
  
  Class<? extends Encoder>[] encoders() default {};
  
  Class<? extends ServerEndpointConfig.Configurator> configurator() default ServerEndpointConfig.Configurator.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\server\ServerEndpoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */