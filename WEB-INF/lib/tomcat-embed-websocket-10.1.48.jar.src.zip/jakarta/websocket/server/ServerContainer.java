package jakarta.websocket.server;

import jakarta.websocket.DeploymentException;
import jakarta.websocket.WebSocketContainer;
import java.io.IOException;
import java.util.Map;

public interface ServerContainer extends WebSocketContainer {
  void addEndpoint(Class<?> paramClass) throws DeploymentException;
  
  void addEndpoint(ServerEndpointConfig paramServerEndpointConfig) throws DeploymentException;
  
  void upgradeHttpToWebSocket(Object paramObject1, Object paramObject2, ServerEndpointConfig paramServerEndpointConfig, Map<String, String> paramMap) throws IOException, DeploymentException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\server\ServerContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */