/*     */ package jakarta.websocket.server;
/*     */ 
/*     */ import jakarta.websocket.Decoder;
/*     */ import jakarta.websocket.Encoder;
/*     */ import jakarta.websocket.EndpointConfig;
/*     */ import jakarta.websocket.Extension;
/*     */ import jakarta.websocket.HandshakeResponse;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ServiceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ServerEndpointConfig
/*     */   extends EndpointConfig
/*     */ {
/*     */   Class<?> getEndpointClass();
/*     */   
/*     */   String getPath();
/*     */   
/*     */   List<String> getSubprotocols();
/*     */   
/*     */   List<Extension> getExtensions();
/*     */   
/*     */   Configurator getConfigurator();
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final Class<?> endpointClass;
/*     */     private final String path;
/*     */     
/*     */     public static Builder create(Class<?> endpointClass, String path) {
/*  58 */       return new Builder(endpointClass, path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     private List<Class<? extends Encoder>> encoders = Collections.emptyList();
/*  65 */     private List<Class<? extends Decoder>> decoders = Collections.emptyList();
/*  66 */     private List<String> subprotocols = Collections.emptyList();
/*  67 */     private List<Extension> extensions = Collections.emptyList();
/*  68 */     private ServerEndpointConfig.Configurator configurator = ServerEndpointConfig.Configurator.fetchContainerDefaultConfigurator();
/*     */ 
/*     */     
/*     */     private Builder(Class<?> endpointClass, String path) {
/*  72 */       if (endpointClass == null) {
/*  73 */         throw new IllegalArgumentException("Endpoint class may not be null");
/*     */       }
/*  75 */       if (path == null) {
/*  76 */         throw new IllegalArgumentException("Path may not be null");
/*     */       }
/*  78 */       if (path.isEmpty()) {
/*  79 */         throw new IllegalArgumentException("Path may not be empty");
/*     */       }
/*  81 */       if (path.charAt(0) != '/') {
/*  82 */         throw new IllegalArgumentException("Path must start with '/'");
/*     */       }
/*  84 */       this.endpointClass = endpointClass;
/*  85 */       this.path = path;
/*     */     }
/*     */     
/*     */     public ServerEndpointConfig build() {
/*  89 */       return new DefaultServerEndpointConfig(this.endpointClass, this.path, this.subprotocols, this.extensions, this.encoders, this.decoders, this.configurator);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder encoders(List<Class<? extends Encoder>> encoders) {
/*  95 */       if (encoders == null || encoders.size() == 0) {
/*  96 */         this.encoders = Collections.emptyList();
/*     */       } else {
/*  98 */         this.encoders = Collections.unmodifiableList(encoders);
/*     */       } 
/* 100 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder decoders(List<Class<? extends Decoder>> decoders) {
/* 105 */       if (decoders == null || decoders.size() == 0) {
/* 106 */         this.decoders = Collections.emptyList();
/*     */       } else {
/* 108 */         this.decoders = Collections.unmodifiableList(decoders);
/*     */       } 
/* 110 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder subprotocols(List<String> subprotocols) {
/* 115 */       if (subprotocols == null || subprotocols.size() == 0) {
/* 116 */         this.subprotocols = Collections.emptyList();
/*     */       } else {
/* 118 */         this.subprotocols = Collections.unmodifiableList(subprotocols);
/*     */       } 
/* 120 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder extensions(List<Extension> extensions) {
/* 125 */       if (extensions == null || extensions.size() == 0) {
/* 126 */         this.extensions = Collections.emptyList();
/*     */       } else {
/* 128 */         this.extensions = Collections.unmodifiableList(extensions);
/*     */       } 
/* 130 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder configurator(ServerEndpointConfig.Configurator serverEndpointConfigurator) {
/* 135 */       if (serverEndpointConfigurator == null) {
/* 136 */         this.configurator = ServerEndpointConfig.Configurator.fetchContainerDefaultConfigurator();
/*     */       } else {
/* 138 */         this.configurator = serverEndpointConfigurator;
/*     */       } 
/* 140 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Configurator
/*     */   {
/* 147 */     private static volatile Configurator defaultImpl = null;
/* 148 */     private static final Object defaultImplLock = new Object();
/*     */     
/*     */     private static final String DEFAULT_IMPL_CLASSNAME = "org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator";
/*     */ 
/*     */     
/*     */     static Configurator fetchContainerDefaultConfigurator() {
/* 154 */       if (defaultImpl == null) {
/* 155 */         synchronized (defaultImplLock) {
/* 156 */           if (defaultImpl == null) {
/* 157 */             if (System.getSecurityManager() == null) {
/* 158 */               defaultImpl = loadDefault();
/*     */             } else {
/* 160 */               defaultImpl = AccessController.<Configurator>doPrivileged(new PrivilegedLoadDefault());
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/* 165 */       return defaultImpl;
/*     */     }
/*     */ 
/*     */     
/*     */     private static Configurator loadDefault() {
/* 170 */       Configurator result = null;
/*     */       
/* 172 */       ServiceLoader<Configurator> serviceLoader = ServiceLoader.load(Configurator.class);
/*     */       
/* 174 */       Iterator<Configurator> iter = serviceLoader.iterator();
/* 175 */       while (result == null && iter.hasNext()) {
/* 176 */         result = iter.next();
/*     */       }
/*     */ 
/*     */       
/* 180 */       if (result == null) {
/*     */         
/*     */         try {
/* 183 */           Class<Configurator> clazz = (Class)Class.forName("org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator");
/* 184 */           result = clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 185 */         } catch (ReflectiveOperationException|IllegalArgumentException|SecurityException reflectiveOperationException) {}
/*     */       }
/*     */ 
/*     */       
/* 189 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private static class PrivilegedLoadDefault
/*     */       implements PrivilegedAction<Configurator>
/*     */     {
/*     */       public ServerEndpointConfig.Configurator run() {
/* 197 */         return ServerEndpointConfig.Configurator.loadDefault();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Configurator getContainerDefaultConfigurator() {
/* 210 */       return fetchContainerDefaultConfigurator();
/*     */     }
/*     */     
/*     */     public String getNegotiatedSubprotocol(List<String> supported, List<String> requested) {
/* 214 */       return fetchContainerDefaultConfigurator().getNegotiatedSubprotocol(supported, requested);
/*     */     }
/*     */     
/*     */     public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested) {
/* 218 */       return fetchContainerDefaultConfigurator().getNegotiatedExtensions(installed, requested);
/*     */     }
/*     */     
/*     */     public boolean checkOrigin(String originHeaderValue) {
/* 222 */       return fetchContainerDefaultConfigurator().checkOrigin(originHeaderValue);
/*     */     }
/*     */     
/*     */     public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
/* 226 */       fetchContainerDefaultConfigurator().modifyHandshake(sec, request, response);
/*     */     }
/*     */     
/*     */     public <T> T getEndpointInstance(Class<T> clazz) throws InstantiationException {
/* 230 */       return fetchContainerDefaultConfigurator().getEndpointInstance(clazz);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedLoadDefault implements PrivilegedAction<Configurator> {
/*     */     public ServerEndpointConfig.Configurator run() {
/*     */       return ServerEndpointConfig.Configurator.loadDefault();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\server\ServerEndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */