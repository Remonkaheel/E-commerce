/*    */ package jakarta.websocket.server;
/*    */ 
/*    */ import jakarta.websocket.Decoder;
/*    */ import jakarta.websocket.Encoder;
/*    */ import jakarta.websocket.Extension;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultServerEndpointConfig
/*    */   implements ServerEndpointConfig
/*    */ {
/*    */   private final Class<?> endpointClass;
/*    */   private final String path;
/*    */   private final List<String> subprotocols;
/*    */   private final List<Extension> extensions;
/*    */   private final List<Class<? extends Encoder>> encoders;
/*    */   private final List<Class<? extends Decoder>> decoders;
/*    */   private final ServerEndpointConfig.Configurator serverEndpointConfigurator;
/* 39 */   private final Map<String, Object> userProperties = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   DefaultServerEndpointConfig(Class<?> endpointClass, String path, List<String> subprotocols, List<Extension> extensions, List<Class<? extends Encoder>> encoders, List<Class<? extends Decoder>> decoders, ServerEndpointConfig.Configurator serverEndpointConfigurator) {
/* 44 */     this.endpointClass = endpointClass;
/* 45 */     this.path = path;
/* 46 */     this.subprotocols = subprotocols;
/* 47 */     this.extensions = extensions;
/* 48 */     this.encoders = encoders;
/* 49 */     this.decoders = decoders;
/* 50 */     this.serverEndpointConfigurator = serverEndpointConfigurator;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getEndpointClass() {
/* 55 */     return this.endpointClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Class<? extends Encoder>> getEncoders() {
/* 60 */     return this.encoders;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Class<? extends Decoder>> getDecoders() {
/* 65 */     return this.decoders;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPath() {
/* 70 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerEndpointConfig.Configurator getConfigurator() {
/* 75 */     return this.serverEndpointConfigurator;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getUserProperties() {
/* 80 */     return this.userProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getSubprotocols() {
/* 85 */     return this.subprotocols;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Extension> getExtensions() {
/* 90 */     return this.extensions;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\server\DefaultServerEndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */