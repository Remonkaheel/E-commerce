package jakarta.websocket.server;

import jakarta.websocket.Endpoint;
import java.util.Set;

public interface ServerApplicationConfig {
  Set<ServerEndpointConfig> getEndpointConfigs(Set<Class<? extends Endpoint>> paramSet);
  
  Set<Class<?>> getAnnotatedEndpointClasses(Set<Class<?>> paramSet);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\server\ServerApplicationConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */