/*    */ package jakarta.websocket;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecodeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private ByteBuffer bb;
/*    */   private String encodedString;
/*    */   
/*    */   public DecodeException(ByteBuffer bb, String message, Throwable cause) {
/* 29 */     super(message, cause);
/* 30 */     this.bb = bb;
/*    */   }
/*    */   
/*    */   public DecodeException(String encodedString, String message, Throwable cause) {
/* 34 */     super(message, cause);
/* 35 */     this.encodedString = encodedString;
/*    */   }
/*    */   
/*    */   public DecodeException(ByteBuffer bb, String message) {
/* 39 */     super(message);
/* 40 */     this.bb = bb;
/*    */   }
/*    */   
/*    */   public DecodeException(String encodedString, String message) {
/* 44 */     super(message);
/* 45 */     this.encodedString = encodedString;
/*    */   }
/*    */   
/*    */   public ByteBuffer getBytes() {
/* 49 */     return this.bb;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 53 */     return this.encodedString;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\DecodeException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */