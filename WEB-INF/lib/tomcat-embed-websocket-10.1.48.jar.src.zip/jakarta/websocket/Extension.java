package jakarta.websocket;

import java.util.List;

public interface Extension {
  String getName();
  
  List<Parameter> getParameters();
  
  public static interface Parameter {
    String getName();
    
    String getValue();
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\Extension.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */