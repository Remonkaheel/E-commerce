/*    */ package jakarta.websocket;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import javax.net.ssl.SSLContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultClientEndpointConfig
/*    */   implements ClientEndpointConfig
/*    */ {
/*    */   private final List<String> preferredSubprotocols;
/*    */   private final List<Extension> extensions;
/*    */   private final List<Class<? extends Encoder>> encoders;
/*    */   private final List<Class<? extends Decoder>> decoders;
/*    */   private final SSLContext sslContext;
/* 32 */   private final Map<String, Object> userProperties = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   private final ClientEndpointConfig.Configurator configurator;
/*    */ 
/*    */   
/*    */   DefaultClientEndpointConfig(List<String> preferredSubprotocols, List<Extension> extensions, List<Class<? extends Encoder>> encoders, List<Class<? extends Decoder>> decoders, SSLContext sslContext, ClientEndpointConfig.Configurator configurator) {
/* 39 */     this.preferredSubprotocols = preferredSubprotocols;
/* 40 */     this.extensions = extensions;
/* 41 */     this.encoders = encoders;
/* 42 */     this.decoders = decoders;
/* 43 */     this.sslContext = sslContext;
/* 44 */     this.configurator = configurator;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getPreferredSubprotocols() {
/* 50 */     return this.preferredSubprotocols;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Extension> getExtensions() {
/* 56 */     return this.extensions;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Class<? extends Encoder>> getEncoders() {
/* 62 */     return this.encoders;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Class<? extends Decoder>> getDecoders() {
/* 68 */     return this.decoders;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SSLContext getSSLContext() {
/* 74 */     return this.sslContext;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getUserProperties() {
/* 80 */     return this.userProperties;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientEndpointConfig.Configurator getConfigurator() {
/* 86 */     return this.configurator;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\DefaultClientEndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */