package jakarta.websocket;

import java.util.List;
import java.util.Map;

public interface HandshakeResponse {
  public static final String SEC_WEBSOCKET_ACCEPT = "Sec-WebSocket-Accept";
  
  Map<String, List<String>> getHeaders();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\HandshakeResponse.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */