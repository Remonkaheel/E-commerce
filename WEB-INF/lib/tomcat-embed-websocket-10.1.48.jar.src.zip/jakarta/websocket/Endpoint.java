package jakarta.websocket;

public abstract class Endpoint {
  public abstract void onOpen(Session paramSession, EndpointConfig paramEndpointConfig);
  
  public void onClose(Session session, CloseReason closeReason) {}
  
  public void onError(Session session, Throwable throwable) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\Endpoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */