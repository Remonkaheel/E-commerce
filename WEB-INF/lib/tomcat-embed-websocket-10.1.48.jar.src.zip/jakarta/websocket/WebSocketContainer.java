package jakarta.websocket;

import java.io.IOException;
import java.net.URI;
import java.util.Set;

public interface WebSocketContainer {
  long getDefaultAsyncSendTimeout();
  
  void setAsyncSendTimeout(long paramLong);
  
  Session connectToServer(Object paramObject, URI paramURI) throws DeploymentException, IOException;
  
  Session connectToServer(Class<?> paramClass, URI paramURI) throws DeploymentException, IOException;
  
  Session connectToServer(Endpoint paramEndpoint, ClientEndpointConfig paramClientEndpointConfig, URI paramURI) throws DeploymentException, IOException;
  
  Session connectToServer(Class<? extends Endpoint> paramClass, ClientEndpointConfig paramClientEndpointConfig, URI paramURI) throws DeploymentException, IOException;
  
  long getDefaultMaxSessionIdleTimeout();
  
  void setDefaultMaxSessionIdleTimeout(long paramLong);
  
  int getDefaultMaxBinaryMessageBufferSize();
  
  void setDefaultMaxBinaryMessageBufferSize(int paramInt);
  
  int getDefaultMaxTextMessageBufferSize();
  
  void setDefaultMaxTextMessageBufferSize(int paramInt);
  
  Set<Extension> getInstalledExtensions();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\WebSocketContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */