/*    */ package jakarta.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeploymentException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DeploymentException(String message) {
/* 24 */     super(message);
/*    */   }
/*    */   
/*    */   public DeploymentException(String message, Throwable cause) {
/* 28 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\DeploymentException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */