package jakarta.websocket;

public interface SendHandler {
  void onResult(SendResult paramSendResult);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\SendHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */