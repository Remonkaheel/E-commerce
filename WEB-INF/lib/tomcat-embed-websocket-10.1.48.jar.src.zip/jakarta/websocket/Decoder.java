package jakarta.websocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.ByteBuffer;

public interface Decoder {
  default void init(EndpointConfig endpointConfig) {}
  
  default void destroy() {}
  
  public static interface TextStream<T> extends Decoder {
    T decode(Reader param1Reader) throws DecodeException, IOException;
  }
  
  public static interface Text<T> extends Decoder {
    T decode(String param1String) throws DecodeException;
    
    boolean willDecode(String param1String);
  }
  
  public static interface BinaryStream<T> extends Decoder {
    T decode(InputStream param1InputStream) throws DecodeException, IOException;
  }
  
  public static interface Binary<T> extends Decoder {
    T decode(ByteBuffer param1ByteBuffer) throws DecodeException;
    
    boolean willDecode(ByteBuffer param1ByteBuffer);
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\Decoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */