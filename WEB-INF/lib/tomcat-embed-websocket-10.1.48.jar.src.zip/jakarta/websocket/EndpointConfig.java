package jakarta.websocket;

import java.util.List;
import java.util.Map;

public interface EndpointConfig {
  List<Class<? extends Encoder>> getEncoders();
  
  List<Class<? extends Decoder>> getDecoders();
  
  Map<String, Object> getUserProperties();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-websocket-10.1.48.jar!\jakarta\websocket\EndpointConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */