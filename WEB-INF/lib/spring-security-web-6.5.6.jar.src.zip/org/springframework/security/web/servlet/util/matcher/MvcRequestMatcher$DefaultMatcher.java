/*     */ package org.springframework.security.web.servlet.util.matcher;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Map;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultMatcher
/*     */   implements RequestMatcher
/*     */ {
/* 169 */   private final UrlPathHelper pathHelper = new UrlPathHelper();
/*     */   
/* 171 */   private final PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*     */ 
/*     */   
/*     */   public boolean matches(HttpServletRequest request) {
/* 175 */     String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 176 */     return matches(lookupPath);
/*     */   }
/*     */   
/*     */   private boolean matches(String lookupPath) {
/* 180 */     return this.pathMatcher.match(MvcRequestMatcher.this.pattern, lookupPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 185 */     String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 186 */     if (matches(lookupPath)) {
/*     */       
/* 188 */       Map<String, String> variables = this.pathMatcher.extractUriTemplateVariables(MvcRequestMatcher.this.pattern, lookupPath);
/* 189 */       return RequestMatcher.MatchResult.match(variables);
/*     */     } 
/* 191 */     return RequestMatcher.MatchResult.notMatch();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servle\\util\matcher\MvcRequestMatcher$DefaultMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */