/*    */ package org.springframework.security.web.servlet.support.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.springframework.security.web.csrf.CsrfToken;
/*    */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CsrfRequestDataValueProcessor
/*    */   implements RequestDataValueProcessor
/*    */ {
/* 38 */   private Pattern DISABLE_CSRF_TOKEN_PATTERN = Pattern.compile("(?i)^(GET|HEAD|TRACE|OPTIONS)$");
/*    */   
/* 40 */   private String DISABLE_CSRF_TOKEN_ATTR = "DISABLE_CSRF_TOKEN_ATTR";
/*    */   
/*    */   public String processAction(HttpServletRequest request, String action) {
/* 43 */     return action;
/*    */   }
/*    */ 
/*    */   
/*    */   public String processAction(HttpServletRequest request, String action, String method) {
/* 48 */     if (method != null && this.DISABLE_CSRF_TOKEN_PATTERN.matcher(method).matches()) {
/* 49 */       request.setAttribute(this.DISABLE_CSRF_TOKEN_ATTR, Boolean.TRUE);
/*    */     } else {
/*    */       
/* 52 */       request.removeAttribute(this.DISABLE_CSRF_TOKEN_ATTR);
/*    */     } 
/* 54 */     return action;
/*    */   }
/*    */ 
/*    */   
/*    */   public String processFormFieldValue(HttpServletRequest request, String name, String value, String type) {
/* 59 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getExtraHiddenFields(HttpServletRequest request) {
/* 64 */     if (Boolean.TRUE.equals(request.getAttribute(this.DISABLE_CSRF_TOKEN_ATTR))) {
/* 65 */       request.removeAttribute(this.DISABLE_CSRF_TOKEN_ATTR);
/* 66 */       return Collections.emptyMap();
/*    */     } 
/* 68 */     CsrfToken token = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/* 69 */     if (token == null) {
/* 70 */       return Collections.emptyMap();
/*    */     }
/* 72 */     Map<String, String> hiddenFields = new HashMap<>(1);
/* 73 */     hiddenFields.put(token.getParameterName(), token.getToken());
/* 74 */     return hiddenFields;
/*    */   }
/*    */ 
/*    */   
/*    */   public String processUrl(HttpServletRequest request, String url) {
/* 79 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servlet\support\csrf\CsrfRequestDataValueProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */