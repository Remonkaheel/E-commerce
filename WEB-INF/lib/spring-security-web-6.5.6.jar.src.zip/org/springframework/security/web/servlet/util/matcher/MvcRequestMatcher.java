/*     */ package org.springframework.security.web.servlet.util.matcher;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestVariablesExtractor;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*     */ import org.springframework.web.servlet.handler.MatchableHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.RequestMatchResult;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(forRemoval = true)
/*     */ public class MvcRequestMatcher
/*     */   implements RequestMatcher, RequestVariablesExtractor
/*     */ {
/*  54 */   private final DefaultMatcher defaultMatcher = new DefaultMatcher();
/*     */   
/*     */   private final HandlerMappingIntrospector introspector;
/*     */   
/*     */   private final String pattern;
/*     */   
/*     */   private HttpMethod method;
/*     */   
/*     */   private String servletPath;
/*     */   
/*     */   public MvcRequestMatcher(HandlerMappingIntrospector introspector, String pattern) {
/*  65 */     this.introspector = introspector;
/*  66 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(HttpServletRequest request) {
/*  71 */     if (notMatchMethodOrServletPath(request)) {
/*  72 */       return false;
/*     */     }
/*  74 */     MatchableHandlerMapping mapping = getMapping(request);
/*  75 */     if (mapping == null) {
/*  76 */       return this.defaultMatcher.matches(request);
/*     */     }
/*  78 */     RequestMatchResult matchResult = mapping.match(request, this.pattern);
/*  79 */     return (matchResult != null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Map<String, String> extractUriTemplateVariables(HttpServletRequest request) {
/*  85 */     return matcher(request).getVariables();
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/*  90 */     if (notMatchMethodOrServletPath(request)) {
/*  91 */       return RequestMatcher.MatchResult.notMatch();
/*     */     }
/*  93 */     MatchableHandlerMapping mapping = getMapping(request);
/*  94 */     if (mapping == null) {
/*  95 */       return this.defaultMatcher.matcher(request);
/*     */     }
/*  97 */     RequestMatchResult result = mapping.match(request, this.pattern);
/*  98 */     return (result != null) ? RequestMatcher.MatchResult.match(result.extractUriTemplateVariables()) : RequestMatcher.MatchResult.notMatch();
/*     */   }
/*     */   
/*     */   private boolean notMatchMethodOrServletPath(HttpServletRequest request) {
/* 102 */     return ((this.method != null && !this.method.name().equals(request.getMethod())) || (this.servletPath != null && 
/* 103 */       !this.servletPath.equals(request.getServletPath())));
/*     */   }
/*     */   
/*     */   private MatchableHandlerMapping getMapping(HttpServletRequest request) {
/*     */     try {
/* 108 */       return this.introspector.getMatchableHandlerMapping(request);
/*     */     }
/* 110 */     catch (Throwable ex) {
/* 111 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethod(HttpMethod method) {
/* 119 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServletPath(String servletPath) {
/* 128 */     this.servletPath = servletPath;
/*     */   }
/*     */   
/*     */   protected final String getServletPath() {
/* 132 */     return this.servletPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 137 */     if (this == o) {
/* 138 */       return true;
/*     */     }
/* 140 */     if (o == null || getClass() != o.getClass()) {
/* 141 */       return false;
/*     */     }
/* 143 */     MvcRequestMatcher that = (MvcRequestMatcher)o;
/* 144 */     return (Objects.equals(this.pattern, that.pattern) && Objects.equals(this.method, that.method) && 
/* 145 */       Objects.equals(this.servletPath, that.servletPath));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 150 */     return Objects.hash(new Object[] { this.pattern, this.method, this.servletPath });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     StringBuilder sb = new StringBuilder();
/* 156 */     sb.append("Mvc [pattern='").append(this.pattern).append("'");
/* 157 */     if (this.servletPath != null) {
/* 158 */       sb.append(", servletPath='").append(this.servletPath).append("'");
/*     */     }
/* 160 */     if (this.method != null) {
/* 161 */       sb.append(", ").append(this.method);
/*     */     }
/* 163 */     sb.append("]");
/* 164 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private class DefaultMatcher
/*     */     implements RequestMatcher {
/* 169 */     private final UrlPathHelper pathHelper = new UrlPathHelper();
/*     */     
/* 171 */     private final PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 175 */       String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 176 */       return matches(lookupPath);
/*     */     }
/*     */     
/*     */     private boolean matches(String lookupPath) {
/* 180 */       return this.pathMatcher.match(MvcRequestMatcher.this.pattern, lookupPath);
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 185 */       String lookupPath = this.pathHelper.getLookupPathForRequest(request);
/* 186 */       if (matches(lookupPath)) {
/*     */         
/* 188 */         Map<String, String> variables = this.pathMatcher.extractUriTemplateVariables(MvcRequestMatcher.this.pattern, lookupPath);
/* 189 */         return RequestMatcher.MatchResult.match(variables);
/*     */       } 
/* 191 */       return RequestMatcher.MatchResult.notMatch();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final HandlerMappingIntrospector introspector;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String servletPath;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(HandlerMappingIntrospector introspector) {
/* 212 */       this.introspector = introspector;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder servletPath(String servletPath) {
/* 222 */       this.servletPath = servletPath;
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MvcRequestMatcher pattern(String pattern) {
/* 232 */       return pattern(null, pattern);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MvcRequestMatcher pattern(HttpMethod method, String pattern) {
/* 243 */       MvcRequestMatcher mvcRequestMatcher = new MvcRequestMatcher(this.introspector, pattern);
/* 244 */       mvcRequestMatcher.setServletPath(this.servletPath);
/* 245 */       mvcRequestMatcher.setMethod(method);
/* 246 */       return mvcRequestMatcher;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servle\\util\matcher\MvcRequestMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */