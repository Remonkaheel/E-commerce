/*     */ package org.springframework.security.web.servlet.util.matcher;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Objects;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathPatternRequestMatcher
/*     */   implements RequestMatcher
/*     */ {
/*     */   private final PathPattern pattern;
/*     */   private final RequestMatcher method;
/*     */   
/*     */   private PathPatternRequestMatcher(PathPattern pattern, RequestMatcher method) {
/*  69 */     this.pattern = pattern;
/*  70 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder withDefaults() {
/*  78 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder withPathPatternParser(PathPatternParser parser) {
/*  88 */     Assert.notNull(parser, "pathPatternParser cannot be null");
/*  89 */     return new Builder(parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(HttpServletRequest request) {
/*  97 */     return matcher(request).isMatch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 105 */     if (!this.method.matches(request)) {
/* 106 */       return RequestMatcher.MatchResult.notMatch();
/*     */     }
/* 108 */     PathContainer path = getPathContainer(request);
/* 109 */     PathPattern.PathMatchInfo info = this.pattern.matchAndExtract(path);
/* 110 */     return (info != null) ? RequestMatcher.MatchResult.match(info.getUriVariables()) : RequestMatcher.MatchResult.notMatch();
/*     */   }
/*     */   
/*     */   private PathContainer getPathContainer(HttpServletRequest request) {
/*     */     RequestPath path;
/* 115 */     if (ServletRequestPathUtils.hasParsedRequestPath((ServletRequest)request)) {
/* 116 */       path = ServletRequestPathUtils.getParsedRequestPath((ServletRequest)request);
/*     */     } else {
/*     */       
/* 119 */       path = ServletRequestPathUtils.parseAndCache(request);
/* 120 */       ServletRequestPathUtils.clearParsedRequestPath((ServletRequest)request);
/*     */     } 
/* 122 */     PathContainer contextPath = path.contextPath();
/* 123 */     return path.subPath(contextPath.elements().size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     PathPatternRequestMatcher that;
/* 131 */     if (o instanceof PathPatternRequestMatcher) { that = (PathPatternRequestMatcher)o; }
/* 132 */     else { return false; }
/*     */     
/* 134 */     return (Objects.equals(this.pattern, that.pattern) && Objects.equals(this.method, that.method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 142 */     return Objects.hash(new Object[] { this.pattern, this.method });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     StringBuilder request = new StringBuilder();
/* 151 */     RequestMatcher requestMatcher = this.method; if (requestMatcher instanceof HttpMethodRequestMatcher) { HttpMethodRequestMatcher m = (HttpMethodRequestMatcher)requestMatcher;
/* 152 */       request.append(m.method.name()).append(' '); }
/*     */     
/* 154 */     return "PathPattern [" + String.valueOf(request) + String.valueOf(this.pattern) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final PathPatternParser parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String basePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder() {
/* 187 */       this(PathPatternParser.defaultInstance);
/*     */     }
/*     */     
/*     */     Builder(PathPatternParser parser) {
/* 191 */       this(parser, "");
/*     */     }
/*     */     
/*     */     Builder(PathPatternParser parser, String basePath) {
/* 195 */       this.parser = parser;
/* 196 */       this.basePath = basePath;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder basePath(String basePath) {
/* 210 */       Assert.notNull(basePath, "basePath cannot be null");
/* 211 */       Assert.isTrue(basePath.startsWith("/"), "basePath must start with '/'");
/* 212 */       Assert.isTrue(("/".equals(basePath) || !basePath.endsWith("/")), "basePath must not end with a slash");
/* 213 */       Assert.isTrue(!basePath.contains("*"), "basePath must not contain a star");
/* 214 */       return new Builder(this.parser, basePath);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PathPatternRequestMatcher matcher(String path) {
/* 249 */       return matcher(null, path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PathPatternRequestMatcher matcher(@Nullable HttpMethod method, String path) {
/* 285 */       Assert.notNull(path, "pattern cannot be null");
/* 286 */       Assert.isTrue(path.startsWith("/"), "pattern must start with a /");
/* 287 */       String prefix = "/".equals(this.basePath) ? "" : this.basePath;
/* 288 */       PathPattern pathPattern = this.parser.parse(prefix + prefix);
/* 289 */       return new PathPatternRequestMatcher(pathPattern, 
/* 290 */           (method != null) ? new PathPatternRequestMatcher.HttpMethodRequestMatcher(method) : AnyRequestMatcher.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class HttpMethodRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private final HttpMethod method;
/*     */     
/*     */     HttpMethodRequestMatcher(HttpMethod method) {
/* 300 */       this.method = method;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 305 */       return this.method.name().equals(request.getMethod());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 310 */       return "HttpMethod [" + String.valueOf(this.method) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servle\\util\matcher\PathPatternRequestMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */