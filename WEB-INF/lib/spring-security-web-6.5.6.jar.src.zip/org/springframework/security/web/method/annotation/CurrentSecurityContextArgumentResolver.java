/*     */ package org.springframework.security.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.CurrentSecurityContext;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CurrentSecurityContextArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  85 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  87 */   private ExpressionParser parser = (ExpressionParser)new SpelExpressionParser();
/*     */   
/*  89 */   private final Class<CurrentSecurityContext> annotationType = CurrentSecurityContext.class;
/*     */ 
/*     */   
/*  92 */   private SecurityAnnotationScanner<CurrentSecurityContext> scanner = SecurityAnnotationScanners.requireUnique(this.annotationType);
/*     */   
/*     */   private boolean useAnnotationTemplate = false;
/*     */   
/*     */   private BeanResolver beanResolver;
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/* 100 */     return (SecurityContext.class.isAssignableFrom(parameter.getParameterType()) || 
/* 101 */       findMethodAnnotation(parameter) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) {
/* 107 */     SecurityContext securityContext = this.securityContextHolderStrategy.getContext();
/* 108 */     if (securityContext == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     CurrentSecurityContext annotation = findMethodAnnotation(parameter);
/* 112 */     if (annotation != null) {
/* 113 */       return resolveSecurityContextFromAnnotation(parameter, annotation, securityContext);
/*     */     }
/*     */     
/* 116 */     return securityContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 126 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 127 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanResolver(BeanResolver beanResolver) {
/* 135 */     Assert.notNull(beanResolver, "beanResolver cannot be null");
/* 136 */     this.beanResolver = beanResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 149 */     this.useAnnotationTemplate = (templateDefaults != null);
/* 150 */     this.scanner = SecurityAnnotationScanners.requireUnique(CurrentSecurityContext.class, templateDefaults);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object resolveSecurityContextFromAnnotation(MethodParameter parameter, CurrentSecurityContext annotation, SecurityContext securityContext) {
/* 155 */     Object securityContextResult = securityContext;
/* 156 */     String expressionToParse = annotation.expression();
/* 157 */     if (StringUtils.hasLength(expressionToParse)) {
/* 158 */       StandardEvaluationContext context = new StandardEvaluationContext();
/* 159 */       context.setRootObject(securityContext);
/* 160 */       context.setVariable("this", securityContext);
/* 161 */       context.setBeanResolver(this.beanResolver);
/* 162 */       Expression expression = this.parser.parseExpression(expressionToParse);
/* 163 */       securityContextResult = expression.getValue((EvaluationContext)context);
/*     */     } 
/* 165 */     if (securityContextResult != null && 
/* 166 */       !parameter.getParameterType().isAssignableFrom(securityContextResult.getClass())) {
/* 167 */       if (annotation.errorOnInvalidType()) {
/* 168 */         throw new ClassCastException(String.valueOf(securityContextResult) + " is not assignable to " + String.valueOf(securityContextResult));
/*     */       }
/*     */       
/* 171 */       return null;
/*     */     } 
/* 173 */     return securityContextResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CurrentSecurityContext findMethodAnnotation(MethodParameter parameter) {
/* 182 */     if (this.useAnnotationTemplate) {
/* 183 */       return (CurrentSecurityContext)this.scanner.scan(parameter.getParameter());
/*     */     }
/* 185 */     CurrentSecurityContext annotation = (CurrentSecurityContext)parameter.getParameterAnnotation(this.annotationType);
/* 186 */     if (annotation != null) {
/* 187 */       return annotation;
/*     */     }
/* 189 */     Annotation[] annotationsToSearch = parameter.getParameterAnnotations();
/* 190 */     for (Annotation toSearch : annotationsToSearch) {
/* 191 */       annotation = (CurrentSecurityContext)AnnotationUtils.findAnnotation(toSearch.annotationType(), this.annotationType);
/* 192 */       if (annotation != null) {
/* 193 */         return (CurrentSecurityContext)MergedAnnotations.from(new Annotation[] { toSearch }).get(this.annotationType).synthesize();
/*     */       }
/*     */     } 
/* 196 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\method\annotation\CurrentSecurityContextArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */