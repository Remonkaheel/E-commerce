/*     */ package org.springframework.security.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.AuthenticationPrincipal;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthenticationPrincipalArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  98 */   private final Class<AuthenticationPrincipal> annotationType = AuthenticationPrincipal.class;
/*     */ 
/*     */   
/* 101 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/* 103 */   private ExpressionParser parser = (ExpressionParser)new SpelExpressionParser();
/*     */ 
/*     */   
/* 106 */   private SecurityAnnotationScanner<AuthenticationPrincipal> scanner = SecurityAnnotationScanners.requireUnique(AuthenticationPrincipal.class);
/*     */   
/*     */   private boolean useAnnotationTemplate = false;
/*     */   
/*     */   private BeanResolver beanResolver;
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/* 114 */     return (findMethodAnnotation(parameter) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) {
/* 120 */     Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 121 */     if (authentication == null) {
/* 122 */       return null;
/*     */     }
/* 124 */     Object principal = authentication.getPrincipal();
/* 125 */     AuthenticationPrincipal annotation = findMethodAnnotation(parameter);
/* 126 */     String expressionToParse = annotation.expression();
/* 127 */     if (StringUtils.hasLength(expressionToParse)) {
/* 128 */       StandardEvaluationContext context = new StandardEvaluationContext();
/* 129 */       context.setRootObject(principal);
/* 130 */       context.setVariable("this", principal);
/* 131 */       context.setBeanResolver(this.beanResolver);
/* 132 */       Expression expression = this.parser.parseExpression(expressionToParse);
/* 133 */       principal = expression.getValue((EvaluationContext)context);
/*     */     } 
/* 135 */     if (principal != null && !ClassUtils.isAssignable(parameter.getParameterType(), principal.getClass())) {
/* 136 */       if (annotation.errorOnInvalidType()) {
/* 137 */         throw new ClassCastException(String.valueOf(principal) + " is not assignable to " + String.valueOf(principal));
/*     */       }
/* 139 */       return null;
/*     */     } 
/* 141 */     return principal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanResolver(BeanResolver beanResolver) {
/* 149 */     this.beanResolver = beanResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 159 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 160 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 173 */     this.scanner = SecurityAnnotationScanners.requireUnique(AuthenticationPrincipal.class, templateDefaults);
/* 174 */     this.useAnnotationTemplate = (templateDefaults != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationPrincipal findMethodAnnotation(MethodParameter parameter) {
/* 185 */     if (this.useAnnotationTemplate) {
/* 186 */       return (AuthenticationPrincipal)this.scanner.scan(parameter.getParameter());
/*     */     }
/* 188 */     AuthenticationPrincipal annotation = (AuthenticationPrincipal)parameter.getParameterAnnotation(this.annotationType);
/* 189 */     if (annotation != null) {
/* 190 */       return annotation;
/*     */     }
/* 192 */     Annotation[] annotationsToSearch = parameter.getParameterAnnotations();
/* 193 */     for (Annotation toSearch : annotationsToSearch) {
/* 194 */       annotation = (AuthenticationPrincipal)AnnotationUtils.findAnnotation(toSearch.annotationType(), this.annotationType);
/* 195 */       if (annotation != null) {
/* 196 */         return (AuthenticationPrincipal)MergedAnnotations.from(new Annotation[] { toSearch }).get(this.annotationType).synthesize();
/*     */       }
/*     */     } 
/* 199 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\method\annotation\AuthenticationPrincipalArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */