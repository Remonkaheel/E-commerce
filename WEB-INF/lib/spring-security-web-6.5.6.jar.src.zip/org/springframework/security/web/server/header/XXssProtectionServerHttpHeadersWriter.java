/*     */ package org.springframework.security.web.server.header;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XXssProtectionServerHttpHeadersWriter
/*     */   implements ServerHttpHeadersWriter
/*     */ {
/*     */   public static final String X_XSS_PROTECTION = "X-XSS-Protection";
/*     */   private ServerHttpHeadersWriter delegate;
/*     */   private HeaderValue headerValue;
/*     */   
/*     */   public XXssProtectionServerHttpHeadersWriter() {
/*  44 */     this.headerValue = HeaderValue.DISABLED;
/*  45 */     updateDelegate();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/*  50 */     return this.delegate.writeHttpHeaders(exchange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderValue(HeaderValue headerValue) {
/*  83 */     Assert.notNull(headerValue, "headerValue cannot be null");
/*  84 */     this.headerValue = headerValue;
/*  85 */     updateDelegate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum HeaderValue
/*     */   {
/*  96 */     DISABLED("0"), ENABLED("1"), ENABLED_MODE_BLOCK("1; mode=block");
/*     */     
/*     */     private final String value;
/*     */     
/*     */     HeaderValue(String value) {
/* 101 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 106 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateDelegate() {
/* 112 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 113 */     builder.header("X-XSS-Protection", new String[] { this.headerValue.toString() });
/* 114 */     this.delegate = builder.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\XXssProtectionServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */