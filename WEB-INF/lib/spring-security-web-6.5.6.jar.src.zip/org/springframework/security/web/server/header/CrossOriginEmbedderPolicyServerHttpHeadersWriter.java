/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginEmbedderPolicyServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String EMBEDDER_POLICY = "Cross-Origin-Embedder-Policy";
/*    */   private ServerHttpHeadersWriter delegate;
/*    */   
/*    */   public void setPolicy(CrossOriginEmbedderPolicy embedderPolicy) {
/* 45 */     Assert.notNull(embedderPolicy, "embedderPolicy cannot be null");
/* 46 */     this.delegate = createDelegate(embedderPolicy);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 51 */     return (this.delegate != null) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*    */   }
/*    */   
/*    */   private static ServerHttpHeadersWriter createDelegate(CrossOriginEmbedderPolicy embedderPolicy) {
/* 55 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 56 */     builder.header("Cross-Origin-Embedder-Policy", new String[] { embedderPolicy.getPolicy() });
/* 57 */     return builder.build();
/*    */   }
/*    */   
/*    */   public enum CrossOriginEmbedderPolicy
/*    */   {
/* 62 */     UNSAFE_NONE("unsafe-none"),
/*    */     
/* 64 */     REQUIRE_CORP("require-corp");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginEmbedderPolicy(String policy) {
/* 69 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 73 */       return this.policy;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginEmbedderPolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */