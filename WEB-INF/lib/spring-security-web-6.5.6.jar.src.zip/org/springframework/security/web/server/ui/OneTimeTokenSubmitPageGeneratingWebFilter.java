/*     */ package org.springframework.security.web.server.ui;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.security.web.server.csrf.CsrfToken;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OneTimeTokenSubmitPageGeneratingWebFilter
/*     */   implements WebFilter
/*     */ {
/*  48 */   private ServerWebExchangeMatcher matcher = ServerWebExchangeMatchers.pathMatchers(HttpMethod.GET, new String[] { "/login/ott" });
/*     */   
/*  50 */   private String loginProcessingUrl = "/login/ott";
/*     */   private static final String ONE_TIME_TOKEN_SUBMIT_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <title>One-Time Token Login</title>\n    <meta charset=\"utf-8\"/>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\"/>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"container\">\n      <form class=\"login-form\" action=\"{{loginProcessingUrl}}\" method=\"post\">\n        <h2>Please input the token</h2>\n        <p>\n          <label for=\"token\" class=\"screenreader\">Token</label>\n          <input type=\"text\" id=\"token\" name=\"token\" value=\"{{tokenValue}}\" placeholder=\"Token\" required=\"true\" autofocus=\"autofocus\"/>\n        </p>\n{{csrf}}\n        <button class=\"primary\" type=\"submit\">Sign in</button>\n      </form>\n    </div>\n  </body>\n</html>\n";
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/*  54 */     return this.matcher.matches(exchange)
/*  55 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/*  56 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/*  57 */       .flatMap(matchResult -> render(exchange));
/*     */   }
/*     */   private static final String CSRF_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*     */   private Mono<Void> render(ServerWebExchange exchange) {
/*  61 */     ServerHttpResponse result = exchange.getResponse();
/*  62 */     result.setStatusCode((HttpStatusCode)HttpStatus.OK);
/*  63 */     result.getHeaders().setContentType(MediaType.TEXT_HTML);
/*  64 */     return result.writeWith((Publisher)createBuffer(exchange));
/*     */   }
/*     */   
/*     */   private Mono<DataBuffer> createBuffer(ServerWebExchange exchange) {
/*  68 */     Mono<CsrfToken> token = (Mono<CsrfToken>)exchange.getAttributeOrDefault(CsrfToken.class.getName(), Mono.empty());
/*  69 */     return token.map(OneTimeTokenSubmitPageGeneratingWebFilter::csrfToken)
/*  70 */       .defaultIfEmpty("")
/*  71 */       .map(csrfTokenHtmlInput -> {
/*     */           byte[] bytes = createPage(exchange, csrfTokenHtmlInput);
/*     */           DataBufferFactory bufferFactory = exchange.getResponse().bufferFactory();
/*     */           return bufferFactory.wrap(bytes);
/*     */         });
/*     */   }
/*     */   
/*     */   private byte[] createPage(ServerWebExchange exchange, String csrfTokenHtmlInput) {
/*  79 */     MultiValueMap<String, String> queryParams = exchange.getRequest().getQueryParams();
/*  80 */     String token = (String)queryParams.getFirst("token");
/*  81 */     String tokenValue = StringUtils.hasText(token) ? token : "";
/*     */     
/*  83 */     String contextPath = exchange.getRequest().getPath().contextPath().value();
/*     */     
/*  85 */     return HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <title>One-Time Token Login</title>\n    <meta charset=\"utf-8\"/>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\"/>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"container\">\n      <form class=\"login-form\" action=\"{{loginProcessingUrl}}\" method=\"post\">\n        <h2>Please input the token</h2>\n        <p>\n          <label for=\"token\" class=\"screenreader\">Token</label>\n          <input type=\"text\" id=\"token\" name=\"token\" value=\"{{tokenValue}}\" placeholder=\"Token\" required=\"true\" autofocus=\"autofocus\"/>\n        </p>\n{{csrf}}\n        <button class=\"primary\" type=\"submit\">Sign in</button>\n      </form>\n    </div>\n  </body>\n</html>\n")
/*  86 */       .withRawHtml("contextPath", contextPath)
/*  87 */       .withValue("tokenValue", tokenValue)
/*  88 */       .withRawHtml("csrf", csrfTokenHtmlInput.indent(8))
/*  89 */       .withValue("loginProcessingUrl", contextPath + contextPath)
/*  90 */       .render()
/*  91 */       .getBytes(Charset.defaultCharset());
/*     */   }
/*     */   
/*     */   private static String csrfToken(CsrfToken token) {
/*  95 */     return HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n")
/*  96 */       .withValue("name", token.getParameterName())
/*  97 */       .withValue("value", token.getToken())
/*  98 */       .render();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(ServerWebExchangeMatcher requestMatcher) {
/* 107 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 108 */     this.matcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginProcessingUrl(String loginProcessingUrl) {
/* 117 */     Assert.hasText(loginProcessingUrl, "loginProcessingUrl cannot be null or empty");
/* 118 */     this.loginProcessingUrl = loginProcessingUrl;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\ui\OneTimeTokenSubmitPageGeneratingWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */