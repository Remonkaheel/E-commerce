/*    */ package org.springframework.security.web.server.firewall;
/*    */ 
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ServerWebExchangeFirewall
/*    */ {
/*    */   public static final ServerWebExchangeFirewall INSECURE_NOOP;
/*    */   
/*    */   Mono<ServerWebExchange> getFirewalledExchange(ServerWebExchange paramServerWebExchange);
/*    */   
/*    */   static {
/* 36 */     INSECURE_NOOP = (exchange -> Mono.just(exchange));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\ServerWebExchangeFirewall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */