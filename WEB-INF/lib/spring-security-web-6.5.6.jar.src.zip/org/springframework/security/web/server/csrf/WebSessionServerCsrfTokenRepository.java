/*     */ package org.springframework.security.web.server.csrf;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebSessionServerCsrfTokenRepository
/*     */   implements ServerCsrfTokenRepository
/*     */ {
/*     */   private static final String DEFAULT_CSRF_PARAMETER_NAME = "_csrf";
/*     */   private static final String DEFAULT_CSRF_HEADER_NAME = "X-CSRF-TOKEN";
/*  42 */   private static final String DEFAULT_CSRF_TOKEN_ATTR_NAME = WebSessionServerCsrfTokenRepository.class.getName()
/*  43 */     .concat(".CSRF_TOKEN");
/*     */   
/*  45 */   private String parameterName = "_csrf";
/*     */   
/*  47 */   private String headerName = "X-CSRF-TOKEN";
/*     */   
/*  49 */   private String sessionAttributeName = DEFAULT_CSRF_TOKEN_ATTR_NAME;
/*     */ 
/*     */   
/*     */   public Mono<CsrfToken> generateToken(ServerWebExchange exchange) {
/*  53 */     return Mono.fromCallable(() -> createCsrfToken()).subscribeOn(Schedulers.boundedElastic());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveToken(ServerWebExchange exchange, CsrfToken token) {
/*  58 */     return exchange.getSession()
/*  59 */       .doOnNext(session -> putToken(session.getAttributes(), token))
/*  60 */       .flatMap(session -> session.changeSessionId());
/*     */   }
/*     */   
/*     */   private void putToken(Map<String, Object> attributes, CsrfToken token) {
/*  64 */     if (token == null) {
/*  65 */       attributes.remove(this.sessionAttributeName);
/*     */     } else {
/*     */       
/*  68 */       attributes.put(this.sessionAttributeName, token);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<CsrfToken> loadToken(ServerWebExchange exchange) {
/*  74 */     return exchange.getSession()
/*  75 */       .filter(session -> session.getAttributes().containsKey(this.sessionAttributeName))
/*  76 */       .map(session -> (CsrfToken)session.getAttribute(this.sessionAttributeName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterName(String parameterName) {
/*  85 */     Assert.hasLength(parameterName, "parameterName cannot be null or empty");
/*  86 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderName(String headerName) {
/*  95 */     Assert.hasLength(headerName, "headerName cannot be null or empty");
/*  96 */     this.headerName = headerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAttributeName(String sessionAttributeName) {
/* 104 */     Assert.hasLength(sessionAttributeName, "sessionAttributename cannot be null or empty");
/* 105 */     this.sessionAttributeName = sessionAttributeName;
/*     */   }
/*     */   
/*     */   private CsrfToken createCsrfToken() {
/* 109 */     return new DefaultCsrfToken(this.headerName, this.parameterName, createNewToken());
/*     */   }
/*     */   
/*     */   private String createNewToken() {
/* 113 */     return UUID.randomUUID().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\WebSessionServerCsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */