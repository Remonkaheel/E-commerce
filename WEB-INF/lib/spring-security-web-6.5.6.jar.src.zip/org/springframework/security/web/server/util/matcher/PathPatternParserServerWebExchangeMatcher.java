/*     */ package org.springframework.security.web.server.util.matcher;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PathPatternParserServerWebExchangeMatcher
/*     */   implements ServerWebExchangeMatcher
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(PathPatternParserServerWebExchangeMatcher.class);
/*     */   
/*     */   private final PathPattern pattern;
/*     */   
/*     */   private final HttpMethod method;
/*     */   
/*     */   public PathPatternParserServerWebExchangeMatcher(PathPattern pattern) {
/*  50 */     this(pattern, (HttpMethod)null);
/*     */   }
/*     */   
/*     */   public PathPatternParserServerWebExchangeMatcher(PathPattern pattern, HttpMethod method) {
/*  54 */     Assert.notNull(pattern, "pattern cannot be null");
/*  55 */     this.pattern = pattern;
/*  56 */     this.method = method;
/*     */   }
/*     */   
/*     */   public PathPatternParserServerWebExchangeMatcher(String pattern, HttpMethod method) {
/*  60 */     Assert.notNull(pattern, "pattern cannot be null");
/*  61 */     this.pattern = parse(pattern);
/*  62 */     this.method = method;
/*     */   }
/*     */   
/*     */   public PathPatternParserServerWebExchangeMatcher(String pattern) {
/*  66 */     this(pattern, (HttpMethod)null);
/*     */   }
/*     */   
/*     */   private PathPattern parse(String pattern) {
/*  70 */     PathPatternParser parser = PathPatternParser.defaultInstance;
/*  71 */     pattern = parser.initFullPathPattern(pattern);
/*  72 */     return parser.parse(pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/*  77 */     ServerHttpRequest request = exchange.getRequest();
/*  78 */     PathContainer path = request.getPath().pathWithinApplication();
/*  79 */     if (this.method != null && !this.method.equals(request.getMethod())) {
/*  80 */       return ServerWebExchangeMatcher.MatchResult.notMatch().doOnNext(result -> {
/*     */             if (logger.isDebugEnabled()) {
/*     */               logger.debug("Request '" + String.valueOf(request.getMethod()) + " " + String.valueOf(path) + "' doesn't match '" + String.valueOf(this.method) + " " + this.pattern.getPatternString() + "'");
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*  87 */     boolean match = this.pattern.matches(path);
/*  88 */     if (!match) {
/*  89 */       return ServerWebExchangeMatcher.MatchResult.notMatch().doOnNext(result -> {
/*     */             if (logger.isDebugEnabled()) {
/*     */               logger.debug("Request '" + String.valueOf(request.getMethod()) + " " + String.valueOf(path) + "' doesn't match '" + String.valueOf(this.method) + " " + this.pattern.getPatternString() + "'");
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*  96 */     Map<String, String> pathVariables = this.pattern.matchAndExtract(path).getUriVariables();
/*  97 */     Map<String, Object> variables = new HashMap<>(pathVariables);
/*  98 */     if (logger.isDebugEnabled()) {
/*  99 */       logger
/* 100 */         .debug("Checking match of request : '" + String.valueOf(path) + "'; against '" + this.pattern.getPatternString() + "'");
/*     */     }
/* 102 */     return ServerWebExchangeMatcher.MatchResult.match(variables);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     return "PathMatcherServerWebExchangeMatcher{pattern='" + String.valueOf(this.pattern) + "', method=" + String.valueOf(this.method) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\PathPatternParserServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */