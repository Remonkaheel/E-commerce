/*     */ package org.springframework.security.web.server.authentication;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManagerResolver;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver
/*     */   implements ReactiveAuthenticationManagerResolver<ServerWebExchange>
/*     */ {
/*     */   private final List<ServerWebExchangeMatcherEntry<ReactiveAuthenticationManager>> authenticationManagers;
/*     */   private ReactiveAuthenticationManager defaultAuthenticationManager;
/*     */   
/*     */   ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver(ServerWebExchangeMatcherEntry<ReactiveAuthenticationManager>... managers) {
/*  64 */     this(Arrays.asList(managers));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver(List<ServerWebExchangeMatcherEntry<ReactiveAuthenticationManager>> managers) {
/*     */     this.defaultAuthenticationManager = (authentication -> {
/*     */         AuthenticationServiceException authenticationServiceException = new AuthenticationServiceException("Cannot authenticate " + String.valueOf(authentication));
/*     */         authenticationServiceException.setAuthenticationRequest(authentication);
/*     */         return (ReactiveAuthenticationManager)Mono.error((Throwable)authenticationServiceException);
/*     */       });
/*  75 */     Assert.notNull(managers, "entries cannot be null");
/*  76 */     this.authenticationManagers = managers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<ReactiveAuthenticationManager> resolve(ServerWebExchange exchange) {
/*  84 */     return Flux.fromIterable(this.authenticationManagers)
/*  85 */       .filterWhen(entry -> isMatch(exchange, entry))
/*  86 */       .next()
/*  87 */       .map(ServerWebExchangeMatcherEntry::getEntry)
/*  88 */       .defaultIfEmpty(this.defaultAuthenticationManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAuthenticationManager(ReactiveAuthenticationManager defaultAuthenticationManager) {
/*  98 */     Assert.notNull(defaultAuthenticationManager, "defaultAuthenticationManager cannot be null");
/*  99 */     this.defaultAuthenticationManager = defaultAuthenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 108 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Boolean> isMatch(ServerWebExchange exchange, ServerWebExchangeMatcherEntry<ReactiveAuthenticationManager> entry) {
/* 113 */     ServerWebExchangeMatcher matcher = entry.getMatcher();
/* 114 */     return matcher.matches(exchange).map(ServerWebExchangeMatcher.MatchResult::isMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 123 */     private final List<ServerWebExchangeMatcherEntry<ReactiveAuthenticationManager>> entries = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder add(ServerWebExchangeMatcher matcher, ReactiveAuthenticationManager manager) {
/* 140 */       Assert.notNull(matcher, "matcher cannot be null");
/* 141 */       Assert.notNull(manager, "manager cannot be null");
/* 142 */       this.entries.add(new ServerWebExchangeMatcherEntry(matcher, manager));
/* 143 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver build() {
/* 155 */       return new ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver(this.entries);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerWebExchangeDelegatingReactiveAuthenticationManagerResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */