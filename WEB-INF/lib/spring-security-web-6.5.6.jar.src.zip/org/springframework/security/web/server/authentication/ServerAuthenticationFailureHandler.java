package org.springframework.security.web.server.authentication;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.server.WebFilterExchange;
import reactor.core.publisher.Mono;

public interface ServerAuthenticationFailureHandler {
  Mono<Void> onAuthenticationFailure(WebFilterExchange paramWebFilterExchange, AuthenticationException paramAuthenticationException);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */