package org.springframework.security.web.server.authorization;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface ServerAccessDeniedHandler {
  Mono<Void> handle(ServerWebExchange paramServerWebExchange, AccessDeniedException paramAccessDeniedException);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\ServerAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */