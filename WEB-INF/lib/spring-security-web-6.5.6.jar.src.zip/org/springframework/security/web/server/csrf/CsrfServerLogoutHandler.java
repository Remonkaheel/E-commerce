/*    */ package org.springframework.security.web.server.csrf;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.security.web.server.authentication.logout.ServerLogoutHandler;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsrfServerLogoutHandler
/*    */   implements ServerLogoutHandler
/*    */ {
/*    */   private final ServerCsrfTokenRepository csrfTokenRepository;
/*    */   
/*    */   public CsrfServerLogoutHandler(ServerCsrfTokenRepository csrfTokenRepository) {
/* 43 */     Assert.notNull(csrfTokenRepository, "csrfTokenRepository cannot be null");
/* 44 */     this.csrfTokenRepository = csrfTokenRepository;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> logout(WebFilterExchange exchange, Authentication authentication) {
/* 55 */     return this.csrfTokenRepository.saveToken(exchange.getExchange(), null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\CsrfServerLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */