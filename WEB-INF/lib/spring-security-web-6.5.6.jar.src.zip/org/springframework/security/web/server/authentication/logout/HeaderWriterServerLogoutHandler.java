/*    */ package org.springframework.security.web.server.authentication.logout;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.security.web.server.header.ServerHttpHeadersWriter;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderWriterServerLogoutHandler
/*    */   implements ServerLogoutHandler
/*    */ {
/*    */   private final ServerHttpHeadersWriter headersWriter;
/*    */   
/*    */   public HeaderWriterServerLogoutHandler(ServerHttpHeadersWriter headersWriter) {
/* 46 */     Assert.notNull(headersWriter, "headersWriter cannot be null");
/* 47 */     this.headersWriter = headersWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> logout(WebFilterExchange exchange, Authentication authentication) {
/* 52 */     return this.headersWriter.writeHttpHeaders(exchange.getExchange());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\HeaderWriterServerLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */