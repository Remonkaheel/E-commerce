/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Builder
/*    */ {
/* 64 */   private HttpHeaders headers = new HttpHeaders();
/*    */   
/*    */   public Builder header(String headerName, String... values) {
/* 67 */     this.headers.put(headerName, Arrays.asList(values));
/* 68 */     return this;
/*    */   }
/*    */   
/*    */   public StaticServerHttpHeadersWriter build() {
/* 72 */     return new StaticServerHttpHeadersWriter(this.headers);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\StaticServerHttpHeadersWriter$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */