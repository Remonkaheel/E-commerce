/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingServerAuthenticationSuccessHandler
/*    */   implements ServerAuthenticationSuccessHandler
/*    */ {
/*    */   private final List<ServerAuthenticationSuccessHandler> delegates;
/*    */   
/*    */   public DelegatingServerAuthenticationSuccessHandler(ServerAuthenticationSuccessHandler... delegates) {
/* 41 */     Assert.notEmpty((Object[])delegates, "delegates cannot be null or empty");
/* 42 */     this.delegates = Arrays.asList(delegates);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingServerAuthenticationSuccessHandler(List<ServerAuthenticationSuccessHandler> delegates) {
/* 51 */     Assert.notEmpty(delegates, "delegates cannot be null or empty");
/* 52 */     this.delegates = delegates;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> onAuthenticationSuccess(WebFilterExchange exchange, Authentication authentication) {
/* 57 */     return Flux.fromIterable(this.delegates)
/* 58 */       .concatMap(delegate -> delegate.onAuthenticationSuccess(exchange, authentication))
/* 59 */       .then();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\DelegatingServerAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */