/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegateEntry
/*     */ {
/*     */   private final ServerWebExchangeMatcher matcher;
/*     */   private final ServerAuthenticationEntryPoint entryPoint;
/*     */   
/*     */   public DelegateEntry(ServerWebExchangeMatcher matcher, ServerAuthenticationEntryPoint entryPoint) {
/*  96 */     this.matcher = matcher;
/*  97 */     this.entryPoint = entryPoint;
/*     */   }
/*     */   
/*     */   public ServerWebExchangeMatcher getMatcher() {
/* 101 */     return this.matcher;
/*     */   }
/*     */   
/*     */   public ServerAuthenticationEntryPoint getEntryPoint() {
/* 105 */     return this.entryPoint;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\DelegatingServerAuthenticationEntryPoint$DelegateEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */