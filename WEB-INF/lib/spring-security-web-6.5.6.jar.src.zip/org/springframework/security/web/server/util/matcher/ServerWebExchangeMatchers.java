/*     */ package org.springframework.security.web.server.util.matcher;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServerWebExchangeMatchers
/*     */ {
/*     */   public static ServerWebExchangeMatcher pathMatchers(HttpMethod method, String... patterns) {
/*  47 */     List<ServerWebExchangeMatcher> matchers = new ArrayList<>(patterns.length);
/*  48 */     for (String pattern : patterns) {
/*  49 */       matchers.add(new PathPatternParserServerWebExchangeMatcher(pattern, method));
/*     */     }
/*  51 */     return new OrServerWebExchangeMatcher(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchangeMatcher pathMatchers(String... patterns) {
/*  60 */     return pathMatchers((HttpMethod)null, patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchangeMatcher pathMatchers(PathPattern... pathPatterns) {
/*  69 */     return pathMatchers((HttpMethod)null, pathPatterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchangeMatcher pathMatchers(HttpMethod method, PathPattern... pathPatterns) {
/*  80 */     List<ServerWebExchangeMatcher> matchers = new ArrayList<>(pathPatterns.length);
/*  81 */     for (PathPattern pathPattern : pathPatterns) {
/*  82 */       matchers.add(new PathPatternParserServerWebExchangeMatcher(pathPattern, method));
/*     */     }
/*  84 */     return new OrServerWebExchangeMatcher(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchangeMatcher matchers(ServerWebExchangeMatcher... matchers) {
/*  93 */     return new OrServerWebExchangeMatcher(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServerWebExchangeMatcher anyExchange() {
/* 105 */     return new ServerWebExchangeMatcher()
/*     */       {
/*     */         public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange)
/*     */         {
/* 109 */           return ServerWebExchangeMatcher.MatchResult.match();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\ServerWebExchangeMatchers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */