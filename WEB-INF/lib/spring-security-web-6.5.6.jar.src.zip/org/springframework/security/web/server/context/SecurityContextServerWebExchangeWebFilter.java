/*    */ package org.springframework.security.web.server.context;
/*    */ 
/*    */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextServerWebExchangeWebFilter
/*    */   implements WebFilter
/*    */ {
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 38 */     return chain.filter((ServerWebExchange)new SecurityContextServerWebExchange(exchange, ReactiveSecurityContextHolder.getContext()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\SecurityContextServerWebExchangeWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */