/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FeaturePolicyServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String FEATURE_POLICY = "Feature-Policy";
/*    */   private ServerHttpHeadersWriter delegate;
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 39 */     return (this.delegate != null) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPolicyDirectives(String policyDirectives) {
/* 48 */     Assert.hasLength(policyDirectives, "policyDirectives must not be null or empty");
/* 49 */     this.delegate = createDelegate(policyDirectives);
/*    */   }
/*    */   
/*    */   private static ServerHttpHeadersWriter createDelegate(String policyDirectives) {
/* 53 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 54 */     builder.header("Feature-Policy", new String[] { policyDirectives });
/* 55 */     return builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\FeaturePolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */