/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthenticationConverterServerWebExchangeMatcher
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/*    */   private final ServerAuthenticationConverter serverAuthenticationConverter;
/*    */   
/*    */   public AuthenticationConverterServerWebExchangeMatcher(ServerAuthenticationConverter serverAuthenticationConverter) {
/* 40 */     Assert.notNull(serverAuthenticationConverter, "serverAuthenticationConverter cannot be null");
/* 41 */     this.serverAuthenticationConverter = serverAuthenticationConverter;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 46 */     return this.serverAuthenticationConverter.convert(exchange)
/* 47 */       .flatMap(a -> ServerWebExchangeMatcher.MatchResult.match())
/* 48 */       .onErrorResume(ex -> ServerWebExchangeMatcher.MatchResult.notMatch())
/* 49 */       .switchIfEmpty(ServerWebExchangeMatcher.MatchResult.notMatch());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\AuthenticationConverterServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */