/*    */ package org.springframework.security.web.server.ui;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*    */ import org.springframework.security.web.server.csrf.CsrfToken;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogoutPageGeneratingWebFilter
/*    */   implements WebFilter
/*    */ {
/* 44 */   private ServerWebExchangeMatcher matcher = ServerWebExchangeMatchers.pathMatchers(HttpMethod.GET, new String[] { "/logout" });
/*    */   private static final String LOGOUT_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Confirm Log Out?</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n      <form class=\"logout-form\" method=\"post\" action=\"{{contextPath}}/logout\">\n        <h2>Are you sure you want to log out?</h2>\n{{csrf}}\n        <button class=\"primary\" type=\"submit\">Log Out</button>\n      </form>\n    </div>\n  </body>\n</html>";
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 48 */     return this.matcher.matches(exchange)
/* 49 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 50 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/* 51 */       .flatMap(matchResult -> render(exchange));
/*    */   }
/*    */   private static final String CSRF_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*    */   private Mono<Void> render(ServerWebExchange exchange) {
/* 55 */     ServerHttpResponse result = exchange.getResponse();
/* 56 */     result.setStatusCode((HttpStatusCode)HttpStatus.OK);
/* 57 */     result.getHeaders().setContentType(MediaType.TEXT_HTML);
/* 58 */     return result.writeWith((Publisher)createBuffer(exchange));
/*    */   }
/*    */   
/*    */   private Mono<DataBuffer> createBuffer(ServerWebExchange exchange) {
/* 62 */     Mono<CsrfToken> token = (Mono<CsrfToken>)exchange.getAttributeOrDefault(CsrfToken.class.getName(), Mono.empty());
/* 63 */     String contextPath = exchange.getRequest().getPath().contextPath().value();
/* 64 */     return token.map(LogoutPageGeneratingWebFilter::csrfToken).defaultIfEmpty("").map(csrfTokenHtmlInput -> {
/*    */           byte[] bytes = createPage(csrfTokenHtmlInput, contextPath);
/*    */           DataBufferFactory bufferFactory = exchange.getResponse().bufferFactory();
/*    */           return bufferFactory.wrap(bytes);
/*    */         });
/*    */   }
/*    */   
/*    */   private static byte[] createPage(String csrfTokenHtmlInput, String contextPath) {
/* 72 */     return HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Confirm Log Out?</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n      <form class=\"logout-form\" method=\"post\" action=\"{{contextPath}}/logout\">\n        <h2>Are you sure you want to log out?</h2>\n{{csrf}}\n        <button class=\"primary\" type=\"submit\">Log Out</button>\n      </form>\n    </div>\n  </body>\n</html>")
/* 73 */       .withValue("contextPath", contextPath)
/* 74 */       .withRawHtml("csrf", csrfTokenHtmlInput.indent(8))
/* 75 */       .render()
/* 76 */       .getBytes(Charset.defaultCharset());
/*    */   }
/*    */   
/*    */   private static String csrfToken(CsrfToken token) {
/* 80 */     return HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n")
/* 81 */       .withValue("name", token.getParameterName())
/* 82 */       .withValue("value", token.getToken())
/* 83 */       .render();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\ui\LogoutPageGeneratingWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */