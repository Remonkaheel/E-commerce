/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.savedrequest.ServerRequestCache;
/*    */ import org.springframework.security.web.server.savedrequest.WebSessionServerRequestCache;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedirectServerAuthenticationEntryPoint
/*    */   implements ServerAuthenticationEntryPoint
/*    */ {
/*    */   private final URI location;
/* 42 */   private ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */   
/* 44 */   private ServerRequestCache requestCache = (ServerRequestCache)new WebSessionServerRequestCache();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RedirectServerAuthenticationEntryPoint(String location) {
/* 51 */     Assert.notNull(location, "location cannot be null");
/* 52 */     this.location = URI.create(location);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequestCache(ServerRequestCache requestCache) {
/* 60 */     Assert.notNull(requestCache, "requestCache cannot be null");
/* 61 */     this.requestCache = requestCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException ex) {
/* 66 */     return this.requestCache.saveRequest(exchange)
/* 67 */       .then(this.redirectStrategy.sendRedirect(exchange, this.location));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRedirectStrategy(ServerRedirectStrategy redirectStrategy) {
/* 75 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 76 */     this.redirectStrategy = redirectStrategy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\RedirectServerAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */