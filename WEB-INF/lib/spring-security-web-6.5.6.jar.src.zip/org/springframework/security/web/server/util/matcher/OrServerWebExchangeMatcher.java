/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrServerWebExchangeMatcher
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/* 41 */   private static final Log logger = LogFactory.getLog(OrServerWebExchangeMatcher.class);
/*    */   
/*    */   private final List<ServerWebExchangeMatcher> matchers;
/*    */   
/*    */   public OrServerWebExchangeMatcher(List<ServerWebExchangeMatcher> matchers) {
/* 46 */     Assert.notEmpty(matchers, "matchers cannot be empty");
/* 47 */     this.matchers = matchers;
/*    */   }
/*    */   
/*    */   public OrServerWebExchangeMatcher(ServerWebExchangeMatcher... matchers) {
/* 51 */     this(Arrays.asList(matchers));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 56 */     return Flux.fromIterable(this.matchers)
/* 57 */       .doOnNext(matcher -> logger.debug(LogMessage.format("Trying to match using %s", matcher)))
/* 58 */       .flatMap(matcher -> matcher.matches(exchange))
/* 59 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 60 */       .next()
/* 61 */       .switchIfEmpty(ServerWebExchangeMatcher.MatchResult.notMatch())
/* 62 */       .doOnNext(matchResult -> logger.debug(matchResult.isMatch() ? "matched" : "No matches found"));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return "OrServerWebExchangeMatcher{matchers=" + String.valueOf(this.matchers) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\OrServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */