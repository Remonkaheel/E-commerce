package org.springframework.security.web.server;

import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface SecurityWebFilterChain {
  Mono<Boolean> matches(ServerWebExchange paramServerWebExchange);
  
  Flux<WebFilter> getWebFilters();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\SecurityWebFilterChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */