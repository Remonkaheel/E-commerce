package org.springframework.security.web.server.authentication.ott;

import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@FunctionalInterface
public interface ServerOneTimeTokenGenerationSuccessHandler {
  Mono<Void> handle(ServerWebExchange paramServerWebExchange, OneTimeToken paramOneTimeToken);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\ServerOneTimeTokenGenerationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */