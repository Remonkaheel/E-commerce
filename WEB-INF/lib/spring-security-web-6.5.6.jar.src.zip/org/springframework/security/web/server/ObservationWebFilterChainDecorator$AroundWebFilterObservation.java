/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface AroundWebFilterObservation
/*     */   extends ObservationWebFilterChainDecorator.WebFilterObservation
/*     */ {
/* 237 */   public static final AroundWebFilterObservation NOOP = new AroundWebFilterObservation() {  }
/*     */   ;
/*     */   
/*     */   static AroundWebFilterObservation create(Observation before, Observation after) {
/* 241 */     if (before.isNoop() || after.isNoop()) {
/* 242 */       return NOOP;
/*     */     }
/* 244 */     return new SimpleAroundWebFilterObservation(before, after);
/*     */   }
/*     */   
/*     */   default Observation before() {
/* 248 */     return Observation.NOOP;
/*     */   }
/*     */   
/*     */   default Observation after() {
/* 252 */     return Observation.NOOP;
/*     */   }
/*     */   
/*     */   public static class SimpleAroundWebFilterObservation
/*     */     implements AroundWebFilterObservation {
/* 257 */     private final Object lock = new Object();
/*     */     
/*     */     private final ObservationWebFilterChainDecorator.PhasedObservation before;
/*     */     
/*     */     private final ObservationWebFilterChainDecorator.PhasedObservation after;
/*     */     
/* 263 */     private volatile ObservationWebFilterChainDecorator.PhasedObservation currentObservation = ObservationWebFilterChainDecorator.PhasedObservation.NOOP;
/*     */     
/*     */     SimpleAroundWebFilterObservation(Observation before, Observation after) {
/* 266 */       this.before = new ObservationWebFilterChainDecorator.PhasedObservation(before);
/* 267 */       this.after = new ObservationWebFilterChainDecorator.PhasedObservation(after);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation start() {
/* 272 */       synchronized (this.lock) {
/* 273 */         if (this.currentObservation == ObservationWebFilterChainDecorator.PhasedObservation.NOOP) {
/* 274 */           this.before.start();
/* 275 */           this.currentObservation = this.before;
/* 276 */           return this.currentObservation;
/*     */         } 
/* 278 */         if (this.currentObservation == this.before) {
/* 279 */           this.before.stop();
/* 280 */           this.after.start();
/* 281 */           this.currentObservation = this.after;
/* 282 */           return this.currentObservation;
/*     */         } 
/*     */       } 
/* 285 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation error(Throwable ex) {
/* 290 */       this.currentObservation.error(ex);
/* 291 */       return this.currentObservation.observation;
/*     */     }
/*     */ 
/*     */     
/*     */     public void stop() {
/* 296 */       this.before.stop();
/* 297 */       this.after.stop();
/*     */     }
/*     */     
/*     */     private void close() {
/* 301 */       this.before.close();
/* 302 */       this.after.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation contextualName(String contextualName) {
/* 307 */       return this.currentObservation.observation.contextualName(contextualName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation parentObservation(Observation parentObservation) {
/* 312 */       return this.currentObservation.observation.parentObservation(parentObservation);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 317 */       return this.currentObservation.observation.lowCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 322 */       return this.currentObservation.observation.highCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 327 */       return this.currentObservation.observation.observationConvention(observationConvention);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation event(Observation.Event event) {
/* 332 */       return this.currentObservation.observation.event(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Context getContext() {
/* 337 */       return this.currentObservation.observation.getContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Scope openScope() {
/* 342 */       return this.currentObservation.observation.openScope();
/*     */     }
/*     */ 
/*     */     
/*     */     public WebFilterChain wrap(WebFilterChain chain) {
/* 347 */       return exchange -> {
/*     */           stop();
/*     */           return chain.filter(exchange).doOnSuccess(()).doOnCancel(this::start).doOnError(());
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebFilter wrap(WebFilter filter) {
/* 363 */       return (exchange, chain) -> {
/*     */           start();
/*     */           return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this::close).doOnError(()).contextWrite(());
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Observation before() {
/* 380 */       return this.before.observation;
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation after() {
/* 385 */       return this.after.observation;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 390 */       return this.currentObservation.observation.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ObservationWebFilterChainDecorator$AroundWebFilterObservation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */