/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginOpenerPolicyServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String OPENER_POLICY = "Cross-Origin-Opener-Policy";
/*    */   private ServerHttpHeadersWriter delegate;
/*    */   
/*    */   public void setPolicy(CrossOriginOpenerPolicy openerPolicy) {
/* 45 */     Assert.notNull(openerPolicy, "openerPolicy cannot be null");
/* 46 */     this.delegate = createDelegate(openerPolicy);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 51 */     return (this.delegate != null) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*    */   }
/*    */   
/*    */   private static ServerHttpHeadersWriter createDelegate(CrossOriginOpenerPolicy openerPolicy) {
/* 55 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 56 */     builder.header("Cross-Origin-Opener-Policy", new String[] { openerPolicy.getPolicy() });
/* 57 */     return builder.build();
/*    */   }
/*    */   
/*    */   public enum CrossOriginOpenerPolicy
/*    */   {
/* 62 */     UNSAFE_NONE("unsafe-none"),
/*    */     
/* 64 */     SAME_ORIGIN_ALLOW_POPUPS("same-origin-allow-popups"),
/*    */     
/* 66 */     SAME_ORIGIN("same-origin");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginOpenerPolicy(String policy) {
/* 71 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 75 */       return this.policy;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginOpenerPolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */