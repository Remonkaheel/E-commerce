/*     */ package org.springframework.security.web.server.util.matcher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.NotAcceptableStatusException;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaTypeServerWebExchangeMatcher
/*     */   implements ServerWebExchangeMatcher
/*     */ {
/*  45 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final Collection<MediaType> matchingMediaTypes;
/*     */   
/*     */   private boolean useEquals;
/*     */   
/*  51 */   private Set<MediaType> ignoredMediaTypes = Collections.emptySet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaTypeServerWebExchangeMatcher(MediaType... matchingMediaTypes) {
/*  58 */     Assert.notEmpty((Object[])matchingMediaTypes, "matchingMediaTypes cannot be null");
/*  59 */     Assert.noNullElements((Object[])matchingMediaTypes, "matchingMediaTypes cannot contain null");
/*  60 */     this.matchingMediaTypes = Arrays.asList(matchingMediaTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaTypeServerWebExchangeMatcher(Collection<MediaType> matchingMediaTypes) {
/*  68 */     Assert.notEmpty(matchingMediaTypes, "matchingMediaTypes cannot be null");
/*  69 */     Assert.noNullElements(matchingMediaTypes, () -> "matchingMediaTypes cannot contain null. Got " + String.valueOf(matchingMediaTypes));
/*     */     
/*  71 */     this.matchingMediaTypes = matchingMediaTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/*     */     List<MediaType> httpRequestMediaTypes;
/*     */     try {
/*  78 */       httpRequestMediaTypes = resolveMediaTypes(exchange);
/*     */     }
/*  80 */     catch (NotAcceptableStatusException ex) {
/*  81 */       this.logger.debug("Failed to parse MediaTypes, returning false", (Throwable)ex);
/*  82 */       return ServerWebExchangeMatcher.MatchResult.notMatch();
/*     */     } 
/*  84 */     this.logger.debug(LogMessage.format("httpRequestMediaTypes=%s", httpRequestMediaTypes));
/*  85 */     for (MediaType httpRequestMediaType : httpRequestMediaTypes) {
/*  86 */       this.logger.debug(LogMessage.format("Processing %s", httpRequestMediaType));
/*  87 */       if (shouldIgnore(httpRequestMediaType)) {
/*  88 */         this.logger.debug("Ignoring");
/*     */         continue;
/*     */       } 
/*  91 */       if (this.useEquals) {
/*  92 */         boolean isEqualTo = this.matchingMediaTypes.contains(httpRequestMediaType);
/*  93 */         this.logger.debug("isEqualTo " + isEqualTo);
/*  94 */         return isEqualTo ? ServerWebExchangeMatcher.MatchResult.match() : ServerWebExchangeMatcher.MatchResult.notMatch();
/*     */       } 
/*  96 */       for (MediaType matchingMediaType : this.matchingMediaTypes) {
/*  97 */         boolean isCompatibleWith = matchingMediaType.isCompatibleWith(httpRequestMediaType);
/*  98 */         this.logger.debug(LogMessage.format("%s .isCompatibleWith %s = %s", matchingMediaType, httpRequestMediaType, 
/*  99 */               Boolean.valueOf(isCompatibleWith)));
/* 100 */         if (isCompatibleWith) {
/* 101 */           return ServerWebExchangeMatcher.MatchResult.match();
/*     */         }
/*     */       } 
/*     */     } 
/* 105 */     this.logger.debug("Did not match any media types");
/* 106 */     return ServerWebExchangeMatcher.MatchResult.notMatch();
/*     */   }
/*     */   
/*     */   private boolean shouldIgnore(MediaType httpRequestMediaType) {
/* 110 */     for (MediaType ignoredMediaType : this.ignoredMediaTypes) {
/* 111 */       if (httpRequestMediaType.includes(ignoredMediaType)) {
/* 112 */         return true;
/*     */       }
/*     */     } 
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseEquals(boolean useEquals) {
/* 124 */     this.useEquals = useEquals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoredMediaTypes(Set<MediaType> ignoredMediaTypes) {
/* 135 */     this.ignoredMediaTypes = ignoredMediaTypes;
/*     */   }
/*     */   
/*     */   private List<MediaType> resolveMediaTypes(ServerWebExchange exchange) throws NotAcceptableStatusException {
/*     */     try {
/* 140 */       List<MediaType> mediaTypes = exchange.getRequest().getHeaders().getAccept();
/* 141 */       MediaType.sortBySpecificityAndQuality(mediaTypes);
/* 142 */       return mediaTypes;
/*     */     }
/* 144 */     catch (InvalidMediaTypeException ex) {
/* 145 */       String value = exchange.getRequest().getHeaders().getFirst("Accept");
/* 146 */       throw new NotAcceptableStatusException("Could not parse 'Accept' header [" + value + "]: " + ex
/* 147 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     return "MediaTypeRequestMatcher [matchingMediaTypes=" + String.valueOf(this.matchingMediaTypes) + ", useEquals=" + this.useEquals + ", ignoredMediaTypes=" + String.valueOf(this.ignoredMediaTypes) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\MediaTypeServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */