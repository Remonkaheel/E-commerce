/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Directive
/*    */ {
/* 74 */   CACHE("cache"),
/*    */   
/* 76 */   COOKIES("cookies"),
/*    */   
/* 78 */   STORAGE("storage"),
/*    */   
/* 80 */   EXECUTION_CONTEXTS("executionContexts"),
/*    */   
/* 82 */   ALL("*");
/*    */   
/*    */   private final String headerValue;
/*    */   
/*    */   Directive(String headerValue) {
/* 87 */     this.headerValue = "\"" + headerValue + "\"";
/*    */   }
/*    */   
/*    */   public String getHeaderValue() {
/* 91 */     return this.headerValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\ClearSiteDataServerHttpHeadersWriter$Directive.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */