/*     */ package org.springframework.security.web.server.authentication;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextImpl;
/*     */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.web.authentication.switchuser.SwitchUserGrantedAuthority;
/*     */ import org.springframework.security.web.server.WebFilterExchange;
/*     */ import org.springframework.security.web.server.context.ServerSecurityContextRepository;
/*     */ import org.springframework.security.web.server.context.WebSessionServerSecurityContextRepository;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchUserWebFilter
/*     */   implements WebFilter
/*     */ {
/*  96 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   public static final String SPRING_SECURITY_SWITCH_USERNAME_KEY = "username";
/*     */   
/*     */   public static final String ROLE_PREVIOUS_ADMINISTRATOR = "ROLE_PREVIOUS_ADMINISTRATOR";
/*     */   
/*     */   private final ServerAuthenticationSuccessHandler successHandler;
/*     */   
/*     */   private final ServerAuthenticationFailureHandler failureHandler;
/*     */   
/*     */   private final ReactiveUserDetailsService userDetailsService;
/*     */   
/*     */   private final UserDetailsChecker userDetailsChecker;
/*     */   
/*     */   private ServerSecurityContextRepository securityContextRepository;
/*     */   
/* 112 */   private ServerWebExchangeMatcher switchUserMatcher = createMatcher("/login/impersonate");
/*     */   
/* 114 */   private ServerWebExchangeMatcher exitUserMatcher = createMatcher("/logout/impersonate");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SwitchUserWebFilter(ReactiveUserDetailsService userDetailsService, ServerAuthenticationSuccessHandler successHandler, @Nullable ServerAuthenticationFailureHandler failureHandler) {
/* 127 */     Assert.notNull(userDetailsService, "userDetailsService must be specified");
/* 128 */     Assert.notNull(successHandler, "successHandler must be specified");
/* 129 */     this.userDetailsService = userDetailsService;
/* 130 */     this.successHandler = successHandler;
/* 131 */     this.failureHandler = failureHandler;
/* 132 */     this.securityContextRepository = (ServerSecurityContextRepository)new WebSessionServerSecurityContextRepository();
/* 133 */     this.userDetailsChecker = (UserDetailsChecker)new AccountStatusUserDetailsChecker();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SwitchUserWebFilter(ReactiveUserDetailsService userDetailsService, String successTargetUrl, @Nullable String failureTargetUrl) {
/* 147 */     Assert.notNull(userDetailsService, "userDetailsService must be specified");
/* 148 */     Assert.notNull(successTargetUrl, "successTargetUrl must be specified");
/* 149 */     this.userDetailsService = userDetailsService;
/* 150 */     this.successHandler = new RedirectServerAuthenticationSuccessHandler(successTargetUrl);
/* 151 */     this
/* 152 */       .failureHandler = (failureTargetUrl != null) ? new RedirectServerAuthenticationFailureHandler(failureTargetUrl) : null;
/* 153 */     this.securityContextRepository = (ServerSecurityContextRepository)new WebSessionServerSecurityContextRepository();
/* 154 */     this.userDetailsChecker = (UserDetailsChecker)new AccountStatusUserDetailsChecker();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 159 */     WebFilterExchange webFilterExchange = new WebFilterExchange(exchange, chain);
/* 160 */     return switchUser(webFilterExchange).switchIfEmpty(Mono.defer(() -> exitSwitchUser(webFilterExchange)))
/* 161 */       .switchIfEmpty(Mono.defer(() -> {
/*     */             this.logger.trace(LogMessage.format("Did not attempt to switch user since request did not match [%s] or [%s]", this.switchUserMatcher, this.exitUserMatcher));
/*     */ 
/*     */ 
/*     */             
/*     */             return chain.filter(exchange).then(Mono.empty());
/* 167 */           })).flatMap(authentication -> onAuthenticationSuccess(authentication, webFilterExchange))
/* 168 */       .onErrorResume(SwitchUserAuthenticationException.class, exception -> Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Authentication> switchUser(WebFilterExchange webFilterExchange) {
/* 180 */     return this.switchUserMatcher.matches(webFilterExchange.getExchange())
/* 181 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 182 */       .flatMap(matchResult -> ReactiveSecurityContextHolder.getContext())
/* 183 */       .map(SecurityContext::getAuthentication)
/* 184 */       .flatMap(currentAuthentication -> {
/*     */           String username = getUsername(webFilterExchange.getExchange());
/*     */           
/*     */           return attemptSwitchUser(currentAuthentication, username);
/* 188 */         }).onErrorResume(AuthenticationException.class, ex -> onAuthenticationFailure(ex, webFilterExchange).then(Mono.error(new SwitchUserAuthenticationException(ex))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Authentication> exitSwitchUser(WebFilterExchange webFilterExchange) {
/* 201 */     return this.exitUserMatcher.matches(webFilterExchange.getExchange())
/* 202 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 203 */       .flatMap(matchResult -> ReactiveSecurityContextHolder.getContext().map(SecurityContext::getAuthentication).switchIfEmpty(Mono.error(this::noCurrentUserException)))
/*     */ 
/*     */       
/* 206 */       .map(this::attemptExitUser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getUsername(ServerWebExchange exchange) {
/* 215 */     return (String)exchange.getRequest().getQueryParams().getFirst("username");
/*     */   }
/*     */   
/*     */   @NonNull
/*     */   private Mono<Authentication> attemptSwitchUser(Authentication currentAuthentication, String userName) {
/* 220 */     Assert.notNull(userName, "The userName can not be null.");
/* 221 */     this.logger.debug(LogMessage.format("Attempting to switch to user [%s]", userName));
/*     */ 
/*     */     
/* 224 */     Objects.requireNonNull(this.userDetailsChecker); return this.userDetailsService.findByUsername(userName).switchIfEmpty(Mono.error(this::noTargetAuthenticationException)).doOnNext(this.userDetailsChecker::check)
/* 225 */       .map(userDetails -> createSwitchUserToken(userDetails, currentAuthentication));
/*     */   }
/*     */   
/*     */   @NonNull
/*     */   private Authentication attemptExitUser(Authentication currentAuthentication) {
/* 230 */     Optional<Authentication> sourceAuthentication = extractSourceAuthentication(currentAuthentication);
/* 231 */     if (sourceAuthentication.isEmpty()) {
/* 232 */       this.logger.debug("Failed to find original user");
/* 233 */       throw noOriginalAuthenticationException();
/*     */     } 
/* 235 */     return sourceAuthentication.get();
/*     */   }
/*     */   
/*     */   private Mono<Void> onAuthenticationSuccess(Authentication authentication, WebFilterExchange webFilterExchange) {
/* 239 */     ServerWebExchange exchange = webFilterExchange.getExchange();
/* 240 */     SecurityContextImpl securityContext = new SecurityContextImpl(authentication);
/* 241 */     return this.securityContextRepository.save(exchange, (SecurityContext)securityContext)
/* 242 */       .doOnSuccess(v -> this.logger.debug(LogMessage.format("Switched user to %s", authentication)))
/* 243 */       .then(this.successHandler.onAuthenticationSuccess(webFilterExchange, authentication))
/* 244 */       .contextWrite((ContextView)ReactiveSecurityContextHolder.withSecurityContext(Mono.just(securityContext)));
/*     */   }
/*     */   
/*     */   private Mono<Void> onAuthenticationFailure(AuthenticationException exception, WebFilterExchange webFilterExchange) {
/* 248 */     return Mono.justOrEmpty(this.failureHandler).switchIfEmpty(Mono.defer(() -> {
/*     */             this.logger.debug("Failed to switch user", (Throwable)exception);
/*     */             return Mono.error((Throwable)exception);
/* 251 */           })).flatMap(failureHandler -> failureHandler.onAuthenticationFailure(webFilterExchange, exception));
/*     */   }
/*     */   
/*     */   private Authentication createSwitchUserToken(UserDetails targetUser, Authentication currentAuthentication) {
/* 255 */     Optional<Authentication> sourceAuthentication = extractSourceAuthentication(currentAuthentication);
/* 256 */     if (sourceAuthentication.isPresent()) {
/*     */       
/* 258 */       this.logger.debug(
/* 259 */           LogMessage.format("Found original switch user granted authority [%s]", sourceAuthentication.get()));
/* 260 */       currentAuthentication = sourceAuthentication.get();
/*     */     } 
/* 262 */     SwitchUserGrantedAuthority switchUserGrantedAuthority = new SwitchUserGrantedAuthority("ROLE_PREVIOUS_ADMINISTRATOR", currentAuthentication);
/*     */     
/* 264 */     Collection<? extends GrantedAuthority> targetUserAuthorities = targetUser.getAuthorities();
/* 265 */     List<GrantedAuthority> extendedTargetUserAuthorities = new ArrayList<>(targetUserAuthorities);
/* 266 */     extendedTargetUserAuthorities.add(switchUserGrantedAuthority);
/* 267 */     return (Authentication)UsernamePasswordAuthenticationToken.authenticated(targetUser, targetUser.getPassword(), extendedTargetUserAuthorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<Authentication> extractSourceAuthentication(Authentication currentAuthentication) {
/* 282 */     for (GrantedAuthority authority : currentAuthentication.getAuthorities()) {
/* 283 */       if (authority instanceof SwitchUserGrantedAuthority) { SwitchUserGrantedAuthority switchAuthority = (SwitchUserGrantedAuthority)authority;
/* 284 */         return Optional.of(switchAuthority.getSource()); }
/*     */     
/*     */     } 
/* 287 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   private static ServerWebExchangeMatcher createMatcher(String pattern) {
/* 291 */     return ServerWebExchangeMatchers.pathMatchers(HttpMethod.POST, new String[] { pattern });
/*     */   }
/*     */   
/*     */   private AuthenticationCredentialsNotFoundException noCurrentUserException() {
/* 295 */     return new AuthenticationCredentialsNotFoundException("No current user associated with this request");
/*     */   }
/*     */   
/*     */   private AuthenticationCredentialsNotFoundException noOriginalAuthenticationException() {
/* 299 */     return new AuthenticationCredentialsNotFoundException("Could not find original Authentication object");
/*     */   }
/*     */   
/*     */   private AuthenticationCredentialsNotFoundException noTargetAuthenticationException() {
/* 303 */     return new AuthenticationCredentialsNotFoundException("No target user for the given username");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(ServerSecurityContextRepository securityContextRepository) {
/* 312 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 313 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitUserUrl(String exitUserUrl) {
/* 322 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(exitUserUrl), "exitUserUrl cannot be empty and must be a valid redirect URL");
/*     */     
/* 324 */     this.exitUserMatcher = createMatcher(exitUserUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitUserMatcher(ServerWebExchangeMatcher exitUserMatcher) {
/* 332 */     Assert.notNull(exitUserMatcher, "exitUserMatcher cannot be null");
/* 333 */     this.exitUserMatcher = exitUserMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchUserUrl(String switchUserUrl) {
/* 342 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(switchUserUrl), "switchUserUrl cannot be empty and must be a valid redirect URL");
/*     */     
/* 344 */     this.switchUserMatcher = createMatcher(switchUserUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchUserMatcher(ServerWebExchangeMatcher switchUserMatcher) {
/* 352 */     Assert.notNull(switchUserMatcher, "switchUserMatcher cannot be null");
/* 353 */     this.switchUserMatcher = switchUserMatcher;
/*     */   }
/*     */   
/*     */   private static class SwitchUserAuthenticationException
/*     */     extends RuntimeException
/*     */   {
/*     */     SwitchUserAuthenticationException(AuthenticationException exception) {
/* 360 */       super((Throwable)exception);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\SwitchUserWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */