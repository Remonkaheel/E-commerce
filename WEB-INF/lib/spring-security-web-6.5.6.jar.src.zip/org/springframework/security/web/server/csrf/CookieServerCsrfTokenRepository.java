/*     */ package org.springframework.security.web.server.csrf;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CookieServerCsrfTokenRepository
/*     */   implements ServerCsrfTokenRepository
/*     */ {
/*     */   static final String DEFAULT_CSRF_COOKIE_NAME = "XSRF-TOKEN";
/*     */   static final String DEFAULT_CSRF_PARAMETER_NAME = "_csrf";
/*     */   static final String DEFAULT_CSRF_HEADER_NAME = "X-XSRF-TOKEN";
/*  49 */   private String parameterName = "_csrf";
/*     */   
/*  51 */   private String headerName = "X-XSRF-TOKEN";
/*     */   
/*     */   private String cookiePath;
/*     */   
/*     */   private String cookieDomain;
/*     */   
/*  57 */   private String cookieName = "XSRF-TOKEN";
/*     */   
/*     */   private boolean cookieHttpOnly = true;
/*     */   
/*     */   private Boolean secure;
/*     */   
/*  63 */   private int cookieMaxAge = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer = builder -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieCustomizer(Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer) {
/*  75 */     Assert.notNull(cookieCustomizer, "cookieCustomizer must not be null");
/*  76 */     this.cookieCustomizer = cookieCustomizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CookieServerCsrfTokenRepository withHttpOnlyFalse() {
/*  86 */     CookieServerCsrfTokenRepository result = new CookieServerCsrfTokenRepository();
/*  87 */     result.cookieHttpOnly = false;
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<CsrfToken> generateToken(ServerWebExchange exchange) {
/*  93 */     return Mono.fromCallable(this::createCsrfToken).subscribeOn(Schedulers.boundedElastic());
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveToken(ServerWebExchange exchange, CsrfToken token) {
/*  98 */     return Mono.fromRunnable(() -> {
/*     */           String tokenValue = (token != null) ? token.getToken() : "";
/*     */           ResponseCookie.ResponseCookieBuilder cookieBuilder = ResponseCookie.from(this.cookieName, tokenValue).domain(this.cookieDomain).httpOnly(this.cookieHttpOnly).maxAge(!tokenValue.isEmpty() ? this.cookieMaxAge : 0L).path((this.cookiePath != null) ? this.cookiePath : getRequestContext(exchange.getRequest())).secure((this.secure != null) ? this.secure.booleanValue() : ((exchange.getRequest().getSslInfo() != null)));
/*     */           this.cookieCustomizer.accept(cookieBuilder);
/*     */           exchange.getResponse().addCookie(cookieBuilder.build());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<CsrfToken> loadToken(ServerWebExchange exchange) {
/* 118 */     return Mono.fromCallable(() -> {
/*     */           HttpCookie csrfCookie = (HttpCookie)exchange.getRequest().getCookies().getFirst(this.cookieName);
/* 120 */           return (csrfCookie == null || !StringUtils.hasText(csrfCookie.getValue())) ? null : createCsrfToken(csrfCookie.getValue());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 132 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 140 */     Assert.hasLength(cookieName, "cookieName can't be null");
/* 141 */     this.cookieName = cookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterName(String parameterName) {
/* 149 */     Assert.hasLength(parameterName, "parameterName can't be null");
/* 150 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderName(String headerName) {
/* 158 */     Assert.hasLength(headerName, "headerName can't be null");
/* 159 */     this.headerName = headerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookiePath(String cookiePath) {
/* 167 */     this.cookiePath = cookiePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieDomain(String cookieDomain) {
/* 175 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setSecure(boolean secure) {
/* 184 */     this.secure = Boolean.valueOf(secure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieMaxAge(int cookieMaxAge) {
/* 193 */     Assert.isTrue((cookieMaxAge != 0), "cookieMaxAge cannot be zero");
/* 194 */     this.cookieMaxAge = cookieMaxAge;
/*     */   }
/*     */   
/*     */   private CsrfToken createCsrfToken() {
/* 198 */     return createCsrfToken(createNewToken());
/*     */   }
/*     */   
/*     */   private CsrfToken createCsrfToken(String tokenValue) {
/* 202 */     return new DefaultCsrfToken(this.headerName, this.parameterName, tokenValue);
/*     */   }
/*     */   
/*     */   private String createNewToken() {
/* 206 */     return UUID.randomUUID().toString();
/*     */   }
/*     */   
/*     */   private String getRequestContext(ServerHttpRequest request) {
/* 210 */     String contextPath = request.getPath().contextPath().value();
/* 211 */     return StringUtils.hasLength(contextPath) ? contextPath : "/";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\CookieServerCsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */