/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheControlServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String EXPIRES_VALUE = "0";
/*    */   public static final String PRAGMA_VALUE = "no-cache";
/*    */   public static final String CACHE_CONTRTOL_VALUE = "no-cache, no-store, max-age=0, must-revalidate";
/* 57 */   private static final ServerHttpHeadersWriter CACHE_HEADERS = StaticServerHttpHeadersWriter.builder()
/* 58 */     .header("Cache-Control", new String[] { "no-cache, no-store, max-age=0, must-revalidate"
/* 59 */       }).header("Pragma", new String[] { "no-cache"
/* 60 */       }).header("Expires", new String[] { "0"
/* 61 */       }).build();
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 65 */     if (exchange.getResponse().getStatusCode() == HttpStatus.NOT_MODIFIED) {
/* 66 */       return Mono.empty();
/*    */     }
/* 68 */     return CACHE_HEADERS.writeHttpHeaders(exchange);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CacheControlServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */