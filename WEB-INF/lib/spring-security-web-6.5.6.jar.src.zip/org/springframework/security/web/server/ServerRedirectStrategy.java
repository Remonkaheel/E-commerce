package org.springframework.security.web.server;

import java.net.URI;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@FunctionalInterface
public interface ServerRedirectStrategy {
  Mono<Void> sendRedirect(ServerWebExchange paramServerWebExchange, URI paramURI);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ServerRedirectStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */