/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AndServerWebExchangeMatcher
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/* 43 */   private static final Log logger = LogFactory.getLog(AndServerWebExchangeMatcher.class);
/*    */   
/*    */   private final List<ServerWebExchangeMatcher> matchers;
/*    */   
/*    */   public AndServerWebExchangeMatcher(List<ServerWebExchangeMatcher> matchers) {
/* 48 */     Assert.notEmpty(matchers, "matchers cannot be empty");
/* 49 */     this.matchers = matchers;
/*    */   }
/*    */   
/*    */   public AndServerWebExchangeMatcher(ServerWebExchangeMatcher... matchers) {
/* 53 */     this(Arrays.asList(matchers));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 58 */     return Mono.defer(() -> {
/*    */           Map<String, Object> variables = new HashMap<>();
/*    */           return Flux.fromIterable(this.matchers).doOnNext(()).flatMap(()).doOnNext(()).all(ServerWebExchangeMatcher.MatchResult::isMatch).flatMap(()).doOnNext(());
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return "AndServerWebExchangeMatcher{matchers=" + String.valueOf(this.matchers) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\AndServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */