/*    */ package org.springframework.security.web.server.authorization;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.util.matcher.IpAddressServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IpAddressReactiveAuthorizationManager
/*    */   implements ReactiveAuthorizationManager<AuthorizationContext>
/*    */ {
/*    */   private final IpAddressServerWebExchangeMatcher ipAddressExchangeMatcher;
/*    */   
/*    */   IpAddressReactiveAuthorizationManager(String ipAddress) {
/* 39 */     this.ipAddressExchangeMatcher = new IpAddressServerWebExchangeMatcher(ipAddress);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, AuthorizationContext context) {
/* 45 */     Objects.requireNonNull(this.ipAddressExchangeMatcher); return Mono.just(context.getExchange()).flatMap(this.ipAddressExchangeMatcher::matches)
/* 46 */       .map(matchResult -> new AuthorizationDecision(matchResult.isMatch()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IpAddressReactiveAuthorizationManager hasIpAddress(String ipAddress) {
/* 56 */     Assert.notNull(ipAddress, "This IP address is required; it must not be null");
/* 57 */     return new IpAddressReactiveAuthorizationManager(ipAddress);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\IpAddressReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */