/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.web.util.matcher.IpAddressMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IpAddressServerWebExchangeMatcher
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/*    */   private final IpAddressMatcher ipAddressMatcher;
/*    */   
/*    */   public IpAddressServerWebExchangeMatcher(String ipAddress) {
/* 43 */     Assert.hasText(ipAddress, "IP address cannot be empty");
/* 44 */     this.ipAddressMatcher = new IpAddressMatcher(ipAddress);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 52 */     Objects.requireNonNull(this.ipAddressMatcher); return Mono.justOrEmpty(exchange.getRequest().getRemoteAddress()).map(remoteAddress -> remoteAddress.isUnresolved() ? remoteAddress.getHostString() : remoteAddress.getAddress().getHostAddress()).map(this.ipAddressMatcher::matches)
/* 53 */       .flatMap(matches -> matches.booleanValue() ? ServerWebExchangeMatcher.MatchResult.match() : ServerWebExchangeMatcher.MatchResult.notMatch())
/* 54 */       .switchIfEmpty(ServerWebExchangeMatcher.MatchResult.notMatch());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return "IpAddressServerWebExchangeMatcher{ipAddressMatcher=" + String.valueOf(this.ipAddressMatcher) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\IpAddressServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */