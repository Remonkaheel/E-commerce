/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextImpl;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnonymousAuthenticationWebFilter
/*    */   implements WebFilter
/*    */ {
/* 48 */   private static final Log logger = LogFactory.getLog(AnonymousAuthenticationWebFilter.class);
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */   
/*    */   private Object principal;
/*    */ 
/*    */   
/*    */   private List<GrantedAuthority> authorities;
/*    */ 
/*    */ 
/*    */   
/*    */   public AnonymousAuthenticationWebFilter(String key) {
/* 62 */     this(key, "anonymousUser", AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AnonymousAuthenticationWebFilter(String key, Object principal, List<GrantedAuthority> authorities) {
/* 71 */     Assert.hasLength(key, "key cannot be null or empty");
/* 72 */     Assert.notNull(principal, "Anonymous authentication principal must be set");
/* 73 */     Assert.notNull(authorities, "Anonymous authorities must be set");
/* 74 */     this.key = key;
/* 75 */     this.principal = principal;
/* 76 */     this.authorities = authorities;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 81 */     return ReactiveSecurityContextHolder.getContext().switchIfEmpty(Mono.defer(() -> {
/*    */             Authentication authentication = createAuthentication(exchange);
/*    */             
/*    */             SecurityContextImpl securityContextImpl = new SecurityContextImpl(authentication);
/*    */             
/*    */             logger.debug(LogMessage.format("Populated SecurityContext with anonymous token: '%s'", authentication));
/*    */             return chain.filter(exchange).contextWrite((ContextView)ReactiveSecurityContextHolder.withSecurityContext(Mono.just(securityContextImpl))).then(Mono.empty());
/* 88 */           })).flatMap(securityContext -> {
/*    */           logger.debug(LogMessage.format("SecurityContext contains anonymous token: '%s'", securityContext.getAuthentication()));
/*    */           return chain.filter(exchange);
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   protected Authentication createAuthentication(ServerWebExchange exchange) {
/* 96 */     return (Authentication)new AnonymousAuthenticationToken(this.key, this.principal, this.authorities);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\AnonymousAuthenticationWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */