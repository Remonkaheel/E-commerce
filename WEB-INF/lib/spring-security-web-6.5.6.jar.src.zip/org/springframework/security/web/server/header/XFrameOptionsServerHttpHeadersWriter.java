/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XFrameOptionsServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String X_FRAME_OPTIONS = "X-Frame-Options";
/* 34 */   private ServerHttpHeadersWriter delegate = createDelegate(Mode.DENY);
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 38 */     return this.delegate.writeHttpHeaders(exchange);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMode(Mode mode) {
/* 51 */     this.delegate = createDelegate(mode);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Mode
/*    */   {
/* 70 */     DENY,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 79 */     SAMEORIGIN;
/*    */   }
/*    */ 
/*    */   
/*    */   private static ServerHttpHeadersWriter createDelegate(Mode mode) {
/* 84 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 85 */     builder.header("X-Frame-Options", new String[] { mode.name() });
/* 86 */     return builder.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\XFrameOptionsServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */