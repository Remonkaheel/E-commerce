package org.springframework.security.web.server.authentication.ott;

import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface ServerGenerateOneTimeTokenRequestResolver {
  Mono<GenerateOneTimeTokenRequest> resolve(ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\ServerGenerateOneTimeTokenRequestResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */