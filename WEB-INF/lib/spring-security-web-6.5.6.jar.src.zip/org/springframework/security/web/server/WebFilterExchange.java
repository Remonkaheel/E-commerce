/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebFilterExchange
/*    */ {
/*    */   private final ServerWebExchange exchange;
/*    */   private final WebFilterChain chain;
/*    */   
/*    */   public WebFilterExchange(ServerWebExchange exchange, WebFilterChain chain) {
/* 37 */     Assert.notNull(exchange, "exchange cannot be null");
/* 38 */     Assert.notNull(chain, "chain cannot be null");
/* 39 */     this.exchange = exchange;
/* 40 */     this.chain = chain;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerWebExchange getExchange() {
/* 48 */     return this.exchange;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebFilterChain getChain() {
/* 56 */     return this.chain;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\WebFilterExchange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */