/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpBasicServerAuthenticationEntryPoint
/*    */   implements ServerAuthenticationEntryPoint
/*    */ {
/*    */   private static final String WWW_AUTHENTICATE = "WWW-Authenticate";
/*    */   private static final String DEFAULT_REALM = "Realm";
/* 40 */   private static String WWW_AUTHENTICATE_FORMAT = "Basic realm=\"%s\"";
/*    */   
/* 42 */   private String headerValue = createHeaderValue("Realm");
/*    */ 
/*    */   
/*    */   public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException ex) {
/* 46 */     return Mono.fromRunnable(() -> {
/*    */           ServerHttpResponse response = exchange.getResponse();
/*    */           response.setStatusCode((HttpStatusCode)HttpStatus.UNAUTHORIZED);
/*    */           response.getHeaders().set("WWW-Authenticate", this.headerValue);
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRealm(String realm) {
/* 58 */     this.headerValue = createHeaderValue(realm);
/*    */   }
/*    */   
/*    */   private static String createHeaderValue(String realm) {
/* 62 */     Assert.notNull(realm, "realm cannot be null");
/* 63 */     return String.format(WWW_AUTHENTICATE_FORMAT, new Object[] { realm });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\HttpBasicServerAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */