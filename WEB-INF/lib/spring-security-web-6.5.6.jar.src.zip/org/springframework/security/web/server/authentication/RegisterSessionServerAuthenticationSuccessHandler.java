/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.session.ReactiveSessionInformation;
/*    */ import org.springframework.security.core.session.ReactiveSessionRegistry;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.WebSession;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RegisterSessionServerAuthenticationSuccessHandler
/*    */   implements ServerAuthenticationSuccessHandler
/*    */ {
/*    */   private final ReactiveSessionRegistry sessionRegistry;
/*    */   
/*    */   public RegisterSessionServerAuthenticationSuccessHandler(ReactiveSessionRegistry sessionRegistry) {
/* 39 */     Assert.notNull(sessionRegistry, "sessionRegistry cannot be null");
/* 40 */     this.sessionRegistry = sessionRegistry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> onAuthenticationSuccess(WebFilterExchange exchange, Authentication authentication) {
/* 49 */     Objects.requireNonNull(this.sessionRegistry); return exchange.getExchange().getSession().map(session -> new ReactiveSessionInformation(authentication.getPrincipal(), session.getId(), session.getLastAccessTime())).flatMap(this.sessionRegistry::saveSessionInformation);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\RegisterSessionServerAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */