/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.security.web.server.savedrequest.ServerRequestCache;
/*    */ import org.springframework.security.web.server.savedrequest.WebSessionServerRequestCache;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedirectServerAuthenticationSuccessHandler
/*    */   implements ServerAuthenticationSuccessHandler
/*    */ {
/* 41 */   private URI location = URI.create("/");
/*    */   
/* 43 */   private ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */   
/* 45 */   private ServerRequestCache requestCache = (ServerRequestCache)new WebSessionServerRequestCache();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RedirectServerAuthenticationSuccessHandler(String location) {
/* 59 */     this.location = URI.create(location);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequestCache(ServerRequestCache requestCache) {
/* 68 */     Assert.notNull(requestCache, "requestCache cannot be null");
/* 69 */     this.requestCache = requestCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> onAuthenticationSuccess(WebFilterExchange webFilterExchange, Authentication authentication) {
/* 74 */     ServerWebExchange exchange = webFilterExchange.getExchange();
/* 75 */     return this.requestCache.getRedirectUri(exchange)
/* 76 */       .defaultIfEmpty(this.location)
/* 77 */       .flatMap(location -> this.redirectStrategy.sendRedirect(exchange, location));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLocation(URI location) {
/* 85 */     Assert.notNull(location, "location cannot be null");
/* 86 */     this.location = location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRedirectStrategy(ServerRedirectStrategy redirectStrategy) {
/* 94 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 95 */     this.redirectStrategy = redirectStrategy;
/*    */   }
/*    */   
/*    */   public RedirectServerAuthenticationSuccessHandler() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\RedirectServerAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */