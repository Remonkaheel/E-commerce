/*     */ package org.springframework.security.web.server.header;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClearSiteDataServerHttpHeadersWriter
/*     */   implements ServerHttpHeadersWriter
/*     */ {
/*     */   public static final String CLEAR_SITE_DATA_HEADER = "Clear-Site-Data";
/*     */   private final StaticServerHttpHeadersWriter headerWriterDelegate;
/*     */   
/*     */   public ClearSiteDataServerHttpHeadersWriter(Directive... directives) {
/*  51 */     Assert.notEmpty((Object[])directives, "directives cannot be empty or null");
/*  52 */     this
/*     */       
/*  54 */       .headerWriterDelegate = StaticServerHttpHeadersWriter.builder().header("Clear-Site-Data", new String[] { transformToHeaderValue(directives) }).build();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/*  59 */     if (isSecure(exchange)) {
/*  60 */       return this.headerWriterDelegate.writeHttpHeaders(exchange);
/*     */     }
/*  62 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Directive
/*     */   {
/*  74 */     CACHE("cache"),
/*     */     
/*  76 */     COOKIES("cookies"),
/*     */     
/*  78 */     STORAGE("storage"),
/*     */     
/*  80 */     EXECUTION_CONTEXTS("executionContexts"),
/*     */     
/*  82 */     ALL("*");
/*     */     
/*     */     private final String headerValue;
/*     */     
/*     */     Directive(String headerValue) {
/*  87 */       this.headerValue = "\"" + headerValue + "\"";
/*     */     }
/*     */     
/*     */     public String getHeaderValue() {
/*  91 */       return this.headerValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private String transformToHeaderValue(Directive... directives) {
/*  97 */     StringBuilder sb = new StringBuilder();
/*  98 */     for (int i = 0; i < directives.length - 1; i++) {
/*  99 */       sb.append((directives[i]).headerValue).append(", ");
/*     */     }
/* 101 */     sb.append((directives[directives.length - 1]).headerValue);
/* 102 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private boolean isSecure(ServerWebExchange exchange) {
/* 106 */     String scheme = exchange.getRequest().getURI().getScheme();
/* 107 */     return (scheme != null && scheme.equalsIgnoreCase("https"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\ClearSiteDataServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */