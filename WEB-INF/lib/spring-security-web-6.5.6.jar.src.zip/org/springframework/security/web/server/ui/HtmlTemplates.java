/*     */ package org.springframework.security.web.server.ui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HtmlTemplates
/*     */ {
/*     */   static Builder fromTemplate(String template) {
/*  41 */     return new Builder(template);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Builder
/*     */   {
/*     */     private final String template;
/*  48 */     private final Map<String, String> values = new HashMap<>();
/*     */     
/*     */     private Builder(String template) {
/*  51 */       this.template = template;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder withValue(String key, String value) {
/*  62 */       this.values.put(key, HtmlUtils.htmlEscape(value));
/*  63 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder withRawHtml(String key, String value) {
/*  74 */       if (!value.isEmpty() && value.charAt(value.length() - 1) == '\n') {
/*  75 */         value = value.substring(0, value.length() - 1);
/*     */       }
/*  77 */       this.values.put(key, value);
/*  78 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String render() {
/*  88 */       String template = this.template;
/*  89 */       for (String key : this.values.keySet()) {
/*  90 */         String pattern = Pattern.quote("{{" + key + "}}");
/*  91 */         template = template.replaceAll(pattern, this.values.get(key));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       String unusedPlaceholders = Pattern.compile("\\{\\{([a-zA-Z0-9]+)}}").matcher(template).results().<CharSequence>map(result -> result.group(1)).collect(Collectors.joining(", "));
/*  99 */       if (StringUtils.hasLength(unusedPlaceholders)) {
/* 100 */         throw new IllegalStateException("Unused placeholders in template: [%s]".formatted(new Object[] { unusedPlaceholders }));
/*     */       }
/*     */       
/* 103 */       return template;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\ui\HtmlTemplates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */