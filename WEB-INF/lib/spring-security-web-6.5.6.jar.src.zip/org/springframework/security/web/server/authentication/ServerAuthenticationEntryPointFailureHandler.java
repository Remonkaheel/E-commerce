/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.security.authentication.AuthenticationServiceException;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerAuthenticationEntryPointFailureHandler
/*    */   implements ServerAuthenticationFailureHandler
/*    */ {
/*    */   private final ServerAuthenticationEntryPoint authenticationEntryPoint;
/*    */   private boolean rethrowAuthenticationServiceException = true;
/*    */   
/*    */   public ServerAuthenticationEntryPointFailureHandler(ServerAuthenticationEntryPoint authenticationEntryPoint) {
/* 41 */     Assert.notNull(authenticationEntryPoint, "authenticationEntryPoint cannot be null");
/* 42 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> onAuthenticationFailure(WebFilterExchange webFilterExchange, AuthenticationException exception) {
/* 47 */     if (!this.rethrowAuthenticationServiceException) {
/* 48 */       return this.authenticationEntryPoint.commence(webFilterExchange.getExchange(), exception);
/*    */     }
/* 50 */     if (!AuthenticationServiceException.class.isAssignableFrom(exception.getClass())) {
/* 51 */       return this.authenticationEntryPoint.commence(webFilterExchange.getExchange(), exception);
/*    */     }
/* 53 */     return Mono.error((Throwable)exception);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRethrowAuthenticationServiceException(boolean rethrowAuthenticationServiceException) {
/* 63 */     this.rethrowAuthenticationServiceException = rethrowAuthenticationServiceException;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerAuthenticationEntryPointFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */