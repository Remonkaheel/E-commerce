/*    */ package org.springframework.security.web.server.context;
/*    */ 
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoOpServerSecurityContextRepository
/*    */   implements ServerSecurityContextRepository
/*    */ {
/* 33 */   private static final NoOpServerSecurityContextRepository INSTANCE = new NoOpServerSecurityContextRepository();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> save(ServerWebExchange exchange, SecurityContext context) {
/* 40 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<SecurityContext> load(ServerWebExchange exchange) {
/* 45 */     return Mono.empty();
/*    */   }
/*    */   
/*    */   public static NoOpServerSecurityContextRepository getInstance() {
/* 49 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\NoOpServerSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */