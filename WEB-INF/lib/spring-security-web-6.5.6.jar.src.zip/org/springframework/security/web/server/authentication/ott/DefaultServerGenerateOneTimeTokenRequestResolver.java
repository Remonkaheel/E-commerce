/*    */ package org.springframework.security.web.server.authentication.ott;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultServerGenerateOneTimeTokenRequestResolver
/*    */   implements ServerGenerateOneTimeTokenRequestResolver
/*    */ {
/*    */   private static final String USERNAME = "username";
/* 39 */   private static final Duration DEFAULT_EXPIRES_IN = Duration.ofMinutes(5L);
/*    */   
/* 41 */   private Duration expiresIn = DEFAULT_EXPIRES_IN;
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<GenerateOneTimeTokenRequest> resolve(ServerWebExchange exchange) {
/* 46 */     return exchange.getFormData()
/* 47 */       .mapNotNull(data -> (String)data.getFirst("username"))
/* 48 */       .switchIfEmpty(Mono.empty())
/* 49 */       .map(username -> new GenerateOneTimeTokenRequest(username, this.expiresIn));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExpiresIn(Duration expiresIn) {
/* 58 */     Assert.notNull(expiresIn, "expiresIn cannot be null");
/* 59 */     this.expiresIn = expiresIn;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\DefaultServerGenerateOneTimeTokenRequestResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */