/*     */ package org.springframework.security.web.server.ui;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.security.web.server.csrf.CsrfToken;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoginPageGeneratingWebFilter
/*     */   implements WebFilter
/*     */ {
/*  50 */   private ServerWebExchangeMatcher matcher = ServerWebExchangeMatchers.pathMatchers(HttpMethod.GET, new String[] { "/login" });
/*     */   
/*  52 */   private Map<String, String> oauth2AuthenticationUrlToClientName = new HashMap<>();
/*     */   
/*     */   private boolean formLoginEnabled;
/*     */   
/*     */   private boolean oneTimeTokenEnabled = false;
/*     */   private String generateOneTimeTokenUrl;
/*     */   private static final String LOGIN_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Please sign in</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n{{formLogin}}\n{{oneTimeTokenLogin}}\n{{oauth2Login}}\n    </div>\n  </body>\n</html>";
/*     */   private static final String LOGIN_FORM_TEMPLATE = "      <form class=\"login-form\" method=\"post\" action=\"{{loginUrl}}\">\n        <h2>Please sign in</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"username\" name=\"username\" placeholder=\"Username\" required autofocus>\n        </p>\n        <p>\n          <label for=\"password\" class=\"screenreader\">Password</label>\n          <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\" required>\n        </p>\n{{csrf}}\n        <button type=\"submit\" class=\"primary\">Sign in</button>\n      </form>";
/*     */   private static final String CSRF_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*     */   private static final String OAUTH2_LOGIN_TEMPLATE = "<h2>Login with OAuth 2.0</h2>\n{{errorMessage}}\n<table class=\"table table-striped\">\n{{oauth2Rows}}\n</table>";
/*     */   private static final String OAUTH2_ROW_TEMPLATE = "<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>";
/*     */   private static final String ONE_TIME_TEMPLATE = "      <form id=\"ott-form\" class=\"login-form\" method=\"post\" action=\"{{generateOneTimeTokenUrl}}\">\n        <h2>Request a One-Time Token</h2>\n      {{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"ott-username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"ott-username\" name=\"username\" placeholder=\"Username\" required>\n        </p>\n        {{csrf}}\n        <button class=\"primary\" type=\"submit\" form=\"ott-form\">Send Token</button>\n      </form>\n";
/*     */   
/*     */   public void setGenerateOneTimeTokenUrl(String generateOneTimeTokenUrl) {
/*  66 */     Assert.isTrue(StringUtils.hasText(generateOneTimeTokenUrl), "generateOneTimeTokenUrl cannot be null or empty");
/*  67 */     this.generateOneTimeTokenUrl = generateOneTimeTokenUrl;
/*     */   }
/*     */   
/*     */   public void setFormLoginEnabled(boolean enabled) {
/*  71 */     this.formLoginEnabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOneTimeTokenEnabled(boolean oneTimeTokenEnabled) {
/*  79 */     this.oneTimeTokenEnabled = oneTimeTokenEnabled;
/*     */   }
/*     */   
/*     */   public void setOauth2AuthenticationUrlToClientName(Map<String, String> oauth2AuthenticationUrlToClientName) {
/*  83 */     Assert.notNull(oauth2AuthenticationUrlToClientName, "oauth2AuthenticationUrlToClientName cannot be null");
/*  84 */     this.oauth2AuthenticationUrlToClientName = oauth2AuthenticationUrlToClientName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/*  89 */     return this.matcher.matches(exchange)
/*  90 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/*  91 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/*  92 */       .flatMap(matchResult -> render(exchange));
/*     */   }
/*     */   
/*     */   private Mono<Void> render(ServerWebExchange exchange) {
/*  96 */     ServerHttpResponse result = exchange.getResponse();
/*  97 */     result.setStatusCode((HttpStatusCode)HttpStatus.OK);
/*  98 */     result.getHeaders().setContentType(MediaType.TEXT_HTML);
/*  99 */     return result.writeWith((Publisher)createBuffer(exchange));
/*     */   }
/*     */   
/*     */   private Mono<DataBuffer> createBuffer(ServerWebExchange exchange) {
/* 103 */     Mono<CsrfToken> token = (Mono<CsrfToken>)exchange.getAttributeOrDefault(CsrfToken.class.getName(), Mono.empty());
/* 104 */     return token.map(LoginPageGeneratingWebFilter::csrfToken).defaultIfEmpty("").map(csrfTokenHtmlInput -> {
/*     */           byte[] bytes = createPage(exchange, csrfTokenHtmlInput);
/*     */           DataBufferFactory bufferFactory = exchange.getResponse().bufferFactory();
/*     */           return bufferFactory.wrap(bytes);
/*     */         });
/*     */   }
/*     */   
/*     */   private byte[] createPage(ServerWebExchange exchange, String csrfTokenHtmlInput) {
/* 112 */     MultiValueMap<String, String> queryParams = exchange.getRequest().getQueryParams();
/* 113 */     String contextPath = exchange.getRequest().getPath().contextPath().value();
/*     */     
/* 115 */     return HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Please sign in</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n{{formLogin}}\n{{oneTimeTokenLogin}}\n{{oauth2Login}}\n    </div>\n  </body>\n</html>")
/* 116 */       .withRawHtml("contextPath", contextPath)
/* 117 */       .withRawHtml("formLogin", formLogin(queryParams, contextPath, csrfTokenHtmlInput))
/* 118 */       .withRawHtml("oneTimeTokenLogin", renderOneTimeTokenLogin(queryParams, contextPath, csrfTokenHtmlInput))
/* 119 */       .withRawHtml("oauth2Login", oauth2Login(queryParams, contextPath, this.oauth2AuthenticationUrlToClientName))
/* 120 */       .render()
/* 121 */       .getBytes(Charset.defaultCharset());
/*     */   }
/*     */   
/*     */   private String formLogin(MultiValueMap<String, String> queryParams, String contextPath, String csrfTokenHtmlInput) {
/* 125 */     if (!this.formLoginEnabled) {
/* 126 */       return "";
/*     */     }
/*     */     
/* 129 */     boolean isError = queryParams.containsKey("error");
/* 130 */     boolean isLogoutSuccess = queryParams.containsKey("logout");
/*     */     
/* 132 */     return HtmlTemplates.fromTemplate("      <form class=\"login-form\" method=\"post\" action=\"{{loginUrl}}\">\n        <h2>Please sign in</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"username\" name=\"username\" placeholder=\"Username\" required autofocus>\n        </p>\n        <p>\n          <label for=\"password\" class=\"screenreader\">Password</label>\n          <input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Password\" required>\n        </p>\n{{csrf}}\n        <button type=\"submit\" class=\"primary\">Sign in</button>\n      </form>")
/* 133 */       .withValue("loginUrl", contextPath + "/login")
/* 134 */       .withRawHtml("errorMessage", createError(isError))
/* 135 */       .withRawHtml("logoutMessage", createLogoutSuccess(isLogoutSuccess))
/* 136 */       .withRawHtml("csrf", csrfTokenHtmlInput)
/* 137 */       .render();
/*     */   }
/*     */ 
/*     */   
/*     */   private String renderOneTimeTokenLogin(MultiValueMap<String, String> queryParams, String contextPath, String csrfTokenHtmlInput) {
/* 142 */     if (!this.oneTimeTokenEnabled) {
/* 143 */       return "";
/*     */     }
/*     */     
/* 146 */     boolean isError = queryParams.containsKey("error");
/* 147 */     boolean isLogoutSuccess = queryParams.containsKey("logout");
/*     */     
/* 149 */     return HtmlTemplates.fromTemplate("      <form id=\"ott-form\" class=\"login-form\" method=\"post\" action=\"{{generateOneTimeTokenUrl}}\">\n        <h2>Request a One-Time Token</h2>\n      {{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"ott-username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"ott-username\" name=\"username\" placeholder=\"Username\" required>\n        </p>\n        {{csrf}}\n        <button class=\"primary\" type=\"submit\" form=\"ott-form\">Send Token</button>\n      </form>\n")
/* 150 */       .withValue("generateOneTimeTokenUrl", contextPath + contextPath)
/* 151 */       .withRawHtml("errorMessage", createError(isError))
/* 152 */       .withRawHtml("logoutMessage", createLogoutSuccess(isLogoutSuccess))
/* 153 */       .withRawHtml("csrf", csrfTokenHtmlInput)
/* 154 */       .render();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String oauth2Login(MultiValueMap<String, String> queryParams, String contextPath, Map<String, String> oauth2AuthenticationUrlToClientName) {
/* 159 */     if (oauth2AuthenticationUrlToClientName.isEmpty()) {
/* 160 */       return "";
/*     */     }
/* 162 */     boolean isError = queryParams.containsKey("error");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     String oauth2Rows = ((String)oauth2AuthenticationUrlToClientName.entrySet().stream().map(urlToName -> oauth2LoginLink(contextPath, (String)urlToName.getKey(), (String)urlToName.getValue())).collect(Collectors.joining("\n"))).indent(2);
/* 169 */     return HtmlTemplates.fromTemplate("<h2>Login with OAuth 2.0</h2>\n{{errorMessage}}\n<table class=\"table table-striped\">\n{{oauth2Rows}}\n</table>")
/* 170 */       .withRawHtml("errorMessage", createError(isError))
/* 171 */       .withRawHtml("oauth2Rows", oauth2Rows)
/* 172 */       .render();
/*     */   }
/*     */   
/*     */   private static String oauth2LoginLink(String contextPath, String url, String clientName) {
/* 176 */     return HtmlTemplates.fromTemplate("<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>")
/* 177 */       .withValue("url", contextPath + contextPath)
/* 178 */       .withValue("clientName", clientName)
/* 179 */       .render();
/*     */   }
/*     */   
/*     */   private static String csrfToken(CsrfToken token) {
/* 183 */     return HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n")
/* 184 */       .withValue("name", token.getParameterName())
/* 185 */       .withValue("value", token.getToken())
/* 186 */       .render();
/*     */   }
/*     */   
/*     */   private static String createError(boolean isError) {
/* 190 */     return isError ? "<div class=\"alert alert-danger\" role=\"alert\">Invalid credentials</div>" : "";
/*     */   }
/*     */   
/*     */   private static String createLogoutSuccess(boolean isLogoutSuccess) {
/* 194 */     return isLogoutSuccess ? "<div class=\"alert alert-success\" role=\"alert\">You have been signed out</div>" : 
/* 195 */       "";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\ui\LoginPageGeneratingWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */