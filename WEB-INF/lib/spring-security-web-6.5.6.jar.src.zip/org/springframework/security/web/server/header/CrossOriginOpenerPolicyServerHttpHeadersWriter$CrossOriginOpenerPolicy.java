/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CrossOriginOpenerPolicy
/*    */ {
/* 62 */   UNSAFE_NONE("unsafe-none"),
/*    */   
/* 64 */   SAME_ORIGIN_ALLOW_POPUPS("same-origin-allow-popups"),
/*    */   
/* 66 */   SAME_ORIGIN("same-origin");
/*    */   
/*    */   private final String policy;
/*    */   
/*    */   CrossOriginOpenerPolicy(String policy) {
/* 71 */     this.policy = policy;
/*    */   }
/*    */   
/*    */   public String getPolicy() {
/* 75 */     return this.policy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginOpenerPolicyServerHttpHeadersWriter$CrossOriginOpenerPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */