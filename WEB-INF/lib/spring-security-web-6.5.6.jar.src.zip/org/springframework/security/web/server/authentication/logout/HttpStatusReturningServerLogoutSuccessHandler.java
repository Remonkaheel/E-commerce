/*    */ package org.springframework.security.web.server.authentication.logout;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpStatusReturningServerLogoutSuccessHandler
/*    */   implements ServerLogoutSuccessHandler
/*    */ {
/*    */   private final HttpStatus httpStatusToReturn;
/*    */   
/*    */   public HttpStatusReturningServerLogoutSuccessHandler(HttpStatus httpStatusToReturn) {
/* 44 */     Assert.notNull(httpStatusToReturn, "The provided HttpStatus must not be null.");
/* 45 */     this.httpStatusToReturn = httpStatusToReturn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusReturningServerLogoutSuccessHandler() {
/* 53 */     this.httpStatusToReturn = HttpStatus.OK;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> onLogoutSuccess(WebFilterExchange exchange, Authentication authentication) {
/* 66 */     return Mono.fromRunnable(() -> exchange.getExchange().getResponse().setStatusCode((HttpStatusCode)this.httpStatusToReturn));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\HttpStatusReturningServerLogoutSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */