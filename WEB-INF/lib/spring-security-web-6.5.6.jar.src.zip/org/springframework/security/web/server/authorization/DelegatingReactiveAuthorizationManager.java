/*    */ package org.springframework.security.web.server.authorization;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcherEntry;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingReactiveAuthorizationManager
/*    */   implements ReactiveAuthorizationManager<ServerWebExchange>
/*    */ {
/* 42 */   private static final Log logger = LogFactory.getLog(DelegatingReactiveAuthorizationManager.class);
/*    */   
/*    */   private final List<ServerWebExchangeMatcherEntry<ReactiveAuthorizationManager<AuthorizationContext>>> mappings;
/*    */ 
/*    */   
/*    */   private DelegatingReactiveAuthorizationManager(List<ServerWebExchangeMatcherEntry<ReactiveAuthorizationManager<AuthorizationContext>>> mappings) {
/* 48 */     this.mappings = mappings;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, ServerWebExchange exchange) {
/* 57 */     return Flux.fromIterable(this.mappings)
/* 58 */       .concatMap(mapping -> mapping.getMatcher().matches(exchange).filter(ServerWebExchangeMatcher.MatchResult::isMatch).map(ServerWebExchangeMatcher.MatchResult::getVariables).flatMap(()))
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 68 */       .next()
/* 69 */       .defaultIfEmpty(new AuthorizationDecision(false));
/*    */   }
/*    */   
/*    */   public static Builder builder() {
/* 73 */     return new Builder();
/*    */   }
/*    */   
/*    */   public static final class Builder
/*    */   {
/* 78 */     private final List<ServerWebExchangeMatcherEntry<ReactiveAuthorizationManager<AuthorizationContext>>> mappings = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Builder add(ServerWebExchangeMatcherEntry<ReactiveAuthorizationManager<AuthorizationContext>> entry) {
/* 85 */       this.mappings.add(entry);
/* 86 */       return this;
/*    */     }
/*    */     
/*    */     public DelegatingReactiveAuthorizationManager build() {
/* 90 */       return new DelegatingReactiveAuthorizationManager(this.mappings);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\DelegatingReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */