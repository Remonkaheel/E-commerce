/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpStatusServerEntryPoint
/*    */   implements ServerAuthenticationEntryPoint
/*    */ {
/*    */   private final HttpStatus httpStatus;
/*    */   
/*    */   public HttpStatusServerEntryPoint(HttpStatus httpStatus) {
/* 40 */     Assert.notNull(httpStatus, "httpStatus cannot be null");
/* 41 */     this.httpStatus = httpStatus;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException authException) {
/* 46 */     return Mono.fromRunnable(() -> exchange.getResponse().setStatusCode((HttpStatusCode)this.httpStatus));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\HttpStatusServerEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */