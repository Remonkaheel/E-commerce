/*    */ package org.springframework.security.web.server.context;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebSession;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebSessionServerSecurityContextRepository
/*    */   implements ServerSecurityContextRepository
/*    */ {
/* 40 */   private static final Log logger = LogFactory.getLog(WebSessionServerSecurityContextRepository.class);
/*    */ 
/*    */ 
/*    */   
/*    */   public static final String DEFAULT_SPRING_SECURITY_CONTEXT_ATTR_NAME = "SPRING_SECURITY_CONTEXT";
/*    */ 
/*    */   
/* 47 */   private String springSecurityContextAttrName = "SPRING_SECURITY_CONTEXT";
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean cacheSecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSpringSecurityContextAttrName(String springSecurityContextAttrName) {
/* 57 */     Assert.hasText(springSecurityContextAttrName, "springSecurityContextAttrName cannot be null or empty");
/* 58 */     this.springSecurityContextAttrName = springSecurityContextAttrName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCacheSecurityContext(boolean cacheSecurityContext) {
/* 68 */     this.cacheSecurityContext = cacheSecurityContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> save(ServerWebExchange exchange, SecurityContext context) {
/* 73 */     return exchange.getSession().doOnNext(session -> {
/*    */           if (context == null) {
/*    */             session.getAttributes().remove(this.springSecurityContextAttrName);
/*    */             
/*    */             logger.debug(LogMessage.format("Removed SecurityContext stored in WebSession: '%s'", session));
/*    */           } else {
/*    */             session.getAttributes().put(this.springSecurityContextAttrName, context);
/*    */             logger.debug(LogMessage.format("Saved SecurityContext '%s' in WebSession: '%s'", context, session));
/*    */           } 
/* 82 */         }).flatMap(WebSession::changeSessionId);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<SecurityContext> load(ServerWebExchange exchange) {
/* 87 */     Mono<SecurityContext> result = exchange.getSession().flatMap(session -> {
/*    */           SecurityContext context = (SecurityContext)session.getAttribute(this.springSecurityContextAttrName);
/*    */           
/*    */           logger.debug((context != null) ? LogMessage.format("Found SecurityContext '%s' in WebSession: '%s'", context, session) : LogMessage.format("No SecurityContext found in WebSession: '%s'", session));
/*    */           
/*    */           return Mono.justOrEmpty(context);
/*    */         });
/* 94 */     return this.cacheSecurityContext ? result.cache() : result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\WebSessionServerSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */