/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   private final HttpHeaders headersToAdd;
/*    */   
/*    */   public StaticServerHttpHeadersWriter(HttpHeaders headersToAdd) {
/* 37 */     this.headersToAdd = headersToAdd;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 42 */     HttpHeaders headers = exchange.getResponse().getHeaders();
/*    */ 
/*    */     
/* 45 */     boolean containsNoHeadersToAdd = true;
/* 46 */     for (String headerName : this.headersToAdd.keySet()) {
/* 47 */       if (headers.containsKey(headerName)) {
/* 48 */         containsNoHeadersToAdd = false;
/*    */         break;
/*    */       } 
/*    */     } 
/* 52 */     if (containsNoHeadersToAdd) {
/* 53 */       Objects.requireNonNull(headers); this.headersToAdd.forEach(headers::put);
/*    */     } 
/* 55 */     return Mono.empty();
/*    */   }
/*    */   
/*    */   public static Builder builder() {
/* 59 */     return new Builder();
/*    */   }
/*    */   
/*    */   public static class Builder
/*    */   {
/* 64 */     private HttpHeaders headers = new HttpHeaders();
/*    */     
/*    */     public Builder header(String headerName, String... values) {
/* 67 */       this.headers.put(headerName, Arrays.asList(values));
/* 68 */       return this;
/*    */     }
/*    */     
/*    */     public StaticServerHttpHeadersWriter build() {
/* 72 */       return new StaticServerHttpHeadersWriter(this.headers);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\StaticServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */