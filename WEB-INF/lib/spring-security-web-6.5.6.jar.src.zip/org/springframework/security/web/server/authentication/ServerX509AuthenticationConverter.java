/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.server.reactive.SslInfo;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerX509AuthenticationConverter
/*    */   implements ServerAuthenticationConverter
/*    */ {
/* 41 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final X509PrincipalExtractor principalExtractor;
/*    */   
/*    */   public ServerX509AuthenticationConverter(@NonNull X509PrincipalExtractor principalExtractor) {
/* 46 */     this.principalExtractor = principalExtractor;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Authentication> convert(ServerWebExchange exchange) {
/* 51 */     SslInfo sslInfo = exchange.getRequest().getSslInfo();
/* 52 */     if (sslInfo == null) {
/* 53 */       this.logger.debug("No SslInfo provided with a request, skipping x509 authentication");
/* 54 */       return Mono.empty();
/*    */     } 
/* 56 */     if (sslInfo.getPeerCertificates() == null || (sslInfo.getPeerCertificates()).length == 0) {
/* 57 */       this.logger.debug("No peer certificates found in SslInfo, skipping x509 authentication");
/* 58 */       return Mono.empty();
/*    */     } 
/* 60 */     X509Certificate clientCertificate = sslInfo.getPeerCertificates()[0];
/* 61 */     Object principal = this.principalExtractor.extractPrincipal(clientCertificate);
/* 62 */     return Mono.just(new PreAuthenticatedAuthenticationToken(principal, clientCertificate));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerX509AuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */