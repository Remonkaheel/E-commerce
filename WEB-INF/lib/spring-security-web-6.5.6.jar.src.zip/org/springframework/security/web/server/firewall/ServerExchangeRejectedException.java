/*    */ package org.springframework.security.web.server.firewall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerExchangeRejectedException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 904984955691607748L;
/*    */   
/*    */   public ServerExchangeRejectedException(String message) {
/* 33 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\ServerExchangeRejectedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */