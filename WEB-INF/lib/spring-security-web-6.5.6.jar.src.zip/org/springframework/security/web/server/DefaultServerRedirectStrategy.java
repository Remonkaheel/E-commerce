/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultServerRedirectStrategy
/*    */   implements ServerRedirectStrategy
/*    */ {
/* 40 */   private static final Log logger = LogFactory.getLog(DefaultServerRedirectStrategy.class);
/*    */   
/* 42 */   private HttpStatus httpStatus = HttpStatus.FOUND;
/*    */   
/*    */   private boolean contextRelative = true;
/*    */ 
/*    */   
/*    */   public Mono<Void> sendRedirect(ServerWebExchange exchange, URI location) {
/* 48 */     Assert.notNull(exchange, "exchange cannot be null");
/* 49 */     Assert.notNull(location, "location cannot be null");
/* 50 */     return Mono.fromRunnable(() -> {
/*    */           ServerHttpResponse response = exchange.getResponse();
/*    */           response.setStatusCode((HttpStatusCode)this.httpStatus);
/*    */           URI newLocation = createLocation(exchange, location);
/*    */           logger.debug(LogMessage.format("Redirecting to '%s'", newLocation));
/*    */           response.getHeaders().setLocation(newLocation);
/*    */         });
/*    */   }
/*    */   
/*    */   private URI createLocation(ServerWebExchange exchange, URI location) {
/* 60 */     if (!this.contextRelative) {
/* 61 */       return location;
/*    */     }
/* 63 */     String url = location.toASCIIString();
/* 64 */     if (url.startsWith("/")) {
/* 65 */       String context = exchange.getRequest().getPath().contextPath().value();
/* 66 */       return URI.create(context + context);
/*    */     } 
/* 68 */     return location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHttpStatus(HttpStatus httpStatus) {
/* 76 */     Assert.notNull(httpStatus, "httpStatus cannot be null");
/* 77 */     this.httpStatus = httpStatus;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContextRelative(boolean contextRelative) {
/* 86 */     this.contextRelative = contextRelative;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\DefaultServerRedirectStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */