/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import org.springframework.web.server.WebHandler;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ObservationWebFilterChain
/*     */   implements WebFilterChain
/*     */ {
/*     */   private final WebHandler handler;
/*     */   @Nullable
/*     */   private final ObservationWebFilterChainDecorator.ObservationWebFilter currentFilter;
/*     */   @Nullable
/*     */   private final ObservationWebFilterChain chain;
/*     */   
/*     */   ObservationWebFilterChain(WebHandler handler, List<ObservationWebFilterChainDecorator.ObservationWebFilter> filters) {
/* 124 */     Assert.notNull(handler, "WebHandler is required");
/* 125 */     this.handler = handler;
/* 126 */     ObservationWebFilterChain chain = initChain(filters, handler);
/* 127 */     this.currentFilter = chain.currentFilter;
/* 128 */     this.chain = chain.chain;
/*     */   }
/*     */   
/*     */   private static ObservationWebFilterChain initChain(List<ObservationWebFilterChainDecorator.ObservationWebFilter> filters, WebHandler handler) {
/* 132 */     ObservationWebFilterChain chain = new ObservationWebFilterChain(handler, null, null);
/* 133 */     ListIterator<? extends ObservationWebFilterChainDecorator.ObservationWebFilter> iterator = filters.listIterator(filters.size());
/* 134 */     while (iterator.hasPrevious()) {
/* 135 */       chain = new ObservationWebFilterChain(handler, iterator.previous(), chain);
/*     */     }
/* 137 */     return chain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObservationWebFilterChain(WebHandler handler, @Nullable ObservationWebFilterChainDecorator.ObservationWebFilter currentFilter, @Nullable ObservationWebFilterChain chain) {
/* 145 */     this.currentFilter = currentFilter;
/* 146 */     this.handler = handler;
/* 147 */     this.chain = chain;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange) {
/* 152 */     return Mono.defer(() -> (this.currentFilter != null && this.chain != null) ? invokeFilter(this.currentFilter, this.chain, exchange) : this.handler.handle(exchange));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Void> invokeFilter(ObservationWebFilterChainDecorator.ObservationWebFilter current, ObservationWebFilterChain chain, ServerWebExchange exchange) {
/* 158 */     String currentName = current.getName();
/* 159 */     return current.filter(exchange, chain).checkpoint(currentName + " [DefaultWebFilterChain]");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ObservationWebFilterChainDecorator$ObservationWebFilterChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */