/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedirectServerAuthenticationFailureHandler
/*    */   implements ServerAuthenticationFailureHandler
/*    */ {
/*    */   private final URI location;
/* 39 */   private ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RedirectServerAuthenticationFailureHandler(String location) {
/* 46 */     Assert.notNull(location, "location cannot be null");
/* 47 */     this.location = URI.create(location);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRedirectStrategy(ServerRedirectStrategy redirectStrategy) {
/* 55 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 56 */     this.redirectStrategy = redirectStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> onAuthenticationFailure(WebFilterExchange webFilterExchange, AuthenticationException exception) {
/* 61 */     return this.redirectStrategy.sendRedirect(webFilterExchange.getExchange(), this.location);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\RedirectServerAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */