/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.security.web.authentication.session.SessionAuthenticationException;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PreventLoginServerMaximumSessionsExceededHandler
/*    */   implements ServerMaximumSessionsExceededHandler
/*    */ {
/*    */   public Mono<Void> handle(MaximumSessionsContext context) {
/* 34 */     return context.getCurrentSession()
/* 35 */       .invalidate()
/* 36 */       .then(Mono.defer(() -> Mono.error((Throwable)new SessionAuthenticationException("Maximum sessions exceeded"))));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\PreventLoginServerMaximumSessionsExceededHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */