/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ContentSecurityPolicyServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";
/*    */   public static final String CONTENT_SECURITY_POLICY_REPORT_ONLY = "Content-Security-Policy-Report-Only";
/*    */   private String policyDirectives;
/*    */   private boolean reportOnly;
/*    */   private ServerHttpHeadersWriter delegate;
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 46 */     return (this.delegate != null) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPolicyDirectives(String policyDirectives) {
/* 55 */     Assert.hasLength(policyDirectives, "policyDirectives must not be null or empty");
/* 56 */     this.policyDirectives = policyDirectives;
/* 57 */     this.delegate = createDelegate();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReportOnly(boolean reportOnly) {
/* 66 */     this.reportOnly = reportOnly;
/* 67 */     this.delegate = createDelegate();
/*    */   }
/*    */   
/*    */   private ServerHttpHeadersWriter createDelegate() {
/* 71 */     if (this.policyDirectives == null) {
/* 72 */       return null;
/*    */     }
/* 74 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 75 */     builder.header(resolveHeader(this.reportOnly), new String[] { this.policyDirectives });
/* 76 */     return builder.build();
/*    */   }
/*    */   
/*    */   private static String resolveHeader(boolean reportOnly) {
/* 80 */     return reportOnly ? "Content-Security-Policy-Report-Only" : "Content-Security-Policy";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\ContentSecurityPolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */