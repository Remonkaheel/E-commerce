/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CrossOriginEmbedderPolicy
/*    */ {
/* 62 */   UNSAFE_NONE("unsafe-none"),
/*    */   
/* 64 */   REQUIRE_CORP("require-corp");
/*    */   
/*    */   private final String policy;
/*    */   
/*    */   CrossOriginEmbedderPolicy(String policy) {
/* 69 */     this.policy = policy;
/*    */   }
/*    */   
/*    */   public String getPolicy() {
/* 73 */     return this.policy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginEmbedderPolicyServerHttpHeadersWriter$CrossOriginEmbedderPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */