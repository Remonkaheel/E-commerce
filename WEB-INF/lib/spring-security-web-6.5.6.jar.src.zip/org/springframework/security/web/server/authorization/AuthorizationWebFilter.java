/*    */ package org.springframework.security.web.server.authorization;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationWebFilter
/*    */   implements WebFilter
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(AuthorizationWebFilter.class);
/*    */   
/*    */   private ReactiveAuthorizationManager<? super ServerWebExchange> authorizationManager;
/*    */   
/*    */   public AuthorizationWebFilter(ReactiveAuthorizationManager<? super ServerWebExchange> authorizationManager) {
/* 44 */     this.authorizationManager = authorizationManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 49 */     return ((Mono)ReactiveSecurityContextHolder.getContext()
/* 50 */       .filter(c -> (c.getAuthentication() != null))
/* 51 */       .map(SecurityContext::getAuthentication)
/* 52 */       .as(authentication -> this.authorizationManager.verify(authentication, exchange)))
/* 53 */       .doOnSuccess(it -> logger.debug("Authorization successful"))
/* 54 */       .doOnError(AccessDeniedException.class, ex -> logger.debug(LogMessage.format("Authorization failed: %s", ex.getMessage())))
/*    */       
/* 56 */       .switchIfEmpty(chain.filter(exchange));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\AuthorizationWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */