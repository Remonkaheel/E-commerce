/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ServerFormLoginAuthenticationConverter
/*    */   implements Function<ServerWebExchange, Mono<Authentication>>
/*    */ {
/* 42 */   private String usernameParameter = "username";
/*    */   
/* 44 */   private String passwordParameter = "password";
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Mono<Authentication> apply(ServerWebExchange exchange) {
/* 49 */     return exchange.getFormData().map(this::createAuthentication);
/*    */   }
/*    */   
/*    */   private UsernamePasswordAuthenticationToken createAuthentication(MultiValueMap<String, String> data) {
/* 53 */     String username = (String)data.getFirst(this.usernameParameter);
/* 54 */     String password = (String)data.getFirst(this.passwordParameter);
/* 55 */     return UsernamePasswordAuthenticationToken.unauthenticated(username, password);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUsernameParameter(String usernameParameter) {
/* 63 */     Assert.notNull(usernameParameter, "usernameParameter cannot be null");
/* 64 */     this.usernameParameter = usernameParameter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPasswordParameter(String passwordParameter) {
/* 72 */     Assert.notNull(passwordParameter, "passwordParameter cannot be null");
/* 73 */     this.passwordParameter = passwordParameter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ServerFormLoginAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */