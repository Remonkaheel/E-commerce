/*    */ package org.springframework.security.web.server.csrf;
/*    */ 
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface ServerCsrfTokenRequestHandler
/*    */   extends ServerCsrfTokenRequestResolver
/*    */ {
/*    */   default Mono<String> resolveCsrfTokenValue(ServerWebExchange exchange, CsrfToken csrfToken) {
/* 48 */     Assert.notNull(exchange, "exchange cannot be null");
/* 49 */     Assert.notNull(csrfToken, "csrfToken cannot be null");
/*    */     
/* 51 */     String headerName = csrfToken.getHeaderName();
/* 52 */     String parameterName = csrfToken.getParameterName();
/*    */     
/* 54 */     return exchange.getFormData().flatMap(data -> {
/*    */           String token = (String)data.getFirst(parameterName);
/*    */           
/*    */           if (token != null) {
/*    */             return Mono.just(token);
/*    */           }
/*    */           ServerCsrfTokenRequestHandlerLoggerHolder.logger.trace(LogMessage.format("Did not find a CSRF token in the [%s] request parameter", parameterName));
/*    */           return Mono.empty();
/* 62 */         }).switchIfEmpty(Mono.defer(() -> {
/*    */             String token = exchange.getRequest().getHeaders().getFirst(headerName);
/*    */             if (token != null)
/*    */               return Mono.just(token); 
/*    */             ServerCsrfTokenRequestHandlerLoggerHolder.logger.trace(LogMessage.format("Did not find a CSRF token in the [%s] request header", headerName));
/*    */             return Mono.empty();
/*    */           }));
/*    */   }
/*    */   
/*    */   void handle(ServerWebExchange paramServerWebExchange, Mono<CsrfToken> paramMono);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\ServerCsrfTokenRequestHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */