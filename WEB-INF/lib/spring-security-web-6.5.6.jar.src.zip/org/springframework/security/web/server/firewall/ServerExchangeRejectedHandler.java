package org.springframework.security.web.server.firewall;

import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface ServerExchangeRejectedHandler {
  Mono<Void> handle(ServerWebExchange paramServerWebExchange, ServerExchangeRejectedException paramServerExchangeRejectedException);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\ServerExchangeRejectedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */