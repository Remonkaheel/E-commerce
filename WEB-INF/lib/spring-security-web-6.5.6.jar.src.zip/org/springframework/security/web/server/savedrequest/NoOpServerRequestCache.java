/*    */ package org.springframework.security.web.server.savedrequest;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoOpServerRequestCache
/*    */   implements ServerRequestCache
/*    */ {
/*    */   public Mono<Void> saveRequest(ServerWebExchange exchange) {
/* 40 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<URI> getRedirectUri(ServerWebExchange exchange) {
/* 45 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ServerHttpRequest> removeMatchingRequest(ServerWebExchange exchange) {
/* 50 */     return Mono.empty();
/*    */   }
/*    */   
/*    */   public static NoOpServerRequestCache getInstance() {
/* 54 */     return new NoOpServerRequestCache();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\savedrequest\NoOpServerRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */