/*     */ package org.springframework.security.web.server.header;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReferrerPolicyServerHttpHeadersWriter
/*     */   implements ServerHttpHeadersWriter
/*     */ {
/*     */   public static final String REFERRER_POLICY = "Referrer-Policy";
/*  42 */   private ServerHttpHeadersWriter delegate = createDelegate(ReferrerPolicy.NO_REFERRER);
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/*  47 */     return this.delegate.writeHttpHeaders(exchange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicy(ReferrerPolicy policy) {
/*  56 */     Assert.notNull(policy, "policy must not be null");
/*  57 */     this.delegate = createDelegate(policy);
/*     */   }
/*     */   
/*     */   private static ServerHttpHeadersWriter createDelegate(ReferrerPolicy policy) {
/*  61 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/*  62 */     builder.header("Referrer-Policy", new String[] { policy.getPolicy() });
/*  63 */     return builder.build();
/*     */   }
/*     */   
/*     */   public enum ReferrerPolicy
/*     */   {
/*  68 */     NO_REFERRER("no-referrer"),
/*     */     
/*  70 */     NO_REFERRER_WHEN_DOWNGRADE("no-referrer-when-downgrade"),
/*     */     
/*  72 */     SAME_ORIGIN("same-origin"),
/*     */     
/*  74 */     ORIGIN("origin"),
/*     */     
/*  76 */     STRICT_ORIGIN("strict-origin"),
/*     */     
/*  78 */     ORIGIN_WHEN_CROSS_ORIGIN("origin-when-cross-origin"),
/*     */     
/*  80 */     STRICT_ORIGIN_WHEN_CROSS_ORIGIN("strict-origin-when-cross-origin"),
/*     */     
/*  82 */     UNSAFE_URL("unsafe-url");
/*     */     private static final Map<String, ReferrerPolicy> REFERRER_POLICIES;
/*     */     private final String policy;
/*     */     
/*     */     static {
/*  87 */       Map<String, ReferrerPolicy> referrerPolicies = new HashMap<>();
/*  88 */       for (ReferrerPolicy referrerPolicy : values()) {
/*  89 */         referrerPolicies.put(referrerPolicy.getPolicy(), referrerPolicy);
/*     */       }
/*  91 */       REFERRER_POLICIES = Collections.unmodifiableMap(referrerPolicies);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ReferrerPolicy(String policy) {
/*  97 */       this.policy = policy;
/*     */     }
/*     */     
/*     */     public String getPolicy() {
/* 101 */       return this.policy;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\ReferrerPolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */