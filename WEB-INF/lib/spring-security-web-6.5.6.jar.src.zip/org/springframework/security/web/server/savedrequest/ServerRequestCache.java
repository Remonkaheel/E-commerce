package org.springframework.security.web.server.savedrequest;

import java.net.URI;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface ServerRequestCache {
  Mono<Void> saveRequest(ServerWebExchange paramServerWebExchange);
  
  Mono<URI> getRedirectUri(ServerWebExchange paramServerWebExchange);
  
  Mono<ServerHttpRequest> removeMatchingRequest(ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\savedrequest\ServerRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */