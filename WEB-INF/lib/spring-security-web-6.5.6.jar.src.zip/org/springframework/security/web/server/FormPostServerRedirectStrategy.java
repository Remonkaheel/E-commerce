/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.security.crypto.keygen.Base64StringKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.StringKeyGenerator;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormPostServerRedirectStrategy
/*     */   implements ServerRedirectStrategy
/*     */ {
/*     */   private static final String CONTENT_SECURITY_POLICY_HEADER = "Content-Security-Policy";
/*     */   private static final String REDIRECT_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Redirect</title>\n  </head>\n  <body>\n    <form id=\"redirect-form\" method=\"POST\" action=\"{{action}}\">\n      {{params}}\n      <noscript>\n        <p>JavaScript is not enabled for this page.</p>\n        <button type=\"submit\">Click to continue</button>\n      </noscript>\n    </form>\n    <script nonce=\"{{nonce}}\">\n      document.getElementById(\"redirect-form\").submit();\n    </script>\n  </body>\n</html>\n";
/*     */   private static final String HIDDEN_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*  81 */   private static final StringKeyGenerator DEFAULT_NONCE_GENERATOR = (StringKeyGenerator)new Base64StringKeyGenerator(
/*  82 */       Base64.getUrlEncoder().withoutPadding(), 96);
/*     */ 
/*     */   
/*     */   public Mono<Void> sendRedirect(ServerWebExchange exchange, URI location) {
/*  86 */     UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUri(location);
/*     */     
/*  88 */     StringBuilder hiddenInputsHtmlBuilder = new StringBuilder();
/*  89 */     for (Map.Entry<String, List<String>> entry : (Iterable<Map.Entry<String, List<String>>>)uriComponentsBuilder.build().getQueryParams().entrySet()) {
/*  90 */       String name = entry.getKey();
/*  91 */       for (String value : entry.getValue()) {
/*     */ 
/*     */ 
/*     */         
/*  95 */         String hiddenInput = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n".replace("{{name}}", HtmlUtils.htmlEscape(name)).replace("{{value}}", HtmlUtils.htmlEscape(value));
/*     */         
/*  97 */         hiddenInputsHtmlBuilder.append(hiddenInput.trim());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 102 */     String nonce = DEFAULT_NONCE_GENERATOR.generateKey();
/* 103 */     String policyDirective = "script-src 'nonce-%s'".formatted(new Object[] { nonce });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     String html = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Redirect</title>\n  </head>\n  <body>\n    <form id=\"redirect-form\" method=\"POST\" action=\"{{action}}\">\n      {{params}}\n      <noscript>\n        <p>JavaScript is not enabled for this page.</p>\n        <button type=\"submit\">Click to continue</button>\n      </noscript>\n    </form>\n    <script nonce=\"{{nonce}}\">\n      document.getElementById(\"redirect-form\").submit();\n    </script>\n  </body>\n</html>\n".replace("{{action}}", HtmlUtils.htmlEscape(uriComponentsBuilder.query(null).build().toUriString())).replace("{{params}}", hiddenInputsHtmlBuilder.toString()).replace("{{nonce}}", HtmlUtils.htmlEscape(nonce));
/*     */ 
/*     */     
/* 113 */     ServerHttpResponse response = exchange.getResponse();
/* 114 */     response.setStatusCode((HttpStatusCode)HttpStatus.OK);
/* 115 */     response.getHeaders().setContentType(MediaType.TEXT_HTML);
/* 116 */     response.getHeaders().set("Content-Security-Policy", policyDirective);
/*     */     
/* 118 */     DataBufferFactory bufferFactory = response.bufferFactory();
/* 119 */     DataBuffer buffer = bufferFactory.wrap(html.getBytes(StandardCharsets.UTF_8));
/* 120 */     return response.writeWith((Publisher)Mono.just(buffer)).doOnError(error -> DataBufferUtils.release(buffer));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\FormPostServerRedirectStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */