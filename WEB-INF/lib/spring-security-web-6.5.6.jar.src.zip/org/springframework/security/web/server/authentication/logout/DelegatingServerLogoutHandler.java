/*    */ package org.springframework.security.web.server.authentication.logout;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingServerLogoutHandler
/*    */   implements ServerLogoutHandler
/*    */ {
/* 39 */   private final List<ServerLogoutHandler> delegates = new ArrayList<>();
/*    */   
/*    */   public DelegatingServerLogoutHandler(ServerLogoutHandler... delegates) {
/* 42 */     Assert.notEmpty((Object[])delegates, "delegates cannot be null or empty");
/* 43 */     this.delegates.addAll(Arrays.asList(delegates));
/*    */   }
/*    */   
/*    */   public DelegatingServerLogoutHandler(Collection<ServerLogoutHandler> delegates) {
/* 47 */     Assert.notEmpty(delegates, "delegates cannot be null or empty");
/* 48 */     this.delegates.addAll(delegates);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> logout(WebFilterExchange exchange, Authentication authentication) {
/* 53 */     return Flux.fromIterable(this.delegates)
/* 54 */       .concatMap(delegate -> delegate.logout(exchange, authentication))
/* 55 */       .then();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\DelegatingServerLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */