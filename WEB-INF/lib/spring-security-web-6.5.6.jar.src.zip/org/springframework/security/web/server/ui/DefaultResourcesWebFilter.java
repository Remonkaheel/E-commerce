/*    */ package org.springframework.security.web.server.ui;
/*    */ 
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Collections;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.io.ClassPathResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.ResourceHttpMessageWriter;
/*    */ import org.springframework.security.web.server.util.matcher.PathPatternParserServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultResourcesWebFilter
/*    */   implements WebFilter
/*    */ {
/*    */   private final ServerWebExchangeMatcher matcher;
/*    */   private final ClassPathResource resource;
/*    */   private final MediaType mediaType;
/*    */   
/*    */   private DefaultResourcesWebFilter(ServerWebExchangeMatcher matcher, ClassPathResource resource, MediaType mediaType) {
/* 56 */     Assert.isTrue(resource.exists(), "classpath resource must exist");
/* 57 */     this.matcher = matcher;
/* 58 */     this.resource = resource;
/* 59 */     this.mediaType = mediaType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 64 */     return this.matcher.matches(exchange)
/* 65 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 66 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/* 67 */       .flatMap(matchResult -> sendContent(exchange));
/*    */   }
/*    */   
/*    */   private Mono<Void> sendContent(ServerWebExchange exchange) {
/* 71 */     exchange.getResponse().setStatusCode((HttpStatusCode)HttpStatus.OK);
/* 72 */     ResourceHttpMessageWriter writer = new ResourceHttpMessageWriter();
/* 73 */     return writer.write((Publisher)Mono.just(this.resource), ResolvableType.forClass(Resource.class), 
/* 74 */         ResolvableType.forClass(Resource.class), this.mediaType, exchange.getRequest(), exchange.getResponse(), 
/* 75 */         Collections.emptyMap());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return "%s{matcher=%s, resource='%s'}".formatted(new Object[] { getClass().getSimpleName(), this.matcher, this.resource
/* 81 */           .getPath() });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DefaultResourcesWebFilter css() {
/* 95 */     return new DefaultResourcesWebFilter((ServerWebExchangeMatcher)new PathPatternParserServerWebExchangeMatcher("/default-ui.css", HttpMethod.GET), new ClassPathResource("org/springframework/security/default-ui.css"), new MediaType("text", "css", StandardCharsets.UTF_8));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\ui\DefaultResourcesWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */