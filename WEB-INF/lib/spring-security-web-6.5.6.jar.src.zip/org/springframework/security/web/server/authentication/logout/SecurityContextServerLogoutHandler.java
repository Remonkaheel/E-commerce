/*    */ package org.springframework.security.web.server.authentication.logout;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.security.web.server.context.ServerSecurityContextRepository;
/*    */ import org.springframework.security.web.server.context.WebSessionServerSecurityContextRepository;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextServerLogoutHandler
/*    */   implements ServerLogoutHandler
/*    */ {
/* 36 */   private ServerSecurityContextRepository securityContextRepository = (ServerSecurityContextRepository)new WebSessionServerSecurityContextRepository();
/*    */ 
/*    */   
/*    */   public Mono<Void> logout(WebFilterExchange exchange, Authentication authentication) {
/* 40 */     return this.securityContextRepository.save(exchange.getExchange(), null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSecurityContextRepository(ServerSecurityContextRepository securityContextRepository) {
/* 50 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 51 */     this.securityContextRepository = securityContextRepository;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\SecurityContextServerLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */