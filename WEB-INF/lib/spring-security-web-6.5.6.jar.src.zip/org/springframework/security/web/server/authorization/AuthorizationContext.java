/*    */ package org.springframework.security.web.server.authorization;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationContext
/*    */ {
/*    */   private final ServerWebExchange exchange;
/*    */   private final Map<String, Object> variables;
/*    */   
/*    */   public AuthorizationContext(ServerWebExchange exchange) {
/* 35 */     this(exchange, Collections.emptyMap());
/*    */   }
/*    */   
/*    */   public AuthorizationContext(ServerWebExchange exchange, Map<String, Object> variables) {
/* 39 */     this.exchange = exchange;
/* 40 */     this.variables = variables;
/*    */   }
/*    */   
/*    */   public ServerWebExchange getExchange() {
/* 44 */     return this.exchange;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getVariables() {
/* 48 */     return Collections.unmodifiableMap(this.variables);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\AuthorizationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */