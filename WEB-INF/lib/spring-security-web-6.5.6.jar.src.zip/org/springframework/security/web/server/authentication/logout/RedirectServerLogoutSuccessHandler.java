/*    */ package org.springframework.security.web.server.authentication.logout;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.WebFilterExchange;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedirectServerLogoutSuccessHandler
/*    */   implements ServerLogoutSuccessHandler
/*    */ {
/*    */   public static final String DEFAULT_LOGOUT_SUCCESS_URL = "/login?logout";
/* 39 */   private URI logoutSuccessUrl = URI.create("/login?logout");
/*    */   
/* 41 */   private ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */ 
/*    */   
/*    */   public Mono<Void> onLogoutSuccess(WebFilterExchange exchange, Authentication authentication) {
/* 45 */     return this.redirectStrategy.sendRedirect(exchange.getExchange(), this.logoutSuccessUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLogoutSuccessUrl(URI logoutSuccessUrl) {
/* 53 */     Assert.notNull(logoutSuccessUrl, "logoutSuccessUrl cannot be null");
/* 54 */     this.logoutSuccessUrl = logoutSuccessUrl;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\RedirectServerLogoutSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */