package org.springframework.security.web.server.jackson2;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, include = JsonTypeInfo.As.PROPERTY, property = "@class")
@JsonIgnoreProperties(ignoreUnknown = true)
class DefaultCsrfServerTokenMixin {
  @JsonCreator
  DefaultCsrfServerTokenMixin(@JsonProperty("headerName") String headerName, @JsonProperty("parameterName") String parameterName, @JsonProperty("token") String token) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\jackson2\DefaultCsrfServerTokenMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */