/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpHeaderWriterWebFilter
/*    */   implements WebFilter
/*    */ {
/*    */   private final ServerHttpHeadersWriter writer;
/*    */   
/*    */   public HttpHeaderWriterWebFilter(ServerHttpHeadersWriter writer) {
/* 38 */     this.writer = writer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 43 */     exchange.getResponse().beforeCommit(() -> this.writer.writeHttpHeaders(exchange));
/* 44 */     return chain.filter(exchange);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\HttpHeaderWriterWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */