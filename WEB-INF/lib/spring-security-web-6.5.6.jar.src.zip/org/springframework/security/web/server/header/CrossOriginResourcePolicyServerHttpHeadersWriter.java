/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginResourcePolicyServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   public static final String RESOURCE_POLICY = "Cross-Origin-Resource-Policy";
/*    */   private ServerHttpHeadersWriter delegate;
/*    */   
/*    */   public void setPolicy(CrossOriginResourcePolicy resourcePolicy) {
/* 45 */     Assert.notNull(resourcePolicy, "resourcePolicy cannot be null");
/* 46 */     this.delegate = createDelegate(resourcePolicy);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 51 */     return (this.delegate != null) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*    */   }
/*    */   
/*    */   private static ServerHttpHeadersWriter createDelegate(CrossOriginResourcePolicy resourcePolicy) {
/* 55 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/* 56 */     builder.header("Cross-Origin-Resource-Policy", new String[] { resourcePolicy.getPolicy() });
/* 57 */     return builder.build();
/*    */   }
/*    */   
/*    */   public enum CrossOriginResourcePolicy
/*    */   {
/* 62 */     SAME_SITE("same-site"),
/*    */     
/* 64 */     SAME_ORIGIN("same-origin"),
/*    */     
/* 66 */     CROSS_ORIGIN("cross-origin");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginResourcePolicy(String policy) {
/* 71 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 75 */       return this.policy;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginResourcePolicyServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */