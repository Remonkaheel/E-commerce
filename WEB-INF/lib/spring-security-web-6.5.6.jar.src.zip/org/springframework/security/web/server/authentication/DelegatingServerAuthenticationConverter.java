/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingServerAuthenticationConverter
/*    */   implements ServerAuthenticationConverter
/*    */ {
/*    */   private final List<ServerAuthenticationConverter> delegates;
/*    */   private boolean continueOnError = false;
/* 44 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   public DelegatingServerAuthenticationConverter(ServerAuthenticationConverter... converters) {
/* 47 */     this(List.of(converters));
/*    */   }
/*    */   
/*    */   public DelegatingServerAuthenticationConverter(List<ServerAuthenticationConverter> converters) {
/* 51 */     Assert.notEmpty(converters, "converters cannot be null");
/* 52 */     this.delegates = converters;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Authentication> convert(ServerWebExchange exchange) {
/* 57 */     Flux<ServerAuthenticationConverter> result = Flux.fromIterable(this.delegates);
/* 58 */     Function<ServerAuthenticationConverter, Mono<Authentication>> logging = converter -> {
/*    */         Objects.requireNonNull(this.logger); return converter.convert(exchange).doOnError(this.logger::debug);
/* 60 */       }; return (this.continueOnError ? result.concatMapDelayError(logging) : result.concatMap(logging)).next();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContinueOnError(boolean continueOnError) {
/* 69 */     this.continueOnError = continueOnError;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\DelegatingServerAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */