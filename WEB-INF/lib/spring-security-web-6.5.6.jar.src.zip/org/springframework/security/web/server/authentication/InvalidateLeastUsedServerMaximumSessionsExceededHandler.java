/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.security.core.session.ReactiveSessionInformation;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.session.WebSessionStore;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InvalidateLeastUsedServerMaximumSessionsExceededHandler
/*    */   implements ServerMaximumSessionsExceededHandler
/*    */ {
/*    */   private final WebSessionStore webSessionStore;
/*    */   
/*    */   public InvalidateLeastUsedServerMaximumSessionsExceededHandler(WebSessionStore webSessionStore) {
/* 46 */     Assert.notNull(webSessionStore, "webSessionStore cannot be null");
/* 47 */     this.webSessionStore = webSessionStore;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> handle(MaximumSessionsContext context) {
/* 52 */     List<ReactiveSessionInformation> sessions = new ArrayList<>(context.getSessions());
/* 53 */     sessions.removeIf(session -> session.getSessionId().equals(context.getCurrentSession().getId()));
/* 54 */     sessions.sort(Comparator.comparing(ReactiveSessionInformation::getLastAccessTime));
/* 55 */     int maximumSessionsExceededBy = sessions.size() - context.getMaximumSessionsAllowed() + 1;
/* 56 */     List<ReactiveSessionInformation> leastRecentlyUsedSessionsToInvalidate = sessions.subList(0, maximumSessionsExceededBy);
/*    */ 
/*    */     
/* 59 */     return Flux.fromIterable(leastRecentlyUsedSessionsToInvalidate)
/* 60 */       .flatMap(toInvalidate -> toInvalidate.invalidate().thenReturn(toInvalidate))
/* 61 */       .flatMap(toInvalidate -> this.webSessionStore.removeSession(toInvalidate.getSessionId()))
/* 62 */       .then();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\InvalidateLeastUsedServerMaximumSessionsExceededHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */