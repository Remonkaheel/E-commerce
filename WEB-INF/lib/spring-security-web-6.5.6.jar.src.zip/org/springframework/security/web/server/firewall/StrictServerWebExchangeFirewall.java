/*     */ package org.springframework.security.web.server.firewall;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.http.server.reactive.SslInfo;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.ServerWebExchangeDecorator;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrictServerWebExchangeFirewall
/*     */   implements ServerWebExchangeFirewall
/*     */ {
/*  95 */   private static final Set<HttpMethod> ALLOW_ANY_HTTP_METHOD = Collections.emptySet();
/*     */ 
/*     */   
/*     */   private static final String ENCODED_PERCENT = "%25";
/*     */   
/*     */   private static final String PERCENT = "%";
/*     */   
/* 102 */   private static final List<String> FORBIDDEN_ENCODED_PERIOD = Collections.unmodifiableList(Arrays.asList(new String[] { "%2e", "%2E" }));
/*     */ 
/*     */   
/* 105 */   private static final List<String> FORBIDDEN_SEMICOLON = Collections.unmodifiableList(Arrays.asList(new String[] { ";", "%3b", "%3B" }));
/*     */ 
/*     */   
/* 108 */   private static final List<String> FORBIDDEN_FORWARDSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "%2f", "%2F" }));
/*     */ 
/*     */   
/* 111 */   private static final List<String> FORBIDDEN_DOUBLE_FORWARDSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "//", "%2f%2f", "%2f%2F", "%2F%2f", "%2F%2F" }));
/*     */ 
/*     */   
/* 114 */   private static final List<String> FORBIDDEN_BACKSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "\\", "%5c", "%5C" }));
/*     */   
/* 116 */   private static final List<String> FORBIDDEN_NULL = Collections.unmodifiableList(Arrays.asList(new String[] { "\000", "%00" }));
/*     */   
/* 118 */   private static final List<String> FORBIDDEN_LF = Collections.unmodifiableList(Arrays.asList(new String[] { "\n", "%0a", "%0A" }));
/*     */   
/* 120 */   private static final List<String> FORBIDDEN_CR = Collections.unmodifiableList(Arrays.asList(new String[] { "\r", "%0d", "%0D" }));
/*     */   
/* 122 */   private static final List<String> FORBIDDEN_LINE_SEPARATOR = Collections.unmodifiableList(Arrays.asList(new String[] { " " }));
/*     */ 
/*     */   
/* 125 */   private static final List<String> FORBIDDEN_PARAGRAPH_SEPARATOR = Collections.unmodifiableList(Arrays.asList(new String[] { " " }));
/*     */   
/* 127 */   private Set<String> encodedUrlBlocklist = new HashSet<>();
/*     */   
/* 129 */   private Set<String> decodedUrlBlocklist = new HashSet<>();
/*     */   
/* 131 */   private Set<HttpMethod> allowedHttpMethods = createDefaultAllowedHttpMethods();
/*     */ 
/*     */   
/*     */   private Predicate<String> allowedHostnames = hostname -> true;
/*     */   
/* 136 */   private static final Pattern ASSIGNED_AND_NOT_ISO_CONTROL_PATTERN = Pattern.compile("[\\p{IsAssigned}&&[^\\p{IsControl}]]*"); private static final Predicate<String> ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/*     */   static {
/* 138 */     ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE = (s -> ASSIGNED_AND_NOT_ISO_CONTROL_PATTERN.matcher(s).matches());
/*     */   }
/*     */   
/* 141 */   private static final Pattern HEADER_VALUE_PATTERN = Pattern.compile("[\\p{IsAssigned}&&[[^\\p{IsControl}]||\\t]]*"); private static final Predicate<String> HEADER_VALUE_PREDICATE;
/*     */   static {
/* 143 */     HEADER_VALUE_PREDICATE = (s -> (s == null || HEADER_VALUE_PATTERN.matcher(s).matches()));
/*     */   }
/*     */   
/* 146 */   private Predicate<String> allowedHeaderNames = ALLOWED_HEADER_NAMES;
/*     */   
/* 148 */   public static final Predicate<String> ALLOWED_HEADER_NAMES = ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/*     */   
/* 150 */   private Predicate<String> allowedHeaderValues = ALLOWED_HEADER_VALUES;
/*     */   
/* 152 */   public static final Predicate<String> ALLOWED_HEADER_VALUES = HEADER_VALUE_PREDICATE;
/*     */   
/* 154 */   private Predicate<String> allowedParameterNames = ALLOWED_PARAMETER_NAMES;
/*     */   
/* 156 */   public static final Predicate<String> ALLOWED_PARAMETER_NAMES = ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/*     */   
/* 158 */   private Predicate<String> allowedParameterValues = ALLOWED_PARAMETER_VALUES;
/*     */   
/*     */   public static final Predicate<String> ALLOWED_PARAMETER_VALUES = value -> true;
/*     */   
/*     */   public StrictServerWebExchangeFirewall() {
/* 163 */     urlBlocklistsAddAll(FORBIDDEN_SEMICOLON);
/* 164 */     urlBlocklistsAddAll(FORBIDDEN_FORWARDSLASH);
/* 165 */     urlBlocklistsAddAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/* 166 */     urlBlocklistsAddAll(FORBIDDEN_BACKSLASH);
/* 167 */     urlBlocklistsAddAll(FORBIDDEN_NULL);
/* 168 */     urlBlocklistsAddAll(FORBIDDEN_LF);
/* 169 */     urlBlocklistsAddAll(FORBIDDEN_CR);
/*     */     
/* 171 */     this.encodedUrlBlocklist.add("%25");
/* 172 */     this.encodedUrlBlocklist.addAll(FORBIDDEN_ENCODED_PERIOD);
/* 173 */     this.decodedUrlBlocklist.add("%");
/* 174 */     this.decodedUrlBlocklist.addAll(FORBIDDEN_LINE_SEPARATOR);
/* 175 */     this.decodedUrlBlocklist.addAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */   }
/*     */   
/*     */   public Set<String> getEncodedUrlBlocklist() {
/* 179 */     return this.encodedUrlBlocklist;
/*     */   }
/*     */   
/*     */   public Set<String> getDecodedUrlBlocklist() {
/* 183 */     return this.decodedUrlBlocklist;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ServerWebExchange> getFirewalledExchange(ServerWebExchange exchange) {
/* 188 */     return Mono.fromCallable(() -> {
/*     */           ServerHttpRequest request = exchange.getRequest();
/*     */           rejectForbiddenHttpMethod(request);
/*     */           rejectedBlocklistedUrls(request);
/*     */           rejectedUntrustedHosts(request);
/*     */           if (!isNormalized(request)) {
/*     */             throw new ServerExchangeRejectedException("The request was rejected because the URL was not normalized");
/*     */           }
/*     */           exchange.getResponse().beforeCommit(());
/*     */           return (ServerWebExchange)new StrictFirewallServerWebExchange(exchange);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateCrlf(String name, String value) {
/* 214 */     Assert.isTrue((!hasCrlf(name) && !hasCrlf(value)), () -> "Invalid characters (CR/LF) in header " + name);
/*     */   }
/*     */   
/*     */   private static boolean hasCrlf(String value) {
/* 218 */     return (value != null && (value.indexOf('\n') != -1 || value.indexOf('\r') != -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnsafeAllowAnyHttpMethod(boolean unsafeAllowAnyHttpMethod) {
/* 232 */     this.allowedHttpMethods = unsafeAllowAnyHttpMethod ? ALLOW_ANY_HTTP_METHOD : createDefaultAllowedHttpMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHttpMethods(Collection<HttpMethod> allowedHttpMethods) {
/* 246 */     Assert.notNull(allowedHttpMethods, "allowedHttpMethods cannot be null");
/* 247 */     this
/* 248 */       .allowedHttpMethods = (allowedHttpMethods != ALLOW_ANY_HTTP_METHOD) ? new HashSet<>(allowedHttpMethods) : ALLOW_ANY_HTTP_METHOD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowSemicolon(boolean allowSemicolon) {
/* 284 */     if (allowSemicolon) {
/* 285 */       urlBlocklistsRemoveAll(FORBIDDEN_SEMICOLON);
/*     */     } else {
/*     */       
/* 288 */       urlBlocklistsAddAll(FORBIDDEN_SEMICOLON);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedSlash(boolean allowUrlEncodedSlash) {
/* 307 */     if (allowUrlEncodedSlash) {
/* 308 */       urlBlocklistsRemoveAll(FORBIDDEN_FORWARDSLASH);
/*     */     } else {
/*     */       
/* 311 */       urlBlocklistsAddAll(FORBIDDEN_FORWARDSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedDoubleSlash(boolean allowUrlEncodedDoubleSlash) {
/* 324 */     if (allowUrlEncodedDoubleSlash) {
/* 325 */       urlBlocklistsRemoveAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/*     */     } else {
/*     */       
/* 328 */       urlBlocklistsAddAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedPeriod(boolean allowUrlEncodedPeriod) {
/* 349 */     if (allowUrlEncodedPeriod) {
/* 350 */       this.encodedUrlBlocklist.removeAll(FORBIDDEN_ENCODED_PERIOD);
/*     */     } else {
/*     */       
/* 353 */       this.encodedUrlBlocklist.addAll(FORBIDDEN_ENCODED_PERIOD);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowBackSlash(boolean allowBackSlash) {
/* 374 */     if (allowBackSlash) {
/* 375 */       urlBlocklistsRemoveAll(FORBIDDEN_BACKSLASH);
/*     */     } else {
/*     */       
/* 378 */       urlBlocklistsAddAll(FORBIDDEN_BACKSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowNull(boolean allowNull) {
/* 393 */     if (allowNull) {
/* 394 */       urlBlocklistsRemoveAll(FORBIDDEN_NULL);
/*     */     } else {
/*     */       
/* 397 */       urlBlocklistsAddAll(FORBIDDEN_NULL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedPercent(boolean allowUrlEncodedPercent) {
/* 415 */     if (allowUrlEncodedPercent) {
/* 416 */       this.encodedUrlBlocklist.remove("%25");
/* 417 */       this.decodedUrlBlocklist.remove("%");
/*     */     } else {
/*     */       
/* 420 */       this.encodedUrlBlocklist.add("%25");
/* 421 */       this.decodedUrlBlocklist.add("%");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedCarriageReturn(boolean allowUrlEncodedCarriageReturn) {
/* 433 */     if (allowUrlEncodedCarriageReturn) {
/* 434 */       urlBlocklistsRemoveAll(FORBIDDEN_CR);
/*     */     } else {
/*     */       
/* 437 */       urlBlocklistsAddAll(FORBIDDEN_CR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedLineFeed(boolean allowUrlEncodedLineFeed) {
/* 448 */     if (allowUrlEncodedLineFeed) {
/* 449 */       urlBlocklistsRemoveAll(FORBIDDEN_LF);
/*     */     } else {
/*     */       
/* 452 */       urlBlocklistsAddAll(FORBIDDEN_LF);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedParagraphSeparator(boolean allowUrlEncodedParagraphSeparator) {
/* 464 */     if (allowUrlEncodedParagraphSeparator) {
/* 465 */       this.decodedUrlBlocklist.removeAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */     } else {
/*     */       
/* 468 */       this.decodedUrlBlocklist.addAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedLineSeparator(boolean allowUrlEncodedLineSeparator) {
/* 480 */     if (allowUrlEncodedLineSeparator) {
/* 481 */       this.decodedUrlBlocklist.removeAll(FORBIDDEN_LINE_SEPARATOR);
/*     */     } else {
/*     */       
/* 484 */       this.decodedUrlBlocklist.addAll(FORBIDDEN_LINE_SEPARATOR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHeaderNames(Predicate<String> allowedHeaderNames) {
/* 499 */     Assert.notNull(allowedHeaderNames, "allowedHeaderNames cannot be null");
/* 500 */     this.allowedHeaderNames = allowedHeaderNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHeaderValues(Predicate<String> allowedHeaderValues) {
/* 514 */     Assert.notNull(allowedHeaderValues, "allowedHeaderValues cannot be null");
/* 515 */     this.allowedHeaderValues = allowedHeaderValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedParameterNames(Predicate<String> allowedParameterNames) {
/* 527 */     Assert.notNull(allowedParameterNames, "allowedParameterNames cannot be null");
/* 528 */     this.allowedParameterNames = allowedParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedParameterValues(Predicate<String> allowedParameterValues) {
/* 540 */     Assert.notNull(allowedParameterValues, "allowedParameterValues cannot be null");
/* 541 */     this.allowedParameterValues = allowedParameterValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHostnames(Predicate<String> allowedHostnames) {
/* 552 */     Assert.notNull(allowedHostnames, "allowedHostnames cannot be null");
/* 553 */     this.allowedHostnames = allowedHostnames;
/*     */   }
/*     */   
/*     */   private void urlBlocklistsAddAll(Collection<String> values) {
/* 557 */     this.encodedUrlBlocklist.addAll(values);
/* 558 */     this.decodedUrlBlocklist.addAll(values);
/*     */   }
/*     */   
/*     */   private void urlBlocklistsRemoveAll(Collection<String> values) {
/* 562 */     this.encodedUrlBlocklist.removeAll(values);
/* 563 */     this.decodedUrlBlocklist.removeAll(values);
/*     */   }
/*     */   
/*     */   private void rejectNonPrintableAsciiCharactersInFieldName(String toCheck, String propertyName) {
/* 567 */     if (!containsOnlyPrintableAsciiCharacters(toCheck)) {
/* 568 */       throw new ServerExchangeRejectedException(
/* 569 */           String.format("The %s was rejected because it can only contain printable ASCII characters.", new Object[] { propertyName }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void rejectForbiddenHttpMethod(ServerHttpRequest request) {
/* 574 */     if (this.allowedHttpMethods == ALLOW_ANY_HTTP_METHOD) {
/*     */       return;
/*     */     }
/* 577 */     if (!this.allowedHttpMethods.contains(request.getMethod())) {
/* 578 */       throw new ServerExchangeRejectedException("The request was rejected because the HTTP method \"" + 
/* 579 */           String.valueOf(request.getMethod()) + "\" was not included within the list of allowed HTTP methods " + String.valueOf(this.allowedHttpMethods));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void rejectedBlocklistedUrls(ServerHttpRequest request) {
/* 585 */     for (String forbidden : this.encodedUrlBlocklist) {
/* 586 */       if (encodedUrlContains(request, forbidden)) {
/* 587 */         throw new ServerExchangeRejectedException("The request was rejected because the URL contained a potentially malicious String \"" + forbidden + "\"");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 592 */     for (String forbidden : this.decodedUrlBlocklist) {
/* 593 */       if (decodedUrlContains(request, forbidden)) {
/* 594 */         throw new ServerExchangeRejectedException("The request was rejected because the URL contained a potentially malicious String \"" + forbidden + "\"");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void rejectedUntrustedHosts(ServerHttpRequest request) {
/* 602 */     String hostName = request.getURI().getHost();
/* 603 */     if (hostName != null && !this.allowedHostnames.test(hostName)) {
/* 604 */       throw new ServerExchangeRejectedException("The request was rejected because the domain " + hostName + " is untrusted.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<HttpMethod> createDefaultAllowedHttpMethods() {
/* 610 */     Set<HttpMethod> result = new HashSet<>();
/* 611 */     result.add(HttpMethod.DELETE);
/* 612 */     result.add(HttpMethod.GET);
/* 613 */     result.add(HttpMethod.HEAD);
/* 614 */     result.add(HttpMethod.OPTIONS);
/* 615 */     result.add(HttpMethod.PATCH);
/* 616 */     result.add(HttpMethod.POST);
/* 617 */     result.add(HttpMethod.PUT);
/* 618 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isNormalized(ServerHttpRequest request) {
/* 622 */     if (!isNormalized(request.getPath().value())) {
/* 623 */       return false;
/*     */     }
/* 625 */     if (!isNormalized(request.getURI().getRawPath())) {
/* 626 */       return false;
/*     */     }
/* 628 */     if (!isNormalized(request.getURI().getPath())) {
/* 629 */       return false;
/*     */     }
/* 631 */     return true;
/*     */   }
/*     */   
/*     */   private void validateAllowedHeaderName(String headerNames) {
/* 635 */     if (!this.allowedHeaderNames.test(headerNames)) {
/* 636 */       throw new ServerExchangeRejectedException("The request was rejected because the header name \"" + headerNames + "\" is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedHeaderValue(Object key, String value) {
/* 642 */     if (!this.allowedHeaderValues.test(value)) {
/* 643 */       throw new ServerExchangeRejectedException("The request was rejected because the header: \"" + String.valueOf(key) + " \" has a value \"" + value + "\" that is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedParameterName(String name) {
/* 649 */     if (!this.allowedParameterNames.test(name)) {
/* 650 */       throw new ServerExchangeRejectedException("The request was rejected because the parameter name \"" + name + "\" is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedParameterValue(String name, String value) {
/* 656 */     if (!this.allowedParameterValues.test(value)) {
/* 657 */       throw new ServerExchangeRejectedException("The request was rejected because the parameter: \"" + name + " \" has a value \"" + value + "\" that is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean encodedUrlContains(ServerHttpRequest request, String value) {
/* 663 */     if (valueContains(request.getPath().value(), value)) {
/* 664 */       return true;
/*     */     }
/* 666 */     return valueContains(request.getURI().getRawPath(), value);
/*     */   }
/*     */   
/*     */   private static boolean decodedUrlContains(ServerHttpRequest request, String value) {
/* 670 */     return valueContains(request.getURI().getPath(), value);
/*     */   }
/*     */   
/*     */   private static boolean containsOnlyPrintableAsciiCharacters(String uri) {
/* 674 */     if (uri == null) {
/* 675 */       return true;
/*     */     }
/* 677 */     int length = uri.length();
/* 678 */     for (int i = 0; i < length; i++) {
/* 679 */       char ch = uri.charAt(i);
/* 680 */       if (ch < ' ' || ch > '~') {
/* 681 */         return false;
/*     */       }
/*     */     } 
/* 684 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean valueContains(String value, String contains) {
/* 688 */     return (value != null && value.contains(contains));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNormalized(String path) {
/* 698 */     if (path == null) {
/* 699 */       return true;
/*     */     }
/* 701 */     for (int i = path.length(); i > 0; ) {
/* 702 */       int slashIndex = path.lastIndexOf('/', i - 1);
/* 703 */       int gap = i - slashIndex;
/* 704 */       if (gap == 2 && path.charAt(slashIndex + 1) == '.') {
/* 705 */         return false;
/*     */       }
/* 707 */       if (gap == 3 && path.charAt(slashIndex + 1) == '.' && path.charAt(slashIndex + 2) == '.') {
/* 708 */         return false;
/*     */       }
/* 710 */       i = slashIndex;
/*     */     } 
/* 712 */     return true;
/*     */   }
/*     */   
/*     */   private final class StrictFirewallServerWebExchange
/*     */     extends ServerWebExchangeDecorator {
/*     */     private StrictFirewallServerWebExchange(ServerWebExchange delegate) {
/* 718 */       super(delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerHttpRequest getRequest() {
/* 723 */       return (ServerHttpRequest)new StrictFirewallHttpRequest(super.getRequest());
/*     */     }
/*     */     
/*     */     private final class StrictFirewallHttpRequest
/*     */       extends ServerHttpRequestDecorator {
/*     */       private StrictFirewallHttpRequest(ServerHttpRequest delegate) {
/* 729 */         super(delegate);
/*     */       }
/*     */ 
/*     */       
/*     */       public HttpHeaders getHeaders() {
/* 734 */         return new StrictFirewallHttpHeaders(super.getHeaders());
/*     */       }
/*     */ 
/*     */       
/*     */       public MultiValueMap<String, String> getQueryParams() {
/* 739 */         MultiValueMap<String, String> queryParams = super.getQueryParams();
/* 740 */         for (Map.Entry<String, List<String>> paramEntry : (Iterable<Map.Entry<String, List<String>>>)queryParams.entrySet()) {
/* 741 */           String paramName = paramEntry.getKey();
/* 742 */           StrictServerWebExchangeFirewall.this.validateAllowedParameterName(paramName);
/* 743 */           for (String paramValue : paramEntry.getValue()) {
/* 744 */             StrictServerWebExchangeFirewall.this.validateAllowedParameterValue(paramName, paramValue);
/*     */           }
/*     */         } 
/* 747 */         return queryParams;
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder mutate() {
/* 752 */         return new StrictFirewallBuilder(super.mutate());
/*     */       }
/*     */       
/*     */       private final class StrictFirewallHttpHeaders
/*     */         extends HttpHeaders {
/*     */         private StrictFirewallHttpHeaders(HttpHeaders delegate) {
/* 758 */           super((MultiValueMap)delegate);
/*     */         }
/*     */ 
/*     */         
/*     */         public String getFirst(String headerName) {
/* 763 */           StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName);
/* 764 */           String headerValue = super.getFirst(headerName);
/* 765 */           StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(headerName, headerValue);
/* 766 */           return headerValue;
/*     */         }
/*     */ 
/*     */         
/*     */         public List<String> get(Object key) {
/* 771 */           if (key instanceof String) { String headerName = (String)key;
/* 772 */             StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName); }
/*     */           
/* 774 */           List<String> headerValues = super.get(key);
/* 775 */           if (headerValues == null) {
/* 776 */             return headerValues;
/*     */           }
/* 778 */           for (String headerValue : headerValues) {
/* 779 */             StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(key, headerValue);
/*     */           }
/* 781 */           return headerValues;
/*     */         }
/*     */ 
/*     */         
/*     */         public Set<String> keySet() {
/* 786 */           Set<String> headerNames = super.keySet();
/* 787 */           for (String headerName : headerNames) {
/* 788 */             StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName);
/*     */           }
/* 790 */           return headerNames;
/*     */         }
/*     */       }
/*     */       
/*     */       private final class StrictFirewallBuilder
/*     */         implements ServerHttpRequest.Builder
/*     */       {
/*     */         private final ServerHttpRequest.Builder delegate;
/*     */         
/*     */         private StrictFirewallBuilder(ServerHttpRequest.Builder delegate) {
/* 800 */           this.delegate = delegate;
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder method(HttpMethod httpMethod) {
/* 805 */           return new StrictFirewallBuilder(this.delegate.method(httpMethod));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder uri(URI uri) {
/* 810 */           return new StrictFirewallBuilder(this.delegate.uri(uri));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder path(String path) {
/* 815 */           return new StrictFirewallBuilder(this.delegate.path(path));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder contextPath(String contextPath) {
/* 820 */           return new StrictFirewallBuilder(this.delegate.contextPath(contextPath));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder header(String headerName, String... headerValues) {
/* 825 */           return new StrictFirewallBuilder(this.delegate.header(headerName, headerValues));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) {
/* 830 */           return new StrictFirewallBuilder(this.delegate.headers(headersConsumer));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder sslInfo(SslInfo sslInfo) {
/* 835 */           return new StrictFirewallBuilder(this.delegate.sslInfo(sslInfo));
/*     */         }
/*     */ 
/*     */         
/*     */         public ServerHttpRequest.Builder remoteAddress(InetSocketAddress remoteAddress) {
/* 840 */           return new StrictFirewallBuilder(this.delegate.remoteAddress(remoteAddress));
/*     */         }
/*     */         
/*     */         public ServerHttpRequest build()
/*     */         {
/* 845 */           return (ServerHttpRequest)new StrictServerWebExchangeFirewall.StrictFirewallServerWebExchange.StrictFirewallHttpRequest(this.delegate.build()); } } } } private final class StrictFirewallHttpRequest extends ServerHttpRequestDecorator { private StrictFirewallHttpRequest(ServerHttpRequest delegate) { super(delegate); } public HttpHeaders getHeaders() { return new StrictFirewallHttpHeaders(super.getHeaders()); } public MultiValueMap<String, String> getQueryParams() { MultiValueMap<String, String> queryParams = super.getQueryParams(); for (Map.Entry<String, List<String>> paramEntry : (Iterable<Map.Entry<String, List<String>>>)queryParams.entrySet()) { String paramName = paramEntry.getKey(); StrictServerWebExchangeFirewall.this.validateAllowedParameterName(paramName); for (String paramValue : paramEntry.getValue()) StrictServerWebExchangeFirewall.this.validateAllowedParameterValue(paramName, paramValue);  }  return queryParams; } public ServerHttpRequest.Builder mutate() { return new StrictFirewallBuilder(super.mutate()); } private final class StrictFirewallHttpHeaders extends HttpHeaders { private StrictFirewallHttpHeaders(HttpHeaders delegate) { super((MultiValueMap)delegate); } public String getFirst(String headerName) { StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName); String headerValue = super.getFirst(headerName); StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(headerName, headerValue); return headerValue; } public List<String> get(Object key) { if (key instanceof String) { String headerName = (String)key; StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName); }  List<String> headerValues = super.get(key); if (headerValues == null) return headerValues;  for (String headerValue : headerValues) StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(key, headerValue);  return headerValues; } public Set<String> keySet() { Set<String> headerNames = super.keySet(); for (String headerName : headerNames) StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName);  return headerNames; } } private final class StrictFirewallBuilder implements ServerHttpRequest.Builder { private final ServerHttpRequest.Builder delegate; private StrictFirewallBuilder(ServerHttpRequest.Builder delegate) { this.delegate = delegate; } public ServerHttpRequest.Builder method(HttpMethod httpMethod) { return new StrictFirewallBuilder(this.delegate.method(httpMethod)); } public ServerHttpRequest.Builder uri(URI uri) { return new StrictFirewallBuilder(this.delegate.uri(uri)); } public ServerHttpRequest.Builder path(String path) { return new StrictFirewallBuilder(this.delegate.path(path)); } public ServerHttpRequest build() { return (ServerHttpRequest)new StrictServerWebExchangeFirewall.StrictFirewallServerWebExchange.StrictFirewallHttpRequest(this.delegate.build()); } public ServerHttpRequest.Builder contextPath(String contextPath) { return new StrictFirewallBuilder(this.delegate.contextPath(contextPath)); } public ServerHttpRequest.Builder header(String headerName, String... headerValues) { return new StrictFirewallBuilder(this.delegate.header(headerName, headerValues)); } public ServerHttpRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) { return new StrictFirewallBuilder(this.delegate.headers(headersConsumer)); } public ServerHttpRequest.Builder sslInfo(SslInfo sslInfo) { return new StrictFirewallBuilder(this.delegate.sslInfo(sslInfo)); } public ServerHttpRequest.Builder remoteAddress(InetSocketAddress remoteAddress) { return new StrictFirewallBuilder(this.delegate.remoteAddress(remoteAddress)); } } } private final class StrictFirewallHttpHeaders extends HttpHeaders { private StrictFirewallHttpHeaders(HttpHeaders delegate) { super((MultiValueMap)delegate); } public String getFirst(String headerName) { StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName); String headerValue = super.getFirst(headerName); StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(headerName, headerValue); return headerValue; } public List<String> get(Object key) { if (key instanceof String) { String headerName = (String)key; StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName); }  List<String> headerValues = super.get(key); if (headerValues == null) return headerValues;  for (String headerValue : headerValues) StrictServerWebExchangeFirewall.this.validateAllowedHeaderValue(key, headerValue);  return headerValues; } public Set<String> keySet() { Set<String> headerNames = super.keySet(); for (String headerName : headerNames) StrictServerWebExchangeFirewall.this.validateAllowedHeaderName(headerName);  return headerNames; } } private final class StrictFirewallBuilder implements ServerHttpRequest.Builder { private final ServerHttpRequest.Builder delegate; private StrictFirewallBuilder(ServerHttpRequest.Builder delegate) { this.delegate = delegate; } public ServerHttpRequest.Builder method(HttpMethod httpMethod) { return new StrictFirewallBuilder(this.delegate.method(httpMethod)); } public ServerHttpRequest.Builder uri(URI uri) { return new StrictFirewallBuilder(this.delegate.uri(uri)); } public ServerHttpRequest.Builder path(String path) { return new StrictFirewallBuilder(this.delegate.path(path)); } public ServerHttpRequest.Builder contextPath(String contextPath) { return new StrictFirewallBuilder(this.delegate.contextPath(contextPath)); } public ServerHttpRequest.Builder header(String headerName, String... headerValues) { return new StrictFirewallBuilder(this.delegate.header(headerName, headerValues)); } public ServerHttpRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) { return new StrictFirewallBuilder(this.delegate.headers(headersConsumer)); } public ServerHttpRequest.Builder sslInfo(SslInfo sslInfo) { return new StrictFirewallBuilder(this.delegate.sslInfo(sslInfo)); } public ServerHttpRequest.Builder remoteAddress(InetSocketAddress remoteAddress) { return new StrictFirewallBuilder(this.delegate.remoteAddress(remoteAddress)); } public ServerHttpRequest build() { return (ServerHttpRequest)new StrictServerWebExchangeFirewall.StrictFirewallServerWebExchange.StrictFirewallHttpRequest(this.delegate.build()); }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\StrictServerWebExchangeFirewall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */