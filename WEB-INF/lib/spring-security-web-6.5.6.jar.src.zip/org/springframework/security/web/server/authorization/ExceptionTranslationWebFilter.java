/*     */ package org.springframework.security.web.server.authorization;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.authentication.InsufficientAuthenticationException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.server.authentication.HttpBasicServerAuthenticationEntryPoint;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionTranslationWebFilter
/*     */   implements WebFilter
/*     */ {
/*  43 */   private ServerAuthenticationEntryPoint authenticationEntryPoint = (ServerAuthenticationEntryPoint)new HttpBasicServerAuthenticationEntryPoint();
/*     */   
/*  45 */   private ServerAccessDeniedHandler accessDeniedHandler = new HttpStatusServerAccessDeniedHandler(HttpStatus.FORBIDDEN);
/*     */ 
/*     */   
/*  48 */   private AuthenticationTrustResolver authenticationTrustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/*  52 */     return chain.filter(exchange)
/*  53 */       .onErrorResume(AccessDeniedException.class, denied -> exchange.getPrincipal().switchIfEmpty(Mono.defer(())).flatMap(()).then());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessDeniedHandler(ServerAccessDeniedHandler accessDeniedHandler) {
/*  74 */     Assert.notNull(accessDeniedHandler, "accessDeniedHandler cannot be null");
/*  75 */     this.accessDeniedHandler = accessDeniedHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationEntryPoint(ServerAuthenticationEntryPoint authenticationEntryPoint) {
/*  84 */     Assert.notNull(authenticationEntryPoint, "authenticationEntryPoint cannot be null");
/*  85 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationTrustResolver(AuthenticationTrustResolver authenticationTrustResolver) {
/*  96 */     Assert.notNull(authenticationTrustResolver, "authenticationTrustResolver must not be null");
/*  97 */     this.authenticationTrustResolver = authenticationTrustResolver;
/*     */   }
/*     */   
/*     */   private <T> Mono<T> commenceAuthentication(ServerWebExchange exchange, Authentication authentication) {
/* 101 */     InsufficientAuthenticationException insufficientAuthenticationException = new InsufficientAuthenticationException("Full authentication is required to access this resource");
/*     */     
/* 103 */     AuthenticationCredentialsNotFoundException authenticationCredentialsNotFoundException = new AuthenticationCredentialsNotFoundException("Not Authenticated", (Throwable)insufficientAuthenticationException);
/* 104 */     if (authentication != null) {
/* 105 */       authenticationCredentialsNotFoundException.setAuthenticationRequest(authentication);
/*     */     }
/* 107 */     return this.authenticationEntryPoint.commence(exchange, (AuthenticationException)authenticationCredentialsNotFoundException).then(Mono.empty());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\ExceptionTranslationWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */