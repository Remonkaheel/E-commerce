/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CrossOriginResourcePolicy
/*    */ {
/* 62 */   SAME_SITE("same-site"),
/*    */   
/* 64 */   SAME_ORIGIN("same-origin"),
/*    */   
/* 66 */   CROSS_ORIGIN("cross-origin");
/*    */   
/*    */   private final String policy;
/*    */   
/*    */   CrossOriginResourcePolicy(String policy) {
/* 71 */     this.policy = policy;
/*    */   }
/*    */   
/*    */   public String getPolicy() {
/* 75 */     return this.policy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CrossOriginResourcePolicyServerHttpHeadersWriter$CrossOriginResourcePolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */