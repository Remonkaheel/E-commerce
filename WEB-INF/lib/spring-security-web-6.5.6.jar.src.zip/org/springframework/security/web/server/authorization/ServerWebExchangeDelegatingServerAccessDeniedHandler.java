/*     */ package org.springframework.security.web.server.authorization;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerWebExchangeDelegatingServerAccessDeniedHandler
/*     */   implements ServerAccessDeniedHandler
/*     */ {
/*     */   private final List<DelegateEntry> handlers;
/*     */   private ServerAccessDeniedHandler defaultHandler;
/*     */   
/*     */   public ServerWebExchangeDelegatingServerAccessDeniedHandler(DelegateEntry... handlers) {
/*  55 */     this(Arrays.asList(handlers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerWebExchangeDelegatingServerAccessDeniedHandler(List<DelegateEntry> handlers) {
/*     */     this.defaultHandler = ((exchange, ex) -> {
/*     */         exchange.getResponse().setStatusCode((HttpStatusCode)HttpStatus.FORBIDDEN);
/*     */         return (ServerAccessDeniedHandler)exchange.getResponse().setComplete();
/*     */       });
/*  66 */     Assert.notEmpty(handlers, "handlers cannot be null");
/*  67 */     this.handlers = handlers;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> handle(ServerWebExchange exchange, AccessDeniedException denied) {
/*  72 */     return Flux.fromIterable(this.handlers)
/*  73 */       .filterWhen(entry -> isMatch(exchange, entry))
/*  74 */       .next()
/*  75 */       .map(DelegateEntry::getAccessDeniedHandler)
/*  76 */       .defaultIfEmpty(this.defaultHandler)
/*  77 */       .flatMap(handler -> handler.handle(exchange, denied));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAccessDeniedHandler(ServerAccessDeniedHandler accessDeniedHandler) {
/*  86 */     Assert.notNull(accessDeniedHandler, "accessDeniedHandler cannot be null");
/*  87 */     this.defaultHandler = accessDeniedHandler;
/*     */   }
/*     */   
/*     */   private Mono<Boolean> isMatch(ServerWebExchange exchange, DelegateEntry entry) {
/*  91 */     ServerWebExchangeMatcher matcher = entry.getMatcher();
/*  92 */     return matcher.matches(exchange).map(ServerWebExchangeMatcher.MatchResult::isMatch);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class DelegateEntry
/*     */   {
/*     */     private final ServerWebExchangeMatcher matcher;
/*     */     private final ServerAccessDeniedHandler accessDeniedHandler;
/*     */     
/*     */     public DelegateEntry(ServerWebExchangeMatcher matcher, ServerAccessDeniedHandler accessDeniedHandler) {
/* 102 */       this.matcher = matcher;
/* 103 */       this.accessDeniedHandler = accessDeniedHandler;
/*     */     }
/*     */     
/*     */     public ServerWebExchangeMatcher getMatcher() {
/* 107 */       return this.matcher;
/*     */     }
/*     */     
/*     */     public ServerAccessDeniedHandler getAccessDeniedHandler() {
/* 111 */       return this.accessDeniedHandler;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\ServerWebExchangeDelegatingServerAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */