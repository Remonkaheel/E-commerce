/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.session.ReactiveSessionInformation;
/*    */ import org.springframework.web.server.WebSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MaximumSessionsContext
/*    */ {
/*    */   private final Authentication authentication;
/*    */   private final List<ReactiveSessionInformation> sessions;
/*    */   private final int maximumSessionsAllowed;
/*    */   private final WebSession currentSession;
/*    */   
/*    */   public MaximumSessionsContext(Authentication authentication, List<ReactiveSessionInformation> sessions, int maximumSessionsAllowed, WebSession currentSession) {
/* 37 */     this.authentication = authentication;
/* 38 */     this.sessions = sessions;
/* 39 */     this.maximumSessionsAllowed = maximumSessionsAllowed;
/* 40 */     this.currentSession = currentSession;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 44 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public List<ReactiveSessionInformation> getSessions() {
/* 48 */     return this.sessions;
/*    */   }
/*    */   
/*    */   public int getMaximumSessionsAllowed() {
/* 52 */     return this.maximumSessionsAllowed;
/*    */   }
/*    */   
/*    */   public WebSession getCurrentSession() {
/* 56 */     return this.currentSession;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\MaximumSessionsContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */