/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.security.web.server.firewall.HttpStatusExchangeRejectedHandler;
/*     */ import org.springframework.security.web.server.firewall.ServerExchangeRejectedException;
/*     */ import org.springframework.security.web.server.firewall.ServerExchangeRejectedHandler;
/*     */ import org.springframework.security.web.server.firewall.ServerWebExchangeFirewall;
/*     */ import org.springframework.security.web.server.firewall.StrictServerWebExchangeFirewall;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import org.springframework.web.server.handler.DefaultWebFilterChain;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebFilterChainProxy
/*     */   implements WebFilter
/*     */ {
/*     */   private final List<SecurityWebFilterChain> filters;
/*  48 */   private WebFilterChainDecorator filterChainDecorator = new DefaultWebFilterChainDecorator();
/*     */   
/*  50 */   private ServerWebExchangeFirewall firewall = (ServerWebExchangeFirewall)new StrictServerWebExchangeFirewall();
/*     */   
/*  52 */   private ServerExchangeRejectedHandler exchangeRejectedHandler = (ServerExchangeRejectedHandler)new HttpStatusExchangeRejectedHandler();
/*     */   
/*     */   public WebFilterChainProxy(List<SecurityWebFilterChain> filters) {
/*  55 */     this.filters = filters;
/*     */   }
/*     */   
/*     */   public WebFilterChainProxy(SecurityWebFilterChain... filters) {
/*  59 */     this.filters = Arrays.asList(filters);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/*  64 */     return this.firewall.getFirewalledExchange(exchange)
/*  65 */       .flatMap(firewalledExchange -> filterFirewalledExchange(firewalledExchange, chain))
/*  66 */       .onErrorResume(ServerExchangeRejectedException.class, rejected -> this.exchangeRejectedHandler.handle(exchange, rejected).then(Mono.empty()));
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> filterFirewalledExchange(ServerWebExchange firewalledExchange, WebFilterChain chain) {
/*  71 */     return Flux.fromIterable(this.filters)
/*  72 */       .filterWhen(securityWebFilterChain -> securityWebFilterChain.matches(firewalledExchange))
/*  73 */       .next()
/*  74 */       .switchIfEmpty(
/*  75 */         Mono.defer(() -> this.filterChainDecorator.decorate(chain).filter(firewalledExchange).then(Mono.empty())))
/*  76 */       .flatMap(securityWebFilterChain -> securityWebFilterChain.getWebFilters().collectList())
/*  77 */       .map(filters -> this.filterChainDecorator.decorate(chain, filters))
/*  78 */       .flatMap(securedChain -> securedChain.filter(firewalledExchange));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFirewall(ServerWebExchangeFirewall firewall) {
/*  88 */     Assert.notNull(firewall, "firewall cannot be null");
/*  89 */     this.firewall = firewall;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExchangeRejectedHandler(ServerExchangeRejectedHandler exchangeRejectedHandler) {
/*  98 */     this.exchangeRejectedHandler = exchangeRejectedHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterChainDecorator(WebFilterChainDecorator filterChainDecorator) {
/* 111 */     Assert.notNull(filterChainDecorator, "filterChainDecorator cannot be null");
/* 112 */     this.filterChainDecorator = filterChainDecorator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface WebFilterChainDecorator
/*     */   {
/*     */     default WebFilterChain decorate(WebFilterChain original) {
/* 131 */       return decorate(original, Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WebFilterChain decorate(WebFilterChain param1WebFilterChain, List<WebFilter> param1List);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DefaultWebFilterChainDecorator
/*     */     implements WebFilterChainDecorator
/*     */   {
/*     */     public WebFilterChain decorate(WebFilterChain original) {
/* 159 */       return original;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebFilterChain decorate(WebFilterChain original, List<WebFilter> filters) {
/* 167 */       Objects.requireNonNull(original); return (WebFilterChain)new DefaultWebFilterChain(original::filter, filters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\WebFilterChainProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */