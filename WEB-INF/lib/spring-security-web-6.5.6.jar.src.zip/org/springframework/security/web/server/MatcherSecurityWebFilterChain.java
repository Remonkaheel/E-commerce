/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatcherSecurityWebFilterChain
/*    */   implements SecurityWebFilterChain
/*    */ {
/*    */   private final ServerWebExchangeMatcher matcher;
/*    */   private final List<WebFilter> filters;
/*    */   
/*    */   public MatcherSecurityWebFilterChain(ServerWebExchangeMatcher matcher, List<WebFilter> filters) {
/* 43 */     Assert.notNull(matcher, "matcher cannot be null");
/* 44 */     Assert.notEmpty(filters, () -> "filters cannot be null or empty. Got " + String.valueOf(filters));
/* 45 */     this.matcher = matcher;
/* 46 */     this.filters = filters;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Boolean> matches(ServerWebExchange exchange) {
/* 51 */     return this.matcher.matches(exchange).map(m -> Boolean.valueOf(m.isMatch()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Flux<WebFilter> getWebFilters() {
/* 56 */     return Flux.fromIterable(this.filters);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\MatcherSecurityWebFilterChain.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */