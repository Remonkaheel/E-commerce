/*     */ package org.springframework.security.web.server.csrf;
/*     */ 
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Base64;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XorServerCsrfTokenRequestAttributeHandler
/*     */   extends ServerCsrfTokenRequestAttributeHandler
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(XorServerCsrfTokenRequestAttributeHandler.class);
/*     */   
/*  45 */   private SecureRandom secureRandom = new SecureRandom();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandom(SecureRandom secureRandom) {
/*  53 */     Assert.notNull(secureRandom, "secureRandom cannot be null");
/*  54 */     this.secureRandom = secureRandom;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(ServerWebExchange exchange, Mono<CsrfToken> csrfToken) {
/*  59 */     Assert.notNull(exchange, "exchange cannot be null");
/*  60 */     Assert.notNull(csrfToken, "csrfToken cannot be null");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     Mono<CsrfToken> updatedCsrfToken = csrfToken.map(token -> new DefaultCsrfToken(token.getHeaderName(), token.getParameterName(), createXoredCsrfToken(this.secureRandom, token.getToken()))).cast(CsrfToken.class).cache();
/*  66 */     super.handle(exchange, updatedCsrfToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<String> resolveCsrfTokenValue(ServerWebExchange exchange, CsrfToken csrfToken) {
/*  71 */     return super.resolveCsrfTokenValue(exchange, csrfToken)
/*  72 */       .flatMap(actualToken -> Mono.justOrEmpty(getTokenValue(actualToken, csrfToken.getToken())));
/*     */   }
/*     */   
/*     */   private static String getTokenValue(String actualToken, String token) {
/*     */     byte[] actualBytes;
/*     */     try {
/*  78 */       actualBytes = Base64.getUrlDecoder().decode(actualToken);
/*     */     }
/*  80 */     catch (Exception ex) {
/*  81 */       logger.trace(LogMessage.format("Not returning the CSRF token since it's not Base64-encoded", new Object[0]), ex);
/*  82 */       return null;
/*     */     } 
/*     */     
/*  85 */     byte[] tokenBytes = Utf8.encode(token);
/*  86 */     int tokenSize = tokenBytes.length;
/*  87 */     if (actualBytes.length != tokenSize * 2) {
/*  88 */       logger.trace(LogMessage.format("Not returning the CSRF token since its Base64-decoded length (%d) is not equal to (%d)", 
/*     */             
/*  90 */             Integer.valueOf(actualBytes.length), Integer.valueOf(tokenSize * 2)));
/*  91 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  95 */     byte[] xoredCsrf = new byte[tokenSize];
/*  96 */     byte[] randomBytes = new byte[tokenSize];
/*     */     
/*  98 */     System.arraycopy(actualBytes, 0, randomBytes, 0, tokenSize);
/*  99 */     System.arraycopy(actualBytes, tokenSize, xoredCsrf, 0, tokenSize);
/*     */     
/* 101 */     byte[] csrfBytes = xorCsrf(randomBytes, xoredCsrf);
/* 102 */     return (csrfBytes != null) ? Utf8.decode(csrfBytes) : null;
/*     */   }
/*     */   
/*     */   private static String createXoredCsrfToken(SecureRandom secureRandom, String token) {
/* 106 */     byte[] tokenBytes = Utf8.encode(token);
/* 107 */     byte[] randomBytes = new byte[tokenBytes.length];
/* 108 */     secureRandom.nextBytes(randomBytes);
/*     */     
/* 110 */     byte[] xoredBytes = xorCsrf(randomBytes, tokenBytes);
/* 111 */     byte[] combinedBytes = new byte[tokenBytes.length + randomBytes.length];
/* 112 */     System.arraycopy(randomBytes, 0, combinedBytes, 0, randomBytes.length);
/* 113 */     System.arraycopy(xoredBytes, 0, combinedBytes, randomBytes.length, xoredBytes.length);
/*     */     
/* 115 */     return Base64.getUrlEncoder().encodeToString(combinedBytes);
/*     */   }
/*     */   
/*     */   private static byte[] xorCsrf(byte[] randomBytes, byte[] csrfBytes) {
/* 119 */     Assert.isTrue((randomBytes.length == csrfBytes.length), "arrays must be equal length");
/* 120 */     int len = csrfBytes.length;
/* 121 */     byte[] xoredCsrf = new byte[len];
/* 122 */     System.arraycopy(csrfBytes, 0, xoredCsrf, 0, len);
/* 123 */     for (int i = 0; i < len; i++) {
/* 124 */       xoredCsrf[i] = (byte)(xoredCsrf[i] ^ randomBytes[i]);
/*     */     }
/* 126 */     return xoredCsrf;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\XorServerCsrfTokenRequestAttributeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */