/*    */ package org.springframework.security.web.server.authentication.ott;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.authentication.ott.OneTimeToken;
/*    */ import org.springframework.security.authentication.ott.reactive.ReactiveOneTimeTokenService;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GenerateOneTimeTokenWebFilter
/*    */   implements WebFilter
/*    */ {
/*    */   private final ReactiveOneTimeTokenService oneTimeTokenService;
/* 41 */   private ServerWebExchangeMatcher matcher = ServerWebExchangeMatchers.pathMatchers(HttpMethod.POST, new String[] { "/ott/generate" });
/*    */   
/* 43 */   private ServerGenerateOneTimeTokenRequestResolver generateRequestResolver = new DefaultServerGenerateOneTimeTokenRequestResolver();
/*    */   
/*    */   private final ServerOneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler;
/*    */ 
/*    */   
/*    */   public GenerateOneTimeTokenWebFilter(ReactiveOneTimeTokenService oneTimeTokenService, ServerOneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler) {
/* 49 */     Assert.notNull(oneTimeTokenGenerationSuccessHandler, "oneTimeTokenGenerationSuccessHandler cannot be null");
/* 50 */     Assert.notNull(oneTimeTokenService, "oneTimeTokenService cannot be null");
/* 51 */     this.oneTimeTokenGenerationSuccessHandler = oneTimeTokenGenerationSuccessHandler;
/* 52 */     this.oneTimeTokenService = oneTimeTokenService;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 62 */     Objects.requireNonNull(this.oneTimeTokenService); return this.matcher.matches(exchange).filter(ServerWebExchangeMatcher.MatchResult::isMatch).flatMap(result -> this.generateRequestResolver.resolve(exchange)).switchIfEmpty(chain.filter(exchange).then(Mono.empty())).flatMap(this.oneTimeTokenService::generate)
/* 63 */       .flatMap(token -> this.oneTimeTokenGenerationSuccessHandler.handle(exchange, token));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequestMatcher(ServerWebExchangeMatcher matcher) {
/* 72 */     Assert.notNull(matcher, "matcher cannot be null");
/* 73 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setGenerateRequestResolver(ServerGenerateOneTimeTokenRequestResolver requestResolver) {
/* 83 */     Assert.notNull(requestResolver, "requestResolver cannot be null");
/* 84 */     this.generateRequestResolver = requestResolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\GenerateOneTimeTokenWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */