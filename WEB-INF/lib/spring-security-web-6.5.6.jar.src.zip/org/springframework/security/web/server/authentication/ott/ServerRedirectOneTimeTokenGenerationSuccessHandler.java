/*    */ package org.springframework.security.web.server.authentication.ott;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.authentication.ott.OneTimeToken;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerRedirectOneTimeTokenGenerationSuccessHandler
/*    */   implements ServerOneTimeTokenGenerationSuccessHandler
/*    */ {
/* 39 */   private final ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */   
/*    */   private final URI redirectUri;
/*    */   
/*    */   public ServerRedirectOneTimeTokenGenerationSuccessHandler(String redirectUri) {
/* 44 */     Assert.hasText(redirectUri, "redirectUri cannot be empty or null");
/* 45 */     this.redirectUri = URI.create(redirectUri);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> handle(ServerWebExchange exchange, OneTimeToken oneTimeToken) {
/* 50 */     return this.redirectStrategy.sendRedirect(exchange, this.redirectUri);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\ServerRedirectOneTimeTokenGenerationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */