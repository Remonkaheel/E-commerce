/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcherEntry;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerWebExchangeDelegatingServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   private final ServerWebExchangeMatcherEntry<ServerHttpHeadersWriter> headersWriter;
/*    */   
/*    */   public ServerWebExchangeDelegatingServerHttpHeadersWriter(ServerWebExchangeMatcherEntry<ServerHttpHeadersWriter> headersWriter) {
/* 45 */     Assert.notNull(headersWriter, "headersWriter cannot be null");
/* 46 */     Assert.notNull(headersWriter.getMatcher(), "webExchangeMatcher cannot be null");
/* 47 */     Assert.notNull(headersWriter.getEntry(), "delegateHeadersWriter cannot be null");
/* 48 */     this.headersWriter = headersWriter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ServerWebExchangeDelegatingServerHttpHeadersWriter(ServerWebExchangeMatcher webExchangeMatcher, ServerHttpHeadersWriter delegateHeadersWriter) {
/* 60 */     this(new ServerWebExchangeMatcherEntry(webExchangeMatcher, delegateHeadersWriter));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 65 */     return this.headersWriter.getMatcher()
/* 66 */       .matches(exchange)
/* 67 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 68 */       .flatMap(matchResult -> ((ServerHttpHeadersWriter)this.headersWriter.getEntry()).writeHttpHeaders(exchange));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\ServerWebExchangeDelegatingServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */