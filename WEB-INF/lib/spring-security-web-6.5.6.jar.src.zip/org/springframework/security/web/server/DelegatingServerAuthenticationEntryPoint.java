/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingServerAuthenticationEntryPoint
/*     */   implements ServerAuthenticationEntryPoint
/*     */ {
/*  45 */   private static final Log logger = LogFactory.getLog(DelegatingServerAuthenticationEntryPoint.class);
/*     */ 
/*     */   
/*     */   private final List<DelegateEntry> entryPoints;
/*     */ 
/*     */   
/*     */   private ServerAuthenticationEntryPoint defaultEntryPoint;
/*     */ 
/*     */   
/*     */   public DelegatingServerAuthenticationEntryPoint(DelegateEntry... entryPoints) {
/*  55 */     this(Arrays.asList(entryPoints)); } public DelegatingServerAuthenticationEntryPoint(List<DelegateEntry> entryPoints) { this.defaultEntryPoint = ((exchange, ex) -> {
/*     */         exchange.getResponse().setStatusCode((HttpStatusCode)HttpStatus.UNAUTHORIZED);
/*     */         return (ServerAuthenticationEntryPoint)exchange.getResponse().setComplete();
/*     */       });
/*  59 */     Assert.notEmpty(entryPoints, "entryPoints cannot be null");
/*  60 */     this.entryPoints = entryPoints; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException ex) {
/*  65 */     return Flux.fromIterable(this.entryPoints)
/*  66 */       .filterWhen(entry -> isMatch(exchange, entry))
/*  67 */       .next()
/*  68 */       .map(entry -> entry.getEntryPoint())
/*  69 */       .doOnNext(entryPoint -> logger.debug(LogMessage.format("Match found! Executing %s", entryPoint)))
/*  70 */       .switchIfEmpty(Mono.just(this.defaultEntryPoint)
/*  71 */         .doOnNext(entryPoint -> logger.debug(LogMessage.format("No match found. Using default entry point %s", this.defaultEntryPoint))))
/*     */       
/*  73 */       .flatMap(entryPoint -> entryPoint.commence(exchange, ex));
/*     */   }
/*     */   
/*     */   private Mono<Boolean> isMatch(ServerWebExchange exchange, DelegateEntry entry) {
/*  77 */     ServerWebExchangeMatcher matcher = entry.getMatcher();
/*  78 */     logger.debug(LogMessage.format("Trying to match using %s", matcher));
/*  79 */     return matcher.matches(exchange).map(ServerWebExchangeMatcher.MatchResult::isMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultEntryPoint(ServerAuthenticationEntryPoint defaultEntryPoint) {
/*  86 */     this.defaultEntryPoint = defaultEntryPoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class DelegateEntry
/*     */   {
/*     */     private final ServerWebExchangeMatcher matcher;
/*     */     private final ServerAuthenticationEntryPoint entryPoint;
/*     */     
/*     */     public DelegateEntry(ServerWebExchangeMatcher matcher, ServerAuthenticationEntryPoint entryPoint) {
/*  96 */       this.matcher = matcher;
/*  97 */       this.entryPoint = entryPoint;
/*     */     }
/*     */     
/*     */     public ServerWebExchangeMatcher getMatcher() {
/* 101 */       return this.matcher;
/*     */     }
/*     */     
/*     */     public ServerAuthenticationEntryPoint getEntryPoint() {
/* 105 */       return this.entryPoint;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\DelegatingServerAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */