/*    */ package org.springframework.security.web.server.csrf;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.codec.multipart.FormFieldPart;
/*    */ import org.springframework.http.codec.multipart.Part;
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerCsrfTokenRequestAttributeHandler
/*    */   implements ServerCsrfTokenRequestHandler
/*    */ {
/* 42 */   private static final Log logger = LogFactory.getLog(ServerCsrfTokenRequestAttributeHandler.class);
/*    */   
/*    */   private boolean isTokenFromMultipartDataEnabled;
/*    */ 
/*    */   
/*    */   public void handle(ServerWebExchange exchange, Mono<CsrfToken> csrfToken) {
/* 48 */     Assert.notNull(exchange, "exchange cannot be null");
/* 49 */     Assert.notNull(csrfToken, "csrfToken cannot be null");
/* 50 */     exchange.getAttributes().put(CsrfToken.class.getName(), csrfToken);
/* 51 */     logger.trace(LogMessage.format("Wrote a CSRF token to the [%s] exchange attribute", CsrfToken.class.getName()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<String> resolveCsrfTokenValue(ServerWebExchange exchange, CsrfToken csrfToken) {
/* 56 */     return super.resolveCsrfTokenValue(exchange, csrfToken)
/* 57 */       .switchIfEmpty(tokenFromMultipartData(exchange, csrfToken));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTokenFromMultipartDataEnabled(boolean tokenFromMultipartDataEnabled) {
/* 67 */     this.isTokenFromMultipartDataEnabled = tokenFromMultipartDataEnabled;
/*    */   }
/*    */   
/*    */   private Mono<String> tokenFromMultipartData(ServerWebExchange exchange, CsrfToken expected) {
/* 71 */     if (!this.isTokenFromMultipartDataEnabled) {
/* 72 */       return Mono.empty();
/*    */     }
/* 74 */     ServerHttpRequest request = exchange.getRequest();
/* 75 */     HttpHeaders headers = request.getHeaders();
/* 76 */     MediaType contentType = headers.getContentType();
/* 77 */     if (!MediaType.MULTIPART_FORM_DATA.isCompatibleWith(contentType)) {
/* 78 */       return Mono.empty();
/*    */     }
/* 80 */     return exchange.getMultipartData()
/* 81 */       .map(d -> (Part)d.getFirst(expected.getParameterName()))
/* 82 */       .cast(FormFieldPart.class)
/* 83 */       .map(FormFieldPart::value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\ServerCsrfTokenRequestAttributeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */