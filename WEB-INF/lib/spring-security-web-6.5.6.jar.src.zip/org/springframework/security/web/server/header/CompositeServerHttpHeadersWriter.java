/*    */ package org.springframework.security.web.server.header;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeServerHttpHeadersWriter
/*    */   implements ServerHttpHeadersWriter
/*    */ {
/*    */   private final List<ServerHttpHeadersWriter> writers;
/*    */   
/*    */   public CompositeServerHttpHeadersWriter(ServerHttpHeadersWriter... writers) {
/* 38 */     this(Arrays.asList(writers));
/*    */   }
/*    */   
/*    */   public CompositeServerHttpHeadersWriter(List<ServerHttpHeadersWriter> writers) {
/* 42 */     this.writers = writers;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/* 47 */     return Flux.fromIterable(this.writers).concatMap(w -> w.writeHttpHeaders(exchange)).then();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\CompositeServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */