/*     */ package org.springframework.security.web.server.firewall;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
/*     */ import org.springframework.http.server.reactive.SslInfo;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.ServerWebExchangeDecorator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StrictFirewallServerWebExchange
/*     */   extends ServerWebExchangeDecorator
/*     */ {
/*     */   private StrictFirewallServerWebExchange(ServerWebExchange delegate) {
/* 718 */     super(delegate);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerHttpRequest getRequest() {
/* 723 */     return (ServerHttpRequest)new StrictFirewallHttpRequest(super.getRequest());
/*     */   }
/*     */   
/*     */   private final class StrictFirewallHttpRequest
/*     */     extends ServerHttpRequestDecorator {
/*     */     private StrictFirewallHttpRequest(ServerHttpRequest delegate) {
/* 729 */       super(delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 734 */       return new StrictFirewallHttpHeaders(super.getHeaders());
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiValueMap<String, String> getQueryParams() {
/* 739 */       MultiValueMap<String, String> queryParams = super.getQueryParams();
/* 740 */       for (Map.Entry<String, List<String>> paramEntry : (Iterable<Map.Entry<String, List<String>>>)queryParams.entrySet()) {
/* 741 */         String paramName = paramEntry.getKey();
/* 742 */         this.this$1.this$0.validateAllowedParameterName(paramName);
/* 743 */         for (String paramValue : paramEntry.getValue()) {
/* 744 */           this.this$1.this$0.validateAllowedParameterValue(paramName, paramValue);
/*     */         }
/*     */       } 
/* 747 */       return queryParams;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServerHttpRequest.Builder mutate() {
/* 752 */       return new StrictFirewallBuilder(super.mutate());
/*     */     }
/*     */     
/*     */     private final class StrictFirewallHttpHeaders
/*     */       extends HttpHeaders {
/*     */       private StrictFirewallHttpHeaders(HttpHeaders delegate) {
/* 758 */         super((MultiValueMap)delegate);
/*     */       }
/*     */ 
/*     */       
/*     */       public String getFirst(String headerName) {
/* 763 */         this.this$2.this$1.this$0.validateAllowedHeaderName(headerName);
/* 764 */         String headerValue = super.getFirst(headerName);
/* 765 */         this.this$2.this$1.this$0.validateAllowedHeaderValue(headerName, headerValue);
/* 766 */         return headerValue;
/*     */       }
/*     */ 
/*     */       
/*     */       public List<String> get(Object key) {
/* 771 */         if (key instanceof String) { String headerName = (String)key;
/* 772 */           this.this$2.this$1.this$0.validateAllowedHeaderName(headerName); }
/*     */         
/* 774 */         List<String> headerValues = super.get(key);
/* 775 */         if (headerValues == null) {
/* 776 */           return headerValues;
/*     */         }
/* 778 */         for (String headerValue : headerValues) {
/* 779 */           this.this$2.this$1.this$0.validateAllowedHeaderValue(key, headerValue);
/*     */         }
/* 781 */         return headerValues;
/*     */       }
/*     */ 
/*     */       
/*     */       public Set<String> keySet() {
/* 786 */         Set<String> headerNames = super.keySet();
/* 787 */         for (String headerName : headerNames) {
/* 788 */           this.this$2.this$1.this$0.validateAllowedHeaderName(headerName);
/*     */         }
/* 790 */         return headerNames;
/*     */       }
/*     */     }
/*     */     
/*     */     private final class StrictFirewallBuilder
/*     */       implements ServerHttpRequest.Builder
/*     */     {
/*     */       private final ServerHttpRequest.Builder delegate;
/*     */       
/*     */       private StrictFirewallBuilder(ServerHttpRequest.Builder delegate) {
/* 800 */         this.delegate = delegate;
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder method(HttpMethod httpMethod) {
/* 805 */         return new StrictFirewallBuilder(this.delegate.method(httpMethod));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder uri(URI uri) {
/* 810 */         return new StrictFirewallBuilder(this.delegate.uri(uri));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder path(String path) {
/* 815 */         return new StrictFirewallBuilder(this.delegate.path(path));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder contextPath(String contextPath) {
/* 820 */         return new StrictFirewallBuilder(this.delegate.contextPath(contextPath));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder header(String headerName, String... headerValues) {
/* 825 */         return new StrictFirewallBuilder(this.delegate.header(headerName, headerValues));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder headers(Consumer<HttpHeaders> headersConsumer) {
/* 830 */         return new StrictFirewallBuilder(this.delegate.headers(headersConsumer));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder sslInfo(SslInfo sslInfo) {
/* 835 */         return new StrictFirewallBuilder(this.delegate.sslInfo(sslInfo));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest.Builder remoteAddress(InetSocketAddress remoteAddress) {
/* 840 */         return new StrictFirewallBuilder(this.delegate.remoteAddress(remoteAddress));
/*     */       }
/*     */ 
/*     */       
/*     */       public ServerHttpRequest build() {
/* 845 */         return (ServerHttpRequest)new StrictServerWebExchangeFirewall.StrictFirewallServerWebExchange.StrictFirewallHttpRequest(this.delegate.build());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\StrictServerWebExchangeFirewall$StrictFirewallServerWebExchange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */