/*     */ package org.springframework.security.web.server.savedrequest;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.security.web.server.util.matcher.AndServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.MediaTypeServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.NegatedServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebSessionServerRequestCache
/*     */   implements ServerRequestCache
/*     */ {
/*     */   private static final String DEFAULT_SAVED_REQUEST_ATTR = "SPRING_SECURITY_SAVED_REQUEST";
/*  56 */   private static final Log logger = LogFactory.getLog(WebSessionServerRequestCache.class);
/*     */   
/*  58 */   private String sessionAttrName = "SPRING_SECURITY_SAVED_REQUEST";
/*     */   
/*  60 */   private ServerWebExchangeMatcher saveRequestMatcher = createDefaultRequestMatcher();
/*     */ 
/*     */ 
/*     */   
/*     */   private String matchingRequestParameterName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaveRequestMatcher(ServerWebExchangeMatcher saveRequestMatcher) {
/*  70 */     Assert.notNull(saveRequestMatcher, "saveRequestMatcher cannot be null");
/*  71 */     this.saveRequestMatcher = saveRequestMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveRequest(ServerWebExchange exchange) {
/*  76 */     return this.saveRequestMatcher.matches(exchange)
/*  77 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/*  78 */       .flatMap(m -> exchange.getSession())
/*  79 */       .map(WebSession::getAttributes)
/*  80 */       .doOnNext(attrs -> {
/*     */           String requestPath = pathInApplication(exchange.getRequest());
/*     */           
/*     */           attrs.put(this.sessionAttrName, requestPath);
/*     */           logger.debug(LogMessage.format("Request added to WebSession: '%s'", requestPath));
/*  85 */         }).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<URI> getRedirectUri(ServerWebExchange exchange) {
/*  90 */     return exchange.getSession()
/*  91 */       .flatMap(session -> Mono.justOrEmpty(session.getAttribute(this.sessionAttrName)))
/*  92 */       .map(this::createRedirectUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ServerHttpRequest> removeMatchingRequest(ServerWebExchange exchange) {
/*  97 */     MultiValueMap<String, String> queryParams = exchange.getRequest().getQueryParams();
/*  98 */     if (this.matchingRequestParameterName != null && !queryParams.containsKey(this.matchingRequestParameterName)) {
/*  99 */       this; logger.trace("matchingRequestParameterName is required for getMatchingRequest to lookup a value, but not provided");
/*     */       
/* 101 */       return Mono.empty();
/*     */     } 
/* 103 */     ServerHttpRequest request = stripMatchingRequestParameterName(exchange.getRequest());
/* 104 */     return exchange.getSession().map(WebSession::getAttributes).filter(attributes -> {
/*     */           String requestPath = pathInApplication(request);
/*     */           boolean removed = attributes.remove(this.sessionAttrName, requestPath);
/*     */           if (removed) {
/*     */             logger.debug(LogMessage.format("Request removed from WebSession: '%s'", requestPath));
/*     */           }
/*     */           return removed;
/* 111 */         }).map(attributes -> request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchingRequestParameterName(String matchingRequestParameterName) {
/* 123 */     this.matchingRequestParameterName = matchingRequestParameterName;
/*     */   }
/*     */   
/*     */   private ServerHttpRequest stripMatchingRequestParameterName(ServerHttpRequest request) {
/* 127 */     if (this.matchingRequestParameterName == null) {
/* 128 */       return request;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     URI uri = UriComponentsBuilder.fromUri(request.getURI()).replaceQueryParam(this.matchingRequestParameterName, new Object[0]).build().toUri();
/* 135 */     return request.mutate()
/* 136 */       .uri(uri)
/* 137 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String pathInApplication(ServerHttpRequest request) {
/* 142 */     String path = request.getPath().pathWithinApplication().value();
/* 143 */     String query = request.getURI().getRawQuery();
/* 144 */     return path + path;
/*     */   }
/*     */   
/*     */   private URI createRedirectUri(String uri) {
/* 148 */     if (this.matchingRequestParameterName == null) {
/* 149 */       return URI.create(uri);
/*     */     }
/*     */     
/* 152 */     return UriComponentsBuilder.fromUriString(uri)
/* 153 */       .queryParam(this.matchingRequestParameterName, new Object[0])
/* 154 */       .build()
/* 155 */       .toUri();
/*     */   }
/*     */ 
/*     */   
/*     */   private static ServerWebExchangeMatcher createDefaultRequestMatcher() {
/* 160 */     ServerWebExchangeMatcher get = ServerWebExchangeMatchers.pathMatchers(HttpMethod.GET, new String[] { "/**" });
/*     */     
/* 162 */     NegatedServerWebExchangeMatcher negatedServerWebExchangeMatcher = new NegatedServerWebExchangeMatcher(ServerWebExchangeMatchers.pathMatchers(new String[] { "/favicon.*" }));
/* 163 */     MediaTypeServerWebExchangeMatcher html = new MediaTypeServerWebExchangeMatcher(new MediaType[] { MediaType.TEXT_HTML });
/* 164 */     html.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 165 */     return (ServerWebExchangeMatcher)new AndServerWebExchangeMatcher(new ServerWebExchangeMatcher[] { get, (ServerWebExchangeMatcher)negatedServerWebExchangeMatcher, (ServerWebExchangeMatcher)html });
/*     */   }
/*     */   
/*     */   private static String createQueryString(String queryString, String matchingRequestParameterName) {
/* 169 */     if (matchingRequestParameterName == null) {
/* 170 */       return queryString;
/*     */     }
/* 172 */     if (queryString == null || queryString.length() == 0) {
/* 173 */       return matchingRequestParameterName;
/*     */     }
/* 175 */     if (queryString.endsWith("&")) {
/* 176 */       return queryString + queryString;
/*     */     }
/* 178 */     return queryString + "&" + queryString;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\savedrequest\WebSessionServerRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */