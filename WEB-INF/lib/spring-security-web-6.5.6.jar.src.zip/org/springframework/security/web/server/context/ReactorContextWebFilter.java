/*    */ package org.springframework.security.web.server.context;
/*    */ 
/*    */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactorContextWebFilter
/*    */   implements WebFilter
/*    */ {
/*    */   private final ServerSecurityContextRepository repository;
/*    */   
/*    */   public ReactorContextWebFilter(ServerSecurityContextRepository repository) {
/* 41 */     Assert.notNull(repository, "repository cannot be null");
/* 42 */     this.repository = repository;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 47 */     return chain.filter(exchange)
/* 48 */       .contextWrite(context -> context.hasKey(SecurityContext.class) ? context : withSecurityContext(context, exchange));
/*    */   }
/*    */ 
/*    */   
/*    */   private Context withSecurityContext(Context mainContext, ServerWebExchange exchange) {
/* 53 */     return mainContext
/* 54 */       .putAll(((Context)this.repository.load(exchange).as(ReactiveSecurityContextHolder::withSecurityContext)).readOnly());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\ReactorContextWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */