/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import io.micrometer.context.ThreadLocalAccessor;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerWebExchangeThreadLocalAccessor
/*    */   implements ThreadLocalAccessor<ServerWebExchange>
/*    */ {
/* 40 */   private static final ThreadLocal<ServerWebExchange> threadLocal = new ThreadLocal<>();
/*    */ 
/*    */   
/*    */   public Object key() {
/* 44 */     return ServerWebExchange.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerWebExchange getValue() {
/* 49 */     return threadLocal.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(ServerWebExchange exchange) {
/* 54 */     Assert.notNull(exchange, "exchange cannot be null");
/* 55 */     threadLocal.set(exchange);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue() {
/* 60 */     threadLocal.remove();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ServerWebExchangeThreadLocalAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */