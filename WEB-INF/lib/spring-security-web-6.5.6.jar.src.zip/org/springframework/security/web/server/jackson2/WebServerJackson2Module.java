/*    */ package org.springframework.security.web.server.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import org.springframework.security.jackson2.SecurityJackson2Modules;
/*    */ import org.springframework.security.web.server.csrf.DefaultCsrfToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServerJackson2Module
/*    */   extends SimpleModule
/*    */ {
/* 44 */   private static final String NAME = WebServerJackson2Module.class.getName();
/*    */   
/* 46 */   private static final Version VERSION = new Version(1, 0, 0, null, null, null);
/*    */   
/*    */   public WebServerJackson2Module() {
/* 49 */     super(NAME, VERSION);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 54 */     SecurityJackson2Modules.enableDefaultTyping((ObjectMapper)context.getOwner());
/* 55 */     context.setMixInAnnotations(DefaultCsrfToken.class, DefaultCsrfServerTokenMixin.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\jackson2\WebServerJackson2Module.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */