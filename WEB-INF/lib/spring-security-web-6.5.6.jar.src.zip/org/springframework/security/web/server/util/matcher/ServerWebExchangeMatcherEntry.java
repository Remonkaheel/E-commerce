/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerWebExchangeMatcherEntry<T>
/*    */ {
/*    */   private final ServerWebExchangeMatcher matcher;
/*    */   private final T entry;
/*    */   
/*    */   public ServerWebExchangeMatcherEntry(ServerWebExchangeMatcher matcher, T entry) {
/* 32 */     this.matcher = matcher;
/* 33 */     this.entry = entry;
/*    */   }
/*    */   
/*    */   public ServerWebExchangeMatcher getMatcher() {
/* 37 */     return this.matcher;
/*    */   }
/*    */   
/*    */   public T getEntry() {
/* 41 */     return this.entry;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\ServerWebExchangeMatcherEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */