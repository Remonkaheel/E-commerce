/*    */ package org.springframework.security.web.server.firewall;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpStatusExchangeRejectedHandler
/*    */   implements ServerExchangeRejectedHandler
/*    */ {
/* 36 */   private static final Log logger = LogFactory.getLog(HttpStatusExchangeRejectedHandler.class);
/*    */ 
/*    */   
/*    */   private final HttpStatus status;
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusExchangeRejectedHandler() {
/* 44 */     this(HttpStatus.BAD_REQUEST);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusExchangeRejectedHandler(HttpStatus status) {
/* 52 */     this.status = status;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> handle(ServerWebExchange exchange, ServerExchangeRejectedException serverExchangeRejectedException) {
/* 58 */     return Mono.fromRunnable(() -> {
/*    */           logger.debug(LogMessage.format("Rejecting request due to: %s", serverExchangeRejectedException.getMessage()), serverExchangeRejectedException);
/*    */           exchange.getResponse().setStatusCode((HttpStatusCode)this.status);
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\firewall\HttpStatusExchangeRejectedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */