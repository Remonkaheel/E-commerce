/*    */ package org.springframework.security.web.server.authentication.ott;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.authentication.ServerAuthenticationConverter;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerOneTimeTokenAuthenticationConverter
/*    */   implements ServerAuthenticationConverter
/*    */ {
/*    */   private static final String TOKEN = "token";
/*    */   
/*    */   public Mono<Authentication> convert(ServerWebExchange exchange) {
/* 49 */     Assert.notNull(exchange, "exchange cannot be null");
/* 50 */     if (isFormEncodedRequest(exchange.getRequest())) {
/* 51 */       return exchange.getFormData()
/* 52 */         .map(data -> OneTimeTokenAuthenticationToken.unauthenticated((String)data.getFirst("token")));
/*    */     }
/* 54 */     String token = resolveTokenFromRequest(exchange.getRequest());
/* 55 */     if (!StringUtils.hasText(token)) {
/* 56 */       return Mono.empty();
/*    */     }
/* 58 */     return Mono.just(OneTimeTokenAuthenticationToken.unauthenticated(token));
/*    */   }
/*    */   
/*    */   private String resolveTokenFromRequest(ServerHttpRequest request) {
/* 62 */     List<String> parameterTokens = (List<String>)request.getQueryParams().get("token");
/* 63 */     if (CollectionUtils.isEmpty(parameterTokens)) {
/* 64 */       return null;
/*    */     }
/* 66 */     if (parameterTokens.size() == 1) {
/* 67 */       return parameterTokens.get(0);
/*    */     }
/* 69 */     return null;
/*    */   }
/*    */   
/*    */   private boolean isFormEncodedRequest(ServerHttpRequest request) {
/* 73 */     return (HttpMethod.POST.equals(request.getMethod()) && "application/x-www-form-urlencoded"
/* 74 */       .equals(request.getHeaders().getFirst("Content-Type")));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ott\ServerOneTimeTokenAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */