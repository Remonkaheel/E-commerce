/*     */ package org.springframework.security.web.server.authentication.logout;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.web.server.WebFilterExchange;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogoutWebFilter
/*     */   implements WebFilter
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(LogoutWebFilter.class);
/*     */   
/*  49 */   private AnonymousAuthenticationToken anonymousAuthenticationToken = new AnonymousAuthenticationToken("key", "anonymous", 
/*  50 */       AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" }));
/*     */   
/*  52 */   private ServerLogoutHandler logoutHandler = new SecurityContextServerLogoutHandler();
/*     */   
/*  54 */   private ServerLogoutSuccessHandler logoutSuccessHandler = new RedirectServerLogoutSuccessHandler();
/*     */   
/*  56 */   private ServerWebExchangeMatcher requiresLogout = ServerWebExchangeMatchers.pathMatchers(HttpMethod.POST, new String[] { "/logout" });
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/*  61 */     return this.requiresLogout.matches(exchange)
/*  62 */       .filter(result -> result.isMatch())
/*  63 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/*  64 */       .map(result -> exchange)
/*  65 */       .flatMap(this::flatMapAuthentication)
/*  66 */       .flatMap(authentication -> {
/*     */           WebFilterExchange webFilterExchange = new WebFilterExchange(exchange, chain);
/*     */           return logout(webFilterExchange, authentication);
/*     */         });
/*     */   }
/*     */   
/*     */   private Mono<Authentication> flatMapAuthentication(ServerWebExchange exchange) {
/*  73 */     return exchange.getPrincipal().cast(Authentication.class).defaultIfEmpty(this.anonymousAuthenticationToken);
/*     */   }
/*     */   
/*     */   private Mono<Void> logout(WebFilterExchange webFilterExchange, Authentication authentication) {
/*  77 */     logger.debug(LogMessage.format("Logging out user '%s' and transferring to logout destination", authentication));
/*  78 */     return this.logoutHandler.logout(webFilterExchange, authentication)
/*  79 */       .then(this.logoutSuccessHandler.onLogoutSuccess(webFilterExchange, authentication))
/*  80 */       .contextWrite(ReactiveSecurityContextHolder.clearContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogoutSuccessHandler(ServerLogoutSuccessHandler logoutSuccessHandler) {
/*  89 */     Assert.notNull(logoutSuccessHandler, "logoutSuccessHandler cannot be null");
/*  90 */     this.logoutSuccessHandler = logoutSuccessHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogoutHandler(ServerLogoutHandler logoutHandler) {
/*  99 */     Assert.notNull(logoutHandler, "logoutHandler must not be null");
/* 100 */     this.logoutHandler = logoutHandler;
/*     */   }
/*     */   
/*     */   public void setRequiresLogoutMatcher(ServerWebExchangeMatcher requiresLogoutMatcher) {
/* 104 */     Assert.notNull(requiresLogoutMatcher, "requiresLogoutMatcher must not be null");
/* 105 */     this.requiresLogout = requiresLogoutMatcher;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\logout\LogoutWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */