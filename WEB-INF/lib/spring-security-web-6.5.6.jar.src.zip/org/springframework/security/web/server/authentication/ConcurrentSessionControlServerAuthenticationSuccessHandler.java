/*     */ package org.springframework.security.web.server.authentication;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.session.ReactiveSessionInformation;
/*     */ import org.springframework.security.core.session.ReactiveSessionRegistry;
/*     */ import org.springframework.security.web.server.WebFilterExchange;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConcurrentSessionControlServerAuthenticationSuccessHandler
/*     */   implements ServerAuthenticationSuccessHandler
/*     */ {
/*     */   private final ReactiveSessionRegistry sessionRegistry;
/*     */   private final ServerMaximumSessionsExceededHandler maximumSessionsExceededHandler;
/*  50 */   private SessionLimit sessionLimit = SessionLimit.of(1);
/*     */ 
/*     */   
/*     */   public ConcurrentSessionControlServerAuthenticationSuccessHandler(ReactiveSessionRegistry sessionRegistry, ServerMaximumSessionsExceededHandler maximumSessionsExceededHandler) {
/*  54 */     Assert.notNull(sessionRegistry, "sessionRegistry cannot be null");
/*  55 */     Assert.notNull(maximumSessionsExceededHandler, "maximumSessionsExceededHandler cannot be null");
/*  56 */     this.sessionRegistry = sessionRegistry;
/*  57 */     this.maximumSessionsExceededHandler = maximumSessionsExceededHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> onAuthenticationSuccess(WebFilterExchange exchange, Authentication authentication) {
/*  62 */     return this.sessionLimit.apply(authentication)
/*  63 */       .flatMap(maxSessions -> handleConcurrency(exchange, authentication, maxSessions));
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> handleConcurrency(WebFilterExchange exchange, Authentication authentication, Integer maximumSessions) {
/*  68 */     return this.sessionRegistry.getAllSessions(authentication.getPrincipal())
/*  69 */       .collectList()
/*  70 */       .flatMap(registeredSessions -> exchange.getExchange().getSession().map(()))
/*     */ 
/*     */       
/*  73 */       .flatMap(sessionTuple -> {
/*     */           WebSession currentSession = (WebSession)sessionTuple.getT1();
/*     */           List<ReactiveSessionInformation> registeredSessions = (List<ReactiveSessionInformation>)sessionTuple.getT2();
/*     */           int registeredSessionsCount = registeredSessions.size();
/*     */           if (registeredSessionsCount < maximumSessions.intValue()) {
/*     */             return Mono.empty();
/*     */           }
/*     */           if (registeredSessionsCount == maximumSessions.intValue()) {
/*     */             for (ReactiveSessionInformation registeredSession : registeredSessions) {
/*     */               if (registeredSession.getSessionId().equals(currentSession.getId())) {
/*     */                 return Mono.empty();
/*     */               }
/*     */             } 
/*     */           }
/*     */           return this.maximumSessionsExceededHandler.handle(new MaximumSessionsContext(authentication, registeredSessions, maximumSessions.intValue(), currentSession));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionLimit(SessionLimit sessionLimit) {
/*  99 */     Assert.notNull(sessionLimit, "sessionLimit cannot be null");
/* 100 */     this.sessionLimit = sessionLimit;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ConcurrentSessionControlServerAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */