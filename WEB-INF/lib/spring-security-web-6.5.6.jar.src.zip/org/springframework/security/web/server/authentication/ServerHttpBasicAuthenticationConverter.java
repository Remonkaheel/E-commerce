/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.server.ServerHttpBasicAuthenticationConverter;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerHttpBasicAuthenticationConverter
/*    */   extends ServerHttpBasicAuthenticationConverter
/*    */   implements ServerAuthenticationConverter
/*    */ {
/*    */   public Mono<Authentication> convert(ServerWebExchange exchange) {
/* 38 */     return apply(exchange);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerHttpBasicAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */