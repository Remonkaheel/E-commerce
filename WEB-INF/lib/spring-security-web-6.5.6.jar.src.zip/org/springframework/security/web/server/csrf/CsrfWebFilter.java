/*     */ package org.springframework.security.web.server.csrf;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.web.server.authorization.HttpStatusServerAccessDeniedHandler;
/*     */ import org.springframework.security.web.server.authorization.ServerAccessDeniedHandler;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsrfWebFilter
/*     */   implements WebFilter
/*     */ {
/*  67 */   public static final ServerWebExchangeMatcher DEFAULT_CSRF_MATCHER = new DefaultRequireCsrfProtectionMatcher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private static final String SHOULD_NOT_FILTER = "SHOULD_NOT_FILTER" + CsrfWebFilter.class.getName();
/*     */   
/*  79 */   private ServerWebExchangeMatcher requireCsrfProtectionMatcher = DEFAULT_CSRF_MATCHER;
/*     */   
/*  81 */   private ServerCsrfTokenRepository csrfTokenRepository = new WebSessionServerCsrfTokenRepository();
/*     */   
/*  83 */   private ServerAccessDeniedHandler accessDeniedHandler = (ServerAccessDeniedHandler)new HttpStatusServerAccessDeniedHandler(HttpStatus.FORBIDDEN);
/*     */ 
/*     */   
/*  86 */   private ServerCsrfTokenRequestHandler requestHandler = new XorServerCsrfTokenRequestAttributeHandler();
/*     */   
/*     */   public void setAccessDeniedHandler(ServerAccessDeniedHandler accessDeniedHandler) {
/*  89 */     Assert.notNull(accessDeniedHandler, "accessDeniedHandler");
/*  90 */     this.accessDeniedHandler = accessDeniedHandler;
/*     */   }
/*     */   
/*     */   public void setCsrfTokenRepository(ServerCsrfTokenRepository csrfTokenRepository) {
/*  94 */     Assert.notNull(csrfTokenRepository, "csrfTokenRepository cannot be null");
/*  95 */     this.csrfTokenRepository = csrfTokenRepository;
/*     */   }
/*     */   
/*     */   public void setRequireCsrfProtectionMatcher(ServerWebExchangeMatcher requireCsrfProtectionMatcher) {
/*  99 */     Assert.notNull(requireCsrfProtectionMatcher, "requireCsrfProtectionMatcher cannot be null");
/* 100 */     this.requireCsrfProtectionMatcher = requireCsrfProtectionMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestHandler(ServerCsrfTokenRequestHandler requestHandler) {
/* 112 */     Assert.notNull(requestHandler, "requestHandler cannot be null");
/* 113 */     this.requestHandler = requestHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 118 */     if (Boolean.TRUE.equals(exchange.getAttribute(SHOULD_NOT_FILTER))) {
/* 119 */       return chain.filter(exchange).then(Mono.empty());
/*     */     }
/* 121 */     return this.requireCsrfProtectionMatcher.matches(exchange)
/* 122 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 123 */       .filter(matchResult -> !exchange.getAttributes().containsKey(CsrfToken.class.getName()))
/* 124 */       .flatMap(m -> validateToken(exchange))
/* 125 */       .flatMap(m -> continueFilterChain(exchange, chain))
/* 126 */       .switchIfEmpty(continueFilterChain(exchange, chain).then(Mono.empty()))
/* 127 */       .onErrorResume(CsrfException.class, ex -> this.accessDeniedHandler.handle(exchange, ex));
/*     */   }
/*     */   
/*     */   public static void skipExchange(ServerWebExchange exchange) {
/* 131 */     exchange.getAttributes().put(SHOULD_NOT_FILTER, Boolean.TRUE);
/*     */   }
/*     */   
/*     */   private Mono<Void> validateToken(ServerWebExchange exchange) {
/* 135 */     return this.csrfTokenRepository.loadToken(exchange)
/* 136 */       .switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new CsrfException("An expected CSRF token cannot be found"))))
/* 137 */       .filterWhen(expected -> containsValidCsrfToken(exchange, expected))
/* 138 */       .switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new CsrfException("Invalid CSRF Token"))))
/* 139 */       .then();
/*     */   }
/*     */   
/*     */   private Mono<Boolean> containsValidCsrfToken(ServerWebExchange exchange, CsrfToken expected) {
/* 143 */     return this.requestHandler.resolveCsrfTokenValue(exchange, expected)
/* 144 */       .map(actual -> Boolean.valueOf(equalsConstantTime(actual, expected.getToken())));
/*     */   }
/*     */   
/*     */   private Mono<Void> continueFilterChain(ServerWebExchange exchange, WebFilterChain chain) {
/* 148 */     return Mono.defer(() -> {
/*     */           Mono<CsrfToken> csrfToken = csrfToken(exchange);
/*     */           this.requestHandler.handle(exchange, csrfToken);
/*     */           return chain.filter(exchange);
/*     */         });
/*     */   }
/*     */   
/*     */   private Mono<CsrfToken> csrfToken(ServerWebExchange exchange) {
/* 156 */     return this.csrfTokenRepository.loadToken(exchange).switchIfEmpty(generateToken(exchange));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equalsConstantTime(String expected, String actual) {
/* 166 */     if (expected == actual) {
/* 167 */       return true;
/*     */     }
/* 169 */     if (expected == null || actual == null) {
/* 170 */       return false;
/*     */     }
/*     */     
/* 173 */     byte[] expectedBytes = Utf8.encode(expected);
/* 174 */     byte[] actualBytes = Utf8.encode(actual);
/* 175 */     return MessageDigest.isEqual(expectedBytes, actualBytes);
/*     */   }
/*     */   
/*     */   private Mono<CsrfToken> generateToken(ServerWebExchange exchange) {
/* 179 */     return this.csrfTokenRepository.generateToken(exchange)
/* 180 */       .delayUntil(token -> this.csrfTokenRepository.saveToken(exchange, token))
/* 181 */       .cache();
/*     */   }
/*     */   
/*     */   private static class DefaultRequireCsrfProtectionMatcher
/*     */     implements ServerWebExchangeMatcher {
/* 186 */     private static final Set<HttpMethod> ALLOWED_METHODS = new HashSet<>(
/* 187 */         Arrays.asList(new HttpMethod[] { HttpMethod.GET, HttpMethod.HEAD, HttpMethod.TRACE, HttpMethod.OPTIONS }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 193 */       Objects.requireNonNull(ALLOWED_METHODS); return Mono.just(exchange.getRequest()).flatMap(r -> Mono.justOrEmpty(r.getMethod())).filter(ALLOWED_METHODS::contains)
/* 194 */         .flatMap(m -> ServerWebExchangeMatcher.MatchResult.notMatch())
/* 195 */         .switchIfEmpty(ServerWebExchangeMatcher.MatchResult.match());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\CsrfWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */