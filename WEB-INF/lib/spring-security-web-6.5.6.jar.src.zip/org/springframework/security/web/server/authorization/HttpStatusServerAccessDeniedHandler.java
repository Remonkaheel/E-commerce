/*    */ package org.springframework.security.web.server.authorization;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.io.buffer.DataBuffer;
/*    */ import org.springframework.core.io.buffer.DataBufferFactory;
/*    */ import org.springframework.core.io.buffer.DataBufferUtils;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.HttpStatusCode;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpStatusServerAccessDeniedHandler
/*    */   implements ServerAccessDeniedHandler
/*    */ {
/*    */   private final HttpStatus httpStatus;
/*    */   
/*    */   public HttpStatusServerAccessDeniedHandler(HttpStatus httpStatus) {
/* 47 */     Assert.notNull(httpStatus, "httpStatus cannot be null");
/* 48 */     this.httpStatus = httpStatus;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> handle(ServerWebExchange exchange, AccessDeniedException ex) {
/* 53 */     return Mono.defer(() -> Mono.just(exchange.getResponse())).flatMap(response -> {
/*    */           response.setStatusCode((HttpStatusCode)this.httpStatus);
/*    */           response.getHeaders().setContentType(MediaType.TEXT_PLAIN);
/*    */           DataBufferFactory dataBufferFactory = response.bufferFactory();
/*    */           DataBuffer buffer = dataBufferFactory.wrap("Access Denied".getBytes(Charset.defaultCharset()));
/*    */           return response.writeWith((Publisher)Mono.just(buffer)).doOnError(());
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authorization\HttpStatusServerAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */