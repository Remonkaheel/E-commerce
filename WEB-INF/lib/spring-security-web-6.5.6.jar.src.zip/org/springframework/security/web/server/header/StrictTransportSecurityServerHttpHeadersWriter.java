/*     */ package org.springframework.security.web.server.header;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StrictTransportSecurityServerHttpHeadersWriter
/*     */   implements ServerHttpHeadersWriter
/*     */ {
/*     */   public static final String STRICT_TRANSPORT_SECURITY = "Strict-Transport-Security";
/*     */   private String maxAge;
/*     */   private String subdomain;
/*     */   private String preload;
/*     */   private ServerHttpHeadersWriter delegate;
/*     */   
/*     */   public StrictTransportSecurityServerHttpHeadersWriter() {
/*  46 */     setIncludeSubDomains(true);
/*  47 */     setMaxAge(Duration.ofDays(365L));
/*  48 */     setPreload(false);
/*  49 */     updateDelegate();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> writeHttpHeaders(ServerWebExchange exchange) {
/*  54 */     return isSecure(exchange) ? this.delegate.writeHttpHeaders(exchange) : Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludeSubDomains(boolean includeSubDomains) {
/*  62 */     this.subdomain = includeSubDomains ? " ; includeSubDomains" : "";
/*  63 */     updateDelegate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreload(boolean preload) {
/*  79 */     this.preload = preload ? " ; preload" : "";
/*  80 */     updateDelegate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAge(Duration maxAge) {
/*  88 */     this.maxAge = "max-age=" + maxAge.getSeconds();
/*  89 */     updateDelegate();
/*     */   }
/*     */   
/*     */   private void updateDelegate() {
/*  93 */     StaticServerHttpHeadersWriter.Builder builder = StaticServerHttpHeadersWriter.builder();
/*  94 */     builder.header("Strict-Transport-Security", new String[] { this.maxAge + this.maxAge + this.subdomain });
/*  95 */     this.delegate = builder.build();
/*     */   }
/*     */   
/*     */   private boolean isSecure(ServerWebExchange exchange) {
/*  99 */     String scheme = exchange.getRequest().getURI().getScheme();
/* 100 */     boolean isSecure = (scheme != null && scheme.equalsIgnoreCase("https"));
/* 101 */     return isSecure;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\header\StrictTransportSecurityServerHttpHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */