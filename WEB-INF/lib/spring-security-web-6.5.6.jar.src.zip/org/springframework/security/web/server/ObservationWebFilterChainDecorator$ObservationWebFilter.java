/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ObservationWebFilter
/*     */   implements WebFilter
/*     */ {
/*     */   private final ObservationRegistry registry;
/* 168 */   private final ObservationWebFilterChainDecorator.WebFilterChainObservationConvention convention = new ObservationWebFilterChainDecorator.WebFilterChainObservationConvention();
/*     */   
/*     */   private final WebFilter filter;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final int position;
/*     */   
/*     */   private final int size;
/*     */   
/*     */   ObservationWebFilter(ObservationRegistry registry, WebFilter filter, int position, int size) {
/* 179 */     this.registry = registry;
/* 180 */     this.filter = filter;
/* 181 */     this.name = filter.getClass().getSimpleName();
/* 182 */     this.position = position;
/* 183 */     this.size = size;
/*     */   }
/*     */   
/*     */   String getName() {
/* 187 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 192 */     if (this.position == 1) {
/* 193 */       return Mono.deferContextual(contextView -> {
/*     */             Observation parentObservation = (Observation)contextView.getOrDefault("micrometer.observation", null);
/*     */             
/*     */             ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = parent(exchange, parentObservation);
/*     */             return parent.wrap(this::wrapFilter).filter(exchange, chain);
/*     */           });
/*     */     }
/* 200 */     return wrapFilter(exchange, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> wrapFilter(ServerWebExchange exchange, WebFilterChain chain) {
/* 205 */     ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = ObservationWebFilterChainDecorator.observation(exchange);
/* 206 */     Observation.Context context = parent.before().getContext(); if (context instanceof ObservationWebFilterChainDecorator.WebFilterChainObservationContext) { ObservationWebFilterChainDecorator.WebFilterChainObservationContext parentBefore = (ObservationWebFilterChainDecorator.WebFilterChainObservationContext)context;
/* 207 */       parentBefore.setChainSize(this.size);
/* 208 */       parentBefore.setFilterName(this.name);
/* 209 */       parentBefore.setChainPosition(this.position); }
/*     */     
/* 211 */     return this.filter.filter(exchange, chain).doOnSuccess(result -> {
/*     */           parent.start();
/*     */           Observation.Context patt7767$temp = parent.after().getContext();
/*     */           if (patt7767$temp instanceof ObservationWebFilterChainDecorator.WebFilterChainObservationContext) {
/*     */             ObservationWebFilterChainDecorator.WebFilterChainObservationContext parentAfter = (ObservationWebFilterChainDecorator.WebFilterChainObservationContext)patt7767$temp;
/*     */             parentAfter.setChainSize(this.size);
/*     */             parentAfter.setFilterName(this.name);
/*     */             parentAfter.setChainPosition(this.size - this.position + 1);
/*     */           } 
/*     */         });
/*     */   } private ObservationWebFilterChainDecorator.AroundWebFilterObservation parent(ServerWebExchange exchange, Observation parentObservation) {
/* 222 */     ObservationWebFilterChainDecorator.WebFilterChainObservationContext beforeContext = ObservationWebFilterChainDecorator.WebFilterChainObservationContext.before();
/* 223 */     ObservationWebFilterChainDecorator.WebFilterChainObservationContext afterContext = ObservationWebFilterChainDecorator.WebFilterChainObservationContext.after();
/*     */     
/* 225 */     Observation before = Observation.createNotStarted(this.convention, () -> beforeContext, this.registry).parentObservation(parentObservation);
/*     */     
/* 227 */     Observation after = Observation.createNotStarted(this.convention, () -> afterContext, this.registry).parentObservation(parentObservation);
/* 228 */     ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = ObservationWebFilterChainDecorator.AroundWebFilterObservation.create(before, after);
/* 229 */     exchange.getAttributes().put(ObservationWebFilterChainDecorator.ATTRIBUTE, parent);
/* 230 */     return parent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ObservationWebFilterChainDecorator$ObservationWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */