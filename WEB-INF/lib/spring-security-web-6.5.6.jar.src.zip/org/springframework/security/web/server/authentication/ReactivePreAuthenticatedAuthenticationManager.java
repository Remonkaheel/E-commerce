/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
/*    */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*    */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactivePreAuthenticatedAuthenticationManager
/*    */   implements ReactiveAuthenticationManager
/*    */ {
/*    */   private final ReactiveUserDetailsService userDetailsService;
/*    */   private final UserDetailsChecker userDetailsChecker;
/*    */   
/*    */   public ReactivePreAuthenticatedAuthenticationManager(ReactiveUserDetailsService userDetailsService) {
/* 50 */     this(userDetailsService, (UserDetailsChecker)new AccountStatusUserDetailsChecker());
/*    */   }
/*    */ 
/*    */   
/*    */   public ReactivePreAuthenticatedAuthenticationManager(ReactiveUserDetailsService userDetailsService, UserDetailsChecker userDetailsChecker) {
/* 55 */     this.userDetailsService = userDetailsService;
/* 56 */     this.userDetailsChecker = userDetailsChecker;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Authentication> authenticate(Authentication authentication) {
/* 64 */     Objects.requireNonNull(this.userDetailsService);
/*    */     
/* 66 */     Objects.requireNonNull(this.userDetailsChecker); return Mono.just(authentication).filter(this::supports).map(Principal::getName).flatMap(this.userDetailsService::findByUsername).switchIfEmpty(Mono.error(() -> new UsernameNotFoundException("User not found"))).doOnNext(this.userDetailsChecker::check)
/* 67 */       .map(userDetails -> {
/*    */           PreAuthenticatedAuthenticationToken result = new PreAuthenticatedAuthenticationToken(userDetails, authentication.getCredentials(), userDetails.getAuthorities());
/*    */           result.setDetails(authentication.getDetails());
/*    */           return (Authentication)result;
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean supports(Authentication authentication) {
/* 76 */     return PreAuthenticatedAuthenticationToken.class.isAssignableFrom(authentication.getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ReactivePreAuthenticatedAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */