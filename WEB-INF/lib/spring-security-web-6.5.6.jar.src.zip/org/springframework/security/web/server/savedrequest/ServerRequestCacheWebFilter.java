/*    */ package org.springframework.security.web.server.savedrequest;
/*    */ 
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerRequestCacheWebFilter
/*    */   implements WebFilter
/*    */ {
/* 34 */   private ServerRequestCache requestCache = new WebSessionServerRequestCache();
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 38 */     return this.requestCache.removeMatchingRequest(exchange)
/* 39 */       .map(r -> exchange.mutate().request(r).build())
/* 40 */       .defaultIfEmpty(exchange)
/* 41 */       .flatMap(e -> chain.filter(e));
/*    */   }
/*    */   
/*    */   public void setRequestCache(ServerRequestCache requestCache) {
/* 45 */     Assert.notNull(requestCache, "requestCache cannot be null");
/* 46 */     this.requestCache = requestCache;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\savedrequest\ServerRequestCacheWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */