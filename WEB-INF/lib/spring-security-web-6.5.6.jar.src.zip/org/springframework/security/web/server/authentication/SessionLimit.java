/*    */ package org.springframework.security.web.server.authentication;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SessionLimit
/*    */   extends Function<Authentication, Mono<Integer>>
/*    */ {
/*    */   public static final SessionLimit UNLIMITED = authentication -> Mono.empty();
/*    */   
/*    */   static SessionLimit of(int maxSessions) {
/* 47 */     return authentication -> Mono.just(Integer.valueOf(maxSessions));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\SessionLimit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */