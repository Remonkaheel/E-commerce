/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NegatedServerWebExchangeMatcher
/*    */   implements ServerWebExchangeMatcher
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(NegatedServerWebExchangeMatcher.class);
/*    */   
/*    */   private final ServerWebExchangeMatcher matcher;
/*    */   
/*    */   public NegatedServerWebExchangeMatcher(ServerWebExchangeMatcher matcher) {
/* 42 */     Assert.notNull(matcher, "matcher cannot be null");
/* 43 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ServerWebExchangeMatcher.MatchResult> matches(ServerWebExchange exchange) {
/* 48 */     return this.matcher.matches(exchange)
/* 49 */       .flatMap(this::negate)
/* 50 */       .doOnNext(matchResult -> logger.debug(LogMessage.format("matches = %s", Boolean.valueOf(matchResult.isMatch()))));
/*    */   }
/*    */   
/*    */   private Mono<ServerWebExchangeMatcher.MatchResult> negate(ServerWebExchangeMatcher.MatchResult matchResult) {
/* 54 */     return matchResult.isMatch() ? ServerWebExchangeMatcher.MatchResult.notMatch() : ServerWebExchangeMatcher.MatchResult.match();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "NegatedServerWebExchangeMatcher{matcher=" + String.valueOf(this.matcher) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\NegatedServerWebExchangeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */