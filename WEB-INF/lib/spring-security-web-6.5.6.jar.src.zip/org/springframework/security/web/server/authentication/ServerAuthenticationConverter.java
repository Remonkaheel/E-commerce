package org.springframework.security.web.server.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@FunctionalInterface
public interface ServerAuthenticationConverter {
  Mono<Authentication> convert(ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\ServerAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */