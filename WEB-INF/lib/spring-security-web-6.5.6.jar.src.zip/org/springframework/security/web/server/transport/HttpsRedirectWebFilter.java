/*    */ package org.springframework.security.web.server.transport;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.web.PortMapper;
/*    */ import org.springframework.security.web.PortMapperImpl;
/*    */ import org.springframework.security.web.server.DefaultServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.ServerRedirectStrategy;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import org.springframework.web.util.UriComponentsBuilder;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpsRedirectWebFilter
/*    */   implements WebFilter
/*    */ {
/* 48 */   private PortMapper portMapper = (PortMapper)new PortMapperImpl();
/*    */   
/* 50 */   private ServerWebExchangeMatcher requiresHttpsRedirectMatcher = ServerWebExchangeMatchers.anyExchange();
/*    */   
/* 52 */   private final ServerRedirectStrategy redirectStrategy = (ServerRedirectStrategy)new DefaultServerRedirectStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 58 */     Objects.requireNonNull(this.requiresHttpsRedirectMatcher); return Mono.just(exchange).filter(this::isInsecure).flatMap(this.requiresHttpsRedirectMatcher::matches)
/* 59 */       .filter(matchResult -> matchResult.isMatch())
/* 60 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/* 61 */       .map(matchResult -> createRedirectUri(exchange))
/* 62 */       .flatMap(uri -> this.redirectStrategy.sendRedirect(exchange, uri));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPortMapper(PortMapper portMapper) {
/* 70 */     Assert.notNull(portMapper, "portMapper cannot be null");
/* 71 */     this.portMapper = portMapper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequiresHttpsRedirectMatcher(ServerWebExchangeMatcher requiresHttpsRedirectMatcher) {
/* 83 */     Assert.notNull(requiresHttpsRedirectMatcher, "requiresHttpsRedirectMatcher cannot be null");
/* 84 */     this.requiresHttpsRedirectMatcher = requiresHttpsRedirectMatcher;
/*    */   }
/*    */   
/*    */   private boolean isInsecure(ServerWebExchange exchange) {
/* 88 */     return !"https".equals(exchange.getRequest().getURI().getScheme());
/*    */   }
/*    */   
/*    */   private URI createRedirectUri(ServerWebExchange exchange) {
/* 92 */     int port = exchange.getRequest().getURI().getPort();
/* 93 */     UriComponentsBuilder builder = UriComponentsBuilder.fromUri(exchange.getRequest().getURI());
/* 94 */     if (port > 0) {
/* 95 */       Integer httpsPort = this.portMapper.lookupHttpsPort(Integer.valueOf(port));
/* 96 */       Assert.state((httpsPort != null), () -> "HTTP Port '" + port + "' does not have a corresponding HTTPS Port");
/* 97 */       builder.port(httpsPort.intValue());
/*    */     } 
/* 99 */     return builder.scheme("https").build().toUri();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\transport\HttpsRedirectWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */