/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ServerHttpBasicAuthenticationConverter
/*    */   implements Function<ServerWebExchange, Mono<Authentication>>
/*    */ {
/*    */   public static final String BASIC = "Basic ";
/* 49 */   private Charset credentialsCharset = StandardCharsets.UTF_8;
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Mono<Authentication> apply(ServerWebExchange exchange) {
/* 54 */     ServerHttpRequest request = exchange.getRequest();
/* 55 */     String authorization = request.getHeaders().getFirst("Authorization");
/* 56 */     if (!StringUtils.startsWithIgnoreCase(authorization, "basic ")) {
/* 57 */       return Mono.empty();
/*    */     }
/* 59 */     String credentials = (authorization.length() <= "Basic ".length()) ? "" : authorization.substring("Basic ".length());
/* 60 */     String decoded = new String(base64Decode(credentials), this.credentialsCharset);
/* 61 */     String[] parts = decoded.split(":", 2);
/* 62 */     if (parts.length != 2) {
/* 63 */       return Mono.empty();
/*    */     }
/* 65 */     return Mono.just(UsernamePasswordAuthenticationToken.unauthenticated(parts[0], parts[1]));
/*    */   }
/*    */   
/*    */   private byte[] base64Decode(String value) {
/*    */     try {
/* 70 */       return Base64.getDecoder().decode(value);
/*    */     }
/* 72 */     catch (Exception ex) {
/* 73 */       return new byte[0];
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setCredentialsCharset(Charset credentialsCharset) {
/* 85 */     Assert.notNull(credentialsCharset, "credentialsCharset cannot be null");
/* 86 */     this.credentialsCharset = credentialsCharset;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ServerHttpBasicAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */