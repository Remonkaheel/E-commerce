/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import java.util.Objects;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface WebFilterObservation
/*     */   extends Observation
/*     */ {
/* 399 */   public static final WebFilterObservation NOOP = new WebFilterObservation() {  }
/*     */   ;
/*     */   
/*     */   static WebFilterObservation create(Observation observation) {
/* 403 */     if (observation.isNoop()) {
/* 404 */       return NOOP;
/*     */     }
/* 406 */     return new SimpleWebFilterObservation(observation);
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation contextualName(String contextualName) {
/* 411 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation parentObservation(Observation parentObservation) {
/* 416 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 421 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 426 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 431 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation error(Throwable error) {
/* 436 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation event(Observation.Event event) {
/* 441 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation start() {
/* 446 */     return Observation.NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   default Observation.Context getContext() {
/* 451 */     return new Observation.Context();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void stop() {}
/*     */ 
/*     */ 
/*     */   
/*     */   default Observation.Scope openScope() {
/* 461 */     return Observation.Scope.NOOP;
/*     */   }
/*     */   
/*     */   default WebFilter wrap(WebFilter filter) {
/* 465 */     return filter;
/*     */   }
/*     */   
/*     */   default WebFilterChain wrap(WebFilterChain chain) {
/* 469 */     return chain;
/*     */   }
/*     */   
/*     */   public static class SimpleWebFilterObservation
/*     */     implements WebFilterObservation {
/*     */     private final ObservationWebFilterChainDecorator.PhasedObservation observation;
/*     */     
/*     */     SimpleWebFilterObservation(Observation observation) {
/* 477 */       this.observation = new ObservationWebFilterChainDecorator.PhasedObservation(observation);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation start() {
/* 482 */       return this.observation.start();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation error(Throwable ex) {
/* 487 */       return this.observation.error(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void stop() {
/* 492 */       this.observation.stop();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation contextualName(String contextualName) {
/* 497 */       return this.observation.contextualName(contextualName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation parentObservation(Observation parentObservation) {
/* 502 */       return this.observation.parentObservation(parentObservation);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 507 */       return this.observation.lowCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 512 */       return this.observation.highCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 517 */       return this.observation.observationConvention(observationConvention);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation event(Observation.Event event) {
/* 522 */       return this.observation.event(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Context getContext() {
/* 527 */       return this.observation.getContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Scope openScope() {
/* 532 */       return this.observation.openScope();
/*     */     }
/*     */ 
/*     */     
/*     */     public WebFilter wrap(WebFilter filter) {
/* 537 */       if (this.observation.isNoop()) {
/* 538 */         return filter;
/*     */       }
/* 540 */       return (exchange, chain) -> {
/*     */           this.observation.start();
/*     */           Objects.requireNonNull(this.observation);
/*     */           return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(());
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebFilterChain wrap(WebFilterChain chain) {
/* 554 */       if (this.observation.isNoop()) {
/* 555 */         return chain;
/*     */       }
/* 557 */       return exchange -> {
/*     */           this.observation.start();
/*     */           Objects.requireNonNull(this.observation);
/*     */           return chain.filter(exchange).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(()).contextWrite(());
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ObservationWebFilterChainDecorator$WebFilterObservation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */