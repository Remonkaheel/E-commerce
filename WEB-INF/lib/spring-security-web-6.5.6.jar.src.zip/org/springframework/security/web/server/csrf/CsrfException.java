/*    */ package org.springframework.security.web.server.csrf;
/*    */ 
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsrfException
/*    */   extends AccessDeniedException
/*    */ {
/*    */   private static final long serialVersionUID = -8209680716517631141L;
/*    */   
/*    */   public CsrfException(String message) {
/* 35 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\csrf\CsrfException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */