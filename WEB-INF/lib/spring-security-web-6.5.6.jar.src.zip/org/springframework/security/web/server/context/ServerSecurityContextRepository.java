package org.springframework.security.web.server.context;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface ServerSecurityContextRepository {
  Mono<Void> save(ServerWebExchange paramServerWebExchange, SecurityContext paramSecurityContext);
  
  Mono<SecurityContext> load(ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\ServerSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */