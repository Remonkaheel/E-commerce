/*    */ package org.springframework.security.web.server.util.matcher;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MatchResult
/*    */ {
/*    */   private final boolean match;
/*    */   private final Map<String, Object> variables;
/*    */   
/*    */   private MatchResult(boolean match, Map<String, Object> variables) {
/* 51 */     this.match = match;
/* 52 */     this.variables = variables;
/*    */   }
/*    */   
/*    */   public boolean isMatch() {
/* 56 */     return this.match;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getVariables() {
/* 64 */     return this.variables;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<MatchResult> match() {
/* 72 */     return match(Collections.emptyMap());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<MatchResult> match(Map<String, Object> variables) {
/* 83 */     return Mono.just(new MatchResult(true, variables));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<MatchResult> notMatch() {
/* 91 */     return Mono.just(new MatchResult(false, Collections.emptyMap()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\serve\\util\matcher\ServerWebExchangeMatcher$MatchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */