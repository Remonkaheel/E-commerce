/*     */ package org.springframework.security.web.server;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import org.springframework.web.server.WebHandler;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObservationWebFilterChainDecorator
/*     */   implements WebFilterChainProxy.WebFilterChainDecorator
/*     */ {
/*  49 */   private static final String ATTRIBUTE = String.valueOf(ObservationWebFilterChainDecorator.class) + ".observation";
/*     */   
/*     */   static final String UNSECURED_OBSERVATION_NAME = "spring.security.http.unsecured.requests";
/*     */   
/*     */   static final String SECURED_OBSERVATION_NAME = "spring.security.http.secured.requests";
/*     */   
/*     */   private final ObservationRegistry registry;
/*     */   
/*     */   public ObservationWebFilterChainDecorator(ObservationRegistry registry) {
/*  58 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebFilterChain decorate(WebFilterChain original) {
/*  63 */     return wrapUnsecured(original);
/*     */   }
/*     */ 
/*     */   
/*     */   public WebFilterChain decorate(WebFilterChain original, List<WebFilter> filters) {
/*  68 */     Objects.requireNonNull(wrapSecured(original)); return new ObservationWebFilterChain(wrapSecured(original)::filter, wrap(filters));
/*     */   }
/*     */   
/*     */   private static AroundWebFilterObservation observation(ServerWebExchange exchange) {
/*  72 */     return (AroundWebFilterObservation)exchange.getAttribute(ATTRIBUTE);
/*     */   }
/*     */   
/*     */   private WebFilterChain wrapSecured(WebFilterChain original) {
/*  76 */     return exchange -> Mono.deferContextual(());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebFilterChain wrapUnsecured(WebFilterChain original) {
/*  87 */     return exchange -> Mono.deferContextual(());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ObservationWebFilter> wrap(List<WebFilter> filters) {
/*  97 */     int size = filters.size();
/*  98 */     List<ObservationWebFilter> observableFilters = new ArrayList<>();
/*  99 */     int position = 1;
/* 100 */     for (WebFilter filter : filters) {
/* 101 */       observableFilters.add(new ObservationWebFilter(this.registry, filter, position, size));
/* 102 */       position++;
/*     */     } 
/* 104 */     return observableFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class ObservationWebFilterChain
/*     */     implements WebFilterChain
/*     */   {
/*     */     private final WebHandler handler;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ObservationWebFilterChainDecorator.ObservationWebFilter currentFilter;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ObservationWebFilterChain chain;
/*     */ 
/*     */     
/*     */     ObservationWebFilterChain(WebHandler handler, List<ObservationWebFilterChainDecorator.ObservationWebFilter> filters) {
/* 124 */       Assert.notNull(handler, "WebHandler is required");
/* 125 */       this.handler = handler;
/* 126 */       ObservationWebFilterChain chain = initChain(filters, handler);
/* 127 */       this.currentFilter = chain.currentFilter;
/* 128 */       this.chain = chain.chain;
/*     */     }
/*     */     
/*     */     private static ObservationWebFilterChain initChain(List<ObservationWebFilterChainDecorator.ObservationWebFilter> filters, WebHandler handler) {
/* 132 */       ObservationWebFilterChain chain = new ObservationWebFilterChain(handler, null, null);
/* 133 */       ListIterator<? extends ObservationWebFilterChainDecorator.ObservationWebFilter> iterator = filters.listIterator(filters.size());
/* 134 */       while (iterator.hasPrevious()) {
/* 135 */         chain = new ObservationWebFilterChain(handler, iterator.previous(), chain);
/*     */       }
/* 137 */       return chain;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ObservationWebFilterChain(WebHandler handler, @Nullable ObservationWebFilterChainDecorator.ObservationWebFilter currentFilter, @Nullable ObservationWebFilterChain chain) {
/* 145 */       this.currentFilter = currentFilter;
/* 146 */       this.handler = handler;
/* 147 */       this.chain = chain;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> filter(ServerWebExchange exchange) {
/* 152 */       return Mono.defer(() -> (this.currentFilter != null && this.chain != null) ? invokeFilter(this.currentFilter, this.chain, exchange) : this.handler.handle(exchange));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Mono<Void> invokeFilter(ObservationWebFilterChainDecorator.ObservationWebFilter current, ObservationWebFilterChain chain, ServerWebExchange exchange) {
/* 158 */       String currentName = current.getName();
/* 159 */       return current.filter(exchange, chain).checkpoint(currentName + " [DefaultWebFilterChain]");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ObservationWebFilter
/*     */     implements WebFilter
/*     */   {
/*     */     private final ObservationRegistry registry;
/* 168 */     private final ObservationWebFilterChainDecorator.WebFilterChainObservationConvention convention = new ObservationWebFilterChainDecorator.WebFilterChainObservationConvention();
/*     */     
/*     */     private final WebFilter filter;
/*     */     
/*     */     private final String name;
/*     */     
/*     */     private final int position;
/*     */     
/*     */     private final int size;
/*     */     
/*     */     ObservationWebFilter(ObservationRegistry registry, WebFilter filter, int position, int size) {
/* 179 */       this.registry = registry;
/* 180 */       this.filter = filter;
/* 181 */       this.name = filter.getClass().getSimpleName();
/* 182 */       this.position = position;
/* 183 */       this.size = size;
/*     */     }
/*     */     
/*     */     String getName() {
/* 187 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 192 */       if (this.position == 1) {
/* 193 */         return Mono.deferContextual(contextView -> {
/*     */               Observation parentObservation = (Observation)contextView.getOrDefault("micrometer.observation", null);
/*     */               
/*     */               ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = parent(exchange, parentObservation);
/*     */               return parent.wrap(this::wrapFilter).filter(exchange, chain);
/*     */             });
/*     */       }
/* 200 */       return wrapFilter(exchange, chain);
/*     */     }
/*     */ 
/*     */     
/*     */     private Mono<Void> wrapFilter(ServerWebExchange exchange, WebFilterChain chain) {
/* 205 */       ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = ObservationWebFilterChainDecorator.observation(exchange);
/* 206 */       Observation.Context context = parent.before().getContext(); if (context instanceof ObservationWebFilterChainDecorator.WebFilterChainObservationContext) { ObservationWebFilterChainDecorator.WebFilterChainObservationContext parentBefore = (ObservationWebFilterChainDecorator.WebFilterChainObservationContext)context;
/* 207 */         parentBefore.setChainSize(this.size);
/* 208 */         parentBefore.setFilterName(this.name);
/* 209 */         parentBefore.setChainPosition(this.position); }
/*     */       
/* 211 */       return this.filter.filter(exchange, chain).doOnSuccess(result -> {
/*     */             parent.start();
/*     */             Observation.Context patt7767$temp = parent.after().getContext();
/*     */             if (patt7767$temp instanceof ObservationWebFilterChainDecorator.WebFilterChainObservationContext) {
/*     */               ObservationWebFilterChainDecorator.WebFilterChainObservationContext parentAfter = (ObservationWebFilterChainDecorator.WebFilterChainObservationContext)patt7767$temp;
/*     */               parentAfter.setChainSize(this.size);
/*     */               parentAfter.setFilterName(this.name);
/*     */               parentAfter.setChainPosition(this.size - this.position + 1);
/*     */             } 
/*     */           });
/*     */     } private ObservationWebFilterChainDecorator.AroundWebFilterObservation parent(ServerWebExchange exchange, Observation parentObservation) {
/* 222 */       ObservationWebFilterChainDecorator.WebFilterChainObservationContext beforeContext = ObservationWebFilterChainDecorator.WebFilterChainObservationContext.before();
/* 223 */       ObservationWebFilterChainDecorator.WebFilterChainObservationContext afterContext = ObservationWebFilterChainDecorator.WebFilterChainObservationContext.after();
/*     */       
/* 225 */       Observation before = Observation.createNotStarted(this.convention, () -> beforeContext, this.registry).parentObservation(parentObservation);
/*     */       
/* 227 */       Observation after = Observation.createNotStarted(this.convention, () -> afterContext, this.registry).parentObservation(parentObservation);
/* 228 */       ObservationWebFilterChainDecorator.AroundWebFilterObservation parent = ObservationWebFilterChainDecorator.AroundWebFilterObservation.create(before, after);
/* 229 */       exchange.getAttributes().put(ObservationWebFilterChainDecorator.ATTRIBUTE, parent);
/* 230 */       return parent;
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements AroundWebFilterObservation {}
/*     */   
/*     */   static interface AroundWebFilterObservation extends WebFilterObservation {
/* 237 */     public static final AroundWebFilterObservation NOOP = new AroundWebFilterObservation() {  }
/*     */     ;
/*     */     
/*     */     static AroundWebFilterObservation create(Observation before, Observation after) {
/* 241 */       if (before.isNoop() || after.isNoop()) {
/* 242 */         return NOOP;
/*     */       }
/* 244 */       return new SimpleAroundWebFilterObservation(before, after);
/*     */     }
/*     */     
/*     */     default Observation before() {
/* 248 */       return Observation.NOOP;
/*     */     }
/*     */     
/*     */     default Observation after() {
/* 252 */       return Observation.NOOP;
/*     */     }
/*     */     
/*     */     public static class SimpleAroundWebFilterObservation
/*     */       implements AroundWebFilterObservation {
/* 257 */       private final Object lock = new Object();
/*     */       
/*     */       private final ObservationWebFilterChainDecorator.PhasedObservation before;
/*     */       
/*     */       private final ObservationWebFilterChainDecorator.PhasedObservation after;
/*     */       
/* 263 */       private volatile ObservationWebFilterChainDecorator.PhasedObservation currentObservation = ObservationWebFilterChainDecorator.PhasedObservation.NOOP;
/*     */       
/*     */       SimpleAroundWebFilterObservation(Observation before, Observation after) {
/* 266 */         this.before = new ObservationWebFilterChainDecorator.PhasedObservation(before);
/* 267 */         this.after = new ObservationWebFilterChainDecorator.PhasedObservation(after);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation start() {
/* 272 */         synchronized (this.lock) {
/* 273 */           if (this.currentObservation == ObservationWebFilterChainDecorator.PhasedObservation.NOOP) {
/* 274 */             this.before.start();
/* 275 */             this.currentObservation = this.before;
/* 276 */             return this.currentObservation;
/*     */           } 
/* 278 */           if (this.currentObservation == this.before) {
/* 279 */             this.before.stop();
/* 280 */             this.after.start();
/* 281 */             this.currentObservation = this.after;
/* 282 */             return this.currentObservation;
/*     */           } 
/*     */         } 
/* 285 */         return Observation.NOOP;
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation error(Throwable ex) {
/* 290 */         this.currentObservation.error(ex);
/* 291 */         return this.currentObservation.observation;
/*     */       }
/*     */ 
/*     */       
/*     */       public void stop() {
/* 296 */         this.before.stop();
/* 297 */         this.after.stop();
/*     */       }
/*     */       
/*     */       private void close() {
/* 301 */         this.before.close();
/* 302 */         this.after.close();
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation contextualName(String contextualName) {
/* 307 */         return this.currentObservation.observation.contextualName(contextualName);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation parentObservation(Observation parentObservation) {
/* 312 */         return this.currentObservation.observation.parentObservation(parentObservation);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 317 */         return this.currentObservation.observation.lowCardinalityKeyValue(keyValue);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 322 */         return this.currentObservation.observation.highCardinalityKeyValue(keyValue);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 327 */         return this.currentObservation.observation.observationConvention(observationConvention);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation event(Observation.Event event) {
/* 332 */         return this.currentObservation.observation.event(event);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation.Context getContext() {
/* 337 */         return this.currentObservation.observation.getContext();
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation.Scope openScope() {
/* 342 */         return this.currentObservation.observation.openScope();
/*     */       }
/*     */ 
/*     */       
/*     */       public WebFilterChain wrap(WebFilterChain chain) {
/* 347 */         return exchange -> {
/*     */             stop();
/*     */             return chain.filter(exchange).doOnSuccess(()).doOnCancel(this::start).doOnError(());
/*     */           };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public WebFilter wrap(WebFilter filter) {
/* 363 */         return (exchange, chain) -> {
/*     */             start();
/*     */             return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this::close).doOnError(()).contextWrite(());
/*     */           };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Observation before() {
/* 380 */         return this.before.observation;
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation after() {
/* 385 */         return this.after.observation;
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 390 */         return this.currentObservation.observation.toString(); } } } public static class SimpleAroundWebFilterObservation implements AroundWebFilterObservation { private final Object lock = new Object(); private final ObservationWebFilterChainDecorator.PhasedObservation before; private final ObservationWebFilterChainDecorator.PhasedObservation after; private volatile ObservationWebFilterChainDecorator.PhasedObservation currentObservation = ObservationWebFilterChainDecorator.PhasedObservation.NOOP; SimpleAroundWebFilterObservation(Observation before, Observation after) { this.before = new ObservationWebFilterChainDecorator.PhasedObservation(before); this.after = new ObservationWebFilterChainDecorator.PhasedObservation(after); } public String toString() { return this.currentObservation.observation.toString(); }
/*     */     public Observation start() { synchronized (this.lock) { if (this.currentObservation == ObservationWebFilterChainDecorator.PhasedObservation.NOOP) { this.before.start(); this.currentObservation = this.before; return this.currentObservation; }  if (this.currentObservation == this.before) { this.before.stop(); this.after.start(); this.currentObservation = this.after; return this.currentObservation; }  }  return Observation.NOOP; }
/*     */     public Observation error(Throwable ex) { this.currentObservation.error(ex); return this.currentObservation.observation; }
/*     */     public void stop() { this.before.stop(); this.after.stop(); }
/*     */     private void close() { this.before.close(); this.after.close(); }
/*     */     public Observation contextualName(String contextualName) { return this.currentObservation.observation.contextualName(contextualName); }
/*     */     public Observation parentObservation(Observation parentObservation) { return this.currentObservation.observation.parentObservation(parentObservation); } public Observation lowCardinalityKeyValue(KeyValue keyValue) { return this.currentObservation.observation.lowCardinalityKeyValue(keyValue); } public Observation highCardinalityKeyValue(KeyValue keyValue) { return this.currentObservation.observation.highCardinalityKeyValue(keyValue); } public Observation observationConvention(ObservationConvention<?> observationConvention) { return this.currentObservation.observation.observationConvention(observationConvention); } public Observation event(Observation.Event event) { return this.currentObservation.observation.event(event); } public Observation.Context getContext() { return this.currentObservation.observation.getContext(); } public Observation.Scope openScope() { return this.currentObservation.observation.openScope(); } public WebFilterChain wrap(WebFilterChain chain) { return exchange -> { stop(); return chain.filter(exchange).doOnSuccess(()).doOnCancel(this::start).doOnError(()); }; } public WebFilter wrap(WebFilter filter) { return (exchange, chain) -> { start(); return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this::close).doOnError(()).contextWrite(()); }; } public Observation before() { return this.before.observation; } public Observation after() { return this.after.observation; } }
/*     */    class null implements WebFilterObservation {} static interface WebFilterObservation extends Observation
/*     */   {
/* 399 */     public static final WebFilterObservation NOOP = new WebFilterObservation() {  }
/*     */     ;
/*     */     
/*     */     static WebFilterObservation create(Observation observation) {
/* 403 */       if (observation.isNoop()) {
/* 404 */         return NOOP;
/*     */       }
/* 406 */       return new SimpleWebFilterObservation(observation);
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation contextualName(String contextualName) {
/* 411 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation parentObservation(Observation parentObservation) {
/* 416 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 421 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 426 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 431 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation error(Throwable error) {
/* 436 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation event(Observation.Event event) {
/* 441 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation start() {
/* 446 */       return Observation.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     default Observation.Context getContext() {
/* 451 */       return new Observation.Context();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     default void stop() {}
/*     */ 
/*     */ 
/*     */     
/*     */     default Observation.Scope openScope() {
/* 461 */       return Observation.Scope.NOOP;
/*     */     }
/*     */     
/*     */     default WebFilter wrap(WebFilter filter) {
/* 465 */       return filter;
/*     */     }
/*     */     
/*     */     default WebFilterChain wrap(WebFilterChain chain) {
/* 469 */       return chain;
/*     */     }
/*     */     
/*     */     public static class SimpleWebFilterObservation
/*     */       implements WebFilterObservation {
/*     */       private final ObservationWebFilterChainDecorator.PhasedObservation observation;
/*     */       
/*     */       SimpleWebFilterObservation(Observation observation) {
/* 477 */         this.observation = new ObservationWebFilterChainDecorator.PhasedObservation(observation);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation start() {
/* 482 */         return this.observation.start();
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation error(Throwable ex) {
/* 487 */         return this.observation.error(ex);
/*     */       }
/*     */ 
/*     */       
/*     */       public void stop() {
/* 492 */         this.observation.stop();
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation contextualName(String contextualName) {
/* 497 */         return this.observation.contextualName(contextualName);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation parentObservation(Observation parentObservation) {
/* 502 */         return this.observation.parentObservation(parentObservation);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 507 */         return this.observation.lowCardinalityKeyValue(keyValue);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 512 */         return this.observation.highCardinalityKeyValue(keyValue);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 517 */         return this.observation.observationConvention(observationConvention);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation event(Observation.Event event) {
/* 522 */         return this.observation.event(event);
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation.Context getContext() {
/* 527 */         return this.observation.getContext();
/*     */       }
/*     */ 
/*     */       
/*     */       public Observation.Scope openScope() {
/* 532 */         return this.observation.openScope();
/*     */       }
/*     */ 
/*     */       
/*     */       public WebFilter wrap(WebFilter filter) {
/* 537 */         if (this.observation.isNoop()) {
/* 538 */           return filter;
/*     */         }
/* 540 */         return (exchange, chain) -> {
/*     */             this.observation.start();
/*     */             Objects.requireNonNull(this.observation);
/*     */             return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(());
/*     */           };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public WebFilterChain wrap(WebFilterChain chain)
/*     */       {
/* 554 */         if (this.observation.isNoop()) {
/* 555 */           return chain;
/*     */         }
/* 557 */         return exchange -> { this.observation.start(); Objects.requireNonNull(this.observation); return chain.filter(exchange).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(()).contextWrite(()); }; } } } public static class SimpleWebFilterObservation implements WebFilterObservation { private final ObservationWebFilterChainDecorator.PhasedObservation observation; SimpleWebFilterObservation(Observation observation) { this.observation = new ObservationWebFilterChainDecorator.PhasedObservation(observation); } public Observation start() { return this.observation.start(); } public Observation error(Throwable ex) { return this.observation.error(ex); } public void stop() { this.observation.stop(); } public Observation contextualName(String contextualName) { return this.observation.contextualName(contextualName); } public Observation parentObservation(Observation parentObservation) { return this.observation.parentObservation(parentObservation); } public WebFilterChain wrap(WebFilterChain chain) { if (this.observation.isNoop()) return chain;  return exchange -> {
/*     */           this.observation.start();
/*     */           Objects.requireNonNull(this.observation);
/*     */           return chain.filter(exchange).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(()).contextWrite(());
/*     */         }; }
/*     */      public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/*     */       return this.observation.lowCardinalityKeyValue(keyValue);
/*     */     } public Observation highCardinalityKeyValue(KeyValue keyValue) {
/*     */       return this.observation.highCardinalityKeyValue(keyValue);
/*     */     } public Observation observationConvention(ObservationConvention<?> observationConvention) {
/*     */       return this.observation.observationConvention(observationConvention);
/*     */     } public Observation event(Observation.Event event) {
/*     */       return this.observation.event(event);
/*     */     } public Observation.Context getContext() {
/*     */       return this.observation.getContext();
/*     */     } public Observation.Scope openScope() {
/*     */       return this.observation.openScope();
/*     */     } public WebFilter wrap(WebFilter filter) {
/*     */       if (this.observation.isNoop())
/*     */         return filter; 
/*     */       return (exchange, chain) -> {
/*     */           this.observation.start();
/*     */           Objects.requireNonNull(this.observation);
/*     */           return filter.filter(exchange, chain).doOnSuccess(()).doOnCancel(this.observation::stop).doOnError(());
/*     */         };
/*     */     } }
/*     */   static final class WebFilterChainObservationContext extends Observation.Context { private final String filterSection; private String filterName; private int chainPosition; private int chainSize;
/*     */     private WebFilterChainObservationContext(String filterSection) {
/* 585 */       this.filterSection = filterSection;
/*     */     }
/*     */     
/*     */     static WebFilterChainObservationContext before() {
/* 589 */       return new WebFilterChainObservationContext("before");
/*     */     }
/*     */     
/*     */     static WebFilterChainObservationContext after() {
/* 593 */       return new WebFilterChainObservationContext("after");
/*     */     }
/*     */     
/*     */     String getFilterSection() {
/* 597 */       return this.filterSection;
/*     */     }
/*     */     
/*     */     String getFilterName() {
/* 601 */       return this.filterName;
/*     */     }
/*     */     
/*     */     void setFilterName(String filterName) {
/* 605 */       this.filterName = filterName;
/*     */     }
/*     */     
/*     */     int getChainPosition() {
/* 609 */       return this.chainPosition;
/*     */     }
/*     */     
/*     */     void setChainPosition(int chainPosition) {
/* 613 */       this.chainPosition = chainPosition;
/*     */     }
/*     */     
/*     */     int getChainSize() {
/* 617 */       return this.chainSize;
/*     */     }
/*     */     
/*     */     void setChainSize(int chainSize) {
/* 621 */       this.chainSize = chainSize;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class WebFilterChainObservationConvention
/*     */     implements ObservationConvention<WebFilterChainObservationContext>
/*     */   {
/*     */     static final String CHAIN_OBSERVATION_NAME = "spring.security.filterchains";
/*     */     
/*     */     private static final String CHAIN_POSITION_NAME = "spring.security.filterchain.position";
/*     */     
/*     */     private static final String CHAIN_SIZE_NAME = "spring.security.filterchain.size";
/*     */     
/*     */     private static final String FILTER_SECTION_NAME = "spring.security.reached.filter.section";
/*     */     
/*     */     private static final String FILTER_NAME = "spring.security.reached.filter.name";
/*     */ 
/*     */     
/*     */     public String getName() {
/* 641 */       return "spring.security.filterchains";
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContextualName(ObservationWebFilterChainDecorator.WebFilterChainObservationContext context) {
/* 646 */       return "security filterchain " + context.getFilterSection();
/*     */     }
/*     */ 
/*     */     
/*     */     public KeyValues getLowCardinalityKeyValues(ObservationWebFilterChainDecorator.WebFilterChainObservationContext context) {
/* 651 */       return KeyValues.of("spring.security.filterchain.size", String.valueOf(context.getChainSize()))
/* 652 */         .and("spring.security.filterchain.position", String.valueOf(context.getChainPosition()))
/* 653 */         .and("spring.security.reached.filter.section", context.getFilterSection())
/* 654 */         .and("spring.security.reached.filter.name", 
/* 655 */           StringUtils.hasText(context.getFilterName()) ? context.getFilterName() : "none");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supportsContext(Observation.Context context) {
/* 660 */       return context instanceof ObservationWebFilterChainDecorator.WebFilterChainObservationContext;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PhasedObservation
/*     */     implements Observation
/*     */   {
/* 667 */     private static final PhasedObservation NOOP = new PhasedObservation(Observation.NOOP);
/*     */     
/* 669 */     private final Object lock = new Object();
/*     */     
/* 671 */     private volatile int phase = 0;
/*     */     
/*     */     private final Observation observation;
/*     */     
/*     */     private PhasedObservation(Observation observation) {
/* 676 */       this.observation = observation;
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation contextualName(String contextualName) {
/* 681 */       return this.observation.contextualName(contextualName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation parentObservation(Observation parentObservation) {
/* 686 */       return this.observation.parentObservation(parentObservation);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation lowCardinalityKeyValue(KeyValue keyValue) {
/* 691 */       return this.observation.lowCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation highCardinalityKeyValue(KeyValue keyValue) {
/* 696 */       return this.observation.highCardinalityKeyValue(keyValue);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation observationConvention(ObservationConvention<?> observationConvention) {
/* 701 */       return this.observation.observationConvention(observationConvention);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation event(Observation.Event event) {
/* 706 */       return this.observation.event(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Context getContext() {
/* 711 */       return this.observation.getContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Observation.Scope openScope() {
/* 716 */       return this.observation.openScope();
/*     */     }
/*     */ 
/*     */     
/*     */     public PhasedObservation start() {
/* 721 */       synchronized (this.lock) {
/* 722 */         if (this.phase == 0) {
/* 723 */           this.observation.start();
/* 724 */           this.phase = 1;
/*     */         } 
/*     */       } 
/* 727 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public PhasedObservation error(Throwable ex) {
/* 732 */       synchronized (this.lock) {
/* 733 */         if (this.phase == 1) {
/* 734 */           this.observation.error(ex);
/*     */         }
/*     */       } 
/* 737 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void stop() {
/* 742 */       synchronized (this.lock) {
/* 743 */         if (this.phase == 1) {
/* 744 */           this.observation.stop();
/* 745 */           this.phase = 2;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void close() {
/* 751 */       synchronized (this.lock) {
/* 752 */         if (this.phase == 1) {
/* 753 */           this.observation.stop();
/*     */         }
/* 755 */         this.phase = 3;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ObservationWebFilterChainDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */