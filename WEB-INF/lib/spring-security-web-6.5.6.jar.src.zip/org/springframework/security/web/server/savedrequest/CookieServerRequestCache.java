/*     */ package org.springframework.security.web.server.savedrequest;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.Base64;
/*     */ import java.util.Collections;
/*     */ import java.util.function.Consumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.security.web.server.util.matcher.AndServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.MediaTypeServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.NegatedServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieServerRequestCache
/*     */   implements ServerRequestCache
/*     */ {
/*     */   private static final String REDIRECT_URI_COOKIE_NAME = "REDIRECT_URI";
/*  57 */   private static final Duration COOKIE_MAX_AGE = Duration.ofSeconds(-1L);
/*     */   
/*  59 */   private static final Log logger = LogFactory.getLog(CookieServerRequestCache.class);
/*     */   
/*  61 */   private ServerWebExchangeMatcher saveRequestMatcher = createDefaultRequestMatcher();
/*     */ 
/*     */ 
/*     */   
/*     */   private Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer = cookieBuilder -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaveRequestMatcher(ServerWebExchangeMatcher saveRequestMatcher) {
/*  73 */     Assert.notNull(saveRequestMatcher, "saveRequestMatcher cannot be null");
/*  74 */     this.saveRequestMatcher = saveRequestMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> saveRequest(ServerWebExchange exchange) {
/*  79 */     return this.saveRequestMatcher.matches(exchange)
/*  80 */       .filter(m -> m.isMatch())
/*  81 */       .map(m -> exchange.getResponse())
/*  82 */       .map(ServerHttpResponse::getCookies)
/*  83 */       .doOnNext(cookies -> {
/*     */           ResponseCookie.ResponseCookieBuilder builder = createRedirectUriCookieBuilder(exchange.getRequest());
/*     */           
/*     */           this.cookieCustomizer.accept(builder);
/*     */           ResponseCookie redirectUriCookie = builder.build();
/*     */           cookies.add("REDIRECT_URI", redirectUriCookie);
/*     */           logger.debug(LogMessage.format("Request added to Cookie: %s", redirectUriCookie));
/*  90 */         }).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<URI> getRedirectUri(ServerWebExchange exchange) {
/*  95 */     MultiValueMap<String, HttpCookie> cookieMap = exchange.getRequest().getCookies();
/*  96 */     return Mono.justOrEmpty(cookieMap.getFirst("REDIRECT_URI"))
/*  97 */       .map(HttpCookie::getValue)
/*  98 */       .map(CookieServerRequestCache::decodeCookie)
/*  99 */       .onErrorResume(IllegalArgumentException.class, ex -> Mono.empty())
/* 100 */       .map(URI::create);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ServerHttpRequest> removeMatchingRequest(ServerWebExchange exchange) {
/* 105 */     return Mono.just(exchange.getResponse())
/* 106 */       .map(ServerHttpResponse::getCookies)
/* 107 */       .doOnNext(cookies -> cookies.add("REDIRECT_URI", invalidateRedirectUriCookie(exchange.getRequest())))
/*     */       
/* 109 */       .thenReturn(exchange.getRequest());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieCustomizer(Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer) {
/* 118 */     Assert.notNull(cookieCustomizer, "cookieCustomizer cannot be null");
/* 119 */     this.cookieCustomizer = cookieCustomizer;
/*     */   }
/*     */   
/*     */   private static ResponseCookie.ResponseCookieBuilder createRedirectUriCookieBuilder(ServerHttpRequest request) {
/* 123 */     String path = request.getPath().pathWithinApplication().value();
/* 124 */     String query = request.getURI().getRawQuery();
/* 125 */     String redirectUri = path + path;
/* 126 */     return createResponseCookieBuilder(request, encodeCookie(redirectUri), COOKIE_MAX_AGE);
/*     */   }
/*     */   
/*     */   private static ResponseCookie invalidateRedirectUriCookie(ServerHttpRequest request) {
/* 130 */     return createResponseCookieBuilder(request, null, Duration.ZERO).build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static ResponseCookie.ResponseCookieBuilder createResponseCookieBuilder(ServerHttpRequest request, String cookieValue, Duration age) {
/* 135 */     return ResponseCookie.from("REDIRECT_URI", cookieValue)
/* 136 */       .path(request.getPath().contextPath().value() + "/")
/* 137 */       .maxAge(age)
/* 138 */       .httpOnly(true)
/* 139 */       .secure("https".equalsIgnoreCase(request.getURI().getScheme()))
/* 140 */       .sameSite("Lax");
/*     */   }
/*     */   
/*     */   private static String encodeCookie(String cookieValue) {
/* 144 */     return new String(Base64.getEncoder().encode(cookieValue.getBytes()));
/*     */   }
/*     */   
/*     */   private static String decodeCookie(String encodedCookieValue) {
/* 148 */     return new String(Base64.getDecoder().decode(encodedCookieValue.getBytes()));
/*     */   }
/*     */   
/*     */   private static ServerWebExchangeMatcher createDefaultRequestMatcher() {
/* 152 */     ServerWebExchangeMatcher get = ServerWebExchangeMatchers.pathMatchers(HttpMethod.GET, new String[] { "/**" });
/*     */     
/* 154 */     NegatedServerWebExchangeMatcher negatedServerWebExchangeMatcher = new NegatedServerWebExchangeMatcher(ServerWebExchangeMatchers.pathMatchers(new String[] { "/favicon.*" }));
/* 155 */     MediaTypeServerWebExchangeMatcher html = new MediaTypeServerWebExchangeMatcher(new MediaType[] { MediaType.TEXT_HTML });
/* 156 */     html.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 157 */     return (ServerWebExchangeMatcher)new AndServerWebExchangeMatcher(new ServerWebExchangeMatcher[] { get, (ServerWebExchangeMatcher)negatedServerWebExchangeMatcher, (ServerWebExchangeMatcher)html });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\savedrequest\CookieServerRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */