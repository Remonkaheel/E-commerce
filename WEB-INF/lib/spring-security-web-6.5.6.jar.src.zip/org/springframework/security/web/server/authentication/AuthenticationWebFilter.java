/*     */ package org.springframework.security.web.server.authentication;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManagerResolver;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextImpl;
/*     */ import org.springframework.security.web.server.WebFilterExchange;
/*     */ import org.springframework.security.web.server.context.NoOpServerSecurityContextRepository;
/*     */ import org.springframework.security.web.server.context.ServerSecurityContextRepository;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*     */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebFilter;
/*     */ import org.springframework.web.server.WebFilterChain;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationWebFilter
/*     */   implements WebFilter
/*     */ {
/*  73 */   private static final Log logger = LogFactory.getLog(AuthenticationWebFilter.class);
/*     */   
/*     */   private final ReactiveAuthenticationManagerResolver<ServerWebExchange> authenticationManagerResolver;
/*     */   
/*  77 */   private ServerAuthenticationSuccessHandler authenticationSuccessHandler = new WebFilterChainServerAuthenticationSuccessHandler();
/*     */   
/*  79 */   private ServerAuthenticationConverter authenticationConverter = new ServerHttpBasicAuthenticationConverter();
/*     */   
/*  81 */   private ServerAuthenticationFailureHandler authenticationFailureHandler = new ServerAuthenticationEntryPointFailureHandler(new HttpBasicServerAuthenticationEntryPoint());
/*     */ 
/*     */ 
/*     */   
/*  85 */   private ServerSecurityContextRepository securityContextRepository = (ServerSecurityContextRepository)NoOpServerSecurityContextRepository.getInstance();
/*     */   
/*  87 */   private ServerWebExchangeMatcher requiresAuthenticationMatcher = ServerWebExchangeMatchers.anyExchange();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationWebFilter(ReactiveAuthenticationManager authenticationManager) {
/*  94 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/*  95 */     this.authenticationManagerResolver = (request -> Mono.just(authenticationManager));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationWebFilter(ReactiveAuthenticationManagerResolver<ServerWebExchange> authenticationManagerResolver) {
/* 105 */     Assert.notNull(authenticationManagerResolver, "authenticationResolverManager cannot be null");
/* 106 */     this.authenticationManagerResolver = authenticationManagerResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 111 */     return this.requiresAuthenticationMatcher.matches(exchange)
/* 112 */       .filter(matchResult -> matchResult.isMatch())
/* 113 */       .flatMap(matchResult -> this.authenticationConverter.convert(exchange))
/* 114 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/* 115 */       .flatMap(token -> authenticate(exchange, chain, token))
/* 116 */       .onErrorResume(AuthenticationException.class, ex -> this.authenticationFailureHandler.onAuthenticationFailure(new WebFilterExchange(exchange, chain), ex));
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> authenticate(ServerWebExchange exchange, WebFilterChain chain, Authentication token) {
/* 121 */     return this.authenticationManagerResolver.resolve(exchange)
/* 122 */       .flatMap(authenticationManager -> authenticationManager.authenticate(token))
/* 123 */       .switchIfEmpty(
/* 124 */         Mono.defer(() -> Mono.error(new IllegalStateException("No provider found for " + String.valueOf(token.getClass())))))
/* 125 */       .flatMap(authentication -> onAuthenticationSuccess(authentication, new WebFilterExchange(exchange, chain)))
/*     */       
/* 127 */       .doOnError(AuthenticationException.class, ex -> logger.debug(LogMessage.format("Authentication failed: %s", ex.getMessage()), (Throwable)ex));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Mono<Void> onAuthenticationSuccess(Authentication authentication, WebFilterExchange webFilterExchange) {
/* 132 */     ServerWebExchange exchange = webFilterExchange.getExchange();
/* 133 */     SecurityContextImpl securityContext = new SecurityContextImpl();
/* 134 */     securityContext.setAuthentication(authentication);
/* 135 */     return this.securityContextRepository.save(exchange, (SecurityContext)securityContext)
/* 136 */       .then(this.authenticationSuccessHandler.onAuthenticationSuccess(webFilterExchange, authentication))
/* 137 */       .contextWrite((ContextView)ReactiveSecurityContextHolder.withSecurityContext(Mono.just(securityContext)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(ServerSecurityContextRepository securityContextRepository) {
/* 146 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 147 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationSuccessHandler(ServerAuthenticationSuccessHandler authenticationSuccessHandler) {
/* 156 */     Assert.notNull(authenticationSuccessHandler, "authenticationSuccessHandler cannot be null");
/* 157 */     this.authenticationSuccessHandler = authenticationSuccessHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setAuthenticationConverter(Function<ServerWebExchange, Mono<Authentication>> authenticationConverter) {
/* 173 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 174 */     Objects.requireNonNull(authenticationConverter); setServerAuthenticationConverter(authenticationConverter::apply);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerAuthenticationConverter(ServerAuthenticationConverter authenticationConverter) {
/* 187 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 188 */     this.authenticationConverter = authenticationConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationFailureHandler(ServerAuthenticationFailureHandler authenticationFailureHandler) {
/* 197 */     Assert.notNull(authenticationFailureHandler, "authenticationFailureHandler cannot be null");
/* 198 */     this.authenticationFailureHandler = authenticationFailureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequiresAuthenticationMatcher(ServerWebExchangeMatcher requiresAuthenticationMatcher) {
/* 209 */     Assert.notNull(requiresAuthenticationMatcher, "requiresAuthenticationMatcher cannot be null");
/* 210 */     this.requiresAuthenticationMatcher = requiresAuthenticationMatcher;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\authentication\AuthenticationWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */