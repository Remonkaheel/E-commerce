/*    */ package org.springframework.security.web.server.context;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.ServerWebExchangeDecorator;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextServerWebExchange
/*    */   extends ServerWebExchangeDecorator
/*    */ {
/*    */   private final Mono<SecurityContext> context;
/*    */   
/*    */   public SecurityContextServerWebExchange(ServerWebExchange delegate, Mono<SecurityContext> context) {
/* 40 */     super(delegate);
/* 41 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends Principal> Mono<T> getPrincipal() {
/* 47 */     return this.context.map(context -> context.getAuthentication());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\context\SecurityContextServerWebExchange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */