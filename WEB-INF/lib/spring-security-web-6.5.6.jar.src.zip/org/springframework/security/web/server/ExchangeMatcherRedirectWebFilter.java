/*    */ package org.springframework.security.web.server;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.springframework.web.server.WebFilter;
/*    */ import org.springframework.web.server.WebFilterChain;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExchangeMatcherRedirectWebFilter
/*    */   implements WebFilter
/*    */ {
/* 39 */   private final ServerRedirectStrategy redirectStrategy = new DefaultServerRedirectStrategy();
/*    */ 
/*    */ 
/*    */   
/*    */   private final ServerWebExchangeMatcher exchangeMatcher;
/*    */ 
/*    */   
/*    */   private final URI redirectUri;
/*    */ 
/*    */ 
/*    */   
/*    */   public ExchangeMatcherRedirectWebFilter(ServerWebExchangeMatcher exchangeMatcher, String redirectUrl) {
/* 51 */     Assert.notNull(exchangeMatcher, "exchangeMatcher cannot be null");
/* 52 */     Assert.hasText(redirectUrl, "redirectUrl cannot be empty");
/* 53 */     this.exchangeMatcher = exchangeMatcher;
/* 54 */     this.redirectUri = URI.create(redirectUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
/* 63 */     return this.exchangeMatcher.matches(exchange)
/* 64 */       .filter(ServerWebExchangeMatcher.MatchResult::isMatch)
/* 65 */       .switchIfEmpty(chain.filter(exchange).then(Mono.empty()))
/* 66 */       .flatMap(result -> this.redirectStrategy.sendRedirect(exchange, this.redirectUri));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\server\ExchangeMatcherRedirectWebFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */