/*    */ package org.springframework.security.web.savedrequest;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.filter.GenericFilterBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestCacheAwareFilter
/*    */   extends GenericFilterBean
/*    */ {
/*    */   private RequestCache requestCache;
/*    */   
/*    */   public RequestCacheAwareFilter() {
/* 50 */     this(new HttpSessionRequestCache());
/*    */   }
/*    */   
/*    */   public RequestCacheAwareFilter(RequestCache requestCache) {
/* 54 */     Assert.notNull(requestCache, "requestCache cannot be null");
/* 55 */     this.requestCache = requestCache;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 61 */     HttpServletRequest wrappedSavedRequest = this.requestCache.getMatchingRequest((HttpServletRequest)request, (HttpServletResponse)response);
/*    */     
/* 63 */     chain.doFilter((wrappedSavedRequest != null) ? (ServletRequest)wrappedSavedRequest : request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\RequestCacheAwareFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */