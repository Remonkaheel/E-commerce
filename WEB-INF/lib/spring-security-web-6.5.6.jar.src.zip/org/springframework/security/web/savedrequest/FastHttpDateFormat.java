/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FastHttpDateFormat
/*     */ {
/*  40 */   protected static final SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   protected static final SimpleDateFormat[] formats = new SimpleDateFormat[] { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final TimeZone gmtZone = TimeZone.getTimeZone("GMT");
/*     */   
/*     */   static {
/*  56 */     format.setTimeZone(gmtZone);
/*  57 */     formats[0].setTimeZone(gmtZone);
/*  58 */     formats[1].setTimeZone(gmtZone);
/*  59 */     formats[2].setTimeZone(gmtZone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected static long currentDateGenerated = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   protected static String currentDate = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   protected static final HashMap<Long, String> formatCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   protected static final HashMap<String, Long> parseCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDate(long value, DateFormat threadLocalformat) {
/*  94 */     String newDate, cachedDate = null;
/*  95 */     Long longValue = Long.valueOf(value);
/*     */     try {
/*  97 */       cachedDate = formatCache.get(longValue);
/*     */     }
/*  99 */     catch (Exception exception) {}
/*     */     
/* 101 */     if (cachedDate != null) {
/* 102 */       return cachedDate;
/*     */     }
/*     */     
/* 105 */     Date dateValue = new Date(value);
/* 106 */     if (threadLocalformat != null) {
/* 107 */       newDate = threadLocalformat.format(dateValue);
/* 108 */       synchronized (formatCache) {
/* 109 */         updateCache(formatCache, longValue, newDate);
/*     */       } 
/*     */     } else {
/*     */       
/* 113 */       synchronized (formatCache) {
/* 114 */         newDate = format.format(dateValue);
/* 115 */         updateCache(formatCache, longValue, newDate);
/*     */       } 
/*     */     } 
/* 118 */     return newDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCurrentDate() {
/* 126 */     long now = System.currentTimeMillis();
/* 127 */     if (now - currentDateGenerated > 1000L) {
/* 128 */       synchronized (format) {
/* 129 */         if (now - currentDateGenerated > 1000L) {
/* 130 */           currentDateGenerated = now;
/* 131 */           currentDate = format.format(new Date(now));
/*     */         } 
/*     */       } 
/*     */     }
/* 135 */     return currentDate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Long internalParseDate(String value, DateFormat[] formats) {
/* 145 */     Date date = null;
/* 146 */     for (int i = 0; date == null && i < formats.length; i++) {
/*     */       try {
/* 148 */         date = formats[i].parse(value);
/*     */       }
/* 150 */       catch (ParseException parseException) {}
/*     */     } 
/*     */     
/* 153 */     if (date == null) {
/* 154 */       return null;
/*     */     }
/* 156 */     return Long.valueOf(date.getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseDate(String value, DateFormat[] threadLocalformats) {
/* 168 */     Long date, cachedDate = null;
/*     */     try {
/* 170 */       cachedDate = parseCache.get(value);
/*     */     }
/* 172 */     catch (Exception exception) {}
/*     */     
/* 174 */     if (cachedDate != null) {
/* 175 */       return cachedDate.longValue();
/*     */     }
/*     */     
/* 178 */     if (threadLocalformats != null) {
/* 179 */       date = internalParseDate(value, threadLocalformats);
/* 180 */       synchronized (parseCache) {
/* 181 */         updateCache(parseCache, value, date);
/*     */       } 
/*     */     } else {
/*     */       
/* 185 */       synchronized (parseCache) {
/* 186 */         date = internalParseDate(value, (DateFormat[])formats);
/* 187 */         updateCache(parseCache, value, date);
/*     */       } 
/*     */     } 
/* 190 */     return (date != null) ? date.longValue() : -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updateCache(HashMap<Object, Object> cache, Object key, Object value) {
/* 201 */     if (value == null) {
/*     */       return;
/*     */     }
/* 204 */     if (cache.size() > 1000) {
/* 205 */       cache.clear();
/*     */     }
/* 207 */     cache.put(key, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\FastHttpDateFormat.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */