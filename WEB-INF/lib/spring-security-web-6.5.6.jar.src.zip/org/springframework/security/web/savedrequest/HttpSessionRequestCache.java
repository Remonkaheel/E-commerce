/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.PortResolverImpl;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSessionRequestCache
/*     */   implements RequestCache
/*     */ {
/*     */   static final String SAVED_REQUEST = "SPRING_SECURITY_SAVED_REQUEST";
/*  47 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  49 */   private PortResolver portResolver = (PortResolver)new PortResolverImpl();
/*     */   
/*     */   private boolean createSessionAllowed = true;
/*     */   
/*  53 */   private RequestMatcher requestMatcher = AnyRequestMatcher.INSTANCE;
/*     */   
/*  55 */   private String sessionAttrName = "SPRING_SECURITY_SAVED_REQUEST";
/*     */   
/*  57 */   private String matchingRequestParameterName = "continue";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveRequest(HttpServletRequest request, HttpServletResponse response) {
/*  64 */     if (!this.requestMatcher.matches(request)) {
/*  65 */       if (this.logger.isTraceEnabled()) {
/*  66 */         this.logger
/*  67 */           .trace(LogMessage.format("Did not save request since it did not match [%s]", this.requestMatcher));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  72 */     if (this.createSessionAllowed || request.getSession(false) != null) {
/*     */ 
/*     */ 
/*     */       
/*  76 */       DefaultSavedRequest savedRequest = new DefaultSavedRequest(request, this.portResolver, this.matchingRequestParameterName);
/*     */       
/*  78 */       request.getSession().setAttribute(this.sessionAttrName, savedRequest);
/*  79 */       if (this.logger.isDebugEnabled()) {
/*  80 */         this.logger.debug(LogMessage.format("Saved request %s to session", savedRequest.getRedirectUrl()));
/*     */       }
/*     */     } else {
/*     */       
/*  84 */       this.logger.trace("Did not save request since there's no session and createSessionAllowed is false");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public SavedRequest getRequest(HttpServletRequest currentRequest, HttpServletResponse response) {
/*  90 */     HttpSession session = currentRequest.getSession(false);
/*  91 */     return (session != null) ? (SavedRequest)session.getAttribute(this.sessionAttrName) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeRequest(HttpServletRequest currentRequest, HttpServletResponse response) {
/*  96 */     HttpSession session = currentRequest.getSession(false);
/*  97 */     if (session != null) {
/*  98 */       this.logger.trace("Removing DefaultSavedRequest from session if present");
/*  99 */       session.removeAttribute(this.sessionAttrName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest getMatchingRequest(HttpServletRequest request, HttpServletResponse response) {
/* 105 */     if (this.matchingRequestParameterName != null && (
/* 106 */       !StringUtils.hasText(request.getQueryString()) || 
/*     */ 
/*     */ 
/*     */       
/* 110 */       !UriComponentsBuilder.fromUriString(UrlUtils.buildRequestUrl(request)).build().getQueryParams().containsKey(this.matchingRequestParameterName))) {
/* 111 */       this.logger.trace("matchingRequestParameterName is required for getMatchingRequest to lookup a value, but not provided");
/*     */       
/* 113 */       return null;
/*     */     } 
/*     */     
/* 116 */     SavedRequest saved = getRequest(request, response);
/* 117 */     if (saved == null) {
/* 118 */       this.logger.trace("No saved request");
/* 119 */       return null;
/*     */     } 
/* 121 */     if (!matchesSavedRequest(request, saved)) {
/* 122 */       if (this.logger.isTraceEnabled()) {
/* 123 */         this.logger.trace(LogMessage.format("Did not match request %s to the saved one %s", 
/* 124 */               UrlUtils.buildRequestUrl(request), saved));
/*     */       }
/* 126 */       return null;
/*     */     } 
/* 128 */     removeRequest(request, response);
/* 129 */     if (this.logger.isDebugEnabled()) {
/* 130 */       this.logger.debug(LogMessage.format("Loaded matching saved request %s", saved.getRedirectUrl()));
/*     */     }
/* 132 */     return (HttpServletRequest)new SavedRequestAwareWrapper(saved, request);
/*     */   }
/*     */   
/*     */   private boolean matchesSavedRequest(HttpServletRequest request, SavedRequest savedRequest) {
/* 136 */     if (savedRequest instanceof DefaultSavedRequest) {
/* 137 */       DefaultSavedRequest defaultSavedRequest = (DefaultSavedRequest)savedRequest;
/* 138 */       return defaultSavedRequest.doesRequestMatch(request, this.portResolver);
/*     */     } 
/* 140 */     String currentUrl = UrlUtils.buildFullRequestUrl(request);
/* 141 */     return savedRequest.getRedirectUrl().equals(currentUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/* 153 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCreateSessionAllowed(boolean createSessionAllowed) {
/* 164 */     this.createSessionAllowed = createSessionAllowed;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public void setPortResolver(PortResolver portResolver) {
/* 169 */     this.portResolver = portResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAttrName(String sessionAttrName) {
/* 179 */     this.sessionAttrName = sessionAttrName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchingRequestParameterName(String matchingRequestParameterName) {
/* 191 */     this.matchingRequestParameterName = matchingRequestParameterName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\HttpSessionRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */