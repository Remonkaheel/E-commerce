/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleSavedRequest
/*     */   implements SavedRequest
/*     */ {
/*     */   private static final long serialVersionUID = 807650604272166969L;
/*     */   private String redirectUrl;
/*  44 */   private List<Cookie> cookies = new ArrayList<>();
/*     */   
/*  46 */   private String method = "GET";
/*     */   
/*  48 */   private Map<String, List<String>> headers = new HashMap<>();
/*     */   
/*  50 */   private List<Locale> locales = new ArrayList<>();
/*     */   
/*  52 */   private Map<String, String[]> parameters = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   public SimpleSavedRequest() {}
/*     */   
/*     */   public SimpleSavedRequest(String redirectUrl) {
/*  58 */     this.redirectUrl = redirectUrl;
/*     */   }
/*     */   
/*     */   public SimpleSavedRequest(SavedRequest request) {
/*  62 */     this.redirectUrl = request.getRedirectUrl();
/*  63 */     this.cookies = request.getCookies();
/*  64 */     for (String headerName : request.getHeaderNames()) {
/*  65 */       this.headers.put(headerName, request.getHeaderValues(headerName));
/*     */     }
/*  67 */     this.locales = request.getLocales();
/*  68 */     this.parameters = request.getParameterMap();
/*  69 */     this.method = request.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRedirectUrl() {
/*  74 */     return this.redirectUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Cookie> getCookies() {
/*  79 */     return this.cookies;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethod() {
/*  84 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getHeaderValues(String name) {
/*  89 */     return this.headers.getOrDefault(name, new ArrayList<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getHeaderNames() {
/*  94 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Locale> getLocales() {
/*  99 */     return this.locales;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 104 */     return this.parameters.getOrDefault(name, new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getParameterMap() {
/* 109 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void setRedirectUrl(String redirectUrl) {
/* 113 */     Assert.notNull(redirectUrl, "redirectUrl cannot be null");
/* 114 */     this.redirectUrl = redirectUrl;
/*     */   }
/*     */   
/*     */   public void setCookies(List<Cookie> cookies) {
/* 118 */     Assert.notNull(cookies, "cookies cannot be null");
/* 119 */     this.cookies = cookies;
/*     */   }
/*     */   
/*     */   public void setMethod(String method) {
/* 123 */     Assert.notNull(method, "method cannot be null");
/* 124 */     this.method = method;
/*     */   }
/*     */   
/*     */   public void setHeaders(Map<String, List<String>> headers) {
/* 128 */     Assert.notNull(headers, "headers cannot be null");
/* 129 */     this.headers = headers;
/*     */   }
/*     */   
/*     */   public void setLocales(List<Locale> locales) {
/* 133 */     Assert.notNull(locales, "locales cannot be null");
/* 134 */     this.locales = locales;
/*     */   }
/*     */   
/*     */   public void setParameters(Map<String, String[]> parameters) {
/* 138 */     Assert.notNull(parameters, "parameters cannot be null");
/* 139 */     this.parameters = parameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\SimpleSavedRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */