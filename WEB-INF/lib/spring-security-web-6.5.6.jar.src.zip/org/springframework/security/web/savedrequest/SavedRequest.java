package org.springframework.security.web.savedrequest;

import jakarta.servlet.http.Cookie;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public interface SavedRequest extends Serializable {
  String getRedirectUrl();
  
  List<Cookie> getCookies();
  
  String getMethod();
  
  List<String> getHeaderValues(String paramString);
  
  Collection<String> getHeaderNames();
  
  List<Locale> getLocales();
  
  String[] getParameterValues(String paramString);
  
  Map<String, String[]> getParameterMap();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\SavedRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */