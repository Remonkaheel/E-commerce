/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSavedRequest
/*     */   implements SavedRequest
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*  67 */   protected static final Log logger = LogFactory.getLog(DefaultSavedRequest.class);
/*     */   
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   
/*  73 */   private final ArrayList<SavedCookie> cookies = new ArrayList<>();
/*     */   
/*  75 */   private final ArrayList<Locale> locales = new ArrayList<>();
/*     */   
/*  77 */   private final Map<String, List<String>> headers = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */   
/*  79 */   private final Map<String, String[]> parameters = (Map)new TreeMap<>();
/*     */   
/*     */   private final String contextPath;
/*     */   
/*     */   private final String method;
/*     */   
/*     */   private final String pathInfo;
/*     */   
/*     */   private final String queryString;
/*     */   
/*     */   private final String requestURI;
/*     */   
/*     */   private final String requestURL;
/*     */   
/*     */   private final String scheme;
/*     */   
/*     */   private final String serverName;
/*     */   
/*     */   private final String servletPath;
/*     */   
/*     */   private final int serverPort;
/*     */   
/*     */   private final String matchingRequestParameterName;
/*     */   
/*     */   public DefaultSavedRequest(HttpServletRequest request) {
/* 104 */     this(request, (String)null);
/*     */   }
/*     */   
/*     */   public DefaultSavedRequest(HttpServletRequest request, String matchingRequestParameterName) {
/* 108 */     this(request, PortResolver.NO_OP, matchingRequestParameterName);
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public DefaultSavedRequest(HttpServletRequest request, PortResolver portResolver) {
/* 113 */     this(request, portResolver, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public DefaultSavedRequest(HttpServletRequest request, PortResolver portResolver, String matchingRequestParameterName) {
/* 120 */     Assert.notNull(request, "Request required");
/* 121 */     Assert.notNull(portResolver, "PortResolver required");
/*     */     
/* 123 */     addCookies(request.getCookies());
/*     */     
/* 125 */     Enumeration<String> names = request.getHeaderNames();
/* 126 */     while (names.hasMoreElements()) {
/* 127 */       String name = names.nextElement();
/*     */       
/* 129 */       if ("If-Modified-Since".equalsIgnoreCase(name) || "If-None-Match".equalsIgnoreCase(name)) {
/*     */         continue;
/*     */       }
/* 132 */       Enumeration<String> values = request.getHeaders(name);
/* 133 */       while (values.hasMoreElements()) {
/* 134 */         addHeader(name, values.nextElement());
/*     */       }
/*     */     } 
/*     */     
/* 138 */     addLocales(request.getLocales());
/*     */     
/* 140 */     addParameters(request.getParameterMap());
/*     */     
/* 142 */     this.method = request.getMethod();
/* 143 */     this.pathInfo = request.getPathInfo();
/* 144 */     this.queryString = request.getQueryString();
/* 145 */     this.requestURI = request.getRequestURI();
/* 146 */     this.serverPort = portResolver.getServerPort((ServletRequest)request);
/* 147 */     this.requestURL = request.getRequestURL().toString();
/* 148 */     this.scheme = request.getScheme();
/* 149 */     this.serverName = request.getServerName();
/* 150 */     this.contextPath = request.getContextPath();
/* 151 */     this.servletPath = request.getServletPath();
/* 152 */     this.matchingRequestParameterName = matchingRequestParameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultSavedRequest(Builder builder) {
/* 159 */     this.contextPath = builder.contextPath;
/* 160 */     this.method = builder.method;
/* 161 */     this.pathInfo = builder.pathInfo;
/* 162 */     this.queryString = builder.queryString;
/* 163 */     this.requestURI = builder.requestURI;
/* 164 */     this.requestURL = builder.requestURL;
/* 165 */     this.scheme = builder.scheme;
/* 166 */     this.serverName = builder.serverName;
/* 167 */     this.servletPath = builder.servletPath;
/* 168 */     this.serverPort = builder.serverPort;
/* 169 */     this.matchingRequestParameterName = builder.matchingRequestParameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addCookies(Cookie[] cookies) {
/* 176 */     if (cookies != null) {
/* 177 */       for (Cookie cookie : cookies) {
/* 178 */         addCookie(cookie);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addCookie(Cookie cookie) {
/* 184 */     this.cookies.add(new SavedCookie(cookie));
/*     */   }
/*     */   
/*     */   private void addHeader(String name, String value) {
/* 188 */     List<String> values = this.headers.computeIfAbsent(name, key -> new ArrayList());
/* 189 */     values.add(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addLocales(Enumeration<Locale> locales) {
/* 196 */     while (locales.hasMoreElements()) {
/* 197 */       Locale locale = locales.nextElement();
/* 198 */       addLocale(locale);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addLocale(Locale locale) {
/* 203 */     this.locales.add(locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addParameters(Map<String, String[]> parameters) {
/* 210 */     if (!ObjectUtils.isEmpty(parameters)) {
/* 211 */       for (String paramName : parameters.keySet()) {
/* 212 */         Object paramValues = parameters.get(paramName);
/* 213 */         if (paramValues instanceof String[]) {
/* 214 */           addParameter(paramName, (String[])paramValues);
/*     */           continue;
/*     */         } 
/* 217 */         logger.warn("ServletRequest.getParameterMap() returned non-String array");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addParameter(String name, String[] values) {
/* 224 */     this.parameters.put(name, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public boolean doesRequestMatch(HttpServletRequest request, PortResolver portResolver) {
/* 239 */     if (!propertyEquals(this.pathInfo, request.getPathInfo())) {
/* 240 */       return false;
/*     */     }
/* 242 */     if (!propertyEquals(createQueryString(this.queryString, this.matchingRequestParameterName), request
/* 243 */         .getQueryString())) {
/* 244 */       return false;
/*     */     }
/* 246 */     if (!propertyEquals(this.requestURI, request.getRequestURI())) {
/* 247 */       return false;
/*     */     }
/* 249 */     if (!"GET".equals(request.getMethod()) && "GET".equals(this.method))
/*     */     {
/* 251 */       return false;
/*     */     }
/* 253 */     if (!propertyEquals(Integer.valueOf(this.serverPort), Integer.valueOf(portResolver.getServerPort((ServletRequest)request)))) {
/* 254 */       return false;
/*     */     }
/* 256 */     if (!propertyEquals(this.requestURL, request.getRequestURL().toString())) {
/* 257 */       return false;
/*     */     }
/* 259 */     if (!propertyEquals(this.scheme, request.getScheme())) {
/* 260 */       return false;
/*     */     }
/* 262 */     if (!propertyEquals(this.serverName, request.getServerName())) {
/* 263 */       return false;
/*     */     }
/* 265 */     if (!propertyEquals(this.contextPath, request.getContextPath())) {
/* 266 */       return false;
/*     */     }
/* 268 */     return propertyEquals(this.servletPath, request.getServletPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/* 273 */     return this.contextPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Cookie> getCookies() {
/* 278 */     List<Cookie> cookieList = new ArrayList<>(this.cookies.size());
/* 279 */     for (SavedCookie savedCookie : this.cookies) {
/* 280 */       cookieList.add(savedCookie.getCookie());
/*     */     }
/* 282 */     return cookieList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRedirectUrl() {
/* 291 */     String queryString = createQueryString(this.queryString, this.matchingRequestParameterName);
/* 292 */     return UrlUtils.buildFullRequestUrl(this.scheme, this.serverName, this.serverPort, this.requestURI, queryString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getHeaderNames() {
/* 298 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getHeaderValues(String name) {
/* 303 */     List<String> values = this.headers.get(name);
/* 304 */     return (values != null) ? values : Collections.<String>emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Locale> getLocales() {
/* 309 */     return this.locales;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethod() {
/* 314 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getParameterMap() {
/* 319 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public Collection<String> getParameterNames() {
/* 323 */     return this.parameters.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 328 */     return this.parameters.get(name);
/*     */   }
/*     */   
/*     */   public String getPathInfo() {
/* 332 */     return this.pathInfo;
/*     */   }
/*     */   
/*     */   public String getQueryString() {
/* 336 */     return this.queryString;
/*     */   }
/*     */   
/*     */   public String getRequestURI() {
/* 340 */     return this.requestURI;
/*     */   }
/*     */   
/*     */   public String getRequestURL() {
/* 344 */     return this.requestURL;
/*     */   }
/*     */   
/*     */   public String getScheme() {
/* 348 */     return this.scheme;
/*     */   }
/*     */   
/*     */   public String getServerName() {
/* 352 */     return this.serverName;
/*     */   }
/*     */   
/*     */   public int getServerPort() {
/* 356 */     return this.serverPort;
/*     */   }
/*     */   
/*     */   public String getServletPath() {
/* 360 */     return this.servletPath;
/*     */   }
/*     */   
/*     */   private boolean propertyEquals(Object arg1, Object arg2) {
/* 364 */     if (arg1 == null && arg2 == null) {
/* 365 */       return true;
/*     */     }
/* 367 */     if (arg1 == null || arg2 == null) {
/* 368 */       return false;
/*     */     }
/* 370 */     return arg1.equals(arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 375 */     return "DefaultSavedRequest [" + getRedirectUrl() + "]";
/*     */   }
/*     */   
/*     */   private static String createQueryString(String queryString, String matchingRequestParameterName) {
/* 379 */     if (matchingRequestParameterName == null) {
/* 380 */       return queryString;
/*     */     }
/* 382 */     if (queryString == null || queryString.length() == 0) {
/* 383 */       return matchingRequestParameterName;
/*     */     }
/* 385 */     return UriComponentsBuilder.newInstance()
/* 386 */       .query(queryString)
/* 387 */       .replaceQueryParam(matchingRequestParameterName, new Object[0])
/* 388 */       .queryParam(matchingRequestParameterName, new Object[0])
/* 389 */       .build()
/* 390 */       .getQuery();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonIgnoreProperties(ignoreUnknown = true)
/*     */   @JsonPOJOBuilder(withPrefix = "set")
/*     */   public static class Builder
/*     */   {
/* 400 */     private List<SavedCookie> cookies = null;
/*     */     
/* 402 */     private List<Locale> locales = null;
/*     */     
/* 404 */     private Map<String, List<String>> headers = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */     
/* 406 */     private Map<String, String[]> parameters = (Map)new TreeMap<>();
/*     */     
/*     */     private String contextPath;
/*     */     
/*     */     private String method;
/*     */     
/*     */     private String pathInfo;
/*     */     
/*     */     private String queryString;
/*     */     
/*     */     private String requestURI;
/*     */     
/*     */     private String requestURL;
/*     */     
/*     */     private String scheme;
/*     */     
/*     */     private String serverName;
/*     */     
/*     */     private String servletPath;
/*     */     
/* 426 */     private int serverPort = 80;
/*     */     
/*     */     private String matchingRequestParameterName;
/*     */     
/*     */     public Builder setCookies(List<SavedCookie> cookies) {
/* 431 */       this.cookies = cookies;
/* 432 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setLocales(List<Locale> locales) {
/* 436 */       this.locales = locales;
/* 437 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setHeaders(Map<String, List<String>> header) {
/* 441 */       this.headers.putAll(header);
/* 442 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setParameters(Map<String, String[]> parameters) {
/* 446 */       this.parameters = parameters;
/* 447 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setContextPath(String contextPath) {
/* 451 */       this.contextPath = contextPath;
/* 452 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setMethod(String method) {
/* 456 */       this.method = method;
/* 457 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setPathInfo(String pathInfo) {
/* 461 */       this.pathInfo = pathInfo;
/* 462 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setQueryString(String queryString) {
/* 466 */       this.queryString = queryString;
/* 467 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setRequestURI(String requestURI) {
/* 471 */       this.requestURI = requestURI;
/* 472 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setRequestURL(String requestURL) {
/* 476 */       this.requestURL = requestURL;
/* 477 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setScheme(String scheme) {
/* 481 */       this.scheme = scheme;
/* 482 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setServerName(String serverName) {
/* 486 */       this.serverName = serverName;
/* 487 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setServletPath(String servletPath) {
/* 491 */       this.servletPath = servletPath;
/* 492 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setServerPort(int serverPort) {
/* 496 */       this.serverPort = serverPort;
/* 497 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setMatchingRequestParameterName(String matchingRequestParameterName) {
/* 501 */       this.matchingRequestParameterName = matchingRequestParameterName;
/* 502 */       return this;
/*     */     }
/*     */     
/*     */     public DefaultSavedRequest build() {
/* 506 */       DefaultSavedRequest savedRequest = new DefaultSavedRequest(this);
/* 507 */       if (!ObjectUtils.isEmpty(this.cookies)) {
/* 508 */         for (SavedCookie cookie : this.cookies) {
/* 509 */           savedRequest.addCookie(cookie.getCookie());
/*     */         }
/*     */       }
/* 512 */       if (!ObjectUtils.isEmpty(this.locales)) {
/* 513 */         savedRequest.locales.addAll(this.locales);
/*     */       }
/* 515 */       savedRequest.addParameters(this.parameters);
/* 516 */       this.headers.remove("If-Modified-Since");
/* 517 */       this.headers.remove("If-None-Match");
/* 518 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/* 519 */         String headerName = entry.getKey();
/* 520 */         List<String> headerValues = entry.getValue();
/* 521 */         for (String headerValue : headerValues) {
/* 522 */           savedRequest.addHeader(headerName, headerValue);
/*     */         }
/*     */       } 
/* 525 */       return savedRequest;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\DefaultSavedRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */