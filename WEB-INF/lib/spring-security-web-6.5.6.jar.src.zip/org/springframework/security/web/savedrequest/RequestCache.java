package org.springframework.security.web.savedrequest;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface RequestCache {
  void saveRequest(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  SavedRequest getRequest(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  HttpServletRequest getMatchingRequest(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  void removeRequest(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\RequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */