/*    */ package org.springframework.security.web.savedrequest;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullRequestCache
/*    */   implements RequestCache
/*    */ {
/*    */   public SavedRequest getRequest(HttpServletRequest request, HttpServletResponse response) {
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeRequest(HttpServletRequest request, HttpServletResponse response) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void saveRequest(HttpServletRequest request, HttpServletResponse response) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpServletRequest getMatchingRequest(HttpServletRequest request, HttpServletResponse response) {
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\NullRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */