/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SavedRequestAwareWrapper
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*  58 */   protected static final Log logger = LogFactory.getLog(SavedRequestAwareWrapper.class);
/*     */   
/*  60 */   protected static final TimeZone GMT_ZONE = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SavedRequest savedRequest;
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected final SimpleDateFormat[] formats = new SimpleDateFormat[3];
/*     */   
/*     */   SavedRequestAwareWrapper(SavedRequest saved, HttpServletRequest request) {
/*  72 */     super(request);
/*  73 */     this.savedRequest = saved;
/*  74 */     this.formats[0] = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
/*  75 */     this.formats[1] = new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US);
/*  76 */     this.formats[2] = new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US);
/*  77 */     this.formats[0].setTimeZone(GMT_ZONE);
/*  78 */     this.formats[1].setTimeZone(GMT_ZONE);
/*  79 */     this.formats[2].setTimeZone(GMT_ZONE);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getDateHeader(String name) {
/*  84 */     String value = getHeader(name);
/*  85 */     if (value == null) {
/*  86 */       return -1L;
/*     */     }
/*     */     
/*  89 */     long result = FastHttpDateFormat.parseDate(value, (DateFormat[])this.formats);
/*  90 */     if (result != -1L) {
/*  91 */       return result;
/*     */     }
/*  93 */     throw new IllegalArgumentException(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeader(String name) {
/*  98 */     List<String> values = this.savedRequest.getHeaderValues(name);
/*  99 */     return values.isEmpty() ? null : values.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaderNames() {
/* 104 */     return new Enumerator<>(this.savedRequest.getHeaderNames());
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaders(String name) {
/* 109 */     return new Enumerator<>(this.savedRequest.getHeaderValues(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntHeader(String name) {
/* 114 */     String value = getHeader(name);
/* 115 */     return (value != null) ? Integer.parseInt(value) : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 120 */     List<Locale> locales = this.savedRequest.getLocales();
/* 121 */     return locales.isEmpty() ? Locale.getDefault() : locales.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<Locale> getLocales() {
/* 126 */     List<Locale> locales = this.savedRequest.getLocales();
/* 127 */     if (locales.isEmpty()) {
/*     */       
/* 129 */       locales = new ArrayList<>(1);
/* 130 */       locales.add(Locale.getDefault());
/*     */     } 
/* 132 */     return new Enumerator<>(locales);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethod() {
/* 137 */     return this.savedRequest.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 142 */     return getHeader("Content-Type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 157 */     String value = super.getParameter(name);
/* 158 */     if (value != null) {
/* 159 */       return value;
/*     */     }
/* 161 */     String[] values = this.savedRequest.getParameterValues(name);
/* 162 */     if (values == null || values.length == 0) {
/* 163 */       return null;
/*     */     }
/* 165 */     return values[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getParameterMap() {
/* 170 */     Set<String> names = getCombinedParameterNames();
/* 171 */     Map<String, String[]> parameterMap = (Map)new HashMap<>(names.size());
/* 172 */     for (String name : names) {
/* 173 */       parameterMap.put(name, getParameterValues(name));
/*     */     }
/* 175 */     return parameterMap;
/*     */   }
/*     */   
/*     */   private Set<String> getCombinedParameterNames() {
/* 179 */     Set<String> names = new HashSet<>();
/* 180 */     names.addAll(super.getParameterMap().keySet());
/* 181 */     names.addAll(this.savedRequest.getParameterMap().keySet());
/* 182 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getParameterNames() {
/* 187 */     return new Enumerator<>(getCombinedParameterNames());
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 192 */     String[] savedRequestParams = this.savedRequest.getParameterValues(name);
/* 193 */     String[] wrappedRequestParams = super.getParameterValues(name);
/* 194 */     if (savedRequestParams == null) {
/* 195 */       return wrappedRequestParams;
/*     */     }
/* 197 */     if (wrappedRequestParams == null) {
/* 198 */       return savedRequestParams;
/*     */     }
/*     */     
/* 201 */     List<String> wrappedParamsList = Arrays.asList(wrappedRequestParams);
/* 202 */     List<String> combinedParams = new ArrayList<>(wrappedParamsList);
/*     */ 
/*     */     
/* 205 */     for (String savedRequestParam : savedRequestParams) {
/* 206 */       if (!wrappedParamsList.contains(savedRequestParam)) {
/* 207 */         combinedParams.add(savedRequestParam);
/*     */       }
/*     */     } 
/* 210 */     return combinedParams.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\SavedRequestAwareWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */