/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Enumerator<T>
/*     */   implements Enumeration<T>
/*     */ {
/*  48 */   private Iterator<T> iterator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Collection<T> collection) {
/*  55 */     this(collection.iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Collection<T> collection, boolean clone) {
/*  64 */     this(collection.iterator(), clone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Iterator<T> iterator) {
/*  72 */     this.iterator = iterator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Iterator<T> iterator, boolean clone) {
/*  81 */     if (!clone) {
/*  82 */       this.iterator = iterator;
/*     */     } else {
/*     */       
/*  85 */       List<T> list = new ArrayList<>();
/*  86 */       while (iterator.hasNext()) {
/*  87 */         list.add(iterator.next());
/*     */       }
/*  89 */       this.iterator = list.iterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Map<?, T> map) {
/*  98 */     this(map.values().iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumerator(Map<?, T> map, boolean clone) {
/* 107 */     this(map.values().iterator(), clone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMoreElements() {
/* 117 */     return this.iterator.hasNext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T nextElement() throws NoSuchElementException {
/* 128 */     return this.iterator.next();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\Enumerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */