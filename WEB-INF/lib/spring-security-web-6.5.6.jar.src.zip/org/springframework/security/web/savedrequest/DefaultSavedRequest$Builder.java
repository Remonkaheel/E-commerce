/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JsonIgnoreProperties(ignoreUnknown = true)
/*     */ @JsonPOJOBuilder(withPrefix = "set")
/*     */ public class Builder
/*     */ {
/* 400 */   private List<SavedCookie> cookies = null;
/*     */   
/* 402 */   private List<Locale> locales = null;
/*     */   
/* 404 */   private Map<String, List<String>> headers = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */   
/* 406 */   private Map<String, String[]> parameters = (Map)new TreeMap<>();
/*     */   
/*     */   private String contextPath;
/*     */   
/*     */   private String method;
/*     */   
/*     */   private String pathInfo;
/*     */   
/*     */   private String queryString;
/*     */   
/*     */   private String requestURI;
/*     */   
/*     */   private String requestURL;
/*     */   
/*     */   private String scheme;
/*     */   
/*     */   private String serverName;
/*     */   
/*     */   private String servletPath;
/*     */   
/* 426 */   private int serverPort = 80;
/*     */   
/*     */   private String matchingRequestParameterName;
/*     */   
/*     */   public Builder setCookies(List<SavedCookie> cookies) {
/* 431 */     this.cookies = cookies;
/* 432 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setLocales(List<Locale> locales) {
/* 436 */     this.locales = locales;
/* 437 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setHeaders(Map<String, List<String>> header) {
/* 441 */     this.headers.putAll(header);
/* 442 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setParameters(Map<String, String[]> parameters) {
/* 446 */     this.parameters = parameters;
/* 447 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setContextPath(String contextPath) {
/* 451 */     this.contextPath = contextPath;
/* 452 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setMethod(String method) {
/* 456 */     this.method = method;
/* 457 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setPathInfo(String pathInfo) {
/* 461 */     this.pathInfo = pathInfo;
/* 462 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setQueryString(String queryString) {
/* 466 */     this.queryString = queryString;
/* 467 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setRequestURI(String requestURI) {
/* 471 */     this.requestURI = requestURI;
/* 472 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setRequestURL(String requestURL) {
/* 476 */     this.requestURL = requestURL;
/* 477 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setScheme(String scheme) {
/* 481 */     this.scheme = scheme;
/* 482 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setServerName(String serverName) {
/* 486 */     this.serverName = serverName;
/* 487 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setServletPath(String servletPath) {
/* 491 */     this.servletPath = servletPath;
/* 492 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setServerPort(int serverPort) {
/* 496 */     this.serverPort = serverPort;
/* 497 */     return this;
/*     */   }
/*     */   
/*     */   public Builder setMatchingRequestParameterName(String matchingRequestParameterName) {
/* 501 */     this.matchingRequestParameterName = matchingRequestParameterName;
/* 502 */     return this;
/*     */   }
/*     */   
/*     */   public DefaultSavedRequest build() {
/* 506 */     DefaultSavedRequest savedRequest = new DefaultSavedRequest(this);
/* 507 */     if (!ObjectUtils.isEmpty(this.cookies)) {
/* 508 */       for (SavedCookie cookie : this.cookies) {
/* 509 */         savedRequest.addCookie(cookie.getCookie());
/*     */       }
/*     */     }
/* 512 */     if (!ObjectUtils.isEmpty(this.locales)) {
/* 513 */       savedRequest.locales.addAll(this.locales);
/*     */     }
/* 515 */     savedRequest.addParameters(this.parameters);
/* 516 */     this.headers.remove("If-Modified-Since");
/* 517 */     this.headers.remove("If-None-Match");
/* 518 */     for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/* 519 */       String headerName = entry.getKey();
/* 520 */       List<String> headerValues = entry.getValue();
/* 521 */       for (String headerValue : headerValues) {
/* 522 */         savedRequest.addHeader(headerName, headerValue);
/*     */       }
/*     */     } 
/* 525 */     return savedRequest;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\DefaultSavedRequest$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */