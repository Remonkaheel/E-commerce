/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SavedCookie
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*     */   private final String name;
/*     */   private final String value;
/*     */   private final String comment;
/*     */   private final String domain;
/*     */   private final int maxAge;
/*     */   private final String path;
/*     */   private final boolean secure;
/*     */   private final int version;
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "6.1")
/*     */   public SavedCookie(String name, String value, String comment, String domain, int maxAge, String path, boolean secure, int version) {
/*  58 */     this.name = name;
/*  59 */     this.value = value;
/*  60 */     this.comment = comment;
/*  61 */     this.domain = domain;
/*  62 */     this.maxAge = maxAge;
/*  63 */     this.path = path;
/*  64 */     this.secure = secure;
/*  65 */     this.version = version;
/*     */   }
/*     */   
/*     */   public SavedCookie(String name, String value, String domain, int maxAge, String path, boolean secure) {
/*  69 */     this(name, value, null, domain, maxAge, path, secure, 0);
/*     */   }
/*     */   
/*     */   public SavedCookie(Cookie cookie) {
/*  73 */     this(cookie.getName(), cookie.getValue(), cookie.getDomain(), cookie.getMaxAge(), cookie.getPath(), cookie
/*  74 */         .getSecure());
/*     */   }
/*     */   
/*     */   public String getName() {
/*  78 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  82 */     return this.value;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "6.1")
/*     */   public String getComment() {
/*  87 */     return this.comment;
/*     */   }
/*     */   
/*     */   public String getDomain() {
/*  91 */     return this.domain;
/*     */   }
/*     */   
/*     */   public int getMaxAge() {
/*  95 */     return this.maxAge;
/*     */   }
/*     */   
/*     */   public String getPath() {
/*  99 */     return this.path;
/*     */   }
/*     */   
/*     */   public boolean isSecure() {
/* 103 */     return this.secure;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true, since = "6.1")
/*     */   public int getVersion() {
/* 108 */     return this.version;
/*     */   }
/*     */   
/*     */   public Cookie getCookie() {
/* 112 */     Cookie cookie = new Cookie(getName(), getValue());
/* 113 */     if (getComment() != null) {
/* 114 */       cookie.setComment(getComment());
/*     */     }
/* 116 */     if (getDomain() != null) {
/* 117 */       cookie.setDomain(getDomain());
/*     */     }
/* 119 */     if (getPath() != null) {
/* 120 */       cookie.setPath(getPath());
/*     */     }
/* 122 */     cookie.setVersion(getVersion());
/* 123 */     cookie.setMaxAge(getMaxAge());
/* 124 */     cookie.setSecure(isSecure());
/* 125 */     return cookie;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\SavedCookie.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */