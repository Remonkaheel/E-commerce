/*     */ package org.springframework.security.web.savedrequest;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Base64;
/*     */ import java.util.Collections;
/*     */ import java.util.function.Consumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieRequestCache
/*     */   implements RequestCache
/*     */ {
/*  47 */   private RequestMatcher requestMatcher = AnyRequestMatcher.INSTANCE;
/*     */   
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private static final String COOKIE_NAME = "REDIRECT_URI";
/*     */   
/*     */   private static final int COOKIE_MAX_AGE = -1;
/*     */   
/*     */   private Consumer<Cookie> cookieCustomizer = cookie -> {
/*     */     
/*     */     };
/*     */   
/*     */   public void saveRequest(HttpServletRequest request, HttpServletResponse response) {
/*  60 */     if (!this.requestMatcher.matches(request)) {
/*  61 */       this.logger.debug("Request not saved as configured RequestMatcher did not match");
/*     */       return;
/*     */     } 
/*  64 */     String redirectUrl = UrlUtils.buildFullRequestUrl(request);
/*  65 */     Cookie savedCookie = new Cookie("REDIRECT_URI", encodeCookie(redirectUrl));
/*  66 */     savedCookie.setMaxAge(-1);
/*  67 */     savedCookie.setSecure(request.isSecure());
/*  68 */     savedCookie.setPath(getCookiePath(request));
/*  69 */     savedCookie.setHttpOnly(true);
/*  70 */     this.cookieCustomizer.accept(savedCookie);
/*  71 */     response.addCookie(savedCookie);
/*     */   }
/*     */ 
/*     */   
/*     */   public SavedRequest getRequest(HttpServletRequest request, HttpServletResponse response) {
/*  76 */     Cookie savedRequestCookie = WebUtils.getCookie(request, "REDIRECT_URI");
/*  77 */     if (savedRequestCookie == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     String originalURI = decodeCookie(savedRequestCookie.getValue());
/*  81 */     if (originalURI == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     UriComponents uriComponents = UriComponentsBuilder.fromUriString(originalURI).build();
/*  85 */     DefaultSavedRequest.Builder builder = new DefaultSavedRequest.Builder();
/*  86 */     int port = getPort(uriComponents);
/*  87 */     return builder.setScheme(uriComponents.getScheme())
/*  88 */       .setServerName(uriComponents.getHost())
/*  89 */       .setRequestURI(uriComponents.getPath())
/*  90 */       .setQueryString(uriComponents.getQuery())
/*  91 */       .setServerPort(port)
/*  92 */       .setMethod(request.getMethod())
/*  93 */       .setLocales(Collections.list(request.getLocales()))
/*  94 */       .build();
/*     */   }
/*     */   
/*     */   private int getPort(UriComponents uriComponents) {
/*  98 */     int port = uriComponents.getPort();
/*  99 */     if (port != -1) {
/* 100 */       return port;
/*     */     }
/* 102 */     if ("https".equalsIgnoreCase(uriComponents.getScheme())) {
/* 103 */       return 443;
/*     */     }
/* 105 */     return 80;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest getMatchingRequest(HttpServletRequest request, HttpServletResponse response) {
/* 110 */     SavedRequest saved = getRequest(request, response);
/* 111 */     if (!matchesSavedRequest(request, saved)) {
/* 112 */       this.logger.debug("saved request doesn't match");
/* 113 */       return null;
/*     */     } 
/* 115 */     removeRequest(request, response);
/* 116 */     return (HttpServletRequest)new SavedRequestAwareWrapper(saved, request);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeRequest(HttpServletRequest request, HttpServletResponse response) {
/* 121 */     Cookie removeSavedRequestCookie = new Cookie("REDIRECT_URI", "");
/* 122 */     removeSavedRequestCookie.setSecure(request.isSecure());
/* 123 */     removeSavedRequestCookie.setHttpOnly(true);
/* 124 */     removeSavedRequestCookie.setPath(getCookiePath(request));
/* 125 */     removeSavedRequestCookie.setMaxAge(0);
/* 126 */     response.addCookie(removeSavedRequestCookie);
/*     */   }
/*     */   
/*     */   private static String encodeCookie(String cookieValue) {
/* 130 */     return Base64.getEncoder().encodeToString(cookieValue.getBytes());
/*     */   }
/*     */   
/*     */   private String decodeCookie(String encodedCookieValue) {
/*     */     try {
/* 135 */       return new String(Base64.getDecoder().decode(encodedCookieValue.getBytes()));
/*     */     }
/* 137 */     catch (IllegalArgumentException ex) {
/* 138 */       this.logger.debug("Failed decode cookie value " + encodedCookieValue);
/* 139 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getCookiePath(HttpServletRequest request) {
/* 144 */     String contextPath = request.getContextPath();
/* 145 */     return StringUtils.hasLength(contextPath) ? contextPath : "/";
/*     */   }
/*     */   
/*     */   private boolean matchesSavedRequest(HttpServletRequest request, SavedRequest savedRequest) {
/* 149 */     if (savedRequest == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     String currentUrl = UrlUtils.buildFullRequestUrl(request);
/* 153 */     return savedRequest.getRedirectUrl().equals(currentUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/* 165 */     Assert.notNull(requestMatcher, "requestMatcher should not be null");
/* 166 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieCustomizer(Consumer<Cookie> cookieCustomizer) {
/* 175 */     Assert.notNull(cookieCustomizer, "cookieCustomizer cannot be null");
/* 176 */     this.cookieCustomizer = cookieCustomizer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\savedrequest\CookieRequestCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */