package org.springframework.security.web.jackson2;

import com.fasterxml.jackson.core.type.TypeReference;
import java.util.List;
import org.springframework.security.core.GrantedAuthority;

class null extends TypeReference<List<GrantedAuthority>> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jackson2\PreAuthenticatedAuthenticationTokenDeserializer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */