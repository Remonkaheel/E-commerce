/*    */ package org.springframework.security.web.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.node.MissingNode;
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CookieDeserializer
/*    */   extends JsonDeserializer<Cookie>
/*    */ {
/*    */   public Cookie deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
/* 45 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/* 46 */     JsonNode jsonNode = (JsonNode)mapper.readTree(jp);
/* 47 */     Cookie cookie = new Cookie(readJsonNode(jsonNode, "name").asText(), readJsonNode(jsonNode, "value").asText());
/* 48 */     cookie.setComment(readJsonNode(jsonNode, "comment").asText());
/* 49 */     cookie.setDomain(readJsonNode(jsonNode, "domain").asText());
/* 50 */     cookie.setMaxAge(readJsonNode(jsonNode, "maxAge").asInt(-1));
/* 51 */     cookie.setSecure(readJsonNode(jsonNode, "secure").asBoolean());
/* 52 */     cookie.setVersion(readJsonNode(jsonNode, "version").asInt());
/* 53 */     cookie.setPath(readJsonNode(jsonNode, "path").asText());
/* 54 */     JsonNode attributes = readJsonNode(jsonNode, "attributes");
/* 55 */     cookie.setHttpOnly(readJsonNode(attributes, "HttpOnly").asBoolean());
/* 56 */     return cookie;
/*    */   }
/*    */   
/*    */   private JsonNode readJsonNode(JsonNode jsonNode, String field) {
/* 60 */     return hasNonNullField(jsonNode, field) ? jsonNode.get(field) : (JsonNode)MissingNode.getInstance();
/*    */   }
/*    */   
/*    */   private boolean hasNonNullField(JsonNode jsonNode, String field) {
/* 64 */     return (jsonNode.has(field) && !(jsonNode.get(field) instanceof com.fasterxml.jackson.databind.node.NullNode));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jackson2\CookieDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */