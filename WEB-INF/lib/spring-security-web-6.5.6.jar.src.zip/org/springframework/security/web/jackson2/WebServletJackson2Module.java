/*    */ package org.springframework.security.web.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import org.springframework.security.jackson2.SecurityJackson2Modules;
/*    */ import org.springframework.security.web.authentication.WebAuthenticationDetails;
/*    */ import org.springframework.security.web.authentication.switchuser.SwitchUserGrantedAuthority;
/*    */ import org.springframework.security.web.savedrequest.DefaultSavedRequest;
/*    */ import org.springframework.security.web.savedrequest.SavedCookie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServletJackson2Module
/*    */   extends SimpleModule
/*    */ {
/*    */   public WebServletJackson2Module() {
/* 51 */     super(WebServletJackson2Module.class.getName(), new Version(1, 0, 0, null, null, null));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 56 */     SecurityJackson2Modules.enableDefaultTyping((ObjectMapper)context.getOwner());
/* 57 */     context.setMixInAnnotations(Cookie.class, CookieMixin.class);
/* 58 */     context.setMixInAnnotations(SavedCookie.class, SavedCookieMixin.class);
/* 59 */     context.setMixInAnnotations(DefaultSavedRequest.class, DefaultSavedRequestMixin.class);
/* 60 */     context.setMixInAnnotations(WebAuthenticationDetails.class, WebAuthenticationDetailsMixin.class);
/* 61 */     context.setMixInAnnotations(SwitchUserGrantedAuthority.class, SwitchUserGrantedAuthorityMixIn.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jackson2\WebServletJackson2Module.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */