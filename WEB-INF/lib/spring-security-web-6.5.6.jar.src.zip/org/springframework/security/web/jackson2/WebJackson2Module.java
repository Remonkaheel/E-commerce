/*    */ package org.springframework.security.web.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import org.springframework.security.jackson2.SecurityJackson2Modules;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ import org.springframework.security.web.csrf.DefaultCsrfToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebJackson2Module
/*    */   extends SimpleModule
/*    */ {
/*    */   public WebJackson2Module() {
/* 47 */     super(WebJackson2Module.class.getName(), new Version(1, 0, 0, null, null, null));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 52 */     SecurityJackson2Modules.enableDefaultTyping((ObjectMapper)context.getOwner());
/* 53 */     context.setMixInAnnotations(DefaultCsrfToken.class, DefaultCsrfTokenMixin.class);
/* 54 */     context.setMixInAnnotations(PreAuthenticatedAuthenticationToken.class, PreAuthenticatedAuthenticationTokenMixin.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jackson2\WebJackson2Module.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */