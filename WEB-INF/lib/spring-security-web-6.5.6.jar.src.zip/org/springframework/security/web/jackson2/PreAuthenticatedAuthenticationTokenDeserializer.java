/*    */ package org.springframework.security.web.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.core.ObjectCodec;
/*    */ import com.fasterxml.jackson.core.type.TypeReference;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.node.MissingNode;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PreAuthenticatedAuthenticationTokenDeserializer
/*    */   extends JsonDeserializer<PreAuthenticatedAuthenticationToken>
/*    */ {
/* 49 */   private static final TypeReference<List<GrantedAuthority>> GRANTED_AUTHORITY_LIST = new TypeReference<List<GrantedAuthority>>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PreAuthenticatedAuthenticationToken deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
/* 64 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/* 65 */     JsonNode jsonNode = (JsonNode)mapper.readTree(jp);
/* 66 */     Boolean authenticated = Boolean.valueOf(readJsonNode(jsonNode, "authenticated").asBoolean());
/* 67 */     JsonNode principalNode = readJsonNode(jsonNode, "principal");
/*    */     
/* 69 */     Object principal = !principalNode.isObject() ? principalNode.asText() : mapper.readValue(principalNode.traverse((ObjectCodec)mapper), Object.class);
/* 70 */     Object credentials = readJsonNode(jsonNode, "credentials").asText();
/* 71 */     List<GrantedAuthority> authorities = (List<GrantedAuthority>)mapper.readValue(readJsonNode(jsonNode, "authorities").traverse((ObjectCodec)mapper), GRANTED_AUTHORITY_LIST);
/*    */ 
/*    */ 
/*    */     
/* 75 */     PreAuthenticatedAuthenticationToken token = !authenticated.booleanValue() ? new PreAuthenticatedAuthenticationToken(principal, credentials) : new PreAuthenticatedAuthenticationToken(principal, credentials, authorities);
/* 76 */     token.setDetails(readJsonNode(jsonNode, "details"));
/* 77 */     return token;
/*    */   }
/*    */   
/*    */   private JsonNode readJsonNode(JsonNode jsonNode, String field) {
/* 81 */     return jsonNode.has(field) ? jsonNode.get(field) : (JsonNode)MissingNode.getInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jackson2\PreAuthenticatedAuthenticationTokenDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */