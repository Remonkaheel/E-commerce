/*     */ package org.springframework.security.web.transport;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.PortMapperImpl;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpsRedirectFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  53 */   private PortMapper portMapper = (PortMapper)new PortMapperImpl();
/*     */   
/*  55 */   private RequestMatcher requestMatcher = AnyRequestMatcher.INSTANCE;
/*     */   
/*  57 */   private final RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
/*  62 */     if (!isInsecure(request)) {
/*  63 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  66 */     if (!this.requestMatcher.matches(request)) {
/*  67 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  70 */     String redirectUri = createRedirectUri(request);
/*  71 */     this.redirectStrategy.sendRedirect(request, response, redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPortMapper(PortMapper portMapper) {
/*  79 */     Assert.notNull(portMapper, "portMapper cannot be null");
/*  80 */     this.portMapper = portMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/*  91 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/*  92 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */   
/*     */   private boolean isInsecure(HttpServletRequest request) {
/*  96 */     return !"https".equals(request.getScheme());
/*     */   }
/*     */   
/*     */   private String createRedirectUri(HttpServletRequest request) {
/* 100 */     String url = UrlUtils.buildFullRequestUrl(request);
/* 101 */     UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
/* 102 */     UriComponents components = builder.build();
/* 103 */     int port = components.getPort();
/* 104 */     if (port > 0) {
/* 105 */       Integer httpsPort = this.portMapper.lookupHttpsPort(Integer.valueOf(port));
/* 106 */       Assert.state((httpsPort != null), () -> "HTTP Port '" + port + "' does not have a corresponding HTTPS Port");
/* 107 */       builder.port(httpsPort.intValue());
/*     */     } 
/* 109 */     return builder.scheme("https").toUriString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\transport\HttpsRedirectFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */