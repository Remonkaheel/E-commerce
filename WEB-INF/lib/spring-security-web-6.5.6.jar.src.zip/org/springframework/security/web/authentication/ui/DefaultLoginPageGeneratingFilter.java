/*     */ package org.springframework.security.web.authentication.ui;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultLoginPageGeneratingFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   public static final String DEFAULT_LOGIN_PAGE_URL = "/login";
/*     */   public static final String ERROR_PARAMETER_NAME = "error";
/*     */   private String loginPageUrl;
/*     */   private String logoutSuccessUrl;
/*     */   private String failureUrl;
/*     */   private boolean formLoginEnabled;
/*     */   private boolean oauth2LoginEnabled;
/*     */   private boolean saml2LoginEnabled;
/*     */   private boolean passkeysEnabled;
/*     */   private boolean oneTimeTokenEnabled;
/*     */   private String authenticationUrl;
/*     */   private String generateOneTimeTokenUrl;
/*     */   private String usernameParameter;
/*     */   private String passwordParameter;
/*     */   private String rememberMeParameter;
/*     */   private Map<String, String> oauth2AuthenticationUrlToClientName;
/*     */   private Map<String, String> saml2AuthenticationUrlToProviderName;
/*     */   private Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs = request -> Collections.emptyMap();
/*     */   private Function<HttpServletRequest, Map<String, String>> resolveHeaders = request -> Collections.emptyMap();
/*     */   private static final String CSRF_HEADERS = "{\"{{headerName}}\" : \"{{headerValue}}\"}";
/*     */   private static final String PASSKEY_SCRIPT_TEMPLATE = "\t<script type=\"text/javascript\" src=\"{{contextPath}}/login/webauthn.js\"></script>\n\t<script type=\"text/javascript\">\n\t<!--\n\t\tdocument.addEventListener(\"DOMContentLoaded\",() => setupLogin({{csrfHeaders}}, \"{{contextPath}}\", document.getElementById('passkey-signin')));\n\n\t//-->\n\t</script>\n";
/*     */   private static final String PASSKEY_FORM_TEMPLATE = "<div class=\"login-form\">\n<h2>Login with Passkeys</h2>\n<button id=\"passkey-signin\" type=\"submit\" class=\"primary\">Sign in with a passkey</button>\n</div>\n";
/*     */   private static final String LOGIN_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Please sign in</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />{{javaScript}}\n  </head>\n  <body>\n    <div class=\"content\">\n{{formLogin}}\n{{oneTimeTokenLogin}}{{passkeyLogin}}\n{{oauth2Login}}\n{{saml2Login}}\n    </div>\n  </body>\n</html>";
/*     */   private static final String LOGIN_FORM_TEMPLATE = "      <form class=\"login-form\" method=\"post\" action=\"{{loginUrl}}\">\n        <h2>Please sign in</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"username\" name=\"{{usernameParameter}}\" placeholder=\"Username\" required autofocus>\n        </p>\n        <p>\n          <label for=\"password\" class=\"screenreader\">Password</label>\n          <input type=\"password\" id=\"password\" name=\"{{passwordParameter}}\" placeholder=\"Password\" {{autocomplete}}required>\n        </p>\n{{rememberMeInput}}\n{{hiddenInputs}}\n        <button type=\"submit\" class=\"primary\">Sign in</button>\n      </form>";
/*     */   private static final String HIDDEN_HTML_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*     */   private static final String ALERT_TEMPLATE = "<div class=\"alert alert-danger\" role=\"alert\">{{message}}</div>";
/*     */   private static final String OAUTH2_LOGIN_TEMPLATE = "<h2>Login with OAuth 2.0</h2>\n{{errorMessage}}{{logoutMessage}}\n<table class=\"table table-striped\">\n  {{oauth2Rows}}\n</table>";
/*     */   private static final String OAUTH2_ROW_TEMPLATE = "<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>";
/*     */   private static final String SAML_LOGIN_TEMPLATE = "<h2>Login with SAML 2.0</h2>\n{{errorMessage}}{{logoutMessage}}\n<table class=\"table table-striped\">\n  {{samlRows}}\n</table>";
/*     */   private static final String SAML_ROW_TEMPLATE = "<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>";
/*     */   private static final String ONE_TIME_TEMPLATE = "      <form id=\"ott-form\" class=\"login-form\" method=\"post\" action=\"{{generateOneTimeTokenUrl}}\">\n        <h2>Request a One-Time Token</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"ott-username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"ott-username\" name=\"username\" placeholder=\"Username\" required>\n        </p>\n{{hiddenInputs}}\n        <button class=\"primary\" type=\"submit\" form=\"ott-form\">Send Token</button>\n      </form>\n";
/*     */   
/*     */   public DefaultLoginPageGeneratingFilter(UsernamePasswordAuthenticationFilter authFilter) {
/*  92 */     this.loginPageUrl = "/login";
/*  93 */     this.logoutSuccessUrl = "/login?logout";
/*  94 */     this.failureUrl = "/login?error";
/*  95 */     if (authFilter != null) {
/*  96 */       initAuthFilter(authFilter);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initAuthFilter(UsernamePasswordAuthenticationFilter authFilter) {
/* 101 */     this.formLoginEnabled = true;
/* 102 */     this.usernameParameter = authFilter.getUsernameParameter();
/* 103 */     this.passwordParameter = authFilter.getPasswordParameter();
/* 104 */     RememberMeServices rememberMeServices = authFilter.getRememberMeServices(); if (rememberMeServices instanceof AbstractRememberMeServices) { AbstractRememberMeServices abstractRememberMeServices = (AbstractRememberMeServices)rememberMeServices;
/* 105 */       this.rememberMeParameter = abstractRememberMeServices.getParameter(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolveHiddenInputs(Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs) {
/* 116 */     Assert.notNull(resolveHiddenInputs, "resolveHiddenInputs cannot be null");
/* 117 */     this.resolveHiddenInputs = resolveHiddenInputs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolveHeaders(Function<HttpServletRequest, Map<String, String>> resolveHeaders) {
/* 127 */     Assert.notNull(resolveHeaders, "resolveHeaders cannot be null");
/* 128 */     this.resolveHeaders = resolveHeaders;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 132 */     return (this.formLoginEnabled || this.oauth2LoginEnabled || this.saml2LoginEnabled || this.oneTimeTokenEnabled);
/*     */   }
/*     */   
/*     */   public void setLogoutSuccessUrl(String logoutSuccessUrl) {
/* 136 */     this.logoutSuccessUrl = logoutSuccessUrl;
/*     */   }
/*     */   
/*     */   public String getLoginPageUrl() {
/* 140 */     return this.loginPageUrl;
/*     */   }
/*     */   
/*     */   public void setLoginPageUrl(String loginPageUrl) {
/* 144 */     this.loginPageUrl = loginPageUrl;
/*     */   }
/*     */   
/*     */   public void setFailureUrl(String failureUrl) {
/* 148 */     this.failureUrl = failureUrl;
/*     */   }
/*     */   
/*     */   public void setFormLoginEnabled(boolean formLoginEnabled) {
/* 152 */     this.formLoginEnabled = formLoginEnabled;
/*     */   }
/*     */   
/*     */   public void setOauth2LoginEnabled(boolean oauth2LoginEnabled) {
/* 156 */     this.oauth2LoginEnabled = oauth2LoginEnabled;
/*     */   }
/*     */   
/*     */   public void setOneTimeTokenEnabled(boolean oneTimeTokenEnabled) {
/* 160 */     this.oneTimeTokenEnabled = oneTimeTokenEnabled;
/*     */   }
/*     */   
/*     */   public void setSaml2LoginEnabled(boolean saml2LoginEnabled) {
/* 164 */     this.saml2LoginEnabled = saml2LoginEnabled;
/*     */   }
/*     */   
/*     */   public void setPasskeysEnabled(boolean passkeysEnabled) {
/* 168 */     this.passkeysEnabled = passkeysEnabled;
/*     */   }
/*     */   
/*     */   public void setAuthenticationUrl(String authenticationUrl) {
/* 172 */     this.authenticationUrl = authenticationUrl;
/*     */   }
/*     */   
/*     */   public void setOneTimeTokenGenerationUrl(String generateOneTimeTokenUrl) {
/* 176 */     this.generateOneTimeTokenUrl = generateOneTimeTokenUrl;
/*     */   }
/*     */   
/*     */   public void setUsernameParameter(String usernameParameter) {
/* 180 */     this.usernameParameter = usernameParameter;
/*     */   }
/*     */   
/*     */   public void setPasswordParameter(String passwordParameter) {
/* 184 */     this.passwordParameter = passwordParameter;
/*     */   }
/*     */   
/*     */   public void setRememberMeParameter(String rememberMeParameter) {
/* 188 */     this.rememberMeParameter = rememberMeParameter;
/*     */   }
/*     */   
/*     */   public void setOauth2AuthenticationUrlToClientName(Map<String, String> oauth2AuthenticationUrlToClientName) {
/* 192 */     this.oauth2AuthenticationUrlToClientName = oauth2AuthenticationUrlToClientName;
/*     */   }
/*     */   
/*     */   public void setSaml2AuthenticationUrlToProviderName(Map<String, String> saml2AuthenticationUrlToProviderName) {
/* 196 */     this.saml2AuthenticationUrlToProviderName = saml2AuthenticationUrlToProviderName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 202 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 207 */     boolean loginError = isErrorPage(request);
/* 208 */     boolean logoutSuccess = isLogoutSuccess(request);
/* 209 */     if (isLoginUrlRequest(request) || loginError || logoutSuccess) {
/* 210 */       String loginPageHtml = generateLoginPageHtml(request, loginError, logoutSuccess);
/* 211 */       response.setContentType("text/html;charset=UTF-8");
/* 212 */       response.setContentLength((loginPageHtml.getBytes(StandardCharsets.UTF_8)).length);
/* 213 */       response.getWriter().write(loginPageHtml);
/*     */       return;
/*     */     } 
/* 216 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */   
/*     */   private String generateLoginPageHtml(HttpServletRequest request, boolean loginError, boolean logoutSuccess) {
/* 220 */     String errorMsg = "Invalid credentials";
/* 221 */     String contextPath = request.getContextPath();
/*     */     
/* 223 */     return HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Please sign in</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />{{javaScript}}\n  </head>\n  <body>\n    <div class=\"content\">\n{{formLogin}}\n{{oneTimeTokenLogin}}{{passkeyLogin}}\n{{oauth2Login}}\n{{saml2Login}}\n    </div>\n  </body>\n</html>")
/* 224 */       .withRawHtml("contextPath", contextPath)
/* 225 */       .withRawHtml("javaScript", renderJavaScript(request, contextPath))
/* 226 */       .withRawHtml("formLogin", renderFormLogin(request, loginError, logoutSuccess, contextPath, errorMsg))
/* 227 */       .withRawHtml("oneTimeTokenLogin", 
/* 228 */         renderOneTimeTokenLogin(request, loginError, logoutSuccess, contextPath, errorMsg))
/* 229 */       .withRawHtml("oauth2Login", renderOAuth2Login(loginError, logoutSuccess, errorMsg, contextPath))
/* 230 */       .withRawHtml("saml2Login", renderSaml2Login(loginError, logoutSuccess, errorMsg, contextPath))
/* 231 */       .withRawHtml("passkeyLogin", renderPasskeyLogin())
/* 232 */       .render();
/*     */   }
/*     */   
/*     */   private String renderJavaScript(HttpServletRequest request, String contextPath) {
/* 236 */     if (this.passkeysEnabled) {
/* 237 */       return HtmlTemplates.fromTemplate("\t<script type=\"text/javascript\" src=\"{{contextPath}}/login/webauthn.js\"></script>\n\t<script type=\"text/javascript\">\n\t<!--\n\t\tdocument.addEventListener(\"DOMContentLoaded\",() => setupLogin({{csrfHeaders}}, \"{{contextPath}}\", document.getElementById('passkey-signin')));\n\n\t//-->\n\t</script>\n")
/* 238 */         .withValue("loginPageUrl", this.loginPageUrl)
/* 239 */         .withValue("contextPath", contextPath)
/* 240 */         .withRawHtml("csrfHeaders", renderHeaders(request))
/* 241 */         .render();
/*     */     }
/* 243 */     return "";
/*     */   }
/*     */   
/*     */   private String renderPasskeyLogin() {
/* 247 */     if (this.passkeysEnabled) {
/* 248 */       return "<div class=\"login-form\">\n<h2>Login with Passkeys</h2>\n<button id=\"passkey-signin\" type=\"submit\" class=\"primary\">Sign in with a passkey</button>\n</div>\n";
/*     */     }
/* 250 */     return "";
/*     */   }
/*     */   
/*     */   private String renderHeaders(HttpServletRequest request) {
/* 254 */     StringBuffer javascriptHeadersEntries = new StringBuffer();
/* 255 */     Map<String, String> headers = this.resolveHeaders.apply(request);
/* 256 */     for (Map.Entry<String, String> header : headers.entrySet()) {
/* 257 */       javascriptHeadersEntries.append(HtmlTemplates.fromTemplate("{\"{{headerName}}\" : \"{{headerValue}}\"}")
/* 258 */           .withValue("headerName", header.getKey())
/* 259 */           .withValue("headerValue", header.getValue())
/* 260 */           .render());
/*     */     }
/* 262 */     return javascriptHeadersEntries.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String renderFormLogin(HttpServletRequest request, boolean loginError, boolean logoutSuccess, String contextPath, String errorMsg) {
/* 267 */     if (!this.formLoginEnabled) {
/* 268 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     String hiddenInputs = ((Map)this.resolveHiddenInputs.apply(request)).entrySet().stream().map(inputKeyValue -> renderHiddenInput((String)inputKeyValue.getKey(), (String)inputKeyValue.getValue())).collect(Collectors.joining("\n"));
/*     */     
/* 277 */     return HtmlTemplates.fromTemplate("      <form class=\"login-form\" method=\"post\" action=\"{{loginUrl}}\">\n        <h2>Please sign in</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"username\" name=\"{{usernameParameter}}\" placeholder=\"Username\" required autofocus>\n        </p>\n        <p>\n          <label for=\"password\" class=\"screenreader\">Password</label>\n          <input type=\"password\" id=\"password\" name=\"{{passwordParameter}}\" placeholder=\"Password\" {{autocomplete}}required>\n        </p>\n{{rememberMeInput}}\n{{hiddenInputs}}\n        <button type=\"submit\" class=\"primary\">Sign in</button>\n      </form>")
/* 278 */       .withValue("loginUrl", contextPath + contextPath)
/* 279 */       .withRawHtml("errorMessage", renderError(loginError, errorMsg))
/* 280 */       .withRawHtml("logoutMessage", renderSuccess(logoutSuccess))
/* 281 */       .withValue("usernameParameter", this.usernameParameter)
/* 282 */       .withValue("passwordParameter", this.passwordParameter)
/* 283 */       .withRawHtml("rememberMeInput", renderRememberMe(this.rememberMeParameter))
/* 284 */       .withRawHtml("hiddenInputs", hiddenInputs)
/* 285 */       .withRawHtml("autocomplete", this.passkeysEnabled ? "autocomplete=\"password webauthn\" " : "")
/* 286 */       .render();
/*     */   }
/*     */ 
/*     */   
/*     */   private String renderOneTimeTokenLogin(HttpServletRequest request, boolean loginError, boolean logoutSuccess, String contextPath, String errorMsg) {
/* 291 */     if (!this.oneTimeTokenEnabled) {
/* 292 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     String hiddenInputs = ((Map)this.resolveHiddenInputs.apply(request)).entrySet().stream().map(inputKeyValue -> renderHiddenInput((String)inputKeyValue.getKey(), (String)inputKeyValue.getValue())).collect(Collectors.joining("\n"));
/*     */     
/* 301 */     return HtmlTemplates.fromTemplate("      <form id=\"ott-form\" class=\"login-form\" method=\"post\" action=\"{{generateOneTimeTokenUrl}}\">\n        <h2>Request a One-Time Token</h2>\n{{errorMessage}}{{logoutMessage}}\n        <p>\n          <label for=\"ott-username\" class=\"screenreader\">Username</label>\n          <input type=\"text\" id=\"ott-username\" name=\"username\" placeholder=\"Username\" required>\n        </p>\n{{hiddenInputs}}\n        <button class=\"primary\" type=\"submit\" form=\"ott-form\">Send Token</button>\n      </form>\n")
/* 302 */       .withValue("generateOneTimeTokenUrl", contextPath + contextPath)
/* 303 */       .withRawHtml("errorMessage", renderError(loginError, errorMsg))
/* 304 */       .withRawHtml("logoutMessage", renderSuccess(logoutSuccess))
/* 305 */       .withRawHtml("hiddenInputs", hiddenInputs)
/* 306 */       .render();
/*     */   }
/*     */   
/*     */   private String renderOAuth2Login(boolean loginError, boolean logoutSuccess, String errorMsg, String contextPath) {
/* 310 */     if (!this.oauth2LoginEnabled) {
/* 311 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     String oauth2Rows = this.oauth2AuthenticationUrlToClientName.entrySet().stream().map(urlToName -> renderOAuth2Row(contextPath, (String)urlToName.getKey(), (String)urlToName.getValue())).collect(Collectors.joining("\n"));
/*     */     
/* 319 */     return HtmlTemplates.fromTemplate("<h2>Login with OAuth 2.0</h2>\n{{errorMessage}}{{logoutMessage}}\n<table class=\"table table-striped\">\n  {{oauth2Rows}}\n</table>")
/* 320 */       .withRawHtml("errorMessage", renderError(loginError, errorMsg))
/* 321 */       .withRawHtml("logoutMessage", renderSuccess(logoutSuccess))
/* 322 */       .withRawHtml("oauth2Rows", oauth2Rows)
/* 323 */       .render();
/*     */   }
/*     */   
/*     */   private static String renderOAuth2Row(String contextPath, String url, String clientName) {
/* 327 */     return HtmlTemplates.fromTemplate("<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>")
/* 328 */       .withValue("url", contextPath + contextPath)
/* 329 */       .withValue("clientName", clientName)
/* 330 */       .render();
/*     */   }
/*     */   
/*     */   private String renderSaml2Login(boolean loginError, boolean logoutSuccess, String errorMsg, String contextPath) {
/* 334 */     if (!this.saml2LoginEnabled) {
/* 335 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     String samlRows = this.saml2AuthenticationUrlToProviderName.entrySet().stream().map(urlToName -> renderSaml2Row(contextPath, (String)urlToName.getKey(), (String)urlToName.getValue())).collect(Collectors.joining("\n"));
/*     */     
/* 343 */     return HtmlTemplates.fromTemplate("<h2>Login with SAML 2.0</h2>\n{{errorMessage}}{{logoutMessage}}\n<table class=\"table table-striped\">\n  {{samlRows}}\n</table>")
/* 344 */       .withRawHtml("errorMessage", renderError(loginError, errorMsg))
/* 345 */       .withRawHtml("logoutMessage", renderSuccess(logoutSuccess))
/* 346 */       .withRawHtml("samlRows", samlRows)
/* 347 */       .render();
/*     */   }
/*     */   
/*     */   private static String renderSaml2Row(String contextPath, String url, String clientName) {
/* 351 */     return HtmlTemplates.fromTemplate("<tr><td><a href=\"{{url}}\">{{clientName}}</a></td></tr>")
/* 352 */       .withValue("url", contextPath + contextPath)
/* 353 */       .withValue("clientName", clientName)
/* 354 */       .render();
/*     */   }
/*     */   
/*     */   private String renderHiddenInput(String name, String value) {
/* 358 */     return HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n")
/* 359 */       .withValue("name", name)
/* 360 */       .withValue("value", value)
/* 361 */       .render();
/*     */   }
/*     */   
/*     */   private String renderRememberMe(String paramName) {
/* 365 */     if (paramName == null) {
/* 366 */       return "";
/*     */     }
/* 368 */     return 
/* 369 */       HtmlTemplates.fromTemplate("<p><input type='checkbox' name='{{paramName}}'/> Remember me on this computer.</p>")
/* 370 */       .withValue("paramName", paramName)
/* 371 */       .render();
/*     */   }
/*     */   
/*     */   private boolean isLogoutSuccess(HttpServletRequest request) {
/* 375 */     return (this.logoutSuccessUrl != null && matches(request, this.logoutSuccessUrl));
/*     */   }
/*     */   
/*     */   private boolean isLoginUrlRequest(HttpServletRequest request) {
/* 379 */     return matches(request, this.loginPageUrl);
/*     */   }
/*     */   
/*     */   private boolean isErrorPage(HttpServletRequest request) {
/* 383 */     return matches(request, this.failureUrl);
/*     */   }
/*     */   
/*     */   private String renderError(boolean isError, String message) {
/* 387 */     if (!isError) {
/* 388 */       return "";
/*     */     }
/* 390 */     return HtmlTemplates.fromTemplate("<div class=\"alert alert-danger\" role=\"alert\">{{message}}</div>").withValue("message", message).render();
/*     */   }
/*     */   
/*     */   private String renderSuccess(boolean isLogoutSuccess) {
/* 394 */     if (!isLogoutSuccess) {
/* 395 */       return "";
/*     */     }
/* 397 */     return "<div class=\"alert alert-success\" role=\"alert\">You have been signed out</div>";
/*     */   }
/*     */   
/*     */   private boolean matches(HttpServletRequest request, String url) {
/* 401 */     if (!"GET".equals(request.getMethod()) || url == null) {
/* 402 */       return false;
/*     */     }
/* 404 */     String uri = request.getRequestURI();
/* 405 */     int pathParamIndex = uri.indexOf(';');
/* 406 */     if (pathParamIndex > 0)
/*     */     {
/* 408 */       uri = uri.substring(0, pathParamIndex);
/*     */     }
/* 410 */     if (request.getQueryString() != null) {
/* 411 */       uri = uri + "?" + uri;
/*     */     }
/* 413 */     if ("".equals(request.getContextPath())) {
/* 414 */       return uri.equals(url);
/*     */     }
/* 416 */     return uri.equals(request.getContextPath() + request.getContextPath());
/*     */   }
/*     */   
/*     */   public DefaultLoginPageGeneratingFilter() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authenticatio\\ui\DefaultLoginPageGeneratingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */