package org.springframework.security.web.authentication.preauth.websphere;

import java.util.List;

interface WASUsernameAndGroupsExtractor {
  List<String> getGroupsForCurrentUser();
  
  String getCurrentUserName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\websphere\WASUsernameAndGroupsExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */