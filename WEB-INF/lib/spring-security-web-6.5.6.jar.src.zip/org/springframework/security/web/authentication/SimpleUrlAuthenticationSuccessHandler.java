/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleUrlAuthenticationSuccessHandler
/*    */   extends AbstractAuthenticationTargetUrlRequestHandler
/*    */   implements AuthenticationSuccessHandler
/*    */ {
/*    */   public SimpleUrlAuthenticationSuccessHandler() {}
/*    */   
/*    */   public SimpleUrlAuthenticationSuccessHandler(String defaultTargetUrl) {
/* 51 */     setDefaultTargetUrl(defaultTargetUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
/* 62 */     handle(request, response, authentication);
/* 63 */     clearAuthenticationAttributes(request);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void clearAuthenticationAttributes(HttpServletRequest request) {
/* 71 */     HttpSession session = request.getSession(false);
/* 72 */     if (session != null)
/* 73 */       session.removeAttribute("SPRING_SECURITY_LAST_EXCEPTION"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\SimpleUrlAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */