/*     */ package org.springframework.security.web.authentication.session;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSessionFixationProtectionStrategy
/*     */   implements SessionAuthenticationStrategy, ApplicationEventPublisherAware
/*     */ {
/*  42 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private ApplicationEventPublisher applicationEventPublisher = new NullEventPublisher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean alwaysCreateSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) {
/*  75 */     boolean hadSessionAlready = (request.getSession(false) != null);
/*  76 */     if (!hadSessionAlready && !this.alwaysCreateSession) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  81 */     HttpSession session = request.getSession();
/*  82 */     if (hadSessionAlready && request.isRequestedSessionIdValid()) {
/*     */       String originalSessionId, newSessionId;
/*     */       
/*  85 */       Object mutex = WebUtils.getSessionMutex(session);
/*  86 */       synchronized (mutex) {
/*     */         
/*  88 */         originalSessionId = session.getId();
/*  89 */         session = applySessionFixation(request);
/*  90 */         newSessionId = session.getId();
/*     */       } 
/*  92 */       if (originalSessionId.equals(newSessionId)) {
/*  93 */         this.logger.warn("Your servlet container did not change the session ID when a new session was created. You will not be adequately protected against session-fixation attacks");
/*     */ 
/*     */       
/*     */       }
/*  97 */       else if (this.logger.isDebugEnabled()) {
/*  98 */         this.logger.debug(LogMessage.format("Changed session id from %s", originalSessionId));
/*     */       } 
/*     */       
/* 101 */       onSessionChange(originalSessionId, session, authentication);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract HttpSession applySessionFixation(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onSessionChange(String originalSessionId, HttpSession newSession, Authentication auth) {
/* 128 */     this.applicationEventPublisher
/* 129 */       .publishEvent((ApplicationEvent)new SessionFixationProtectionEvent(auth, originalSessionId, newSession.getId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 141 */     Assert.notNull(applicationEventPublisher, "applicationEventPublisher cannot be null");
/* 142 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   public void setAlwaysCreateSession(boolean alwaysCreateSession) {
/* 146 */     this.alwaysCreateSession = alwaysCreateSession;
/*     */   }
/*     */   
/*     */   protected static final class NullEventPublisher implements ApplicationEventPublisher {
/*     */     public void publishEvent(ApplicationEvent event) {}
/*     */     
/*     */     public void publishEvent(Object event) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\AbstractSessionFixationProtectionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */