/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestMatcherDelegatingAuthenticationManagerResolver
/*     */   implements AuthenticationManagerResolver<HttpServletRequest>
/*     */ {
/*     */   private final List<RequestMatcherEntry<AuthenticationManager>> authenticationManagers;
/*     */   private AuthenticationManager defaultAuthenticationManager;
/*     */   
/*     */   RequestMatcherDelegatingAuthenticationManagerResolver(RequestMatcherEntry<AuthenticationManager>... authenticationManagers) {
/*  49 */     this.defaultAuthenticationManager = (authentication -> {
/*     */         AuthenticationServiceException authenticationServiceException = new AuthenticationServiceException("Cannot authenticate " + String.valueOf(authentication));
/*     */ 
/*     */ 
/*     */         
/*     */         authenticationServiceException.setAuthenticationRequest(authentication);
/*     */ 
/*     */ 
/*     */         
/*     */         throw authenticationServiceException;
/*     */       });
/*     */ 
/*     */ 
/*     */     
/*  63 */     Assert.notEmpty((Object[])authenticationManagers, "authenticationManagers cannot be empty");
/*  64 */     this.authenticationManagers = Arrays.asList(authenticationManagers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   RequestMatcherDelegatingAuthenticationManagerResolver(List<RequestMatcherEntry<AuthenticationManager>> authenticationManagers) {
/*     */     this.defaultAuthenticationManager = (authentication -> {
/*     */         AuthenticationServiceException authenticationServiceException = new AuthenticationServiceException("Cannot authenticate " + String.valueOf(authentication));
/*     */         authenticationServiceException.setAuthenticationRequest(authentication);
/*     */         throw authenticationServiceException;
/*     */       });
/*  75 */     Assert.notEmpty(authenticationManagers, "authenticationManagers cannot be empty");
/*  76 */     this.authenticationManagers = authenticationManagers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationManager resolve(HttpServletRequest context) {
/*  84 */     for (RequestMatcherEntry<AuthenticationManager> entry : this.authenticationManagers) {
/*  85 */       if (entry.getRequestMatcher().matches(context)) {
/*  86 */         return (AuthenticationManager)entry.getEntry();
/*     */       }
/*     */     } 
/*     */     
/*  90 */     return this.defaultAuthenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAuthenticationManager(AuthenticationManager defaultAuthenticationManager) {
/*  99 */     Assert.notNull(defaultAuthenticationManager, "defaultAuthenticationManager cannot be null");
/* 100 */     this.defaultAuthenticationManager = defaultAuthenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 109 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 117 */     private final List<RequestMatcherEntry<AuthenticationManager>> entries = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder add(RequestMatcher matcher, AuthenticationManager manager) {
/* 131 */       Assert.notNull(matcher, "matcher cannot be null");
/* 132 */       Assert.notNull(manager, "manager cannot be null");
/* 133 */       this.entries.add(new RequestMatcherEntry(matcher, manager));
/* 134 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthenticationManagerResolver build() {
/* 144 */       return new RequestMatcherDelegatingAuthenticationManagerResolver(this.entries);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\RequestMatcherDelegatingAuthenticationManagerResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */