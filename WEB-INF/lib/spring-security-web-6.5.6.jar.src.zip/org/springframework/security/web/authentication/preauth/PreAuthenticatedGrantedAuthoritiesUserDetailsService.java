/*    */ package org.springframework.security.web.authentication.preauth;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.GrantedAuthoritiesContainer;
/*    */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreAuthenticatedGrantedAuthoritiesUserDetailsService
/*    */   implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken>
/*    */ {
/*    */   public final UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) throws AuthenticationException {
/* 58 */     Assert.notNull(token.getDetails(), "token.getDetails() cannot be null");
/* 59 */     Assert.isInstanceOf(GrantedAuthoritiesContainer.class, token.getDetails());
/*    */     
/* 61 */     Collection<? extends GrantedAuthority> authorities = ((GrantedAuthoritiesContainer)token.getDetails()).getGrantedAuthorities();
/* 62 */     return createUserDetails((Authentication)token, authorities);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected UserDetails createUserDetails(Authentication token, Collection<? extends GrantedAuthority> authorities) {
/* 72 */     return (UserDetails)new User(token.getName(), "N/A", true, true, true, true, authorities);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\PreAuthenticatedGrantedAuthoritiesUserDetailsService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */