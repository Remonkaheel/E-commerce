/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DigestAuthUtils
/*     */ {
/*  32 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String encodePasswordInA1Format(String username, String realm, String password) {
/*  38 */     String a1 = username + ":" + username + ":" + realm;
/*     */     
/*  40 */     return md5Hex(a1);
/*     */   }
/*     */   
/*     */   static String[] splitIgnoringQuotes(String str, char separatorChar) {
/*  44 */     if (str == null) {
/*  45 */       return null;
/*     */     }
/*  47 */     int len = str.length();
/*  48 */     if (len == 0) {
/*  49 */       return EMPTY_STRING_ARRAY;
/*     */     }
/*  51 */     List<String> list = new ArrayList<>();
/*  52 */     int i = 0;
/*  53 */     int start = 0;
/*  54 */     boolean match = false;
/*  55 */     while (i < len) {
/*  56 */       if (str.charAt(i) == '"') {
/*  57 */         i++;
/*  58 */         while (i < len) {
/*  59 */           if (str.charAt(i) == '"') {
/*  60 */             i++;
/*     */             break;
/*     */           } 
/*  63 */           i++;
/*     */         } 
/*  65 */         match = true;
/*     */         continue;
/*     */       } 
/*  68 */       if (str.charAt(i) == separatorChar) {
/*  69 */         if (match) {
/*  70 */           list.add(str.substring(start, i));
/*  71 */           match = false;
/*     */         } 
/*  73 */         start = ++i;
/*     */         continue;
/*     */       } 
/*  76 */       match = true;
/*  77 */       i++;
/*     */     } 
/*  79 */     if (match) {
/*  80 */       list.add(str.substring(start, i));
/*     */     }
/*  82 */     return list.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String generateDigest(boolean passwordAlreadyEncoded, String username, String realm, String password, String httpMethod, String uri, String qop, String nonce, String nc, String cnonce) throws IllegalArgumentException {
/* 106 */     String a2 = httpMethod + ":" + httpMethod;
/*     */     
/* 108 */     String a1Md5 = !passwordAlreadyEncoded ? encodePasswordInA1Format(username, realm, password) : password;
/* 109 */     String a2Md5 = md5Hex(a2);
/* 110 */     if (qop == null)
/*     */     {
/* 112 */       return md5Hex(a1Md5 + ":" + a1Md5 + ":" + nonce);
/*     */     }
/* 114 */     if ("auth".equals(qop))
/*     */     {
/* 116 */       return md5Hex(a1Md5 + ":" + a1Md5 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop);
/*     */     }
/* 118 */     throw new IllegalArgumentException("This method does not support a qop: '" + qop + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Map<String, String> splitEachArrayElementAndCreateMap(String[] array, String delimiter, String removeCharacters) {
/* 139 */     if (array == null || array.length == 0) {
/* 140 */       return null;
/*     */     }
/* 142 */     Map<String, String> map = new HashMap<>();
/* 143 */     for (String s : array) {
/* 144 */       String postRemove = (removeCharacters != null) ? StringUtils.replace(s, removeCharacters, "") : s;
/* 145 */       String[] splitThisArrayElement = split(postRemove, delimiter);
/* 146 */       if (splitThisArrayElement != null)
/*     */       {
/*     */         
/* 149 */         map.put(splitThisArrayElement[0].trim(), splitThisArrayElement[1].trim()); } 
/*     */     } 
/* 151 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] split(String toSplit, String delimiter) {
/* 166 */     Assert.hasLength(toSplit, "Cannot split a null or empty string");
/* 167 */     Assert.hasLength(delimiter, "Cannot use a null or empty delimiter to split a string");
/* 168 */     Assert.isTrue((delimiter.length() == 1), "Delimiter can only be one character in length");
/* 169 */     int offset = toSplit.indexOf(delimiter);
/* 170 */     if (offset < 0) {
/* 171 */       return null;
/*     */     }
/* 173 */     String beforeDelimiter = toSplit.substring(0, offset);
/* 174 */     String afterDelimiter = toSplit.substring(offset + 1);
/* 175 */     return new String[] { beforeDelimiter, afterDelimiter };
/*     */   }
/*     */   
/*     */   static String md5Hex(String data) {
/*     */     try {
/* 180 */       MessageDigest digest = MessageDigest.getInstance("MD5");
/* 181 */       return new String(Hex.encode(digest.digest(data.getBytes())));
/*     */     }
/* 183 */     catch (NoSuchAlgorithmException ex) {
/* 184 */       throw new IllegalStateException("No MD5 algorithm available!");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\DigestAuthUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */