/*     */ package org.springframework.security.web.authentication.rememberme;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Date;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcTokenRepositoryImpl
/*     */   extends JdbcDaoSupport
/*     */   implements PersistentTokenRepository
/*     */ {
/*     */   public static final String CREATE_TABLE_SQL = "create table persistent_logins (username varchar(64) not null, series varchar(64) primary key, token varchar(64) not null, last_used timestamp not null)";
/*     */   public static final String DEF_TOKEN_BY_SERIES_SQL = "select username,series,token,last_used from persistent_logins where series = ?";
/*     */   public static final String DEF_INSERT_TOKEN_SQL = "insert into persistent_logins (username, series, token, last_used) values(?,?,?,?)";
/*     */   public static final String DEF_UPDATE_TOKEN_SQL = "update persistent_logins set token = ?, last_used = ? where series = ?";
/*     */   public static final String DEF_REMOVE_USER_TOKENS_SQL = "delete from persistent_logins where username = ?";
/*  53 */   private String tokensBySeriesSql = "select username,series,token,last_used from persistent_logins where series = ?";
/*     */   
/*  55 */   private String insertTokenSql = "insert into persistent_logins (username, series, token, last_used) values(?,?,?,?)";
/*     */   
/*  57 */   private String updateTokenSql = "update persistent_logins set token = ?, last_used = ? where series = ?";
/*     */   
/*  59 */   private String removeUserTokensSql = "delete from persistent_logins where username = ?";
/*     */   
/*     */   private boolean createTableOnStartup;
/*     */ 
/*     */   
/*     */   protected void initDao() {
/*  65 */     if (this.createTableOnStartup) {
/*  66 */       getJdbcTemplate().execute("create table persistent_logins (username varchar(64) not null, series varchar(64) primary key, token varchar(64) not null, last_used timestamp not null)");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void createNewToken(PersistentRememberMeToken token) {
/*  72 */     getJdbcTemplate().update(this.insertTokenSql, new Object[] { token.getUsername(), token.getSeries(), token.getTokenValue(), token
/*  73 */           .getDate() });
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateToken(String series, String tokenValue, Date lastUsed) {
/*  78 */     getJdbcTemplate().update(this.updateTokenSql, new Object[] { tokenValue, lastUsed, series });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentRememberMeToken getTokenForSeries(String seriesId) {
/*     */     try {
/*  93 */       return (PersistentRememberMeToken)getJdbcTemplate().queryForObject(this.tokensBySeriesSql, this::createRememberMeToken, new Object[] { seriesId });
/*     */     }
/*  95 */     catch (EmptyResultDataAccessException ex) {
/*  96 */       this.logger.debug(LogMessage.format("Querying token for series '%s' returned no results.", seriesId), (Throwable)ex);
/*     */     }
/*  98 */     catch (IncorrectResultSizeDataAccessException ex) {
/*  99 */       this.logger.error(LogMessage.format("Querying token for series '%s' returned more than one value. Series should be unique", seriesId));
/*     */ 
/*     */     
/*     */     }
/* 103 */     catch (DataAccessException ex) {
/* 104 */       this.logger.error("Failed to load token for series " + seriesId, (Throwable)ex);
/*     */     } 
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   private PersistentRememberMeToken createRememberMeToken(ResultSet rs, int rowNum) throws SQLException {
/* 110 */     return new PersistentRememberMeToken(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeUserTokens(String username) {
/* 115 */     getJdbcTemplate().update(this.removeUserTokensSql, new Object[] { username });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCreateTableOnStartup(boolean createTableOnStartup) {
/* 124 */     this.createTableOnStartup = createTableOnStartup;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\JdbcTokenRepositoryImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */