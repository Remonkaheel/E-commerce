package org.springframework.security.web.authentication.session;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationEventPublisher;

public final class NullEventPublisher implements ApplicationEventPublisher {
  public void publishEvent(ApplicationEvent event) {}
  
  public void publishEvent(Object event) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\AbstractSessionFixationProtectionStrategy$NullEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */