/*    */ package org.springframework.security.web.authentication.preauth.websphere;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebSpherePreAuthenticatedProcessingFilter
/*    */   extends AbstractPreAuthenticatedProcessingFilter
/*    */ {
/*    */   private final WASUsernameAndGroupsExtractor wasHelper;
/*    */   
/*    */   public WebSpherePreAuthenticatedProcessingFilter() {
/* 41 */     this(new DefaultWASUsernameAndGroupsExtractor());
/*    */   }
/*    */   
/*    */   WebSpherePreAuthenticatedProcessingFilter(WASUsernameAndGroupsExtractor wasHelper) {
/* 45 */     this.wasHelper = wasHelper;
/* 46 */     setAuthenticationDetailsSource(new WebSpherePreAuthenticatedWebAuthenticationDetailsSource());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedPrincipal(HttpServletRequest httpRequest) {
/* 54 */     Object principal = this.wasHelper.getCurrentUserName();
/* 55 */     this.logger.debug(LogMessage.format("PreAuthenticated WebSphere principal: %s", principal));
/* 56 */     return principal;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedCredentials(HttpServletRequest httpRequest) {
/* 65 */     return "N/A";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\websphere\WebSpherePreAuthenticatedProcessingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */