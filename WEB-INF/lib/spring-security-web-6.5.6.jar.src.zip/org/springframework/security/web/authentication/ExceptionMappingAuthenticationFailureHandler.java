/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.util.UrlUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionMappingAuthenticationFailureHandler
/*    */   extends SimpleUrlAuthenticationFailureHandler
/*    */ {
/* 46 */   private final Map<String, String> failureUrlMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
/* 51 */     String url = this.failureUrlMap.get(exception.getClass().getName());
/* 52 */     if (url != null) {
/* 53 */       getRedirectStrategy().sendRedirect(request, response, url);
/*    */     } else {
/*    */       
/* 56 */       super.onAuthenticationFailure(request, response, exception);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExceptionMappings(Map<?, ?> failureUrlMap) {
/* 68 */     this.failureUrlMap.clear();
/* 69 */     for (Map.Entry<?, ?> entry : failureUrlMap.entrySet()) {
/* 70 */       Object exception = entry.getKey();
/* 71 */       Object url = entry.getValue();
/* 72 */       Assert.isInstanceOf(String.class, exception, "Exception key must be a String (the exception classname).");
/* 73 */       Assert.isInstanceOf(String.class, url, "URL must be a String");
/* 74 */       Assert.isTrue(UrlUtils.isValidRedirectUrl((String)url), () -> "Not a valid redirect URL: " + String.valueOf(url));
/* 75 */       this.failureUrlMap.put((String)exception, (String)url);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ExceptionMappingAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */