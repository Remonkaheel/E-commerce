/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.InternalAuthenticationServiceException;
/*     */ import org.springframework.security.authentication.event.InteractiveAuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAuthenticationProcessingFilter
/*     */   extends GenericFilterBean
/*     */   implements ApplicationEventPublisherAware, MessageSourceAware
/*     */ {
/* 120 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   protected ApplicationEventPublisher eventPublisher;
/*     */   
/* 124 */   protected AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
/*     */ 
/*     */   
/*     */   private AuthenticationConverter authenticationConverter = request -> {
/*     */       throw new AuthenticationCredentialsNotFoundException("Please either configure an AuthenticationConverter or override attemptAuthentication when extending AbstractAuthenticationProcessingFilter");
/*     */     };
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/* 133 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/* 135 */   private RememberMeServices rememberMeServices = new NullRememberMeServices();
/*     */   
/*     */   private RequestMatcher requiresAuthenticationRequestMatcher;
/*     */   
/*     */   private boolean continueChainBeforeSuccessfulAuthentication = false;
/*     */   
/*     */   private boolean continueChainWhenNoAuthenticationResult;
/*     */   
/* 143 */   private SessionAuthenticationStrategy sessionStrategy = (SessionAuthenticationStrategy)new NullAuthenticatedSessionStrategy();
/*     */   
/*     */   private boolean allowSessionCreation = true;
/*     */   
/* 147 */   private AuthenticationSuccessHandler successHandler = new SavedRequestAwareAuthenticationSuccessHandler();
/*     */   
/* 149 */   private AuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
/*     */   
/* 151 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new RequestAttributeSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationProcessingFilter(String defaultFilterProcessesUrl) {
/* 157 */     setFilterProcessesUrl(defaultFilterProcessesUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationProcessingFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
/* 166 */     Assert.notNull(requiresAuthenticationRequestMatcher, "requiresAuthenticationRequestMatcher cannot be null");
/* 167 */     this.requiresAuthenticationRequestMatcher = requiresAuthenticationRequestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationProcessingFilter(String defaultFilterProcessesUrl, AuthenticationManager authenticationManager) {
/* 179 */     setFilterProcessesUrl(defaultFilterProcessesUrl);
/* 180 */     setAuthenticationManager(authenticationManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationProcessingFilter(RequestMatcher requiresAuthenticationRequestMatcher, AuthenticationManager authenticationManager) {
/* 193 */     setRequiresAuthenticationRequestMatcher(requiresAuthenticationRequestMatcher);
/* 194 */     setAuthenticationManager(authenticationManager);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 199 */     Assert.notNull(this.authenticationManager, "authenticationManager must be specified");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 229 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 234 */     if (!requiresAuthentication(request, response)) {
/* 235 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*     */     try {
/* 239 */       Authentication authenticationResult = attemptAuthentication(request, response);
/* 240 */       if (authenticationResult == null) {
/* 241 */         if (this.continueChainWhenNoAuthenticationResult) {
/* 242 */           chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */           
/*     */           return;
/*     */         } 
/*     */         return;
/*     */       } 
/* 248 */       this.sessionStrategy.onAuthentication(authenticationResult, request, response);
/*     */       
/* 250 */       if (this.continueChainBeforeSuccessfulAuthentication) {
/* 251 */         chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       }
/* 253 */       successfulAuthentication(request, response, chain, authenticationResult);
/*     */     }
/* 255 */     catch (InternalAuthenticationServiceException failed) {
/* 256 */       this.logger.error("An internal error occurred while trying to authenticate the user.", (Throwable)failed);
/* 257 */       unsuccessfulAuthentication(request, response, (AuthenticationException)failed);
/*     */     }
/* 259 */     catch (AuthenticationException ex) {
/*     */       
/* 261 */       unsuccessfulAuthentication(request, response, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean requiresAuthentication(HttpServletRequest request, HttpServletResponse response) {
/* 278 */     if (this.requiresAuthenticationRequestMatcher.matches(request)) {
/* 279 */       return true;
/*     */     }
/* 281 */     if (this.logger.isTraceEnabled()) {
/* 282 */       this.logger
/* 283 */         .trace(LogMessage.format("Did not match request to %s", this.requiresAuthenticationRequestMatcher));
/*     */     }
/* 285 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
/* 309 */     Authentication authentication = this.authenticationConverter.convert(request);
/* 310 */     if (authentication == null) {
/* 311 */       return null;
/*     */     }
/* 313 */     Authentication result = this.authenticationManager.authenticate(authentication);
/* 314 */     if (result == null) {
/* 315 */       throw new ServletException("AuthenticationManager should not return null Authentication object.");
/*     */     }
/* 317 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException, ServletException {
/* 344 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 345 */     context.setAuthentication(authResult);
/* 346 */     this.securityContextHolderStrategy.setContext(context);
/* 347 */     this.securityContextRepository.saveContext(context, request, response);
/* 348 */     if (this.logger.isDebugEnabled()) {
/* 349 */       this.logger.debug(LogMessage.format("Set SecurityContextHolder to %s", authResult));
/*     */     }
/* 351 */     this.rememberMeServices.loginSuccess(request, response, authResult);
/* 352 */     if (this.eventPublisher != null) {
/* 353 */       this.eventPublisher.publishEvent((ApplicationEvent)new InteractiveAuthenticationSuccessEvent(authResult, getClass()));
/*     */     }
/* 355 */     this.successHandler.onAuthenticationSuccess(request, response, authResult);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
/* 371 */     this.securityContextHolderStrategy.clearContext();
/* 372 */     this.logger.trace("Failed to process authentication request", (Throwable)failed);
/* 373 */     this.logger.trace("Cleared SecurityContextHolder");
/* 374 */     this.logger.trace("Handling authentication failure");
/* 375 */     this.rememberMeServices.loginFail(request, response);
/* 376 */     this.failureHandler.onAuthenticationFailure(request, response, failed);
/*     */   }
/*     */   
/*     */   public void setAuthenticationConverter(AuthenticationConverter authenticationConverter) {
/* 380 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 381 */     this.authenticationConverter = authenticationConverter;
/* 382 */     this.continueChainWhenNoAuthenticationResult = true;
/*     */   }
/*     */   
/*     */   protected AuthenticationManager getAuthenticationManager() {
/* 386 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 390 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterProcessesUrl(String filterProcessesUrl) {
/* 398 */     setRequiresAuthenticationRequestMatcher((RequestMatcher)new AntPathRequestMatcher(filterProcessesUrl));
/*     */   }
/*     */   
/*     */   public final void setRequiresAuthenticationRequestMatcher(RequestMatcher requestMatcher) {
/* 402 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null or empty");
/* 403 */     this.requiresAuthenticationRequestMatcher = requestMatcher;
/*     */   }
/*     */   
/*     */   public RememberMeServices getRememberMeServices() {
/* 407 */     return this.rememberMeServices;
/*     */   }
/*     */   
/*     */   public void setRememberMeServices(RememberMeServices rememberMeServices) {
/* 411 */     Assert.notNull(rememberMeServices, "rememberMeServices cannot be null");
/* 412 */     this.rememberMeServices = rememberMeServices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContinueChainBeforeSuccessfulAuthentication(boolean continueChainBeforeSuccessfulAuthentication) {
/* 422 */     this.continueChainBeforeSuccessfulAuthentication = continueChainBeforeSuccessfulAuthentication;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher eventPublisher) {
/* 427 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 432 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/* 433 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 438 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   protected boolean getAllowSessionCreation() {
/* 442 */     return this.allowSessionCreation;
/*     */   }
/*     */   
/*     */   public void setAllowSessionCreation(boolean allowSessionCreation) {
/* 446 */     this.allowSessionCreation = allowSessionCreation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAuthenticationStrategy(SessionAuthenticationStrategy sessionStrategy) {
/* 458 */     this.sessionStrategy = sessionStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationSuccessHandler(AuthenticationSuccessHandler successHandler) {
/* 466 */     Assert.notNull(successHandler, "successHandler cannot be null");
/* 467 */     this.successHandler = successHandler;
/*     */   }
/*     */   
/*     */   public void setAuthenticationFailureHandler(AuthenticationFailureHandler failureHandler) {
/* 471 */     Assert.notNull(failureHandler, "failureHandler cannot be null");
/* 472 */     this.failureHandler = failureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 483 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 484 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 494 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 495 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   protected AuthenticationSuccessHandler getSuccessHandler() {
/* 499 */     return this.successHandler;
/*     */   }
/*     */   
/*     */   protected AuthenticationFailureHandler getFailureHandler() {
/* 503 */     return this.failureHandler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\AbstractAuthenticationProcessingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */