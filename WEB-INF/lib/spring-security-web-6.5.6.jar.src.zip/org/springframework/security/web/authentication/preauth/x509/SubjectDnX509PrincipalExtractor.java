/*    */ package org.springframework.security.web.authentication.preauth.x509;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.authentication.BadCredentialsException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubjectDnX509PrincipalExtractor
/*    */   implements X509PrincipalExtractor, MessageSourceAware
/*    */ {
/* 49 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 51 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   private Pattern subjectDnPattern;
/*    */   
/*    */   public SubjectDnX509PrincipalExtractor() {
/* 56 */     setSubjectDnRegex("CN=(.*?)(?:,|$)");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object extractPrincipal(X509Certificate clientCert) {
/* 62 */     String subjectDN = clientCert.getSubjectDN().getName();
/* 63 */     this.logger.debug(LogMessage.format("Subject DN is '%s'", subjectDN));
/* 64 */     Matcher matcher = this.subjectDnPattern.matcher(subjectDN);
/* 65 */     if (!matcher.find()) {
/* 66 */       throw new BadCredentialsException(this.messages.getMessage("SubjectDnX509PrincipalExtractor.noMatching", new Object[] { subjectDN }, "No matching pattern was found in subject DN: {0}"));
/*    */     }
/*    */     
/* 69 */     Assert.isTrue((matcher.groupCount() == 1), "Regular expression must contain a single group ");
/* 70 */     String username = matcher.group(1);
/* 71 */     this.logger.debug(LogMessage.format("Extracted Principal name is '%s'", username));
/* 72 */     return username;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSubjectDnRegex(String subjectDnRegex) {
/* 88 */     Assert.hasText(subjectDnRegex, "Regular expression may not be null or empty");
/* 89 */     this.subjectDnPattern = Pattern.compile(subjectDnRegex, 2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 97 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 98 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\x509\SubjectDnX509PrincipalExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */