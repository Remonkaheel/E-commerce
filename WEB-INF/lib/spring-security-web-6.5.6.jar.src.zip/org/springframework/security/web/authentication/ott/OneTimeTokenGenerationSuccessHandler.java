package org.springframework.security.web.authentication.ott;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.authentication.ott.OneTimeToken;

@FunctionalInterface
public interface OneTimeTokenGenerationSuccessHandler {
  void handle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, OneTimeToken paramOneTimeToken) throws IOException, ServletException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\OneTimeTokenGenerationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */