package org.springframework.security.web.authentication.session;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;

public final class NullAuthenticatedSessionStrategy implements SessionAuthenticationStrategy {
  public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\NullAuthenticatedSessionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */