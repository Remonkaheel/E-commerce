/*    */ package org.springframework.security.web.authentication.logout;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompositeLogoutHandler
/*    */   implements LogoutHandler
/*    */ {
/*    */   private final List<LogoutHandler> logoutHandlers;
/*    */   
/*    */   public CompositeLogoutHandler(LogoutHandler... logoutHandlers) {
/* 42 */     Assert.notEmpty((Object[])logoutHandlers, "LogoutHandlers are required");
/* 43 */     this.logoutHandlers = Arrays.asList(logoutHandlers);
/*    */   }
/*    */   
/*    */   public CompositeLogoutHandler(List<LogoutHandler> logoutHandlers) {
/* 47 */     Assert.notEmpty(logoutHandlers, "LogoutHandlers are required");
/* 48 */     this.logoutHandlers = logoutHandlers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 53 */     for (LogoutHandler handler : this.logoutHandlers)
/* 54 */       handler.logout(request, response, authentication); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\CompositeLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */