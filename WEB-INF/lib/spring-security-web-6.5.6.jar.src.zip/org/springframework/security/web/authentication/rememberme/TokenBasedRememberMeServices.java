/*     */ package org.springframework.security.web.authentication.rememberme;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenBasedRememberMeServices
/*     */   extends AbstractRememberMeServices
/*     */ {
/*  97 */   private static final RememberMeTokenAlgorithm DEFAULT_MATCHING_ALGORITHM = RememberMeTokenAlgorithm.SHA256;
/*     */   
/*  99 */   private static final RememberMeTokenAlgorithm DEFAULT_ENCODING_ALGORITHM = RememberMeTokenAlgorithm.SHA256;
/*     */   
/*     */   private final RememberMeTokenAlgorithm encodingAlgorithm;
/*     */   
/* 103 */   private RememberMeTokenAlgorithm matchingAlgorithm = DEFAULT_MATCHING_ALGORITHM;
/*     */   
/*     */   public TokenBasedRememberMeServices(String key, UserDetailsService userDetailsService) {
/* 106 */     this(key, userDetailsService, DEFAULT_ENCODING_ALGORITHM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenBasedRememberMeServices(String key, UserDetailsService userDetailsService, RememberMeTokenAlgorithm encodingAlgorithm) {
/* 119 */     super(key, userDetailsService);
/* 120 */     Assert.notNull(encodingAlgorithm, "encodingAlgorithm cannot be null");
/* 121 */     this.encodingAlgorithm = encodingAlgorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request, HttpServletResponse response) {
/* 127 */     if (!isValidCookieTokensLength(cookieTokens)) {
/* 128 */       throw new InvalidCookieException("Cookie token did not contain 3 or 4 tokens, but contained '" + 
/* 129 */           String.valueOf(Arrays.asList(cookieTokens)) + "'");
/*     */     }
/* 131 */     long tokenExpiryTime = getTokenExpiryTime(cookieTokens);
/* 132 */     if (isTokenExpired(tokenExpiryTime)) {
/* 133 */       throw new InvalidCookieException("Cookie token[1] has expired (expired on '" + String.valueOf(new Date(tokenExpiryTime)) + "'; current time is '" + String.valueOf(new Date()) + "')");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 138 */     UserDetails userDetails = getUserDetailsService().loadUserByUsername(cookieTokens[0]);
/* 139 */     Assert.notNull(userDetails, () -> "UserDetailsService " + String.valueOf(getUserDetailsService()) + " returned null for username " + cookieTokens[0] + ". This is an interface contract violation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     String actualTokenSignature = cookieTokens[2];
/* 148 */     RememberMeTokenAlgorithm actualAlgorithm = this.matchingAlgorithm;
/*     */ 
/*     */     
/* 151 */     if (cookieTokens.length == 4) {
/* 152 */       actualTokenSignature = cookieTokens[3];
/* 153 */       actualAlgorithm = RememberMeTokenAlgorithm.valueOf(cookieTokens[2]);
/*     */     } 
/* 155 */     String expectedTokenSignature = makeTokenSignature(tokenExpiryTime, userDetails.getUsername(), userDetails
/* 156 */         .getPassword(), actualAlgorithm);
/* 157 */     if (!equals(expectedTokenSignature, actualTokenSignature)) {
/* 158 */       throw new InvalidCookieException("Cookie contained signature '" + actualTokenSignature + "' but expected '" + expectedTokenSignature + "'");
/*     */     }
/*     */     
/* 161 */     return userDetails;
/*     */   }
/*     */   
/*     */   private boolean isValidCookieTokensLength(String[] cookieTokens) {
/* 165 */     return (cookieTokens.length == 3 || cookieTokens.length == 4);
/*     */   }
/*     */   
/*     */   private long getTokenExpiryTime(String[] cookieTokens) {
/*     */     try {
/* 170 */       return Long.valueOf(cookieTokens[1]).longValue();
/*     */     }
/* 172 */     catch (NumberFormatException nfe) {
/* 173 */       throw new InvalidCookieException("Cookie token[1] did not contain a valid number (contained '" + cookieTokens[1] + "')");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String makeTokenSignature(long tokenExpiryTime, String username, String password) {
/* 183 */     String data = username + ":" + username + ":" + tokenExpiryTime + ":" + password;
/*     */     try {
/* 185 */       MessageDigest digest = MessageDigest.getInstance(this.encodingAlgorithm.getDigestAlgorithm());
/* 186 */       return new String(Hex.encode(digest.digest(data.getBytes())));
/*     */     }
/* 188 */     catch (NoSuchAlgorithmException ex) {
/* 189 */       throw new IllegalStateException("No " + this.encodingAlgorithm.name() + " algorithm available!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String makeTokenSignature(long tokenExpiryTime, String username, String password, RememberMeTokenAlgorithm algorithm) {
/* 199 */     String data = username + ":" + username + ":" + tokenExpiryTime + ":" + password;
/*     */     try {
/* 201 */       MessageDigest digest = MessageDigest.getInstance(algorithm.getDigestAlgorithm());
/* 202 */       return new String(Hex.encode(digest.digest(data.getBytes())));
/*     */     }
/* 204 */     catch (NoSuchAlgorithmException ex) {
/* 205 */       throw new IllegalStateException("No " + algorithm.name() + " algorithm available!");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isTokenExpired(long tokenExpiryTime) {
/* 210 */     return (tokenExpiryTime < System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLoginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {
/* 216 */     String username = retrieveUserName(successfulAuthentication);
/* 217 */     String password = retrievePassword(successfulAuthentication);
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (!StringUtils.hasLength(username)) {
/* 222 */       this.logger.debug("Unable to retrieve username");
/*     */       return;
/*     */     } 
/* 225 */     if (!StringUtils.hasLength(password)) {
/* 226 */       UserDetails user = getUserDetailsService().loadUserByUsername(username);
/* 227 */       password = user.getPassword();
/* 228 */       if (!StringUtils.hasLength(password)) {
/* 229 */         this.logger.debug("Unable to obtain password for user: " + username);
/*     */         return;
/*     */       } 
/*     */     } 
/* 233 */     int tokenLifetime = calculateLoginLifetime(request, successfulAuthentication);
/* 234 */     long expiryTime = System.currentTimeMillis();
/*     */     
/* 236 */     expiryTime += 1000L * ((tokenLifetime < 0) ? 1209600L : tokenLifetime);
/* 237 */     String signatureValue = makeTokenSignature(expiryTime, username, password, this.encodingAlgorithm);
/* 238 */     setCookie(new String[] { username, Long.toString(expiryTime), this.encodingAlgorithm.name(), signatureValue }, tokenLifetime, request, response);
/*     */     
/* 240 */     if (this.logger.isDebugEnabled()) {
/* 241 */       this.logger
/* 242 */         .debug("Added remember-me cookie for user '" + username + "', expiry: '" + String.valueOf(new Date(expiryTime)) + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchingAlgorithm(RememberMeTokenAlgorithm matchingAlgorithm) {
/* 252 */     Assert.notNull(matchingAlgorithm, "matchingAlgorithm cannot be null");
/* 253 */     this.matchingAlgorithm = matchingAlgorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int calculateLoginLifetime(HttpServletRequest request, Authentication authentication) {
/* 272 */     return getTokenValiditySeconds();
/*     */   }
/*     */   
/*     */   protected String retrieveUserName(Authentication authentication) {
/* 276 */     if (isInstanceOfUserDetails(authentication)) {
/* 277 */       return ((UserDetails)authentication.getPrincipal()).getUsername();
/*     */     }
/* 279 */     return authentication.getPrincipal().toString();
/*     */   }
/*     */   
/*     */   protected String retrievePassword(Authentication authentication) {
/* 283 */     if (isInstanceOfUserDetails(authentication)) {
/* 284 */       return ((UserDetails)authentication.getPrincipal()).getPassword();
/*     */     }
/* 286 */     if (authentication.getCredentials() != null) {
/* 287 */       return authentication.getCredentials().toString();
/*     */     }
/* 289 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isInstanceOfUserDetails(Authentication authentication) {
/* 293 */     return authentication.getPrincipal() instanceof UserDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equals(String expected, String actual) {
/* 300 */     byte[] expectedBytes = bytesUtf8(expected);
/* 301 */     byte[] actualBytes = bytesUtf8(actual);
/* 302 */     return MessageDigest.isEqual(expectedBytes, actualBytes);
/*     */   }
/*     */   
/*     */   private static byte[] bytesUtf8(String s) {
/* 306 */     return (s != null) ? Utf8.encode(s) : null;
/*     */   }
/*     */   
/*     */   public enum RememberMeTokenAlgorithm
/*     */   {
/* 311 */     MD5("MD5"), SHA256("SHA-256");
/*     */     
/*     */     private final String digestAlgorithm;
/*     */     
/*     */     RememberMeTokenAlgorithm(String digestAlgorithm) {
/* 316 */       this.digestAlgorithm = digestAlgorithm;
/*     */     }
/*     */     
/*     */     public String getDigestAlgorithm() {
/* 320 */       return this.digestAlgorithm;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\TokenBasedRememberMeServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */