/*     */ package org.springframework.security.web.authentication.ui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Builder
/*     */ {
/*     */   private final String template;
/*  47 */   private final Map<String, String> values = new HashMap<>();
/*     */   
/*     */   private Builder(String template) {
/*  50 */     this.template = template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Builder withValue(String key, String value) {
/*  61 */     this.values.put(key, HtmlUtils.htmlEscape(value));
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Builder withRawHtml(String key, String value) {
/*  73 */     if (!value.isEmpty() && value.charAt(value.length() - 1) == '\n') {
/*  74 */       value = value.substring(0, value.length() - 1);
/*     */     }
/*  76 */     this.values.put(key, value);
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String render() {
/*  87 */     String template = this.template;
/*  88 */     for (String key : this.values.keySet()) {
/*  89 */       String pattern = Pattern.quote("{{" + key + "}}");
/*  90 */       template = template.replaceAll(pattern, this.values.get(key));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     String unusedPlaceholders = Pattern.compile("\\{\\{([a-zA-Z0-9]+)}}").matcher(template).results().<CharSequence>map(result -> result.group(1)).collect(Collectors.joining(", "));
/*  98 */     if (StringUtils.hasLength(unusedPlaceholders)) {
/*  99 */       throw new IllegalStateException("Unused placeholders in template: [%s]".formatted(new Object[] { unusedPlaceholders }));
/*     */     }
/*     */     
/* 102 */     return template;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authenticatio\\ui\HtmlTemplates$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */