/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAuthenticationTargetUrlRequestHandler
/*     */ {
/*  63 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  65 */   private String targetUrlParameter = null;
/*     */   
/*  67 */   private String defaultTargetUrl = "/";
/*     */   
/*     */   private boolean alwaysUseDefaultTargetUrl = false;
/*     */   
/*     */   private boolean useReferer = false;
/*     */   
/*  73 */   private RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
/*  86 */     String targetUrl = determineTargetUrl(request, response, authentication);
/*  87 */     if (response.isCommitted()) {
/*  88 */       this.logger.debug(LogMessage.format("Did not redirect to %s since response already committed.", targetUrl));
/*     */       return;
/*     */     } 
/*  91 */     this.redirectStrategy.sendRedirect(request, response, targetUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 100 */     return determineTargetUrl(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response) {
/* 107 */     if (isAlwaysUseDefaultTargetUrl()) {
/* 108 */       return this.defaultTargetUrl;
/*     */     }
/* 110 */     String targetUrlParameterValue = getTargetUrlParameterValue(request);
/* 111 */     if (StringUtils.hasText(targetUrlParameterValue)) {
/* 112 */       trace("Using url %s from request parameter %s", new String[] { targetUrlParameterValue, this.targetUrlParameter });
/* 113 */       return targetUrlParameterValue;
/*     */     } 
/* 115 */     if (this.useReferer) {
/* 116 */       trace("Using url %s from Referer header", new String[] { request.getHeader("Referer") });
/* 117 */       return request.getHeader("Referer");
/*     */     } 
/* 119 */     return this.defaultTargetUrl;
/*     */   }
/*     */   
/*     */   private String getTargetUrlParameterValue(HttpServletRequest request) {
/* 123 */     if (this.targetUrlParameter == null) {
/* 124 */       return null;
/*     */     }
/* 126 */     String value = request.getParameter(this.targetUrlParameter);
/* 127 */     if (value == null) {
/* 128 */       return null;
/*     */     }
/* 130 */     if (StringUtils.hasText(value)) {
/* 131 */       return value;
/*     */     }
/* 133 */     return this.defaultTargetUrl;
/*     */   }
/*     */   
/*     */   private void trace(String msg, String... msgParts) {
/* 137 */     if (this.logger.isTraceEnabled()) {
/* 138 */       this.logger.trace(LogMessage.format(msg, (Object[])msgParts));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getDefaultTargetUrl() {
/* 149 */     return this.defaultTargetUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultTargetUrl(String defaultTargetUrl) {
/* 162 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(defaultTargetUrl), "defaultTarget must start with '/' or with 'http(s)'");
/*     */     
/* 164 */     this.defaultTargetUrl = defaultTargetUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysUseDefaultTargetUrl(boolean alwaysUseDefaultTargetUrl) {
/* 172 */     this.alwaysUseDefaultTargetUrl = alwaysUseDefaultTargetUrl;
/*     */   }
/*     */   
/*     */   protected boolean isAlwaysUseDefaultTargetUrl() {
/* 176 */     return this.alwaysUseDefaultTargetUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetUrlParameter(String targetUrlParameter) {
/* 186 */     if (targetUrlParameter != null) {
/* 187 */       Assert.hasText(targetUrlParameter, "targetUrlParameter cannot be empty");
/*     */     }
/* 189 */     this.targetUrlParameter = targetUrlParameter;
/*     */   }
/*     */   
/*     */   protected String getTargetUrlParameter() {
/* 193 */     return this.targetUrlParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
/* 201 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 202 */     this.redirectStrategy = redirectStrategy;
/*     */   }
/*     */   
/*     */   protected RedirectStrategy getRedirectStrategy() {
/* 206 */     return this.redirectStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseReferer(boolean useReferer) {
/* 214 */     this.useReferer = useReferer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\AbstractAuthenticationTargetUrlRequestHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */