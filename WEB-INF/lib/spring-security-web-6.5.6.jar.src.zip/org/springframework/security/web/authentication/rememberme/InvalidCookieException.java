/*    */ package org.springframework.security.web.authentication.rememberme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidCookieException
/*    */   extends RememberMeAuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = -7952247791921087125L;
/*    */   
/*    */   public InvalidCookieException(String message) {
/* 33 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\InvalidCookieException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */