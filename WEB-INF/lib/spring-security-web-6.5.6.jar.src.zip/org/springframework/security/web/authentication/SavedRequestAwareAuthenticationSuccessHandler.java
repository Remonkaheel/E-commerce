/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*    */ import org.springframework.security.web.savedrequest.RequestCache;
/*    */ import org.springframework.security.web.savedrequest.SavedRequest;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SavedRequestAwareAuthenticationSuccessHandler
/*    */   extends SimpleUrlAuthenticationSuccessHandler
/*    */ {
/* 68 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 70 */   private RequestCache requestCache = (RequestCache)new HttpSessionRequestCache();
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws ServletException, IOException {
/* 75 */     SavedRequest savedRequest = this.requestCache.getRequest(request, response);
/* 76 */     if (savedRequest == null) {
/* 77 */       super.onAuthenticationSuccess(request, response, authentication);
/*    */       return;
/*    */     } 
/* 80 */     String targetUrlParameter = getTargetUrlParameter();
/* 81 */     if (isAlwaysUseDefaultTargetUrl() || (targetUrlParameter != null && 
/* 82 */       StringUtils.hasText(request.getParameter(targetUrlParameter)))) {
/* 83 */       this.requestCache.removeRequest(request, response);
/* 84 */       super.onAuthenticationSuccess(request, response, authentication);
/*    */       return;
/*    */     } 
/* 87 */     clearAuthenticationAttributes(request);
/*    */     
/* 89 */     String targetUrl = savedRequest.getRedirectUrl();
/* 90 */     getRedirectStrategy().sendRedirect(request, response, targetUrl);
/*    */   }
/*    */   
/*    */   public void setRequestCache(RequestCache requestCache) {
/* 94 */     this.requestCache = requestCache;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\SavedRequestAwareAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */