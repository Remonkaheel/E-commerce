/*    */ package org.springframework.security.web.authentication.logout;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.ApplicationEventPublisherAware;
/*    */ import org.springframework.security.authentication.event.LogoutSuccessEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LogoutSuccessEventPublishingLogoutHandler
/*    */   implements LogoutHandler, ApplicationEventPublisherAware
/*    */ {
/*    */   private ApplicationEventPublisher eventPublisher;
/*    */   
/*    */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 39 */     if (this.eventPublisher == null) {
/*    */       return;
/*    */     }
/* 42 */     if (authentication == null) {
/*    */       return;
/*    */     }
/* 45 */     this.eventPublisher.publishEvent((ApplicationEvent)new LogoutSuccessEvent(authentication));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 50 */     this.eventPublisher = applicationEventPublisher;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\LogoutSuccessEventPublishingLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */