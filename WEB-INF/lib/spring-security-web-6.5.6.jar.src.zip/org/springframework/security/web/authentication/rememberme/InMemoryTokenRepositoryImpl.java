/*    */ package org.springframework.security.web.authentication.rememberme;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import org.springframework.dao.DataIntegrityViolationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryTokenRepositoryImpl
/*    */   implements PersistentTokenRepository
/*    */ {
/* 34 */   private final Map<String, PersistentRememberMeToken> seriesTokens = new HashMap<>();
/*    */ 
/*    */   
/*    */   public synchronized void createNewToken(PersistentRememberMeToken token) {
/* 38 */     PersistentRememberMeToken current = this.seriesTokens.get(token.getSeries());
/* 39 */     if (current != null) {
/* 40 */       throw new DataIntegrityViolationException("Series Id '" + token.getSeries() + "' already exists!");
/*    */     }
/* 42 */     this.seriesTokens.put(token.getSeries(), token);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void updateToken(String series, String tokenValue, Date lastUsed) {
/* 47 */     PersistentRememberMeToken token = getTokenForSeries(series);
/* 48 */     PersistentRememberMeToken newToken = new PersistentRememberMeToken(token.getUsername(), series, tokenValue, new Date());
/*    */ 
/*    */     
/* 51 */     this.seriesTokens.put(series, newToken);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized PersistentRememberMeToken getTokenForSeries(String seriesId) {
/* 56 */     return this.seriesTokens.get(seriesId);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void removeUserTokens(String username) {
/* 61 */     Iterator<String> series = this.seriesTokens.keySet().iterator();
/* 62 */     while (series.hasNext()) {
/* 63 */       String seriesId = series.next();
/* 64 */       PersistentRememberMeToken token = this.seriesTokens.get(seriesId);
/* 65 */       if (username.equals(token.getUsername()))
/* 66 */         series.remove(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\InMemoryTokenRepositoryImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */