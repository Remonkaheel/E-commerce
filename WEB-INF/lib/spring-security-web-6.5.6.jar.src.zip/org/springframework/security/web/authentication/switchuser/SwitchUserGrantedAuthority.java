/*    */ package org.springframework.security.web.authentication.switchuser;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SwitchUserGrantedAuthority
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final String role;
/*    */   private final Authentication source;
/*    */   
/*    */   public SwitchUserGrantedAuthority(String role, Authentication source) {
/* 43 */     Assert.notNull(role, "role cannot be null");
/* 44 */     Assert.notNull(source, "source cannot be null");
/* 45 */     this.role = role;
/* 46 */     this.source = source;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getSource() {
/* 54 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAuthority() {
/* 59 */     return this.role;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 64 */     if (this == obj) {
/* 65 */       return true;
/*    */     }
/* 67 */     if (obj instanceof SwitchUserGrantedAuthority) { SwitchUserGrantedAuthority swa = (SwitchUserGrantedAuthority)obj;
/* 68 */       return (this.role.equals(swa.getAuthority()) && this.source.equals(swa.getSource())); }
/*    */     
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     int result = this.role.hashCode();
/* 76 */     result = 31 * result + this.source.hashCode();
/* 77 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "Switch User Authority [" + this.role + "," + String.valueOf(this.source) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\switchuser\SwitchUserGrantedAuthority.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */