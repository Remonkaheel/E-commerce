/*     */ package org.springframework.security.web.authentication.preauth;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreAuthenticatedAuthenticationProvider
/*     */   implements AuthenticationProvider, InitializingBean, Ordered
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(PreAuthenticatedAuthenticationProvider.class);
/*     */   
/*     */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> preAuthenticatedUserDetailsService;
/*     */   
/*  56 */   private UserDetailsChecker userDetailsChecker = (UserDetailsChecker)new AccountStatusUserDetailsChecker();
/*     */   
/*     */   private boolean throwExceptionWhenTokenRejected;
/*     */   
/*  60 */   private int order = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  67 */     Assert.notNull(this.preAuthenticatedUserDetailsService, "An AuthenticationUserDetailsService must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/*  78 */     if (!supports(authentication.getClass())) {
/*  79 */       return null;
/*     */     }
/*  81 */     logger.debug(LogMessage.format("PreAuthenticated authentication request: %s", authentication));
/*  82 */     if (authentication.getPrincipal() == null) {
/*  83 */       logger.debug("No pre-authenticated principal found in request.");
/*  84 */       if (this.throwExceptionWhenTokenRejected) {
/*  85 */         throw new BadCredentialsException("No pre-authenticated principal found in request.");
/*     */       }
/*  87 */       return null;
/*     */     } 
/*  89 */     if (authentication.getCredentials() == null) {
/*  90 */       logger.debug("No pre-authenticated credentials found in request.");
/*  91 */       if (this.throwExceptionWhenTokenRejected) {
/*  92 */         throw new BadCredentialsException("No pre-authenticated credentials found in request.");
/*     */       }
/*  94 */       return null;
/*     */     } 
/*     */     
/*  97 */     UserDetails userDetails = this.preAuthenticatedUserDetailsService.loadUserDetails(authentication);
/*  98 */     this.userDetailsChecker.check(userDetails);
/*     */     
/* 100 */     PreAuthenticatedAuthenticationToken result = new PreAuthenticatedAuthenticationToken(userDetails, authentication.getCredentials(), userDetails.getAuthorities());
/* 101 */     result.setDetails(authentication.getDetails());
/* 102 */     return (Authentication)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean supports(Class<?> authentication) {
/* 111 */     return PreAuthenticatedAuthenticationToken.class.isAssignableFrom(authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreAuthenticatedUserDetailsService(AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> uds) {
/* 121 */     this.preAuthenticatedUserDetailsService = uds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThrowExceptionWhenTokenRejected(boolean throwExceptionWhenTokenRejected) {
/* 130 */     this.throwExceptionWhenTokenRejected = throwExceptionWhenTokenRejected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsChecker(UserDetailsChecker userDetailsChecker) {
/* 139 */     Assert.notNull(userDetailsChecker, "userDetailsChecker cannot be null");
/* 140 */     this.userDetailsChecker = userDetailsChecker;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 145 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int i) {
/* 149 */     this.order = i;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\PreAuthenticatedAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */