/*    */ package org.springframework.security.web.authentication.preauth.x509;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.security.cert.X509Certificate;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X509AuthenticationFilter
/*    */   extends AbstractPreAuthenticatedProcessingFilter
/*    */ {
/* 31 */   private X509PrincipalExtractor principalExtractor = new SubjectDnX509PrincipalExtractor();
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
/* 35 */     X509Certificate cert = extractClientCertificate(request);
/* 36 */     return (cert != null) ? this.principalExtractor.extractPrincipal(cert) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
/* 41 */     return extractClientCertificate(request);
/*    */   }
/*    */   
/*    */   private X509Certificate extractClientCertificate(HttpServletRequest request) {
/* 45 */     X509Certificate[] certs = (X509Certificate[])request.getAttribute("jakarta.servlet.request.X509Certificate");
/* 46 */     if (certs != null && certs.length > 0) {
/* 47 */       this.logger.debug(LogMessage.format("X.509 client authentication certificate:%s", certs[0]));
/* 48 */       return certs[0];
/*    */     } 
/* 50 */     this.logger.debug("No client certificate found in request.");
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public void setPrincipalExtractor(X509PrincipalExtractor principalExtractor) {
/* 55 */     this.principalExtractor = principalExtractor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\x509\X509AuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */