/*     */ package org.springframework.security.web.authentication.switchuser;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchUserFilter
/*     */   extends GenericFilterBean
/*     */   implements ApplicationEventPublisherAware, MessageSourceAware
/*     */ {
/*     */   public static final String SPRING_SECURITY_SWITCH_USERNAME_KEY = "username";
/*     */   public static final String ROLE_PREVIOUS_ADMINISTRATOR = "ROLE_PREVIOUS_ADMINISTRATOR";
/* 124 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private ApplicationEventPublisher eventPublisher;
/*     */   
/* 128 */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = (AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource();
/*     */   
/* 130 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/* 132 */   private RequestMatcher exitUserMatcher = createMatcher("/logout/impersonate", true);
/*     */   
/* 134 */   private RequestMatcher switchUserMatcher = createMatcher("/login/impersonate", true);
/*     */   
/*     */   private String targetUrl;
/*     */   
/*     */   private String switchFailureUrl;
/*     */   
/* 140 */   private String usernameParameter = "username";
/*     */   
/* 142 */   private String switchAuthorityRole = "ROLE_PREVIOUS_ADMINISTRATOR";
/*     */   
/*     */   private SwitchUserAuthorityChanger switchUserAuthorityChanger;
/*     */   
/*     */   private UserDetailsService userDetailsService;
/*     */   
/* 148 */   private UserDetailsChecker userDetailsChecker = (UserDetailsChecker)new AccountStatusUserDetailsChecker();
/*     */   
/*     */   private AuthenticationSuccessHandler successHandler;
/*     */   
/*     */   private AuthenticationFailureHandler failureHandler;
/*     */   
/* 154 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 158 */     Assert.notNull(this.userDetailsService, "userDetailsService must be specified");
/* 159 */     Assert.isTrue((this.successHandler != null || this.targetUrl != null), "You must set either a successHandler or the targetUrl");
/*     */     
/* 161 */     if (this.targetUrl != null) {
/* 162 */       Assert.isNull(this.successHandler, "You cannot set both successHandler and targetUrl");
/* 163 */       this.successHandler = (AuthenticationSuccessHandler)new SimpleUrlAuthenticationSuccessHandler(this.targetUrl);
/*     */     } 
/* 165 */     if (this.failureHandler == null) {
/* 166 */       this
/*     */         
/* 168 */         .failureHandler = (this.switchFailureUrl != null) ? (AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler(this.switchFailureUrl) : (AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler();
/*     */     } else {
/*     */       
/* 171 */       Assert.isNull(this.switchFailureUrl, "You cannot set both a switchFailureUrl and a failureHandler");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 178 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 184 */     if (requiresSwitchUser(request)) {
/*     */       
/*     */       try {
/* 187 */         Authentication targetUser = attemptSwitchUser(request);
/*     */         
/* 189 */         SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 190 */         context.setAuthentication(targetUser);
/* 191 */         this.securityContextHolderStrategy.setContext(context);
/* 192 */         this.logger.debug(LogMessage.format("Set SecurityContextHolder to %s", targetUser));
/* 193 */         this.securityContextRepository.saveContext(context, request, response);
/*     */         
/* 195 */         this.successHandler.onAuthenticationSuccess(request, response, targetUser);
/*     */       }
/* 197 */       catch (AuthenticationException ex) {
/* 198 */         this.logger.debug("Failed to switch user", (Throwable)ex);
/* 199 */         this.failureHandler.onAuthenticationFailure(request, response, ex);
/*     */       } 
/*     */       return;
/*     */     } 
/* 203 */     if (requiresExitUser(request)) {
/*     */       
/* 205 */       Authentication originalUser = attemptExitUser(request);
/*     */       
/* 207 */       SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 208 */       context.setAuthentication(originalUser);
/* 209 */       this.securityContextHolderStrategy.setContext(context);
/* 210 */       this.logger.debug(LogMessage.format("Set SecurityContextHolder to %s", originalUser));
/* 211 */       this.securityContextRepository.saveContext(context, request, response);
/*     */       
/* 213 */       this.successHandler.onAuthenticationSuccess(request, response, originalUser);
/*     */       return;
/*     */     } 
/* 216 */     this.logger.trace(LogMessage.format("Did not attempt to switch user since request did not match [%s] or [%s]", this.switchUserMatcher, this.exitUserMatcher));
/*     */     
/* 218 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication attemptSwitchUser(HttpServletRequest request) throws AuthenticationException {
/* 234 */     String username = request.getParameter(this.usernameParameter);
/* 235 */     username = (username != null) ? username : "";
/* 236 */     this.logger.debug(LogMessage.format("Attempting to switch to user [%s]", username));
/* 237 */     UserDetails targetUser = this.userDetailsService.loadUserByUsername(username);
/* 238 */     this.userDetailsChecker.check(targetUser);
/*     */     
/* 240 */     UsernamePasswordAuthenticationToken targetUserRequest = createSwitchUserToken(request, targetUser);
/*     */     
/* 242 */     if (this.eventPublisher != null) {
/* 243 */       this.eventPublisher.publishEvent((ApplicationEvent)new AuthenticationSwitchUserEvent(this.securityContextHolderStrategy
/* 244 */             .getContext().getAuthentication(), targetUser));
/*     */     }
/* 246 */     return (Authentication)targetUserRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication attemptExitUser(HttpServletRequest request) throws AuthenticationCredentialsNotFoundException {
/* 260 */     Authentication current = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 261 */     if (current == null) {
/* 262 */       throw new AuthenticationCredentialsNotFoundException(this.messages
/* 263 */           .getMessage("SwitchUserFilter.noCurrentUser", "No current user associated with this request"));
/*     */     }
/*     */ 
/*     */     
/* 267 */     Authentication original = getSourceAuthentication(current);
/* 268 */     if (original == null) {
/* 269 */       this.logger.debug("Failed to find original user");
/* 270 */       throw new AuthenticationCredentialsNotFoundException(this.messages
/* 271 */           .getMessage("SwitchUserFilter.noOriginalAuthentication", "Failed to find original user"));
/*     */     } 
/*     */     
/* 274 */     UserDetails originalUser = null;
/* 275 */     Object obj = original.getPrincipal();
/* 276 */     if (obj != null && obj instanceof UserDetails) {
/* 277 */       originalUser = (UserDetails)obj;
/*     */     }
/*     */     
/* 280 */     if (this.eventPublisher != null) {
/* 281 */       this.eventPublisher.publishEvent((ApplicationEvent)new AuthenticationSwitchUserEvent(current, originalUser));
/*     */     }
/* 283 */     return original;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UsernamePasswordAuthenticationToken createSwitchUserToken(HttpServletRequest request, UserDetails targetUser) {
/* 300 */     Authentication currentAuthentication = getCurrentAuthentication(request);
/* 301 */     GrantedAuthority switchAuthority = new SwitchUserGrantedAuthority(this.switchAuthorityRole, currentAuthentication);
/*     */ 
/*     */     
/* 304 */     Collection<? extends GrantedAuthority> orig = targetUser.getAuthorities();
/*     */     
/* 306 */     if (this.switchUserAuthorityChanger != null) {
/* 307 */       orig = this.switchUserAuthorityChanger.modifyGrantedAuthorities(targetUser, currentAuthentication, orig);
/*     */     }
/*     */     
/* 310 */     List<GrantedAuthority> newAuths = new ArrayList<>(orig);
/* 311 */     newAuths.add(switchAuthority);
/*     */     
/* 313 */     UsernamePasswordAuthenticationToken targetUserRequest = UsernamePasswordAuthenticationToken.authenticated(targetUser, targetUser.getPassword(), newAuths);
/*     */ 
/*     */     
/* 316 */     targetUserRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 317 */     return targetUserRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   private Authentication getCurrentAuthentication(HttpServletRequest request) {
/*     */     try {
/* 323 */       return attemptExitUser(request);
/*     */     }
/* 325 */     catch (AuthenticationCredentialsNotFoundException ex) {
/* 326 */       return this.securityContextHolderStrategy.getContext().getAuthentication();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication getSourceAuthentication(Authentication current) {
/* 340 */     Authentication original = null;
/*     */     
/* 342 */     Collection<? extends GrantedAuthority> authorities = current.getAuthorities();
/* 343 */     for (GrantedAuthority auth : authorities) {
/*     */       
/* 345 */       if (auth instanceof SwitchUserGrantedAuthority) {
/* 346 */         original = ((SwitchUserGrantedAuthority)auth).getSource();
/* 347 */         this.logger.debug(LogMessage.format("Found original switch user granted authority [%s]", original));
/*     */       } 
/*     */     } 
/* 350 */     return original;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean requiresExitUser(HttpServletRequest request) {
/* 362 */     return this.exitUserMatcher.matches(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean requiresSwitchUser(HttpServletRequest request) {
/* 374 */     return this.switchUserMatcher.matches(request);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher eventPublisher) throws BeansException {
/* 379 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 384 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/* 385 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 390 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 391 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsService(UserDetailsService userDetailsService) {
/* 400 */     this.userDetailsService = userDetailsService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitUserUrl(String exitUserUrl) {
/* 409 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(exitUserUrl), "exitUserUrl cannot be empty and must be a valid redirect URL");
/*     */     
/* 411 */     this.exitUserMatcher = createMatcher(exitUserUrl, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitUserMatcher(RequestMatcher exitUserMatcher) {
/* 419 */     Assert.notNull(exitUserMatcher, "exitUserMatcher cannot be null");
/* 420 */     this.exitUserMatcher = exitUserMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchUserUrl(String switchUserUrl) {
/* 429 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(switchUserUrl), "switchUserUrl cannot be empty and must be a valid redirect URL");
/*     */     
/* 431 */     this.switchUserMatcher = createMatcher(switchUserUrl, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchUserMatcher(RequestMatcher switchUserMatcher) {
/* 439 */     Assert.notNull(switchUserMatcher, "switchUserMatcher cannot be null");
/* 440 */     this.switchUserMatcher = switchUserMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetUrl(String targetUrl) {
/* 450 */     this.targetUrl = targetUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuccessHandler(AuthenticationSuccessHandler successHandler) {
/* 459 */     Assert.notNull(successHandler, "successHandler cannot be null");
/* 460 */     this.successHandler = successHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchFailureUrl(String switchFailureUrl) {
/* 475 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(switchFailureUrl), "switchFailureUrl must be a valid redirect URL");
/* 476 */     this.switchFailureUrl = switchFailureUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailureHandler(AuthenticationFailureHandler failureHandler) {
/* 485 */     Assert.notNull(failureHandler, "failureHandler cannot be null");
/* 486 */     this.failureHandler = failureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchUserAuthorityChanger(SwitchUserAuthorityChanger switchUserAuthorityChanger) {
/* 494 */     this.switchUserAuthorityChanger = switchUserAuthorityChanger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsChecker(UserDetailsChecker userDetailsChecker) {
/* 505 */     this.userDetailsChecker = userDetailsChecker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsernameParameter(String usernameParameter) {
/* 513 */     this.usernameParameter = usernameParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchAuthorityRole(String switchAuthorityRole) {
/* 522 */     Assert.notNull(switchAuthorityRole, "switchAuthorityRole cannot be null");
/* 523 */     this.switchAuthorityRole = switchAuthorityRole;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 533 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 534 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 546 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 547 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */   
/*     */   private static RequestMatcher createMatcher(String pattern, boolean usePathPatterns) {
/* 551 */     if (usePathPatterns) {
/* 552 */       return (RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(HttpMethod.POST, pattern);
/*     */     }
/* 554 */     return (RequestMatcher)new AntPathRequestMatcher(pattern, "POST", true, new UrlPathHelper());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\switchuser\SwitchUserFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */