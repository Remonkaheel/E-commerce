/*    */ package org.springframework.security.web.authentication.logout;
/*    */ 
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CookieClearingLogoutHandler
/*    */   implements LogoutHandler
/*    */ {
/*    */   private final List<Function<HttpServletRequest, Cookie>> cookiesToClear;
/*    */   
/*    */   public CookieClearingLogoutHandler(String... cookiesToClear) {
/* 44 */     Assert.notNull(cookiesToClear, "List of cookies cannot be null");
/* 45 */     List<Function<HttpServletRequest, Cookie>> cookieList = new ArrayList<>();
/* 46 */     for (String cookieName : cookiesToClear) {
/* 47 */       cookieList.add(request -> {
/*    */             Cookie cookie = new Cookie(cookieName, null);
/*    */             String contextPath = request.getContextPath();
/*    */             String cookiePath = StringUtils.hasText(contextPath) ? contextPath : "/";
/*    */             cookie.setPath(cookiePath);
/*    */             cookie.setMaxAge(0);
/*    */             cookie.setSecure(request.isSecure());
/*    */             return cookie;
/*    */           });
/*    */     } 
/* 57 */     this.cookiesToClear = cookieList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CookieClearingLogoutHandler(Cookie... cookiesToClear) {
/* 65 */     Assert.notNull(cookiesToClear, "List of cookies cannot be null");
/* 66 */     List<Function<HttpServletRequest, Cookie>> cookieList = new ArrayList<>();
/* 67 */     for (Cookie cookie : cookiesToClear) {
/* 68 */       Assert.isTrue((cookie.getMaxAge() == 0), "Cookie maxAge must be 0");
/* 69 */       cookieList.add(request -> cookie);
/*    */     } 
/* 71 */     this.cookiesToClear = cookieList;
/*    */   }
/*    */ 
/*    */   
/*    */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 76 */     this.cookiesToClear.forEach(f -> response.addCookie(f.apply(request)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\CookieClearingLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */