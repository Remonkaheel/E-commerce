/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  73 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  75 */   private RequestMatcher requestMatcher = AnyRequestMatcher.INSTANCE;
/*     */   
/*     */   private AuthenticationConverter authenticationConverter;
/*     */   
/*  79 */   private AuthenticationSuccessHandler successHandler = new SavedRequestAwareAuthenticationSuccessHandler();
/*     */   
/*  81 */   private AuthenticationFailureHandler failureHandler = new AuthenticationEntryPointFailureHandler(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
/*     */ 
/*     */   
/*  84 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new RequestAttributeSecurityContextRepository();
/*     */   
/*     */   private AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver;
/*     */ 
/*     */   
/*     */   public AuthenticationFilter(AuthenticationManager authenticationManager, AuthenticationConverter authenticationConverter) {
/*  90 */     this(r -> authenticationManager, authenticationConverter);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthenticationFilter(AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver, AuthenticationConverter authenticationConverter) {
/*  95 */     Assert.notNull(authenticationManagerResolver, "authenticationManagerResolver cannot be null");
/*  96 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/*  97 */     this.authenticationManagerResolver = authenticationManagerResolver;
/*  98 */     this.authenticationConverter = authenticationConverter;
/*     */   }
/*     */   
/*     */   public RequestMatcher getRequestMatcher() {
/* 102 */     return this.requestMatcher;
/*     */   }
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/* 106 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 107 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */   
/*     */   public AuthenticationConverter getAuthenticationConverter() {
/* 111 */     return this.authenticationConverter;
/*     */   }
/*     */   
/*     */   public void setAuthenticationConverter(AuthenticationConverter authenticationConverter) {
/* 115 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 116 */     this.authenticationConverter = authenticationConverter;
/*     */   }
/*     */   
/*     */   public AuthenticationSuccessHandler getSuccessHandler() {
/* 120 */     return this.successHandler;
/*     */   }
/*     */   
/*     */   public void setSuccessHandler(AuthenticationSuccessHandler successHandler) {
/* 124 */     Assert.notNull(successHandler, "successHandler cannot be null");
/* 125 */     this.successHandler = successHandler;
/*     */   }
/*     */   
/*     */   public AuthenticationFailureHandler getFailureHandler() {
/* 129 */     return this.failureHandler;
/*     */   }
/*     */   
/*     */   public void setFailureHandler(AuthenticationFailureHandler failureHandler) {
/* 133 */     Assert.notNull(failureHandler, "failureHandler cannot be null");
/* 134 */     this.failureHandler = failureHandler;
/*     */   }
/*     */   
/*     */   public AuthenticationManagerResolver<HttpServletRequest> getAuthenticationManagerResolver() {
/* 138 */     return this.authenticationManagerResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationManagerResolver(AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver) {
/* 143 */     Assert.notNull(authenticationManagerResolver, "authenticationManagerResolver cannot be null");
/* 144 */     this.authenticationManagerResolver = authenticationManagerResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 155 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 156 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 166 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 167 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 173 */     if (!this.requestMatcher.matches(request)) {
/* 174 */       if (this.logger.isTraceEnabled()) {
/* 175 */         this.logger.trace("Did not match request to " + String.valueOf(this.requestMatcher));
/*     */       }
/* 177 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*     */     try {
/* 181 */       Authentication authenticationResult = attemptAuthentication(request, response);
/* 182 */       if (authenticationResult == null) {
/* 183 */         filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */         return;
/*     */       } 
/* 186 */       HttpSession session = request.getSession(false);
/* 187 */       if (session != null) {
/* 188 */         request.changeSessionId();
/*     */       }
/* 190 */       successfulAuthentication(request, response, filterChain, authenticationResult);
/*     */     }
/* 192 */     catch (AuthenticationException ex) {
/* 193 */       unsuccessfulAuthentication(request, response, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getAlreadyFilteredAttributeName() {
/* 199 */     String name = getFilterName();
/* 200 */     if (name == null) {
/* 201 */       name = getClass().getName().concat("-" + System.identityHashCode(this));
/*     */     }
/* 203 */     return name + ".FILTERED";
/*     */   }
/*     */ 
/*     */   
/*     */   private void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
/* 208 */     this.securityContextHolderStrategy.clearContext();
/* 209 */     this.failureHandler.onAuthenticationFailure(request, response, failed);
/*     */   }
/*     */ 
/*     */   
/*     */   private void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authentication) throws IOException, ServletException {
/* 214 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 215 */     context.setAuthentication(authentication);
/* 216 */     this.securityContextHolderStrategy.setContext(context);
/* 217 */     this.securityContextRepository.saveContext(context, request, response);
/* 218 */     this.successHandler.onAuthenticationSuccess(request, response, chain, authentication);
/*     */   }
/*     */ 
/*     */   
/*     */   private Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, ServletException {
/* 223 */     Authentication authentication = this.authenticationConverter.convert(request);
/* 224 */     if (authentication == null) {
/* 225 */       return null;
/*     */     }
/* 227 */     AuthenticationManager authenticationManager = this.authenticationManagerResolver.resolve(request);
/* 228 */     Authentication authenticationResult = authenticationManager.authenticate(authentication);
/* 229 */     if (authenticationResult == null) {
/* 230 */       throw new ServletException("AuthenticationManager should not return null Authentication object.");
/*     */     }
/* 232 */     return authenticationResult;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\AuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */