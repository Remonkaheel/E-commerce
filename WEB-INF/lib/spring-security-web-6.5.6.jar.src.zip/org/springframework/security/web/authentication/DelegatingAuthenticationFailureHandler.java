/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingAuthenticationFailureHandler
/*    */   implements AuthenticationFailureHandler
/*    */ {
/*    */   private final LinkedHashMap<Class<? extends AuthenticationException>, AuthenticationFailureHandler> handlers;
/*    */   private final AuthenticationFailureHandler defaultHandler;
/*    */   
/*    */   public DelegatingAuthenticationFailureHandler(LinkedHashMap<Class<? extends AuthenticationException>, AuthenticationFailureHandler> handlers, AuthenticationFailureHandler defaultHandler) {
/* 59 */     Assert.notEmpty(handlers, "handlers cannot be null or empty");
/* 60 */     Assert.notNull(defaultHandler, "defaultHandler cannot be null");
/* 61 */     this.handlers = handlers;
/* 62 */     this.defaultHandler = defaultHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
/* 68 */     for (Map.Entry<Class<? extends AuthenticationException>, AuthenticationFailureHandler> entry : this.handlers
/* 69 */       .entrySet()) {
/* 70 */       Class<? extends AuthenticationException> handlerMappedExceptionClass = entry.getKey();
/* 71 */       if (handlerMappedExceptionClass.isAssignableFrom(exception.getClass())) {
/* 72 */         AuthenticationFailureHandler handler = entry.getValue();
/* 73 */         handler.onAuthenticationFailure(request, response, exception);
/*    */         return;
/*    */       } 
/*    */     } 
/* 77 */     this.defaultHandler.onAuthenticationFailure(request, response, exception);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\DelegatingAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */