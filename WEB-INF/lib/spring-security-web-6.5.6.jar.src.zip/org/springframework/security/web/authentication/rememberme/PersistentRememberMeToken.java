/*    */ package org.springframework.security.web.authentication.rememberme;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistentRememberMeToken
/*    */ {
/*    */   private final String username;
/*    */   private final String series;
/*    */   private final String tokenValue;
/*    */   private final Date date;
/*    */   
/*    */   public PersistentRememberMeToken(String username, String series, String tokenValue, Date date) {
/* 35 */     this.username = username;
/* 36 */     this.series = series;
/* 37 */     this.tokenValue = tokenValue;
/* 38 */     this.date = date;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 42 */     return this.username;
/*    */   }
/*    */   
/*    */   public String getSeries() {
/* 46 */     return this.series;
/*    */   }
/*    */   
/*    */   public String getTokenValue() {
/* 50 */     return this.tokenValue;
/*    */   }
/*    */   
/*    */   public Date getDate() {
/* 54 */     return this.date;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\PersistentRememberMeToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */