package org.springframework.security.web.authentication;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;

public interface RememberMeServices {
  Authentication autoLogin(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  void loginFail(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  void loginSuccess(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Authentication paramAuthentication);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\RememberMeServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */