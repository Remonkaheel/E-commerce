/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Base64;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthenticationFilter
/*     */   extends GenericFilterBean
/*     */   implements MessageSourceAware
/*     */ {
/*  95 */   private static final Log logger = LogFactory.getLog(DigestAuthenticationFilter.class);
/*     */ 
/*     */   
/*  98 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/* 100 */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = (AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource();
/*     */   
/*     */   private DigestAuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/* 104 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/* 106 */   private UserCache userCache = (UserCache)new NullUserCache();
/*     */   
/*     */   private UserDetailsService userDetailsService;
/*     */   
/*     */   private boolean passwordAlreadyEncoded = false;
/*     */   
/*     */   private boolean createAuthenticatedToken = false;
/*     */   
/* 114 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new RequestAttributeSecurityContextRepository();
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 118 */     Assert.notNull(this.userDetailsService, "A UserDetailsService is required");
/* 119 */     Assert.notNull(this.authenticationEntryPoint, "A DigestAuthenticationEntryPoint is required");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 125 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 130 */     String serverDigestMd5, header = request.getHeader("Authorization");
/* 131 */     if (header == null || !header.startsWith("Digest ")) {
/* 132 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/* 135 */     logger.debug(LogMessage.format("Digest Authorization header received from user agent: %s", header));
/* 136 */     DigestData digestAuth = new DigestData(header);
/*     */     try {
/* 138 */       digestAuth.validateAndDecode(this.authenticationEntryPoint.getKey(), this.authenticationEntryPoint
/* 139 */           .getRealmName());
/*     */     }
/* 141 */     catch (BadCredentialsException ex) {
/* 142 */       fail(request, response, (AuthenticationException)ex);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 148 */     boolean cacheWasUsed = true;
/* 149 */     UserDetails user = this.userCache.getUserFromCache(digestAuth.getUsername());
/*     */     
/*     */     try {
/* 152 */       if (user == null) {
/* 153 */         cacheWasUsed = false;
/* 154 */         user = this.userDetailsService.loadUserByUsername(digestAuth.getUsername());
/* 155 */         if (user == null) {
/* 156 */           throw new AuthenticationServiceException("AuthenticationDao returned null, which is an interface contract violation");
/*     */         }
/*     */         
/* 159 */         this.userCache.putUserInCache(user);
/*     */       } 
/* 161 */       serverDigestMd5 = digestAuth.calculateServerDigest(user.getPassword(), request.getMethod());
/*     */       
/* 163 */       if (!serverDigestMd5.equals(digestAuth.getResponse()) && cacheWasUsed) {
/* 164 */         logger.debug("Digest comparison failure; trying to refresh user from DAO in case password had changed");
/* 165 */         user = this.userDetailsService.loadUserByUsername(digestAuth.getUsername());
/* 166 */         this.userCache.putUserInCache(user);
/* 167 */         serverDigestMd5 = digestAuth.calculateServerDigest(user.getPassword(), request.getMethod());
/*     */       }
/*     */     
/* 170 */     } catch (UsernameNotFoundException ex) {
/* 171 */       String message = this.messages.getMessage("DigestAuthenticationFilter.usernameNotFound", new Object[] { digestAuth
/* 172 */             .getUsername() }, "Username {0} not found");
/* 173 */       fail(request, response, (AuthenticationException)new BadCredentialsException(message));
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     if (!serverDigestMd5.equals(digestAuth.getResponse())) {
/* 178 */       logger.debug(LogMessage.format("Expected response: '%s' but received: '%s'; is AuthenticationDao returning clear text passwords?", serverDigestMd5, digestAuth
/*     */             
/* 180 */             .getResponse()));
/* 181 */       String message = this.messages.getMessage("DigestAuthenticationFilter.incorrectResponse", "Incorrect response");
/*     */       
/* 183 */       fail(request, response, (AuthenticationException)new BadCredentialsException(message));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     if (digestAuth.isNonceExpired()) {
/* 191 */       String message = this.messages.getMessage("DigestAuthenticationFilter.nonceExpired", "Nonce has expired/timed out");
/*     */       
/* 193 */       fail(request, response, new NonceExpiredException(message));
/*     */       return;
/*     */     } 
/* 196 */     logger.debug(LogMessage.format("Authentication success for user: '%s' with response: '%s'", digestAuth
/* 197 */           .getUsername(), digestAuth.getResponse()));
/* 198 */     Authentication authentication = createSuccessfulAuthentication(request, user);
/* 199 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 200 */     context.setAuthentication(authentication);
/* 201 */     this.securityContextHolderStrategy.setContext(context);
/* 202 */     this.securityContextRepository.saveContext(context, request, response);
/* 203 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */   
/*     */   private Authentication createSuccessfulAuthentication(HttpServletRequest request, UserDetails user) {
/* 207 */     UsernamePasswordAuthenticationToken authRequest = getAuthRequest(user);
/* 208 */     authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 209 */     return (Authentication)authRequest;
/*     */   }
/*     */   
/*     */   private UsernamePasswordAuthenticationToken getAuthRequest(UserDetails user) {
/* 213 */     if (this.createAuthenticatedToken) {
/* 214 */       return UsernamePasswordAuthenticationToken.authenticated(user, user.getPassword(), user.getAuthorities());
/*     */     }
/* 216 */     return UsernamePasswordAuthenticationToken.unauthenticated(user, user.getPassword());
/*     */   }
/*     */ 
/*     */   
/*     */   private void fail(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
/* 221 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 222 */     this.securityContextHolderStrategy.setContext(context);
/* 223 */     logger.debug(failed);
/* 224 */     this.authenticationEntryPoint.commence(request, response, failed);
/*     */   }
/*     */   
/*     */   protected final DigestAuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 228 */     return this.authenticationEntryPoint;
/*     */   }
/*     */   
/*     */   public UserCache getUserCache() {
/* 232 */     return this.userCache;
/*     */   }
/*     */   
/*     */   public UserDetailsService getUserDetailsService() {
/* 236 */     return this.userDetailsService;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 241 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/* 242 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */   
/*     */   public void setAuthenticationEntryPoint(DigestAuthenticationEntryPoint authenticationEntryPoint) {
/* 246 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 251 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   public void setPasswordAlreadyEncoded(boolean passwordAlreadyEncoded) {
/* 255 */     this.passwordAlreadyEncoded = passwordAlreadyEncoded;
/*     */   }
/*     */   
/*     */   public void setUserCache(UserCache userCache) {
/* 259 */     this.userCache = userCache;
/*     */   }
/*     */   
/*     */   public void setUserDetailsService(UserDetailsService userDetailsService) {
/* 263 */     this.userDetailsService = userDetailsService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCreateAuthenticatedToken(boolean createAuthenticatedToken) {
/* 279 */     this.createAuthenticatedToken = createAuthenticatedToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 290 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 291 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 301 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 302 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   private class DigestData
/*     */   {
/*     */     private final String username;
/*     */     
/*     */     private final String realm;
/*     */     
/*     */     private final String nonce;
/*     */     
/*     */     private final String uri;
/*     */     
/*     */     private final String response;
/*     */     
/*     */     private final String qop;
/*     */     
/*     */     private final String nc;
/*     */     
/*     */     private final String cnonce;
/*     */     
/*     */     private final String section212response;
/*     */     private long nonceExpiryTime;
/*     */     
/*     */     DigestData(String header) {
/* 328 */       this.section212response = header.substring(7);
/* 329 */       String[] headerEntries = DigestAuthUtils.splitIgnoringQuotes(this.section212response, ',');
/* 330 */       Map<String, String> headerMap = DigestAuthUtils.splitEachArrayElementAndCreateMap(headerEntries, "=", "\"");
/* 331 */       this.username = headerMap.get("username");
/* 332 */       this.realm = headerMap.get("realm");
/* 333 */       this.nonce = headerMap.get("nonce");
/* 334 */       this.uri = headerMap.get("uri");
/* 335 */       this.response = headerMap.get("response");
/* 336 */       this.qop = headerMap.get("qop");
/* 337 */       this.nc = headerMap.get("nc");
/* 338 */       this.cnonce = headerMap.get("cnonce");
/* 339 */       DigestAuthenticationFilter.logger.debug(
/* 340 */           LogMessage.format("Extracted username: '%s'; realm: '%s'; nonce: '%s'; uri: '%s'; response: '%s'", new Object[] { this.username, this.realm, this.nonce, this.uri, this.response }));
/*     */     }
/*     */ 
/*     */     
/*     */     void validateAndDecode(String entryPointKey, String expectedRealm) throws BadCredentialsException {
/*     */       byte[] nonceBytes;
/* 346 */       if (this.username == null || this.realm == null || this.nonce == null || this.uri == null || this.response == null)
/*     */       {
/* 348 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.missingMandatory", new Object[] { this.section212response }, "Missing mandatory digest value; received header {0}"));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 353 */       if ("auth".equals(this.qop) && (
/* 354 */         this.nc == null || this.cnonce == null)) {
/* 355 */         DigestAuthenticationFilter.logger.debug(LogMessage.format("extracted nc: '%s'; cnonce: '%s'", this.nc, this.cnonce));
/* 356 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.missingAuth", new Object[] { this.section212response }, "Missing mandatory digest value; received header {0}"));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 362 */       if (!expectedRealm.equals(this.realm)) {
/* 363 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.incorrectRealm", new Object[] { this.realm, expectedRealm }, "Response realm name '{0}' does not match system realm name of '{1}'"));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 370 */         nonceBytes = Base64.getDecoder().decode(this.nonce.getBytes());
/*     */       }
/* 372 */       catch (IllegalArgumentException ex) {
/* 373 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages
/* 374 */             .getMessage("DigestAuthenticationFilter.nonceEncoding", new Object[] { this.nonce }, "Nonce is not encoded in Base64; received nonce {0}"));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 379 */       String nonceAsPlainText = new String(nonceBytes);
/* 380 */       String[] nonceTokens = StringUtils.delimitedListToStringArray(nonceAsPlainText, ":");
/* 381 */       if (nonceTokens.length != 2) {
/* 382 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceNotTwoTokens", new Object[] { nonceAsPlainText }, "Nonce should have yielded two tokens but was {0}"));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 388 */         this.nonceExpiryTime = Long.valueOf(nonceTokens[0]).longValue();
/*     */       }
/* 390 */       catch (NumberFormatException nfe) {
/* 391 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceNotNumeric", new Object[] { nonceAsPlainText }, "Nonce token should have yielded a numeric first token, but was {0}"));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 396 */       String expectedNonceSignature = DigestAuthUtils.md5Hex("" + this.nonceExpiryTime + ":" + this.nonceExpiryTime);
/* 397 */       if (!expectedNonceSignature.equals(nonceTokens[1])) {
/* 398 */         throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceCompromised", new Object[] { nonceAsPlainText }, "Nonce token compromised {0}"));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String calculateServerDigest(String password, String httpMethod) {
/* 407 */       return DigestAuthUtils.generateDigest(DigestAuthenticationFilter.this.passwordAlreadyEncoded, this.username, this.realm, password, httpMethod, this.uri, this.qop, this.nonce, this.nc, this.cnonce);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isNonceExpired() {
/* 412 */       long now = System.currentTimeMillis();
/* 413 */       return (this.nonceExpiryTime < now);
/*     */     }
/*     */     
/*     */     String getUsername() {
/* 417 */       return this.username;
/*     */     }
/*     */     
/*     */     String getResponse() {
/* 421 */       return this.response;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\DigestAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */