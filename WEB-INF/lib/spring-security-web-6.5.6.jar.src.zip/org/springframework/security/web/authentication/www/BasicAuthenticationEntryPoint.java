/*    */ package org.springframework.security.web.authentication.www;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicAuthenticationEntryPoint
/*    */   implements AuthenticationEntryPoint, InitializingBean
/*    */ {
/*    */   private String realmName;
/*    */   
/*    */   public void afterPropertiesSet() {
/* 49 */     Assert.hasText(this.realmName, "realmName must be specified");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
/* 55 */     response.setHeader("WWW-Authenticate", "Basic realm=\"" + this.realmName + "\"");
/* 56 */     response.sendError(HttpStatus.UNAUTHORIZED.value(), HttpStatus.UNAUTHORIZED.getReasonPhrase());
/*    */   }
/*    */   
/*    */   public String getRealmName() {
/* 60 */     return this.realmName;
/*    */   }
/*    */   
/*    */   public void setRealmName(String realmName) {
/* 64 */     this.realmName = realmName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\BasicAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */