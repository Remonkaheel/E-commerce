/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeSessionAuthenticationStrategy
/*    */   implements SessionAuthenticationStrategy
/*    */ {
/* 59 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final List<SessionAuthenticationStrategy> delegateStrategies;
/*    */   
/*    */   public CompositeSessionAuthenticationStrategy(List<SessionAuthenticationStrategy> delegateStrategies) {
/* 64 */     Assert.notEmpty(delegateStrategies, "delegateStrategies cannot be null or empty");
/* 65 */     for (SessionAuthenticationStrategy strategy : delegateStrategies) {
/* 66 */       Assert.notNull(strategy, () -> "delegateStrategies cannot contain null entires. Got " + String.valueOf(delegateStrategies));
/*    */     }
/* 68 */     this.delegateStrategies = delegateStrategies;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) throws SessionAuthenticationException {
/* 74 */     int currentPosition = 0;
/* 75 */     int size = this.delegateStrategies.size();
/* 76 */     for (SessionAuthenticationStrategy delegate : this.delegateStrategies) {
/* 77 */       if (this.logger.isTraceEnabled()) {
/* 78 */         this.logger.trace(LogMessage.format("Preparing session with %s (%d/%d)", delegate
/* 79 */               .getClass().getSimpleName(), Integer.valueOf(++currentPosition), Integer.valueOf(size)));
/*    */       }
/* 81 */       delegate.onAuthentication(authentication, request, response);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 87 */     return getClass().getName() + " [delegateStrategies = " + getClass().getName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\CompositeSessionAuthenticationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */