/*    */ package org.springframework.security.web.authentication.switchuser;
/*    */ 
/*    */ import org.springframework.security.authentication.event.AbstractAuthenticationEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationSwitchUserEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 6265996480231793939L;
/*    */   private final UserDetails targetUser;
/*    */   
/*    */   public AuthenticationSwitchUserEvent(Authentication authentication, UserDetails targetUser) {
/* 43 */     super(authentication);
/* 44 */     this.targetUser = targetUser;
/*    */   }
/*    */   
/*    */   public UserDetails getTargetUser() {
/* 48 */     return this.targetUser;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\switchuser\AuthenticationSwitchUserEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */