/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.savedrequest.SavedRequest;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpMessageConverterAuthenticationSuccessHandler
/*     */   implements AuthenticationSuccessHandler
/*     */ {
/*  52 */   private HttpMessageConverter<Object> converter = (HttpMessageConverter<Object>)new MappingJackson2HttpMessageConverter();
/*     */   
/*  54 */   private RequestCache requestCache = (RequestCache)new HttpSessionRequestCache();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConverter(HttpMessageConverter<Object> converter) {
/*  62 */     Assert.notNull(converter, "converter cannot be null");
/*  63 */     this.converter = converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestCache(RequestCache requestCache) {
/*  72 */     Assert.notNull(requestCache, "requestCache cannot be null");
/*  73 */     this.requestCache = requestCache;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
/*  79 */     SavedRequest savedRequest = this.requestCache.getRequest(request, response);
/*     */     
/*  81 */     String redirectUrl = (savedRequest != null) ? savedRequest.getRedirectUrl() : (request.getContextPath() + "/");
/*  82 */     this.requestCache.removeRequest(request, response);
/*  83 */     this.converter.write(new AuthenticationSuccess(redirectUrl), MediaType.APPLICATION_JSON, (HttpOutputMessage)new ServletServerHttpResponse(response));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class AuthenticationSuccess
/*     */   {
/*     */     private final String redirectUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AuthenticationSuccess(String redirectUrl) {
/*  99 */       this.redirectUrl = redirectUrl;
/*     */     }
/*     */     
/*     */     public String getRedirectUrl() {
/* 103 */       return this.redirectUrl;
/*     */     }
/*     */     
/*     */     public boolean isAuthenticated() {
/* 107 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\HttpMessageConverterAuthenticationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */