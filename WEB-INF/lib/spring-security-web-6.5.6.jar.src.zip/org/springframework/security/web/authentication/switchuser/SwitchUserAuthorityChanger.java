package org.springframework.security.web.authentication.switchuser;

import java.util.Collection;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public interface SwitchUserAuthorityChanger {
  Collection<? extends GrantedAuthority> modifyGrantedAuthorities(UserDetails paramUserDetails, Authentication paramAuthentication, Collection<? extends GrantedAuthority> paramCollection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\switchuser\SwitchUserAuthorityChanger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */