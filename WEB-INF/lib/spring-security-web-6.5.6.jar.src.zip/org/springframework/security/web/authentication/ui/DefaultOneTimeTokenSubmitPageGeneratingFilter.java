/*     */ package org.springframework.security.web.authentication.ui;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultOneTimeTokenSubmitPageGeneratingFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_SUBMIT_PAGE_URL = "/login/ott";
/*  50 */   private RequestMatcher requestMatcher = (RequestMatcher)PathPatternRequestMatcher.withDefaults()
/*  51 */     .matcher(HttpMethod.GET, "/login/ott");
/*     */   
/*     */   private Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs = request -> Collections.emptyMap();
/*     */   
/*  55 */   private String loginProcessingUrl = "/login/ott";
/*     */   private static final String ONE_TIME_TOKEN_SUBMIT_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <title>One-Time Token Login</title>\n    <meta charset=\"utf-8\"/>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\"/>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"container\">\n      <form class=\"login-form\" action=\"{{loginProcessingUrl}}\" method=\"post\">\n        <h2>Please input the token</h2>\n        <p>\n          <label for=\"token\" class=\"screenreader\">Token</label>\n          <input type=\"text\" id=\"token\" name=\"token\" value=\"{{tokenValue}}\" placeholder=\"Token\" required=\"true\" autofocus=\"autofocus\"/>\n        </p>\n        <button class=\"primary\" type=\"submit\">Sign in</button>\n{{hiddenInputs}}\n      </form>\n    </div>\n  </body>\n</html>\n";
/*     */   private static final String HIDDEN_HTML_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*  60 */     if (!this.requestMatcher.matches(request)) {
/*  61 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  64 */     String html = generateHtml(request);
/*  65 */     response.setContentType("text/html;charset=UTF-8");
/*  66 */     response.setContentLength((html.getBytes(StandardCharsets.UTF_8)).length);
/*  67 */     response.getWriter().write(html);
/*     */   }
/*     */   
/*     */   private String generateHtml(HttpServletRequest request) {
/*  71 */     String contextPath = request.getContextPath();
/*     */     
/*  73 */     String token = request.getParameter("token");
/*  74 */     String tokenValue = StringUtils.hasText(token) ? token : "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     String hiddenInputs = ((Map)this.resolveHiddenInputs.apply(request)).entrySet().stream().map(inputKeyValue -> renderHiddenInput((String)inputKeyValue.getKey(), (String)inputKeyValue.getValue())).collect(Collectors.joining("\n"));
/*     */     
/*  82 */     return HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <title>One-Time Token Login</title>\n    <meta charset=\"utf-8\"/>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\"/>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"container\">\n      <form class=\"login-form\" action=\"{{loginProcessingUrl}}\" method=\"post\">\n        <h2>Please input the token</h2>\n        <p>\n          <label for=\"token\" class=\"screenreader\">Token</label>\n          <input type=\"text\" id=\"token\" name=\"token\" value=\"{{tokenValue}}\" placeholder=\"Token\" required=\"true\" autofocus=\"autofocus\"/>\n        </p>\n        <button class=\"primary\" type=\"submit\">Sign in</button>\n{{hiddenInputs}}\n      </form>\n    </div>\n  </body>\n</html>\n")
/*  83 */       .withValue("contextPath", contextPath)
/*  84 */       .withValue("tokenValue", tokenValue)
/*  85 */       .withValue("loginProcessingUrl", contextPath + contextPath)
/*  86 */       .withRawHtml("hiddenInputs", hiddenInputs)
/*  87 */       .render();
/*     */   }
/*     */   
/*     */   private String renderHiddenInput(String name, String value) {
/*  91 */     return HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n")
/*  92 */       .withValue("name", name)
/*  93 */       .withValue("value", value)
/*  94 */       .render();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolveHiddenInputs(Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs) {
/* 103 */     Assert.notNull(resolveHiddenInputs, "resolveHiddenInputs cannot be null");
/* 104 */     this.resolveHiddenInputs = resolveHiddenInputs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/* 113 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 114 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginProcessingUrl(String loginProcessingUrl) {
/* 123 */     Assert.hasText(loginProcessingUrl, "loginProcessingUrl cannot be null or empty");
/* 124 */     this.loginProcessingUrl = loginProcessingUrl;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authenticatio\\ui\DefaultOneTimeTokenSubmitPageGeneratingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */