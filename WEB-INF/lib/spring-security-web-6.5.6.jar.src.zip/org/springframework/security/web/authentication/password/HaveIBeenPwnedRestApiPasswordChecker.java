/*     */ package org.springframework.security.web.authentication.password;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordChecker;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordDecision;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.client.RestClient;
/*     */ import org.springframework.web.client.RestClientException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HaveIBeenPwnedRestApiPasswordChecker
/*     */   implements CompromisedPasswordChecker
/*     */ {
/*     */   private static final String API_URL = "https://api.pwnedpasswords.com/range/";
/*     */   private static final int PREFIX_LENGTH = 5;
/*  53 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final MessageDigest sha1Digest;
/*     */   
/*  57 */   private RestClient restClient = RestClient.builder().baseUrl("https://api.pwnedpasswords.com/range/").build();
/*     */   
/*     */   public HaveIBeenPwnedRestApiPasswordChecker() {
/*  60 */     this.sha1Digest = getSha1Digest();
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public CompromisedPasswordDecision check(String password) {
/*  66 */     byte[] hash = this.sha1Digest.digest(password.getBytes(StandardCharsets.UTF_8));
/*  67 */     String encoded = (new String(Hex.encode(hash))).toUpperCase(Locale.ROOT);
/*  68 */     String prefix = encoded.substring(0, 5);
/*  69 */     String suffix = encoded.substring(5);
/*     */     
/*  71 */     List<String> passwords = getLeakedPasswordsForPrefix(prefix);
/*  72 */     boolean isLeaked = findLeakedPassword(passwords, suffix);
/*  73 */     return new CompromisedPasswordDecision(isLeaked);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRestClient(RestClient restClient) {
/*  82 */     Assert.notNull(restClient, "restClient cannot be null");
/*  83 */     this.restClient = restClient;
/*     */   }
/*     */   
/*     */   private boolean findLeakedPassword(List<String> passwords, String suffix) {
/*  87 */     for (String pw : passwords) {
/*  88 */       if (pw.startsWith(suffix)) {
/*  89 */         return true;
/*     */       }
/*     */     } 
/*  92 */     return false;
/*     */   }
/*     */   
/*     */   private List<String> getLeakedPasswordsForPrefix(String prefix) {
/*     */     try {
/*  97 */       String response = (String)this.restClient.get().uri(prefix, new Object[0]).retrieve().body(String.class);
/*  98 */       if (!StringUtils.hasText(response)) {
/*  99 */         return Collections.emptyList();
/*     */       }
/* 101 */       return response.lines().toList();
/*     */     }
/* 103 */     catch (RestClientException ex) {
/* 104 */       this.logger.error("Request for leaked passwords failed", (Throwable)ex);
/* 105 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static MessageDigest getSha1Digest() {
/*     */     try {
/* 111 */       return MessageDigest.getInstance("SHA-1");
/*     */     }
/* 113 */     catch (NoSuchAlgorithmException ex) {
/* 114 */       throw new RuntimeException(ex.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\password\HaveIBeenPwnedRestApiPasswordChecker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */