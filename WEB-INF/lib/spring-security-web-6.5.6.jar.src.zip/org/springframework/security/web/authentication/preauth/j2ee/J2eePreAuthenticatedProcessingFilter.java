/*    */ package org.springframework.security.web.authentication.preauth.j2ee;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class J2eePreAuthenticatedProcessingFilter
/*    */   extends AbstractPreAuthenticatedProcessingFilter
/*    */ {
/*    */   protected Object getPreAuthenticatedPrincipal(HttpServletRequest httpRequest) {
/* 39 */     Object principal = (httpRequest.getUserPrincipal() != null) ? httpRequest.getUserPrincipal().getName() : null;
/* 40 */     this.logger.debug(LogMessage.format("PreAuthenticated J2EE principal: %s", principal));
/* 41 */     return principal;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedCredentials(HttpServletRequest httpRequest) {
/* 50 */     return "N/A";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\j2ee\J2eePreAuthenticatedProcessingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */