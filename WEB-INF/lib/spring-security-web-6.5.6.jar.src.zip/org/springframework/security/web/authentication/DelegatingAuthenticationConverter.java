/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingAuthenticationConverter
/*    */   implements AuthenticationConverter
/*    */ {
/*    */   private final List<AuthenticationConverter> delegates;
/*    */   
/*    */   public DelegatingAuthenticationConverter(List<AuthenticationConverter> delegates) {
/* 39 */     Assert.notEmpty(delegates, "delegates cannot be null");
/* 40 */     this.delegates = List.copyOf(delegates);
/*    */   }
/*    */   
/*    */   public DelegatingAuthenticationConverter(AuthenticationConverter... delegates) {
/* 44 */     Assert.notEmpty((Object[])delegates, "delegates cannot be null");
/* 45 */     this.delegates = List.of(delegates);
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication convert(HttpServletRequest request) {
/* 50 */     for (AuthenticationConverter delegate : this.delegates) {
/* 51 */       Authentication authentication = delegate.convert(request);
/* 52 */       if (authentication != null) {
/* 53 */         return authentication;
/*    */       }
/*    */     } 
/* 56 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\DelegatingAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */