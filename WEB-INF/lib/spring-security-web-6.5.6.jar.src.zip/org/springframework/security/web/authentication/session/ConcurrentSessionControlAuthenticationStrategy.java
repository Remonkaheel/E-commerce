/*     */ package org.springframework.security.web.authentication.session;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.session.SessionInformation;
/*     */ import org.springframework.security.core.session.SessionRegistry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentSessionControlAuthenticationStrategy
/*     */   implements MessageSourceAware, SessionAuthenticationStrategy
/*     */ {
/*  73 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private final SessionRegistry sessionRegistry;
/*     */   
/*     */   private boolean exceptionIfMaximumExceeded = false;
/*     */   
/*  79 */   private SessionLimit sessionLimit = SessionLimit.of(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentSessionControlAuthenticationStrategy(SessionRegistry sessionRegistry) {
/*  86 */     Assert.notNull(sessionRegistry, "The sessionRegistry cannot be null");
/*  87 */     this.sessionRegistry = sessionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) {
/*  97 */     int allowedSessions = getMaximumSessionsForThisUser(authentication);
/*  98 */     if (allowedSessions == -1) {
/*     */       return;
/*     */     }
/*     */     
/* 102 */     List<SessionInformation> sessions = this.sessionRegistry.getAllSessions(authentication.getPrincipal(), false);
/* 103 */     int sessionCount = sessions.size();
/* 104 */     if (sessionCount < allowedSessions) {
/*     */       return;
/*     */     }
/*     */     
/* 108 */     if (sessionCount == allowedSessions) {
/* 109 */       HttpSession session = request.getSession(false);
/* 110 */       if (session != null)
/*     */       {
/*     */         
/* 113 */         for (SessionInformation si : sessions) {
/* 114 */           if (si.getSessionId().equals(session.getId())) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 122 */     allowableSessionsExceeded(sessions, allowedSessions, this.sessionRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaximumSessionsForThisUser(Authentication authentication) {
/* 133 */     return this.sessionLimit.apply(authentication).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void allowableSessionsExceeded(List<SessionInformation> sessions, int allowableSessions, SessionRegistry registry) throws SessionAuthenticationException {
/* 147 */     if (this.exceptionIfMaximumExceeded || sessions == null) {
/* 148 */       throw new SessionAuthenticationException(this.messages
/* 149 */           .getMessage("ConcurrentSessionControlAuthenticationStrategy.exceededAllowed", new Object[] {
/* 150 */               Integer.valueOf(allowableSessions) }, "Maximum sessions of {0} for this principal exceeded"));
/*     */     }
/*     */     
/* 153 */     sessions.sort(Comparator.comparing(SessionInformation::getLastRequest));
/* 154 */     int maximumSessionsExceededBy = sessions.size() - allowableSessions + 1;
/* 155 */     List<SessionInformation> sessionsToBeExpired = sessions.subList(0, maximumSessionsExceededBy);
/* 156 */     for (SessionInformation session : sessionsToBeExpired) {
/* 157 */       session.expireNow();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionIfMaximumExceeded(boolean exceptionIfMaximumExceeded) {
/* 171 */     this.exceptionIfMaximumExceeded = exceptionIfMaximumExceeded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximumSessions(int maximumSessions) {
/* 181 */     this.sessionLimit = SessionLimit.of(maximumSessions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximumSessions(SessionLimit sessionLimit) {
/* 191 */     Assert.notNull(sessionLimit, "sessionLimit cannot be null");
/* 192 */     this.sessionLimit = sessionLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 201 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 202 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\ConcurrentSessionControlAuthenticationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */