/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpStatusEntryPoint
/*    */   implements AuthenticationEntryPoint
/*    */ {
/*    */   private final HttpStatus httpStatus;
/*    */   
/*    */   public HttpStatusEntryPoint(HttpStatus httpStatus) {
/* 44 */     Assert.notNull(httpStatus, "httpStatus cannot be null");
/* 45 */     this.httpStatus = httpStatus;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) {
/* 51 */     response.setStatus(this.httpStatus.value());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\HttpStatusEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */