/*    */ package org.springframework.security.web.authentication.ott;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OneTimeTokenAuthenticationConverter
/*    */   implements AuthenticationConverter
/*    */ {
/* 39 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   
/*    */   public Authentication convert(HttpServletRequest request) {
/* 43 */     String token = request.getParameter("token");
/* 44 */     if (!StringUtils.hasText(token)) {
/* 45 */       this.logger.debug("No token found in request");
/* 46 */       return null;
/*    */     } 
/* 48 */     return (Authentication)OneTimeTokenAuthenticationToken.unauthenticated(token);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\OneTimeTokenAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */