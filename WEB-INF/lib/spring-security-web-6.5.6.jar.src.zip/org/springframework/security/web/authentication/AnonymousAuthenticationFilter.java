/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnonymousAuthenticationFilter
/*     */   extends GenericFilterBean
/*     */   implements InitializingBean
/*     */ {
/*  54 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  56 */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
/*     */ 
/*     */   
/*     */   private String key;
/*     */ 
/*     */   
/*     */   private Object principal;
/*     */ 
/*     */   
/*     */   private List<GrantedAuthority> authorities;
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousAuthenticationFilter(String key) {
/*  70 */     this(key, "anonymousUser", AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousAuthenticationFilter(String key, Object principal, List<GrantedAuthority> authorities) {
/*  79 */     Assert.hasLength(key, "key cannot be null or empty");
/*  80 */     Assert.notNull(principal, "Anonymous authentication principal must be set");
/*  81 */     Assert.notNull(authorities, "Anonymous authorities must be set");
/*  82 */     this.key = key;
/*  83 */     this.principal = principal;
/*  84 */     this.authorities = authorities;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  89 */     Assert.hasLength(this.key, "key must have length");
/*  90 */     Assert.notNull(this.principal, "Anonymous authentication principal must be set");
/*  91 */     Assert.notNull(this.authorities, "Anonymous authorities must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/*  97 */     Supplier<SecurityContext> deferredContext = this.securityContextHolderStrategy.getDeferredContext();
/*  98 */     this.securityContextHolderStrategy
/*  99 */       .setDeferredContext(defaultWithAnonymous((HttpServletRequest)req, deferredContext));
/* 100 */     chain.doFilter(req, res);
/*     */   }
/*     */ 
/*     */   
/*     */   private Supplier<SecurityContext> defaultWithAnonymous(HttpServletRequest request, Supplier<SecurityContext> currentDeferredContext) {
/* 105 */     return (Supplier<SecurityContext>)SingletonSupplier.of(() -> {
/*     */           SecurityContext currentContext = currentDeferredContext.get();
/*     */           return defaultWithAnonymous(request, currentContext);
/*     */         });
/*     */   }
/*     */   
/*     */   private SecurityContext defaultWithAnonymous(HttpServletRequest request, SecurityContext currentContext) {
/* 112 */     Authentication currentAuthentication = currentContext.getAuthentication();
/* 113 */     if (currentAuthentication == null) {
/* 114 */       Authentication anonymous = createAuthentication(request);
/* 115 */       if (this.logger.isTraceEnabled()) {
/* 116 */         this.logger.trace(LogMessage.of(() -> "Set SecurityContextHolder to " + String.valueOf(anonymous)));
/*     */       } else {
/*     */         
/* 119 */         this.logger.debug("Set SecurityContextHolder to anonymous SecurityContext");
/*     */       } 
/* 121 */       SecurityContext anonymousContext = this.securityContextHolderStrategy.createEmptyContext();
/* 122 */       anonymousContext.setAuthentication(anonymous);
/* 123 */       return anonymousContext;
/*     */     } 
/*     */     
/* 126 */     if (this.logger.isTraceEnabled()) {
/* 127 */       this.logger.trace(LogMessage.of(() -> "Did not set SecurityContextHolder since already authenticated " + String.valueOf(currentAuthentication)));
/*     */     }
/*     */ 
/*     */     
/* 131 */     return currentContext;
/*     */   }
/*     */   
/*     */   protected Authentication createAuthentication(HttpServletRequest request) {
/* 135 */     AnonymousAuthenticationToken token = new AnonymousAuthenticationToken(this.key, this.principal, this.authorities);
/*     */     
/* 137 */     token.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 138 */     return (Authentication)token;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 143 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/* 144 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 154 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 155 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public Object getPrincipal() {
/* 159 */     return this.principal;
/*     */   }
/*     */   
/*     */   public List<GrantedAuthority> getAuthorities() {
/* 163 */     return this.authorities;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\AnonymousAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */