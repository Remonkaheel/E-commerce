/*     */ package org.springframework.security.web.authentication.rememberme;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.event.InteractiveAuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RememberMeAuthenticationFilter
/*     */   extends GenericFilterBean
/*     */   implements ApplicationEventPublisherAware
/*     */ {
/*  74 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private ApplicationEventPublisher eventPublisher;
/*     */   
/*     */   private AuthenticationSuccessHandler successHandler;
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/*     */   private RememberMeServices rememberMeServices;
/*     */   
/*  84 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */   
/*  86 */   private SessionAuthenticationStrategy sessionStrategy = (SessionAuthenticationStrategy)new NullAuthenticatedSessionStrategy();
/*     */ 
/*     */   
/*     */   public RememberMeAuthenticationFilter(AuthenticationManager authenticationManager, RememberMeServices rememberMeServices) {
/*  90 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/*  91 */     Assert.notNull(rememberMeServices, "rememberMeServices cannot be null");
/*  92 */     this.authenticationManager = authenticationManager;
/*  93 */     this.rememberMeServices = rememberMeServices;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  98 */     Assert.notNull(this.authenticationManager, "authenticationManager must be specified");
/*  99 */     Assert.notNull(this.rememberMeServices, "rememberMeServices must be specified");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 105 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 110 */     if (this.securityContextHolderStrategy.getContext().getAuthentication() != null) {
/* 111 */       this.logger.debug(
/* 112 */           LogMessage.of(() -> "SecurityContextHolder not populated with remember-me token, as it already contained: '" + String.valueOf(this.securityContextHolderStrategy.getContext().getAuthentication()) + "'"));
/*     */       
/* 114 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/* 117 */     Authentication rememberMeAuth = this.rememberMeServices.autoLogin(request, response);
/* 118 */     if (rememberMeAuth != null) {
/*     */       
/*     */       try {
/* 121 */         rememberMeAuth = this.authenticationManager.authenticate(rememberMeAuth);
/* 122 */         this.sessionStrategy.onAuthentication(rememberMeAuth, request, response);
/*     */         
/* 124 */         SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 125 */         context.setAuthentication(rememberMeAuth);
/* 126 */         this.securityContextHolderStrategy.setContext(context);
/* 127 */         onSuccessfulAuthentication(request, response, rememberMeAuth);
/* 128 */         this.logger.debug(LogMessage.of(() -> "SecurityContextHolder populated with remember-me token: '" + String.valueOf(this.securityContextHolderStrategy.getContext().getAuthentication()) + "'"));
/*     */         
/* 130 */         this.securityContextRepository.saveContext(context, request, response);
/* 131 */         if (this.eventPublisher != null) {
/* 132 */           this.eventPublisher.publishEvent((ApplicationEvent)new InteractiveAuthenticationSuccessEvent(this.securityContextHolderStrategy
/* 133 */                 .getContext().getAuthentication(), getClass()));
/*     */         }
/* 135 */         if (this.successHandler != null) {
/* 136 */           this.successHandler.onAuthenticationSuccess(request, response, rememberMeAuth);
/*     */           
/*     */           return;
/*     */         } 
/* 140 */       } catch (AuthenticationException ex) {
/* 141 */         this.logger.debug(
/* 142 */             LogMessage.format("SecurityContextHolder not populated with remember-me token, as AuthenticationManager rejected Authentication returned by RememberMeServices: '%s'; invalidating remember-me token", rememberMeAuth), (Throwable)ex);
/*     */ 
/*     */ 
/*     */         
/* 146 */         this.rememberMeServices.loginFail(request, response);
/* 147 */         onUnsuccessfulAuthentication(request, response, ex);
/*     */       } 
/*     */     }
/* 150 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onSuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, Authentication authResult) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onUnsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeServices getRememberMeServices() {
/* 173 */     return this.rememberMeServices;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher eventPublisher) {
/* 178 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationSuccessHandler(AuthenticationSuccessHandler successHandler) {
/* 192 */     Assert.notNull(successHandler, "successHandler cannot be null");
/* 193 */     this.successHandler = successHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 204 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 205 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 215 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 216 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAuthenticationStrategy(SessionAuthenticationStrategy sessionStrategy) {
/* 229 */     Assert.notNull(sessionStrategy, "sessionStrategy cannot be null");
/* 230 */     this.sessionStrategy = sessionStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\RememberMeAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */