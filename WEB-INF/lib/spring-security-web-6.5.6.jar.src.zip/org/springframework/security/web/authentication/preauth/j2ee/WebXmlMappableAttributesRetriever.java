/*     */ package org.springframework.security.web.authentication.preauth.j2ee;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.FactoryConfigurationError;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.security.core.authority.mapping.MappableAttributesRetriever;
/*     */ import org.springframework.util.Assert;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebXmlMappableAttributesRetriever
/*     */   implements ResourceLoaderAware, MappableAttributesRetriever, InitializingBean
/*     */ {
/*  61 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   private Set<String> mappableAttributes;
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/*  69 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getMappableAttributes() {
/*  74 */     return this.mappableAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  84 */     Resource webXml = this.resourceLoader.getResource("/WEB-INF/web.xml");
/*  85 */     Document doc = getDocument(webXml.getInputStream());
/*  86 */     NodeList webApp = doc.getElementsByTagName("web-app");
/*  87 */     Assert.isTrue((webApp.getLength() == 1), () -> "Failed to find 'web-app' element in resource" + String.valueOf(webXml));
/*  88 */     NodeList securityRoles = ((Element)webApp.item(0)).getElementsByTagName("security-role");
/*  89 */     List<String> roleNames = getRoleNames(webXml, securityRoles);
/*  90 */     this.mappableAttributes = Collections.unmodifiableSet(new HashSet<>(roleNames));
/*     */   }
/*     */   
/*     */   private List<String> getRoleNames(Resource webXml, NodeList securityRoles) {
/*  94 */     ArrayList<String> roleNames = new ArrayList<>();
/*  95 */     for (int i = 0; i < securityRoles.getLength(); i++) {
/*  96 */       Element securityRoleElement = (Element)securityRoles.item(i);
/*  97 */       NodeList roles = securityRoleElement.getElementsByTagName("role-name");
/*  98 */       if (roles.getLength() > 0) {
/*  99 */         String roleName = roles.item(0).getTextContent().trim();
/* 100 */         roleNames.add(roleName);
/* 101 */         this.logger.info("Retrieved role-name '" + roleName + "' from web.xml");
/*     */       } else {
/*     */         
/* 104 */         this.logger.info("No security-role elements found in " + String.valueOf(webXml));
/*     */       } 
/*     */     } 
/* 107 */     return roleNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Document getDocument(InputStream aStream) {
/*     */     try {
/* 115 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 116 */       factory.setValidating(false);
/* 117 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 118 */       builder.setEntityResolver(new MyEntityResolver());
/* 119 */       return builder.parse(aStream);
/*     */     }
/* 121 */     catch (FactoryConfigurationError|IOException|org.xml.sax.SAXException|javax.xml.parsers.ParserConfigurationException ex) {
/* 122 */       throw new RuntimeException("Unable to parse document object", ex);
/*     */     } finally {
/*     */       
/*     */       try {
/* 126 */         aStream.close();
/*     */       }
/* 128 */       catch (IOException ex) {
/* 129 */         this.logger.warn("Failed to close input stream for web.xml", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MyEntityResolver
/*     */     implements EntityResolver
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId) {
/* 141 */       return new InputSource(new StringReader(""));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\j2ee\WebXmlMappableAttributesRetriever.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */