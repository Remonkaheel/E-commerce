/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingAuthenticationEntryPoint
/*     */   implements AuthenticationEntryPoint, InitializingBean
/*     */ {
/*  65 */   private static final Log logger = LogFactory.getLog(DelegatingAuthenticationEntryPoint.class);
/*     */   
/*     */   private final LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> entryPoints;
/*     */   
/*     */   private AuthenticationEntryPoint defaultEntryPoint;
/*     */   
/*     */   public DelegatingAuthenticationEntryPoint(LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> entryPoints) {
/*  72 */     this.entryPoints = entryPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
/*  78 */     for (RequestMatcher requestMatcher : this.entryPoints.keySet()) {
/*  79 */       logger.debug(LogMessage.format("Trying to match using %s", requestMatcher));
/*  80 */       if (requestMatcher.matches(request)) {
/*  81 */         AuthenticationEntryPoint entryPoint = this.entryPoints.get(requestMatcher);
/*  82 */         logger.debug(LogMessage.format("Match found! Executing %s", entryPoint));
/*  83 */         entryPoint.commence(request, response, authException);
/*     */         return;
/*     */       } 
/*     */     } 
/*  87 */     logger.debug(LogMessage.format("No match found. Using default entry point %s", this.defaultEntryPoint));
/*     */     
/*  89 */     this.defaultEntryPoint.commence(request, response, authException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultEntryPoint(AuthenticationEntryPoint defaultEntryPoint) {
/*  96 */     this.defaultEntryPoint = defaultEntryPoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 101 */     Assert.notEmpty(this.entryPoints, "entryPoints must be specified");
/* 102 */     Assert.notNull(this.defaultEntryPoint, "defaultEntryPoint must be specified");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\DelegatingAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */