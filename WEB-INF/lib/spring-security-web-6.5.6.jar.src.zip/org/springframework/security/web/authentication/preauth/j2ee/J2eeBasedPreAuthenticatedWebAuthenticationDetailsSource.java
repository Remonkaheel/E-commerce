/*     */ package org.springframework.security.web.authentication.preauth.j2ee;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.mapping.Attributes2GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.MappableAttributesRetriever;
/*     */ import org.springframework.security.core.authority.mapping.SimpleAttributes2GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource
/*     */   implements AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails>, InitializingBean
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> j2eeMappableRoles;
/*     */ 
/*     */   
/*  57 */   protected Attributes2GrantedAuthoritiesMapper j2eeUserRoles2GrantedAuthoritiesMapper = (Attributes2GrantedAuthoritiesMapper)new SimpleAttributes2GrantedAuthoritiesMapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  64 */     Assert.notNull(this.j2eeMappableRoles, "No mappable roles available");
/*  65 */     Assert.notNull(this.j2eeUserRoles2GrantedAuthoritiesMapper, "Roles to granted authorities mapper not set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<String> getUserRoles(HttpServletRequest request) {
/*  78 */     ArrayList<String> j2eeUserRolesList = new ArrayList<>();
/*  79 */     for (String role : this.j2eeMappableRoles) {
/*  80 */       if (request.isUserInRole(role)) {
/*  81 */         j2eeUserRolesList.add(role);
/*     */       }
/*     */     } 
/*  84 */     return j2eeUserRolesList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails buildDetails(HttpServletRequest context) {
/*  94 */     Collection<String> j2eeUserRoles = getUserRoles(context);
/*     */     
/*  96 */     Collection<? extends GrantedAuthority> userGrantedAuthorities = this.j2eeUserRoles2GrantedAuthoritiesMapper.getGrantedAuthorities(j2eeUserRoles);
/*  97 */     if (this.logger.isDebugEnabled()) {
/*  98 */       this.logger.debug(LogMessage.format("J2EE roles [%s] mapped to Granted Authorities: [%s]", j2eeUserRoles, userGrantedAuthorities));
/*     */     }
/*     */     
/* 101 */     return new PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails(context, userGrantedAuthorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappableRolesRetriever(MappableAttributesRetriever aJ2eeMappableRolesRetriever) {
/* 108 */     this.j2eeMappableRoles = Collections.unmodifiableSet(aJ2eeMappableRolesRetriever.getMappableAttributes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserRoles2GrantedAuthoritiesMapper(Attributes2GrantedAuthoritiesMapper mapper) {
/* 115 */     this.j2eeUserRoles2GrantedAuthoritiesMapper = mapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\j2ee\J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */