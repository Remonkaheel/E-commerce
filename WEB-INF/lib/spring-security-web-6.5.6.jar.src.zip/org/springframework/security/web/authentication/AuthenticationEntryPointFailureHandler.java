/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.authentication.AuthenticationServiceException;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationEntryPointFailureHandler
/*    */   implements AuthenticationFailureHandler
/*    */ {
/*    */   private boolean rethrowAuthenticationServiceException = true;
/*    */   private final AuthenticationEntryPoint authenticationEntryPoint;
/*    */   
/*    */   public AuthenticationEntryPointFailureHandler(AuthenticationEntryPoint authenticationEntryPoint) {
/* 43 */     Assert.notNull(authenticationEntryPoint, "authenticationEntryPoint cannot be null");
/* 44 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
/* 50 */     if (!this.rethrowAuthenticationServiceException) {
/* 51 */       this.authenticationEntryPoint.commence(request, response, exception);
/*    */       return;
/*    */     } 
/* 54 */     if (!AuthenticationServiceException.class.isAssignableFrom(exception.getClass())) {
/* 55 */       this.authenticationEntryPoint.commence(request, response, exception);
/*    */       return;
/*    */     } 
/* 58 */     throw exception;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRethrowAuthenticationServiceException(boolean rethrowAuthenticationServiceException) {
/* 68 */     this.rethrowAuthenticationServiceException = rethrowAuthenticationServiceException;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\AuthenticationEntryPointFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */