/*    */ package org.springframework.security.web.authentication.rememberme;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RememberMeAuthenticationException
/*    */   extends AuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = 7028526952590057426L;
/*    */   
/*    */   public RememberMeAuthenticationException(String msg, Throwable cause) {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RememberMeAuthenticationException(String msg) {
/* 51 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\RememberMeAuthenticationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */