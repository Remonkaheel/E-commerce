/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Base64;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthenticationEntryPoint
/*     */   implements AuthenticationEntryPoint, InitializingBean, Ordered
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(DigestAuthenticationEntryPoint.class);
/*     */   
/*     */   private String key;
/*     */   
/*     */   private String realmName;
/*     */   
/*  57 */   private int nonceValiditySeconds = 300;
/*     */   
/*  59 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  63 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  67 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  72 */     Assert.hasLength(this.realmName, "realmName must be specified");
/*  73 */     Assert.hasLength(this.key, "key must be specified");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
/*  81 */     long expiryTime = System.currentTimeMillis() + (this.nonceValiditySeconds * 1000);
/*  82 */     String signatureValue = DigestAuthUtils.md5Hex("" + expiryTime + ":" + expiryTime);
/*  83 */     String nonceValue = "" + expiryTime + ":" + expiryTime;
/*  84 */     String nonceValueBase64 = new String(Base64.getEncoder().encode(nonceValue.getBytes()));
/*     */ 
/*     */ 
/*     */     
/*  88 */     String authenticateHeader = "Digest realm=\"" + this.realmName + "\", qop=\"auth\", nonce=\"" + nonceValueBase64 + "\"";
/*     */     
/*  90 */     if (authException instanceof NonceExpiredException) {
/*  91 */       authenticateHeader = authenticateHeader + ", stale=\"true\"";
/*     */     }
/*  93 */     logger.debug(LogMessage.format("WWW-Authenticate header sent to user agent: %s", authenticateHeader));
/*  94 */     response.addHeader("WWW-Authenticate", authenticateHeader);
/*  95 */     response.sendError(HttpStatus.UNAUTHORIZED.value(), HttpStatus.UNAUTHORIZED.getReasonPhrase());
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  99 */     return this.key;
/*     */   }
/*     */   
/*     */   public int getNonceValiditySeconds() {
/* 103 */     return this.nonceValiditySeconds;
/*     */   }
/*     */   
/*     */   public String getRealmName() {
/* 107 */     return this.realmName;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/* 111 */     this.key = key;
/*     */   }
/*     */   
/*     */   public void setNonceValiditySeconds(int nonceValiditySeconds) {
/* 115 */     this.nonceValiditySeconds = nonceValiditySeconds;
/*     */   }
/*     */   
/*     */   public void setRealmName(String realmName) {
/* 119 */     this.realmName = realmName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\DigestAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */