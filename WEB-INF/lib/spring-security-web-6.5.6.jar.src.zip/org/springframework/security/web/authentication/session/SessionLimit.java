/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SessionLimit
/*    */   extends Function<Authentication, Integer>
/*    */ {
/*    */   public static final SessionLimit UNLIMITED = authentication -> Integer.valueOf(-1);
/*    */   
/*    */   static SessionLimit of(int maxSessions) {
/* 44 */     Assert.isTrue((maxSessions != 0), "MaximumLogins must be either -1 to allow unlimited logins, or a positive integer to specify a maximum");
/*    */     
/* 46 */     return authentication -> Integer.valueOf(maxSessions);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\SessionLimit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */