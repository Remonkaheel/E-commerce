/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionAuthenticationException
/*    */   extends AuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = -2359914603911936474L;
/*    */   
/*    */   public SessionAuthenticationException(String msg) {
/* 40 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\SessionAuthenticationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */