/*    */ package org.springframework.security.web.authentication.logout;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderWriterLogoutHandler
/*    */   implements LogoutHandler
/*    */ {
/*    */   private final HeaderWriter headerWriter;
/*    */   
/*    */   public HeaderWriterLogoutHandler(HeaderWriter headerWriter) {
/* 40 */     Assert.notNull(headerWriter, "headerWriter cannot be null");
/* 41 */     this.headerWriter = headerWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 46 */     this.headerWriter.writeHeaders(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\HeaderWriterLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */