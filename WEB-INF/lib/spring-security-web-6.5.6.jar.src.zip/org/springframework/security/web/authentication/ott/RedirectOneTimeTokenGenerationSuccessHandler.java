/*    */ package org.springframework.security.web.authentication.ott;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.authentication.ott.OneTimeToken;
/*    */ import org.springframework.security.web.DefaultRedirectStrategy;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RedirectOneTimeTokenGenerationSuccessHandler
/*    */   implements OneTimeTokenGenerationSuccessHandler
/*    */ {
/* 38 */   private final RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*    */ 
/*    */ 
/*    */   
/*    */   private final String redirectUrl;
/*    */ 
/*    */ 
/*    */   
/*    */   public RedirectOneTimeTokenGenerationSuccessHandler(String redirectUrl) {
/* 47 */     Assert.hasText(redirectUrl, "redirectUrl cannot be empty or null");
/* 48 */     this.redirectUrl = redirectUrl;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, OneTimeToken oneTimeToken) throws IOException {
/* 54 */     this.redirectStrategy.sendRedirect(request, response, this.redirectUrl);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\RedirectOneTimeTokenGenerationSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */