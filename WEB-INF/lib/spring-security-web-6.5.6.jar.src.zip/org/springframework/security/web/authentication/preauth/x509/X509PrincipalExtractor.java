package org.springframework.security.web.authentication.preauth.x509;

import java.security.cert.X509Certificate;

@FunctionalInterface
public interface X509PrincipalExtractor {
  Object extractPrincipal(X509Certificate paramX509Certificate);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\x509\X509PrincipalExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */