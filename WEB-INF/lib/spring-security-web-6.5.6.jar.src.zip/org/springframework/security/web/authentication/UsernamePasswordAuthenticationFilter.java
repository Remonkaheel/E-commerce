/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UsernamePasswordAuthenticationFilter
/*     */   extends AbstractAuthenticationProcessingFilter
/*     */ {
/*     */   public static final String SPRING_SECURITY_FORM_USERNAME_KEY = "username";
/*     */   public static final String SPRING_SECURITY_FORM_PASSWORD_KEY = "password";
/*  56 */   private static final RequestMatcher DEFAULT_ANT_PATH_REQUEST_MATCHER = (RequestMatcher)PathPatternRequestMatcher.withDefaults()
/*  57 */     .matcher(HttpMethod.POST, "/login");
/*     */   
/*  59 */   private String usernameParameter = "username";
/*     */   
/*  61 */   private String passwordParameter = "password";
/*     */   
/*     */   private boolean postOnly = true;
/*     */   
/*     */   public UsernamePasswordAuthenticationFilter() {
/*  66 */     super(DEFAULT_ANT_PATH_REQUEST_MATCHER);
/*     */   }
/*     */   
/*     */   public UsernamePasswordAuthenticationFilter(AuthenticationManager authenticationManager) {
/*  70 */     super(DEFAULT_ANT_PATH_REQUEST_MATCHER, authenticationManager);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
/*  76 */     if (this.postOnly && !request.getMethod().equals("POST")) {
/*  77 */       throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
/*     */     }
/*  79 */     String username = obtainUsername(request);
/*  80 */     username = (username != null) ? username.trim() : "";
/*  81 */     String password = obtainPassword(request);
/*  82 */     password = (password != null) ? password : "";
/*  83 */     UsernamePasswordAuthenticationToken authRequest = UsernamePasswordAuthenticationToken.unauthenticated(username, password);
/*     */ 
/*     */     
/*  86 */     setDetails(request, authRequest);
/*  87 */     return getAuthenticationManager().authenticate((Authentication)authRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String obtainPassword(HttpServletRequest request) {
/* 105 */     return request.getParameter(this.passwordParameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String obtainUsername(HttpServletRequest request) {
/* 117 */     return request.getParameter(this.usernameParameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDetails(HttpServletRequest request, UsernamePasswordAuthenticationToken authRequest) {
/* 128 */     authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsernameParameter(String usernameParameter) {
/* 137 */     Assert.hasText(usernameParameter, "Username parameter must not be empty or null");
/* 138 */     this.usernameParameter = usernameParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPasswordParameter(String passwordParameter) {
/* 147 */     Assert.hasText(passwordParameter, "Password parameter must not be empty or null");
/* 148 */     this.passwordParameter = passwordParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPostOnly(boolean postOnly) {
/* 161 */     this.postOnly = postOnly;
/*     */   }
/*     */   
/*     */   public final String getUsernameParameter() {
/* 165 */     return this.usernameParameter;
/*     */   }
/*     */   
/*     */   public final String getPasswordParameter() {
/* 169 */     return this.passwordParameter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\UsernamePasswordAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */