/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.PortMapperImpl;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.PortResolverImpl;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.util.RedirectUrlBuilder;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoginUrlAuthenticationEntryPoint
/*     */   implements AuthenticationEntryPoint, InitializingBean
/*     */ {
/*  69 */   private static final Log logger = LogFactory.getLog(LoginUrlAuthenticationEntryPoint.class);
/*     */   
/*  71 */   private PortMapper portMapper = (PortMapper)new PortMapperImpl();
/*     */   
/*  73 */   private PortResolver portResolver = (PortResolver)new PortResolverImpl();
/*     */   
/*     */   private String loginFormUrl;
/*     */   
/*     */   private boolean forceHttps = false;
/*     */   
/*     */   private boolean useForward = false;
/*     */   
/*     */   private boolean favorRelativeUris = false;
/*     */   
/*  83 */   private final RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoginUrlAuthenticationEntryPoint(String loginFormUrl) {
/*  91 */     Assert.notNull(loginFormUrl, "loginFormUrl cannot be null");
/*  92 */     this.loginFormUrl = loginFormUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  97 */     Assert.isTrue((StringUtils.hasText(this.loginFormUrl) && UrlUtils.isValidRedirectUrl(this.loginFormUrl)), "loginFormUrl must be specified and must be a valid redirect URL");
/*     */     
/*  99 */     Assert.isTrue((!this.useForward || !UrlUtils.isAbsoluteUrl(this.loginFormUrl)), "useForward must be false if using an absolute loginFormURL");
/*     */     
/* 101 */     Assert.notNull(this.portMapper, "portMapper must be specified");
/* 102 */     Assert.notNull(this.portResolver, "portResolver must be specified");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineUrlToUseForThisRequest(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) {
/* 115 */     return getLoginFormUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
/* 124 */     if (!this.useForward) {
/*     */       
/* 126 */       String str = buildRedirectUrlToLoginPage(request, response, authException);
/* 127 */       this.redirectStrategy.sendRedirect(request, response, str);
/*     */       return;
/*     */     } 
/* 130 */     String redirectUrl = null;
/* 131 */     if (this.forceHttps && "http".equals(request.getScheme()))
/*     */     {
/*     */       
/* 134 */       redirectUrl = buildHttpsRedirectUrlForRequest(request);
/*     */     }
/* 136 */     if (redirectUrl != null) {
/* 137 */       this.redirectStrategy.sendRedirect(request, response, redirectUrl);
/*     */       return;
/*     */     } 
/* 140 */     String loginForm = determineUrlToUseForThisRequest(request, response, authException);
/* 141 */     logger.debug(LogMessage.format("Server side forward to: %s", loginForm));
/* 142 */     RequestDispatcher dispatcher = request.getRequestDispatcher(loginForm);
/* 143 */     dispatcher.forward((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String buildRedirectUrlToLoginPage(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) {
/* 148 */     String loginForm = determineUrlToUseForThisRequest(request, response, authException);
/* 149 */     if (UrlUtils.isAbsoluteUrl(loginForm)) {
/* 150 */       return loginForm;
/*     */     }
/* 152 */     if (requiresRewrite(request)) {
/* 153 */       return httpsUri(request, loginForm);
/*     */     }
/* 155 */     return this.favorRelativeUris ? loginForm : absoluteUri(request, loginForm).getUrl();
/*     */   }
/*     */   
/*     */   private boolean requiresRewrite(HttpServletRequest request) {
/* 159 */     return (this.forceHttps && "http".equals(request.getScheme()));
/*     */   }
/*     */   
/*     */   private String httpsUri(HttpServletRequest request, String path) {
/* 163 */     int serverPort = this.portResolver.getServerPort((ServletRequest)request);
/* 164 */     Integer httpsPort = this.portMapper.lookupHttpsPort(Integer.valueOf(serverPort));
/* 165 */     if (httpsPort == null) {
/* 166 */       logger.warn(LogMessage.format("Unable to redirect to HTTPS as no port mapping found for HTTP port %s", 
/* 167 */             Integer.valueOf(serverPort)));
/* 168 */       return this.favorRelativeUris ? path : absoluteUri(request, path).getUrl();
/*     */     } 
/* 170 */     RedirectUrlBuilder builder = absoluteUri(request, path);
/* 171 */     builder.setScheme("https");
/* 172 */     builder.setPort(httpsPort.intValue());
/* 173 */     return builder.getUrl();
/*     */   }
/*     */   
/*     */   private RedirectUrlBuilder absoluteUri(HttpServletRequest request, String path) {
/* 177 */     RedirectUrlBuilder urlBuilder = new RedirectUrlBuilder();
/* 178 */     urlBuilder.setScheme(request.getScheme());
/* 179 */     urlBuilder.setServerName(request.getServerName());
/* 180 */     urlBuilder.setPort(this.portResolver.getServerPort((ServletRequest)request));
/* 181 */     urlBuilder.setContextPath(request.getContextPath());
/* 182 */     urlBuilder.setPathInfo(path);
/* 183 */     return urlBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildHttpsRedirectUrlForRequest(HttpServletRequest request) throws IOException, ServletException {
/* 191 */     int serverPort = this.portResolver.getServerPort((ServletRequest)request);
/* 192 */     Integer httpsPort = this.portMapper.lookupHttpsPort(Integer.valueOf(serverPort));
/* 193 */     if (httpsPort != null) {
/* 194 */       RedirectUrlBuilder urlBuilder = new RedirectUrlBuilder();
/* 195 */       urlBuilder.setScheme("https");
/* 196 */       urlBuilder.setServerName(request.getServerName());
/* 197 */       urlBuilder.setPort(httpsPort.intValue());
/* 198 */       urlBuilder.setContextPath(request.getContextPath());
/* 199 */       urlBuilder.setServletPath(request.getServletPath());
/* 200 */       urlBuilder.setPathInfo(request.getPathInfo());
/* 201 */       urlBuilder.setQuery(request.getQueryString());
/* 202 */       return urlBuilder.getUrl();
/*     */     } 
/*     */     
/* 205 */     logger.warn(
/* 206 */         LogMessage.format("Unable to redirect to HTTPS as no port mapping found for HTTP port %s", Integer.valueOf(serverPort)));
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForceHttps(boolean forceHttps) {
/* 218 */     this.forceHttps = forceHttps;
/*     */   }
/*     */   
/*     */   protected boolean isForceHttps() {
/* 222 */     return this.forceHttps;
/*     */   }
/*     */   
/*     */   public String getLoginFormUrl() {
/* 226 */     return this.loginFormUrl;
/*     */   }
/*     */   
/*     */   public void setPortMapper(PortMapper portMapper) {
/* 230 */     Assert.notNull(portMapper, "portMapper cannot be null");
/* 231 */     this.portMapper = portMapper;
/*     */   }
/*     */   
/*     */   protected PortMapper getPortMapper() {
/* 235 */     return this.portMapper;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public void setPortResolver(PortResolver portResolver) {
/* 240 */     Assert.notNull(portResolver, "portResolver cannot be null");
/* 241 */     this.portResolver = portResolver;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   protected PortResolver getPortResolver() {
/* 246 */     return this.portResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseForward(boolean useForward) {
/* 256 */     this.useForward = useForward;
/*     */   }
/*     */   
/*     */   protected boolean isUseForward() {
/* 260 */     return this.useForward;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFavorRelativeUris(boolean favorRelativeUris) {
/* 274 */     this.favorRelativeUris = favorRelativeUris;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\LoginUrlAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */