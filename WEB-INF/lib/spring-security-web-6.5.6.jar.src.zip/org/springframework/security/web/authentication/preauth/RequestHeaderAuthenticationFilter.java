/*     */ package org.springframework.security.web.authentication.preauth;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestHeaderAuthenticationFilter
/*     */   extends AbstractPreAuthenticatedProcessingFilter
/*     */ {
/*  48 */   private String principalRequestHeader = "SM_USER";
/*     */ 
/*     */ 
/*     */   
/*     */   private String credentialsRequestHeader;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean exceptionIfHeaderMissing = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
/*  62 */     String principal = request.getHeader(this.principalRequestHeader);
/*  63 */     if (principal == null && this.exceptionIfHeaderMissing) {
/*  64 */       throw new PreAuthenticatedCredentialsNotFoundException(this.principalRequestHeader + " header not found in request.");
/*     */     }
/*     */     
/*  67 */     return principal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
/*  77 */     if (this.credentialsRequestHeader != null) {
/*  78 */       return request.getHeader(this.credentialsRequestHeader);
/*     */     }
/*  80 */     return "N/A";
/*     */   }
/*     */   
/*     */   public void setPrincipalRequestHeader(String principalRequestHeader) {
/*  84 */     Assert.hasText(principalRequestHeader, "principalRequestHeader must not be empty or null");
/*  85 */     this.principalRequestHeader = principalRequestHeader;
/*     */   }
/*     */   
/*     */   public void setCredentialsRequestHeader(String credentialsRequestHeader) {
/*  89 */     Assert.hasText(credentialsRequestHeader, "credentialsRequestHeader must not be empty or null");
/*  90 */     this.credentialsRequestHeader = credentialsRequestHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionIfHeaderMissing(boolean exceptionIfHeaderMissing) {
/* 100 */     this.exceptionIfHeaderMissing = exceptionIfHeaderMissing;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\RequestHeaderAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */