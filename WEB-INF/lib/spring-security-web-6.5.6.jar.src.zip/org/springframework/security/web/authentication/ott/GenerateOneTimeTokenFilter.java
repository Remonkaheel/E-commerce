/*     */ package org.springframework.security.web.authentication.ott;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
/*     */ import org.springframework.security.authentication.ott.OneTimeToken;
/*     */ import org.springframework.security.authentication.ott.OneTimeTokenService;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GenerateOneTimeTokenFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_GENERATE_URL = "/ott/generate";
/*     */   private final OneTimeTokenService tokenService;
/*     */   private final OneTimeTokenGenerationSuccessHandler tokenGenerationSuccessHandler;
/*  51 */   private RequestMatcher requestMatcher = (RequestMatcher)PathPatternRequestMatcher.withDefaults()
/*  52 */     .matcher(HttpMethod.POST, "/ott/generate");
/*     */   
/*  54 */   private GenerateOneTimeTokenRequestResolver requestResolver = new DefaultGenerateOneTimeTokenRequestResolver();
/*     */ 
/*     */   
/*     */   public GenerateOneTimeTokenFilter(OneTimeTokenService tokenService, OneTimeTokenGenerationSuccessHandler tokenGenerationSuccessHandler) {
/*  58 */     Assert.notNull(tokenService, "tokenService cannot be null");
/*  59 */     Assert.notNull(tokenGenerationSuccessHandler, "tokenGenerationSuccessHandler cannot be null");
/*  60 */     this.tokenService = tokenService;
/*  61 */     this.tokenGenerationSuccessHandler = tokenGenerationSuccessHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*  67 */     if (!this.requestMatcher.matches(request)) {
/*  68 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  71 */     String username = request.getParameter("username");
/*  72 */     if (!StringUtils.hasText(username)) {
/*  73 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  76 */     GenerateOneTimeTokenRequest generateRequest = this.requestResolver.resolve(request);
/*  77 */     OneTimeToken ott = this.tokenService.generate(generateRequest);
/*  78 */     if (generateRequest == null) {
/*  79 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  82 */     this.tokenGenerationSuccessHandler.handle(request, response, ott);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/*  90 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/*  91 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestResolver(GenerateOneTimeTokenRequestResolver requestResolver) {
/* 101 */     Assert.notNull(requestResolver, "requestResolver cannot be null");
/* 102 */     this.requestResolver = requestResolver;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\GenerateOneTimeTokenFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */