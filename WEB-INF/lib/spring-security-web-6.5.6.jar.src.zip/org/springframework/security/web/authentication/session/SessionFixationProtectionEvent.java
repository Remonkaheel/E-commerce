/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import org.springframework.security.authentication.event.AbstractAuthenticationEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionFixationProtectionEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = -2554621992006921150L;
/*    */   private final String oldSessionId;
/*    */   private final String newSessionId;
/*    */   
/*    */   public SessionFixationProtectionEvent(Authentication authentication, String oldSessionId, String newSessionId) {
/* 48 */     super(authentication);
/* 49 */     Assert.hasLength(oldSessionId, "oldSessionId must have length");
/* 50 */     Assert.hasLength(newSessionId, "newSessionId must have length");
/* 51 */     this.oldSessionId = oldSessionId;
/* 52 */     this.newSessionId = newSessionId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getOldSessionId() {
/* 60 */     return this.oldSessionId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getNewSessionId() {
/* 68 */     return this.newSessionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\SessionFixationProtectionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */