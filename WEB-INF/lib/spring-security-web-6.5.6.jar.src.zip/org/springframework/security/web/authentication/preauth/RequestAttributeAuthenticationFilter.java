/*    */ package org.springframework.security.web.authentication.preauth;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestAttributeAuthenticationFilter
/*    */   extends AbstractPreAuthenticatedProcessingFilter
/*    */ {
/* 47 */   private String principalEnvironmentVariable = "REMOTE_USER";
/*    */ 
/*    */ 
/*    */   
/*    */   private String credentialsEnvironmentVariable;
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean exceptionIfVariableMissing = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
/* 61 */     String principal = (String)request.getAttribute(this.principalEnvironmentVariable);
/* 62 */     if (principal == null && this.exceptionIfVariableMissing) {
/* 63 */       throw new PreAuthenticatedCredentialsNotFoundException(this.principalEnvironmentVariable + " variable not found in request.");
/*    */     }
/*    */     
/* 66 */     return principal;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
/* 76 */     if (this.credentialsEnvironmentVariable != null) {
/* 77 */       return request.getAttribute(this.credentialsEnvironmentVariable);
/*    */     }
/* 79 */     return "N/A";
/*    */   }
/*    */   
/*    */   public void setPrincipalEnvironmentVariable(String principalEnvironmentVariable) {
/* 83 */     Assert.hasText(principalEnvironmentVariable, "principalEnvironmentVariable must not be empty or null");
/* 84 */     this.principalEnvironmentVariable = principalEnvironmentVariable;
/*    */   }
/*    */   
/*    */   public void setCredentialsEnvironmentVariable(String credentialsEnvironmentVariable) {
/* 88 */     Assert.hasText(credentialsEnvironmentVariable, "credentialsEnvironmentVariable must not be empty or null");
/* 89 */     this.credentialsEnvironmentVariable = credentialsEnvironmentVariable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExceptionIfVariableMissing(boolean exceptionIfVariableMissing) {
/* 99 */     this.exceptionIfVariableMissing = exceptionIfVariableMissing;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\RequestAttributeAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */