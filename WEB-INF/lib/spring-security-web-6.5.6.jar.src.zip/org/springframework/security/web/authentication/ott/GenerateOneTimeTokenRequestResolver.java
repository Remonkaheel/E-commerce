package org.springframework.security.web.authentication.ott;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.lang.Nullable;
import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;

public interface GenerateOneTimeTokenRequestResolver {
  @Nullable
  GenerateOneTimeTokenRequest resolve(HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\GenerateOneTimeTokenRequestResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */