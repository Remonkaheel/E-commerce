/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.web.util.UrlUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForwardAuthenticationFailureHandler
/*    */   implements AuthenticationFailureHandler
/*    */ {
/*    */   private final String forwardUrl;
/*    */   
/*    */   public ForwardAuthenticationFailureHandler(String forwardUrl) {
/* 46 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(forwardUrl), () -> "'" + forwardUrl + "' is not a valid forward URL");
/* 47 */     this.forwardUrl = forwardUrl;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
/* 53 */     request.setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
/* 54 */     request.getRequestDispatcher(this.forwardUrl).forward((ServletRequest)request, (ServletResponse)response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ForwardAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */