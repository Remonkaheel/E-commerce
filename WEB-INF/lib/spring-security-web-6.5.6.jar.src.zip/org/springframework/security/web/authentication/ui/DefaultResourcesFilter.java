/*     */ package org.springframework.security.web.authentication.ui;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultResourcesFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   private final RequestMatcher matcher;
/*     */   private final ClassPathResource resource;
/*     */   private final MediaType mediaType;
/*     */   
/*     */   private DefaultResourcesFilter(RequestMatcher matcher, ClassPathResource resource, MediaType mediaType) {
/*  52 */     Assert.isTrue(resource.exists(), "classpath resource must exist");
/*  53 */     this.matcher = matcher;
/*  54 */     this.resource = resource;
/*  55 */     this.mediaType = mediaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*     */     HttpServletRequest servletRequest;
/*  61 */     if (request instanceof HttpServletRequest) { servletRequest = (HttpServletRequest)request; }
/*  62 */     else { filterChain.doFilter(request, response);
/*     */       
/*     */       return; }
/*     */     
/*  66 */     if (this.matcher.matches(servletRequest)) {
/*  67 */       response.setContentType(this.mediaType.toString());
/*  68 */       response.getWriter().write(this.resource.getContentAsString(StandardCharsets.UTF_8));
/*     */       
/*     */       return;
/*     */     } 
/*  72 */     filterChain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     return "%s [matcher=%s, resource=%s]".formatted(new Object[] { getClass().getSimpleName(), this.matcher.toString(), this.resource
/*  78 */           .getPath() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultResourcesFilter css() {
/*  92 */     return new DefaultResourcesFilter(
/*  93 */         (RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(HttpMethod.GET, "/default-ui.css"), new ClassPathResource("org/springframework/security/default-ui.css"), new MediaType("text", "css", StandardCharsets.UTF_8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultResourcesFilter webauthn() {
/* 110 */     return new DefaultResourcesFilter(
/* 111 */         (RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(HttpMethod.GET, "/login/webauthn.js"), new ClassPathResource("org/springframework/security/spring-security-webauthn.js"), new MediaType("text", "javascript", StandardCharsets.UTF_8));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authenticatio\\ui\DefaultResourcesFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */