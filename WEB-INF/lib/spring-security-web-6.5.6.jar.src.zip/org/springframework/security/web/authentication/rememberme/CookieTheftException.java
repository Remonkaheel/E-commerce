/*    */ package org.springframework.security.web.authentication.rememberme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CookieTheftException
/*    */   extends RememberMeAuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = -7215039140728554850L;
/*    */   
/*    */   public CookieTheftException(String message) {
/* 30 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\CookieTheftException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */