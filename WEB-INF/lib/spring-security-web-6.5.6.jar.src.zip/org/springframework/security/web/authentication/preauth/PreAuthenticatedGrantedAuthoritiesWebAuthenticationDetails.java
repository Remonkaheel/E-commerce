/*    */ package org.springframework.security.web.authentication.preauth;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.GrantedAuthoritiesContainer;
/*    */ import org.springframework.security.web.authentication.WebAuthenticationDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails
/*    */   extends WebAuthenticationDetails
/*    */   implements GrantedAuthoritiesContainer
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final List<GrantedAuthority> authorities;
/*    */   
/*    */   public PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails(HttpServletRequest request, Collection<? extends GrantedAuthority> authorities) {
/* 48 */     super(request);
/* 49 */     List<GrantedAuthority> temp = new ArrayList<>(authorities.size());
/* 50 */     temp.addAll(authorities);
/* 51 */     this.authorities = Collections.unmodifiableList(temp);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<GrantedAuthority> getGrantedAuthorities() {
/* 56 */     return this.authorities;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     StringBuilder sb = new StringBuilder();
/* 62 */     sb.append(super.toString()).append("; ");
/* 63 */     sb.append(this.authorities);
/* 64 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */