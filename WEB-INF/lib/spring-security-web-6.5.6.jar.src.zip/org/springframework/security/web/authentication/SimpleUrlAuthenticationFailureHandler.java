/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleUrlAuthenticationFailureHandler
/*     */   implements AuthenticationFailureHandler
/*     */ {
/*  51 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private String defaultFailureUrl;
/*     */   
/*     */   private boolean forwardToDestination = false;
/*     */   
/*     */   private boolean allowSessionCreation = true;
/*     */   
/*  59 */   private RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleUrlAuthenticationFailureHandler(String defaultFailureUrl) {
/*  65 */     setDefaultFailureUrl(defaultFailureUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
/*  78 */     if (this.defaultFailureUrl == null) {
/*  79 */       if (this.logger.isTraceEnabled()) {
/*  80 */         this.logger.trace("Sending 401 Unauthorized error since no failure URL is set");
/*     */       } else {
/*     */         
/*  83 */         this.logger.debug("Sending 401 Unauthorized error");
/*     */       } 
/*  85 */       response.sendError(HttpStatus.UNAUTHORIZED.value(), HttpStatus.UNAUTHORIZED.getReasonPhrase());
/*     */       return;
/*     */     } 
/*  88 */     saveException(request, exception);
/*  89 */     if (this.forwardToDestination) {
/*  90 */       this.logger.debug("Forwarding to " + this.defaultFailureUrl);
/*  91 */       request.getRequestDispatcher(this.defaultFailureUrl).forward((ServletRequest)request, (ServletResponse)response);
/*     */     } else {
/*     */       
/*  94 */       this.redirectStrategy.sendRedirect(request, response, this.defaultFailureUrl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void saveException(HttpServletRequest request, AuthenticationException exception) {
/* 107 */     if (this.forwardToDestination) {
/* 108 */       request.setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
/*     */       return;
/*     */     } 
/* 111 */     HttpSession session = request.getSession(false);
/* 112 */     if (session != null || this.allowSessionCreation) {
/* 113 */       request.getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultFailureUrl(String defaultFailureUrl) {
/* 122 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(defaultFailureUrl), () -> "'" + defaultFailureUrl + "' is not a valid redirect URL");
/*     */     
/* 124 */     this.defaultFailureUrl = defaultFailureUrl;
/*     */   }
/*     */   
/*     */   protected boolean isUseForward() {
/* 128 */     return this.forwardToDestination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseForward(boolean forwardToDestination) {
/* 136 */     this.forwardToDestination = forwardToDestination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
/* 143 */     this.redirectStrategy = redirectStrategy;
/*     */   }
/*     */   
/*     */   protected RedirectStrategy getRedirectStrategy() {
/* 147 */     return this.redirectStrategy;
/*     */   }
/*     */   
/*     */   protected boolean isAllowSessionCreation() {
/* 151 */     return this.allowSessionCreation;
/*     */   }
/*     */   
/*     */   public void setAllowSessionCreation(boolean allowSessionCreation) {
/* 155 */     this.allowSessionCreation = allowSessionCreation;
/*     */   }
/*     */   
/*     */   public SimpleUrlAuthenticationFailureHandler() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\SimpleUrlAuthenticationFailureHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */