/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.session.SessionRegistry;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegisterSessionAuthenticationStrategy
/*    */   implements SessionAuthenticationStrategy
/*    */ {
/*    */   private final SessionRegistry sessionRegistry;
/*    */   
/*    */   public RegisterSessionAuthenticationStrategy(SessionRegistry sessionRegistry) {
/* 56 */     Assert.notNull(sessionRegistry, "The sessionRegistry cannot be null");
/* 57 */     this.sessionRegistry = sessionRegistry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) {
/* 67 */     this.sessionRegistry.registerNewSession(request.getSession().getId(), authentication.getPrincipal());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\RegisterSessionAuthenticationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */