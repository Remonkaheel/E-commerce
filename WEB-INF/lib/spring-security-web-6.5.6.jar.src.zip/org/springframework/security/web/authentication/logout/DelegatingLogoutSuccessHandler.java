/*    */ package org.springframework.security.web.authentication.logout;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingLogoutSuccessHandler
/*    */   implements LogoutSuccessHandler
/*    */ {
/*    */   private final LinkedHashMap<RequestMatcher, LogoutSuccessHandler> matcherToHandler;
/*    */   private LogoutSuccessHandler defaultLogoutSuccessHandler;
/*    */   
/*    */   public DelegatingLogoutSuccessHandler(LinkedHashMap<RequestMatcher, LogoutSuccessHandler> matcherToHandler) {
/* 45 */     Assert.notEmpty(matcherToHandler, "matcherToHandler cannot be null");
/* 46 */     this.matcherToHandler = matcherToHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
/* 52 */     for (Map.Entry<RequestMatcher, LogoutSuccessHandler> entry : this.matcherToHandler.entrySet()) {
/* 53 */       RequestMatcher matcher = entry.getKey();
/* 54 */       if (matcher.matches(request)) {
/* 55 */         LogoutSuccessHandler handler = entry.getValue();
/* 56 */         handler.onLogoutSuccess(request, response, authentication);
/*    */         return;
/*    */       } 
/*    */     } 
/* 60 */     if (this.defaultLogoutSuccessHandler != null) {
/* 61 */       this.defaultLogoutSuccessHandler.onLogoutSuccess(request, response, authentication);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultLogoutSuccessHandler(LogoutSuccessHandler defaultLogoutSuccessHandler) {
/* 70 */     this.defaultLogoutSuccessHandler = defaultLogoutSuccessHandler;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\DelegatingLogoutSuccessHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */