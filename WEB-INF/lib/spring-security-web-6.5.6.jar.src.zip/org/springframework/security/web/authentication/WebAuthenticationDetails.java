/*     */ package org.springframework.security.web.authentication;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAuthenticationDetails
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*     */   private final String remoteAddress;
/*     */   private final String sessionId;
/*     */   
/*     */   public WebAuthenticationDetails(HttpServletRequest request) {
/*  47 */     this(request.getRemoteAddr(), extractSessionId(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthenticationDetails(String remoteAddress, String sessionId) {
/*  57 */     this.remoteAddress = remoteAddress;
/*  58 */     this.sessionId = sessionId;
/*     */   }
/*     */   
/*     */   private static String extractSessionId(HttpServletRequest request) {
/*  62 */     HttpSession session = request.getSession(false);
/*  63 */     return (session != null) ? session.getId() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteAddress() {
/*  71 */     return this.remoteAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionId() {
/*  80 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  85 */     if (this == o) {
/*  86 */       return true;
/*     */     }
/*  88 */     if (o == null || getClass() != o.getClass()) {
/*  89 */       return false;
/*     */     }
/*  91 */     WebAuthenticationDetails that = (WebAuthenticationDetails)o;
/*  92 */     return (Objects.equals(this.remoteAddress, that.remoteAddress) && Objects.equals(this.sessionId, that.sessionId));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return Objects.hash(new Object[] { this.remoteAddress, this.sessionId });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     StringBuilder sb = new StringBuilder();
/* 103 */     sb.append(getClass().getSimpleName()).append(" [");
/* 104 */     sb.append("RemoteIpAddress=").append(getRemoteAddress()).append(", ");
/* 105 */     sb.append("SessionId=").append(getSessionId()).append("]");
/* 106 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\WebAuthenticationDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */