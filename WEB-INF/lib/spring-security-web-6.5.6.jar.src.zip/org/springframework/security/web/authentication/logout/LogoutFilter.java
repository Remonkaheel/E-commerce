/*     */ package org.springframework.security.web.authentication.logout;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogoutFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  57 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestMatcher logoutRequestMatcher;
/*     */ 
/*     */   
/*     */   private final LogoutHandler handler;
/*     */ 
/*     */   
/*     */   private final LogoutSuccessHandler logoutSuccessHandler;
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutFilter(LogoutSuccessHandler logoutSuccessHandler, LogoutHandler... handlers) {
/*  72 */     this.handler = new CompositeLogoutHandler(handlers);
/*  73 */     Assert.notNull(logoutSuccessHandler, "logoutSuccessHandler cannot be null");
/*  74 */     this.logoutSuccessHandler = logoutSuccessHandler;
/*  75 */     setFilterProcessesUrl("/logout");
/*     */   }
/*     */   
/*     */   public LogoutFilter(String logoutSuccessUrl, LogoutHandler... handlers) {
/*  79 */     this.handler = new CompositeLogoutHandler(handlers);
/*  80 */     Assert.isTrue((!StringUtils.hasLength(logoutSuccessUrl) || UrlUtils.isValidRedirectUrl(logoutSuccessUrl)), () -> logoutSuccessUrl + " isn't a valid redirect URL");
/*     */     
/*  82 */     SimpleUrlLogoutSuccessHandler urlLogoutSuccessHandler = new SimpleUrlLogoutSuccessHandler();
/*  83 */     if (StringUtils.hasText(logoutSuccessUrl)) {
/*  84 */       urlLogoutSuccessHandler.setDefaultTargetUrl(logoutSuccessUrl);
/*     */     }
/*  86 */     this.logoutSuccessHandler = urlLogoutSuccessHandler;
/*  87 */     setFilterProcessesUrl("/logout");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  93 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  98 */     if (requiresLogout(request, response)) {
/*  99 */       Authentication auth = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 100 */       if (this.logger.isDebugEnabled()) {
/* 101 */         this.logger.debug(LogMessage.format("Logging out [%s]", auth));
/*     */       }
/* 103 */       this.handler.logout(request, response, auth);
/* 104 */       this.logoutSuccessHandler.onLogoutSuccess(request, response, auth);
/*     */       return;
/*     */     } 
/* 107 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean requiresLogout(HttpServletRequest request, HttpServletResponse response) {
/* 117 */     if (this.logoutRequestMatcher.matches(request)) {
/* 118 */       return true;
/*     */     }
/* 120 */     if (this.logger.isTraceEnabled()) {
/* 121 */       this.logger.trace(LogMessage.format("Did not match request to %s", this.logoutRequestMatcher));
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 133 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 134 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setLogoutRequestMatcher(RequestMatcher logoutRequestMatcher) {
/* 138 */     Assert.notNull(logoutRequestMatcher, "logoutRequestMatcher cannot be null");
/* 139 */     this.logoutRequestMatcher = logoutRequestMatcher;
/*     */   }
/*     */   
/*     */   public void setFilterProcessesUrl(String filterProcessesUrl) {
/* 143 */     this.logoutRequestMatcher = (RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(filterProcessesUrl);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\LogoutFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */