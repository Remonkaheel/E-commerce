/*    */ package org.springframework.security.web.authentication.ott;
/*    */ 
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
/*    */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OneTimeTokenAuthenticationFilter
/*    */   extends AbstractAuthenticationProcessingFilter
/*    */ {
/*    */   public static final String DEFAULT_LOGIN_PROCESSING_URL = "/login/ott";
/*    */   
/*    */   public OneTimeTokenAuthenticationFilter() {
/* 37 */     super((RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(HttpMethod.POST, "/login/ott"));
/* 38 */     setAuthenticationConverter(new OneTimeTokenAuthenticationConverter());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\OneTimeTokenAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */