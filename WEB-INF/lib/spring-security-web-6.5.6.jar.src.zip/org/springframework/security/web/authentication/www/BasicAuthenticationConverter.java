/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Base64;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAuthenticationConverter
/*     */   implements AuthenticationConverter
/*     */ {
/*     */   public static final String AUTHENTICATION_SCHEME_BASIC = "Basic";
/*     */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*  48 */   private Charset credentialsCharset = StandardCharsets.UTF_8;
/*     */   
/*     */   public BasicAuthenticationConverter() {
/*  51 */     this((AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource());
/*     */   }
/*     */ 
/*     */   
/*     */   public BasicAuthenticationConverter(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/*  56 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */   
/*     */   public Charset getCredentialsCharset() {
/*  60 */     return this.credentialsCharset;
/*     */   }
/*     */   
/*     */   public void setCredentialsCharset(Charset credentialsCharset) {
/*  64 */     this.credentialsCharset = credentialsCharset;
/*     */   }
/*     */   
/*     */   public AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() {
/*  68 */     return this.authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/*  73 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/*  74 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public UsernamePasswordAuthenticationToken convert(HttpServletRequest request) {
/*  79 */     String header = request.getHeader("Authorization");
/*  80 */     if (header == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     header = header.trim();
/*  84 */     if (!StringUtils.startsWithIgnoreCase(header, "Basic")) {
/*  85 */       return null;
/*     */     }
/*  87 */     if (header.equalsIgnoreCase("Basic")) {
/*  88 */       throw new BadCredentialsException("Empty basic authentication token");
/*     */     }
/*  90 */     byte[] base64Token = header.substring(6).getBytes(StandardCharsets.UTF_8);
/*  91 */     byte[] decoded = decode(base64Token);
/*  92 */     String token = new String(decoded, getCredentialsCharset(request));
/*  93 */     int delim = token.indexOf(":");
/*  94 */     if (delim == -1) {
/*  95 */       throw new BadCredentialsException("Invalid basic authentication token");
/*     */     }
/*     */     
/*  98 */     UsernamePasswordAuthenticationToken result = UsernamePasswordAuthenticationToken.unauthenticated(token.substring(0, delim), token.substring(delim + 1));
/*  99 */     result.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 100 */     return result;
/*     */   }
/*     */   
/*     */   private byte[] decode(byte[] base64Token) {
/*     */     try {
/* 105 */       return Base64.getDecoder().decode(base64Token);
/*     */     }
/* 107 */     catch (IllegalArgumentException ex) {
/* 108 */       throw new BadCredentialsException("Failed to decode basic authentication token");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Charset getCredentialsCharset(HttpServletRequest request) {
/* 113 */     return getCredentialsCharset();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\BasicAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */