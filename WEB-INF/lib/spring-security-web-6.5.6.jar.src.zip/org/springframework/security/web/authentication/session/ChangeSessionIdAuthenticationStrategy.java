/*    */ package org.springframework.security.web.authentication.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChangeSessionIdAuthenticationStrategy
/*    */   extends AbstractSessionFixationProtectionStrategy
/*    */ {
/*    */   HttpSession applySessionFixation(HttpServletRequest request) {
/* 33 */     request.changeSessionId();
/* 34 */     return request.getSession();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\ChangeSessionIdAuthenticationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */