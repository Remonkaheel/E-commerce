/*     */ package org.springframework.security.web.authentication.logout;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextLogoutHandler
/*     */   implements LogoutHandler
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*  52 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private boolean invalidateHttpSession = true;
/*     */   
/*     */   private boolean clearAuthentication = true;
/*     */   
/*  58 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/*  68 */     Assert.notNull(request, "HttpServletRequest required");
/*  69 */     if (this.invalidateHttpSession) {
/*  70 */       HttpSession session = request.getSession(false);
/*  71 */       if (session != null) {
/*  72 */         session.invalidate();
/*  73 */         if (this.logger.isDebugEnabled()) {
/*  74 */           this.logger.debug(LogMessage.format("Invalidated session %s", session.getId()));
/*     */         }
/*     */       } 
/*     */     } 
/*  78 */     SecurityContext context = this.securityContextHolderStrategy.getContext();
/*  79 */     this.securityContextHolderStrategy.clearContext();
/*  80 */     if (this.clearAuthentication) {
/*  81 */       context.setAuthentication(null);
/*     */     }
/*  83 */     SecurityContext emptyContext = this.securityContextHolderStrategy.createEmptyContext();
/*  84 */     this.securityContextRepository.saveContext(emptyContext, request, response);
/*     */   }
/*     */   
/*     */   public boolean isInvalidateHttpSession() {
/*  88 */     return this.invalidateHttpSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  98 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*  99 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvalidateHttpSession(boolean invalidateHttpSession) {
/* 109 */     this.invalidateHttpSession = invalidateHttpSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClearAuthentication(boolean clearAuthentication) {
/* 120 */     this.clearAuthentication = clearAuthentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 129 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 130 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\logout\SecurityContextLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */