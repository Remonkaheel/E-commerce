/*     */ package org.springframework.security.web.authentication.preauth;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.event.InteractiveAuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPreAuthenticatedProcessingFilter
/*     */   extends GenericFilterBean
/*     */   implements ApplicationEventPublisherAware
/*     */ {
/*  97 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  99 */   private ApplicationEventPublisher eventPublisher = null;
/*     */   
/* 101 */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = (AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource();
/*     */   
/* 103 */   private AuthenticationManager authenticationManager = null;
/*     */   
/*     */   private boolean continueFilterChainOnUnsuccessfulAuthentication = true;
/*     */   
/*     */   private boolean checkForPrincipalChanges;
/*     */   
/*     */   private boolean invalidateSessionOnPrincipalChange = true;
/*     */   
/* 111 */   private AuthenticationSuccessHandler authenticationSuccessHandler = null;
/*     */   
/* 113 */   private AuthenticationFailureHandler authenticationFailureHandler = null;
/*     */   
/* 115 */   private RequestMatcher requiresAuthenticationRequestMatcher = new PreAuthenticatedProcessingRequestMatcher();
/*     */   
/* 117 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*     */     try {
/* 125 */       super.afterPropertiesSet();
/*     */     }
/* 127 */     catch (ServletException ex) {
/*     */       
/* 129 */       throw new RuntimeException(ex);
/*     */     } 
/* 131 */     Assert.notNull(this.authenticationManager, "An AuthenticationManager must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 141 */     if (this.requiresAuthenticationRequestMatcher.matches((HttpServletRequest)request)) {
/* 142 */       if (this.logger.isDebugEnabled()) {
/* 143 */         this.logger.debug(
/* 144 */             LogMessage.of(() -> "Authenticating " + String.valueOf(this.securityContextHolderStrategy.getContext().getAuthentication())));
/*     */       }
/* 146 */       doAuthenticate((HttpServletRequest)request, (HttpServletResponse)response);
/*     */     
/*     */     }
/* 149 */     else if (this.logger.isTraceEnabled()) {
/* 150 */       this.logger.trace(LogMessage.format("Did not authenticate since request did not match [%s]", this.requiresAuthenticationRequestMatcher));
/*     */     } 
/*     */ 
/*     */     
/* 154 */     chain.doFilter(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean principalChanged(HttpServletRequest request, Authentication currentAuthentication) {
/* 176 */     Object principal = getPreAuthenticatedPrincipal(request);
/* 177 */     if (principal instanceof String && currentAuthentication.getName().equals(principal)) {
/* 178 */       return false;
/*     */     }
/* 180 */     if (principal != null && principal.equals(currentAuthentication.getPrincipal())) {
/* 181 */       return false;
/*     */     }
/* 183 */     this.logger.debug(LogMessage.format("Pre-authenticated principal has changed to %s and will be reauthenticated", principal));
/*     */     
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doAuthenticate(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/* 193 */     Object principal = getPreAuthenticatedPrincipal(request);
/* 194 */     if (principal == null) {
/* 195 */       this.logger.debug("No pre-authenticated principal found in request");
/*     */       return;
/*     */     } 
/* 198 */     this.logger.debug(LogMessage.format("preAuthenticatedPrincipal = %s, trying to authenticate", principal));
/* 199 */     Object credentials = getPreAuthenticatedCredentials(request);
/*     */     try {
/* 201 */       PreAuthenticatedAuthenticationToken authenticationRequest = new PreAuthenticatedAuthenticationToken(principal, credentials);
/*     */       
/* 203 */       authenticationRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 204 */       Authentication authenticationResult = this.authenticationManager.authenticate((Authentication)authenticationRequest);
/* 205 */       successfulAuthentication(request, response, authenticationResult);
/*     */     }
/* 207 */     catch (AuthenticationException ex) {
/* 208 */       unsuccessfulAuthentication(request, response, ex);
/* 209 */       if (!this.continueFilterChainOnUnsuccessfulAuthentication) {
/* 210 */         throw ex;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, Authentication authResult) throws IOException, ServletException {
/* 221 */     this.logger.debug(LogMessage.format("Authentication success: %s", authResult));
/* 222 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 223 */     context.setAuthentication(authResult);
/* 224 */     this.securityContextHolderStrategy.setContext(context);
/* 225 */     this.securityContextRepository.saveContext(context, request, response);
/* 226 */     if (this.eventPublisher != null) {
/* 227 */       this.eventPublisher.publishEvent((ApplicationEvent)new InteractiveAuthenticationSuccessEvent(authResult, getClass()));
/*     */     }
/* 229 */     if (this.authenticationSuccessHandler != null) {
/* 230 */       this.authenticationSuccessHandler.onAuthenticationSuccess(request, response, authResult);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
/* 242 */     this.securityContextHolderStrategy.clearContext();
/* 243 */     this.logger.debug("Cleared security context due to exception", (Throwable)failed);
/* 244 */     request.setAttribute("SPRING_SECURITY_LAST_EXCEPTION", failed);
/* 245 */     if (this.authenticationFailureHandler != null) {
/* 246 */       this.authenticationFailureHandler.onAuthenticationFailure(request, response, failed);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher anApplicationEventPublisher) {
/* 255 */     this.eventPublisher = anApplicationEventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 266 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 267 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 275 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource required");
/* 276 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */   
/*     */   protected AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() {
/* 280 */     return this.authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 287 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContinueFilterChainOnUnsuccessfulAuthentication(boolean shouldContinue) {
/* 299 */     this.continueFilterChainOnUnsuccessfulAuthentication = shouldContinue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckForPrincipalChanges(boolean checkForPrincipalChanges) {
/* 310 */     this.checkForPrincipalChanges = checkForPrincipalChanges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvalidateSessionOnPrincipalChange(boolean invalidateSessionOnPrincipalChange) {
/* 321 */     this.invalidateSessionOnPrincipalChange = invalidateSessionOnPrincipalChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationSuccessHandler(AuthenticationSuccessHandler authenticationSuccessHandler) {
/* 328 */     this.authenticationSuccessHandler = authenticationSuccessHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationFailureHandler(AuthenticationFailureHandler authenticationFailureHandler) {
/* 335 */     this.authenticationFailureHandler = authenticationFailureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequiresAuthenticationRequestMatcher(RequestMatcher requiresAuthenticationRequestMatcher) {
/* 342 */     Assert.notNull(requiresAuthenticationRequestMatcher, "requestMatcher cannot be null");
/* 343 */     this.requiresAuthenticationRequestMatcher = requiresAuthenticationRequestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 353 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 354 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object getPreAuthenticatedPrincipal(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object getPreAuthenticatedCredentials(HttpServletRequest paramHttpServletRequest);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class PreAuthenticatedProcessingRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 378 */       Authentication currentUser = AbstractPreAuthenticatedProcessingFilter.this.securityContextHolderStrategy.getContext().getAuthentication();
/* 379 */       if (currentUser == null) {
/* 380 */         return true;
/*     */       }
/* 382 */       if (!AbstractPreAuthenticatedProcessingFilter.this.checkForPrincipalChanges) {
/* 383 */         return false;
/*     */       }
/* 385 */       if (!AbstractPreAuthenticatedProcessingFilter.this.principalChanged(request, currentUser)) {
/* 386 */         return false;
/*     */       }
/* 388 */       AbstractPreAuthenticatedProcessingFilter.this.logger
/* 389 */         .debug("Pre-authenticated principal has changed and will be reauthenticated");
/* 390 */       if (AbstractPreAuthenticatedProcessingFilter.this.invalidateSessionOnPrincipalChange) {
/* 391 */         AbstractPreAuthenticatedProcessingFilter.this.securityContextHolderStrategy.clearContext();
/* 392 */         HttpSession session = request.getSession(false);
/* 393 */         if (session != null) {
/* 394 */           AbstractPreAuthenticatedProcessingFilter.this.logger.debug("Invalidating existing session");
/* 395 */           session.invalidate();
/* 396 */           request.getSession();
/*     */         } 
/*     */       } 
/* 399 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\AbstractPreAuthenticatedProcessingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */