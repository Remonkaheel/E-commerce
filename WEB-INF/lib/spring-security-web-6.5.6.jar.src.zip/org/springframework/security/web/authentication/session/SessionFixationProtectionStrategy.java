/*     */ package org.springframework.security.web.authentication.session;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionFixationProtectionStrategy
/*     */   extends AbstractSessionFixationProtectionStrategy
/*     */ {
/*     */   boolean migrateSessionAttributes = true;
/*     */   
/*     */   protected Map<String, Object> extractAttributes(HttpSession session) {
/*  80 */     return createMigratedAttributeMap(session);
/*     */   }
/*     */ 
/*     */   
/*     */   final HttpSession applySessionFixation(HttpServletRequest request) {
/*  85 */     HttpSession session = request.getSession();
/*  86 */     String originalSessionId = session.getId();
/*  87 */     this.logger.debug(LogMessage.of(() -> "Invalidating session with Id '" + originalSessionId + "' " + (this.migrateSessionAttributes ? "and" : "without") + " migrating attributes."));
/*     */     
/*  89 */     Map<String, Object> attributesToMigrate = extractAttributes(session);
/*  90 */     int maxInactiveIntervalToMigrate = session.getMaxInactiveInterval();
/*  91 */     session.invalidate();
/*  92 */     session = request.getSession(true);
/*  93 */     this.logger.debug(LogMessage.format("Started new session: %s", session.getId()));
/*  94 */     transferAttributes(attributesToMigrate, session);
/*  95 */     if (this.migrateSessionAttributes) {
/*  96 */       session.setMaxInactiveInterval(maxInactiveIntervalToMigrate);
/*     */     }
/*  98 */     return session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void transferAttributes(Map<String, Object> attributes, HttpSession newSession) {
/* 107 */     if (attributes != null) {
/* 108 */       Objects.requireNonNull(newSession); attributes.forEach(newSession::setAttribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> createMigratedAttributeMap(HttpSession session) {
/* 114 */     HashMap<String, Object> attributesToMigrate = new HashMap<>();
/* 115 */     Enumeration<String> enumeration = session.getAttributeNames();
/* 116 */     while (enumeration.hasMoreElements()) {
/* 117 */       String key = enumeration.nextElement();
/* 118 */       if (!this.migrateSessionAttributes && !key.startsWith("SPRING_SECURITY_")) {
/*     */         continue;
/*     */       }
/*     */       
/* 122 */       attributesToMigrate.put(key, session.getAttribute(key));
/*     */     } 
/* 124 */     return attributesToMigrate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMigrateSessionAttributes(boolean migrateSessionAttributes) {
/* 137 */     this.migrateSessionAttributes = migrateSessionAttributes;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\session\SessionFixationProtectionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */