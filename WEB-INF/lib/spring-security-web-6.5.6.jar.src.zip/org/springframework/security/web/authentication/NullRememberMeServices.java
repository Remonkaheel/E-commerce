/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullRememberMeServices
/*    */   implements RememberMeServices
/*    */ {
/*    */   public Authentication autoLogin(HttpServletRequest request, HttpServletResponse response) {
/* 36 */     return null;
/*    */   }
/*    */   
/*    */   public void loginFail(HttpServletRequest request, HttpServletResponse response) {}
/*    */   
/*    */   public void loginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\NullRememberMeServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */