/*     */ package org.springframework.security.web.authentication.rememberme;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.Date;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentTokenBasedRememberMeServices
/*     */   extends AbstractRememberMeServices
/*     */ {
/*  63 */   private PersistentTokenRepository tokenRepository = new InMemoryTokenRepositoryImpl();
/*     */   
/*     */   private SecureRandom random;
/*     */   
/*     */   public static final int DEFAULT_SERIES_LENGTH = 16;
/*     */   
/*     */   public static final int DEFAULT_TOKEN_LENGTH = 16;
/*     */   
/*  71 */   private int seriesLength = 16;
/*     */   
/*  73 */   private int tokenLength = 16;
/*     */ 
/*     */   
/*     */   public PersistentTokenBasedRememberMeServices(String key, UserDetailsService userDetailsService, PersistentTokenRepository tokenRepository) {
/*  77 */     super(key, userDetailsService);
/*  78 */     this.random = new SecureRandom();
/*  79 */     this.tokenRepository = tokenRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request, HttpServletResponse response) {
/*  97 */     if (cookieTokens.length != 2) {
/*  98 */       throw new InvalidCookieException("Cookie token did not contain 2 tokens, but contained '" + 
/*  99 */           String.valueOf(Arrays.asList(cookieTokens)) + "'");
/*     */     }
/* 101 */     String presentedSeries = cookieTokens[0];
/* 102 */     String presentedToken = cookieTokens[1];
/* 103 */     PersistentRememberMeToken token = this.tokenRepository.getTokenForSeries(presentedSeries);
/* 104 */     if (token == null)
/*     */     {
/* 106 */       throw new RememberMeAuthenticationException("No persistent token found for series id: " + presentedSeries);
/*     */     }
/*     */     
/* 109 */     if (!presentedToken.equals(token.getTokenValue())) {
/*     */ 
/*     */       
/* 112 */       this.tokenRepository.removeUserTokens(token.getUsername());
/* 113 */       throw new CookieTheftException(this.messages.getMessage("PersistentTokenBasedRememberMeServices.cookieStolen", "Invalid remember-me token (Series/token) mismatch. Implies previous cookie theft attack."));
/*     */     } 
/*     */ 
/*     */     
/* 117 */     if (token.getDate().getTime() + getTokenValiditySeconds() * 1000L < System.currentTimeMillis()) {
/* 118 */       throw new RememberMeAuthenticationException("Remember-me login has expired");
/*     */     }
/*     */ 
/*     */     
/* 122 */     this.logger.debug(LogMessage.format("Refreshing persistent login token for user '%s', series '%s'", token
/* 123 */           .getUsername(), token.getSeries()));
/*     */     
/* 125 */     PersistentRememberMeToken newToken = new PersistentRememberMeToken(token.getUsername(), token.getSeries(), generateTokenData(), new Date());
/*     */     try {
/* 127 */       this.tokenRepository.updateToken(newToken.getSeries(), newToken.getTokenValue(), newToken.getDate());
/* 128 */       addCookie(newToken, request, response);
/*     */     }
/* 130 */     catch (Exception ex) {
/* 131 */       this.logger.error("Failed to update token: ", ex);
/* 132 */       throw new RememberMeAuthenticationException("Autologin failed due to data access problem");
/*     */     } 
/* 134 */     return getUserDetailsService().loadUserByUsername(token.getUsername());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onLoginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {
/* 145 */     String username = successfulAuthentication.getName();
/* 146 */     this.logger.debug(LogMessage.format("Creating new persistent login for user %s", username));
/*     */     
/* 148 */     PersistentRememberMeToken persistentToken = new PersistentRememberMeToken(username, generateSeriesData(), generateTokenData(), new Date());
/*     */     try {
/* 150 */       this.tokenRepository.createNewToken(persistentToken);
/* 151 */       addCookie(persistentToken, request, response);
/*     */     }
/* 153 */     catch (Exception ex) {
/* 154 */       this.logger.error("Failed to save persistent token ", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 160 */     super.logout(request, response, authentication);
/* 161 */     if (authentication != null) {
/* 162 */       this.tokenRepository.removeUserTokens(authentication.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   protected String generateSeriesData() {
/* 167 */     byte[] newSeries = new byte[this.seriesLength];
/* 168 */     this.random.nextBytes(newSeries);
/* 169 */     return new String(Base64.getEncoder().encode(newSeries));
/*     */   }
/*     */   
/*     */   protected String generateTokenData() {
/* 173 */     byte[] newToken = new byte[this.tokenLength];
/* 174 */     this.random.nextBytes(newToken);
/* 175 */     return new String(Base64.getEncoder().encode(newToken));
/*     */   }
/*     */   
/*     */   private void addCookie(PersistentRememberMeToken token, HttpServletRequest request, HttpServletResponse response) {
/* 179 */     setCookie(new String[] { token.getSeries(), token.getTokenValue() }, getTokenValiditySeconds(), request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSeriesLength(int seriesLength) {
/* 184 */     this.seriesLength = seriesLength;
/*     */   }
/*     */   
/*     */   public void setTokenLength(int tokenLength) {
/* 188 */     this.tokenLength = tokenLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenValiditySeconds(int tokenValiditySeconds) {
/* 193 */     Assert.isTrue((tokenValiditySeconds > 0), "tokenValiditySeconds must be positive for this implementation");
/* 194 */     super.setTokenValiditySeconds(tokenValiditySeconds);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\PersistentTokenBasedRememberMeServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */