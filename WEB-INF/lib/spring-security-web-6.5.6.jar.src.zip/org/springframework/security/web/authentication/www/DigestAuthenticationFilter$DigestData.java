/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import java.util.Base64;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DigestData
/*     */ {
/*     */   private final String username;
/*     */   private final String realm;
/*     */   private final String nonce;
/*     */   private final String uri;
/*     */   private final String response;
/*     */   private final String qop;
/*     */   private final String nc;
/*     */   private final String cnonce;
/*     */   private final String section212response;
/*     */   private long nonceExpiryTime;
/*     */   
/*     */   DigestData(String header) {
/* 328 */     this.section212response = header.substring(7);
/* 329 */     String[] headerEntries = DigestAuthUtils.splitIgnoringQuotes(this.section212response, ',');
/* 330 */     Map<String, String> headerMap = DigestAuthUtils.splitEachArrayElementAndCreateMap(headerEntries, "=", "\"");
/* 331 */     this.username = headerMap.get("username");
/* 332 */     this.realm = headerMap.get("realm");
/* 333 */     this.nonce = headerMap.get("nonce");
/* 334 */     this.uri = headerMap.get("uri");
/* 335 */     this.response = headerMap.get("response");
/* 336 */     this.qop = headerMap.get("qop");
/* 337 */     this.nc = headerMap.get("nc");
/* 338 */     this.cnonce = headerMap.get("cnonce");
/* 339 */     DigestAuthenticationFilter.logger.debug(
/* 340 */         LogMessage.format("Extracted username: '%s'; realm: '%s'; nonce: '%s'; uri: '%s'; response: '%s'", new Object[] { this.username, this.realm, this.nonce, this.uri, this.response }));
/*     */   }
/*     */ 
/*     */   
/*     */   void validateAndDecode(String entryPointKey, String expectedRealm) throws BadCredentialsException {
/*     */     byte[] nonceBytes;
/* 346 */     if (this.username == null || this.realm == null || this.nonce == null || this.uri == null || this.response == null)
/*     */     {
/* 348 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.missingMandatory", new Object[] { this.section212response }, "Missing mandatory digest value; received header {0}"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 353 */     if ("auth".equals(this.qop) && (
/* 354 */       this.nc == null || this.cnonce == null)) {
/* 355 */       DigestAuthenticationFilter.logger.debug(LogMessage.format("extracted nc: '%s'; cnonce: '%s'", this.nc, this.cnonce));
/* 356 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.missingAuth", new Object[] { this.section212response }, "Missing mandatory digest value; received header {0}"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     if (!expectedRealm.equals(this.realm)) {
/* 363 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.incorrectRealm", new Object[] { this.realm, expectedRealm }, "Response realm name '{0}' does not match system realm name of '{1}'"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 370 */       nonceBytes = Base64.getDecoder().decode(this.nonce.getBytes());
/*     */     }
/* 372 */     catch (IllegalArgumentException ex) {
/* 373 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages
/* 374 */           .getMessage("DigestAuthenticationFilter.nonceEncoding", new Object[] { this.nonce }, "Nonce is not encoded in Base64; received nonce {0}"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 379 */     String nonceAsPlainText = new String(nonceBytes);
/* 380 */     String[] nonceTokens = StringUtils.delimitedListToStringArray(nonceAsPlainText, ":");
/* 381 */     if (nonceTokens.length != 2) {
/* 382 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceNotTwoTokens", new Object[] { nonceAsPlainText }, "Nonce should have yielded two tokens but was {0}"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 388 */       this.nonceExpiryTime = Long.valueOf(nonceTokens[0]).longValue();
/*     */     }
/* 390 */     catch (NumberFormatException nfe) {
/* 391 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceNotNumeric", new Object[] { nonceAsPlainText }, "Nonce token should have yielded a numeric first token, but was {0}"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 396 */     String expectedNonceSignature = DigestAuthUtils.md5Hex("" + this.nonceExpiryTime + ":" + this.nonceExpiryTime);
/* 397 */     if (!expectedNonceSignature.equals(nonceTokens[1])) {
/* 398 */       throw new BadCredentialsException(DigestAuthenticationFilter.this.messages.getMessage("DigestAuthenticationFilter.nonceCompromised", new Object[] { nonceAsPlainText }, "Nonce token compromised {0}"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String calculateServerDigest(String password, String httpMethod) {
/* 407 */     return DigestAuthUtils.generateDigest(DigestAuthenticationFilter.this.passwordAlreadyEncoded, this.username, this.realm, password, httpMethod, this.uri, this.qop, this.nonce, this.nc, this.cnonce);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isNonceExpired() {
/* 412 */     long now = System.currentTimeMillis();
/* 413 */     return (this.nonceExpiryTime < now);
/*     */   }
/*     */   
/*     */   String getUsername() {
/* 417 */     return this.username;
/*     */   }
/*     */   
/*     */   String getResponse() {
/* 421 */     return this.response;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\DigestAuthenticationFilter$DigestData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */