/*    */ package org.springframework.security.web.authentication.ui;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.filter.OncePerRequestFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLogoutPageGeneratingFilter
/*    */   extends OncePerRequestFilter
/*    */ {
/* 44 */   private RequestMatcher matcher = (RequestMatcher)PathPatternRequestMatcher.withDefaults().matcher(HttpMethod.GET, "/logout");
/*    */   
/*    */   private Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs = request -> Collections.emptyMap();
/*    */   private static final String LOGOUT_PAGE_TEMPLATE = "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Confirm Log Out?</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n      <form class=\"logout-form\" method=\"post\" action=\"{{contextPath}}/logout\">\n        <h2>Are you sure you want to log out?</h2>\n{{hiddenInputs}}\n        <button class=\"primary\" type=\"submit\">Log Out</button>\n      </form>\n    </div>\n  </body>\n</html>";
/*    */   private static final String HIDDEN_HTML_INPUT_TEMPLATE = "<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n";
/*    */   
/*    */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 51 */     if (this.matcher.matches(request)) {
/* 52 */       renderLogout(request, response);
/*    */     } else {
/*    */       
/* 55 */       if (this.logger.isTraceEnabled()) {
/* 56 */         this.logger.trace(LogMessage.format("Did not render default logout page since request did not match [%s]", this.matcher));
/*    */       }
/*    */       
/* 59 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void renderLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 67 */     String renderedPage = HtmlTemplates.fromTemplate("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title>Confirm Log Out?</title>\n    <link href=\"{{contextPath}}/default-ui.css\" rel=\"stylesheet\" />\n  </head>\n  <body>\n    <div class=\"content\">\n      <form class=\"logout-form\" method=\"post\" action=\"{{contextPath}}/logout\">\n        <h2>Are you sure you want to log out?</h2>\n{{hiddenInputs}}\n        <button class=\"primary\" type=\"submit\">Log Out</button>\n      </form>\n    </div>\n  </body>\n</html>").withValue("contextPath", request.getContextPath()).withRawHtml("hiddenInputs", renderHiddenInputs(request).indent(8)).render();
/* 68 */     response.setContentType("text/html;charset=UTF-8");
/* 69 */     response.getWriter().write(renderedPage);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResolveHiddenInputs(Function<HttpServletRequest, Map<String, String>> resolveHiddenInputs) {
/* 79 */     Assert.notNull(resolveHiddenInputs, "resolveHiddenInputs cannot be null");
/* 80 */     this.resolveHiddenInputs = resolveHiddenInputs;
/*    */   }
/*    */   
/*    */   private String renderHiddenInputs(HttpServletRequest request) {
/* 84 */     StringBuilder sb = new StringBuilder();
/* 85 */     for (Map.Entry<String, String> input : (Iterable<Map.Entry<String, String>>)((Map)this.resolveHiddenInputs.apply(request)).entrySet()) {
/*    */ 
/*    */ 
/*    */       
/* 89 */       String inputElement = HtmlTemplates.fromTemplate("<input name=\"{{name}}\" type=\"hidden\" value=\"{{value}}\" />\n").withValue("name", input.getKey()).withValue("value", input.getValue()).render();
/* 90 */       sb.append(inputElement);
/*    */     } 
/* 92 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authenticatio\\ui\DefaultLogoutPageGeneratingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */