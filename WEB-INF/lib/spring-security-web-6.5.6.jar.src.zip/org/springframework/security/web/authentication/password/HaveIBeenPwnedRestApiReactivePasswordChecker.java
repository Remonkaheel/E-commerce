/*     */ package org.springframework.security.web.authentication.password;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Locale;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordDecision;
/*     */ import org.springframework.security.authentication.password.ReactiveCompromisedPasswordChecker;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.reactive.function.client.WebClient;
/*     */ import org.springframework.web.reactive.function.client.WebClientResponseException;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HaveIBeenPwnedRestApiReactivePasswordChecker
/*     */   implements ReactiveCompromisedPasswordChecker
/*     */ {
/*     */   private static final String API_URL = "https://api.pwnedpasswords.com/range/";
/*     */   private static final int PREFIX_LENGTH = 5;
/*  53 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  55 */   private WebClient webClient = WebClient.builder().baseUrl("https://api.pwnedpasswords.com/range/").build();
/*     */   
/*     */   private final MessageDigest sha1Digest;
/*     */   
/*     */   public HaveIBeenPwnedRestApiReactivePasswordChecker() {
/*  60 */     this.sha1Digest = getSha1Digest();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<CompromisedPasswordDecision> check(String password) {
/*  65 */     return getHash(password).map(hash -> new String(Hex.encode(hash)))
/*  66 */       .flatMap(this::findLeakedPassword)
/*  67 */       .map(CompromisedPasswordDecision::new);
/*     */   }
/*     */   
/*     */   private Mono<Boolean> findLeakedPassword(String encodedPassword) {
/*  71 */     String prefix = encodedPassword.substring(0, 5).toUpperCase(Locale.ROOT);
/*  72 */     String suffix = encodedPassword.substring(5).toUpperCase(Locale.ROOT);
/*  73 */     return getLeakedPasswordsForPrefix(prefix).any(leakedPw -> leakedPw.startsWith(suffix));
/*     */   }
/*     */   
/*     */   private Flux<String> getLeakedPasswordsForPrefix(String prefix) {
/*  77 */     return this.webClient.get().uri(prefix, new Object[0]).retrieve().bodyToMono(String.class).flatMapMany(body -> StringUtils.hasText(body) ? Flux.fromStream(body.lines()) : Flux.empty())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       .doOnError(ex -> this.logger.error("Request for leaked passwords failed", ex))
/*  84 */       .onErrorResume(WebClientResponseException.class, ex -> Flux.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWebClient(WebClient webClient) {
/*  93 */     Assert.notNull(webClient, "webClient cannot be null");
/*  94 */     this.webClient = webClient;
/*     */   }
/*     */   
/*     */   private Mono<byte[]> getHash(String password) {
/*  98 */     return Mono.fromSupplier(() -> this.sha1Digest.digest(password.getBytes(StandardCharsets.UTF_8)))
/*  99 */       .subscribeOn(Schedulers.boundedElastic())
/* 100 */       .publishOn(Schedulers.parallel());
/*     */   }
/*     */   
/*     */   private static MessageDigest getSha1Digest() {
/*     */     try {
/* 105 */       return MessageDigest.getInstance("SHA-1");
/*     */     }
/* 107 */     catch (NoSuchAlgorithmException ex) {
/* 108 */       throw new RuntimeException(ex.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\password\HaveIBeenPwnedRestApiReactivePasswordChecker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */