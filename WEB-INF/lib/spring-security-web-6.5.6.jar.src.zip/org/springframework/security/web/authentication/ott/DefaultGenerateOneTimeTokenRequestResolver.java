/*    */ package org.springframework.security.web.authentication.ott;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.time.Duration;
/*    */ import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultGenerateOneTimeTokenRequestResolver
/*    */   implements GenerateOneTimeTokenRequestResolver
/*    */ {
/* 36 */   private static final Duration DEFAULT_EXPIRES_IN = Duration.ofMinutes(5L);
/*    */   
/* 38 */   private Duration expiresIn = DEFAULT_EXPIRES_IN;
/*    */ 
/*    */   
/*    */   public GenerateOneTimeTokenRequest resolve(HttpServletRequest request) {
/* 42 */     String username = request.getParameter("username");
/* 43 */     if (!StringUtils.hasText(username)) {
/* 44 */       return null;
/*    */     }
/* 46 */     return new GenerateOneTimeTokenRequest(username, this.expiresIn);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExpiresIn(Duration expiresIn) {
/* 54 */     Assert.notNull(expiresIn, "expiresIn cannot be null");
/* 55 */     this.expiresIn = expiresIn;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\ott\DefaultGenerateOneTimeTokenRequestResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */