/*    */ package org.springframework.security.web.authentication.preauth.websphere;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.mapping.Attributes2GrantedAuthoritiesMapper;
/*    */ import org.springframework.security.core.authority.mapping.SimpleAttributes2GrantedAuthoritiesMapper;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebSpherePreAuthenticatedWebAuthenticationDetailsSource
/*    */   implements AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails>
/*    */ {
/* 43 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 45 */   private Attributes2GrantedAuthoritiesMapper webSphereGroups2GrantedAuthoritiesMapper = (Attributes2GrantedAuthoritiesMapper)new SimpleAttributes2GrantedAuthoritiesMapper();
/*    */   
/*    */   private final WASUsernameAndGroupsExtractor wasHelper;
/*    */   
/*    */   public WebSpherePreAuthenticatedWebAuthenticationDetailsSource() {
/* 50 */     this(new DefaultWASUsernameAndGroupsExtractor());
/*    */   }
/*    */   
/*    */   public WebSpherePreAuthenticatedWebAuthenticationDetailsSource(WASUsernameAndGroupsExtractor wasHelper) {
/* 54 */     this.wasHelper = wasHelper;
/*    */   }
/*    */ 
/*    */   
/*    */   public PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails buildDetails(HttpServletRequest context) {
/* 59 */     return new PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails(context, 
/* 60 */         getWebSphereGroupsBasedGrantedAuthorities());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Collection<? extends GrantedAuthority> getWebSphereGroupsBasedGrantedAuthorities() {
/* 68 */     List<String> webSphereGroups = this.wasHelper.getGroupsForCurrentUser();
/*    */     
/* 70 */     Collection<? extends GrantedAuthority> userGas = this.webSphereGroups2GrantedAuthoritiesMapper.getGrantedAuthorities(webSphereGroups);
/* 71 */     this.logger.debug(
/* 72 */         LogMessage.format("WebSphere groups: %s mapped to Granted Authorities: %s", webSphereGroups, userGas));
/* 73 */     return userGas;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setWebSphereGroups2GrantedAuthoritiesMapper(Attributes2GrantedAuthoritiesMapper mapper) {
/* 81 */     this.webSphereGroups2GrantedAuthoritiesMapper = mapper;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\websphere\WebSpherePreAuthenticatedWebAuthenticationDetailsSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */