/*     */ package org.springframework.security.web.authentication.rememberme;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Base64;
/*     */ import java.util.function.Consumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AccountStatusException;
/*     */ import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.RememberMeAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRememberMeServices
/*     */   implements RememberMeServices, InitializingBean, LogoutHandler, MessageSourceAware
/*     */ {
/*     */   public static final String SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY = "remember-me";
/*     */   public static final String DEFAULT_PARAMETER = "remember-me";
/*     */   public static final int TWO_WEEKS_S = 1209600;
/*     */   private static final String DELIMITER = ":";
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  77 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private UserDetailsService userDetailsService;
/*     */   
/*  81 */   private UserDetailsChecker userDetailsChecker = (UserDetailsChecker)new AccountStatusUserDetailsChecker();
/*     */   
/*  83 */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = (AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource();
/*     */   
/*  85 */   private String cookieName = "remember-me";
/*     */   
/*     */   private String cookieDomain;
/*     */   
/*  89 */   private String parameter = "remember-me";
/*     */   
/*     */   private boolean alwaysRemember;
/*     */   
/*     */   private String key;
/*     */   
/*  95 */   private int tokenValiditySeconds = 1209600;
/*     */   
/*  97 */   private Boolean useSecureCookie = null;
/*     */   
/*  99 */   private GrantedAuthoritiesMapper authoritiesMapper = (GrantedAuthoritiesMapper)new NullAuthoritiesMapper();
/*     */   private Consumer<Cookie> cookieCustomizer = cookie -> {
/*     */     
/*     */     };
/*     */   
/*     */   protected AbstractRememberMeServices(String key, UserDetailsService userDetailsService) {
/* 105 */     Assert.hasLength(key, "key cannot be empty or null");
/* 106 */     Assert.notNull(userDetailsService, "UserDetailsService cannot be null");
/* 107 */     this.key = key;
/* 108 */     this.userDetailsService = userDetailsService;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 113 */     Assert.hasLength(this.key, "key cannot be empty or null");
/* 114 */     Assert.notNull(this.userDetailsService, "A UserDetailsService is required");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication autoLogin(HttpServletRequest request, HttpServletResponse response) {
/* 127 */     String rememberMeCookie = extractRememberMeCookie(request);
/* 128 */     if (rememberMeCookie == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     this.logger.debug("Remember-me cookie detected");
/* 132 */     if (rememberMeCookie.length() == 0) {
/* 133 */       this.logger.debug("Cookie was empty");
/* 134 */       cancelCookie(request, response);
/* 135 */       return null;
/*     */     } 
/*     */     try {
/* 138 */       String[] cookieTokens = decodeCookie(rememberMeCookie);
/* 139 */       UserDetails user = processAutoLoginCookie(cookieTokens, request, response);
/* 140 */       this.userDetailsChecker.check(user);
/* 141 */       this.logger.debug("Remember-me cookie accepted");
/* 142 */       return createSuccessfulAuthentication(request, user);
/*     */     }
/* 144 */     catch (CookieTheftException ex) {
/* 145 */       cancelCookie(request, response);
/* 146 */       throw ex;
/*     */     }
/* 148 */     catch (UsernameNotFoundException ex) {
/* 149 */       this.logger.debug("Remember-me login was valid but corresponding user not found.", (Throwable)ex);
/*     */     }
/* 151 */     catch (InvalidCookieException ex) {
/* 152 */       this.logger.debug("Invalid remember-me cookie: " + ex.getMessage());
/*     */     }
/* 154 */     catch (AccountStatusException ex) {
/* 155 */       this.logger.debug("Invalid UserDetails: " + ex.getMessage());
/*     */     }
/* 157 */     catch (RememberMeAuthenticationException ex) {
/* 158 */       this.logger.debug(ex.getMessage());
/*     */     } 
/* 160 */     cancelCookie(request, response);
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String extractRememberMeCookie(HttpServletRequest request) {
/* 172 */     Cookie[] cookies = request.getCookies();
/* 173 */     if (cookies == null || cookies.length == 0) {
/* 174 */       return null;
/*     */     }
/* 176 */     for (Cookie cookie : cookies) {
/* 177 */       if (this.cookieName.equals(cookie.getName())) {
/* 178 */         return cookie.getValue();
/*     */       }
/*     */     } 
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication createSuccessfulAuthentication(HttpServletRequest request, UserDetails user) {
/* 198 */     RememberMeAuthenticationToken auth = new RememberMeAuthenticationToken(this.key, user, this.authoritiesMapper.mapAuthorities(user.getAuthorities()));
/* 199 */     auth.setDetails(this.authenticationDetailsSource.buildDetails(request));
/* 200 */     return (Authentication)auth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] decodeCookie(String cookieValue) throws InvalidCookieException {
/*     */     String cookieAsPlainText;
/* 211 */     for (int j = 0; j < cookieValue.length() % 4; j++) {
/* 212 */       cookieValue = cookieValue + "=";
/*     */     }
/*     */     
/*     */     try {
/* 216 */       cookieAsPlainText = new String(Base64.getDecoder().decode(cookieValue.getBytes()));
/*     */     }
/* 218 */     catch (IllegalArgumentException ex) {
/* 219 */       throw new InvalidCookieException("Cookie token was not Base64 encoded; value was '" + cookieValue + "'");
/*     */     } 
/* 221 */     String[] tokens = StringUtils.delimitedListToStringArray(cookieAsPlainText, ":");
/* 222 */     for (int i = 0; i < tokens.length; i++) {
/*     */       try {
/* 224 */         tokens[i] = URLDecoder.decode(tokens[i], StandardCharsets.UTF_8.toString());
/*     */       }
/* 226 */       catch (UnsupportedEncodingException ex) {
/* 227 */         this.logger.error(ex.getMessage(), ex);
/*     */       } 
/*     */     } 
/* 230 */     return tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String encodeCookie(String[] cookieTokens) {
/* 239 */     StringBuilder sb = new StringBuilder();
/* 240 */     for (int i = 0; i < cookieTokens.length; i++) {
/*     */       try {
/* 242 */         sb.append(URLEncoder.encode(cookieTokens[i], StandardCharsets.UTF_8.toString()));
/*     */       }
/* 244 */       catch (UnsupportedEncodingException ex) {
/* 245 */         this.logger.error(ex.getMessage(), ex);
/*     */       } 
/* 247 */       if (i < cookieTokens.length - 1) {
/* 248 */         sb.append(":");
/*     */       }
/*     */     } 
/* 251 */     String value = sb.toString();
/* 252 */     sb = new StringBuilder(new String(Base64.getEncoder().encode(value.getBytes())));
/* 253 */     while (sb.charAt(sb.length() - 1) == '=') {
/* 254 */       sb.deleteCharAt(sb.length() - 1);
/*     */     }
/* 256 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void loginFail(HttpServletRequest request, HttpServletResponse response) {
/* 261 */     this.logger.debug("Interactive login attempt was unsuccessful.");
/* 262 */     cancelCookie(request, response);
/* 263 */     onLoginFail(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onLoginFail(HttpServletRequest request, HttpServletResponse response) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {
/* 281 */     if (!rememberMeRequested(request, this.parameter)) {
/* 282 */       this.logger.debug("Remember-me login not requested.");
/*     */       return;
/*     */     } 
/* 285 */     onLoginSuccess(request, response, successfulAuthentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean rememberMeRequested(HttpServletRequest request, String parameter) {
/* 307 */     if (this.alwaysRemember) {
/* 308 */       return true;
/*     */     }
/* 310 */     String paramValue = request.getParameter(parameter);
/* 311 */     if (paramValue != null && (
/* 312 */       paramValue.equalsIgnoreCase("true") || paramValue.equalsIgnoreCase("on") || paramValue
/* 313 */       .equalsIgnoreCase("yes") || paramValue.equals("1"))) {
/* 314 */       return true;
/*     */     }
/*     */     
/* 317 */     this.logger.debug(
/* 318 */         LogMessage.format("Did not send remember-me cookie (principal did not set parameter '%s')", parameter));
/* 319 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cancelCookie(HttpServletRequest request, HttpServletResponse response) {
/* 344 */     this.logger.debug("Cancelling cookie");
/* 345 */     Cookie cookie = new Cookie(this.cookieName, null);
/* 346 */     cookie.setMaxAge(0);
/* 347 */     cookie.setPath(getCookiePath(request));
/* 348 */     if (this.cookieDomain != null) {
/* 349 */       cookie.setDomain(this.cookieDomain);
/*     */     }
/* 351 */     cookie.setSecure((this.useSecureCookie != null) ? this.useSecureCookie.booleanValue() : request.isSecure());
/* 352 */     response.addCookie(cookie);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCookie(String[] tokens, int maxAge, HttpServletRequest request, HttpServletResponse response) {
/* 368 */     String cookieValue = encodeCookie(tokens);
/* 369 */     Cookie cookie = new Cookie(this.cookieName, cookieValue);
/* 370 */     cookie.setMaxAge(maxAge);
/* 371 */     cookie.setPath(getCookiePath(request));
/* 372 */     if (this.cookieDomain != null) {
/* 373 */       cookie.setDomain(this.cookieDomain);
/*     */     }
/* 375 */     if (maxAge < 1) {
/* 376 */       cookie.setVersion(1);
/*     */     }
/* 378 */     cookie.setSecure((this.useSecureCookie != null) ? this.useSecureCookie.booleanValue() : request.isSecure());
/* 379 */     cookie.setHttpOnly(true);
/*     */     
/* 381 */     this.cookieCustomizer.accept(cookie);
/*     */     
/* 383 */     response.addCookie(cookie);
/*     */   }
/*     */   
/*     */   private String getCookiePath(HttpServletRequest request) {
/* 387 */     String contextPath = request.getContextPath();
/* 388 */     return (contextPath.length() > 0) ? contextPath : "/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 397 */     this.logger.debug(
/* 398 */         LogMessage.of(() -> "Logout of user " + ((authentication != null) ? authentication.getName() : "Unknown")));
/* 399 */     cancelCookie(request, response);
/*     */   }
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 403 */     Assert.hasLength(cookieName, "Cookie name cannot be empty or null");
/* 404 */     this.cookieName = cookieName;
/*     */   }
/*     */   
/*     */   public void setCookieDomain(String cookieDomain) {
/* 408 */     Assert.hasLength(cookieDomain, "Cookie domain cannot be empty or null");
/* 409 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */   
/*     */   protected String getCookieName() {
/* 413 */     return this.cookieName;
/*     */   }
/*     */   
/*     */   public void setAlwaysRemember(boolean alwaysRemember) {
/* 417 */     this.alwaysRemember = alwaysRemember;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String parameter) {
/* 427 */     Assert.hasText(parameter, "Parameter name cannot be empty or null");
/* 428 */     this.parameter = parameter;
/*     */   }
/*     */   
/*     */   public String getParameter() {
/* 432 */     return this.parameter;
/*     */   }
/*     */   
/*     */   protected UserDetailsService getUserDetailsService() {
/* 436 */     return this.userDetailsService;
/*     */   }
/*     */   
/*     */   public String getKey() {
/* 440 */     return this.key;
/*     */   }
/*     */   
/*     */   public void setTokenValiditySeconds(int tokenValiditySeconds) {
/* 444 */     this.tokenValiditySeconds = tokenValiditySeconds;
/*     */   }
/*     */   
/*     */   protected int getTokenValiditySeconds() {
/* 448 */     return this.tokenValiditySeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseSecureCookie(boolean useSecureCookie) {
/* 463 */     this.useSecureCookie = Boolean.valueOf(useSecureCookie);
/*     */   }
/*     */   
/*     */   protected AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() {
/* 467 */     return this.authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 472 */     Assert.notNull(authenticationDetailsSource, "AuthenticationDetailsSource cannot be null");
/* 473 */     this.authenticationDetailsSource = authenticationDetailsSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsChecker(UserDetailsChecker userDetailsChecker) {
/* 486 */     this.userDetailsChecker = userDetailsChecker;
/*     */   }
/*     */   
/*     */   public void setAuthoritiesMapper(GrantedAuthoritiesMapper authoritiesMapper) {
/* 490 */     this.authoritiesMapper = authoritiesMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 498 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 499 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieCustomizer(Consumer<Cookie> cookieCustomizer) {
/* 508 */     Assert.notNull(cookieCustomizer, "cookieCustomizer cannot be null");
/* 509 */     this.cookieCustomizer = cookieCustomizer;
/*     */   }
/*     */   
/*     */   protected abstract void onLoginSuccess(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Authentication paramAuthentication);
/*     */   
/*     */   protected abstract UserDetails processAutoLoginCookie(String[] paramArrayOfString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws RememberMeAuthenticationException, UsernameNotFoundException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\AbstractRememberMeServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */