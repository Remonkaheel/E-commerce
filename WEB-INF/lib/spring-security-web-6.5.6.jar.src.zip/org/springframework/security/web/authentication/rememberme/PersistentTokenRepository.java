package org.springframework.security.web.authentication.rememberme;

import java.util.Date;

public interface PersistentTokenRepository {
  void createNewToken(PersistentRememberMeToken paramPersistentRememberMeToken);
  
  void updateToken(String paramString1, String paramString2, Date paramDate);
  
  PersistentRememberMeToken getTokenForSeries(String paramString);
  
  void removeUserTokens(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\rememberme\PersistentTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */