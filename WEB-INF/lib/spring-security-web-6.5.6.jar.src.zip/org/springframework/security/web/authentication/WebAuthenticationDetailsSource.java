/*    */ package org.springframework.security.web.authentication;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebAuthenticationDetailsSource
/*    */   implements AuthenticationDetailsSource<HttpServletRequest, WebAuthenticationDetails>
/*    */ {
/*    */   public WebAuthenticationDetails buildDetails(HttpServletRequest context) {
/* 40 */     return new WebAuthenticationDetails(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\WebAuthenticationDetailsSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */