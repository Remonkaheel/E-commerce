/*     */ package org.springframework.security.web.authentication.www;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.NullRememberMeServices;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAuthenticationFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  97 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/* 103 */   private RememberMeServices rememberMeServices = (RememberMeServices)new NullRememberMeServices();
/*     */   
/*     */   private boolean ignoreFailure = false;
/*     */   
/* 107 */   private String credentialsCharset = "UTF-8";
/*     */   
/* 109 */   private AuthenticationConverter authenticationConverter = new BasicAuthenticationConverter();
/*     */   
/* 111 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new RequestAttributeSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicAuthenticationFilter(AuthenticationManager authenticationManager) {
/* 120 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 121 */     this.authenticationManager = authenticationManager;
/* 122 */     this.ignoreFailure = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicAuthenticationFilter(AuthenticationManager authenticationManager, AuthenticationEntryPoint authenticationEntryPoint) {
/* 135 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 136 */     Assert.notNull(authenticationEntryPoint, "authenticationEntryPoint cannot be null");
/* 137 */     this.authenticationManager = authenticationManager;
/* 138 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 149 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 150 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationConverter(AuthenticationConverter authenticationConverter) {
/* 161 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 162 */     this.authenticationConverter = authenticationConverter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 167 */     Assert.notNull(this.authenticationManager, "An AuthenticationManager is required");
/* 168 */     if (!isIgnoreFailure()) {
/* 169 */       Assert.notNull(this.authenticationEntryPoint, "An AuthenticationEntryPoint is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*     */     try {
/* 177 */       Authentication authRequest = this.authenticationConverter.convert(request);
/* 178 */       if (authRequest == null) {
/* 179 */         this.logger.trace("Did not process authentication request since failed to find username and password in Basic Authorization header");
/*     */         
/* 181 */         chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */         return;
/*     */       } 
/* 184 */       String username = authRequest.getName();
/* 185 */       this.logger.trace(LogMessage.format("Found username '%s' in Basic Authorization header", username));
/* 186 */       if (authenticationIsRequired(username)) {
/* 187 */         Authentication authResult = this.authenticationManager.authenticate(authRequest);
/* 188 */         SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 189 */         context.setAuthentication(authResult);
/* 190 */         this.securityContextHolderStrategy.setContext(context);
/* 191 */         if (this.logger.isDebugEnabled()) {
/* 192 */           this.logger.debug(LogMessage.format("Set SecurityContextHolder to %s", authResult));
/*     */         }
/* 194 */         this.rememberMeServices.loginSuccess(request, response, authResult);
/* 195 */         this.securityContextRepository.saveContext(context, request, response);
/* 196 */         onSuccessfulAuthentication(request, response, authResult);
/*     */       }
/*     */     
/* 199 */     } catch (AuthenticationException ex) {
/* 200 */       this.securityContextHolderStrategy.clearContext();
/* 201 */       this.logger.debug("Failed to process authentication request", (Throwable)ex);
/* 202 */       this.rememberMeServices.loginFail(request, response);
/* 203 */       onUnsuccessfulAuthentication(request, response, ex);
/* 204 */       if (this.ignoreFailure) {
/* 205 */         chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       } else {
/*     */         
/* 208 */         this.authenticationEntryPoint.commence(request, response, ex);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 213 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean authenticationIsRequired(String username) {
/* 219 */     Authentication existingAuth = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 220 */     if (existingAuth == null || !existingAuth.getName().equals(username) || !existingAuth.isAuthenticated()) {
/* 221 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     return existingAuth instanceof org.springframework.security.authentication.AnonymousAuthenticationToken;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onSuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, Authentication authResult) throws IOException {}
/*     */ 
/*     */   
/*     */   protected void onUnsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException {}
/*     */ 
/*     */   
/*     */   protected AuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 245 */     return this.authenticationEntryPoint;
/*     */   }
/*     */   
/*     */   protected AuthenticationManager getAuthenticationManager() {
/* 249 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   protected boolean isIgnoreFailure() {
/* 253 */     return this.ignoreFailure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 263 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 264 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 277 */     AuthenticationConverter authenticationConverter = this.authenticationConverter; if (authenticationConverter instanceof BasicAuthenticationConverter) { BasicAuthenticationConverter basicAuthenticationConverter = (BasicAuthenticationConverter)authenticationConverter;
/* 278 */       basicAuthenticationConverter.setAuthenticationDetailsSource(authenticationDetailsSource); }
/*     */   
/*     */   }
/*     */   
/*     */   public void setRememberMeServices(RememberMeServices rememberMeServices) {
/* 283 */     Assert.notNull(rememberMeServices, "rememberMeServices cannot be null");
/* 284 */     this.rememberMeServices = rememberMeServices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCredentialsCharset(String credentialsCharset) {
/* 296 */     Assert.hasText(credentialsCharset, "credentialsCharset cannot be null or empty");
/* 297 */     this.credentialsCharset = credentialsCharset;
/* 298 */     AuthenticationConverter authenticationConverter = this.authenticationConverter; if (authenticationConverter instanceof BasicAuthenticationConverter) { BasicAuthenticationConverter basicAuthenticationConverter = (BasicAuthenticationConverter)authenticationConverter;
/* 299 */       basicAuthenticationConverter.setCredentialsCharset(Charset.forName(credentialsCharset)); }
/*     */   
/*     */   }
/*     */   
/*     */   protected String getCredentialsCharset(HttpServletRequest httpRequest) {
/* 304 */     return this.credentialsCharset;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\www\BasicAuthenticationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */