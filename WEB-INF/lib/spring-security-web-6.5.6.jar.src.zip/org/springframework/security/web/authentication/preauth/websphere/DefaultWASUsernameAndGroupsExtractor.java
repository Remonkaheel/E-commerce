/*     */ package org.springframework.security.web.authentication.preauth.websphere;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.security.auth.Subject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultWASUsernameAndGroupsExtractor
/*     */   implements WASUsernameAndGroupsExtractor
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(DefaultWASUsernameAndGroupsExtractor.class);
/*     */   
/*     */   private static final String PORTABLE_REMOTE_OBJECT_CLASSNAME = "javax.rmi.PortableRemoteObject";
/*     */   
/*     */   private static final String USER_REGISTRY = "UserRegistry";
/*     */   
/*  53 */   private static Method getRunAsSubject = null;
/*     */   
/*  55 */   private static Method getGroupsForUser = null;
/*     */   
/*  57 */   private static Method getSecurityName = null;
/*     */   
/*  59 */   private static Method narrow = null;
/*     */ 
/*     */   
/*  62 */   private static Class<?> wsCredentialClass = null;
/*     */ 
/*     */   
/*     */   public List<String> getGroupsForCurrentUser() {
/*  66 */     return getWebSphereGroups(getRunAsSubject());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCurrentUserName() {
/*  71 */     return getSecurityName(getRunAsSubject());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSecurityName(Subject subject) {
/*  80 */     logger.debug(LogMessage.format("Determining Websphere security name for subject %s", subject));
/*  81 */     String userSecurityName = null;
/*  82 */     if (subject != null) {
/*     */       
/*  84 */       Object credential = subject.getPublicCredentials(getWSCredentialClass()).iterator().next();
/*  85 */       if (credential != null) {
/*  86 */         userSecurityName = (String)invokeMethod(getSecurityNameMethod(), credential, new Object[0]);
/*     */       }
/*     */     } 
/*  89 */     logger.debug(LogMessage.format("Websphere security name is %s for subject %s", subject, userSecurityName));
/*  90 */     return userSecurityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Subject getRunAsSubject() {
/*  98 */     logger.debug("Retrieving WebSphere RunAs subject");
/*     */     
/* 100 */     return (Subject)invokeMethod(getRunAsSubjectMethod(), null, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> getWebSphereGroups(Subject subject) {
/* 109 */     return getWebSphereGroups(getSecurityName(subject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> getWebSphereGroups(String securityName) {
/* 120 */     Context context = null;
/*     */     
/*     */     try {
/* 123 */       context = new InitialContext();
/* 124 */       Object objRef = context.lookup("UserRegistry");
/* 125 */       Object userReg = invokeMethod(getNarrowMethod(), null, new Object[] { objRef, 
/* 126 */             Class.forName("com.ibm.websphere.security.UserRegistry") });
/* 127 */       logger.debug(LogMessage.format("Determining WebSphere groups for user %s using WebSphere UserRegistry %s", securityName, userReg));
/*     */       
/* 129 */       Collection<String> groups = (Collection<String>)invokeMethod(getGroupsForUserMethod(), userReg, new Object[] { securityName });
/*     */       
/* 131 */       logger.debug(LogMessage.format("Groups for user %s: %s", securityName, groups));
/* 132 */       return new ArrayList<>(groups);
/*     */     }
/* 134 */     catch (Exception ex) {
/* 135 */       logger.error("Exception occured while looking up groups for user", ex);
/* 136 */       throw new RuntimeException("Exception occured while looking up groups for user", ex);
/*     */     } finally {
/*     */       
/* 139 */       closeContext(context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void closeContext(Context context) {
/*     */     try {
/* 145 */       if (context != null) {
/* 146 */         context.close();
/*     */       }
/*     */     }
/* 149 */     catch (NamingException ex) {
/* 150 */       logger.debug("Exception occured while closing context", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object invokeMethod(Method method, Object instance, Object... args) {
/*     */     try {
/* 156 */       return method.invoke(instance, args);
/*     */     }
/* 158 */     catch (IllegalArgumentException|IllegalAccessException|java.lang.reflect.InvocationTargetException ex) {
/*     */       
/* 160 */       String message = "Error while invoking method " + method.getClass().getName() + "." + method.getName() + "(" + String.valueOf(Arrays.asList(args)) + ")";
/* 161 */       logger.error(message, ex);
/* 162 */       throw new RuntimeException(message, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method getMethod(String className, String methodName, String[] parameterTypeNames) {
/*     */     try {
/* 168 */       Class<?> c = Class.forName(className);
/* 169 */       int len = parameterTypeNames.length;
/* 170 */       Class<?>[] parameterTypes = new Class[len];
/* 171 */       for (int i = 0; i < len; i++) {
/* 172 */         parameterTypes[i] = Class.forName(parameterTypeNames[i]);
/*     */       }
/* 174 */       return c.getDeclaredMethod(methodName, parameterTypes);
/*     */     }
/* 176 */     catch (ClassNotFoundException ex) {
/* 177 */       logger.error("Required class" + className + " not found");
/* 178 */       throw new RuntimeException("Required class" + className + " not found", ex);
/*     */     }
/* 180 */     catch (NoSuchMethodException ex) {
/* 181 */       logger.error("Required method " + methodName + " with parameter types (" + String.valueOf(Arrays.asList(parameterTypeNames)) + ") not found on class " + className);
/*     */       
/* 183 */       throw new RuntimeException("Required class" + className + " not found", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method getRunAsSubjectMethod() {
/* 188 */     if (getRunAsSubject == null) {
/* 189 */       getRunAsSubject = getMethod("com.ibm.websphere.security.auth.WSSubject", "getRunAsSubject", new String[0]);
/*     */     }
/*     */     
/* 192 */     return getRunAsSubject;
/*     */   }
/*     */   
/*     */   private static Method getGroupsForUserMethod() {
/* 196 */     if (getGroupsForUser == null) {
/* 197 */       getGroupsForUser = getMethod("com.ibm.websphere.security.UserRegistry", "getGroupsForUser", new String[] { "java.lang.String" });
/*     */     }
/*     */     
/* 200 */     return getGroupsForUser;
/*     */   }
/*     */   
/*     */   private static Method getSecurityNameMethod() {
/* 204 */     if (getSecurityName == null) {
/* 205 */       getSecurityName = getMethod("com.ibm.websphere.security.cred.WSCredential", "getSecurityName", new String[0]);
/*     */     }
/*     */     
/* 208 */     return getSecurityName;
/*     */   }
/*     */   
/*     */   private static Method getNarrowMethod() {
/* 212 */     if (narrow == null) {
/* 213 */       narrow = getMethod("javax.rmi.PortableRemoteObject", "narrow", new String[] { Object.class
/* 214 */             .getName(), Class.class.getName() });
/*     */     }
/* 216 */     return narrow;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<?> getWSCredentialClass() {
/* 221 */     if (wsCredentialClass == null) {
/* 222 */       wsCredentialClass = getClass("com.ibm.websphere.security.cred.WSCredential");
/*     */     }
/* 224 */     return wsCredentialClass;
/*     */   }
/*     */   
/*     */   private static Class<?> getClass(String className) {
/*     */     try {
/* 229 */       return Class.forName(className);
/*     */     }
/* 231 */     catch (ClassNotFoundException ex) {
/* 232 */       logger.error("Required class " + className + " not found");
/* 233 */       throw new RuntimeException("Required class " + className + " not found", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\authentication\preauth\websphere\DefaultWASUsernameAndGroupsExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */