/*    */ package org.springframework.security.web.debug;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Logger
/*    */ {
/* 33 */   private static final Log logger = LogFactory.getLog("Spring Security Debugger");
/*    */   
/*    */   void info(String message) {
/* 36 */     info(message, false);
/*    */   }
/*    */   
/*    */   void info(String message, boolean dumpStack) {
/* 40 */     StringBuilder output = new StringBuilder(256);
/* 41 */     output.append("\n\n************************************************************\n\n");
/* 42 */     output.append(message).append("\n");
/*    */     
/* 44 */     if (dumpStack) {
/* 45 */       StringWriter os = new StringWriter();
/* 46 */       (new Exception()).printStackTrace(new PrintWriter(os));
/* 47 */       StringBuffer buffer = os.getBuffer();
/*    */       
/* 49 */       int start = buffer.indexOf("java.lang.Exception");
/* 50 */       buffer.replace(start, start + 19, "");
/* 51 */       output.append("\nCall stack: \n").append(os.toString());
/*    */     } 
/*    */     
/* 54 */     output.append("\n\n************************************************************\n\n");
/*    */     
/* 56 */     logger.info(output.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\debug\Logger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */