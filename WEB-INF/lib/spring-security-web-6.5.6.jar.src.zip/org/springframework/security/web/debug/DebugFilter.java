/*     */ package org.springframework.security.web.debug;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DebugFilter
/*     */   implements Filter
/*     */ {
/*  51 */   static final String ALREADY_FILTERED_ATTR_NAME = DebugFilter.class.getName().concat(".FILTERED");
/*     */   
/*     */   private final FilterChainProxy filterChainProxy;
/*     */   
/*  55 */   private final Logger logger = new Logger();
/*     */   
/*     */   public DebugFilter(FilterChainProxy filterChainProxy) {
/*  58 */     this.filterChainProxy = filterChainProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*  64 */     if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
/*  65 */       throw new ServletException("DebugFilter just supports HTTP requests");
/*     */     }
/*  67 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, filterChain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
/*  72 */     List<Filter> filters = getFilters(request);
/*  73 */     this.logger.info("Request received for " + request.getMethod() + " '" + UrlUtils.buildRequestUrl(request) + "':\n\n" + String.valueOf(request) + "\n\nservletPath:" + request
/*  74 */         .getServletPath() + "\npathInfo:" + request
/*  75 */         .getPathInfo() + "\nheaders: \n" + formatHeaders(request) + "\n\n" + 
/*  76 */         formatFilters(filters));
/*  77 */     if (request.getAttribute(ALREADY_FILTERED_ATTR_NAME) == null) {
/*  78 */       invokeWithWrappedRequest(request, response, filterChain);
/*     */     } else {
/*     */       
/*  81 */       this.filterChainProxy.doFilter((ServletRequest)request, (ServletResponse)response, filterChain);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void invokeWithWrappedRequest(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
/*  87 */     request.setAttribute(ALREADY_FILTERED_ATTR_NAME, Boolean.TRUE);
/*  88 */     DebugRequestWrapper debugRequestWrapper = new DebugRequestWrapper(request);
/*     */     try {
/*  90 */       this.filterChainProxy.doFilter((ServletRequest)debugRequestWrapper, (ServletResponse)response, filterChain);
/*     */     } finally {
/*     */       
/*  93 */       debugRequestWrapper.removeAttribute(ALREADY_FILTERED_ATTR_NAME);
/*     */     } 
/*     */   }
/*     */   
/*     */   String formatHeaders(HttpServletRequest request) {
/*  98 */     StringBuilder sb = new StringBuilder();
/*  99 */     Enumeration<String> eHeaderNames = request.getHeaderNames();
/* 100 */     while (eHeaderNames.hasMoreElements()) {
/* 101 */       String headerName = eHeaderNames.nextElement();
/* 102 */       sb.append(headerName);
/* 103 */       sb.append(": ");
/* 104 */       Enumeration<String> eHeaderValues = request.getHeaders(headerName);
/* 105 */       while (eHeaderValues.hasMoreElements()) {
/* 106 */         sb.append(eHeaderValues.nextElement());
/* 107 */         if (eHeaderValues.hasMoreElements()) {
/* 108 */           sb.append(", ");
/*     */         }
/*     */       } 
/* 111 */       sb.append("\n");
/*     */     } 
/* 113 */     return sb.toString();
/*     */   }
/*     */   
/*     */   String formatFilters(List<Filter> filters) {
/* 117 */     StringBuilder sb = new StringBuilder();
/* 118 */     sb.append("Security filter chain: ");
/* 119 */     if (filters == null) {
/* 120 */       sb.append("no match");
/*     */     }
/* 122 */     else if (filters.isEmpty()) {
/* 123 */       sb.append("[] empty (bypassed by security='none') ");
/*     */     } else {
/*     */       
/* 126 */       sb.append("[\n");
/* 127 */       for (Filter f : filters) {
/* 128 */         sb.append("  ").append(f.getClass().getSimpleName()).append("\n");
/*     */       }
/* 130 */       sb.append("]");
/*     */     } 
/*     */     
/* 133 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private List<Filter> getFilters(HttpServletRequest request) {
/* 137 */     for (SecurityFilterChain chain : this.filterChainProxy.getFilterChains()) {
/* 138 */       if (chain.matches(request)) {
/* 139 */         return chain.getFilters();
/*     */       }
/*     */     } 
/*     */     
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FilterConfig filterConfig) {}
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */   
/*     */   public FilterChainProxy getFilterChainProxy() {
/* 155 */     return this.filterChainProxy;
/*     */   }
/*     */   
/*     */   static class DebugRequestWrapper
/*     */     extends HttpServletRequestWrapper {
/* 160 */     private static final Logger logger = new Logger();
/*     */     
/*     */     DebugRequestWrapper(HttpServletRequest request) {
/* 163 */       super(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpSession getSession() {
/* 168 */       boolean sessionExists = (super.getSession(false) != null);
/* 169 */       HttpSession session = super.getSession();
/* 170 */       if (!sessionExists) {
/* 171 */         logger.info("New HTTP session created: " + session.getId(), true);
/*     */       }
/* 173 */       return session;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpSession getSession(boolean create) {
/* 178 */       if (!create) {
/* 179 */         return super.getSession(create);
/*     */       }
/* 181 */       return getSession();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\debug\DebugFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */