/*    */ package org.springframework.security.web.http;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SecurityHeaders
/*    */ {
/*    */   public static Consumer<HttpHeaders> bearerToken(String bearerTokenValue) {
/* 42 */     Assert.hasText(bearerTokenValue, "bearerTokenValue cannot be null");
/* 43 */     return headers -> headers.set("Authorization", "Bearer " + bearerTokenValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\http\SecurityHeaders.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */