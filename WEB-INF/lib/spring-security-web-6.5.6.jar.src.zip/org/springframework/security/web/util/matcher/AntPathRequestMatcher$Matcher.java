package org.springframework.security.web.util.matcher;

import java.util.Map;

interface Matcher {
  boolean matches(String paramString);
  
  Map<String, String> extractUriTemplateVariables(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\we\\util\matcher\AntPathRequestMatcher$Matcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */