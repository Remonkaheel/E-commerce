/*     */ package org.springframework.security.web.util.matcher;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AndRequestMatcher
/*     */   implements RequestMatcher
/*     */ {
/*     */   private final List<RequestMatcher> requestMatchers;
/*     */   
/*     */   public AndRequestMatcher(List<RequestMatcher> requestMatchers) {
/*  45 */     Assert.notEmpty(requestMatchers, "requestMatchers must contain a value");
/*  46 */     Assert.noNullElements(requestMatchers, "requestMatchers cannot contain null values");
/*  47 */     this.requestMatchers = requestMatchers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AndRequestMatcher(RequestMatcher... requestMatchers) {
/*  55 */     this(Arrays.asList(requestMatchers));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(HttpServletRequest request) {
/*  60 */     for (RequestMatcher matcher : this.requestMatchers) {
/*  61 */       if (!matcher.matches(request)) {
/*  62 */         return false;
/*     */       }
/*     */     } 
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/*  79 */     Map<String, String> variables = new LinkedHashMap<>();
/*  80 */     for (RequestMatcher matcher : this.requestMatchers) {
/*  81 */       RequestMatcher.MatchResult result = matcher.matcher(request);
/*  82 */       if (!result.isMatch()) {
/*  83 */         return RequestMatcher.MatchResult.notMatch();
/*     */       }
/*  85 */       variables.putAll(result.getVariables());
/*     */     } 
/*  87 */     return RequestMatcher.MatchResult.match(variables);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  92 */     if (this == o) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (o == null || getClass() != o.getClass()) {
/*  96 */       return false;
/*     */     }
/*  98 */     AndRequestMatcher that = (AndRequestMatcher)o;
/*  99 */     return Objects.equals(this.requestMatchers, that.requestMatchers);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     return Objects.hash(new Object[] { this.requestMatchers });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return "And " + String.valueOf(this.requestMatchers);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\we\\util\matcher\AndRequestMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */