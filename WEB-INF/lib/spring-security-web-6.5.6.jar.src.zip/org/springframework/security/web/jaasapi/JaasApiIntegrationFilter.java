/*     */ package org.springframework.security.web.jaasapi;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.security.PrivilegedActionException;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.jaas.JaasAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaasApiIntegrationFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  58 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean createEmptySubject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
/*  83 */     Subject subject = obtainSubject(request);
/*  84 */     if (subject == null && this.createEmptySubject) {
/*  85 */       this.logger.debug("Subject returned was null and createEmptySubject is true; creating new empty subject to run as.");
/*     */       
/*  87 */       subject = new Subject();
/*     */     } 
/*  89 */     if (subject == null) {
/*  90 */       this.logger.debug("Subject is null continue running with no Subject.");
/*  91 */       chain.doFilter(request, response);
/*     */       return;
/*     */     } 
/*  94 */     this.logger.debug(LogMessage.format("Running as Subject %s", subject));
/*     */     try {
/*  96 */       Subject.doAs(subject, () -> {
/*     */             chain.doFilter(request, response);
/*     */             
/*     */             return null;
/*     */           });
/* 101 */     } catch (PrivilegedActionException ex) {
/* 102 */       throw new ServletException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subject obtainSubject(ServletRequest request) {
/*     */     JaasAuthenticationToken token;
/* 122 */     Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 123 */     this.logger.debug(LogMessage.format("Attempting to obtainSubject using authentication : %s", authentication));
/* 124 */     if (authentication == null) {
/* 125 */       return null;
/*     */     }
/* 127 */     if (!authentication.isAuthenticated()) {
/* 128 */       return null;
/*     */     }
/* 130 */     if (authentication instanceof JaasAuthenticationToken) { token = (JaasAuthenticationToken)authentication; }
/* 131 */     else { return null; }
/*     */     
/* 133 */     LoginContext loginContext = token.getLoginContext();
/* 134 */     if (loginContext == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     return loginContext.getSubject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCreateEmptySubject(boolean createEmptySubject) {
/* 148 */     this.createEmptySubject = createEmptySubject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 158 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 159 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\jaasapi\JaasApiIntegrationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */