/*    */ package org.springframework.security.web.aot.hint;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.core.io.ClassPathResource;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.security.web.access.expression.WebSecurityExpressionRoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebMvcSecurityRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 37 */     hints.reflection()
/* 38 */       .registerType(WebSecurityExpressionRoot.class, builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS, MemberCategory.DECLARED_FIELDS }));
/*    */     
/* 40 */     hints.reflection()
/* 41 */       .registerType(
/*    */         
/* 43 */         TypeReference.of("org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler$SupplierCsrfToken"), new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS });
/*    */ 
/*    */     
/* 46 */     ClassPathResource css = new ClassPathResource("org/springframework/security/default-ui.css");
/* 47 */     if (css.exists()) {
/* 48 */       hints.resources().registerResource((Resource)css);
/*    */     }
/*    */     
/* 51 */     ClassPathResource webauthnJavascript = new ClassPathResource("org/springframework/security/spring-security-webauthn.js");
/*    */     
/* 53 */     if (webauthnJavascript.exists())
/* 54 */       hints.resources().registerResource((Resource)webauthnJavascript); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\aot\hint\WebMvcSecurityRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */