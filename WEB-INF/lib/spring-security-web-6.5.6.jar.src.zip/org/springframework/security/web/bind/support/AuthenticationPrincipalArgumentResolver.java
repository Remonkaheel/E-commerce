/*     */ package org.springframework.security.web.bind.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.web.bind.annotation.AuthenticationPrincipal;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class AuthenticationPrincipalArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/*  92 */     return (findMethodAnnotation(AuthenticationPrincipal.class, parameter) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) {
/*  98 */     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
/*  99 */     if (authentication == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     Object principal = authentication.getPrincipal();
/* 103 */     if (principal != null && !parameter.getParameterType().isAssignableFrom(principal.getClass())) {
/* 104 */       AuthenticationPrincipal authPrincipal = findMethodAnnotation(AuthenticationPrincipal.class, parameter);
/* 105 */       if (authPrincipal.errorOnInvalidType()) {
/* 106 */         throw new ClassCastException(String.valueOf(principal) + " is not assignable to " + String.valueOf(principal));
/*     */       }
/* 108 */       return null;
/*     */     } 
/* 110 */     return principal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends Annotation> T findMethodAnnotation(Class<T> annotationClass, MethodParameter parameter) {
/* 121 */     Annotation annotation = parameter.getParameterAnnotation(annotationClass);
/* 122 */     if (annotation != null) {
/* 123 */       return (T)annotation;
/*     */     }
/* 125 */     Annotation[] annotationsToSearch = parameter.getParameterAnnotations();
/* 126 */     for (Annotation toSearch : annotationsToSearch) {
/* 127 */       annotation = AnnotationUtils.findAnnotation(toSearch.annotationType(), annotationClass);
/* 128 */       if (annotation != null) {
/* 129 */         return (T)annotation;
/*     */       }
/*     */     } 
/* 132 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\bind\support\AuthenticationPrincipalArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */