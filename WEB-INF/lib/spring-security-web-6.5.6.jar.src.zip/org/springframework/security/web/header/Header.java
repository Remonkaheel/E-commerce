/*    */ package org.springframework.security.web.header;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Header
/*    */ {
/*    */   private final String headerName;
/*    */   private final List<String> headerValues;
/*    */   
/*    */   public Header(String headerName, String... headerValues) {
/* 41 */     Assert.hasText(headerName, "headerName is required");
/* 42 */     Assert.notEmpty((Object[])headerValues, "headerValues cannot be null or empty");
/* 43 */     Assert.noNullElements((Object[])headerValues, "headerValues cannot contain null values");
/* 44 */     this.headerName = headerName;
/* 45 */     this.headerValues = Arrays.asList(headerValues);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 53 */     return this.headerName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getValues() {
/* 61 */     return this.headerValues;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 66 */     if (this == obj) {
/* 67 */       return true;
/*    */     }
/* 69 */     if (obj == null || getClass() != obj.getClass()) {
/* 70 */       return false;
/*    */     }
/* 72 */     Header other = (Header)obj;
/* 73 */     if (!this.headerName.equals(other.headerName)) {
/* 74 */       return false;
/*    */     }
/* 76 */     return this.headerValues.equals(other.headerValues);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 81 */     return this.headerName.hashCode() + this.headerValues.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "Header [name: " + this.headerName + ", values: " + String.valueOf(this.headerValues) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\Header.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */