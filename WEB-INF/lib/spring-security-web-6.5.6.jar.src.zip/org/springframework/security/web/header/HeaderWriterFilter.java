/*     */ package org.springframework.security.web.header;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.web.util.OnCommittedResponseWrapper;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderWriterFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   private final List<HeaderWriter> headerWriters;
/*     */   private boolean shouldWriteHeadersEagerly = false;
/*     */   
/*     */   public HeaderWriterFilter(List<HeaderWriter> headerWriters) {
/*  64 */     Assert.notEmpty(headerWriters, "headerWriters cannot be null or empty");
/*  65 */     this.headerWriters = headerWriters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/*  71 */     if (this.shouldWriteHeadersEagerly) {
/*  72 */       doHeadersBefore(request, response, filterChain);
/*     */     } else {
/*     */       
/*  75 */       doHeadersAfter(request, response, filterChain);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doHeadersBefore(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
/*  81 */     writeHeaders(request, response);
/*  82 */     filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doHeadersAfter(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
/*  87 */     HeaderWriterResponse headerWriterResponse = new HeaderWriterResponse(request, response);
/*  88 */     HeaderWriterRequest headerWriterRequest = new HeaderWriterRequest(request, headerWriterResponse);
/*     */     try {
/*  90 */       filterChain.doFilter((ServletRequest)headerWriterRequest, (ServletResponse)headerWriterResponse);
/*     */     } finally {
/*     */       
/*  93 */       headerWriterResponse.writeHeaders();
/*     */     } 
/*     */   }
/*     */   
/*     */   void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/*  98 */     for (HeaderWriter writer : this.headerWriters) {
/*  99 */       writer.writeHeaders(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShouldWriteHeadersEagerly(boolean shouldWriteHeadersEagerly) {
/* 110 */     this.shouldWriteHeadersEagerly = shouldWriteHeadersEagerly;
/*     */   }
/*     */   
/*     */   class HeaderWriterResponse
/*     */     extends OnCommittedResponseWrapper {
/*     */     private final HttpServletRequest request;
/*     */     
/*     */     HeaderWriterResponse(HttpServletRequest request, HttpServletResponse response) {
/* 118 */       super(response);
/* 119 */       this.request = request;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onResponseCommitted() {
/* 124 */       writeHeaders();
/* 125 */       disableOnResponseCommitted();
/*     */     }
/*     */     
/*     */     protected void writeHeaders() {
/* 129 */       if (isDisableOnResponseCommitted()) {
/*     */         return;
/*     */       }
/* 132 */       HeaderWriterFilter.this.writeHeaders(this.request, getHttpResponse());
/*     */     }
/*     */     
/*     */     private HttpServletResponse getHttpResponse() {
/* 136 */       return (HttpServletResponse)getResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   static class HeaderWriterRequest
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     private final HeaderWriterFilter.HeaderWriterResponse response;
/*     */     
/*     */     HeaderWriterRequest(HttpServletRequest request, HeaderWriterFilter.HeaderWriterResponse response) {
/* 146 */       super(request);
/* 147 */       this.response = response;
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestDispatcher getRequestDispatcher(String path) {
/* 152 */       return new HeaderWriterFilter.HeaderWriterRequestDispatcher(super.getRequestDispatcher(path), this.response);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class HeaderWriterRequestDispatcher
/*     */     implements RequestDispatcher
/*     */   {
/*     */     private final RequestDispatcher delegate;
/*     */     private final HeaderWriterFilter.HeaderWriterResponse response;
/*     */     
/*     */     HeaderWriterRequestDispatcher(RequestDispatcher delegate, HeaderWriterFilter.HeaderWriterResponse response) {
/* 164 */       this.delegate = delegate;
/* 165 */       this.response = response;
/*     */     }
/*     */ 
/*     */     
/*     */     public void forward(ServletRequest request, ServletResponse response) throws ServletException, IOException {
/* 170 */       this.delegate.forward(request, response);
/*     */     }
/*     */ 
/*     */     
/*     */     public void include(ServletRequest request, ServletResponse response) throws ServletException, IOException {
/* 175 */       this.response.onResponseCommitted();
/* 176 */       this.delegate.include(request, response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\HeaderWriterFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */