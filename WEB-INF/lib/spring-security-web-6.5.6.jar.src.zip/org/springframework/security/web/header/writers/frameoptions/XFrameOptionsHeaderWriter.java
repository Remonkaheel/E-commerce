/*     */ package org.springframework.security.web.header.writers.frameoptions;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XFrameOptionsHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   public static final String XFRAME_OPTIONS_HEADER = "X-Frame-Options";
/*     */   private final AllowFromStrategy allowFromStrategy;
/*     */   private final XFrameOptionsMode frameOptionsMode;
/*     */   
/*     */   public XFrameOptionsHeaderWriter() {
/*  46 */     this(XFrameOptionsMode.DENY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XFrameOptionsHeaderWriter(XFrameOptionsMode frameOptionsMode) {
/*  57 */     Assert.notNull(frameOptionsMode, "frameOptionsMode cannot be null");
/*  58 */     Assert.isTrue(!XFrameOptionsMode.ALLOW_FROM.equals(frameOptionsMode), "ALLOW_FROM requires an AllowFromStrategy. Please use FrameOptionsHeaderWriter(AllowFromStrategy allowFromStrategy) instead");
/*     */ 
/*     */     
/*  61 */     this.frameOptionsMode = frameOptionsMode;
/*  62 */     this.allowFromStrategy = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public XFrameOptionsHeaderWriter(AllowFromStrategy allowFromStrategy) {
/*  77 */     Assert.notNull(allowFromStrategy, "allowFromStrategy cannot be null");
/*  78 */     this.frameOptionsMode = XFrameOptionsMode.ALLOW_FROM;
/*  79 */     this.allowFromStrategy = allowFromStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/*  89 */     if (XFrameOptionsMode.ALLOW_FROM.equals(this.frameOptionsMode)) {
/*  90 */       String allowFromValue = this.allowFromStrategy.getAllowFromValue(request);
/*  91 */       if (XFrameOptionsMode.DENY.getMode().equals(allowFromValue)) {
/*  92 */         if (!response.containsHeader("X-Frame-Options")) {
/*  93 */           response.setHeader("X-Frame-Options", XFrameOptionsMode.DENY.getMode());
/*     */         }
/*     */       }
/*  96 */       else if (allowFromValue != null && 
/*  97 */         !response.containsHeader("X-Frame-Options")) {
/*  98 */         response.setHeader("X-Frame-Options", XFrameOptionsMode.ALLOW_FROM
/*  99 */             .getMode() + " " + XFrameOptionsMode.ALLOW_FROM.getMode());
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 104 */       response.setHeader("X-Frame-Options", this.frameOptionsMode.getMode());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum XFrameOptionsMode
/*     */   {
/* 116 */     DENY("DENY"),
/*     */     
/* 118 */     SAMEORIGIN("SAMEORIGIN"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     ALLOW_FROM("ALLOW-FROM");
/*     */     
/*     */     private final String mode;
/*     */ 
/*     */     
/*     */     XFrameOptionsMode(String mode) {
/* 132 */       this.mode = mode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String getMode() {
/* 141 */       return this.mode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\XFrameOptionsHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */