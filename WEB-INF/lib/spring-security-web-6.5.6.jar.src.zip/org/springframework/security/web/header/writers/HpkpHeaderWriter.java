/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class HpkpHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final long DEFAULT_MAX_AGE_SECONDS = 5184000L;
/*     */   private static final String HPKP_HEADER_NAME = "Public-Key-Pins";
/*     */   private static final String HPKP_RO_HEADER_NAME = "Public-Key-Pins-Report-Only";
/* 125 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 127 */   private final RequestMatcher requestMatcher = new SecureRequestMatcher();
/*     */   
/* 129 */   private Map<String, String> pins = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   private long maxAgeInSeconds;
/*     */ 
/*     */   
/*     */   private boolean includeSubDomains;
/*     */ 
/*     */   
/*     */   private boolean reportOnly;
/*     */ 
/*     */   
/*     */   private URI reportUri;
/*     */ 
/*     */   
/*     */   private String hpkpHeaderValue;
/*     */ 
/*     */   
/*     */   public HpkpHeaderWriter(long maxAgeInSeconds, boolean includeSubDomains, boolean reportOnly) {
/* 148 */     this.maxAgeInSeconds = maxAgeInSeconds;
/* 149 */     this.includeSubDomains = includeSubDomains;
/* 150 */     this.reportOnly = reportOnly;
/* 151 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HpkpHeaderWriter(long maxAgeInSeconds, boolean includeSubDomains) {
/* 160 */     this(maxAgeInSeconds, includeSubDomains, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HpkpHeaderWriter(long maxAgeInSeconds) {
/* 168 */     this(maxAgeInSeconds, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HpkpHeaderWriter() {
/* 175 */     this(5184000L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 180 */     if (!this.requestMatcher.matches(request)) {
/* 181 */       this.logger.debug("Not injecting HPKP header since it wasn't a secure connection");
/*     */       return;
/*     */     } 
/* 184 */     if (this.pins.isEmpty()) {
/* 185 */       this.logger.debug("Not injecting HPKP header since there aren't any pins");
/*     */       return;
/*     */     } 
/* 188 */     String headerName = this.reportOnly ? "Public-Key-Pins-Report-Only" : "Public-Key-Pins";
/* 189 */     if (!response.containsHeader(headerName)) {
/* 190 */       response.setHeader(headerName, this.hpkpHeaderValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPins(Map<String, String> pins) {
/* 225 */     Assert.notNull(pins, "pins cannot be null");
/* 226 */     this.pins = pins;
/* 227 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSha256Pins(String... pins) {
/* 260 */     for (String pin : pins) {
/* 261 */       Assert.notNull(pin, "pin cannot be null");
/* 262 */       this.pins.put(pin, "sha256");
/*     */     } 
/* 264 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAgeInSeconds(long maxAgeInSeconds) {
/* 298 */     Assert.isTrue((maxAgeInSeconds > 0L), () -> "maxAgeInSeconds must be non-negative. Got " + maxAgeInSeconds);
/* 299 */     this.maxAgeInSeconds = maxAgeInSeconds;
/* 300 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludeSubDomains(boolean includeSubDomains) {
/* 326 */     this.includeSubDomains = includeSubDomains;
/* 327 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReportOnly(boolean reportOnly) {
/* 354 */     this.reportOnly = reportOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReportUri(URI reportUri) {
/* 383 */     this.reportUri = reportUri;
/* 384 */     updateHpkpHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReportUri(String reportUri) {
/*     */     try {
/* 415 */       this.reportUri = new URI(reportUri);
/* 416 */       updateHpkpHeaderValue();
/*     */     }
/* 418 */     catch (URISyntaxException ex) {
/* 419 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateHpkpHeaderValue() {
/* 424 */     String headerValue = "max-age=" + this.maxAgeInSeconds;
/* 425 */     for (Map.Entry<String, String> pin : this.pins.entrySet()) {
/* 426 */       headerValue = headerValue + " ; pin-" + headerValue + "=\"" + (String)pin.getValue() + "\"";
/*     */     }
/* 428 */     if (this.reportUri != null) {
/* 429 */       headerValue = headerValue + " ; report-uri=\"" + headerValue + "\"";
/*     */     }
/* 431 */     if (this.includeSubDomains) {
/* 432 */       headerValue = headerValue + " ; includeSubDomains";
/*     */     }
/* 434 */     this.hpkpHeaderValue = headerValue;
/*     */   }
/*     */   
/*     */   private static final class SecureRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 441 */       return request.isSecure();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 446 */       return "Is Secure";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\HpkpHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */