/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HstsHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final long DEFAULT_MAX_AGE_SECONDS = 31536000L;
/*     */   private static final String HSTS_HEADER_NAME = "Strict-Transport-Security";
/*  65 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestMatcher requestMatcher;
/*     */ 
/*     */ 
/*     */   
/*     */   private long maxAgeInSeconds;
/*     */ 
/*     */   
/*     */   private boolean includeSubDomains;
/*     */ 
/*     */   
/*     */   private boolean preload;
/*     */ 
/*     */   
/*     */   private String hstsHeaderValue;
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(RequestMatcher requestMatcher, long maxAgeInSeconds, boolean includeSubDomains, boolean preload) {
/*  87 */     this.requestMatcher = requestMatcher;
/*  88 */     this.maxAgeInSeconds = maxAgeInSeconds;
/*  89 */     this.includeSubDomains = includeSubDomains;
/*  90 */     this.preload = preload;
/*  91 */     updateHstsHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(RequestMatcher requestMatcher, long maxAgeInSeconds, boolean includeSubDomains) {
/* 101 */     this(requestMatcher, maxAgeInSeconds, includeSubDomains, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(long maxAgeInSeconds, boolean includeSubDomains, boolean preload) {
/* 112 */     this(new SecureRequestMatcher(), maxAgeInSeconds, includeSubDomains, preload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(long maxAgeInSeconds, boolean includeSubDomains) {
/* 121 */     this(new SecureRequestMatcher(), maxAgeInSeconds, includeSubDomains, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(long maxAgeInSeconds) {
/* 129 */     this(new SecureRequestMatcher(), maxAgeInSeconds, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter(boolean includeSubDomains) {
/* 137 */     this(new SecureRequestMatcher(), 31536000L, includeSubDomains, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HstsHeaderWriter() {
/* 144 */     this(31536000L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 149 */     if (!this.requestMatcher.matches(request)) {
/* 150 */       if (this.logger.isTraceEnabled()) {
/* 151 */         this.logger.trace(LogMessage.format("Not injecting HSTS header since it did not match request to [%s]", this.requestMatcher));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 156 */     if (!response.containsHeader("Strict-Transport-Security")) {
/* 157 */       response.setHeader("Strict-Transport-Security", this.hstsHeaderValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestMatcher(RequestMatcher requestMatcher) {
/* 170 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 171 */     this.requestMatcher = requestMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAgeInSeconds(long maxAgeInSeconds) {
/* 190 */     Assert.isTrue((maxAgeInSeconds >= 0L), () -> "maxAgeInSeconds must be non-negative. Got " + maxAgeInSeconds);
/* 191 */     this.maxAgeInSeconds = maxAgeInSeconds;
/* 192 */     updateHstsHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludeSubDomains(boolean includeSubDomains) {
/* 207 */     this.includeSubDomains = includeSubDomains;
/* 208 */     updateHstsHeaderValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreload(boolean preload) {
/* 224 */     this.preload = preload;
/* 225 */     updateHstsHeaderValue();
/*     */   }
/*     */   
/*     */   private void updateHstsHeaderValue() {
/* 229 */     String headerValue = "max-age=" + this.maxAgeInSeconds;
/* 230 */     if (this.includeSubDomains) {
/* 231 */       headerValue = headerValue + " ; includeSubDomains";
/*     */     }
/* 233 */     if (this.preload) {
/* 234 */       headerValue = headerValue + " ; preload";
/*     */     }
/* 236 */     this.hstsHeaderValue = headerValue;
/*     */   }
/*     */   
/*     */   private static final class SecureRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 243 */       return request.isSecure();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 248 */       return "Is Secure";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\HstsHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */