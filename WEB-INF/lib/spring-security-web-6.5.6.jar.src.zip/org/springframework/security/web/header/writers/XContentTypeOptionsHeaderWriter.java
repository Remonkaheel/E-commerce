/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XContentTypeOptionsHeaderWriter
/*    */   extends StaticHeadersWriter
/*    */ {
/*    */   public XContentTypeOptionsHeaderWriter() {
/* 35 */     super("X-Content-Type-Options", new String[] { "nosniff" });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\XContentTypeOptionsHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */