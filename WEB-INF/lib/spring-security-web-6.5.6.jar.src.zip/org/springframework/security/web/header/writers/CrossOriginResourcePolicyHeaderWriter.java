/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginResourcePolicyHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String RESOURCE_POLICY = "Cross-Origin-Resource-Policy";
/*    */   private CrossOriginResourcePolicy policy;
/*    */   
/*    */   public void setPolicy(CrossOriginResourcePolicy resourcePolicy) {
/* 46 */     Assert.notNull(resourcePolicy, "resourcePolicy cannot be null");
/* 47 */     this.policy = resourcePolicy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 52 */     if (this.policy != null && !response.containsHeader("Cross-Origin-Resource-Policy")) {
/* 53 */       response.addHeader("Cross-Origin-Resource-Policy", this.policy.getPolicy());
/*    */     }
/*    */   }
/*    */   
/*    */   public enum CrossOriginResourcePolicy
/*    */   {
/* 59 */     SAME_SITE("same-site"),
/*    */     
/* 61 */     SAME_ORIGIN("same-origin"),
/*    */     
/* 63 */     CROSS_ORIGIN("cross-origin");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginResourcePolicy(String policy) {
/* 68 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 72 */       return this.policy;
/*    */     }
/*    */     
/*    */     public static CrossOriginResourcePolicy from(String resourcePolicy) {
/* 76 */       for (CrossOriginResourcePolicy policy : values()) {
/* 77 */         if (policy.getPolicy().equals(resourcePolicy)) {
/* 78 */           return policy;
/*    */         }
/*    */       } 
/* 81 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CrossOriginResourcePolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */