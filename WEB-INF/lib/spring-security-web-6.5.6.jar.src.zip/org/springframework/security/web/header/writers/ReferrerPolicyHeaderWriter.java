/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferrerPolicyHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final String REFERRER_POLICY_HEADER = "Referrer-Policy";
/*     */   private ReferrerPolicy policy;
/*     */   
/*     */   public ReferrerPolicyHeaderWriter() {
/*  68 */     this(ReferrerPolicy.NO_REFERRER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferrerPolicyHeaderWriter(ReferrerPolicy policy) {
/*  77 */     setPolicy(policy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicy(ReferrerPolicy policy) {
/*  86 */     Assert.notNull(policy, "policy can not be null");
/*  87 */     this.policy = policy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/*  96 */     if (!response.containsHeader("Referrer-Policy")) {
/*  97 */       response.setHeader("Referrer-Policy", this.policy.getPolicy());
/*     */     }
/*     */   }
/*     */   
/*     */   public enum ReferrerPolicy
/*     */   {
/* 103 */     NO_REFERRER("no-referrer"),
/*     */     
/* 105 */     NO_REFERRER_WHEN_DOWNGRADE("no-referrer-when-downgrade"),
/*     */     
/* 107 */     SAME_ORIGIN("same-origin"),
/*     */     
/* 109 */     ORIGIN("origin"),
/*     */     
/* 111 */     STRICT_ORIGIN("strict-origin"),
/*     */     
/* 113 */     ORIGIN_WHEN_CROSS_ORIGIN("origin-when-cross-origin"),
/*     */     
/* 115 */     STRICT_ORIGIN_WHEN_CROSS_ORIGIN("strict-origin-when-cross-origin"),
/*     */     
/* 117 */     UNSAFE_URL("unsafe-url");
/*     */     private static final Map<String, ReferrerPolicy> REFERRER_POLICIES;
/*     */     private final String policy;
/*     */     
/*     */     static {
/* 122 */       Map<String, ReferrerPolicy> referrerPolicies = new HashMap<>();
/* 123 */       for (ReferrerPolicy referrerPolicy : values()) {
/* 124 */         referrerPolicies.put(referrerPolicy.getPolicy(), referrerPolicy);
/*     */       }
/* 126 */       REFERRER_POLICIES = Collections.unmodifiableMap(referrerPolicies);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ReferrerPolicy(String policy) {
/* 132 */       this.policy = policy;
/*     */     }
/*     */     
/*     */     public String getPolicy() {
/* 136 */       return this.policy;
/*     */     }
/*     */     
/*     */     public static ReferrerPolicy get(String referrerPolicy) {
/* 140 */       return REFERRER_POLICIES.get(referrerPolicy);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\ReferrerPolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */