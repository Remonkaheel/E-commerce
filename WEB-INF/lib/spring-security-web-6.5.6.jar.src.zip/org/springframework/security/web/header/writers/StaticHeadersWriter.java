/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.security.web.header.Header;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticHeadersWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private final List<Header> headers;
/*    */   
/*    */   public StaticHeadersWriter(List<Header> headers) {
/* 46 */     Assert.notEmpty(headers, "headers cannot be null or empty");
/* 47 */     this.headers = headers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StaticHeadersWriter(String headerName, String... headerValues) {
/* 56 */     this(Collections.singletonList(new Header(headerName, headerValues)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 61 */     for (Header header : this.headers) {
/* 62 */       if (!response.containsHeader(header.getName())) {
/* 63 */         for (String value : header.getValues()) {
/* 64 */           response.addHeader(header.getName(), value);
/*    */         }
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return getClass().getName() + " [headers=" + getClass().getName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\StaticHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */