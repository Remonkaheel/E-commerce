package org.springframework.security.web.header.writers.frameoptions;

import jakarta.servlet.http.HttpServletRequest;

@Deprecated
public interface AllowFromStrategy {
  String getAllowFromValue(HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\AllowFromStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */