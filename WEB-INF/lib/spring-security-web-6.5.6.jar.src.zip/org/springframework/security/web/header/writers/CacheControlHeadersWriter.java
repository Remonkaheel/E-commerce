/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.security.web.header.Header;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CacheControlHeadersWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String EXPIRES = "Expires";
/*    */   private static final String PRAGMA = "Pragma";
/*    */   private static final String CACHE_CONTROL = "Cache-Control";
/* 55 */   private final HeaderWriter delegate = new StaticHeadersWriter(createHeaders());
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 60 */     if (hasHeader(response, "Cache-Control") || hasHeader(response, "Expires") || hasHeader(response, "Pragma") || response
/* 61 */       .getStatus() == HttpStatus.NOT_MODIFIED.value()) {
/*    */       return;
/*    */     }
/* 64 */     this.delegate.writeHeaders(request, response);
/*    */   }
/*    */   
/*    */   private boolean hasHeader(HttpServletResponse response, String headerName) {
/* 68 */     return (response.getHeader(headerName) != null);
/*    */   }
/*    */   
/*    */   private static List<Header> createHeaders() {
/* 72 */     List<Header> headers = new ArrayList<>(3);
/* 73 */     headers.add(new Header("Cache-Control", new String[] { "no-cache, no-store, max-age=0, must-revalidate" }));
/* 74 */     headers.add(new Header("Pragma", new String[] { "no-cache" }));
/* 75 */     headers.add(new Header("Expires", new String[] { "0" }));
/* 76 */     return headers;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CacheControlHeadersWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */