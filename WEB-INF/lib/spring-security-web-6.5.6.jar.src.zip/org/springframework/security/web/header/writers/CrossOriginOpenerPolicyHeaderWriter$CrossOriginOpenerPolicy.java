/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CrossOriginOpenerPolicy
/*    */ {
/* 59 */   UNSAFE_NONE("unsafe-none"),
/*    */   
/* 61 */   SAME_ORIGIN_ALLOW_POPUPS("same-origin-allow-popups"),
/*    */   
/* 63 */   SAME_ORIGIN("same-origin");
/*    */   
/*    */   private final String policy;
/*    */   
/*    */   CrossOriginOpenerPolicy(String policy) {
/* 68 */     this.policy = policy;
/*    */   }
/*    */   
/*    */   public String getPolicy() {
/* 72 */     return this.policy;
/*    */   }
/*    */   
/*    */   public static CrossOriginOpenerPolicy from(String openerPolicy) {
/* 76 */     for (CrossOriginOpenerPolicy policy : values()) {
/* 77 */       if (policy.getPolicy().equals(openerPolicy)) {
/* 78 */         return policy;
/*    */       }
/*    */     } 
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CrossOriginOpenerPolicyHeaderWriter$CrossOriginOpenerPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */