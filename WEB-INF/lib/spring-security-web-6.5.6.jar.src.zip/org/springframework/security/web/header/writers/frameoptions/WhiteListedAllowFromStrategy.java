/*    */ package org.springframework.security.web.header.writers.frameoptions;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class WhiteListedAllowFromStrategy
/*    */   extends AbstractRequestParameterAllowFromStrategy
/*    */ {
/*    */   private final Collection<String> allowed;
/*    */   
/*    */   public WhiteListedAllowFromStrategy(Collection<String> allowed) {
/* 43 */     Assert.notEmpty(allowed, "Allowed origins cannot be empty.");
/* 44 */     this.allowed = allowed;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean allowed(String allowFromOrigin) {
/* 49 */     return this.allowed.contains(allowFromOrigin);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\WhiteListedAllowFromStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */