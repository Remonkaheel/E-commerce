/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.List;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private final List<HeaderWriter> headerWriters;
/*    */   
/*    */   public CompositeHeaderWriter(List<HeaderWriter> headerWriters) {
/* 43 */     Assert.notEmpty(headerWriters, "headerWriters cannot be empty");
/* 44 */     this.headerWriters = headerWriters;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 49 */     this.headerWriters.forEach(headerWriter -> headerWriter.writeHeaders(request, response));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CompositeHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */