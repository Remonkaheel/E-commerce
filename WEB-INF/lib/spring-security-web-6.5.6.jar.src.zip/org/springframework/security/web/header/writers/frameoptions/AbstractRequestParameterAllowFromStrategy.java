/*    */ package org.springframework.security.web.header.writers.frameoptions;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractRequestParameterAllowFromStrategy
/*    */   implements AllowFromStrategy
/*    */ {
/*    */   private static final String DEFAULT_ORIGIN_REQUEST_PARAMETER = "x-frames-allow-from";
/* 44 */   private String allowFromParameterName = "x-frames-allow-from";
/*    */ 
/*    */   
/* 47 */   protected final Log log = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAllowFromValue(HttpServletRequest request) {
/* 54 */     String allowFromOrigin = request.getParameter(this.allowFromParameterName);
/* 55 */     this.log.debug(LogMessage.format("Supplied origin '%s'", allowFromOrigin));
/* 56 */     if (StringUtils.hasText(allowFromOrigin) && allowed(allowFromOrigin)) {
/* 57 */       return allowFromOrigin;
/*    */     }
/* 59 */     return "DENY";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAllowFromParameterName(String allowFromParameterName) {
/* 69 */     Assert.notNull(allowFromParameterName, "allowFromParameterName cannot be null");
/* 70 */     this.allowFromParameterName = allowFromParameterName;
/*    */   }
/*    */   
/*    */   protected abstract boolean allowed(String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\AbstractRequestParameterAllowFromStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */