/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClearSiteDataHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final String CLEAR_SITE_DATA_HEADER = "Clear-Site-Data";
/*  50 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final RequestMatcher requestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String headerValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClearSiteDataHeaderWriter(Directive... directives) {
/*  67 */     Assert.notEmpty((Object[])directives, "directives cannot be empty or null");
/*  68 */     this.requestMatcher = new SecureRequestMatcher();
/*  69 */     this.headerValue = transformToHeaderValue(directives);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/*  74 */     if (this.requestMatcher.matches(request)) {
/*  75 */       if (!response.containsHeader("Clear-Site-Data")) {
/*  76 */         response.setHeader("Clear-Site-Data", this.headerValue);
/*     */       }
/*     */       return;
/*     */     } 
/*  80 */     this.logger.debug(
/*  81 */         LogMessage.format("Not injecting Clear-Site-Data header since it did not match the requestMatcher %s", this.requestMatcher));
/*     */   }
/*     */ 
/*     */   
/*     */   private String transformToHeaderValue(Directive... directives) {
/*  86 */     StringBuilder sb = new StringBuilder();
/*  87 */     for (int i = 0; i < directives.length - 1; i++) {
/*  88 */       sb.append((directives[i]).headerValue).append(", ");
/*     */     }
/*  90 */     sb.append((directives[directives.length - 1]).headerValue);
/*  91 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  96 */     return getClass().getName() + " [headerValue=" + getClass().getName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Directive
/*     */   {
/* 104 */     CACHE("cache"),
/*     */     
/* 106 */     COOKIES("cookies"),
/*     */     
/* 108 */     STORAGE("storage"),
/*     */     
/* 110 */     EXECUTION_CONTEXTS("executionContexts"),
/*     */     
/* 112 */     ALL("*");
/*     */     
/*     */     private final String headerValue;
/*     */     
/*     */     Directive(String headerValue) {
/* 117 */       this.headerValue = "\"" + headerValue + "\"";
/*     */     }
/*     */     
/*     */     public String getHeaderValue() {
/* 121 */       return this.headerValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class SecureRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 130 */       return request.isSecure();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 135 */       return "Is Secure";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\ClearSiteDataHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */