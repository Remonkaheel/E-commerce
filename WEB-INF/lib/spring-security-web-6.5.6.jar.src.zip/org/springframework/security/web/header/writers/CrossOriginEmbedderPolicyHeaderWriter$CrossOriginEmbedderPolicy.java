/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CrossOriginEmbedderPolicy
/*    */ {
/* 59 */   UNSAFE_NONE("unsafe-none"),
/*    */   
/* 61 */   REQUIRE_CORP("require-corp");
/*    */   
/*    */   private final String policy;
/*    */   
/*    */   CrossOriginEmbedderPolicy(String policy) {
/* 66 */     this.policy = policy;
/*    */   }
/*    */   
/*    */   public String getPolicy() {
/* 70 */     return this.policy;
/*    */   }
/*    */   
/*    */   public static CrossOriginEmbedderPolicy from(String embedderPolicy) {
/* 74 */     for (CrossOriginEmbedderPolicy policy : values()) {
/* 75 */       if (policy.getPolicy().equals(embedderPolicy)) {
/* 76 */         return policy;
/*    */       }
/*    */     } 
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CrossOriginEmbedderPolicyHeaderWriter$CrossOriginEmbedderPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */