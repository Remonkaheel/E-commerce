/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginEmbedderPolicyHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String EMBEDDER_POLICY = "Cross-Origin-Embedder-Policy";
/*    */   private CrossOriginEmbedderPolicy policy;
/*    */   
/*    */   public void setPolicy(CrossOriginEmbedderPolicy embedderPolicy) {
/* 46 */     Assert.notNull(embedderPolicy, "embedderPolicy cannot be null");
/* 47 */     this.policy = embedderPolicy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 52 */     if (this.policy != null && !response.containsHeader("Cross-Origin-Embedder-Policy")) {
/* 53 */       response.addHeader("Cross-Origin-Embedder-Policy", this.policy.getPolicy());
/*    */     }
/*    */   }
/*    */   
/*    */   public enum CrossOriginEmbedderPolicy
/*    */   {
/* 59 */     UNSAFE_NONE("unsafe-none"),
/*    */     
/* 61 */     REQUIRE_CORP("require-corp");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginEmbedderPolicy(String policy) {
/* 66 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 70 */       return this.policy;
/*    */     }
/*    */     
/*    */     public static CrossOriginEmbedderPolicy from(String embedderPolicy) {
/* 74 */       for (CrossOriginEmbedderPolicy policy : values()) {
/* 75 */         if (policy.getPolicy().equals(embedderPolicy)) {
/* 76 */           return policy;
/*    */         }
/*    */       } 
/* 79 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CrossOriginEmbedderPolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */