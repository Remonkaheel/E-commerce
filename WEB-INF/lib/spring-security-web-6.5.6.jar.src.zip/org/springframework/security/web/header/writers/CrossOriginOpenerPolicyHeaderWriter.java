/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CrossOriginOpenerPolicyHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String OPENER_POLICY = "Cross-Origin-Opener-Policy";
/*    */   private CrossOriginOpenerPolicy policy;
/*    */   
/*    */   public void setPolicy(CrossOriginOpenerPolicy openerPolicy) {
/* 46 */     Assert.notNull(openerPolicy, "openerPolicy cannot be null");
/* 47 */     this.policy = openerPolicy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 52 */     if (this.policy != null && !response.containsHeader("Cross-Origin-Opener-Policy")) {
/* 53 */       response.addHeader("Cross-Origin-Opener-Policy", this.policy.getPolicy());
/*    */     }
/*    */   }
/*    */   
/*    */   public enum CrossOriginOpenerPolicy
/*    */   {
/* 59 */     UNSAFE_NONE("unsafe-none"),
/*    */     
/* 61 */     SAME_ORIGIN_ALLOW_POPUPS("same-origin-allow-popups"),
/*    */     
/* 63 */     SAME_ORIGIN("same-origin");
/*    */     
/*    */     private final String policy;
/*    */     
/*    */     CrossOriginOpenerPolicy(String policy) {
/* 68 */       this.policy = policy;
/*    */     }
/*    */     
/*    */     public String getPolicy() {
/* 72 */       return this.policy;
/*    */     }
/*    */     
/*    */     public static CrossOriginOpenerPolicy from(String openerPolicy) {
/* 76 */       for (CrossOriginOpenerPolicy policy : values()) {
/* 77 */         if (policy.getPolicy().equals(openerPolicy)) {
/* 78 */           return policy;
/*    */         }
/*    */       } 
/* 81 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\CrossOriginOpenerPolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */