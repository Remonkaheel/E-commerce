/*    */ package org.springframework.security.web.header.writers.frameoptions;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class StaticAllowFromStrategy
/*    */   implements AllowFromStrategy
/*    */ {
/*    */   private final URI uri;
/*    */   
/*    */   public StaticAllowFromStrategy(URI uri) {
/* 37 */     this.uri = uri;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAllowFromValue(HttpServletRequest request) {
/* 42 */     return this.uri.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\StaticAllowFromStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */