/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContentSecurityPolicyHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final String CONTENT_SECURITY_POLICY_HEADER = "Content-Security-Policy";
/*     */   private static final String CONTENT_SECURITY_POLICY_REPORT_ONLY_HEADER = "Content-Security-Policy-Report-Only";
/*     */   private static final String DEFAULT_SRC_SELF_POLICY = "default-src 'self'";
/*     */   private String policyDirectives;
/*     */   private boolean reportOnly;
/*     */   
/*     */   public ContentSecurityPolicyHeaderWriter() {
/* 100 */     setPolicyDirectives("default-src 'self'");
/* 101 */     this.reportOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentSecurityPolicyHeaderWriter(String policyDirectives) {
/* 110 */     setPolicyDirectives(policyDirectives);
/* 111 */     this.reportOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 121 */     String headerName = !this.reportOnly ? "Content-Security-Policy" : "Content-Security-Policy-Report-Only";
/* 122 */     if (!response.containsHeader(headerName)) {
/* 123 */       response.setHeader(headerName, this.policyDirectives);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicyDirectives(String policyDirectives) {
/* 133 */     Assert.hasLength(policyDirectives, "policyDirectives cannot be null or empty");
/* 134 */     this.policyDirectives = policyDirectives;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReportOnly(boolean reportOnly) {
/* 143 */     this.reportOnly = reportOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return getClass().getName() + " [policyDirectives=" + getClass().getName() + "; reportOnly=" + this.policyDirectives + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\ContentSecurityPolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */