/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FeaturePolicyHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String FEATURE_POLICY_HEADER = "Feature-Policy";
/*    */   private String policyDirectives;
/*    */   
/*    */   public FeaturePolicyHeaderWriter(String policyDirectives) {
/* 52 */     setPolicyDirectives(policyDirectives);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 57 */     if (!response.containsHeader("Feature-Policy")) {
/* 58 */       response.setHeader("Feature-Policy", this.policyDirectives);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPolicyDirectives(String policyDirectives) {
/* 68 */     Assert.hasLength(policyDirectives, "policyDirectives must not be null or empty");
/* 69 */     this.policyDirectives = policyDirectives;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return getClass().getName() + " [policyDirectives=" + getClass().getName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\FeaturePolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */