/*    */ package org.springframework.security.web.header.writers.frameoptions;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class RegExpAllowFromStrategy
/*    */   extends AbstractRequestParameterAllowFromStrategy
/*    */ {
/*    */   private final Pattern pattern;
/*    */   
/*    */   public RegExpAllowFromStrategy(String pattern) {
/* 46 */     Assert.hasText(pattern, "Pattern cannot be empty.");
/* 47 */     this.pattern = Pattern.compile(pattern);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean allowed(String allowFromOrigin) {
/* 52 */     return this.pattern.matcher(allowFromOrigin).matches();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\frameoptions\RegExpAllowFromStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */