/*     */ package org.springframework.security.web.header;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.security.web.util.OnCommittedResponseWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HeaderWriterResponse
/*     */   extends OnCommittedResponseWrapper
/*     */ {
/*     */   private final HttpServletRequest request;
/*     */   
/*     */   HeaderWriterResponse(HttpServletRequest request, HttpServletResponse response) {
/* 118 */     super(response);
/* 119 */     this.request = request;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onResponseCommitted() {
/* 124 */     writeHeaders();
/* 125 */     disableOnResponseCommitted();
/*     */   }
/*     */   
/*     */   protected void writeHeaders() {
/* 129 */     if (isDisableOnResponseCommitted()) {
/*     */       return;
/*     */     }
/* 132 */     HeaderWriterFilter.this.writeHeaders(this.request, getHttpResponse());
/*     */   }
/*     */   
/*     */   private HttpServletResponse getHttpResponse() {
/* 136 */     return (HttpServletResponse)getResponse();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\HeaderWriterFilter$HeaderWriterResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */