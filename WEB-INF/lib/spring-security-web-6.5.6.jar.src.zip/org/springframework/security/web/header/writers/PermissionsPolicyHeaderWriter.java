/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PermissionsPolicyHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private static final String PERMISSIONS_POLICY_HEADER = "Permissions-Policy";
/*    */   private String policy;
/*    */   
/*    */   public PermissionsPolicyHeaderWriter() {}
/*    */   
/*    */   public PermissionsPolicyHeaderWriter(String policy) {
/* 57 */     setPolicy(policy);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPolicy(String policy) {
/* 66 */     Assert.hasLength(policy, "policy can not be null or empty");
/* 67 */     this.policy = policy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 72 */     if (!response.containsHeader("Permissions-Policy")) {
/* 73 */       response.setHeader("Permissions-Policy", this.policy);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return getClass().getName() + " [policy=" + getClass().getName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\PermissionsPolicyHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */