/*     */ package org.springframework.security.web.header.writers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XXssProtectionHeaderWriter
/*     */   implements HeaderWriter
/*     */ {
/*     */   private static final String XSS_PROTECTION_HEADER = "X-XSS-Protection";
/*  45 */   private HeaderValue headerValue = HeaderValue.DISABLED;
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/*  50 */     if (!response.containsHeader("X-XSS-Protection")) {
/*  51 */       response.setHeader("X-XSS-Protection", this.headerValue.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderValue(HeaderValue headerValue) {
/*  84 */     Assert.notNull(headerValue, "headerValue cannot be null");
/*  85 */     this.headerValue = headerValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum HeaderValue
/*     */   {
/*  96 */     DISABLED("0"), ENABLED("1"), ENABLED_MODE_BLOCK("1; mode=block");
/*     */     
/*     */     private final String value;
/*     */     
/*     */     HeaderValue(String value) {
/* 101 */       this.value = value;
/*     */     }
/*     */     
/*     */     public static HeaderValue from(String headerValue) {
/* 105 */       for (HeaderValue value : values()) {
/* 106 */         if (value.toString().equals(headerValue)) {
/* 107 */           return value;
/*     */         }
/*     */       } 
/* 110 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 115 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return getClass().getName() + " [headerValue=" + getClass().getName() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\XXssProtectionHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */