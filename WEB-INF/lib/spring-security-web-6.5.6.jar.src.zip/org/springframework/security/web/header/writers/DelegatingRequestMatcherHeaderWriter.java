/*    */ package org.springframework.security.web.header.writers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.web.header.HeaderWriter;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingRequestMatcherHeaderWriter
/*    */   implements HeaderWriter
/*    */ {
/*    */   private final RequestMatcher requestMatcher;
/*    */   private final HeaderWriter delegateHeaderWriter;
/*    */   
/*    */   public DelegatingRequestMatcherHeaderWriter(RequestMatcher requestMatcher, HeaderWriter delegateHeaderWriter) {
/* 47 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 48 */     Assert.notNull(delegateHeaderWriter, "delegateHeaderWriter cannot be null");
/* 49 */     this.requestMatcher = requestMatcher;
/* 50 */     this.delegateHeaderWriter = delegateHeaderWriter;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeHeaders(HttpServletRequest request, HttpServletResponse response) {
/* 55 */     if (this.requestMatcher.matches(request)) {
/* 56 */       this.delegateHeaderWriter.writeHeaders(request, response);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 62 */     return getClass().getName() + " [requestMatcher=" + getClass().getName() + ", delegateHeaderWriter=" + String.valueOf(this.requestMatcher) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\header\writers\DelegatingRequestMatcherHeaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */