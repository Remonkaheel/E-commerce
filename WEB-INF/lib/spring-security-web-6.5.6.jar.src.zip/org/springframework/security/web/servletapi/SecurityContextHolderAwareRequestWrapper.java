/*     */ package org.springframework.security.web.servletapi;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import java.security.Principal;
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextHolderAwareRequestWrapper
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*  55 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AuthenticationTrustResolver trustResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String rolePrefix;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContextHolderAwareRequestWrapper(HttpServletRequest request, String rolePrefix) {
/*  71 */     this(request, (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl(), rolePrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContextHolderAwareRequestWrapper(HttpServletRequest request, AuthenticationTrustResolver trustResolver, String rolePrefix) {
/*  84 */     super(request);
/*  85 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/*  86 */     this.rolePrefix = rolePrefix;
/*  87 */     this.trustResolver = trustResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication getAuthentication() {
/*  95 */     Authentication auth = this.securityContextHolderStrategy.getContext().getAuthentication();
/*  96 */     return this.trustResolver.isAuthenticated(auth) ? auth : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteUser() {
/* 107 */     Authentication auth = getAuthentication();
/* 108 */     if (auth == null || auth.getPrincipal() == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     if (auth.getPrincipal() instanceof UserDetails) {
/* 112 */       return ((UserDetails)auth.getPrincipal()).getUsername();
/*     */     }
/* 114 */     if (auth instanceof org.springframework.security.authentication.AbstractAuthenticationToken) {
/* 115 */       return auth.getName();
/*     */     }
/* 117 */     return auth.getPrincipal().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal getUserPrincipal() {
/* 127 */     Authentication auth = getAuthentication();
/* 128 */     if (auth == null || auth.getPrincipal() == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     return (Principal)auth;
/*     */   }
/*     */   
/*     */   private boolean isGranted(String role) {
/* 135 */     Authentication auth = getAuthentication();
/* 136 */     if (this.rolePrefix != null && role != null && !role.startsWith(this.rolePrefix)) {
/* 137 */       role = this.rolePrefix + this.rolePrefix;
/*     */     }
/* 139 */     if (auth == null || auth.getPrincipal() == null) {
/* 140 */       return false;
/*     */     }
/* 142 */     Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
/* 143 */     if (authorities == null) {
/* 144 */       return false;
/*     */     }
/* 146 */     for (GrantedAuthority grantedAuthority : authorities) {
/* 147 */       if (role.equals(grantedAuthority.getAuthority())) {
/* 148 */         return true;
/*     */       }
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUserInRole(String role) {
/* 168 */     return isGranted(role);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 173 */     return "SecurityContextHolderAwareRequestWrapper[ " + String.valueOf(getRequest()) + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 183 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 184 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servletapi\SecurityContextHolderAwareRequestWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */