/*     */ package org.springframework.security.web.servletapi;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextHolderAwareRequestFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  75 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  77 */   private String rolePrefix = "ROLE_";
/*     */   
/*     */   private HttpServletRequestFactory requestFactory;
/*     */   
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/*     */   private List<LogoutHandler> logoutHandlers;
/*     */   
/*  87 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*  89 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/*  98 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/*  99 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 109 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 110 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/* 114 */     Assert.notNull(rolePrefix, "Role prefix must not be null");
/* 115 */     this.rolePrefix = rolePrefix;
/* 116 */     updateFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
/* 136 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 154 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogoutHandlers(List<LogoutHandler> logoutHandlers) {
/* 173 */     this.logoutHandlers = logoutHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/* 179 */     chain.doFilter((ServletRequest)this.requestFactory.create((HttpServletRequest)req, (HttpServletResponse)res), res);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws ServletException {
/* 184 */     super.afterPropertiesSet();
/* 185 */     updateFactory();
/*     */   }
/*     */   
/*     */   private void updateFactory() {
/* 189 */     String rolePrefix = this.rolePrefix;
/* 190 */     this.requestFactory = createServlet3Factory(rolePrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 200 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 201 */     this.trustResolver = trustResolver;
/* 202 */     updateFactory();
/*     */   }
/*     */   
/*     */   private HttpServletRequestFactory createServlet3Factory(String rolePrefix) {
/* 206 */     HttpServlet3RequestFactory factory = new HttpServlet3RequestFactory(rolePrefix, this.securityContextRepository);
/* 207 */     factory.setTrustResolver(this.trustResolver);
/* 208 */     factory.setAuthenticationEntryPoint(this.authenticationEntryPoint);
/* 209 */     factory.setAuthenticationManager(this.authenticationManager);
/* 210 */     factory.setLogoutHandlers(this.logoutHandlers);
/* 211 */     factory.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 212 */     return factory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servletapi\SecurityContextHolderAwareRequestFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */