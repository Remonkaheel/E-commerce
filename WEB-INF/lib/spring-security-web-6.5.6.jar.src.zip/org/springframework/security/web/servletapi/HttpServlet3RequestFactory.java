/*     */ package org.springframework.security.web.servletapi;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.concurrent.DelegatingSecurityContextRunnable;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HttpServlet3RequestFactory
/*     */   implements HttpServletRequestFactory
/*     */ {
/*  79 */   private Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*  82 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private final String rolePrefix;
/*     */   
/*  86 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*  88 */   private final AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = (AuthenticationDetailsSource<HttpServletRequest, ?>)new WebAuthenticationDetailsSource();
/*     */   
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/*     */   private List<LogoutHandler> logoutHandlers;
/*     */   
/*     */   private SecurityContextRepository securityContextRepository;
/*     */   
/*     */   HttpServlet3RequestFactory(String rolePrefix, SecurityContextRepository securityContextRepository) {
/*  99 */     this.rolePrefix = rolePrefix;
/* 100 */     this.securityContextRepository = securityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAuthenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
/* 121 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 139 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLogoutHandlers(List<LogoutHandler> logoutHandlers) {
/* 158 */     this.logoutHandlers = logoutHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 168 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 169 */     this.trustResolver = trustResolver;
/*     */   }
/*     */   
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 173 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 174 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest create(HttpServletRequest request, HttpServletResponse response) {
/* 179 */     Servlet3SecurityContextHolderAwareRequestWrapper wrapper = new Servlet3SecurityContextHolderAwareRequestWrapper(request, this.rolePrefix, response);
/*     */     
/* 181 */     wrapper.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 182 */     return (HttpServletRequest)wrapper;
/*     */   }
/*     */   
/*     */   private class Servlet3SecurityContextHolderAwareRequestWrapper
/*     */     extends SecurityContextHolderAwareRequestWrapper
/*     */   {
/*     */     private final HttpServletResponse response;
/*     */     
/*     */     Servlet3SecurityContextHolderAwareRequestWrapper(HttpServletRequest request, String rolePrefix, HttpServletResponse response) {
/* 191 */       super(request, HttpServlet3RequestFactory.this.trustResolver, rolePrefix);
/* 192 */       this.response = response;
/*     */     }
/*     */ 
/*     */     
/*     */     public AsyncContext getAsyncContext() {
/* 197 */       AsyncContext asyncContext = super.getAsyncContext();
/* 198 */       if (asyncContext == null) {
/* 199 */         return null;
/*     */       }
/* 201 */       return new HttpServlet3RequestFactory.SecurityContextAsyncContext(asyncContext);
/*     */     }
/*     */ 
/*     */     
/*     */     public AsyncContext startAsync() {
/* 206 */       AsyncContext startAsync = super.startAsync();
/* 207 */       return new HttpServlet3RequestFactory.SecurityContextAsyncContext(startAsync);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
/* 213 */       AsyncContext startAsync = super.startAsync(servletRequest, servletResponse);
/* 214 */       return new HttpServlet3RequestFactory.SecurityContextAsyncContext(startAsync);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean authenticate(HttpServletResponse response) throws IOException, ServletException {
/* 219 */       AuthenticationEntryPoint entryPoint = HttpServlet3RequestFactory.this.authenticationEntryPoint;
/* 220 */       if (entryPoint == null) {
/* 221 */         HttpServlet3RequestFactory.this.logger.debug("authenticationEntryPoint is null, so allowing original HttpServletRequest to handle authenticate");
/*     */         
/* 223 */         return super.authenticate(response);
/*     */       } 
/* 225 */       if (isAuthenticated()) {
/* 226 */         return true;
/*     */       }
/* 228 */       entryPoint.commence((HttpServletRequest)this, response, (AuthenticationException)new AuthenticationCredentialsNotFoundException("User is not Authenticated"));
/*     */       
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void login(String username, String password) throws ServletException {
/* 235 */       if (isAuthenticated()) {
/* 236 */         throw new ServletException("Cannot perform login for '" + username + "' already authenticated as '" + 
/* 237 */             getRemoteUser() + "'");
/*     */       }
/* 239 */       AuthenticationManager authManager = HttpServlet3RequestFactory.this.authenticationManager;
/* 240 */       if (authManager == null) {
/* 241 */         HttpServlet3RequestFactory.this.logger
/* 242 */           .debug("authenticationManager is null, so allowing original HttpServletRequest to handle login");
/* 243 */         super.login(username, password);
/*     */         return;
/*     */       } 
/* 246 */       Authentication authentication = getAuthentication(authManager, username, password);
/*     */       
/* 248 */       SecurityContext context = HttpServlet3RequestFactory.this.securityContextHolderStrategy.createEmptyContext();
/* 249 */       context.setAuthentication(authentication);
/* 250 */       HttpServlet3RequestFactory.this.securityContextHolderStrategy.setContext(context);
/* 251 */       HttpServlet3RequestFactory.this.securityContextRepository.saveContext(context, (HttpServletRequest)this, this.response);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Authentication getAuthentication(AuthenticationManager authManager, String username, String password) throws ServletException {
/*     */       try {
/* 258 */         UsernamePasswordAuthenticationToken authentication = UsernamePasswordAuthenticationToken.unauthenticated(username, password);
/* 259 */         Object details = HttpServlet3RequestFactory.this.authenticationDetailsSource.buildDetails(this);
/* 260 */         authentication.setDetails(details);
/* 261 */         return authManager.authenticate((Authentication)authentication);
/*     */       }
/* 263 */       catch (AuthenticationException ex) {
/* 264 */         HttpServlet3RequestFactory.this.securityContextHolderStrategy.clearContext();
/* 265 */         throw new ServletException(ex.getMessage(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void logout() throws ServletException {
/* 271 */       List<LogoutHandler> handlers = HttpServlet3RequestFactory.this.logoutHandlers;
/* 272 */       if (CollectionUtils.isEmpty(handlers)) {
/* 273 */         HttpServlet3RequestFactory.this.logger
/* 274 */           .debug("logoutHandlers is null, so allowing original HttpServletRequest to handle logout");
/* 275 */         super.logout();
/*     */         
/*     */         return;
/*     */       } 
/* 279 */       Authentication authentication = HttpServlet3RequestFactory.this.securityContextHolderStrategy.getContext().getAuthentication();
/* 280 */       for (LogoutHandler handler : handlers) {
/* 281 */         handler.logout((HttpServletRequest)this, this.response, authentication);
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isAuthenticated() {
/* 286 */       return (getUserPrincipal() != null);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SecurityContextAsyncContext
/*     */     implements AsyncContext
/*     */   {
/*     */     private final AsyncContext asyncContext;
/*     */     
/*     */     SecurityContextAsyncContext(AsyncContext asyncContext) {
/* 296 */       this.asyncContext = asyncContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServletRequest getRequest() {
/* 301 */       return this.asyncContext.getRequest();
/*     */     }
/*     */ 
/*     */     
/*     */     public ServletResponse getResponse() {
/* 306 */       return this.asyncContext.getResponse();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasOriginalRequestAndResponse() {
/* 311 */       return this.asyncContext.hasOriginalRequestAndResponse();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispatch() {
/* 316 */       this.asyncContext.dispatch();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispatch(String path) {
/* 321 */       this.asyncContext.dispatch(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispatch(ServletContext context, String path) {
/* 326 */       this.asyncContext.dispatch(context, path);
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 331 */       this.asyncContext.complete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void start(Runnable run) {
/* 336 */       this.asyncContext.start((Runnable)new DelegatingSecurityContextRunnable(run));
/*     */     }
/*     */ 
/*     */     
/*     */     public void addListener(AsyncListener listener) {
/* 341 */       this.asyncContext.addListener(listener);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addListener(AsyncListener listener, ServletRequest request, ServletResponse response) {
/* 346 */       this.asyncContext.addListener(listener, request, response);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T extends AsyncListener> T createListener(Class<T> clazz) throws ServletException {
/* 351 */       return (T)this.asyncContext.createListener(clazz);
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTimeout() {
/* 356 */       return this.asyncContext.getTimeout();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setTimeout(long timeout) {
/* 361 */       this.asyncContext.setTimeout(timeout);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servletapi\HttpServlet3RequestFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */