/*     */ package org.springframework.security.web.servletapi;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.AsyncListener;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import org.springframework.security.concurrent.DelegatingSecurityContextRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SecurityContextAsyncContext
/*     */   implements AsyncContext
/*     */ {
/*     */   private final AsyncContext asyncContext;
/*     */   
/*     */   SecurityContextAsyncContext(AsyncContext asyncContext) {
/* 296 */     this.asyncContext = asyncContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServletRequest getRequest() {
/* 301 */     return this.asyncContext.getRequest();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServletResponse getResponse() {
/* 306 */     return this.asyncContext.getResponse();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasOriginalRequestAndResponse() {
/* 311 */     return this.asyncContext.hasOriginalRequestAndResponse();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatch() {
/* 316 */     this.asyncContext.dispatch();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatch(String path) {
/* 321 */     this.asyncContext.dispatch(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatch(ServletContext context, String path) {
/* 326 */     this.asyncContext.dispatch(context, path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void complete() {
/* 331 */     this.asyncContext.complete();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(Runnable run) {
/* 336 */     this.asyncContext.start((Runnable)new DelegatingSecurityContextRunnable(run));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(AsyncListener listener) {
/* 341 */     this.asyncContext.addListener(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(AsyncListener listener, ServletRequest request, ServletResponse response) {
/* 346 */     this.asyncContext.addListener(listener, request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends AsyncListener> T createListener(Class<T> clazz) throws ServletException {
/* 351 */     return (T)this.asyncContext.createListener(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeout() {
/* 356 */     return this.asyncContext.getTimeout();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeout(long timeout) {
/* 361 */     this.asyncContext.setTimeout(timeout);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servletapi\HttpServlet3RequestFactory$SecurityContextAsyncContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */