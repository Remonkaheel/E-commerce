/*     */ package org.springframework.security.web.servletapi;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Servlet3SecurityContextHolderAwareRequestWrapper
/*     */   extends SecurityContextHolderAwareRequestWrapper
/*     */ {
/*     */   private final HttpServletResponse response;
/*     */   
/*     */   Servlet3SecurityContextHolderAwareRequestWrapper(HttpServletRequest request, String rolePrefix, HttpServletResponse response) {
/* 191 */     super(request, paramHttpServlet3RequestFactory.trustResolver, rolePrefix);
/* 192 */     this.response = response;
/*     */   }
/*     */ 
/*     */   
/*     */   public AsyncContext getAsyncContext() {
/* 197 */     AsyncContext asyncContext = super.getAsyncContext();
/* 198 */     if (asyncContext == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     return new HttpServlet3RequestFactory.SecurityContextAsyncContext(asyncContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public AsyncContext startAsync() {
/* 206 */     AsyncContext startAsync = super.startAsync();
/* 207 */     return new HttpServlet3RequestFactory.SecurityContextAsyncContext(startAsync);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
/* 213 */     AsyncContext startAsync = super.startAsync(servletRequest, servletResponse);
/* 214 */     return new HttpServlet3RequestFactory.SecurityContextAsyncContext(startAsync);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean authenticate(HttpServletResponse response) throws IOException, ServletException {
/* 219 */     AuthenticationEntryPoint entryPoint = HttpServlet3RequestFactory.this.authenticationEntryPoint;
/* 220 */     if (entryPoint == null) {
/* 221 */       HttpServlet3RequestFactory.this.logger.debug("authenticationEntryPoint is null, so allowing original HttpServletRequest to handle authenticate");
/*     */       
/* 223 */       return super.authenticate(response);
/*     */     } 
/* 225 */     if (isAuthenticated()) {
/* 226 */       return true;
/*     */     }
/* 228 */     entryPoint.commence((HttpServletRequest)this, response, (AuthenticationException)new AuthenticationCredentialsNotFoundException("User is not Authenticated"));
/*     */     
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void login(String username, String password) throws ServletException {
/* 235 */     if (isAuthenticated()) {
/* 236 */       throw new ServletException("Cannot perform login for '" + username + "' already authenticated as '" + 
/* 237 */           getRemoteUser() + "'");
/*     */     }
/* 239 */     AuthenticationManager authManager = HttpServlet3RequestFactory.this.authenticationManager;
/* 240 */     if (authManager == null) {
/* 241 */       HttpServlet3RequestFactory.this.logger
/* 242 */         .debug("authenticationManager is null, so allowing original HttpServletRequest to handle login");
/* 243 */       super.login(username, password);
/*     */       return;
/*     */     } 
/* 246 */     Authentication authentication = getAuthentication(authManager, username, password);
/*     */     
/* 248 */     SecurityContext context = HttpServlet3RequestFactory.this.securityContextHolderStrategy.createEmptyContext();
/* 249 */     context.setAuthentication(authentication);
/* 250 */     HttpServlet3RequestFactory.this.securityContextHolderStrategy.setContext(context);
/* 251 */     HttpServlet3RequestFactory.this.securityContextRepository.saveContext(context, (HttpServletRequest)this, this.response);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication getAuthentication(AuthenticationManager authManager, String username, String password) throws ServletException {
/*     */     try {
/* 258 */       UsernamePasswordAuthenticationToken authentication = UsernamePasswordAuthenticationToken.unauthenticated(username, password);
/* 259 */       Object details = HttpServlet3RequestFactory.this.authenticationDetailsSource.buildDetails(this);
/* 260 */       authentication.setDetails(details);
/* 261 */       return authManager.authenticate((Authentication)authentication);
/*     */     }
/* 263 */     catch (AuthenticationException ex) {
/* 264 */       HttpServlet3RequestFactory.this.securityContextHolderStrategy.clearContext();
/* 265 */       throw new ServletException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void logout() throws ServletException {
/* 271 */     List<LogoutHandler> handlers = HttpServlet3RequestFactory.this.logoutHandlers;
/* 272 */     if (CollectionUtils.isEmpty(handlers)) {
/* 273 */       HttpServlet3RequestFactory.this.logger
/* 274 */         .debug("logoutHandlers is null, so allowing original HttpServletRequest to handle logout");
/* 275 */       super.logout();
/*     */       
/*     */       return;
/*     */     } 
/* 279 */     Authentication authentication = HttpServlet3RequestFactory.this.securityContextHolderStrategy.getContext().getAuthentication();
/* 280 */     for (LogoutHandler handler : handlers) {
/* 281 */       handler.logout((HttpServletRequest)this, this.response, authentication);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isAuthenticated() {
/* 286 */     return (getUserPrincipal() != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\servletapi\HttpServlet3RequestFactory$Servlet3SecurityContextHolderAwareRequestWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */