/*    */ package org.springframework.security.web.access.channel;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SecureChannelProcessor
/*    */   implements InitializingBean, ChannelProcessor
/*    */ {
/* 49 */   private ChannelEntryPoint entryPoint = new RetryWithHttpsEntryPoint();
/*    */   
/* 51 */   private String secureKeyword = "REQUIRES_SECURE_CHANNEL";
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 55 */     Assert.hasLength(this.secureKeyword, "secureKeyword required");
/* 56 */     Assert.notNull(this.entryPoint, "entryPoint required");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void decide(FilterInvocation invocation, Collection<ConfigAttribute> config) throws IOException, ServletException {
/* 62 */     Assert.isTrue((invocation != null && config != null), "Nulls cannot be provided");
/* 63 */     for (ConfigAttribute attribute : config) {
/* 64 */       if (supports(attribute) && 
/* 65 */         !invocation.getHttpRequest().isSecure()) {
/* 66 */         this.entryPoint.commence(invocation.getRequest(), invocation.getResponse());
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public ChannelEntryPoint getEntryPoint() {
/* 73 */     return this.entryPoint;
/*    */   }
/*    */   
/*    */   public String getSecureKeyword() {
/* 77 */     return this.secureKeyword;
/*    */   }
/*    */   
/*    */   public void setEntryPoint(ChannelEntryPoint entryPoint) {
/* 81 */     this.entryPoint = entryPoint;
/*    */   }
/*    */   
/*    */   public void setSecureKeyword(String secureKeyword) {
/* 85 */     this.secureKeyword = secureKeyword;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 90 */     return (attribute != null && attribute.getAttribute() != null && attribute
/* 91 */       .getAttribute().equals(getSecureKeyword()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\SecureChannelProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */