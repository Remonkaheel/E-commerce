/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.DispatcherType;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(forRemoval = true)
/*    */ public class HandlerMappingIntrospectorRequestTransformer
/*    */   implements AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer
/*    */ {
/*    */   private final HandlerMappingIntrospector introspector;
/*    */   
/*    */   public HandlerMappingIntrospectorRequestTransformer(HandlerMappingIntrospector introspector) {
/* 47 */     Assert.notNull(introspector, "introspector canot be null");
/* 48 */     this.introspector = introspector;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpServletRequest transform(HttpServletRequest request) {
/* 53 */     CacheableRequestWrapper cacheableRequest = new CacheableRequestWrapper(request);
/* 54 */     this.introspector.setCache((HttpServletRequest)cacheableRequest);
/* 55 */     return (HttpServletRequest)cacheableRequest;
/*    */   }
/*    */   
/*    */   static final class CacheableRequestWrapper
/*    */     extends HttpServletRequestWrapper {
/* 60 */     private final Map<String, Object> attributes = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     CacheableRequestWrapper(HttpServletRequest request) {
/* 68 */       super(request);
/*    */     }
/*    */ 
/*    */     
/*    */     public DispatcherType getDispatcherType() {
/* 73 */       return DispatcherType.REQUEST;
/*    */     }
/*    */ 
/*    */     
/*    */     public Enumeration<String> getAttributeNames() {
/* 78 */       return Collections.enumeration(this.attributes.keySet());
/*    */     }
/*    */ 
/*    */     
/*    */     public Object getAttribute(String name) {
/* 83 */       return this.attributes.get(name);
/*    */     }
/*    */ 
/*    */     
/*    */     public void setAttribute(String name, Object o) {
/* 88 */       this.attributes.put(name, o);
/*    */     }
/*    */ 
/*    */     
/*    */     public void removeAttribute(String name) {
/* 93 */       this.attributes.remove(name);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\HandlerMappingIntrospectorRequestTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */