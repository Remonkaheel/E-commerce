/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessDeniedHandlerImpl
/*    */   implements AccessDeniedHandler
/*    */ {
/* 48 */   protected static final Log logger = LogFactory.getLog(AccessDeniedHandlerImpl.class);
/*    */ 
/*    */   
/*    */   private String errorPage;
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
/* 55 */     if (response.isCommitted()) {
/* 56 */       logger.trace("Did not write to response since already committed");
/*    */       return;
/*    */     } 
/* 59 */     if (this.errorPage == null) {
/* 60 */       logger.debug("Responding with 403 status code");
/* 61 */       response.sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
/*    */       
/*    */       return;
/*    */     } 
/* 65 */     request.setAttribute("SPRING_SECURITY_403_EXCEPTION", accessDeniedException);
/*    */     
/* 67 */     response.setStatus(HttpStatus.FORBIDDEN.value());
/*    */     
/* 69 */     if (logger.isDebugEnabled()) {
/* 70 */       logger.debug(LogMessage.format("Forwarding to %s with status code 403", this.errorPage));
/*    */     }
/* 72 */     request.getRequestDispatcher(this.errorPage).forward((ServletRequest)request, (ServletResponse)response);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setErrorPage(String errorPage) {
/* 83 */     Assert.isTrue((errorPage == null || errorPage.startsWith("/")), "errorPage must begin with '/'");
/* 84 */     this.errorPage = errorPage;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\AccessDeniedHandlerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */