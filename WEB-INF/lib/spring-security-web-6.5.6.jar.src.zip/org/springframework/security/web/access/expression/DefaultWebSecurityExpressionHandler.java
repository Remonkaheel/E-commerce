/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import org.springframework.security.access.expression.AbstractSecurityExpressionHandler;
/*    */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*    */ import org.springframework.security.access.expression.SecurityExpressionOperations;
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultWebSecurityExpressionHandler
/*    */   extends AbstractSecurityExpressionHandler<FilterInvocation>
/*    */   implements SecurityExpressionHandler<FilterInvocation>
/*    */ {
/* 36 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*    */   
/* 38 */   private String defaultRolePrefix = "ROLE_";
/*    */ 
/*    */ 
/*    */   
/*    */   protected SecurityExpressionOperations createSecurityExpressionRoot(Authentication authentication, FilterInvocation fi) {
/* 43 */     WebSecurityExpressionRoot root = new WebSecurityExpressionRoot(authentication, fi);
/* 44 */     root.setPermissionEvaluator(getPermissionEvaluator());
/* 45 */     root.setTrustResolver(this.trustResolver);
/* 46 */     root.setRoleHierarchy(getRoleHierarchy());
/* 47 */     root.setDefaultRolePrefix(this.defaultRolePrefix);
/* 48 */     return (SecurityExpressionOperations)root;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 58 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 59 */     this.trustResolver = trustResolver;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultRolePrefix(String defaultRolePrefix) {
/* 78 */     this.defaultRolePrefix = defaultRolePrefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\DefaultWebSecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */