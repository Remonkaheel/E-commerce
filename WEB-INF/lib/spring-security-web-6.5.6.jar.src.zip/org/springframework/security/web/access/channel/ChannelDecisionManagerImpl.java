/*     */ package org.springframework.security.web.access.channel;
/*     */ 
/*     */ import jakarta.servlet.ServletException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ChannelDecisionManagerImpl
/*     */   implements ChannelDecisionManager, InitializingBean
/*     */ {
/*     */   public static final String ANY_CHANNEL = "ANY_CHANNEL";
/*     */   private List<ChannelProcessor> channelProcessors;
/*     */   
/*     */   public void afterPropertiesSet() {
/*  60 */     Assert.notEmpty(this.channelProcessors, "A list of ChannelProcessors is required");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decide(FilterInvocation invocation, Collection<ConfigAttribute> config) throws IOException, ServletException {
/*  66 */     for (ConfigAttribute attribute : config) {
/*  67 */       if ("ANY_CHANNEL".equals(attribute.getAttribute())) {
/*     */         return;
/*     */       }
/*     */     } 
/*  71 */     for (ChannelProcessor processor : this.channelProcessors) {
/*  72 */       processor.decide(invocation, config);
/*  73 */       if (invocation.getResponse().isCommitted()) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected List<ChannelProcessor> getChannelProcessors() {
/*  80 */     return this.channelProcessors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChannelProcessors(List<?> channelProcessors) {
/*  85 */     Assert.notEmpty(channelProcessors, "A list of ChannelProcessors is required");
/*  86 */     this.channelProcessors = new ArrayList<>(channelProcessors.size());
/*  87 */     for (Object currentObject : channelProcessors) {
/*  88 */       Assert.isInstanceOf(ChannelProcessor.class, currentObject, () -> "ChannelProcessor " + currentObject.getClass().getName() + " must implement ChannelProcessor");
/*     */       
/*  90 */       this.channelProcessors.add((ChannelProcessor)currentObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  96 */     if ("ANY_CHANNEL".equals(attribute.getAttribute())) {
/*  97 */       return true;
/*     */     }
/*  99 */     for (ChannelProcessor processor : this.channelProcessors) {
/* 100 */       if (processor.supports(attribute)) {
/* 101 */         return true;
/*     */       }
/*     */     } 
/* 104 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\ChannelDecisionManagerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */