/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingAccessDeniedHandler
/*    */   implements AccessDeniedHandler
/*    */ {
/*    */   private final LinkedHashMap<Class<? extends AccessDeniedException>, AccessDeniedHandler> handlers;
/*    */   private final AccessDeniedHandler defaultHandler;
/*    */   
/*    */   public DelegatingAccessDeniedHandler(LinkedHashMap<Class<? extends AccessDeniedException>, AccessDeniedHandler> handlers, AccessDeniedHandler defaultHandler) {
/* 56 */     Assert.notEmpty(handlers, "handlers cannot be null or empty");
/* 57 */     Assert.notNull(defaultHandler, "defaultHandler cannot be null");
/* 58 */     this.handlers = handlers;
/* 59 */     this.defaultHandler = defaultHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
/* 65 */     for (Map.Entry<Class<? extends AccessDeniedException>, AccessDeniedHandler> entry : this.handlers.entrySet()) {
/* 66 */       Class<? extends AccessDeniedException> handlerClass = entry.getKey();
/* 67 */       if (handlerClass.isAssignableFrom(accessDeniedException.getClass())) {
/* 68 */         AccessDeniedHandler handler = entry.getValue();
/* 69 */         handler.handle(request, response, accessDeniedException);
/*    */         return;
/*    */       } 
/*    */     } 
/* 73 */     this.defaultHandler.handle(request, response, accessDeniedException);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\DelegatingAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */