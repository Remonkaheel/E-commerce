/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class WebExpressionConfigAttribute
/*    */   implements ConfigAttribute, EvaluationContextPostProcessor<FilterInvocation>
/*    */ {
/*    */   private final Expression authorizeExpression;
/*    */   private final EvaluationContextPostProcessor<FilterInvocation> postProcessor;
/*    */   
/*    */   WebExpressionConfigAttribute(Expression authorizeExpression, EvaluationContextPostProcessor<FilterInvocation> postProcessor) {
/* 43 */     this.authorizeExpression = authorizeExpression;
/* 44 */     this.postProcessor = postProcessor;
/*    */   }
/*    */   
/*    */   Expression getAuthorizeExpression() {
/* 48 */     return this.authorizeExpression;
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationContext postProcess(EvaluationContext context, FilterInvocation fi) {
/* 53 */     return (this.postProcessor != null) ? this.postProcessor.postProcess(context, fi) : context;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAttribute() {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return this.authorizeExpression.getExpressionString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\WebExpressionConfigAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */