/*    */ package org.springframework.security.web.access.channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.5")
/*    */ public class RetryWithHttpEntryPoint
/*    */   extends AbstractRetryEntryPoint
/*    */ {
/*    */   public RetryWithHttpEntryPoint() {
/* 37 */     super("http://", 80);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Integer getMappedPort(Integer mapFromPort) {
/* 42 */     return getPortMapper().lookupHttpPort(mapFromPort);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\RetryWithHttpEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */