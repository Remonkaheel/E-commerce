package org.springframework.security.web.access.channel;

import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.web.FilterInvocation;

@Deprecated
public interface ChannelProcessor {
  void decide(FilterInvocation paramFilterInvocation, Collection<ConfigAttribute> paramCollection) throws IOException, ServletException;
  
  boolean supports(ConfigAttribute paramConfigAttribute);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\ChannelProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */