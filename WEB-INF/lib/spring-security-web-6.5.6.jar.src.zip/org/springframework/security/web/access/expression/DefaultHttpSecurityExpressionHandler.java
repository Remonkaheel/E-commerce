/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*    */ import org.springframework.security.access.expression.AbstractSecurityExpressionHandler;
/*    */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*    */ import org.springframework.security.access.expression.SecurityExpressionOperations;
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHttpSecurityExpressionHandler
/*    */   extends AbstractSecurityExpressionHandler<RequestAuthorizationContext>
/*    */   implements SecurityExpressionHandler<RequestAuthorizationContext>
/*    */ {
/* 42 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*    */   
/* 44 */   private String defaultRolePrefix = "ROLE_";
/*    */ 
/*    */ 
/*    */   
/*    */   public EvaluationContext createEvaluationContext(Supplier<Authentication> authentication, RequestAuthorizationContext context) {
/* 49 */     WebSecurityExpressionRoot root = createSecurityExpressionRoot(authentication, context);
/* 50 */     StandardEvaluationContext ctx = new StandardEvaluationContext(root);
/* 51 */     ctx.setBeanResolver(getBeanResolver());
/* 52 */     Objects.requireNonNull(ctx); context.getVariables().forEach(ctx::setVariable);
/* 53 */     return (EvaluationContext)ctx;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected SecurityExpressionOperations createSecurityExpressionRoot(Authentication authentication, RequestAuthorizationContext context) {
/* 59 */     return (SecurityExpressionOperations)createSecurityExpressionRoot(() -> authentication, context);
/*    */   }
/*    */ 
/*    */   
/*    */   private WebSecurityExpressionRoot createSecurityExpressionRoot(Supplier<Authentication> authentication, RequestAuthorizationContext context) {
/* 64 */     WebSecurityExpressionRoot root = new WebSecurityExpressionRoot(authentication, context.getRequest());
/* 65 */     root.setRoleHierarchy(getRoleHierarchy());
/* 66 */     root.setPermissionEvaluator(getPermissionEvaluator());
/* 67 */     root.setTrustResolver(this.trustResolver);
/* 68 */     root.setDefaultRolePrefix(this.defaultRolePrefix);
/* 69 */     return root;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 78 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 79 */     this.trustResolver = trustResolver;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultRolePrefix(String defaultRolePrefix) {
/* 93 */     Assert.notNull(defaultRolePrefix, "defaultRolePrefix cannot be null");
/* 94 */     this.defaultRolePrefix = defaultRolePrefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\DefaultHttpSecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */