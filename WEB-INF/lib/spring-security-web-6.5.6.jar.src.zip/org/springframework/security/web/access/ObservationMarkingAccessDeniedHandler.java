/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObservationMarkingAccessDeniedHandler
/*    */   implements AccessDeniedHandler
/*    */ {
/*    */   private final ObservationRegistry registry;
/*    */   
/*    */   public ObservationMarkingAccessDeniedHandler(ObservationRegistry registry) {
/* 34 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException exception) throws IOException, ServletException {
/* 40 */     Observation observation = this.registry.getCurrentObservation();
/* 41 */     if (observation != null)
/* 42 */       observation.error((Throwable)exception); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\ObservationMarkingAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */