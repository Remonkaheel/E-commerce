/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.access.expression.SecurityExpressionRoot;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ import org.springframework.security.web.util.matcher.IpAddressMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebSecurityExpressionRoot
/*    */   extends SecurityExpressionRoot
/*    */ {
/*    */   public final HttpServletRequest request;
/*    */   
/*    */   public WebSecurityExpressionRoot(Authentication a, FilterInvocation fi) {
/* 41 */     this(() -> a, fi.getRequest());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebSecurityExpressionRoot(Supplier<Authentication> authentication, HttpServletRequest request) {
/* 52 */     super(authentication);
/* 53 */     this.request = request;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasIpAddress(String ipAddress) {
/* 64 */     IpAddressMatcher matcher = new IpAddressMatcher(ipAddress);
/* 65 */     return matcher.matches(this.request);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\WebSecurityExpressionRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */