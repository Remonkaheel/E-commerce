/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DefaultFilterInvocationSecurityMetadataSource
/*     */   implements FilterInvocationSecurityMetadataSource
/*     */ {
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<RequestMatcher, Collection<ConfigAttribute>> requestMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFilterInvocationSecurityMetadataSource(LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap) {
/*  77 */     this.requestMap = requestMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/*  82 */     Set<ConfigAttribute> allAttributes = new HashSet<>();
/*  83 */     Objects.requireNonNull(allAttributes); this.requestMap.values().forEach(allAttributes::addAll);
/*  84 */     return allAttributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAttributes(Object object) {
/*  89 */     HttpServletRequest request = ((FilterInvocation)object).getRequest();
/*  90 */     int count = 0;
/*  91 */     for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : this.requestMap.entrySet()) {
/*  92 */       if (((RequestMatcher)entry.getKey()).matches(request)) {
/*  93 */         return entry.getValue();
/*     */       }
/*     */       
/*  96 */       if (this.logger.isTraceEnabled()) {
/*  97 */         this.logger.trace(LogMessage.format("Did not match request to %s - %s (%d/%d)", entry.getKey(), entry
/*  98 */               .getValue(), Integer.valueOf(++count), Integer.valueOf(this.requestMap.size())));
/*     */       }
/*     */     } 
/*     */     
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 107 */     return FilterInvocation.class.isAssignableFrom(clazz);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\DefaultFilterInvocationSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */