/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestMatcherDelegatingAuthorizationManager
/*     */   implements AuthorizationManager<HttpServletRequest>
/*     */ {
/*  52 */   private static final AuthorizationDecision DENY = new AuthorizationDecision(false);
/*     */   
/*  54 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>> mappings;
/*     */ 
/*     */   
/*     */   private RequestMatcherDelegatingAuthorizationManager(List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>> mappings) {
/*  60 */     Assert.notEmpty(mappings, "mappings cannot be empty");
/*  61 */     this.mappings = mappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, HttpServletRequest request) {
/*  77 */     if (this.logger.isTraceEnabled()) {
/*  78 */       this.logger.trace(LogMessage.format("Authorizing %s", requestLine(request)));
/*     */     }
/*  80 */     for (RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>> mapping : this.mappings) {
/*     */       
/*  82 */       RequestMatcher matcher = mapping.getRequestMatcher();
/*  83 */       RequestMatcher.MatchResult matchResult = matcher.matcher(request);
/*  84 */       if (matchResult.isMatch()) {
/*  85 */         AuthorizationManager<RequestAuthorizationContext> manager = (AuthorizationManager<RequestAuthorizationContext>)mapping.getEntry();
/*  86 */         if (this.logger.isTraceEnabled()) {
/*  87 */           this.logger.trace(
/*  88 */               LogMessage.format("Checking authorization on %s using %s", requestLine(request), manager));
/*     */         }
/*  90 */         return manager.check(authentication, new RequestAuthorizationContext(request, matchResult
/*  91 */               .getVariables()));
/*     */       } 
/*     */     } 
/*  94 */     if (this.logger.isTraceEnabled()) {
/*  95 */       this.logger.trace(LogMessage.of(() -> "Denying request since did not find matching RequestMatcher"));
/*     */     }
/*  97 */     return DENY;
/*     */   }
/*     */   
/*     */   private static String requestLine(HttpServletRequest request) {
/* 101 */     return request.getMethod() + " " + request.getMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 109 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private boolean anyRequestConfigured;
/*     */ 
/*     */     
/* 119 */     private final List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>> mappings = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder add(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 128 */       Assert.state(!this.anyRequestConfigured, "Can't add mappings after anyRequest");
/* 129 */       Assert.notNull(matcher, "matcher cannot be null");
/* 130 */       Assert.notNull(manager, "manager cannot be null");
/* 131 */       this.mappings.add(new RequestMatcherEntry(matcher, manager));
/* 132 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder mappings(Consumer<List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>>> mappingsConsumer) {
/* 145 */       Assert.state(!this.anyRequestConfigured, "Can't configure mappings after anyRequest");
/* 146 */       Assert.notNull(mappingsConsumer, "mappingsConsumer cannot be null");
/* 147 */       mappingsConsumer.accept(this.mappings);
/* 148 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizedUrl anyRequest() {
/* 157 */       Assert.state(!this.anyRequestConfigured, "Can't configure anyRequest after itself");
/* 158 */       this.anyRequestConfigured = true;
/* 159 */       return new AuthorizedUrl(new RequestMatcher[] { AnyRequestMatcher.INSTANCE });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizedUrl requestMatchers(RequestMatcher... matchers) {
/* 169 */       Assert.state(!this.anyRequestConfigured, "Can't configure requestMatchers after anyRequest");
/* 170 */       return new AuthorizedUrl(matchers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager build() {
/* 178 */       return new RequestMatcherDelegatingAuthorizationManager(this.mappings);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final class AuthorizedUrl
/*     */     {
/*     */       private final List<RequestMatcher> matchers;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private AuthorizedUrl(RequestMatcher... matchers) {
/* 193 */         this(List.of(matchers));
/*     */       }
/*     */       
/*     */       private AuthorizedUrl(List<RequestMatcher> matchers) {
/* 197 */         this.matchers = matchers;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder permitAll() {
/* 205 */         return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder denyAll() {
/* 213 */         return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.denyAll());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder authenticated() {
/* 221 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder fullyAuthenticated() {
/* 230 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder rememberMe() {
/* 238 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.rememberMe());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder anonymous() {
/* 246 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.anonymous());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder hasRole(String role) {
/* 256 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasRole(role));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyRole(String... roles) {
/* 267 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyRole(roles));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder hasAuthority(String authority) {
/* 276 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAuthority(authority));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyAuthority(String... authorities) {
/* 286 */         return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyAuthority(authorities));
/*     */       }
/*     */       
/*     */       private RequestMatcherDelegatingAuthorizationManager.Builder access(AuthorizationManager<RequestAuthorizationContext> manager) {
/* 290 */         for (RequestMatcher matcher : this.matchers) {
/* 291 */           RequestMatcherDelegatingAuthorizationManager.Builder.this.mappings.add(new RequestMatcherEntry(matcher, manager));
/*     */         }
/* 293 */         return RequestMatcherDelegatingAuthorizationManager.Builder.this; } } } public final class AuthorizedUrl { private RequestMatcherDelegatingAuthorizationManager.Builder access(AuthorizationManager<RequestAuthorizationContext> manager) { for (RequestMatcher matcher : this.matchers) RequestMatcherDelegatingAuthorizationManager.Builder.this.mappings.add(new RequestMatcherEntry(matcher, manager));  return RequestMatcherDelegatingAuthorizationManager.Builder.this; }
/*     */ 
/*     */     
/*     */     private final List<RequestMatcher> matchers;
/*     */     
/*     */     private AuthorizedUrl(RequestMatcher... matchers) {
/*     */       this(List.of(matchers));
/*     */     }
/*     */     
/*     */     private AuthorizedUrl(List<RequestMatcher> matchers) {
/*     */       this.matchers = matchers;
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder permitAll() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder denyAll() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.denyAll());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder authenticated() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder fullyAuthenticated() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder rememberMe() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.rememberMe());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder anonymous() {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.anonymous());
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasRole(String role) {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasRole(role));
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyRole(String... roles) {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyRole(roles));
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAuthority(String authority) {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAuthority(authority));
/*     */     }
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyAuthority(String... authorities) {
/*     */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyAuthority(authorities));
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\RequestMatcherDelegatingAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */