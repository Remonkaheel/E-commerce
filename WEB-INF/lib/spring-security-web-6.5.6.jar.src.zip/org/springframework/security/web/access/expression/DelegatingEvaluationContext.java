/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.expression.BeanResolver;
/*    */ import org.springframework.expression.ConstructorResolver;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.MethodResolver;
/*    */ import org.springframework.expression.OperatorOverloader;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypeComparator;
/*    */ import org.springframework.expression.TypeConverter;
/*    */ import org.springframework.expression.TypeLocator;
/*    */ import org.springframework.expression.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DelegatingEvaluationContext
/*    */   implements EvaluationContext
/*    */ {
/*    */   private final EvaluationContext delegate;
/*    */   
/*    */   DelegatingEvaluationContext(EvaluationContext delegate) {
/* 43 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypedValue getRootObject() {
/* 48 */     return this.delegate.getRootObject();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ConstructorResolver> getConstructorResolvers() {
/* 53 */     return this.delegate.getConstructorResolvers();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<MethodResolver> getMethodResolvers() {
/* 58 */     return this.delegate.getMethodResolvers();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<PropertyAccessor> getPropertyAccessors() {
/* 63 */     return this.delegate.getPropertyAccessors();
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeLocator getTypeLocator() {
/* 68 */     return this.delegate.getTypeLocator();
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeConverter getTypeConverter() {
/* 73 */     return this.delegate.getTypeConverter();
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeComparator getTypeComparator() {
/* 78 */     return this.delegate.getTypeComparator();
/*    */   }
/*    */ 
/*    */   
/*    */   public OperatorOverloader getOperatorOverloader() {
/* 83 */     return this.delegate.getOperatorOverloader();
/*    */   }
/*    */ 
/*    */   
/*    */   public BeanResolver getBeanResolver() {
/* 88 */     return this.delegate.getBeanResolver();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVariable(String name, Object value) {
/* 93 */     this.delegate.setVariable(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object lookupVariable(String name) {
/* 98 */     return this.delegate.lookupVariable(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\DelegatingEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */