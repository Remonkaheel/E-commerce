package org.springframework.security.web.access.expression;

import org.springframework.expression.EvaluationContext;

interface EvaluationContextPostProcessor<I> {
  EvaluationContext postProcess(EvaluationContext paramEvaluationContext, I paramI);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\EvaluationContextPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */