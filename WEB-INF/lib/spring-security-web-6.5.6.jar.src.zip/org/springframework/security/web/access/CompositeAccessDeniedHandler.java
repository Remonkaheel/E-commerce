/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompositeAccessDeniedHandler
/*    */   implements AccessDeniedHandler
/*    */ {
/*    */   private Collection<AccessDeniedHandler> handlers;
/*    */   
/*    */   public CompositeAccessDeniedHandler(AccessDeniedHandler... handlers) {
/* 35 */     this(Arrays.asList(handlers));
/*    */   }
/*    */   
/*    */   public CompositeAccessDeniedHandler(Collection<AccessDeniedHandler> handlers) {
/* 39 */     this.handlers = new ArrayList<>(handlers);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
/* 45 */     for (AccessDeniedHandler handler : this.handlers)
/* 46 */       handler.handle(request, response, accessDeniedException); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\CompositeAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */