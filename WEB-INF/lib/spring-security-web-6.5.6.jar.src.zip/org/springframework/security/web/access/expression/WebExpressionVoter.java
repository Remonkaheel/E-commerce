/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class WebExpressionVoter
/*    */   implements AccessDecisionVoter<FilterInvocation>
/*    */ {
/* 43 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 45 */   private SecurityExpressionHandler<FilterInvocation> expressionHandler = new DefaultWebSecurityExpressionHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   public int vote(Authentication authentication, FilterInvocation filterInvocation, Collection<ConfigAttribute> attributes) {
/* 50 */     Assert.notNull(authentication, "authentication must not be null");
/* 51 */     Assert.notNull(filterInvocation, "filterInvocation must not be null");
/* 52 */     Assert.notNull(attributes, "attributes must not be null");
/* 53 */     WebExpressionConfigAttribute webExpressionConfigAttribute = findConfigAttribute(attributes);
/* 54 */     if (webExpressionConfigAttribute == null) {
/* 55 */       this.logger
/* 56 */         .trace("Abstained since did not find a config attribute of instance WebExpressionConfigAttribute");
/* 57 */       return 0;
/*    */     } 
/* 59 */     EvaluationContext ctx = webExpressionConfigAttribute.postProcess(this.expressionHandler
/* 60 */         .createEvaluationContext(authentication, filterInvocation), filterInvocation);
/* 61 */     boolean granted = ExpressionUtils.evaluateAsBoolean(webExpressionConfigAttribute.getAuthorizeExpression(), ctx);
/* 62 */     if (granted) {
/* 63 */       return 1;
/*    */     }
/* 65 */     this.logger.trace("Voted to deny authorization");
/* 66 */     return -1;
/*    */   }
/*    */   
/*    */   private WebExpressionConfigAttribute findConfigAttribute(Collection<ConfigAttribute> attributes) {
/* 70 */     for (ConfigAttribute attribute : attributes) {
/* 71 */       if (attribute instanceof WebExpressionConfigAttribute) {
/* 72 */         return (WebExpressionConfigAttribute)attribute;
/*    */       }
/*    */     } 
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 80 */     return attribute instanceof WebExpressionConfigAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 85 */     return FilterInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */   
/*    */   public void setExpressionHandler(SecurityExpressionHandler<FilterInvocation> expressionHandler) {
/* 89 */     this.expressionHandler = expressionHandler;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\WebExpressionVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */