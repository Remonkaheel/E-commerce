/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AttributesSupportingHttpServletRequest
/*    */   extends HttpServletRequestWrapper
/*    */ {
/* 47 */   private final Map<String, Object> attributes = new HashMap<>();
/*    */   
/*    */   AttributesSupportingHttpServletRequest(HttpServletRequest request) {
/* 50 */     super(request);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getAttribute(String name) {
/* 55 */     return this.attributes.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAttribute(String name, Object value) {
/* 60 */     this.attributes.put(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeAttribute(String name) {
/* 65 */     this.attributes.remove(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\PathPatternRequestTransformer$AttributesSupportingHttpServletRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */