/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Builder
/*     */ {
/*     */   private boolean anyRequestConfigured;
/* 119 */   private final List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>> mappings = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder add(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 128 */     Assert.state(!this.anyRequestConfigured, "Can't add mappings after anyRequest");
/* 129 */     Assert.notNull(matcher, "matcher cannot be null");
/* 130 */     Assert.notNull(manager, "manager cannot be null");
/* 131 */     this.mappings.add(new RequestMatcherEntry(matcher, manager));
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mappings(Consumer<List<RequestMatcherEntry<AuthorizationManager<RequestAuthorizationContext>>>> mappingsConsumer) {
/* 145 */     Assert.state(!this.anyRequestConfigured, "Can't configure mappings after anyRequest");
/* 146 */     Assert.notNull(mappingsConsumer, "mappingsConsumer cannot be null");
/* 147 */     mappingsConsumer.accept(this.mappings);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizedUrl anyRequest() {
/* 157 */     Assert.state(!this.anyRequestConfigured, "Can't configure anyRequest after itself");
/* 158 */     this.anyRequestConfigured = true;
/* 159 */     return new AuthorizedUrl(new RequestMatcher[] { AnyRequestMatcher.INSTANCE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizedUrl requestMatchers(RequestMatcher... matchers) {
/* 169 */     Assert.state(!this.anyRequestConfigured, "Can't configure requestMatchers after anyRequest");
/* 170 */     return new AuthorizedUrl(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager build() {
/* 178 */     return new RequestMatcherDelegatingAuthorizationManager(this.mappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class AuthorizedUrl
/*     */   {
/*     */     private final List<RequestMatcher> matchers;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AuthorizedUrl(RequestMatcher... matchers) {
/* 193 */       this(List.of(matchers));
/*     */     }
/*     */     
/*     */     private AuthorizedUrl(List<RequestMatcher> matchers) {
/* 197 */       this.matchers = matchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder permitAll() {
/* 205 */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder denyAll() {
/* 213 */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.denyAll());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder authenticated() {
/* 221 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder fullyAuthenticated() {
/* 230 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder rememberMe() {
/* 238 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.rememberMe());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder anonymous() {
/* 246 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.anonymous());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasRole(String role) {
/* 256 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasRole(role));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyRole(String... roles) {
/* 267 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyRole(roles));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAuthority(String authority) {
/* 276 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAuthority(authority));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyAuthority(String... authorities) {
/* 286 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyAuthority(authorities));
/*     */     }
/*     */     
/*     */     private RequestMatcherDelegatingAuthorizationManager.Builder access(AuthorizationManager<RequestAuthorizationContext> manager) {
/* 290 */       for (RequestMatcher matcher : this.matchers) {
/* 291 */         RequestMatcherDelegatingAuthorizationManager.Builder.this.mappings.add(new RequestMatcherEntry(matcher, manager));
/*     */       }
/* 293 */       return RequestMatcherDelegatingAuthorizationManager.Builder.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\RequestMatcherDelegatingAuthorizationManager$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */