/*     */ package org.springframework.security.web.access;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.authentication.InsufficientAuthenticationException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.util.ThrowableAnalyzer;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionTranslationFilter
/*     */   extends GenericFilterBean
/*     */   implements MessageSourceAware
/*     */ {
/*  86 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  88 */   private AccessDeniedHandler accessDeniedHandler = new AccessDeniedHandlerImpl();
/*     */   
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/*  92 */   private AuthenticationTrustResolver authenticationTrustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*  94 */   private ThrowableAnalyzer throwableAnalyzer = new DefaultThrowableAnalyzer();
/*     */   
/*     */   private final RequestCache requestCache;
/*     */   
/*  98 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   public ExceptionTranslationFilter(AuthenticationEntryPoint authenticationEntryPoint) {
/* 101 */     this(authenticationEntryPoint, (RequestCache)new HttpSessionRequestCache());
/*     */   }
/*     */   
/*     */   public ExceptionTranslationFilter(AuthenticationEntryPoint authenticationEntryPoint, RequestCache requestCache) {
/* 105 */     Assert.notNull(authenticationEntryPoint, "authenticationEntryPoint cannot be null");
/* 106 */     Assert.notNull(requestCache, "requestCache cannot be null");
/* 107 */     this.authenticationEntryPoint = authenticationEntryPoint;
/* 108 */     this.requestCache = requestCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 113 */     Assert.notNull(this.authenticationEntryPoint, "authenticationEntryPoint must be specified");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 119 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*     */     try {
/* 125 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */     }
/* 127 */     catch (IOException ex) {
/* 128 */       throw ex;
/*     */     }
/* 130 */     catch (Exception ex) {
/*     */       AccessDeniedException accessDeniedException;
/* 132 */       Throwable[] causeChain = this.throwableAnalyzer.determineCauseChain(ex);
/*     */       
/* 134 */       AuthenticationException authenticationException = (AuthenticationException)this.throwableAnalyzer.getFirstThrowableOfType(AuthenticationException.class, causeChain);
/* 135 */       if (authenticationException == null)
/*     */       {
/* 137 */         accessDeniedException = (AccessDeniedException)this.throwableAnalyzer.getFirstThrowableOfType(AccessDeniedException.class, causeChain);
/*     */       }
/* 139 */       if (accessDeniedException == null) {
/* 140 */         rethrow(ex);
/*     */       }
/* 142 */       if (response.isCommitted()) {
/* 143 */         throw new ServletException("Unable to handle the Spring Security Exception because the response is already committed.", ex);
/*     */       }
/*     */       
/* 146 */       handleSpringSecurityException(request, response, chain, (RuntimeException)accessDeniedException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void rethrow(Exception ex) throws ServletException {
/* 152 */     if (ex instanceof ServletException) {
/* 153 */       throw (ServletException)ex;
/*     */     }
/* 155 */     if (ex instanceof RuntimeException) {
/* 156 */       throw (RuntimeException)ex;
/*     */     }
/*     */ 
/*     */     
/* 160 */     throw new RuntimeException(ex);
/*     */   }
/*     */   
/*     */   public AuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 164 */     return this.authenticationEntryPoint;
/*     */   }
/*     */   
/*     */   protected AuthenticationTrustResolver getAuthenticationTrustResolver() {
/* 168 */     return this.authenticationTrustResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleSpringSecurityException(HttpServletRequest request, HttpServletResponse response, FilterChain chain, RuntimeException exception) throws IOException, ServletException {
/* 173 */     if (exception instanceof AuthenticationException) {
/* 174 */       handleAuthenticationException(request, response, chain, (AuthenticationException)exception);
/*     */     }
/* 176 */     else if (exception instanceof AccessDeniedException) {
/* 177 */       handleAccessDeniedException(request, response, chain, (AccessDeniedException)exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleAuthenticationException(HttpServletRequest request, HttpServletResponse response, FilterChain chain, AuthenticationException exception) throws ServletException, IOException {
/* 183 */     this.logger.trace("Sending to authentication entry point since authentication failed", (Throwable)exception);
/* 184 */     sendStartAuthentication(request, response, chain, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleAccessDeniedException(HttpServletRequest request, HttpServletResponse response, FilterChain chain, AccessDeniedException exception) throws ServletException, IOException {
/* 189 */     Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 190 */     boolean isAnonymous = this.authenticationTrustResolver.isAnonymous(authentication);
/* 191 */     if (isAnonymous || this.authenticationTrustResolver.isRememberMe(authentication)) {
/* 192 */       if (this.logger.isTraceEnabled()) {
/* 193 */         this.logger.trace(LogMessage.format("Sending %s to authentication entry point since access is denied", authentication), (Throwable)exception);
/*     */       }
/*     */ 
/*     */       
/* 197 */       InsufficientAuthenticationException insufficientAuthenticationException = new InsufficientAuthenticationException(this.messages.getMessage("ExceptionTranslationFilter.insufficientAuthentication", "Full authentication is required to access this resource"));
/*     */       
/* 199 */       insufficientAuthenticationException.setAuthenticationRequest(authentication);
/* 200 */       sendStartAuthentication(request, response, chain, (AuthenticationException)insufficientAuthenticationException);
/*     */     } else {
/*     */       
/* 203 */       if (this.logger.isTraceEnabled()) {
/* 204 */         this.logger.trace(
/* 205 */             LogMessage.format("Sending %s to access denied handler since access is denied", authentication), (Throwable)exception);
/*     */       }
/*     */       
/* 208 */       this.accessDeniedHandler.handle(request, response, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendStartAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, AuthenticationException reason) throws ServletException, IOException {
/* 216 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 217 */     this.securityContextHolderStrategy.setContext(context);
/* 218 */     this.requestCache.saveRequest(request, response);
/* 219 */     this.authenticationEntryPoint.commence(request, response, reason);
/*     */   }
/*     */   
/*     */   public void setAccessDeniedHandler(AccessDeniedHandler accessDeniedHandler) {
/* 223 */     Assert.notNull(accessDeniedHandler, "AccessDeniedHandler required");
/* 224 */     this.accessDeniedHandler = accessDeniedHandler;
/*     */   }
/*     */   
/*     */   public void setAuthenticationTrustResolver(AuthenticationTrustResolver authenticationTrustResolver) {
/* 228 */     Assert.notNull(authenticationTrustResolver, "authenticationTrustResolver must not be null");
/* 229 */     this.authenticationTrustResolver = authenticationTrustResolver;
/*     */   }
/*     */   
/*     */   public void setThrowableAnalyzer(ThrowableAnalyzer throwableAnalyzer) {
/* 233 */     Assert.notNull(throwableAnalyzer, "throwableAnalyzer must not be null");
/* 234 */     this.throwableAnalyzer = throwableAnalyzer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 242 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 243 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 253 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 254 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DefaultThrowableAnalyzer
/*     */     extends ThrowableAnalyzer
/*     */   {
/*     */     protected void initExtractorMap() {
/* 268 */       super.initExtractorMap();
/* 269 */       registerExtractor(ServletException.class, throwable -> {
/*     */             ThrowableAnalyzer.verifyThrowableHierarchy(throwable, ServletException.class);
/*     */             return ((ServletException)throwable).getRootCause();
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\ExceptionTranslationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */