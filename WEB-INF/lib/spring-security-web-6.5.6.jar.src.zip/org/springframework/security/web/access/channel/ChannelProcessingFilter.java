/*     */ package org.springframework.security.web.access.channel;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ChannelProcessingFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   private ChannelDecisionManager channelDecisionManager;
/*     */   private FilterInvocationSecurityMetadataSource securityMetadataSource;
/*     */   
/*     */   public void afterPropertiesSet() {
/*  97 */     Assert.notNull(this.securityMetadataSource, "securityMetadataSource must be specified");
/*  98 */     Assert.notNull(this.channelDecisionManager, "channelDecisionManager must be specified");
/*  99 */     Collection<ConfigAttribute> attributes = this.securityMetadataSource.getAllConfigAttributes();
/* 100 */     if (attributes == null) {
/* 101 */       this.logger.warn("Could not validate configuration attributes as the FilterInvocationSecurityMetadataSource did not return any attributes");
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     Set<ConfigAttribute> unsupportedAttributes = getUnsupportedAttributes(attributes);
/* 106 */     Assert.isTrue(unsupportedAttributes.isEmpty(), () -> "Unsupported configuration attributes: " + String.valueOf(unsupportedAttributes));
/*     */     
/* 108 */     this.logger.info("Validated configuration attributes");
/*     */   }
/*     */   
/*     */   private Set<ConfigAttribute> getUnsupportedAttributes(Collection<ConfigAttribute> attrDefs) {
/* 112 */     Set<ConfigAttribute> unsupportedAttributes = new HashSet<>();
/* 113 */     for (ConfigAttribute attr : attrDefs) {
/* 114 */       if (!this.channelDecisionManager.supports(attr)) {
/* 115 */         unsupportedAttributes.add(attr);
/*     */       }
/*     */     } 
/* 118 */     return unsupportedAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/* 124 */     HttpServletRequest request = (HttpServletRequest)req;
/* 125 */     HttpServletResponse response = (HttpServletResponse)res;
/* 126 */     FilterInvocation filterInvocation = new FilterInvocation((ServletRequest)request, (ServletResponse)response, chain);
/* 127 */     Collection<ConfigAttribute> attributes = this.securityMetadataSource.getAttributes(filterInvocation);
/* 128 */     if (attributes != null) {
/* 129 */       this.logger.debug(LogMessage.format("Request: %s; ConfigAttributes: %s", filterInvocation, attributes));
/* 130 */       this.channelDecisionManager.decide(filterInvocation, attributes);
/* 131 */       if (filterInvocation.getResponse().isCommitted()) {
/*     */         return;
/*     */       }
/*     */     } 
/* 135 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */   
/*     */   protected ChannelDecisionManager getChannelDecisionManager() {
/* 139 */     return this.channelDecisionManager;
/*     */   }
/*     */   
/*     */   protected FilterInvocationSecurityMetadataSource getSecurityMetadataSource() {
/* 143 */     return this.securityMetadataSource;
/*     */   }
/*     */   
/*     */   public void setChannelDecisionManager(ChannelDecisionManager channelDecisionManager) {
/* 147 */     this.channelDecisionManager = channelDecisionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSecurityMetadataSource(FilterInvocationSecurityMetadataSource filterInvocationSecurityMetadataSource) {
/* 152 */     this.securityMetadataSource = filterInvocationSecurityMetadataSource;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\ChannelProcessingFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */