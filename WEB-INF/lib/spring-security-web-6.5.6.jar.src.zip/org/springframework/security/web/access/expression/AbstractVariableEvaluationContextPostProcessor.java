/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Map;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractVariableEvaluationContextPostProcessor
/*    */   implements EvaluationContextPostProcessor<FilterInvocation>
/*    */ {
/*    */   abstract Map<String, String> extractVariables(HttpServletRequest paramHttpServletRequest);
/*    */   
/*    */   public final EvaluationContext postProcess(EvaluationContext context, FilterInvocation invocation) {
/* 44 */     return new VariableEvaluationContext(context, invocation.getHttpRequest());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   class VariableEvaluationContext
/*    */     extends DelegatingEvaluationContext
/*    */   {
/*    */     private final HttpServletRequest request;
/*    */ 
/*    */     
/*    */     private Map<String, String> variables;
/*    */ 
/*    */     
/*    */     VariableEvaluationContext(EvaluationContext delegate, HttpServletRequest request) {
/* 59 */       super(delegate);
/* 60 */       this.request = request;
/*    */     }
/*    */ 
/*    */     
/*    */     public Object lookupVariable(String name) {
/* 65 */       Object result = super.lookupVariable(name);
/* 66 */       if (result != null) {
/* 67 */         return result;
/*    */       }
/* 69 */       if (this.variables == null) {
/* 70 */         this.variables = AbstractVariableEvaluationContextPostProcessor.this.extractVariables(this.request);
/*    */       }
/* 72 */       return this.variables.get(name);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\AbstractVariableEvaluationContextPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */