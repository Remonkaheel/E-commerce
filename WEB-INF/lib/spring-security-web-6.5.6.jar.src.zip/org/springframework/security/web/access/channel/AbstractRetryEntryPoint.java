/*     */ package org.springframework.security.web.access.channel;
/*     */ 
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.PortMapperImpl;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.PortResolverImpl;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractRetryEntryPoint
/*     */   implements ChannelEntryPoint
/*     */ {
/*  44 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  46 */   private PortMapper portMapper = (PortMapper)new PortMapperImpl();
/*     */   
/*  48 */   private PortResolver portResolver = (PortResolver)new PortResolverImpl();
/*     */ 
/*     */ 
/*     */   
/*     */   private final String scheme;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int standardPort;
/*     */ 
/*     */ 
/*     */   
/*  60 */   private RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */   
/*     */   public AbstractRetryEntryPoint(String scheme, int standardPort) {
/*  63 */     this.scheme = scheme;
/*  64 */     this.standardPort = standardPort;
/*     */   }
/*     */ 
/*     */   
/*     */   public void commence(HttpServletRequest request, HttpServletResponse response) throws IOException {
/*  69 */     String queryString = request.getQueryString();
/*  70 */     String redirectUrl = request.getRequestURI() + request.getRequestURI();
/*  71 */     Integer currentPort = Integer.valueOf(this.portResolver.getServerPort((ServletRequest)request));
/*  72 */     Integer redirectPort = getMappedPort(currentPort);
/*  73 */     if (redirectPort != null) {
/*  74 */       boolean includePort = (redirectPort.intValue() != this.standardPort);
/*  75 */       String port = includePort ? (":" + redirectPort) : "";
/*  76 */       redirectUrl = this.scheme + this.scheme + request.getServerName() + port;
/*     */     } 
/*  78 */     this.logger.debug(LogMessage.format("Redirecting to: %s", redirectUrl));
/*  79 */     this.redirectStrategy.sendRedirect(request, response, redirectUrl);
/*     */   }
/*     */   
/*     */   protected abstract Integer getMappedPort(Integer paramInteger);
/*     */   
/*     */   protected final PortMapper getPortMapper() {
/*  85 */     return this.portMapper;
/*     */   }
/*     */   
/*     */   public void setPortMapper(PortMapper portMapper) {
/*  89 */     Assert.notNull(portMapper, "portMapper cannot be null");
/*  90 */     this.portMapper = portMapper;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public void setPortResolver(PortResolver portResolver) {
/*  95 */     Assert.notNull(portResolver, "portResolver cannot be null");
/*  96 */     this.portResolver = portResolver;
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   protected final PortResolver getPortResolver() {
/* 101 */     return this.portResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
/* 110 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 111 */     this.redirectStrategy = redirectStrategy;
/*     */   }
/*     */   
/*     */   protected final RedirectStrategy getRedirectStrategy() {
/* 115 */     return this.redirectStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\AbstractRetryEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */