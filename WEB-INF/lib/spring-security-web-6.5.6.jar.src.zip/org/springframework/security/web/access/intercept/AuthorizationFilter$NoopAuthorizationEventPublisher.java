package org.springframework.security.web.access.intercept;

import java.util.function.Supplier;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationEventPublisher;
import org.springframework.security.authorization.AuthorizationResult;
import org.springframework.security.core.Authentication;

class NoopAuthorizationEventPublisher implements AuthorizationEventPublisher {
  public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationDecision decision) {}
  
  public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\AuthorizationFilter$NoopAuthorizationEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */