package org.springframework.security.web.access;

import org.springframework.security.core.Authentication;

public interface WebInvocationPrivilegeEvaluator {
  boolean isAllowed(String paramString, Authentication paramAuthentication);
  
  boolean isAllowed(String paramString1, String paramString2, String paramString3, Authentication paramAuthentication);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\WebInvocationPrivilegeEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */