/*    */ package org.springframework.security.web.access.intercept;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestAuthorizationContext
/*    */ {
/*    */   private final HttpServletRequest request;
/*    */   private final Map<String, String> variables;
/*    */   
/*    */   public RequestAuthorizationContext(HttpServletRequest request) {
/* 41 */     this(request, Collections.emptyMap());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequestAuthorizationContext(HttpServletRequest request, Map<String, String> variables) {
/* 51 */     this.request = request;
/* 52 */     this.variables = variables;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpServletRequest getRequest() {
/* 60 */     return this.request;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, String> getVariables() {
/* 70 */     return this.variables;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\RequestAuthorizationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */