/*    */ package org.springframework.security.web.access.channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.5")
/*    */ public class RetryWithHttpsEntryPoint
/*    */   extends AbstractRetryEntryPoint
/*    */ {
/*    */   public RetryWithHttpsEntryPoint() {
/* 38 */     super("https://", 443);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Integer getMappedPort(Integer mapFromPort) {
/* 43 */     return getPortMapper().lookupHttpsPort(mapFromPort);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\channel\RetryWithHttpsEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */