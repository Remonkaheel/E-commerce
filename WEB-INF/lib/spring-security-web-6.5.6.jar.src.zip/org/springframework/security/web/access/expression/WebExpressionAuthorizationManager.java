/*    */ package org.springframework.security.web.access.expression;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.ExpressionAuthorizationDecision;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebExpressionAuthorizationManager
/*    */   implements AuthorizationManager<RequestAuthorizationContext>
/*    */ {
/* 41 */   private SecurityExpressionHandler<RequestAuthorizationContext> expressionHandler = new DefaultHttpSecurityExpressionHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   private Expression expression;
/*    */ 
/*    */ 
/*    */   
/*    */   public WebExpressionAuthorizationManager(String expressionString) {
/* 50 */     Assert.hasText(expressionString, "expressionString cannot be empty");
/* 51 */     this.expression = this.expressionHandler.getExpressionParser().parseExpression(expressionString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExpressionHandler(SecurityExpressionHandler<RequestAuthorizationContext> expressionHandler) {
/* 60 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/* 61 */     this.expressionHandler = expressionHandler;
/* 62 */     this
/* 63 */       .expression = expressionHandler.getExpressionParser().parseExpression(this.expression.getExpressionString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorizationDecision check(Supplier<Authentication> authentication, RequestAuthorizationContext context) {
/* 75 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, context);
/* 76 */     boolean granted = ExpressionUtils.evaluateAsBoolean(this.expression, ctx);
/* 77 */     return (AuthorizationDecision)new ExpressionAuthorizationDecision(granted, this.expression);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "WebExpressionAuthorizationManager[expression='" + String.valueOf(this.expression) + "']";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\WebExpressionAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */