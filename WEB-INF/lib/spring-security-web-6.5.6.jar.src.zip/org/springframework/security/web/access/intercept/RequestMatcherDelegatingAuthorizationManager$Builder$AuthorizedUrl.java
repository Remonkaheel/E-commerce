/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizedUrl
/*     */ {
/*     */   private final List<RequestMatcher> matchers;
/*     */   
/*     */   private AuthorizedUrl(RequestMatcherDelegatingAuthorizationManager.Builder this$0, RequestMatcher... matchers) {
/* 193 */     this(List.of(matchers));
/*     */   }
/*     */   
/*     */   private AuthorizedUrl(List<RequestMatcher> matchers) {
/* 197 */     this.matchers = matchers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder permitAll() {
/* 205 */     return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder denyAll() {
/* 213 */     return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.denyAll());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder authenticated() {
/* 221 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder fullyAuthenticated() {
/* 230 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder rememberMe() {
/* 238 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.rememberMe());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder anonymous() {
/* 246 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.anonymous());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder hasRole(String role) {
/* 256 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasRole(role));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyRole(String... roles) {
/* 267 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyRole(roles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder hasAuthority(String authority) {
/* 276 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAuthority(authority));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestMatcherDelegatingAuthorizationManager.Builder hasAnyAuthority(String... authorities) {
/* 286 */     return access((AuthorizationManager<RequestAuthorizationContext>)AuthorityAuthorizationManager.hasAnyAuthority(authorities));
/*     */   }
/*     */   
/*     */   private RequestMatcherDelegatingAuthorizationManager.Builder access(AuthorizationManager<RequestAuthorizationContext> manager) {
/* 290 */     for (RequestMatcher matcher : this.matchers) {
/* 291 */       RequestMatcherDelegatingAuthorizationManager.Builder.this.mappings.add(new RequestMatcherEntry(matcher, manager));
/*     */     }
/* 293 */     return RequestMatcherDelegatingAuthorizationManager.Builder.this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\RequestMatcherDelegatingAuthorizationManager$Builder$AuthorizedUrl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */