/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.FilterInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizationManagerWebInvocationPrivilegeEvaluator
/*    */   implements WebInvocationPrivilegeEvaluator, ServletContextAware
/*    */ {
/*    */   private final AuthorizationManager<HttpServletRequest> authorizationManager;
/*    */   private ServletContext servletContext;
/* 43 */   private HttpServletRequestTransformer requestTransformer = HttpServletRequestTransformer.IDENTITY;
/*    */ 
/*    */   
/*    */   public AuthorizationManagerWebInvocationPrivilegeEvaluator(AuthorizationManager<HttpServletRequest> authorizationManager) {
/* 47 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/* 48 */     this.authorizationManager = authorizationManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAllowed(String uri, Authentication authentication) {
/* 53 */     return isAllowed(null, uri, null, authentication);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAllowed(String contextPath, String uri, String method, Authentication authentication) {
/* 58 */     FilterInvocation filterInvocation = new FilterInvocation(contextPath, uri, method, this.servletContext);
/* 59 */     HttpServletRequest httpRequest = this.requestTransformer.transform(filterInvocation.getHttpRequest());
/* 60 */     AuthorizationResult result = this.authorizationManager.authorize(() -> authentication, httpRequest);
/* 61 */     return (result == null || result.isGranted());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setServletContext(ServletContext servletContext) {
/* 66 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequestTransformer(HttpServletRequestTransformer requestTransformer) {
/* 75 */     Assert.notNull(requestTransformer, "requestTransformer cannot be null");
/* 76 */     this.requestTransformer = requestTransformer;
/*    */   }
/*    */   
/*    */   public static interface HttpServletRequestTransformer {
/*    */     public static final HttpServletRequestTransformer IDENTITY;
/*    */     
/*    */     HttpServletRequest transform(HttpServletRequest param1HttpServletRequest);
/*    */     
/*    */     static {
/* 85 */       IDENTITY = (request -> request);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\AuthorizationManagerWebInvocationPrivilegeEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */