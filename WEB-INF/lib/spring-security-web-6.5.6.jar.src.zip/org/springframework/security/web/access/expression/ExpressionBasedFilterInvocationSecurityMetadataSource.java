/*     */ package org.springframework.security.web.access.expression;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParseException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ExpressionBasedFilterInvocationSecurityMetadataSource
/*     */   extends DefaultFilterInvocationSecurityMetadataSource
/*     */ {
/*  58 */   private static final Log logger = LogFactory.getLog(ExpressionBasedFilterInvocationSecurityMetadataSource.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBasedFilterInvocationSecurityMetadataSource(LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap, SecurityExpressionHandler<FilterInvocation> expressionHandler) {
/*  63 */     super(processMap(requestMap, expressionHandler.getExpressionParser()));
/*  64 */     Assert.notNull(expressionHandler, "A non-null SecurityExpressionHandler is required");
/*     */   }
/*     */ 
/*     */   
/*     */   private static LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> processMap(LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap, ExpressionParser parser) {
/*  69 */     Assert.notNull(parser, "SecurityExpressionHandler returned a null parser object");
/*  70 */     LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> processed = new LinkedHashMap<>(requestMap);
/*  71 */     requestMap.forEach((request, value) -> { Objects.requireNonNull(processed); process(parser, request, value, processed::put);
/*  72 */         }); return processed;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void process(ExpressionParser parser, RequestMatcher request, Collection<ConfigAttribute> value, BiConsumer<RequestMatcher, Collection<ConfigAttribute>> consumer) {
/*  77 */     String expression = getExpression(request, value);
/*  78 */     if (logger.isDebugEnabled()) {
/*  79 */       logger.debug(LogMessage.format("Adding web access control expression [%s] for %s", expression, request));
/*     */     }
/*  81 */     AbstractVariableEvaluationContextPostProcessor postProcessor = createPostProcessor(request);
/*  82 */     ArrayList<ConfigAttribute> processed = new ArrayList<>(1);
/*     */     try {
/*  84 */       processed.add(new WebExpressionConfigAttribute(parser.parseExpression(expression), postProcessor));
/*     */     }
/*  86 */     catch (ParseException ex) {
/*  87 */       throw new IllegalArgumentException("Failed to parse expression '" + expression + "'");
/*     */     } 
/*  89 */     consumer.accept(request, processed);
/*     */   }
/*     */   
/*     */   private static String getExpression(RequestMatcher request, Collection<ConfigAttribute> value) {
/*  93 */     Assert.isTrue((value.size() == 1), () -> "Expected a single expression attribute for " + String.valueOf(request));
/*  94 */     return ((ConfigAttribute[])value.toArray((T[])new ConfigAttribute[1]))[0].getAttribute();
/*     */   }
/*     */   
/*     */   private static AbstractVariableEvaluationContextPostProcessor createPostProcessor(RequestMatcher request) {
/*  98 */     return new RequestVariablesExtractorEvaluationContextPostProcessor(request);
/*     */   }
/*     */   
/*     */   static class RequestVariablesExtractorEvaluationContextPostProcessor
/*     */     extends AbstractVariableEvaluationContextPostProcessor
/*     */   {
/*     */     private final RequestMatcher matcher;
/*     */     
/*     */     RequestVariablesExtractorEvaluationContextPostProcessor(RequestMatcher matcher) {
/* 107 */       this.matcher = matcher;
/*     */     }
/*     */ 
/*     */     
/*     */     Map<String, String> extractVariables(HttpServletRequest request) {
/* 112 */       return this.matcher.matcher(request).getVariables();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\expression\ExpressionBasedFilterInvocationSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */