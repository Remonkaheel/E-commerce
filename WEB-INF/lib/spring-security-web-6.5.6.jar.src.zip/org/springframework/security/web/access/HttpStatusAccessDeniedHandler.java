/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpStatusAccessDeniedHandler
/*    */   implements AccessDeniedHandler
/*    */ {
/* 40 */   private static final Log logger = LogFactory.getLog(HttpStatusAccessDeniedHandler.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private final HttpStatus httpStatus;
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusAccessDeniedHandler(HttpStatus httpStatus) {
/* 49 */     Assert.notNull(httpStatus, "httpStatus cannot be null");
/* 50 */     this.httpStatus = httpStatus;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
/* 56 */     logger.debug(LogMessage.format("Access denied with status code %d", Integer.valueOf(this.httpStatus.value())));
/*    */     
/* 58 */     response.sendError(this.httpStatus.value(), "Access Denied");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\HttpStatusAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */