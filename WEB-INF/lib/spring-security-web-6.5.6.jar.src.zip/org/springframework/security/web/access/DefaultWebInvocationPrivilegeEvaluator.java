/*     */ package org.springframework.security.web.access;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import java.util.Collection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DefaultWebInvocationPrivilegeEvaluator
/*     */   implements WebInvocationPrivilegeEvaluator, ServletContextAware
/*     */ {
/*  45 */   protected static final Log logger = LogFactory.getLog(DefaultWebInvocationPrivilegeEvaluator.class);
/*     */   
/*     */   private final AbstractSecurityInterceptor securityInterceptor;
/*     */   
/*     */   private ServletContext servletContext;
/*     */   
/*     */   public DefaultWebInvocationPrivilegeEvaluator(AbstractSecurityInterceptor securityInterceptor) {
/*  52 */     Assert.notNull(securityInterceptor, "SecurityInterceptor cannot be null");
/*  53 */     Assert.isTrue(FilterInvocation.class.equals(securityInterceptor.getSecureObjectClass()), "AbstractSecurityInterceptor does not support FilterInvocations");
/*     */     
/*  55 */     Assert.notNull(securityInterceptor.getAccessDecisionManager(), "AbstractSecurityInterceptor must provide a non-null AccessDecisionManager");
/*     */     
/*  57 */     this.securityInterceptor = securityInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String uri, Authentication authentication) {
/*  68 */     return isAllowed(null, uri, null, authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String contextPath, String uri, String method, Authentication authentication) {
/*  90 */     Assert.notNull(uri, "uri parameter is required");
/*  91 */     FilterInvocation filterInvocation = new FilterInvocation(contextPath, uri, method, this.servletContext);
/*     */     
/*  93 */     Collection<ConfigAttribute> attributes = this.securityInterceptor.obtainSecurityMetadataSource().getAttributes(filterInvocation);
/*  94 */     if (attributes == null) {
/*  95 */       return !this.securityInterceptor.isRejectPublicInvocations();
/*     */     }
/*  97 */     if (authentication == null) {
/*  98 */       return false;
/*     */     }
/*     */     try {
/* 101 */       this.securityInterceptor.getAccessDecisionManager().decide(authentication, filterInvocation, attributes);
/* 102 */       return true;
/*     */     }
/* 104 */     catch (AccessDeniedException ex) {
/* 105 */       logger.debug(LogMessage.format("%s denied for %s", filterInvocation, authentication), (Throwable)ex);
/* 106 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/* 112 */     this.servletContext = servletContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\DefaultWebInvocationPrivilegeEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */