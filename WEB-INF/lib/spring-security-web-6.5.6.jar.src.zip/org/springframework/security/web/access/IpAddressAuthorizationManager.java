/*    */ package org.springframework.security.web.access;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ import org.springframework.security.web.util.matcher.IpAddressMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IpAddressAuthorizationManager
/*    */   implements AuthorizationManager<RequestAuthorizationContext>
/*    */ {
/*    */   private final IpAddressMatcher ipAddressMatcher;
/*    */   
/*    */   IpAddressAuthorizationManager(String ipAddress) {
/* 40 */     this.ipAddressMatcher = new IpAddressMatcher(ipAddress);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IpAddressAuthorizationManager hasIpAddress(String ipAddress) {
/* 50 */     Assert.notNull(ipAddress, "ipAddress cannot be null");
/* 51 */     return new IpAddressAuthorizationManager(ipAddress);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorizationDecision check(Supplier<Authentication> authentication, RequestAuthorizationContext requestAuthorizationContext) {
/* 57 */     return new AuthorizationDecision(this.ipAddressMatcher
/* 58 */         .matcher(requestAuthorizationContext.getRequest()).isMatch());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\IpAddressAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */