package org.springframework.security.web.access.intercept;

import org.springframework.security.access.SecurityMetadataSource;

@Deprecated
public interface FilterInvocationSecurityMetadataSource extends SecurityMetadataSource {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\FilterInvocationSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */