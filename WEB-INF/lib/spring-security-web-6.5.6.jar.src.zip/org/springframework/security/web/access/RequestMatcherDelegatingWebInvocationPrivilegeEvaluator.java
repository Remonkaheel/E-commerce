/*     */ package org.springframework.security.web.access;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class RequestMatcherDelegatingWebInvocationPrivilegeEvaluator
/*     */   implements WebInvocationPrivilegeEvaluator, ServletContextAware
/*     */ {
/*     */   private final List<RequestMatcherEntry<List<WebInvocationPrivilegeEvaluator>>> delegates;
/*     */   private ServletContext servletContext;
/*     */   
/*     */   public RequestMatcherDelegatingWebInvocationPrivilegeEvaluator(List<RequestMatcherEntry<List<WebInvocationPrivilegeEvaluator>>> requestMatcherPrivilegeEvaluatorsEntries) {
/*  53 */     Assert.notNull(requestMatcherPrivilegeEvaluatorsEntries, "requestMatcherPrivilegeEvaluators cannot be null");
/*  54 */     for (RequestMatcherEntry<List<WebInvocationPrivilegeEvaluator>> entry : requestMatcherPrivilegeEvaluatorsEntries) {
/*  55 */       Assert.notNull(entry.getRequestMatcher(), "requestMatcher cannot be null");
/*  56 */       Assert.notNull(entry.getEntry(), "webInvocationPrivilegeEvaluators cannot be null");
/*     */     } 
/*  58 */     this.delegates = requestMatcherPrivilegeEvaluatorsEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String uri, Authentication authentication) {
/*  76 */     List<WebInvocationPrivilegeEvaluator> privilegeEvaluators = getDelegate(null, uri, null);
/*  77 */     if (privilegeEvaluators.isEmpty()) {
/*  78 */       return true;
/*     */     }
/*  80 */     for (WebInvocationPrivilegeEvaluator evaluator : privilegeEvaluators) {
/*  81 */       boolean isAllowed = evaluator.isAllowed(uri, authentication);
/*  82 */       if (!isAllowed) {
/*  83 */         return false;
/*     */       }
/*     */     } 
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(String contextPath, String uri, String method, Authentication authentication) {
/* 109 */     List<WebInvocationPrivilegeEvaluator> privilegeEvaluators = getDelegate(contextPath, uri, method);
/* 110 */     if (privilegeEvaluators.isEmpty()) {
/* 111 */       return true;
/*     */     }
/* 113 */     for (WebInvocationPrivilegeEvaluator evaluator : privilegeEvaluators) {
/* 114 */       boolean isAllowed = evaluator.isAllowed(contextPath, uri, method, authentication);
/* 115 */       if (!isAllowed) {
/* 116 */         return false;
/*     */       }
/*     */     } 
/* 119 */     return true;
/*     */   }
/*     */   
/*     */   private List<WebInvocationPrivilegeEvaluator> getDelegate(String contextPath, String uri, String method) {
/* 123 */     FilterInvocation filterInvocation = new FilterInvocation(contextPath, uri, method, this.servletContext);
/* 124 */     HttpServletRequest request = filterInvocation.getHttpRequest();
/* 125 */     for (RequestMatcherEntry<List<WebInvocationPrivilegeEvaluator>> delegate : this.delegates) {
/* 126 */       if (delegate.getRequestMatcher().matches(request)) {
/* 127 */         return (List<WebInvocationPrivilegeEvaluator>)delegate.getEntry();
/*     */       }
/*     */     } 
/* 130 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/* 135 */     this.servletContext = servletContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\RequestMatcherDelegatingWebInvocationPrivilegeEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */