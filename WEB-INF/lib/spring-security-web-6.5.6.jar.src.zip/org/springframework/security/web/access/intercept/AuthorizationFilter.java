/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  55 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private final AuthorizationManager<HttpServletRequest> authorizationManager;
/*     */   
/*  59 */   private AuthorizationEventPublisher eventPublisher = new NoopAuthorizationEventPublisher();
/*     */ 
/*     */   
/*     */   private boolean observeOncePerRequest = false;
/*     */ 
/*     */   
/*     */   private boolean filterErrorDispatch = true;
/*     */ 
/*     */   
/*     */   private boolean filterAsyncDispatch = true;
/*     */ 
/*     */   
/*     */   public AuthorizationFilter(AuthorizationManager<HttpServletRequest> authorizationManager) {
/*  72 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/*  73 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws ServletException, IOException {
/*  80 */     HttpServletRequest request = (HttpServletRequest)servletRequest;
/*  81 */     HttpServletResponse response = (HttpServletResponse)servletResponse;
/*     */     
/*  83 */     if (this.observeOncePerRequest && isApplied(request)) {
/*  84 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     if (skipDispatch(request)) {
/*  89 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       
/*     */       return;
/*     */     } 
/*  93 */     String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
/*  94 */     request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
/*     */     try {
/*  96 */       AuthorizationResult result = this.authorizationManager.authorize(this::getAuthentication, request);
/*  97 */       this.eventPublisher.publishAuthorizationEvent(this::getAuthentication, request, result);
/*  98 */       if (result != null && !result.isGranted()) {
/*  99 */         throw new AuthorizationDeniedException("Access Denied", result);
/*     */       }
/* 101 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */     } finally {
/*     */       
/* 104 */       request.removeAttribute(alreadyFilteredAttributeName);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean skipDispatch(HttpServletRequest request) {
/* 109 */     if (DispatcherType.ERROR.equals(request.getDispatcherType()) && !this.filterErrorDispatch) {
/* 110 */       return true;
/*     */     }
/*     */     
/* 113 */     return (DispatcherType.ASYNC.equals(request.getDispatcherType()) && !this.filterAsyncDispatch);
/*     */   }
/*     */   
/*     */   private boolean isApplied(HttpServletRequest request) {
/* 117 */     return (request.getAttribute(getAlreadyFilteredAttributeName()) != null);
/*     */   }
/*     */   
/*     */   private String getAlreadyFilteredAttributeName() {
/* 121 */     String name = getFilterName();
/* 122 */     if (name == null) {
/* 123 */       name = getClass().getName();
/*     */     }
/* 125 */     return name + ".APPLIED";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 135 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 136 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 140 */     Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 141 */     if (authentication == null) {
/* 142 */       throw new AuthenticationCredentialsNotFoundException("An Authentication object was not found in the SecurityContext");
/*     */     }
/*     */     
/* 145 */     return authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorizationEventPublisher(AuthorizationEventPublisher eventPublisher) {
/* 155 */     Assert.notNull(eventPublisher, "eventPublisher cannot be null");
/* 156 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManager<HttpServletRequest> getAuthorizationManager() {
/* 164 */     return this.authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public void setShouldFilterAllDispatcherTypes(boolean shouldFilterAllDispatcherTypes) {
/* 192 */     this.observeOncePerRequest = !shouldFilterAllDispatcherTypes;
/* 193 */     this.filterErrorDispatch = shouldFilterAllDispatcherTypes;
/* 194 */     this.filterAsyncDispatch = shouldFilterAllDispatcherTypes;
/*     */   }
/*     */   
/*     */   public boolean isObserveOncePerRequest() {
/* 198 */     return this.observeOncePerRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObserveOncePerRequest(boolean observeOncePerRequest) {
/* 211 */     this.observeOncePerRequest = observeOncePerRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterErrorDispatch(boolean filterErrorDispatch) {
/* 220 */     this.filterErrorDispatch = filterErrorDispatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterAsyncDispatch(boolean filterAsyncDispatch) {
/* 229 */     this.filterAsyncDispatch = filterAsyncDispatch;
/*     */   }
/*     */   
/*     */   private static class NoopAuthorizationEventPublisher implements AuthorizationEventPublisher {
/*     */     public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationDecision decision) {}
/*     */     
/*     */     public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\AuthorizationFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */