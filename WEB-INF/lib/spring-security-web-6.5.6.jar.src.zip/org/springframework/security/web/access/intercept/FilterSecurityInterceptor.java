/*     */ package org.springframework.security.web.access.intercept;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.FilterConfig;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.security.access.SecurityMetadataSource;
/*     */ import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
/*     */ import org.springframework.security.access.intercept.InterceptorStatusToken;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class FilterSecurityInterceptor
/*     */   extends AbstractSecurityInterceptor
/*     */   implements Filter
/*     */ {
/*     */   private static final String FILTER_APPLIED = "__spring_security_filterSecurityInterceptor_filterApplied";
/*     */   private FilterInvocationSecurityMetadataSource securityMetadataSource;
/*     */   private boolean observeOncePerRequest = false;
/*     */   
/*     */   public void init(FilterConfig arg0) {}
/*     */   
/*     */   public void destroy() {}
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  83 */     invoke(new FilterInvocation(request, response, chain));
/*     */   }
/*     */   
/*     */   public FilterInvocationSecurityMetadataSource getSecurityMetadataSource() {
/*  87 */     return this.securityMetadataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public SecurityMetadataSource obtainSecurityMetadataSource() {
/*  92 */     return this.securityMetadataSource;
/*     */   }
/*     */   
/*     */   public void setSecurityMetadataSource(FilterInvocationSecurityMetadataSource newSource) {
/*  96 */     this.securityMetadataSource = newSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getSecureObjectClass() {
/* 101 */     return FilterInvocation.class;
/*     */   }
/*     */   
/*     */   public void invoke(FilterInvocation filterInvocation) throws IOException, ServletException {
/* 105 */     if (isApplied(filterInvocation) && this.observeOncePerRequest) {
/*     */ 
/*     */       
/* 108 */       filterInvocation.getChain().doFilter((ServletRequest)filterInvocation.getRequest(), (ServletResponse)filterInvocation.getResponse());
/*     */       
/*     */       return;
/*     */     } 
/* 112 */     if (filterInvocation.getRequest() != null && this.observeOncePerRequest) {
/* 113 */       filterInvocation.getRequest().setAttribute("__spring_security_filterSecurityInterceptor_filterApplied", Boolean.TRUE);
/*     */     }
/* 115 */     InterceptorStatusToken token = beforeInvocation(filterInvocation);
/*     */     try {
/* 117 */       filterInvocation.getChain().doFilter((ServletRequest)filterInvocation.getRequest(), (ServletResponse)filterInvocation.getResponse());
/*     */     } finally {
/*     */       
/* 120 */       finallyInvocation(token);
/*     */     } 
/* 122 */     afterInvocation(token, null);
/*     */   }
/*     */   
/*     */   private boolean isApplied(FilterInvocation filterInvocation) {
/* 126 */     return (filterInvocation.getRequest() != null && filterInvocation
/* 127 */       .getRequest().getAttribute("__spring_security_filterSecurityInterceptor_filterApplied") != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isObserveOncePerRequest() {
/* 141 */     return this.observeOncePerRequest;
/*     */   }
/*     */   
/*     */   public void setObserveOncePerRequest(boolean observeOncePerRequest) {
/* 145 */     this.observeOncePerRequest = observeOncePerRequest;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\FilterSecurityInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */