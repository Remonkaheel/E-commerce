/*    */ package org.springframework.security.web.access.intercept;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestKey
/*    */ {
/*    */   private final String url;
/*    */   private final String method;
/*    */   
/*    */   public RequestKey(String url) {
/* 32 */     this(url, null);
/*    */   }
/*    */   
/*    */   public RequestKey(String url, String method) {
/* 36 */     Assert.notNull(url, "url cannot be null");
/* 37 */     this.url = url;
/* 38 */     this.method = method;
/*    */   }
/*    */   
/*    */   String getUrl() {
/* 42 */     return this.url;
/*    */   }
/*    */   
/*    */   String getMethod() {
/* 46 */     return this.method;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/*    */     RequestKey key;
/* 51 */     if (obj instanceof RequestKey) { key = (RequestKey)obj; }
/* 52 */     else { return false; }
/*    */     
/* 54 */     if (!this.url.equals(key.url)) {
/* 55 */       return false;
/*    */     }
/* 57 */     if (this.method == null) {
/* 58 */       return (key.method == null);
/*    */     }
/* 60 */     return this.method.equals(key.method);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 65 */     int result = this.url.hashCode();
/* 66 */     result = 31 * result + ((this.method != null) ? this.method.hashCode() : 0);
/* 67 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     StringBuilder sb = new StringBuilder(this.url.length() + 7);
/* 73 */     sb.append("[");
/* 74 */     if (this.method != null) {
/* 75 */       sb.append(this.method).append(",");
/*    */     }
/* 77 */     sb.append(this.url);
/* 78 */     sb.append("]");
/* 79 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\access\intercept\RequestKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */