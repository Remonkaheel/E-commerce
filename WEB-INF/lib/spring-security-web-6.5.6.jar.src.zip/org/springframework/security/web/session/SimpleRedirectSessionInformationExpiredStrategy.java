/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.web.DefaultRedirectStrategy;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ import org.springframework.security.web.util.UrlUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleRedirectSessionInformationExpiredStrategy
/*    */   implements SessionInformationExpiredStrategy
/*    */ {
/* 38 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final String destinationUrl;
/*    */   
/*    */   private final RedirectStrategy redirectStrategy;
/*    */   
/*    */   public SimpleRedirectSessionInformationExpiredStrategy(String invalidSessionUrl) {
/* 45 */     this(invalidSessionUrl, (RedirectStrategy)new DefaultRedirectStrategy());
/*    */   }
/*    */ 
/*    */   
/*    */   public SimpleRedirectSessionInformationExpiredStrategy(String invalidSessionUrl, RedirectStrategy redirectStrategy) {
/* 50 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(invalidSessionUrl), "url must start with '/' or with 'http(s)'");
/* 51 */     this.destinationUrl = invalidSessionUrl;
/* 52 */     this.redirectStrategy = redirectStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExpiredSessionDetected(SessionInformationExpiredEvent event) throws IOException {
/* 57 */     this.logger.debug("Redirecting to '" + this.destinationUrl + "'");
/* 58 */     this.redirectStrategy.sendRedirect(event.getRequest(), event.getResponse(), this.destinationUrl);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\SimpleRedirectSessionInformationExpiredStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */