/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.session.SessionDestroyedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionDestroyedEvent
/*    */   extends SessionDestroyedEvent
/*    */ {
/*    */   public HttpSessionDestroyedEvent(HttpSession session) {
/* 40 */     super(session);
/*    */   }
/*    */   
/*    */   public HttpSession getSession() {
/* 44 */     return (HttpSession)getSource();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<SecurityContext> getSecurityContexts() {
/* 50 */     HttpSession session = getSession();
/* 51 */     Enumeration<String> attributes = session.getAttributeNames();
/* 52 */     ArrayList<SecurityContext> contexts = new ArrayList<>();
/* 53 */     while (attributes.hasMoreElements()) {
/* 54 */       String attributeName = attributes.nextElement();
/* 55 */       Object attributeValue = session.getAttribute(attributeName);
/* 56 */       if (attributeValue instanceof SecurityContext) {
/* 57 */         contexts.add((SecurityContext)attributeValue);
/*    */       }
/*    */     } 
/* 60 */     return contexts;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 65 */     return getSession().getId();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\HttpSessionDestroyedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */