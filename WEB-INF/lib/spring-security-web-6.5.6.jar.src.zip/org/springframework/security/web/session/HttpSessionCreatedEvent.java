/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import org.springframework.security.core.session.SessionCreationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionCreatedEvent
/*    */   extends SessionCreationEvent
/*    */ {
/*    */   public HttpSessionCreatedEvent(HttpSession session) {
/* 34 */     super(session);
/*    */   }
/*    */   
/*    */   public HttpSession getSession() {
/* 38 */     return (HttpSession)getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\HttpSessionCreatedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */