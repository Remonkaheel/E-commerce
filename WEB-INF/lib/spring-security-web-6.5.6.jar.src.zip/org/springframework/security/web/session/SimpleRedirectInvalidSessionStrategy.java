/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.web.DefaultRedirectStrategy;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ import org.springframework.security.web.util.UrlUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleRedirectInvalidSessionStrategy
/*    */   implements InvalidSessionStrategy
/*    */ {
/* 39 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final String destinationUrl;
/*    */   
/* 43 */   private final RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*    */   
/*    */   private boolean createNewSession = true;
/*    */   
/*    */   public SimpleRedirectInvalidSessionStrategy(String invalidSessionUrl) {
/* 48 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(invalidSessionUrl), "url must start with '/' or with 'http(s)'");
/* 49 */     this.destinationUrl = invalidSessionUrl;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onInvalidSessionDetected(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 54 */     if (this.logger.isDebugEnabled()) {
/* 55 */       this.logger.debug("Starting new session (if required) and redirecting to '" + this.destinationUrl + "'");
/*    */     }
/* 57 */     if (this.createNewSession) {
/* 58 */       request.getSession();
/*    */     }
/* 60 */     this.redirectStrategy.sendRedirect(request, response, this.destinationUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCreateNewSession(boolean createNewSession) {
/* 71 */     this.createNewSession = createNewSession;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\SimpleRedirectInvalidSessionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */