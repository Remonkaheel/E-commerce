/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DisableEncodeUrlResponseWrapper
/*    */   extends HttpServletResponseWrapper
/*    */ {
/*    */   private DisableEncodeUrlResponseWrapper(HttpServletResponse response) {
/* 61 */     super(response);
/*    */   }
/*    */ 
/*    */   
/*    */   public String encodeRedirectURL(String url) {
/* 66 */     return url;
/*    */   }
/*    */ 
/*    */   
/*    */   public String encodeURL(String url) {
/* 71 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\DisableEncodeUrlFilter$DisableEncodeUrlResponseWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */