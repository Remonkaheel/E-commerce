/*     */ package org.springframework.security.web.session;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationException;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionFixationProtectionStrategy;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionManagementFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   static final String FILTER_APPLIED = "__spring_security_session_mgmt_filter_applied";
/*  58 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private final SecurityContextRepository securityContextRepository;
/*     */   
/*     */   private SessionAuthenticationStrategy sessionAuthenticationStrategy;
/*     */   
/*  64 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*  66 */   private InvalidSessionStrategy invalidSessionStrategy = null;
/*     */   
/*  68 */   private AuthenticationFailureHandler failureHandler = (AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler();
/*     */   
/*     */   public SessionManagementFilter(SecurityContextRepository securityContextRepository) {
/*  71 */     this(securityContextRepository, (SessionAuthenticationStrategy)new SessionFixationProtectionStrategy());
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionManagementFilter(SecurityContextRepository securityContextRepository, SessionAuthenticationStrategy sessionStrategy) {
/*  76 */     Assert.notNull(securityContextRepository, "SecurityContextRepository cannot be null");
/*  77 */     Assert.notNull(sessionStrategy, "SessionAuthenticationStrategy cannot be null");
/*  78 */     this.securityContextRepository = securityContextRepository;
/*  79 */     this.sessionAuthenticationStrategy = sessionStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  85 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  90 */     if (request.getAttribute("__spring_security_session_mgmt_filter_applied") != null) {
/*  91 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  94 */     request.setAttribute("__spring_security_session_mgmt_filter_applied", Boolean.TRUE);
/*  95 */     if (!this.securityContextRepository.containsContext(request)) {
/*  96 */       Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/*  97 */       if (this.trustResolver.isAuthenticated(authentication)) {
/*     */ 
/*     */         
/*     */         try {
/* 101 */           this.sessionAuthenticationStrategy.onAuthentication(authentication, request, response);
/*     */         }
/* 103 */         catch (SessionAuthenticationException ex) {
/*     */           
/* 105 */           this.logger.debug("SessionAuthenticationStrategy rejected the authentication object", (Throwable)ex);
/* 106 */           this.securityContextHolderStrategy.clearContext();
/* 107 */           this.failureHandler.onAuthenticationFailure(request, response, (AuthenticationException)ex);
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 113 */         this.securityContextRepository.saveContext(this.securityContextHolderStrategy.getContext(), request, response);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 119 */       else if (request.getRequestedSessionId() != null && !request.isRequestedSessionIdValid()) {
/* 120 */         if (this.logger.isDebugEnabled()) {
/* 121 */           this.logger.debug(LogMessage.format("Request requested invalid session id %s", request
/* 122 */                 .getRequestedSessionId()));
/*     */         }
/* 124 */         if (this.invalidSessionStrategy != null) {
/* 125 */           this.invalidSessionStrategy.onInvalidSessionDetected(request, response);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 131 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvalidSessionStrategy(InvalidSessionStrategy invalidSessionStrategy) {
/* 142 */     this.invalidSessionStrategy = invalidSessionStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationFailureHandler(AuthenticationFailureHandler failureHandler) {
/* 153 */     Assert.notNull(failureHandler, "failureHandler cannot be null");
/* 154 */     this.failureHandler = failureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 164 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 165 */     this.trustResolver = trustResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 175 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 176 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\SessionManagementFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */