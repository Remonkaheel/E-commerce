package org.springframework.security.web.session;

import jakarta.servlet.ServletException;
import java.io.IOException;

public interface SessionInformationExpiredStrategy {
  void onExpiredSessionDetected(SessionInformationExpiredEvent paramSessionInformationExpiredEvent) throws IOException, ServletException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\SessionInformationExpiredStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */