/*     */ package org.springframework.security.web.session;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.session.SessionInformation;
/*     */ import org.springframework.security.core.session.SessionRegistry;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.authentication.logout.CompositeLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentSessionFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  72 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private final SessionRegistry sessionRegistry;
/*     */   
/*     */   private String expiredUrl;
/*     */   
/*     */   private RedirectStrategy redirectStrategy;
/*     */   
/*  80 */   private LogoutHandler handlers = (LogoutHandler)new CompositeLogoutHandler(new LogoutHandler[] { (LogoutHandler)new SecurityContextLogoutHandler() });
/*     */   
/*     */   private SessionInformationExpiredStrategy sessionInformationExpiredStrategy;
/*     */   
/*     */   public ConcurrentSessionFilter(SessionRegistry sessionRegistry) {
/*  85 */     Assert.notNull(sessionRegistry, "SessionRegistry required");
/*  86 */     this.sessionRegistry = sessionRegistry;
/*  87 */     this.sessionInformationExpiredStrategy = new ResponseBodySessionInformationExpiredStrategy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ConcurrentSessionFilter(SessionRegistry sessionRegistry, String expiredUrl) {
/* 100 */     Assert.notNull(sessionRegistry, "SessionRegistry required");
/* 101 */     Assert.isTrue((expiredUrl == null || UrlUtils.isValidRedirectUrl(expiredUrl)), () -> expiredUrl + " isn't a valid redirect URL");
/*     */     
/* 103 */     this.expiredUrl = expiredUrl;
/* 104 */     this.sessionRegistry = sessionRegistry;
/* 105 */     this.sessionInformationExpiredStrategy = (event -> {
/*     */         HttpServletRequest request = event.getRequest();
/*     */         HttpServletResponse response = event.getResponse();
/*     */         SessionInformation info = event.getSessionInformation();
/*     */         this.redirectStrategy.sendRedirect(request, response, determineExpiredUrl(request, info));
/*     */       });
/*     */   }
/*     */ 
/*     */   
/*     */   public ConcurrentSessionFilter(SessionRegistry sessionRegistry, SessionInformationExpiredStrategy sessionInformationExpiredStrategy) {
/* 115 */     Assert.notNull(sessionRegistry, "sessionRegistry required");
/* 116 */     Assert.notNull(sessionInformationExpiredStrategy, "sessionInformationExpiredStrategy cannot be null");
/* 117 */     this.sessionRegistry = sessionRegistry;
/* 118 */     this.sessionInformationExpiredStrategy = sessionInformationExpiredStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 123 */     Assert.notNull(this.sessionRegistry, "SessionRegistry required");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 129 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 134 */     HttpSession session = request.getSession(false);
/* 135 */     if (session != null) {
/* 136 */       SessionInformation info = this.sessionRegistry.getSessionInformation(session.getId());
/* 137 */       if (info != null) {
/* 138 */         if (info.isExpired()) {
/*     */           
/* 140 */           this.logger.debug(
/* 141 */               LogMessage.of(() -> "Requested session ID " + request.getRequestedSessionId() + " has expired."));
/* 142 */           doLogout(request, response);
/* 143 */           this.sessionInformationExpiredStrategy
/* 144 */             .onExpiredSessionDetected(new SessionInformationExpiredEvent(info, request, response, chain));
/*     */           
/*     */           return;
/*     */         } 
/* 148 */         this.sessionRegistry.refreshLastRequest(info.getSessionId());
/*     */       } 
/*     */     } 
/* 151 */     chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String determineExpiredUrl(HttpServletRequest request, SessionInformation info) {
/* 165 */     return this.expiredUrl;
/*     */   }
/*     */   
/*     */   private void doLogout(HttpServletRequest request, HttpServletResponse response) {
/* 169 */     Authentication auth = this.securityContextHolderStrategy.getContext().getAuthentication();
/*     */     
/* 171 */     this.handlers.logout(request, response, auth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 181 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 182 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setLogoutHandlers(LogoutHandler[] handlers) {
/* 186 */     this.handlers = (LogoutHandler)new CompositeLogoutHandler(handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogoutHandlers(List<LogoutHandler> handlers) {
/* 195 */     this.handlers = (LogoutHandler)new CompositeLogoutHandler(handlers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
/* 208 */     this.redirectStrategy = redirectStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ResponseBodySessionInformationExpiredStrategy
/*     */     implements SessionInformationExpiredStrategy
/*     */   {
/*     */     public void onExpiredSessionDetected(SessionInformationExpiredEvent event) throws IOException {
/* 223 */       HttpServletResponse response = event.getResponse();
/* 224 */       response.getWriter()
/* 225 */         .print("This session has been expired (possibly due to multiple concurrent logins being attempted as the same user).");
/*     */       
/* 227 */       response.flushBuffer();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\ConcurrentSessionFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */