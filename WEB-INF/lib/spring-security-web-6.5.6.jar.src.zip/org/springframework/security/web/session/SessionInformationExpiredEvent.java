/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.security.core.session.SessionInformation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SessionInformationExpiredEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final HttpServletRequest request;
/*    */   private final HttpServletResponse response;
/*    */   private final FilterChain filterChain;
/*    */   
/*    */   public SessionInformationExpiredEvent(SessionInformation sessionInformation, HttpServletRequest request, HttpServletResponse response) {
/* 50 */     this(sessionInformation, request, response, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SessionInformationExpiredEvent(SessionInformation sessionInformation, HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
/* 63 */     super(sessionInformation);
/* 64 */     Assert.notNull(request, "request cannot be null");
/* 65 */     Assert.notNull(response, "response cannot be null");
/* 66 */     this.request = request;
/* 67 */     this.response = response;
/* 68 */     this.filterChain = filterChain;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpServletRequest getRequest() {
/* 75 */     return this.request;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpServletResponse getResponse() {
/* 82 */     return this.response;
/*    */   }
/*    */   
/*    */   public SessionInformation getSessionInformation() {
/* 86 */     return (SessionInformation)getSource();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterChain getFilterChain() {
/* 94 */     return this.filterChain;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\SessionInformationExpiredEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */