/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*    */ import java.io.IOException;
/*    */ import org.springframework.web.filter.OncePerRequestFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisableEncodeUrlFilter
/*    */   extends OncePerRequestFilter
/*    */ {
/*    */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 42 */     filterChain.doFilter((ServletRequest)request, (ServletResponse)new DisableEncodeUrlResponseWrapper(response));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class DisableEncodeUrlResponseWrapper
/*    */     extends HttpServletResponseWrapper
/*    */   {
/*    */     private DisableEncodeUrlResponseWrapper(HttpServletResponse response) {
/* 61 */       super(response);
/*    */     }
/*    */ 
/*    */     
/*    */     public String encodeRedirectURL(String url) {
/* 66 */       return url;
/*    */     }
/*    */ 
/*    */     
/*    */     public String encodeURL(String url) {
/* 71 */       return url;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\DisableEncodeUrlFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */