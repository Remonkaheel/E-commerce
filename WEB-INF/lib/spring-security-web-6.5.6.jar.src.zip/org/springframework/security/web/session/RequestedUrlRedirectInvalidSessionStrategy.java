/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.web.DefaultRedirectStrategy;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestedUrlRedirectInvalidSessionStrategy
/*    */   implements InvalidSessionStrategy
/*    */ {
/* 40 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 42 */   private RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean createNewSession = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onInvalidSessionDetected(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 52 */     String destinationUrl = ServletUriComponentsBuilder.fromRequest(request).host(null).scheme(null).port(null).toUriString();
/* 53 */     if (this.logger.isDebugEnabled()) {
/* 54 */       this.logger.debug("Starting new session (if required) and redirecting to '" + destinationUrl + "'");
/*    */     }
/* 56 */     if (this.createNewSession) {
/* 57 */       request.getSession();
/*    */     }
/* 59 */     this.redirectStrategy.sendRedirect(request, response, destinationUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCreateNewSession(boolean createNewSession) {
/* 70 */     this.createNewSession = createNewSession;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
/* 79 */     Assert.notNull(redirectStrategy, "redirectStrategy cannot be null");
/* 80 */     this.redirectStrategy = redirectStrategy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\RequestedUrlRedirectInvalidSessionStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */