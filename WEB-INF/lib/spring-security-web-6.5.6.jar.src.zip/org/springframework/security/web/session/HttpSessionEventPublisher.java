/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import jakarta.servlet.http.HttpSessionEvent;
/*    */ import jakarta.servlet.http.HttpSessionIdListener;
/*    */ import jakarta.servlet.http.HttpSessionListener;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.web.context.support.SecurityWebApplicationContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionEventPublisher
/*    */   implements HttpSessionListener, HttpSessionIdListener
/*    */ {
/* 51 */   private static final String LOGGER_NAME = HttpSessionEventPublisher.class.getName();
/*    */   
/*    */   ApplicationContext getContext(ServletContext servletContext) {
/* 54 */     return (ApplicationContext)SecurityWebApplicationContextUtils.findRequiredWebApplicationContext(servletContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionCreated(HttpSessionEvent event) {
/* 64 */     extracted(event.getSession(), (ApplicationEvent)new HttpSessionCreatedEvent(event.getSession()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionDestroyed(HttpSessionEvent event) {
/* 74 */     extracted(event.getSession(), (ApplicationEvent)new HttpSessionDestroyedEvent(event.getSession()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionIdChanged(HttpSessionEvent event, String oldSessionId) {
/* 82 */     extracted(event.getSession(), (ApplicationEvent)new HttpSessionIdChangedEvent(event.getSession(), oldSessionId));
/*    */   }
/*    */   
/*    */   private void extracted(HttpSession session, ApplicationEvent e) {
/* 86 */     Log log = LogFactory.getLog(LOGGER_NAME);
/* 87 */     log.debug(LogMessage.format("Publishing event: %s", e));
/* 88 */     getContext(session.getServletContext()).publishEvent(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\HttpSessionEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */