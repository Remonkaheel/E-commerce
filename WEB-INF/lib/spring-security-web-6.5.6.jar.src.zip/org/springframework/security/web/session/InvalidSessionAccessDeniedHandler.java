/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.web.access.AccessDeniedHandler;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InvalidSessionAccessDeniedHandler
/*    */   implements AccessDeniedHandler
/*    */ {
/*    */   private final InvalidSessionStrategy invalidSessionStrategy;
/*    */   
/*    */   public InvalidSessionAccessDeniedHandler(InvalidSessionStrategy invalidSessionStrategy) {
/* 44 */     Assert.notNull(invalidSessionStrategy, "invalidSessionStrategy cannot be null");
/* 45 */     this.invalidSessionStrategy = invalidSessionStrategy;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
/* 51 */     this.invalidSessionStrategy.onInvalidSessionDetected(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\InvalidSessionAccessDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */