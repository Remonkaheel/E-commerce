/*    */ package org.springframework.security.web.session;
/*    */ 
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import org.springframework.security.core.session.SessionIdChangedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionIdChangedEvent
/*    */   extends SessionIdChangedEvent
/*    */ {
/*    */   private static final long serialVersionUID = -5725731666499807941L;
/*    */   private final String oldSessionId;
/*    */   private final String newSessionId;
/*    */   
/*    */   public HttpSessionIdChangedEvent(HttpSession session, String oldSessionId) {
/* 42 */     super(session);
/* 43 */     this.oldSessionId = oldSessionId;
/* 44 */     this.newSessionId = session.getId();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getOldSessionId() {
/* 49 */     return this.oldSessionId;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNewSessionId() {
/* 54 */     return this.newSessionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\session\HttpSessionIdChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */