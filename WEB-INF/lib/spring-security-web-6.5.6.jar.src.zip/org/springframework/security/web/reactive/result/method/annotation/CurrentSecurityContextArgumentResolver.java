/*     */ package org.springframework.security.web.reactive.result.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.CurrentSecurityContext;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.reactive.BindingContext;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolverSupport;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrentSecurityContextArgumentResolver
/*     */   extends HandlerMethodArgumentResolverSupport
/*     */ {
/*  56 */   private ExpressionParser parser = (ExpressionParser)new SpelExpressionParser();
/*     */   
/*  58 */   private final Class<CurrentSecurityContext> annotationType = CurrentSecurityContext.class;
/*     */ 
/*     */   
/*  61 */   private SecurityAnnotationScanner<CurrentSecurityContext> scanner = SecurityAnnotationScanners.requireUnique(this.annotationType);
/*     */   
/*     */   private boolean useAnnotationTemplate = false;
/*     */   
/*     */   private BeanResolver beanResolver;
/*     */   
/*     */   public CurrentSecurityContextArgumentResolver(ReactiveAdapterRegistry adapterRegistry) {
/*  68 */     super(adapterRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanResolver(BeanResolver beanResolver) {
/*  76 */     Assert.notNull(beanResolver, "beanResolver cannot be null");
/*  77 */     this.beanResolver = beanResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/*  90 */     this.useAnnotationTemplate = (templateDefaults != null);
/*  91 */     this.scanner = SecurityAnnotationScanners.requireUnique(CurrentSecurityContext.class, templateDefaults);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/*  96 */     return (isMonoSecurityContext(parameter) || findMethodAnnotation(parameter) != null);
/*     */   }
/*     */   
/*     */   private boolean isMonoSecurityContext(MethodParameter parameter) {
/* 100 */     boolean isParameterPublisher = Publisher.class.isAssignableFrom(parameter.getParameterType());
/* 101 */     if (isParameterPublisher) {
/* 102 */       ResolvableType resolvableType = ResolvableType.forMethodParameter(parameter);
/* 103 */       Class<?> genericType = resolvableType.resolveGeneric(new int[] { 0 });
/* 104 */       if (genericType == null) {
/* 105 */         return false;
/*     */       }
/* 107 */       return SecurityContext.class.isAssignableFrom(genericType);
/*     */     } 
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> resolveArgument(MethodParameter parameter, BindingContext bindingContext, ServerWebExchange exchange) {
/* 115 */     ReactiveAdapter adapter = getAdapterRegistry().getAdapter(parameter.getParameterType());
/* 116 */     Mono<SecurityContext> reactiveSecurityContext = ReactiveSecurityContextHolder.getContext();
/* 117 */     if (reactiveSecurityContext == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     return reactiveSecurityContext.flatMap(securityContext -> {
/*     */           Mono<Object> resolvedSecurityContext = Mono.justOrEmpty(resolveSecurityContext(parameter, securityContext));
/*     */           return (adapter != null) ? Mono.just(adapter.fromPublisher((Publisher)resolvedSecurityContext)) : resolvedSecurityContext;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object resolveSecurityContext(MethodParameter parameter, SecurityContext securityContext) {
/* 136 */     CurrentSecurityContext annotation = findMethodAnnotation(parameter);
/* 137 */     if (annotation != null) {
/* 138 */       return resolveSecurityContextFromAnnotation(annotation, parameter, securityContext);
/*     */     }
/* 140 */     return securityContext;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object resolveSecurityContextFromAnnotation(CurrentSecurityContext annotation, MethodParameter parameter, Object securityContext) {
/* 145 */     Object securityContextResult = securityContext;
/* 146 */     String expressionToParse = annotation.expression();
/* 147 */     if (StringUtils.hasLength(expressionToParse)) {
/* 148 */       StandardEvaluationContext context = new StandardEvaluationContext();
/* 149 */       context.setRootObject(securityContext);
/* 150 */       context.setVariable("this", securityContext);
/* 151 */       context.setBeanResolver(this.beanResolver);
/* 152 */       Expression expression = this.parser.parseExpression(expressionToParse);
/* 153 */       securityContextResult = expression.getValue((EvaluationContext)context);
/*     */     } 
/* 155 */     if (isInvalidType(parameter, securityContextResult)) {
/* 156 */       if (annotation.errorOnInvalidType()) {
/* 157 */         throw new ClassCastException(String.valueOf(securityContextResult) + " is not assignable to " + String.valueOf(securityContextResult));
/*     */       }
/*     */       
/* 160 */       return null;
/*     */     } 
/* 162 */     return securityContextResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInvalidType(MethodParameter parameter, Object reactiveSecurityContext) {
/* 172 */     if (reactiveSecurityContext == null) {
/* 173 */       return false;
/*     */     }
/* 175 */     Class<?> typeToCheck = parameter.getParameterType();
/* 176 */     boolean isParameterPublisher = Publisher.class.isAssignableFrom(parameter.getParameterType());
/* 177 */     if (isParameterPublisher) {
/* 178 */       ResolvableType resolvableType = ResolvableType.forMethodParameter(parameter);
/* 179 */       Class<?> genericType = resolvableType.resolveGeneric(new int[] { 0 });
/* 180 */       if (genericType == null) {
/* 181 */         return false;
/*     */       }
/* 183 */       typeToCheck = genericType;
/*     */     } 
/* 185 */     return !typeToCheck.isAssignableFrom(reactiveSecurityContext.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CurrentSecurityContext findMethodAnnotation(MethodParameter parameter) {
/* 194 */     if (this.useAnnotationTemplate) {
/* 195 */       return (CurrentSecurityContext)this.scanner.scan(parameter.getParameter());
/*     */     }
/* 197 */     CurrentSecurityContext annotation = (CurrentSecurityContext)parameter.getParameterAnnotation(this.annotationType);
/* 198 */     if (annotation != null) {
/* 199 */       return annotation;
/*     */     }
/* 201 */     Annotation[] annotationsToSearch = parameter.getParameterAnnotations();
/* 202 */     for (Annotation toSearch : annotationsToSearch) {
/* 203 */       annotation = (CurrentSecurityContext)AnnotationUtils.findAnnotation(toSearch.annotationType(), this.annotationType);
/* 204 */       if (annotation != null) {
/* 205 */         return (CurrentSecurityContext)MergedAnnotations.from(new Annotation[] { toSearch }).get(this.annotationType).synthesize();
/*     */       }
/*     */     } 
/* 208 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\reactive\result\method\annotation\CurrentSecurityContextArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */