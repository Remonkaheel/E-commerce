/*     */ package org.springframework.security.web.reactive.result.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.AuthenticationPrincipal;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.reactive.BindingContext;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolverSupport;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationPrincipalArgumentResolver
/*     */   extends HandlerMethodArgumentResolverSupport
/*     */ {
/*  56 */   private ExpressionParser parser = (ExpressionParser)new SpelExpressionParser();
/*     */   
/*  58 */   private final Class<AuthenticationPrincipal> annotationType = AuthenticationPrincipal.class;
/*     */ 
/*     */   
/*  61 */   private SecurityAnnotationScanner<AuthenticationPrincipal> scanner = SecurityAnnotationScanners.requireUnique(this.annotationType);
/*     */   
/*     */   private boolean useAnnotationTemplate = false;
/*     */   
/*     */   private BeanResolver beanResolver;
/*     */   
/*     */   public AuthenticationPrincipalArgumentResolver(ReactiveAdapterRegistry adapterRegistry) {
/*  68 */     super(adapterRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanResolver(BeanResolver beanResolver) {
/*  76 */     this.beanResolver = beanResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsParameter(MethodParameter parameter) {
/*  81 */     return (findMethodAnnotation(parameter) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Object> resolveArgument(MethodParameter parameter, BindingContext bindingContext, ServerWebExchange exchange) {
/*  87 */     ReactiveAdapter adapter = getAdapterRegistry().getAdapter(parameter.getParameterType());
/*  88 */     return ReactiveSecurityContextHolder.getContext()
/*  89 */       .map(SecurityContext::getAuthentication)
/*  90 */       .flatMap(authentication -> {
/*     */           Mono<Object> principal = Mono.justOrEmpty(resolvePrincipal(parameter, authentication.getPrincipal()));
/*     */           return (adapter != null) ? Mono.just(adapter.fromPublisher((Publisher)principal)) : principal;
/*     */         });
/*     */   }
/*     */   
/*     */   private Object resolvePrincipal(MethodParameter parameter, Object principal) {
/*  97 */     AuthenticationPrincipal annotation = findMethodAnnotation(parameter);
/*  98 */     String expressionToParse = annotation.expression();
/*  99 */     if (StringUtils.hasLength(expressionToParse)) {
/* 100 */       StandardEvaluationContext context = new StandardEvaluationContext();
/* 101 */       context.setRootObject(principal);
/* 102 */       context.setVariable("this", principal);
/* 103 */       context.setBeanResolver(this.beanResolver);
/* 104 */       Expression expression = this.parser.parseExpression(expressionToParse);
/* 105 */       principal = expression.getValue((EvaluationContext)context);
/*     */     } 
/* 107 */     if (isInvalidType(parameter, principal)) {
/* 108 */       if (annotation.errorOnInvalidType()) {
/* 109 */         throw new ClassCastException(String.valueOf(principal) + " is not assignable to " + String.valueOf(principal));
/*     */       }
/* 111 */       return null;
/*     */     } 
/* 113 */     return principal;
/*     */   }
/*     */   
/*     */   private boolean isInvalidType(MethodParameter parameter, Object principal) {
/* 117 */     if (principal == null) {
/* 118 */       return false;
/*     */     }
/* 120 */     Class<?> typeToCheck = parameter.getParameterType();
/* 121 */     boolean isParameterPublisher = Publisher.class.isAssignableFrom(parameter.getParameterType());
/* 122 */     if (isParameterPublisher) {
/* 123 */       ResolvableType resolvableType = ResolvableType.forMethodParameter(parameter);
/* 124 */       Class<?> genericType = resolvableType.resolveGeneric(new int[] { 0 });
/* 125 */       if (genericType == null) {
/* 126 */         return false;
/*     */       }
/* 128 */       typeToCheck = genericType;
/*     */     } 
/* 130 */     return !ClassUtils.isAssignable(typeToCheck, principal.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 143 */     this.useAnnotationTemplate = (templateDefaults != null);
/* 144 */     this.scanner = SecurityAnnotationScanners.requireUnique(AuthenticationPrincipal.class, templateDefaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationPrincipal findMethodAnnotation(MethodParameter parameter) {
/* 154 */     if (this.useAnnotationTemplate) {
/* 155 */       return (AuthenticationPrincipal)this.scanner.scan(parameter.getParameter());
/*     */     }
/* 157 */     AuthenticationPrincipal annotation = (AuthenticationPrincipal)parameter.getParameterAnnotation(this.annotationType);
/* 158 */     if (annotation != null) {
/* 159 */       return annotation;
/*     */     }
/* 161 */     Annotation[] annotationsToSearch = parameter.getParameterAnnotations();
/* 162 */     for (Annotation toSearch : annotationsToSearch) {
/* 163 */       annotation = (AuthenticationPrincipal)AnnotationUtils.findAnnotation(toSearch.annotationType(), this.annotationType);
/* 164 */       if (annotation != null) {
/* 165 */         return (AuthenticationPrincipal)MergedAnnotations.from(new Annotation[] { toSearch }).get(this.annotationType).synthesize();
/*     */       }
/*     */     } 
/* 168 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\reactive\result\method\annotation\AuthenticationPrincipalArgumentResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */