/*    */ package org.springframework.security.web.reactive.result.view;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.security.web.server.csrf.CsrfToken;
/*    */ import org.springframework.web.reactive.result.view.RequestDataValueProcessor;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsrfRequestDataValueProcessor
/*    */   implements RequestDataValueProcessor
/*    */ {
/*    */   public static final String DEFAULT_CSRF_ATTR_NAME = "_csrf";
/* 39 */   private static final Pattern DISABLE_CSRF_TOKEN_PATTERN = Pattern.compile("(?i)^(GET|HEAD|TRACE|OPTIONS)$");
/*    */   
/*    */   private static final String DISABLE_CSRF_TOKEN_ATTR = "DISABLE_CSRF_TOKEN_ATTR";
/*    */ 
/*    */   
/*    */   public String processAction(ServerWebExchange exchange, String action, String httpMethod) {
/* 45 */     if (httpMethod != null && DISABLE_CSRF_TOKEN_PATTERN.matcher(httpMethod).matches()) {
/* 46 */       exchange.getAttributes().put("DISABLE_CSRF_TOKEN_ATTR", Boolean.TRUE);
/*    */     } else {
/*    */       
/* 49 */       exchange.getAttributes().remove("DISABLE_CSRF_TOKEN_ATTR");
/*    */     } 
/* 51 */     return action;
/*    */   }
/*    */ 
/*    */   
/*    */   public String processFormFieldValue(ServerWebExchange exchange, String name, String value, String type) {
/* 56 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public Map<String, String> getExtraHiddenFields(ServerWebExchange exchange) {
/* 62 */     if (Boolean.TRUE.equals(exchange.getAttribute("DISABLE_CSRF_TOKEN_ATTR"))) {
/* 63 */       exchange.getAttributes().remove("DISABLE_CSRF_TOKEN_ATTR");
/* 64 */       return Collections.emptyMap();
/*    */     } 
/* 66 */     CsrfToken token = (CsrfToken)exchange.getAttribute("_csrf");
/* 67 */     if (token == null) {
/* 68 */       return Collections.emptyMap();
/*    */     }
/* 70 */     return Collections.singletonMap(token.getParameterName(), token.getToken());
/*    */   }
/*    */ 
/*    */   
/*    */   public String processUrl(ServerWebExchange exchange, String url) {
/* 75 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\reactive\result\view\CsrfRequestDataValueProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */