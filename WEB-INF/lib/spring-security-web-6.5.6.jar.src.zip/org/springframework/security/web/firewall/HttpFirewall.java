package org.springframework.security.web.firewall;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface HttpFirewall {
  FirewalledRequest getFirewalledRequest(HttpServletRequest paramHttpServletRequest) throws RequestRejectedException;
  
  HttpServletResponse getFirewalledResponse(HttpServletResponse paramHttpServletResponse);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\HttpFirewall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */