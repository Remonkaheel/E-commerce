/*    */ package org.springframework.security.web.firewall;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestRejectedException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 7226768874760909859L;
/*    */   
/*    */   public RequestRejectedException(String message) {
/* 30 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\RequestRejectedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */