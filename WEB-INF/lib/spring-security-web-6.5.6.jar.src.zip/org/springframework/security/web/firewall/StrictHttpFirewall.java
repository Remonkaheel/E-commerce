/*     */ package org.springframework.security.web.firewall;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrictHttpFirewall
/*     */   implements HttpFirewall
/*     */ {
/*  88 */   private static final Set<String> ALLOW_ANY_HTTP_METHOD = Collections.emptySet();
/*     */ 
/*     */   
/*     */   private static final String ENCODED_PERCENT = "%25";
/*     */   
/*     */   private static final String PERCENT = "%";
/*     */   
/*  95 */   private static final List<String> FORBIDDEN_ENCODED_PERIOD = Collections.unmodifiableList(Arrays.asList(new String[] { "%2e", "%2E" }));
/*     */ 
/*     */   
/*  98 */   private static final List<String> FORBIDDEN_SEMICOLON = Collections.unmodifiableList(Arrays.asList(new String[] { ";", "%3b", "%3B" }));
/*     */ 
/*     */   
/* 101 */   private static final List<String> FORBIDDEN_FORWARDSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "%2f", "%2F" }));
/*     */ 
/*     */   
/* 104 */   private static final List<String> FORBIDDEN_DOUBLE_FORWARDSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "//", "%2f%2f", "%2f%2F", "%2F%2f", "%2F%2F" }));
/*     */ 
/*     */   
/* 107 */   private static final List<String> FORBIDDEN_BACKSLASH = Collections.unmodifiableList(Arrays.asList(new String[] { "\\", "%5c", "%5C" }));
/*     */   
/* 109 */   private static final List<String> FORBIDDEN_NULL = Collections.unmodifiableList(Arrays.asList(new String[] { "\000", "%00" }));
/*     */   
/* 111 */   private static final List<String> FORBIDDEN_LF = Collections.unmodifiableList(Arrays.asList(new String[] { "\n", "%0a", "%0A" }));
/*     */   
/* 113 */   private static final List<String> FORBIDDEN_CR = Collections.unmodifiableList(Arrays.asList(new String[] { "\r", "%0d", "%0D" }));
/*     */   
/* 115 */   private static final List<String> FORBIDDEN_LINE_SEPARATOR = Collections.unmodifiableList(Arrays.asList(new String[] { " " }));
/*     */ 
/*     */   
/* 118 */   private static final List<String> FORBIDDEN_PARAGRAPH_SEPARATOR = Collections.unmodifiableList(Arrays.asList(new String[] { " " }));
/*     */   
/* 120 */   private Set<String> encodedUrlBlocklist = new HashSet<>();
/*     */   
/* 122 */   private Set<String> decodedUrlBlocklist = new HashSet<>();
/*     */   
/* 124 */   private Set<String> allowedHttpMethods = createDefaultAllowedHttpMethods();
/*     */ 
/*     */   
/*     */   private Predicate<String> allowedHostnames = hostname -> true;
/*     */   
/* 129 */   private static final Pattern ASSIGNED_AND_NOT_ISO_CONTROL_PATTERN = Pattern.compile("[\\p{IsAssigned}&&[^\\p{IsControl}]]*");
/*     */   static {
/* 131 */     ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE = (s -> ASSIGNED_AND_NOT_ISO_CONTROL_PATTERN.matcher(s).matches());
/*     */   }
/*     */   private static final Predicate<String> ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/* 134 */   private static final Pattern HEADER_VALUE_PATTERN = Pattern.compile("[\\p{IsAssigned}&&[[^\\p{IsControl}]||\\t]]*"); private static final Predicate<String> HEADER_VALUE_PREDICATE;
/*     */   static {
/* 136 */     HEADER_VALUE_PREDICATE = (s -> HEADER_VALUE_PATTERN.matcher(s).matches());
/*     */   }
/* 138 */   private Predicate<String> allowedHeaderNames = ALLOWED_HEADER_NAMES;
/*     */   
/* 140 */   public static final Predicate<String> ALLOWED_HEADER_NAMES = ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/*     */   
/* 142 */   private Predicate<String> allowedHeaderValues = ALLOWED_HEADER_VALUES;
/*     */   
/* 144 */   public static final Predicate<String> ALLOWED_HEADER_VALUES = HEADER_VALUE_PREDICATE;
/*     */   
/* 146 */   private Predicate<String> allowedParameterNames = ALLOWED_PARAMETER_NAMES;
/*     */   
/* 148 */   public static final Predicate<String> ALLOWED_PARAMETER_NAMES = ASSIGNED_AND_NOT_ISO_CONTROL_PREDICATE;
/*     */   
/* 150 */   private Predicate<String> allowedParameterValues = ALLOWED_PARAMETER_VALUES;
/*     */   
/*     */   public static final Predicate<String> ALLOWED_PARAMETER_VALUES = value -> true;
/*     */   
/*     */   public StrictHttpFirewall() {
/* 155 */     urlBlocklistsAddAll(FORBIDDEN_SEMICOLON);
/* 156 */     urlBlocklistsAddAll(FORBIDDEN_FORWARDSLASH);
/* 157 */     urlBlocklistsAddAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/* 158 */     urlBlocklistsAddAll(FORBIDDEN_BACKSLASH);
/* 159 */     urlBlocklistsAddAll(FORBIDDEN_NULL);
/* 160 */     urlBlocklistsAddAll(FORBIDDEN_LF);
/* 161 */     urlBlocklistsAddAll(FORBIDDEN_CR);
/*     */     
/* 163 */     this.encodedUrlBlocklist.add("%25");
/* 164 */     this.encodedUrlBlocklist.addAll(FORBIDDEN_ENCODED_PERIOD);
/* 165 */     this.decodedUrlBlocklist.add("%");
/* 166 */     this.decodedUrlBlocklist.addAll(FORBIDDEN_LINE_SEPARATOR);
/* 167 */     this.decodedUrlBlocklist.addAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnsafeAllowAnyHttpMethod(boolean unsafeAllowAnyHttpMethod) {
/* 181 */     this.allowedHttpMethods = unsafeAllowAnyHttpMethod ? ALLOW_ANY_HTTP_METHOD : createDefaultAllowedHttpMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHttpMethods(Collection<String> allowedHttpMethods) {
/* 195 */     Assert.notNull(allowedHttpMethods, "allowedHttpMethods cannot be null");
/* 196 */     this
/* 197 */       .allowedHttpMethods = (allowedHttpMethods != ALLOW_ANY_HTTP_METHOD) ? new HashSet<>(allowedHttpMethods) : ALLOW_ANY_HTTP_METHOD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowSemicolon(boolean allowSemicolon) {
/* 233 */     if (allowSemicolon) {
/* 234 */       urlBlocklistsRemoveAll(FORBIDDEN_SEMICOLON);
/*     */     } else {
/*     */       
/* 237 */       urlBlocklistsAddAll(FORBIDDEN_SEMICOLON);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedSlash(boolean allowUrlEncodedSlash) {
/* 256 */     if (allowUrlEncodedSlash) {
/* 257 */       urlBlocklistsRemoveAll(FORBIDDEN_FORWARDSLASH);
/*     */     } else {
/*     */       
/* 260 */       urlBlocklistsAddAll(FORBIDDEN_FORWARDSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedDoubleSlash(boolean allowUrlEncodedDoubleSlash) {
/* 273 */     if (allowUrlEncodedDoubleSlash) {
/* 274 */       urlBlocklistsRemoveAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/*     */     } else {
/*     */       
/* 277 */       urlBlocklistsAddAll(FORBIDDEN_DOUBLE_FORWARDSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedPeriod(boolean allowUrlEncodedPeriod) {
/* 298 */     if (allowUrlEncodedPeriod) {
/* 299 */       this.encodedUrlBlocklist.removeAll(FORBIDDEN_ENCODED_PERIOD);
/*     */     } else {
/*     */       
/* 302 */       this.encodedUrlBlocklist.addAll(FORBIDDEN_ENCODED_PERIOD);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowBackSlash(boolean allowBackSlash) {
/* 323 */     if (allowBackSlash) {
/* 324 */       urlBlocklistsRemoveAll(FORBIDDEN_BACKSLASH);
/*     */     } else {
/*     */       
/* 327 */       urlBlocklistsAddAll(FORBIDDEN_BACKSLASH);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowNull(boolean allowNull) {
/* 342 */     if (allowNull) {
/* 343 */       urlBlocklistsRemoveAll(FORBIDDEN_NULL);
/*     */     } else {
/*     */       
/* 346 */       urlBlocklistsAddAll(FORBIDDEN_NULL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedPercent(boolean allowUrlEncodedPercent) {
/* 364 */     if (allowUrlEncodedPercent) {
/* 365 */       this.encodedUrlBlocklist.remove("%25");
/* 366 */       this.decodedUrlBlocklist.remove("%");
/*     */     } else {
/*     */       
/* 369 */       this.encodedUrlBlocklist.add("%25");
/* 370 */       this.decodedUrlBlocklist.add("%");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedCarriageReturn(boolean allowUrlEncodedCarriageReturn) {
/* 382 */     if (allowUrlEncodedCarriageReturn) {
/* 383 */       urlBlocklistsRemoveAll(FORBIDDEN_CR);
/*     */     } else {
/*     */       
/* 386 */       urlBlocklistsAddAll(FORBIDDEN_CR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedLineFeed(boolean allowUrlEncodedLineFeed) {
/* 397 */     if (allowUrlEncodedLineFeed) {
/* 398 */       urlBlocklistsRemoveAll(FORBIDDEN_LF);
/*     */     } else {
/*     */       
/* 401 */       urlBlocklistsAddAll(FORBIDDEN_LF);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedParagraphSeparator(boolean allowUrlEncodedParagraphSeparator) {
/* 413 */     if (allowUrlEncodedParagraphSeparator) {
/* 414 */       this.decodedUrlBlocklist.removeAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */     } else {
/*     */       
/* 417 */       this.decodedUrlBlocklist.addAll(FORBIDDEN_PARAGRAPH_SEPARATOR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedLineSeparator(boolean allowUrlEncodedLineSeparator) {
/* 429 */     if (allowUrlEncodedLineSeparator) {
/* 430 */       this.decodedUrlBlocklist.removeAll(FORBIDDEN_LINE_SEPARATOR);
/*     */     } else {
/*     */       
/* 433 */       this.decodedUrlBlocklist.addAll(FORBIDDEN_LINE_SEPARATOR);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHeaderNames(Predicate<String> allowedHeaderNames) {
/* 448 */     Assert.notNull(allowedHeaderNames, "allowedHeaderNames cannot be null");
/* 449 */     this.allowedHeaderNames = allowedHeaderNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHeaderValues(Predicate<String> allowedHeaderValues) {
/* 463 */     Assert.notNull(allowedHeaderValues, "allowedHeaderValues cannot be null");
/* 464 */     this.allowedHeaderValues = allowedHeaderValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedParameterNames(Predicate<String> allowedParameterNames) {
/* 476 */     Assert.notNull(allowedParameterNames, "allowedParameterNames cannot be null");
/* 477 */     this.allowedParameterNames = allowedParameterNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedParameterValues(Predicate<String> allowedParameterValues) {
/* 489 */     Assert.notNull(allowedParameterValues, "allowedParameterValues cannot be null");
/* 490 */     this.allowedParameterValues = allowedParameterValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedHostnames(Predicate<String> allowedHostnames) {
/* 501 */     Assert.notNull(allowedHostnames, "allowedHostnames cannot be null");
/* 502 */     this.allowedHostnames = allowedHostnames;
/*     */   }
/*     */   
/*     */   private void urlBlocklistsAddAll(Collection<String> values) {
/* 506 */     this.encodedUrlBlocklist.addAll(values);
/* 507 */     this.decodedUrlBlocklist.addAll(values);
/*     */   }
/*     */   
/*     */   private void urlBlocklistsRemoveAll(Collection<String> values) {
/* 511 */     this.encodedUrlBlocklist.removeAll(values);
/* 512 */     this.decodedUrlBlocklist.removeAll(values);
/*     */   }
/*     */ 
/*     */   
/*     */   public FirewalledRequest getFirewalledRequest(HttpServletRequest request) throws RequestRejectedException {
/* 517 */     rejectForbiddenHttpMethod(request);
/* 518 */     rejectedBlocklistedUrls(request);
/* 519 */     rejectedUntrustedHosts(request);
/* 520 */     if (!isNormalized(request)) {
/* 521 */       throw new RequestRejectedException("The request was rejected because the URL was not normalized.");
/*     */     }
/* 523 */     rejectNonPrintableAsciiCharactersInFieldName(request.getRequestURI(), "requestURI");
/* 524 */     return new StrictFirewalledRequest(request);
/*     */   }
/*     */   
/*     */   private void rejectNonPrintableAsciiCharactersInFieldName(String toCheck, String propertyName) {
/* 528 */     if (!containsOnlyPrintableAsciiCharacters(toCheck)) {
/* 529 */       throw new RequestRejectedException(
/* 530 */           String.format("The %s was rejected because it can only contain printable ASCII characters.", new Object[] { propertyName }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void rejectForbiddenHttpMethod(HttpServletRequest request) {
/* 535 */     if (this.allowedHttpMethods == ALLOW_ANY_HTTP_METHOD) {
/*     */       return;
/*     */     }
/* 538 */     if (!this.allowedHttpMethods.contains(request.getMethod())) {
/* 539 */       throw new RequestRejectedException("The request was rejected because the HTTP method \"" + request
/* 540 */           .getMethod() + "\" was not included within the list of allowed HTTP methods " + String.valueOf(this.allowedHttpMethods));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void rejectedBlocklistedUrls(HttpServletRequest request) {
/* 546 */     for (String forbidden : this.encodedUrlBlocklist) {
/* 547 */       if (encodedUrlContains(request, forbidden)) {
/* 548 */         throw new RequestRejectedException("The request was rejected because the URL contained a potentially malicious String \"" + forbidden + "\"");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 553 */     for (String forbidden : this.decodedUrlBlocklist) {
/* 554 */       if (decodedUrlContains(request, forbidden)) {
/* 555 */         throw new RequestRejectedException("The request was rejected because the URL contained a potentially malicious String \"" + forbidden + "\"");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void rejectedUntrustedHosts(HttpServletRequest request) {
/* 563 */     String serverName = request.getServerName();
/* 564 */     if (serverName != null && !this.allowedHostnames.test(serverName)) {
/* 565 */       throw new RequestRejectedException("The request was rejected because the domain " + serverName + " is untrusted.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletResponse getFirewalledResponse(HttpServletResponse response) {
/* 572 */     return (HttpServletResponse)new FirewalledResponse(response);
/*     */   }
/*     */   
/*     */   private static Set<String> createDefaultAllowedHttpMethods() {
/* 576 */     Set<String> result = new HashSet<>();
/* 577 */     result.add(HttpMethod.DELETE.name());
/* 578 */     result.add(HttpMethod.GET.name());
/* 579 */     result.add(HttpMethod.HEAD.name());
/* 580 */     result.add(HttpMethod.OPTIONS.name());
/* 581 */     result.add(HttpMethod.PATCH.name());
/* 582 */     result.add(HttpMethod.POST.name());
/* 583 */     result.add(HttpMethod.PUT.name());
/* 584 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean isNormalized(HttpServletRequest request) {
/* 588 */     if (!isNormalized(request.getRequestURI())) {
/* 589 */       return false;
/*     */     }
/* 591 */     if (!isNormalized(request.getContextPath())) {
/* 592 */       return false;
/*     */     }
/* 594 */     if (!isNormalized(request.getServletPath())) {
/* 595 */       return false;
/*     */     }
/* 597 */     if (!isNormalized(request.getPathInfo())) {
/* 598 */       return false;
/*     */     }
/* 600 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean encodedUrlContains(HttpServletRequest request, String value) {
/* 604 */     if (valueContains(request.getContextPath(), value)) {
/* 605 */       return true;
/*     */     }
/* 607 */     return valueContains(request.getRequestURI(), value);
/*     */   }
/*     */   
/*     */   private static boolean decodedUrlContains(HttpServletRequest request, String value) {
/* 611 */     if (valueContains(request.getServletPath(), value)) {
/* 612 */       return true;
/*     */     }
/* 614 */     return valueContains(request.getPathInfo(), value);
/*     */   }
/*     */   
/*     */   private static boolean containsOnlyPrintableAsciiCharacters(String uri) {
/* 618 */     if (uri == null) {
/* 619 */       return true;
/*     */     }
/* 621 */     int length = uri.length();
/* 622 */     for (int i = 0; i < length; i++) {
/* 623 */       char ch = uri.charAt(i);
/* 624 */       if (ch < ' ' || ch > '~') {
/* 625 */         return false;
/*     */       }
/*     */     } 
/* 628 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean valueContains(String value, String contains) {
/* 632 */     return (value != null && value.contains(contains));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNormalized(String path) {
/* 642 */     if (path == null) {
/* 643 */       return true;
/*     */     }
/* 645 */     for (int i = path.length(); i > 0; ) {
/* 646 */       int slashIndex = path.lastIndexOf('/', i - 1);
/* 647 */       int gap = i - slashIndex;
/* 648 */       if (gap == 2 && path.charAt(slashIndex + 1) == '.') {
/* 649 */         return false;
/*     */       }
/* 651 */       if (gap == 3 && path.charAt(slashIndex + 1) == '.' && path.charAt(slashIndex + 2) == '.') {
/* 652 */         return false;
/*     */       }
/* 654 */       i = slashIndex;
/*     */     } 
/* 656 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getEncodedUrlBlocklist() {
/* 664 */     return this.encodedUrlBlocklist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getDecodedUrlBlocklist() {
/* 672 */     return this.decodedUrlBlocklist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Set<String> getEncodedUrlBlacklist() {
/* 682 */     return getEncodedUrlBlocklist();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getDecodedUrlBlacklist() {
/* 691 */     return getDecodedUrlBlocklist();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class StrictFirewalledRequest
/*     */     extends FirewalledRequest
/*     */   {
/*     */     StrictFirewalledRequest(HttpServletRequest request) {
/* 700 */       super(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public long getDateHeader(String name) {
/* 705 */       if (name != null) {
/* 706 */         validateAllowedHeaderName(name);
/*     */       }
/* 708 */       return super.getDateHeader(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIntHeader(String name) {
/* 713 */       if (name != null) {
/* 714 */         validateAllowedHeaderName(name);
/*     */       }
/* 716 */       return super.getIntHeader(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeader(String name) {
/* 721 */       if (name != null) {
/* 722 */         validateAllowedHeaderName(name);
/*     */       }
/* 724 */       String value = super.getHeader(name);
/* 725 */       if (value != null) {
/* 726 */         validateAllowedHeaderValue(name, value);
/*     */       }
/* 728 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getHeaders(final String name) {
/* 733 */       if (name != null) {
/* 734 */         validateAllowedHeaderName(name);
/*     */       }
/* 736 */       final Enumeration<String> headers = super.getHeaders(name);
/* 737 */       return new Enumeration<String>()
/*     */         {
/*     */           public boolean hasMoreElements()
/*     */           {
/* 741 */             return headers.hasMoreElements();
/*     */           }
/*     */ 
/*     */           
/*     */           public String nextElement() {
/* 746 */             String value = headers.nextElement();
/* 747 */             StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderValue(name, value);
/* 748 */             return value;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<String> getHeaderNames() {
/* 756 */       final Enumeration<String> names = super.getHeaderNames();
/* 757 */       return new Enumeration<String>()
/*     */         {
/*     */           public boolean hasMoreElements()
/*     */           {
/* 761 */             return names.hasMoreElements();
/*     */           }
/*     */ 
/*     */           
/*     */           public String nextElement() {
/* 766 */             String headerNames = names.nextElement();
/* 767 */             StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderName(headerNames);
/* 768 */             return headerNames;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getParameter(String name) {
/* 776 */       if (name != null) {
/* 777 */         validateAllowedParameterName(name);
/*     */       }
/* 779 */       String value = super.getParameter(name);
/* 780 */       if (value != null) {
/* 781 */         validateAllowedParameterValue(name, value);
/*     */       }
/* 783 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, String[]> getParameterMap() {
/* 788 */       Map<String, String[]> parameterMap = super.getParameterMap();
/* 789 */       for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
/* 790 */         String name = entry.getKey();
/* 791 */         String[] values = entry.getValue();
/* 792 */         validateAllowedParameterName(name);
/* 793 */         for (String value : values) {
/* 794 */           validateAllowedParameterValue(name, value);
/*     */         }
/*     */       } 
/* 797 */       return parameterMap;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getParameterNames() {
/* 802 */       final Enumeration<String> paramaterNames = super.getParameterNames();
/* 803 */       return new Enumeration<String>()
/*     */         {
/*     */           public boolean hasMoreElements()
/*     */           {
/* 807 */             return paramaterNames.hasMoreElements();
/*     */           }
/*     */ 
/*     */           
/*     */           public String nextElement() {
/* 812 */             String name = paramaterNames.nextElement();
/* 813 */             StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedParameterName(name);
/* 814 */             return name;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getParameterValues(String name) {
/* 822 */       if (name != null) {
/* 823 */         validateAllowedParameterName(name);
/*     */       }
/* 825 */       String[] values = super.getParameterValues(name);
/* 826 */       if (values != null) {
/* 827 */         for (String value : values) {
/* 828 */           validateAllowedParameterValue(name, value);
/*     */         }
/*     */       }
/* 831 */       return values;
/*     */     }
/*     */     
/*     */     private void validateAllowedHeaderName(String headerNames) {
/* 835 */       if (!StrictHttpFirewall.this.allowedHeaderNames.test(headerNames)) {
/* 836 */         throw new RequestRejectedException("The request was rejected because the header name \"" + headerNames + "\" is not allowed.");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void validateAllowedHeaderValue(String name, String value) {
/* 842 */       if (!StrictHttpFirewall.this.allowedHeaderValues.test(value)) {
/* 843 */         throw new RequestRejectedException("The request was rejected because the header: \"" + name + " \" has a value \"" + value + "\" that is not allowed.");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void validateAllowedParameterName(String name) {
/* 849 */       if (!StrictHttpFirewall.this.allowedParameterNames.test(name)) {
/* 850 */         throw new RequestRejectedException("The request was rejected because the parameter name \"" + name + "\" is not allowed.");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void validateAllowedParameterValue(String name, String value) {
/* 856 */       if (!StrictHttpFirewall.this.allowedParameterValues.test(value))
/* 857 */         throw new RequestRejectedException("The request was rejected because the parameter: \"" + name + " \" has a value \"" + value + "\" that is not allowed."); 
/*     */     }
/*     */     
/*     */     public void reset() {}
/*     */   }
/*     */   
/*     */   class null implements Enumeration<String> {
/*     */     public boolean hasMoreElements() {
/*     */       return headers.hasMoreElements();
/*     */     }
/*     */     
/*     */     public String nextElement() {
/*     */       String value = headers.nextElement();
/*     */       StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderValue(name, value);
/*     */       return value;
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Enumeration<String> {
/*     */     public boolean hasMoreElements() {
/*     */       return names.hasMoreElements();
/*     */     }
/*     */     
/*     */     public String nextElement() {
/*     */       String headerNames = names.nextElement();
/*     */       StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderName(headerNames);
/*     */       return headerNames;
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Enumeration<String> {
/*     */     public boolean hasMoreElements() {
/*     */       return paramaterNames.hasMoreElements();
/*     */     }
/*     */     
/*     */     public String nextElement() {
/*     */       String name = paramaterNames.nextElement();
/*     */       StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedParameterName(name);
/*     */       return name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\StrictHttpFirewall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */