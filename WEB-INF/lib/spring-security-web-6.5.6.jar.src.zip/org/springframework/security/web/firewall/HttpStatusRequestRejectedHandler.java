/*    */ package org.springframework.security.web.firewall;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpStatusRequestRejectedHandler
/*    */   implements RequestRejectedHandler
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(HttpStatusRequestRejectedHandler.class);
/*    */ 
/*    */   
/*    */   private final int httpError;
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusRequestRejectedHandler() {
/* 45 */     this.httpError = 400;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpStatusRequestRejectedHandler(int httpError) {
/* 53 */     this.httpError = httpError;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, RequestRejectedException requestRejectedException) throws IOException {
/* 59 */     logger.debug(LogMessage.format("Rejecting request due to: %s", requestRejectedException.getMessage()), requestRejectedException);
/*    */     
/* 61 */     response.sendError(this.httpError);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\HttpStatusRequestRejectedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */