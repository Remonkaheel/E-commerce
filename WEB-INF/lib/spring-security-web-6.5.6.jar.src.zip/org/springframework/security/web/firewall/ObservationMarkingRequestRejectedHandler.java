/*    */ package org.springframework.security.web.firewall;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObservationMarkingRequestRejectedHandler
/*    */   implements RequestRejectedHandler
/*    */ {
/*    */   private final ObservationRegistry registry;
/*    */   
/*    */   public ObservationMarkingRequestRejectedHandler(ObservationRegistry registry) {
/* 32 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, RequestRejectedException exception) throws IOException, ServletException {
/* 38 */     Observation observation = this.registry.getCurrentObservation();
/* 39 */     if (observation != null)
/* 40 */       observation.error(exception); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\ObservationMarkingRequestRejectedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */