/*    */ package org.springframework.security.web.firewall;
/*    */ 
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompositeRequestRejectedHandler
/*    */   implements RequestRejectedHandler
/*    */ {
/*    */   private final List<RequestRejectedHandler> requestRejectedhandlers;
/*    */   
/*    */   public CompositeRequestRejectedHandler(RequestRejectedHandler... requestRejectedhandlers) {
/* 46 */     Assert.notEmpty((Object[])requestRejectedhandlers, "requestRejectedhandlers cannot be empty");
/* 47 */     this.requestRejectedhandlers = Arrays.asList(requestRejectedhandlers);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(HttpServletRequest request, HttpServletResponse response, RequestRejectedException requestRejectedException) throws IOException, ServletException {
/* 53 */     for (RequestRejectedHandler requestRejectedhandler : this.requestRejectedhandlers)
/* 54 */       requestRejectedhandler.handle(request, response, requestRejectedException); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\CompositeRequestRejectedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */