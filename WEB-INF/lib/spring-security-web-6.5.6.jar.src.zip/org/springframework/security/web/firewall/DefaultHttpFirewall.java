/*     */ package org.springframework.security.web.firewall;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttpFirewall
/*     */   implements HttpFirewall
/*     */ {
/*     */   private boolean allowUrlEncodedSlash;
/*     */   
/*     */   public FirewalledRequest getFirewalledRequest(HttpServletRequest request) throws RequestRejectedException {
/*  53 */     FirewalledRequest firewalledRequest = new RequestWrapper(request);
/*  54 */     if (!isNormalized(firewalledRequest.getServletPath()) || !isNormalized(firewalledRequest.getPathInfo())) {
/*  55 */       throw new RequestRejectedException("Un-normalized paths are not supported: " + firewalledRequest
/*  56 */           .getServletPath() + (
/*  57 */           (firewalledRequest.getPathInfo() != null) ? firewalledRequest.getPathInfo() : ""));
/*     */     }
/*  59 */     String requestURI = firewalledRequest.getRequestURI();
/*  60 */     if (containsInvalidUrlEncodedSlash(requestURI)) {
/*  61 */       throw new RequestRejectedException("The requestURI cannot contain encoded slash. Got " + requestURI);
/*     */     }
/*  63 */     return firewalledRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletResponse getFirewalledResponse(HttpServletResponse response) {
/*  68 */     return (HttpServletResponse)new FirewalledResponse(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUrlEncodedSlash(boolean allowUrlEncodedSlash) {
/*  83 */     this.allowUrlEncodedSlash = allowUrlEncodedSlash;
/*     */   }
/*     */   
/*     */   private boolean containsInvalidUrlEncodedSlash(String uri) {
/*  87 */     if (this.allowUrlEncodedSlash || uri == null) {
/*  88 */       return false;
/*     */     }
/*  90 */     return (uri.contains("%2f") || uri.contains("%2F"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isNormalized(String path) {
/* 100 */     if (path == null) {
/* 101 */       return true;
/*     */     }
/* 103 */     for (int i = path.length(); i > 0; ) {
/* 104 */       int slashIndex = path.lastIndexOf('/', i - 1);
/* 105 */       int gap = i - slashIndex;
/* 106 */       if (gap == 2 && path.charAt(slashIndex + 1) == '.')
/*     */       {
/* 108 */         return false;
/*     */       }
/* 110 */       if (gap == 3 && path.charAt(slashIndex + 1) == '.' && path.charAt(slashIndex + 2) == '.') {
/* 111 */         return false;
/*     */       }
/* 113 */       i = slashIndex;
/*     */     } 
/* 115 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\DefaultHttpFirewall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */