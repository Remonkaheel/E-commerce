/*     */ package org.springframework.security.web.firewall;
/*     */ 
/*     */ import jakarta.servlet.RequestDispatcher;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RequestWrapper
/*     */   extends FirewalledRequest
/*     */ {
/*     */   private final String strippedServletPath;
/*     */   private final String strippedPathInfo;
/*     */   private boolean stripPaths = true;
/*     */   
/*     */   RequestWrapper(HttpServletRequest request) {
/*  56 */     super(request);
/*  57 */     this.strippedServletPath = strip(request.getServletPath());
/*  58 */     String pathInfo = strip(request.getPathInfo());
/*  59 */     if (pathInfo != null && pathInfo.length() == 0) {
/*  60 */       pathInfo = null;
/*     */     }
/*  62 */     this.strippedPathInfo = pathInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String strip(String path) {
/*  74 */     if (path == null) {
/*  75 */       return null;
/*     */     }
/*  77 */     int semicolonIndex = path.indexOf(';');
/*  78 */     if (semicolonIndex < 0) {
/*  79 */       int doubleSlashIndex = path.indexOf("//");
/*  80 */       if (doubleSlashIndex < 0)
/*     */       {
/*     */         
/*  83 */         return path;
/*     */       }
/*     */     } 
/*  86 */     StringTokenizer tokenizer = new StringTokenizer(path, "/");
/*  87 */     StringBuilder stripped = new StringBuilder(path.length());
/*  88 */     if (path.charAt(0) == '/') {
/*  89 */       stripped.append('/');
/*     */     }
/*  91 */     while (tokenizer.hasMoreTokens()) {
/*  92 */       String segment = tokenizer.nextToken();
/*  93 */       semicolonIndex = segment.indexOf(';');
/*  94 */       if (semicolonIndex >= 0) {
/*  95 */         segment = segment.substring(0, semicolonIndex);
/*     */       }
/*  97 */       stripped.append(segment).append('/');
/*     */     } 
/*     */     
/* 100 */     if (path.charAt(path.length() - 1) != '/') {
/* 101 */       stripped.deleteCharAt(stripped.length() - 1);
/*     */     }
/* 103 */     return stripped.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPathInfo() {
/* 108 */     return this.stripPaths ? this.strippedPathInfo : super.getPathInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServletPath() {
/* 113 */     return this.stripPaths ? this.strippedServletPath : super.getServletPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public RequestDispatcher getRequestDispatcher(String path) {
/* 118 */     return this.stripPaths ? new FirewalledRequestAwareRequestDispatcher(path) : super.getRequestDispatcher(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 123 */     this.stripPaths = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class FirewalledRequestAwareRequestDispatcher
/*     */     implements RequestDispatcher
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FirewalledRequestAwareRequestDispatcher(String path) {
/* 142 */       this.path = path;
/*     */     }
/*     */ 
/*     */     
/*     */     public void forward(ServletRequest request, ServletResponse response) throws ServletException, IOException {
/* 147 */       RequestWrapper.this.reset();
/* 148 */       getDelegateDispatcher().forward(request, response);
/*     */     }
/*     */ 
/*     */     
/*     */     public void include(ServletRequest request, ServletResponse response) throws ServletException, IOException {
/* 153 */       getDelegateDispatcher().include(request, response);
/*     */     }
/*     */     
/*     */     private RequestDispatcher getDelegateDispatcher() {
/* 157 */       return RequestWrapper.this.getRequestDispatcher(this.path);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\RequestWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */