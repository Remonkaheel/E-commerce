/*    */ package org.springframework.security.web.firewall;
/*    */ 
/*    */ import jakarta.servlet.http.Cookie;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import jakarta.servlet.http.HttpServletResponseWrapper;
/*    */ import java.io.IOException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FirewalledResponse
/*    */   extends HttpServletResponseWrapper
/*    */ {
/*    */   private static final String LOCATION_HEADER = "Location";
/*    */   private static final String SET_COOKIE_HEADER = "Set-Cookie";
/*    */   
/*    */   FirewalledResponse(HttpServletResponse response) {
/* 40 */     super(response);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendRedirect(String location) throws IOException {
/* 47 */     validateCrlf("Location", location);
/* 48 */     super.sendRedirect(location);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setHeader(String name, String value) {
/* 53 */     validateCrlf(name, value);
/* 54 */     super.setHeader(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addHeader(String name, String value) {
/* 59 */     validateCrlf(name, value);
/* 60 */     super.addHeader(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCookie(Cookie cookie) {
/* 65 */     if (cookie != null) {
/* 66 */       validateCrlf("Set-Cookie", cookie.getName());
/* 67 */       validateCrlf("Set-Cookie", cookie.getValue());
/* 68 */       validateCrlf("Set-Cookie", cookie.getPath());
/* 69 */       validateCrlf("Set-Cookie", cookie.getDomain());
/* 70 */       validateCrlf("Set-Cookie", cookie.getComment());
/*    */     } 
/* 72 */     super.addCookie(cookie);
/*    */   }
/*    */   
/*    */   void validateCrlf(String name, String value) {
/* 76 */     Assert.isTrue((!hasCrlf(name) && !hasCrlf(value)), () -> "Invalid characters (CR/LF) in header " + name);
/*    */   }
/*    */   
/*    */   private boolean hasCrlf(String value) {
/* 80 */     return (value != null && (value.indexOf('\n') != -1 || value.indexOf('\r') != -1));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\FirewalledResponse.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */