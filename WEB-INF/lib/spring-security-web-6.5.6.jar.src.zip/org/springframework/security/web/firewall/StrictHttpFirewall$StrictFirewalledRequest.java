/*     */ package org.springframework.security.web.firewall;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StrictFirewalledRequest
/*     */   extends FirewalledRequest
/*     */ {
/*     */   StrictFirewalledRequest(HttpServletRequest request) {
/* 700 */     super(request);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getDateHeader(String name) {
/* 705 */     if (name != null) {
/* 706 */       validateAllowedHeaderName(name);
/*     */     }
/* 708 */     return super.getDateHeader(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntHeader(String name) {
/* 713 */     if (name != null) {
/* 714 */       validateAllowedHeaderName(name);
/*     */     }
/* 716 */     return super.getIntHeader(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeader(String name) {
/* 721 */     if (name != null) {
/* 722 */       validateAllowedHeaderName(name);
/*     */     }
/* 724 */     String value = super.getHeader(name);
/* 725 */     if (value != null) {
/* 726 */       validateAllowedHeaderValue(name, value);
/*     */     }
/* 728 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaders(final String name) {
/* 733 */     if (name != null) {
/* 734 */       validateAllowedHeaderName(name);
/*     */     }
/* 736 */     final Enumeration<String> headers = super.getHeaders(name);
/* 737 */     return new Enumeration<String>()
/*     */       {
/*     */         public boolean hasMoreElements()
/*     */         {
/* 741 */           return headers.hasMoreElements();
/*     */         }
/*     */ 
/*     */         
/*     */         public String nextElement() {
/* 746 */           String value = headers.nextElement();
/* 747 */           StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderValue(name, value);
/* 748 */           return value;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaderNames() {
/* 756 */     final Enumeration<String> names = super.getHeaderNames();
/* 757 */     return new Enumeration<String>()
/*     */       {
/*     */         public boolean hasMoreElements()
/*     */         {
/* 761 */           return names.hasMoreElements();
/*     */         }
/*     */ 
/*     */         
/*     */         public String nextElement() {
/* 766 */           String headerNames = names.nextElement();
/* 767 */           StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedHeaderName(headerNames);
/* 768 */           return headerNames;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 776 */     if (name != null) {
/* 777 */       validateAllowedParameterName(name);
/*     */     }
/* 779 */     String value = super.getParameter(name);
/* 780 */     if (value != null) {
/* 781 */       validateAllowedParameterValue(name, value);
/*     */     }
/* 783 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getParameterMap() {
/* 788 */     Map<String, String[]> parameterMap = super.getParameterMap();
/* 789 */     for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
/* 790 */       String name = entry.getKey();
/* 791 */       String[] values = entry.getValue();
/* 792 */       validateAllowedParameterName(name);
/* 793 */       for (String value : values) {
/* 794 */         validateAllowedParameterValue(name, value);
/*     */       }
/*     */     } 
/* 797 */     return parameterMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getParameterNames() {
/* 802 */     final Enumeration<String> paramaterNames = super.getParameterNames();
/* 803 */     return new Enumeration<String>()
/*     */       {
/*     */         public boolean hasMoreElements()
/*     */         {
/* 807 */           return paramaterNames.hasMoreElements();
/*     */         }
/*     */ 
/*     */         
/*     */         public String nextElement() {
/* 812 */           String name = paramaterNames.nextElement();
/* 813 */           StrictHttpFirewall.StrictFirewalledRequest.this.validateAllowedParameterName(name);
/* 814 */           return name;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 822 */     if (name != null) {
/* 823 */       validateAllowedParameterName(name);
/*     */     }
/* 825 */     String[] values = super.getParameterValues(name);
/* 826 */     if (values != null) {
/* 827 */       for (String value : values) {
/* 828 */         validateAllowedParameterValue(name, value);
/*     */       }
/*     */     }
/* 831 */     return values;
/*     */   }
/*     */   
/*     */   private void validateAllowedHeaderName(String headerNames) {
/* 835 */     if (!StrictHttpFirewall.this.allowedHeaderNames.test(headerNames)) {
/* 836 */       throw new RequestRejectedException("The request was rejected because the header name \"" + headerNames + "\" is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedHeaderValue(String name, String value) {
/* 842 */     if (!StrictHttpFirewall.this.allowedHeaderValues.test(value)) {
/* 843 */       throw new RequestRejectedException("The request was rejected because the header: \"" + name + " \" has a value \"" + value + "\" that is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedParameterName(String name) {
/* 849 */     if (!StrictHttpFirewall.this.allowedParameterNames.test(name)) {
/* 850 */       throw new RequestRejectedException("The request was rejected because the parameter name \"" + name + "\" is not allowed.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAllowedParameterValue(String name, String value) {
/* 856 */     if (!StrictHttpFirewall.this.allowedParameterValues.test(value))
/* 857 */       throw new RequestRejectedException("The request was rejected because the parameter: \"" + name + " \" has a value \"" + value + "\" that is not allowed."); 
/*     */   }
/*     */   
/*     */   public void reset() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\firewall\StrictHttpFirewall$StrictFirewalledRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */