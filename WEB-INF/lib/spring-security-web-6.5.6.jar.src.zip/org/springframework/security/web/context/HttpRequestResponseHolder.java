/*    */ package org.springframework.security.web.context;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class HttpRequestResponseHolder
/*    */ {
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   
/*    */   public HttpRequestResponseHolder(HttpServletRequest request, HttpServletResponse response) {
/* 41 */     this.request = request;
/* 42 */     this.response = response;
/*    */   }
/*    */   
/*    */   public HttpServletRequest getRequest() {
/* 46 */     return this.request;
/*    */   }
/*    */   
/*    */   public void setRequest(HttpServletRequest request) {
/* 50 */     this.request = request;
/*    */   }
/*    */   
/*    */   public HttpServletResponse getResponse() {
/* 54 */     return this.response;
/*    */   }
/*    */   
/*    */   public void setResponse(HttpServletResponse response) {
/* 58 */     this.response = response;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\HttpRequestResponseHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */