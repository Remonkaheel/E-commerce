/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterRegistration;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.SessionTrackingMode;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import java.util.EventListener;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.WebApplicationInitializer;
/*     */ import org.springframework.web.context.ContextLoaderListener;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
/*     */ import org.springframework.web.filter.DelegatingFilterProxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSecurityWebApplicationInitializer
/*     */   implements WebApplicationInitializer
/*     */ {
/*     */   private static final String SERVLET_CONTEXT_PREFIX = "org.springframework.web.servlet.FrameworkServlet.CONTEXT.";
/*     */   public static final String DEFAULT_FILTER_NAME = "springSecurityFilterChain";
/*     */   private final Class<?>[] configurationClasses;
/*     */   
/*     */   protected AbstractSecurityWebApplicationInitializer() {
/*  91 */     this.configurationClasses = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractSecurityWebApplicationInitializer(Class<?>... configurationClasses) {
/* 100 */     this.configurationClasses = configurationClasses;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onStartup(ServletContext servletContext) {
/* 105 */     beforeSpringSecurityFilterChain(servletContext);
/* 106 */     if (this.configurationClasses != null) {
/* 107 */       AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
/* 108 */       rootAppContext.register(this.configurationClasses);
/* 109 */       servletContext.addListener((EventListener)new ContextLoaderListener((WebApplicationContext)rootAppContext));
/*     */     } 
/* 111 */     if (enableHttpSessionEventPublisher()) {
/* 112 */       servletContext.addListener("org.springframework.security.web.session.HttpSessionEventPublisher");
/*     */     }
/* 114 */     servletContext.setSessionTrackingModes(getSessionTrackingModes());
/* 115 */     insertSpringSecurityFilterChain(servletContext);
/* 116 */     afterSpringSecurityFilterChain(servletContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean enableHttpSessionEventPublisher() {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertSpringSecurityFilterChain(ServletContext servletContext) {
/* 134 */     String filterName = "springSecurityFilterChain";
/* 135 */     DelegatingFilterProxy springSecurityFilterChain = new DelegatingFilterProxy(filterName);
/* 136 */     String contextAttribute = getWebApplicationContextAttribute();
/* 137 */     if (contextAttribute != null) {
/* 138 */       springSecurityFilterChain.setContextAttribute(contextAttribute);
/*     */     }
/* 140 */     registerFilter(servletContext, true, filterName, (Filter)springSecurityFilterChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void insertFilters(ServletContext servletContext, Filter... filters) {
/* 151 */     registerFilters(servletContext, true, filters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void appendFilters(ServletContext servletContext, Filter... filters) {
/* 162 */     registerFilters(servletContext, false, filters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerFilters(ServletContext servletContext, boolean insertBeforeOtherFilters, Filter... filters) {
/* 175 */     Assert.notEmpty((Object[])filters, "filters cannot be null or empty");
/* 176 */     for (Filter filter : filters) {
/* 177 */       Assert.notNull(filter, () -> "filters cannot contain null values. Got " + String.valueOf(Arrays.asList(filters)));
/* 178 */       String filterName = Conventions.getVariableName(filter);
/* 179 */       registerFilter(servletContext, insertBeforeOtherFilters, filterName, filter);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerFilter(ServletContext servletContext, boolean insertBeforeOtherFilters, String filterName, Filter filter) {
/* 194 */     FilterRegistration.Dynamic registration = servletContext.addFilter(filterName, filter);
/* 195 */     Assert.state((registration != null), () -> "Duplicate Filter registration for '" + filterName + "'. Check to ensure the Filter is only configured once.");
/*     */     
/* 197 */     registration.setAsyncSupported(isAsyncSecuritySupported());
/* 198 */     EnumSet<DispatcherType> dispatcherTypes = getSecurityDispatcherTypes();
/* 199 */     registration.addMappingForUrlPatterns(dispatcherTypes, !insertBeforeOtherFilters, new String[] { "/*" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getWebApplicationContextAttribute() {
/* 216 */     String dispatcherServletName = getDispatcherWebApplicationContextSuffix();
/* 217 */     if (dispatcherServletName == null) {
/* 218 */       return null;
/*     */     }
/* 220 */     return "org.springframework.web.servlet.FrameworkServlet.CONTEXT." + dispatcherServletName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<SessionTrackingMode> getSessionTrackingModes() {
/* 240 */     return EnumSet.of(SessionTrackingMode.COOKIE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDispatcherWebApplicationContextSuffix() {
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeSpringSecurityFilterChain(ServletContext servletContext) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterSpringSecurityFilterChain(ServletContext servletContext) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EnumSet<DispatcherType> getSecurityDispatcherTypes() {
/* 283 */     return EnumSet.of(DispatcherType.REQUEST, DispatcherType.ERROR, DispatcherType.ASYNC, DispatcherType.FORWARD, DispatcherType.INCLUDE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAsyncSecuritySupported() {
/* 293 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\AbstractSecurityWebApplicationInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */