/*    */ package org.springframework.security.web.context;
/*    */ 
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.io.IOException;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.core.context.DeferredSecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.filter.GenericFilterBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextHolderFilter
/*    */   extends GenericFilterBean
/*    */ {
/* 50 */   private static final String FILTER_APPLIED = SecurityContextHolderFilter.class.getName() + ".APPLIED";
/*    */ 
/*    */   
/*    */   private final SecurityContextRepository securityContextRepository;
/*    */   
/* 55 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityContextHolderFilter(SecurityContextRepository securityContextRepository) {
/* 62 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 63 */     this.securityContextRepository = securityContextRepository;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 69 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*    */   }
/*    */ 
/*    */   
/*    */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
/* 74 */     if (request.getAttribute(FILTER_APPLIED) != null) {
/* 75 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */       return;
/*    */     } 
/* 78 */     request.setAttribute(FILTER_APPLIED, Boolean.TRUE);
/* 79 */     DeferredSecurityContext deferredSecurityContext = this.securityContextRepository.loadDeferredContext(request);
/*    */     try {
/* 81 */       this.securityContextHolderStrategy.setDeferredContext((Supplier)deferredSecurityContext);
/* 82 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */     } finally {
/*    */       
/* 85 */       this.securityContextHolderStrategy.clearContext();
/* 86 */       request.removeAttribute(FILTER_APPLIED);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 97 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 98 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\SecurityContextHolderFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */