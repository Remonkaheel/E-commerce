/*     */ package org.springframework.security.web.context.request.async;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityContextCallableProcessingInterceptor
/*     */   implements CallableProcessingInterceptor
/*     */ {
/*     */   private volatile SecurityContext securityContext;
/*  48 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContextCallableProcessingInterceptor() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContextCallableProcessingInterceptor(SecurityContext securityContext) {
/*  67 */     Assert.notNull(securityContext, "securityContext cannot be null");
/*  68 */     setSecurityContext(securityContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void beforeConcurrentHandling(NativeWebRequest request, Callable<T> task) {
/*  73 */     if (this.securityContext == null) {
/*  74 */       setSecurityContext(this.securityContextHolderStrategy.getContext());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void preProcess(NativeWebRequest request, Callable<T> task) {
/*  80 */     this.securityContextHolderStrategy.setContext(this.securityContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void postProcess(NativeWebRequest request, Callable<T> task, Object concurrentResult) {
/*  85 */     this.securityContextHolderStrategy.clearContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  95 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*  96 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   private void setSecurityContext(SecurityContext securityContext) {
/* 100 */     this.securityContext = securityContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\request\async\SecurityContextCallableProcessingInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */