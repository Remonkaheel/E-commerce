/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SecurityContextPersistenceFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   static final String FILTER_APPLIED = "__spring_security_scpf_applied";
/*     */   private SecurityContextRepository repo;
/*  72 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private boolean forceEagerSessionCreation = false;
/*     */   
/*     */   public SecurityContextPersistenceFilter() {
/*  77 */     this(new HttpSessionSecurityContextRepository());
/*     */   }
/*     */   
/*     */   public SecurityContextPersistenceFilter(SecurityContextRepository repo) {
/*  81 */     this.repo = repo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  87 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
/*  93 */     if (request.getAttribute("__spring_security_scpf_applied") != null) {
/*  94 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/*  97 */     request.setAttribute("__spring_security_scpf_applied", Boolean.TRUE);
/*  98 */     if (this.forceEagerSessionCreation) {
/*  99 */       HttpSession session = request.getSession();
/* 100 */       if (this.logger.isDebugEnabled() && session.isNew()) {
/* 101 */         this.logger.debug(LogMessage.format("Created session %s eagerly", session.getId()));
/*     */       }
/*     */     } 
/* 104 */     HttpRequestResponseHolder holder = new HttpRequestResponseHolder(request, response);
/* 105 */     SecurityContext contextBeforeChainExecution = this.repo.loadContext(holder);
/*     */     try {
/* 107 */       this.securityContextHolderStrategy.setContext(contextBeforeChainExecution);
/* 108 */       if (contextBeforeChainExecution.getAuthentication() == null) {
/* 109 */         this.logger.debug("Set SecurityContextHolder to empty SecurityContext");
/*     */       
/*     */       }
/* 112 */       else if (this.logger.isDebugEnabled()) {
/* 113 */         this.logger
/* 114 */           .debug(LogMessage.format("Set SecurityContextHolder to %s", contextBeforeChainExecution));
/*     */       } 
/*     */       
/* 117 */       chain.doFilter((ServletRequest)holder.getRequest(), (ServletResponse)holder.getResponse());
/*     */     } finally {
/*     */       
/* 120 */       SecurityContext contextAfterChainExecution = this.securityContextHolderStrategy.getContext();
/*     */       
/* 122 */       this.securityContextHolderStrategy.clearContext();
/* 123 */       this.repo.saveContext(contextAfterChainExecution, holder.getRequest(), holder.getResponse());
/* 124 */       request.removeAttribute("__spring_security_scpf_applied");
/* 125 */       this.logger.debug("Cleared SecurityContextHolder to complete request");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setForceEagerSessionCreation(boolean forceEagerSessionCreation) {
/* 130 */     this.forceEagerSessionCreation = forceEagerSessionCreation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 140 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 141 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\SecurityContextPersistenceFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */