/*    */ package org.springframework.security.web.context;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.core.context.DeferredSecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SupplierDeferredSecurityContext
/*    */   implements DeferredSecurityContext
/*    */ {
/* 35 */   private static final Log logger = LogFactory.getLog(SupplierDeferredSecurityContext.class);
/*    */   
/*    */   private final Supplier<SecurityContext> supplier;
/*    */   
/*    */   private final SecurityContextHolderStrategy strategy;
/*    */   
/*    */   private SecurityContext securityContext;
/*    */   
/*    */   private boolean missingContext;
/*    */   
/*    */   SupplierDeferredSecurityContext(Supplier<SecurityContext> supplier, SecurityContextHolderStrategy strategy) {
/* 46 */     this.supplier = supplier;
/* 47 */     this.strategy = strategy;
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext get() {
/* 52 */     init();
/* 53 */     return this.securityContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGenerated() {
/* 58 */     init();
/* 59 */     return this.missingContext;
/*    */   }
/*    */   
/*    */   private void init() {
/* 63 */     if (this.securityContext != null) {
/*    */       return;
/*    */     }
/*    */     
/* 67 */     this.securityContext = this.supplier.get();
/* 68 */     this.missingContext = (this.securityContext == null);
/* 69 */     if (this.missingContext) {
/* 70 */       this.securityContext = this.strategy.createEmptyContext();
/* 71 */       if (logger.isTraceEnabled())
/* 72 */         logger.trace(LogMessage.format("Created %s", this.securityContext)); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\SupplierDeferredSecurityContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */