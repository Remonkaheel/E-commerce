/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SaveToSessionResponseWrapper
/*     */   extends SaveContextOnUpdateOrErrorResponseWrapper
/*     */ {
/* 350 */   private final Log logger = HttpSessionSecurityContextRepository.this.logger;
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpServletRequest request;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean httpSessionExistedAtStartOfRequest;
/*     */ 
/*     */ 
/*     */   
/*     */   private final SecurityContext contextBeforeExecution;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Authentication authBeforeExecution;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSaveContextInvoked;
/*     */ 
/*     */ 
/*     */   
/*     */   SaveToSessionResponseWrapper(HttpServletResponse response, HttpServletRequest request, boolean httpSessionExistedAtStartOfRequest, SecurityContext context) {
/* 375 */     super(response, HttpSessionSecurityContextRepository.this.disableUrlRewriting);
/* 376 */     this.request = request;
/* 377 */     this.httpSessionExistedAtStartOfRequest = httpSessionExistedAtStartOfRequest;
/* 378 */     this.contextBeforeExecution = context;
/* 379 */     this.authBeforeExecution = context.getAuthentication();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void saveContext(SecurityContext context) {
/* 395 */     if (HttpSessionSecurityContextRepository.this.isTransient(context)) {
/*     */       return;
/*     */     }
/* 398 */     Authentication authentication = context.getAuthentication();
/* 399 */     if (HttpSessionSecurityContextRepository.this.isTransient(authentication)) {
/*     */       return;
/*     */     }
/* 402 */     HttpSession httpSession = this.request.getSession(false);
/* 403 */     String springSecurityContextKey = HttpSessionSecurityContextRepository.this.springSecurityContextKey;
/*     */     
/* 405 */     if (authentication == null || HttpSessionSecurityContextRepository.this.trustResolver
/* 406 */       .isAnonymous(authentication)) {
/* 407 */       if (httpSession != null && this.authBeforeExecution != null) {
/*     */ 
/*     */         
/* 410 */         httpSession.removeAttribute(springSecurityContextKey);
/* 411 */         this.isSaveContextInvoked = true;
/*     */       } 
/* 413 */       if (this.logger.isDebugEnabled()) {
/* 414 */         if (authentication == null) {
/* 415 */           this.logger.debug("Did not store empty SecurityContext");
/*     */         } else {
/*     */           
/* 418 */           this.logger.debug("Did not store anonymous SecurityContext");
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 423 */     httpSession = (httpSession != null) ? httpSession : createNewSessionIfAllowed(context);
/*     */ 
/*     */     
/* 426 */     if (httpSession != null)
/*     */     {
/*     */       
/* 429 */       if (contextChanged(context) || httpSession.getAttribute(springSecurityContextKey) == null) {
/* 430 */         HttpSessionSecurityContextRepository.this.saveContextInHttpSession(context, this.request);
/* 431 */         this.isSaveContextInvoked = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean contextChanged(SecurityContext context) {
/* 437 */     return (this.isSaveContextInvoked || context != this.contextBeforeExecution || context
/* 438 */       .getAuthentication() != this.authBeforeExecution);
/*     */   }
/*     */   
/*     */   private HttpSession createNewSessionIfAllowed(SecurityContext context) {
/* 442 */     if (this.httpSessionExistedAtStartOfRequest) {
/* 443 */       this.logger.debug("HttpSession is now null, but was not null at start of request; session was invalidated, so do not create a new session");
/*     */       
/* 445 */       return null;
/*     */     } 
/* 447 */     if (!HttpSessionSecurityContextRepository.this.allowSessionCreation) {
/* 448 */       this.logger.debug("The HttpSession is currently null, and the " + HttpSessionSecurityContextRepository.class
/* 449 */           .getSimpleName() + " is prohibited from creating an HttpSession (because the allowSessionCreation property is false) - SecurityContext thus not stored for next request");
/*     */ 
/*     */ 
/*     */       
/* 453 */       return null;
/*     */     } 
/*     */     
/* 456 */     if (HttpSessionSecurityContextRepository.this.contextObject.equals(context)) {
/* 457 */       this.logger.debug(LogMessage.format("HttpSession is null, but SecurityContext has not changed from default empty context %s so not creating HttpSession or storing SecurityContext", context));
/*     */ 
/*     */ 
/*     */       
/* 461 */       return null;
/*     */     } 
/*     */     try {
/* 464 */       HttpSession session = this.request.getSession(true);
/* 465 */       this.logger.debug("Created HttpSession as SecurityContext is non-default");
/* 466 */       return session;
/*     */     }
/* 468 */     catch (IllegalStateException ex) {
/*     */ 
/*     */       
/* 471 */       this.logger.warn("Failed to create a session, as response has been committed. Unable to store SecurityContext.");
/*     */ 
/*     */       
/* 474 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\HttpSessionSecurityContextRepository$SaveToSessionResponseWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */