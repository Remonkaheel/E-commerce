/*    */ package org.springframework.security.web.context;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.core.context.DeferredSecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.util.function.SingletonSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SecurityContextRepository
/*    */ {
/*    */   @Deprecated
/*    */   SecurityContext loadContext(HttpRequestResponseHolder paramHttpRequestResponseHolder);
/*    */   
/*    */   default DeferredSecurityContext loadDeferredContext(HttpServletRequest request) {
/* 81 */     Supplier<SecurityContext> supplier = () -> loadContext(new HttpRequestResponseHolder(request, null));
/* 82 */     return new SupplierDeferredSecurityContext((Supplier<SecurityContext>)SingletonSupplier.of(supplier), 
/* 83 */         SecurityContextHolder.getContextHolderStrategy());
/*    */   }
/*    */   
/*    */   void saveContext(SecurityContext paramSecurityContext, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*    */   
/*    */   boolean containsContext(HttpServletRequest paramHttpServletRequest);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\SecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */