/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.AsyncContext;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletRequestWrapper;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.Transient;
/*     */ import org.springframework.security.core.context.DeferredSecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSessionSecurityContextRepository
/*     */   implements SecurityContextRepository
/*     */ {
/*     */   public static final String SPRING_SECURITY_CONTEXT_KEY = "SPRING_SECURITY_CONTEXT";
/*  93 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*  96 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Object contextObject = this.securityContextHolderStrategy.createEmptyContext();
/*     */   
/*     */   private boolean allowSessionCreation = true;
/*     */   
/*     */   private boolean disableUrlRewriting = false;
/*     */   
/* 108 */   private String springSecurityContextKey = "SPRING_SECURITY_CONTEXT";
/*     */   
/* 110 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SecurityContext loadContext(HttpRequestResponseHolder requestResponseHolder) {
/* 123 */     HttpServletRequest request = requestResponseHolder.getRequest();
/* 124 */     HttpServletResponse response = requestResponseHolder.getResponse();
/* 125 */     HttpSession httpSession = request.getSession(false);
/* 126 */     SecurityContext context = readSecurityContextFromSession(httpSession);
/* 127 */     if (context == null) {
/* 128 */       context = generateNewContext();
/* 129 */       if (this.logger.isTraceEnabled()) {
/* 130 */         this.logger.trace(LogMessage.format("Created %s", context));
/*     */       }
/*     */     } 
/* 133 */     if (response != null) {
/* 134 */       SaveToSessionResponseWrapper wrappedResponse = new SaveToSessionResponseWrapper(response, request, (httpSession != null), context);
/*     */       
/* 136 */       wrappedResponse.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 137 */       requestResponseHolder.setResponse((HttpServletResponse)wrappedResponse);
/* 138 */       requestResponseHolder.setRequest((HttpServletRequest)new SaveToSessionRequestWrapper(request, wrappedResponse));
/*     */     } 
/* 140 */     return context;
/*     */   }
/*     */ 
/*     */   
/*     */   public DeferredSecurityContext loadDeferredContext(HttpServletRequest request) {
/* 145 */     Supplier<SecurityContext> supplier = () -> readSecurityContextFromSession(request.getSession(false));
/* 146 */     return new SupplierDeferredSecurityContext(supplier, this.securityContextHolderStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveContext(SecurityContext context, HttpServletRequest request, HttpServletResponse response) {
/* 151 */     SaveContextOnUpdateOrErrorResponseWrapper responseWrapper = (SaveContextOnUpdateOrErrorResponseWrapper)WebUtils.getNativeResponse((ServletResponse)response, SaveContextOnUpdateOrErrorResponseWrapper.class);
/*     */     
/* 153 */     if (responseWrapper == null) {
/* 154 */       saveContextInHttpSession(context, request);
/*     */       return;
/*     */     } 
/* 157 */     responseWrapper.saveContext(context);
/*     */   }
/*     */   
/*     */   private void saveContextInHttpSession(SecurityContext context, HttpServletRequest request) {
/* 161 */     if (isTransient(context) || isTransient(context.getAuthentication())) {
/*     */       return;
/*     */     }
/* 164 */     SecurityContext emptyContext = generateNewContext();
/* 165 */     if (emptyContext.equals(context)) {
/* 166 */       HttpSession session = request.getSession(false);
/* 167 */       removeContextFromSession(context, session);
/*     */     } else {
/*     */       
/* 170 */       boolean createSession = this.allowSessionCreation;
/* 171 */       HttpSession session = request.getSession(createSession);
/* 172 */       setContextInSession(context, session);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setContextInSession(SecurityContext context, HttpSession session) {
/* 177 */     if (session != null) {
/* 178 */       session.setAttribute(this.springSecurityContextKey, context);
/* 179 */       if (this.logger.isDebugEnabled()) {
/* 180 */         this.logger.debug(LogMessage.format("Stored %s to HttpSession [%s]", context, session));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeContextFromSession(SecurityContext context, HttpSession session) {
/* 186 */     if (session != null) {
/* 187 */       session.removeAttribute(this.springSecurityContextKey);
/* 188 */       if (this.logger.isDebugEnabled()) {
/* 189 */         this.logger.debug(LogMessage.format("Removed %s from HttpSession [%s]", context, session));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsContext(HttpServletRequest request) {
/* 196 */     HttpSession session = request.getSession(false);
/* 197 */     if (session == null) {
/* 198 */       return false;
/*     */     }
/* 200 */     return (session.getAttribute(this.springSecurityContextKey) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityContext readSecurityContextFromSession(HttpSession httpSession) {
/* 207 */     if (httpSession == null) {
/* 208 */       this.logger.trace("No HttpSession currently exists");
/* 209 */       return null;
/*     */     } 
/*     */     
/* 212 */     Object contextFromSession = httpSession.getAttribute(this.springSecurityContextKey);
/* 213 */     if (contextFromSession == null) {
/* 214 */       if (this.logger.isTraceEnabled()) {
/* 215 */         this.logger.trace(LogMessage.format("Did not find SecurityContext in HttpSession %s using the SPRING_SECURITY_CONTEXT session attribute", httpSession
/* 216 */               .getId()));
/*     */       }
/* 218 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 222 */     if (!(contextFromSession instanceof SecurityContext)) {
/* 223 */       this.logger.warn(LogMessage.format("%s did not contain a SecurityContext but contained: '%s'; are you improperly modifying the HttpSession directly (you should always use SecurityContextHolder) or using the HttpSession attribute reserved for this class?", this.springSecurityContextKey, contextFromSession));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       return null;
/*     */     } 
/*     */     
/* 231 */     if (this.logger.isTraceEnabled()) {
/* 232 */       this.logger
/* 233 */         .trace(LogMessage.format("Retrieved %s from %s", contextFromSession, this.springSecurityContextKey));
/*     */     }
/* 235 */     else if (this.logger.isDebugEnabled()) {
/* 236 */       this.logger.debug(LogMessage.format("Retrieved %s", contextFromSession));
/*     */     } 
/*     */     
/* 239 */     return (SecurityContext)contextFromSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SecurityContext generateNewContext() {
/* 251 */     return this.securityContextHolderStrategy.createEmptyContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowSessionCreation(boolean allowSessionCreation) {
/* 265 */     this.allowSessionCreation = allowSessionCreation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableUrlRewriting(boolean disableUrlRewriting) {
/* 274 */     this.disableUrlRewriting = disableUrlRewriting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpringSecurityContextKey(String springSecurityContextKey) {
/* 283 */     Assert.hasText(springSecurityContextKey, "springSecurityContextKey cannot be empty");
/* 284 */     this.springSecurityContextKey = springSecurityContextKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy strategy) {
/* 294 */     this.securityContextHolderStrategy = strategy;
/* 295 */     this.contextObject = this.securityContextHolderStrategy.createEmptyContext();
/*     */   }
/*     */   
/*     */   private boolean isTransient(Object object) {
/* 299 */     if (object == null) {
/* 300 */       return false;
/*     */     }
/* 302 */     return (AnnotationUtils.getAnnotation(object.getClass(), Transient.class) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 312 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 313 */     this.trustResolver = trustResolver;
/*     */   }
/*     */   
/*     */   private static class SaveToSessionRequestWrapper
/*     */     extends HttpServletRequestWrapper {
/*     */     private final SaveContextOnUpdateOrErrorResponseWrapper response;
/*     */     
/*     */     SaveToSessionRequestWrapper(HttpServletRequest request, SaveContextOnUpdateOrErrorResponseWrapper response) {
/* 321 */       super(request);
/* 322 */       this.response = response;
/*     */     }
/*     */ 
/*     */     
/*     */     public AsyncContext startAsync() {
/* 327 */       this.response.disableSaveOnResponseCommitted();
/* 328 */       return super.startAsync();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
/* 334 */       this.response.disableSaveOnResponseCommitted();
/* 335 */       return super.startAsync(servletRequest, servletResponse);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final class SaveToSessionResponseWrapper
/*     */     extends SaveContextOnUpdateOrErrorResponseWrapper
/*     */   {
/* 350 */     private final Log logger = HttpSessionSecurityContextRepository.this.logger;
/*     */ 
/*     */ 
/*     */     
/*     */     private final HttpServletRequest request;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean httpSessionExistedAtStartOfRequest;
/*     */ 
/*     */ 
/*     */     
/*     */     private final SecurityContext contextBeforeExecution;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Authentication authBeforeExecution;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isSaveContextInvoked;
/*     */ 
/*     */ 
/*     */     
/*     */     SaveToSessionResponseWrapper(HttpServletResponse response, HttpServletRequest request, boolean httpSessionExistedAtStartOfRequest, SecurityContext context) {
/* 375 */       super(response, HttpSessionSecurityContextRepository.this.disableUrlRewriting);
/* 376 */       this.request = request;
/* 377 */       this.httpSessionExistedAtStartOfRequest = httpSessionExistedAtStartOfRequest;
/* 378 */       this.contextBeforeExecution = context;
/* 379 */       this.authBeforeExecution = context.getAuthentication();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void saveContext(SecurityContext context) {
/* 395 */       if (HttpSessionSecurityContextRepository.this.isTransient(context)) {
/*     */         return;
/*     */       }
/* 398 */       Authentication authentication = context.getAuthentication();
/* 399 */       if (HttpSessionSecurityContextRepository.this.isTransient(authentication)) {
/*     */         return;
/*     */       }
/* 402 */       HttpSession httpSession = this.request.getSession(false);
/* 403 */       String springSecurityContextKey = HttpSessionSecurityContextRepository.this.springSecurityContextKey;
/*     */       
/* 405 */       if (authentication == null || HttpSessionSecurityContextRepository.this.trustResolver
/* 406 */         .isAnonymous(authentication)) {
/* 407 */         if (httpSession != null && this.authBeforeExecution != null) {
/*     */ 
/*     */           
/* 410 */           httpSession.removeAttribute(springSecurityContextKey);
/* 411 */           this.isSaveContextInvoked = true;
/*     */         } 
/* 413 */         if (this.logger.isDebugEnabled()) {
/* 414 */           if (authentication == null) {
/* 415 */             this.logger.debug("Did not store empty SecurityContext");
/*     */           } else {
/*     */             
/* 418 */             this.logger.debug("Did not store anonymous SecurityContext");
/*     */           } 
/*     */         }
/*     */         return;
/*     */       } 
/* 423 */       httpSession = (httpSession != null) ? httpSession : createNewSessionIfAllowed(context);
/*     */ 
/*     */       
/* 426 */       if (httpSession != null)
/*     */       {
/*     */         
/* 429 */         if (contextChanged(context) || httpSession.getAttribute(springSecurityContextKey) == null) {
/* 430 */           HttpSessionSecurityContextRepository.this.saveContextInHttpSession(context, this.request);
/* 431 */           this.isSaveContextInvoked = true;
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean contextChanged(SecurityContext context) {
/* 437 */       return (this.isSaveContextInvoked || context != this.contextBeforeExecution || context
/* 438 */         .getAuthentication() != this.authBeforeExecution);
/*     */     }
/*     */     
/*     */     private HttpSession createNewSessionIfAllowed(SecurityContext context) {
/* 442 */       if (this.httpSessionExistedAtStartOfRequest) {
/* 443 */         this.logger.debug("HttpSession is now null, but was not null at start of request; session was invalidated, so do not create a new session");
/*     */         
/* 445 */         return null;
/*     */       } 
/* 447 */       if (!HttpSessionSecurityContextRepository.this.allowSessionCreation) {
/* 448 */         this.logger.debug("The HttpSession is currently null, and the " + HttpSessionSecurityContextRepository.class
/* 449 */             .getSimpleName() + " is prohibited from creating an HttpSession (because the allowSessionCreation property is false) - SecurityContext thus not stored for next request");
/*     */ 
/*     */ 
/*     */         
/* 453 */         return null;
/*     */       } 
/*     */       
/* 456 */       if (HttpSessionSecurityContextRepository.this.contextObject.equals(context)) {
/* 457 */         this.logger.debug(LogMessage.format("HttpSession is null, but SecurityContext has not changed from default empty context %s so not creating HttpSession or storing SecurityContext", context));
/*     */ 
/*     */ 
/*     */         
/* 461 */         return null;
/*     */       } 
/*     */       try {
/* 464 */         HttpSession session = this.request.getSession(true);
/* 465 */         this.logger.debug("Created HttpSession as SecurityContext is non-default");
/* 466 */         return session;
/*     */       }
/* 468 */       catch (IllegalStateException ex) {
/*     */ 
/*     */         
/* 471 */         this.logger.warn("Failed to create a session, as response has been committed. Unable to store SecurityContext.");
/*     */ 
/*     */         
/* 474 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\HttpSessionSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */