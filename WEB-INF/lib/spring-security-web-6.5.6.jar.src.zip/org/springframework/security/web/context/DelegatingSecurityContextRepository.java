/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.context.DeferredSecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DelegatingSecurityContextRepository
/*     */   implements SecurityContextRepository
/*     */ {
/*     */   private final List<SecurityContextRepository> delegates;
/*     */   
/*     */   public DelegatingSecurityContextRepository(SecurityContextRepository... delegates) {
/*  39 */     this(Arrays.asList(delegates));
/*     */   }
/*     */   
/*     */   public DelegatingSecurityContextRepository(List<SecurityContextRepository> delegates) {
/*  43 */     Assert.notEmpty(delegates, "delegates cannot be empty");
/*  44 */     this.delegates = delegates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SecurityContext loadContext(HttpRequestResponseHolder requestResponseHolder) {
/*  54 */     SecurityContext result = null;
/*  55 */     for (SecurityContextRepository delegate : this.delegates) {
/*  56 */       SecurityContext delegateResult = delegate.loadContext(requestResponseHolder);
/*  57 */       if (result == null || delegate.containsContext(requestResponseHolder.getRequest())) {
/*  58 */         result = delegateResult;
/*     */       }
/*     */     } 
/*  61 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public DeferredSecurityContext loadDeferredContext(HttpServletRequest request) {
/*  66 */     DeferredSecurityContext deferredSecurityContext = null;
/*  67 */     for (SecurityContextRepository delegate : this.delegates) {
/*  68 */       if (deferredSecurityContext == null) {
/*  69 */         deferredSecurityContext = delegate.loadDeferredContext(request);
/*     */         continue;
/*     */       } 
/*  72 */       DeferredSecurityContext next = delegate.loadDeferredContext(request);
/*  73 */       deferredSecurityContext = new DelegatingDeferredSecurityContext(deferredSecurityContext, next);
/*     */     } 
/*     */     
/*  76 */     return deferredSecurityContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveContext(SecurityContext context, HttpServletRequest request, HttpServletResponse response) {
/*  81 */     for (SecurityContextRepository delegate : this.delegates) {
/*  82 */       delegate.saveContext(context, request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsContext(HttpServletRequest request) {
/*  88 */     for (SecurityContextRepository delegate : this.delegates) {
/*  89 */       if (delegate.containsContext(request)) {
/*  90 */         return true;
/*     */       }
/*     */     } 
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   static final class DelegatingDeferredSecurityContext
/*     */     implements DeferredSecurityContext
/*     */   {
/*     */     private final DeferredSecurityContext previous;
/*     */     private final DeferredSecurityContext next;
/*     */     
/*     */     DelegatingDeferredSecurityContext(DeferredSecurityContext previous, DeferredSecurityContext next) {
/* 103 */       this.previous = previous;
/* 104 */       this.next = next;
/*     */     }
/*     */ 
/*     */     
/*     */     public SecurityContext get() {
/* 109 */       SecurityContext securityContext = (SecurityContext)this.previous.get();
/* 110 */       if (!this.previous.isGenerated()) {
/* 111 */         return securityContext;
/*     */       }
/* 113 */       return (SecurityContext)this.next.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isGenerated() {
/* 118 */       return (this.previous.isGenerated() && this.next.isGenerated());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\DelegatingSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */