/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import org.springframework.security.core.context.DeferredSecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DelegatingDeferredSecurityContext
/*     */   implements DeferredSecurityContext
/*     */ {
/*     */   private final DeferredSecurityContext previous;
/*     */   private final DeferredSecurityContext next;
/*     */   
/*     */   DelegatingDeferredSecurityContext(DeferredSecurityContext previous, DeferredSecurityContext next) {
/* 103 */     this.previous = previous;
/* 104 */     this.next = next;
/*     */   }
/*     */ 
/*     */   
/*     */   public SecurityContext get() {
/* 109 */     SecurityContext securityContext = (SecurityContext)this.previous.get();
/* 110 */     if (!this.previous.isGenerated()) {
/* 111 */       return securityContext;
/*     */     }
/* 113 */     return (SecurityContext)this.next.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGenerated() {
/* 118 */     return (this.previous.isGenerated() && this.next.isGenerated());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\DelegatingSecurityContextRepository$DelegatingDeferredSecurityContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */