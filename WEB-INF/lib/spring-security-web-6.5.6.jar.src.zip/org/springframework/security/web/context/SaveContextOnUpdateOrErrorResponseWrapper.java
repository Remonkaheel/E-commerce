/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.util.OnCommittedResponseWrapper;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class SaveContextOnUpdateOrErrorResponseWrapper
/*     */   extends OnCommittedResponseWrapper
/*     */ {
/*  52 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean contextSaved = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean disableUrlRewriting;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SaveContextOnUpdateOrErrorResponseWrapper(HttpServletResponse response, boolean disableUrlRewriting) {
/*  66 */     super(response);
/*  67 */     this.disableUrlRewriting = disableUrlRewriting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  77 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*  78 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableSaveOnResponseCommitted() {
/*  88 */     disableOnResponseCommitted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void saveContext(SecurityContext paramSecurityContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onResponseCommitted() {
/* 104 */     saveContext(this.securityContextHolderStrategy.getContext());
/* 105 */     this.contextSaved = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String encodeRedirectURL(String url) {
/* 110 */     if (this.disableUrlRewriting) {
/* 111 */       return url;
/*     */     }
/* 113 */     return super.encodeRedirectURL(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String encodeURL(String url) {
/* 118 */     if (this.disableUrlRewriting) {
/* 119 */       return url;
/*     */     }
/* 121 */     return super.encodeURL(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isContextSaved() {
/* 129 */     return this.contextSaved;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\SaveContextOnUpdateOrErrorResponseWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */