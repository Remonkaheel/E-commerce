/*    */ package org.springframework.security.web.context.support;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SecurityWebApplicationContextUtils
/*    */   extends WebApplicationContextUtils
/*    */ {
/*    */   public static WebApplicationContext findRequiredWebApplicationContext(ServletContext servletContext) {
/* 49 */     WebApplicationContext webApplicationContext = findWebApplicationContext(servletContext);
/* 50 */     Assert.state((webApplicationContext != null), "No WebApplicationContext found: no ContextLoaderListener registered?");
/*    */     
/* 52 */     return webApplicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\support\SecurityWebApplicationContextUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */