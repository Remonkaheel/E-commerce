/*     */ package org.springframework.security.web.context;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.core.context.DeferredSecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestAttributeSecurityContextRepository
/*     */   implements SecurityContextRepository
/*     */ {
/*  49 */   public static final String DEFAULT_REQUEST_ATTR_NAME = RequestAttributeSecurityContextRepository.class.getName()
/*  50 */     .concat(".SPRING_SECURITY_CONTEXT");
/*     */ 
/*     */   
/*     */   private final String requestAttributeName;
/*     */   
/*  55 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestAttributeSecurityContextRepository() {
/*  61 */     this(DEFAULT_REQUEST_ATTR_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestAttributeSecurityContextRepository(String requestAttributeName) {
/*  70 */     this.requestAttributeName = requestAttributeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsContext(HttpServletRequest request) {
/*  75 */     return (getContext(request) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SecurityContext loadContext(HttpRequestResponseHolder requestResponseHolder) {
/*  84 */     return (SecurityContext)loadDeferredContext(requestResponseHolder.getRequest()).get();
/*     */   }
/*     */ 
/*     */   
/*     */   public DeferredSecurityContext loadDeferredContext(HttpServletRequest request) {
/*  89 */     Supplier<SecurityContext> supplier = () -> getContext(request);
/*  90 */     return new SupplierDeferredSecurityContext(supplier, this.securityContextHolderStrategy);
/*     */   }
/*     */   
/*     */   private SecurityContext getContext(HttpServletRequest request) {
/*  94 */     return (SecurityContext)request.getAttribute(this.requestAttributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveContext(SecurityContext context, HttpServletRequest request, HttpServletResponse response) {
/*  99 */     request.setAttribute(this.requestAttributeName, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 108 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 109 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\context\RequestAttributeSecurityContextRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */