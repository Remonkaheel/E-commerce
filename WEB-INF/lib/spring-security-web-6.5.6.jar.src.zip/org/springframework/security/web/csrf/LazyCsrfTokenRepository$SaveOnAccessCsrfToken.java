/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SaveOnAccessCsrfToken
/*     */   implements CsrfToken
/*     */ {
/*     */   private transient CsrfTokenRepository tokenRepository;
/*     */   private transient HttpServletRequest request;
/*     */   private transient HttpServletResponse response;
/*     */   private final CsrfToken delegate;
/*     */   
/*     */   SaveOnAccessCsrfToken(CsrfTokenRepository tokenRepository, HttpServletRequest request, HttpServletResponse response, CsrfToken delegate) {
/* 175 */     this.tokenRepository = tokenRepository;
/* 176 */     this.request = request;
/* 177 */     this.response = response;
/* 178 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName() {
/* 183 */     return this.delegate.getHeaderName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterName() {
/* 188 */     return this.delegate.getParameterName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getToken() {
/* 193 */     saveTokenIfNecessary();
/* 194 */     return this.delegate.getToken();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 199 */     if (this == obj) {
/* 200 */       return true;
/*     */     }
/* 202 */     if (obj == null || getClass() != obj.getClass()) {
/* 203 */       return false;
/*     */     }
/* 205 */     SaveOnAccessCsrfToken other = (SaveOnAccessCsrfToken)obj;
/* 206 */     if (this.delegate == null) {
/* 207 */       if (other.delegate != null) {
/* 208 */         return false;
/*     */       }
/*     */     }
/* 211 */     else if (!this.delegate.equals(other.delegate)) {
/* 212 */       return false;
/*     */     } 
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 219 */     int prime = 31;
/* 220 */     int result = 1;
/* 221 */     result = 31 * result + ((this.delegate == null) ? 0 : this.delegate.hashCode());
/* 222 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 227 */     return "SaveOnAccessCsrfToken [delegate=" + String.valueOf(this.delegate) + "]";
/*     */   }
/*     */   
/*     */   private void saveTokenIfNecessary() {
/* 231 */     if (this.tokenRepository == null) {
/*     */       return;
/*     */     }
/* 234 */     synchronized (this) {
/* 235 */       if (this.tokenRepository != null) {
/* 236 */         this.tokenRepository.saveToken(this.delegate, this.request, this.response);
/* 237 */         this.tokenRepository = null;
/* 238 */         this.request = null;
/* 239 */         this.response = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\LazyCsrfTokenRepository$SaveOnAccessCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */