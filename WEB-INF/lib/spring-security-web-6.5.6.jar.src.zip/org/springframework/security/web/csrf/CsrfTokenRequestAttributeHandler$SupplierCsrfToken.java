/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SupplierCsrfToken
/*     */   implements CsrfToken
/*     */ {
/*     */   private final Supplier<CsrfToken> csrfTokenSupplier;
/*     */   
/*     */   private SupplierCsrfToken(Supplier<CsrfToken> csrfTokenSupplier) {
/*  80 */     this.csrfTokenSupplier = csrfTokenSupplier;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName() {
/*  85 */     return getDelegate().getHeaderName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterName() {
/*  90 */     return getDelegate().getParameterName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getToken() {
/*  95 */     return getDelegate().getToken();
/*     */   }
/*     */   
/*     */   private CsrfToken getDelegate() {
/*  99 */     CsrfToken delegate = this.csrfTokenSupplier.get();
/* 100 */     if (delegate == null) {
/* 101 */       throw new IllegalStateException("csrfTokenSupplier returned null delegate");
/*     */     }
/* 103 */     return delegate;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRequestAttributeHandler$SupplierCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */