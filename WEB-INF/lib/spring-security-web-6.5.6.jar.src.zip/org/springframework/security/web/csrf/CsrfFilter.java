/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ import org.springframework.security.web.access.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CsrfFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  70 */   public static final RequestMatcher DEFAULT_CSRF_MATCHER = new DefaultRequiresCsrfMatcher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static final String SHOULD_NOT_FILTER = "SHOULD_NOT_FILTER" + CsrfFilter.class.getName();
/*     */   
/*  82 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final CsrfTokenRepository tokenRepository;
/*     */   
/*  86 */   private RequestMatcher requireCsrfProtectionMatcher = DEFAULT_CSRF_MATCHER;
/*     */   
/*  88 */   private AccessDeniedHandler accessDeniedHandler = (AccessDeniedHandler)new AccessDeniedHandlerImpl();
/*     */   
/*  90 */   private CsrfTokenRequestHandler requestHandler = new XorCsrfTokenRequestAttributeHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfFilter(CsrfTokenRepository tokenRepository) {
/*  97 */     Assert.notNull(tokenRepository, "tokenRepository cannot be null");
/*  98 */     this.tokenRepository = tokenRepository;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
/* 103 */     return Boolean.TRUE.equals(request.getAttribute(SHOULD_NOT_FILTER));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 109 */     DeferredCsrfToken deferredCsrfToken = this.tokenRepository.loadDeferredToken(request, response);
/* 110 */     request.setAttribute(DeferredCsrfToken.class.getName(), deferredCsrfToken);
/* 111 */     this.requestHandler.handle(request, response, deferredCsrfToken);
/* 112 */     if (!this.requireCsrfProtectionMatcher.matches(request)) {
/* 113 */       if (this.logger.isTraceEnabled()) {
/* 114 */         this.logger.trace("Did not protect against CSRF since request did not match " + String.valueOf(this.requireCsrfProtectionMatcher));
/*     */       }
/*     */       
/* 117 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       return;
/*     */     } 
/* 120 */     CsrfToken csrfToken = deferredCsrfToken.get();
/* 121 */     String actualToken = this.requestHandler.resolveCsrfTokenValue(request, csrfToken);
/* 122 */     if (actualToken != null && this.logger.isTraceEnabled()) {
/* 123 */       this.logger.trace(LogMessage.format("Found a CSRF token in the request", new Object[0]));
/*     */     }
/* 125 */     if (!equalsConstantTime(csrfToken.getToken(), actualToken)) {
/* 126 */       boolean missingToken = deferredCsrfToken.isGenerated();
/* 127 */       this.logger
/* 128 */         .debug(LogMessage.of(() -> "Invalid CSRF token found for " + UrlUtils.buildFullRequestUrl(request)));
/*     */       
/* 130 */       AccessDeniedException exception = !missingToken ? new InvalidCsrfTokenException(csrfToken, actualToken) : new MissingCsrfTokenException(actualToken);
/* 131 */       this.accessDeniedHandler.handle(request, response, exception);
/*     */       return;
/*     */     } 
/* 134 */     filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */   }
/*     */   
/*     */   public static void skipRequest(HttpServletRequest request) {
/* 138 */     request.setAttribute(SHOULD_NOT_FILTER, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequireCsrfProtectionMatcher(RequestMatcher requireCsrfProtectionMatcher) {
/* 154 */     Assert.notNull(requireCsrfProtectionMatcher, "requireCsrfProtectionMatcher cannot be null");
/* 155 */     this.requireCsrfProtectionMatcher = requireCsrfProtectionMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessDeniedHandler(AccessDeniedHandler accessDeniedHandler) {
/* 168 */     Assert.notNull(accessDeniedHandler, "accessDeniedHandler cannot be null");
/* 169 */     this.accessDeniedHandler = accessDeniedHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequestHandler(CsrfTokenRequestHandler requestHandler) {
/* 183 */     Assert.notNull(requestHandler, "requestHandler cannot be null");
/* 184 */     this.requestHandler = requestHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equalsConstantTime(String expected, String actual) {
/* 194 */     if (expected == actual) {
/* 195 */       return true;
/*     */     }
/* 197 */     if (expected == null || actual == null) {
/* 198 */       return false;
/*     */     }
/*     */     
/* 201 */     byte[] expectedBytes = Utf8.encode(expected);
/* 202 */     byte[] actualBytes = Utf8.encode(actual);
/* 203 */     return MessageDigest.isEqual(expectedBytes, actualBytes);
/*     */   }
/*     */   
/*     */   private static final class DefaultRequiresCsrfMatcher
/*     */     implements RequestMatcher {
/* 208 */     private final HashSet<String> allowedMethods = new HashSet<>(Arrays.asList(new String[] { "GET", "HEAD", "TRACE", "OPTIONS" }));
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 212 */       return !this.allowedMethods.contains(request.getMethod());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 217 */       return "CsrfNotRequired " + String.valueOf(this.allowedMethods);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */