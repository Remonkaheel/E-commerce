/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CsrfTokenRequestHandlerLoggerHolder
/*    */ {
/* 27 */   static final Log logger = LogFactory.getLog(CsrfTokenRequestHandler.class);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRequestHandlerLoggerHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */