/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LazyLoadCsrfToken
/*     */   implements CsrfToken
/*     */ {
/*     */   private final HttpServletRequest request;
/*     */   private final CsrfTokenRepository tokenRepository;
/*     */   private CsrfToken token;
/*     */   
/*     */   private LazyLoadCsrfToken(HttpServletRequest request, CsrfTokenRepository tokenRepository) {
/* 122 */     this.request = request;
/* 123 */     this.tokenRepository = tokenRepository;
/*     */   }
/*     */   
/*     */   private CsrfToken getDelegate() {
/* 127 */     if (this.token != null) {
/* 128 */       return this.token;
/*     */     }
/*     */     
/* 131 */     this.token = LazyCsrfTokenRepository.this.delegate.loadToken(this.request);
/* 132 */     if (this.token == null)
/*     */     {
/*     */       
/* 135 */       this.token = LazyCsrfTokenRepository.this.generateToken(this.request);
/*     */     }
/* 137 */     return this.token;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName() {
/* 142 */     return getDelegate().getHeaderName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterName() {
/* 147 */     return getDelegate().getParameterName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getToken() {
/* 152 */     return getDelegate().getToken();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     return "LazyLoadCsrfToken{token=" + String.valueOf(this.token) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\LazyCsrfTokenRepository$LazyLoadCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */