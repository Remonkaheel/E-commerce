/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CsrfTokenRepository
/*    */ {
/*    */   CsrfToken generateToken(HttpServletRequest paramHttpServletRequest);
/*    */   
/*    */   void saveToken(CsrfToken paramCsrfToken, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*    */   
/*    */   CsrfToken loadToken(HttpServletRequest paramHttpServletRequest);
/*    */   
/*    */   default DeferredCsrfToken loadDeferredToken(HttpServletRequest request, HttpServletResponse response) {
/* 72 */     return new RepositoryDeferredCsrfToken(this, request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */