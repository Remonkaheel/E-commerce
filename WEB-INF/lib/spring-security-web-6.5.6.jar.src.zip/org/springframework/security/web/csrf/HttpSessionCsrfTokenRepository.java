/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import jakarta.servlet.http.HttpSession;
/*     */ import java.util.UUID;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpSessionCsrfTokenRepository
/*     */   implements CsrfTokenRepository
/*     */ {
/*     */   private static final String DEFAULT_CSRF_PARAMETER_NAME = "_csrf";
/*     */   private static final String DEFAULT_CSRF_HEADER_NAME = "X-CSRF-TOKEN";
/*  40 */   private static final String DEFAULT_CSRF_TOKEN_ATTR_NAME = HttpSessionCsrfTokenRepository.class.getName()
/*  41 */     .concat(".CSRF_TOKEN");
/*     */   
/*  43 */   private String parameterName = "_csrf";
/*     */   
/*  45 */   private String headerName = "X-CSRF-TOKEN";
/*     */   
/*  47 */   private String sessionAttributeName = DEFAULT_CSRF_TOKEN_ATTR_NAME;
/*     */ 
/*     */   
/*     */   public void saveToken(CsrfToken token, HttpServletRequest request, HttpServletResponse response) {
/*  51 */     if (token == null) {
/*  52 */       HttpSession session = request.getSession(false);
/*  53 */       if (session != null) {
/*  54 */         session.removeAttribute(this.sessionAttributeName);
/*     */       }
/*     */     } else {
/*     */       
/*  58 */       HttpSession session = request.getSession();
/*  59 */       session.setAttribute(this.sessionAttributeName, token);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CsrfToken loadToken(HttpServletRequest request) {
/*  65 */     HttpSession session = request.getSession(false);
/*  66 */     if (session == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     return (CsrfToken)session.getAttribute(this.sessionAttributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public CsrfToken generateToken(HttpServletRequest request) {
/*  74 */     return new DefaultCsrfToken(this.headerName, this.parameterName, createNewToken());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterName(String parameterName) {
/*  83 */     Assert.hasLength(parameterName, "parameterName cannot be null or empty");
/*  84 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderName(String headerName) {
/*  93 */     Assert.hasLength(headerName, "headerName cannot be null or empty");
/*  94 */     this.headerName = headerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionAttributeName(String sessionAttributeName) {
/* 102 */     Assert.hasLength(sessionAttributeName, "sessionAttributename cannot be null or empty");
/* 103 */     this.sessionAttributeName = sessionAttributeName;
/*     */   }
/*     */   
/*     */   private String createNewToken() {
/* 107 */     return UUID.randomUUID().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\HttpSessionCsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */