/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.authentication.session.SessionAuthenticationException;
/*    */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CsrfAuthenticationStrategy
/*    */   implements SessionAuthenticationStrategy
/*    */ {
/* 40 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final CsrfTokenRepository tokenRepository;
/*    */   
/* 44 */   private CsrfTokenRequestHandler requestHandler = new XorCsrfTokenRequestAttributeHandler();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CsrfAuthenticationStrategy(CsrfTokenRepository tokenRepository) {
/* 51 */     Assert.notNull(tokenRepository, "tokenRepository cannot be null");
/* 52 */     this.tokenRepository = tokenRepository;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRequestHandler(CsrfTokenRequestHandler requestHandler) {
/* 61 */     Assert.notNull(requestHandler, "requestHandler cannot be null");
/* 62 */     this.requestHandler = requestHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) throws SessionAuthenticationException {
/* 68 */     boolean containsToken = (this.tokenRepository.loadToken(request) != null);
/* 69 */     if (containsToken) {
/* 70 */       this.tokenRepository.saveToken(null, request, response);
/* 71 */       DeferredCsrfToken deferredCsrfToken = this.tokenRepository.loadDeferredToken(request, response);
/* 72 */       this.requestHandler.handle(request, response, deferredCsrfToken);
/* 73 */       this.logger.debug("Replaced CSRF Token");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfAuthenticationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */