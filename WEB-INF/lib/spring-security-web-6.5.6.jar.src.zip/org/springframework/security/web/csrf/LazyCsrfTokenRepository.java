/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class LazyCsrfTokenRepository
/*     */   implements CsrfTokenRepository
/*     */ {
/*  41 */   private static final String HTTP_RESPONSE_ATTR = HttpServletResponse.class.getName();
/*     */ 
/*     */ 
/*     */   
/*     */   private final CsrfTokenRepository delegate;
/*     */ 
/*     */   
/*     */   private boolean deferLoadToken;
/*     */ 
/*     */ 
/*     */   
/*     */   public LazyCsrfTokenRepository(CsrfTokenRepository delegate) {
/*  53 */     Assert.notNull(delegate, "delegate cannot be null");
/*  54 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeferLoadToken(boolean deferLoadToken) {
/*  63 */     this.deferLoadToken = deferLoadToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfToken generateToken(HttpServletRequest request) {
/*  74 */     return wrap(request, this.delegate.generateToken(request));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveToken(CsrfToken token, HttpServletRequest request, HttpServletResponse response) {
/*  85 */     if (token == null) {
/*  86 */       this.delegate.saveToken(token, request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfToken loadToken(HttpServletRequest request) {
/*  95 */     if (this.deferLoadToken) {
/*  96 */       return new LazyLoadCsrfToken(request, this.delegate);
/*     */     }
/*  98 */     return this.delegate.loadToken(request);
/*     */   }
/*     */   
/*     */   private CsrfToken wrap(HttpServletRequest request, CsrfToken token) {
/* 102 */     HttpServletResponse response = getResponse(request);
/* 103 */     return new SaveOnAccessCsrfToken(this.delegate, request, response, token);
/*     */   }
/*     */   
/*     */   private HttpServletResponse getResponse(HttpServletRequest request) {
/* 107 */     HttpServletResponse response = (HttpServletResponse)request.getAttribute(HTTP_RESPONSE_ATTR);
/* 108 */     Assert.notNull(response, () -> "The HttpServletRequest attribute must contain an HttpServletResponse for the attribute " + HTTP_RESPONSE_ATTR);
/*     */     
/* 110 */     return response;
/*     */   }
/*     */ 
/*     */   
/*     */   private final class LazyLoadCsrfToken
/*     */     implements CsrfToken
/*     */   {
/*     */     private final HttpServletRequest request;
/*     */     private final CsrfTokenRepository tokenRepository;
/*     */     private CsrfToken token;
/*     */     
/*     */     private LazyLoadCsrfToken(HttpServletRequest request, CsrfTokenRepository tokenRepository) {
/* 122 */       this.request = request;
/* 123 */       this.tokenRepository = tokenRepository;
/*     */     }
/*     */     
/*     */     private CsrfToken getDelegate() {
/* 127 */       if (this.token != null) {
/* 128 */         return this.token;
/*     */       }
/*     */       
/* 131 */       this.token = LazyCsrfTokenRepository.this.delegate.loadToken(this.request);
/* 132 */       if (this.token == null)
/*     */       {
/*     */         
/* 135 */         this.token = LazyCsrfTokenRepository.this.generateToken(this.request);
/*     */       }
/* 137 */       return this.token;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeaderName() {
/* 142 */       return getDelegate().getHeaderName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getParameterName() {
/* 147 */       return getDelegate().getParameterName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToken() {
/* 152 */       return getDelegate().getToken();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 157 */       return "LazyLoadCsrfToken{token=" + String.valueOf(this.token) + "}";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class SaveOnAccessCsrfToken
/*     */     implements CsrfToken
/*     */   {
/*     */     private transient CsrfTokenRepository tokenRepository;
/*     */     
/*     */     private transient HttpServletRequest request;
/*     */     
/*     */     private transient HttpServletResponse response;
/*     */     
/*     */     private final CsrfToken delegate;
/*     */ 
/*     */     
/*     */     SaveOnAccessCsrfToken(CsrfTokenRepository tokenRepository, HttpServletRequest request, HttpServletResponse response, CsrfToken delegate) {
/* 175 */       this.tokenRepository = tokenRepository;
/* 176 */       this.request = request;
/* 177 */       this.response = response;
/* 178 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeaderName() {
/* 183 */       return this.delegate.getHeaderName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getParameterName() {
/* 188 */       return this.delegate.getParameterName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToken() {
/* 193 */       saveTokenIfNecessary();
/* 194 */       return this.delegate.getToken();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 199 */       if (this == obj) {
/* 200 */         return true;
/*     */       }
/* 202 */       if (obj == null || getClass() != obj.getClass()) {
/* 203 */         return false;
/*     */       }
/* 205 */       SaveOnAccessCsrfToken other = (SaveOnAccessCsrfToken)obj;
/* 206 */       if (this.delegate == null) {
/* 207 */         if (other.delegate != null) {
/* 208 */           return false;
/*     */         }
/*     */       }
/* 211 */       else if (!this.delegate.equals(other.delegate)) {
/* 212 */         return false;
/*     */       } 
/* 214 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 219 */       int prime = 31;
/* 220 */       int result = 1;
/* 221 */       result = 31 * result + ((this.delegate == null) ? 0 : this.delegate.hashCode());
/* 222 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 227 */       return "SaveOnAccessCsrfToken [delegate=" + String.valueOf(this.delegate) + "]";
/*     */     }
/*     */     
/*     */     private void saveTokenIfNecessary() {
/* 231 */       if (this.tokenRepository == null) {
/*     */         return;
/*     */       }
/* 234 */       synchronized (this) {
/* 235 */         if (this.tokenRepository != null) {
/* 236 */           this.tokenRepository.saveToken(this.delegate, this.request, this.response);
/* 237 */           this.tokenRepository = null;
/* 238 */           this.request = null;
/* 239 */           this.response = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\LazyCsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */