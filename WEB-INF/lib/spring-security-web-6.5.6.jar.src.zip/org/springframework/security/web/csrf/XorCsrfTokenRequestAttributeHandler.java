/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Base64;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XorCsrfTokenRequestAttributeHandler
/*     */   extends CsrfTokenRequestAttributeHandler
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(XorCsrfTokenRequestAttributeHandler.class);
/*     */   
/*  45 */   private SecureRandom secureRandom = new SecureRandom();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecureRandom(SecureRandom secureRandom) {
/*  53 */     Assert.notNull(secureRandom, "secureRandom cannot be null");
/*  54 */     this.secureRandom = secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handle(HttpServletRequest request, HttpServletResponse response, Supplier<CsrfToken> deferredCsrfToken) {
/*  60 */     Assert.notNull(request, "request cannot be null");
/*  61 */     Assert.notNull(response, "response cannot be null");
/*  62 */     Assert.notNull(deferredCsrfToken, "deferredCsrfToken cannot be null");
/*  63 */     Supplier<CsrfToken> updatedCsrfToken = deferCsrfTokenUpdate(deferredCsrfToken);
/*  64 */     super.handle(request, response, updatedCsrfToken);
/*     */   }
/*     */   
/*     */   private Supplier<CsrfToken> deferCsrfTokenUpdate(Supplier<CsrfToken> csrfTokenSupplier) {
/*  68 */     return new CachedCsrfTokenSupplier(() -> {
/*     */           CsrfToken csrfToken = csrfTokenSupplier.get();
/*     */           Assert.state((csrfToken != null), "csrfToken supplier returned null");
/*     */           String updatedToken = createXoredCsrfToken(this.secureRandom, csrfToken.getToken());
/*     */           return new DefaultCsrfToken(csrfToken.getHeaderName(), csrfToken.getParameterName(), updatedToken);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public String resolveCsrfTokenValue(HttpServletRequest request, CsrfToken csrfToken) {
/*  78 */     String actualToken = super.resolveCsrfTokenValue(request, csrfToken);
/*  79 */     if (actualToken == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     return getTokenValue(actualToken, csrfToken.getToken());
/*     */   }
/*     */   
/*     */   private static String getTokenValue(String actualToken, String token) {
/*     */     byte[] actualBytes;
/*     */     try {
/*  88 */       actualBytes = Base64.getUrlDecoder().decode(actualToken);
/*     */     }
/*  90 */     catch (Exception ex) {
/*  91 */       logger.trace(LogMessage.format("Not returning the CSRF token since it's not Base64-encoded", new Object[0]), ex);
/*  92 */       return null;
/*     */     } 
/*     */     
/*  95 */     byte[] tokenBytes = Utf8.encode(token);
/*  96 */     int tokenSize = tokenBytes.length;
/*  97 */     if (actualBytes.length != tokenSize * 2) {
/*  98 */       logger.trace(LogMessage.format("Not returning the CSRF token since its Base64-decoded length (%d) is not equal to (%d)", 
/*     */             
/* 100 */             Integer.valueOf(actualBytes.length), Integer.valueOf(tokenSize * 2)));
/* 101 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     byte[] xoredCsrf = new byte[tokenSize];
/* 106 */     byte[] randomBytes = new byte[tokenSize];
/*     */     
/* 108 */     System.arraycopy(actualBytes, 0, randomBytes, 0, tokenSize);
/* 109 */     System.arraycopy(actualBytes, tokenSize, xoredCsrf, 0, tokenSize);
/*     */     
/* 111 */     byte[] csrfBytes = xorCsrf(randomBytes, xoredCsrf);
/* 112 */     return Utf8.decode(csrfBytes);
/*     */   }
/*     */   
/*     */   private static String createXoredCsrfToken(SecureRandom secureRandom, String token) {
/* 116 */     byte[] tokenBytes = Utf8.encode(token);
/* 117 */     byte[] randomBytes = new byte[tokenBytes.length];
/* 118 */     secureRandom.nextBytes(randomBytes);
/*     */     
/* 120 */     byte[] xoredBytes = xorCsrf(randomBytes, tokenBytes);
/* 121 */     byte[] combinedBytes = new byte[tokenBytes.length + randomBytes.length];
/* 122 */     System.arraycopy(randomBytes, 0, combinedBytes, 0, randomBytes.length);
/* 123 */     System.arraycopy(xoredBytes, 0, combinedBytes, randomBytes.length, xoredBytes.length);
/*     */     
/* 125 */     return Base64.getUrlEncoder().encodeToString(combinedBytes);
/*     */   }
/*     */   
/*     */   private static byte[] xorCsrf(byte[] randomBytes, byte[] csrfBytes) {
/* 129 */     Assert.isTrue((randomBytes.length == csrfBytes.length), "arrays must be equal length");
/* 130 */     int len = csrfBytes.length;
/* 131 */     byte[] xoredCsrf = new byte[len];
/* 132 */     System.arraycopy(csrfBytes, 0, xoredCsrf, 0, len);
/* 133 */     for (int i = 0; i < len; i++) {
/* 134 */       xoredCsrf[i] = (byte)(xoredCsrf[i] ^ randomBytes[i]);
/*     */     }
/* 136 */     return xoredCsrf;
/*     */   }
/*     */   
/*     */   private static final class CachedCsrfTokenSupplier
/*     */     implements Supplier<CsrfToken>
/*     */   {
/*     */     private final Supplier<CsrfToken> delegate;
/*     */     private CsrfToken csrfToken;
/*     */     
/*     */     private CachedCsrfTokenSupplier(Supplier<CsrfToken> delegate) {
/* 146 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public CsrfToken get() {
/* 151 */       if (this.csrfToken == null) {
/* 152 */         this.csrfToken = this.delegate.get();
/*     */       }
/* 154 */       return this.csrfToken;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\XorCsrfTokenRequestAttributeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */