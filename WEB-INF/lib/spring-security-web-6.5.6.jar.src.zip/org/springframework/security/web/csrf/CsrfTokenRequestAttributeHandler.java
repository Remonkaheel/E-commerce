/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsrfTokenRequestAttributeHandler
/*     */   implements CsrfTokenRequestHandler
/*     */ {
/*  40 */   private static final Log logger = LogFactory.getLog(CsrfTokenRequestAttributeHandler.class);
/*     */   
/*  42 */   private String csrfRequestAttributeName = "_csrf";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCsrfRequestAttributeName(String csrfRequestAttributeName) {
/*  53 */     this.csrfRequestAttributeName = csrfRequestAttributeName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handle(HttpServletRequest request, HttpServletResponse response, Supplier<CsrfToken> deferredCsrfToken) {
/*  59 */     Assert.notNull(request, "request cannot be null");
/*  60 */     Assert.notNull(response, "response cannot be null");
/*  61 */     Assert.notNull(deferredCsrfToken, "deferredCsrfToken cannot be null");
/*     */     
/*  63 */     request.setAttribute(HttpServletResponse.class.getName(), response);
/*  64 */     CsrfToken csrfToken = new SupplierCsrfToken(deferredCsrfToken);
/*  65 */     request.setAttribute(CsrfToken.class.getName(), csrfToken);
/*     */     
/*  67 */     String csrfAttrName = (this.csrfRequestAttributeName != null) ? this.csrfRequestAttributeName : csrfToken.getParameterName();
/*  68 */     request.setAttribute(csrfAttrName, csrfToken);
/*     */     
/*  70 */     logger.trace(LogMessage.format("Wrote a CSRF token to the following request attributes: [%s, %s]", csrfAttrName, CsrfToken.class
/*  71 */           .getName()));
/*     */   }
/*     */   
/*     */   private static final class SupplierCsrfToken
/*     */     implements CsrfToken
/*     */   {
/*     */     private final Supplier<CsrfToken> csrfTokenSupplier;
/*     */     
/*     */     private SupplierCsrfToken(Supplier<CsrfToken> csrfTokenSupplier) {
/*  80 */       this.csrfTokenSupplier = csrfTokenSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeaderName() {
/*  85 */       return getDelegate().getHeaderName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getParameterName() {
/*  90 */       return getDelegate().getParameterName();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToken() {
/*  95 */       return getDelegate().getToken();
/*     */     }
/*     */     
/*     */     private CsrfToken getDelegate() {
/*  99 */       CsrfToken delegate = this.csrfTokenSupplier.get();
/* 100 */       if (delegate == null) {
/* 101 */         throw new IllegalStateException("csrfTokenSupplier returned null delegate");
/*     */       }
/* 103 */       return delegate;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRequestAttributeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */