/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidCsrfTokenException
/*    */   extends CsrfException
/*    */ {
/*    */   private static final long serialVersionUID = -7745955098435417418L;
/*    */   
/*    */   public InvalidCsrfTokenException(CsrfToken expectedAccessToken, String actualAccessToken) {
/* 40 */     super("Invalid CSRF Token '" + actualAccessToken + "' was found on the request parameter '" + expectedAccessToken
/* 41 */         .getParameterName() + "' or header '" + expectedAccessToken.getHeaderName() + "'.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\InvalidCsrfTokenException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */