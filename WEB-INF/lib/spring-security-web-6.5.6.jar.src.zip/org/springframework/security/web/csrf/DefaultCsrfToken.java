/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultCsrfToken
/*    */   implements CsrfToken
/*    */ {
/*    */   private static final long serialVersionUID = 6552658053267913685L;
/*    */   private final String token;
/*    */   private final String parameterName;
/*    */   private final String headerName;
/*    */   
/*    */   public DefaultCsrfToken(String headerName, String parameterName, String token) {
/* 48 */     Assert.hasLength(headerName, "headerName cannot be null or empty");
/* 49 */     Assert.hasLength(parameterName, "parameterName cannot be null or empty");
/* 50 */     Assert.hasLength(token, "token cannot be null or empty");
/* 51 */     this.headerName = headerName;
/* 52 */     this.parameterName = parameterName;
/* 53 */     this.token = token;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getHeaderName() {
/* 58 */     return this.headerName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getParameterName() {
/* 63 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getToken() {
/* 68 */     return this.token;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\DefaultCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */