/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CsrfLogoutHandler
/*    */   implements LogoutHandler
/*    */ {
/*    */   private final CsrfTokenRepository csrfTokenRepository;
/*    */   
/*    */   public CsrfLogoutHandler(CsrfTokenRepository csrfTokenRepository) {
/* 42 */     Assert.notNull(csrfTokenRepository, "csrfTokenRepository cannot be null");
/* 43 */     this.csrfTokenRepository = csrfTokenRepository;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 55 */     this.csrfTokenRepository.saveToken(null, request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */