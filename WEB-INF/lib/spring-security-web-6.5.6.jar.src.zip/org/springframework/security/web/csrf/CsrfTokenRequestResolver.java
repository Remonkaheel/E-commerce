package org.springframework.security.web.csrf;

import jakarta.servlet.http.HttpServletRequest;

@FunctionalInterface
public interface CsrfTokenRequestResolver {
  String resolveCsrfTokenValue(HttpServletRequest paramHttpServletRequest, CsrfToken paramCsrfToken);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRequestResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */