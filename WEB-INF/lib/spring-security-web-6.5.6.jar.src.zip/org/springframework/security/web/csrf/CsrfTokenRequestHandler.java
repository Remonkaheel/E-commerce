/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface CsrfTokenRequestHandler
/*    */   extends CsrfTokenRequestResolver
/*    */ {
/*    */   void handle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Supplier<CsrfToken> paramSupplier);
/*    */   
/*    */   default String resolveCsrfTokenValue(HttpServletRequest request, CsrfToken csrfToken) {
/* 51 */     Assert.notNull(request, "request cannot be null");
/* 52 */     Assert.notNull(csrfToken, "csrfToken cannot be null");
/* 53 */     String actualToken = request.getHeader(csrfToken.getHeaderName());
/* 54 */     if (actualToken != null) {
/* 55 */       return actualToken;
/*    */     }
/* 57 */     CsrfTokenRequestHandlerLoggerHolder.logger.trace(
/* 58 */         LogMessage.format("Did not find a CSRF token in the [%s] request header", csrfToken.getHeaderName()));
/*    */     
/* 60 */     actualToken = request.getParameter(csrfToken.getParameterName());
/* 61 */     if (actualToken != null) {
/* 62 */       return actualToken;
/*    */     }
/* 64 */     CsrfTokenRequestHandlerLoggerHolder.logger.trace(
/* 65 */         LogMessage.format("Did not find a CSRF token in the [%s] request parameter", csrfToken.getParameterName()));
/*    */     
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CsrfTokenRequestHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */