/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RepositoryDeferredCsrfToken
/*    */   implements DeferredCsrfToken
/*    */ {
/*    */   private final CsrfTokenRepository csrfTokenRepository;
/*    */   private final HttpServletRequest request;
/*    */   private final HttpServletResponse response;
/*    */   private CsrfToken csrfToken;
/*    */   private boolean missingToken;
/*    */   
/*    */   RepositoryDeferredCsrfToken(CsrfTokenRepository csrfTokenRepository, HttpServletRequest request, HttpServletResponse response) {
/* 41 */     this.csrfTokenRepository = csrfTokenRepository;
/* 42 */     this.request = request;
/* 43 */     this.response = response;
/*    */   }
/*    */ 
/*    */   
/*    */   public CsrfToken get() {
/* 48 */     init();
/* 49 */     return this.csrfToken;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGenerated() {
/* 54 */     init();
/* 55 */     return this.missingToken;
/*    */   }
/*    */   
/*    */   private void init() {
/* 59 */     if (this.csrfToken != null) {
/*    */       return;
/*    */     }
/*    */     
/* 63 */     this.csrfToken = this.csrfTokenRepository.loadToken(this.request);
/* 64 */     this.missingToken = (this.csrfToken == null);
/* 65 */     if (this.missingToken) {
/* 66 */       this.csrfToken = this.csrfTokenRepository.generateToken(this.request);
/* 67 */       this.csrfTokenRepository.saveToken(this.csrfToken, this.request, this.response);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\RepositoryDeferredCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */