/*    */ package org.springframework.security.web.csrf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MissingCsrfTokenException
/*    */   extends CsrfException
/*    */ {
/*    */   public MissingCsrfTokenException(String actualToken) {
/* 29 */     super("Could not verify the provided CSRF token because no token was found to compare.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\MissingCsrfTokenException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */