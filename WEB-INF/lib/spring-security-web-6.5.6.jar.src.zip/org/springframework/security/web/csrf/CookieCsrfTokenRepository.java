/*     */ package org.springframework.security.web.csrf;
/*     */ 
/*     */ import jakarta.servlet.http.Cookie;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CookieCsrfTokenRepository
/*     */   implements CsrfTokenRepository
/*     */ {
/*     */   static final String DEFAULT_CSRF_COOKIE_NAME = "XSRF-TOKEN";
/*     */   static final String DEFAULT_CSRF_PARAMETER_NAME = "_csrf";
/*     */   static final String DEFAULT_CSRF_HEADER_NAME = "X-XSRF-TOKEN";
/*  50 */   private static final String CSRF_TOKEN_REMOVED_ATTRIBUTE_NAME = CookieCsrfTokenRepository.class.getName()
/*  51 */     .concat(".REMOVED");
/*     */   
/*  53 */   private String parameterName = "_csrf";
/*     */   
/*  55 */   private String headerName = "X-XSRF-TOKEN";
/*     */   
/*  57 */   private String cookieName = "XSRF-TOKEN";
/*     */   
/*     */   private boolean cookieHttpOnly = true;
/*     */   
/*     */   private String cookiePath;
/*     */   
/*     */   private String cookieDomain;
/*     */   
/*     */   private Boolean secure;
/*     */   
/*  67 */   private int cookieMaxAge = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer = builder -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieCustomizer(Consumer<ResponseCookie.ResponseCookieBuilder> cookieCustomizer) {
/*  79 */     Assert.notNull(cookieCustomizer, "cookieCustomizer must not be null");
/*  80 */     this.cookieCustomizer = cookieCustomizer;
/*     */   }
/*     */ 
/*     */   
/*     */   public CsrfToken generateToken(HttpServletRequest request) {
/*  85 */     return new DefaultCsrfToken(this.headerName, this.parameterName, createNewToken());
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveToken(CsrfToken token, HttpServletRequest request, HttpServletResponse response) {
/*  90 */     String tokenValue = (token != null) ? token.getToken() : "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     ResponseCookie.ResponseCookieBuilder cookieBuilder = ResponseCookie.from(this.cookieName, tokenValue).secure((this.secure != null) ? this.secure.booleanValue() : request.isSecure()).path(StringUtils.hasLength(this.cookiePath) ? this.cookiePath : getRequestContext(request)).maxAge((token != null) ? this.cookieMaxAge : 0L).httpOnly(this.cookieHttpOnly).domain(this.cookieDomain);
/*     */     
/*  99 */     this.cookieCustomizer.accept(cookieBuilder);
/*     */     
/* 101 */     ResponseCookie responseCookie = cookieBuilder.build();
/* 102 */     if (!StringUtils.hasLength(responseCookie.getSameSite())) {
/* 103 */       Cookie cookie = mapToCookie(responseCookie);
/* 104 */       response.addCookie(cookie);
/*     */     }
/* 106 */     else if (request.getServletContext().getMajorVersion() > 5) {
/* 107 */       Cookie cookie = mapToCookie(responseCookie);
/* 108 */       response.addCookie(cookie);
/*     */     } else {
/*     */       
/* 111 */       response.addHeader("Set-Cookie", responseCookie.toString());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (!StringUtils.hasLength(tokenValue)) {
/* 117 */       request.setAttribute(CSRF_TOKEN_REMOVED_ATTRIBUTE_NAME, Boolean.TRUE);
/*     */     } else {
/*     */       
/* 120 */       request.removeAttribute(CSRF_TOKEN_REMOVED_ATTRIBUTE_NAME);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfToken loadToken(HttpServletRequest request) {
/* 128 */     if (Boolean.TRUE.equals(request.getAttribute(CSRF_TOKEN_REMOVED_ATTRIBUTE_NAME))) {
/* 129 */       return null;
/*     */     }
/* 131 */     Cookie cookie = WebUtils.getCookie(request, this.cookieName);
/* 132 */     if (cookie == null) {
/* 133 */       return null;
/*     */     }
/* 135 */     String token = cookie.getValue();
/* 136 */     if (!StringUtils.hasLength(token)) {
/* 137 */       return null;
/*     */     }
/* 139 */     return new DefaultCsrfToken(this.headerName, this.parameterName, token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterName(String parameterName) {
/* 148 */     Assert.notNull(parameterName, "parameterName cannot be null");
/* 149 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderName(String headerName) {
/* 158 */     Assert.notNull(headerName, "headerName cannot be null");
/* 159 */     this.headerName = headerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookieName(String cookieName) {
/* 168 */     Assert.notNull(cookieName, "cookieName cannot be null");
/* 169 */     this.cookieName = cookieName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 177 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */   
/*     */   private String getRequestContext(HttpServletRequest request) {
/* 181 */     String contextPath = request.getContextPath();
/* 182 */     return (contextPath.length() > 0) ? contextPath : "/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CookieCsrfTokenRepository withHttpOnlyFalse() {
/* 192 */     CookieCsrfTokenRepository result = new CookieCsrfTokenRepository();
/* 193 */     result.cookieHttpOnly = false;
/* 194 */     return result;
/*     */   }
/*     */   
/*     */   private String createNewToken() {
/* 198 */     return UUID.randomUUID().toString();
/*     */   }
/*     */   
/*     */   private Cookie mapToCookie(ResponseCookie responseCookie) {
/* 202 */     Cookie cookie = new Cookie(responseCookie.getName(), responseCookie.getValue());
/* 203 */     cookie.setSecure(responseCookie.isSecure());
/* 204 */     cookie.setPath(responseCookie.getPath());
/* 205 */     cookie.setMaxAge((int)responseCookie.getMaxAge().getSeconds());
/* 206 */     cookie.setHttpOnly(responseCookie.isHttpOnly());
/* 207 */     if (StringUtils.hasLength(responseCookie.getDomain())) {
/* 208 */       cookie.setDomain(responseCookie.getDomain());
/*     */     }
/* 210 */     if (StringUtils.hasText(responseCookie.getSameSite())) {
/* 211 */       cookie.setAttribute("SameSite", responseCookie.getSameSite());
/*     */     }
/* 213 */     return cookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCookiePath(String path) {
/* 222 */     this.cookiePath = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookiePath() {
/* 230 */     return this.cookiePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieDomain(String cookieDomain) {
/* 239 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setSecure(Boolean secure) {
/* 248 */     this.secure = secure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1")
/*     */   public void setCookieMaxAge(int cookieMaxAge) {
/* 257 */     Assert.isTrue((cookieMaxAge != 0), "cookieMaxAge cannot be zero");
/* 258 */     this.cookieMaxAge = cookieMaxAge;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\CookieCsrfTokenRepository.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */