package org.springframework.security.web.csrf;

import java.util.function.Supplier;

public interface DeferredCsrfToken extends Supplier<CsrfToken> {
  CsrfToken get();
  
  boolean isGenerated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-web-6.5.6.jar!\org\springframework\security\web\csrf\DeferredCsrfToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */