/*    */ package org.springframework.boot.autoconfigure.graphql.data;
/*    */ 
/*    */ import graphql.GraphQL;
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlSourceBuilderCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.repository.query.ReactiveQueryByExampleExecutor;
/*    */ import org.springframework.graphql.data.query.QueryByExampleDataFetcher;
/*    */ import org.springframework.graphql.execution.GraphQlSource;
/*    */ import org.springframework.graphql.execution.RuntimeWiringConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {GraphQlAutoConfiguration.class})
/*    */ @ConditionalOnClass({GraphQL.class, QueryByExampleDataFetcher.class, ReactiveQueryByExampleExecutor.class})
/*    */ @ConditionalOnBean({GraphQlSource.class})
/*    */ public class GraphQlReactiveQueryByExampleAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public GraphQlSourceBuilderCustomizer reactiveQueryByExampleRegistrar(ObjectProvider<ReactiveQueryByExampleExecutor<?>> reactiveExecutors) {
/* 56 */     RuntimeWiringConfigurer configurer = QueryByExampleDataFetcher.autoRegistrationConfigurer(Collections.emptyList(), reactiveExecutors.orderedStream().toList());
/* 57 */     return builder -> builder.configureRuntimeWiring(configurer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\data\GraphQlReactiveQueryByExampleAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */