/*    */ package org.springframework.boot.autoconfigure.graphql.security;
/*    */ 
/*    */ import graphql.GraphQL;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.graphql.reactive.GraphQlWebFluxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.graphql.execution.ReactiveSecurityDataFetcherExceptionResolver;
/*    */ import org.springframework.graphql.server.webflux.GraphQlHttpHandler;
/*    */ import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {GraphQlWebFluxAutoConfiguration.class})
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*    */ @ConditionalOnClass({GraphQL.class, GraphQlHttpHandler.class, EnableWebFluxSecurity.class})
/*    */ @ConditionalOnBean({GraphQlHttpHandler.class})
/*    */ public class GraphQlWebFluxSecurityAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveSecurityDataFetcherExceptionResolver reactiveSecurityDataFetcherExceptionResolver() {
/* 50 */     return new ReactiveSecurityDataFetcherExceptionResolver();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\security\GraphQlWebFluxSecurityAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */