/*    */ package org.springframework.boot.autoconfigure.graphql.data;
/*    */ 
/*    */ import graphql.GraphQL;
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlSourceBuilderCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.repository.query.QueryByExampleExecutor;
/*    */ import org.springframework.graphql.data.query.QueryByExampleDataFetcher;
/*    */ import org.springframework.graphql.execution.GraphQlSource;
/*    */ import org.springframework.graphql.execution.RuntimeWiringConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {GraphQlAutoConfiguration.class})
/*    */ @ConditionalOnClass({GraphQL.class, QueryByExampleDataFetcher.class, QueryByExampleExecutor.class})
/*    */ @ConditionalOnBean({GraphQlSource.class})
/*    */ public class GraphQlQueryByExampleAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public GraphQlSourceBuilderCustomizer queryByExampleRegistrar(ObjectProvider<QueryByExampleExecutor<?>> executors) {
/* 55 */     RuntimeWiringConfigurer configurer = QueryByExampleDataFetcher.autoRegistrationConfigurer(executors.orderedStream().toList(), Collections.emptyList());
/* 56 */     return builder -> builder.configureRuntimeWiring(configurer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\data\GraphQlQueryByExampleAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */