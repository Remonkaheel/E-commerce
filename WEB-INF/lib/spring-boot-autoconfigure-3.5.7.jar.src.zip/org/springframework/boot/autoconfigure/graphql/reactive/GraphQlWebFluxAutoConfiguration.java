/*     */ package org.springframework.boot.autoconfigure.graphql.reactive;
/*     */ 
/*     */ import graphql.GraphQL;
/*     */ import java.util.Collections;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiPredicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlCorsProperties;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.graphql.ExecutionGraphQlService;
/*     */ import org.springframework.graphql.execution.GraphQlSource;
/*     */ import org.springframework.graphql.server.WebGraphQlHandler;
/*     */ import org.springframework.graphql.server.WebGraphQlInterceptor;
/*     */ import org.springframework.graphql.server.webflux.GraphQlHttpHandler;
/*     */ import org.springframework.graphql.server.webflux.GraphQlRequestPredicates;
/*     */ import org.springframework.graphql.server.webflux.GraphQlSseHandler;
/*     */ import org.springframework.graphql.server.webflux.GraphQlWebSocketHandler;
/*     */ import org.springframework.graphql.server.webflux.GraphiQlHandler;
/*     */ import org.springframework.graphql.server.webflux.SchemaHandler;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.codec.CodecConfigurer;
/*     */ import org.springframework.http.codec.ServerCodecConfigurer;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.reactive.HandlerMapping;
/*     */ import org.springframework.web.reactive.config.CorsRegistry;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ import org.springframework.web.reactive.function.server.RouterFunction;
/*     */ import org.springframework.web.reactive.function.server.RouterFunctions;
/*     */ import org.springframework.web.reactive.function.server.ServerRequest;
/*     */ import org.springframework.web.reactive.function.server.ServerResponse;
/*     */ import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.reactive.socket.server.support.WebSocketUpgradeHandlerPredicate;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {GraphQlAutoConfiguration.class})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*     */ @ConditionalOnClass({GraphQL.class, GraphQlHttpHandler.class})
/*     */ @ConditionalOnBean({ExecutionGraphQlService.class})
/*     */ @EnableConfigurationProperties({GraphQlCorsProperties.class})
/*     */ @ImportRuntimeHints({GraphQlWebFluxAutoConfiguration.GraphiQlResourceHints.class})
/*     */ public class GraphQlWebFluxAutoConfiguration
/*     */ {
/*  87 */   private static final Log logger = LogFactory.getLog(GraphQlWebFluxAutoConfiguration.class);
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlHttpHandler graphQlHttpHandler(WebGraphQlHandler webGraphQlHandler) {
/*  92 */     return new GraphQlHttpHandler(webGraphQlHandler);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlSseHandler graphQlSseHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties) {
/*  98 */     return new GraphQlSseHandler(webGraphQlHandler, properties.getHttp().getSse().getTimeout(), properties
/*  99 */         .getHttp().getSse().getKeepAlive());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public WebGraphQlHandler webGraphQlHandler(ExecutionGraphQlService service, ObjectProvider<WebGraphQlInterceptor> interceptors) {
/* 106 */     return WebGraphQlHandler.builder(service).interceptors(interceptors.orderedStream().toList()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Order(0)
/*     */   public RouterFunction<ServerResponse> graphQlRouterFunction(GraphQlHttpHandler httpHandler, GraphQlSseHandler sseHandler, ObjectProvider<GraphQlSource> graphQlSourceProvider, GraphQlProperties properties) {
/* 114 */     String path = properties.getHttp().getPath();
/* 115 */     logger.info(LogMessage.format("GraphQL endpoint HTTP POST %s", path));
/* 116 */     RouterFunctions.Builder builder = RouterFunctions.route();
/* 117 */     Objects.requireNonNull(httpHandler); builder.route(GraphQlRequestPredicates.graphQlHttp(path), httpHandler::handleRequest);
/* 118 */     Objects.requireNonNull(sseHandler); builder.route(GraphQlRequestPredicates.graphQlSse(path), sseHandler::handleRequest);
/* 119 */     builder.POST(path, this::unsupportedMediaType);
/* 120 */     builder.GET(path, this::onlyAllowPost);
/* 121 */     if (properties.getGraphiql().isEnabled()) {
/* 122 */       GraphiQlHandler graphQlHandler = new GraphiQlHandler(path, properties.getWebsocket().getPath());
/* 123 */       Objects.requireNonNull(graphQlHandler); builder.GET(properties.getGraphiql().getPath(), graphQlHandler::handleRequest);
/*     */     } 
/* 125 */     GraphQlSource graphQlSource = (GraphQlSource)graphQlSourceProvider.getIfAvailable();
/* 126 */     if (properties.getSchema().getPrinter().isEnabled() && graphQlSource != null) {
/* 127 */       SchemaHandler schemaHandler = new SchemaHandler(graphQlSource);
/* 128 */       Objects.requireNonNull(schemaHandler); builder.GET(path + "/schema", schemaHandler::handleRequest);
/*     */     } 
/* 130 */     return builder.build();
/*     */   }
/*     */   
/*     */   private Mono<ServerResponse> unsupportedMediaType(ServerRequest request) {
/* 134 */     return ((ServerResponse.BodyBuilder)ServerResponse.status((HttpStatusCode)HttpStatus.UNSUPPORTED_MEDIA_TYPE).headers(this::acceptJson)).build();
/*     */   }
/*     */   
/*     */   private void acceptJson(HttpHeaders headers) {
/* 138 */     headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
/*     */   }
/*     */   
/*     */   private Mono<ServerResponse> onlyAllowPost(ServerRequest request) {
/* 142 */     return ((ServerResponse.BodyBuilder)ServerResponse.status((HttpStatusCode)HttpStatus.METHOD_NOT_ALLOWED).headers(this::onlyAllowPost)).build();
/*     */   }
/*     */   
/*     */   private void onlyAllowPost(HttpHeaders headers) {
/* 146 */     headers.setAllow(Collections.singleton(HttpMethod.POST));
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   public static class GraphQlEndpointCorsConfiguration
/*     */     implements WebFluxConfigurer
/*     */   {
/*     */     final GraphQlProperties graphQlProperties;
/*     */     final GraphQlCorsProperties corsProperties;
/*     */     
/*     */     public GraphQlEndpointCorsConfiguration(GraphQlProperties graphQlProps, GraphQlCorsProperties corsProps) {
/* 157 */       this.graphQlProperties = graphQlProps;
/* 158 */       this.corsProperties = corsProps;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addCorsMappings(CorsRegistry registry) {
/* 163 */       CorsConfiguration configuration = this.corsProperties.toCorsConfiguration();
/* 164 */       if (configuration != null) {
/* 165 */         registry.addMapping(this.graphQlProperties.getHttp().getPath()).combine(configuration);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnProperty({"spring.graphql.websocket.path"})
/*     */   public static class WebSocketConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public GraphQlWebSocketHandler graphQlWebSocketHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties, ServerCodecConfigurer configurer) {
/* 179 */       return new GraphQlWebSocketHandler(webGraphQlHandler, (CodecConfigurer)configurer, properties
/* 180 */           .getWebsocket().getConnectionInitTimeout(), properties.getWebsocket().getKeepAlive());
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     public HandlerMapping graphQlWebSocketEndpoint(GraphQlWebSocketHandler graphQlWebSocketHandler, GraphQlProperties properties) {
/* 186 */       String path = properties.getWebsocket().getPath();
/* 187 */       GraphQlWebFluxAutoConfiguration.logger.info(LogMessage.format("GraphQL endpoint WebSocket %s", path));
/* 188 */       SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
/* 189 */       mapping.setHandlerPredicate((BiPredicate)new WebSocketUpgradeHandlerPredicate());
/* 190 */       mapping.setUrlMap(Collections.singletonMap(path, graphQlWebSocketHandler));
/* 191 */       mapping.setOrder(-2);
/* 192 */       return (HandlerMapping)mapping;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class GraphiQlResourceHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 201 */       hints.resources().registerPattern("graphiql/index.html");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\reactive\GraphQlWebFluxAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */