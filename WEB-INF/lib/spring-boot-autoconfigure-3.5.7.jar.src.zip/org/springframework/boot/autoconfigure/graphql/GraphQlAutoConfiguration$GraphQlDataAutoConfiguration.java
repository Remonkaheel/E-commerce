/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.domain.ScrollPosition;
/*     */ import org.springframework.graphql.data.pagination.ConnectionFieldTypeVisitor;
/*     */ import org.springframework.graphql.data.pagination.CursorEncoder;
/*     */ import org.springframework.graphql.data.pagination.CursorStrategy;
/*     */ import org.springframework.graphql.data.pagination.EncodingCursorStrategy;
/*     */ import org.springframework.graphql.data.query.ScrollPositionCursorStrategy;
/*     */ import org.springframework.graphql.data.query.SliceConnectionAdapter;
/*     */ import org.springframework.graphql.data.query.WindowConnectionAdapter;
/*     */ import org.springframework.graphql.execution.GraphQlSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConditionalOnClass({ScrollPosition.class})
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class GraphQlDataAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   EncodingCursorStrategy<ScrollPosition> cursorStrategy() {
/* 185 */     return CursorStrategy.withEncoder((CursorStrategy)new ScrollPositionCursorStrategy(), CursorEncoder.base64());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   GraphQlSourceBuilderCustomizer cursorStrategyCustomizer(CursorStrategy<?> cursorStrategy) {
/* 191 */     if (cursorStrategy.supports(ScrollPosition.class)) {
/* 192 */       CursorStrategy<ScrollPosition> scrollCursorStrategy = (CursorStrategy)cursorStrategy;
/*     */       
/* 194 */       ConnectionFieldTypeVisitor connectionFieldTypeVisitor = ConnectionFieldTypeVisitor.create(List.of(new WindowConnectionAdapter(scrollCursorStrategy), new SliceConnectionAdapter(scrollCursorStrategy)));
/*     */       
/* 196 */       return builder -> builder.typeVisitors(List.of(connectionFieldTypeVisitor));
/*     */     } 
/* 198 */     return builder -> {
/*     */       
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\GraphQlAutoConfiguration$GraphQlDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */