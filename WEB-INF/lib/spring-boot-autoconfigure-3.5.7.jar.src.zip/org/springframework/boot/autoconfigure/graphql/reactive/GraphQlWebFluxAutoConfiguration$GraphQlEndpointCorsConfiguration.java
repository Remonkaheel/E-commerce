/*     */ package org.springframework.boot.autoconfigure.graphql.reactive;
/*     */ 
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlCorsProperties;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.reactive.config.CorsRegistry;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ public class GraphQlEndpointCorsConfiguration
/*     */   implements WebFluxConfigurer
/*     */ {
/*     */   final GraphQlProperties graphQlProperties;
/*     */   final GraphQlCorsProperties corsProperties;
/*     */   
/*     */   public GraphQlEndpointCorsConfiguration(GraphQlProperties graphQlProps, GraphQlCorsProperties corsProps) {
/* 157 */     this.graphQlProperties = graphQlProps;
/* 158 */     this.corsProperties = corsProps;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCorsMappings(CorsRegistry registry) {
/* 163 */     CorsConfiguration configuration = this.corsProperties.toCorsConfiguration();
/* 164 */     if (configuration != null)
/* 165 */       registry.addMapping(this.graphQlProperties.getHttp().getPath()).combine(configuration); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\reactive\GraphQlWebFluxAutoConfiguration$GraphQlEndpointCorsConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */