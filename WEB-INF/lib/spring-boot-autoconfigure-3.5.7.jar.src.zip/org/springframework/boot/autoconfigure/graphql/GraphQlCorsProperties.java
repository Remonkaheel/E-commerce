/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.graphql.cors")
/*     */ public class GraphQlCorsProperties
/*     */ {
/*  46 */   private List<String> allowedOrigins = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private List<String> allowedOriginPatterns = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private List<String> allowedMethods = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private List<String> allowedHeaders = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private List<String> exposedHeaders = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean allowCredentials;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*  82 */   private Duration maxAge = Duration.ofSeconds(1800L);
/*     */   
/*     */   public List<String> getAllowedOrigins() {
/*  85 */     return this.allowedOrigins;
/*     */   }
/*     */   
/*     */   public void setAllowedOrigins(List<String> allowedOrigins) {
/*  89 */     this.allowedOrigins = allowedOrigins;
/*     */   }
/*     */   
/*     */   public List<String> getAllowedOriginPatterns() {
/*  93 */     return this.allowedOriginPatterns;
/*     */   }
/*     */   
/*     */   public void setAllowedOriginPatterns(List<String> allowedOriginPatterns) {
/*  97 */     this.allowedOriginPatterns = allowedOriginPatterns;
/*     */   }
/*     */   
/*     */   public List<String> getAllowedMethods() {
/* 101 */     return this.allowedMethods;
/*     */   }
/*     */   
/*     */   public void setAllowedMethods(List<String> allowedMethods) {
/* 105 */     this.allowedMethods = allowedMethods;
/*     */   }
/*     */   
/*     */   public List<String> getAllowedHeaders() {
/* 109 */     return this.allowedHeaders;
/*     */   }
/*     */   
/*     */   public void setAllowedHeaders(List<String> allowedHeaders) {
/* 113 */     this.allowedHeaders = allowedHeaders;
/*     */   }
/*     */   
/*     */   public List<String> getExposedHeaders() {
/* 117 */     return this.exposedHeaders;
/*     */   }
/*     */   
/*     */   public void setExposedHeaders(List<String> exposedHeaders) {
/* 121 */     this.exposedHeaders = exposedHeaders;
/*     */   }
/*     */   
/*     */   public Boolean getAllowCredentials() {
/* 125 */     return this.allowCredentials;
/*     */   }
/*     */   
/*     */   public void setAllowCredentials(Boolean allowCredentials) {
/* 129 */     this.allowCredentials = allowCredentials;
/*     */   }
/*     */   
/*     */   public Duration getMaxAge() {
/* 133 */     return this.maxAge;
/*     */   }
/*     */   
/*     */   public void setMaxAge(Duration maxAge) {
/* 137 */     this.maxAge = maxAge;
/*     */   }
/*     */   
/*     */   public CorsConfiguration toCorsConfiguration() {
/* 141 */     if (CollectionUtils.isEmpty(this.allowedOrigins) && CollectionUtils.isEmpty(this.allowedOriginPatterns)) {
/* 142 */       return null;
/*     */     }
/* 144 */     PropertyMapper map = PropertyMapper.get();
/* 145 */     CorsConfiguration config = new CorsConfiguration();
/* 146 */     Objects.requireNonNull(config); map.from(this::getAllowedOrigins).to(config::setAllowedOrigins);
/* 147 */     Objects.requireNonNull(config); map.from(this::getAllowedOriginPatterns).to(config::setAllowedOriginPatterns);
/* 148 */     Objects.requireNonNull(config); map.from(this::getAllowedHeaders).whenNot(CollectionUtils::isEmpty).to(config::setAllowedHeaders);
/* 149 */     Objects.requireNonNull(config); map.from(this::getAllowedMethods).whenNot(CollectionUtils::isEmpty).to(config::setAllowedMethods);
/* 150 */     Objects.requireNonNull(config); map.from(this::getExposedHeaders).whenNot(CollectionUtils::isEmpty).to(config::setExposedHeaders);
/* 151 */     Objects.requireNonNull(config); map.from(this::getMaxAge).whenNonNull().as(Duration::getSeconds).to(config::setMaxAge);
/* 152 */     Objects.requireNonNull(config); map.from(this::getAllowCredentials).whenNonNull().to(config::setAllowCredentials);
/* 153 */     return config;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\GraphQlCorsProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */