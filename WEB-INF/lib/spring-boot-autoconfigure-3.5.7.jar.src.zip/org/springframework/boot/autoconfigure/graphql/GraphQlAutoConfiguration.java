/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import graphql.GraphQL;
/*     */ import graphql.execution.instrumentation.Instrumentation;
/*     */ import graphql.introspection.Introspection;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Qualifier;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.data.domain.ScrollPosition;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.graphql.ExecutionGraphQlService;
/*     */ import org.springframework.graphql.data.method.HandlerMethodArgumentResolver;
/*     */ import org.springframework.graphql.data.method.annotation.support.AnnotatedControllerConfigurer;
/*     */ import org.springframework.graphql.data.pagination.ConnectionFieldTypeVisitor;
/*     */ import org.springframework.graphql.data.pagination.CursorEncoder;
/*     */ import org.springframework.graphql.data.pagination.CursorStrategy;
/*     */ import org.springframework.graphql.data.pagination.EncodingCursorStrategy;
/*     */ import org.springframework.graphql.data.query.ScrollPositionCursorStrategy;
/*     */ import org.springframework.graphql.data.query.SliceConnectionAdapter;
/*     */ import org.springframework.graphql.data.query.WindowConnectionAdapter;
/*     */ import org.springframework.graphql.execution.BatchLoaderRegistry;
/*     */ import org.springframework.graphql.execution.ConnectionTypeDefinitionConfigurer;
/*     */ import org.springframework.graphql.execution.DataFetcherExceptionResolver;
/*     */ import org.springframework.graphql.execution.DataLoaderRegistrar;
/*     */ import org.springframework.graphql.execution.DefaultBatchLoaderRegistry;
/*     */ import org.springframework.graphql.execution.DefaultExecutionGraphQlService;
/*     */ import org.springframework.graphql.execution.GraphQlSource;
/*     */ import org.springframework.graphql.execution.RuntimeWiringConfigurer;
/*     */ import org.springframework.graphql.execution.SubscriptionExceptionResolver;
/*     */ import org.springframework.graphql.execution.TypeDefinitionConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration
/*     */ @ConditionalOnClass({GraphQL.class, GraphQlSource.class})
/*     */ @ConditionalOnGraphQlSchema
/*     */ @EnableConfigurationProperties({GraphQlProperties.class})
/*     */ @ImportRuntimeHints({GraphQlAutoConfiguration.GraphQlResourcesRuntimeHints.class})
/*     */ public class GraphQlAutoConfiguration
/*     */ {
/*  84 */   private static final Log logger = LogFactory.getLog(GraphQlAutoConfiguration.class);
/*     */   
/*     */   private final ListableBeanFactory beanFactory;
/*     */   
/*     */   public GraphQlAutoConfiguration(ListableBeanFactory beanFactory) {
/*  89 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlSource graphQlSource(ResourcePatternResolver resourcePatternResolver, GraphQlProperties properties, ObjectProvider<DataFetcherExceptionResolver> exceptionResolvers, ObjectProvider<SubscriptionExceptionResolver> subscriptionExceptionResolvers, ObjectProvider<Instrumentation> instrumentations, ObjectProvider<RuntimeWiringConfigurer> wiringConfigurers, ObjectProvider<GraphQlSourceBuilderCustomizer> sourceCustomizers) {
/* 100 */     String[] schemaLocations = properties.getSchema().getLocations();
/* 101 */     List<Resource> schemaResources = new ArrayList<>();
/* 102 */     schemaResources.addAll(resolveSchemaResources(resourcePatternResolver, schemaLocations, properties
/* 103 */           .getSchema().getFileExtensions()));
/* 104 */     schemaResources.addAll(Arrays.asList(properties.getSchema().getAdditionalFiles()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     GraphQlSource.SchemaResourceBuilder builder = (GraphQlSource.SchemaResourceBuilder)((GraphQlSource.SchemaResourceBuilder)((GraphQlSource.SchemaResourceBuilder)GraphQlSource.schemaResourceBuilder().schemaResources(schemaResources.<Resource>toArray(new Resource[0])).exceptionResolvers(exceptionResolvers.orderedStream().toList())).subscriptionExceptionResolvers(subscriptionExceptionResolvers.orderedStream().toList())).instrumentation(instrumentations.orderedStream().toList());
/* 111 */     if (properties.getSchema().getInspection().isEnabled()) {
/* 112 */       Objects.requireNonNull(logger); builder.inspectSchemaMappings(logger::info);
/*     */     } 
/* 114 */     if (!properties.getSchema().getIntrospection().isEnabled()) {
/* 115 */       Introspection.enabledJvmWide(false);
/*     */     }
/* 117 */     builder.configureTypeDefinitions((TypeDefinitionConfigurer)new ConnectionTypeDefinitionConfigurer());
/* 118 */     Objects.requireNonNull(builder); wiringConfigurers.orderedStream().forEach(builder::configureRuntimeWiring);
/* 119 */     sourceCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 120 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Resource> resolveSchemaResources(ResourcePatternResolver resolver, String[] locations, String[] extensions) {
/* 125 */     List<Resource> resources = new ArrayList<>();
/* 126 */     for (String location : locations) {
/* 127 */       for (String extension : extensions) {
/* 128 */         resources.addAll(resolveSchemaResources(resolver, location + "*" + location));
/*     */       }
/*     */     } 
/* 131 */     return resources;
/*     */   }
/*     */   
/*     */   private List<Resource> resolveSchemaResources(ResourcePatternResolver resolver, String pattern) {
/*     */     try {
/* 136 */       return Arrays.asList(resolver.getResources(pattern));
/*     */     }
/* 138 */     catch (IOException ex) {
/* 139 */       logger.debug(LogMessage.format("Could not resolve schema location: '%s'", pattern), ex);
/* 140 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public BatchLoaderRegistry batchLoaderRegistry() {
/* 147 */     return (BatchLoaderRegistry)new DefaultBatchLoaderRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public ExecutionGraphQlService executionGraphQlService(GraphQlSource graphQlSource, BatchLoaderRegistry batchLoaderRegistry) {
/* 154 */     DefaultExecutionGraphQlService service = new DefaultExecutionGraphQlService(graphQlSource);
/* 155 */     service.addDataLoaderRegistrar((DataLoaderRegistrar)batchLoaderRegistry);
/* 156 */     return (ExecutionGraphQlService)service;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public AnnotatedControllerConfigurer annotatedControllerConfigurer(@Qualifier("applicationTaskExecutor") ObjectProvider<Executor> executorProvider, ObjectProvider<HandlerMethodArgumentResolver> argumentResolvers) {
/* 164 */     AnnotatedControllerConfigurer controllerConfigurer = new AnnotatedControllerConfigurer();
/* 165 */     controllerConfigurer
/* 166 */       .addFormatterRegistrar(registry -> ApplicationConversionService.addBeans(registry, this.beanFactory));
/* 167 */     Objects.requireNonNull(controllerConfigurer); executorProvider.ifAvailable(controllerConfigurer::setExecutor);
/* 168 */     Objects.requireNonNull(controllerConfigurer); argumentResolvers.orderedStream().forEach(controllerConfigurer::addCustomArgumentResolver);
/* 169 */     return controllerConfigurer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   DataFetcherExceptionResolver annotatedControllerConfigurerDataFetcherExceptionResolver(AnnotatedControllerConfigurer annotatedControllerConfigurer) {
/* 175 */     return (DataFetcherExceptionResolver)annotatedControllerConfigurer.getExceptionResolver();
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({ScrollPosition.class})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class GraphQlDataAutoConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     EncodingCursorStrategy<ScrollPosition> cursorStrategy() {
/* 185 */       return CursorStrategy.withEncoder((CursorStrategy)new ScrollPositionCursorStrategy(), CursorEncoder.base64());
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     GraphQlSourceBuilderCustomizer cursorStrategyCustomizer(CursorStrategy<?> cursorStrategy) {
/* 191 */       if (cursorStrategy.supports(ScrollPosition.class)) {
/* 192 */         CursorStrategy<ScrollPosition> scrollCursorStrategy = (CursorStrategy)cursorStrategy;
/*     */         
/* 194 */         ConnectionFieldTypeVisitor connectionFieldTypeVisitor = ConnectionFieldTypeVisitor.create(List.of(new WindowConnectionAdapter(scrollCursorStrategy), new SliceConnectionAdapter(scrollCursorStrategy)));
/*     */         
/* 196 */         return builder -> builder.typeVisitors(List.of(connectionFieldTypeVisitor));
/*     */       } 
/* 198 */       return builder -> {
/*     */         
/*     */         };
/*     */     }
/*     */   }
/*     */   
/*     */   static class GraphQlResourcesRuntimeHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 208 */       hints.resources().registerPattern("graphql/*.graphqls").registerPattern("graphql/*.gqls");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\GraphQlAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */