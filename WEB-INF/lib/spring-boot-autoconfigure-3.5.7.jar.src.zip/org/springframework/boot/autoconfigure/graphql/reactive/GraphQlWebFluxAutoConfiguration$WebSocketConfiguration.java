/*     */ package org.springframework.boot.autoconfigure.graphql.reactive;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.function.BiPredicate;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.graphql.server.WebGraphQlHandler;
/*     */ import org.springframework.graphql.server.webflux.GraphQlWebSocketHandler;
/*     */ import org.springframework.http.codec.CodecConfigurer;
/*     */ import org.springframework.http.codec.ServerCodecConfigurer;
/*     */ import org.springframework.web.reactive.HandlerMapping;
/*     */ import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.reactive.socket.server.support.WebSocketUpgradeHandlerPredicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnProperty({"spring.graphql.websocket.path"})
/*     */ public class WebSocketConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlWebSocketHandler graphQlWebSocketHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties, ServerCodecConfigurer configurer) {
/* 179 */     return new GraphQlWebSocketHandler(webGraphQlHandler, (CodecConfigurer)configurer, properties
/* 180 */         .getWebsocket().getConnectionInitTimeout(), properties.getWebsocket().getKeepAlive());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public HandlerMapping graphQlWebSocketEndpoint(GraphQlWebSocketHandler graphQlWebSocketHandler, GraphQlProperties properties) {
/* 186 */     String path = properties.getWebsocket().getPath();
/* 187 */     GraphQlWebFluxAutoConfiguration.logger.info(LogMessage.format("GraphQL endpoint WebSocket %s", path));
/* 188 */     SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
/* 189 */     mapping.setHandlerPredicate((BiPredicate)new WebSocketUpgradeHandlerPredicate());
/* 190 */     mapping.setUrlMap(Collections.singletonMap(path, graphQlWebSocketHandler));
/* 191 */     mapping.setOrder(-2);
/* 192 */     return (HandlerMapping)mapping;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\reactive\GraphQlWebFluxAutoConfiguration$WebSocketConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */