/*    */ package org.springframework.boot.autoconfigure.graphql.rsocket;
/*    */ 
/*    */ import graphql.GraphQL;
/*    */ import io.rsocket.RSocket;
/*    */ import io.rsocket.transport.netty.client.TcpClientTransport;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.rsocket.RSocketRequesterAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.graphql.client.RSocketGraphQlClient;
/*    */ import org.springframework.messaging.rsocket.RSocketRequester;
/*    */ import org.springframework.util.MimeTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {RSocketRequesterAutoConfiguration.class})
/*    */ @ConditionalOnClass({GraphQL.class, RSocketGraphQlClient.class, RSocketRequester.class, RSocket.class, TcpClientTransport.class})
/*    */ public class RSocketGraphQlClientAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Scope("prototype")
/*    */   @ConditionalOnMissingBean
/*    */   public RSocketGraphQlClient.Builder<?> rsocketGraphQlClientBuilder(RSocketRequester.Builder rsocketRequesterBuilder) {
/* 55 */     return RSocketGraphQlClient.builder(rsocketRequesterBuilder.dataMimeType(MimeTypeUtils.APPLICATION_JSON));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\rsocket\RSocketGraphQlClientAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */