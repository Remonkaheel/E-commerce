/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.graphql")
/*     */ public class GraphQlProperties
/*     */ {
/*  35 */   private final Http http = new Http();
/*     */   
/*  37 */   private final Graphiql graphiql = new Graphiql();
/*     */   
/*  39 */   private final Rsocket rsocket = new Rsocket();
/*     */   
/*  41 */   private final Schema schema = new Schema();
/*     */   
/*  43 */   private final DeprecatedSse sse = new DeprecatedSse(this.http.getSse());
/*     */   
/*  45 */   private final Websocket websocket = new Websocket();
/*     */   
/*     */   public Http getHttp() {
/*  48 */     return this.http;
/*     */   }
/*     */   
/*     */   public Graphiql getGraphiql() {
/*  52 */     return this.graphiql;
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.graphql.http.path", since = "3.5.0")
/*     */   @Deprecated(since = "3.5.0", forRemoval = true)
/*     */   public String getPath() {
/*  58 */     return getHttp().getPath();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.5.0", forRemoval = true)
/*     */   public void setPath(String path) {
/*  63 */     getHttp().setPath(path);
/*     */   }
/*     */   
/*     */   public Schema getSchema() {
/*  67 */     return this.schema;
/*     */   }
/*     */   
/*     */   public Websocket getWebsocket() {
/*  71 */     return this.websocket;
/*     */   }
/*     */   
/*     */   public Rsocket getRsocket() {
/*  75 */     return this.rsocket;
/*     */   }
/*     */   
/*     */   public DeprecatedSse getSse() {
/*  79 */     return this.sse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Http
/*     */   {
/*  87 */     private String path = "/graphql";
/*     */     
/*  89 */     private final GraphQlProperties.Sse sse = new GraphQlProperties.Sse();
/*     */     
/*     */     public String getPath() {
/*  92 */       return this.path;
/*     */     }
/*     */     
/*     */     public void setPath(String path) {
/*  96 */       this.path = path;
/*     */     }
/*     */     
/*     */     public GraphQlProperties.Sse getSse() {
/* 100 */       return this.sse;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Schema
/*     */   {
/* 110 */     private String[] locations = new String[] { "classpath:graphql/**/" };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     private String[] fileExtensions = new String[] { ".graphqls", ".gqls" };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     private Resource[] additionalFiles = new Resource[0];
/*     */     
/* 122 */     private final Inspection inspection = new Inspection();
/*     */     
/* 124 */     private final Introspection introspection = new Introspection();
/*     */     
/* 126 */     private final Printer printer = new Printer();
/*     */     
/*     */     public String[] getLocations() {
/* 129 */       return this.locations;
/*     */     }
/*     */     
/*     */     public void setLocations(String[] locations) {
/* 133 */       this.locations = appendSlashIfNecessary(locations);
/*     */     }
/*     */     
/*     */     public String[] getFileExtensions() {
/* 137 */       return this.fileExtensions;
/*     */     }
/*     */     
/*     */     public void setFileExtensions(String[] fileExtensions) {
/* 141 */       this.fileExtensions = fileExtensions;
/*     */     }
/*     */     
/*     */     public Resource[] getAdditionalFiles() {
/* 145 */       return this.additionalFiles;
/*     */     }
/*     */     
/*     */     public void setAdditionalFiles(Resource[] additionalFiles) {
/* 149 */       this.additionalFiles = additionalFiles;
/*     */     }
/*     */     
/*     */     private String[] appendSlashIfNecessary(String[] locations) {
/* 153 */       return (String[])Arrays.<String>stream(locations)
/* 154 */         .map(location -> location.endsWith("/") ? location : (location + "/"))
/* 155 */         .toArray(x$0 -> new String[x$0]);
/*     */     }
/*     */     
/*     */     public Inspection getInspection() {
/* 159 */       return this.inspection;
/*     */     }
/*     */     
/*     */     public Introspection getIntrospection() {
/* 163 */       return this.introspection;
/*     */     }
/*     */     
/*     */     public Printer getPrinter() {
/* 167 */       return this.printer;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Inspection
/*     */     {
/*     */       private boolean enabled = true;
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isEnabled() {
/* 179 */         return this.enabled;
/*     */       }
/*     */       
/*     */       public void setEnabled(boolean enabled) {
/* 183 */         this.enabled = enabled;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public static class Introspection
/*     */     {
/*     */       private boolean enabled;
/*     */       
/*     */       public Introspection() {
/* 193 */         this.enabled = true;
/*     */       }
/*     */       public boolean isEnabled() {
/* 196 */         return this.enabled;
/*     */       }
/*     */       
/*     */       public void setEnabled(boolean enabled) {
/* 200 */         this.enabled = enabled;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public static class Printer
/*     */     {
/*     */       private boolean enabled;
/*     */ 
/*     */       
/*     */       public Printer() {
/* 211 */         this.enabled = false;
/*     */       }
/*     */       public boolean isEnabled() {
/* 214 */         return this.enabled;
/*     */       }
/*     */       
/*     */       public void setEnabled(boolean enabled) {
/* 218 */         this.enabled = enabled; } } } public static class Inspection { private boolean enabled = true; public boolean isEnabled() { return this.enabled; } public void setEnabled(boolean enabled) { this.enabled = enabled; } } public static class Introspection { private boolean enabled = true; public boolean isEnabled() { return this.enabled; } public void setEnabled(boolean enabled) { this.enabled = enabled; } } public static class Printer { public void setEnabled(boolean enabled) { this.enabled = enabled; }
/*     */     
/*     */     private boolean enabled = false;
/*     */     
/*     */     public boolean isEnabled() {
/*     */       return this.enabled;
/*     */     } }
/*     */   
/*     */   public static class Graphiql { private String path;
/*     */     private boolean enabled;
/*     */     
/*     */     public Graphiql() {
/* 230 */       this.path = "/graphiql";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       this.enabled = false;
/*     */     }
/*     */     public String getPath() {
/* 238 */       return this.path;
/*     */     }
/*     */     
/*     */     public void setPath(String path) {
/* 242 */       this.path = path;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 246 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 250 */       this.enabled = enabled;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Websocket
/*     */   {
/*     */     private String path;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     private Duration connectionInitTimeout = Duration.ofSeconds(60L);
/*     */ 
/*     */     
/*     */     private Duration keepAlive;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPath() {
/* 274 */       return this.path;
/*     */     }
/*     */     
/*     */     public void setPath(String path) {
/* 278 */       this.path = path;
/*     */     }
/*     */     
/*     */     public Duration getConnectionInitTimeout() {
/* 282 */       return this.connectionInitTimeout;
/*     */     }
/*     */     
/*     */     public void setConnectionInitTimeout(Duration connectionInitTimeout) {
/* 286 */       this.connectionInitTimeout = connectionInitTimeout;
/*     */     }
/*     */     
/*     */     public Duration getKeepAlive() {
/* 290 */       return this.keepAlive;
/*     */     }
/*     */     
/*     */     public void setKeepAlive(Duration keepAlive) {
/* 294 */       this.keepAlive = keepAlive;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Rsocket
/*     */   {
/*     */     private String mapping;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMapping() {
/* 307 */       return this.mapping;
/*     */     }
/*     */     
/*     */     public void setMapping(String mapping) {
/* 311 */       this.mapping = mapping;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sse
/*     */   {
/*     */     private Duration keepAlive;
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration timeout;
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getKeepAlive() {
/* 329 */       return this.keepAlive;
/*     */     }
/*     */     
/*     */     public void setKeepAlive(Duration keepAlive) {
/* 333 */       this.keepAlive = keepAlive;
/*     */     }
/*     */     
/*     */     public Duration getTimeout() {
/* 337 */       return this.timeout;
/*     */     }
/*     */     
/*     */     public void setTimeout(Duration timeout) {
/* 341 */       this.timeout = timeout;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.5.1", forRemoval = true)
/*     */   public static final class DeprecatedSse
/*     */   {
/*     */     private final GraphQlProperties.Sse sse;
/*     */     
/*     */     private DeprecatedSse(GraphQlProperties.Sse sse) {
/* 352 */       this.sse = sse;
/*     */     }
/*     */     
/*     */     @DeprecatedConfigurationProperty(replacement = "spring.graphql.http.sse.timeout", since = "3.5.0")
/*     */     @Deprecated(since = "3.5.0", forRemoval = true)
/*     */     public Duration getTimeout() {
/* 358 */       return this.sse.getTimeout();
/*     */     }
/*     */     
/*     */     @Deprecated(since = "3.5.0", forRemoval = true)
/*     */     public void setTimeout(Duration timeout) {
/* 363 */       this.sse.setTimeout(timeout);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\GraphQlProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */