/*    */ package org.springframework.boot.autoconfigure.graphql.rsocket;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.graphql.server.GraphQlRSocketHandler;
/*    */ import org.springframework.messaging.handler.annotation.MessageMapping;
/*    */ import org.springframework.stereotype.Controller;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Controller
/*    */ class GraphQlRSocketController
/*    */ {
/*    */   private final GraphQlRSocketHandler handler;
/*    */   
/*    */   GraphQlRSocketController(GraphQlRSocketHandler handler) {
/* 34 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   @MessageMapping({"${spring.graphql.rsocket.mapping}"})
/*    */   Mono<Map<String, Object>> handle(Map<String, Object> payload) {
/* 39 */     return this.handler.handle(payload);
/*    */   }
/*    */   
/*    */   @MessageMapping({"${spring.graphql.rsocket.mapping}"})
/*    */   Flux<Map<String, Object>> handleSubscription(Map<String, Object> payload) {
/* 44 */     return this.handler.handleSubscription(payload);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\rsocket\GraphQlRSocketController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */