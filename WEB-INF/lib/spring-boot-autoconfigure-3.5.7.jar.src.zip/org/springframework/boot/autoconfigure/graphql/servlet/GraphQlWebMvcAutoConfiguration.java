/*     */ package org.springframework.boot.autoconfigure.graphql.servlet;
/*     */ 
/*     */ import graphql.GraphQL;
/*     */ import jakarta.websocket.server.ServerContainer;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlCorsProperties;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
/*     */ import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.graphql.ExecutionGraphQlService;
/*     */ import org.springframework.graphql.execution.GraphQlSource;
/*     */ import org.springframework.graphql.server.WebGraphQlHandler;
/*     */ import org.springframework.graphql.server.WebGraphQlInterceptor;
/*     */ import org.springframework.graphql.server.webmvc.GraphQlHttpHandler;
/*     */ import org.springframework.graphql.server.webmvc.GraphQlRequestPredicates;
/*     */ import org.springframework.graphql.server.webmvc.GraphQlSseHandler;
/*     */ import org.springframework.graphql.server.webmvc.GraphQlWebSocketHandler;
/*     */ import org.springframework.graphql.server.webmvc.GraphiQlHandler;
/*     */ import org.springframework.graphql.server.webmvc.SchemaHandler;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatusCode;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.config.annotation.CorsRegistry;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ import org.springframework.web.servlet.function.RouterFunction;
/*     */ import org.springframework.web.servlet.function.RouterFunctions;
/*     */ import org.springframework.web.servlet.function.ServerRequest;
/*     */ import org.springframework.web.servlet.function.ServerResponse;
/*     */ import org.springframework.web.socket.WebSocketHandler;
/*     */ import org.springframework.web.socket.server.HandshakeHandler;
/*     */ import org.springframework.web.socket.server.support.DefaultHandshakeHandler;
/*     */ import org.springframework.web.socket.server.support.WebSocketHandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {GraphQlAutoConfiguration.class})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({GraphQL.class, GraphQlHttpHandler.class})
/*     */ @ConditionalOnBean({ExecutionGraphQlService.class})
/*     */ @EnableConfigurationProperties({GraphQlCorsProperties.class})
/*     */ @ImportRuntimeHints({GraphQlWebMvcAutoConfiguration.GraphiQlResourceHints.class})
/*     */ public class GraphQlWebMvcAutoConfiguration
/*     */ {
/*  91 */   private static final Log logger = LogFactory.getLog(GraphQlWebMvcAutoConfiguration.class);
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlHttpHandler graphQlHttpHandler(WebGraphQlHandler webGraphQlHandler) {
/*  96 */     return new GraphQlHttpHandler(webGraphQlHandler);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlSseHandler graphQlSseHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties) {
/* 102 */     return new GraphQlSseHandler(webGraphQlHandler, properties.getHttp().getSse().getTimeout(), properties
/* 103 */         .getHttp().getSse().getKeepAlive());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public WebGraphQlHandler webGraphQlHandler(ExecutionGraphQlService service, ObjectProvider<WebGraphQlInterceptor> interceptors) {
/* 110 */     return WebGraphQlHandler.builder(service).interceptors(interceptors.orderedStream().toList()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Order(0)
/*     */   public RouterFunction<ServerResponse> graphQlRouterFunction(GraphQlHttpHandler httpHandler, GraphQlSseHandler sseHandler, ObjectProvider<GraphQlSource> graphQlSourceProvider, GraphQlProperties properties) {
/* 118 */     String path = properties.getHttp().getPath();
/* 119 */     logger.info(LogMessage.format("GraphQL endpoint HTTP POST %s", path));
/* 120 */     RouterFunctions.Builder builder = RouterFunctions.route();
/* 121 */     Objects.requireNonNull(httpHandler); builder.route(GraphQlRequestPredicates.graphQlHttp(path), httpHandler::handleRequest);
/* 122 */     Objects.requireNonNull(sseHandler); builder.route(GraphQlRequestPredicates.graphQlSse(path), sseHandler::handleRequest);
/* 123 */     builder.POST(path, this::unsupportedMediaType);
/* 124 */     builder.GET(path, this::onlyAllowPost);
/* 125 */     if (properties.getGraphiql().isEnabled()) {
/* 126 */       GraphiQlHandler graphiQLHandler = new GraphiQlHandler(path, properties.getWebsocket().getPath());
/* 127 */       Objects.requireNonNull(graphiQLHandler); builder.GET(properties.getGraphiql().getPath(), graphiQLHandler::handleRequest);
/*     */     } 
/* 129 */     GraphQlSource graphQlSource = (GraphQlSource)graphQlSourceProvider.getIfAvailable();
/* 130 */     if (properties.getSchema().getPrinter().isEnabled() && graphQlSource != null) {
/* 131 */       SchemaHandler schemaHandler = new SchemaHandler(graphQlSource);
/* 132 */       Objects.requireNonNull(schemaHandler); builder.GET(path + "/schema", schemaHandler::handleRequest);
/*     */     } 
/* 134 */     return builder.build();
/*     */   }
/*     */   
/*     */   private ServerResponse unsupportedMediaType(ServerRequest request) {
/* 138 */     return ((ServerResponse.BodyBuilder)ServerResponse.status((HttpStatusCode)HttpStatus.UNSUPPORTED_MEDIA_TYPE).headers(this::acceptJson)).build();
/*     */   }
/*     */   
/*     */   private void acceptJson(HttpHeaders headers) {
/* 142 */     headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
/*     */   }
/*     */   
/*     */   private ServerResponse onlyAllowPost(ServerRequest request) {
/* 146 */     return ((ServerResponse.BodyBuilder)ServerResponse.status((HttpStatusCode)HttpStatus.METHOD_NOT_ALLOWED).headers(this::onlyAllowPost)).build();
/*     */   }
/*     */   
/*     */   private void onlyAllowPost(HttpHeaders headers) {
/* 150 */     headers.setAllow(Collections.singleton(HttpMethod.POST));
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   public static class GraphQlEndpointCorsConfiguration
/*     */     implements WebMvcConfigurer
/*     */   {
/*     */     final GraphQlProperties graphQlProperties;
/*     */     final GraphQlCorsProperties corsProperties;
/*     */     
/*     */     public GraphQlEndpointCorsConfiguration(GraphQlProperties graphQlProps, GraphQlCorsProperties corsProps) {
/* 161 */       this.graphQlProperties = graphQlProps;
/* 162 */       this.corsProperties = corsProps;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addCorsMappings(CorsRegistry registry) {
/* 167 */       CorsConfiguration configuration = this.corsProperties.toCorsConfiguration();
/* 168 */       if (configuration != null) {
/* 169 */         registry.addMapping(this.graphQlProperties.getHttp().getPath()).combine(configuration);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({ServerContainer.class, WebSocketHandler.class})
/*     */   @ConditionalOnProperty({"spring.graphql.websocket.path"})
/*     */   public static class WebSocketConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public GraphQlWebSocketHandler graphQlWebSocketHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties, HttpMessageConverters converters) {
/* 184 */       return new GraphQlWebSocketHandler(webGraphQlHandler, (HttpMessageConverter)getJsonConverter(converters), properties
/* 185 */           .getWebsocket().getConnectionInitTimeout(), properties.getWebsocket().getKeepAlive());
/*     */     }
/*     */     
/*     */     private GenericHttpMessageConverter<Object> getJsonConverter(HttpMessageConverters converters) {
/* 189 */       return (GenericHttpMessageConverter<Object>)converters.getConverters()
/* 190 */         .stream()
/* 191 */         .filter(this::canReadJsonMap)
/* 192 */         .findFirst()
/* 193 */         .map(this::asGenericHttpMessageConverter)
/* 194 */         .orElseThrow(() -> new IllegalStateException("No JSON converter"));
/*     */     }
/*     */     
/*     */     private boolean canReadJsonMap(HttpMessageConverter<?> candidate) {
/* 198 */       return candidate.canRead(Map.class, MediaType.APPLICATION_JSON);
/*     */     }
/*     */ 
/*     */     
/*     */     private GenericHttpMessageConverter<Object> asGenericHttpMessageConverter(HttpMessageConverter<?> converter) {
/* 203 */       return (GenericHttpMessageConverter)converter;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public HandlerMapping graphQlWebSocketMapping(GraphQlWebSocketHandler handler, GraphQlProperties properties) {
/* 208 */       String path = properties.getWebsocket().getPath();
/* 209 */       GraphQlWebMvcAutoConfiguration.logger.info(LogMessage.format("GraphQL endpoint WebSocket %s", path));
/* 210 */       WebSocketHandlerMapping mapping = new WebSocketHandlerMapping();
/* 211 */       mapping.setWebSocketUpgradeMatch(true);
/* 212 */       mapping.setUrlMap(Collections.singletonMap(path, handler
/* 213 */             .initWebSocketHttpRequestHandler((HandshakeHandler)new DefaultHandshakeHandler())));
/* 214 */       mapping.setOrder(-2);
/* 215 */       return (HandlerMapping)mapping;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class GraphiQlResourceHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 224 */       hints.resources().registerPattern("graphiql/index.html");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\servlet\GraphQlWebMvcAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */