/*    */ package org.springframework.boot.autoconfigure.graphql.data;
/*    */ 
/*    */ import com.querydsl.core.Query;
/*    */ import graphql.GraphQL;
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.graphql.GraphQlSourceBuilderCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.querydsl.ReactiveQuerydslPredicateExecutor;
/*    */ import org.springframework.graphql.data.query.QuerydslDataFetcher;
/*    */ import org.springframework.graphql.execution.GraphQlSource;
/*    */ import org.springframework.graphql.execution.RuntimeWiringConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {GraphQlAutoConfiguration.class})
/*    */ @ConditionalOnClass({GraphQL.class, Query.class, QuerydslDataFetcher.class, ReactiveQuerydslPredicateExecutor.class})
/*    */ @ConditionalOnBean({GraphQlSource.class})
/*    */ public class GraphQlReactiveQuerydslAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public GraphQlSourceBuilderCustomizer reactiveQuerydslRegistrar(ObjectProvider<ReactiveQuerydslPredicateExecutor<?>> reactiveExecutors) {
/* 57 */     RuntimeWiringConfigurer configurer = QuerydslDataFetcher.autoRegistrationConfigurer(Collections.emptyList(), reactiveExecutors
/* 58 */         .orderedStream().toList());
/* 59 */     return builder -> builder.configureRuntimeWiring(configurer);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\data\GraphQlReactiveQuerydslAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */