/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.graphql.execution.GraphQlSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultGraphQlSchemaCondition
/*     */   extends SpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase() {
/*  55 */     return ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  60 */     boolean match = false;
/*  61 */     List<ConditionMessage> messages = new ArrayList<>(2);
/*  62 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnGraphQlSchema.class, new Object[0]);
/*  63 */     Binder binder = Binder.get(context.getEnvironment());
/*     */     
/*  65 */     GraphQlProperties.Schema schema = (GraphQlProperties.Schema)binder.bind("spring.graphql.schema", GraphQlProperties.Schema.class).orElse(new GraphQlProperties.Schema());
/*     */     
/*  67 */     ResourcePatternResolver resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(context.getResourceLoader());
/*  68 */     List<Resource> schemaResources = resolveSchemaResources(resourcePatternResolver, schema.getLocations(), schema
/*  69 */         .getFileExtensions());
/*  70 */     if (!schemaResources.isEmpty()) {
/*  71 */       match = true;
/*  72 */       messages.add(message.found("schema", "schemas").items(ConditionMessage.Style.QUOTE, schemaResources));
/*     */     } else {
/*     */       
/*  75 */       messages.add(message.didNotFind("schema files in locations")
/*  76 */           .items(ConditionMessage.Style.QUOTE, Arrays.asList(schema.getLocations())));
/*     */     } 
/*  78 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/*  79 */     String[] customizerBeans = beanFactory.getBeanNamesForType(GraphQlSourceBuilderCustomizer.class, false, false);
/*  80 */     if (customizerBeans.length != 0) {
/*  81 */       match = true;
/*  82 */       messages.add(message.found("customizer", "customizers").items(Arrays.asList(customizerBeans)));
/*     */     } else {
/*     */       
/*  85 */       messages.add(message.didNotFind("GraphQlSourceBuilderCustomizer").atAll());
/*     */     } 
/*  87 */     String[] graphQlSourceBeanNames = beanFactory.getBeanNamesForType(GraphQlSource.class, false, false);
/*  88 */     if (graphQlSourceBeanNames.length != 0) {
/*  89 */       match = true;
/*  90 */       messages.add(message.found("GraphQlSource").items(Arrays.asList(graphQlSourceBeanNames)));
/*     */     } else {
/*     */       
/*  93 */       messages.add(message.didNotFind("GraphQlSource").atAll());
/*     */     } 
/*  95 */     return new ConditionOutcome(match, ConditionMessage.of(messages));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Resource> resolveSchemaResources(ResourcePatternResolver resolver, String[] locations, String[] extensions) {
/* 100 */     List<Resource> resources = new ArrayList<>();
/* 101 */     for (String location : locations) {
/* 102 */       for (String extension : extensions) {
/* 103 */         resources.addAll(resolveSchemaResources(resolver, location + "*" + location));
/*     */       }
/*     */     } 
/* 106 */     return resources;
/*     */   }
/*     */   
/*     */   private List<Resource> resolveSchemaResources(ResourcePatternResolver resolver, String pattern) {
/*     */     try {
/* 111 */       return Arrays.asList(resolver.getResources(pattern));
/*     */     }
/* 113 */     catch (IOException ex) {
/* 114 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\DefaultGraphQlSchemaCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */