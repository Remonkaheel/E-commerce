/*     */ package org.springframework.boot.autoconfigure.graphql;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Schema
/*     */ {
/* 110 */   private String[] locations = new String[] { "classpath:graphql/**/" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private String[] fileExtensions = new String[] { ".graphqls", ".gqls" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private Resource[] additionalFiles = new Resource[0];
/*     */   
/* 122 */   private final Inspection inspection = new Inspection();
/*     */   
/* 124 */   private final Introspection introspection = new Introspection();
/*     */   
/* 126 */   private final Printer printer = new Printer();
/*     */   
/*     */   public String[] getLocations() {
/* 129 */     return this.locations;
/*     */   }
/*     */   
/*     */   public void setLocations(String[] locations) {
/* 133 */     this.locations = appendSlashIfNecessary(locations);
/*     */   }
/*     */   
/*     */   public String[] getFileExtensions() {
/* 137 */     return this.fileExtensions;
/*     */   }
/*     */   
/*     */   public void setFileExtensions(String[] fileExtensions) {
/* 141 */     this.fileExtensions = fileExtensions;
/*     */   }
/*     */   
/*     */   public Resource[] getAdditionalFiles() {
/* 145 */     return this.additionalFiles;
/*     */   }
/*     */   
/*     */   public void setAdditionalFiles(Resource[] additionalFiles) {
/* 149 */     this.additionalFiles = additionalFiles;
/*     */   }
/*     */   
/*     */   private String[] appendSlashIfNecessary(String[] locations) {
/* 153 */     return (String[])Arrays.<String>stream(locations)
/* 154 */       .map(location -> location.endsWith("/") ? location : (location + "/"))
/* 155 */       .toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */   
/*     */   public Inspection getInspection() {
/* 159 */     return this.inspection;
/*     */   }
/*     */   
/*     */   public Introspection getIntrospection() {
/* 163 */     return this.introspection;
/*     */   }
/*     */   
/*     */   public Printer getPrinter() {
/* 167 */     return this.printer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Inspection
/*     */   {
/*     */     private boolean enabled = true;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 179 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 183 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Introspection
/*     */   {
/*     */     private boolean enabled;
/*     */     
/*     */     public Introspection() {
/* 193 */       this.enabled = true;
/*     */     }
/*     */     public boolean isEnabled() {
/* 196 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 200 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Printer
/*     */   {
/*     */     private boolean enabled;
/*     */ 
/*     */     
/*     */     public Printer() {
/* 211 */       this.enabled = false;
/*     */     }
/*     */     public boolean isEnabled() {
/* 214 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 218 */       this.enabled = enabled;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\GraphQlProperties$Schema.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */