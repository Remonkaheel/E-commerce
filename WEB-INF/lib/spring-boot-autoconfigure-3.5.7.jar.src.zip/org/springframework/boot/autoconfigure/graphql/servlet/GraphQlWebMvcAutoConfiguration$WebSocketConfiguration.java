/*     */ package org.springframework.boot.autoconfigure.graphql.servlet;
/*     */ 
/*     */ import jakarta.websocket.server.ServerContainer;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
/*     */ import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.graphql.server.WebGraphQlHandler;
/*     */ import org.springframework.graphql.server.webmvc.GraphQlWebSocketHandler;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.socket.WebSocketHandler;
/*     */ import org.springframework.web.socket.server.HandshakeHandler;
/*     */ import org.springframework.web.socket.server.support.DefaultHandshakeHandler;
/*     */ import org.springframework.web.socket.server.support.WebSocketHandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({ServerContainer.class, WebSocketHandler.class})
/*     */ @ConditionalOnProperty({"spring.graphql.websocket.path"})
/*     */ public class WebSocketConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public GraphQlWebSocketHandler graphQlWebSocketHandler(WebGraphQlHandler webGraphQlHandler, GraphQlProperties properties, HttpMessageConverters converters) {
/* 184 */     return new GraphQlWebSocketHandler(webGraphQlHandler, (HttpMessageConverter)getJsonConverter(converters), properties
/* 185 */         .getWebsocket().getConnectionInitTimeout(), properties.getWebsocket().getKeepAlive());
/*     */   }
/*     */   
/*     */   private GenericHttpMessageConverter<Object> getJsonConverter(HttpMessageConverters converters) {
/* 189 */     return (GenericHttpMessageConverter<Object>)converters.getConverters()
/* 190 */       .stream()
/* 191 */       .filter(this::canReadJsonMap)
/* 192 */       .findFirst()
/* 193 */       .map(this::asGenericHttpMessageConverter)
/* 194 */       .orElseThrow(() -> new IllegalStateException("No JSON converter"));
/*     */   }
/*     */   
/*     */   private boolean canReadJsonMap(HttpMessageConverter<?> candidate) {
/* 198 */     return candidate.canRead(Map.class, MediaType.APPLICATION_JSON);
/*     */   }
/*     */ 
/*     */   
/*     */   private GenericHttpMessageConverter<Object> asGenericHttpMessageConverter(HttpMessageConverter<?> converter) {
/* 203 */     return (GenericHttpMessageConverter)converter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public HandlerMapping graphQlWebSocketMapping(GraphQlWebSocketHandler handler, GraphQlProperties properties) {
/* 208 */     String path = properties.getWebsocket().getPath();
/* 209 */     GraphQlWebMvcAutoConfiguration.logger.info(LogMessage.format("GraphQL endpoint WebSocket %s", path));
/* 210 */     WebSocketHandlerMapping mapping = new WebSocketHandlerMapping();
/* 211 */     mapping.setWebSocketUpgradeMatch(true);
/* 212 */     mapping.setUrlMap(Collections.singletonMap(path, handler
/* 213 */           .initWebSocketHttpRequestHandler((HandshakeHandler)new DefaultHandshakeHandler())));
/* 214 */     mapping.setOrder(-2);
/* 215 */     return (HandlerMapping)mapping;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\graphql\servlet\GraphQlWebMvcAutoConfiguration$WebSocketConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */