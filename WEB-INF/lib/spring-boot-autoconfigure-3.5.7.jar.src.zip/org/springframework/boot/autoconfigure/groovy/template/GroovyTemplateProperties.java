/*     */ package org.springframework.boot.autoconfigure.groovy.template;
/*     */ 
/*     */ import groovy.text.markup.BaseTemplate;
/*     */ import java.util.Locale;
/*     */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.groovy.template")
/*     */ public class GroovyTemplateProperties
/*     */   extends AbstractTemplateViewResolverProperties
/*     */ {
/*     */   public static final String DEFAULT_RESOURCE_LOADER_PATH = "classpath:/templates/";
/*     */   public static final String DEFAULT_PREFIX = "";
/*     */   public static final String DEFAULT_SUFFIX = ".tpl";
/*     */   public static final String DEFAULT_REQUEST_CONTEXT_ATTRIBUTE = "spring";
/*     */   private boolean autoEscape;
/*     */   private boolean autoIndent;
/*     */   private String autoIndentString;
/*     */   private boolean autoNewLine;
/*  68 */   private Class<? extends BaseTemplate> baseTemplateClass = BaseTemplate.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String declarationEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean expandEmptyElements;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Locale locale;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String newLineString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private String resourceLoaderPath = "classpath:/templates/";
/*     */ 
/*     */   
/*     */   private boolean useDoubleQuotes;
/*     */ 
/*     */ 
/*     */   
/*     */   public GroovyTemplateProperties() {
/* 102 */     super("", ".tpl");
/* 103 */     setRequestContextAttribute("spring");
/*     */   }
/*     */   
/*     */   public boolean isAutoEscape() {
/* 107 */     return this.autoEscape;
/*     */   }
/*     */   
/*     */   public void setAutoEscape(boolean autoEscape) {
/* 111 */     this.autoEscape = autoEscape;
/*     */   }
/*     */   
/*     */   public boolean isAutoIndent() {
/* 115 */     return this.autoIndent;
/*     */   }
/*     */   
/*     */   public void setAutoIndent(boolean autoIndent) {
/* 119 */     this.autoIndent = autoIndent;
/*     */   }
/*     */   
/*     */   public String getAutoIndentString() {
/* 123 */     return this.autoIndentString;
/*     */   }
/*     */   
/*     */   public void setAutoIndentString(String autoIndentString) {
/* 127 */     this.autoIndentString = autoIndentString;
/*     */   }
/*     */   
/*     */   public boolean isAutoNewLine() {
/* 131 */     return this.autoNewLine;
/*     */   }
/*     */   
/*     */   public void setAutoNewLine(boolean autoNewLine) {
/* 135 */     this.autoNewLine = autoNewLine;
/*     */   }
/*     */   
/*     */   public Class<? extends BaseTemplate> getBaseTemplateClass() {
/* 139 */     return this.baseTemplateClass;
/*     */   }
/*     */   
/*     */   public void setBaseTemplateClass(Class<? extends BaseTemplate> baseTemplateClass) {
/* 143 */     this.baseTemplateClass = baseTemplateClass;
/*     */   }
/*     */   
/*     */   public String getDeclarationEncoding() {
/* 147 */     return this.declarationEncoding;
/*     */   }
/*     */   
/*     */   public void setDeclarationEncoding(String declarationEncoding) {
/* 151 */     this.declarationEncoding = declarationEncoding;
/*     */   }
/*     */   
/*     */   public boolean isExpandEmptyElements() {
/* 155 */     return this.expandEmptyElements;
/*     */   }
/*     */   
/*     */   public void setExpandEmptyElements(boolean expandEmptyElements) {
/* 159 */     this.expandEmptyElements = expandEmptyElements;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 163 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 167 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public String getNewLineString() {
/* 171 */     return this.newLineString;
/*     */   }
/*     */   
/*     */   public void setNewLineString(String newLineString) {
/* 175 */     this.newLineString = newLineString;
/*     */   }
/*     */   
/*     */   public String getResourceLoaderPath() {
/* 179 */     return this.resourceLoaderPath;
/*     */   }
/*     */   
/*     */   public void setResourceLoaderPath(String resourceLoaderPath) {
/* 183 */     this.resourceLoaderPath = resourceLoaderPath;
/*     */   }
/*     */   
/*     */   public boolean isUseDoubleQuotes() {
/* 187 */     return this.useDoubleQuotes;
/*     */   }
/*     */   
/*     */   public void setUseDoubleQuotes(boolean useDoubleQuotes) {
/* 191 */     this.useDoubleQuotes = useDoubleQuotes;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */