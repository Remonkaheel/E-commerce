/*    */ package org.springframework.boot.autoconfigure.groovy.template;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GroovyTemplateAvailabilityProperties
/*    */   extends PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties
/*    */ {
/* 47 */   private List<String> resourceLoaderPath = new ArrayList<>(
/* 48 */       Arrays.asList(new String[] { "classpath:/templates/" }));
/*    */   
/*    */   GroovyTemplateAvailabilityProperties() {
/* 51 */     super("", ".tpl");
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<String> getLoaderPath() {
/* 56 */     return this.resourceLoaderPath;
/*    */   }
/*    */   
/*    */   public List<String> getResourceLoaderPath() {
/* 60 */     return this.resourceLoaderPath;
/*    */   }
/*    */   
/*    */   public void setResourceLoaderPath(List<String> resourceLoaderPath) {
/* 64 */     this.resourceLoaderPath = resourceLoaderPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateAvailabilityProvider$GroovyTemplateAvailabilityProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */