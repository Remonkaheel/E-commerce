/*    */ package org.springframework.boot.autoconfigure.groovy.template;
/*    */ 
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.boot.context.properties.bind.BindableRuntimeHintsRegistrar;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GroovyTemplateAvailabilityRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 73 */     if (ClassUtils.isPresent("groovy.text.TemplateEngine", classLoader))
/* 74 */       BindableRuntimeHintsRegistrar.forTypes(new Class[] { GroovyTemplateAvailabilityProvider.GroovyTemplateAvailabilityProperties.class
/* 75 */           }).registerHints(hints, classLoader); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateAvailabilityProvider$GroovyTemplateAvailabilityRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */