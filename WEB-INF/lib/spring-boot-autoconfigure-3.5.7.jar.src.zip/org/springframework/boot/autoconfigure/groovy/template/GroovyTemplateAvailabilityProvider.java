/*    */ package org.springframework.boot.autoconfigure.groovy.template;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider;
/*    */ import org.springframework.boot.context.properties.bind.BindableRuntimeHintsRegistrar;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroovyTemplateAvailabilityProvider
/*    */   extends PathBasedTemplateAvailabilityProvider
/*    */ {
/*    */   private static final String REQUIRED_CLASS_NAME = "groovy.text.TemplateEngine";
/*    */   
/*    */   public GroovyTemplateAvailabilityProvider() {
/* 42 */     super("groovy.text.TemplateEngine", GroovyTemplateAvailabilityProperties.class, "spring.groovy.template");
/*    */   }
/*    */   
/*    */   protected static final class GroovyTemplateAvailabilityProperties
/*    */     extends PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties {
/* 47 */     private List<String> resourceLoaderPath = new ArrayList<>(
/* 48 */         Arrays.asList(new String[] { "classpath:/templates/" }));
/*    */     
/*    */     GroovyTemplateAvailabilityProperties() {
/* 51 */       super("", ".tpl");
/*    */     }
/*    */ 
/*    */     
/*    */     protected List<String> getLoaderPath() {
/* 56 */       return this.resourceLoaderPath;
/*    */     }
/*    */     
/*    */     public List<String> getResourceLoaderPath() {
/* 60 */       return this.resourceLoaderPath;
/*    */     }
/*    */     
/*    */     public void setResourceLoaderPath(List<String> resourceLoaderPath) {
/* 64 */       this.resourceLoaderPath = resourceLoaderPath;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   static class GroovyTemplateAvailabilityRuntimeHints
/*    */     implements RuntimeHintsRegistrar
/*    */   {
/*    */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 73 */       if (ClassUtils.isPresent("groovy.text.TemplateEngine", classLoader))
/* 74 */         BindableRuntimeHintsRegistrar.forTypes(new Class[] { GroovyTemplateAvailabilityProvider.GroovyTemplateAvailabilityProperties.class
/* 75 */             }).registerHints(hints, classLoader); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateAvailabilityProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */