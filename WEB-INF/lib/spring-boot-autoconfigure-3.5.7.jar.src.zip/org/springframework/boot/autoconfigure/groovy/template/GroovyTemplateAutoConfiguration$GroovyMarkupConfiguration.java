/*     */ package org.springframework.boot.autoconfigure.groovy.template;
/*     */ 
/*     */ import groovy.text.markup.MarkupTemplateEngine;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.context.properties.bind.Bindable;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupConfig;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({GroovyMarkupConfigurer.class})
/*     */ public class GroovyMarkupConfiguration
/*     */ {
/*     */   private final ApplicationContext applicationContext;
/*     */   private final GroovyTemplateProperties properties;
/*     */   
/*     */   public GroovyMarkupConfiguration(ApplicationContext applicationContext, GroovyTemplateProperties properties) {
/*  78 */     this.applicationContext = applicationContext;
/*  79 */     this.properties = properties;
/*  80 */     checkTemplateLocationExists();
/*     */   }
/*     */   
/*     */   public void checkTemplateLocationExists() {
/*  84 */     if (this.properties.isCheckTemplateLocation() && !isUsingGroovyAllJar()) {
/*  85 */       TemplateLocation location = new TemplateLocation(this.properties.getResourceLoaderPath());
/*  86 */       if (!location.exists((ResourcePatternResolver)this.applicationContext)) {
/*  87 */         GroovyTemplateAutoConfiguration.logger.warn(LogMessage.format("Cannot find template location: %s (please add some templates, check your Groovy configuration, or set spring.groovy.template.check-template-location=false)", location));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUsingGroovyAllJar() {
/*     */     try {
/* 104 */       ProtectionDomain domain = MarkupTemplateEngine.class.getProtectionDomain();
/* 105 */       CodeSource codeSource = domain.getCodeSource();
/* 106 */       return (codeSource != null && codeSource.getLocation().toString().contains("-all"));
/*     */     }
/* 108 */     catch (Exception ex) {
/* 109 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({GroovyMarkupConfig.class})
/*     */   GroovyMarkupConfigurer groovyMarkupConfigurer(ObjectProvider<MarkupTemplateEngine> templateEngine, Environment environment) {
/* 117 */     GroovyMarkupConfigurer configurer = new GroovyMarkupConfigurer();
/* 118 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 119 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isAutoEscape).to(configurer::setAutoEscape);
/* 120 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isAutoIndent).to(configurer::setAutoIndent);
/* 121 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getAutoIndentString).to(configurer::setAutoIndentString);
/* 122 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isAutoNewLine).to(configurer::setAutoNewLine);
/* 123 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getBaseTemplateClass).to(configurer::setBaseTemplateClass);
/* 124 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isCache).to(configurer::setCacheTemplates);
/* 125 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getDeclarationEncoding).to(configurer::setDeclarationEncoding);
/* 126 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isExpandEmptyElements).to(configurer::setExpandEmptyElements);
/* 127 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getLocale).to(configurer::setLocale);
/* 128 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getNewLineString).to(configurer::setNewLineString);
/* 129 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::getResourceLoaderPath).to(configurer::setResourceLoaderPath);
/* 130 */     Objects.requireNonNull(this.properties); Objects.requireNonNull(configurer); map.from(this.properties::isUseDoubleQuotes).to(configurer::setUseDoubleQuotes);
/* 131 */     Binder.get(environment).bind("spring.groovy.template.configuration", Bindable.ofInstance(configurer));
/* 132 */     Objects.requireNonNull(configurer); templateEngine.ifAvailable(configurer::setTemplateEngine);
/* 133 */     return configurer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateAutoConfiguration$GroovyMarkupConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */