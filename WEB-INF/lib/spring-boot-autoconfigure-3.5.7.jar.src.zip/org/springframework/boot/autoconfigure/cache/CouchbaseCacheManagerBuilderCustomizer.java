package org.springframework.boot.autoconfigure.cache;

import org.springframework.data.couchbase.cache.CouchbaseCacheManager;

@FunctionalInterface
public interface CouchbaseCacheManagerBuilderCustomizer {
  void customize(CouchbaseCacheManager.CouchbaseCacheManagerBuilder paramCouchbaseCacheManagerBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CouchbaseCacheManagerBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */