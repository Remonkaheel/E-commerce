package org.springframework.boot.autoconfigure.cache;

import javax.cache.CacheManager;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;

@ConditionalOnSingleCandidate(CacheManager.class)
class CustomJCacheCacheManager {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\JCacheCacheConfiguration$JCacheAvailableCondition$CustomJCacheCacheManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */