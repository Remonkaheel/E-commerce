/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.EnumMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CacheConfigurations
/*    */ {
/*    */   private static final Map<CacheType, String> MAPPINGS;
/*    */   
/*    */   static {
/* 37 */     Map<CacheType, String> mappings = new EnumMap<>(CacheType.class);
/* 38 */     mappings.put(CacheType.GENERIC, GenericCacheConfiguration.class.getName());
/* 39 */     mappings.put(CacheType.HAZELCAST, HazelcastCacheConfiguration.class.getName());
/* 40 */     mappings.put(CacheType.INFINISPAN, InfinispanCacheConfiguration.class.getName());
/* 41 */     mappings.put(CacheType.JCACHE, JCacheCacheConfiguration.class.getName());
/* 42 */     mappings.put(CacheType.COUCHBASE, CouchbaseCacheConfiguration.class.getName());
/* 43 */     mappings.put(CacheType.REDIS, RedisCacheConfiguration.class.getName());
/* 44 */     mappings.put(CacheType.CAFFEINE, CaffeineCacheConfiguration.class.getName());
/* 45 */     mappings.put(CacheType.CACHE2K, Cache2kCacheConfiguration.class.getName());
/* 46 */     mappings.put(CacheType.SIMPLE, SimpleCacheConfiguration.class.getName());
/* 47 */     mappings.put(CacheType.NONE, NoOpCacheConfiguration.class.getName());
/* 48 */     MAPPINGS = Collections.unmodifiableMap(mappings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String getConfigurationClass(CacheType cacheType) {
/* 55 */     String configurationClassName = MAPPINGS.get(cacheType);
/* 56 */     Assert.state((configurationClassName != null), () -> "Unknown cache type " + String.valueOf(cacheType));
/* 57 */     return configurationClassName;
/*    */   }
/*    */   
/*    */   static CacheType getType(String configurationClassName) {
/* 61 */     for (Map.Entry<CacheType, String> entry : MAPPINGS.entrySet()) {
/* 62 */       if (((String)entry.getValue()).equals(configurationClassName)) {
/* 63 */         return entry.getKey();
/*    */       }
/*    */     } 
/* 66 */     throw new IllegalStateException("Unknown configuration class " + configurationClassName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheConfigurations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */