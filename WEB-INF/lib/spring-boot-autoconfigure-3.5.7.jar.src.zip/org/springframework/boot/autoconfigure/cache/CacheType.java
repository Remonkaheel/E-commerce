/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CacheType
/*    */ {
/* 32 */   GENERIC,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   JCACHE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   HAZELCAST,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   COUCHBASE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   INFINISPAN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   REDIS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   CACHE2K,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   CAFFEINE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   SIMPLE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   NONE;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */