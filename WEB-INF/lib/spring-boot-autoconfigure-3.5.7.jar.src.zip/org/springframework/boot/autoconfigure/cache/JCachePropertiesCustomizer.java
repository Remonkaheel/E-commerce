package org.springframework.boot.autoconfigure.cache;

import java.util.Properties;

public interface JCachePropertiesCustomizer {
  void customize(Properties paramProperties);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\JCachePropertiesCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */