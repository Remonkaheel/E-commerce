package org.springframework.boot.autoconfigure.cache;

@FunctionalInterface
public interface CacheManagerCustomizer<T extends org.springframework.cache.CacheManager> {
  void customize(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheManagerCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */