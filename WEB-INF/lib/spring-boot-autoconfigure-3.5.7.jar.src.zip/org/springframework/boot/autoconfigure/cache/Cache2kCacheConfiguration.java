/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.function.Function;
/*    */ import org.cache2k.Cache2kBuilder;
/*    */ import org.cache2k.extra.spring.SpringCache2kCacheManager;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Cache2kBuilder.class, SpringCache2kCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ class Cache2kCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   SpringCache2kCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<Cache2kBuilderCustomizer> cache2kBuilderCustomizers) {
/* 49 */     SpringCache2kCacheManager cacheManager = new SpringCache2kCacheManager();
/* 50 */     cacheManager.defaultSetup(configureDefaults(cache2kBuilderCustomizers));
/* 51 */     Collection<String> cacheNames = cacheProperties.getCacheNames();
/* 52 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/* 53 */       cacheManager.setDefaultCacheNames(cacheNames);
/*    */     }
/* 55 */     return customizers.<SpringCache2kCacheManager>customize(cacheManager);
/*    */   }
/*    */ 
/*    */   
/*    */   private Function<Cache2kBuilder<?, ?>, Cache2kBuilder<?, ?>> configureDefaults(ObjectProvider<Cache2kBuilderCustomizer> cache2kBuilderCustomizers) {
/* 60 */     return builder -> {
/*    */         cache2kBuilderCustomizers.orderedStream().forEach(());
/*    */         return builder;
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\Cache2kCacheConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */