/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.couchbase.client.java.Cluster;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.CouchbaseClientFactory;
/*    */ import org.springframework.data.couchbase.cache.CouchbaseCacheManager;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({Cluster.class, CouchbaseClientFactory.class, CouchbaseCacheManager.class})
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @ConditionalOnSingleCandidate(CouchbaseClientFactory.class)
/*    */ @Conditional({CacheCondition.class})
/*    */ class CouchbaseCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   CouchbaseCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers customizers, ObjectProvider<CouchbaseCacheManagerBuilderCustomizer> couchbaseCacheManagerBuilderCustomizers, CouchbaseClientFactory clientFactory) {
/* 54 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 55 */     CouchbaseCacheManager.CouchbaseCacheManagerBuilder builder = CouchbaseCacheManager.builder(clientFactory);
/* 56 */     CacheProperties.Couchbase couchbase = cacheProperties.getCouchbase();
/*    */     
/* 58 */     org.springframework.data.couchbase.cache.CouchbaseCacheConfiguration config = org.springframework.data.couchbase.cache.CouchbaseCacheConfiguration.defaultCacheConfig();
/* 59 */     if (couchbase.getExpiration() != null) {
/* 60 */       config = config.entryExpiry(couchbase.getExpiration());
/*    */     }
/* 62 */     builder.cacheDefaults(config);
/* 63 */     if (!ObjectUtils.isEmpty(cacheNames)) {
/* 64 */       builder.initialCacheNames(new LinkedHashSet<>(cacheNames));
/*    */     }
/* 66 */     couchbaseCacheManagerBuilderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 67 */     CouchbaseCacheManager cacheManager = builder.build();
/* 68 */     return customizers.<CouchbaseCacheManager>customize(cacheManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CouchbaseCacheConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */