/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.util.LambdaSafe;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheManagerCustomizers
/*    */ {
/*    */   private final List<CacheManagerCustomizer<?>> customizers;
/*    */   
/*    */   public CacheManagerCustomizers(List<? extends CacheManagerCustomizer<?>> customizers) {
/* 38 */     this.customizers = (customizers != null) ? new ArrayList<>(customizers) : Collections.<CacheManagerCustomizer<?>>emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends CacheManager> T customize(T cacheManager) {
/* 51 */     ((LambdaSafe.Callbacks)LambdaSafe.callbacks(CacheManagerCustomizer.class, this.customizers, cacheManager, new Object[0])
/* 52 */       .withLogger(CacheManagerCustomizers.class))
/* 53 */       .invoke(customizer -> customizer.customize(cacheManager));
/* 54 */     return cacheManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheManagerCustomizers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */