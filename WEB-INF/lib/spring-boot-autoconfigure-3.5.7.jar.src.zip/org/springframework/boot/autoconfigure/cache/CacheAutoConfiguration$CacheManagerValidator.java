/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CacheManagerValidator
/*     */   implements InitializingBean
/*     */ {
/*     */   private final CacheProperties cacheProperties;
/*     */   private final ObjectProvider<CacheManager> cacheManager;
/*     */   
/*     */   CacheManagerValidator(CacheProperties cacheProperties, ObjectProvider<CacheManager> cacheManager) {
/*  99 */     this.cacheProperties = cacheProperties;
/* 100 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 105 */     Assert.state((this.cacheManager.getIfAvailable() != null), () -> "No cache manager could be auto-configured, check your configuration (caching type is '" + String.valueOf(this.cacheProperties.getType()) + "')");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheAutoConfiguration$CacheManagerValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */