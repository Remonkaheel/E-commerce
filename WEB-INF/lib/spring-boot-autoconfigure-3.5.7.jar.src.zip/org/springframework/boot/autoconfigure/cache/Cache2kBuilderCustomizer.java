package org.springframework.boot.autoconfigure.cache;

import org.cache2k.Cache2kBuilder;

public interface Cache2kBuilderCustomizer {
  void customize(Cache2kBuilder<?, ?> paramCache2kBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\Cache2kBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */