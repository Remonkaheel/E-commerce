/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.context.properties.bind.BindException;
/*    */ import org.springframework.boot.context.properties.bind.BindResult;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 42 */     Assert.isInstanceOf(AnnotationMetadata.class, metadata);
/* 43 */     return extracted(context, (AnnotationMetadata)metadata);
/*    */   }
/*    */   
/*    */   private ConditionOutcome extracted(ConditionContext context, AnnotationMetadata metadata) {
/* 47 */     String sourceClass = metadata.getClassName();
/* 48 */     ConditionMessage.Builder message = ConditionMessage.forCondition("Cache", new Object[] { sourceClass });
/* 49 */     Environment environment = context.getEnvironment();
/*    */     try {
/* 51 */       BindResult<CacheType> specified = Binder.get(environment).bind("spring.cache.type", CacheType.class);
/* 52 */       if (!specified.isBound()) {
/* 53 */         return ConditionOutcome.match(message.because("automatic cache type"));
/*    */       }
/* 55 */       CacheType required = CacheConfigurations.getType(metadata.getClassName());
/* 56 */       if (specified.get() == required) {
/* 57 */         return ConditionOutcome.match(message.because(String.valueOf(specified.get()) + " cache type"));
/*    */       }
/*    */     }
/* 60 */     catch (BindException bindException) {}
/*    */ 
/*    */     
/* 63 */     return ConditionOutcome.noMatch(message.because("unknown cache type"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */