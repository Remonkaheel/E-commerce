/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.data.couchbase.CouchbaseDataAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.interceptor.CacheAspectSupport;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportSelector;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {CouchbaseDataAutoConfiguration.class, HazelcastAutoConfiguration.class, HibernateJpaAutoConfiguration.class, RedisAutoConfiguration.class})
/*     */ @ConditionalOnClass({CacheManager.class})
/*     */ @ConditionalOnBean({CacheAspectSupport.class})
/*     */ @ConditionalOnMissingBean(value = {CacheManager.class}, name = {"cacheResolver"})
/*     */ @EnableConfigurationProperties({CacheProperties.class})
/*     */ @Import({CacheAutoConfiguration.CacheConfigurationImportSelector.class, CacheAutoConfiguration.CacheManagerEntityManagerFactoryDependsOnPostProcessor.class})
/*     */ public class CacheAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CacheManagerCustomizers cacheManagerCustomizers(ObjectProvider<CacheManagerCustomizer<?>> customizers) {
/*  68 */     return new CacheManagerCustomizers(customizers.orderedStream().toList());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public CacheManagerValidator cacheAutoConfigurationValidator(CacheProperties cacheProperties, ObjectProvider<CacheManager> cacheManager) {
/*  74 */     return new CacheManagerValidator(cacheProperties, cacheManager);
/*     */   }
/*     */   
/*     */   @ConditionalOnClass({LocalContainerEntityManagerFactoryBean.class})
/*     */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*     */   static class CacheManagerEntityManagerFactoryDependsOnPostProcessor
/*     */     extends EntityManagerFactoryDependsOnPostProcessor
/*     */   {
/*     */     CacheManagerEntityManagerFactoryDependsOnPostProcessor() {
/*  83 */       super(new String[] { "cacheManager" });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CacheManagerValidator
/*     */     implements InitializingBean
/*     */   {
/*     */     private final CacheProperties cacheProperties;
/*     */ 
/*     */     
/*     */     private final ObjectProvider<CacheManager> cacheManager;
/*     */ 
/*     */     
/*     */     CacheManagerValidator(CacheProperties cacheProperties, ObjectProvider<CacheManager> cacheManager) {
/*  99 */       this.cacheProperties = cacheProperties;
/* 100 */       this.cacheManager = cacheManager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() {
/* 105 */       Assert.state((this.cacheManager.getIfAvailable() != null), () -> "No cache manager could be auto-configured, check your configuration (caching type is '" + String.valueOf(this.cacheProperties.getType()) + "')");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CacheConfigurationImportSelector
/*     */     implements ImportSelector
/*     */   {
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 119 */       CacheType[] types = CacheType.values();
/* 120 */       String[] imports = new String[types.length];
/* 121 */       for (int i = 0; i < types.length; i++) {
/* 122 */         imports[i] = CacheConfigurations.getConfigurationClass(types[i]);
/*     */       }
/* 124 */       return imports;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */