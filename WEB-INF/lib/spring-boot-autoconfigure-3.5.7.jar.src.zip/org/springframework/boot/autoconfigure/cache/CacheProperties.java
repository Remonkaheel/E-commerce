/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.cache")
/*     */ public class CacheProperties
/*     */ {
/*     */   private CacheType type;
/*  47 */   private List<String> cacheNames = new ArrayList<>();
/*     */   
/*  49 */   private final Caffeine caffeine = new Caffeine();
/*     */   
/*  51 */   private final Couchbase couchbase = new Couchbase();
/*     */   
/*  53 */   private final Infinispan infinispan = new Infinispan();
/*     */   
/*  55 */   private final JCache jcache = new JCache();
/*     */   
/*  57 */   private final Redis redis = new Redis();
/*     */   
/*     */   public CacheType getType() {
/*  60 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(CacheType mode) {
/*  64 */     this.type = mode;
/*     */   }
/*     */   
/*     */   public List<String> getCacheNames() {
/*  68 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */   public void setCacheNames(List<String> cacheNames) {
/*  72 */     this.cacheNames = cacheNames;
/*     */   }
/*     */   
/*     */   public Caffeine getCaffeine() {
/*  76 */     return this.caffeine;
/*     */   }
/*     */   
/*     */   public Couchbase getCouchbase() {
/*  80 */     return this.couchbase;
/*     */   }
/*     */   
/*     */   public Infinispan getInfinispan() {
/*  84 */     return this.infinispan;
/*     */   }
/*     */   
/*     */   public JCache getJcache() {
/*  88 */     return this.jcache;
/*     */   }
/*     */   
/*     */   public Redis getRedis() {
/*  92 */     return this.redis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resource resolveConfigLocation(Resource config) {
/* 103 */     if (config != null) {
/* 104 */       Assert.isTrue(config.exists(), () -> "'config' resource [%s] must exist".formatted(new Object[] { config.getDescription() }));
/*     */       
/* 106 */       return config;
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Caffeine
/*     */   {
/*     */     private String spec;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSpec() {
/* 123 */       return this.spec;
/*     */     }
/*     */     
/*     */     public void setSpec(String spec) {
/* 127 */       this.spec = spec;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Couchbase
/*     */   {
/*     */     private Duration expiration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getExpiration() {
/* 144 */       return this.expiration;
/*     */     }
/*     */     
/*     */     public void setExpiration(Duration expiration) {
/* 148 */       this.expiration = expiration;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Infinispan
/*     */   {
/*     */     private Resource config;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Resource getConfig() {
/* 164 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 168 */       this.config = config;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JCache
/*     */   {
/*     */     private Resource config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String provider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProvider() {
/* 192 */       return this.provider;
/*     */     }
/*     */     
/*     */     public void setProvider(String provider) {
/* 196 */       this.provider = provider;
/*     */     }
/*     */     
/*     */     public Resource getConfig() {
/* 200 */       return this.config;
/*     */     }
/*     */     
/*     */     public void setConfig(Resource config) {
/* 204 */       this.config = config;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Redis
/*     */   {
/*     */     private Duration timeToLive;
/*     */     
/*     */     private boolean cacheNullValues;
/*     */     
/*     */     private String keyPrefix;
/*     */     
/*     */     private boolean useKeyPrefix;
/*     */     
/*     */     private boolean enableStatistics;
/*     */     
/*     */     public Redis() {
/* 222 */       this.cacheNullValues = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 232 */       this.useKeyPrefix = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getTimeToLive() {
/* 240 */       return this.timeToLive;
/*     */     }
/*     */     
/*     */     public void setTimeToLive(Duration timeToLive) {
/* 244 */       this.timeToLive = timeToLive;
/*     */     }
/*     */     
/*     */     public boolean isCacheNullValues() {
/* 248 */       return this.cacheNullValues;
/*     */     }
/*     */     
/*     */     public void setCacheNullValues(boolean cacheNullValues) {
/* 252 */       this.cacheNullValues = cacheNullValues;
/*     */     }
/*     */     
/*     */     public String getKeyPrefix() {
/* 256 */       return this.keyPrefix;
/*     */     }
/*     */     
/*     */     public void setKeyPrefix(String keyPrefix) {
/* 260 */       this.keyPrefix = keyPrefix;
/*     */     }
/*     */     
/*     */     public boolean isUseKeyPrefix() {
/* 264 */       return this.useKeyPrefix;
/*     */     }
/*     */     
/*     */     public void setUseKeyPrefix(boolean useKeyPrefix) {
/* 268 */       this.useKeyPrefix = useKeyPrefix;
/*     */     }
/*     */     
/*     */     public boolean isEnableStatistics() {
/* 272 */       return this.enableStatistics;
/*     */     }
/*     */     
/*     */     public void setEnableStatistics(boolean enableStatistics) {
/* 276 */       this.enableStatistics = enableStatistics;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */