/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Redis
/*     */ {
/*     */   private Duration timeToLive;
/*     */   private boolean cacheNullValues = true;
/*     */   private String keyPrefix;
/*     */   private boolean useKeyPrefix = true;
/*     */   private boolean enableStatistics;
/*     */   
/*     */   public Duration getTimeToLive() {
/* 240 */     return this.timeToLive;
/*     */   }
/*     */   
/*     */   public void setTimeToLive(Duration timeToLive) {
/* 244 */     this.timeToLive = timeToLive;
/*     */   }
/*     */   
/*     */   public boolean isCacheNullValues() {
/* 248 */     return this.cacheNullValues;
/*     */   }
/*     */   
/*     */   public void setCacheNullValues(boolean cacheNullValues) {
/* 252 */     this.cacheNullValues = cacheNullValues;
/*     */   }
/*     */   
/*     */   public String getKeyPrefix() {
/* 256 */     return this.keyPrefix;
/*     */   }
/*     */   
/*     */   public void setKeyPrefix(String keyPrefix) {
/* 260 */     this.keyPrefix = keyPrefix;
/*     */   }
/*     */   
/*     */   public boolean isUseKeyPrefix() {
/* 264 */     return this.useKeyPrefix;
/*     */   }
/*     */   
/*     */   public void setUseKeyPrefix(boolean useKeyPrefix) {
/* 268 */     this.useKeyPrefix = useKeyPrefix;
/*     */   }
/*     */   
/*     */   public boolean isEnableStatistics() {
/* 272 */     return this.enableStatistics;
/*     */   }
/*     */   
/*     */   public void setEnableStatistics(boolean enableStatistics) {
/* 276 */     this.enableStatistics = enableStatistics;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\CacheProperties$Redis.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */