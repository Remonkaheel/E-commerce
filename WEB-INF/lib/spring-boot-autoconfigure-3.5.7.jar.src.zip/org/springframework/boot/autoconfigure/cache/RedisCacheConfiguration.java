/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.data.redis.cache.RedisCacheManager;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
/*     */ import org.springframework.data.redis.serializer.RedisSerializationContext;
/*     */ import org.springframework.data.redis.serializer.RedisSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({RedisConnectionFactory.class})
/*     */ @AutoConfigureAfter({RedisAutoConfiguration.class})
/*     */ @ConditionalOnBean({RedisConnectionFactory.class})
/*     */ @ConditionalOnMissingBean({CacheManager.class})
/*     */ @Conditional({CacheCondition.class})
/*     */ class RedisCacheConfiguration
/*     */ {
/*     */   @Bean
/*     */   RedisCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers cacheManagerCustomizers, ObjectProvider<org.springframework.data.redis.cache.RedisCacheConfiguration> redisCacheConfiguration, ObjectProvider<RedisCacheManagerBuilderCustomizer> redisCacheManagerBuilderCustomizers, RedisConnectionFactory redisConnectionFactory, ResourceLoader resourceLoader) {
/*  61 */     RedisCacheManager.RedisCacheManagerBuilder builder = RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(
/*  62 */         determineConfiguration(cacheProperties, redisCacheConfiguration, resourceLoader.getClassLoader()));
/*  63 */     List<String> cacheNames = cacheProperties.getCacheNames();
/*  64 */     if (!cacheNames.isEmpty()) {
/*  65 */       builder.initialCacheNames(new LinkedHashSet<>(cacheNames));
/*     */     }
/*  67 */     if (cacheProperties.getRedis().isEnableStatistics()) {
/*  68 */       builder.enableStatistics();
/*     */     }
/*  70 */     redisCacheManagerBuilderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  71 */     return cacheManagerCustomizers.<RedisCacheManager>customize(builder.build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private org.springframework.data.redis.cache.RedisCacheConfiguration determineConfiguration(CacheProperties cacheProperties, ObjectProvider<org.springframework.data.redis.cache.RedisCacheConfiguration> redisCacheConfiguration, ClassLoader classLoader) {
/*  78 */     return (org.springframework.data.redis.cache.RedisCacheConfiguration)redisCacheConfiguration.getIfAvailable(() -> createConfiguration(cacheProperties, classLoader));
/*     */   }
/*     */ 
/*     */   
/*     */   private org.springframework.data.redis.cache.RedisCacheConfiguration createConfiguration(CacheProperties cacheProperties, ClassLoader classLoader) {
/*  83 */     CacheProperties.Redis redisProperties = cacheProperties.getRedis();
/*     */     
/*  85 */     org.springframework.data.redis.cache.RedisCacheConfiguration config = org.springframework.data.redis.cache.RedisCacheConfiguration.defaultCacheConfig();
/*     */     
/*  87 */     config = config.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer((RedisSerializer)new JdkSerializationRedisSerializer(classLoader)));
/*  88 */     if (redisProperties.getTimeToLive() != null) {
/*  89 */       config = config.entryTtl(redisProperties.getTimeToLive());
/*     */     }
/*  91 */     if (redisProperties.getKeyPrefix() != null) {
/*  92 */       config = config.prefixCacheNameWith(redisProperties.getKeyPrefix());
/*     */     }
/*  94 */     if (!redisProperties.isCacheNullValues()) {
/*  95 */       config = config.disableCachingNullValues();
/*     */     }
/*  97 */     if (!redisProperties.isUseKeyPrefix()) {
/*  98 */       config = config.disableKeyPrefix();
/*     */     }
/* 100 */     return config;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\RedisCacheConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */