/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnClass({HazelcastInstance.class})
/*    */ class HazelcastJCacheCustomizationConfiguration
/*    */ {
/*    */   @Bean
/*    */   HazelcastPropertiesCustomizer hazelcastPropertiesCustomizer(ObjectProvider<HazelcastInstance> hazelcastInstance, CacheProperties cacheProperties) {
/* 43 */     return new HazelcastPropertiesCustomizer((HazelcastInstance)hazelcastInstance.getIfUnique(), cacheProperties);
/*    */   }
/*    */   
/*    */   static class HazelcastPropertiesCustomizer
/*    */     implements JCachePropertiesCustomizer
/*    */   {
/*    */     private final HazelcastInstance hazelcastInstance;
/*    */     private final CacheProperties cacheProperties;
/*    */     
/*    */     HazelcastPropertiesCustomizer(HazelcastInstance hazelcastInstance, CacheProperties cacheProperties) {
/* 53 */       this.hazelcastInstance = hazelcastInstance;
/* 54 */       this.cacheProperties = cacheProperties;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void customize(Properties properties) {
/* 60 */       Resource configLocation = this.cacheProperties.resolveConfigLocation(this.cacheProperties.getJcache().getConfig());
/* 61 */       if (configLocation != null) {
/*    */         
/* 63 */         properties.setProperty("hazelcast.config.location", toUri(configLocation).toString());
/*    */       }
/* 65 */       else if (this.hazelcastInstance != null) {
/* 66 */         properties.put("hazelcast.instance.itself", this.hazelcastInstance);
/*    */       } 
/*    */     }
/*    */     
/*    */     private static URI toUri(Resource config) {
/*    */       try {
/* 72 */         return config.getURI();
/*    */       }
/* 74 */       catch (IOException ex) {
/* 75 */         throw new IllegalArgumentException("Could not get URI from " + String.valueOf(config), ex);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\HazelcastJCacheCustomizationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */