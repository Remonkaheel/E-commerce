/*     */ package org.springframework.boot.autoconfigure.cache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Supplier;
/*     */ import javax.cache.CacheManager;
/*     */ import javax.cache.Caching;
/*     */ import javax.cache.configuration.Configuration;
/*     */ import javax.cache.spi.CachingProvider;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.cache.jcache.JCacheCacheManager;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({Caching.class, JCacheCacheManager.class})
/*     */ @ConditionalOnMissingBean({CacheManager.class})
/*     */ @Conditional({CacheCondition.class, JCacheCacheConfiguration.JCacheAvailableCondition.class})
/*     */ @Import({HazelcastJCacheCustomizationConfiguration.class})
/*     */ class JCacheCacheConfiguration
/*     */   implements BeanClassLoaderAware
/*     */ {
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  68 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   JCacheCacheManager cacheManager(CacheManagerCustomizers customizers, CacheManager jCacheCacheManager) {
/*  73 */     JCacheCacheManager cacheManager = new JCacheCacheManager(jCacheCacheManager);
/*  74 */     return customizers.<JCacheCacheManager>customize(cacheManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   CacheManager jCacheCacheManager(CacheProperties cacheProperties, ObjectProvider<Configuration<?, ?>> defaultCacheConfiguration, ObjectProvider<JCacheManagerCustomizer> cacheManagerCustomizers, ObjectProvider<JCachePropertiesCustomizer> cachePropertiesCustomizers) throws IOException {
/*  83 */     CacheManager jCacheCacheManager = createCacheManager(cacheProperties, cachePropertiesCustomizers);
/*  84 */     List<String> cacheNames = cacheProperties.getCacheNames();
/*  85 */     if (!CollectionUtils.isEmpty(cacheNames)) {
/*  86 */       for (String cacheName : cacheNames) {
/*  87 */         jCacheCacheManager.createCache(cacheName, (Configuration)defaultCacheConfiguration
/*  88 */             .getIfAvailable(javax.cache.configuration.MutableConfiguration::new));
/*     */       }
/*     */     }
/*  91 */     cacheManagerCustomizers.orderedStream().forEach(customizer -> customizer.customize(jCacheCacheManager));
/*  92 */     return jCacheCacheManager;
/*     */   }
/*     */ 
/*     */   
/*     */   private CacheManager createCacheManager(CacheProperties cacheProperties, ObjectProvider<JCachePropertiesCustomizer> cachePropertiesCustomizers) throws IOException {
/*  97 */     CachingProvider cachingProvider = getCachingProvider(cacheProperties.getJcache().getProvider());
/*  98 */     Properties properties = createCacheManagerProperties(cachePropertiesCustomizers);
/*  99 */     Resource configLocation = cacheProperties.resolveConfigLocation(cacheProperties.getJcache().getConfig());
/* 100 */     if (configLocation != null) {
/* 101 */       return cachingProvider.getCacheManager(configLocation.getURI(), this.beanClassLoader, properties);
/*     */     }
/* 103 */     return cachingProvider.getCacheManager(null, this.beanClassLoader, properties);
/*     */   }
/*     */   
/*     */   private CachingProvider getCachingProvider(String cachingProviderFqn) {
/* 107 */     if (StringUtils.hasText(cachingProviderFqn)) {
/* 108 */       return Caching.getCachingProvider(cachingProviderFqn);
/*     */     }
/* 110 */     return Caching.getCachingProvider();
/*     */   }
/*     */ 
/*     */   
/*     */   private Properties createCacheManagerProperties(ObjectProvider<JCachePropertiesCustomizer> cachePropertiesCustomizers) {
/* 115 */     Properties properties = new Properties();
/* 116 */     cachePropertiesCustomizers.orderedStream().forEach(customizer -> customizer.customize(properties));
/* 117 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Order(2147483647)
/*     */   static class JCacheAvailableCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     JCacheAvailableCondition() {
/* 129 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */ 
/*     */     
/*     */     @Conditional({JCacheCacheConfiguration.JCacheProviderAvailableCondition.class})
/*     */     static class JCacheProvider {}
/*     */ 
/*     */     
/*     */     @ConditionalOnSingleCandidate(CacheManager.class)
/*     */     static class CustomJCacheCacheManager {}
/*     */   }
/*     */ 
/*     */   
/*     */   @Conditional({JCacheProviderAvailableCondition.class})
/*     */   static class JCacheProvider {}
/*     */ 
/*     */   
/*     */   @ConditionalOnSingleCandidate(CacheManager.class)
/*     */   static class CustomJCacheCacheManager {}
/*     */   
/*     */   @Order(2147483647)
/*     */   static class JCacheProviderAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 154 */       ConditionMessage.Builder message = ConditionMessage.forCondition("JCache", new Object[0]);
/* 155 */       String providerProperty = "spring.cache.jcache.provider";
/* 156 */       if (context.getEnvironment().containsProperty(providerProperty)) {
/* 157 */         return ConditionOutcome.match(message.because("JCache provider specified"));
/*     */       }
/* 159 */       Iterator<CachingProvider> providers = Caching.getCachingProviders().iterator();
/* 160 */       if (!providers.hasNext()) {
/* 161 */         return ConditionOutcome.noMatch(message.didNotFind("JSR-107 provider").atAll());
/*     */       }
/* 163 */       providers.next();
/* 164 */       if (providers.hasNext()) {
/* 165 */         return ConditionOutcome.noMatch(message.foundExactly("multiple JSR-107 providers"));
/*     */       }
/* 167 */       return ConditionOutcome.match(message.foundExactly("single JSR-107 provider"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cache\JCacheCacheConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */