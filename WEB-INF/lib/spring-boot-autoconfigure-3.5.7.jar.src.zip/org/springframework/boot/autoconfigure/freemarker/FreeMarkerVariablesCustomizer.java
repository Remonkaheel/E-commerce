package org.springframework.boot.autoconfigure.freemarker;

import java.util.Map;

@FunctionalInterface
public interface FreeMarkerVariablesCustomizer {
  void customizeFreeMarkerVariables(Map<String, Object> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerVariablesCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */