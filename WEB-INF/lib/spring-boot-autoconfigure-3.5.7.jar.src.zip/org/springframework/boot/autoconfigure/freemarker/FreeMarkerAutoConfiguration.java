/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.core.io.support.ResourcePatternResolver;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration
/*    */ @ConditionalOnClass({Configuration.class, FreeMarkerConfigurationFactory.class})
/*    */ @EnableConfigurationProperties({FreeMarkerProperties.class})
/*    */ @Import({FreeMarkerServletWebConfiguration.class, FreeMarkerReactiveWebConfiguration.class, FreeMarkerNonWebConfiguration.class})
/*    */ public class FreeMarkerAutoConfiguration
/*    */ {
/* 49 */   private static final Log logger = LogFactory.getLog(FreeMarkerAutoConfiguration.class);
/*    */   
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   private final FreeMarkerProperties properties;
/*    */   
/*    */   public FreeMarkerAutoConfiguration(ApplicationContext applicationContext, FreeMarkerProperties properties) {
/* 56 */     this.applicationContext = applicationContext;
/* 57 */     this.properties = properties;
/* 58 */     checkTemplateLocationExists();
/*    */   }
/*    */   
/*    */   public void checkTemplateLocationExists() {
/* 62 */     if (logger.isWarnEnabled() && this.properties.isCheckTemplateLocation()) {
/* 63 */       List<TemplateLocation> locations = getLocations();
/* 64 */       if (locations.stream().noneMatch(this::locationExists)) {
/* 65 */         String suffix = (locations.size() == 1) ? "" : "s";
/* 66 */         logger.warn("Cannot find template location" + suffix + ": " + String.valueOf(locations) + " (please add some templates, check your FreeMarker configuration, or set spring.freemarker.check-template-location=false)");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private List<TemplateLocation> getLocations() {
/* 74 */     List<TemplateLocation> locations = new ArrayList<>();
/* 75 */     for (String templateLoaderPath : this.properties.getTemplateLoaderPath()) {
/* 76 */       TemplateLocation location = new TemplateLocation(templateLoaderPath);
/* 77 */       locations.add(location);
/*    */     } 
/* 79 */     return locations;
/*    */   }
/*    */   
/*    */   private boolean locationExists(TemplateLocation location) {
/* 83 */     return location.exists((ResourcePatternResolver)this.applicationContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */