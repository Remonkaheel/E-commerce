/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import jakarta.servlet.DispatcherType;
/*    */ import jakarta.servlet.Filter;
/*    */ import jakarta.servlet.Servlet;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.ConditionalOnMissingFilterBean;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*    */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({Servlet.class, FreeMarkerConfigurer.class})
/*    */ @AutoConfigureAfter({WebMvcAutoConfiguration.class})
/*    */ class FreeMarkerServletWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   protected FreeMarkerServletWebConfiguration(FreeMarkerProperties properties, ObjectProvider<FreeMarkerVariablesCustomizer> variablesCustomizers) {
/* 54 */     super(properties, variablesCustomizers);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({FreeMarkerConfig.class})
/*    */   FreeMarkerConfigurer freeMarkerConfigurer() {
/* 60 */     FreeMarkerConfigurer configurer = new FreeMarkerConfigurer();
/* 61 */     applyProperties((FreeMarkerConfigurationFactory)configurer);
/* 62 */     return configurer;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   Configuration freeMarkerConfiguration(FreeMarkerConfig configurer) {
/* 67 */     return configurer.getConfiguration();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"freeMarkerViewResolver"})
/*    */   @ConditionalOnBooleanProperty(name = {"spring.freemarker.enabled"}, matchIfMissing = true)
/*    */   FreeMarkerViewResolver freeMarkerViewResolver() {
/* 74 */     FreeMarkerViewResolver resolver = new FreeMarkerViewResolver();
/* 75 */     getProperties().applyToMvcViewResolver(resolver);
/* 76 */     return resolver;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnEnabledResourceChain
/*    */   @ConditionalOnMissingFilterBean
/*    */   FilterRegistrationBean<ResourceUrlEncodingFilter> resourceUrlEncodingFilter() {
/* 83 */     FilterRegistrationBean<ResourceUrlEncodingFilter> registration = new FilterRegistrationBean((Filter)new ResourceUrlEncodingFilter(), new org.springframework.boot.web.servlet.ServletRegistrationBean[0]);
/*    */     
/* 85 */     registration.setDispatcherTypes(DispatcherType.REQUEST, new DispatcherType[] { DispatcherType.ERROR });
/* 86 */     return registration;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerServletWebConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */