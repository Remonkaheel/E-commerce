/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.boot.context.properties.bind.BindableRuntimeHintsRegistrar;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FreeMarkerTemplateAvailabilityRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 73 */     if (ClassUtils.isPresent("freemarker.template.Configuration", classLoader))
/* 74 */       BindableRuntimeHintsRegistrar.forTypes(new Class[] { FreeMarkerTemplateAvailabilityProvider.FreeMarkerTemplateAvailabilityProperties.class
/* 75 */           }).registerHints(hints, classLoader); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerTemplateAvailabilityProvider$FreeMarkerTemplateAvailabilityRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */