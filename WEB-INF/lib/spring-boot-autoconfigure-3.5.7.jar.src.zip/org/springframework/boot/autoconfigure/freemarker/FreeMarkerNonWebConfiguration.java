/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnNotWebApplication
/*    */ class FreeMarkerNonWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   FreeMarkerNonWebConfiguration(FreeMarkerProperties properties, ObjectProvider<FreeMarkerVariablesCustomizer> variablesCustomizers) {
/* 38 */     super(properties, variablesCustomizers);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   FreeMarkerConfigurationFactoryBean freeMarkerConfiguration() {
/* 44 */     FreeMarkerConfigurationFactoryBean freeMarkerFactoryBean = new FreeMarkerConfigurationFactoryBean();
/* 45 */     applyProperties((FreeMarkerConfigurationFactory)freeMarkerFactoryBean);
/* 46 */     return freeMarkerFactoryBean;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerNonWebConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */