/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FreeMarkerTemplateAvailabilityProperties
/*    */   extends PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties
/*    */ {
/* 47 */   private List<String> templateLoaderPath = new ArrayList<>(
/* 48 */       Arrays.asList(new String[] { "classpath:/templates/" }));
/*    */   
/*    */   FreeMarkerTemplateAvailabilityProperties() {
/* 51 */     super("", ".ftlh");
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<String> getLoaderPath() {
/* 56 */     return this.templateLoaderPath;
/*    */   }
/*    */   
/*    */   public List<String> getTemplateLoaderPath() {
/* 60 */     return this.templateLoaderPath;
/*    */   }
/*    */   
/*    */   public void setTemplateLoaderPath(List<String> templateLoaderPath) {
/* 64 */     this.templateLoaderPath = templateLoaderPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerTemplateAvailabilityProvider$FreeMarkerTemplateAvailabilityProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */