/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractFreeMarkerConfiguration
/*    */ {
/*    */   private final FreeMarkerProperties properties;
/*    */   private final List<FreeMarkerVariablesCustomizer> variablesCustomizers;
/*    */   
/*    */   protected AbstractFreeMarkerConfiguration(FreeMarkerProperties properties, ObjectProvider<FreeMarkerVariablesCustomizer> variablesCustomizers) {
/* 41 */     this.properties = properties;
/* 42 */     this.variablesCustomizers = variablesCustomizers.orderedStream().toList();
/*    */   }
/*    */   
/*    */   protected final FreeMarkerProperties getProperties() {
/* 46 */     return this.properties;
/*    */   }
/*    */   
/*    */   protected void applyProperties(FreeMarkerConfigurationFactory factory) {
/* 50 */     factory.setTemplateLoaderPaths(this.properties.getTemplateLoaderPath());
/* 51 */     factory.setPreferFileSystemAccess(this.properties.isPreferFileSystemAccess());
/* 52 */     factory.setDefaultEncoding(this.properties.getCharsetName());
/* 53 */     factory.setFreemarkerSettings(createFreeMarkerSettings());
/* 54 */     factory.setFreemarkerVariables(createFreeMarkerVariables());
/*    */   }
/*    */   
/*    */   private Properties createFreeMarkerSettings() {
/* 58 */     Properties settings = new Properties();
/* 59 */     settings.put("recognize_standard_file_extensions", "true");
/* 60 */     settings.putAll(this.properties.getSettings());
/* 61 */     return settings;
/*    */   }
/*    */   
/*    */   private Map<String, Object> createFreeMarkerVariables() {
/* 65 */     Map<String, Object> variables = new HashMap<>();
/* 66 */     for (FreeMarkerVariablesCustomizer customizer : this.variablesCustomizers) {
/* 67 */       customizer.customizeFreeMarkerVariables(variables);
/*    */     }
/* 69 */     return variables;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\AbstractFreeMarkerConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */