/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.freemarker")
/*    */ public class FreeMarkerProperties
/*    */   extends AbstractTemplateViewResolverProperties
/*    */ {
/*    */   public static final String DEFAULT_TEMPLATE_LOADER_PATH = "classpath:/templates/";
/*    */   public static final String DEFAULT_PREFIX = "";
/*    */   public static final String DEFAULT_SUFFIX = ".ftlh";
/* 44 */   private Map<String, String> settings = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   private String[] templateLoaderPath = new String[] { "classpath:/templates/" };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean preferFileSystemAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FreeMarkerProperties() {
/* 60 */     super("", ".ftlh");
/*    */   }
/*    */   
/*    */   public Map<String, String> getSettings() {
/* 64 */     return this.settings;
/*    */   }
/*    */   
/*    */   public void setSettings(Map<String, String> settings) {
/* 68 */     this.settings = settings;
/*    */   }
/*    */   
/*    */   public String[] getTemplateLoaderPath() {
/* 72 */     return this.templateLoaderPath;
/*    */   }
/*    */   
/*    */   public void setTemplateLoaderPath(String... templateLoaderPaths) {
/* 76 */     this.templateLoaderPath = templateLoaderPaths;
/*    */   }
/*    */   
/*    */   public boolean isPreferFileSystemAccess() {
/* 80 */     return this.preferFileSystemAccess;
/*    */   }
/*    */   
/*    */   public void setPreferFileSystemAccess(boolean preferFileSystemAccess) {
/* 84 */     this.preferFileSystemAccess = preferFileSystemAccess;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */