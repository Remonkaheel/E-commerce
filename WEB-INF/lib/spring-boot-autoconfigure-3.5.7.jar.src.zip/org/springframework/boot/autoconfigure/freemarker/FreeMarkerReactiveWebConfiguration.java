/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.web.reactive.WebFluxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerConfig;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerConfigurer;
/*    */ import org.springframework.web.reactive.result.view.freemarker.FreeMarkerViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
/*    */ @AutoConfigureAfter({WebFluxAutoConfiguration.class})
/*    */ class FreeMarkerReactiveWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   FreeMarkerReactiveWebConfiguration(FreeMarkerProperties properties, ObjectProvider<FreeMarkerVariablesCustomizer> variablesCustomizers) {
/* 45 */     super(properties, variablesCustomizers);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({FreeMarkerConfig.class})
/*    */   FreeMarkerConfigurer freeMarkerConfigurer() {
/* 51 */     FreeMarkerConfigurer configurer = new FreeMarkerConfigurer();
/* 52 */     applyProperties((FreeMarkerConfigurationFactory)configurer);
/* 53 */     return configurer;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   Configuration freeMarkerConfiguration(FreeMarkerConfig configurer) {
/* 58 */     return configurer.getConfiguration();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"freeMarkerViewResolver"})
/*    */   @ConditionalOnBooleanProperty(name = {"spring.freemarker.enabled"}, matchIfMissing = true)
/*    */   FreeMarkerViewResolver freeMarkerViewResolver() {
/* 65 */     FreeMarkerViewResolver resolver = new FreeMarkerViewResolver();
/* 66 */     resolver.setPrefix(getProperties().getPrefix());
/* 67 */     resolver.setSuffix(getProperties().getSuffix());
/* 68 */     resolver.setRequestContextAttribute(getProperties().getRequestContextAttribute());
/* 69 */     resolver.setViewNames(getProperties().getViewNames());
/* 70 */     return resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerReactiveWebConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */