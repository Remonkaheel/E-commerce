/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.oss.driver.api.core.DefaultConsistencyLevel;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.cassandra")
/*     */ public class CassandraProperties
/*     */ {
/*     */   private Resource config;
/*     */   private String keyspaceName;
/*     */   private String sessionName;
/*     */   private List<String> contactPoints;
/*  64 */   private int port = 9042;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String localDatacenter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Compression compression;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private String schemaAction = "none";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private Ssl ssl = new Ssl();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private final Connection connection = new Connection();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private final Pool pool = new Pool();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private final Request request = new Request();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private final Controlconnection controlconnection = new Controlconnection();
/*     */   
/*     */   public Resource getConfig() {
/* 118 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setConfig(Resource config) {
/* 122 */     this.config = config;
/*     */   }
/*     */   
/*     */   public String getKeyspaceName() {
/* 126 */     return this.keyspaceName;
/*     */   }
/*     */   
/*     */   public void setKeyspaceName(String keyspaceName) {
/* 130 */     this.keyspaceName = keyspaceName;
/*     */   }
/*     */   
/*     */   public String getSessionName() {
/* 134 */     return this.sessionName;
/*     */   }
/*     */   
/*     */   public void setSessionName(String sessionName) {
/* 138 */     this.sessionName = sessionName;
/*     */   }
/*     */   
/*     */   public List<String> getContactPoints() {
/* 142 */     return this.contactPoints;
/*     */   }
/*     */   
/*     */   public void setContactPoints(List<String> contactPoints) {
/* 146 */     this.contactPoints = contactPoints;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 150 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 154 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getLocalDatacenter() {
/* 158 */     return this.localDatacenter;
/*     */   }
/*     */   
/*     */   public void setLocalDatacenter(String localDatacenter) {
/* 162 */     this.localDatacenter = localDatacenter;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 166 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 170 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 174 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 178 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Compression getCompression() {
/* 182 */     return this.compression;
/*     */   }
/*     */   
/*     */   public void setCompression(Compression compression) {
/* 186 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 190 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(Ssl ssl) {
/* 194 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public String getSchemaAction() {
/* 198 */     return this.schemaAction;
/*     */   }
/*     */   
/*     */   public void setSchemaAction(String schemaAction) {
/* 202 */     this.schemaAction = schemaAction;
/*     */   }
/*     */   
/*     */   public Connection getConnection() {
/* 206 */     return this.connection;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 210 */     return this.pool;
/*     */   }
/*     */   
/*     */   public Request getRequest() {
/* 214 */     return this.request;
/*     */   }
/*     */   
/*     */   public Controlconnection getControlconnection() {
/* 218 */     return this.controlconnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Ssl
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */     
/*     */     private String bundle;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 234 */       return (this.enabled != null) ? this.enabled.booleanValue() : ((this.bundle != null));
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 238 */       this.enabled = Boolean.valueOf(enabled);
/*     */     }
/*     */     
/*     */     public String getBundle() {
/* 242 */       return this.bundle;
/*     */     }
/*     */     
/*     */     public void setBundle(String bundle) {
/* 246 */       this.bundle = bundle;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Connection
/*     */   {
/*     */     private Duration connectTimeout;
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration initQueryTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getConnectTimeout() {
/* 265 */       return this.connectTimeout;
/*     */     }
/*     */     
/*     */     public void setConnectTimeout(Duration connectTimeout) {
/* 269 */       this.connectTimeout = connectTimeout;
/*     */     }
/*     */     
/*     */     public Duration getInitQueryTimeout() {
/* 273 */       return this.initQueryTimeout;
/*     */     }
/*     */     
/*     */     public void setInitQueryTimeout(Duration initQueryTimeout) {
/* 277 */       this.initQueryTimeout = initQueryTimeout;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Request
/*     */   {
/*     */     private Duration timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DefaultConsistencyLevel consistency;
/*     */ 
/*     */ 
/*     */     
/*     */     private DefaultConsistencyLevel serialConsistency;
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer pageSize;
/*     */ 
/*     */ 
/*     */     
/* 304 */     private final CassandraProperties.Throttler throttler = new CassandraProperties.Throttler();
/*     */     
/*     */     public Duration getTimeout() {
/* 307 */       return this.timeout;
/*     */     }
/*     */     
/*     */     public void setTimeout(Duration timeout) {
/* 311 */       this.timeout = timeout;
/*     */     }
/*     */     
/*     */     public DefaultConsistencyLevel getConsistency() {
/* 315 */       return this.consistency;
/*     */     }
/*     */     
/*     */     public void setConsistency(DefaultConsistencyLevel consistency) {
/* 319 */       this.consistency = consistency;
/*     */     }
/*     */     
/*     */     public DefaultConsistencyLevel getSerialConsistency() {
/* 323 */       return this.serialConsistency;
/*     */     }
/*     */     
/*     */     public void setSerialConsistency(DefaultConsistencyLevel serialConsistency) {
/* 327 */       this.serialConsistency = serialConsistency;
/*     */     }
/*     */     
/*     */     public Integer getPageSize() {
/* 331 */       return this.pageSize;
/*     */     }
/*     */     
/*     */     public void setPageSize(int pageSize) {
/* 335 */       this.pageSize = Integer.valueOf(pageSize);
/*     */     }
/*     */     
/*     */     public CassandraProperties.Throttler getThrottler() {
/* 339 */       return this.throttler;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pool
/*     */   {
/*     */     private Duration idleTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration heartbeatInterval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getIdleTimeout() {
/* 361 */       return this.idleTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleTimeout(Duration idleTimeout) {
/* 365 */       this.idleTimeout = idleTimeout;
/*     */     }
/*     */     
/*     */     public Duration getHeartbeatInterval() {
/* 369 */       return this.heartbeatInterval;
/*     */     }
/*     */     
/*     */     public void setHeartbeatInterval(Duration heartbeatInterval) {
/* 373 */       this.heartbeatInterval = heartbeatInterval;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Controlconnection
/*     */   {
/*     */     private Duration timeout;
/*     */ 
/*     */ 
/*     */     
/*     */     public Duration getTimeout() {
/* 386 */       return this.timeout;
/*     */     }
/*     */     
/*     */     public void setTimeout(Duration timeout) {
/* 390 */       this.timeout = timeout;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Throttler
/*     */   {
/*     */     private CassandraProperties.ThrottlerType type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer maxQueueSize;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer maxConcurrentRequests;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer maxRequestsPerSecond;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration drainInterval;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CassandraProperties.ThrottlerType getType() {
/* 426 */       return this.type;
/*     */     }
/*     */     
/*     */     public void setType(CassandraProperties.ThrottlerType type) {
/* 430 */       this.type = type;
/*     */     }
/*     */     
/*     */     public Integer getMaxQueueSize() {
/* 434 */       return this.maxQueueSize;
/*     */     }
/*     */     
/*     */     public void setMaxQueueSize(int maxQueueSize) {
/* 438 */       this.maxQueueSize = Integer.valueOf(maxQueueSize);
/*     */     }
/*     */     
/*     */     public Integer getMaxConcurrentRequests() {
/* 442 */       return this.maxConcurrentRequests;
/*     */     }
/*     */     
/*     */     public void setMaxConcurrentRequests(int maxConcurrentRequests) {
/* 446 */       this.maxConcurrentRequests = Integer.valueOf(maxConcurrentRequests);
/*     */     }
/*     */     
/*     */     public Integer getMaxRequestsPerSecond() {
/* 450 */       return this.maxRequestsPerSecond;
/*     */     }
/*     */     
/*     */     public void setMaxRequestsPerSecond(int maxRequestsPerSecond) {
/* 454 */       this.maxRequestsPerSecond = Integer.valueOf(maxRequestsPerSecond);
/*     */     }
/*     */     
/*     */     public Duration getDrainInterval() {
/* 458 */       return this.drainInterval;
/*     */     }
/*     */     
/*     */     public void setDrainInterval(Duration drainInterval) {
/* 462 */       this.drainInterval = drainInterval;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Compression
/*     */   {
/* 475 */     LZ4,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 480 */     SNAPPY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 485 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ThrottlerType
/*     */   {
/* 494 */     CONCURRENCY_LIMITING("ConcurrencyLimitingRequestThrottler"),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     RATE_LIMITING("RateLimitingRequestThrottler"),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 504 */     NONE("PassThroughRequestThrottler");
/*     */     
/*     */     private final String type;
/*     */     
/*     */     ThrottlerType(String type) {
/* 509 */       this.type = type;
/*     */     }
/*     */     
/*     */     public String type() {
/* 513 */       return this.type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */