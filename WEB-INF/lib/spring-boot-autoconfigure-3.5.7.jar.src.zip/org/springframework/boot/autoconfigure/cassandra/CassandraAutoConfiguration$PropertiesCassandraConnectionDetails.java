/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertiesCassandraConnectionDetails
/*     */   implements CassandraConnectionDetails
/*     */ {
/*     */   private final CassandraProperties properties;
/*     */   private final SslBundles sslBundles;
/*     */   
/*     */   private PropertiesCassandraConnectionDetails(CassandraProperties properties, SslBundles sslBundles) {
/* 304 */     this.properties = properties;
/* 305 */     this.sslBundles = sslBundles;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CassandraConnectionDetails.Node> getContactPoints() {
/* 310 */     List<String> contactPoints = this.properties.getContactPoints();
/* 311 */     return (contactPoints != null) ? contactPoints.stream().map(this::asNode).toList() : 
/* 312 */       Collections.<CassandraConnectionDetails.Node>emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 317 */     return this.properties.getUsername();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 322 */     return this.properties.getPassword();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalDatacenter() {
/* 327 */     return this.properties.getLocalDatacenter();
/*     */   }
/*     */ 
/*     */   
/*     */   public SslBundle getSslBundle() {
/* 332 */     CassandraProperties.Ssl ssl = this.properties.getSsl();
/* 333 */     if (ssl == null || !ssl.isEnabled()) {
/* 334 */       return null;
/*     */     }
/* 336 */     if (StringUtils.hasLength(ssl.getBundle())) {
/* 337 */       Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 338 */       return this.sslBundles.getBundle(ssl.getBundle());
/*     */     } 
/* 340 */     return SslBundle.systemDefault();
/*     */   }
/*     */   
/*     */   private CassandraConnectionDetails.Node asNode(String contactPoint) {
/* 344 */     int i = contactPoint.lastIndexOf(':');
/* 345 */     if (i >= 0) {
/* 346 */       String portCandidate = contactPoint.substring(i + 1);
/* 347 */       Integer port = asPort(portCandidate);
/* 348 */       if (port != null) {
/* 349 */         return new CassandraConnectionDetails.Node(contactPoint.substring(0, i), port.intValue());
/*     */       }
/*     */     } 
/* 352 */     return new CassandraConnectionDetails.Node(contactPoint, this.properties.getPort());
/*     */   }
/*     */   
/*     */   private Integer asPort(String value) {
/*     */     try {
/* 357 */       int i = Integer.parseInt(value);
/* 358 */       return (i > 0 && i < 65535) ? Integer.valueOf(i) : null;
/*     */     }
/* 360 */     catch (Exception ex) {
/* 361 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraAutoConfiguration$PropertiesCassandraConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */