/*    */ package org.springframework.boot.autoconfigure.cassandra;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CassandraConnectionDetails
/*    */   extends ConnectionDetails
/*    */ {
/*    */   List<Node> getContactPoints();
/*    */   
/*    */   default String getUsername() {
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getPassword() {
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getLocalDatacenter();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default SslBundle getSslBundle() {
/* 69 */     return null;
/*    */   }
/*    */   public static final class Node extends Record { private final String host; private final int port;
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #78	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;
/*    */     }
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #78	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;
/*    */     }
/* 78 */     public Node(String host, int port) { this.host = host; this.port = port; } public String host() { return this.host; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #78	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/boot/autoconfigure/cassandra/CassandraConnectionDetails$Node;
/* 78 */       //   0	8	1	o	Ljava/lang/Object; } public int port() { return this.port; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */