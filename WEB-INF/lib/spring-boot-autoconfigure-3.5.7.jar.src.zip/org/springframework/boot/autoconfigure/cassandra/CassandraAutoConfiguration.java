/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.oss.driver.api.core.CqlSession;
/*     */ import com.datastax.oss.driver.api.core.CqlSessionBuilder;
/*     */ import com.datastax.oss.driver.api.core.DefaultConsistencyLevel;
/*     */ import com.datastax.oss.driver.api.core.config.DefaultDriverOption;
/*     */ import com.datastax.oss.driver.api.core.config.DriverConfigLoader;
/*     */ import com.datastax.oss.driver.api.core.config.DriverOption;
/*     */ import com.datastax.oss.driver.api.core.config.ProgrammaticDriverConfigLoaderBuilder;
/*     */ import com.datastax.oss.driver.api.core.ssl.ProgrammaticSslEngineFactory;
/*     */ import com.datastax.oss.driver.api.core.ssl.SslEngineFactory;
/*     */ import com.datastax.oss.driver.internal.core.config.typesafe.DefaultProgrammaticDriverConfigLoaderBuilder;
/*     */ import com.typesafe.config.Config;
/*     */ import com.typesafe.config.ConfigFactory;
/*     */ import com.typesafe.config.ConfigMergeable;
/*     */ import java.io.IOException;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Lazy;
/*     */ import org.springframework.context.annotation.Scope;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration
/*     */ @ConditionalOnClass({CqlSession.class})
/*     */ @EnableConfigurationProperties({CassandraProperties.class})
/*     */ public class CassandraAutoConfiguration
/*     */ {
/*     */   private static final Config SPRING_BOOT_DEFAULTS;
/*     */   private final CassandraProperties properties;
/*     */   
/*     */   static {
/*  84 */     CassandraDriverOptions options = new CassandraDriverOptions();
/*  85 */     options.add((DriverOption)DefaultDriverOption.CONTACT_POINTS, Collections.singletonList("127.0.0.1:9042"));
/*  86 */     options.add((DriverOption)DefaultDriverOption.PROTOCOL_COMPRESSION, "none");
/*  87 */     options.add((DriverOption)DefaultDriverOption.CONTROL_CONNECTION_TIMEOUT, (int)Duration.ofSeconds(5L).toMillis());
/*  88 */     SPRING_BOOT_DEFAULTS = options.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   CassandraAutoConfiguration(CassandraProperties properties) {
/*  94 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({CassandraConnectionDetails.class})
/*     */   PropertiesCassandraConnectionDetails cassandraConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/* 100 */     return new PropertiesCassandraConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @Lazy
/*     */   public CqlSession cassandraSession(CqlSessionBuilder cqlSessionBuilder) {
/* 107 */     return (CqlSession)cqlSessionBuilder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @Scope("prototype")
/*     */   public CqlSessionBuilder cassandraSessionBuilder(DriverConfigLoader driverConfigLoader, CassandraConnectionDetails connectionDetails, ObjectProvider<CqlSessionBuilderCustomizer> builderCustomizers) {
/* 116 */     CqlSessionBuilder builder = (CqlSessionBuilder)CqlSession.builder().withConfigLoader(driverConfigLoader);
/* 117 */     configureAuthentication(builder, connectionDetails);
/* 118 */     configureSsl(builder, connectionDetails);
/* 119 */     builder.withKeyspace(this.properties.getKeyspaceName());
/* 120 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 121 */     return builder;
/*     */   }
/*     */   
/*     */   private void configureAuthentication(CqlSessionBuilder builder, CassandraConnectionDetails connectionDetails) {
/* 125 */     String username = connectionDetails.getUsername();
/* 126 */     if (username != null) {
/* 127 */       builder.withAuthCredentials(username, connectionDetails.getPassword());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSsl(CqlSessionBuilder builder, CassandraConnectionDetails connectionDetails) {
/* 132 */     SslBundle sslBundle = connectionDetails.getSslBundle();
/* 133 */     if (sslBundle == null) {
/*     */       return;
/*     */     }
/* 136 */     SslOptions options = sslBundle.getOptions();
/* 137 */     Assert.state((options.getEnabledProtocols() == null), "SSL protocol options cannot be specified with Cassandra");
/* 138 */     builder
/* 139 */       .withSslEngineFactory((SslEngineFactory)new ProgrammaticSslEngineFactory(sslBundle.createSslContext(), options.getCiphers()));
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(destroyMethod = "")
/*     */   @ConditionalOnMissingBean
/*     */   public DriverConfigLoader cassandraDriverConfigLoader(CassandraConnectionDetails connectionDetails, ObjectProvider<DriverConfigLoaderBuilderCustomizer> builderCustomizers) {
/* 146 */     DefaultProgrammaticDriverConfigLoaderBuilder defaultProgrammaticDriverConfigLoaderBuilder = new DefaultProgrammaticDriverConfigLoaderBuilder(() -> cassandraConfiguration(connectionDetails), "datastax-java-driver");
/*     */     
/* 148 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 149 */     return defaultProgrammaticDriverConfigLoaderBuilder.build();
/*     */   }
/*     */   
/*     */   private Config cassandraConfiguration(CassandraConnectionDetails connectionDetails) {
/* 153 */     ConfigFactory.invalidateCaches();
/* 154 */     Config config = ConfigFactory.defaultOverrides();
/* 155 */     config = config.withFallback((ConfigMergeable)mapConfig(connectionDetails));
/* 156 */     if (this.properties.getConfig() != null) {
/* 157 */       config = config.withFallback((ConfigMergeable)loadConfig(this.properties.getConfig()));
/*     */     }
/* 159 */     config = config.withFallback((ConfigMergeable)SPRING_BOOT_DEFAULTS);
/* 160 */     config = config.withFallback((ConfigMergeable)ConfigFactory.defaultReferenceUnresolved());
/* 161 */     return config.resolve();
/*     */   }
/*     */   
/*     */   private Config loadConfig(Resource resource) {
/*     */     try {
/* 166 */       return ConfigFactory.parseURL(resource.getURL());
/*     */     }
/* 168 */     catch (IOException ex) {
/* 169 */       throw new IllegalStateException("Failed to load cassandra configuration from " + String.valueOf(resource), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Config mapConfig(CassandraConnectionDetails connectionDetails) {
/* 174 */     CassandraDriverOptions options = new CassandraDriverOptions();
/* 175 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 176 */     map.from(this.properties.getSessionName())
/* 177 */       .whenHasText()
/* 178 */       .to(sessionName -> options.add((DriverOption)DefaultDriverOption.SESSION_NAME, sessionName));
/* 179 */     map.from(connectionDetails.getUsername())
/* 180 */       .to(value -> options.add((DriverOption)DefaultDriverOption.AUTH_PROVIDER_USER_NAME, value).add((DriverOption)DefaultDriverOption.AUTH_PROVIDER_PASSWORD, connectionDetails.getPassword()));
/*     */     
/* 182 */     Objects.requireNonNull(this.properties); map.from(this.properties::getCompression)
/* 183 */       .to(compression -> options.add((DriverOption)DefaultDriverOption.PROTOCOL_COMPRESSION, compression));
/* 184 */     mapConnectionOptions(options);
/* 185 */     mapPoolingOptions(options);
/* 186 */     mapRequestOptions(options);
/* 187 */     mapControlConnectionOptions(options);
/* 188 */     map.from(mapContactPoints(connectionDetails))
/* 189 */       .to(contactPoints -> options.add((DriverOption)DefaultDriverOption.CONTACT_POINTS, contactPoints));
/* 190 */     map.from(connectionDetails.getLocalDatacenter())
/* 191 */       .whenHasText()
/* 192 */       .to(localDatacenter -> options.add((DriverOption)DefaultDriverOption.LOAD_BALANCING_LOCAL_DATACENTER, localDatacenter));
/* 193 */     return options.build();
/*     */   }
/*     */   
/*     */   private void mapConnectionOptions(CassandraDriverOptions options) {
/* 197 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 198 */     CassandraProperties.Connection connectionProperties = this.properties.getConnection();
/* 199 */     Objects.requireNonNull(connectionProperties); map.from(connectionProperties::getConnectTimeout)
/* 200 */       .asInt(Duration::toMillis)
/* 201 */       .to(connectTimeout -> options.add((DriverOption)DefaultDriverOption.CONNECTION_CONNECT_TIMEOUT, connectTimeout.intValue()));
/* 202 */     Objects.requireNonNull(connectionProperties); map.from(connectionProperties::getInitQueryTimeout)
/* 203 */       .asInt(Duration::toMillis)
/* 204 */       .to(initQueryTimeout -> options.add((DriverOption)DefaultDriverOption.CONNECTION_INIT_QUERY_TIMEOUT, initQueryTimeout.intValue()));
/*     */   }
/*     */   
/*     */   private void mapPoolingOptions(CassandraDriverOptions options) {
/* 208 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 209 */     CassandraProperties.Pool poolProperties = this.properties.getPool();
/* 210 */     Objects.requireNonNull(poolProperties); map.from(poolProperties::getIdleTimeout)
/* 211 */       .asInt(Duration::toMillis)
/* 212 */       .to(idleTimeout -> options.add((DriverOption)DefaultDriverOption.HEARTBEAT_TIMEOUT, idleTimeout.intValue()));
/* 213 */     Objects.requireNonNull(poolProperties); map.from(poolProperties::getHeartbeatInterval)
/* 214 */       .asInt(Duration::toMillis)
/* 215 */       .to(heartBeatInterval -> options.add((DriverOption)DefaultDriverOption.HEARTBEAT_INTERVAL, heartBeatInterval.intValue()));
/*     */   }
/*     */   
/*     */   private void mapRequestOptions(CassandraDriverOptions options) {
/* 219 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 220 */     CassandraProperties.Request requestProperties = this.properties.getRequest();
/* 221 */     Objects.requireNonNull(requestProperties); map.from(requestProperties::getTimeout)
/* 222 */       .asInt(Duration::toMillis)
/* 223 */       .to(timeout -> options.add((DriverOption)DefaultDriverOption.REQUEST_TIMEOUT, timeout.intValue()));
/* 224 */     Objects.requireNonNull(requestProperties); map.from(requestProperties::getConsistency)
/* 225 */       .to(consistency -> options.add((DriverOption)DefaultDriverOption.REQUEST_CONSISTENCY, (Enum<?>)consistency));
/* 226 */     Objects.requireNonNull(requestProperties); map.from(requestProperties::getSerialConsistency)
/* 227 */       .to(serialConsistency -> options.add((DriverOption)DefaultDriverOption.REQUEST_SERIAL_CONSISTENCY, (Enum<?>)serialConsistency));
/* 228 */     Objects.requireNonNull(requestProperties); map.from(requestProperties::getPageSize)
/* 229 */       .to(pageSize -> options.add((DriverOption)DefaultDriverOption.REQUEST_PAGE_SIZE, pageSize.intValue()));
/* 230 */     CassandraProperties.Throttler throttlerProperties = requestProperties.getThrottler();
/* 231 */     Objects.requireNonNull(throttlerProperties); map.from(throttlerProperties::getType)
/* 232 */       .as(CassandraProperties.ThrottlerType::type)
/* 233 */       .to(type -> options.add((DriverOption)DefaultDriverOption.REQUEST_THROTTLER_CLASS, type));
/* 234 */     Objects.requireNonNull(throttlerProperties); map.from(throttlerProperties::getMaxQueueSize)
/* 235 */       .to(maxQueueSize -> options.add((DriverOption)DefaultDriverOption.REQUEST_THROTTLER_MAX_QUEUE_SIZE, maxQueueSize.intValue()));
/* 236 */     Objects.requireNonNull(throttlerProperties); map.from(throttlerProperties::getMaxConcurrentRequests)
/* 237 */       .to(maxConcurrentRequests -> options.add((DriverOption)DefaultDriverOption.REQUEST_THROTTLER_MAX_CONCURRENT_REQUESTS, maxConcurrentRequests.intValue()));
/*     */     
/* 239 */     Objects.requireNonNull(throttlerProperties); map.from(throttlerProperties::getMaxRequestsPerSecond)
/* 240 */       .to(maxRequestsPerSecond -> options.add((DriverOption)DefaultDriverOption.REQUEST_THROTTLER_MAX_REQUESTS_PER_SECOND, maxRequestsPerSecond.intValue()));
/*     */     
/* 242 */     Objects.requireNonNull(throttlerProperties); map.from(throttlerProperties::getDrainInterval)
/* 243 */       .asInt(Duration::toMillis)
/* 244 */       .to(drainInterval -> options.add((DriverOption)DefaultDriverOption.REQUEST_THROTTLER_DRAIN_INTERVAL, drainInterval.intValue()));
/*     */   }
/*     */   
/*     */   private void mapControlConnectionOptions(CassandraDriverOptions options) {
/* 248 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 249 */     CassandraProperties.Controlconnection controlProperties = this.properties.getControlconnection();
/* 250 */     Objects.requireNonNull(controlProperties); map.from(controlProperties::getTimeout)
/* 251 */       .asInt(Duration::toMillis)
/* 252 */       .to(timeout -> options.add((DriverOption)DefaultDriverOption.CONTROL_CONNECTION_TIMEOUT, timeout.intValue()));
/*     */   }
/*     */   
/*     */   private List<String> mapContactPoints(CassandraConnectionDetails connectionDetails) {
/* 256 */     return connectionDetails.getContactPoints().stream().map(node -> node.host() + ":" + node.host()).toList();
/*     */   }
/*     */   
/*     */   private static final class CassandraDriverOptions
/*     */   {
/* 261 */     private final Map<String, String> options = new LinkedHashMap<>();
/*     */     
/*     */     private CassandraDriverOptions add(DriverOption option, String value) {
/* 264 */       String key = createKeyFor(option);
/* 265 */       this.options.put(key, value);
/* 266 */       return this;
/*     */     }
/*     */     
/*     */     private CassandraDriverOptions add(DriverOption option, int value) {
/* 270 */       return add(option, String.valueOf(value));
/*     */     }
/*     */     
/*     */     private CassandraDriverOptions add(DriverOption option, Enum<?> value) {
/* 274 */       return add(option, value.name());
/*     */     }
/*     */     
/*     */     private CassandraDriverOptions add(DriverOption option, List<String> values) {
/* 278 */       for (int i = 0; i < values.size(); i++) {
/* 279 */         this.options.put(String.format("%s.%s", new Object[] { createKeyFor(option), Integer.valueOf(i) }), values.get(i));
/*     */       } 
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     private Config build() {
/* 285 */       return ConfigFactory.parseMap(this.options, "Environment");
/*     */     }
/*     */     
/*     */     private static String createKeyFor(DriverOption option) {
/* 289 */       return String.format("%s.%s", new Object[] { "datastax-java-driver", option.getPath() });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PropertiesCassandraConnectionDetails
/*     */     implements CassandraConnectionDetails
/*     */   {
/*     */     private final CassandraProperties properties;
/*     */     
/*     */     private final SslBundles sslBundles;
/*     */ 
/*     */     
/*     */     private PropertiesCassandraConnectionDetails(CassandraProperties properties, SslBundles sslBundles) {
/* 304 */       this.properties = properties;
/* 305 */       this.sslBundles = sslBundles;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<CassandraConnectionDetails.Node> getContactPoints() {
/* 310 */       List<String> contactPoints = this.properties.getContactPoints();
/* 311 */       return (contactPoints != null) ? contactPoints.stream().map(this::asNode).toList() : 
/* 312 */         Collections.<CassandraConnectionDetails.Node>emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 317 */       return this.properties.getUsername();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 322 */       return this.properties.getPassword();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocalDatacenter() {
/* 327 */       return this.properties.getLocalDatacenter();
/*     */     }
/*     */ 
/*     */     
/*     */     public SslBundle getSslBundle() {
/* 332 */       CassandraProperties.Ssl ssl = this.properties.getSsl();
/* 333 */       if (ssl == null || !ssl.isEnabled()) {
/* 334 */         return null;
/*     */       }
/* 336 */       if (StringUtils.hasLength(ssl.getBundle())) {
/* 337 */         Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 338 */         return this.sslBundles.getBundle(ssl.getBundle());
/*     */       } 
/* 340 */       return SslBundle.systemDefault();
/*     */     }
/*     */     
/*     */     private CassandraConnectionDetails.Node asNode(String contactPoint) {
/* 344 */       int i = contactPoint.lastIndexOf(':');
/* 345 */       if (i >= 0) {
/* 346 */         String portCandidate = contactPoint.substring(i + 1);
/* 347 */         Integer port = asPort(portCandidate);
/* 348 */         if (port != null) {
/* 349 */           return new CassandraConnectionDetails.Node(contactPoint.substring(0, i), port.intValue());
/*     */         }
/*     */       } 
/* 352 */       return new CassandraConnectionDetails.Node(contactPoint, this.properties.getPort());
/*     */     }
/*     */     
/*     */     private Integer asPort(String value) {
/*     */       try {
/* 357 */         int i = Integer.parseInt(value);
/* 358 */         return (i > 0 && i < 65535) ? Integer.valueOf(i) : null;
/*     */       }
/* 360 */       catch (Exception ex) {
/* 361 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */