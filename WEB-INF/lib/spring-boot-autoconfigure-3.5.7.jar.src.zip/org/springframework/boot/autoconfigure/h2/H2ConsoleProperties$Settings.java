/*     */ package org.springframework.boot.autoconfigure.h2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Settings
/*     */ {
/*     */   private boolean trace = false;
/*     */   private boolean webAllowOthers = false;
/*     */   private String webAdminPassword;
/*     */   
/*     */   public boolean isTrace() {
/*  86 */     return this.trace;
/*     */   }
/*     */   
/*     */   public void setTrace(boolean trace) {
/*  90 */     this.trace = trace;
/*     */   }
/*     */   
/*     */   public boolean isWebAllowOthers() {
/*  94 */     return this.webAllowOthers;
/*     */   }
/*     */   
/*     */   public void setWebAllowOthers(boolean webAllowOthers) {
/*  98 */     this.webAllowOthers = webAllowOthers;
/*     */   }
/*     */   
/*     */   public String getWebAdminPassword() {
/* 102 */     return this.webAdminPassword;
/*     */   }
/*     */   
/*     */   public void setWebAdminPassword(String webAdminPassword) {
/* 106 */     this.webAdminPassword = webAdminPassword;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleProperties$Settings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */