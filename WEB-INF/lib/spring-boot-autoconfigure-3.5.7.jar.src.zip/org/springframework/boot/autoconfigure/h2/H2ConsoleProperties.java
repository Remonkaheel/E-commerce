/*     */ package org.springframework.boot.autoconfigure.h2;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.h2.console")
/*     */ public class H2ConsoleProperties
/*     */ {
/*  36 */   private String path = "/h2-console";
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enabled = false;
/*     */ 
/*     */   
/*  43 */   private final Settings settings = new Settings();
/*     */   
/*     */   public String getPath() {
/*  46 */     return this.path;
/*     */   }
/*     */   
/*     */   public void setPath(String path) {
/*  50 */     Assert.notNull(path, "'path' must not be null");
/*  51 */     Assert.isTrue((path.length() > 1), "'path' must have length greater than 1");
/*  52 */     Assert.isTrue(path.startsWith("/"), "'path' must start with '/'");
/*  53 */     this.path = path;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  57 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  61 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public Settings getSettings() {
/*  65 */     return this.settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Settings
/*     */   {
/*     */     private boolean trace = false;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean webAllowOthers = false;
/*     */ 
/*     */ 
/*     */     
/*     */     private String webAdminPassword;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isTrace() {
/*  86 */       return this.trace;
/*     */     }
/*     */     
/*     */     public void setTrace(boolean trace) {
/*  90 */       this.trace = trace;
/*     */     }
/*     */     
/*     */     public boolean isWebAllowOthers() {
/*  94 */       return this.webAllowOthers;
/*     */     }
/*     */     
/*     */     public void setWebAllowOthers(boolean webAllowOthers) {
/*  98 */       this.webAllowOthers = webAllowOthers;
/*     */     }
/*     */     
/*     */     public String getWebAdminPassword() {
/* 102 */       return this.webAdminPassword;
/*     */     }
/*     */     
/*     */     public void setWebAdminPassword(String webAdminPassword) {
/* 106 */       this.webAdminPassword = webAdminPassword;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */