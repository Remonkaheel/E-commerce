/*     */ package org.springframework.boot.autoconfigure.h2;
/*     */ 
/*     */ import jakarta.servlet.Servlet;
/*     */ import java.sql.Connection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.h2.server.web.JakartaWebServlet;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {DataSourceAutoConfiguration.class})
/*     */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*     */ @ConditionalOnClass({JakartaWebServlet.class})
/*     */ @ConditionalOnBooleanProperty({"spring.h2.console.enabled"})
/*     */ @EnableConfigurationProperties({H2ConsoleProperties.class})
/*     */ public class H2ConsoleAutoConfiguration
/*     */ {
/*  59 */   private static final Log logger = LogFactory.getLog(H2ConsoleAutoConfiguration.class);
/*     */   
/*     */   private final H2ConsoleProperties properties;
/*     */   
/*     */   H2ConsoleAutoConfiguration(H2ConsoleProperties properties) {
/*  64 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public ServletRegistrationBean<JakartaWebServlet> h2Console() {
/*  69 */     String path = this.properties.getPath();
/*  70 */     String urlMapping = path + path;
/*  71 */     ServletRegistrationBean<JakartaWebServlet> registration = new ServletRegistrationBean((Servlet)new JakartaWebServlet(), new String[] { urlMapping });
/*     */     
/*  73 */     configureH2ConsoleSettings(registration, this.properties.getSettings());
/*  74 */     return registration;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   H2ConsoleLogger h2ConsoleLogger(ObjectProvider<DataSource> dataSources) {
/*  79 */     return new H2ConsoleLogger(dataSources, this.properties.getPath());
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureH2ConsoleSettings(ServletRegistrationBean<JakartaWebServlet> registration, H2ConsoleProperties.Settings settings) {
/*  84 */     if (settings.isTrace()) {
/*  85 */       registration.addInitParameter("trace", "");
/*     */     }
/*  87 */     if (settings.isWebAllowOthers()) {
/*  88 */       registration.addInitParameter("webAllowOthers", "");
/*     */     }
/*  90 */     if (settings.getWebAdminPassword() != null) {
/*  91 */       registration.addInitParameter("webAdminPassword", settings.getWebAdminPassword());
/*     */     }
/*     */   }
/*     */   
/*     */   static class H2ConsoleLogger
/*     */   {
/*     */     H2ConsoleLogger(ObjectProvider<DataSource> dataSources, String path) {
/*  98 */       if (H2ConsoleAutoConfiguration.logger.isInfoEnabled()) {
/*  99 */         ClassLoader classLoader = getClass().getClassLoader();
/* 100 */         withThreadContextClassLoader(classLoader, () -> log(getConnectionUrls(dataSources), path));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void withThreadContextClassLoader(ClassLoader classLoader, Runnable action) {
/* 105 */       ClassLoader previous = Thread.currentThread().getContextClassLoader();
/*     */       try {
/* 107 */         Thread.currentThread().setContextClassLoader(classLoader);
/* 108 */         action.run();
/*     */       } finally {
/*     */         
/* 111 */         Thread.currentThread().setContextClassLoader(previous);
/*     */       } 
/*     */     }
/*     */     
/*     */     private List<String> getConnectionUrls(ObjectProvider<DataSource> dataSources) {
/* 116 */       return dataSources.orderedStream(ObjectProvider.UNFILTERED)
/* 117 */         .map(this::getConnectionUrl)
/* 118 */         .filter(Objects::nonNull)
/* 119 */         .toList();
/*     */     }
/*     */     private String getConnectionUrl(DataSource dataSource) {
/*     */       
/* 123 */       try { Connection connection = dataSource.getConnection(); 
/* 124 */         try { String str = "'" + connection.getMetaData().getURL() + "'";
/* 125 */           if (connection != null) connection.close();  return str; } catch (Throwable throwable) { if (connection != null)
/* 126 */             try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/* 127 */       { return null; }
/*     */     
/*     */     }
/*     */     
/*     */     private void log(List<String> urls, String path) {
/* 132 */       if (!urls.isEmpty())
/* 133 */         H2ConsoleAutoConfiguration.logger.info(LogMessage.format("H2 console available at '%s'. %s available at %s", path, 
/* 134 */               (urls.size() > 1) ? "Databases" : "Database", String.join(", ", (Iterable)urls))); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */