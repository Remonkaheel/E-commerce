/*     */ package org.springframework.boot.autoconfigure.h2;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class H2ConsoleLogger
/*     */ {
/*     */   H2ConsoleLogger(ObjectProvider<DataSource> dataSources, String path) {
/*  98 */     if (H2ConsoleAutoConfiguration.logger.isInfoEnabled()) {
/*  99 */       ClassLoader classLoader = getClass().getClassLoader();
/* 100 */       withThreadContextClassLoader(classLoader, () -> log(getConnectionUrls(dataSources), path));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void withThreadContextClassLoader(ClassLoader classLoader, Runnable action) {
/* 105 */     ClassLoader previous = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 107 */       Thread.currentThread().setContextClassLoader(classLoader);
/* 108 */       action.run();
/*     */     } finally {
/*     */       
/* 111 */       Thread.currentThread().setContextClassLoader(previous);
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<String> getConnectionUrls(ObjectProvider<DataSource> dataSources) {
/* 116 */     return dataSources.orderedStream(ObjectProvider.UNFILTERED)
/* 117 */       .map(this::getConnectionUrl)
/* 118 */       .filter(Objects::nonNull)
/* 119 */       .toList();
/*     */   }
/*     */   private String getConnectionUrl(DataSource dataSource) {
/*     */     
/* 123 */     try { Connection connection = dataSource.getConnection(); 
/* 124 */       try { String str = "'" + connection.getMetaData().getURL() + "'";
/* 125 */         if (connection != null) connection.close();  return str; } catch (Throwable throwable) { if (connection != null)
/* 126 */           try { connection.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/* 127 */     { return null; }
/*     */   
/*     */   }
/*     */   
/*     */   private void log(List<String> urls, String path) {
/* 132 */     if (!urls.isEmpty())
/* 133 */       H2ConsoleAutoConfiguration.logger.info(LogMessage.format("H2 console available at '%s'. %s available at %s", path, 
/* 134 */             (urls.size() > 1) ? "Databases" : "Database", String.join(", ", (Iterable)urls))); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\h2\H2ConsoleAutoConfiguration$H2ConsoleLogger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */