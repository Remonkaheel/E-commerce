/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(-2147483628)
/*    */ class OnResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 44 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(ConditionalOnResource.class.getName(), true);
/* 45 */     ResourceLoader loader = context.getResourceLoader();
/* 46 */     List<String> locations = new ArrayList<>();
/* 47 */     collectValues(locations, (List<Object>)attributes.get("resources"));
/* 48 */     Assert.state(!locations.isEmpty(), "@ConditionalOnResource annotations must specify at least one resource location");
/*    */     
/* 50 */     List<String> missing = new ArrayList<>();
/* 51 */     for (String location : locations) {
/* 52 */       String resource = context.getEnvironment().resolvePlaceholders(location);
/* 53 */       if (!loader.getResource(resource).exists()) {
/* 54 */         missing.add(location);
/*    */       }
/*    */     } 
/* 57 */     if (!missing.isEmpty()) {
/* 58 */       return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnResource.class, new Object[0])
/* 59 */           .didNotFind("resource", "resources")
/* 60 */           .items(ConditionMessage.Style.QUOTE, missing));
/*    */     }
/* 62 */     return ConditionOutcome.match(ConditionMessage.forCondition((Class)ConditionalOnResource.class, new Object[0])
/* 63 */         .found("location", "locations")
/* 64 */         .items(locations));
/*    */   }
/*    */   
/*    */   private void collectValues(List<String> names, List<Object> values) {
/* 68 */     for (Object value : values) {
/* 69 */       for (Object item : (Object[])value)
/* 70 */         names.add((String)item); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnResourceCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */