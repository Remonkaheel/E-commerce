/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ClassNameFilter
/*     */ {
/* 115 */   PRESENT
/*     */   {
/*     */     public boolean matches(String className, ClassLoader classLoader)
/*     */     {
/* 119 */       return isPresent(className, classLoader);
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 124 */   MISSING
/*     */   {
/*     */     public boolean matches(String className, ClassLoader classLoader)
/*     */     {
/* 128 */       return !isPresent(className, classLoader);
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isPresent(String className, ClassLoader classLoader) {
/* 136 */     if (classLoader == null) {
/* 137 */       classLoader = ClassUtils.getDefaultClassLoader();
/*     */     }
/*     */     try {
/* 140 */       FilteringSpringBootCondition.resolve(className, classLoader);
/* 141 */       return true;
/*     */     }
/* 143 */     catch (Throwable ex) {
/* 144 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   abstract boolean matches(String paramString, ClassLoader paramClassLoader);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\FilteringSpringBootCondition$ClassNameFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */