/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private final String name;
/*    */   private final String property;
/*    */   private final String[] resourceLocations;
/*    */   
/*    */   protected ResourceCondition(String name, String property, String... resourceLocations) {
/* 55 */     this.name = name;
/* 56 */     this.property = property;
/* 57 */     this.resourceLocations = resourceLocations;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 62 */     if (context.getEnvironment().containsProperty(this.property)) {
/* 63 */       return ConditionOutcome.match(startConditionMessage().foundExactly("property " + this.property));
/*    */     }
/* 65 */     return getResourceOutcome(context, metadata);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 75 */     List<String> found = new ArrayList<>();
/* 76 */     for (String location : this.resourceLocations) {
/* 77 */       Resource resource = context.getResourceLoader().getResource(location);
/* 78 */       if (resource != null && resource.exists()) {
/* 79 */         found.add(location);
/*    */       }
/*    */     } 
/* 82 */     if (found.isEmpty()) {
/*    */       
/* 84 */       ConditionMessage conditionMessage = startConditionMessage().didNotFind("resource", "resources").items(ConditionMessage.Style.QUOTE, Arrays.asList((Object[])this.resourceLocations));
/* 85 */       return ConditionOutcome.noMatch(conditionMessage);
/*    */     } 
/* 87 */     ConditionMessage message = startConditionMessage().found("resource", "resources").items(ConditionMessage.Style.QUOTE, found);
/* 88 */     return ConditionOutcome.match(message);
/*    */   }
/*    */   
/*    */   protected final ConditionMessage.Builder startConditionMessage() {
/* 92 */     return ConditionMessage.forCondition("ResourceCondition", new Object[] { "(" + this.name + ")" });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ResourceCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */