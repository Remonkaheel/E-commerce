/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.core.annotation.Order;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ public abstract class AnyNestedCondition
/*    */   extends AbstractNestedCondition
/*    */ {
/*    */   public AnyNestedCondition(ConfigurationCondition.ConfigurationPhase configurationPhase) {
/* 61 */     super(configurationPhase);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getFinalMatchOutcome(AbstractNestedCondition.MemberMatchOutcomes memberOutcomes) {
/* 66 */     boolean match = !memberOutcomes.getMatches().isEmpty();
/* 67 */     List<ConditionMessage> messages = new ArrayList<>();
/* 68 */     messages.add(ConditionMessage.forCondition("AnyNestedCondition", new Object[0])
/* 69 */         .because("" + memberOutcomes.getMatches().size() + " matched " + memberOutcomes.getMatches().size() + " did not"));
/*    */     
/* 71 */     for (ConditionOutcome outcome : memberOutcomes.getAll()) {
/* 72 */       messages.add(outcome.getConditionMessage());
/*    */     }
/* 74 */     return new ConditionOutcome(match, ConditionMessage.of(messages));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\AnyNestedCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */