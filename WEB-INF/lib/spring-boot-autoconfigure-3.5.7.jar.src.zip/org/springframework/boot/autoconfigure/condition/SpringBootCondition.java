/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.ClassMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpringBootCondition
/*     */   implements Condition
/*     */ {
/*  41 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   public final boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  45 */     String classOrMethodName = getClassOrMethodName(metadata);
/*     */     try {
/*  47 */       ConditionOutcome outcome = getMatchOutcome(context, metadata);
/*  48 */       logOutcome(classOrMethodName, outcome);
/*  49 */       recordEvaluation(context, classOrMethodName, outcome);
/*  50 */       return outcome.isMatch();
/*     */     }
/*  52 */     catch (NoClassDefFoundError ex) {
/*  53 */       throw new IllegalStateException("Could not evaluate condition on " + classOrMethodName + " due to " + ex
/*  54 */           .getMessage() + " not found. Make sure your own configuration does not rely on that class. This can also happen if you are @ComponentScanning a springframework package (e.g. if you put a @ComponentScan in the default package by mistake)", ex);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  59 */     catch (RuntimeException ex) {
/*  60 */       throw new IllegalStateException("Error processing condition on " + getName(metadata), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getName(AnnotatedTypeMetadata metadata) {
/*  65 */     if (metadata instanceof AnnotationMetadata) { AnnotationMetadata annotationMetadata = (AnnotationMetadata)metadata;
/*  66 */       return annotationMetadata.getClassName(); }
/*     */     
/*  68 */     if (metadata instanceof MethodMetadata) { MethodMetadata methodMetadata = (MethodMetadata)metadata;
/*  69 */       return methodMetadata.getDeclaringClassName() + "." + methodMetadata.getDeclaringClassName(); }
/*     */     
/*  71 */     return metadata.toString();
/*     */   }
/*     */   
/*     */   private static String getClassOrMethodName(AnnotatedTypeMetadata metadata) {
/*  75 */     if (metadata instanceof ClassMetadata) { ClassMetadata classMetadata = (ClassMetadata)metadata;
/*  76 */       return classMetadata.getClassName(); }
/*     */     
/*  78 */     MethodMetadata methodMetadata = (MethodMetadata)metadata;
/*  79 */     return methodMetadata.getDeclaringClassName() + "#" + methodMetadata.getDeclaringClassName();
/*     */   }
/*     */   
/*     */   protected final void logOutcome(String classOrMethodName, ConditionOutcome outcome) {
/*  83 */     if (this.logger.isTraceEnabled()) {
/*  84 */       this.logger.trace(getLogMessage(classOrMethodName, outcome));
/*     */     }
/*     */   }
/*     */   
/*     */   private StringBuilder getLogMessage(String classOrMethodName, ConditionOutcome outcome) {
/*  89 */     StringBuilder message = new StringBuilder();
/*  90 */     message.append("Condition ");
/*  91 */     message.append(ClassUtils.getShortName(getClass()));
/*  92 */     message.append(" on ");
/*  93 */     message.append(classOrMethodName);
/*  94 */     message.append(outcome.isMatch() ? " matched" : " did not match");
/*  95 */     if (StringUtils.hasLength(outcome.getMessage())) {
/*  96 */       message.append(" due to ");
/*  97 */       message.append(outcome.getMessage());
/*     */     } 
/*  99 */     return message;
/*     */   }
/*     */   
/*     */   private void recordEvaluation(ConditionContext context, String classOrMethodName, ConditionOutcome outcome) {
/* 103 */     if (context.getBeanFactory() != null) {
/* 104 */       ConditionEvaluationReport.get(context.getBeanFactory())
/* 105 */         .recordConditionEvaluation(classOrMethodName, this, outcome);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ConditionOutcome getMatchOutcome(ConditionContext paramConditionContext, AnnotatedTypeMetadata paramAnnotatedTypeMetadata);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean anyMatches(ConditionContext context, AnnotatedTypeMetadata metadata, Condition... conditions) {
/* 126 */     for (Condition condition : conditions) {
/* 127 */       if (matches(context, metadata, condition)) {
/* 128 */         return true;
/*     */       }
/*     */     } 
/* 131 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata, Condition condition) {
/* 142 */     if (condition instanceof SpringBootCondition) { SpringBootCondition springBootCondition = (SpringBootCondition)condition;
/* 143 */       return springBootCondition.getMatchOutcome(context, metadata).isMatch(); }
/*     */     
/* 145 */     return condition.matches(context, metadata);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\SpringBootCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */