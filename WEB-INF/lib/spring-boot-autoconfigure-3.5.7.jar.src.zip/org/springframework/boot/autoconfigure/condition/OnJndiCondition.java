/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.jndi.JndiLocatorDelegate;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(2147483627)
/*     */ class OnJndiCondition
/*     */   extends SpringBootCondition
/*     */ {
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  43 */     AnnotationAttributes annotationAttributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(ConditionalOnJndi.class.getName()));
/*  44 */     String[] locations = annotationAttributes.getStringArray("value");
/*     */     try {
/*  46 */       return getMatchOutcome(locations);
/*     */     }
/*  48 */     catch (NoClassDefFoundError ex) {
/*  49 */       return 
/*  50 */         ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnJndi.class, new Object[0]).because("JNDI class not found"));
/*     */     } 
/*     */   }
/*     */   
/*     */   private ConditionOutcome getMatchOutcome(String[] locations) {
/*  55 */     if (!isJndiAvailable()) {
/*  56 */       return 
/*  57 */         ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnJndi.class, new Object[0]).notAvailable("JNDI environment"));
/*     */     }
/*  59 */     if (locations.length == 0) {
/*  60 */       return 
/*  61 */         ConditionOutcome.match(ConditionMessage.forCondition((Class)ConditionalOnJndi.class, new Object[0]).available("JNDI environment"));
/*     */     }
/*  63 */     JndiLocator locator = getJndiLocator(locations);
/*  64 */     String location = locator.lookupFirstLocation();
/*  65 */     String details = "(" + StringUtils.arrayToCommaDelimitedString((Object[])locations) + ")";
/*  66 */     if (location != null) {
/*  67 */       return ConditionOutcome.match(ConditionMessage.forCondition((Class)ConditionalOnJndi.class, new Object[] { details
/*  68 */             }).foundExactly("\"" + location + "\""));
/*     */     }
/*  70 */     return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnJndi.class, new Object[] { details
/*  71 */           }).didNotFind("any matching JNDI location")
/*  72 */         .atAll());
/*     */   }
/*     */   
/*     */   protected boolean isJndiAvailable() {
/*  76 */     return JndiLocatorDelegate.isDefaultJndiEnvironmentAvailable();
/*     */   }
/*     */   
/*     */   protected JndiLocator getJndiLocator(String[] locations) {
/*  80 */     return new JndiLocator(locations);
/*     */   }
/*     */   
/*     */   protected static class JndiLocator
/*     */     extends JndiLocatorSupport {
/*     */     private final String[] locations;
/*     */     
/*     */     public JndiLocator(String[] locations) {
/*  88 */       this.locations = locations;
/*     */     }
/*     */     
/*     */     public String lookupFirstLocation() {
/*  92 */       for (String location : this.locations) {
/*     */         try {
/*  94 */           lookup(location);
/*  95 */           return location;
/*     */         }
/*  97 */         catch (NamingException namingException) {}
/*     */       } 
/*     */ 
/*     */       
/* 101 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnJndiCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */