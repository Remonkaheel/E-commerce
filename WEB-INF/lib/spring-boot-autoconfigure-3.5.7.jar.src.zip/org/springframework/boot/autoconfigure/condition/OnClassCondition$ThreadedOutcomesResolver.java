/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ThreadedOutcomesResolver
/*     */   implements OnClassCondition.OutcomesResolver
/*     */ {
/*     */   private final Thread thread;
/*     */   private volatile ConditionOutcome[] outcomes;
/*     */   private volatile Throwable failure;
/*     */   
/*     */   private ThreadedOutcomesResolver(OnClassCondition.OutcomesResolver outcomesResolver) {
/* 149 */     this.thread = new Thread(() -> {
/*     */           
/*     */           try {
/*     */             this.outcomes = outcomesResolver.resolveOutcomes();
/* 153 */           } catch (Throwable ex) {
/*     */             this.failure = ex;
/*     */           } 
/*     */         });
/* 157 */     this.thread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome[] resolveOutcomes() {
/*     */     try {
/* 163 */       this.thread.join();
/*     */     }
/* 165 */     catch (InterruptedException ex) {
/* 166 */       Thread.currentThread().interrupt();
/*     */     } 
/* 168 */     Throwable failure = this.failure;
/* 169 */     if (failure != null) {
/* 170 */       ReflectionUtils.rethrowRuntimeException(failure);
/*     */     }
/* 172 */     ConditionOutcome[] outcomes = this.outcomes;
/* 173 */     return (outcomes != null) ? outcomes : new ConditionOutcome[0];
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnClassCondition$ThreadedOutcomesResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */