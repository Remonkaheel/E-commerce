/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemberMatchOutcomes
/*    */ {
/*    */   private final List<ConditionOutcome> all;
/*    */   private final List<ConditionOutcome> matches;
/*    */   private final List<ConditionOutcome> nonMatches;
/*    */   
/*    */   public MemberMatchOutcomes(AbstractNestedCondition.MemberConditions memberConditions) {
/* 78 */     this.all = Collections.unmodifiableList(memberConditions.getMatchOutcomes());
/* 79 */     List<ConditionOutcome> matches = new ArrayList<>();
/* 80 */     List<ConditionOutcome> nonMatches = new ArrayList<>();
/* 81 */     for (ConditionOutcome outcome : this.all) {
/* 82 */       (outcome.isMatch() ? matches : nonMatches).add(outcome);
/*    */     }
/* 84 */     this.matches = Collections.unmodifiableList(matches);
/* 85 */     this.nonMatches = Collections.unmodifiableList(nonMatches);
/*    */   }
/*    */   
/*    */   public List<ConditionOutcome> getAll() {
/* 89 */     return this.all;
/*    */   }
/*    */   
/*    */   public List<ConditionOutcome> getMatches() {
/* 93 */     return this.matches;
/*    */   }
/*    */   
/*    */   public List<ConditionOutcome> getNonMatches() {
/* 97 */     return this.nonMatches;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\AbstractNestedCondition$MemberMatchOutcomes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */