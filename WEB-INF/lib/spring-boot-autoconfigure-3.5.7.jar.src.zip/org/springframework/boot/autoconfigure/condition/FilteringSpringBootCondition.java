/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationImportFilter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class FilteringSpringBootCondition
/*     */   extends SpringBootCondition
/*     */   implements AutoConfigurationImportFilter, BeanFactoryAware, BeanClassLoaderAware
/*     */ {
/*     */   private BeanFactory beanFactory;
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   public boolean[] match(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  48 */     ConditionEvaluationReport report = ConditionEvaluationReport.find(this.beanFactory);
/*  49 */     ConditionOutcome[] outcomes = getOutcomes(autoConfigurationClasses, autoConfigurationMetadata);
/*  50 */     boolean[] match = new boolean[outcomes.length];
/*  51 */     for (int i = 0; i < outcomes.length; i++) {
/*  52 */       match[i] = (outcomes[i] == null || outcomes[i].isMatch());
/*  53 */       if (!match[i] && outcomes[i] != null) {
/*  54 */         logOutcome(autoConfigurationClasses[i], outcomes[i]);
/*  55 */         if (report != null) {
/*  56 */           report.recordConditionEvaluation(autoConfigurationClasses[i], this, outcomes[i]);
/*     */         }
/*     */       } 
/*     */     } 
/*  60 */     return match;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract ConditionOutcome[] getOutcomes(String[] paramArrayOfString, AutoConfigurationMetadata paramAutoConfigurationMetadata);
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  68 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   protected final BeanFactory getBeanFactory() {
/*  72 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */   protected final ClassLoader getBeanClassLoader() {
/*  76 */     return this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  81 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final List<String> filter(Collection<String> classNames, ClassNameFilter classNameFilter, ClassLoader classLoader) {
/*  86 */     if (CollectionUtils.isEmpty(classNames)) {
/*  87 */       return Collections.emptyList();
/*     */     }
/*  89 */     List<String> matches = new ArrayList<>(classNames.size());
/*  90 */     for (String candidate : classNames) {
/*  91 */       if (classNameFilter.matches(candidate, classLoader)) {
/*  92 */         matches.add(candidate);
/*     */       }
/*     */     } 
/*  95 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Class<?> resolve(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 107 */     if (classLoader != null) {
/* 108 */       return Class.forName(className, false, classLoader);
/*     */     }
/* 110 */     return Class.forName(className);
/*     */   }
/*     */   
/*     */   protected enum ClassNameFilter
/*     */   {
/* 115 */     PRESENT
/*     */     {
/*     */       public boolean matches(String className, ClassLoader classLoader)
/*     */       {
/* 119 */         return isPresent(className, classLoader);
/*     */       }
/*     */     },
/*     */ 
/*     */     
/* 124 */     MISSING
/*     */     {
/*     */       public boolean matches(String className, ClassLoader classLoader)
/*     */       {
/* 128 */         return !isPresent(className, classLoader);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean isPresent(String className, ClassLoader classLoader) {
/* 136 */       if (classLoader == null) {
/* 137 */         classLoader = ClassUtils.getDefaultClassLoader();
/*     */       }
/*     */       try {
/* 140 */         FilteringSpringBootCondition.resolve(className, classLoader);
/* 141 */         return true;
/*     */       }
/* 143 */       catch (Throwable ex) {
/* 144 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     abstract boolean matches(String param1String, ClassLoader param1ClassLoader);
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public boolean matches(String className, ClassLoader classLoader) {
/*     */       return FilteringSpringBootCondition.ClassNameFilter.isPresent(className, classLoader);
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     public boolean matches(String className, ClassLoader classLoader) {
/*     */       return !FilteringSpringBootCondition.ClassNameFilter.isPresent(className, classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\FilteringSpringBootCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */