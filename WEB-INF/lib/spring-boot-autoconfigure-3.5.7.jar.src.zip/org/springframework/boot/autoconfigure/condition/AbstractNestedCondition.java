/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractNestedCondition
/*     */   extends SpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*     */   private final ConfigurationCondition.ConfigurationPhase configurationPhase;
/*     */   
/*     */   AbstractNestedCondition(ConfigurationCondition.ConfigurationPhase configurationPhase) {
/*  50 */     Assert.notNull(configurationPhase, "'configurationPhase' must not be null");
/*  51 */     this.configurationPhase = configurationPhase;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase() {
/*  56 */     return this.configurationPhase;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  61 */     String className = getClass().getName();
/*  62 */     MemberConditions memberConditions = new MemberConditions(context, this.configurationPhase, className);
/*  63 */     MemberMatchOutcomes memberOutcomes = new MemberMatchOutcomes(memberConditions);
/*  64 */     return getFinalMatchOutcome(memberOutcomes);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract ConditionOutcome getFinalMatchOutcome(MemberMatchOutcomes paramMemberMatchOutcomes);
/*     */ 
/*     */   
/*     */   protected static class MemberMatchOutcomes
/*     */   {
/*     */     private final List<ConditionOutcome> all;
/*     */     private final List<ConditionOutcome> matches;
/*     */     private final List<ConditionOutcome> nonMatches;
/*     */     
/*     */     public MemberMatchOutcomes(AbstractNestedCondition.MemberConditions memberConditions) {
/*  78 */       this.all = Collections.unmodifiableList(memberConditions.getMatchOutcomes());
/*  79 */       List<ConditionOutcome> matches = new ArrayList<>();
/*  80 */       List<ConditionOutcome> nonMatches = new ArrayList<>();
/*  81 */       for (ConditionOutcome outcome : this.all) {
/*  82 */         (outcome.isMatch() ? matches : nonMatches).add(outcome);
/*     */       }
/*  84 */       this.matches = Collections.unmodifiableList(matches);
/*  85 */       this.nonMatches = Collections.unmodifiableList(nonMatches);
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getAll() {
/*  89 */       return this.all;
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getMatches() {
/*  93 */       return this.matches;
/*     */     }
/*     */     
/*     */     public List<ConditionOutcome> getNonMatches() {
/*  97 */       return this.nonMatches;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MemberConditions
/*     */   {
/*     */     private final ConditionContext context;
/*     */     
/*     */     private final MetadataReaderFactory readerFactory;
/*     */     
/*     */     private final Map<AnnotationMetadata, List<Condition>> memberConditions;
/*     */     
/*     */     MemberConditions(ConditionContext context, ConfigurationCondition.ConfigurationPhase phase, String className) {
/* 111 */       this.context = context;
/* 112 */       this.readerFactory = (MetadataReaderFactory)new SimpleMetadataReaderFactory(context.getResourceLoader());
/* 113 */       String[] members = getMetadata(className).getMemberClassNames();
/* 114 */       this.memberConditions = getMemberConditions(members, phase, className);
/*     */     }
/*     */ 
/*     */     
/*     */     private Map<AnnotationMetadata, List<Condition>> getMemberConditions(String[] members, ConfigurationCondition.ConfigurationPhase phase, String className) {
/* 119 */       LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 120 */       for (String member : members) {
/* 121 */         AnnotationMetadata metadata = getMetadata(member);
/* 122 */         for (String[] conditionClasses : getConditionClasses((AnnotatedTypeMetadata)metadata)) {
/* 123 */           for (String conditionClass : conditionClasses) {
/* 124 */             Condition condition = getCondition(conditionClass);
/* 125 */             validateMemberCondition(condition, phase, className);
/* 126 */             linkedMultiValueMap.add(metadata, condition);
/*     */           } 
/*     */         } 
/*     */       } 
/* 130 */       return Collections.unmodifiableMap((Map<? extends AnnotationMetadata, ? extends List<Condition>>)linkedMultiValueMap);
/*     */     }
/*     */ 
/*     */     
/*     */     private void validateMemberCondition(Condition condition, ConfigurationCondition.ConfigurationPhase nestedPhase, String nestedClassName) {
/* 135 */       if (nestedPhase == ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION && condition instanceof ConfigurationCondition) {
/* 136 */         ConfigurationCondition configurationCondition = (ConfigurationCondition)condition;
/* 137 */         ConfigurationCondition.ConfigurationPhase memberPhase = configurationCondition.getConfigurationPhase();
/* 138 */         if (memberPhase == ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN) {
/* 139 */           throw new IllegalStateException("Nested condition " + nestedClassName + " uses a configuration phase that is inappropriate for " + 
/* 140 */               String.valueOf(condition.getClass()));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private AnnotationMetadata getMetadata(String className) {
/*     */       try {
/* 147 */         return this.readerFactory.getMetadataReader(className).getAnnotationMetadata();
/*     */       }
/* 149 */       catch (IOException ex) {
/* 150 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private List<String[]> getConditionClasses(AnnotatedTypeMetadata metadata) {
/* 156 */       MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(Conditional.class.getName(), true);
/*     */       
/* 158 */       Object values = (attributes != null) ? attributes.get("value") : null;
/* 159 */       return (values != null) ? (List<String[]>)values : (List)Collections.<String[]>emptyList();
/*     */     }
/*     */     
/*     */     private Condition getCondition(String conditionClassName) {
/* 163 */       Class<?> conditionClass = ClassUtils.resolveClassName(conditionClassName, this.context.getClassLoader());
/* 164 */       return (Condition)BeanUtils.instantiateClass(conditionClass);
/*     */     }
/*     */     
/*     */     List<ConditionOutcome> getMatchOutcomes() {
/* 168 */       List<ConditionOutcome> outcomes = new ArrayList<>();
/* 169 */       this.memberConditions.forEach((metadata, conditions) -> outcomes.add((new AbstractNestedCondition.MemberOutcomes(this.context, metadata, conditions)).getUltimateOutcome()));
/*     */       
/* 171 */       return Collections.unmodifiableList(outcomes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MemberOutcomes
/*     */   {
/*     */     private final ConditionContext context;
/*     */     
/*     */     private final AnnotationMetadata metadata;
/*     */     
/*     */     private final List<ConditionOutcome> outcomes;
/*     */     
/*     */     MemberOutcomes(ConditionContext context, AnnotationMetadata metadata, List<Condition> conditions) {
/* 185 */       this.context = context;
/* 186 */       this.metadata = metadata;
/* 187 */       this.outcomes = new ArrayList<>(conditions.size());
/* 188 */       for (Condition condition : conditions) {
/* 189 */         this.outcomes.add(getConditionOutcome(metadata, condition));
/*     */       }
/*     */     }
/*     */     
/*     */     private ConditionOutcome getConditionOutcome(AnnotationMetadata metadata, Condition condition) {
/* 194 */       if (condition instanceof SpringBootCondition) { SpringBootCondition springBootCondition = (SpringBootCondition)condition;
/* 195 */         return springBootCondition.getMatchOutcome(this.context, (AnnotatedTypeMetadata)metadata); }
/*     */       
/* 197 */       return new ConditionOutcome(condition.matches(this.context, (AnnotatedTypeMetadata)metadata), ConditionMessage.empty());
/*     */     }
/*     */ 
/*     */     
/*     */     ConditionOutcome getUltimateOutcome() {
/* 202 */       ConditionMessage.Builder message = ConditionMessage.forCondition("NestedCondition on " + ClassUtils.getShortName(this.metadata.getClassName()), new Object[0]);
/* 203 */       if (this.outcomes.size() == 1) {
/* 204 */         ConditionOutcome outcome = this.outcomes.get(0);
/* 205 */         return new ConditionOutcome(outcome.isMatch(), message.because(outcome.getMessage()));
/*     */       } 
/* 207 */       List<ConditionOutcome> match = new ArrayList<>();
/* 208 */       List<ConditionOutcome> nonMatch = new ArrayList<>();
/* 209 */       for (ConditionOutcome outcome : this.outcomes) {
/* 210 */         (outcome.isMatch() ? match : nonMatch).add(outcome);
/*     */       }
/* 212 */       if (nonMatch.isEmpty()) {
/* 213 */         return ConditionOutcome.match(message.found("matching nested conditions").items(match));
/*     */       }
/* 215 */       return ConditionOutcome.noMatch(message.found("non-matching nested conditions").items(nonMatch));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\AbstractNestedCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */