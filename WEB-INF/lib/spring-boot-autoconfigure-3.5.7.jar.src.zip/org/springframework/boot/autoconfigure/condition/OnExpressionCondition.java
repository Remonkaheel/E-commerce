/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*    */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ class OnExpressionCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 41 */     String expression = (String)metadata.getAnnotationAttributes(ConditionalOnExpression.class.getName()).get("value");
/* 42 */     expression = wrapIfNecessary(expression);
/* 43 */     ConditionMessage.Builder messageBuilder = ConditionMessage.forCondition((Class)ConditionalOnExpression.class, new Object[] { "(" + expression + ")" });
/*    */     
/* 45 */     expression = context.getEnvironment().resolvePlaceholders(expression);
/* 46 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 47 */     if (beanFactory != null) {
/* 48 */       boolean result = evaluateExpression(beanFactory, expression);
/* 49 */       return new ConditionOutcome(result, messageBuilder.resultedIn(Boolean.valueOf(result)));
/*    */     } 
/* 51 */     return ConditionOutcome.noMatch(messageBuilder.because("no BeanFactory available."));
/*    */   }
/*    */   private boolean evaluateExpression(ConfigurableListableBeanFactory beanFactory, String expression) {
/*    */     StandardBeanExpressionResolver standardBeanExpressionResolver;
/* 55 */     BeanExpressionResolver resolver = beanFactory.getBeanExpressionResolver();
/* 56 */     if (resolver == null) {
/* 57 */       standardBeanExpressionResolver = new StandardBeanExpressionResolver();
/*    */     }
/* 59 */     BeanExpressionContext expressionContext = new BeanExpressionContext((ConfigurableBeanFactory)beanFactory, null);
/* 60 */     Object result = standardBeanExpressionResolver.evaluate(expression, expressionContext);
/* 61 */     return (result != null && ((Boolean)result).booleanValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String wrapIfNecessary(String expression) {
/* 70 */     if (!expression.startsWith("#{")) {
/* 71 */       return "#{" + expression + "}";
/*    */     }
/* 73 */     return expression;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnExpressionCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */