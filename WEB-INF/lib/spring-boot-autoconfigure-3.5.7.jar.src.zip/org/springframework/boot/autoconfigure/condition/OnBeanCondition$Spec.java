/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotationCollectors;
/*     */ import org.springframework.core.annotation.MergedAnnotationPredicates;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Spec<A extends Annotation>
/*     */ {
/*     */   private final ConditionContext context;
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   private final Set<String> names;
/*     */   private final Set<ResolvableType> types;
/*     */   private final Set<String> annotations;
/*     */   private final Set<ResolvableType> ignoredTypes;
/*     */   private final Set<ResolvableType> parameterizedContainers;
/*     */   private final SearchStrategy strategy;
/*     */   
/*     */   Spec(ConditionContext context, AnnotatedTypeMetadata metadata, MergedAnnotations annotations, Class<A> annotationType) {
/* 558 */     MultiValueMap<String, Object> attributes = (MultiValueMap<String, Object>)annotations.stream(annotationType).filter(MergedAnnotationPredicates.unique(MergedAnnotation::getMetaTypes)).collect(MergedAnnotationCollectors.toMultiValueMap(new MergedAnnotation.Adapt[] { MergedAnnotation.Adapt.CLASS_TO_STRING }));
/* 559 */     MergedAnnotation<A> annotation = annotations.get(annotationType);
/* 560 */     this.context = context;
/* 561 */     this.annotationType = annotationType;
/* 562 */     this.names = extract(attributes, new String[] { "name" });
/* 563 */     this.annotations = extract(attributes, new String[] { "annotation" });
/* 564 */     this.ignoredTypes = resolveWhenPossible(extract(attributes, new String[] { "ignored", "ignoredType" }));
/* 565 */     this.parameterizedContainers = resolveWhenPossible(extract(attributes, new String[] { "parameterizedContainer" }));
/* 566 */     this.strategy = annotation.getValue("search", SearchStrategy.class).orElse(null);
/* 567 */     Set<ResolvableType> types = resolveWhenPossible(extractTypes(attributes));
/* 568 */     OnBeanCondition.BeanTypeDeductionException deductionException = null;
/* 569 */     if (types.isEmpty() && this.names.isEmpty() && this.annotations.isEmpty()) {
/*     */       try {
/* 571 */         types = deducedBeanType(context, metadata);
/*     */       }
/* 573 */       catch (BeanTypeDeductionException ex) {
/* 574 */         deductionException = ex;
/*     */       } 
/*     */     }
/* 577 */     this.types = types;
/* 578 */     validate(deductionException);
/*     */   }
/*     */   
/*     */   protected Set<String> extractTypes(MultiValueMap<String, Object> attributes) {
/* 582 */     return extract(attributes, new String[] { "value", "type" });
/*     */   }
/*     */   
/*     */   private Set<String> extract(MultiValueMap<String, Object> attributes, String... attributeNames) {
/* 586 */     if (attributes.isEmpty()) {
/* 587 */       return Collections.emptySet();
/*     */     }
/* 589 */     Set<String> result = new LinkedHashSet<>();
/* 590 */     for (String attributeName : attributeNames) {
/* 591 */       List<Object> values = (List<Object>)attributes.getOrDefault(attributeName, Collections.emptyList());
/* 592 */       for (Object value : values) {
/* 593 */         if (value instanceof String[]) { String[] stringArray = (String[])value;
/* 594 */           merge(result, stringArray); continue; }
/*     */         
/* 596 */         if (value instanceof String) { String string = (String)value;
/* 597 */           merge(result, new String[] { string }); }
/*     */       
/*     */       } 
/*     */     } 
/* 601 */     return result.isEmpty() ? Collections.<String>emptySet() : result;
/*     */   }
/*     */   
/*     */   private void merge(Set<String> result, String... additional) {
/* 605 */     Collections.addAll(result, additional);
/*     */   }
/*     */   
/*     */   private Set<ResolvableType> resolveWhenPossible(Set<String> classNames) {
/* 609 */     if (classNames.isEmpty()) {
/* 610 */       return Collections.emptySet();
/*     */     }
/* 612 */     Set<ResolvableType> resolved = new LinkedHashSet<>(classNames.size());
/* 613 */     for (String className : classNames) {
/*     */       try {
/* 615 */         Class<?> type = FilteringSpringBootCondition.resolve(className, this.context.getClassLoader());
/* 616 */         resolved.add(ResolvableType.forRawClass(type));
/*     */       }
/* 618 */       catch (ClassNotFoundException|NoClassDefFoundError ex) {
/* 619 */         resolved.add(ResolvableType.NONE);
/*     */       } 
/*     */     } 
/* 622 */     return resolved;
/*     */   }
/*     */   
/*     */   protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 626 */     if (!hasAtLeastOneElement((Set<?>[])new Set[] { getTypes(), getNames(), getAnnotations() })) {
/* 627 */       String message = getAnnotationName() + " did not specify a bean using type, name or annotation";
/* 628 */       if (ex == null) {
/* 629 */         throw new IllegalStateException(message);
/*     */       }
/* 631 */       throw new IllegalStateException(message + " and the attempt to deduce the bean's type failed", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasAtLeastOneElement(Set<?>... sets) {
/* 636 */     for (Set<?> set : sets) {
/* 637 */       if (!set.isEmpty()) {
/* 638 */         return true;
/*     */       }
/*     */     } 
/* 641 */     return false;
/*     */   }
/*     */   
/*     */   protected final String getAnnotationName() {
/* 645 */     return "@" + ClassUtils.getShortName(this.annotationType);
/*     */   }
/*     */   
/*     */   private Set<ResolvableType> deducedBeanType(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 649 */     if (metadata instanceof MethodMetadata && metadata.isAnnotated(Bean.class.getName())) {
/* 650 */       return deducedBeanTypeForBeanMethod(context, (MethodMetadata)metadata);
/*     */     }
/* 652 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   private Set<ResolvableType> deducedBeanTypeForBeanMethod(ConditionContext context, MethodMetadata metadata) {
/*     */     try {
/* 657 */       return Set.of(getReturnType(context, metadata));
/*     */     }
/* 659 */     catch (Throwable ex) {
/* 660 */       throw new OnBeanCondition.BeanTypeDeductionException(metadata.getDeclaringClassName(), metadata.getMethodName(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvableType getReturnType(ConditionContext context, MethodMetadata metadata) throws ClassNotFoundException, LinkageError {
/* 667 */     ClassLoader classLoader = context.getClassLoader();
/* 668 */     ResolvableType returnType = getMethodReturnType(metadata, classLoader);
/* 669 */     if (isParameterizedContainer(returnType.resolve())) {
/* 670 */       returnType = returnType.getGeneric(new int[0]);
/*     */     }
/* 672 */     return returnType;
/*     */   }
/*     */   
/*     */   private boolean isParameterizedContainer(Class<?> type) {
/* 676 */     return (type != null && this.parameterizedContainers.stream()
/* 677 */       .map(ResolvableType::resolve)
/* 678 */       .anyMatch(container -> (container != null && container.isAssignableFrom(type))));
/*     */   }
/*     */ 
/*     */   
/*     */   private ResolvableType getMethodReturnType(MethodMetadata metadata, ClassLoader classLoader) throws ClassNotFoundException, LinkageError {
/* 683 */     Class<?> declaringClass = FilteringSpringBootCondition.resolve(metadata.getDeclaringClassName(), classLoader);
/* 684 */     Method beanMethod = findBeanMethod(declaringClass, metadata.getMethodName());
/* 685 */     return ResolvableType.forMethodReturnType(beanMethod);
/*     */   }
/*     */   
/*     */   private Method findBeanMethod(Class<?> declaringClass, String methodName) {
/* 689 */     Method method = ReflectionUtils.findMethod(declaringClass, methodName);
/* 690 */     if (isBeanMethod(method)) {
/* 691 */       return method;
/*     */     }
/* 693 */     Method[] candidates = ReflectionUtils.getAllDeclaredMethods(declaringClass);
/* 694 */     for (Method candidate : candidates) {
/* 695 */       if (candidate.getName().equals(methodName) && isBeanMethod(candidate)) {
/* 696 */         return candidate;
/*     */       }
/*     */     } 
/* 699 */     throw new IllegalStateException("Unable to find bean method " + methodName);
/*     */   }
/*     */   
/*     */   private boolean isBeanMethod(Method method) {
/* 703 */     return (method != null && MergedAnnotations.from(method, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 704 */       .isPresent(Bean.class));
/*     */   }
/*     */   
/*     */   private SearchStrategy getStrategy() {
/* 708 */     return (this.strategy != null) ? this.strategy : SearchStrategy.ALL;
/*     */   }
/*     */   
/*     */   Set<ResolvableType> getTypes() {
/* 712 */     return this.types;
/*     */   }
/*     */   
/*     */   private ConditionContext getContext() {
/* 716 */     return this.context;
/*     */   }
/*     */   
/*     */   private Set<String> getNames() {
/* 720 */     return this.names;
/*     */   }
/*     */   
/*     */   private Set<String> getAnnotations() {
/* 724 */     return this.annotations;
/*     */   }
/*     */   
/*     */   private Set<ResolvableType> getIgnoredTypes() {
/* 728 */     return this.ignoredTypes;
/*     */   }
/*     */   
/*     */   private Set<ResolvableType> getParameterizedContainers() {
/* 732 */     return this.parameterizedContainers;
/*     */   }
/*     */   
/*     */   private ConditionMessage.Builder message() {
/* 736 */     return ConditionMessage.forCondition(this.annotationType, new Object[] { this });
/*     */   }
/*     */   
/*     */   private ConditionMessage.Builder message(ConditionMessage message) {
/* 740 */     return message.andCondition(this.annotationType, new Object[] { this });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 745 */     boolean hasNames = !this.names.isEmpty();
/* 746 */     boolean hasTypes = !this.types.isEmpty();
/* 747 */     boolean hasIgnoredTypes = !this.ignoredTypes.isEmpty();
/* 748 */     StringBuilder string = new StringBuilder();
/* 749 */     string.append("(");
/* 750 */     if (hasNames) {
/* 751 */       string.append("names: ");
/* 752 */       string.append(StringUtils.collectionToCommaDelimitedString(this.names));
/* 753 */       string.append(hasTypes ? " " : "; ");
/*     */     } 
/* 755 */     if (hasTypes) {
/* 756 */       string.append("types: ");
/* 757 */       string.append(StringUtils.collectionToCommaDelimitedString(this.types));
/* 758 */       string.append(hasIgnoredTypes ? " " : "; ");
/*     */     } 
/* 760 */     if (hasIgnoredTypes) {
/* 761 */       string.append("ignored: ");
/* 762 */       string.append(StringUtils.collectionToCommaDelimitedString(this.ignoredTypes));
/* 763 */       string.append("; ");
/*     */     } 
/* 765 */     string.append("SearchStrategy: ");
/* 766 */     string.append(this.strategy.toString().toLowerCase(Locale.ENGLISH));
/* 767 */     string.append(")");
/* 768 */     return string.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnBeanCondition$Spec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */