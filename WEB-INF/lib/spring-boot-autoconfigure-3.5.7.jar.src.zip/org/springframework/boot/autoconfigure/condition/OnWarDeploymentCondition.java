/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnWarDeploymentCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 39 */     boolean required = metadata.isAnnotated(ConditionalOnWarDeployment.class.getName());
/* 40 */     ResourceLoader resourceLoader = context.getResourceLoader();
/* 41 */     if (resourceLoader instanceof WebApplicationContext) { WebApplicationContext applicationContext = (WebApplicationContext)resourceLoader;
/* 42 */       ServletContext servletContext = applicationContext.getServletContext();
/* 43 */       if (servletContext != null) {
/* 44 */         return new ConditionOutcome(required, "Application is deployed as a WAR file.");
/*    */       } }
/*    */     
/* 47 */     return new ConditionOutcome(!required, ConditionMessage.forCondition((Class)ConditionalOnWarDeployment.class, new Object[0])
/* 48 */         .because("the application is not deployed as a WAR file."));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnWarDeploymentCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */