/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aop.scope.ScopedProxyUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotationCollectors;
/*     */ import org.springframework.core.annotation.MergedAnnotationPredicates;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(2147483647)
/*     */ class OnBeanCondition
/*     */   extends FilteringSpringBootCondition
/*     */   implements ConfigurationCondition
/*     */ {
/*     */   public ConfigurationCondition.ConfigurationPhase getConfigurationPhase() {
/*  89 */     return ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  95 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  96 */     for (int i = 0; i < outcomes.length; i++) {
/*  97 */       String autoConfigurationClass = autoConfigurationClasses[i];
/*  98 */       if (autoConfigurationClass != null) {
/*  99 */         Set<String> onBeanTypes = autoConfigurationMetadata.getSet(autoConfigurationClass, "ConditionalOnBean");
/* 100 */         outcomes[i] = getOutcome(onBeanTypes, (Class)ConditionalOnBean.class);
/* 101 */         if (outcomes[i] == null) {
/* 102 */           Set<String> onSingleCandidateTypes = autoConfigurationMetadata.getSet(autoConfigurationClass, "ConditionalOnSingleCandidate");
/*     */           
/* 104 */           outcomes[i] = getOutcome(onSingleCandidateTypes, (Class)ConditionalOnSingleCandidate.class);
/*     */         } 
/*     */       } 
/*     */     } 
/* 108 */     return outcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(Set<String> requiredBeanTypes, Class<? extends Annotation> annotation) {
/* 112 */     List<String> missing = filter(requiredBeanTypes, FilteringSpringBootCondition.ClassNameFilter.MISSING, getBeanClassLoader());
/* 113 */     if (!missing.isEmpty()) {
/*     */ 
/*     */       
/* 116 */       ConditionMessage message = ConditionMessage.forCondition(annotation, new Object[0]).didNotFind("required type", "required types").items(ConditionMessage.Style.QUOTE, missing);
/* 117 */       return ConditionOutcome.noMatch(message);
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 124 */     ConditionOutcome matchOutcome = ConditionOutcome.match();
/* 125 */     MergedAnnotations annotations = metadata.getAnnotations();
/* 126 */     if (annotations.isPresent(ConditionalOnBean.class)) {
/* 127 */       Spec<ConditionalOnBean> spec = new Spec<>(context, metadata, annotations, ConditionalOnBean.class);
/* 128 */       matchOutcome = evaluateConditionalOnBean(spec, matchOutcome.getConditionMessage());
/* 129 */       if (!matchOutcome.isMatch()) {
/* 130 */         return matchOutcome;
/*     */       }
/*     */     } 
/* 133 */     if (metadata.isAnnotated(ConditionalOnSingleCandidate.class.getName())) {
/*     */       
/* 135 */       Spec<ConditionalOnSingleCandidate> spec = new SingleCandidateSpec(context, metadata, metadata.getAnnotations());
/* 136 */       matchOutcome = evaluateConditionalOnSingleCandidate(spec, matchOutcome.getConditionMessage());
/* 137 */       if (!matchOutcome.isMatch()) {
/* 138 */         return matchOutcome;
/*     */       }
/*     */     } 
/* 141 */     if (metadata.isAnnotated(ConditionalOnMissingBean.class.getName())) {
/* 142 */       Spec<ConditionalOnMissingBean> spec = new Spec<>(context, metadata, annotations, ConditionalOnMissingBean.class);
/*     */       
/* 144 */       matchOutcome = evaluateConditionalOnMissingBean(spec, matchOutcome.getConditionMessage());
/* 145 */       if (!matchOutcome.isMatch()) {
/* 146 */         return matchOutcome;
/*     */       }
/*     */     } 
/* 149 */     return matchOutcome;
/*     */   }
/*     */   
/*     */   private ConditionOutcome evaluateConditionalOnBean(Spec<ConditionalOnBean> spec, ConditionMessage matchMessage) {
/* 153 */     MatchResult matchResult = getMatchingBeans(spec);
/* 154 */     if (!matchResult.isAllMatched()) {
/* 155 */       String reason = createOnBeanNoMatchReason(matchResult);
/* 156 */       return ConditionOutcome.noMatch(spec.message().because(reason));
/*     */     } 
/* 158 */     return ConditionOutcome.match(spec.message(matchMessage)
/* 159 */         .found("bean", "beans")
/* 160 */         .items(ConditionMessage.Style.QUOTE, matchResult.getNamesOfAllMatches()));
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionOutcome evaluateConditionalOnSingleCandidate(Spec<ConditionalOnSingleCandidate> spec, ConditionMessage matchMessage) {
/* 165 */     MatchResult matchResult = getMatchingBeans(spec);
/* 166 */     if (!matchResult.isAllMatched()) {
/* 167 */       return ConditionOutcome.noMatch(spec.message().didNotFind("any beans").atAll());
/*     */     }
/* 169 */     Set<String> allBeans = matchResult.getNamesOfAllMatches();
/* 170 */     if (allBeans.size() == 1) {
/* 171 */       return 
/* 172 */         ConditionOutcome.match(spec.message(matchMessage).found("a single bean").items(ConditionMessage.Style.QUOTE, allBeans));
/*     */     }
/* 174 */     Map<String, BeanDefinition> beanDefinitions = getBeanDefinitions(spec.context.getBeanFactory(), allBeans, 
/* 175 */         (spec.getStrategy() == SearchStrategy.ALL));
/* 176 */     List<String> primaryBeans = getPrimaryBeans(beanDefinitions);
/* 177 */     if (primaryBeans.size() == 1) {
/* 178 */       return ConditionOutcome.match(spec.message(matchMessage)
/* 179 */           .found("a single primary bean '" + (String)primaryBeans.get(0) + "' from beans")
/* 180 */           .items(ConditionMessage.Style.QUOTE, allBeans));
/*     */     }
/* 182 */     if (primaryBeans.size() > 1) {
/* 183 */       return 
/* 184 */         ConditionOutcome.noMatch(spec.message().found("multiple primary beans").items(ConditionMessage.Style.QUOTE, primaryBeans));
/*     */     }
/* 186 */     List<String> nonFallbackBeans = getNonFallbackBeans(beanDefinitions);
/* 187 */     if (nonFallbackBeans.size() == 1) {
/* 188 */       return ConditionOutcome.match(spec.message(matchMessage)
/* 189 */           .found("a single non-fallback bean '" + (String)nonFallbackBeans.get(0) + "' from beans")
/* 190 */           .items(ConditionMessage.Style.QUOTE, allBeans));
/*     */     }
/* 192 */     return ConditionOutcome.noMatch(spec.message().found("multiple beans").items(ConditionMessage.Style.QUOTE, allBeans));
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionOutcome evaluateConditionalOnMissingBean(Spec<ConditionalOnMissingBean> spec, ConditionMessage matchMessage) {
/* 197 */     MatchResult matchResult = getMatchingBeans(spec);
/* 198 */     if (matchResult.isAnyMatched()) {
/* 199 */       String reason = createOnMissingBeanNoMatchReason(matchResult);
/* 200 */       return ConditionOutcome.noMatch(spec.message().because(reason));
/*     */     } 
/* 202 */     return ConditionOutcome.match(spec.message(matchMessage).didNotFind("any beans").atAll());
/*     */   }
/*     */   
/*     */   protected final MatchResult getMatchingBeans(Spec<?> spec) {
/* 206 */     ConfigurableListableBeanFactory beanFactory = getSearchBeanFactory(spec);
/* 207 */     ClassLoader classLoader = spec.getContext().getClassLoader();
/* 208 */     boolean considerHierarchy = (spec.getStrategy() != SearchStrategy.CURRENT);
/* 209 */     Set<ResolvableType> parameterizedContainers = spec.getParameterizedContainers();
/* 210 */     MatchResult result = new MatchResult();
/* 211 */     Set<String> beansIgnoredByType = getNamesOfBeansIgnoredByType((ListableBeanFactory)beanFactory, considerHierarchy, spec
/* 212 */         .getIgnoredTypes(), parameterizedContainers);
/* 213 */     for (ResolvableType type : spec.getTypes()) {
/* 214 */       Map<String, BeanDefinition> typeMatchedDefinitions = getBeanDefinitionsForType((ListableBeanFactory)beanFactory, considerHierarchy, type, parameterizedContainers);
/*     */       
/* 216 */       Set<String> typeMatchedNames = matchedNamesFrom(typeMatchedDefinitions, (name, definition) -> 
/* 217 */           (!ScopedProxyUtils.isScopedTarget(name) && isCandidate(beanFactory, name, definition, beansIgnoredByType)));
/*     */       
/* 219 */       if (typeMatchedNames.isEmpty()) {
/* 220 */         result.recordUnmatchedType(type);
/*     */         continue;
/*     */       } 
/* 223 */       result.recordMatchedType(type, typeMatchedNames);
/*     */     } 
/*     */     
/* 226 */     for (String annotation : spec.getAnnotations()) {
/* 227 */       Map<String, BeanDefinition> annotationMatchedDefinitions = getBeanDefinitionsForAnnotation(classLoader, beanFactory, annotation, considerHierarchy);
/*     */       
/* 229 */       Set<String> annotationMatchedNames = matchedNamesFrom(annotationMatchedDefinitions, (name, definition) -> isCandidate(beanFactory, name, definition, beansIgnoredByType));
/*     */       
/* 231 */       if (annotationMatchedNames.isEmpty()) {
/* 232 */         result.recordUnmatchedAnnotation(annotation);
/*     */         continue;
/*     */       } 
/* 235 */       result.recordMatchedAnnotation(annotation, annotationMatchedNames);
/*     */     } 
/*     */ 
/*     */     
/* 239 */     for (String beanName : spec.getNames()) {
/* 240 */       if (!beansIgnoredByType.contains(beanName) && containsBean(beanFactory, beanName, considerHierarchy)) {
/* 241 */         result.recordMatchedName(beanName);
/*     */         continue;
/*     */       } 
/* 244 */       result.recordUnmatchedName(beanName);
/*     */     } 
/*     */     
/* 247 */     return result;
/*     */   }
/*     */   
/*     */   private ConfigurableListableBeanFactory getSearchBeanFactory(Spec<?> spec) {
/* 251 */     ConfigurableListableBeanFactory beanFactory = spec.getContext().getBeanFactory();
/* 252 */     if (spec.getStrategy() == SearchStrategy.ANCESTORS) {
/* 253 */       BeanFactory parent = beanFactory.getParentBeanFactory();
/* 254 */       Assert.state(parent instanceof ConfigurableListableBeanFactory, "Unable to use SearchStrategy.ANCESTORS without ConfigurableListableBeanFactory");
/*     */       
/* 256 */       beanFactory = (ConfigurableListableBeanFactory)parent;
/*     */     } 
/* 258 */     return beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> matchedNamesFrom(Map<String, BeanDefinition> namedDefinitions, BiPredicate<String, BeanDefinition> filter) {
/* 263 */     Set<String> matchedNames = new LinkedHashSet<>(namedDefinitions.size());
/* 264 */     for (Map.Entry<String, BeanDefinition> namedDefinition : namedDefinitions.entrySet()) {
/* 265 */       if (filter.test(namedDefinition.getKey(), namedDefinition.getValue())) {
/* 266 */         matchedNames.add(namedDefinition.getKey());
/*     */       }
/*     */     } 
/* 269 */     return matchedNames;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isCandidate(ConfigurableListableBeanFactory beanFactory, String name, BeanDefinition definition, Set<String> ignoredBeans) {
/* 274 */     if (ignoredBeans.contains(name)) {
/* 275 */       return false;
/*     */     }
/* 277 */     if (definition == null || (definition.isAutowireCandidate() && isDefaultCandidate(definition))) {
/* 278 */       return true;
/*     */     }
/* 280 */     if (ScopedProxyUtils.isScopedTarget(name)) {
/*     */       
/*     */       try {
/* 283 */         BeanDefinition originalDefinition = beanFactory.getBeanDefinition(ScopedProxyUtils.getOriginalBeanName(name));
/* 284 */         if (originalDefinition.isAutowireCandidate() && isDefaultCandidate(originalDefinition)) {
/* 285 */           return true;
/*     */         }
/*     */       }
/* 288 */       catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     }
/*     */     
/* 291 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isDefaultCandidate(BeanDefinition definition) {
/* 295 */     if (definition instanceof AbstractBeanDefinition) { AbstractBeanDefinition abstractBeanDefinition = (AbstractBeanDefinition)definition;
/* 296 */       return abstractBeanDefinition.isDefaultCandidate(); }
/*     */     
/* 298 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getNamesOfBeansIgnoredByType(ListableBeanFactory beanFactory, boolean considerHierarchy, Set<ResolvableType> ignoredTypes, Set<ResolvableType> parameterizedContainers) {
/* 303 */     Set<String> result = null;
/* 304 */     for (ResolvableType ignoredType : ignoredTypes) {
/*     */ 
/*     */       
/* 307 */       Collection<String> ignoredNames = getBeanDefinitionsForType(beanFactory, considerHierarchy, ignoredType, parameterizedContainers).keySet();
/* 308 */       result = addAll(result, ignoredNames);
/*     */     } 
/* 310 */     return (result != null) ? result : Collections.<String>emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, BeanDefinition> getBeanDefinitionsForType(ListableBeanFactory beanFactory, boolean considerHierarchy, ResolvableType type, Set<ResolvableType> parameterizedContainers) {
/* 315 */     Map<String, BeanDefinition> result = collectBeanDefinitionsForType(beanFactory, considerHierarchy, type, parameterizedContainers, (Map<String, BeanDefinition>)null);
/*     */     
/* 317 */     return (result != null) ? result : Collections.<String, BeanDefinition>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, BeanDefinition> collectBeanDefinitionsForType(ListableBeanFactory beanFactory, boolean considerHierarchy, ResolvableType type, Set<ResolvableType> parameterizedContainers, Map<String, BeanDefinition> result) {
/* 323 */     result = putAll(result, beanFactory.getBeanNamesForType(type, true, false), beanFactory);
/* 324 */     for (ResolvableType parameterizedContainer : parameterizedContainers) {
/* 325 */       ResolvableType generic = ResolvableType.forClassWithGenerics(parameterizedContainer.resolve(), new ResolvableType[] { type });
/* 326 */       result = putAll(result, beanFactory.getBeanNamesForType(generic, true, false), beanFactory);
/*     */     } 
/* 328 */     if (considerHierarchy && beanFactory instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hierarchicalBeanFactory = (HierarchicalBeanFactory)beanFactory;
/* 329 */       BeanFactory parent = hierarchicalBeanFactory.getParentBeanFactory();
/* 330 */       if (parent instanceof ListableBeanFactory) { ListableBeanFactory listableBeanFactory = (ListableBeanFactory)parent;
/* 331 */         result = collectBeanDefinitionsForType(listableBeanFactory, considerHierarchy, type, parameterizedContainers, result); }
/*     */        }
/*     */ 
/*     */     
/* 335 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, BeanDefinition> getBeanDefinitionsForAnnotation(ClassLoader classLoader, ConfigurableListableBeanFactory beanFactory, String type, boolean considerHierarchy) throws LinkageError {
/* 340 */     Map<String, BeanDefinition> result = null;
/*     */     try {
/* 342 */       result = collectBeanDefinitionsForAnnotation((ListableBeanFactory)beanFactory, resolveAnnotationType(classLoader, type), considerHierarchy, result);
/*     */     
/*     */     }
/* 345 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 348 */     return (result != null) ? result : Collections.<String, BeanDefinition>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<? extends Annotation> resolveAnnotationType(ClassLoader classLoader, String type) throws ClassNotFoundException {
/* 354 */     return (Class)resolve(type, classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, BeanDefinition> collectBeanDefinitionsForAnnotation(ListableBeanFactory beanFactory, Class<? extends Annotation> annotationType, boolean considerHierarchy, Map<String, BeanDefinition> result) {
/* 359 */     result = putAll(result, getBeanNamesForAnnotation(beanFactory, annotationType), beanFactory);
/* 360 */     if (considerHierarchy) {
/* 361 */       BeanFactory parent = ((HierarchicalBeanFactory)beanFactory).getParentBeanFactory();
/* 362 */       if (parent instanceof ListableBeanFactory) { ListableBeanFactory listableBeanFactory = (ListableBeanFactory)parent;
/* 363 */         result = collectBeanDefinitionsForAnnotation(listableBeanFactory, annotationType, considerHierarchy, result); }
/*     */     
/*     */     } 
/*     */     
/* 367 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private String[] getBeanNamesForAnnotation(ListableBeanFactory beanFactory, Class<? extends Annotation> annotationType) {
/* 372 */     Set<String> foundBeanNames = new LinkedHashSet<>();
/* 373 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 374 */       if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory configurableListableBeanFactory = (ConfigurableListableBeanFactory)beanFactory;
/* 375 */         BeanDefinition beanDefinition = configurableListableBeanFactory.getBeanDefinition(beanName);
/* 376 */         if (beanDefinition != null && beanDefinition.isAbstract()) {
/*     */           continue;
/*     */         } }
/*     */       
/* 380 */       if (beanFactory.findAnnotationOnBean(beanName, annotationType, false) != null)
/* 381 */         foundBeanNames.add(beanName); 
/*     */       continue;
/*     */     } 
/* 384 */     if (beanFactory instanceof SingletonBeanRegistry) { SingletonBeanRegistry singletonBeanRegistry = (SingletonBeanRegistry)beanFactory;
/* 385 */       for (String beanName : singletonBeanRegistry.getSingletonNames()) {
/* 386 */         if (beanFactory.findAnnotationOnBean(beanName, annotationType) != null) {
/* 387 */           foundBeanNames.add(beanName);
/*     */         }
/*     */       }  }
/*     */     
/* 391 */     return (String[])foundBeanNames.toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsBean(ConfigurableListableBeanFactory beanFactory, String beanName, boolean considerHierarchy) {
/* 396 */     if (considerHierarchy) {
/* 397 */       return beanFactory.containsBean(beanName);
/*     */     }
/* 399 */     return beanFactory.containsLocalBean(beanName);
/*     */   }
/*     */   
/*     */   private String createOnBeanNoMatchReason(MatchResult matchResult) {
/* 403 */     StringBuilder reason = new StringBuilder();
/* 404 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedAnnotations(), "annotated with");
/* 405 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedTypes(), "of type");
/* 406 */     appendMessageForNoMatches(reason, matchResult.getUnmatchedNames(), "named");
/* 407 */     return reason.toString();
/*     */   }
/*     */   
/*     */   private void appendMessageForNoMatches(StringBuilder reason, Collection<String> unmatched, String description) {
/* 411 */     if (!unmatched.isEmpty()) {
/* 412 */       if (!reason.isEmpty()) {
/* 413 */         reason.append(" and ");
/*     */       }
/* 415 */       reason.append("did not find any beans ");
/* 416 */       reason.append(description);
/* 417 */       reason.append(" ");
/* 418 */       reason.append(StringUtils.collectionToDelimitedString(unmatched, ", "));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String createOnMissingBeanNoMatchReason(MatchResult matchResult) {
/* 423 */     StringBuilder reason = new StringBuilder();
/* 424 */     appendMessageForMatches(reason, matchResult.getMatchedAnnotations(), "annotated with");
/* 425 */     appendMessageForMatches(reason, matchResult.getMatchedTypes(), "of type");
/* 426 */     if (!matchResult.getMatchedNames().isEmpty()) {
/* 427 */       if (!reason.isEmpty()) {
/* 428 */         reason.append(" and ");
/*     */       }
/* 430 */       reason.append("found beans named ");
/* 431 */       reason.append(StringUtils.collectionToDelimitedString(matchResult.getMatchedNames(), ", "));
/*     */     } 
/* 433 */     return reason.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendMessageForMatches(StringBuilder reason, Map<String, Collection<String>> matches, String description) {
/* 438 */     if (!matches.isEmpty()) {
/* 439 */       matches.forEach((key, value) -> {
/*     */             if (!reason.isEmpty()) {
/*     */               reason.append(" and ");
/*     */             }
/*     */             reason.append("found beans ");
/*     */             reason.append(description);
/*     */             reason.append(" '");
/*     */             reason.append(key);
/*     */             reason.append("' ");
/*     */             reason.append(StringUtils.collectionToDelimitedString(value, ", "));
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, BeanDefinition> getBeanDefinitions(ConfigurableListableBeanFactory beanFactory, Set<String> beanNames, boolean considerHierarchy) {
/* 455 */     Map<String, BeanDefinition> definitions = new HashMap<>(beanNames.size());
/* 456 */     for (String beanName : beanNames) {
/* 457 */       BeanDefinition beanDefinition = findBeanDefinition(beanFactory, beanName, considerHierarchy);
/* 458 */       definitions.put(beanName, beanDefinition);
/*     */     } 
/* 460 */     return definitions;
/*     */   }
/*     */   
/*     */   private List<String> getPrimaryBeans(Map<String, BeanDefinition> beanDefinitions) {
/* 464 */     return getMatchingBeans(beanDefinitions, BeanDefinition::isPrimary);
/*     */   }
/*     */   
/*     */   private List<String> getNonFallbackBeans(Map<String, BeanDefinition> beanDefinitions) {
/* 468 */     return getMatchingBeans(beanDefinitions, Predicate.not(BeanDefinition::isFallback));
/*     */   }
/*     */   
/*     */   private List<String> getMatchingBeans(Map<String, BeanDefinition> beanDefinitions, Predicate<BeanDefinition> test) {
/* 472 */     List<String> matches = new ArrayList<>();
/* 473 */     for (Map.Entry<String, BeanDefinition> namedBeanDefinition : beanDefinitions.entrySet()) {
/* 474 */       if (test.test(namedBeanDefinition.getValue())) {
/* 475 */         matches.add(namedBeanDefinition.getKey());
/*     */       }
/*     */     } 
/* 478 */     return matches;
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition findBeanDefinition(ConfigurableListableBeanFactory beanFactory, String beanName, boolean considerHierarchy) {
/* 483 */     if (beanFactory.containsBeanDefinition(beanName)) {
/* 484 */       return beanFactory.getBeanDefinition(beanName);
/*     */     }
/* 486 */     if (considerHierarchy) {
/* 487 */       BeanFactory beanFactory1 = beanFactory.getParentBeanFactory(); if (beanFactory1 instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory listableBeanFactory = (ConfigurableListableBeanFactory)beanFactory1;
/* 488 */         return findBeanDefinition(listableBeanFactory, beanName, considerHierarchy); }
/*     */     
/* 490 */     }  return null;
/*     */   }
/*     */   
/*     */   private static Set<String> addAll(Set<String> result, Collection<String> additional) {
/* 494 */     if (CollectionUtils.isEmpty(additional)) {
/* 495 */       return result;
/*     */     }
/* 497 */     result = (result != null) ? result : new LinkedHashSet<>();
/* 498 */     result.addAll(additional);
/* 499 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<String, BeanDefinition> putAll(Map<String, BeanDefinition> result, String[] beanNames, ListableBeanFactory beanFactory) {
/* 504 */     if (ObjectUtils.isEmpty((Object[])beanNames)) {
/* 505 */       return result;
/*     */     }
/* 507 */     if (result == null) {
/* 508 */       result = new LinkedHashMap<>();
/*     */     }
/* 510 */     for (String beanName : beanNames) {
/* 511 */       if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory;
/* 512 */         result.put(beanName, getBeanDefinition(beanName, clbf)); }
/*     */       else
/*     */       
/* 515 */       { result.put(beanName, null); }
/*     */     
/*     */     } 
/* 518 */     return result;
/*     */   }
/*     */   
/*     */   private static BeanDefinition getBeanDefinition(String beanName, ConfigurableListableBeanFactory beanFactory) {
/*     */     try {
/* 523 */       return beanFactory.getBeanDefinition(beanName);
/*     */     }
/* 525 */     catch (NoSuchBeanDefinitionException ex) {
/* 526 */       if (BeanFactoryUtils.isFactoryDereference(beanName)) {
/* 527 */         return getBeanDefinition(BeanFactoryUtils.transformedBeanName(beanName), beanFactory);
/*     */       }
/*     */       
/* 530 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Spec<A extends Annotation>
/*     */   {
/*     */     private final ConditionContext context;
/*     */ 
/*     */     
/*     */     private final Class<? extends Annotation> annotationType;
/*     */ 
/*     */     
/*     */     private final Set<String> names;
/*     */     
/*     */     private final Set<ResolvableType> types;
/*     */     
/*     */     private final Set<String> annotations;
/*     */     
/*     */     private final Set<ResolvableType> ignoredTypes;
/*     */     
/*     */     private final Set<ResolvableType> parameterizedContainers;
/*     */     
/*     */     private final SearchStrategy strategy;
/*     */ 
/*     */     
/*     */     Spec(ConditionContext context, AnnotatedTypeMetadata metadata, MergedAnnotations annotations, Class<A> annotationType) {
/* 558 */       MultiValueMap<String, Object> attributes = (MultiValueMap<String, Object>)annotations.stream(annotationType).filter(MergedAnnotationPredicates.unique(MergedAnnotation::getMetaTypes)).collect(MergedAnnotationCollectors.toMultiValueMap(new MergedAnnotation.Adapt[] { MergedAnnotation.Adapt.CLASS_TO_STRING }));
/* 559 */       MergedAnnotation<A> annotation = annotations.get(annotationType);
/* 560 */       this.context = context;
/* 561 */       this.annotationType = annotationType;
/* 562 */       this.names = extract(attributes, new String[] { "name" });
/* 563 */       this.annotations = extract(attributes, new String[] { "annotation" });
/* 564 */       this.ignoredTypes = resolveWhenPossible(extract(attributes, new String[] { "ignored", "ignoredType" }));
/* 565 */       this.parameterizedContainers = resolveWhenPossible(extract(attributes, new String[] { "parameterizedContainer" }));
/* 566 */       this.strategy = annotation.getValue("search", SearchStrategy.class).orElse(null);
/* 567 */       Set<ResolvableType> types = resolveWhenPossible(extractTypes(attributes));
/* 568 */       OnBeanCondition.BeanTypeDeductionException deductionException = null;
/* 569 */       if (types.isEmpty() && this.names.isEmpty() && this.annotations.isEmpty()) {
/*     */         try {
/* 571 */           types = deducedBeanType(context, metadata);
/*     */         }
/* 573 */         catch (BeanTypeDeductionException ex) {
/* 574 */           deductionException = ex;
/*     */         } 
/*     */       }
/* 577 */       this.types = types;
/* 578 */       validate(deductionException);
/*     */     }
/*     */     
/*     */     protected Set<String> extractTypes(MultiValueMap<String, Object> attributes) {
/* 582 */       return extract(attributes, new String[] { "value", "type" });
/*     */     }
/*     */     
/*     */     private Set<String> extract(MultiValueMap<String, Object> attributes, String... attributeNames) {
/* 586 */       if (attributes.isEmpty()) {
/* 587 */         return Collections.emptySet();
/*     */       }
/* 589 */       Set<String> result = new LinkedHashSet<>();
/* 590 */       for (String attributeName : attributeNames) {
/* 591 */         List<Object> values = (List<Object>)attributes.getOrDefault(attributeName, Collections.emptyList());
/* 592 */         for (Object value : values) {
/* 593 */           if (value instanceof String[]) { String[] stringArray = (String[])value;
/* 594 */             merge(result, stringArray); continue; }
/*     */           
/* 596 */           if (value instanceof String) { String string = (String)value;
/* 597 */             merge(result, new String[] { string }); }
/*     */         
/*     */         } 
/*     */       } 
/* 601 */       return result.isEmpty() ? Collections.<String>emptySet() : result;
/*     */     }
/*     */     
/*     */     private void merge(Set<String> result, String... additional) {
/* 605 */       Collections.addAll(result, additional);
/*     */     }
/*     */     
/*     */     private Set<ResolvableType> resolveWhenPossible(Set<String> classNames) {
/* 609 */       if (classNames.isEmpty()) {
/* 610 */         return Collections.emptySet();
/*     */       }
/* 612 */       Set<ResolvableType> resolved = new LinkedHashSet<>(classNames.size());
/* 613 */       for (String className : classNames) {
/*     */         try {
/* 615 */           Class<?> type = FilteringSpringBootCondition.resolve(className, this.context.getClassLoader());
/* 616 */           resolved.add(ResolvableType.forRawClass(type));
/*     */         }
/* 618 */         catch (ClassNotFoundException|NoClassDefFoundError ex) {
/* 619 */           resolved.add(ResolvableType.NONE);
/*     */         } 
/*     */       } 
/* 622 */       return resolved;
/*     */     }
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 626 */       if (!hasAtLeastOneElement((Set<?>[])new Set[] { getTypes(), getNames(), getAnnotations() })) {
/* 627 */         String message = getAnnotationName() + " did not specify a bean using type, name or annotation";
/* 628 */         if (ex == null) {
/* 629 */           throw new IllegalStateException(message);
/*     */         }
/* 631 */         throw new IllegalStateException(message + " and the attempt to deduce the bean's type failed", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean hasAtLeastOneElement(Set<?>... sets) {
/* 636 */       for (Set<?> set : sets) {
/* 637 */         if (!set.isEmpty()) {
/* 638 */           return true;
/*     */         }
/*     */       } 
/* 641 */       return false;
/*     */     }
/*     */     
/*     */     protected final String getAnnotationName() {
/* 645 */       return "@" + ClassUtils.getShortName(this.annotationType);
/*     */     }
/*     */     
/*     */     private Set<ResolvableType> deducedBeanType(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 649 */       if (metadata instanceof MethodMetadata && metadata.isAnnotated(Bean.class.getName())) {
/* 650 */         return deducedBeanTypeForBeanMethod(context, (MethodMetadata)metadata);
/*     */       }
/* 652 */       return Collections.emptySet();
/*     */     }
/*     */     
/*     */     private Set<ResolvableType> deducedBeanTypeForBeanMethod(ConditionContext context, MethodMetadata metadata) {
/*     */       try {
/* 657 */         return Set.of(getReturnType(context, metadata));
/*     */       }
/* 659 */       catch (Throwable ex) {
/* 660 */         throw new OnBeanCondition.BeanTypeDeductionException(metadata.getDeclaringClassName(), metadata.getMethodName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private ResolvableType getReturnType(ConditionContext context, MethodMetadata metadata) throws ClassNotFoundException, LinkageError {
/* 667 */       ClassLoader classLoader = context.getClassLoader();
/* 668 */       ResolvableType returnType = getMethodReturnType(metadata, classLoader);
/* 669 */       if (isParameterizedContainer(returnType.resolve())) {
/* 670 */         returnType = returnType.getGeneric(new int[0]);
/*     */       }
/* 672 */       return returnType;
/*     */     }
/*     */     
/*     */     private boolean isParameterizedContainer(Class<?> type) {
/* 676 */       return (type != null && this.parameterizedContainers.stream()
/* 677 */         .map(ResolvableType::resolve)
/* 678 */         .anyMatch(container -> (container != null && container.isAssignableFrom(type))));
/*     */     }
/*     */ 
/*     */     
/*     */     private ResolvableType getMethodReturnType(MethodMetadata metadata, ClassLoader classLoader) throws ClassNotFoundException, LinkageError {
/* 683 */       Class<?> declaringClass = FilteringSpringBootCondition.resolve(metadata.getDeclaringClassName(), classLoader);
/* 684 */       Method beanMethod = findBeanMethod(declaringClass, metadata.getMethodName());
/* 685 */       return ResolvableType.forMethodReturnType(beanMethod);
/*     */     }
/*     */     
/*     */     private Method findBeanMethod(Class<?> declaringClass, String methodName) {
/* 689 */       Method method = ReflectionUtils.findMethod(declaringClass, methodName);
/* 690 */       if (isBeanMethod(method)) {
/* 691 */         return method;
/*     */       }
/* 693 */       Method[] candidates = ReflectionUtils.getAllDeclaredMethods(declaringClass);
/* 694 */       for (Method candidate : candidates) {
/* 695 */         if (candidate.getName().equals(methodName) && isBeanMethod(candidate)) {
/* 696 */           return candidate;
/*     */         }
/*     */       } 
/* 699 */       throw new IllegalStateException("Unable to find bean method " + methodName);
/*     */     }
/*     */     
/*     */     private boolean isBeanMethod(Method method) {
/* 703 */       return (method != null && MergedAnnotations.from(method, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/* 704 */         .isPresent(Bean.class));
/*     */     }
/*     */     
/*     */     private SearchStrategy getStrategy() {
/* 708 */       return (this.strategy != null) ? this.strategy : SearchStrategy.ALL;
/*     */     }
/*     */     
/*     */     Set<ResolvableType> getTypes() {
/* 712 */       return this.types;
/*     */     }
/*     */     
/*     */     private ConditionContext getContext() {
/* 716 */       return this.context;
/*     */     }
/*     */     
/*     */     private Set<String> getNames() {
/* 720 */       return this.names;
/*     */     }
/*     */     
/*     */     private Set<String> getAnnotations() {
/* 724 */       return this.annotations;
/*     */     }
/*     */     
/*     */     private Set<ResolvableType> getIgnoredTypes() {
/* 728 */       return this.ignoredTypes;
/*     */     }
/*     */     
/*     */     private Set<ResolvableType> getParameterizedContainers() {
/* 732 */       return this.parameterizedContainers;
/*     */     }
/*     */     
/*     */     private ConditionMessage.Builder message() {
/* 736 */       return ConditionMessage.forCondition(this.annotationType, new Object[] { this });
/*     */     }
/*     */     
/*     */     private ConditionMessage.Builder message(ConditionMessage message) {
/* 740 */       return message.andCondition(this.annotationType, new Object[] { this });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 745 */       boolean hasNames = !this.names.isEmpty();
/* 746 */       boolean hasTypes = !this.types.isEmpty();
/* 747 */       boolean hasIgnoredTypes = !this.ignoredTypes.isEmpty();
/* 748 */       StringBuilder string = new StringBuilder();
/* 749 */       string.append("(");
/* 750 */       if (hasNames) {
/* 751 */         string.append("names: ");
/* 752 */         string.append(StringUtils.collectionToCommaDelimitedString(this.names));
/* 753 */         string.append(hasTypes ? " " : "; ");
/*     */       } 
/* 755 */       if (hasTypes) {
/* 756 */         string.append("types: ");
/* 757 */         string.append(StringUtils.collectionToCommaDelimitedString(this.types));
/* 758 */         string.append(hasIgnoredTypes ? " " : "; ");
/*     */       } 
/* 760 */       if (hasIgnoredTypes) {
/* 761 */         string.append("ignored: ");
/* 762 */         string.append(StringUtils.collectionToCommaDelimitedString(this.ignoredTypes));
/* 763 */         string.append("; ");
/*     */       } 
/* 765 */       string.append("SearchStrategy: ");
/* 766 */       string.append(this.strategy.toString().toLowerCase(Locale.ENGLISH));
/* 767 */       string.append(")");
/* 768 */       return string.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SingleCandidateSpec
/*     */     extends Spec<ConditionalOnSingleCandidate>
/*     */   {
/* 779 */     private static final Collection<String> FILTERED_TYPES = Arrays.asList(new String[] { "", Object.class.getName() });
/*     */     
/*     */     SingleCandidateSpec(ConditionContext context, AnnotatedTypeMetadata metadata, MergedAnnotations annotations) {
/* 782 */       super(context, metadata, annotations, ConditionalOnSingleCandidate.class);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Set<String> extractTypes(MultiValueMap<String, Object> attributes) {
/* 787 */       Set<String> types = super.extractTypes(attributes);
/* 788 */       types.removeAll(FILTERED_TYPES);
/* 789 */       return types;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void validate(OnBeanCondition.BeanTypeDeductionException ex) {
/* 794 */       Assert.isTrue((getTypes().size() == 1), () -> getAnnotationName() + " annotations must specify only one type (got " + getAnnotationName() + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MatchResult
/*     */   {
/*     */     private final Map<String, Collection<String>> matchedAnnotations;
/*     */     private final List<String> matchedNames;
/*     */     private final Map<String, Collection<String>> matchedTypes;
/*     */     
/*     */     private MatchResult() {
/* 806 */       this.matchedAnnotations = new HashMap<>();
/*     */       
/* 808 */       this.matchedNames = new ArrayList<>();
/*     */       
/* 810 */       this.matchedTypes = new HashMap<>();
/*     */       
/* 812 */       this.unmatchedAnnotations = new ArrayList<>();
/*     */       
/* 814 */       this.unmatchedNames = new ArrayList<>();
/*     */       
/* 816 */       this.unmatchedTypes = new ArrayList<>();
/*     */       
/* 818 */       this.namesOfAllMatches = new HashSet<>();
/*     */     } private final List<String> unmatchedAnnotations; private final List<String> unmatchedNames; private final List<String> unmatchedTypes; private final Set<String> namesOfAllMatches;
/*     */     private void recordMatchedName(String name) {
/* 821 */       this.matchedNames.add(name);
/* 822 */       this.namesOfAllMatches.add(name);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedName(String name) {
/* 826 */       this.unmatchedNames.add(name);
/*     */     }
/*     */     
/*     */     private void recordMatchedAnnotation(String annotation, Collection<String> matchingNames) {
/* 830 */       this.matchedAnnotations.put(annotation, matchingNames);
/* 831 */       this.namesOfAllMatches.addAll(matchingNames);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedAnnotation(String annotation) {
/* 835 */       this.unmatchedAnnotations.add(annotation);
/*     */     }
/*     */     
/*     */     private void recordMatchedType(ResolvableType type, Collection<String> matchingNames) {
/* 839 */       this.matchedTypes.put(type.toString(), matchingNames);
/* 840 */       this.namesOfAllMatches.addAll(matchingNames);
/*     */     }
/*     */     
/*     */     private void recordUnmatchedType(ResolvableType type) {
/* 844 */       this.unmatchedTypes.add(type.toString());
/*     */     }
/*     */     
/*     */     boolean isAllMatched() {
/* 848 */       return (this.unmatchedAnnotations.isEmpty() && this.unmatchedNames.isEmpty() && this.unmatchedTypes
/* 849 */         .isEmpty());
/*     */     }
/*     */     
/*     */     boolean isAnyMatched() {
/* 853 */       return (!this.matchedAnnotations.isEmpty() || !this.matchedNames.isEmpty() || 
/* 854 */         !this.matchedTypes.isEmpty());
/*     */     }
/*     */     
/*     */     Map<String, Collection<String>> getMatchedAnnotations() {
/* 858 */       return this.matchedAnnotations;
/*     */     }
/*     */     
/*     */     List<String> getMatchedNames() {
/* 862 */       return this.matchedNames;
/*     */     }
/*     */     
/*     */     Map<String, Collection<String>> getMatchedTypes() {
/* 866 */       return this.matchedTypes;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedAnnotations() {
/* 870 */       return this.unmatchedAnnotations;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedNames() {
/* 874 */       return this.unmatchedNames;
/*     */     }
/*     */     
/*     */     List<String> getUnmatchedTypes() {
/* 878 */       return this.unmatchedTypes;
/*     */     }
/*     */     
/*     */     Set<String> getNamesOfAllMatches() {
/* 882 */       return this.namesOfAllMatches;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BeanTypeDeductionException
/*     */     extends RuntimeException
/*     */   {
/*     */     private BeanTypeDeductionException(String className, String beanMethodName, Throwable cause) {
/* 893 */       super("Failed to deduce bean type for " + className + "." + beanMethodName, cause);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnBeanCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */