/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483648)
/*     */ class OnClassCondition
/*     */   extends FilteringSpringBootCondition
/*     */ {
/*     */   protected final ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  52 */     if (autoConfigurationClasses.length > 1 && Runtime.getRuntime().availableProcessors() > 1) {
/*  53 */       return resolveOutcomesThreaded(autoConfigurationClasses, autoConfigurationMetadata);
/*     */     }
/*     */ 
/*     */     
/*  57 */     OutcomesResolver outcomesResolver = new StandardOutcomesResolver(autoConfigurationClasses, 0, autoConfigurationClasses.length, autoConfigurationMetadata, getBeanClassLoader());
/*  58 */     return outcomesResolver.resolveOutcomes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConditionOutcome[] resolveOutcomesThreaded(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  64 */     int split = autoConfigurationClasses.length / 2;
/*  65 */     OutcomesResolver firstHalfResolver = createOutcomesResolver(autoConfigurationClasses, 0, split, autoConfigurationMetadata);
/*     */ 
/*     */     
/*  68 */     OutcomesResolver secondHalfResolver = new StandardOutcomesResolver(autoConfigurationClasses, split, autoConfigurationClasses.length, autoConfigurationMetadata, getBeanClassLoader());
/*  69 */     ConditionOutcome[] secondHalf = secondHalfResolver.resolveOutcomes();
/*  70 */     ConditionOutcome[] firstHalf = firstHalfResolver.resolveOutcomes();
/*  71 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  72 */     System.arraycopy(firstHalf, 0, outcomes, 0, firstHalf.length);
/*  73 */     System.arraycopy(secondHalf, 0, outcomes, split, secondHalf.length);
/*  74 */     return outcomes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private OutcomesResolver createOutcomesResolver(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  80 */     OutcomesResolver outcomesResolver = new StandardOutcomesResolver(autoConfigurationClasses, start, end, autoConfigurationMetadata, getBeanClassLoader());
/*  81 */     return new ThreadedOutcomesResolver(outcomesResolver);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  86 */     ClassLoader classLoader = context.getClassLoader();
/*  87 */     ConditionMessage matchMessage = ConditionMessage.empty();
/*  88 */     List<String> onClasses = getCandidates(metadata, ConditionalOnClass.class);
/*  89 */     if (onClasses != null) {
/*  90 */       List<String> missing = filter(onClasses, FilteringSpringBootCondition.ClassNameFilter.MISSING, classLoader);
/*  91 */       if (!missing.isEmpty()) {
/*  92 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnClass.class, new Object[0])
/*  93 */             .didNotFind("required class", "required classes")
/*  94 */             .items(ConditionMessage.Style.QUOTE, missing));
/*     */       }
/*     */ 
/*     */       
/*  98 */       matchMessage = matchMessage.andCondition((Class)ConditionalOnClass.class, new Object[0]).found("required class", "required classes").items(ConditionMessage.Style.QUOTE, filter(onClasses, FilteringSpringBootCondition.ClassNameFilter.PRESENT, classLoader));
/*     */     } 
/* 100 */     List<String> onMissingClasses = getCandidates(metadata, ConditionalOnMissingClass.class);
/* 101 */     if (onMissingClasses != null) {
/* 102 */       List<String> present = filter(onMissingClasses, FilteringSpringBootCondition.ClassNameFilter.PRESENT, classLoader);
/* 103 */       if (!present.isEmpty()) {
/* 104 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnMissingClass.class, new Object[0])
/* 105 */             .found("unwanted class", "unwanted classes")
/* 106 */             .items(ConditionMessage.Style.QUOTE, present));
/*     */       }
/*     */ 
/*     */       
/* 110 */       matchMessage = matchMessage.andCondition((Class)ConditionalOnMissingClass.class, new Object[0]).didNotFind("unwanted class", "unwanted classes").items(ConditionMessage.Style.QUOTE, filter(onMissingClasses, FilteringSpringBootCondition.ClassNameFilter.MISSING, classLoader));
/*     */     } 
/* 112 */     return ConditionOutcome.match(matchMessage);
/*     */   }
/*     */   
/*     */   private List<String> getCandidates(AnnotatedTypeMetadata metadata, Class<?> annotationType) {
/* 116 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(annotationType.getName(), true);
/* 117 */     if (attributes == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     List<String> candidates = new ArrayList<>();
/* 121 */     addAll(candidates, (List<Object>)attributes.get("value"));
/* 122 */     addAll(candidates, (List<Object>)attributes.get("name"));
/* 123 */     return candidates;
/*     */   }
/*     */   
/*     */   private void addAll(List<String> list, List<Object> itemsToAdd) {
/* 127 */     if (itemsToAdd != null) {
/* 128 */       for (Object item : itemsToAdd) {
/* 129 */         Collections.addAll(list, (String[])item);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ThreadedOutcomesResolver
/*     */     implements OutcomesResolver
/*     */   {
/*     */     private final Thread thread;
/*     */ 
/*     */     
/*     */     private volatile ConditionOutcome[] outcomes;
/*     */ 
/*     */     
/*     */     private volatile Throwable failure;
/*     */ 
/*     */     
/*     */     private ThreadedOutcomesResolver(OnClassCondition.OutcomesResolver outcomesResolver) {
/* 149 */       this.thread = new Thread(() -> {
/*     */             
/*     */             try {
/*     */               this.outcomes = outcomesResolver.resolveOutcomes();
/* 153 */             } catch (Throwable ex) {
/*     */               this.failure = ex;
/*     */             } 
/*     */           });
/* 157 */       this.thread.start();
/*     */     }
/*     */ 
/*     */     
/*     */     public ConditionOutcome[] resolveOutcomes() {
/*     */       try {
/* 163 */         this.thread.join();
/*     */       }
/* 165 */       catch (InterruptedException ex) {
/* 166 */         Thread.currentThread().interrupt();
/*     */       } 
/* 168 */       Throwable failure = this.failure;
/* 169 */       if (failure != null) {
/* 170 */         ReflectionUtils.rethrowRuntimeException(failure);
/*     */       }
/* 172 */       ConditionOutcome[] outcomes = this.outcomes;
/* 173 */       return (outcomes != null) ? outcomes : new ConditionOutcome[0];
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface OutcomesResolver
/*     */   {
/*     */     ConditionOutcome[] resolveOutcomes();
/*     */   }
/*     */   
/*     */   private static final class StandardOutcomesResolver
/*     */     implements OutcomesResolver
/*     */   {
/*     */     private final String[] autoConfigurationClasses;
/*     */     private final int start;
/*     */     private final int end;
/*     */     private final AutoConfigurationMetadata autoConfigurationMetadata;
/*     */     private final ClassLoader beanClassLoader;
/*     */     
/*     */     private StandardOutcomesResolver(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata, ClassLoader beanClassLoader) {
/* 192 */       this.autoConfigurationClasses = autoConfigurationClasses;
/* 193 */       this.start = start;
/* 194 */       this.end = end;
/* 195 */       this.autoConfigurationMetadata = autoConfigurationMetadata;
/* 196 */       this.beanClassLoader = beanClassLoader;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConditionOutcome[] resolveOutcomes() {
/* 201 */       return getOutcomes(this.autoConfigurationClasses, this.start, this.end, this.autoConfigurationMetadata);
/*     */     }
/*     */ 
/*     */     
/*     */     private ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata) {
/* 206 */       ConditionOutcome[] outcomes = new ConditionOutcome[end - start];
/* 207 */       for (int i = start; i < end; i++) {
/* 208 */         String autoConfigurationClass = autoConfigurationClasses[i];
/* 209 */         if (autoConfigurationClass != null) {
/* 210 */           String candidates = autoConfigurationMetadata.get(autoConfigurationClass, "ConditionalOnClass");
/* 211 */           if (candidates != null) {
/* 212 */             outcomes[i - start] = getOutcome(candidates);
/*     */           }
/*     */         } 
/*     */       } 
/* 216 */       return outcomes;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getOutcome(String candidates) {
/*     */       try {
/* 221 */         if (!candidates.contains(",")) {
/* 222 */           return getOutcome(candidates, this.beanClassLoader);
/*     */         }
/* 224 */         for (String candidate : StringUtils.commaDelimitedListToStringArray(candidates)) {
/* 225 */           ConditionOutcome outcome = getOutcome(candidate, this.beanClassLoader);
/* 226 */           if (outcome != null) {
/* 227 */             return outcome;
/*     */           }
/*     */         }
/*     */       
/* 231 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 234 */       return null;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getOutcome(String className, ClassLoader classLoader) {
/* 238 */       if (FilteringSpringBootCondition.ClassNameFilter.MISSING.matches(className, classLoader)) {
/* 239 */         return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnClass.class, new Object[0])
/* 240 */             .didNotFind("required class")
/* 241 */             .items(ConditionMessage.Style.QUOTE, new Object[] { className }));
/*     */       }
/* 243 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnClassCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */