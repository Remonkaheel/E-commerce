/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SearchStrategy
/*    */ {
/* 30 */   CURRENT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   ANCESTORS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   ALL;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\SearchStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */