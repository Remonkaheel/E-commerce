/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MemberOutcomes
/*     */ {
/*     */   private final ConditionContext context;
/*     */   private final AnnotationMetadata metadata;
/*     */   private final List<ConditionOutcome> outcomes;
/*     */   
/*     */   MemberOutcomes(ConditionContext context, AnnotationMetadata metadata, List<Condition> conditions) {
/* 185 */     this.context = context;
/* 186 */     this.metadata = metadata;
/* 187 */     this.outcomes = new ArrayList<>(conditions.size());
/* 188 */     for (Condition condition : conditions) {
/* 189 */       this.outcomes.add(getConditionOutcome(metadata, condition));
/*     */     }
/*     */   }
/*     */   
/*     */   private ConditionOutcome getConditionOutcome(AnnotationMetadata metadata, Condition condition) {
/* 194 */     if (condition instanceof SpringBootCondition) { SpringBootCondition springBootCondition = (SpringBootCondition)condition;
/* 195 */       return springBootCondition.getMatchOutcome(this.context, (AnnotatedTypeMetadata)metadata); }
/*     */     
/* 197 */     return new ConditionOutcome(condition.matches(this.context, (AnnotatedTypeMetadata)metadata), ConditionMessage.empty());
/*     */   }
/*     */ 
/*     */   
/*     */   ConditionOutcome getUltimateOutcome() {
/* 202 */     ConditionMessage.Builder message = ConditionMessage.forCondition("NestedCondition on " + ClassUtils.getShortName(this.metadata.getClassName()), new Object[0]);
/* 203 */     if (this.outcomes.size() == 1) {
/* 204 */       ConditionOutcome outcome = this.outcomes.get(0);
/* 205 */       return new ConditionOutcome(outcome.isMatch(), message.because(outcome.getMessage()));
/*     */     } 
/* 207 */     List<ConditionOutcome> match = new ArrayList<>();
/* 208 */     List<ConditionOutcome> nonMatch = new ArrayList<>();
/* 209 */     for (ConditionOutcome outcome : this.outcomes) {
/* 210 */       (outcome.isMatch() ? match : nonMatch).add(outcome);
/*     */     }
/* 212 */     if (nonMatch.isEmpty()) {
/* 213 */       return ConditionOutcome.match(message.found("matching nested conditions").items(match));
/*     */     }
/* 215 */     return ConditionOutcome.noMatch(message.found("non-matching nested conditions").items(nonMatch));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\AbstractNestedCondition$MemberOutcomes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */