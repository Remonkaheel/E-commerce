/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardOutcomesResolver
/*     */   implements OnClassCondition.OutcomesResolver
/*     */ {
/*     */   private final String[] autoConfigurationClasses;
/*     */   private final int start;
/*     */   private final int end;
/*     */   private final AutoConfigurationMetadata autoConfigurationMetadata;
/*     */   private final ClassLoader beanClassLoader;
/*     */   
/*     */   private StandardOutcomesResolver(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata, ClassLoader beanClassLoader) {
/* 192 */     this.autoConfigurationClasses = autoConfigurationClasses;
/* 193 */     this.start = start;
/* 194 */     this.end = end;
/* 195 */     this.autoConfigurationMetadata = autoConfigurationMetadata;
/* 196 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome[] resolveOutcomes() {
/* 201 */     return getOutcomes(this.autoConfigurationClasses, this.start, this.end, this.autoConfigurationMetadata);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, int start, int end, AutoConfigurationMetadata autoConfigurationMetadata) {
/* 206 */     ConditionOutcome[] outcomes = new ConditionOutcome[end - start];
/* 207 */     for (int i = start; i < end; i++) {
/* 208 */       String autoConfigurationClass = autoConfigurationClasses[i];
/* 209 */       if (autoConfigurationClass != null) {
/* 210 */         String candidates = autoConfigurationMetadata.get(autoConfigurationClass, "ConditionalOnClass");
/* 211 */         if (candidates != null) {
/* 212 */           outcomes[i - start] = getOutcome(candidates);
/*     */         }
/*     */       } 
/*     */     } 
/* 216 */     return outcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(String candidates) {
/*     */     try {
/* 221 */       if (!candidates.contains(",")) {
/* 222 */         return getOutcome(candidates, this.beanClassLoader);
/*     */       }
/* 224 */       for (String candidate : StringUtils.commaDelimitedListToStringArray(candidates)) {
/* 225 */         ConditionOutcome outcome = getOutcome(candidate, this.beanClassLoader);
/* 226 */         if (outcome != null) {
/* 227 */           return outcome;
/*     */         }
/*     */       }
/*     */     
/* 231 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(String className, ClassLoader classLoader) {
/* 238 */     if (FilteringSpringBootCondition.ClassNameFilter.MISSING.matches(className, classLoader)) {
/* 239 */       return ConditionOutcome.noMatch(ConditionMessage.forCondition((Class)ConditionalOnClass.class, new Object[0])
/* 240 */           .didNotFind("required class")
/* 241 */           .items(ConditionMessage.Style.QUOTE, new Object[] { className }));
/*     */     }
/* 243 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnClassCondition$StandardOutcomesResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */