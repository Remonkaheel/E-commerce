/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.thread.Threading;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnThreadingCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 37 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnThreading.class.getName());
/* 38 */     Threading threading = (Threading)attributes.get("value");
/* 39 */     return getMatchOutcome(context.getEnvironment(), threading);
/*    */   }
/*    */   
/*    */   private ConditionOutcome getMatchOutcome(Environment environment, Threading threading) {
/* 43 */     String name = threading.name();
/* 44 */     ConditionMessage.Builder message = ConditionMessage.forCondition((Class)ConditionalOnThreading.class, new Object[0]);
/* 45 */     if (threading.isActive(environment)) {
/* 46 */       return ConditionOutcome.match(message.foundExactly(name));
/*    */     }
/* 48 */     return ConditionOutcome.noMatch(message.didNotFind(name).atAll());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnThreadingCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */