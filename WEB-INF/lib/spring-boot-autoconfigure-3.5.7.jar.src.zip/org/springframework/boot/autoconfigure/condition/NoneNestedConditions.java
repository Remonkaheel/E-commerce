/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NoneNestedConditions
/*    */   extends AbstractNestedCondition
/*    */ {
/*    */   public NoneNestedConditions(ConfigurationCondition.ConfigurationPhase configurationPhase) {
/* 58 */     super(configurationPhase);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getFinalMatchOutcome(AbstractNestedCondition.MemberMatchOutcomes memberOutcomes) {
/* 63 */     boolean match = memberOutcomes.getMatches().isEmpty();
/* 64 */     List<ConditionMessage> messages = new ArrayList<>();
/* 65 */     messages.add(ConditionMessage.forCondition("NoneNestedConditions", new Object[0])
/* 66 */         .because("" + memberOutcomes.getMatches().size() + " matched " + memberOutcomes.getMatches().size() + " did not"));
/*    */     
/* 68 */     for (ConditionOutcome outcome : memberOutcomes.getAll()) {
/* 69 */       messages.add(outcome.getConditionMessage());
/*    */     }
/* 71 */     return new ConditionOutcome(match, ConditionMessage.of(messages));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\NoneNestedConditions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */