/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.lang.annotation.Documented;
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ import org.springframework.boot.system.JavaVersion;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Target({ElementType.TYPE, ElementType.METHOD})
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Documented
/*    */ @Conditional({OnJavaCondition.class})
/*    */ public @interface ConditionalOnJava
/*    */ {
/*    */   Range range() default Range.EQUAL_OR_NEWER;
/*    */   
/*    */   JavaVersion value();
/*    */   
/*    */   public enum Range
/*    */   {
/* 66 */     EQUAL_OR_NEWER,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     OLDER_THAN;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ConditionalOnJava.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */