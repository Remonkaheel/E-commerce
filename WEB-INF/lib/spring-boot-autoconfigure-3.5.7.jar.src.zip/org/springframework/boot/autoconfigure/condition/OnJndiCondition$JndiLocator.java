/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JndiLocator
/*     */   extends JndiLocatorSupport
/*     */ {
/*     */   private final String[] locations;
/*     */   
/*     */   public JndiLocator(String[] locations) {
/*  88 */     this.locations = locations;
/*     */   }
/*     */   
/*     */   public String lookupFirstLocation() {
/*  92 */     for (String location : this.locations) {
/*     */       try {
/*  94 */         lookup(location);
/*  95 */         return location;
/*     */       }
/*  97 */       catch (NamingException namingException) {}
/*     */     } 
/*     */ 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnJndiCondition$JndiLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */