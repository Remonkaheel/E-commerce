/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MemberConditions
/*     */ {
/*     */   private final ConditionContext context;
/*     */   private final MetadataReaderFactory readerFactory;
/*     */   private final Map<AnnotationMetadata, List<Condition>> memberConditions;
/*     */   
/*     */   MemberConditions(ConditionContext context, ConfigurationCondition.ConfigurationPhase phase, String className) {
/* 111 */     this.context = context;
/* 112 */     this.readerFactory = (MetadataReaderFactory)new SimpleMetadataReaderFactory(context.getResourceLoader());
/* 113 */     String[] members = getMetadata(className).getMemberClassNames();
/* 114 */     this.memberConditions = getMemberConditions(members, phase, className);
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<AnnotationMetadata, List<Condition>> getMemberConditions(String[] members, ConfigurationCondition.ConfigurationPhase phase, String className) {
/* 119 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 120 */     for (String member : members) {
/* 121 */       AnnotationMetadata metadata = getMetadata(member);
/* 122 */       for (String[] conditionClasses : getConditionClasses((AnnotatedTypeMetadata)metadata)) {
/* 123 */         for (String conditionClass : conditionClasses) {
/* 124 */           Condition condition = getCondition(conditionClass);
/* 125 */           validateMemberCondition(condition, phase, className);
/* 126 */           linkedMultiValueMap.add(metadata, condition);
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     return Collections.unmodifiableMap((Map<? extends AnnotationMetadata, ? extends List<Condition>>)linkedMultiValueMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateMemberCondition(Condition condition, ConfigurationCondition.ConfigurationPhase nestedPhase, String nestedClassName) {
/* 135 */     if (nestedPhase == ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION && condition instanceof ConfigurationCondition) {
/* 136 */       ConfigurationCondition configurationCondition = (ConfigurationCondition)condition;
/* 137 */       ConfigurationCondition.ConfigurationPhase memberPhase = configurationCondition.getConfigurationPhase();
/* 138 */       if (memberPhase == ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN) {
/* 139 */         throw new IllegalStateException("Nested condition " + nestedClassName + " uses a configuration phase that is inappropriate for " + 
/* 140 */             String.valueOf(condition.getClass()));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private AnnotationMetadata getMetadata(String className) {
/*     */     try {
/* 147 */       return this.readerFactory.getMetadataReader(className).getAnnotationMetadata();
/*     */     }
/* 149 */     catch (IOException ex) {
/* 150 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String[]> getConditionClasses(AnnotatedTypeMetadata metadata) {
/* 156 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(Conditional.class.getName(), true);
/*     */     
/* 158 */     Object values = (attributes != null) ? attributes.get("value") : null;
/* 159 */     return (values != null) ? (List<String[]>)values : (List)Collections.<String[]>emptyList();
/*     */   }
/*     */   
/*     */   private Condition getCondition(String conditionClassName) {
/* 163 */     Class<?> conditionClass = ClassUtils.resolveClassName(conditionClassName, this.context.getClassLoader());
/* 164 */     return (Condition)BeanUtils.instantiateClass(conditionClass);
/*     */   }
/*     */   
/*     */   List<ConditionOutcome> getMatchOutcomes() {
/* 168 */     List<ConditionOutcome> outcomes = new ArrayList<>();
/* 169 */     this.memberConditions.forEach((metadata, conditions) -> outcomes.add((new AbstractNestedCondition.MemberOutcomes(this.context, metadata, conditions)).getUltimateOutcome()));
/*     */     
/* 171 */     return Collections.unmodifiableList(outcomes);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\AbstractNestedCondition$MemberConditions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */