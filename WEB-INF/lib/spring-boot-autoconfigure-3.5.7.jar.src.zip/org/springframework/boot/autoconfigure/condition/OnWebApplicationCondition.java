/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483628)
/*     */ class OnWebApplicationCondition
/*     */   extends FilteringSpringBootCondition
/*     */ {
/*     */   private static final String SERVLET_WEB_APPLICATION_CLASS = "org.springframework.web.context.support.GenericWebApplicationContext";
/*     */   private static final String REACTIVE_WEB_APPLICATION_CLASS = "org.springframework.web.reactive.HandlerResult";
/*     */   
/*     */   protected ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata) {
/*  54 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  55 */     for (int i = 0; i < outcomes.length; i++) {
/*  56 */       String autoConfigurationClass = autoConfigurationClasses[i];
/*  57 */       if (autoConfigurationClass != null) {
/*  58 */         outcomes[i] = getOutcome(autoConfigurationMetadata
/*  59 */             .get(autoConfigurationClass, "ConditionalOnWebApplication"));
/*     */       }
/*     */     } 
/*  62 */     return outcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(String type) {
/*  66 */     if (type == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     ConditionMessage.Builder message = ConditionMessage.forCondition((Class)ConditionalOnWebApplication.class, new Object[0]);
/*  70 */     FilteringSpringBootCondition.ClassNameFilter missingClassFilter = FilteringSpringBootCondition.ClassNameFilter.MISSING;
/*  71 */     if (ConditionalOnWebApplication.Type.SERVLET.name().equals(type) && 
/*  72 */       missingClassFilter.matches("org.springframework.web.context.support.GenericWebApplicationContext", getBeanClassLoader())) {
/*  73 */       return ConditionOutcome.noMatch(message.didNotFind("servlet web application classes").atAll());
/*     */     }
/*     */     
/*  76 */     if (ConditionalOnWebApplication.Type.REACTIVE.name().equals(type) && 
/*  77 */       missingClassFilter.matches("org.springframework.web.reactive.HandlerResult", getBeanClassLoader())) {
/*  78 */       return ConditionOutcome.noMatch(message.didNotFind("reactive web application classes").atAll());
/*     */     }
/*     */     
/*  81 */     if (missingClassFilter.matches("org.springframework.web.context.support.GenericWebApplicationContext", getBeanClassLoader()) && 
/*  82 */       !ClassUtils.isPresent("org.springframework.web.reactive.HandlerResult", getBeanClassLoader())) {
/*  83 */       return ConditionOutcome.noMatch(message.didNotFind("reactive or servlet web application classes").atAll());
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/*  90 */     boolean required = metadata.isAnnotated(ConditionalOnWebApplication.class.getName());
/*  91 */     ConditionOutcome outcome = isWebApplication(context, metadata, required);
/*  92 */     if (required && !outcome.isMatch()) {
/*  93 */       return ConditionOutcome.noMatch(outcome.getConditionMessage());
/*     */     }
/*  95 */     if (!required && outcome.isMatch()) {
/*  96 */       return ConditionOutcome.noMatch(outcome.getConditionMessage());
/*     */     }
/*  98 */     return ConditionOutcome.match(outcome.getConditionMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionOutcome isWebApplication(ConditionContext context, AnnotatedTypeMetadata metadata, boolean required) {
/* 103 */     switch (deduceType(metadata)) { case SERVLET: case REACTIVE:  }  return 
/*     */ 
/*     */       
/* 106 */       isAnyWebApplication(context, required);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionOutcome isAnyWebApplication(ConditionContext context, boolean required) {
/* 111 */     ConditionMessage.Builder message = ConditionMessage.forCondition((Class)ConditionalOnWebApplication.class, new Object[] {
/* 112 */           required ? "(required)" : "" });
/* 113 */     ConditionOutcome servletOutcome = isServletWebApplication(context);
/* 114 */     if (servletOutcome.isMatch() && required) {
/* 115 */       return new ConditionOutcome(servletOutcome.isMatch(), message.because(servletOutcome.getMessage()));
/*     */     }
/* 117 */     ConditionOutcome reactiveOutcome = isReactiveWebApplication(context);
/* 118 */     if (reactiveOutcome.isMatch() && required) {
/* 119 */       return new ConditionOutcome(reactiveOutcome.isMatch(), message.because(reactiveOutcome.getMessage()));
/*     */     }
/* 121 */     return new ConditionOutcome((servletOutcome.isMatch() || reactiveOutcome.isMatch()), message
/* 122 */         .because(servletOutcome.getMessage()).append("and").append(reactiveOutcome.getMessage()));
/*     */   }
/*     */   
/*     */   private ConditionOutcome isServletWebApplication(ConditionContext context) {
/* 126 */     ConditionMessage.Builder message = ConditionMessage.forCondition("", new Object[0]);
/* 127 */     if (FilteringSpringBootCondition.ClassNameFilter.MISSING.matches("org.springframework.web.context.support.GenericWebApplicationContext", context.getClassLoader())) {
/* 128 */       return ConditionOutcome.noMatch(message.didNotFind("servlet web application classes").atAll());
/*     */     }
/* 130 */     if (context.getBeanFactory() != null) {
/* 131 */       String[] scopes = context.getBeanFactory().getRegisteredScopeNames();
/* 132 */       if (ObjectUtils.containsElement((Object[])scopes, "session")) {
/* 133 */         return ConditionOutcome.match(message.foundExactly("'session' scope"));
/*     */       }
/*     */     } 
/* 136 */     if (context.getEnvironment() instanceof org.springframework.web.context.ConfigurableWebEnvironment) {
/* 137 */       return ConditionOutcome.match(message.foundExactly("ConfigurableWebEnvironment"));
/*     */     }
/* 139 */     if (context.getResourceLoader() instanceof org.springframework.web.context.WebApplicationContext) {
/* 140 */       return ConditionOutcome.match(message.foundExactly("WebApplicationContext"));
/*     */     }
/* 142 */     return ConditionOutcome.noMatch(message.because("not a servlet web application"));
/*     */   }
/*     */   
/*     */   private ConditionOutcome isReactiveWebApplication(ConditionContext context) {
/* 146 */     ConditionMessage.Builder message = ConditionMessage.forCondition("", new Object[0]);
/* 147 */     if (FilteringSpringBootCondition.ClassNameFilter.MISSING.matches("org.springframework.web.reactive.HandlerResult", context.getClassLoader())) {
/* 148 */       return ConditionOutcome.noMatch(message.didNotFind("reactive web application classes").atAll());
/*     */     }
/* 150 */     if (context.getEnvironment() instanceof org.springframework.boot.web.reactive.context.ConfigurableReactiveWebEnvironment) {
/* 151 */       return ConditionOutcome.match(message.foundExactly("ConfigurableReactiveWebEnvironment"));
/*     */     }
/* 153 */     if (context.getResourceLoader() instanceof org.springframework.boot.web.reactive.context.ReactiveWebApplicationContext) {
/* 154 */       return ConditionOutcome.match(message.foundExactly("ReactiveWebApplicationContext"));
/*     */     }
/* 156 */     return ConditionOutcome.noMatch(message.because("not a reactive web application"));
/*     */   }
/*     */   
/*     */   private ConditionalOnWebApplication.Type deduceType(AnnotatedTypeMetadata metadata) {
/* 160 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnWebApplication.class.getName());
/* 161 */     if (attributes != null) {
/* 162 */       return (ConditionalOnWebApplication.Type)attributes.get("type");
/*     */     }
/* 164 */     return ConditionalOnWebApplication.Type.ANY;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnWebApplicationCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */