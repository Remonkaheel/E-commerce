/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConditionMessage
/*     */ {
/*     */   private final String message;
/*     */   
/*     */   private ConditionMessage() {
/*  44 */     this(null);
/*     */   }
/*     */   
/*     */   private ConditionMessage(String message) {
/*  48 */     this.message = message;
/*     */   }
/*     */   
/*     */   private ConditionMessage(ConditionMessage prior, String message) {
/*  52 */     this.message = prior.isEmpty() ? message : (String.valueOf(prior) + "; " + String.valueOf(prior));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  60 */     return !StringUtils.hasLength(this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  65 */     if (obj == this) {
/*  66 */       return true;
/*     */     }
/*  68 */     if (obj instanceof ConditionMessage) { ConditionMessage other = (ConditionMessage)obj;
/*  69 */       return ObjectUtils.nullSafeEquals(other.message, this.message); }
/*     */     
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     return ObjectUtils.nullSafeHashCode(this.message);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  81 */     return (this.message != null) ? this.message : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionMessage append(String message) {
/*  91 */     if (!StringUtils.hasLength(message)) {
/*  92 */       return this;
/*     */     }
/*  94 */     if (!StringUtils.hasLength(this.message)) {
/*  95 */       return new ConditionMessage(message);
/*     */     }
/*     */     
/*  98 */     return new ConditionMessage(this.message + " " + this.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder andCondition(Class<? extends Annotation> condition, Object... details) {
/* 111 */     Assert.notNull(condition, "'condition' must not be null");
/* 112 */     return andCondition("@" + ClassUtils.getShortName(condition), details);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder andCondition(String condition, Object... details) {
/* 125 */     Assert.notNull(condition, "'condition' must not be null");
/* 126 */     String detail = StringUtils.arrayToDelimitedString(details, " ");
/* 127 */     if (StringUtils.hasLength(detail)) {
/* 128 */       return new Builder(condition + " " + condition);
/*     */     }
/* 130 */     return new Builder(condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionMessage empty() {
/* 138 */     return new ConditionMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionMessage of(String message, Object... args) {
/* 149 */     if (ObjectUtils.isEmpty(args)) {
/* 150 */       return new ConditionMessage(message);
/*     */     }
/* 152 */     return new ConditionMessage(String.format(message, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionMessage of(Collection<? extends ConditionMessage> messages) {
/* 162 */     ConditionMessage result = new ConditionMessage();
/* 163 */     if (messages != null) {
/* 164 */       for (ConditionMessage message : messages) {
/* 165 */         result = new ConditionMessage(result, message.toString());
/*     */       }
/*     */     }
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forCondition(Class<? extends Annotation> condition, Object... details) {
/* 181 */     return (new ConditionMessage()).andCondition(condition, details);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder forCondition(String condition, Object... details) {
/* 194 */     return (new ConditionMessage()).andCondition(condition, details);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Builder
/*     */   {
/*     */     private final String condition;
/*     */ 
/*     */     
/*     */     private Builder(String condition) {
/* 205 */       this.condition = condition;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage foundExactly(Object result) {
/* 215 */       return found("").items(new Object[] { result });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage.ItemsBuilder found(String article) {
/* 225 */       return found(article, article);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage.ItemsBuilder found(String singular, String plural) {
/* 237 */       return new ConditionMessage.ItemsBuilder(this, "found", singular, plural);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage.ItemsBuilder didNotFind(String article) {
/* 248 */       return didNotFind(article, article);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage.ItemsBuilder didNotFind(String singular, String plural) {
/* 260 */       return new ConditionMessage.ItemsBuilder(this, "did not find", singular, plural);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage resultedIn(Object result) {
/* 270 */       return because("resulted in " + String.valueOf(result));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage available(String item) {
/* 280 */       return because(item + " is available");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage notAvailable(String item) {
/* 290 */       return because(item + " is not available");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage because(String reason) {
/* 300 */       if (StringUtils.hasLength(reason)) {
/* 301 */         return new ConditionMessage(ConditionMessage.this, 
/* 302 */             StringUtils.hasLength(this.condition) ? (this.condition + " " + this.condition) : reason);
/*     */       }
/* 304 */       return new ConditionMessage(ConditionMessage.this, this.condition);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class ItemsBuilder
/*     */   {
/*     */     private final ConditionMessage.Builder condition;
/*     */ 
/*     */     
/*     */     private final String reason;
/*     */     
/*     */     private final String singular;
/*     */     
/*     */     private final String plural;
/*     */ 
/*     */     
/*     */     private ItemsBuilder(ConditionMessage.Builder condition, String reason, String singular, String plural) {
/* 323 */       this.condition = condition;
/* 324 */       this.reason = reason;
/* 325 */       this.singular = singular;
/* 326 */       this.plural = plural;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage atAll() {
/* 336 */       return items(Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage items(Object... items) {
/* 347 */       return items(ConditionMessage.Style.NORMAL, items);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage items(ConditionMessage.Style style, Object... items) {
/* 359 */       return items(style, (items != null) ? Arrays.asList(items) : null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage items(Collection<?> items) {
/* 370 */       return items(ConditionMessage.Style.NORMAL, items);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConditionMessage items(ConditionMessage.Style style, Collection<?> items) {
/* 382 */       Assert.notNull(style, "'style' must not be null");
/* 383 */       StringBuilder message = new StringBuilder(this.reason);
/* 384 */       items = style.applyTo(items);
/* 385 */       if ((this.condition == null || items == null || items.size() <= 1) && 
/* 386 */         StringUtils.hasLength(this.singular)) {
/* 387 */         message.append(" ").append(this.singular);
/*     */       }
/* 389 */       else if (StringUtils.hasLength(this.plural)) {
/* 390 */         message.append(" ").append(this.plural);
/*     */       } 
/* 392 */       if (!CollectionUtils.isEmpty(items)) {
/* 393 */         message.append(" ").append(StringUtils.collectionToDelimitedString(items, ", "));
/*     */       }
/* 395 */       return this.condition.because(message.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Style
/*     */   {
/* 408 */     NORMAL
/*     */     {
/*     */       protected Object applyToItem(Object item)
/*     */       {
/* 412 */         return item;
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 420 */     QUOTE
/*     */     {
/*     */       protected String applyToItem(Object item)
/*     */       {
/* 424 */         return (item != null) ? ("'" + String.valueOf(item) + "'") : null;
/*     */       }
/*     */     };
/*     */ 
/*     */     
/*     */     public Collection<?> applyTo(Collection<?> items) {
/* 430 */       if (items == null) {
/* 431 */         return null;
/*     */       }
/* 433 */       List<Object> result = new ArrayList(items.size());
/* 434 */       for (Object item : items) {
/* 435 */         result.add(applyToItem(item));
/*     */       }
/* 437 */       return result;
/*     */     }
/*     */     
/*     */     protected abstract Object applyToItem(Object param1Object);
/*     */   }
/*     */   
/*     */   enum null {
/*     */     protected Object applyToItem(Object item) {
/*     */       return item;
/*     */     }
/*     */   }
/*     */   
/*     */   enum null {
/*     */     protected String applyToItem(Object item) {
/*     */       return (item != null) ? ("'" + String.valueOf(item) + "'") : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ConditionMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */