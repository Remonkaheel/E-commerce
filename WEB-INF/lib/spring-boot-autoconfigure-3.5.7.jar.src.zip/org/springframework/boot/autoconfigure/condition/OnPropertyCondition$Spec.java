/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Spec
/*     */ {
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   private final String prefix;
/*     */   private final String[] names;
/*     */   private final String havingValue;
/*     */   private final boolean matchIfMissing;
/*     */   
/*     */   Spec(Class<? extends Annotation> annotationType, AnnotationAttributes annotationAttributes) {
/* 129 */     this.annotationType = annotationType;
/* 130 */     this.prefix = !annotationAttributes.containsKey("prefix") ? "" : getPrefix(annotationAttributes);
/* 131 */     this.names = getNames(annotationAttributes);
/* 132 */     this.havingValue = annotationAttributes.get("havingValue").toString();
/* 133 */     this.matchIfMissing = annotationAttributes.getBoolean("matchIfMissing");
/*     */   }
/*     */   
/*     */   private String getPrefix(AnnotationAttributes annotationAttributes) {
/* 137 */     String prefix = annotationAttributes.getString("prefix").trim();
/* 138 */     if (StringUtils.hasText(prefix) && !prefix.endsWith(".")) {
/* 139 */       prefix = prefix + ".";
/*     */     }
/* 141 */     return prefix;
/*     */   }
/*     */   
/*     */   private String[] getNames(AnnotationAttributes annotationAttributes) {
/* 145 */     String[] value = (String[])annotationAttributes.get("value");
/* 146 */     String[] name = (String[])annotationAttributes.get("name");
/* 147 */     Assert.state((value.length > 0 || name.length > 0), () -> "The name or value attribute of @%s must be specified".formatted(new Object[] { ClassUtils.getShortName(this.annotationType) }));
/*     */ 
/*     */     
/* 150 */     Assert.state((value.length == 0 || name.length == 0), () -> "The name and value attributes of @%s are exclusive".formatted(new Object[] { ClassUtils.getShortName(this.annotationType) }));
/*     */ 
/*     */     
/* 153 */     return (value.length > 0) ? value : name;
/*     */   }
/*     */   
/*     */   private void collectProperties(PropertyResolver resolver, List<String> missing, List<String> nonMatching) {
/* 157 */     for (String name : this.names) {
/* 158 */       String key = this.prefix + this.prefix;
/* 159 */       if (resolver.containsProperty(key)) {
/* 160 */         if (!isMatch(resolver.getProperty(key), this.havingValue)) {
/* 161 */           nonMatching.add(name);
/*     */         
/*     */         }
/*     */       }
/* 165 */       else if (!this.matchIfMissing) {
/* 166 */         missing.add(name);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isMatch(String value, String requiredValue) {
/* 173 */     if (StringUtils.hasLength(requiredValue)) {
/* 174 */       return requiredValue.equalsIgnoreCase(value);
/*     */     }
/* 176 */     return !"false".equalsIgnoreCase(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 181 */     StringBuilder result = new StringBuilder();
/* 182 */     result.append("(");
/* 183 */     result.append(this.prefix);
/* 184 */     if (this.names.length == 1) {
/* 185 */       result.append(this.names[0]);
/*     */     } else {
/*     */       
/* 188 */       result.append("[");
/* 189 */       result.append(StringUtils.arrayToCommaDelimitedString((Object[])this.names));
/* 190 */       result.append("]");
/*     */     } 
/* 192 */     if (StringUtils.hasLength(this.havingValue)) {
/* 193 */       result.append("=").append(this.havingValue);
/*     */     }
/* 195 */     result.append(")");
/* 196 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\OnPropertyCondition$Spec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */