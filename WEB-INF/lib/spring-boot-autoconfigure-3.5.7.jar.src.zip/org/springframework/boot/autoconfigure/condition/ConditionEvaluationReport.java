/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConditionEvaluationReport
/*     */ {
/*     */   private static final String BEAN_NAME = "autoConfigurationReport";
/*  55 */   private static final AncestorsMatchedCondition ANCESTOR_CONDITION = new AncestorsMatchedCondition();
/*     */   
/*  57 */   private final SortedMap<String, ConditionAndOutcomes> outcomes = new TreeMap<>();
/*     */   
/*     */   private boolean addedAncestorOutcomes;
/*     */   
/*     */   private ConditionEvaluationReport parent;
/*     */   
/*  63 */   private final List<String> exclusions = new ArrayList<>();
/*     */   
/*  65 */   private final Set<String> unconditionalClasses = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordConditionEvaluation(String source, Condition condition, ConditionOutcome outcome) {
/*  81 */     Assert.notNull(source, "'source' must not be null");
/*  82 */     Assert.notNull(condition, "'condition' must not be null");
/*  83 */     Assert.notNull(outcome, "'outcome' must not be null");
/*  84 */     this.unconditionalClasses.remove(source);
/*  85 */     ((ConditionAndOutcomes)this.outcomes.computeIfAbsent(source, key -> new ConditionAndOutcomes())).add(condition, outcome);
/*  86 */     this.addedAncestorOutcomes = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordExclusions(Collection<String> exclusions) {
/*  94 */     Assert.notNull(exclusions, "'exclusions' must not be null");
/*  95 */     this.exclusions.addAll(exclusions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordEvaluationCandidates(List<String> evaluationCandidates) {
/* 104 */     Assert.notNull(evaluationCandidates, "'evaluationCandidates' must not be null");
/* 105 */     this.unconditionalClasses.addAll(evaluationCandidates);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ConditionAndOutcomes> getConditionAndOutcomesBySource() {
/* 113 */     if (!this.addedAncestorOutcomes) {
/* 114 */       this.outcomes.forEach((source, sourceOutcomes) -> {
/*     */             if (!sourceOutcomes.isFullMatch()) {
/*     */               addNoMatchOutcomeToAncestors(source);
/*     */             }
/*     */           });
/* 119 */       this.addedAncestorOutcomes = true;
/*     */     } 
/* 121 */     return Collections.unmodifiableMap(this.outcomes);
/*     */   }
/*     */   
/*     */   private void addNoMatchOutcomeToAncestors(String source) {
/* 125 */     String prefix = source + "$";
/* 126 */     this.outcomes.forEach((candidateSource, sourceOutcomes) -> {
/*     */           if (candidateSource.startsWith(prefix)) {
/*     */             ConditionOutcome outcome = ConditionOutcome.noMatch(ConditionMessage.forCondition("Ancestor " + source, new Object[0]).because("did not match"));
/*     */             sourceOutcomes.add(ANCESTOR_CONDITION, outcome);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getExclusions() {
/* 140 */     return Collections.unmodifiableList(this.exclusions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getUnconditionalClasses() {
/* 148 */     Set<String> filtered = new HashSet<>(this.unconditionalClasses);
/* 149 */     Objects.requireNonNull(filtered); this.exclusions.forEach(filtered::remove);
/* 150 */     return Collections.unmodifiableSet(filtered);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionEvaluationReport getParent() {
/* 158 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionEvaluationReport find(BeanFactory beanFactory) {
/* 168 */     if (beanFactory instanceof ConfigurableListableBeanFactory) {
/* 169 */       return get((ConfigurableListableBeanFactory)beanFactory);
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConditionEvaluationReport get(ConfigurableListableBeanFactory beanFactory) {
/* 180 */     synchronized (beanFactory) {
/*     */       ConditionEvaluationReport report;
/* 182 */       if (beanFactory.containsSingleton("autoConfigurationReport")) {
/* 183 */         report = (ConditionEvaluationReport)beanFactory.getBean("autoConfigurationReport", ConditionEvaluationReport.class);
/*     */       } else {
/*     */         
/* 186 */         report = new ConditionEvaluationReport();
/* 187 */         beanFactory.registerSingleton("autoConfigurationReport", report);
/*     */       } 
/* 189 */       locateParent(beanFactory.getParentBeanFactory(), report);
/* 190 */       return report;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void locateParent(BeanFactory beanFactory, ConditionEvaluationReport report) {
/* 195 */     if (beanFactory != null && report.parent == null && beanFactory.containsBean("autoConfigurationReport")) {
/* 196 */       report.parent = (ConditionEvaluationReport)beanFactory.getBean("autoConfigurationReport", ConditionEvaluationReport.class);
/*     */     }
/*     */   }
/*     */   
/*     */   public ConditionEvaluationReport getDelta(ConditionEvaluationReport previousReport) {
/* 201 */     ConditionEvaluationReport delta = new ConditionEvaluationReport();
/* 202 */     this.outcomes.forEach((source, sourceOutcomes) -> {
/*     */           ConditionAndOutcomes previous = previousReport.outcomes.get(source);
/*     */           
/*     */           if (previous == null || previous.isFullMatch() != sourceOutcomes.isFullMatch()) {
/*     */             sourceOutcomes.forEach(());
/*     */           }
/*     */         });
/* 209 */     List<String> newExclusions = new ArrayList<>(this.exclusions);
/* 210 */     newExclusions.removeAll(previousReport.getExclusions());
/* 211 */     delta.recordExclusions(newExclusions);
/* 212 */     List<String> newUnconditionalClasses = new ArrayList<>(this.unconditionalClasses);
/* 213 */     newUnconditionalClasses.removeAll(previousReport.unconditionalClasses);
/* 214 */     delta.unconditionalClasses.addAll(newUnconditionalClasses);
/* 215 */     return delta;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConditionAndOutcomes
/*     */     implements Iterable<ConditionAndOutcome>
/*     */   {
/* 223 */     private final Set<ConditionEvaluationReport.ConditionAndOutcome> outcomes = new LinkedHashSet<>();
/*     */     
/*     */     public void add(Condition condition, ConditionOutcome outcome) {
/* 226 */       this.outcomes.add(new ConditionEvaluationReport.ConditionAndOutcome(condition, outcome));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isFullMatch() {
/* 234 */       for (ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcomes : this) {
/* 235 */         if (!conditionAndOutcomes.getOutcome().isMatch()) {
/* 236 */           return false;
/*     */         }
/*     */       } 
/* 239 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Stream<ConditionEvaluationReport.ConditionAndOutcome> stream() {
/* 248 */       return StreamSupport.stream(spliterator(), false);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<ConditionEvaluationReport.ConditionAndOutcome> iterator() {
/* 253 */       return Collections.<ConditionEvaluationReport.ConditionAndOutcome>unmodifiableSet(this.outcomes).iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConditionAndOutcome
/*     */   {
/*     */     private final Condition condition;
/*     */ 
/*     */     
/*     */     private final ConditionOutcome outcome;
/*     */ 
/*     */     
/*     */     public ConditionAndOutcome(Condition condition, ConditionOutcome outcome) {
/* 268 */       this.condition = condition;
/* 269 */       this.outcome = outcome;
/*     */     }
/*     */     
/*     */     public Condition getCondition() {
/* 273 */       return this.condition;
/*     */     }
/*     */     
/*     */     public ConditionOutcome getOutcome() {
/* 277 */       return this.outcome;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 282 */       if (this == obj) {
/* 283 */         return true;
/*     */       }
/* 285 */       if (obj == null || getClass() != obj.getClass()) {
/* 286 */         return false;
/*     */       }
/* 288 */       ConditionAndOutcome other = (ConditionAndOutcome)obj;
/* 289 */       return (ObjectUtils.nullSafeEquals(this.condition.getClass(), other.condition.getClass()) && 
/* 290 */         ObjectUtils.nullSafeEquals(this.outcome, other.outcome));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 295 */       return this.condition.getClass().hashCode() * 31 + this.outcome.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 300 */       return String.valueOf(this.condition.getClass()) + " " + String.valueOf(this.condition.getClass());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class AncestorsMatchedCondition
/*     */     implements Condition
/*     */   {
/*     */     public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 309 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ConditionEvaluationReport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */