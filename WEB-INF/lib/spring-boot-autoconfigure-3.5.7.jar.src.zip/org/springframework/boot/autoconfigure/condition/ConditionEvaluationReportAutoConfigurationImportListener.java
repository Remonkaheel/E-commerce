/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationImportEvent;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationImportListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConditionEvaluationReportAutoConfigurationImportListener
/*    */   implements AutoConfigurationImportListener, BeanFactoryAware
/*    */ {
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   public void onAutoConfigurationImportEvent(AutoConfigurationImportEvent event) {
/* 39 */     if (this.beanFactory != null) {
/* 40 */       ConditionEvaluationReport report = ConditionEvaluationReport.get(this.beanFactory);
/* 41 */       report.recordEvaluationCandidates(event.getCandidateConfigurations());
/* 42 */       report.recordExclusions(event.getExclusions());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 48 */     ConfigurableListableBeanFactory listableBeanFactory = (ConfigurableListableBeanFactory)beanFactory; this
/* 49 */       .beanFactory = (beanFactory instanceof ConfigurableListableBeanFactory) ? listableBeanFactory : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ConditionEvaluationReportAutoConfigurationImportListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */