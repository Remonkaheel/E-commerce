package org.springframework.boot.autoconfigure.condition;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Conditional;

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Conditional({OnBeanCondition.class})
public @interface ConditionalOnBean {
  Class<?>[] value() default {};
  
  String[] type() default {};
  
  Class<? extends Annotation>[] annotation() default {};
  
  String[] name() default {};
  
  SearchStrategy search() default SearchStrategy.ALL;
  
  Class<?>[] parameterizedContainer() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\condition\ConditionalOnBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */