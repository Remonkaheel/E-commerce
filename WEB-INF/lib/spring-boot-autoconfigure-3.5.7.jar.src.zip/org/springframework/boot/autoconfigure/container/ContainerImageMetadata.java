/*    */ package org.springframework.boot.autoconfigure.container;
/*    */ 
/*    */ import org.springframework.core.AttributeAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ContainerImageMetadata
/*    */   extends Record
/*    */ {
/*    */   private final String imageName;
/*    */   
/*    */   public ContainerImageMetadata(String imageName) {
/* 32 */     this.imageName = imageName; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #32	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 32 */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata; } public String imageName() { return this.imageName; }
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #32	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata; }
/*    */   public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #32	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/boot/autoconfigure/container/ContainerImageMetadata;
/* 34 */     //   0	8	1	o	Ljava/lang/Object; } static final String NAME = ContainerImageMetadata.class.getName();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addTo(AttributeAccessor attributes) {
/* 41 */     if (attributes != null) {
/* 42 */       attributes.setAttribute(NAME, this);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isPresent(AttributeAccessor attributes) {
/* 53 */     return (getFrom(attributes) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ContainerImageMetadata getFrom(AttributeAccessor attributes) {
/* 63 */     return (attributes != null) ? (ContainerImageMetadata)attributes.getAttribute(NAME) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\container\ContainerImageMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */