/*     */ package org.springframework.boot.autoconfigure.context;
/*     */ 
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBundleCondition
/*     */   extends SpringBootCondition
/*     */ {
/* 113 */   private static final ConcurrentReferenceHashMap<String, ConditionOutcome> cache = new ConcurrentReferenceHashMap();
/*     */ 
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 117 */     String basename = context.getEnvironment().getProperty("spring.messages.basename", "messages");
/* 118 */     ConditionOutcome outcome = (ConditionOutcome)cache.get(basename);
/* 119 */     if (outcome == null) {
/* 120 */       outcome = getMatchOutcomeForBasename(context, basename);
/* 121 */       cache.put(basename, outcome);
/*     */     } 
/* 123 */     return outcome;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getMatchOutcomeForBasename(ConditionContext context, String basename) {
/* 127 */     ConditionMessage.Builder message = ConditionMessage.forCondition("ResourceBundle", new Object[0]);
/* 128 */     for (String name : StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(basename))) {
/* 129 */       for (Resource resource : getResources(context.getClassLoader(), name)) {
/* 130 */         if (resource.exists()) {
/* 131 */           return ConditionOutcome.match(message.found("bundle").items(new Object[] { resource }));
/*     */         }
/*     */       } 
/*     */     } 
/* 135 */     return ConditionOutcome.noMatch(message.didNotFind("bundle with basename " + basename).atAll());
/*     */   }
/*     */   
/*     */   private Resource[] getResources(ClassLoader classLoader, String name) {
/* 139 */     String target = name.replace('.', '/');
/*     */     try {
/* 141 */       return (new PathMatchingResourcePatternResolver(classLoader))
/* 142 */         .getResources("classpath*:" + target + ".properties");
/*     */     }
/* 144 */     catch (Exception ex) {
/* 145 */       return MessageSourceAutoConfiguration.NO_RESOURCES;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\context\MessageSourceAutoConfiguration$ResourceBundleCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */