/*     */ package org.springframework.boot.autoconfigure.context;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.messages")
/*     */ public class MessageSourceProperties
/*     */ {
/*  47 */   private List<String> basename = new ArrayList<>(List.of("messages"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Resource> commonMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private Charset encoding = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*     */   private Duration cacheDuration;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fallbackToSystemLocale = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean alwaysUseMessageFormat = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useCodeAsDefaultMessage = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getBasename() {
/*  86 */     return this.basename;
/*     */   }
/*     */   
/*     */   public void setBasename(List<String> basename) {
/*  90 */     this.basename = basename;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/*  94 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/*  98 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public Duration getCacheDuration() {
/* 102 */     return this.cacheDuration;
/*     */   }
/*     */   
/*     */   public void setCacheDuration(Duration cacheDuration) {
/* 106 */     this.cacheDuration = cacheDuration;
/*     */   }
/*     */   
/*     */   public boolean isFallbackToSystemLocale() {
/* 110 */     return this.fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale) {
/* 114 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public boolean isAlwaysUseMessageFormat() {
/* 118 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat) {
/* 122 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   public boolean isUseCodeAsDefaultMessage() {
/* 126 */     return this.useCodeAsDefaultMessage;
/*     */   }
/*     */   
/*     */   public void setUseCodeAsDefaultMessage(boolean useCodeAsDefaultMessage) {
/* 130 */     this.useCodeAsDefaultMessage = useCodeAsDefaultMessage;
/*     */   }
/*     */   
/*     */   public List<Resource> getCommonMessages() {
/* 134 */     return this.commonMessages;
/*     */   }
/*     */   
/*     */   public void setCommonMessages(List<Resource> commonMessages) {
/* 138 */     this.commonMessages = commonMessages;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\context\MessageSourceProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */