/*     */ package org.springframework.boot.autoconfigure.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureOrder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration
/*     */ @ConditionalOnMissingBean(name = {"messageSource"}, search = SearchStrategy.CURRENT)
/*     */ @AutoConfigureOrder(-2147483648)
/*     */ @Conditional({MessageSourceAutoConfiguration.ResourceBundleCondition.class})
/*     */ @EnableConfigurationProperties({MessageSourceProperties.class})
/*     */ @ImportRuntimeHints({MessageSourceAutoConfiguration.MessageSourceRuntimeHints.class})
/*     */ public class MessageSourceAutoConfiguration
/*     */ {
/*  73 */   private static final Resource[] NO_RESOURCES = new Resource[0];
/*     */   
/*     */   @Bean
/*     */   public MessageSource messageSource(MessageSourceProperties properties) {
/*  77 */     ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
/*  78 */     if (!CollectionUtils.isEmpty(properties.getBasename())) {
/*  79 */       messageSource.setBasenames(properties.getBasename().<String>toArray(new String[0]));
/*     */     }
/*  81 */     if (properties.getEncoding() != null) {
/*  82 */       messageSource.setDefaultEncoding(properties.getEncoding().name());
/*     */     }
/*  84 */     messageSource.setFallbackToSystemLocale(properties.isFallbackToSystemLocale());
/*  85 */     Duration cacheDuration = properties.getCacheDuration();
/*  86 */     if (cacheDuration != null) {
/*  87 */       messageSource.setCacheMillis(cacheDuration.toMillis());
/*     */     }
/*  89 */     messageSource.setAlwaysUseMessageFormat(properties.isAlwaysUseMessageFormat());
/*  90 */     messageSource.setUseCodeAsDefaultMessage(properties.isUseCodeAsDefaultMessage());
/*  91 */     messageSource.setCommonMessages(loadCommonMessages(properties.getCommonMessages()));
/*  92 */     return (MessageSource)messageSource;
/*     */   }
/*     */   
/*     */   private Properties loadCommonMessages(List<Resource> resources) {
/*  96 */     if (CollectionUtils.isEmpty(resources)) {
/*  97 */       return null;
/*     */     }
/*  99 */     Properties properties = CollectionFactory.createSortedProperties(false);
/* 100 */     for (Resource resource : resources) {
/*     */       try {
/* 102 */         PropertiesLoaderUtils.fillProperties(properties, resource);
/*     */       }
/* 104 */       catch (IOException ex) {
/* 105 */         throw new UncheckedIOException("Failed to load common messages from '%s'".formatted(new Object[] { resource }, ), ex);
/*     */       } 
/*     */     } 
/* 108 */     return properties;
/*     */   }
/*     */   
/*     */   protected static class ResourceBundleCondition
/*     */     extends SpringBootCondition {
/* 113 */     private static final ConcurrentReferenceHashMap<String, ConditionOutcome> cache = new ConcurrentReferenceHashMap();
/*     */ 
/*     */     
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 117 */       String basename = context.getEnvironment().getProperty("spring.messages.basename", "messages");
/* 118 */       ConditionOutcome outcome = (ConditionOutcome)cache.get(basename);
/* 119 */       if (outcome == null) {
/* 120 */         outcome = getMatchOutcomeForBasename(context, basename);
/* 121 */         cache.put(basename, outcome);
/*     */       } 
/* 123 */       return outcome;
/*     */     }
/*     */     
/*     */     private ConditionOutcome getMatchOutcomeForBasename(ConditionContext context, String basename) {
/* 127 */       ConditionMessage.Builder message = ConditionMessage.forCondition("ResourceBundle", new Object[0]);
/* 128 */       for (String name : StringUtils.commaDelimitedListToStringArray(StringUtils.trimAllWhitespace(basename))) {
/* 129 */         for (Resource resource : getResources(context.getClassLoader(), name)) {
/* 130 */           if (resource.exists()) {
/* 131 */             return ConditionOutcome.match(message.found("bundle").items(new Object[] { resource }));
/*     */           }
/*     */         } 
/*     */       } 
/* 135 */       return ConditionOutcome.noMatch(message.didNotFind("bundle with basename " + basename).atAll());
/*     */     }
/*     */     
/*     */     private Resource[] getResources(ClassLoader classLoader, String name) {
/* 139 */       String target = name.replace('.', '/');
/*     */       try {
/* 141 */         return (new PathMatchingResourcePatternResolver(classLoader))
/* 142 */           .getResources("classpath*:" + target + ".properties");
/*     */       }
/* 144 */       catch (Exception ex) {
/* 145 */         return MessageSourceAutoConfiguration.NO_RESOURCES;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class MessageSourceRuntimeHints
/*     */     implements RuntimeHintsRegistrar
/*     */   {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 155 */       hints.resources().registerPattern("messages.properties").registerPattern("messages_*.properties");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\context\MessageSourceAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */