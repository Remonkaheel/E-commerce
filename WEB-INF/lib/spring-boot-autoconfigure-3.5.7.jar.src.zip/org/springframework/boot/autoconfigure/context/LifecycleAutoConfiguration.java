/*    */ package org.springframework.boot.autoconfigure.context;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.support.DefaultLifecycleProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration
/*    */ @EnableConfigurationProperties({LifecycleProperties.class})
/*    */ public class LifecycleAutoConfiguration
/*    */ {
/*    */   @Bean(name = {"lifecycleProcessor"})
/*    */   @ConditionalOnMissingBean(name = {"lifecycleProcessor"}, search = SearchStrategy.CURRENT)
/*    */   public DefaultLifecycleProcessor defaultLifecycleProcessor(LifecycleProperties properties) {
/* 43 */     DefaultLifecycleProcessor lifecycleProcessor = new DefaultLifecycleProcessor();
/* 44 */     lifecycleProcessor.setTimeoutPerShutdownPhase(properties.getTimeoutPerShutdownPhase().toMillis());
/* 45 */     return lifecycleProcessor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\context\LifecycleAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */