/*    */ package org.springframework.boot.autoconfigure.context;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.lifecycle")
/*    */ public class LifecycleProperties
/*    */ {
/* 36 */   private Duration timeoutPerShutdownPhase = Duration.ofSeconds(30L);
/*    */   
/*    */   public Duration getTimeoutPerShutdownPhase() {
/* 39 */     return this.timeoutPerShutdownPhase;
/*    */   }
/*    */   
/*    */   public void setTimeoutPerShutdownPhase(Duration timeoutPerShutdownPhase) {
/* 43 */     this.timeoutPerShutdownPhase = timeoutPerShutdownPhase;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\context\LifecycleProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */