/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.batch.core.BatchStatus;
/*     */ import org.springframework.batch.core.Job;
/*     */ import org.springframework.batch.core.JobExecution;
/*     */ import org.springframework.batch.core.JobExecutionException;
/*     */ import org.springframework.batch.core.JobParameter;
/*     */ import org.springframework.batch.core.JobParameters;
/*     */ import org.springframework.batch.core.JobParametersBuilder;
/*     */ import org.springframework.batch.core.JobParametersInvalidException;
/*     */ import org.springframework.batch.core.configuration.JobRegistry;
/*     */ import org.springframework.batch.core.converter.DefaultJobParametersConverter;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
/*     */ import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.batch.core.repository.JobRestartException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.boot.ApplicationArguments;
/*     */ import org.springframework.boot.ApplicationRunner;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobLauncherApplicationRunner
/*     */   implements ApplicationRunner, InitializingBean, Ordered, ApplicationEventPublisherAware
/*     */ {
/*     */   public static final int DEFAULT_ORDER = 0;
/*  77 */   private static final Log logger = LogFactory.getLog(JobLauncherApplicationRunner.class);
/*     */   
/*  79 */   private JobParametersConverter converter = (JobParametersConverter)new DefaultJobParametersConverter();
/*     */   
/*     */   private final JobLauncher jobLauncher;
/*     */   
/*     */   private final JobExplorer jobExplorer;
/*     */   
/*     */   private final JobRepository jobRepository;
/*     */   
/*     */   private JobRegistry jobRegistry;
/*     */   
/*     */   private String jobName;
/*     */   
/*  91 */   private Collection<Job> jobs = Collections.emptySet();
/*     */   
/*  93 */   private int order = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ApplicationEventPublisher publisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JobLauncherApplicationRunner(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository) {
/* 105 */     Assert.notNull(jobLauncher, "'jobLauncher' must not be null");
/* 106 */     Assert.notNull(jobExplorer, "'jobExplorer' must not be null");
/* 107 */     Assert.notNull(jobRepository, "'jobRepository' must not be null");
/* 108 */     this.jobLauncher = jobLauncher;
/* 109 */     this.jobExplorer = jobExplorer;
/* 110 */     this.jobRepository = jobRepository;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 115 */     Assert.state((this.jobs.size() <= 1 || StringUtils.hasText(this.jobName)), "Job name must be specified in case of multiple jobs");
/*     */     
/* 117 */     if (StringUtils.hasText(this.jobName)) {
/* 118 */       Assert.state((isLocalJob(this.jobName) || isRegisteredJob(this.jobName)), () -> "No job found with name '" + this.jobName + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.0.10", forRemoval = true)
/*     */   public void validate() {
/* 125 */     afterPropertiesSet();
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 129 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 134 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
/* 139 */     this.publisher = publisher;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobRegistry(JobRegistry jobRegistry) {
/* 144 */     this.jobRegistry = jobRegistry;
/*     */   }
/*     */   
/*     */   public void setJobName(String jobName) {
/* 148 */     this.jobName = jobName;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobParametersConverter(JobParametersConverter converter) {
/* 153 */     this.converter = converter;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setJobs(Collection<Job> jobs) {
/* 158 */     this.jobs = jobs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(ApplicationArguments args) throws Exception {
/* 163 */     String[] jobArguments = (String[])args.getNonOptionArgs().toArray((Object[])new String[0]);
/* 164 */     run(jobArguments);
/*     */   }
/*     */   
/*     */   public void run(String... args) throws JobExecutionException {
/* 168 */     logger.info("Running default command line with: " + String.valueOf(Arrays.asList(args)));
/* 169 */     launchJobFromProperties(StringUtils.splitArrayElementsIntoProperties(args, "="));
/*     */   }
/*     */   
/*     */   protected void launchJobFromProperties(Properties properties) throws JobExecutionException {
/* 173 */     JobParameters jobParameters = this.converter.getJobParameters(properties);
/* 174 */     executeLocalJobs(jobParameters);
/* 175 */     executeRegisteredJobs(jobParameters);
/*     */   }
/*     */   
/*     */   private boolean isLocalJob(String jobName) {
/* 179 */     return this.jobs.stream().anyMatch(job -> job.getName().equals(jobName));
/*     */   }
/*     */   
/*     */   private boolean isRegisteredJob(String jobName) {
/* 183 */     return (this.jobRegistry != null && this.jobRegistry.getJobNames().contains(jobName));
/*     */   }
/*     */   
/*     */   private void executeLocalJobs(JobParameters jobParameters) throws JobExecutionException {
/* 187 */     for (Job job : this.jobs) {
/* 188 */       if (StringUtils.hasText(this.jobName) && 
/* 189 */         !this.jobName.equals(job.getName())) {
/* 190 */         logger.debug(LogMessage.format("Skipped job: %s", job.getName()));
/*     */         
/*     */         continue;
/*     */       } 
/* 194 */       execute(job, jobParameters);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void executeRegisteredJobs(JobParameters jobParameters) throws JobExecutionException {
/* 199 */     if (this.jobRegistry != null && StringUtils.hasText(this.jobName) && 
/* 200 */       !isLocalJob(this.jobName)) {
/* 201 */       Job job = this.jobRegistry.getJob(this.jobName);
/* 202 */       execute(job, jobParameters);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void execute(Job job, JobParameters jobParameters) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
/* 209 */     JobParameters parameters = getNextJobParameters(job, jobParameters);
/* 210 */     JobExecution execution = this.jobLauncher.run(job, parameters);
/* 211 */     if (this.publisher != null) {
/* 212 */       this.publisher.publishEvent(new JobExecutionEvent(execution));
/*     */     }
/*     */   }
/*     */   
/*     */   private JobParameters getNextJobParameters(Job job, JobParameters jobParameters) {
/* 217 */     if (this.jobRepository != null && this.jobRepository.isJobInstanceExists(job.getName(), jobParameters)) {
/* 218 */       return getNextJobParametersForExisting(job, jobParameters);
/*     */     }
/* 220 */     if (job.getJobParametersIncrementer() == null) {
/* 221 */       return jobParameters;
/*     */     }
/*     */ 
/*     */     
/* 225 */     JobParameters nextParameters = (new JobParametersBuilder(jobParameters, this.jobExplorer)).getNextJobParameters(job).toJobParameters();
/* 226 */     return merge(nextParameters, jobParameters);
/*     */   }
/*     */   
/*     */   private JobParameters getNextJobParametersForExisting(Job job, JobParameters jobParameters) {
/* 230 */     JobExecution lastExecution = this.jobRepository.getLastJobExecution(job.getName(), jobParameters);
/* 231 */     if (isStoppedOrFailed(lastExecution) && job.isRestartable()) {
/*     */       
/* 233 */       JobParameters previousIdentifyingParameters = new JobParameters(lastExecution.getJobParameters().getIdentifyingParameters());
/* 234 */       return merge(previousIdentifyingParameters, jobParameters);
/*     */     } 
/* 236 */     return jobParameters;
/*     */   }
/*     */   
/*     */   private boolean isStoppedOrFailed(JobExecution execution) {
/* 240 */     BatchStatus status = (execution != null) ? execution.getStatus() : null;
/* 241 */     return (status == BatchStatus.STOPPED || status == BatchStatus.FAILED);
/*     */   }
/*     */   
/*     */   private JobParameters merge(JobParameters parameters, JobParameters additionals) {
/* 245 */     Map<String, JobParameter<?>> merged = new LinkedHashMap<>();
/* 246 */     merged.putAll(parameters.getParameters());
/* 247 */     merged.putAll(additionals.getParameters());
/* 248 */     return new JobParameters(merged);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\JobLauncherApplicationRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */