/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.batch.core.configuration.support.DefaultBatchConfiguration;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.repository.ExecutionContextSerializer;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.annotation.Isolation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class SpringBootBatchConfiguration
/*     */   extends DefaultBatchConfiguration
/*     */ {
/*     */   private final DataSource dataSource;
/*     */   private final PlatformTransactionManager transactionManager;
/*     */   private final TaskExecutor taskExecutor;
/*     */   private final BatchProperties properties;
/*     */   private final List<BatchConversionServiceCustomizer> batchConversionServiceCustomizers;
/*     */   private final ExecutionContextSerializer executionContextSerializer;
/*     */   private final JobParametersConverter jobParametersConverter;
/*     */   
/*     */   SpringBootBatchConfiguration(DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, PlatformTransactionManager transactionManager, @BatchTransactionManager ObjectProvider<PlatformTransactionManager> batchTransactionManager, @BatchTaskExecutor ObjectProvider<TaskExecutor> batchTaskExecutor, BatchProperties properties, ObjectProvider<BatchConversionServiceCustomizer> batchConversionServiceCustomizers, ObjectProvider<ExecutionContextSerializer> executionContextSerializer, ObjectProvider<JobParametersConverter> jobParametersConverter) {
/* 124 */     this.dataSource = (DataSource)batchDataSource.getIfAvailable(() -> dataSource);
/* 125 */     this.transactionManager = (PlatformTransactionManager)batchTransactionManager.getIfAvailable(() -> transactionManager);
/* 126 */     this.taskExecutor = (TaskExecutor)batchTaskExecutor.getIfAvailable();
/* 127 */     this.properties = properties;
/* 128 */     this.batchConversionServiceCustomizers = batchConversionServiceCustomizers.orderedStream().toList();
/* 129 */     this.executionContextSerializer = (ExecutionContextSerializer)executionContextSerializer.getIfAvailable();
/* 130 */     this.jobParametersConverter = (JobParametersConverter)jobParametersConverter.getIfAvailable();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DataSource getDataSource() {
/* 135 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   protected PlatformTransactionManager getTransactionManager() {
/* 140 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getTablePrefix() {
/* 145 */     String tablePrefix = this.properties.getJdbc().getTablePrefix();
/* 146 */     return (tablePrefix != null) ? tablePrefix : super.getTablePrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean getValidateTransactionState() {
/* 151 */     return this.properties.getJdbc().isValidateTransactionState();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Isolation getIsolationLevelForCreate() {
/* 156 */     Isolation isolation = this.properties.getJdbc().getIsolationLevelForCreate();
/* 157 */     return (isolation != null) ? isolation : super.getIsolationLevelForCreate();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ConfigurableConversionService getConversionService() {
/* 162 */     ConfigurableConversionService conversionService = super.getConversionService();
/* 163 */     for (BatchConversionServiceCustomizer customizer : this.batchConversionServiceCustomizers) {
/* 164 */       customizer.customize(conversionService);
/*     */     }
/* 166 */     return conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ExecutionContextSerializer getExecutionContextSerializer() {
/* 171 */     return (this.executionContextSerializer != null) ? this.executionContextSerializer : 
/* 172 */       super.getExecutionContextSerializer();
/*     */   }
/*     */ 
/*     */   
/*     */   protected JobParametersConverter getJobParametersConverter() {
/* 177 */     return (this.jobParametersConverter != null) ? this.jobParametersConverter : 
/* 178 */       super.getJobParametersConverter();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TaskExecutor getTaskExecutor() {
/* 183 */     return (this.taskExecutor != null) ? this.taskExecutor : super.getTaskExecutor();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\BatchAutoConfiguration$SpringBootBatchConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */