/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
/*     */ import org.springframework.batch.core.configuration.support.DefaultBatchConfiguration;
/*     */ import org.springframework.batch.core.converter.JobParametersConverter;
/*     */ import org.springframework.batch.core.explore.JobExplorer;
/*     */ import org.springframework.batch.core.launch.JobLauncher;
/*     */ import org.springframework.batch.core.repository.ExecutionContextSerializer;
/*     */ import org.springframework.batch.core.repository.JobRepository;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.ExitCodeGenerator;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.sql.init.OnDatabaseInitializationCondition;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.sql.init.dependency.DatabaseInitializationDependencyConfigurer;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.convert.support.ConfigurableConversionService;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.annotation.Isolation;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {HibernateJpaAutoConfiguration.class, TransactionAutoConfiguration.class})
/*     */ @ConditionalOnClass({JobLauncher.class, DataSource.class, DatabasePopulator.class})
/*     */ @ConditionalOnBean({DataSource.class, PlatformTransactionManager.class})
/*     */ @ConditionalOnMissingBean(value = {DefaultBatchConfiguration.class}, annotation = {EnableBatchProcessing.class})
/*     */ @EnableConfigurationProperties({BatchProperties.class})
/*     */ @Import({DatabaseInitializationDependencyConfigurer.class})
/*     */ public class BatchAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnBooleanProperty(name = {"spring.batch.job.enabled"}, matchIfMissing = true)
/*     */   public JobLauncherApplicationRunner jobLauncherApplicationRunner(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository, BatchProperties properties) {
/*  86 */     JobLauncherApplicationRunner runner = new JobLauncherApplicationRunner(jobLauncher, jobExplorer, jobRepository);
/*  87 */     String jobName = properties.getJob().getName();
/*  88 */     if (StringUtils.hasText(jobName)) {
/*  89 */       runner.setJobName(jobName);
/*     */     }
/*  91 */     return runner;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ExitCodeGenerator.class})
/*     */   public JobExecutionExitCodeGenerator jobExecutionExitCodeGenerator() {
/*  97 */     return new JobExecutionExitCodeGenerator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class SpringBootBatchConfiguration
/*     */     extends DefaultBatchConfiguration
/*     */   {
/*     */     private final DataSource dataSource;
/*     */ 
/*     */     
/*     */     private final PlatformTransactionManager transactionManager;
/*     */ 
/*     */     
/*     */     private final TaskExecutor taskExecutor;
/*     */     
/*     */     private final BatchProperties properties;
/*     */     
/*     */     private final List<BatchConversionServiceCustomizer> batchConversionServiceCustomizers;
/*     */     
/*     */     private final ExecutionContextSerializer executionContextSerializer;
/*     */     
/*     */     private final JobParametersConverter jobParametersConverter;
/*     */ 
/*     */     
/*     */     SpringBootBatchConfiguration(DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, PlatformTransactionManager transactionManager, @BatchTransactionManager ObjectProvider<PlatformTransactionManager> batchTransactionManager, @BatchTaskExecutor ObjectProvider<TaskExecutor> batchTaskExecutor, BatchProperties properties, ObjectProvider<BatchConversionServiceCustomizer> batchConversionServiceCustomizers, ObjectProvider<ExecutionContextSerializer> executionContextSerializer, ObjectProvider<JobParametersConverter> jobParametersConverter) {
/* 124 */       this.dataSource = (DataSource)batchDataSource.getIfAvailable(() -> dataSource);
/* 125 */       this.transactionManager = (PlatformTransactionManager)batchTransactionManager.getIfAvailable(() -> transactionManager);
/* 126 */       this.taskExecutor = (TaskExecutor)batchTaskExecutor.getIfAvailable();
/* 127 */       this.properties = properties;
/* 128 */       this.batchConversionServiceCustomizers = batchConversionServiceCustomizers.orderedStream().toList();
/* 129 */       this.executionContextSerializer = (ExecutionContextSerializer)executionContextSerializer.getIfAvailable();
/* 130 */       this.jobParametersConverter = (JobParametersConverter)jobParametersConverter.getIfAvailable();
/*     */     }
/*     */ 
/*     */     
/*     */     protected DataSource getDataSource() {
/* 135 */       return this.dataSource;
/*     */     }
/*     */ 
/*     */     
/*     */     protected PlatformTransactionManager getTransactionManager() {
/* 140 */       return this.transactionManager;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String getTablePrefix() {
/* 145 */       String tablePrefix = this.properties.getJdbc().getTablePrefix();
/* 146 */       return (tablePrefix != null) ? tablePrefix : super.getTablePrefix();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean getValidateTransactionState() {
/* 151 */       return this.properties.getJdbc().isValidateTransactionState();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Isolation getIsolationLevelForCreate() {
/* 156 */       Isolation isolation = this.properties.getJdbc().getIsolationLevelForCreate();
/* 157 */       return (isolation != null) ? isolation : super.getIsolationLevelForCreate();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ConfigurableConversionService getConversionService() {
/* 162 */       ConfigurableConversionService conversionService = super.getConversionService();
/* 163 */       for (BatchConversionServiceCustomizer customizer : this.batchConversionServiceCustomizers) {
/* 164 */         customizer.customize(conversionService);
/*     */       }
/* 166 */       return conversionService;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExecutionContextSerializer getExecutionContextSerializer() {
/* 171 */       return (this.executionContextSerializer != null) ? this.executionContextSerializer : 
/* 172 */         super.getExecutionContextSerializer();
/*     */     }
/*     */ 
/*     */     
/*     */     protected JobParametersConverter getJobParametersConverter() {
/* 177 */       return (this.jobParametersConverter != null) ? this.jobParametersConverter : 
/* 178 */         super.getJobParametersConverter();
/*     */     }
/*     */ 
/*     */     
/*     */     protected TaskExecutor getTaskExecutor() {
/* 183 */       return (this.taskExecutor != null) ? this.taskExecutor : super.getTaskExecutor();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Conditional({OnBatchDatasourceInitializationCondition.class})
/*     */   static class DataSourceInitializerConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     BatchDataSourceScriptDatabaseInitializer batchDataSourceInitializer(DataSource dataSource, @BatchDataSource ObjectProvider<DataSource> batchDataSource, BatchProperties properties) {
/* 196 */       return new BatchDataSourceScriptDatabaseInitializer((DataSource)batchDataSource.getIfAvailable(() -> dataSource), properties
/* 197 */           .getJdbc());
/*     */     }
/*     */   }
/*     */   
/*     */   static class OnBatchDatasourceInitializationCondition
/*     */     extends OnDatabaseInitializationCondition
/*     */   {
/*     */     OnBatchDatasourceInitializationCondition() {
/* 205 */       super("Batch", new String[] { "spring.batch.jdbc.initialize-schema" });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\BatchAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */