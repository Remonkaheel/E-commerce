/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.init.DataSourceScriptDatabaseInitializer;
/*    */ import org.springframework.boot.jdbc.init.PlatformPlaceholderDatabaseDriverResolver;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchDataSourceScriptDatabaseInitializer
/*    */   extends DataSourceScriptDatabaseInitializer
/*    */ {
/*    */   public BatchDataSourceScriptDatabaseInitializer(DataSource dataSource, BatchProperties.Jdbc properties) {
/* 47 */     this(dataSource, getSettings(dataSource, properties));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BatchDataSourceScriptDatabaseInitializer(DataSource dataSource, DatabaseInitializationSettings settings) {
/* 57 */     super(dataSource, settings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DatabaseInitializationSettings getSettings(DataSource dataSource, BatchProperties.Jdbc properties) {
/* 71 */     DatabaseInitializationSettings settings = new DatabaseInitializationSettings();
/* 72 */     settings.setSchemaLocations(resolveSchemaLocations(dataSource, properties));
/* 73 */     settings.setMode(properties.getInitializeSchema());
/* 74 */     settings.setContinueOnError(true);
/* 75 */     return settings;
/*    */   }
/*    */   
/*    */   private static List<String> resolveSchemaLocations(DataSource dataSource, BatchProperties.Jdbc properties) {
/* 79 */     PlatformPlaceholderDatabaseDriverResolver platformResolver = new PlatformPlaceholderDatabaseDriverResolver();
/* 80 */     if (StringUtils.hasText(properties.getPlatform())) {
/* 81 */       return platformResolver.resolveAll(properties.getPlatform(), new String[] { properties.getSchema() });
/*    */     }
/* 83 */     return platformResolver.resolveAll(dataSource, new String[] { properties.getSchema() });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\BatchDataSourceScriptDatabaseInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */