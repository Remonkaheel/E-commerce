/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import org.springframework.batch.core.JobExecution;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobExecutionEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final JobExecution execution;
/*    */   
/*    */   public JobExecutionEvent(JobExecution execution) {
/* 38 */     super(execution);
/* 39 */     this.execution = execution;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JobExecution getJobExecution() {
/* 47 */     return this.execution;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\JobExecutionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */