package org.springframework.boot.autoconfigure.batch;

import org.springframework.core.convert.support.ConfigurableConversionService;

@FunctionalInterface
public interface BatchConversionServiceCustomizer {
  void customize(ConfigurableConversionService paramConfigurableConversionService);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\BatchConversionServiceCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */