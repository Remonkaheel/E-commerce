/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ import org.springframework.batch.core.JobExecution;
/*    */ import org.springframework.boot.ExitCodeGenerator;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobExecutionExitCodeGenerator
/*    */   implements ApplicationListener<JobExecutionEvent>, ExitCodeGenerator
/*    */ {
/* 34 */   private final List<JobExecution> executions = new CopyOnWriteArrayList<>();
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(JobExecutionEvent event) {
/* 38 */     this.executions.add(event.getJobExecution());
/*    */   }
/*    */ 
/*    */   
/*    */   public int getExitCode() {
/* 43 */     for (JobExecution execution : this.executions) {
/* 44 */       if (execution.getStatus().ordinal() > 0) {
/* 45 */         return execution.getStatus().ordinal();
/*    */       }
/*    */     } 
/* 48 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\JobExecutionExitCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */