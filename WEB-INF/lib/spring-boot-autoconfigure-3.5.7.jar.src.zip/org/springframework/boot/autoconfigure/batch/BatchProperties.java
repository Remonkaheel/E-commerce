/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.sql.init.DatabaseInitializationMode;
/*     */ import org.springframework.transaction.annotation.Isolation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.batch")
/*     */ public class BatchProperties
/*     */ {
/*  36 */   private final Job job = new Job();
/*     */   
/*  38 */   private final Jdbc jdbc = new Jdbc();
/*     */   
/*     */   public Job getJob() {
/*  41 */     return this.job;
/*     */   }
/*     */   
/*     */   public Jdbc getJdbc() {
/*  45 */     return this.jdbc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Job
/*     */   {
/*  54 */     private String name = "";
/*     */     
/*     */     public String getName() {
/*  57 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(String name) {
/*  61 */       this.name = name;
/*     */     } }
/*     */   
/*     */   public static class Jdbc {
/*     */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*     */     private boolean validateTransactionState;
/*     */     private Isolation isolationLevelForCreate;
/*     */     private String schema;
/*     */     private String platform;
/*     */     private String tablePrefix;
/*     */     private DatabaseInitializationMode initializeSchema;
/*     */     
/*     */     public Jdbc() {
/*  74 */       this.validateTransactionState = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       this.schema = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       this.initializeSchema = DatabaseInitializationMode.EMBEDDED;
/*     */     }
/*     */     public boolean isValidateTransactionState() {
/* 103 */       return this.validateTransactionState;
/*     */     }
/*     */     
/*     */     public void setValidateTransactionState(boolean validateTransactionState) {
/* 107 */       this.validateTransactionState = validateTransactionState;
/*     */     }
/*     */     
/*     */     public Isolation getIsolationLevelForCreate() {
/* 111 */       return this.isolationLevelForCreate;
/*     */     }
/*     */     
/*     */     public void setIsolationLevelForCreate(Isolation isolationLevelForCreate) {
/* 115 */       this.isolationLevelForCreate = isolationLevelForCreate;
/*     */     }
/*     */     
/*     */     public String getSchema() {
/* 119 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(String schema) {
/* 123 */       this.schema = schema;
/*     */     }
/*     */     
/*     */     public String getPlatform() {
/* 127 */       return this.platform;
/*     */     }
/*     */     
/*     */     public void setPlatform(String platform) {
/* 131 */       this.platform = platform;
/*     */     }
/*     */     
/*     */     public String getTablePrefix() {
/* 135 */       return this.tablePrefix;
/*     */     }
/*     */     
/*     */     public void setTablePrefix(String tablePrefix) {
/* 139 */       this.tablePrefix = tablePrefix;
/*     */     }
/*     */     
/*     */     public DatabaseInitializationMode getInitializeSchema() {
/* 143 */       return this.initializeSchema;
/*     */     }
/*     */     
/*     */     public void setInitializeSchema(DatabaseInitializationMode initializeSchema) {
/* 147 */       this.initializeSchema = initializeSchema;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\batch\BatchProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */