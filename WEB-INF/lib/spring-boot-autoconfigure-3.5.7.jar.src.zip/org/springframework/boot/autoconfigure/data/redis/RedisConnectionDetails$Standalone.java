/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Standalone
/*     */ {
/*     */   String getHost();
/*     */   
/*     */   int getPort();
/*     */   
/*     */   default int getDatabase() {
/*  99 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default SslBundle getSslBundle() {
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Standalone of(String host, int port) {
/* 118 */     return of(host, port, 0, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Standalone of(String host, int port, SslBundle sslBundle) {
/* 130 */     return of(host, port, 0, sslBundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Standalone of(String host, int port, int database) {
/* 141 */     return of(host, port, database, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Standalone of(final String host, final int port, final int database, final SslBundle sslBundle) {
/* 154 */     Assert.hasLength(host, "'host' must not be empty");
/* 155 */     return new Standalone()
/*     */       {
/*     */         public String getHost()
/*     */         {
/* 159 */           return host;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getPort() {
/* 164 */           return port;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDatabase() {
/* 169 */           return database;
/*     */         }
/*     */ 
/*     */         
/*     */         public SslBundle getSslBundle() {
/* 174 */           return sslBundle;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisConnectionDetails$Standalone.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */