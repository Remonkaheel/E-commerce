/*    */ package org.springframework.boot.autoconfigure.data.rest;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.rest.webmvc.config.RepositoryRestMvcConfiguration;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {HttpMessageConvertersAutoConfiguration.class, JacksonAutoConfiguration.class})
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnMissingBean({RepositoryRestMvcConfiguration.class})
/*    */ @ConditionalOnClass({RepositoryRestMvcConfiguration.class})
/*    */ @EnableConfigurationProperties({RepositoryRestProperties.class})
/*    */ @Import({RepositoryRestMvcConfiguration.class})
/*    */ public class RepositoryRestMvcAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public SpringBootRepositoryRestConfigurer springBootRepositoryRestConfigurer(ObjectProvider<Jackson2ObjectMapperBuilder> objectMapperBuilder, RepositoryRestProperties properties) {
/* 61 */     return new SpringBootRepositoryRestConfigurer((Jackson2ObjectMapperBuilder)objectMapperBuilder.getIfAvailable(), properties);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\rest\RepositoryRestMvcAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */