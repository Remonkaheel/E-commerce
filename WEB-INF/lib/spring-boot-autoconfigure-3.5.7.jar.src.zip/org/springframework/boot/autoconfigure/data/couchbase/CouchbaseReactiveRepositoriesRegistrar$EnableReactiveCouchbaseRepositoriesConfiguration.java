package org.springframework.boot.autoconfigure.data.couchbase;

import org.springframework.data.couchbase.repository.config.EnableReactiveCouchbaseRepositories;

@EnableReactiveCouchbaseRepositories
final class EnableReactiveCouchbaseRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseReactiveRepositoriesRegistrar$EnableReactiveCouchbaseRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */