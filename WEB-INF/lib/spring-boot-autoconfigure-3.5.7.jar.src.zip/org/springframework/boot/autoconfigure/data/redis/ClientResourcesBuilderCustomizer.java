package org.springframework.boot.autoconfigure.data.redis;

import io.lettuce.core.resource.ClientResources;

public interface ClientResourcesBuilderCustomizer {
  void customize(ClientResources.Builder paramBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\ClientResourcesBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */