/*     */ package org.springframework.boot.autoconfigure.data.jpa;
/*     */ 
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BootstrapExecutorCondition
/*     */   extends AnyNestedCondition
/*     */ {
/*     */   BootstrapExecutorCondition() {
/* 110 */     super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */   }
/*     */   
/*     */   @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "deferred")
/*     */   static class DeferredBootstrapMode {}
/*     */   
/*     */   @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "lazy")
/*     */   static class LazyBootstrapMode {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesAutoConfiguration$BootstrapExecutorCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */