/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.convert.CustomConversions;
/*    */ import org.springframework.data.couchbase.core.convert.CouchbaseCustomConversions;
/*    */ import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
/*    */ import org.springframework.data.couchbase.core.convert.translation.JacksonTranslationService;
/*    */ import org.springframework.data.couchbase.core.convert.translation.TranslationService;
/*    */ import org.springframework.data.couchbase.core.mapping.CouchbaseMappingContext;
/*    */ import org.springframework.data.couchbase.core.mapping.Document;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ import org.springframework.data.mapping.model.FieldNamingStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class CouchbaseDataConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MappingCouchbaseConverter couchbaseMappingConverter(CouchbaseDataProperties properties, CouchbaseMappingContext couchbaseMappingContext, CouchbaseCustomConversions couchbaseCustomConversions) {
/* 49 */     MappingCouchbaseConverter converter = new MappingCouchbaseConverter((MappingContext)couchbaseMappingContext, properties.getTypeKey());
/* 50 */     converter.setCustomConversions((CustomConversions)couchbaseCustomConversions);
/* 51 */     return converter;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   TranslationService couchbaseTranslationService() {
/* 57 */     return (TranslationService)new JacksonTranslationService();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Bean(name = {"couchbaseMappingContext"})
/*    */   @ConditionalOnMissingBean(name = {"couchbaseMappingContext"})
/*    */   CouchbaseMappingContext couchbaseMappingContext(CouchbaseDataProperties properties, ApplicationContext applicationContext, CouchbaseCustomConversions couchbaseCustomConversions) throws ClassNotFoundException {
/* 65 */     CouchbaseMappingContext mappingContext = new CouchbaseMappingContext();
/* 66 */     mappingContext.setInitialEntitySet((new EntityScanner(applicationContext)).scan(new Class[] { Document.class }));
/* 67 */     mappingContext.setSimpleTypeHolder(couchbaseCustomConversions.getSimpleTypeHolder());
/* 68 */     Class<?> fieldNamingStrategy = properties.getFieldNamingStrategy();
/* 69 */     if (fieldNamingStrategy != null) {
/* 70 */       mappingContext
/* 71 */         .setFieldNamingStrategy((FieldNamingStrategy)BeanUtils.instantiateClass(fieldNamingStrategy));
/*    */     }
/* 73 */     mappingContext.setAutoIndexCreation(properties.isAutoIndex());
/* 74 */     return mappingContext;
/*    */   }
/*    */   
/*    */   @Bean(name = {"couchbaseCustomConversions"})
/*    */   @ConditionalOnMissingBean(name = {"couchbaseCustomConversions"})
/*    */   CouchbaseCustomConversions couchbaseCustomConversions() {
/* 80 */     return new CouchbaseCustomConversions(Collections.emptyList());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseDataConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */