package org.springframework.boot.autoconfigure.data.redis;

import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

@EnableRedisRepositories
final class EnableRedisRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisRepositoriesRegistrar$EnableRedisRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */