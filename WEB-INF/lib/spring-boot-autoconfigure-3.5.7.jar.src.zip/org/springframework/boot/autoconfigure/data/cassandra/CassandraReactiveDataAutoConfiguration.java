/*    */ package org.springframework.boot.autoconfigure.data.cassandra;
/*    */ 
/*    */ import com.datastax.oss.driver.api.core.CqlSession;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.cassandra.ReactiveSession;
/*    */ import org.springframework.data.cassandra.ReactiveSessionFactory;
/*    */ import org.springframework.data.cassandra.core.ReactiveCassandraOperations;
/*    */ import org.springframework.data.cassandra.core.ReactiveCassandraTemplate;
/*    */ import org.springframework.data.cassandra.core.convert.CassandraConverter;
/*    */ import org.springframework.data.cassandra.core.cql.ReactiveCqlOperations;
/*    */ import org.springframework.data.cassandra.core.cql.ReactiveCqlTemplate;
/*    */ import org.springframework.data.cassandra.core.cql.session.DefaultBridgedReactiveSession;
/*    */ import org.springframework.data.cassandra.core.cql.session.DefaultReactiveSessionFactory;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {CassandraDataAutoConfiguration.class})
/*    */ @ConditionalOnClass({CqlSession.class, ReactiveCassandraTemplate.class, Flux.class})
/*    */ @ConditionalOnBean({CqlSession.class})
/*    */ public class CassandraReactiveDataAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveSession reactiveCassandraSession(CqlSession session) {
/* 54 */     return (ReactiveSession)new DefaultBridgedReactiveSession(session);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveSessionFactory reactiveCassandraSessionFactory(ReactiveSession reactiveCassandraSession) {
/* 60 */     return (ReactiveSessionFactory)new DefaultReactiveSessionFactory(reactiveCassandraSession);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({ReactiveCqlOperations.class})
/*    */   public ReactiveCqlTemplate reactiveCqlTemplate(ReactiveSessionFactory reactiveCassandraSessionFactory) {
/* 66 */     return new ReactiveCqlTemplate(reactiveCassandraSessionFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({ReactiveCassandraOperations.class})
/*    */   public ReactiveCassandraTemplate reactiveCassandraTemplate(ReactiveCqlTemplate reactiveCqlTemplate, CassandraConverter converter) {
/* 73 */     return new ReactiveCassandraTemplate((ReactiveCqlOperations)reactiveCqlTemplate, converter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraReactiveDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */