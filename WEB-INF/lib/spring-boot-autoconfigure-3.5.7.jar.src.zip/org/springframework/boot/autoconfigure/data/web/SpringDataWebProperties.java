/*     */ package org.springframework.boot.autoconfigure.data.web;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.data.web.config.EnableSpringDataWebSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.data.web")
/*     */ public class SpringDataWebProperties
/*     */ {
/*  32 */   private final Pageable pageable = new Pageable();
/*     */   
/*  34 */   private final Sort sort = new Sort();
/*     */   
/*     */   public Pageable getPageable() {
/*  37 */     return this.pageable;
/*     */   }
/*     */   
/*     */   public Sort getSort() {
/*  41 */     return this.sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pageable
/*     */   {
/*  52 */     private String pageParameter = "page";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     private String sizeParameter = "size";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean oneIndexedParameters = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     private String prefix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     private String qualifierDelimiter = "_";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     private int defaultPageSize = 20;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     private int maxPageSize = 2000;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     private EnableSpringDataWebSupport.PageSerializationMode serializationMode = EnableSpringDataWebSupport.PageSerializationMode.DIRECT;
/*     */     
/*     */     public String getPageParameter() {
/*  92 */       return this.pageParameter;
/*     */     }
/*     */     
/*     */     public void setPageParameter(String pageParameter) {
/*  96 */       this.pageParameter = pageParameter;
/*     */     }
/*     */     
/*     */     public String getSizeParameter() {
/* 100 */       return this.sizeParameter;
/*     */     }
/*     */     
/*     */     public void setSizeParameter(String sizeParameter) {
/* 104 */       this.sizeParameter = sizeParameter;
/*     */     }
/*     */     
/*     */     public boolean isOneIndexedParameters() {
/* 108 */       return this.oneIndexedParameters;
/*     */     }
/*     */     
/*     */     public void setOneIndexedParameters(boolean oneIndexedParameters) {
/* 112 */       this.oneIndexedParameters = oneIndexedParameters;
/*     */     }
/*     */     
/*     */     public String getPrefix() {
/* 116 */       return this.prefix;
/*     */     }
/*     */     
/*     */     public void setPrefix(String prefix) {
/* 120 */       this.prefix = prefix;
/*     */     }
/*     */     
/*     */     public String getQualifierDelimiter() {
/* 124 */       return this.qualifierDelimiter;
/*     */     }
/*     */     
/*     */     public void setQualifierDelimiter(String qualifierDelimiter) {
/* 128 */       this.qualifierDelimiter = qualifierDelimiter;
/*     */     }
/*     */     
/*     */     public int getDefaultPageSize() {
/* 132 */       return this.defaultPageSize;
/*     */     }
/*     */     
/*     */     public void setDefaultPageSize(int defaultPageSize) {
/* 136 */       this.defaultPageSize = defaultPageSize;
/*     */     }
/*     */     
/*     */     public int getMaxPageSize() {
/* 140 */       return this.maxPageSize;
/*     */     }
/*     */     
/*     */     public void setMaxPageSize(int maxPageSize) {
/* 144 */       this.maxPageSize = maxPageSize;
/*     */     }
/*     */     
/*     */     public EnableSpringDataWebSupport.PageSerializationMode getSerializationMode() {
/* 148 */       return this.serializationMode;
/*     */     }
/*     */     
/*     */     public void setSerializationMode(EnableSpringDataWebSupport.PageSerializationMode serializationMode) {
/* 152 */       this.serializationMode = serializationMode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sort
/*     */   {
/*     */     private String sortParameter;
/*     */ 
/*     */ 
/*     */     
/*     */     public Sort() {
/* 165 */       this.sortParameter = "sort";
/*     */     }
/*     */     public String getSortParameter() {
/* 168 */       return this.sortParameter;
/*     */     }
/*     */     
/*     */     public void setSortParameter(String sortParameter) {
/* 172 */       this.sortParameter = sortParameter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\web\SpringDataWebProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */