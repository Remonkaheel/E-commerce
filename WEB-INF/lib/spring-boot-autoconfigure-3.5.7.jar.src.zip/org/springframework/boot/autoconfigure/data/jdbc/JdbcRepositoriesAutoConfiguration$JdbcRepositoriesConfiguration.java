package org.springframework.boot.autoconfigure.data.jdbc;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jdbc.repository.config.JdbcRepositoryConfigExtension;

@Configuration(proxyBeanMethods = false)
@ConditionalOnMissingBean({JdbcRepositoryConfigExtension.class})
@Import({JdbcRepositoriesRegistrar.class})
class JdbcRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jdbc\JdbcRepositoriesAutoConfiguration$JdbcRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */