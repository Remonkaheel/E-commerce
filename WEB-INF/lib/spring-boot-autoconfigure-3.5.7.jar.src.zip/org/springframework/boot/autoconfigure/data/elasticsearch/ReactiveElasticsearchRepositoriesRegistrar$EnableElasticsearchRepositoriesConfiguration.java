package org.springframework.boot.autoconfigure.data.elasticsearch;

import org.springframework.data.elasticsearch.repository.config.EnableReactiveElasticsearchRepositories;

@EnableReactiveElasticsearchRepositories
final class EnableElasticsearchRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ReactiveElasticsearchRepositoriesRegistrar$EnableElasticsearchRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */