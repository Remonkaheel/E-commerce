/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Objects;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.convert.CustomConversions;
/*    */ import org.springframework.data.domain.ManagedTypes;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ import org.springframework.data.mapping.model.FieldNamingStrategy;
/*    */ import org.springframework.data.mongodb.MongoDatabaseFactory;
/*    */ import org.springframework.data.mongodb.MongoManagedTypes;
/*    */ import org.springframework.data.mongodb.core.convert.DbRefResolver;
/*    */ import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
/*    */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*    */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*    */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*    */ import org.springframework.data.mongodb.core.convert.NoOpDbRefResolver;
/*    */ import org.springframework.data.mongodb.core.mapping.Document;
/*    */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class MongoDataConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   static MongoManagedTypes mongoManagedTypes(ApplicationContext applicationContext) throws ClassNotFoundException {
/* 55 */     return MongoManagedTypes.fromIterable((new EntityScanner(applicationContext)).scan(new Class[] { Document.class }));
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MongoMappingContext mongoMappingContext(MongoProperties properties, MongoCustomConversions conversions, MongoManagedTypes managedTypes) {
/* 62 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 63 */     MongoMappingContext context = new MongoMappingContext();
/* 64 */     Objects.requireNonNull(context); map.from(properties.isAutoIndexCreation()).to(context::setAutoIndexCreation);
/* 65 */     context.setManagedTypes((ManagedTypes)managedTypes);
/* 66 */     Class<?> strategyClass = properties.getFieldNamingStrategy();
/* 67 */     if (strategyClass != null) {
/* 68 */       context.setFieldNamingStrategy((FieldNamingStrategy)BeanUtils.instantiateClass(strategyClass));
/*    */     }
/* 70 */     context.setSimpleTypeHolder(conversions.getSimpleTypeHolder());
/* 71 */     return context;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MongoCustomConversions mongoCustomConversions() {
/* 77 */     return new MongoCustomConversions(Collections.emptyList());
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({MongoConverter.class})
/*    */   MappingMongoConverter mappingMongoConverter(ObjectProvider<MongoDatabaseFactory> factory, MongoMappingContext context, MongoCustomConversions conversions) {
/* 84 */     MongoDatabaseFactory mongoDatabaseFactory = (MongoDatabaseFactory)factory.getIfAvailable();
/*    */     
/* 86 */     DbRefResolver dbRefResolver = (mongoDatabaseFactory != null) ? (DbRefResolver)new DefaultDbRefResolver(mongoDatabaseFactory) : (DbRefResolver)NoOpDbRefResolver.INSTANCE;
/* 87 */     MappingMongoConverter mappingConverter = new MappingMongoConverter(dbRefResolver, (MappingContext)context);
/* 88 */     mappingConverter.setCustomConversions((CustomConversions)conversions);
/* 89 */     return mappingConverter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDataConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */