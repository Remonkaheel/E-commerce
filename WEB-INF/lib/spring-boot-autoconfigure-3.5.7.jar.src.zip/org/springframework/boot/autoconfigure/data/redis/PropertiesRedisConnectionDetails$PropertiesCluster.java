/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertiesCluster
/*     */   implements RedisConnectionDetails.Cluster
/*     */ {
/*     */   private final List<RedisConnectionDetails.Node> nodes;
/*     */   
/*     */   PropertiesCluster(RedisProperties.Cluster properties) {
/* 115 */     this.nodes = paramPropertiesRedisConnectionDetails.asNodes(properties.getNodes());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<RedisConnectionDetails.Node> getNodes() {
/* 120 */     return this.nodes;
/*     */   }
/*     */ 
/*     */   
/*     */   public SslBundle getSslBundle() {
/* 125 */     return PropertiesRedisConnectionDetails.this.getSslBundle();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\PropertiesRedisConnectionDetails$PropertiesCluster.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */