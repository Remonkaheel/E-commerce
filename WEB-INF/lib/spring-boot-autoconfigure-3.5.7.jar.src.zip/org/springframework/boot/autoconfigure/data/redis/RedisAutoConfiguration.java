/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.ssl.SslBundles;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.RedisOperations;
/*    */ import org.springframework.data.redis.core.RedisTemplate;
/*    */ import org.springframework.data.redis.core.StringRedisTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration
/*    */ @ConditionalOnClass({RedisOperations.class})
/*    */ @EnableConfigurationProperties({RedisProperties.class})
/*    */ @Import({LettuceConnectionConfiguration.class, JedisConnectionConfiguration.class})
/*    */ public class RedisAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({RedisConnectionDetails.class})
/*    */   PropertiesRedisConnectionDetails redisConnectionDetails(RedisProperties properties, ObjectProvider<SslBundles> sslBundles) {
/* 58 */     return new PropertiesRedisConnectionDetails(properties, (SslBundles)sslBundles.getIfAvailable());
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"redisTemplate"})
/*    */   @ConditionalOnSingleCandidate(RedisConnectionFactory.class)
/*    */   public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
/* 65 */     RedisTemplate<Object, Object> template = new RedisTemplate();
/* 66 */     template.setConnectionFactory(redisConnectionFactory);
/* 67 */     return template;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnSingleCandidate(RedisConnectionFactory.class)
/*    */   public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
/* 74 */     return new StringRedisTemplate(redisConnectionFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */