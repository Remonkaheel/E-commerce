package org.springframework.boot.autoconfigure.data.neo4j;

import org.springframework.data.neo4j.repository.config.EnableReactiveNeo4jRepositories;

@EnableReactiveNeo4jRepositories
final class EnableReactiveNeo4jRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jReactiveRepositoriesRegistrar$EnableReactiveNeo4jRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */