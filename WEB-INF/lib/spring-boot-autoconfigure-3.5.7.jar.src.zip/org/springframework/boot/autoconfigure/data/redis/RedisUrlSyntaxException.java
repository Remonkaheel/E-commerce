/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RedisUrlSyntaxException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String url;
/*    */   
/*    */   RedisUrlSyntaxException(String url, Exception cause) {
/* 29 */     super(buildMessage(url), cause);
/* 30 */     this.url = url;
/*    */   }
/*    */   
/*    */   RedisUrlSyntaxException(String url) {
/* 34 */     super(buildMessage(url));
/* 35 */     this.url = url;
/*    */   }
/*    */   
/*    */   String getUrl() {
/* 39 */     return this.url;
/*    */   }
/*    */   
/*    */   private static String buildMessage(String url) {
/* 43 */     return "Invalid Redis URL '" + url + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisUrlSyntaxException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */