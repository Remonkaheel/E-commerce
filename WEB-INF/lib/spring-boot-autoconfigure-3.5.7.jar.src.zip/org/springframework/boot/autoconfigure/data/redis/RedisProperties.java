/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.data.redis")
/*     */ public class RedisProperties
/*     */ {
/*  43 */   private int database = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private String host = "localhost";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private int port = 6379;
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration timeout;
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration connectTimeout;
/*     */ 
/*     */ 
/*     */   
/*     */   private String clientName;
/*     */ 
/*     */ 
/*     */   
/*     */   private ClientType clientType;
/*     */ 
/*     */ 
/*     */   
/*     */   private Sentinel sentinel;
/*     */ 
/*     */   
/*     */   private Cluster cluster;
/*     */ 
/*     */   
/*  95 */   private final Ssl ssl = new Ssl();
/*     */   
/*  97 */   private final Jedis jedis = new Jedis();
/*     */   
/*  99 */   private final Lettuce lettuce = new Lettuce();
/*     */   
/*     */   public int getDatabase() {
/* 102 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(int database) {
/* 106 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 110 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 114 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getHost() {
/* 118 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 122 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 126 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 130 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 134 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 138 */     this.password = password;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 142 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 146 */     this.port = port;
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 150 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/* 154 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public Duration getTimeout() {
/* 158 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public Duration getConnectTimeout() {
/* 162 */     return this.connectTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 166 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */   
/*     */   public String getClientName() {
/* 170 */     return this.clientName;
/*     */   }
/*     */   
/*     */   public void setClientName(String clientName) {
/* 174 */     this.clientName = clientName;
/*     */   }
/*     */   
/*     */   public ClientType getClientType() {
/* 178 */     return this.clientType;
/*     */   }
/*     */   
/*     */   public void setClientType(ClientType clientType) {
/* 182 */     this.clientType = clientType;
/*     */   }
/*     */   
/*     */   public Sentinel getSentinel() {
/* 186 */     return this.sentinel;
/*     */   }
/*     */   
/*     */   public void setSentinel(Sentinel sentinel) {
/* 190 */     this.sentinel = sentinel;
/*     */   }
/*     */   
/*     */   public Cluster getCluster() {
/* 194 */     return this.cluster;
/*     */   }
/*     */   
/*     */   public void setCluster(Cluster cluster) {
/* 198 */     this.cluster = cluster;
/*     */   }
/*     */   
/*     */   public Jedis getJedis() {
/* 202 */     return this.jedis;
/*     */   }
/*     */   
/*     */   public Lettuce getLettuce() {
/* 206 */     return this.lettuce;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ClientType
/*     */   {
/* 217 */     LETTUCE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     JEDIS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pool
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     private int maxIdle = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     private int minIdle = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     private int maxActive = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     private Duration maxWait = Duration.ofMillis(-1L);
/*     */ 
/*     */ 
/*     */     
/*     */     private Duration timeBetweenEvictionRuns;
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getEnabled() {
/* 271 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(Boolean enabled) {
/* 275 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public int getMaxIdle() {
/* 279 */       return this.maxIdle;
/*     */     }
/*     */     
/*     */     public void setMaxIdle(int maxIdle) {
/* 283 */       this.maxIdle = maxIdle;
/*     */     }
/*     */     
/*     */     public int getMinIdle() {
/* 287 */       return this.minIdle;
/*     */     }
/*     */     
/*     */     public void setMinIdle(int minIdle) {
/* 291 */       this.minIdle = minIdle;
/*     */     }
/*     */     
/*     */     public int getMaxActive() {
/* 295 */       return this.maxActive;
/*     */     }
/*     */     
/*     */     public void setMaxActive(int maxActive) {
/* 299 */       this.maxActive = maxActive;
/*     */     }
/*     */     
/*     */     public Duration getMaxWait() {
/* 303 */       return this.maxWait;
/*     */     }
/*     */     
/*     */     public void setMaxWait(Duration maxWait) {
/* 307 */       this.maxWait = maxWait;
/*     */     }
/*     */     
/*     */     public Duration getTimeBetweenEvictionRuns() {
/* 311 */       return this.timeBetweenEvictionRuns;
/*     */     }
/*     */     
/*     */     public void setTimeBetweenEvictionRuns(Duration timeBetweenEvictionRuns) {
/* 315 */       this.timeBetweenEvictionRuns = timeBetweenEvictionRuns;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Cluster
/*     */   {
/*     */     private List<String> nodes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer maxRedirects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getNodes() {
/* 338 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 342 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public Integer getMaxRedirects() {
/* 346 */       return this.maxRedirects;
/*     */     }
/*     */     
/*     */     public void setMaxRedirects(Integer maxRedirects) {
/* 350 */       this.maxRedirects = maxRedirects;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sentinel
/*     */   {
/*     */     private String master;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<String> nodes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMaster() {
/* 381 */       return this.master;
/*     */     }
/*     */     
/*     */     public void setMaster(String master) {
/* 385 */       this.master = master;
/*     */     }
/*     */     
/*     */     public List<String> getNodes() {
/* 389 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 393 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public String getUsername() {
/* 397 */       return this.username;
/*     */     }
/*     */     
/*     */     public void setUsername(String username) {
/* 401 */       this.username = username;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 405 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 409 */       this.password = password;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Ssl
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */ 
/*     */     
/*     */     private String bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 428 */       return (this.enabled != null) ? this.enabled.booleanValue() : ((this.bundle != null));
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 432 */       this.enabled = Boolean.valueOf(enabled);
/*     */     }
/*     */     
/*     */     public String getBundle() {
/* 436 */       return this.bundle;
/*     */     }
/*     */     
/*     */     public void setBundle(String bundle) {
/* 440 */       this.bundle = bundle;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Jedis
/*     */   {
/*     */     private final RedisProperties.Pool pool;
/*     */ 
/*     */ 
/*     */     
/*     */     public Jedis() {
/* 453 */       this.pool = new RedisProperties.Pool();
/*     */     }
/*     */     public RedisProperties.Pool getPool() {
/* 456 */       return this.pool;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Lettuce
/*     */   {
/* 469 */     private Duration shutdownTimeout = Duration.ofMillis(100L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String readFrom;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 479 */     private final RedisProperties.Pool pool = new RedisProperties.Pool();
/*     */     
/* 481 */     private final Cluster cluster = new Cluster();
/*     */     
/*     */     public Duration getShutdownTimeout() {
/* 484 */       return this.shutdownTimeout;
/*     */     }
/*     */     
/*     */     public void setShutdownTimeout(Duration shutdownTimeout) {
/* 488 */       this.shutdownTimeout = shutdownTimeout;
/*     */     }
/*     */     
/*     */     public void setReadFrom(String readFrom) {
/* 492 */       this.readFrom = readFrom;
/*     */     }
/*     */     
/*     */     public String getReadFrom() {
/* 496 */       return this.readFrom;
/*     */     }
/*     */     
/*     */     public RedisProperties.Pool getPool() {
/* 500 */       return this.pool;
/*     */     }
/*     */     
/*     */     public Cluster getCluster() {
/* 504 */       return this.cluster;
/*     */     }
/*     */     
/*     */     public static class Cluster
/*     */     {
/* 509 */       private final Refresh refresh = new Refresh();
/*     */       
/*     */       public Refresh getRefresh() {
/* 512 */         return this.refresh;
/*     */       }
/*     */       
/*     */       public static class Refresh
/*     */       {
/*     */         private boolean dynamicRefreshSources;
/*     */         private Duration period;
/*     */         private boolean adaptive;
/*     */         
/*     */         public Refresh() {
/* 522 */           this.dynamicRefreshSources = true;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isDynamicRefreshSources() {
/* 536 */           return this.dynamicRefreshSources;
/*     */         }
/*     */         
/*     */         public void setDynamicRefreshSources(boolean dynamicRefreshSources) {
/* 540 */           this.dynamicRefreshSources = dynamicRefreshSources;
/*     */         }
/*     */         
/*     */         public Duration getPeriod() {
/* 544 */           return this.period;
/*     */         }
/*     */         
/*     */         public void setPeriod(Duration period) {
/* 548 */           this.period = period;
/*     */         }
/*     */         
/*     */         public boolean isAdaptive() {
/* 552 */           return this.adaptive;
/*     */         }
/*     */         
/*     */         public void setAdaptive(boolean adaptive) {
/* 556 */           this.adaptive = adaptive; } } } } public static class Cluster { private final Refresh refresh = new Refresh(); public Refresh getRefresh() { return this.refresh; } public static class Refresh { private boolean dynamicRefreshSources; private Duration period; private boolean adaptive; public Refresh() { this.dynamicRefreshSources = true; } public void setAdaptive(boolean adaptive) { this.adaptive = adaptive; } public boolean isDynamicRefreshSources() { return this.dynamicRefreshSources; } public void setDynamicRefreshSources(boolean dynamicRefreshSources) { this.dynamicRefreshSources = dynamicRefreshSources; } public Duration getPeriod() { return this.period; } public void setPeriod(Duration period) { this.period = period; } public boolean isAdaptive() { return this.adaptive; } } } public static class Refresh { private boolean dynamicRefreshSources; private Duration period; private boolean adaptive; public Refresh() { this.dynamicRefreshSources = true; } public boolean isDynamicRefreshSources() { return this.dynamicRefreshSources; } public void setDynamicRefreshSources(boolean dynamicRefreshSources) { this.dynamicRefreshSources = dynamicRefreshSources; } public Duration getPeriod() { return this.period; } public void setPeriod(Duration period) { this.period = period; } public boolean isAdaptive() { return this.adaptive; } public void setAdaptive(boolean adaptive) { this.adaptive = adaptive; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */