/*     */ package org.springframework.boot.autoconfigure.data.web;
/*     */ 
/*     */ import org.springframework.data.web.config.EnableSpringDataWebSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pageable
/*     */ {
/*  52 */   private String pageParameter = "page";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private String sizeParameter = "size";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean oneIndexedParameters = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private String prefix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private String qualifierDelimiter = "_";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private int defaultPageSize = 20;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private int maxPageSize = 2000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private EnableSpringDataWebSupport.PageSerializationMode serializationMode = EnableSpringDataWebSupport.PageSerializationMode.DIRECT;
/*     */   
/*     */   public String getPageParameter() {
/*  92 */     return this.pageParameter;
/*     */   }
/*     */   
/*     */   public void setPageParameter(String pageParameter) {
/*  96 */     this.pageParameter = pageParameter;
/*     */   }
/*     */   
/*     */   public String getSizeParameter() {
/* 100 */     return this.sizeParameter;
/*     */   }
/*     */   
/*     */   public void setSizeParameter(String sizeParameter) {
/* 104 */     this.sizeParameter = sizeParameter;
/*     */   }
/*     */   
/*     */   public boolean isOneIndexedParameters() {
/* 108 */     return this.oneIndexedParameters;
/*     */   }
/*     */   
/*     */   public void setOneIndexedParameters(boolean oneIndexedParameters) {
/* 112 */     this.oneIndexedParameters = oneIndexedParameters;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 116 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 120 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */   public String getQualifierDelimiter() {
/* 124 */     return this.qualifierDelimiter;
/*     */   }
/*     */   
/*     */   public void setQualifierDelimiter(String qualifierDelimiter) {
/* 128 */     this.qualifierDelimiter = qualifierDelimiter;
/*     */   }
/*     */   
/*     */   public int getDefaultPageSize() {
/* 132 */     return this.defaultPageSize;
/*     */   }
/*     */   
/*     */   public void setDefaultPageSize(int defaultPageSize) {
/* 136 */     this.defaultPageSize = defaultPageSize;
/*     */   }
/*     */   
/*     */   public int getMaxPageSize() {
/* 140 */     return this.maxPageSize;
/*     */   }
/*     */   
/*     */   public void setMaxPageSize(int maxPageSize) {
/* 144 */     this.maxPageSize = maxPageSize;
/*     */   }
/*     */   
/*     */   public EnableSpringDataWebSupport.PageSerializationMode getSerializationMode() {
/* 148 */     return this.serializationMode;
/*     */   }
/*     */   
/*     */   public void setSerializationMode(EnableSpringDataWebSupport.PageSerializationMode serializationMode) {
/* 152 */     this.serializationMode = serializationMode;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\web\SpringDataWebProperties$Pageable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */