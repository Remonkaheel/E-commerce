/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPool;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnThreading;
/*     */ import org.springframework.boot.autoconfigure.thread.Threading;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
/*     */ import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnection;
/*     */ import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ import redis.clients.jedis.Jedis;
/*     */ import redis.clients.jedis.JedisPoolConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({GenericObjectPool.class, JedisConnection.class, Jedis.class})
/*     */ @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */ @ConditionalOnProperty(name = {"spring.data.redis.client-type"}, havingValue = "jedis", matchIfMissing = true)
/*     */ class JedisConnectionConfiguration
/*     */   extends RedisConnectionConfiguration
/*     */ {
/*     */   JedisConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisStandaloneConfiguration> standaloneConfigurationProvider, ObjectProvider<RedisSentinelConfiguration> sentinelConfiguration, ObjectProvider<RedisClusterConfiguration> clusterConfiguration, RedisConnectionDetails connectionDetails) {
/*  68 */     super(properties, connectionDetails, standaloneConfigurationProvider, sentinelConfiguration, clusterConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnThreading(Threading.PLATFORM)
/*     */   JedisConnectionFactory redisConnectionFactory(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/*  76 */     return createJedisConnectionFactory(builderCustomizers);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnThreading(Threading.VIRTUAL)
/*     */   JedisConnectionFactory redisConnectionFactoryVirtualThreads(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/*  83 */     JedisConnectionFactory factory = createJedisConnectionFactory(builderCustomizers);
/*  84 */     SimpleAsyncTaskExecutor executor = new SimpleAsyncTaskExecutor("redis-");
/*  85 */     executor.setVirtualThreads(true);
/*  86 */     factory.setExecutor((AsyncTaskExecutor)executor);
/*  87 */     return factory;
/*     */   }
/*     */ 
/*     */   
/*     */   private JedisConnectionFactory createJedisConnectionFactory(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/*  92 */     JedisClientConfiguration clientConfiguration = getJedisClientConfiguration(builderCustomizers);
/*  93 */     switch (this.mode) { default: throw new IncompatibleClassChangeError();case STANDALONE: case CLUSTER: case SENTINEL: break; }  return 
/*     */ 
/*     */       
/*  96 */       new JedisConnectionFactory(getSentinelConfig(), clientConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JedisClientConfiguration getJedisClientConfiguration(ObjectProvider<JedisClientConfigurationBuilderCustomizer> builderCustomizers) {
/* 102 */     JedisClientConfiguration.JedisClientConfigurationBuilder builder = applyProperties(JedisClientConfiguration.builder());
/* 103 */     applySslIfNeeded(builder);
/* 104 */     RedisProperties.Pool pool = getProperties().getJedis().getPool();
/* 105 */     if (isPoolEnabled(pool)) {
/* 106 */       applyPooling(pool, builder);
/*     */     }
/* 108 */     if (StringUtils.hasText(getProperties().getUrl())) {
/* 109 */       customizeConfigurationFromUrl(builder);
/*     */     }
/* 111 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 112 */     return builder.build();
/*     */   }
/*     */   
/*     */   private JedisClientConfiguration.JedisClientConfigurationBuilder applyProperties(JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 116 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 117 */     Objects.requireNonNull(builder); map.from(getProperties().getTimeout()).to(builder::readTimeout);
/* 118 */     Objects.requireNonNull(builder); map.from(getProperties().getConnectTimeout()).to(builder::connectTimeout);
/* 119 */     Objects.requireNonNull(builder); map.from(getProperties().getClientName()).whenHasText().to(builder::clientName);
/* 120 */     return builder;
/*     */   }
/*     */   
/*     */   private void applySslIfNeeded(JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 124 */     SslBundle sslBundle = getSslBundle();
/* 125 */     if (sslBundle == null) {
/*     */       return;
/*     */     }
/* 128 */     JedisClientConfiguration.JedisSslClientConfigurationBuilder sslBuilder = builder.useSsl();
/* 129 */     sslBuilder.sslSocketFactory(sslBundle.createSslContext().getSocketFactory());
/* 130 */     SslOptions sslOptions = sslBundle.getOptions();
/* 131 */     SSLParameters sslParameters = new SSLParameters();
/* 132 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 133 */     Objects.requireNonNull(sslParameters); map.from(sslOptions.getCiphers()).to(sslParameters::setCipherSuites);
/* 134 */     Objects.requireNonNull(sslParameters); map.from(sslOptions.getEnabledProtocols()).to(sslParameters::setProtocols);
/* 135 */     sslBuilder.sslParameters(sslParameters);
/*     */   }
/*     */ 
/*     */   
/*     */   private void applyPooling(RedisProperties.Pool pool, JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 140 */     builder.usePooling().poolConfig((GenericObjectPoolConfig)jedisPoolConfig(pool));
/*     */   }
/*     */   
/*     */   private JedisPoolConfig jedisPoolConfig(RedisProperties.Pool pool) {
/* 144 */     JedisPoolConfig config = new JedisPoolConfig();
/* 145 */     config.setMaxTotal(pool.getMaxActive());
/* 146 */     config.setMaxIdle(pool.getMaxIdle());
/* 147 */     config.setMinIdle(pool.getMinIdle());
/* 148 */     if (pool.getTimeBetweenEvictionRuns() != null) {
/* 149 */       config.setTimeBetweenEvictionRuns(pool.getTimeBetweenEvictionRuns());
/*     */     }
/* 151 */     if (pool.getMaxWait() != null) {
/* 152 */       config.setMaxWait(pool.getMaxWait());
/*     */     }
/* 154 */     return config;
/*     */   }
/*     */   
/*     */   private void customizeConfigurationFromUrl(JedisClientConfiguration.JedisClientConfigurationBuilder builder) {
/* 158 */     if (urlUsesSsl())
/* 159 */       builder.useSsl(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\JedisConnectionConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */