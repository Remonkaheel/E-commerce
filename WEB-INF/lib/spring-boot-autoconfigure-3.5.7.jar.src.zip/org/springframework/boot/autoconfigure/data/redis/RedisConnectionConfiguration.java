/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisNode;
/*     */ import org.springframework.data.redis.connection.RedisPassword;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RedisConnectionConfiguration
/*     */ {
/*  50 */   private static final boolean COMMONS_POOL2_AVAILABLE = ClassUtils.isPresent("org.apache.commons.pool2.ObjectPool", RedisConnectionConfiguration.class
/*  51 */       .getClassLoader());
/*     */ 
/*     */   
/*     */   private final RedisProperties properties;
/*     */ 
/*     */   
/*     */   private final RedisStandaloneConfiguration standaloneConfiguration;
/*     */   
/*     */   private final RedisSentinelConfiguration sentinelConfiguration;
/*     */   
/*     */   private final RedisClusterConfiguration clusterConfiguration;
/*     */   
/*     */   private final RedisConnectionDetails connectionDetails;
/*     */   
/*     */   protected final Mode mode;
/*     */ 
/*     */   
/*     */   protected RedisConnectionConfiguration(RedisProperties properties, RedisConnectionDetails connectionDetails, ObjectProvider<RedisStandaloneConfiguration> standaloneConfigurationProvider, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider) {
/*  69 */     this.properties = properties;
/*  70 */     this.standaloneConfiguration = (RedisStandaloneConfiguration)standaloneConfigurationProvider.getIfAvailable();
/*  71 */     this.sentinelConfiguration = (RedisSentinelConfiguration)sentinelConfigurationProvider.getIfAvailable();
/*  72 */     this.clusterConfiguration = (RedisClusterConfiguration)clusterConfigurationProvider.getIfAvailable();
/*  73 */     this.connectionDetails = connectionDetails;
/*  74 */     this.mode = determineMode();
/*     */   }
/*     */   
/*     */   protected final RedisStandaloneConfiguration getStandaloneConfig() {
/*  78 */     if (this.standaloneConfiguration != null) {
/*  79 */       return this.standaloneConfiguration;
/*     */     }
/*  81 */     RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
/*  82 */     config.setHostName(this.connectionDetails.getStandalone().getHost());
/*  83 */     config.setPort(this.connectionDetails.getStandalone().getPort());
/*  84 */     config.setUsername(this.connectionDetails.getUsername());
/*  85 */     config.setPassword(RedisPassword.of(this.connectionDetails.getPassword()));
/*  86 */     config.setDatabase(this.connectionDetails.getStandalone().getDatabase());
/*  87 */     return config;
/*     */   }
/*     */   
/*     */   protected final RedisSentinelConfiguration getSentinelConfig() {
/*  91 */     if (this.sentinelConfiguration != null) {
/*  92 */       return this.sentinelConfiguration;
/*     */     }
/*  94 */     if (this.connectionDetails.getSentinel() != null) {
/*  95 */       RedisSentinelConfiguration config = new RedisSentinelConfiguration();
/*  96 */       config.master(this.connectionDetails.getSentinel().getMaster());
/*  97 */       config.setSentinels(createSentinels(this.connectionDetails.getSentinel()));
/*  98 */       config.setUsername(this.connectionDetails.getUsername());
/*  99 */       String password = this.connectionDetails.getPassword();
/* 100 */       if (password != null) {
/* 101 */         config.setPassword(RedisPassword.of(password));
/*     */       }
/* 103 */       config.setSentinelUsername(this.connectionDetails.getSentinel().getUsername());
/* 104 */       String sentinelPassword = this.connectionDetails.getSentinel().getPassword();
/* 105 */       if (sentinelPassword != null) {
/* 106 */         config.setSentinelPassword(RedisPassword.of(sentinelPassword));
/*     */       }
/* 108 */       config.setDatabase(this.connectionDetails.getSentinel().getDatabase());
/* 109 */       return config;
/*     */     } 
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RedisClusterConfiguration getClusterConfiguration() {
/* 119 */     if (this.clusterConfiguration != null) {
/* 120 */       return this.clusterConfiguration;
/*     */     }
/* 122 */     RedisProperties.Cluster clusterProperties = this.properties.getCluster();
/* 123 */     if (this.connectionDetails.getCluster() != null) {
/* 124 */       RedisClusterConfiguration config = new RedisClusterConfiguration();
/* 125 */       config.setClusterNodes(getNodes(this.connectionDetails.getCluster()));
/* 126 */       if (clusterProperties != null && clusterProperties.getMaxRedirects() != null) {
/* 127 */         config.setMaxRedirects(clusterProperties.getMaxRedirects().intValue());
/*     */       }
/* 129 */       config.setUsername(this.connectionDetails.getUsername());
/* 130 */       String password = this.connectionDetails.getPassword();
/* 131 */       if (password != null) {
/* 132 */         config.setPassword(RedisPassword.of(password));
/*     */       }
/* 134 */       return config;
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   private List<RedisNode> getNodes(RedisConnectionDetails.Cluster cluster) {
/* 140 */     return cluster.getNodes().stream().map(this::asRedisNode).toList();
/*     */   }
/*     */   
/*     */   private RedisNode asRedisNode(RedisConnectionDetails.Node node) {
/* 144 */     return new RedisNode(node.host(), node.port());
/*     */   }
/*     */   
/*     */   protected final RedisProperties getProperties() {
/* 148 */     return this.properties;
/*     */   }
/*     */   
/*     */   protected SslBundle getSslBundle() {
/* 152 */     switch (this.mode) { default: throw new IncompatibleClassChangeError();case STANDALONE: return 
/* 153 */           (this.connectionDetails.getStandalone() != null) ? 
/* 154 */           this.connectionDetails.getStandalone().getSslBundle() : null;
/* 155 */       case CLUSTER: return (this.connectionDetails.getCluster() != null) ? 
/* 156 */           this.connectionDetails.getCluster().getSslBundle() : null;
/* 157 */       case SENTINEL: break; }  return (this.connectionDetails.getSentinel() != null) ? 
/* 158 */       this.connectionDetails.getSentinel().getSslBundle() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean isSslEnabled() {
/* 163 */     return getProperties().getSsl().isEnabled();
/*     */   }
/*     */   
/*     */   protected final boolean urlUsesSsl() {
/* 167 */     return RedisUrl.of(this.properties.getUrl()).useSsl();
/*     */   }
/*     */   
/*     */   protected boolean isPoolEnabled(RedisProperties.Pool pool) {
/* 171 */     Boolean enabled = pool.getEnabled();
/* 172 */     return (enabled != null) ? enabled.booleanValue() : COMMONS_POOL2_AVAILABLE;
/*     */   }
/*     */   
/*     */   private List<RedisNode> createSentinels(RedisConnectionDetails.Sentinel sentinel) {
/* 176 */     List<RedisNode> nodes = new ArrayList<>();
/* 177 */     for (RedisConnectionDetails.Node node : sentinel.getNodes()) {
/* 178 */       nodes.add(asRedisNode(node));
/*     */     }
/* 180 */     return nodes;
/*     */   }
/*     */   
/*     */   protected final RedisConnectionDetails getConnectionDetails() {
/* 184 */     return this.connectionDetails;
/*     */   }
/*     */   
/*     */   private Mode determineMode() {
/* 188 */     if (getSentinelConfig() != null) {
/* 189 */       return Mode.SENTINEL;
/*     */     }
/* 191 */     if (getClusterConfiguration() != null) {
/* 192 */       return Mode.CLUSTER;
/*     */     }
/* 194 */     return Mode.STANDALONE;
/*     */   }
/*     */   
/*     */   enum Mode
/*     */   {
/* 199 */     STANDALONE, CLUSTER, SENTINEL;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisConnectionConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */