package org.springframework.boot.autoconfigure.data.r2dbc;

import io.r2dbc.spi.ConnectionFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.r2dbc.repository.support.R2dbcRepositoryFactoryBean;
import org.springframework.r2dbc.core.DatabaseClient;

@AutoConfiguration(after = {R2dbcDataAutoConfiguration.class})
@ConditionalOnClass({ConnectionFactory.class, R2dbcRepository.class})
@ConditionalOnBean({DatabaseClient.class})
@ConditionalOnBooleanProperty(name = {"spring.data.r2dbc.repositories.enabled"}, matchIfMissing = true)
@ConditionalOnMissingBean({R2dbcRepositoryFactoryBean.class})
@Import({R2dbcRepositoriesAutoConfigureRegistrar.class})
public class R2dbcRepositoriesAutoConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\r2dbc\R2dbcRepositoriesAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */