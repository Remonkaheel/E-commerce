/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.client.ClientSession;
/*     */ import com.mongodb.client.MongoDatabase;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoConnectionDetails;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.mongodb.MongoDatabaseFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GridFsMongoDatabaseFactory
/*     */   implements MongoDatabaseFactory
/*     */ {
/*     */   private final MongoDatabaseFactory mongoDatabaseFactory;
/*     */   private final MongoConnectionDetails connectionDetails;
/*     */   
/*     */   GridFsMongoDatabaseFactory(MongoDatabaseFactory mongoDatabaseFactory, MongoConnectionDetails connectionDetails) {
/*  80 */     Assert.notNull(mongoDatabaseFactory, "'mongoDatabaseFactory' must not be null");
/*  81 */     Assert.notNull(connectionDetails, "'connectionDetails' must not be null");
/*  82 */     this.mongoDatabaseFactory = mongoDatabaseFactory;
/*  83 */     this.connectionDetails = connectionDetails;
/*     */   }
/*     */ 
/*     */   
/*     */   public MongoDatabase getMongoDatabase() throws DataAccessException {
/*  88 */     String gridFsDatabase = getGridFsDatabase(this.connectionDetails);
/*  89 */     if (StringUtils.hasText(gridFsDatabase)) {
/*  90 */       return this.mongoDatabaseFactory.getMongoDatabase(gridFsDatabase);
/*     */     }
/*  92 */     return this.mongoDatabaseFactory.getMongoDatabase();
/*     */   }
/*     */ 
/*     */   
/*     */   public MongoDatabase getMongoDatabase(String dbName) throws DataAccessException {
/*  97 */     return this.mongoDatabaseFactory.getMongoDatabase(dbName);
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistenceExceptionTranslator getExceptionTranslator() {
/* 102 */     return this.mongoDatabaseFactory.getExceptionTranslator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientSession getSession(ClientSessionOptions options) {
/* 107 */     return this.mongoDatabaseFactory.getSession(options);
/*     */   }
/*     */ 
/*     */   
/*     */   public MongoDatabaseFactory withSession(ClientSession session) {
/* 112 */     return this.mongoDatabaseFactory.withSession(session);
/*     */   }
/*     */   
/*     */   private String getGridFsDatabase(MongoConnectionDetails connectionDetails) {
/* 116 */     return (connectionDetails.getGridFs() != null) ? connectionDetails.getGridFs().getDatabase() : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDatabaseFactoryDependentConfiguration$GridFsMongoDatabaseFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */