package org.springframework.boot.autoconfigure.data.cassandra;

import org.springframework.data.cassandra.repository.config.EnableReactiveCassandraRepositories;

@EnableReactiveCassandraRepositories
final class EnableReactiveCassandraRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraReactiveRepositoriesRegistrar$EnableReactiveCassandraRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */