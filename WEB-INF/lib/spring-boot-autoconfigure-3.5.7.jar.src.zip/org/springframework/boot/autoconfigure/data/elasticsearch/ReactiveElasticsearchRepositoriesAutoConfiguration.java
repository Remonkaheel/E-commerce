package org.springframework.boot.autoconfigure.data.elasticsearch;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.elasticsearch.client.elc.ReactiveElasticsearchClient;
import org.springframework.data.elasticsearch.repository.ReactiveElasticsearchRepository;
import org.springframework.data.elasticsearch.repository.support.ReactiveElasticsearchRepositoryFactoryBean;
import reactor.core.publisher.Mono;

@AutoConfiguration
@ConditionalOnClass({ReactiveElasticsearchClient.class, ReactiveElasticsearchRepository.class, Mono.class})
@ConditionalOnBooleanProperty(name = {"spring.data.elasticsearch.repositories.enabled"}, matchIfMissing = true)
@ConditionalOnMissingBean({ReactiveElasticsearchRepositoryFactoryBean.class})
@Import({ReactiveElasticsearchRepositoriesRegistrar.class})
public class ReactiveElasticsearchRepositoriesAutoConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ReactiveElasticsearchRepositoriesAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */