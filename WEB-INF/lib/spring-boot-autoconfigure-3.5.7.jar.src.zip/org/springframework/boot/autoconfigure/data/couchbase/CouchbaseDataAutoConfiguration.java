/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import com.couchbase.client.java.Bucket;
/*    */ import jakarta.validation.Validator;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.autoconfigure.couchbase.CouchbaseAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.couchbase.core.mapping.event.ValidatingCouchbaseEventListener;
/*    */ import org.springframework.data.couchbase.repository.CouchbaseRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {CouchbaseAutoConfiguration.class, ValidationAutoConfiguration.class})
/*    */ @ConditionalOnClass({Bucket.class, CouchbaseRepository.class})
/*    */ @EnableConfigurationProperties({CouchbaseDataProperties.class})
/*    */ @Import({CouchbaseDataConfiguration.class, CouchbaseClientFactoryConfiguration.class, CouchbaseClientFactoryDependentConfiguration.class})
/*    */ public class CouchbaseDataAutoConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({Validator.class})
/*    */   public static class ValidationConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnSingleCandidate(Validator.class)
/*    */     public ValidatingCouchbaseEventListener validationEventListener(Validator validator) {
/* 56 */       return new ValidatingCouchbaseEventListener(validator);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */