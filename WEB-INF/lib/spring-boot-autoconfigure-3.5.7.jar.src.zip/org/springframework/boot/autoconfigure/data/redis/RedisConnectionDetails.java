/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RedisConnectionDetails
/*     */   extends ConnectionDetails
/*     */ {
/*     */   default String getUsername() {
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getPassword() {
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Standalone getStandalone() {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Sentinel getSentinel() {
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Cluster getCluster() {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Standalone
/*     */   {
/*     */     String getHost();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int getPort();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default int getDatabase() {
/*  99 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default SslBundle getSslBundle() {
/* 108 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Standalone of(String host, int port) {
/* 118 */       return of(host, port, 0, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Standalone of(String host, int port, SslBundle sslBundle) {
/* 130 */       return of(host, port, 0, sslBundle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Standalone of(String host, int port, int database) {
/* 141 */       return of(host, port, database, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Standalone of(final String host, final int port, final int database, final SslBundle sslBundle)
/*     */     {
/* 154 */       Assert.hasLength(host, "'host' must not be empty");
/* 155 */       return new Standalone()
/*     */         {
/*     */           public String getHost()
/*     */           {
/* 159 */             return host;
/*     */           }
/*     */ 
/*     */           
/*     */           public int getPort() {
/* 164 */             return port;
/*     */           }
/*     */ 
/*     */           
/*     */           public int getDatabase() {
/* 169 */             return database;
/*     */           }
/*     */           
/*     */           public SslBundle getSslBundle()
/*     */           {
/* 174 */             return sslBundle; } }; } } class null implements Standalone { public SslBundle getSslBundle() { return sslBundle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getHost() {
/*     */       return host;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getPort() {
/*     */       return port;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getDatabase() {
/*     */       return database;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Sentinel
/*     */   {
/*     */     int getDatabase();
/*     */ 
/*     */ 
/*     */     
/*     */     String getMaster();
/*     */ 
/*     */ 
/*     */     
/*     */     List<RedisConnectionDetails.Node> getNodes();
/*     */ 
/*     */ 
/*     */     
/*     */     String getUsername();
/*     */ 
/*     */ 
/*     */     
/*     */     String getPassword();
/*     */ 
/*     */ 
/*     */     
/*     */     default SslBundle getSslBundle() {
/* 222 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Cluster
/*     */   {
/*     */     List<RedisConnectionDetails.Node> getNodes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default SslBundle getSslBundle() {
/* 245 */       return null;
/*     */     } }
/*     */   public static final class Node extends Record { private final String host; private final int port;
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #256	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;
/*     */     }
/*     */     
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #256	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;
/*     */     }
/*     */     
/* 256 */     public Node(String host, int port) { this.host = host; this.port = port; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #256	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisConnectionDetails$Node;
/* 256 */       //   0	8	1	o	Ljava/lang/Object; } public String host() { return this.host; } public int port() { return this.port; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */