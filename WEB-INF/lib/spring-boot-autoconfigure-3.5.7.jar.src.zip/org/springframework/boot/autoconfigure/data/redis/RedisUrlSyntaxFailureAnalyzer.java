/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RedisUrlSyntaxFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<RedisUrlSyntaxException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, RedisUrlSyntaxException cause) {
/*    */     try {
/* 36 */       URI uri = new URI(cause.getUrl());
/* 37 */       if ("redis-sentinel".equals(uri.getScheme())) {
/* 38 */         return new FailureAnalysis(getUnsupportedSchemeDescription(cause.getUrl(), uri.getScheme()), "Use spring.data.redis.sentinel properties instead of spring.data.redis.url to configure Redis sentinel addresses.", cause);
/*    */       }
/*    */ 
/*    */       
/* 42 */       if ("redis-socket".equals(uri.getScheme())) {
/* 43 */         return new FailureAnalysis(getUnsupportedSchemeDescription(cause.getUrl(), uri.getScheme()), "Configure the appropriate Spring Data Redis connection beans directly instead of setting the property 'spring.data.redis.url'.", cause);
/*    */       }
/*    */ 
/*    */       
/* 47 */       if (!"redis".equals(uri.getScheme()) && !"rediss".equals(uri.getScheme())) {
/* 48 */         return new FailureAnalysis(getUnsupportedSchemeDescription(cause.getUrl(), uri.getScheme()), "Use the scheme 'redis://' for insecure or 'rediss://' for secure Redis standalone configuration.", cause);
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 53 */     catch (URISyntaxException uRISyntaxException) {}
/*    */ 
/*    */     
/* 56 */     return new FailureAnalysis(getDefaultDescription(cause.getUrl()), "Review the value of the property 'spring.data.redis.url'.", cause);
/*    */   }
/*    */ 
/*    */   
/*    */   private String getDefaultDescription(String url) {
/* 61 */     return "The URL '" + url + "' is not valid for configuring Spring Data Redis. ";
/*    */   }
/*    */   
/*    */   private String getUnsupportedSchemeDescription(String url, String scheme) {
/* 65 */     return getDefaultDescription(url) + "The scheme '" + getDefaultDescription(url) + "' is not supported.";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisUrlSyntaxFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */