package org.springframework.boot.autoconfigure.data.neo4j;

import org.neo4j.driver.Driver;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.data.ConditionalOnRepositoryType;
import org.springframework.boot.autoconfigure.data.RepositoryType;
import org.springframework.context.annotation.Import;
import org.springframework.data.neo4j.repository.ReactiveNeo4jRepository;
import org.springframework.data.neo4j.repository.config.ReactiveNeo4jRepositoryConfigurationExtension;
import org.springframework.data.neo4j.repository.support.ReactiveNeo4jRepositoryFactoryBean;
import reactor.core.publisher.Flux;

@AutoConfiguration(after = {Neo4jReactiveDataAutoConfiguration.class})
@ConditionalOnClass({Driver.class, ReactiveNeo4jRepository.class, Flux.class})
@ConditionalOnMissingBean({ReactiveNeo4jRepositoryFactoryBean.class, ReactiveNeo4jRepositoryConfigurationExtension.class})
@ConditionalOnRepositoryType(store = "neo4j", type = RepositoryType.REACTIVE)
@Import({Neo4jReactiveRepositoriesRegistrar.class})
public class Neo4jReactiveRepositoriesAutoConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jReactiveRepositoriesAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */