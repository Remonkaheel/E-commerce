/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.client.MongoClient;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoConnectionDetails;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.boot.autoconfigure.mongo.PropertiesMongoConnectionDetails;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.ssl.SslBundles;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.mongodb.core.MongoTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {MongoAutoConfiguration.class})
/*    */ @ConditionalOnClass({MongoClient.class, MongoTemplate.class})
/*    */ @EnableConfigurationProperties({MongoProperties.class})
/*    */ @Import({MongoDataConfiguration.class, MongoDatabaseFactoryConfiguration.class, MongoDatabaseFactoryDependentConfiguration.class})
/*    */ public class MongoDataAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({MongoConnectionDetails.class})
/*    */   PropertiesMongoConnectionDetails mongoConnectionDetails(MongoProperties properties, ObjectProvider<SslBundles> sslBundles) {
/* 66 */     return new PropertiesMongoConnectionDetails(properties, (SslBundles)sslBundles.getIfAvailable());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */