/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertiesSentinel
/*     */   implements RedisConnectionDetails.Sentinel
/*     */ {
/*     */   private final int database;
/*     */   private final RedisProperties.Sentinel properties;
/*     */   
/*     */   PropertiesSentinel(int database, RedisProperties.Sentinel properties) {
/* 140 */     this.database = database;
/* 141 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDatabase() {
/* 146 */     return this.database;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMaster() {
/* 151 */     return this.properties.getMaster();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<RedisConnectionDetails.Node> getNodes() {
/* 156 */     return PropertiesRedisConnectionDetails.this.asNodes(this.properties.getNodes());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 161 */     return this.properties.getUsername();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 166 */     return this.properties.getPassword();
/*     */   }
/*     */ 
/*     */   
/*     */   public SslBundle getSslBundle() {
/* 171 */     return PropertiesRedisConnectionDetails.this.getSslBundle();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\PropertiesRedisConnectionDetails$PropertiesSentinel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */