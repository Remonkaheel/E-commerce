/*     */ package org.springframework.boot.autoconfigure.data.jdbc;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.Lazy;
/*     */ import org.springframework.data.jdbc.core.JdbcAggregateTemplate;
/*     */ import org.springframework.data.jdbc.core.convert.DataAccessStrategy;
/*     */ import org.springframework.data.jdbc.core.convert.JdbcConverter;
/*     */ import org.springframework.data.jdbc.core.convert.JdbcCustomConversions;
/*     */ import org.springframework.data.jdbc.core.convert.RelationResolver;
/*     */ import org.springframework.data.jdbc.core.mapping.JdbcMappingContext;
/*     */ import org.springframework.data.jdbc.repository.config.AbstractJdbcConfiguration;
/*     */ import org.springframework.data.jdbc.repository.config.JdbcRepositoryConfigExtension;
/*     */ import org.springframework.data.relational.RelationalManagedTypes;
/*     */ import org.springframework.data.relational.core.dialect.Dialect;
/*     */ import org.springframework.data.relational.core.mapping.NamingStrategy;
/*     */ import org.springframework.data.relational.core.mapping.Table;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {JdbcTemplateAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
/*     */ @ConditionalOnBean({NamedParameterJdbcOperations.class, PlatformTransactionManager.class})
/*     */ @ConditionalOnClass({NamedParameterJdbcOperations.class, AbstractJdbcConfiguration.class})
/*     */ @ConditionalOnBooleanProperty(name = {"spring.data.jdbc.repositories.enabled"}, matchIfMissing = true)
/*     */ @EnableConfigurationProperties({JdbcDataProperties.class})
/*     */ public class JdbcRepositoriesAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({JdbcRepositoryConfigExtension.class})
/*     */   @Import({JdbcRepositoriesRegistrar.class})
/*     */   static class JdbcRepositoriesConfiguration {}
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({AbstractJdbcConfiguration.class})
/*     */   static class SpringBootJdbcConfiguration
/*     */     extends AbstractJdbcConfiguration
/*     */   {
/*     */     private final ApplicationContext applicationContext;
/*     */     private final JdbcDataProperties properties;
/*     */     
/*     */     SpringBootJdbcConfiguration(ApplicationContext applicationContext, JdbcDataProperties properties) {
/*  90 */       this.applicationContext = applicationContext;
/*  91 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Set<Class<?>> getInitialEntitySet() throws ClassNotFoundException {
/*  96 */       return (new EntityScanner(this.applicationContext)).scan(new Class[] { Table.class });
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public RelationalManagedTypes jdbcManagedTypes() throws ClassNotFoundException {
/* 103 */       return super.jdbcManagedTypes();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public JdbcMappingContext jdbcMappingContext(Optional<NamingStrategy> namingStrategy, JdbcCustomConversions customConversions, RelationalManagedTypes jdbcManagedTypes) {
/* 111 */       return super.jdbcMappingContext(namingStrategy, customConversions, jdbcManagedTypes);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public JdbcConverter jdbcConverter(JdbcMappingContext mappingContext, NamedParameterJdbcOperations operations, @Lazy RelationResolver relationResolver, JdbcCustomConversions conversions, Dialect dialect) {
/* 119 */       return super.jdbcConverter(mappingContext, operations, relationResolver, conversions, dialect);
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public JdbcCustomConversions jdbcCustomConversions() {
/* 126 */       return super.jdbcCustomConversions();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public JdbcAggregateTemplate jdbcAggregateTemplate(ApplicationContext applicationContext, JdbcMappingContext mappingContext, JdbcConverter converter, DataAccessStrategy dataAccessStrategy) {
/* 134 */       return super.jdbcAggregateTemplate(applicationContext, mappingContext, converter, dataAccessStrategy);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public DataAccessStrategy dataAccessStrategyBean(NamedParameterJdbcOperations operations, JdbcConverter jdbcConverter, JdbcMappingContext context, Dialect dialect) {
/* 142 */       return super.dataAccessStrategyBean(operations, jdbcConverter, context, dialect);
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public Dialect jdbcDialect(NamedParameterJdbcOperations operations) {
/* 149 */       JdbcDatabaseDialect dialect = this.properties.getDialect();
/* 150 */       return (dialect != null) ? dialect.getDialect() : super.jdbcDialect(operations);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jdbc\JdbcRepositoriesAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */