/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pool
/*     */ {
/*     */   private Boolean enabled;
/* 242 */   private int maxIdle = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   private int minIdle = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   private int maxActive = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   private Duration maxWait = Duration.ofMillis(-1L);
/*     */ 
/*     */ 
/*     */   
/*     */   private Duration timeBetweenEvictionRuns;
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getEnabled() {
/* 271 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(Boolean enabled) {
/* 275 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public int getMaxIdle() {
/* 279 */     return this.maxIdle;
/*     */   }
/*     */   
/*     */   public void setMaxIdle(int maxIdle) {
/* 283 */     this.maxIdle = maxIdle;
/*     */   }
/*     */   
/*     */   public int getMinIdle() {
/* 287 */     return this.minIdle;
/*     */   }
/*     */   
/*     */   public void setMinIdle(int minIdle) {
/* 291 */     this.minIdle = minIdle;
/*     */   }
/*     */   
/*     */   public int getMaxActive() {
/* 295 */     return this.maxActive;
/*     */   }
/*     */   
/*     */   public void setMaxActive(int maxActive) {
/* 299 */     this.maxActive = maxActive;
/*     */   }
/*     */   
/*     */   public Duration getMaxWait() {
/* 303 */     return this.maxWait;
/*     */   }
/*     */   
/*     */   public void setMaxWait(Duration maxWait) {
/* 307 */     this.maxWait = maxWait;
/*     */   }
/*     */   
/*     */   public Duration getTimeBetweenEvictionRuns() {
/* 311 */     return this.timeBetweenEvictionRuns;
/*     */   }
/*     */   
/*     */   public void setTimeBetweenEvictionRuns(Duration timeBetweenEvictionRuns) {
/* 315 */     this.timeBetweenEvictionRuns = timeBetweenEvictionRuns;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisProperties$Pool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */