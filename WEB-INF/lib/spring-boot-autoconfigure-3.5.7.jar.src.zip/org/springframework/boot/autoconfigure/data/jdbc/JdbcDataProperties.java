/*    */ package org.springframework.boot.autoconfigure.data.jdbc;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.data.jdbc")
/*    */ public class JdbcDataProperties
/*    */ {
/*    */   private JdbcDatabaseDialect dialect;
/*    */   
/*    */   public JdbcDatabaseDialect getDialect() {
/* 37 */     return this.dialect;
/*    */   }
/*    */   
/*    */   public void setDialect(JdbcDatabaseDialect dialect) {
/* 41 */     this.dialect = dialect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jdbc\JdbcDataProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */