/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import io.lettuce.core.ClientOptions;
/*     */ import io.lettuce.core.ReadFrom;
/*     */ import io.lettuce.core.RedisClient;
/*     */ import io.lettuce.core.SocketOptions;
/*     */ import io.lettuce.core.SslOptions;
/*     */ import io.lettuce.core.TimeoutOptions;
/*     */ import io.lettuce.core.api.StatefulConnection;
/*     */ import io.lettuce.core.cluster.ClusterClientOptions;
/*     */ import io.lettuce.core.cluster.ClusterTopologyRefreshOptions;
/*     */ import io.lettuce.core.resource.ClientResources;
/*     */ import io.lettuce.core.resource.DefaultClientResources;
/*     */ import java.time.Duration;
/*     */ import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnThreading;
/*     */ import org.springframework.boot.autoconfigure.thread.Threading;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
/*     */ import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
/*     */ import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
/*     */ import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({RedisClient.class})
/*     */ @ConditionalOnProperty(name = {"spring.data.redis.client-type"}, havingValue = "lettuce", matchIfMissing = true)
/*     */ class LettuceConnectionConfiguration
/*     */   extends RedisConnectionConfiguration
/*     */ {
/*     */   LettuceConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisStandaloneConfiguration> standaloneConfigurationProvider, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider, RedisConnectionDetails connectionDetails) {
/*  76 */     super(properties, connectionDetails, standaloneConfigurationProvider, sentinelConfigurationProvider, clusterConfigurationProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(destroyMethod = "shutdown")
/*     */   @ConditionalOnMissingBean({ClientResources.class})
/*     */   DefaultClientResources lettuceClientResources(ObjectProvider<ClientResourcesBuilderCustomizer> customizers) {
/*  83 */     DefaultClientResources.Builder builder = DefaultClientResources.builder();
/*  84 */     customizers.orderedStream().forEach(customizer -> customizer.customize((ClientResources.Builder)builder));
/*  85 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */   @ConditionalOnThreading(Threading.PLATFORM)
/*     */   LettuceConnectionFactory redisConnectionFactory(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> clientConfigurationBuilderCustomizers, ObjectProvider<LettuceClientOptionsBuilderCustomizer> clientOptionsBuilderCustomizers, ClientResources clientResources) {
/*  95 */     return createConnectionFactory(clientConfigurationBuilderCustomizers, clientOptionsBuilderCustomizers, clientResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({RedisConnectionFactory.class})
/*     */   @ConditionalOnThreading(Threading.VIRTUAL)
/*     */   LettuceConnectionFactory redisConnectionFactoryVirtualThreads(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> clientConfigurationBuilderCustomizers, ObjectProvider<LettuceClientOptionsBuilderCustomizer> clientOptionsBuilderCustomizers, ClientResources clientResources) {
/* 106 */     LettuceConnectionFactory factory = createConnectionFactory(clientConfigurationBuilderCustomizers, clientOptionsBuilderCustomizers, clientResources);
/*     */     
/* 108 */     SimpleAsyncTaskExecutor executor = new SimpleAsyncTaskExecutor("redis-");
/* 109 */     executor.setVirtualThreads(true);
/* 110 */     factory.setExecutor((AsyncTaskExecutor)executor);
/* 111 */     return factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LettuceConnectionFactory createConnectionFactory(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> clientConfigurationBuilderCustomizers, ObjectProvider<LettuceClientOptionsBuilderCustomizer> clientOptionsBuilderCustomizers, ClientResources clientResources) {
/* 118 */     LettuceClientConfiguration clientConfiguration = getLettuceClientConfiguration(clientConfigurationBuilderCustomizers, clientOptionsBuilderCustomizers, clientResources, 
/*     */         
/* 120 */         getProperties().getLettuce().getPool());
/* 121 */     switch (this.mode) { default: throw new IncompatibleClassChangeError();case STANDALONE: case CLUSTER: case SENTINEL: break; }  return 
/*     */ 
/*     */       
/* 124 */       new LettuceConnectionFactory(getSentinelConfig(), clientConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LettuceClientConfiguration getLettuceClientConfiguration(ObjectProvider<LettuceClientConfigurationBuilderCustomizer> clientConfigurationBuilderCustomizers, ObjectProvider<LettuceClientOptionsBuilderCustomizer> clientOptionsBuilderCustomizers, ClientResources clientResources, RedisProperties.Pool pool) {
/* 132 */     LettuceClientConfiguration.LettuceClientConfigurationBuilder builder = createBuilder(pool);
/* 133 */     SslBundle sslBundle = getSslBundle();
/* 134 */     applyProperties(builder, sslBundle);
/* 135 */     if (StringUtils.hasText(getProperties().getUrl())) {
/* 136 */       customizeConfigurationFromUrl(builder);
/*     */     }
/* 138 */     builder.clientOptions(createClientOptions(clientOptionsBuilderCustomizers, sslBundle));
/* 139 */     builder.clientResources(clientResources);
/* 140 */     clientConfigurationBuilderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 141 */     return builder.build();
/*     */   }
/*     */   
/*     */   private LettuceClientConfiguration.LettuceClientConfigurationBuilder createBuilder(RedisProperties.Pool pool) {
/* 145 */     if (isPoolEnabled(pool)) {
/* 146 */       return (new PoolBuilderFactory()).createBuilder(pool);
/*     */     }
/* 148 */     return LettuceClientConfiguration.builder();
/*     */   }
/*     */   
/*     */   private void applyProperties(LettuceClientConfiguration.LettuceClientConfigurationBuilder builder, SslBundle sslBundle) {
/* 152 */     if (sslBundle != null) {
/* 153 */       builder.useSsl();
/*     */     }
/* 155 */     if (getProperties().getTimeout() != null) {
/* 156 */       builder.commandTimeout(getProperties().getTimeout());
/*     */     }
/* 158 */     if (getProperties().getLettuce() != null) {
/* 159 */       RedisProperties.Lettuce lettuce = getProperties().getLettuce();
/* 160 */       if (lettuce.getShutdownTimeout() != null && !lettuce.getShutdownTimeout().isZero()) {
/* 161 */         builder.shutdownTimeout(getProperties().getLettuce().getShutdownTimeout());
/*     */       }
/* 163 */       String readFrom = lettuce.getReadFrom();
/* 164 */       if (readFrom != null) {
/* 165 */         builder.readFrom(getReadFrom(readFrom));
/*     */       }
/*     */     } 
/* 168 */     if (StringUtils.hasText(getProperties().getClientName())) {
/* 169 */       builder.clientName(getProperties().getClientName());
/*     */     }
/*     */   }
/*     */   
/*     */   private ReadFrom getReadFrom(String readFrom) {
/* 174 */     int index = readFrom.indexOf(':');
/* 175 */     if (index == -1) {
/* 176 */       return ReadFrom.valueOf(getCanonicalReadFromName(readFrom));
/*     */     }
/* 178 */     String name = getCanonicalReadFromName(readFrom.substring(0, index));
/* 179 */     String value = readFrom.substring(index + 1);
/* 180 */     return ReadFrom.valueOf(name + ":" + name);
/*     */   }
/*     */   
/*     */   private String getCanonicalReadFromName(String name) {
/* 184 */     StringBuilder canonicalName = new StringBuilder(name.length());
/* 185 */     name.chars()
/* 186 */       .filter(Character::isLetterOrDigit)
/* 187 */       .map(Character::toLowerCase)
/* 188 */       .forEach(c -> canonicalName.append((char)c));
/* 189 */     return canonicalName.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ClientOptions createClientOptions(ObjectProvider<LettuceClientOptionsBuilderCustomizer> clientConfigurationBuilderCustomizers, SslBundle sslBundle) {
/* 195 */     ClientOptions.Builder builder = initializeClientOptionsBuilder();
/* 196 */     Duration connectTimeout = getProperties().getConnectTimeout();
/* 197 */     if (connectTimeout != null) {
/* 198 */       builder.socketOptions(SocketOptions.builder().connectTimeout(connectTimeout).build());
/*     */     }
/* 200 */     if (sslBundle != null) {
/* 201 */       SslOptions.Builder sslOptionsBuilder = SslOptions.builder();
/* 202 */       sslOptionsBuilder.keyManager(sslBundle.getManagers().getKeyManagerFactory());
/* 203 */       sslOptionsBuilder.trustManager(sslBundle.getManagers().getTrustManagerFactory());
/* 204 */       SslOptions sslOptions = sslBundle.getOptions();
/* 205 */       if (sslOptions.getCiphers() != null) {
/* 206 */         sslOptionsBuilder.cipherSuites(sslOptions.getCiphers());
/*     */       }
/* 208 */       if (sslOptions.getEnabledProtocols() != null) {
/* 209 */         sslOptionsBuilder.protocols(sslOptions.getEnabledProtocols());
/*     */       }
/* 211 */       builder.sslOptions(sslOptionsBuilder.build());
/*     */     } 
/* 213 */     builder.timeoutOptions(TimeoutOptions.enabled());
/* 214 */     clientConfigurationBuilderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 215 */     return builder.build();
/*     */   }
/*     */   
/*     */   private ClientOptions.Builder initializeClientOptionsBuilder() {
/* 219 */     if (getProperties().getCluster() != null) {
/* 220 */       ClusterClientOptions.Builder builder = ClusterClientOptions.builder();
/* 221 */       RedisProperties.Lettuce.Cluster.Refresh refreshProperties = getProperties().getLettuce().getCluster().getRefresh();
/*     */       
/* 223 */       ClusterTopologyRefreshOptions.Builder refreshBuilder = ClusterTopologyRefreshOptions.builder().dynamicRefreshSources(refreshProperties.isDynamicRefreshSources());
/* 224 */       if (refreshProperties.getPeriod() != null) {
/* 225 */         refreshBuilder.enablePeriodicRefresh(refreshProperties.getPeriod());
/*     */       }
/* 227 */       if (refreshProperties.isAdaptive()) {
/* 228 */         refreshBuilder.enableAllAdaptiveRefreshTriggers();
/*     */       }
/* 230 */       return (ClientOptions.Builder)builder.topologyRefreshOptions(refreshBuilder.build());
/*     */     } 
/* 232 */     return ClientOptions.builder();
/*     */   }
/*     */   
/*     */   private void customizeConfigurationFromUrl(LettuceClientConfiguration.LettuceClientConfigurationBuilder builder) {
/* 236 */     if (urlUsesSsl()) {
/* 237 */       builder.useSsl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PoolBuilderFactory
/*     */   {
/*     */     LettuceClientConfiguration.LettuceClientConfigurationBuilder createBuilder(RedisProperties.Pool properties) {
/* 247 */       return (LettuceClientConfiguration.LettuceClientConfigurationBuilder)LettucePoolingClientConfiguration.builder().poolConfig(getPoolConfig(properties));
/*     */     }
/*     */     
/*     */     private GenericObjectPoolConfig<StatefulConnection<?, ?>> getPoolConfig(RedisProperties.Pool properties) {
/* 251 */       GenericObjectPoolConfig<StatefulConnection<?, ?>> config = new GenericObjectPoolConfig();
/* 252 */       config.setMaxTotal(properties.getMaxActive());
/* 253 */       config.setMaxIdle(properties.getMaxIdle());
/* 254 */       config.setMinIdle(properties.getMinIdle());
/* 255 */       if (properties.getTimeBetweenEvictionRuns() != null) {
/* 256 */         config.setTimeBetweenEvictionRuns(properties.getTimeBetweenEvictionRuns());
/*     */       }
/* 258 */       if (properties.getMaxWait() != null) {
/* 259 */         config.setMaxWait(properties.getMaxWait());
/*     */       }
/* 261 */       return config;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\LettuceConnectionConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */