/*    */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.convert.CustomConversions;
/*    */ import org.springframework.data.elasticsearch.annotations.Document;
/*    */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchConverter;
/*    */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchCustomConversions;
/*    */ import org.springframework.data.elasticsearch.core.convert.MappingElasticsearchConverter;
/*    */ import org.springframework.data.elasticsearch.core.mapping.SimpleElasticsearchMappingContext;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class BaseConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   ElasticsearchCustomConversions elasticsearchCustomConversions() {
/* 59 */     return new ElasticsearchCustomConversions(Collections.emptyList());
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   SimpleElasticsearchMappingContext elasticsearchMappingContext(ApplicationContext applicationContext, ElasticsearchCustomConversions elasticsearchCustomConversions) throws ClassNotFoundException {
/* 66 */     SimpleElasticsearchMappingContext mappingContext = new SimpleElasticsearchMappingContext();
/* 67 */     mappingContext.setInitialEntitySet((new EntityScanner(applicationContext)).scan(new Class[] { Document.class }));
/* 68 */     mappingContext.setSimpleTypeHolder(elasticsearchCustomConversions.getSimpleTypeHolder());
/* 69 */     return mappingContext;
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   ElasticsearchConverter elasticsearchConverter(SimpleElasticsearchMappingContext mappingContext, ElasticsearchCustomConversions elasticsearchCustomConversions) {
/* 76 */     MappingElasticsearchConverter converter = new MappingElasticsearchConverter((MappingContext)mappingContext);
/* 77 */     converter.setConversions((CustomConversions)elasticsearchCustomConversions);
/* 78 */     return (ElasticsearchConverter)converter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataConfiguration$BaseConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */