/*     */ package org.springframework.boot.autoconfigure.data.neo4j;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.neo4j.driver.Driver;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*     */ import org.springframework.boot.autoconfigure.neo4j.Neo4jAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizationAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.data.neo4j.aot.Neo4jManagedTypes;
/*     */ import org.springframework.data.neo4j.core.DatabaseSelectionProvider;
/*     */ import org.springframework.data.neo4j.core.Neo4jClient;
/*     */ import org.springframework.data.neo4j.core.Neo4jOperations;
/*     */ import org.springframework.data.neo4j.core.Neo4jTemplate;
/*     */ import org.springframework.data.neo4j.core.convert.Neo4jConversions;
/*     */ import org.springframework.data.neo4j.core.mapping.Neo4jMappingContext;
/*     */ import org.springframework.data.neo4j.core.schema.Node;
/*     */ import org.springframework.data.neo4j.core.schema.RelationshipProperties;
/*     */ import org.springframework.data.neo4j.core.transaction.Neo4jTransactionManager;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(before = {TransactionAutoConfiguration.class}, after = {Neo4jAutoConfiguration.class, TransactionManagerCustomizationAutoConfiguration.class})
/*     */ @ConditionalOnClass({Driver.class, Neo4jTransactionManager.class, PlatformTransactionManager.class})
/*     */ @EnableConfigurationProperties({Neo4jDataProperties.class})
/*     */ @ConditionalOnBean({Driver.class})
/*     */ public class Neo4jDataAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public Neo4jConversions neo4jConversions() {
/*  72 */     return new Neo4jConversions();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   Neo4jManagedTypes neo4jManagedTypes(ApplicationContext applicationContext) throws ClassNotFoundException {
/*  78 */     Set<Class<?>> initialEntityClasses = (new EntityScanner(applicationContext)).scan(new Class[] { Node.class, RelationshipProperties.class });
/*     */     
/*  80 */     return Neo4jManagedTypes.fromIterable(initialEntityClasses);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public Neo4jMappingContext neo4jMappingContext(Neo4jManagedTypes managedTypes, Neo4jConversions neo4jConversions) {
/*  86 */     Neo4jMappingContext context = new Neo4jMappingContext(neo4jConversions);
/*  87 */     context.setManagedTypes((ManagedTypes)managedTypes);
/*  88 */     return context;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public DatabaseSelectionProvider databaseSelectionProvider(Neo4jDataProperties properties) {
/*  94 */     String database = properties.getDatabase();
/*  95 */     return (database != null) ? DatabaseSelectionProvider.createStaticDatabaseSelectionProvider(database) : 
/*  96 */       DatabaseSelectionProvider.getDefaultSelectionProvider();
/*     */   }
/*     */   
/*     */   @Bean({"neo4jClient"})
/*     */   @ConditionalOnMissingBean
/*     */   public Neo4jClient neo4jClient(Driver driver, DatabaseSelectionProvider databaseNameProvider) {
/* 102 */     return Neo4jClient.create(driver, databaseNameProvider);
/*     */   }
/*     */   
/*     */   @Bean({"neo4jTemplate"})
/*     */   @ConditionalOnMissingBean({Neo4jOperations.class})
/*     */   public Neo4jTemplate neo4jTemplate(Neo4jClient neo4jClient, Neo4jMappingContext neo4jMappingContext) {
/* 108 */     return new Neo4jTemplate(neo4jClient, neo4jMappingContext);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean({"transactionManager"})
/*     */   @ConditionalOnMissingBean({TransactionManager.class})
/*     */   public Neo4jTransactionManager transactionManager(Driver driver, DatabaseSelectionProvider databaseNameProvider, ObjectProvider<TransactionManagerCustomizers> optionalCustomizers) {
/* 115 */     Neo4jTransactionManager transactionManager = new Neo4jTransactionManager(driver, databaseNameProvider);
/* 116 */     optionalCustomizers.ifAvailable(customizer -> customizer.customize((TransactionManager)transactionManager));
/* 117 */     return transactionManager;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */