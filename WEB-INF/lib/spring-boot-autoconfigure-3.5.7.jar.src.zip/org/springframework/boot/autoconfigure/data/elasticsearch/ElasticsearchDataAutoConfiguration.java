package org.springframework.boot.autoconfigure.data.elasticsearch;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.elasticsearch.ElasticsearchClientAutoConfiguration;
import org.springframework.boot.autoconfigure.elasticsearch.ReactiveElasticsearchClientAutoConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchTemplate;

@AutoConfiguration(after = {ElasticsearchClientAutoConfiguration.class, ReactiveElasticsearchClientAutoConfiguration.class})
@ConditionalOnClass({ElasticsearchTemplate.class})
@Import({ElasticsearchDataConfiguration.BaseConfiguration.class, ElasticsearchDataConfiguration.JavaClientConfiguration.class, ElasticsearchDataConfiguration.ReactiveRestClientConfiguration.class})
public class ElasticsearchDataAutoConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */