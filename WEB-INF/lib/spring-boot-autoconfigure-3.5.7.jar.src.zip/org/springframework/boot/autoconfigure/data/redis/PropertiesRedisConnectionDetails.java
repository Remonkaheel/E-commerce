/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertiesRedisConnectionDetails
/*     */   implements RedisConnectionDetails
/*     */ {
/*     */   private final RedisProperties properties;
/*     */   private final SslBundles sslBundles;
/*     */   
/*     */   PropertiesRedisConnectionDetails(RedisProperties properties, SslBundles sslBundles) {
/*  43 */     this.properties = properties;
/*  44 */     this.sslBundles = sslBundles;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/*  49 */     RedisUrl redisUrl = getRedisUrl();
/*  50 */     return (redisUrl != null) ? redisUrl.credentials().username() : this.properties.getUsername();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/*  55 */     RedisUrl redisUrl = getRedisUrl();
/*  56 */     return (redisUrl != null) ? redisUrl.credentials().password() : this.properties.getPassword();
/*     */   }
/*     */ 
/*     */   
/*     */   public RedisConnectionDetails.Standalone getStandalone() {
/*  61 */     RedisUrl redisUrl = getRedisUrl();
/*  62 */     return (redisUrl != null) ? 
/*  63 */       RedisConnectionDetails.Standalone.of(redisUrl.uri().getHost(), redisUrl.uri().getPort(), redisUrl.database(), getSslBundle()) : 
/*  64 */       RedisConnectionDetails.Standalone.of(this.properties.getHost(), this.properties.getPort(), this.properties.getDatabase(), 
/*  65 */         getSslBundle());
/*     */   }
/*     */   
/*     */   private SslBundle getSslBundle() {
/*  69 */     if (!this.properties.getSsl().isEnabled()) {
/*  70 */       return null;
/*     */     }
/*  72 */     String bundleName = this.properties.getSsl().getBundle();
/*  73 */     if (StringUtils.hasLength(bundleName)) {
/*  74 */       Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/*  75 */       return this.sslBundles.getBundle(bundleName);
/*     */     } 
/*  77 */     return SslBundle.systemDefault();
/*     */   }
/*     */ 
/*     */   
/*     */   public RedisConnectionDetails.Sentinel getSentinel() {
/*  82 */     RedisProperties.Sentinel sentinel = this.properties.getSentinel();
/*  83 */     return (sentinel != null) ? new PropertiesSentinel(getStandalone().getDatabase(), sentinel) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public RedisConnectionDetails.Cluster getCluster() {
/*  88 */     RedisProperties.Cluster cluster = this.properties.getCluster();
/*  89 */     return (cluster != null) ? new PropertiesCluster(cluster) : null;
/*     */   }
/*     */   
/*     */   private RedisUrl getRedisUrl() {
/*  93 */     return RedisUrl.of(this.properties.getUrl());
/*     */   }
/*     */   
/*     */   private List<RedisConnectionDetails.Node> asNodes(List<String> nodes) {
/*  97 */     return nodes.stream().map(this::asNode).toList();
/*     */   }
/*     */   
/*     */   private RedisConnectionDetails.Node asNode(String node) {
/* 101 */     int portSeparatorIndex = node.lastIndexOf(':');
/* 102 */     String host = node.substring(0, portSeparatorIndex);
/* 103 */     int port = Integer.parseInt(node.substring(portSeparatorIndex + 1));
/* 104 */     return new RedisConnectionDetails.Node(host, port);
/*     */   }
/*     */ 
/*     */   
/*     */   private class PropertiesCluster
/*     */     implements RedisConnectionDetails.Cluster
/*     */   {
/*     */     private final List<RedisConnectionDetails.Node> nodes;
/*     */ 
/*     */     
/*     */     PropertiesCluster(RedisProperties.Cluster properties) {
/* 115 */       this.nodes = PropertiesRedisConnectionDetails.this.asNodes(properties.getNodes());
/*     */     }
/*     */ 
/*     */     
/*     */     public List<RedisConnectionDetails.Node> getNodes() {
/* 120 */       return this.nodes;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslBundle getSslBundle() {
/* 125 */       return PropertiesRedisConnectionDetails.this.getSslBundle();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class PropertiesSentinel
/*     */     implements RedisConnectionDetails.Sentinel
/*     */   {
/*     */     private final int database;
/*     */     
/*     */     private final RedisProperties.Sentinel properties;
/*     */ 
/*     */     
/*     */     PropertiesSentinel(int database, RedisProperties.Sentinel properties) {
/* 140 */       this.database = database;
/* 141 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getDatabase() {
/* 146 */       return this.database;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMaster() {
/* 151 */       return this.properties.getMaster();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<RedisConnectionDetails.Node> getNodes() {
/* 156 */       return PropertiesRedisConnectionDetails.this.asNodes(this.properties.getNodes());
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 161 */       return this.properties.getUsername();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 166 */       return this.properties.getPassword();
/*     */     }
/*     */ 
/*     */     
/*     */     public SslBundle getSslBundle() {
/* 171 */       return PropertiesRedisConnectionDetails.this.getSslBundle();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\PropertiesRedisConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */