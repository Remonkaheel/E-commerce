/*    */ package org.springframework.boot.autoconfigure.data.web;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.domain.PageRequest;
/*    */ import org.springframework.data.domain.Pageable;
/*    */ import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
/*    */ import org.springframework.data.web.SortHandlerMethodArgumentResolver;
/*    */ import org.springframework.data.web.config.EnableSpringDataWebSupport;
/*    */ import org.springframework.data.web.config.PageableHandlerMethodArgumentResolverCustomizer;
/*    */ import org.springframework.data.web.config.SortHandlerMethodArgumentResolverCustomizer;
/*    */ import org.springframework.data.web.config.SpringDataWebSettings;
/*    */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {RepositoryRestMvcAutoConfiguration.class})
/*    */ @EnableSpringDataWebSupport
/*    */ @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({PageableHandlerMethodArgumentResolver.class, WebMvcConfigurer.class})
/*    */ @ConditionalOnMissingBean({PageableHandlerMethodArgumentResolver.class})
/*    */ @EnableConfigurationProperties({SpringDataWebProperties.class})
/*    */ public class SpringDataWebAutoConfiguration
/*    */ {
/*    */   private final SpringDataWebProperties properties;
/*    */   
/*    */   public SpringDataWebAutoConfiguration(SpringDataWebProperties properties) {
/* 60 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public PageableHandlerMethodArgumentResolverCustomizer pageableCustomizer() {
/* 66 */     return resolver -> {
/*    */         SpringDataWebProperties.Pageable pageable = this.properties.getPageable();
/*    */         resolver.setPageParameterName(pageable.getPageParameter());
/*    */         resolver.setSizeParameterName(pageable.getSizeParameter());
/*    */         resolver.setOneIndexedParameters(pageable.isOneIndexedParameters());
/*    */         resolver.setPrefix(pageable.getPrefix());
/*    */         resolver.setQualifierDelimiter(pageable.getQualifierDelimiter());
/*    */         resolver.setFallbackPageable((Pageable)PageRequest.of(0, pageable.getDefaultPageSize()));
/*    */         resolver.setMaxPageSize(pageable.getMaxPageSize());
/*    */       };
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SortHandlerMethodArgumentResolverCustomizer sortCustomizer() {
/* 81 */     return resolver -> resolver.setSortParameter(this.properties.getSort().getSortParameter());
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SpringDataWebSettings springDataWebSettings() {
/* 87 */     return new SpringDataWebSettings(this.properties.getPageable().getSerializationMode());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\web\SpringDataWebAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */