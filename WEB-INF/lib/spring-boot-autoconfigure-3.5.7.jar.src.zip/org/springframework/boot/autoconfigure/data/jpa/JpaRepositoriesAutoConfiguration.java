/*     */ package org.springframework.boot.autoconfigure.data.jpa;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.boot.LazyInitializationExcludeFilter;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryBuilderCustomizer;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
/*     */ import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportSelector;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.data.jpa.repository.JpaRepository;
/*     */ import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
/*     */ import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {HibernateJpaAutoConfiguration.class, TaskExecutionAutoConfiguration.class})
/*     */ @ConditionalOnBean({DataSource.class})
/*     */ @ConditionalOnClass({JpaRepository.class})
/*     */ @ConditionalOnMissingBean({JpaRepositoryFactoryBean.class, JpaRepositoryConfigExtension.class})
/*     */ @ConditionalOnBooleanProperty(name = {"spring.data.jpa.repositories.enabled"}, matchIfMissing = true)
/*     */ @Import({JpaRepositoriesAutoConfiguration.JpaRepositoriesImportSelector.class})
/*     */ public class JpaRepositoriesAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @Conditional({BootstrapExecutorCondition.class})
/*     */   public EntityManagerFactoryBuilderCustomizer entityManagerFactoryBootstrapExecutorCustomizer(Map<String, AsyncTaskExecutor> taskExecutors) {
/*  87 */     return builder -> {
/*     */         AsyncTaskExecutor bootstrapExecutor = determineBootstrapExecutor(taskExecutors);
/*     */         if (bootstrapExecutor != null) {
/*     */           builder.setBootstrapExecutor(bootstrapExecutor);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   @Bean
/*     */   static LazyInitializationExcludeFilter eagerJpaMetamodelCacheCleanup() {
/*  97 */     return (name, definition, type) -> "org.springframework.data.jpa.util.JpaMetamodelCacheCleanup".equals(name);
/*     */   }
/*     */   
/*     */   private AsyncTaskExecutor determineBootstrapExecutor(Map<String, AsyncTaskExecutor> taskExecutors) {
/* 101 */     if (taskExecutors.size() == 1) {
/* 102 */       return taskExecutors.values().iterator().next();
/*     */     }
/* 104 */     return taskExecutors.get("applicationTaskExecutor");
/*     */   }
/*     */   
/*     */   private static final class BootstrapExecutorCondition
/*     */     extends AnyNestedCondition {
/*     */     BootstrapExecutorCondition() {
/* 110 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */     
/*     */     @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "deferred")
/*     */     static class DeferredBootstrapMode {}
/*     */     
/*     */     @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "lazy")
/*     */     static class LazyBootstrapMode {}
/*     */   }
/*     */   
/*     */   @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "deferred")
/*     */   static class DeferredBootstrapMode {}
/*     */   
/*     */   @ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "lazy")
/*     */   static class LazyBootstrapMode {}
/*     */   
/*     */   static class JpaRepositoriesImportSelector implements ImportSelector {
/* 127 */     private static final boolean ENVERS_AVAILABLE = ClassUtils.isPresent("org.springframework.data.envers.repository.config.EnableEnversRepositories", JpaRepositoriesImportSelector.class
/*     */         
/* 129 */         .getClassLoader());
/*     */ 
/*     */     
/*     */     public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 133 */       return new String[] { determineImport() };
/*     */     }
/*     */     
/*     */     private String determineImport() {
/* 137 */       return ENVERS_AVAILABLE ? EnversRevisionRepositoriesRegistrar.class.getName() : 
/* 138 */         JpaRepositoriesRegistrar.class.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */