/*    */ package org.springframework.boot.autoconfigure.data.jpa;
/*    */ 
/*    */ import org.springframework.data.envers.repository.support.EnversRevisionRepositoryFactoryBean;
/*    */ import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EnversRevisionRepositoriesRegistrar
/*    */   extends JpaRepositoriesRegistrar
/*    */ {
/*    */   protected Class<?> getConfiguration() {
/* 33 */     return EnableJpaRepositoriesConfiguration.class;
/*    */   }
/*    */   
/*    */   @EnableJpaRepositories(repositoryFactoryBeanClass = EnversRevisionRepositoryFactoryBean.class)
/*    */   private static final class EnableJpaRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jpa\EnversRevisionRepositoriesRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */