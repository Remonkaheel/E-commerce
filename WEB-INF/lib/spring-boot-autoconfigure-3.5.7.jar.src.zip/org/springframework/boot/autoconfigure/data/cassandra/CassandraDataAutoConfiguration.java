/*     */ package org.springframework.boot.autoconfigure.data.cassandra;
/*     */ 
/*     */ import com.datastax.oss.driver.api.core.CqlSession;
/*     */ import com.datastax.oss.driver.api.core.type.codec.registry.CodecRegistry;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanPackages;
/*     */ import org.springframework.boot.context.properties.bind.Binder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Lazy;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.data.cassandra.CassandraManagedTypes;
/*     */ import org.springframework.data.cassandra.SessionFactory;
/*     */ import org.springframework.data.cassandra.config.CassandraEntityClassScanner;
/*     */ import org.springframework.data.cassandra.config.SchemaAction;
/*     */ import org.springframework.data.cassandra.config.SessionFactoryFactoryBean;
/*     */ import org.springframework.data.cassandra.core.CassandraAdminOperations;
/*     */ import org.springframework.data.cassandra.core.CassandraOperations;
/*     */ import org.springframework.data.cassandra.core.CassandraTemplate;
/*     */ import org.springframework.data.cassandra.core.convert.CassandraConverter;
/*     */ import org.springframework.data.cassandra.core.convert.CassandraCustomConversions;
/*     */ import org.springframework.data.cassandra.core.convert.MappingCassandraConverter;
/*     */ import org.springframework.data.cassandra.core.cql.CqlOperations;
/*     */ import org.springframework.data.cassandra.core.cql.CqlTemplate;
/*     */ import org.springframework.data.cassandra.core.mapping.CassandraMappingContext;
/*     */ import org.springframework.data.cassandra.core.mapping.SimpleUserTypeResolver;
/*     */ import org.springframework.data.cassandra.core.mapping.UserTypeResolver;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {CassandraAutoConfiguration.class})
/*     */ @ConditionalOnClass({CqlSession.class, CassandraAdminOperations.class})
/*     */ @ConditionalOnBean({CqlSession.class})
/*     */ public class CassandraDataAutoConfiguration
/*     */ {
/*     */   private final CqlSession session;
/*     */   
/*     */   public CassandraDataAutoConfiguration(@Lazy CqlSession session) {
/*  71 */     this.session = session;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public static CassandraManagedTypes cassandraManagedTypes(BeanFactory beanFactory) throws ClassNotFoundException {
/*  77 */     List<String> packages = EntityScanPackages.get(beanFactory).getPackageNames();
/*  78 */     if (packages.isEmpty() && AutoConfigurationPackages.has(beanFactory)) {
/*  79 */       packages = AutoConfigurationPackages.get(beanFactory);
/*     */     }
/*  81 */     if (!packages.isEmpty()) {
/*  82 */       return CassandraManagedTypes.fromIterable(CassandraEntityClassScanner.scan(packages));
/*     */     }
/*  84 */     return CassandraManagedTypes.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraMappingContext cassandraMappingContext(CassandraManagedTypes cassandraManagedTypes, CassandraCustomConversions conversions) {
/*  91 */     CassandraMappingContext context = new CassandraMappingContext();
/*  92 */     context.setManagedTypes((ManagedTypes)cassandraManagedTypes);
/*  93 */     context.setSimpleTypeHolder(conversions.getSimpleTypeHolder());
/*  94 */     return context;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraConverter cassandraConverter(CassandraMappingContext mapping, CassandraCustomConversions conversions) {
/* 101 */     MappingCassandraConverter converter = new MappingCassandraConverter(mapping);
/* 102 */     converter.setCodecRegistry(() -> this.session.getContext().getCodecRegistry());
/* 103 */     converter.setCustomConversions((CustomConversions)conversions);
/* 104 */     converter.setUserTypeResolver((UserTypeResolver)new SimpleUserTypeResolver(this.session));
/* 105 */     return (CassandraConverter)converter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({SessionFactory.class})
/*     */   public SessionFactoryFactoryBean cassandraSessionFactory(Environment environment, CassandraConverter converter) {
/* 111 */     SessionFactoryFactoryBean session = new SessionFactoryFactoryBean();
/* 112 */     session.setSession(this.session);
/* 113 */     session.setConverter(converter);
/* 114 */     Binder binder = Binder.get(environment);
/* 115 */     Objects.requireNonNull(session); binder.bind("spring.cassandra.schema-action", SchemaAction.class).ifBound(session::setSchemaAction);
/* 116 */     return session;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({CqlOperations.class})
/*     */   public CqlTemplate cqlTemplate(SessionFactory sessionFactory) {
/* 122 */     return new CqlTemplate(sessionFactory);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({CassandraOperations.class})
/*     */   public CassandraTemplate cassandraTemplate(CqlTemplate cqlTemplate, CassandraConverter converter) {
/* 128 */     return new CassandraTemplate((CqlOperations)cqlTemplate, converter);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public CassandraCustomConversions cassandraCustomConversions() {
/* 134 */     return new CassandraCustomConversions(Collections.emptyList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\cassandra\CassandraDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */