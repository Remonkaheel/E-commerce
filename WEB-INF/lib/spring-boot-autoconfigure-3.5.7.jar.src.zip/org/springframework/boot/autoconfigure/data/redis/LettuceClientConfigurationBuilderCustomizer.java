package org.springframework.boot.autoconfigure.data.redis;

import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;

@FunctionalInterface
public interface LettuceClientConfigurationBuilderCustomizer {
  void customize(LettuceClientConfiguration.LettuceClientConfigurationBuilder paramLettuceClientConfigurationBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\LettuceClientConfigurationBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */