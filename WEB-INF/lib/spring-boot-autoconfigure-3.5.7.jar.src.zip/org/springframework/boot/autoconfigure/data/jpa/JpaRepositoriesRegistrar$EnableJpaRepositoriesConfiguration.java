package org.springframework.boot.autoconfigure.data.jpa;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
final class EnableJpaRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesRegistrar$EnableJpaRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */