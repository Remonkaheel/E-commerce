/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.client.MongoClient;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoConnectionDetails;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.mongodb.MongoDatabaseFactory;
/*    */ import org.springframework.data.mongodb.core.MongoDatabaseFactorySupport;
/*    */ import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingBean({MongoDatabaseFactory.class})
/*    */ @ConditionalOnSingleCandidate(MongoClient.class)
/*    */ class MongoDatabaseFactoryConfiguration
/*    */ {
/*    */   @Bean
/*    */   MongoDatabaseFactorySupport<?> mongoDatabaseFactory(MongoClient mongoClient, MongoProperties properties, MongoConnectionDetails connectionDetails) {
/* 48 */     String database = properties.getDatabase();
/* 49 */     if (database == null) {
/* 50 */       database = connectionDetails.getConnectionString().getDatabase();
/*    */     }
/* 52 */     return (MongoDatabaseFactorySupport<?>)new SimpleMongoClientDatabaseFactory(mongoClient, database);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDatabaseFactoryConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */