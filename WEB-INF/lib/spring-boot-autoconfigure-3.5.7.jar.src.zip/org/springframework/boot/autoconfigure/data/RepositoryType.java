/*    */ package org.springframework.boot.autoconfigure.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RepositoryType
/*    */ {
/* 30 */   AUTO,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   IMPERATIVE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   REACTIVE;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\RepositoryType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */