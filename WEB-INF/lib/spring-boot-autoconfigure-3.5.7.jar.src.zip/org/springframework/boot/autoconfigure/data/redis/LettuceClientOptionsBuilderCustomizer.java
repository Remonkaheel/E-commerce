package org.springframework.boot.autoconfigure.data.redis;

import io.lettuce.core.ClientOptions;

@FunctionalInterface
public interface LettuceClientOptionsBuilderCustomizer {
  void customize(ClientOptions.Builder paramBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\LettuceClientOptionsBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */