package org.springframework.boot.autoconfigure.data.jpa;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@ConditionalOnProperty(name = {"spring.data.jpa.repositories.bootstrap-mode"}, havingValue = "lazy")
class LazyBootstrapMode {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesAutoConfiguration$BootstrapExecutorCondition$LazyBootstrapMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */