package org.springframework.boot.autoconfigure.data.neo4j;

import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;

@EnableNeo4jRepositories
final class EnableNeo4jRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jRepositoriesRegistrar$EnableNeo4jRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */