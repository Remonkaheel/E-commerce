package org.springframework.boot.autoconfigure.data.r2dbc;

import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

@EnableR2dbcRepositories
final class EnableR2dbcRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\r2dbc\R2dbcRepositoriesAutoConfigureRegistrar$EnableR2dbcRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */