/*    */ package org.springframework.boot.autoconfigure.data.jdbc;
/*    */ 
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcDb2Dialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcH2Dialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcHsqlDbDialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcMySqlDialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcOracleDialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcPostgresDialect;
/*    */ import org.springframework.data.jdbc.core.dialect.JdbcSqlServerDialect;
/*    */ import org.springframework.data.relational.core.dialect.Dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JdbcDatabaseDialect
/*    */ {
/* 39 */   DB2((Dialect)JdbcDb2Dialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   H2((Dialect)JdbcH2Dialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   HSQL((Dialect)JdbcHsqlDbDialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   MARIA((Dialect)JdbcMySqlDialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   MYSQL((Dialect)JdbcMySqlDialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   ORACLE((Dialect)JdbcOracleDialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   POSTGRESQL((Dialect)JdbcPostgresDialect.INSTANCE),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   SQL_SERVER((Dialect)JdbcSqlServerDialect.INSTANCE);
/*    */   
/*    */   private final Dialect dialect;
/*    */   
/*    */   JdbcDatabaseDialect(Dialect dialect) {
/* 79 */     this.dialect = dialect;
/*    */   }
/*    */   
/*    */   final Dialect getDialect() {
/* 83 */     return this.dialect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\jdbc\JdbcDatabaseDialect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */