/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.reactivestreams.client.ClientSession;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import com.mongodb.reactivestreams.client.MongoDatabase;
/*     */ import java.util.Optional;
/*     */ import org.bson.codecs.Codec;
/*     */ import org.bson.codecs.configuration.CodecRegistry;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoConnectionDetails;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoReactiveAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoOperations;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
/*     */ import org.springframework.data.mongodb.core.SimpleReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsOperations;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsTemplate;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {MongoReactiveAutoConfiguration.class})
/*     */ @ConditionalOnClass({MongoClient.class, ReactiveMongoTemplate.class})
/*     */ @ConditionalOnBean({MongoClient.class})
/*     */ @EnableConfigurationProperties({MongoProperties.class})
/*     */ @Import({MongoDataConfiguration.class})
/*     */ public class MongoReactiveDataAutoConfiguration
/*     */ {
/*     */   private final MongoConnectionDetails connectionDetails;
/*     */   
/*     */   MongoReactiveDataAutoConfiguration(MongoConnectionDetails connectionDetails) {
/*  80 */     this.connectionDetails = connectionDetails;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoDatabaseFactory.class})
/*     */   public SimpleReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory(MongoClient mongo, MongoProperties properties) {
/*  87 */     String database = properties.getDatabase();
/*  88 */     if (database == null) {
/*  89 */       database = this.connectionDetails.getConnectionString().getDatabase();
/*     */     }
/*  91 */     return new SimpleReactiveMongoDatabaseFactory(mongo, database);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoOperations.class})
/*     */   public ReactiveMongoTemplate reactiveMongoTemplate(ReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory, MongoConverter converter) {
/*  98 */     return new ReactiveMongoTemplate(reactiveMongoDatabaseFactory, converter);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({DataBufferFactory.class})
/*     */   public DefaultDataBufferFactory dataBufferFactory() {
/* 104 */     return new DefaultDataBufferFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveGridFsOperations.class})
/*     */   public ReactiveGridFsTemplate reactiveGridFsTemplate(ReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory, MappingMongoConverter mappingMongoConverter, DataBufferFactory dataBufferFactory) {
/* 111 */     return new ReactiveGridFsTemplate(dataBufferFactory, new GridFsReactiveMongoDatabaseFactory(reactiveMongoDatabaseFactory, this.connectionDetails), (MongoConverter)mappingMongoConverter, 
/*     */ 
/*     */         
/* 114 */         (this.connectionDetails.getGridFs() != null) ? this.connectionDetails.getGridFs().getBucket() : null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class GridFsReactiveMongoDatabaseFactory
/*     */     implements ReactiveMongoDatabaseFactory
/*     */   {
/*     */     private final ReactiveMongoDatabaseFactory delegate;
/*     */ 
/*     */     
/*     */     private final MongoConnectionDetails connectionDetails;
/*     */ 
/*     */     
/*     */     GridFsReactiveMongoDatabaseFactory(ReactiveMongoDatabaseFactory delegate, MongoConnectionDetails connectionDetails) {
/* 129 */       this.delegate = delegate;
/* 130 */       this.connectionDetails = connectionDetails;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasCodecFor(Class<?> type) {
/* 135 */       return this.delegate.hasCodecFor(type);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MongoDatabase> getMongoDatabase() throws DataAccessException {
/* 140 */       String gridFsDatabase = getGridFsDatabase(this.connectionDetails);
/* 141 */       if (StringUtils.hasText(gridFsDatabase)) {
/* 142 */         return this.delegate.getMongoDatabase(gridFsDatabase);
/*     */       }
/* 144 */       return this.delegate.getMongoDatabase();
/*     */     }
/*     */     
/*     */     private String getGridFsDatabase(MongoConnectionDetails connectionDetails) {
/* 148 */       return (connectionDetails.getGridFs() != null) ? connectionDetails.getGridFs().getDatabase() : null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<MongoDatabase> getMongoDatabase(String dbName) throws DataAccessException {
/* 153 */       return this.delegate.getMongoDatabase(dbName);
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Optional<Codec<T>> getCodecFor(Class<T> type) {
/* 158 */       return this.delegate.getCodecFor(type);
/*     */     }
/*     */ 
/*     */     
/*     */     public PersistenceExceptionTranslator getExceptionTranslator() {
/* 163 */       return this.delegate.getExceptionTranslator();
/*     */     }
/*     */ 
/*     */     
/*     */     public CodecRegistry getCodecRegistry() {
/* 168 */       return this.delegate.getCodecRegistry();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<ClientSession> getSession(ClientSessionOptions options) {
/* 173 */       return this.delegate.getSession(options);
/*     */     }
/*     */ 
/*     */     
/*     */     public ReactiveMongoDatabaseFactory withSession(ClientSession session) {
/* 178 */       return this.delegate.withSession(session);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTransactionActive() {
/* 183 */       return this.delegate.isTransactionActive();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoReactiveDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */