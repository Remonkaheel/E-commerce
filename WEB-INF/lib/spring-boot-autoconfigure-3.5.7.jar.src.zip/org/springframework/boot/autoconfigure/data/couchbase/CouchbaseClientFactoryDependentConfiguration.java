/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.CouchbaseClientFactory;
/*    */ import org.springframework.data.couchbase.core.CouchbaseOperations;
/*    */ import org.springframework.data.couchbase.core.CouchbaseTemplate;
/*    */ import org.springframework.data.couchbase.core.convert.CouchbaseConverter;
/*    */ import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
/*    */ import org.springframework.data.couchbase.repository.config.RepositoryOperationsMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnSingleCandidate(CouchbaseClientFactory.class)
/*    */ class CouchbaseClientFactoryDependentConfiguration
/*    */ {
/*    */   @Bean(name = {"couchbaseTemplate"})
/*    */   @ConditionalOnMissingBean(name = {"couchbaseTemplate"})
/*    */   CouchbaseTemplate couchbaseTemplate(CouchbaseClientFactory couchbaseClientFactory, MappingCouchbaseConverter mappingCouchbaseConverter) {
/* 43 */     return new CouchbaseTemplate(couchbaseClientFactory, (CouchbaseConverter)mappingCouchbaseConverter);
/*    */   }
/*    */   
/*    */   @Bean(name = {"couchbaseRepositoryOperationsMapping"})
/*    */   @ConditionalOnMissingBean(name = {"couchbaseRepositoryOperationsMapping"})
/*    */   RepositoryOperationsMapping couchbaseRepositoryOperationsMapping(CouchbaseTemplate couchbaseTemplate) {
/* 49 */     return new RepositoryOperationsMapping((CouchbaseOperations)couchbaseTemplate);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseClientFactoryDependentConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */