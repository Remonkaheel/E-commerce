/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.reactivestreams.client.ClientSession;
/*     */ import com.mongodb.reactivestreams.client.MongoDatabase;
/*     */ import java.util.Optional;
/*     */ import org.bson.codecs.Codec;
/*     */ import org.bson.codecs.configuration.CodecRegistry;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoConnectionDetails;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GridFsReactiveMongoDatabaseFactory
/*     */   implements ReactiveMongoDatabaseFactory
/*     */ {
/*     */   private final ReactiveMongoDatabaseFactory delegate;
/*     */   private final MongoConnectionDetails connectionDetails;
/*     */   
/*     */   GridFsReactiveMongoDatabaseFactory(ReactiveMongoDatabaseFactory delegate, MongoConnectionDetails connectionDetails) {
/* 129 */     this.delegate = delegate;
/* 130 */     this.connectionDetails = connectionDetails;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCodecFor(Class<?> type) {
/* 135 */     return this.delegate.hasCodecFor(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MongoDatabase> getMongoDatabase() throws DataAccessException {
/* 140 */     String gridFsDatabase = getGridFsDatabase(this.connectionDetails);
/* 141 */     if (StringUtils.hasText(gridFsDatabase)) {
/* 142 */       return this.delegate.getMongoDatabase(gridFsDatabase);
/*     */     }
/* 144 */     return this.delegate.getMongoDatabase();
/*     */   }
/*     */   
/*     */   private String getGridFsDatabase(MongoConnectionDetails connectionDetails) {
/* 148 */     return (connectionDetails.getGridFs() != null) ? connectionDetails.getGridFs().getDatabase() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<MongoDatabase> getMongoDatabase(String dbName) throws DataAccessException {
/* 153 */     return this.delegate.getMongoDatabase(dbName);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<Codec<T>> getCodecFor(Class<T> type) {
/* 158 */     return this.delegate.getCodecFor(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistenceExceptionTranslator getExceptionTranslator() {
/* 163 */     return this.delegate.getExceptionTranslator();
/*     */   }
/*     */ 
/*     */   
/*     */   public CodecRegistry getCodecRegistry() {
/* 168 */     return this.delegate.getCodecRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<ClientSession> getSession(ClientSessionOptions options) {
/* 173 */     return this.delegate.getSession(options);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReactiveMongoDatabaseFactory withSession(ClientSession session) {
/* 178 */     return this.delegate.withSession(session);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransactionActive() {
/* 183 */     return this.delegate.isTransactionActive();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoReactiveDataAutoConfiguration$GridFsReactiveMongoDatabaseFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */