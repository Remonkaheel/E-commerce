/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.ReactiveRedisTemplate;
/*    */ import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
/*    */ import org.springframework.data.redis.serializer.RedisSerializationContext;
/*    */ import org.springframework.data.redis.serializer.RedisSerializer;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {RedisAutoConfiguration.class})
/*    */ @ConditionalOnClass({ReactiveRedisConnectionFactory.class, ReactiveRedisTemplate.class, Flux.class})
/*    */ public class RedisReactiveAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"reactiveRedisTemplate"})
/*    */   @ConditionalOnBean({ReactiveRedisConnectionFactory.class})
/*    */   public ReactiveRedisTemplate<Object, Object> reactiveRedisTemplate(ReactiveRedisConnectionFactory reactiveRedisConnectionFactory, ResourceLoader resourceLoader) {
/* 51 */     RedisSerializer<Object> javaSerializer = RedisSerializer.java(resourceLoader.getClassLoader());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     RedisSerializationContext<Object, Object> serializationContext = RedisSerializationContext.newSerializationContext().key(javaSerializer).value(javaSerializer).hashKey(javaSerializer).hashValue(javaSerializer).build();
/* 59 */     return new ReactiveRedisTemplate(reactiveRedisConnectionFactory, serializationContext);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name = {"reactiveStringRedisTemplate"})
/*    */   @ConditionalOnBean({ReactiveRedisConnectionFactory.class})
/*    */   public ReactiveStringRedisTemplate reactiveStringRedisTemplate(ReactiveRedisConnectionFactory reactiveRedisConnectionFactory) {
/* 67 */     return new ReactiveStringRedisTemplate(reactiveRedisConnectionFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisReactiveAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */