/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import org.neo4j.driver.Driver;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.data.neo4j.core.ReactiveDatabaseSelectionProvider;
/*    */ import org.springframework.data.neo4j.core.ReactiveNeo4jClient;
/*    */ import org.springframework.data.neo4j.core.ReactiveNeo4jOperations;
/*    */ import org.springframework.data.neo4j.core.ReactiveNeo4jTemplate;
/*    */ import org.springframework.data.neo4j.core.mapping.Neo4jMappingContext;
/*    */ import org.springframework.transaction.ReactiveTransactionManager;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {Neo4jDataAutoConfiguration.class})
/*    */ @ConditionalOnClass({Driver.class, ReactiveNeo4jTemplate.class, ReactiveTransactionManager.class, Flux.class})
/*    */ @ConditionalOnBean({Driver.class})
/*    */ @EnableConfigurationProperties({Neo4jDataProperties.class})
/*    */ public class Neo4jReactiveDataAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveDatabaseSelectionProvider reactiveDatabaseSelectionProvider(Neo4jDataProperties dataProperties) {
/* 54 */     String database = dataProperties.getDatabase();
/* 55 */     return (database != null) ? ReactiveDatabaseSelectionProvider.createStaticDatabaseSelectionProvider(database) : 
/* 56 */       ReactiveDatabaseSelectionProvider.getDefaultSelectionProvider();
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean({"reactiveNeo4jClient"})
/*    */   @ConditionalOnMissingBean
/*    */   public ReactiveNeo4jClient reactiveNeo4jClient(Driver driver, ReactiveDatabaseSelectionProvider databaseNameProvider) {
/* 63 */     return ReactiveNeo4jClient.create(driver, databaseNameProvider);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean({"reactiveNeo4jTemplate"})
/*    */   @ConditionalOnMissingBean({ReactiveNeo4jOperations.class})
/*    */   @ConditionalOnBean({Neo4jMappingContext.class})
/*    */   public ReactiveNeo4jTemplate reactiveNeo4jTemplate(ReactiveNeo4jClient neo4jClient, Neo4jMappingContext neo4jMappingContext) {
/* 71 */     return new ReactiveNeo4jTemplate(neo4jClient, neo4jMappingContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jReactiveDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */