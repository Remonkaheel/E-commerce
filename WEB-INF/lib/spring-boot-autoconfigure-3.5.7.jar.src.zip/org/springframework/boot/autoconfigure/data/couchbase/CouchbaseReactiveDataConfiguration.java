/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.CouchbaseClientFactory;
/*    */ import org.springframework.data.couchbase.core.ReactiveCouchbaseOperations;
/*    */ import org.springframework.data.couchbase.core.ReactiveCouchbaseTemplate;
/*    */ import org.springframework.data.couchbase.core.convert.CouchbaseConverter;
/*    */ import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
/*    */ import org.springframework.data.couchbase.repository.config.ReactiveRepositoryOperationsMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnSingleCandidate(CouchbaseClientFactory.class)
/*    */ class CouchbaseReactiveDataConfiguration
/*    */ {
/*    */   @Bean(name = {"reactiveCouchbaseTemplate"})
/*    */   @ConditionalOnMissingBean(name = {"reactiveCouchbaseTemplate"})
/*    */   ReactiveCouchbaseTemplate reactiveCouchbaseTemplate(CouchbaseClientFactory couchbaseClientFactory, MappingCouchbaseConverter mappingCouchbaseConverter) {
/* 42 */     return new ReactiveCouchbaseTemplate(couchbaseClientFactory, (CouchbaseConverter)mappingCouchbaseConverter);
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean(name = {"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   @ConditionalOnMissingBean(name = {"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   ReactiveRepositoryOperationsMapping reactiveCouchbaseRepositoryOperationsMapping(ReactiveCouchbaseTemplate reactiveCouchbaseTemplate) {
/* 49 */     return new ReactiveRepositoryOperationsMapping((ReactiveCouchbaseOperations)reactiveCouchbaseTemplate);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseReactiveDataConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */