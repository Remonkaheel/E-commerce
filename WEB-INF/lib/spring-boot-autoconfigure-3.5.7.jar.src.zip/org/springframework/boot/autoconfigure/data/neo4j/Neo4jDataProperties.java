/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.data.neo4j")
/*    */ public class Neo4jDataProperties
/*    */ {
/*    */   private String database;
/*    */   
/*    */   public String getDatabase() {
/* 36 */     return this.database;
/*    */   }
/*    */   
/*    */   public void setDatabase(String database) {
/* 40 */     this.database = database;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jDataProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */