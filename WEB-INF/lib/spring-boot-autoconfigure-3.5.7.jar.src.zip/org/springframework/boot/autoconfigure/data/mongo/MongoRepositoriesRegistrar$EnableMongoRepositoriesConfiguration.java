package org.springframework.boot.autoconfigure.data.mongo;

import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@EnableMongoRepositories
final class EnableMongoRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoRepositoriesRegistrar$EnableMongoRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */