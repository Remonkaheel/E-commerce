package org.springframework.boot.autoconfigure.data.ldap;

import org.springframework.data.ldap.repository.config.EnableLdapRepositories;

@EnableLdapRepositories
final class EnableLdapRepositoriesConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\ldap\LdapRepositoriesRegistrar$EnableLdapRepositoriesConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */