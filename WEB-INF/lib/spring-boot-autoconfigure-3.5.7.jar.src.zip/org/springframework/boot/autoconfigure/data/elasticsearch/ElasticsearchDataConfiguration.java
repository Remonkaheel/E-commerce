/*     */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*     */ 
/*     */ import co.elastic.clients.elasticsearch.ElasticsearchClient;
/*     */ import java.util.Collections;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ import org.springframework.data.elasticsearch.annotations.Document;
/*     */ import org.springframework.data.elasticsearch.client.elc.ElasticsearchTemplate;
/*     */ import org.springframework.data.elasticsearch.client.elc.ReactiveElasticsearchClient;
/*     */ import org.springframework.data.elasticsearch.client.elc.ReactiveElasticsearchTemplate;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.ReactiveElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchCustomConversions;
/*     */ import org.springframework.data.elasticsearch.core.convert.MappingElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.mapping.SimpleElasticsearchMappingContext;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ElasticsearchDataConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class BaseConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchCustomConversions elasticsearchCustomConversions() {
/*  59 */       return new ElasticsearchCustomConversions(Collections.emptyList());
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     SimpleElasticsearchMappingContext elasticsearchMappingContext(ApplicationContext applicationContext, ElasticsearchCustomConversions elasticsearchCustomConversions) throws ClassNotFoundException {
/*  66 */       SimpleElasticsearchMappingContext mappingContext = new SimpleElasticsearchMappingContext();
/*  67 */       mappingContext.setInitialEntitySet((new EntityScanner(applicationContext)).scan(new Class[] { Document.class }));
/*  68 */       mappingContext.setSimpleTypeHolder(elasticsearchCustomConversions.getSimpleTypeHolder());
/*  69 */       return mappingContext;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchConverter elasticsearchConverter(SimpleElasticsearchMappingContext mappingContext, ElasticsearchCustomConversions elasticsearchCustomConversions) {
/*  76 */       MappingElasticsearchConverter converter = new MappingElasticsearchConverter((MappingContext)mappingContext);
/*  77 */       converter.setConversions((CustomConversions)elasticsearchCustomConversions);
/*  78 */       return (ElasticsearchConverter)converter;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({ElasticsearchClient.class})
/*     */   static class JavaClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value = {ElasticsearchOperations.class}, name = {"elasticsearchTemplate"})
/*     */     @ConditionalOnBean({ElasticsearchClient.class})
/*     */     ElasticsearchTemplate elasticsearchTemplate(ElasticsearchClient client, ElasticsearchConverter converter) {
/*  91 */       return new ElasticsearchTemplate(client, converter);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class ReactiveRestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value = {ReactiveElasticsearchOperations.class}, name = {"reactiveElasticsearchTemplate"})
/*     */     @ConditionalOnBean({ReactiveElasticsearchClient.class})
/*     */     ReactiveElasticsearchTemplate reactiveElasticsearchTemplate(ReactiveElasticsearchClient client, ElasticsearchConverter converter) {
/* 104 */       return new ReactiveElasticsearchTemplate(client, converter);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */