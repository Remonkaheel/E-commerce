/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RedisUrl
/*    */   extends Record
/*    */ {
/*    */   private final URI uri;
/*    */   private final boolean useSsl;
/*    */   private final Credentials credentials;
/*    */   private final int database;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #42	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   RedisUrl(URI uri, boolean useSsl, Credentials credentials, int database) {
/* 42 */     this.uri = uri; this.useSsl = useSsl; this.credentials = credentials; this.database = database; } public URI uri() { return this.uri; } public boolean useSsl() { return this.useSsl; } public Credentials credentials() { return this.credentials; } public int database() { return this.database; }
/*    */   
/*    */   static RedisUrl of(String url) {
/* 45 */     return (url != null) ? of(toUri(url)) : null;
/*    */   }
/*    */   
/*    */   private static RedisUrl of(URI uri) {
/* 49 */     boolean useSsl = "rediss".equals(uri.getScheme());
/* 50 */     Credentials credentials = Credentials.fromUserInfo(uri.getUserInfo());
/* 51 */     int database = getDatabase(uri);
/* 52 */     return new RedisUrl(uri, useSsl, credentials, database);
/*    */   }
/*    */   
/*    */   private static int getDatabase(URI uri) {
/* 56 */     String path = uri.getPath();
/* 57 */     String[] split = !StringUtils.hasText(path) ? new String[0] : path.split("/", 2);
/* 58 */     return (split.length > 1 && !split[1].isEmpty()) ? Integer.parseInt(split[1]) : 0;
/*    */   }
/*    */   
/*    */   private static URI toUri(String url) {
/*    */     try {
/* 63 */       URI uri = new URI(url);
/* 64 */       String scheme = uri.getScheme();
/* 65 */       if (!"redis".equals(scheme) && !"rediss".equals(scheme)) {
/* 66 */         throw new RedisUrlSyntaxException(url);
/*    */       }
/* 68 */       return uri;
/*    */     }
/* 70 */     catch (URISyntaxException ex) {
/* 71 */       throw new RedisUrlSyntaxException(url, ex);
/*    */     } 
/*    */   }
/*    */   static final class Credentials extends Record { private final String username; private final String password;
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #81	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;
/*    */     }
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #81	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;
/*    */     }
/* 81 */     Credentials(String username, String password) { this.username = username; this.password = password; } public String username() { return this.username; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #81	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/boot/autoconfigure/data/redis/RedisUrl$Credentials;
/* 81 */       //   0	8	1	o	Ljava/lang/Object; } public String password() { return this.password; }
/*    */     
/* 83 */     private static final Credentials NONE = new Credentials(null, null);
/*    */     
/*    */     private static Credentials fromUserInfo(String userInfo) {
/* 86 */       if (userInfo == null) {
/* 87 */         return NONE;
/*    */       }
/* 89 */       int index = userInfo.indexOf(':');
/* 90 */       if (index != -1) {
/* 91 */         return new Credentials(userInfo.substring(0, index), userInfo.substring(index + 1));
/*    */       }
/* 93 */       return new Credentials(null, userInfo);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\redis\RedisUrl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */