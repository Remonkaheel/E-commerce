/*     */ package org.springframework.boot.autoconfigure.data.r2dbc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*     */ import org.springframework.boot.autoconfigure.r2dbc.R2dbcAutoConfiguration;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.data.convert.CustomConversions;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.r2dbc.convert.MappingR2dbcConverter;
/*     */ import org.springframework.data.r2dbc.convert.R2dbcConverter;
/*     */ import org.springframework.data.r2dbc.convert.R2dbcCustomConversions;
/*     */ import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
/*     */ import org.springframework.data.r2dbc.dialect.DialectResolver;
/*     */ import org.springframework.data.r2dbc.dialect.R2dbcDialect;
/*     */ import org.springframework.data.r2dbc.mapping.R2dbcMappingContext;
/*     */ import org.springframework.data.relational.RelationalManagedTypes;
/*     */ import org.springframework.data.relational.core.mapping.DefaultNamingStrategy;
/*     */ import org.springframework.data.relational.core.mapping.NamingStrategy;
/*     */ import org.springframework.data.relational.core.mapping.Table;
/*     */ import org.springframework.r2dbc.core.DatabaseClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {R2dbcAutoConfiguration.class})
/*     */ @ConditionalOnClass({DatabaseClient.class, R2dbcEntityTemplate.class})
/*     */ @ConditionalOnSingleCandidate(DatabaseClient.class)
/*     */ public class R2dbcDataAutoConfiguration
/*     */ {
/*     */   private final DatabaseClient databaseClient;
/*     */   private final R2dbcDialect dialect;
/*     */   
/*     */   public R2dbcDataAutoConfiguration(DatabaseClient databaseClient) {
/*  64 */     this.databaseClient = databaseClient;
/*  65 */     this.dialect = DialectResolver.getDialect(this.databaseClient.getConnectionFactory());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public R2dbcEntityTemplate r2dbcEntityTemplate(R2dbcConverter r2dbcConverter) {
/*  71 */     return new R2dbcEntityTemplate(this.databaseClient, this.dialect, r2dbcConverter);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   static RelationalManagedTypes r2dbcManagedTypes(ApplicationContext applicationContext) throws ClassNotFoundException {
/*  78 */     return RelationalManagedTypes.fromIterable((new EntityScanner(applicationContext)).scan(new Class[] { Table.class }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public R2dbcMappingContext r2dbcMappingContext(ObjectProvider<NamingStrategy> namingStrategy, R2dbcCustomConversions r2dbcCustomConversions, RelationalManagedTypes r2dbcManagedTypes) {
/*  86 */     R2dbcMappingContext relationalMappingContext = new R2dbcMappingContext((NamingStrategy)namingStrategy.getIfAvailable(() -> DefaultNamingStrategy.INSTANCE));
/*  87 */     relationalMappingContext.setSimpleTypeHolder(r2dbcCustomConversions.getSimpleTypeHolder());
/*  88 */     relationalMappingContext.setManagedTypes((ManagedTypes)r2dbcManagedTypes);
/*  89 */     return relationalMappingContext;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public MappingR2dbcConverter r2dbcConverter(R2dbcMappingContext mappingContext, R2dbcCustomConversions r2dbcCustomConversions) {
/*  96 */     return new MappingR2dbcConverter((MappingContext)mappingContext, (CustomConversions)r2dbcCustomConversions);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public R2dbcCustomConversions r2dbcCustomConversions() {
/* 102 */     List<Object> converters = new ArrayList(this.dialect.getConverters());
/* 103 */     converters.addAll(R2dbcCustomConversions.STORE_CONVERTERS);
/* 104 */     return new R2dbcCustomConversions(
/* 105 */         CustomConversions.StoreConversions.of(this.dialect.getSimpleTypeHolder(), converters), 
/* 106 */         Collections.emptyList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\data\r2dbc\R2dbcDataAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */