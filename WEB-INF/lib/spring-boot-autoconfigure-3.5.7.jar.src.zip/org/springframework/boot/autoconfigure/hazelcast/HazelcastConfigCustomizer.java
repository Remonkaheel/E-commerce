package org.springframework.boot.autoconfigure.hazelcast;

import com.hazelcast.config.Config;

@FunctionalInterface
public interface HazelcastConfigCustomizer {
  void customize(Config paramConfig);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConfigCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */