package org.springframework.boot.autoconfigure.hazelcast;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;

@ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
class HasJpa {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration$OnHazelcastAndJpaCondition$HasJpa.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */