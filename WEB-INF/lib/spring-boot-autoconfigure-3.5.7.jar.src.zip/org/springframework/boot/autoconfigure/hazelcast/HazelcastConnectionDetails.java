package org.springframework.boot.autoconfigure.hazelcast;

import com.hazelcast.client.config.ClientConfig;
import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;

public interface HazelcastConnectionDetails extends ConnectionDetails {
  ClientConfig getClientConfig();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */