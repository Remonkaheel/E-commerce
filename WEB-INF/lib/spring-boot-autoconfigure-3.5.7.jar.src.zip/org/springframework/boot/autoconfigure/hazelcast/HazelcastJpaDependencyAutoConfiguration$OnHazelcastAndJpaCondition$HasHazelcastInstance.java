package org.springframework.boot.autoconfigure.hazelcast;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

@ConditionalOnBean(name = {"hazelcastInstance"})
class HasHazelcastInstance {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration$OnHazelcastAndJpaCondition$HasHazelcastInstance.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */