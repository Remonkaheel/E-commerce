/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Conditional({HazelcastJpaDependencyAutoConfiguration.OnHazelcastAndJpaCondition.class})
/*    */ class HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor
/*    */   extends EntityManagerFactoryDependsOnPostProcessor
/*    */ {
/*    */   HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor() {
/* 51 */     super(new String[] { "hazelcastInstance" });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration$HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */