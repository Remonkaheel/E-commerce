/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.config.ClientConfigRecognizer;
/*    */ import com.hazelcast.config.ConfigStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HazelcastClientConfigAvailableCondition
/*    */   extends HazelcastConfigResourceCondition
/*    */ {
/*    */   HazelcastClientConfigAvailableCondition() {
/* 41 */     super("hazelcast.client.config", new String[] { "file:./hazelcast-client.xml", "classpath:/hazelcast-client.xml", "file:./hazelcast-client.yaml", "classpath:/hazelcast-client.yaml", "file:./hazelcast-client.yml", "classpath:/hazelcast-client.yml" });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 48 */     if (context.getEnvironment().containsProperty("spring.hazelcast.config")) {
/* 49 */       ConditionOutcome configValidationOutcome = HazelcastClientValidation.clientConfigOutcome(context, "spring.hazelcast.config", 
/* 50 */           startConditionMessage());
/* 51 */       return (configValidationOutcome != null) ? configValidationOutcome : 
/* 52 */         ConditionOutcome.match(startConditionMessage().foundExactly("property spring.hazelcast.config"));
/*    */     } 
/* 54 */     return getResourceOutcome(context, metadata);
/*    */   }
/*    */   
/*    */   static class HazelcastClientValidation
/*    */   {
/*    */     static ConditionOutcome clientConfigOutcome(ConditionContext context, String propertyName, ConditionMessage.Builder builder) {
/* 60 */       String resourcePath = context.getEnvironment().getProperty(propertyName);
/* 61 */       Resource resource = context.getResourceLoader().getResource(resourcePath);
/* 62 */       if (!resource.exists())
/* 63 */         return ConditionOutcome.noMatch(builder.because("Hazelcast configuration does not exist")); 
/*    */       
/* 65 */       try { InputStream in = resource.getInputStream(); 
/* 66 */         try { boolean clientConfig = (new ClientConfigRecognizer()).isRecognized(new ConfigStream(in));
/* 67 */           ConditionOutcome conditionOutcome = new ConditionOutcome(clientConfig, existingConfigurationOutcome(resource, clientConfig));
/* 68 */           if (in != null) in.close();  return conditionOutcome; } catch (Throwable throwable) { if (in != null)
/* 69 */             try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable ex)
/* 70 */       { return null; }
/*    */     
/*    */     }
/*    */     
/*    */     private static String existingConfigurationOutcome(Resource resource, boolean client) throws IOException {
/* 75 */       URL location = resource.getURL();
/* 76 */       return client ? ("Hazelcast client configuration detected at '" + String.valueOf(location) + "'") : ("Hazelcast server configuration detected  at '" + 
/* 77 */         String.valueOf(location) + "'");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientConfigAvailableCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */