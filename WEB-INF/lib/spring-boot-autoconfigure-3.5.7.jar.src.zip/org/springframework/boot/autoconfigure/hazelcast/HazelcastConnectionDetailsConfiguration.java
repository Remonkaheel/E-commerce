/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingBean({HazelcastConnectionDetails.class})
/*    */ class HazelcastConnectionDetailsConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({ClientConfig.class})
/*    */   @Conditional({HazelcastClientConfigAvailableCondition.class})
/*    */   static class HazelcastClientConfigFileConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastConnectionDetails hazelcastConnectionDetails(HazelcastProperties properties, ResourceLoader resourceLoader) {
/* 46 */       return new PropertiesHazelcastConnectionDetails(properties, resourceLoader);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnSingleCandidate(ClientConfig.class)
/*    */   static class HazelcastClientConfigConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastConnectionDetails hazelcastConnectionDetails(ClientConfig config) {
/* 57 */       return () -> config;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConnectionDetailsConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */