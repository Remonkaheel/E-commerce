/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.HazelcastClient;
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnBean({HazelcastConnectionDetails.class})
/*    */ class HazelcastClientInstanceConfiguration
/*    */ {
/*    */   @Bean
/*    */   HazelcastInstance hazelcastInstance(HazelcastConnectionDetails hazelcastConnectionDetails) {
/* 39 */     ClientConfig config = hazelcastConnectionDetails.getClientConfig();
/* 40 */     return !StringUtils.hasText(config.getInstanceName()) ? HazelcastClient.newHazelcastClient(config) : 
/* 41 */       HazelcastClient.getOrCreateHazelcastClient(config);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientInstanceConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */