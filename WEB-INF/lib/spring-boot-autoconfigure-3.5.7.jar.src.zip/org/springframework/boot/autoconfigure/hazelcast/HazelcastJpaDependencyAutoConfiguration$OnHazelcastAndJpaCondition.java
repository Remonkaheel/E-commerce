/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.AllNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.context.annotation.ConfigurationCondition;
/*    */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnHazelcastAndJpaCondition
/*    */   extends AllNestedConditions
/*    */ {
/*    */   OnHazelcastAndJpaCondition() {
/* 59 */     super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */   }
/*    */   
/*    */   @ConditionalOnBean(name = {"hazelcastInstance"})
/*    */   static class HasHazelcastInstance {}
/*    */   
/*    */   @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*    */   static class HasJpa {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration$OnHazelcastAndJpaCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */