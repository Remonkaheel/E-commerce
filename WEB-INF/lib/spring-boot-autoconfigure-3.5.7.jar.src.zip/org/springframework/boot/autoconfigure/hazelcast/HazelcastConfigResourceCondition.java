/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.ResourceCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HazelcastConfigResourceCondition
/*    */   extends ResourceCondition
/*    */ {
/*    */   protected static final String HAZELCAST_CONFIG_PROPERTY = "spring.hazelcast.config";
/*    */   private final String configSystemProperty;
/*    */   
/*    */   protected HazelcastConfigResourceCondition(String configSystemProperty, String... resourceLocations) {
/* 43 */     super("Hazelcast", "spring.hazelcast.config", resourceLocations);
/* 44 */     Assert.notNull(configSystemProperty, "'configSystemProperty' must not be null");
/* 45 */     this.configSystemProperty = configSystemProperty;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
/* 50 */     if (System.getProperty(this.configSystemProperty) != null) {
/* 51 */       return 
/* 52 */         ConditionOutcome.match(startConditionMessage().because("System property '" + this.configSystemProperty + "' is set."));
/*    */     }
/* 54 */     return super.getResourceOutcome(context, metadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastConfigResourceCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */