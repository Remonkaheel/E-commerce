/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.hazelcast")
/*    */ public class HazelcastProperties
/*    */ {
/*    */   private Resource config;
/*    */   
/*    */   public Resource getConfig() {
/* 38 */     return this.config;
/*    */   }
/*    */   
/*    */   public void setConfig(Resource config) {
/* 42 */     this.config = config;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Resource resolveConfigLocation() {
/* 52 */     if (this.config == null) {
/* 53 */       return null;
/*    */     }
/* 55 */     Assert.state(this.config.exists(), () -> "Hazelcast configuration does not exist '" + this.config.getDescription() + "'");
/*    */     
/* 57 */     return this.config;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */