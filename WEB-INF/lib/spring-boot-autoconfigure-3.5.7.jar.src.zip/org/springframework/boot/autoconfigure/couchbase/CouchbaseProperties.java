/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.couchbase")
/*     */ public class CouchbaseProperties
/*     */ {
/*     */   private String connectionString;
/*     */   private String username;
/*     */   private String password;
/*  53 */   private final Authentication authentication = new Authentication();
/*     */   
/*  55 */   private final Env env = new Env();
/*     */   
/*     */   public String getConnectionString() {
/*  58 */     return this.connectionString;
/*     */   }
/*     */   
/*     */   public void setConnectionString(String connectionString) {
/*  62 */     this.connectionString = connectionString;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  66 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  70 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  74 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  78 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Authentication getAuthentication() {
/*  82 */     return this.authentication;
/*     */   }
/*     */   
/*     */   public Env getEnv() {
/*  86 */     return this.env;
/*     */   }
/*     */   
/*     */   public static class Authentication
/*     */   {
/*  91 */     private final Pem pem = new Pem();
/*     */     
/*  93 */     private final Jks jks = new Jks();
/*     */     
/*     */     public Pem getPem() {
/*  96 */       return this.pem;
/*     */     }
/*     */     
/*     */     public Jks getJks() {
/* 100 */       return this.jks;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Pem
/*     */     {
/*     */       private String certificates;
/*     */ 
/*     */ 
/*     */       
/*     */       private String privateKey;
/*     */ 
/*     */ 
/*     */       
/*     */       private String privateKeyPassword;
/*     */ 
/*     */ 
/*     */       
/*     */       public String getCertificates() {
/* 121 */         return this.certificates;
/*     */       }
/*     */       
/*     */       public void setCertificates(String certificates) {
/* 125 */         this.certificates = certificates;
/*     */       }
/*     */       
/*     */       public String getPrivateKey() {
/* 129 */         return this.privateKey;
/*     */       }
/*     */       
/*     */       public void setPrivateKey(String privateKey) {
/* 133 */         this.privateKey = privateKey;
/*     */       }
/*     */       
/*     */       public String getPrivateKeyPassword() {
/* 137 */         return this.privateKeyPassword;
/*     */       }
/*     */       
/*     */       public void setPrivateKeyPassword(String privateKeyPassword) {
/* 141 */         this.privateKeyPassword = privateKeyPassword;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Jks
/*     */     {
/*     */       private String location;
/*     */ 
/*     */ 
/*     */       
/*     */       private String password;
/*     */ 
/*     */ 
/*     */       
/*     */       public String getLocation() {
/* 159 */         return this.location;
/*     */       }
/*     */       
/*     */       public void setLocation(String location) {
/* 163 */         this.location = location;
/*     */       }
/*     */       
/*     */       public String getPassword() {
/* 167 */         return this.password;
/*     */       }
/*     */       
/*     */       public void setPassword(String password) {
/* 171 */         this.password = password; } } } public static class Pem { private String certificates; private String privateKey; private String privateKeyPassword; public String getCertificates() { return this.certificates; } public void setCertificates(String certificates) { this.certificates = certificates; } public String getPrivateKey() { return this.privateKey; } public void setPrivateKey(String privateKey) { this.privateKey = privateKey; } public String getPrivateKeyPassword() { return this.privateKeyPassword; } public void setPrivateKeyPassword(String privateKeyPassword) { this.privateKeyPassword = privateKeyPassword; } } public static class Jks { private String location; private String password; public void setPassword(String password) { this.password = password; }
/*     */      public String getLocation() {
/*     */       return this.location;
/*     */     } public void setLocation(String location) {
/*     */       this.location = location;
/*     */     } public String getPassword() {
/*     */       return this.password;
/*     */     } } public static class Env { private final CouchbaseProperties.Io io; private final CouchbaseProperties.Ssl ssl; private final CouchbaseProperties.Timeouts timeouts;
/*     */     public Env() {
/* 180 */       this.io = new CouchbaseProperties.Io();
/*     */       
/* 182 */       this.ssl = new CouchbaseProperties.Ssl();
/*     */       
/* 184 */       this.timeouts = new CouchbaseProperties.Timeouts();
/*     */     }
/*     */     public CouchbaseProperties.Io getIo() {
/* 187 */       return this.io;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Ssl getSsl() {
/* 191 */       return this.ssl;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Timeouts getTimeouts() {
/* 195 */       return this.timeouts;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Io
/*     */   {
/* 205 */     private int minEndpoints = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     private int maxEndpoints = 12;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     private Duration idleHttpConnectionTimeout = Duration.ofSeconds(1L);
/*     */     
/*     */     public int getMinEndpoints() {
/* 219 */       return this.minEndpoints;
/*     */     }
/*     */     
/*     */     public void setMinEndpoints(int minEndpoints) {
/* 223 */       this.minEndpoints = minEndpoints;
/*     */     }
/*     */     
/*     */     public int getMaxEndpoints() {
/* 227 */       return this.maxEndpoints;
/*     */     }
/*     */     
/*     */     public void setMaxEndpoints(int maxEndpoints) {
/* 231 */       this.maxEndpoints = maxEndpoints;
/*     */     }
/*     */     
/*     */     public Duration getIdleHttpConnectionTimeout() {
/* 235 */       return this.idleHttpConnectionTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleHttpConnectionTimeout(Duration idleHttpConnectionTimeout) {
/* 239 */       this.idleHttpConnectionTimeout = idleHttpConnectionTimeout;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Ssl
/*     */   {
/*     */     private Boolean enabled;
/*     */ 
/*     */ 
/*     */     
/*     */     private String bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getEnabled() {
/* 258 */       return Boolean.valueOf((this.enabled != null) ? this.enabled.booleanValue() : StringUtils.hasText(this.bundle));
/*     */     }
/*     */     
/*     */     public void setEnabled(Boolean enabled) {
/* 262 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String getBundle() {
/* 266 */       return this.bundle;
/*     */     }
/*     */     
/*     */     public void setBundle(String bundle) {
/* 270 */       this.bundle = bundle;
/*     */     } }
/*     */   public static class Timeouts { private Duration connect; private Duration disconnect; private Duration keyValue; private Duration keyValueDurable;
/*     */     private Duration query;
/*     */     private Duration view;
/*     */     private Duration search;
/*     */     private Duration analytics;
/*     */     private Duration management;
/*     */     
/*     */     public Timeouts() {
/* 280 */       this.connect = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 285 */       this.disconnect = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 290 */       this.keyValue = Duration.ofMillis(2500L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 295 */       this.keyValueDurable = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       this.query = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 305 */       this.view = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       this.search = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 315 */       this.analytics = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 320 */       this.management = Duration.ofSeconds(75L);
/*     */     }
/*     */     public Duration getConnect() {
/* 323 */       return this.connect;
/*     */     }
/*     */     
/*     */     public void setConnect(Duration connect) {
/* 327 */       this.connect = connect;
/*     */     }
/*     */     
/*     */     public Duration getDisconnect() {
/* 331 */       return this.disconnect;
/*     */     }
/*     */     
/*     */     public void setDisconnect(Duration disconnect) {
/* 335 */       this.disconnect = disconnect;
/*     */     }
/*     */     
/*     */     public Duration getKeyValue() {
/* 339 */       return this.keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyValue(Duration keyValue) {
/* 343 */       this.keyValue = keyValue;
/*     */     }
/*     */     
/*     */     public Duration getKeyValueDurable() {
/* 347 */       return this.keyValueDurable;
/*     */     }
/*     */     
/*     */     public void setKeyValueDurable(Duration keyValueDurable) {
/* 351 */       this.keyValueDurable = keyValueDurable;
/*     */     }
/*     */     
/*     */     public Duration getQuery() {
/* 355 */       return this.query;
/*     */     }
/*     */     
/*     */     public void setQuery(Duration query) {
/* 359 */       this.query = query;
/*     */     }
/*     */     
/*     */     public Duration getView() {
/* 363 */       return this.view;
/*     */     }
/*     */     
/*     */     public void setView(Duration view) {
/* 367 */       this.view = view;
/*     */     }
/*     */     
/*     */     public Duration getSearch() {
/* 371 */       return this.search;
/*     */     }
/*     */     
/*     */     public void setSearch(Duration search) {
/* 375 */       this.search = search;
/*     */     }
/*     */     
/*     */     public Duration getAnalytics() {
/* 379 */       return this.analytics;
/*     */     }
/*     */     
/*     */     public void setAnalytics(Duration analytics) {
/* 383 */       this.analytics = analytics;
/*     */     }
/*     */     
/*     */     public Duration getManagement() {
/* 387 */       return this.management;
/*     */     }
/*     */     
/*     */     public void setManagement(Duration management) {
/* 391 */       this.management = management;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */