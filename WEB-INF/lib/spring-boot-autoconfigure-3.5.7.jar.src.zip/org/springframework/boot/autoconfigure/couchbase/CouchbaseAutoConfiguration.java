/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import com.couchbase.client.core.env.Authenticator;
/*     */ import com.couchbase.client.core.env.CertificateAuthenticator;
/*     */ import com.couchbase.client.core.env.IoConfig;
/*     */ import com.couchbase.client.core.env.PasswordAuthenticator;
/*     */ import com.couchbase.client.core.env.SecurityConfig;
/*     */ import com.couchbase.client.core.env.TimeoutConfig;
/*     */ import com.couchbase.client.java.Cluster;
/*     */ import com.couchbase.client.java.ClusterOptions;
/*     */ import com.couchbase.client.java.codec.JacksonJsonSerializer;
/*     */ import com.couchbase.client.java.codec.JsonSerializer;
/*     */ import com.couchbase.client.java.env.ClusterEnvironment;
/*     */ import com.couchbase.client.java.json.JsonValueModule;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.io.ApplicationResourceLoader;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.boot.ssl.pem.PemSslStore;
/*     */ import org.springframework.boot.ssl.pem.PemSslStoreDetails;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {JacksonAutoConfiguration.class})
/*     */ @ConditionalOnClass({Cluster.class})
/*     */ @Conditional({CouchbaseAutoConfiguration.CouchbaseCondition.class})
/*     */ @EnableConfigurationProperties({CouchbaseProperties.class})
/*     */ public class CouchbaseAutoConfiguration
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final CouchbaseProperties properties;
/*     */   
/*     */   CouchbaseAutoConfiguration(ResourceLoader resourceLoader, CouchbaseProperties properties) {
/*  90 */     this.resourceLoader = ApplicationResourceLoader.get(resourceLoader);
/*  91 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({CouchbaseConnectionDetails.class})
/*     */   PropertiesCouchbaseConnectionDetails couchbaseConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/*  97 */     return new PropertiesCouchbaseConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public ClusterEnvironment couchbaseClusterEnvironment(ObjectProvider<ClusterEnvironmentBuilderCustomizer> customizers, CouchbaseConnectionDetails connectionDetails) {
/* 105 */     ClusterEnvironment.Builder builder = initializeEnvironmentBuilder(connectionDetails);
/* 106 */     customizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 107 */     return builder.build();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public Authenticator couchbaseAuthenticator(CouchbaseConnectionDetails connectionDetails) throws IOException {
/* 113 */     if (connectionDetails.getUsername() != null && connectionDetails.getPassword() != null) {
/* 114 */       return (Authenticator)PasswordAuthenticator.create(connectionDetails.getUsername(), connectionDetails.getPassword());
/*     */     }
/* 116 */     CouchbaseProperties.Authentication.Pem pem = this.properties.getAuthentication().getPem();
/* 117 */     if (pem.getCertificates() != null) {
/* 118 */       PemSslStoreDetails details = new PemSslStoreDetails(null, pem.getCertificates(), pem.getPrivateKey());
/* 119 */       PemSslStore store = PemSslStore.load(details);
/* 120 */       return (Authenticator)CertificateAuthenticator.fromKey(store.privateKey(), pem.getPrivateKeyPassword(), store
/* 121 */           .certificates());
/*     */     } 
/* 123 */     CouchbaseProperties.Authentication.Jks jks = this.properties.getAuthentication().getJks();
/* 124 */     if (jks.getLocation() != null) {
/* 125 */       Resource resource = this.resourceLoader.getResource(jks.getLocation());
/* 126 */       String keystorePassword = jks.getPassword(); 
/* 127 */       try { InputStream inputStream = resource.getInputStream(); 
/* 128 */         try { KeyStore store = KeyStore.getInstance(KeyStore.getDefaultType());
/* 129 */           store.load(inputStream, (keystorePassword != null) ? keystorePassword.toCharArray() : null);
/* 130 */           CertificateAuthenticator certificateAuthenticator = CertificateAuthenticator.fromKeyStore(store, keystorePassword);
/* 131 */           if (inputStream != null) inputStream.close();  return (Authenticator)certificateAuthenticator; } catch (Throwable throwable) { if (inputStream != null)
/* 132 */             try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (GeneralSecurityException ex)
/* 133 */       { throw new IllegalStateException("Error reading Couchbase certificate store", ex); }
/*     */     
/*     */     } 
/* 136 */     throw new IllegalStateException("Couchbase authentication requires username and password, or certificates");
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(destroyMethod = "disconnect")
/*     */   @ConditionalOnMissingBean
/*     */   public Cluster couchbaseCluster(ClusterEnvironment couchbaseClusterEnvironment, Authenticator authenticator, CouchbaseConnectionDetails connectionDetails) {
/* 143 */     ClusterOptions options = ClusterOptions.clusterOptions(authenticator).environment(couchbaseClusterEnvironment);
/* 144 */     return Cluster.connect(connectionDetails.getConnectionString(), options);
/*     */   }
/*     */   
/*     */   private ClusterEnvironment.Builder initializeEnvironmentBuilder(CouchbaseConnectionDetails connectionDetails) {
/* 148 */     ClusterEnvironment.Builder builder = ClusterEnvironment.builder();
/* 149 */     CouchbaseProperties.Timeouts timeouts = this.properties.getEnv().getTimeouts();
/* 150 */     builder.timeoutConfig(config -> config.kvTimeout(timeouts.getKeyValue()).analyticsTimeout(timeouts.getAnalytics()).kvDurableTimeout(timeouts.getKeyValueDurable()).queryTimeout(timeouts.getQuery()).viewTimeout(timeouts.getView()).searchTimeout(timeouts.getSearch()).managementTimeout(timeouts.getManagement()).connectTimeout(timeouts.getConnect()).disconnectTimeout(timeouts.getDisconnect()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     CouchbaseProperties.Io io = this.properties.getEnv().getIo();
/* 160 */     builder.ioConfig(config -> config.maxHttpConnections(io.getMaxEndpoints()).numKvConnections(io.getMinEndpoints()).idleHttpConnectionTimeout(io.getIdleHttpConnectionTimeout()));
/*     */ 
/*     */     
/* 163 */     SslBundle sslBundle = connectionDetails.getSslBundle();
/* 164 */     if (sslBundle != null) {
/* 165 */       configureSsl(builder, sslBundle);
/*     */     }
/* 167 */     return builder;
/*     */   }
/*     */   
/*     */   private void configureSsl(ClusterEnvironment.Builder builder, SslBundle sslBundle) {
/* 171 */     Assert.state(!sslBundle.getOptions().isSpecified(), "SSL Options cannot be specified with Couchbase");
/* 172 */     builder.securityConfig(config -> {
/*     */           config.enableTls(true);
/*     */           TrustManagerFactory trustManagerFactory = sslBundle.getManagers().getTrustManagerFactory();
/*     */           if (trustManagerFactory != null) {
/*     */             config.trustManagerFactory(trustManagerFactory);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({ObjectMapper.class})
/*     */   static class JacksonConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(ObjectMapper.class)
/*     */     ClusterEnvironmentBuilderCustomizer jacksonClusterEnvironmentBuilderCustomizer(ObjectMapper objectMapper) {
/* 188 */       return new CouchbaseAutoConfiguration.JacksonClusterEnvironmentBuilderCustomizer(objectMapper
/* 189 */           .copy().registerModule((Module)new JsonValueModule()));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class JacksonClusterEnvironmentBuilderCustomizer
/*     */     implements ClusterEnvironmentBuilderCustomizer, Ordered
/*     */   {
/*     */     private final ObjectMapper objectMapper;
/*     */     
/*     */     private JacksonClusterEnvironmentBuilderCustomizer(ObjectMapper objectMapper) {
/* 200 */       this.objectMapper = objectMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(ClusterEnvironment.Builder builder) {
/* 205 */       builder.jsonSerializer((JsonSerializer)JacksonJsonSerializer.create(this.objectMapper));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 210 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class CouchbaseCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     CouchbaseCondition() {
/* 222 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */ 
/*     */     
/*     */     @ConditionalOnProperty({"spring.couchbase.connection-string"})
/*     */     private static final class CouchbaseUrlCondition {}
/*     */ 
/*     */     
/*     */     @ConditionalOnBean({CouchbaseConnectionDetails.class})
/*     */     private static final class CouchbaseConnectionDetailsCondition {}
/*     */   }
/*     */   
/*     */   @ConditionalOnProperty({"spring.couchbase.connection-string"})
/*     */   private static final class CouchbaseUrlCondition {}
/*     */   
/*     */   @ConditionalOnBean({CouchbaseConnectionDetails.class})
/*     */   private static final class CouchbaseConnectionDetailsCondition {}
/*     */   
/*     */   static final class PropertiesCouchbaseConnectionDetails
/*     */     implements CouchbaseConnectionDetails
/*     */   {
/*     */     private final CouchbaseProperties properties;
/*     */     private final SslBundles sslBundles;
/*     */     
/*     */     PropertiesCouchbaseConnectionDetails(CouchbaseProperties properties, SslBundles sslBundles) {
/* 247 */       this.properties = properties;
/* 248 */       this.sslBundles = sslBundles;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getConnectionString() {
/* 253 */       return this.properties.getConnectionString();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 258 */       return this.properties.getUsername();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 263 */       return this.properties.getPassword();
/*     */     }
/*     */ 
/*     */     
/*     */     public SslBundle getSslBundle() {
/* 268 */       CouchbaseProperties.Ssl ssl = this.properties.getEnv().getSsl();
/* 269 */       if (!ssl.getEnabled().booleanValue()) {
/* 270 */         return null;
/*     */       }
/* 272 */       if (StringUtils.hasLength(ssl.getBundle())) {
/* 273 */         Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 274 */         return this.sslBundles.getBundle(ssl.getBundle());
/*     */       } 
/* 276 */       return SslBundle.systemDefault();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */