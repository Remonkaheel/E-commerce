/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Authentication
/*     */ {
/*  91 */   private final Pem pem = new Pem();
/*     */   
/*  93 */   private final Jks jks = new Jks();
/*     */   
/*     */   public Pem getPem() {
/*  96 */     return this.pem;
/*     */   }
/*     */   
/*     */   public Jks getJks() {
/* 100 */     return this.jks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pem
/*     */   {
/*     */     private String certificates;
/*     */ 
/*     */ 
/*     */     
/*     */     private String privateKey;
/*     */ 
/*     */ 
/*     */     
/*     */     private String privateKeyPassword;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCertificates() {
/* 121 */       return this.certificates;
/*     */     }
/*     */     
/*     */     public void setCertificates(String certificates) {
/* 125 */       this.certificates = certificates;
/*     */     }
/*     */     
/*     */     public String getPrivateKey() {
/* 129 */       return this.privateKey;
/*     */     }
/*     */     
/*     */     public void setPrivateKey(String privateKey) {
/* 133 */       this.privateKey = privateKey;
/*     */     }
/*     */     
/*     */     public String getPrivateKeyPassword() {
/* 137 */       return this.privateKeyPassword;
/*     */     }
/*     */     
/*     */     public void setPrivateKeyPassword(String privateKeyPassword) {
/* 141 */       this.privateKeyPassword = privateKeyPassword;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Jks
/*     */   {
/*     */     private String location;
/*     */ 
/*     */ 
/*     */     
/*     */     private String password;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getLocation() {
/* 159 */       return this.location;
/*     */     }
/*     */     
/*     */     public void setLocation(String location) {
/* 163 */       this.location = location;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 167 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 171 */       this.password = password;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties$Authentication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */