/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timeouts
/*     */ {
/* 280 */   private Duration connect = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   private Duration disconnect = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   private Duration keyValue = Duration.ofMillis(2500L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   private Duration keyValueDurable = Duration.ofSeconds(10L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   private Duration query = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 305 */   private Duration view = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 310 */   private Duration search = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   private Duration analytics = Duration.ofSeconds(75L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   private Duration management = Duration.ofSeconds(75L);
/*     */   
/*     */   public Duration getConnect() {
/* 323 */     return this.connect;
/*     */   }
/*     */   
/*     */   public void setConnect(Duration connect) {
/* 327 */     this.connect = connect;
/*     */   }
/*     */   
/*     */   public Duration getDisconnect() {
/* 331 */     return this.disconnect;
/*     */   }
/*     */   
/*     */   public void setDisconnect(Duration disconnect) {
/* 335 */     this.disconnect = disconnect;
/*     */   }
/*     */   
/*     */   public Duration getKeyValue() {
/* 339 */     return this.keyValue;
/*     */   }
/*     */   
/*     */   public void setKeyValue(Duration keyValue) {
/* 343 */     this.keyValue = keyValue;
/*     */   }
/*     */   
/*     */   public Duration getKeyValueDurable() {
/* 347 */     return this.keyValueDurable;
/*     */   }
/*     */   
/*     */   public void setKeyValueDurable(Duration keyValueDurable) {
/* 351 */     this.keyValueDurable = keyValueDurable;
/*     */   }
/*     */   
/*     */   public Duration getQuery() {
/* 355 */     return this.query;
/*     */   }
/*     */   
/*     */   public void setQuery(Duration query) {
/* 359 */     this.query = query;
/*     */   }
/*     */   
/*     */   public Duration getView() {
/* 363 */     return this.view;
/*     */   }
/*     */   
/*     */   public void setView(Duration view) {
/* 367 */     this.view = view;
/*     */   }
/*     */   
/*     */   public Duration getSearch() {
/* 371 */     return this.search;
/*     */   }
/*     */   
/*     */   public void setSearch(Duration search) {
/* 375 */     this.search = search;
/*     */   }
/*     */   
/*     */   public Duration getAnalytics() {
/* 379 */     return this.analytics;
/*     */   }
/*     */   
/*     */   public void setAnalytics(Duration analytics) {
/* 383 */     this.analytics = analytics;
/*     */   }
/*     */   
/*     */   public Duration getManagement() {
/* 387 */     return this.management;
/*     */   }
/*     */   
/*     */   public void setManagement(Duration management) {
/* 391 */     this.management = management;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties$Timeouts.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */