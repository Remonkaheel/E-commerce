/*    */ package org.springframework.boot.autoconfigure.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CouchbaseConnectionDetails
/*    */   extends ConnectionDetails
/*    */ {
/*    */   String getConnectionString();
/*    */   
/*    */   String getUsername();
/*    */   
/*    */   String getPassword();
/*    */   
/*    */   default SslBundle getSslBundle() {
/* 56 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */