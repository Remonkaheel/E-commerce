package org.springframework.boot.autoconfigure.couchbase;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@ConditionalOnProperty({"spring.couchbase.connection-string"})
final class CouchbaseUrlCondition {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseAutoConfiguration$CouchbaseCondition$CouchbaseUrlCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */