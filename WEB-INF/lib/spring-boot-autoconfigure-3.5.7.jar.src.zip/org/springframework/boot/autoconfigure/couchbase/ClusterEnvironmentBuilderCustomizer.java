package org.springframework.boot.autoconfigure.couchbase;

import com.couchbase.client.java.env.ClusterEnvironment;

@FunctionalInterface
public interface ClusterEnvironmentBuilderCustomizer {
  void customize(ClusterEnvironment.Builder paramBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\ClusterEnvironmentBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */