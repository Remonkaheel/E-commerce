/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pem
/*     */ {
/*     */   private String certificates;
/*     */   private String privateKey;
/*     */   private String privateKeyPassword;
/*     */   
/*     */   public String getCertificates() {
/* 121 */     return this.certificates;
/*     */   }
/*     */   
/*     */   public void setCertificates(String certificates) {
/* 125 */     this.certificates = certificates;
/*     */   }
/*     */   
/*     */   public String getPrivateKey() {
/* 129 */     return this.privateKey;
/*     */   }
/*     */   
/*     */   public void setPrivateKey(String privateKey) {
/* 133 */     this.privateKey = privateKey;
/*     */   }
/*     */   
/*     */   public String getPrivateKeyPassword() {
/* 137 */     return this.privateKeyPassword;
/*     */   }
/*     */   
/*     */   public void setPrivateKeyPassword(String privateKeyPassword) {
/* 141 */     this.privateKeyPassword = privateKeyPassword;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties$Authentication$Pem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */