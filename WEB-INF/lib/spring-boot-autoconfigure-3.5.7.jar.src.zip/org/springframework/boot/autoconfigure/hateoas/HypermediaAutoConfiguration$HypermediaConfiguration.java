package org.springframework.boot.autoconfigure.hateoas;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.hateoas.client.LinkDiscoverers;
import org.springframework.hateoas.config.EnableHypermediaSupport;

@Configuration(proxyBeanMethods = false)
@ConditionalOnMissingBean({LinkDiscoverers.class})
@ConditionalOnClass({ObjectMapper.class})
@EnableHypermediaSupport(type = {EnableHypermediaSupport.HypermediaType.HAL})
public class HypermediaConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaAutoConfiguration$HypermediaConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */