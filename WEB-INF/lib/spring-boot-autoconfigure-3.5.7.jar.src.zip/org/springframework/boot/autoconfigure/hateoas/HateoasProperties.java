/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.hateoas")
/*    */ public class HateoasProperties
/*    */ {
/*    */   private boolean useHalAsDefaultJsonMediaType = true;
/*    */   
/*    */   public boolean isUseHalAsDefaultJsonMediaType() {
/* 38 */     return this.useHalAsDefaultJsonMediaType;
/*    */   }
/*    */   
/*    */   public void setUseHalAsDefaultJsonMediaType(boolean useHalAsDefaultJsonMediaType) {
/* 42 */     this.useHalAsDefaultJsonMediaType = useHalAsDefaultJsonMediaType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hateoas\HateoasProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */