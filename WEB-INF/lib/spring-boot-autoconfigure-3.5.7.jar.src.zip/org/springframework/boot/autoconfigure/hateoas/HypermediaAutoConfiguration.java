/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.hateoas.EntityModel;
/*    */ import org.springframework.hateoas.client.LinkDiscoverers;
/*    */ import org.springframework.hateoas.config.EnableHypermediaSupport;
/*    */ import org.springframework.hateoas.mediatype.hal.HalConfiguration;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.plugin.core.Plugin;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {WebMvcAutoConfiguration.class, JacksonAutoConfiguration.class, HttpMessageConvertersAutoConfiguration.class, RepositoryRestMvcAutoConfiguration.class})
/*    */ @ConditionalOnClass({EntityModel.class, RequestMapping.class, RequestMappingHandlerAdapter.class, Plugin.class})
/*    */ @ConditionalOnWebApplication
/*    */ @EnableConfigurationProperties({HateoasProperties.class})
/*    */ public class HypermediaAutoConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass(name = {"com.fasterxml.jackson.databind.ObjectMapper"})
/*    */   @ConditionalOnBooleanProperty(name = {"spring.hateoas.use-hal-as-default-json-media-type"}, matchIfMissing = true)
/*    */   static class JacksonJsonHalConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     HalConfiguration applicationJsonHalConfiguration() {
/* 68 */       return (new HalConfiguration()).withMediaType(MediaType.APPLICATION_JSON);
/*    */     }
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingBean({LinkDiscoverers.class})
/*    */   @ConditionalOnClass({ObjectMapper.class})
/*    */   @EnableHypermediaSupport(type = {EnableHypermediaSupport.HypermediaType.HAL})
/*    */   protected static class HypermediaConfiguration {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */