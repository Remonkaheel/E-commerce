/*     */ package org.springframework.boot.autoconfigure.gson;
/*     */ 
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.Strictness;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardGsonBuilderCustomizer
/*     */   implements GsonBuilderCustomizer, Ordered
/*     */ {
/*     */   private final GsonProperties properties;
/*     */   
/*     */   StandardGsonBuilderCustomizer(GsonProperties properties) {
/*  72 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  77 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void customize(GsonBuilder builder) {
/*  82 */     GsonProperties properties = this.properties;
/*  83 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*  84 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getGenerateNonExecutableJson).whenTrue().toCall(builder::generateNonExecutableJson);
/*  85 */     Objects.requireNonNull(properties);
/*     */     
/*  87 */     Objects.requireNonNull(builder); map.from(properties::getExcludeFieldsWithoutExposeAnnotation).whenTrue().toCall(builder::excludeFieldsWithoutExposeAnnotation);
/*  88 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getSerializeNulls).whenTrue().toCall(builder::serializeNulls);
/*  89 */     Objects.requireNonNull(properties);
/*     */     
/*  91 */     Objects.requireNonNull(builder); map.from(properties::getEnableComplexMapKeySerialization).whenTrue().toCall(builder::enableComplexMapKeySerialization);
/*  92 */     Objects.requireNonNull(properties);
/*     */     
/*  94 */     Objects.requireNonNull(builder); map.from(properties::getDisableInnerClassSerialization).whenTrue().toCall(builder::disableInnerClassSerialization);
/*  95 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getLongSerializationPolicy).to(builder::setLongSerializationPolicy);
/*  96 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getFieldNamingPolicy).to(builder::setFieldNamingPolicy);
/*  97 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getPrettyPrinting).whenTrue().toCall(builder::setPrettyPrinting);
/*  98 */     Objects.requireNonNull(properties); map.from(properties::getStrictness).to(strictnessOrLeniency(builder));
/*  99 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getDisableHtmlEscaping).whenTrue().toCall(builder::disableHtmlEscaping);
/* 100 */     Objects.requireNonNull(properties); Objects.requireNonNull(builder); map.from(properties::getDateFormat).to(builder::setDateFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   private Consumer<GsonProperties.Strictness> strictnessOrLeniency(GsonBuilder builder) {
/* 105 */     if (ClassUtils.isPresent("com.google.gson.Strictness", getClass().getClassLoader())) {
/* 106 */       return strictness -> builder.setStrictness(Strictness.valueOf(strictness.name()));
/*     */     }
/* 108 */     return strictness -> {
/*     */         if (strictness == GsonProperties.Strictness.LENIENT)
/*     */           builder.setLenient(); 
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\gson\GsonAutoConfiguration$StandardGsonBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */