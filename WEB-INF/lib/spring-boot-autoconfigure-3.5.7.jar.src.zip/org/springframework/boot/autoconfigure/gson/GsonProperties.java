/*     */ package org.springframework.boot.autoconfigure.gson;
/*     */ 
/*     */ import com.google.gson.FieldNamingPolicy;
/*     */ import com.google.gson.LongSerializationPolicy;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.gson")
/*     */ public class GsonProperties
/*     */ {
/*     */   private Boolean generateNonExecutableJson;
/*     */   private Boolean excludeFieldsWithoutExposeAnnotation;
/*     */   private Boolean serializeNulls;
/*     */   private Boolean enableComplexMapKeySerialization;
/*     */   private Boolean disableInnerClassSerialization;
/*     */   private LongSerializationPolicy longSerializationPolicy;
/*     */   private FieldNamingPolicy fieldNamingPolicy;
/*     */   private Boolean prettyPrinting;
/*     */   private Strictness strictness;
/*     */   private Boolean disableHtmlEscaping;
/*     */   private String dateFormat;
/*     */   
/*     */   public Boolean getGenerateNonExecutableJson() {
/*  95 */     return this.generateNonExecutableJson;
/*     */   }
/*     */   
/*     */   public void setGenerateNonExecutableJson(Boolean generateNonExecutableJson) {
/*  99 */     this.generateNonExecutableJson = generateNonExecutableJson;
/*     */   }
/*     */   
/*     */   public Boolean getExcludeFieldsWithoutExposeAnnotation() {
/* 103 */     return this.excludeFieldsWithoutExposeAnnotation;
/*     */   }
/*     */   
/*     */   public void setExcludeFieldsWithoutExposeAnnotation(Boolean excludeFieldsWithoutExposeAnnotation) {
/* 107 */     this.excludeFieldsWithoutExposeAnnotation = excludeFieldsWithoutExposeAnnotation;
/*     */   }
/*     */   
/*     */   public Boolean getSerializeNulls() {
/* 111 */     return this.serializeNulls;
/*     */   }
/*     */   
/*     */   public void setSerializeNulls(Boolean serializeNulls) {
/* 115 */     this.serializeNulls = serializeNulls;
/*     */   }
/*     */   
/*     */   public Boolean getEnableComplexMapKeySerialization() {
/* 119 */     return this.enableComplexMapKeySerialization;
/*     */   }
/*     */   
/*     */   public void setEnableComplexMapKeySerialization(Boolean enableComplexMapKeySerialization) {
/* 123 */     this.enableComplexMapKeySerialization = enableComplexMapKeySerialization;
/*     */   }
/*     */   
/*     */   public Boolean getDisableInnerClassSerialization() {
/* 127 */     return this.disableInnerClassSerialization;
/*     */   }
/*     */   
/*     */   public void setDisableInnerClassSerialization(Boolean disableInnerClassSerialization) {
/* 131 */     this.disableInnerClassSerialization = disableInnerClassSerialization;
/*     */   }
/*     */   
/*     */   public LongSerializationPolicy getLongSerializationPolicy() {
/* 135 */     return this.longSerializationPolicy;
/*     */   }
/*     */   
/*     */   public void setLongSerializationPolicy(LongSerializationPolicy longSerializationPolicy) {
/* 139 */     this.longSerializationPolicy = longSerializationPolicy;
/*     */   }
/*     */   
/*     */   public FieldNamingPolicy getFieldNamingPolicy() {
/* 143 */     return this.fieldNamingPolicy;
/*     */   }
/*     */   
/*     */   public void setFieldNamingPolicy(FieldNamingPolicy fieldNamingPolicy) {
/* 147 */     this.fieldNamingPolicy = fieldNamingPolicy;
/*     */   }
/*     */   
/*     */   public Boolean getPrettyPrinting() {
/* 151 */     return this.prettyPrinting;
/*     */   }
/*     */   
/*     */   public void setPrettyPrinting(Boolean prettyPrinting) {
/* 155 */     this.prettyPrinting = prettyPrinting;
/*     */   }
/*     */   
/*     */   public Strictness getStrictness() {
/* 159 */     return this.strictness;
/*     */   }
/*     */   
/*     */   public void setStrictness(Strictness strictness) {
/* 163 */     this.strictness = strictness;
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.gson.strictness", since = "3.4.0")
/*     */   public Boolean getLenient() {
/* 169 */     return Boolean.valueOf((this.strictness != null && this.strictness == Strictness.LENIENT));
/*     */   }
/*     */   
/*     */   public void setLenient(Boolean lenient) {
/* 173 */     setStrictness((lenient != null && lenient.booleanValue()) ? Strictness.LENIENT : Strictness.STRICT);
/*     */   }
/*     */   
/*     */   public Boolean getDisableHtmlEscaping() {
/* 177 */     return this.disableHtmlEscaping;
/*     */   }
/*     */   
/*     */   public void setDisableHtmlEscaping(Boolean disableHtmlEscaping) {
/* 181 */     this.disableHtmlEscaping = disableHtmlEscaping;
/*     */   }
/*     */   
/*     */   public String getDateFormat() {
/* 185 */     return this.dateFormat;
/*     */   }
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 189 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Strictness
/*     */   {
/* 204 */     LENIENT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     LEGACY_STRICT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     STRICT;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\gson\GsonProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */