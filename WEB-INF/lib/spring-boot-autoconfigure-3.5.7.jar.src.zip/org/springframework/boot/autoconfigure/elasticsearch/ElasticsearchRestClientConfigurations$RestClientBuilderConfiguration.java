/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
/*     */ import org.apache.http.nio.conn.SchemeIOSessionStrategy;
/*     */ import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
/*     */ import org.elasticsearch.client.RestClient;
/*     */ import org.elasticsearch.client.RestClientBuilder;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnMissingBean({RestClientBuilder.class})
/*     */ class RestClientBuilderConfiguration
/*     */ {
/*     */   private final ElasticsearchProperties properties;
/*     */   
/*     */   RestClientBuilderConfiguration(ElasticsearchProperties properties) {
/*  75 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ElasticsearchConnectionDetails.class})
/*     */   ElasticsearchRestClientConfigurations.PropertiesElasticsearchConnectionDetails elasticsearchConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/*  81 */     return new ElasticsearchRestClientConfigurations.PropertiesElasticsearchConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   RestClientBuilderCustomizer defaultRestClientBuilderCustomizer(ElasticsearchConnectionDetails connectionDetails) {
/*  87 */     return new ElasticsearchRestClientConfigurations.DefaultRestClientBuilderCustomizer(this.properties, connectionDetails);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   RestClientBuilder elasticsearchRestClientBuilder(ElasticsearchConnectionDetails connectionDetails, ObjectProvider<RestClientBuilderCustomizer> builderCustomizers) {
/*  93 */     RestClientBuilder builder = RestClient.builder((HttpHost[])connectionDetails.getNodes()
/*  94 */         .stream()
/*  95 */         .map(node -> new HttpHost(node.hostname(), node.port(), node.protocol().getScheme()))
/*  96 */         .toArray(x$0 -> new HttpHost[x$0]));
/*  97 */     builder.setHttpClientConfigCallback(httpClientBuilder -> {
/*     */           builderCustomizers.orderedStream().forEach(());
/*     */           SslBundle sslBundle = connectionDetails.getSslBundle();
/*     */           if (sslBundle != null) {
/*     */             configureSsl(httpClientBuilder, sslBundle);
/*     */           }
/*     */           return httpClientBuilder;
/*     */         });
/* 105 */     builder.setRequestConfigCallback(requestConfigBuilder -> {
/*     */           builderCustomizers.orderedStream().forEach(());
/*     */           return requestConfigBuilder;
/*     */         });
/* 109 */     String pathPrefix = connectionDetails.getPathPrefix();
/* 110 */     if (pathPrefix != null) {
/* 111 */       builder.setPathPrefix(pathPrefix);
/*     */     }
/* 113 */     builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 114 */     return builder;
/*     */   }
/*     */   
/*     */   private void configureSsl(HttpAsyncClientBuilder httpClientBuilder, SslBundle sslBundle) {
/* 118 */     SSLContext sslcontext = sslBundle.createSslContext();
/* 119 */     SslOptions sslOptions = sslBundle.getOptions();
/* 120 */     httpClientBuilder.setSSLStrategy((SchemeIOSessionStrategy)new SSLIOSessionStrategy(sslcontext, sslOptions.getEnabledProtocols(), sslOptions
/* 121 */           .getCiphers(), (HostnameVerifier)null));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientConfigurations$RestClientBuilderConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */