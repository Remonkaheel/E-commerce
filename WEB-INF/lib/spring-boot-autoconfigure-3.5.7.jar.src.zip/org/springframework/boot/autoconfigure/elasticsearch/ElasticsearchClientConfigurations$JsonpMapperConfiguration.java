package org.springframework.boot.autoconfigure.elasticsearch;

import org.springframework.context.annotation.Import;

@Import({ElasticsearchClientConfigurations.JacksonJsonpMapperConfiguration.class, ElasticsearchClientConfigurations.JsonbJsonpMapperConfiguration.class, ElasticsearchClientConfigurations.SimpleJsonpMapperConfiguration.class})
class JsonpMapperConfiguration {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchClientConfigurations$JsonpMapperConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */