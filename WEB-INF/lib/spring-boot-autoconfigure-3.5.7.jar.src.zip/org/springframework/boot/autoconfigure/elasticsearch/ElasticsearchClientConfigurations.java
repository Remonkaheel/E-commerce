/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import co.elastic.clients.elasticsearch.ElasticsearchClient;
/*     */ import co.elastic.clients.json.JsonpMapper;
/*     */ import co.elastic.clients.json.SimpleJsonpMapper;
/*     */ import co.elastic.clients.json.jackson.JacksonJsonpMapper;
/*     */ import co.elastic.clients.json.jsonb.JsonbJsonpMapper;
/*     */ import co.elastic.clients.transport.ElasticsearchTransport;
/*     */ import co.elastic.clients.transport.rest_client.RestClientOptions;
/*     */ import co.elastic.clients.transport.rest_client.RestClientTransport;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import jakarta.json.bind.Jsonb;
/*     */ import jakarta.json.spi.JsonProvider;
/*     */ import org.elasticsearch.client.RestClient;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElasticsearchClientConfigurations
/*     */ {
/*     */   @Import({JacksonJsonpMapperConfiguration.class, JsonbJsonpMapperConfiguration.class, SimpleJsonpMapperConfiguration.class})
/*     */   static class JsonpMapperConfiguration {}
/*     */   
/*     */   @ConditionalOnMissingBean({JsonpMapper.class})
/*     */   @ConditionalOnClass({ObjectMapper.class})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class JacksonJsonpMapperConfiguration
/*     */   {
/*     */     @Bean
/*     */     JacksonJsonpMapper jacksonJsonpMapper() {
/*  60 */       return new JacksonJsonpMapper();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @ConditionalOnMissingBean({JsonpMapper.class})
/*     */   @ConditionalOnBean({Jsonb.class})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class JsonbJsonpMapperConfiguration
/*     */   {
/*     */     @Bean
/*     */     JsonbJsonpMapper jsonbJsonpMapper(Jsonb jsonb) {
/*  72 */       return new JsonbJsonpMapper(JsonProvider.provider(), jsonb);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @ConditionalOnMissingBean({JsonpMapper.class})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class SimpleJsonpMapperConfiguration
/*     */   {
/*     */     @Bean
/*     */     SimpleJsonpMapper simpleJsonpMapper() {
/*  83 */       return new SimpleJsonpMapper();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnMissingBean({ElasticsearchTransport.class})
/*     */   static class ElasticsearchTransportConfiguration
/*     */   {
/*     */     @Bean
/*     */     RestClientTransport restClientTransport(RestClient restClient, JsonpMapper jsonMapper, ObjectProvider<RestClientOptions> restClientOptions) {
/*  94 */       return new RestClientTransport(restClient, jsonMapper, (RestClientOptions)restClientOptions.getIfAvailable());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnBean({ElasticsearchTransport.class})
/*     */   static class ElasticsearchClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchClient elasticsearchClient(ElasticsearchTransport transport) {
/* 106 */       return new ElasticsearchClient(transport);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchClientConfigurations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */