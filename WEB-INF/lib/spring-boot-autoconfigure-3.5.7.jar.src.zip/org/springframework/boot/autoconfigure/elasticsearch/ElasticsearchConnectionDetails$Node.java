/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Node
/*     */   extends Record
/*     */ {
/*     */   private final String hostname;
/*     */   private final int port;
/*     */   private final Protocol protocol;
/*     */   private final String username;
/*     */   private final String password;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #85	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #85	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #85	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/boot/autoconfigure/elasticsearch/ElasticsearchConnectionDetails$Node;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public Node(String hostname, int port, Protocol protocol, String username, String password) {
/*  85 */     this.hostname = hostname; this.port = port; this.protocol = protocol; this.username = username; this.password = password; } public String hostname() { return this.hostname; } public int port() { return this.port; } public Protocol protocol() { return this.protocol; } public String username() { return this.username; } public String password() { return this.password; }
/*     */   
/*     */   public Node(String host, int port, Protocol protocol) {
/*  88 */     this(host, port, protocol, null, null);
/*     */   }
/*     */   
/*     */   URI toUri() {
/*     */     try {
/*  93 */       return new URI(this.protocol.getScheme(), userInfo(), this.hostname, this.port, null, null, null);
/*     */     }
/*  95 */     catch (URISyntaxException ex) {
/*  96 */       throw new IllegalStateException("Can't construct URI", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String userInfo() {
/* 101 */     if (this.username == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     return (this.password != null) ? (this.username + ":" + this.username) : this.username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Protocol
/*     */   {
/* 115 */     HTTP("http"),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     HTTPS("https");
/*     */     
/*     */     private final String scheme;
/*     */     
/*     */     Protocol(String scheme) {
/* 125 */       this.scheme = scheme;
/*     */     }
/*     */     
/*     */     String getScheme() {
/* 129 */       return this.scheme;
/*     */     }
/*     */     
/*     */     static Protocol forScheme(String scheme) {
/* 133 */       for (Protocol protocol : values()) {
/* 134 */         if (protocol.scheme.equals(scheme)) {
/* 135 */           return protocol;
/*     */         }
/*     */       } 
/* 138 */       throw new IllegalArgumentException("Unknown scheme '" + scheme + "'");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchConnectionDetails$Node.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */