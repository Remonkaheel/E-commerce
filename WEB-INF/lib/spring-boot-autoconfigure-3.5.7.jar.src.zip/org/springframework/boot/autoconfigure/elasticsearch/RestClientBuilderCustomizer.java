package org.springframework.boot.autoconfigure.elasticsearch;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClientBuilder;

@FunctionalInterface
public interface RestClientBuilderCustomizer {
  void customize(RestClientBuilder paramRestClientBuilder);
  
  default void customize(HttpAsyncClientBuilder builder) {}
  
  default void customize(RequestConfig.Builder builder) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\RestClientBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */