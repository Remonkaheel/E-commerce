/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertiesElasticsearchConnectionDetails
/*     */   implements ElasticsearchConnectionDetails
/*     */ {
/*     */   private final ElasticsearchProperties properties;
/*     */   private final SslBundles sslBundles;
/*     */   
/*     */   PropertiesElasticsearchConnectionDetails(ElasticsearchProperties properties, SslBundles sslBundles) {
/* 244 */     this.properties = properties;
/* 245 */     this.sslBundles = sslBundles;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ElasticsearchConnectionDetails.Node> getNodes() {
/* 250 */     return this.properties.getUris().stream().map(this::createNode).toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 255 */     return this.properties.getUsername();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 260 */     return this.properties.getPassword();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPathPrefix() {
/* 265 */     return this.properties.getPathPrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public SslBundle getSslBundle() {
/* 270 */     ElasticsearchProperties.Restclient.Ssl ssl = this.properties.getRestclient().getSsl();
/* 271 */     if (StringUtils.hasLength(ssl.getBundle())) {
/* 272 */       Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 273 */       return this.sslBundles.getBundle(ssl.getBundle());
/*     */     } 
/* 275 */     return null;
/*     */   }
/*     */   
/*     */   private ElasticsearchConnectionDetails.Node createNode(String uri) {
/* 279 */     if (!uri.startsWith("http://") && !uri.startsWith("https://")) {
/* 280 */       uri = "http://" + uri;
/*     */     }
/* 282 */     return createNode(URI.create(uri));
/*     */   }
/*     */   
/*     */   private ElasticsearchConnectionDetails.Node createNode(URI uri) {
/* 286 */     String userInfo = uri.getUserInfo();
/* 287 */     ElasticsearchConnectionDetails.Node.Protocol protocol = ElasticsearchConnectionDetails.Node.Protocol.forScheme(uri.getScheme());
/* 288 */     if (!StringUtils.hasLength(userInfo)) {
/* 289 */       return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, null, null);
/*     */     }
/* 291 */     int separatorIndex = userInfo.indexOf(':');
/* 292 */     if (separatorIndex == -1) {
/* 293 */       return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, userInfo, null);
/*     */     }
/* 295 */     String[] components = userInfo.split(":");
/* 296 */     return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, components[0], 
/* 297 */         (components.length > 1) ? components[1] : "");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientConfigurations$PropertiesElasticsearchConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */