/*    */ package org.springframework.boot.autoconfigure.elasticsearch;
/*    */ 
/*    */ import co.elastic.clients.json.JsonpMapper;
/*    */ import co.elastic.clients.transport.ElasticsearchTransport;
/*    */ import co.elastic.clients.transport.rest_client.RestClientOptions;
/*    */ import co.elastic.clients.transport.rest_client.RestClientTransport;
/*    */ import org.elasticsearch.client.RestClient;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnMissingBean({ElasticsearchTransport.class})
/*    */ class ElasticsearchTransportConfiguration
/*    */ {
/*    */   @Bean
/*    */   RestClientTransport restClientTransport(RestClient restClient, JsonpMapper jsonMapper, ObjectProvider<RestClientOptions> restClientOptions) {
/* 94 */     return new RestClientTransport(restClient, jsonMapper, (RestClientOptions)restClientOptions.getIfAvailable());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchClientConfigurations$ElasticsearchTransportConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */