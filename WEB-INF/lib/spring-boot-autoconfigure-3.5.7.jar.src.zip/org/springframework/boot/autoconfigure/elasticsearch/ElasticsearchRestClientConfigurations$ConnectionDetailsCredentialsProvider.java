/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.Credentials;
/*     */ import org.apache.http.auth.UsernamePasswordCredentials;
/*     */ import org.apache.http.impl.client.BasicCredentialsProvider;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectionDetailsCredentialsProvider
/*     */   extends BasicCredentialsProvider
/*     */ {
/*     */   ConnectionDetailsCredentialsProvider(ElasticsearchConnectionDetails connectionDetails) {
/* 199 */     String username = connectionDetails.getUsername();
/* 200 */     if (StringUtils.hasText(username)) {
/* 201 */       UsernamePasswordCredentials usernamePasswordCredentials = new UsernamePasswordCredentials(username, connectionDetails.getPassword());
/* 202 */       setCredentials(AuthScope.ANY, (Credentials)usernamePasswordCredentials);
/*     */     } 
/* 204 */     Stream<URI> uris = getUris(connectionDetails);
/* 205 */     uris.filter(this::hasUserInfo).forEach(this::addUserInfoCredentials);
/*     */   }
/*     */   
/*     */   private Stream<URI> getUris(ElasticsearchConnectionDetails connectionDetails) {
/* 209 */     return connectionDetails.getNodes().stream().map(ElasticsearchConnectionDetails.Node::toUri);
/*     */   }
/*     */   
/*     */   private boolean hasUserInfo(URI uri) {
/* 213 */     return (uri != null && StringUtils.hasLength(uri.getUserInfo()));
/*     */   }
/*     */   
/*     */   private void addUserInfoCredentials(URI uri) {
/* 217 */     AuthScope authScope = new AuthScope(uri.getHost(), uri.getPort());
/* 218 */     Credentials credentials = createUserInfoCredentials(uri.getUserInfo());
/* 219 */     setCredentials(authScope, credentials);
/*     */   }
/*     */   
/*     */   private Credentials createUserInfoCredentials(String userInfo) {
/* 223 */     int delimiter = userInfo.indexOf(":");
/* 224 */     if (delimiter == -1) {
/* 225 */       return (Credentials)new UsernamePasswordCredentials(userInfo, null);
/*     */     }
/* 227 */     String username = userInfo.substring(0, delimiter);
/* 228 */     String password = userInfo.substring(delimiter + 1);
/* 229 */     return (Credentials)new UsernamePasswordCredentials(username, password);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientConfigurations$ConnectionDetailsCredentialsProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */