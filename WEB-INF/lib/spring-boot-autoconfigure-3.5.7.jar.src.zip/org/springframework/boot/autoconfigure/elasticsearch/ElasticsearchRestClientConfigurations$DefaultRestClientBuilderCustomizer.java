/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
/*     */ import org.apache.http.impl.nio.reactor.IOReactorConfig;
/*     */ import org.elasticsearch.client.RestClientBuilder;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultRestClientBuilderCustomizer
/*     */   implements RestClientBuilderCustomizer
/*     */ {
/* 158 */   private static final PropertyMapper map = PropertyMapper.get();
/*     */   
/*     */   private final ElasticsearchProperties properties;
/*     */   
/*     */   private final ElasticsearchConnectionDetails connectionDetails;
/*     */ 
/*     */   
/*     */   DefaultRestClientBuilderCustomizer(ElasticsearchProperties properties, ElasticsearchConnectionDetails connectionDetails) {
/* 166 */     this.properties = properties;
/* 167 */     this.connectionDetails = connectionDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void customize(RestClientBuilder builder) {}
/*     */ 
/*     */   
/*     */   public void customize(HttpAsyncClientBuilder builder) {
/* 176 */     builder.setDefaultCredentialsProvider((CredentialsProvider)new ElasticsearchRestClientConfigurations.ConnectionDetailsCredentialsProvider(this.connectionDetails));
/* 177 */     Objects.requireNonNull(this.properties); map.from(this.properties::isSocketKeepAlive)
/* 178 */       .to(keepAlive -> builder.setDefaultIOReactorConfig(IOReactorConfig.custom().setSoKeepAlive(keepAlive.booleanValue()).build()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void customize(RequestConfig.Builder builder) {
/* 184 */     Objects.requireNonNull(this.properties);
/*     */ 
/*     */     
/* 187 */     Objects.requireNonNull(builder); map.from(this.properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis).to(builder::setConnectTimeout);
/* 188 */     Objects.requireNonNull(this.properties);
/*     */ 
/*     */     
/* 191 */     Objects.requireNonNull(builder); map.from(this.properties::getSocketTimeout).whenNonNull().asInt(Duration::toMillis).to(builder::setSocketTimeout);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientConfigurations$DefaultRestClientBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */