/*    */ package org.springframework.boot.autoconfigure.elasticsearch;
/*    */ 
/*    */ import co.elastic.clients.transport.ElasticsearchTransport;
/*    */ import org.elasticsearch.client.RestClient;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.elasticsearch.client.elc.ReactiveElasticsearchClient;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {ElasticsearchClientAutoConfiguration.class})
/*    */ @ConditionalOnBean({RestClient.class})
/*    */ @ConditionalOnClass({ReactiveElasticsearchClient.class, ElasticsearchTransport.class, Mono.class})
/*    */ @EnableConfigurationProperties({ElasticsearchProperties.class})
/*    */ @Import({ElasticsearchClientConfigurations.JsonpMapperConfiguration.class, ElasticsearchClientConfigurations.ElasticsearchTransportConfiguration.class})
/*    */ public class ReactiveElasticsearchClientAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnBean({ElasticsearchTransport.class})
/*    */   ReactiveElasticsearchClient reactiveElasticsearchClient(ElasticsearchTransport transport) {
/* 52 */     return new ReactiveElasticsearchClient(transport);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ReactiveElasticsearchClientAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */