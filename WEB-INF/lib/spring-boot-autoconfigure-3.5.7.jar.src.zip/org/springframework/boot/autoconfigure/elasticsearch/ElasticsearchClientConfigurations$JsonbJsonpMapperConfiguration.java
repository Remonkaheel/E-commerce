/*    */ package org.springframework.boot.autoconfigure.elasticsearch;
/*    */ 
/*    */ import co.elastic.clients.json.JsonpMapper;
/*    */ import co.elastic.clients.json.jsonb.JsonbJsonpMapper;
/*    */ import jakarta.json.bind.Jsonb;
/*    */ import jakarta.json.spi.JsonProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnMissingBean({JsonpMapper.class})
/*    */ @ConditionalOnBean({Jsonb.class})
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class JsonbJsonpMapperConfiguration
/*    */ {
/*    */   @Bean
/*    */   JsonbJsonpMapper jsonbJsonpMapper(Jsonb jsonb) {
/* 72 */     return new JsonbJsonpMapper(JsonProvider.provider(), jsonb);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchClientConfigurations$JsonbJsonpMapperConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */