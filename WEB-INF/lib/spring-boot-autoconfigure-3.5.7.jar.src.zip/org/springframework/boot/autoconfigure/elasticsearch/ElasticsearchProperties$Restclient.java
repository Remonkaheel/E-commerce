/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Restclient
/*     */ {
/* 134 */   private final Sniffer sniffer = new Sniffer();
/*     */   
/* 136 */   private final Ssl ssl = new Ssl();
/*     */   
/*     */   public Sniffer getSniffer() {
/* 139 */     return this.sniffer;
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 143 */     return this.ssl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sniffer
/*     */   {
/* 151 */     private Duration interval = Duration.ofMinutes(5L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     private Duration delayAfterFailure = Duration.ofMinutes(1L);
/*     */     
/*     */     public Duration getInterval() {
/* 159 */       return this.interval;
/*     */     }
/*     */     
/*     */     public void setInterval(Duration interval) {
/* 163 */       this.interval = interval;
/*     */     }
/*     */     
/*     */     public Duration getDelayAfterFailure() {
/* 167 */       return this.delayAfterFailure;
/*     */     }
/*     */     
/*     */     public void setDelayAfterFailure(Duration delayAfterFailure) {
/* 171 */       this.delayAfterFailure = delayAfterFailure;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Ssl
/*     */   {
/*     */     private String bundle;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getBundle() {
/* 184 */       return this.bundle;
/*     */     }
/*     */     
/*     */     public void setBundle(String bundle) {
/* 188 */       this.bundle = bundle;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchProperties$Restclient.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */