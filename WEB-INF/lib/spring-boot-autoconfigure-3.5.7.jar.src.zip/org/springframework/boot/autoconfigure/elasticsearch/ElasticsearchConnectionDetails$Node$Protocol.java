/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Protocol
/*     */ {
/* 115 */   HTTP("http"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   HTTPS("https");
/*     */   
/*     */   private final String scheme;
/*     */   
/*     */   Protocol(String scheme) {
/* 125 */     this.scheme = scheme;
/*     */   }
/*     */   
/*     */   String getScheme() {
/* 129 */     return this.scheme;
/*     */   }
/*     */   
/*     */   static Protocol forScheme(String scheme) {
/* 133 */     for (Protocol protocol : values()) {
/* 134 */       if (protocol.scheme.equals(scheme)) {
/* 135 */         return protocol;
/*     */       }
/*     */     } 
/* 138 */     throw new IllegalArgumentException("Unknown scheme '" + scheme + "'");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchConnectionDetails$Node$Protocol.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */