/*    */ package org.springframework.boot.autoconfigure.elasticsearch;
/*    */ 
/*    */ import co.elastic.clients.json.JsonpMapper;
/*    */ import co.elastic.clients.json.jackson.JacksonJsonpMapper;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnMissingBean({JsonpMapper.class})
/*    */ @ConditionalOnClass({ObjectMapper.class})
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class JacksonJsonpMapperConfiguration
/*    */ {
/*    */   @Bean
/*    */   JacksonJsonpMapper jacksonJsonpMapper() {
/* 60 */     return new JacksonJsonpMapper();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchClientConfigurations$JacksonJsonpMapperConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */