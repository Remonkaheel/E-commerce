/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.elasticsearch")
/*     */ public class ElasticsearchProperties
/*     */ {
/*  38 */   private List<String> uris = new ArrayList<>(Collections.singletonList("http://localhost:9200"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String username;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private Duration connectionTimeout = Duration.ofSeconds(1L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private Duration socketTimeout = Duration.ofSeconds(30L);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean socketKeepAlive = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private String pathPrefix;
/*     */ 
/*     */ 
/*     */   
/*  70 */   private final Restclient restclient = new Restclient();
/*     */   
/*     */   public List<String> getUris() {
/*  73 */     return this.uris;
/*     */   }
/*     */   
/*     */   public void setUris(List<String> uris) {
/*  77 */     this.uris = uris;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  81 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  85 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  89 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  93 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Duration getConnectionTimeout() {
/*  97 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Duration connectionTimeout) {
/* 101 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Duration getSocketTimeout() {
/* 105 */     return this.socketTimeout;
/*     */   }
/*     */   
/*     */   public void setSocketTimeout(Duration socketTimeout) {
/* 109 */     this.socketTimeout = socketTimeout;
/*     */   }
/*     */   
/*     */   public boolean isSocketKeepAlive() {
/* 113 */     return this.socketKeepAlive;
/*     */   }
/*     */   
/*     */   public void setSocketKeepAlive(boolean socketKeepAlive) {
/* 117 */     this.socketKeepAlive = socketKeepAlive;
/*     */   }
/*     */   
/*     */   public String getPathPrefix() {
/* 121 */     return this.pathPrefix;
/*     */   }
/*     */   
/*     */   public void setPathPrefix(String pathPrefix) {
/* 125 */     this.pathPrefix = pathPrefix;
/*     */   }
/*     */   
/*     */   public Restclient getRestclient() {
/* 129 */     return this.restclient;
/*     */   }
/*     */   
/*     */   public static class Restclient
/*     */   {
/* 134 */     private final Sniffer sniffer = new Sniffer();
/*     */     
/* 136 */     private final Ssl ssl = new Ssl();
/*     */     
/*     */     public Sniffer getSniffer() {
/* 139 */       return this.sniffer;
/*     */     }
/*     */     
/*     */     public Ssl getSsl() {
/* 143 */       return this.ssl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Sniffer
/*     */     {
/* 151 */       private Duration interval = Duration.ofMinutes(5L);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 156 */       private Duration delayAfterFailure = Duration.ofMinutes(1L);
/*     */       
/*     */       public Duration getInterval() {
/* 159 */         return this.interval;
/*     */       }
/*     */       
/*     */       public void setInterval(Duration interval) {
/* 163 */         this.interval = interval;
/*     */       }
/*     */       
/*     */       public Duration getDelayAfterFailure() {
/* 167 */         return this.delayAfterFailure;
/*     */       }
/*     */       
/*     */       public void setDelayAfterFailure(Duration delayAfterFailure) {
/* 171 */         this.delayAfterFailure = delayAfterFailure;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Ssl
/*     */     {
/*     */       private String bundle;
/*     */ 
/*     */ 
/*     */       
/*     */       public String getBundle() {
/* 184 */         return this.bundle;
/*     */       }
/*     */       
/*     */       public void setBundle(String bundle) {
/* 188 */         this.bundle = bundle; } } } public static class Sniffer { private Duration interval = Duration.ofMinutes(5L); private Duration delayAfterFailure = Duration.ofMinutes(1L); public Duration getInterval() { return this.interval; } public void setInterval(Duration interval) { this.interval = interval; } public Duration getDelayAfterFailure() { return this.delayAfterFailure; } public void setDelayAfterFailure(Duration delayAfterFailure) { this.delayAfterFailure = delayAfterFailure; } } public static class Ssl { public void setBundle(String bundle) { this.bundle = bundle; }
/*     */ 
/*     */     
/*     */     private String bundle;
/*     */     
/*     */     public String getBundle() {
/*     */       return this.bundle;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */