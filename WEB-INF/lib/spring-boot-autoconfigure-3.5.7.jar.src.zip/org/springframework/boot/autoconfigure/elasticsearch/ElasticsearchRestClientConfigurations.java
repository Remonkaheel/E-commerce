/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.Credentials;
/*     */ import org.apache.http.auth.UsernamePasswordCredentials;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.impl.client.BasicCredentialsProvider;
/*     */ import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
/*     */ import org.apache.http.impl.nio.reactor.IOReactorConfig;
/*     */ import org.apache.http.nio.conn.SchemeIOSessionStrategy;
/*     */ import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
/*     */ import org.elasticsearch.client.RestClient;
/*     */ import org.elasticsearch.client.RestClientBuilder;
/*     */ import org.elasticsearch.client.sniff.Sniffer;
/*     */ import org.elasticsearch.client.sniff.SnifferBuilder;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.boot.ssl.SslOptions;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElasticsearchRestClientConfigurations
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({RestClientBuilder.class})
/*     */   static class RestClientBuilderConfiguration
/*     */   {
/*     */     private final ElasticsearchProperties properties;
/*     */     
/*     */     RestClientBuilderConfiguration(ElasticsearchProperties properties) {
/*  75 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({ElasticsearchConnectionDetails.class})
/*     */     ElasticsearchRestClientConfigurations.PropertiesElasticsearchConnectionDetails elasticsearchConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/*  81 */       return new ElasticsearchRestClientConfigurations.PropertiesElasticsearchConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     RestClientBuilderCustomizer defaultRestClientBuilderCustomizer(ElasticsearchConnectionDetails connectionDetails) {
/*  87 */       return new ElasticsearchRestClientConfigurations.DefaultRestClientBuilderCustomizer(this.properties, connectionDetails);
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     RestClientBuilder elasticsearchRestClientBuilder(ElasticsearchConnectionDetails connectionDetails, ObjectProvider<RestClientBuilderCustomizer> builderCustomizers) {
/*  93 */       RestClientBuilder builder = RestClient.builder((HttpHost[])connectionDetails.getNodes()
/*  94 */           .stream()
/*  95 */           .map(node -> new HttpHost(node.hostname(), node.port(), node.protocol().getScheme()))
/*  96 */           .toArray(x$0 -> new HttpHost[x$0]));
/*  97 */       builder.setHttpClientConfigCallback(httpClientBuilder -> {
/*     */             builderCustomizers.orderedStream().forEach(());
/*     */             SslBundle sslBundle = connectionDetails.getSslBundle();
/*     */             if (sslBundle != null) {
/*     */               configureSsl(httpClientBuilder, sslBundle);
/*     */             }
/*     */             return httpClientBuilder;
/*     */           });
/* 105 */       builder.setRequestConfigCallback(requestConfigBuilder -> {
/*     */             builderCustomizers.orderedStream().forEach(());
/*     */             return requestConfigBuilder;
/*     */           });
/* 109 */       String pathPrefix = connectionDetails.getPathPrefix();
/* 110 */       if (pathPrefix != null) {
/* 111 */         builder.setPathPrefix(pathPrefix);
/*     */       }
/* 113 */       builderCustomizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/* 114 */       return builder;
/*     */     }
/*     */     
/*     */     private void configureSsl(HttpAsyncClientBuilder httpClientBuilder, SslBundle sslBundle) {
/* 118 */       SSLContext sslcontext = sslBundle.createSslContext();
/* 119 */       SslOptions sslOptions = sslBundle.getOptions();
/* 120 */       httpClientBuilder.setSSLStrategy((SchemeIOSessionStrategy)new SSLIOSessionStrategy(sslcontext, sslOptions.getEnabledProtocols(), sslOptions
/* 121 */             .getCiphers(), (HostnameVerifier)null));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnMissingBean({RestClient.class})
/*     */   static class RestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     RestClient elasticsearchRestClient(RestClientBuilder restClientBuilder) {
/* 132 */       return restClientBuilder.build();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({Sniffer.class})
/*     */   @ConditionalOnSingleCandidate(RestClient.class)
/*     */   static class RestClientSnifferConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     Sniffer elasticsearchSniffer(RestClient client, ElasticsearchProperties properties) {
/* 145 */       SnifferBuilder builder = Sniffer.builder(client);
/* 146 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 147 */       Duration interval = properties.getRestclient().getSniffer().getInterval();
/* 148 */       Objects.requireNonNull(builder); map.from(interval).asInt(Duration::toMillis).to(builder::setSniffIntervalMillis);
/* 149 */       Duration delayAfterFailure = properties.getRestclient().getSniffer().getDelayAfterFailure();
/* 150 */       Objects.requireNonNull(builder); map.from(delayAfterFailure).asInt(Duration::toMillis).to(builder::setSniffAfterFailureDelayMillis);
/* 151 */       return builder.build();
/*     */     }
/*     */   }
/*     */   
/*     */   static class DefaultRestClientBuilderCustomizer
/*     */     implements RestClientBuilderCustomizer
/*     */   {
/* 158 */     private static final PropertyMapper map = PropertyMapper.get();
/*     */     
/*     */     private final ElasticsearchProperties properties;
/*     */     
/*     */     private final ElasticsearchConnectionDetails connectionDetails;
/*     */ 
/*     */     
/*     */     DefaultRestClientBuilderCustomizer(ElasticsearchProperties properties, ElasticsearchConnectionDetails connectionDetails) {
/* 166 */       this.properties = properties;
/* 167 */       this.connectionDetails = connectionDetails;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void customize(RestClientBuilder builder) {}
/*     */ 
/*     */     
/*     */     public void customize(HttpAsyncClientBuilder builder) {
/* 176 */       builder.setDefaultCredentialsProvider((CredentialsProvider)new ElasticsearchRestClientConfigurations.ConnectionDetailsCredentialsProvider(this.connectionDetails));
/* 177 */       Objects.requireNonNull(this.properties); map.from(this.properties::isSocketKeepAlive)
/* 178 */         .to(keepAlive -> builder.setDefaultIOReactorConfig(IOReactorConfig.custom().setSoKeepAlive(keepAlive.booleanValue()).build()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void customize(RequestConfig.Builder builder) {
/* 184 */       Objects.requireNonNull(this.properties);
/*     */ 
/*     */       
/* 187 */       Objects.requireNonNull(builder); map.from(this.properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis).to(builder::setConnectTimeout);
/* 188 */       Objects.requireNonNull(this.properties);
/*     */ 
/*     */       
/* 191 */       Objects.requireNonNull(builder); map.from(this.properties::getSocketTimeout).whenNonNull().asInt(Duration::toMillis).to(builder::setSocketTimeout);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ConnectionDetailsCredentialsProvider
/*     */     extends BasicCredentialsProvider
/*     */   {
/*     */     ConnectionDetailsCredentialsProvider(ElasticsearchConnectionDetails connectionDetails) {
/* 199 */       String username = connectionDetails.getUsername();
/* 200 */       if (StringUtils.hasText(username)) {
/* 201 */         UsernamePasswordCredentials usernamePasswordCredentials = new UsernamePasswordCredentials(username, connectionDetails.getPassword());
/* 202 */         setCredentials(AuthScope.ANY, (Credentials)usernamePasswordCredentials);
/*     */       } 
/* 204 */       Stream<URI> uris = getUris(connectionDetails);
/* 205 */       uris.filter(this::hasUserInfo).forEach(this::addUserInfoCredentials);
/*     */     }
/*     */     
/*     */     private Stream<URI> getUris(ElasticsearchConnectionDetails connectionDetails) {
/* 209 */       return connectionDetails.getNodes().stream().map(ElasticsearchConnectionDetails.Node::toUri);
/*     */     }
/*     */     
/*     */     private boolean hasUserInfo(URI uri) {
/* 213 */       return (uri != null && StringUtils.hasLength(uri.getUserInfo()));
/*     */     }
/*     */     
/*     */     private void addUserInfoCredentials(URI uri) {
/* 217 */       AuthScope authScope = new AuthScope(uri.getHost(), uri.getPort());
/* 218 */       Credentials credentials = createUserInfoCredentials(uri.getUserInfo());
/* 219 */       setCredentials(authScope, credentials);
/*     */     }
/*     */     
/*     */     private Credentials createUserInfoCredentials(String userInfo) {
/* 223 */       int delimiter = userInfo.indexOf(":");
/* 224 */       if (delimiter == -1) {
/* 225 */         return (Credentials)new UsernamePasswordCredentials(userInfo, null);
/*     */       }
/* 227 */       String username = userInfo.substring(0, delimiter);
/* 228 */       String password = userInfo.substring(delimiter + 1);
/* 229 */       return (Credentials)new UsernamePasswordCredentials(username, password);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class PropertiesElasticsearchConnectionDetails
/*     */     implements ElasticsearchConnectionDetails
/*     */   {
/*     */     private final ElasticsearchProperties properties;
/*     */     
/*     */     private final SslBundles sslBundles;
/*     */ 
/*     */     
/*     */     PropertiesElasticsearchConnectionDetails(ElasticsearchProperties properties, SslBundles sslBundles) {
/* 244 */       this.properties = properties;
/* 245 */       this.sslBundles = sslBundles;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ElasticsearchConnectionDetails.Node> getNodes() {
/* 250 */       return this.properties.getUris().stream().map(this::createNode).toList();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 255 */       return this.properties.getUsername();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 260 */       return this.properties.getPassword();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPathPrefix() {
/* 265 */       return this.properties.getPathPrefix();
/*     */     }
/*     */ 
/*     */     
/*     */     public SslBundle getSslBundle() {
/* 270 */       ElasticsearchProperties.Restclient.Ssl ssl = this.properties.getRestclient().getSsl();
/* 271 */       if (StringUtils.hasLength(ssl.getBundle())) {
/* 272 */         Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 273 */         return this.sslBundles.getBundle(ssl.getBundle());
/*     */       } 
/* 275 */       return null;
/*     */     }
/*     */     
/*     */     private ElasticsearchConnectionDetails.Node createNode(String uri) {
/* 279 */       if (!uri.startsWith("http://") && !uri.startsWith("https://")) {
/* 280 */         uri = "http://" + uri;
/*     */       }
/* 282 */       return createNode(URI.create(uri));
/*     */     }
/*     */     
/*     */     private ElasticsearchConnectionDetails.Node createNode(URI uri) {
/* 286 */       String userInfo = uri.getUserInfo();
/* 287 */       ElasticsearchConnectionDetails.Node.Protocol protocol = ElasticsearchConnectionDetails.Node.Protocol.forScheme(uri.getScheme());
/* 288 */       if (!StringUtils.hasLength(userInfo)) {
/* 289 */         return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, null, null);
/*     */       }
/* 291 */       int separatorIndex = userInfo.indexOf(':');
/* 292 */       if (separatorIndex == -1) {
/* 293 */         return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, userInfo, null);
/*     */       }
/* 295 */       String[] components = userInfo.split(":");
/* 296 */       return new ElasticsearchConnectionDetails.Node(uri.getHost(), uri.getPort(), protocol, components[0], 
/* 297 */           (components.length > 1) ? components[1] : "");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientConfigurations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */