/*     */ package org.springframework.boot.autoconfigure.diagnostics.analyzer;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.boot.diagnostics.analyzer.AbstractInjectionFailureAnalyzer;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoSuchBeanDefinitionFailureAnalyzer
/*     */   extends AbstractInjectionFailureAnalyzer<NoSuchBeanDefinitionException>
/*     */ {
/*     */   private final ConfigurableListableBeanFactory beanFactory;
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ConditionEvaluationReport report;
/*     */   
/*     */   NoSuchBeanDefinitionFailureAnalyzer(BeanFactory beanFactory) {
/*  68 */     Assert.isTrue(beanFactory instanceof ConfigurableListableBeanFactory, "'beanFactory' must be a ConfigurableListableBeanFactory");
/*     */     
/*  70 */     this.beanFactory = (ConfigurableListableBeanFactory)beanFactory;
/*  71 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(this.beanFactory.getBeanClassLoader());
/*     */     
/*  73 */     this.report = ConditionEvaluationReport.get(this.beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchBeanDefinitionException cause, String description) {
/*  78 */     if (cause.getNumberOfBeansFound() != 0) {
/*  79 */       return null;
/*     */     }
/*  81 */     List<AutoConfigurationResult> autoConfigurationResults = getAutoConfigurationResults(cause);
/*  82 */     List<UserConfigurationResult> userConfigurationResults = getUserConfigurationResults(cause);
/*  83 */     StringBuilder message = new StringBuilder();
/*  84 */     message.append(String.format("%s required %s that could not be found.%n", new Object[] {
/*  85 */             (description != null) ? description : "A component", getBeanDescription(cause) }));
/*  86 */     InjectionPoint injectionPoint = findInjectionPoint(rootFailure);
/*  87 */     if (injectionPoint != null) {
/*  88 */       Annotation[] injectionAnnotations = injectionPoint.getAnnotations();
/*  89 */       if (injectionAnnotations.length > 0) {
/*  90 */         message.append(String.format("%nThe injection point has the following annotations:%n", new Object[0]));
/*  91 */         for (Annotation injectionAnnotation : injectionAnnotations) {
/*  92 */           message.append(String.format("\t- %s%n", new Object[] { injectionAnnotation }));
/*     */         } 
/*     */       } 
/*     */     } 
/*  96 */     if (!autoConfigurationResults.isEmpty() || !userConfigurationResults.isEmpty()) {
/*  97 */       message.append(String.format("%nThe following candidates were found but could not be injected:%n", new Object[0]));
/*  98 */       for (AutoConfigurationResult result : autoConfigurationResults) {
/*  99 */         message.append(String.format("\t- %s%n", new Object[] { result }));
/*     */       } 
/* 101 */       for (UserConfigurationResult result : userConfigurationResults) {
/* 102 */         message.append(String.format("\t- %s%n", new Object[] { result }));
/*     */       } 
/*     */     } 
/* 105 */     String action = String.format("Consider %s %s in your configuration.", new Object[] { (
/* 106 */           !autoConfigurationResults.isEmpty() || !userConfigurationResults.isEmpty()) ? 
/* 107 */           "revisiting the entries above or defining" : "defining", 
/* 108 */           getBeanDescription(cause) });
/* 109 */     return new FailureAnalysis(message.toString(), action, (Throwable)cause);
/*     */   }
/*     */   
/*     */   private String getBeanDescription(NoSuchBeanDefinitionException cause) {
/* 113 */     if (cause.getResolvableType() != null) {
/* 114 */       Class<?> type = extractBeanType(cause.getResolvableType());
/* 115 */       return "a bean of type '" + type.getName() + "'";
/*     */     } 
/* 117 */     return "a bean named '" + cause.getBeanName() + "'";
/*     */   }
/*     */   
/*     */   private Class<?> extractBeanType(ResolvableType resolvableType) {
/* 121 */     return resolvableType.getRawClass();
/*     */   }
/*     */   
/*     */   private List<AutoConfigurationResult> getAutoConfigurationResults(NoSuchBeanDefinitionException cause) {
/* 125 */     List<AutoConfigurationResult> results = new ArrayList<>();
/* 126 */     collectReportedConditionOutcomes(cause, results);
/* 127 */     collectExcludedAutoConfiguration(cause, results);
/* 128 */     return results;
/*     */   }
/*     */   
/*     */   private List<UserConfigurationResult> getUserConfigurationResults(NoSuchBeanDefinitionException cause) {
/* 132 */     ResolvableType type = cause.getResolvableType();
/* 133 */     if (type == null) {
/* 134 */       return Collections.emptyList();
/*     */     }
/* 136 */     String[] beanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, type);
/* 137 */     return Arrays.<String>stream(beanNames)
/* 138 */       .map(beanName -> new UserConfigurationResult(getFactoryMethodMetadata(beanName), this.beanFactory.getBean(beanName).equals(null)))
/*     */       
/* 140 */       .toList();
/*     */   }
/*     */   
/*     */   private MethodMetadata getFactoryMethodMetadata(String beanName) {
/* 144 */     BeanDefinition beanDefinition = this.beanFactory.getBeanDefinition(beanName);
/* 145 */     if (beanDefinition instanceof AnnotatedBeanDefinition) { AnnotatedBeanDefinition annotatedBeanDefinition = (AnnotatedBeanDefinition)beanDefinition;
/* 146 */       return annotatedBeanDefinition.getFactoryMethodMetadata(); }
/*     */     
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectReportedConditionOutcomes(NoSuchBeanDefinitionException cause, List<AutoConfigurationResult> results) {
/* 153 */     this.report.getConditionAndOutcomesBySource()
/* 154 */       .forEach((source, sourceOutcomes) -> collectReportedConditionOutcomes(cause, new Source(source), sourceOutcomes, results));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectReportedConditionOutcomes(NoSuchBeanDefinitionException cause, Source source, ConditionEvaluationReport.ConditionAndOutcomes sourceOutcomes, List<AutoConfigurationResult> results) {
/* 160 */     if (sourceOutcomes.isFullMatch()) {
/*     */       return;
/*     */     }
/* 163 */     BeanMethods methods = new BeanMethods(source, cause);
/* 164 */     for (ConditionEvaluationReport.ConditionAndOutcome conditionAndOutcome : sourceOutcomes) {
/* 165 */       if (!conditionAndOutcome.getOutcome().isMatch()) {
/* 166 */         for (MethodMetadata method : methods) {
/* 167 */           results.add(new AutoConfigurationResult(method, conditionAndOutcome.getOutcome()));
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void collectExcludedAutoConfiguration(NoSuchBeanDefinitionException cause, List<AutoConfigurationResult> results) {
/* 175 */     for (String excludedClass : this.report.getExclusions()) {
/* 176 */       Source source = new Source(excludedClass);
/* 177 */       BeanMethods methods = new BeanMethods(source, cause);
/* 178 */       for (MethodMetadata method : methods) {
/* 179 */         String message = String.format("auto-configuration '%s' was excluded", new Object[] {
/* 180 */               ClassUtils.getShortName(excludedClass) });
/* 181 */         results.add(new AutoConfigurationResult(method, new ConditionOutcome(false, message)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private InjectionPoint findInjectionPoint(Throwable failure) {
/* 187 */     UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)findCause(failure, UnsatisfiedDependencyException.class);
/*     */     
/* 189 */     if (unsatisfiedDependencyException == null) {
/* 190 */       return null;
/*     */     }
/* 192 */     return unsatisfiedDependencyException.getInjectionPoint();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Source
/*     */   {
/*     */     private final String className;
/*     */     private final String methodName;
/*     */     
/*     */     Source(String source) {
/* 202 */       String[] tokens = source.split("#");
/* 203 */       this.className = (tokens.length > 1) ? tokens[0] : source;
/* 204 */       this.methodName = (tokens.length != 2) ? null : tokens[1];
/*     */     }
/*     */     
/*     */     String getClassName() {
/* 208 */       return this.className;
/*     */     }
/*     */     
/*     */     String getMethodName() {
/* 212 */       return this.methodName;
/*     */     }
/*     */   }
/*     */   
/*     */   private class BeanMethods
/*     */     implements Iterable<MethodMetadata>
/*     */   {
/*     */     private final List<MethodMetadata> methods;
/*     */     
/*     */     BeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 222 */       this.methods = findBeanMethods(source, cause);
/*     */     }
/*     */ 
/*     */     
/*     */     private List<MethodMetadata> findBeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/*     */       try {
/* 228 */         MetadataReader classMetadata = NoSuchBeanDefinitionFailureAnalyzer.this.metadataReaderFactory.getMetadataReader(source.getClassName());
/*     */         
/* 230 */         Set<MethodMetadata> candidates = classMetadata.getAnnotationMetadata().getAnnotatedMethods(Bean.class.getName());
/* 231 */         List<MethodMetadata> result = new ArrayList<>();
/* 232 */         for (MethodMetadata candidate : candidates) {
/* 233 */           if (isMatch(candidate, source, cause)) {
/* 234 */             result.add(candidate);
/*     */           }
/*     */         } 
/* 237 */         return Collections.unmodifiableList(result);
/*     */       }
/* 239 */       catch (Exception ex) {
/* 240 */         return Collections.emptyList();
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isMatch(MethodMetadata candidate, NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 245 */       if (source.getMethodName() != null && !source.getMethodName().equals(candidate.getMethodName())) {
/* 246 */         return false;
/*     */       }
/* 248 */       String name = cause.getBeanName();
/* 249 */       ResolvableType resolvableType = cause.getResolvableType();
/* 250 */       return ((name != null && hasName(candidate, name)) || (resolvableType != null && 
/* 251 */         hasType(candidate, NoSuchBeanDefinitionFailureAnalyzer.this.extractBeanType(resolvableType))));
/*     */     }
/*     */     
/*     */     private boolean hasName(MethodMetadata methodMetadata, String name) {
/* 255 */       Map<String, Object> attributes = methodMetadata.getAnnotationAttributes(Bean.class.getName());
/* 256 */       String[] candidates = (attributes != null) ? (String[])attributes.get("name") : null;
/* 257 */       if (candidates != null) {
/* 258 */         for (String candidate : candidates) {
/* 259 */           if (candidate.equals(name)) {
/* 260 */             return true;
/*     */           }
/*     */         } 
/* 263 */         return false;
/*     */       } 
/* 265 */       return methodMetadata.getMethodName().equals(name);
/*     */     }
/*     */     
/*     */     private boolean hasType(MethodMetadata candidate, Class<?> type) {
/* 269 */       String returnTypeName = candidate.getReturnTypeName();
/* 270 */       if (type.getName().equals(returnTypeName)) {
/* 271 */         return true;
/*     */       }
/*     */       try {
/* 274 */         Class<?> returnType = ClassUtils.forName(returnTypeName, NoSuchBeanDefinitionFailureAnalyzer.this.beanFactory
/* 275 */             .getBeanClassLoader());
/* 276 */         return type.isAssignableFrom(returnType);
/*     */       }
/* 278 */       catch (Throwable ex) {
/* 279 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<MethodMetadata> iterator() {
/* 285 */       return this.methods.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AutoConfigurationResult
/*     */   {
/*     */     private final MethodMetadata methodMetadata;
/*     */     
/*     */     private final ConditionOutcome conditionOutcome;
/*     */     
/*     */     AutoConfigurationResult(MethodMetadata methodMetadata, ConditionOutcome conditionOutcome) {
/* 297 */       this.methodMetadata = methodMetadata;
/* 298 */       this.conditionOutcome = conditionOutcome;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 303 */       return String.format("Bean method '%s' in '%s' not loaded because %s", new Object[] { this.methodMetadata.getMethodName(), 
/* 304 */             ClassUtils.getShortName(this.methodMetadata.getDeclaringClassName()), this.conditionOutcome
/* 305 */             .getMessage() });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class UserConfigurationResult
/*     */   {
/*     */     private final MethodMetadata methodMetadata;
/*     */     
/*     */     private final boolean nullBean;
/*     */     
/*     */     UserConfigurationResult(MethodMetadata methodMetadata, boolean nullBean) {
/* 317 */       this.methodMetadata = methodMetadata;
/* 318 */       this.nullBean = nullBean;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 323 */       StringBuilder sb = new StringBuilder("User-defined bean");
/* 324 */       if (this.methodMetadata != null) {
/* 325 */         sb.append(String.format(" method '%s' in '%s'", new Object[] { this.methodMetadata.getMethodName(), 
/* 326 */                 ClassUtils.getShortName(this.methodMetadata.getDeclaringClassName()) }));
/*     */       }
/* 328 */       if (this.nullBean) {
/* 329 */         sb.append(" ignored as the bean value is null");
/*     */       }
/* 331 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\diagnostics\analyzer\NoSuchBeanDefinitionFailureAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */