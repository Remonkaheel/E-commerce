/*     */ package org.springframework.boot.autoconfigure.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanMethods
/*     */   implements Iterable<MethodMetadata>
/*     */ {
/*     */   private final List<MethodMetadata> methods;
/*     */   
/*     */   BeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 222 */     this.methods = findBeanMethods(source, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<MethodMetadata> findBeanMethods(NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/*     */     try {
/* 228 */       MetadataReader classMetadata = NoSuchBeanDefinitionFailureAnalyzer.this.metadataReaderFactory.getMetadataReader(source.getClassName());
/*     */       
/* 230 */       Set<MethodMetadata> candidates = classMetadata.getAnnotationMetadata().getAnnotatedMethods(Bean.class.getName());
/* 231 */       List<MethodMetadata> result = new ArrayList<>();
/* 232 */       for (MethodMetadata candidate : candidates) {
/* 233 */         if (isMatch(candidate, source, cause)) {
/* 234 */           result.add(candidate);
/*     */         }
/*     */       } 
/* 237 */       return Collections.unmodifiableList(result);
/*     */     }
/* 239 */     catch (Exception ex) {
/* 240 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isMatch(MethodMetadata candidate, NoSuchBeanDefinitionFailureAnalyzer.Source source, NoSuchBeanDefinitionException cause) {
/* 245 */     if (source.getMethodName() != null && !source.getMethodName().equals(candidate.getMethodName())) {
/* 246 */       return false;
/*     */     }
/* 248 */     String name = cause.getBeanName();
/* 249 */     ResolvableType resolvableType = cause.getResolvableType();
/* 250 */     return ((name != null && hasName(candidate, name)) || (resolvableType != null && 
/* 251 */       hasType(candidate, NoSuchBeanDefinitionFailureAnalyzer.this.extractBeanType(resolvableType))));
/*     */   }
/*     */   
/*     */   private boolean hasName(MethodMetadata methodMetadata, String name) {
/* 255 */     Map<String, Object> attributes = methodMetadata.getAnnotationAttributes(Bean.class.getName());
/* 256 */     String[] candidates = (attributes != null) ? (String[])attributes.get("name") : null;
/* 257 */     if (candidates != null) {
/* 258 */       for (String candidate : candidates) {
/* 259 */         if (candidate.equals(name)) {
/* 260 */           return true;
/*     */         }
/*     */       } 
/* 263 */       return false;
/*     */     } 
/* 265 */     return methodMetadata.getMethodName().equals(name);
/*     */   }
/*     */   
/*     */   private boolean hasType(MethodMetadata candidate, Class<?> type) {
/* 269 */     String returnTypeName = candidate.getReturnTypeName();
/* 270 */     if (type.getName().equals(returnTypeName)) {
/* 271 */       return true;
/*     */     }
/*     */     try {
/* 274 */       Class<?> returnType = ClassUtils.forName(returnTypeName, NoSuchBeanDefinitionFailureAnalyzer.this.beanFactory
/* 275 */           .getBeanClassLoader());
/* 276 */       return type.isAssignableFrom(returnType);
/*     */     }
/* 278 */     catch (Throwable ex) {
/* 279 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<MethodMetadata> iterator() {
/* 285 */     return this.methods.iterator();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\diagnostics\analyzer\NoSuchBeanDefinitionFailureAnalyzer$BeanMethods.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */