/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleRabbitListenerContainerFactoryConfigurer
/*    */   extends AbstractRabbitListenerContainerFactoryConfigurer<SimpleRabbitListenerContainerFactory>
/*    */ {
/*    */   public SimpleRabbitListenerContainerFactoryConfigurer(RabbitProperties rabbitProperties) {
/* 44 */     super(rabbitProperties);
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(SimpleRabbitListenerContainerFactory factory, ConnectionFactory connectionFactory) {
/* 49 */     PropertyMapper map = PropertyMapper.get();
/* 50 */     RabbitProperties.SimpleContainer config = getRabbitProperties().getListener().getSimple();
/* 51 */     configure(factory, connectionFactory, config);
/* 52 */     Objects.requireNonNull(config); Objects.requireNonNull(factory); map.from(config::getConcurrency).whenNonNull().to(factory::setConcurrentConsumers);
/* 53 */     Objects.requireNonNull(config); Objects.requireNonNull(factory); map.from(config::getMaxConcurrency).whenNonNull().to(factory::setMaxConcurrentConsumers);
/* 54 */     Objects.requireNonNull(config); Objects.requireNonNull(factory); map.from(config::getBatchSize).whenNonNull().to(factory::setBatchSize);
/* 55 */     Objects.requireNonNull(config); Objects.requireNonNull(factory); map.from(config::isConsumerBatchEnabled).to(factory::setConsumerBatchEnabled);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\SimpleRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */