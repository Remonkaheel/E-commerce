/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import com.rabbitmq.client.impl.CredentialsProvider;
/*     */ import com.rabbitmq.client.impl.CredentialsRefreshService;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.ssl.SslBundle;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RabbitConnectionFactoryBeanConfigurer
/*     */ {
/*     */   private final RabbitProperties rabbitProperties;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final RabbitConnectionDetails connectionDetails;
/*     */   private CredentialsProvider credentialsProvider;
/*     */   private CredentialsRefreshService credentialsRefreshService;
/*     */   
/*     */   public RabbitConnectionFactoryBeanConfigurer(ResourceLoader resourceLoader, RabbitProperties properties) {
/*  67 */     this(resourceLoader, properties, new PropertiesRabbitConnectionDetails(properties, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RabbitConnectionFactoryBeanConfigurer(ResourceLoader resourceLoader, RabbitProperties properties, RabbitConnectionDetails connectionDetails) {
/*  81 */     this(resourceLoader, properties, connectionDetails, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RabbitConnectionFactoryBeanConfigurer(ResourceLoader resourceLoader, RabbitProperties properties, RabbitConnectionDetails connectionDetails, SslBundles sslBundles) {
/*  96 */     Assert.notNull(resourceLoader, "'resourceLoader' must not be null");
/*  97 */     Assert.notNull(properties, "'properties' must not be null");
/*  98 */     Assert.notNull(connectionDetails, "'connectionDetails' must not be null");
/*  99 */     this.resourceLoader = resourceLoader;
/* 100 */     this.rabbitProperties = properties;
/* 101 */     this.connectionDetails = connectionDetails;
/*     */   }
/*     */   
/*     */   public void setCredentialsProvider(CredentialsProvider credentialsProvider) {
/* 105 */     this.credentialsProvider = credentialsProvider;
/*     */   }
/*     */   
/*     */   public void setCredentialsRefreshService(CredentialsRefreshService credentialsRefreshService) {
/* 109 */     this.credentialsRefreshService = credentialsRefreshService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(RabbitConnectionFactoryBean factory) {
/* 120 */     Assert.notNull(factory, "'factory' must not be null");
/* 121 */     factory.setResourceLoader(this.resourceLoader);
/* 122 */     RabbitConnectionDetails.Address address = this.connectionDetails.getFirstAddress();
/* 123 */     PropertyMapper map = PropertyMapper.get();
/* 124 */     Objects.requireNonNull(address); Objects.requireNonNull(factory); map.from(address::host).whenNonNull().to(factory::setHost);
/* 125 */     Objects.requireNonNull(address); Objects.requireNonNull(factory); map.from(address::port).to(factory::setPort);
/* 126 */     Objects.requireNonNull(this.connectionDetails); Objects.requireNonNull(factory); map.from(this.connectionDetails::getUsername).whenNonNull().to(factory::setUsername);
/* 127 */     Objects.requireNonNull(this.connectionDetails); Objects.requireNonNull(factory); map.from(this.connectionDetails::getPassword).whenNonNull().to(factory::setPassword);
/* 128 */     Objects.requireNonNull(this.connectionDetails); Objects.requireNonNull(factory); map.from(this.connectionDetails::getVirtualHost).whenNonNull().to(factory::setVirtualHost);
/* 129 */     Objects.requireNonNull(this.rabbitProperties);
/*     */ 
/*     */     
/* 132 */     Objects.requireNonNull(factory); map.from(this.rabbitProperties::getRequestedHeartbeat).whenNonNull().asInt(Duration::getSeconds).to(factory::setRequestedHeartbeat);
/* 133 */     Objects.requireNonNull(this.rabbitProperties); Objects.requireNonNull(factory); map.from(this.rabbitProperties::getRequestedChannelMax).to(factory::setRequestedChannelMax);
/* 134 */     SslBundle sslBundle = this.connectionDetails.getSslBundle();
/* 135 */     if (sslBundle != null) {
/* 136 */       applySslBundle(factory, sslBundle);
/*     */     } else {
/*     */       
/* 139 */       RabbitProperties.Ssl ssl = this.rabbitProperties.getSsl();
/* 140 */       if (ssl.determineEnabled()) {
/* 141 */         factory.setUseSSL(true);
/* 142 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getAlgorithm).whenNonNull().to(factory::setSslAlgorithm);
/* 143 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getKeyStoreType).to(factory::setKeyStoreType);
/* 144 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getKeyStore).to(factory::setKeyStore);
/* 145 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getKeyStorePassword).to(factory::setKeyStorePassphrase);
/* 146 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getKeyStoreAlgorithm).whenNonNull().to(factory::setKeyStoreAlgorithm);
/* 147 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getTrustStoreType).to(factory::setTrustStoreType);
/* 148 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getTrustStore).to(factory::setTrustStore);
/* 149 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getTrustStorePassword).to(factory::setTrustStorePassphrase);
/* 150 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::getTrustStoreAlgorithm).whenNonNull().to(factory::setTrustStoreAlgorithm);
/* 151 */         Objects.requireNonNull(ssl); map.from(ssl::isValidateServerCertificate)
/* 152 */           .to(validate -> factory.setSkipServerCertificateValidation(!validate.booleanValue()));
/* 153 */         Objects.requireNonNull(ssl); Objects.requireNonNull(factory); map.from(ssl::isVerifyHostname).to(factory::setEnableHostnameVerification);
/*     */       } 
/*     */     } 
/* 156 */     Objects.requireNonNull(this.rabbitProperties);
/*     */ 
/*     */     
/* 159 */     Objects.requireNonNull(factory); map.from(this.rabbitProperties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis).to(factory::setConnectionTimeout);
/* 160 */     Objects.requireNonNull(this.rabbitProperties);
/*     */ 
/*     */     
/* 163 */     Objects.requireNonNull(factory); map.from(this.rabbitProperties::getChannelRpcTimeout).whenNonNull().asInt(Duration::toMillis).to(factory::setChannelRpcTimeout);
/* 164 */     Objects.requireNonNull(factory); map.from(this.credentialsProvider).whenNonNull().to(factory::setCredentialsProvider);
/* 165 */     Objects.requireNonNull(factory); map.from(this.credentialsRefreshService).whenNonNull().to(factory::setCredentialsRefreshService);
/*     */ 
/*     */ 
/*     */     
/* 169 */     Objects.requireNonNull(factory); map.from(this.rabbitProperties.getMaxInboundMessageBodySize()).whenNonNull().asInt(DataSize::toBytes).to(factory::setMaxInboundMessageBodySize);
/*     */   }
/*     */   
/*     */   private static void applySslBundle(RabbitConnectionFactoryBean factory, SslBundle bundle) {
/* 173 */     factory.setUseSSL(true);
/* 174 */     if (factory instanceof SslBundleRabbitConnectionFactoryBean) { SslBundleRabbitConnectionFactoryBean sslFactory = (SslBundleRabbitConnectionFactoryBean)factory;
/* 175 */       sslFactory.setSslBundle(bundle); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitConnectionFactoryBeanConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */