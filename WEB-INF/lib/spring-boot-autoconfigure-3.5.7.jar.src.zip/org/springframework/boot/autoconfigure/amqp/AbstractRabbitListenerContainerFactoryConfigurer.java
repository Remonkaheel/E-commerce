/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.retry.MessageRecoverer;
/*     */ import org.springframework.amqp.rabbit.retry.RejectAndDontRequeueRecoverer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.retry.RetryOperations;
/*     */ import org.springframework.retry.support.RetryTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRabbitListenerContainerFactoryConfigurer<T extends AbstractRabbitListenerContainerFactory<?>>
/*     */ {
/*     */   private MessageConverter messageConverter;
/*     */   private MessageRecoverer messageRecoverer;
/*     */   private List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers;
/*     */   private final RabbitProperties rabbitProperties;
/*     */   private Executor taskExecutor;
/*     */   
/*     */   protected AbstractRabbitListenerContainerFactoryConfigurer(RabbitProperties rabbitProperties) {
/*  59 */     this.rabbitProperties = rabbitProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMessageConverter(MessageConverter messageConverter) {
/*  68 */     this.messageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMessageRecoverer(MessageRecoverer messageRecoverer) {
/*  76 */     this.messageRecoverer = messageRecoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRetryTemplateCustomizers(List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {
/*  84 */     this.retryTemplateCustomizers = retryTemplateCustomizers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTaskExecutor(Executor taskExecutor) {
/*  93 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */   
/*     */   protected final RabbitProperties getRabbitProperties() {
/*  97 */     return this.rabbitProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void configure(T paramT, ConnectionFactory paramConnectionFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configure(T factory, ConnectionFactory connectionFactory, RabbitProperties.AmqpContainer configuration) {
/* 111 */     Assert.notNull(factory, "'factory' must not be null");
/* 112 */     Assert.notNull(connectionFactory, "'connectionFactory' must not be null");
/* 113 */     Assert.notNull(configuration, "'configuration' must not be null");
/* 114 */     factory.setConnectionFactory(connectionFactory);
/* 115 */     if (this.messageConverter != null) {
/* 116 */       factory.setMessageConverter(this.messageConverter);
/*     */     }
/* 118 */     factory.setAutoStartup(Boolean.valueOf(configuration.isAutoStartup()));
/* 119 */     if (configuration.getAcknowledgeMode() != null) {
/* 120 */       factory.setAcknowledgeMode(configuration.getAcknowledgeMode());
/*     */     }
/* 122 */     if (configuration.getPrefetch() != null) {
/* 123 */       factory.setPrefetchCount(configuration.getPrefetch());
/*     */     }
/* 125 */     if (configuration.getDefaultRequeueRejected() != null) {
/* 126 */       factory.setDefaultRequeueRejected(configuration.getDefaultRequeueRejected());
/*     */     }
/* 128 */     if (configuration.getIdleEventInterval() != null) {
/* 129 */       factory.setIdleEventInterval(Long.valueOf(configuration.getIdleEventInterval().toMillis()));
/*     */     }
/* 131 */     factory.setMissingQueuesFatal(Boolean.valueOf(configuration.isMissingQueuesFatal()));
/* 132 */     factory.setDeBatchingEnabled(Boolean.valueOf(configuration.isDeBatchingEnabled()));
/* 133 */     factory.setForceStop(configuration.isForceStop());
/* 134 */     if (this.taskExecutor != null) {
/* 135 */       factory.setTaskExecutor(this.taskExecutor);
/*     */     }
/* 137 */     factory.setObservationEnabled(configuration.isObservationEnabled());
/* 138 */     RabbitProperties.ListenerRetry retryConfig = configuration.getRetry();
/* 139 */     if (retryConfig.isEnabled()) {
/*     */       
/* 141 */       RetryInterceptorBuilder<?, ?> builder = retryConfig.isStateless() ? (RetryInterceptorBuilder<?, ?>)RetryInterceptorBuilder.stateless() : (RetryInterceptorBuilder<?, ?>)RetryInterceptorBuilder.stateful();
/*     */       
/* 143 */       RetryTemplate retryTemplate = (new RetryTemplateFactory(this.retryTemplateCustomizers)).createRetryTemplate(retryConfig, RabbitRetryTemplateCustomizer.Target.LISTENER);
/* 144 */       builder.retryOperations((RetryOperations)retryTemplate);
/*     */       
/* 146 */       MessageRecoverer recoverer = (this.messageRecoverer != null) ? this.messageRecoverer : (MessageRecoverer)new RejectAndDontRequeueRecoverer();
/* 147 */       builder.recoverer(recoverer);
/* 148 */       factory.setAdviceChain(new Advice[] { (Advice)builder.build() });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\AbstractRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */