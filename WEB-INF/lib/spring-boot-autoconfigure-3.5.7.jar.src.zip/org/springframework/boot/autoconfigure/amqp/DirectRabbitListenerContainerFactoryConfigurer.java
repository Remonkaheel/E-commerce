/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.amqp.rabbit.config.AbstractRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.config.DirectRabbitListenerContainerFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DirectRabbitListenerContainerFactoryConfigurer
/*    */   extends AbstractRabbitListenerContainerFactoryConfigurer<DirectRabbitListenerContainerFactory>
/*    */ {
/*    */   public DirectRabbitListenerContainerFactoryConfigurer(RabbitProperties rabbitProperties) {
/* 44 */     super(rabbitProperties);
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(DirectRabbitListenerContainerFactory factory, ConnectionFactory connectionFactory) {
/* 49 */     PropertyMapper map = PropertyMapper.get();
/* 50 */     RabbitProperties.DirectContainer config = getRabbitProperties().getListener().getDirect();
/* 51 */     configure(factory, connectionFactory, config);
/* 52 */     Objects.requireNonNull(config); Objects.requireNonNull(factory); map.from(config::getConsumersPerQueue).whenNonNull().to(factory::setConsumersPerQueue);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\DirectRabbitListenerContainerFactoryConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */