/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ import org.springframework.boot.ssl.SslBundles;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertiesRabbitConnectionDetails
/*    */   implements RabbitConnectionDetails
/*    */ {
/*    */   private final RabbitProperties properties;
/*    */   private final SslBundles sslBundles;
/*    */   
/*    */   PropertiesRabbitConnectionDetails(RabbitProperties properties, SslBundles sslBundles) {
/* 42 */     this.properties = properties;
/* 43 */     this.sslBundles = sslBundles;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 48 */     return this.properties.determineUsername();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 53 */     return this.properties.determinePassword();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getVirtualHost() {
/* 58 */     return this.properties.determineVirtualHost();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<RabbitConnectionDetails.Address> getAddresses() {
/* 63 */     List<RabbitConnectionDetails.Address> addresses = new ArrayList<>();
/* 64 */     for (String address : this.properties.determineAddresses()) {
/* 65 */       int portSeparatorIndex = address.lastIndexOf(':');
/* 66 */       String host = address.substring(0, portSeparatorIndex);
/* 67 */       String port = address.substring(portSeparatorIndex + 1);
/* 68 */       addresses.add(new RabbitConnectionDetails.Address(host, Integer.parseInt(port)));
/*    */     } 
/* 70 */     return addresses;
/*    */   }
/*    */ 
/*    */   
/*    */   public SslBundle getSslBundle() {
/* 75 */     RabbitProperties.Ssl ssl = this.properties.getSsl();
/* 76 */     if (!ssl.determineEnabled()) {
/* 77 */       return null;
/*    */     }
/* 79 */     if (StringUtils.hasLength(ssl.getBundle())) {
/* 80 */       Assert.notNull(this.sslBundles, "SSL bundle name has been set but no SSL bundles found in context");
/* 81 */       return this.sslBundles.getBundle(ssl.getBundle());
/*    */     } 
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\PropertiesRabbitConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */