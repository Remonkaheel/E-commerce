/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.core.RabbitTemplate;
/*     */ import org.springframework.amqp.support.converter.AllowedListDeserializingMessageConverter;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RabbitTemplateConfigurer
/*     */ {
/*     */   private MessageConverter messageConverter;
/*     */   private List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers;
/*     */   private final RabbitProperties rabbitProperties;
/*     */   
/*     */   public RabbitTemplateConfigurer(RabbitProperties rabbitProperties) {
/*  57 */     Assert.notNull(rabbitProperties, "'rabbitProperties' must not be null");
/*  58 */     this.rabbitProperties = rabbitProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageConverter(MessageConverter messageConverter) {
/*  68 */     this.messageConverter = messageConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRetryTemplateCustomizers(List<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {
/*  77 */     this.retryTemplateCustomizers = retryTemplateCustomizers;
/*     */   }
/*     */   
/*     */   protected final RabbitProperties getRabbitProperties() {
/*  81 */     return this.rabbitProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(RabbitTemplate template, ConnectionFactory connectionFactory) {
/*  91 */     PropertyMapper map = PropertyMapper.get();
/*  92 */     template.setConnectionFactory(connectionFactory);
/*  93 */     if (this.messageConverter != null) {
/*  94 */       template.setMessageConverter(this.messageConverter);
/*     */     }
/*  96 */     template.setMandatory(determineMandatoryFlag());
/*  97 */     RabbitProperties.Template templateProperties = this.rabbitProperties.getTemplate();
/*  98 */     if (templateProperties.getRetry().isEnabled()) {
/*  99 */       template.setRetryTemplate((new RetryTemplateFactory(this.retryTemplateCustomizers))
/* 100 */           .createRetryTemplate(templateProperties.getRetry(), RabbitRetryTemplateCustomizer.Target.SENDER));
/*     */     }
/* 102 */     Objects.requireNonNull(templateProperties);
/*     */ 
/*     */     
/* 105 */     Objects.requireNonNull(template); map.from(templateProperties::getReceiveTimeout).whenNonNull().as(Duration::toMillis).to(template::setReceiveTimeout);
/* 106 */     Objects.requireNonNull(templateProperties);
/*     */ 
/*     */     
/* 109 */     Objects.requireNonNull(template); map.from(templateProperties::getReplyTimeout).whenNonNull().as(Duration::toMillis).to(template::setReplyTimeout);
/* 110 */     Objects.requireNonNull(templateProperties); Objects.requireNonNull(template); map.from(templateProperties::getExchange).to(template::setExchange);
/* 111 */     Objects.requireNonNull(templateProperties); Objects.requireNonNull(template); map.from(templateProperties::getRoutingKey).to(template::setRoutingKey);
/* 112 */     Objects.requireNonNull(templateProperties); Objects.requireNonNull(template); map.from(templateProperties::getDefaultReceiveQueue).whenNonNull().to(template::setDefaultReceiveQueue);
/* 113 */     Objects.requireNonNull(templateProperties); Objects.requireNonNull(template); map.from(templateProperties::isObservationEnabled).to(template::setObservationEnabled);
/* 114 */     Objects.requireNonNull(templateProperties); map.from(templateProperties::getAllowedListPatterns)
/* 115 */       .whenNot(CollectionUtils::isEmpty)
/* 116 */       .to(allowedListPatterns -> setAllowedListPatterns(template.getMessageConverter(), allowedListPatterns));
/*     */   }
/*     */   
/*     */   private void setAllowedListPatterns(MessageConverter messageConverter, List<String> allowedListPatterns) {
/* 120 */     if (messageConverter instanceof AllowedListDeserializingMessageConverter) { AllowedListDeserializingMessageConverter allowedListDeserializingMessageConverter = (AllowedListDeserializingMessageConverter)messageConverter;
/* 121 */       allowedListDeserializingMessageConverter.setAllowedListPatterns(allowedListPatterns);
/*     */       return; }
/*     */     
/* 124 */     throw new InvalidConfigurationPropertyValueException("spring.rabbitmq.template.allowed-list-patterns", allowedListPatterns, "Allowed list patterns can only be applied to an AllowedListDeserializingMessageConverter");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean determineMandatoryFlag() {
/* 130 */     Boolean mandatory = this.rabbitProperties.getTemplate().getMandatory();
/* 131 */     return (mandatory != null) ? mandatory.booleanValue() : this.rabbitProperties.isPublisherReturns();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitTemplateConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */