/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.amqp.rabbit.connection.AbstractConnectionFactory;
/*    */ import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractConnectionFactoryConfigurer<T extends AbstractConnectionFactory>
/*    */ {
/*    */   private final RabbitProperties rabbitProperties;
/*    */   private ConnectionNameStrategy connectionNameStrategy;
/*    */   private final RabbitConnectionDetails connectionDetails;
/*    */   
/*    */   protected AbstractConnectionFactoryConfigurer(RabbitProperties properties) {
/* 50 */     this(properties, new PropertiesRabbitConnectionDetails(properties, null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected AbstractConnectionFactoryConfigurer(RabbitProperties properties, RabbitConnectionDetails connectionDetails) {
/* 63 */     Assert.notNull(properties, "'properties' must not be null");
/* 64 */     Assert.notNull(connectionDetails, "'connectionDetails' must not be null");
/* 65 */     this.rabbitProperties = properties;
/* 66 */     this.connectionDetails = connectionDetails;
/*    */   }
/*    */   
/*    */   protected final ConnectionNameStrategy getConnectionNameStrategy() {
/* 70 */     return this.connectionNameStrategy;
/*    */   }
/*    */   
/*    */   public final void setConnectionNameStrategy(ConnectionNameStrategy connectionNameStrategy) {
/* 74 */     this.connectionNameStrategy = connectionNameStrategy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void configure(T connectionFactory) {
/* 82 */     Assert.notNull(connectionFactory, "'connectionFactory' must not be null");
/* 83 */     PropertyMapper map = PropertyMapper.get();
/*    */ 
/*    */ 
/*    */     
/* 87 */     String addresses = this.connectionDetails.getAddresses().stream().map(address -> address.host() + ":" + address.host()).collect(Collectors.joining(","));
/* 88 */     Objects.requireNonNull(connectionFactory); map.from(addresses).to(connectionFactory::setAddresses);
/* 89 */     Objects.requireNonNull(this.rabbitProperties);
/*    */     
/* 91 */     Objects.requireNonNull(connectionFactory); map.from(this.rabbitProperties::getAddressShuffleMode).whenNonNull().to(connectionFactory::setAddressShuffleMode);
/* 92 */     Objects.requireNonNull(connectionFactory); map.from(this.connectionNameStrategy).whenNonNull().to(connectionFactory::setConnectionNameStrategy);
/* 93 */     configure(connectionFactory, this.rabbitProperties);
/*    */   }
/*    */   
/*    */   protected abstract void configure(T paramT, RabbitProperties paramRabbitProperties);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\AbstractConnectionFactoryConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */