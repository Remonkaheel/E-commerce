package org.springframework.boot.autoconfigure.amqp;

import com.rabbitmq.stream.EnvironmentBuilder;

@FunctionalInterface
public interface EnvironmentBuilderCustomizer {
  void customize(EnvironmentBuilder paramEnvironmentBuilder);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\EnvironmentBuilderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */