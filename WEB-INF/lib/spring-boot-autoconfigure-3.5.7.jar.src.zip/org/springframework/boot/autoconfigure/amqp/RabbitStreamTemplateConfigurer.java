/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.amqp.support.converter.MessageConverter;
/*    */ import org.springframework.rabbit.stream.producer.ProducerCustomizer;
/*    */ import org.springframework.rabbit.stream.producer.RabbitStreamTemplate;
/*    */ import org.springframework.rabbit.stream.support.converter.StreamMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RabbitStreamTemplateConfigurer
/*    */ {
/*    */   private MessageConverter messageConverter;
/*    */   private StreamMessageConverter streamMessageConverter;
/*    */   private ProducerCustomizer producerCustomizer;
/*    */   
/*    */   public void setMessageConverter(MessageConverter messageConverter) {
/* 48 */     this.messageConverter = messageConverter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setStreamMessageConverter(StreamMessageConverter streamMessageConverter) {
/* 57 */     this.streamMessageConverter = streamMessageConverter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setProducerCustomizer(ProducerCustomizer producerCustomizer) {
/* 65 */     this.producerCustomizer = producerCustomizer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void configure(RabbitStreamTemplate template) {
/* 74 */     if (this.messageConverter != null) {
/* 75 */       template.setMessageConverter(this.messageConverter);
/*    */     }
/* 77 */     if (this.streamMessageConverter != null) {
/* 78 */       template.setStreamConverter(this.streamMessageConverter);
/*    */     }
/* 80 */     if (this.producerCustomizer != null)
/* 81 */       template.setProducerCustomizer(this.producerCustomizer); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitStreamTemplateConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */