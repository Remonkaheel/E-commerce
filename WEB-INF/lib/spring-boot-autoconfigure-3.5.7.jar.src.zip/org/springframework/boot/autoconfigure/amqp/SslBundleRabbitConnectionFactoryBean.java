/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SslBundleRabbitConnectionFactoryBean
/*    */   extends RabbitConnectionFactoryBean
/*    */ {
/*    */   private SslBundle sslBundle;
/*    */   private boolean enableHostnameVerification;
/*    */   
/*    */   protected void setUpSSL() {
/* 36 */     if (this.sslBundle != null) {
/* 37 */       this.connectionFactory.useSslProtocol(this.sslBundle.createSslContext());
/* 38 */       if (this.enableHostnameVerification) {
/* 39 */         this.connectionFactory.enableHostnameVerification();
/*    */       }
/*    */     } else {
/*    */       
/* 43 */       super.setUpSSL();
/*    */     } 
/*    */   }
/*    */   
/*    */   void setSslBundle(SslBundle sslBundle) {
/* 48 */     this.sslBundle = sslBundle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnableHostnameVerification(boolean enable) {
/* 53 */     this.enableHostnameVerification = enable;
/* 54 */     super.setEnableHostnameVerification(enable);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\SslBundleRabbitConnectionFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */