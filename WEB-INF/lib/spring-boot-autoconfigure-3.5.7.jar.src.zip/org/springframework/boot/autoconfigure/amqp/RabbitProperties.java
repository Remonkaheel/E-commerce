/*      */ package org.springframework.boot.autoconfigure.amqp;
/*      */ 
/*      */ import java.time.Duration;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.springframework.amqp.core.AcknowledgeMode;
/*      */ import org.springframework.amqp.rabbit.connection.AbstractConnectionFactory;
/*      */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*      */ import org.springframework.boot.convert.DurationUnit;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.unit.DataSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties("spring.rabbitmq")
/*      */ public class RabbitProperties
/*      */ {
/*      */   private static final int DEFAULT_PORT = 5672;
/*      */   private static final int DEFAULT_PORT_SECURE = 5671;
/*      */   private static final int DEFAULT_STREAM_PORT = 5552;
/*   65 */   private String host = "localhost";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Integer port;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   76 */   private String username = "guest";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   private String password = "guest";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   86 */   private final Ssl ssl = new Ssl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String virtualHost;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> addresses;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private AbstractConnectionFactory.AddressShuffleMode addressShuffleMode = AbstractConnectionFactory.AddressShuffleMode.NONE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @DurationUnit(ChronoUnit.SECONDS)
/*      */   private Duration requestedHeartbeat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private int requestedChannelMax = 2047;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean publisherReturns;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CachingConnectionFactory.ConfirmType publisherConfirmType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Duration connectionTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   private Duration channelRpcTimeout = Duration.ofMinutes(10L);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   private DataSize maxInboundMessageBodySize = DataSize.ofMegabytes(64L);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  144 */   private final Cache cache = new Cache();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   private final Listener listener = new Listener();
/*      */   
/*  151 */   private final Template template = new Template();
/*      */   
/*  153 */   private final Stream stream = new Stream();
/*      */   
/*      */   private List<Address> parsedAddresses;
/*      */   
/*      */   public String getHost() {
/*  158 */     return this.host;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineHost() {
/*  169 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  170 */       return getHost();
/*      */     }
/*  172 */     return ((Address)this.parsedAddresses.get(0)).host;
/*      */   }
/*      */   
/*      */   public void setHost(String host) {
/*  176 */     this.host = host;
/*      */   }
/*      */   
/*      */   public Integer getPort() {
/*  180 */     return this.port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int determinePort() {
/*  191 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  192 */       Integer port = getPort();
/*  193 */       if (port != null) {
/*  194 */         return port.intValue();
/*      */       }
/*  196 */       return Boolean.TRUE.equals(getSsl().getEnabled()) ? 5671 : 5672;
/*      */     } 
/*  198 */     return ((Address)this.parsedAddresses.get(0)).port;
/*      */   }
/*      */   
/*      */   public void setPort(Integer port) {
/*  202 */     this.port = port;
/*      */   }
/*      */   
/*      */   public List<String> getAddresses() {
/*  206 */     return this.addresses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> determineAddresses() {
/*  215 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  216 */       if (this.host.contains(",")) {
/*  217 */         throw new InvalidConfigurationPropertyValueException("spring.rabbitmq.host", this.host, "Invalid character ','. Value must be a single host. For multiple hosts, use property 'spring.rabbitmq.addresses' instead.");
/*      */       }
/*      */       
/*  220 */       return List.of(this.host + ":" + this.host);
/*      */     } 
/*  222 */     List<String> addressStrings = new ArrayList<>();
/*  223 */     for (Address parsedAddress : this.parsedAddresses) {
/*  224 */       addressStrings.add(parsedAddress.host + ":" + parsedAddress.host);
/*      */     }
/*  226 */     return addressStrings;
/*      */   }
/*      */   
/*      */   public void setAddresses(List<String> addresses) {
/*  230 */     this.addresses = addresses;
/*  231 */     this.parsedAddresses = parseAddresses(addresses);
/*      */   }
/*      */   
/*      */   private List<Address> parseAddresses(List<String> addresses) {
/*  235 */     List<Address> parsedAddresses = new ArrayList<>();
/*  236 */     for (String address : addresses) {
/*  237 */       parsedAddresses.add(new Address(address, Boolean.TRUE.equals(getSsl().getEnabled())));
/*      */     }
/*  239 */     return parsedAddresses;
/*      */   }
/*      */   
/*      */   public String getUsername() {
/*  243 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineUsername() {
/*  254 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  255 */       return this.username;
/*      */     }
/*  257 */     Address address = this.parsedAddresses.get(0);
/*  258 */     return (address.username != null) ? address.username : this.username;
/*      */   }
/*      */   
/*      */   public void setUsername(String username) {
/*  262 */     this.username = username;
/*      */   }
/*      */   
/*      */   public String getPassword() {
/*  266 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determinePassword() {
/*  277 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  278 */       return getPassword();
/*      */     }
/*  280 */     Address address = this.parsedAddresses.get(0);
/*  281 */     return (address.password != null) ? address.password : getPassword();
/*      */   }
/*      */   
/*      */   public void setPassword(String password) {
/*  285 */     this.password = password;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  289 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public String getVirtualHost() {
/*  293 */     return this.virtualHost;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String determineVirtualHost() {
/*  304 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  305 */       return getVirtualHost();
/*      */     }
/*  307 */     Address address = this.parsedAddresses.get(0);
/*  308 */     return (address.virtualHost != null) ? address.virtualHost : getVirtualHost();
/*      */   }
/*      */   
/*      */   public void setVirtualHost(String virtualHost) {
/*  312 */     this.virtualHost = StringUtils.hasText(virtualHost) ? virtualHost : "/";
/*      */   }
/*      */   
/*      */   public AbstractConnectionFactory.AddressShuffleMode getAddressShuffleMode() {
/*  316 */     return this.addressShuffleMode;
/*      */   }
/*      */   
/*      */   public void setAddressShuffleMode(AbstractConnectionFactory.AddressShuffleMode addressShuffleMode) {
/*  320 */     this.addressShuffleMode = addressShuffleMode;
/*      */   }
/*      */   
/*      */   public Duration getRequestedHeartbeat() {
/*  324 */     return this.requestedHeartbeat;
/*      */   }
/*      */   
/*      */   public void setRequestedHeartbeat(Duration requestedHeartbeat) {
/*  328 */     this.requestedHeartbeat = requestedHeartbeat;
/*      */   }
/*      */   
/*      */   public int getRequestedChannelMax() {
/*  332 */     return this.requestedChannelMax;
/*      */   }
/*      */   
/*      */   public void setRequestedChannelMax(int requestedChannelMax) {
/*  336 */     this.requestedChannelMax = requestedChannelMax;
/*      */   }
/*      */   
/*      */   public boolean isPublisherReturns() {
/*  340 */     return this.publisherReturns;
/*      */   }
/*      */   
/*      */   public void setPublisherReturns(boolean publisherReturns) {
/*  344 */     this.publisherReturns = publisherReturns;
/*      */   }
/*      */   
/*      */   public Duration getConnectionTimeout() {
/*  348 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */   public void setPublisherConfirmType(CachingConnectionFactory.ConfirmType publisherConfirmType) {
/*  352 */     this.publisherConfirmType = publisherConfirmType;
/*      */   }
/*      */   
/*      */   public CachingConnectionFactory.ConfirmType getPublisherConfirmType() {
/*  356 */     return this.publisherConfirmType;
/*      */   }
/*      */   
/*      */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  360 */     this.connectionTimeout = connectionTimeout;
/*      */   }
/*      */   
/*      */   public Duration getChannelRpcTimeout() {
/*  364 */     return this.channelRpcTimeout;
/*      */   }
/*      */   
/*      */   public void setChannelRpcTimeout(Duration channelRpcTimeout) {
/*  368 */     this.channelRpcTimeout = channelRpcTimeout;
/*      */   }
/*      */   
/*      */   public DataSize getMaxInboundMessageBodySize() {
/*  372 */     return this.maxInboundMessageBodySize;
/*      */   }
/*      */   
/*      */   public void setMaxInboundMessageBodySize(DataSize maxInboundMessageBodySize) {
/*  376 */     this.maxInboundMessageBodySize = maxInboundMessageBodySize;
/*      */   }
/*      */   
/*      */   public Cache getCache() {
/*  380 */     return this.cache;
/*      */   }
/*      */   
/*      */   public Listener getListener() {
/*  384 */     return this.listener;
/*      */   }
/*      */   
/*      */   public Template getTemplate() {
/*  388 */     return this.template;
/*      */   }
/*      */   
/*      */   public Stream getStream() {
/*  392 */     return this.stream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class Ssl
/*      */   {
/*      */     private static final String SUN_X509 = "SunX509";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean enabled;
/*      */ 
/*      */ 
/*      */     
/*      */     private String bundle;
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStore;
/*      */ 
/*      */ 
/*      */     
/*  418 */     private String keyStoreType = "PKCS12";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String keyStorePassword;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  428 */     private String keyStoreAlgorithm = "SunX509";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStore;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  438 */     private String trustStoreType = "JKS";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String trustStorePassword;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  448 */     private String trustStoreAlgorithm = "SunX509";
/*      */ 
/*      */ 
/*      */     
/*      */     private String algorithm;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean validateServerCertificate = true;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean verifyHostname = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Boolean getEnabled() {
/*  466 */       return this.enabled;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean determineEnabled() {
/*  477 */       boolean defaultEnabled = (Boolean.TRUE.equals(getEnabled()) || this.bundle != null);
/*  478 */       if (CollectionUtils.isEmpty(RabbitProperties.this.parsedAddresses)) {
/*  479 */         return defaultEnabled;
/*      */       }
/*  481 */       RabbitProperties.Address address = RabbitProperties.this.parsedAddresses.get(0);
/*  482 */       return address.determineSslEnabled(defaultEnabled);
/*      */     }
/*      */     
/*      */     public void setEnabled(Boolean enabled) {
/*  486 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public String getBundle() {
/*  490 */       return this.bundle;
/*      */     }
/*      */     
/*      */     public void setBundle(String bundle) {
/*  494 */       this.bundle = bundle;
/*      */     }
/*      */     
/*      */     public String getKeyStore() {
/*  498 */       return this.keyStore;
/*      */     }
/*      */     
/*      */     public void setKeyStore(String keyStore) {
/*  502 */       this.keyStore = keyStore;
/*      */     }
/*      */     
/*      */     public String getKeyStoreType() {
/*  506 */       return this.keyStoreType;
/*      */     }
/*      */     
/*      */     public void setKeyStoreType(String keyStoreType) {
/*  510 */       this.keyStoreType = keyStoreType;
/*      */     }
/*      */     
/*      */     public String getKeyStorePassword() {
/*  514 */       return this.keyStorePassword;
/*      */     }
/*      */     
/*      */     public void setKeyStorePassword(String keyStorePassword) {
/*  518 */       this.keyStorePassword = keyStorePassword;
/*      */     }
/*      */     
/*      */     public String getKeyStoreAlgorithm() {
/*  522 */       return this.keyStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public void setKeyStoreAlgorithm(String keyStoreAlgorithm) {
/*  526 */       this.keyStoreAlgorithm = keyStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public String getTrustStore() {
/*  530 */       return this.trustStore;
/*      */     }
/*      */     
/*      */     public void setTrustStore(String trustStore) {
/*  534 */       this.trustStore = trustStore;
/*      */     }
/*      */     
/*      */     public String getTrustStoreType() {
/*  538 */       return this.trustStoreType;
/*      */     }
/*      */     
/*      */     public void setTrustStoreType(String trustStoreType) {
/*  542 */       this.trustStoreType = trustStoreType;
/*      */     }
/*      */     
/*      */     public String getTrustStorePassword() {
/*  546 */       return this.trustStorePassword;
/*      */     }
/*      */     
/*      */     public void setTrustStorePassword(String trustStorePassword) {
/*  550 */       this.trustStorePassword = trustStorePassword;
/*      */     }
/*      */     
/*      */     public String getTrustStoreAlgorithm() {
/*  554 */       return this.trustStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public void setTrustStoreAlgorithm(String trustStoreAlgorithm) {
/*  558 */       this.trustStoreAlgorithm = trustStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public String getAlgorithm() {
/*  562 */       return this.algorithm;
/*      */     }
/*      */     
/*      */     public void setAlgorithm(String sslAlgorithm) {
/*  566 */       this.algorithm = sslAlgorithm;
/*      */     }
/*      */     
/*      */     public boolean isValidateServerCertificate() {
/*  570 */       return this.validateServerCertificate;
/*      */     }
/*      */     
/*      */     public void setValidateServerCertificate(boolean validateServerCertificate) {
/*  574 */       this.validateServerCertificate = validateServerCertificate;
/*      */     }
/*      */     
/*      */     public boolean isVerifyHostname() {
/*  578 */       return this.verifyHostname;
/*      */     }
/*      */     
/*      */     public void setVerifyHostname(boolean verifyHostname) {
/*  582 */       this.verifyHostname = verifyHostname;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class Cache
/*      */   {
/*  589 */     private final Channel channel = new Channel();
/*      */     
/*  591 */     private final Connection connection = new Connection();
/*      */     
/*      */     public Channel getChannel() {
/*  594 */       return this.channel;
/*      */     }
/*      */     
/*      */     public Connection getConnection() {
/*  598 */       return this.connection;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Channel
/*      */     {
/*      */       private Integer size;
/*      */ 
/*      */ 
/*      */       
/*      */       private Duration checkoutTimeout;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Integer getSize() {
/*  616 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  620 */         this.size = size;
/*      */       }
/*      */       
/*      */       public Duration getCheckoutTimeout() {
/*  624 */         return this.checkoutTimeout;
/*      */       }
/*      */       
/*      */       public void setCheckoutTimeout(Duration checkoutTimeout) {
/*  628 */         this.checkoutTimeout = checkoutTimeout;
/*      */       }
/*      */     }
/*      */     
/*      */     public static class Connection
/*      */     {
/*      */       private CachingConnectionFactory.CacheMode mode;
/*      */       private Integer size;
/*      */       
/*      */       public Connection() {
/*  638 */         this.mode = CachingConnectionFactory.CacheMode.CHANNEL;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public CachingConnectionFactory.CacheMode getMode() {
/*  646 */         return this.mode;
/*      */       }
/*      */       
/*      */       public void setMode(CachingConnectionFactory.CacheMode mode) {
/*  650 */         this.mode = mode;
/*      */       }
/*      */       
/*      */       public Integer getSize() {
/*  654 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  658 */         this.size = size; } } } public static class Channel { private Integer size; private Duration checkoutTimeout; public Integer getSize() { return this.size; } public void setSize(Integer size) { this.size = size; } public Duration getCheckoutTimeout() { return this.checkoutTimeout; } public void setCheckoutTimeout(Duration checkoutTimeout) { this.checkoutTimeout = checkoutTimeout; } } public static class Connection { private CachingConnectionFactory.CacheMode mode = CachingConnectionFactory.CacheMode.CHANNEL; public void setSize(Integer size) { this.size = size; }
/*      */     
/*      */     private Integer size;
/*      */     public CachingConnectionFactory.CacheMode getMode() {
/*      */       return this.mode;
/*      */     }
/*      */     public void setMode(CachingConnectionFactory.CacheMode mode) {
/*      */       this.mode = mode;
/*      */     }
/*      */     public Integer getSize() {
/*      */       return this.size;
/*      */     } }
/*  670 */   public enum ContainerType { SIMPLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  676 */     DIRECT,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  681 */     STREAM; }
/*      */   
/*      */   public static class Listener {
/*      */     private RabbitProperties.ContainerType type;
/*      */     private final RabbitProperties.SimpleContainer simple;
/*      */     private final RabbitProperties.DirectContainer direct;
/*      */     private final RabbitProperties.StreamContainer stream;
/*      */     
/*      */     public Listener() {
/*  690 */       this.type = RabbitProperties.ContainerType.SIMPLE;
/*      */       
/*  692 */       this.simple = new RabbitProperties.SimpleContainer();
/*      */       
/*  694 */       this.direct = new RabbitProperties.DirectContainer();
/*      */       
/*  696 */       this.stream = new RabbitProperties.StreamContainer();
/*      */     }
/*      */     public RabbitProperties.ContainerType getType() {
/*  699 */       return this.type;
/*      */     }
/*      */     
/*      */     public void setType(RabbitProperties.ContainerType containerType) {
/*  703 */       this.type = containerType;
/*      */     }
/*      */     
/*      */     public RabbitProperties.SimpleContainer getSimple() {
/*  707 */       return this.simple;
/*      */     }
/*      */     
/*      */     public RabbitProperties.DirectContainer getDirect() {
/*  711 */       return this.direct;
/*      */     }
/*      */     
/*      */     public RabbitProperties.StreamContainer getStream() {
/*  715 */       return this.stream;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class BaseContainer
/*      */   {
/*      */     private boolean observationEnabled;
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isObservationEnabled() {
/*  728 */       return this.observationEnabled;
/*      */     }
/*      */     
/*      */     public void setObservationEnabled(boolean observationEnabled) {
/*  732 */       this.observationEnabled = observationEnabled;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AmqpContainer
/*      */     extends BaseContainer
/*      */   {
/*      */     private boolean autoStartup = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private AcknowledgeMode acknowledgeMode;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer prefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Boolean defaultRequeueRejected;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Duration idleEventInterval;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean deBatchingEnabled = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean forceStop;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  780 */     private final RabbitProperties.ListenerRetry retry = new RabbitProperties.ListenerRetry();
/*      */     
/*      */     public boolean isAutoStartup() {
/*  783 */       return this.autoStartup;
/*      */     }
/*      */     
/*      */     public void setAutoStartup(boolean autoStartup) {
/*  787 */       this.autoStartup = autoStartup;
/*      */     }
/*      */     
/*      */     public AcknowledgeMode getAcknowledgeMode() {
/*  791 */       return this.acknowledgeMode;
/*      */     }
/*      */     
/*      */     public void setAcknowledgeMode(AcknowledgeMode acknowledgeMode) {
/*  795 */       this.acknowledgeMode = acknowledgeMode;
/*      */     }
/*      */     
/*      */     public Integer getPrefetch() {
/*  799 */       return this.prefetch;
/*      */     }
/*      */     
/*      */     public void setPrefetch(Integer prefetch) {
/*  803 */       this.prefetch = prefetch;
/*      */     }
/*      */     
/*      */     public Boolean getDefaultRequeueRejected() {
/*  807 */       return this.defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public void setDefaultRequeueRejected(Boolean defaultRequeueRejected) {
/*  811 */       this.defaultRequeueRejected = defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public Duration getIdleEventInterval() {
/*  815 */       return this.idleEventInterval;
/*      */     }
/*      */     
/*      */     public void setIdleEventInterval(Duration idleEventInterval) {
/*  819 */       this.idleEventInterval = idleEventInterval;
/*      */     }
/*      */     
/*      */     public abstract boolean isMissingQueuesFatal();
/*      */     
/*      */     public boolean isDeBatchingEnabled() {
/*  825 */       return this.deBatchingEnabled;
/*      */     }
/*      */     
/*      */     public void setDeBatchingEnabled(boolean deBatchingEnabled) {
/*  829 */       this.deBatchingEnabled = deBatchingEnabled;
/*      */     }
/*      */     
/*      */     public boolean isForceStop() {
/*  833 */       return this.forceStop;
/*      */     }
/*      */     
/*      */     public void setForceStop(boolean forceStop) {
/*  837 */       this.forceStop = forceStop;
/*      */     }
/*      */     
/*      */     public RabbitProperties.ListenerRetry getRetry() {
/*  841 */       return this.retry;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SimpleContainer
/*      */     extends AmqpContainer
/*      */   {
/*      */     private Integer concurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer maxConcurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Integer batchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean missingQueuesFatal = true;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean consumerBatchEnabled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Integer getConcurrency() {
/*  883 */       return this.concurrency;
/*      */     }
/*      */     
/*      */     public void setConcurrency(Integer concurrency) {
/*  887 */       this.concurrency = concurrency;
/*      */     }
/*      */     
/*      */     public Integer getMaxConcurrency() {
/*  891 */       return this.maxConcurrency;
/*      */     }
/*      */     
/*      */     public void setMaxConcurrency(Integer maxConcurrency) {
/*  895 */       this.maxConcurrency = maxConcurrency;
/*      */     }
/*      */     
/*      */     public Integer getBatchSize() {
/*  899 */       return this.batchSize;
/*      */     }
/*      */     
/*      */     public void setBatchSize(Integer batchSize) {
/*  903 */       this.batchSize = batchSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isMissingQueuesFatal() {
/*  908 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  912 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public boolean isConsumerBatchEnabled() {
/*  916 */       return this.consumerBatchEnabled;
/*      */     }
/*      */     
/*      */     public void setConsumerBatchEnabled(boolean consumerBatchEnabled) {
/*  920 */       this.consumerBatchEnabled = consumerBatchEnabled;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DirectContainer
/*      */     extends AmqpContainer
/*      */   {
/*      */     private Integer consumersPerQueue;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean missingQueuesFatal = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Integer getConsumersPerQueue() {
/*  942 */       return this.consumersPerQueue;
/*      */     }
/*      */     
/*      */     public void setConsumersPerQueue(Integer consumersPerQueue) {
/*  946 */       this.consumersPerQueue = consumersPerQueue;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isMissingQueuesFatal() {
/*  951 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  955 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class StreamContainer
/*      */     extends BaseContainer
/*      */   {
/*      */     private boolean nativeListener;
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNativeListener() {
/*  969 */       return this.nativeListener;
/*      */     }
/*      */     
/*      */     public void setNativeListener(boolean nativeListener) {
/*  973 */       this.nativeListener = nativeListener;
/*      */     } }
/*      */   public static class Template { private final RabbitProperties.Retry retry; private Boolean mandatory; private Duration receiveTimeout; private Duration replyTimeout; private String exchange; private String routingKey; private String defaultReceiveQueue;
/*      */     private boolean observationEnabled;
/*      */     private List<String> allowedListPatterns;
/*      */     
/*      */     public Template() {
/*  980 */       this.retry = new RabbitProperties.Retry();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1000 */       this.exchange = "";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1005 */       this.routingKey = "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RabbitProperties.Retry getRetry() {
/* 1024 */       return this.retry;
/*      */     }
/*      */     
/*      */     public Boolean getMandatory() {
/* 1028 */       return this.mandatory;
/*      */     }
/*      */     
/*      */     public void setMandatory(Boolean mandatory) {
/* 1032 */       this.mandatory = mandatory;
/*      */     }
/*      */     
/*      */     public Duration getReceiveTimeout() {
/* 1036 */       return this.receiveTimeout;
/*      */     }
/*      */     
/*      */     public void setReceiveTimeout(Duration receiveTimeout) {
/* 1040 */       this.receiveTimeout = receiveTimeout;
/*      */     }
/*      */     
/*      */     public Duration getReplyTimeout() {
/* 1044 */       return this.replyTimeout;
/*      */     }
/*      */     
/*      */     public void setReplyTimeout(Duration replyTimeout) {
/* 1048 */       this.replyTimeout = replyTimeout;
/*      */     }
/*      */     
/*      */     public String getExchange() {
/* 1052 */       return this.exchange;
/*      */     }
/*      */     
/*      */     public void setExchange(String exchange) {
/* 1056 */       this.exchange = exchange;
/*      */     }
/*      */     
/*      */     public String getRoutingKey() {
/* 1060 */       return this.routingKey;
/*      */     }
/*      */     
/*      */     public void setRoutingKey(String routingKey) {
/* 1064 */       this.routingKey = routingKey;
/*      */     }
/*      */     
/*      */     public String getDefaultReceiveQueue() {
/* 1068 */       return this.defaultReceiveQueue;
/*      */     }
/*      */     
/*      */     public void setDefaultReceiveQueue(String defaultReceiveQueue) {
/* 1072 */       this.defaultReceiveQueue = defaultReceiveQueue;
/*      */     }
/*      */     
/*      */     public boolean isObservationEnabled() {
/* 1076 */       return this.observationEnabled;
/*      */     }
/*      */     
/*      */     public void setObservationEnabled(boolean observationEnabled) {
/* 1080 */       this.observationEnabled = observationEnabled;
/*      */     }
/*      */     
/*      */     public List<String> getAllowedListPatterns() {
/* 1084 */       return this.allowedListPatterns;
/*      */     }
/*      */     
/*      */     public void setAllowedListPatterns(List<String> allowedListPatterns) {
/* 1088 */       this.allowedListPatterns = allowedListPatterns;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Retry
/*      */   {
/*      */     private boolean enabled;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1103 */     private int maxAttempts = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1108 */     private Duration initialInterval = Duration.ofMillis(1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     private double multiplier = 1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1118 */     private Duration maxInterval = Duration.ofMillis(10000L);
/*      */     
/*      */     public boolean isEnabled() {
/* 1121 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean enabled) {
/* 1125 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public int getMaxAttempts() {
/* 1129 */       return this.maxAttempts;
/*      */     }
/*      */     
/*      */     public void setMaxAttempts(int maxAttempts) {
/* 1133 */       this.maxAttempts = maxAttempts;
/*      */     }
/*      */     
/*      */     public Duration getInitialInterval() {
/* 1137 */       return this.initialInterval;
/*      */     }
/*      */     
/*      */     public void setInitialInterval(Duration initialInterval) {
/* 1141 */       this.initialInterval = initialInterval;
/*      */     }
/*      */     
/*      */     public double getMultiplier() {
/* 1145 */       return this.multiplier;
/*      */     }
/*      */     
/*      */     public void setMultiplier(double multiplier) {
/* 1149 */       this.multiplier = multiplier;
/*      */     }
/*      */     
/*      */     public Duration getMaxInterval() {
/* 1153 */       return this.maxInterval;
/*      */     }
/*      */     
/*      */     public void setMaxInterval(Duration maxInterval) {
/* 1157 */       this.maxInterval = maxInterval;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ListenerRetry
/*      */     extends Retry
/*      */   {
/*      */     private boolean stateless = true;
/*      */ 
/*      */     
/*      */     public boolean isStateless() {
/* 1170 */       return this.stateless;
/*      */     }
/*      */     
/*      */     public void setStateless(boolean stateless) {
/* 1174 */       this.stateless = stateless;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class Address
/*      */   {
/*      */     private static final String PREFIX_AMQP = "amqp://";
/*      */     
/*      */     private static final String PREFIX_AMQP_SECURE = "amqps://";
/*      */     
/*      */     private String host;
/*      */     
/*      */     private int port;
/*      */     
/*      */     private String username;
/*      */     
/*      */     private String password;
/*      */     
/*      */     private String virtualHost;
/*      */     
/*      */     private Boolean secureConnection;
/*      */     
/*      */     private Address(String input, boolean sslEnabled) {
/* 1198 */       input = input.trim();
/* 1199 */       input = trimPrefix(input);
/* 1200 */       input = parseUsernameAndPassword(input);
/* 1201 */       input = parseVirtualHost(input);
/* 1202 */       parseHostAndPort(input, sslEnabled);
/*      */     }
/*      */     
/*      */     private String trimPrefix(String input) {
/* 1206 */       if (input.startsWith("amqps://")) {
/* 1207 */         this.secureConnection = Boolean.valueOf(true);
/* 1208 */         return input.substring("amqps://".length());
/*      */       } 
/* 1210 */       if (input.startsWith("amqp://")) {
/* 1211 */         this.secureConnection = Boolean.valueOf(false);
/* 1212 */         return input.substring("amqp://".length());
/*      */       } 
/* 1214 */       return input;
/*      */     }
/*      */     
/*      */     private String parseUsernameAndPassword(String input) {
/* 1218 */       String[] splitInput = StringUtils.split(input, "@");
/* 1219 */       if (splitInput == null) {
/* 1220 */         return input;
/*      */       }
/* 1222 */       String credentials = splitInput[0];
/* 1223 */       String[] splitCredentials = StringUtils.split(credentials, ":");
/* 1224 */       if (splitCredentials == null) {
/* 1225 */         this.username = credentials;
/*      */       } else {
/*      */         
/* 1228 */         this.username = splitCredentials[0];
/* 1229 */         this.password = splitCredentials[1];
/*      */       } 
/* 1231 */       return splitInput[1];
/*      */     }
/*      */     
/*      */     private String parseVirtualHost(String input) {
/* 1235 */       int hostIndex = input.indexOf('/');
/* 1236 */       if (hostIndex >= 0) {
/* 1237 */         this.virtualHost = input.substring(hostIndex + 1);
/* 1238 */         if (this.virtualHost.isEmpty()) {
/* 1239 */           this.virtualHost = "/";
/*      */         }
/* 1241 */         input = input.substring(0, hostIndex);
/*      */       } 
/* 1243 */       return input;
/*      */     }
/*      */     
/*      */     private void parseHostAndPort(String input, boolean sslEnabled) {
/* 1247 */       int bracketIndex = input.lastIndexOf(']');
/* 1248 */       int colonIndex = input.lastIndexOf(':');
/* 1249 */       if (colonIndex == -1 || colonIndex < bracketIndex) {
/* 1250 */         this.host = input;
/* 1251 */         this.port = determineSslEnabled(sslEnabled) ? 5671 : 5672;
/*      */       } else {
/*      */         
/* 1254 */         this.host = input.substring(0, colonIndex);
/* 1255 */         this.port = Integer.parseInt(input.substring(colonIndex + 1));
/*      */       } 
/*      */     }
/*      */     
/*      */     private boolean determineSslEnabled(boolean sslEnabled) {
/* 1260 */       return (this.secureConnection != null) ? this.secureConnection.booleanValue() : sslEnabled;
/*      */     } }
/*      */   public static final class Stream { private String host;
/*      */     private int port;
/*      */     private String virtualHost;
/*      */     private String username;
/*      */     private String password;
/*      */     private String name;
/*      */     
/*      */     public Stream() {
/* 1270 */       this.host = "localhost";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1275 */       this.port = 5552;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getHost() {
/* 1301 */       return this.host;
/*      */     }
/*      */     
/*      */     public void setHost(String host) {
/* 1305 */       this.host = host;
/*      */     }
/*      */     
/*      */     public int getPort() {
/* 1309 */       return this.port;
/*      */     }
/*      */     
/*      */     public void setPort(int port) {
/* 1313 */       this.port = port;
/*      */     }
/*      */     
/*      */     public String getVirtualHost() {
/* 1317 */       return this.virtualHost;
/*      */     }
/*      */     
/*      */     public void setVirtualHost(String virtualHost) {
/* 1321 */       this.virtualHost = virtualHost;
/*      */     }
/*      */     
/*      */     public String getUsername() {
/* 1325 */       return this.username;
/*      */     }
/*      */     
/*      */     public void setUsername(String username) {
/* 1329 */       this.username = username;
/*      */     }
/*      */     
/*      */     public String getPassword() {
/* 1333 */       return this.password;
/*      */     }
/*      */     
/*      */     public void setPassword(String password) {
/* 1337 */       this.password = password;
/*      */     }
/*      */     
/*      */     public String getName() {
/* 1341 */       return this.name;
/*      */     }
/*      */     
/*      */     public void setName(String name) {
/* 1345 */       this.name = name;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */