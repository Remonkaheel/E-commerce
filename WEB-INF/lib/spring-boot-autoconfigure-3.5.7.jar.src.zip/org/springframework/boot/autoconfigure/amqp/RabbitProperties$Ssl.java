/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ssl
/*     */ {
/*     */   private static final String SUN_X509 = "SunX509";
/*     */   private Boolean enabled;
/*     */   private String bundle;
/*     */   private String keyStore;
/* 418 */   private String keyStoreType = "PKCS12";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String keyStorePassword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 428 */   private String keyStoreAlgorithm = "SunX509";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trustStore;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 438 */   private String trustStoreType = "JKS";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trustStorePassword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 448 */   private String trustStoreAlgorithm = "SunX509";
/*     */ 
/*     */ 
/*     */   
/*     */   private String algorithm;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateServerCertificate = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean verifyHostname = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getEnabled() {
/* 466 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean determineEnabled() {
/* 477 */     boolean defaultEnabled = (Boolean.TRUE.equals(getEnabled()) || this.bundle != null);
/* 478 */     if (CollectionUtils.isEmpty(RabbitProperties.this.parsedAddresses)) {
/* 479 */       return defaultEnabled;
/*     */     }
/* 481 */     RabbitProperties.Address address = RabbitProperties.this.parsedAddresses.get(0);
/* 482 */     return address.determineSslEnabled(defaultEnabled);
/*     */   }
/*     */   
/*     */   public void setEnabled(Boolean enabled) {
/* 486 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getBundle() {
/* 490 */     return this.bundle;
/*     */   }
/*     */   
/*     */   public void setBundle(String bundle) {
/* 494 */     this.bundle = bundle;
/*     */   }
/*     */   
/*     */   public String getKeyStore() {
/* 498 */     return this.keyStore;
/*     */   }
/*     */   
/*     */   public void setKeyStore(String keyStore) {
/* 502 */     this.keyStore = keyStore;
/*     */   }
/*     */   
/*     */   public String getKeyStoreType() {
/* 506 */     return this.keyStoreType;
/*     */   }
/*     */   
/*     */   public void setKeyStoreType(String keyStoreType) {
/* 510 */     this.keyStoreType = keyStoreType;
/*     */   }
/*     */   
/*     */   public String getKeyStorePassword() {
/* 514 */     return this.keyStorePassword;
/*     */   }
/*     */   
/*     */   public void setKeyStorePassword(String keyStorePassword) {
/* 518 */     this.keyStorePassword = keyStorePassword;
/*     */   }
/*     */   
/*     */   public String getKeyStoreAlgorithm() {
/* 522 */     return this.keyStoreAlgorithm;
/*     */   }
/*     */   
/*     */   public void setKeyStoreAlgorithm(String keyStoreAlgorithm) {
/* 526 */     this.keyStoreAlgorithm = keyStoreAlgorithm;
/*     */   }
/*     */   
/*     */   public String getTrustStore() {
/* 530 */     return this.trustStore;
/*     */   }
/*     */   
/*     */   public void setTrustStore(String trustStore) {
/* 534 */     this.trustStore = trustStore;
/*     */   }
/*     */   
/*     */   public String getTrustStoreType() {
/* 538 */     return this.trustStoreType;
/*     */   }
/*     */   
/*     */   public void setTrustStoreType(String trustStoreType) {
/* 542 */     this.trustStoreType = trustStoreType;
/*     */   }
/*     */   
/*     */   public String getTrustStorePassword() {
/* 546 */     return this.trustStorePassword;
/*     */   }
/*     */   
/*     */   public void setTrustStorePassword(String trustStorePassword) {
/* 550 */     this.trustStorePassword = trustStorePassword;
/*     */   }
/*     */   
/*     */   public String getTrustStoreAlgorithm() {
/* 554 */     return this.trustStoreAlgorithm;
/*     */   }
/*     */   
/*     */   public void setTrustStoreAlgorithm(String trustStoreAlgorithm) {
/* 558 */     this.trustStoreAlgorithm = trustStoreAlgorithm;
/*     */   }
/*     */   
/*     */   public String getAlgorithm() {
/* 562 */     return this.algorithm;
/*     */   }
/*     */   
/*     */   public void setAlgorithm(String sslAlgorithm) {
/* 566 */     this.algorithm = sslAlgorithm;
/*     */   }
/*     */   
/*     */   public boolean isValidateServerCertificate() {
/* 570 */     return this.validateServerCertificate;
/*     */   }
/*     */   
/*     */   public void setValidateServerCertificate(boolean validateServerCertificate) {
/* 574 */     this.validateServerCertificate = validateServerCertificate;
/*     */   }
/*     */   
/*     */   public boolean isVerifyHostname() {
/* 578 */     return this.verifyHostname;
/*     */   }
/*     */   
/*     */   public void setVerifyHostname(boolean verifyHostname) {
/* 582 */     this.verifyHostname = verifyHostname;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitProperties$Ssl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */