package org.springframework.boot.autoconfigure.amqp;

import com.rabbitmq.client.ConnectionFactory;

@FunctionalInterface
public interface ConnectionFactoryCustomizer {
  void customize(ConnectionFactory paramConnectionFactory);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\ConnectionFactoryCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */