/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import org.springframework.amqp.rabbit.connection.AbstractConnectionFactory;
/*    */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachingConnectionFactoryConfigurer
/*    */   extends AbstractConnectionFactoryConfigurer<CachingConnectionFactory>
/*    */ {
/*    */   public CachingConnectionFactoryConfigurer(RabbitProperties properties) {
/* 46 */     this(properties, new PropertiesRabbitConnectionDetails(properties, null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CachingConnectionFactoryConfigurer(RabbitProperties properties, RabbitConnectionDetails connectionDetails) {
/* 58 */     super(properties, connectionDetails);
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(CachingConnectionFactory connectionFactory, RabbitProperties rabbitProperties) {
/* 63 */     PropertyMapper map = PropertyMapper.get();
/* 64 */     Objects.requireNonNull(rabbitProperties); Objects.requireNonNull(connectionFactory); map.from(rabbitProperties::isPublisherReturns).to(connectionFactory::setPublisherReturns);
/* 65 */     Objects.requireNonNull(rabbitProperties);
/*    */     
/* 67 */     Objects.requireNonNull(connectionFactory); map.from(rabbitProperties::getPublisherConfirmType).whenNonNull().to(connectionFactory::setPublisherConfirmType);
/* 68 */     RabbitProperties.Cache.Channel channel = rabbitProperties.getCache().getChannel();
/* 69 */     Objects.requireNonNull(channel); Objects.requireNonNull(connectionFactory); map.from(channel::getSize).whenNonNull().to(connectionFactory::setChannelCacheSize);
/* 70 */     Objects.requireNonNull(channel);
/*    */ 
/*    */     
/* 73 */     Objects.requireNonNull(connectionFactory); map.from(channel::getCheckoutTimeout).whenNonNull().as(Duration::toMillis).to(connectionFactory::setChannelCheckoutTimeout);
/* 74 */     RabbitProperties.Cache.Connection connection = rabbitProperties.getCache().getConnection();
/* 75 */     Objects.requireNonNull(connection); Objects.requireNonNull(connectionFactory); map.from(connection::getMode).whenNonNull().to(connectionFactory::setCacheMode);
/* 76 */     Objects.requireNonNull(connection); Objects.requireNonNull(connectionFactory); map.from(connection::getSize).whenNonNull().to(connectionFactory::setConnectionCacheSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\CachingConnectionFactoryConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */