/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.springframework.boot.context.properties.PropertyMapper;
/*    */ import org.springframework.retry.RetryPolicy;
/*    */ import org.springframework.retry.backoff.BackOffPolicy;
/*    */ import org.springframework.retry.backoff.ExponentialBackOffPolicy;
/*    */ import org.springframework.retry.policy.SimpleRetryPolicy;
/*    */ import org.springframework.retry.support.RetryTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RetryTemplateFactory
/*    */ {
/*    */   private final List<RabbitRetryTemplateCustomizer> customizers;
/*    */   
/*    */   RetryTemplateFactory(List<RabbitRetryTemplateCustomizer> customizers) {
/* 38 */     this.customizers = customizers;
/*    */   }
/*    */   
/*    */   RetryTemplate createRetryTemplate(RabbitProperties.Retry properties, RabbitRetryTemplateCustomizer.Target target) {
/* 42 */     PropertyMapper map = PropertyMapper.get();
/* 43 */     RetryTemplate template = new RetryTemplate();
/* 44 */     SimpleRetryPolicy policy = new SimpleRetryPolicy();
/* 45 */     Objects.requireNonNull(properties); Objects.requireNonNull(policy); map.from(properties::getMaxAttempts).to(policy::setMaxAttempts);
/* 46 */     template.setRetryPolicy((RetryPolicy)policy);
/* 47 */     ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
/* 48 */     Objects.requireNonNull(properties);
/*    */ 
/*    */     
/* 51 */     Objects.requireNonNull(backOffPolicy); map.from(properties::getInitialInterval).whenNonNull().as(Duration::toMillis).to(backOffPolicy::setInitialInterval);
/* 52 */     Objects.requireNonNull(properties); Objects.requireNonNull(backOffPolicy); map.from(properties::getMultiplier).to(backOffPolicy::setMultiplier);
/* 53 */     Objects.requireNonNull(properties); Objects.requireNonNull(backOffPolicy); map.from(properties::getMaxInterval).whenNonNull().as(Duration::toMillis).to(backOffPolicy::setMaxInterval);
/* 54 */     template.setBackOffPolicy((BackOffPolicy)backOffPolicy);
/* 55 */     if (this.customizers != null) {
/* 56 */       for (RabbitRetryTemplateCustomizer customizer : this.customizers) {
/* 57 */         customizer.customize(target, template);
/*    */       }
/*    */     }
/* 60 */     return template;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RetryTemplateFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */