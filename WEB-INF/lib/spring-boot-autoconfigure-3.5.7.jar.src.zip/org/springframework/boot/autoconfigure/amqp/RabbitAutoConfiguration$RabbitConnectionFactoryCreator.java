/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import com.rabbitmq.client.ConnectionFactory;
/*     */ import com.rabbitmq.client.impl.CredentialsProvider;
/*     */ import com.rabbitmq.client.impl.CredentialsRefreshService;
/*     */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
/*     */ import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ public class RabbitConnectionFactoryCreator
/*     */ {
/*     */   private final RabbitProperties properties;
/*     */   
/*     */   protected RabbitConnectionFactoryCreator(RabbitProperties properties) {
/*  88 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   RabbitConnectionDetails rabbitConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/*  94 */     return new PropertiesRabbitConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   RabbitConnectionFactoryBeanConfigurer rabbitConnectionFactoryBeanConfigurer(ResourceLoader resourceLoader, RabbitConnectionDetails connectionDetails, ObjectProvider<CredentialsProvider> credentialsProvider, ObjectProvider<CredentialsRefreshService> credentialsRefreshService) {
/* 102 */     RabbitConnectionFactoryBeanConfigurer configurer = new RabbitConnectionFactoryBeanConfigurer(resourceLoader, this.properties, connectionDetails);
/*     */     
/* 104 */     configurer.setCredentialsProvider((CredentialsProvider)credentialsProvider.getIfUnique());
/* 105 */     configurer.setCredentialsRefreshService((CredentialsRefreshService)credentialsRefreshService.getIfUnique());
/* 106 */     return configurer;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   CachingConnectionFactoryConfigurer rabbitConnectionFactoryConfigurer(RabbitConnectionDetails connectionDetails, ObjectProvider<ConnectionNameStrategy> connectionNameStrategy) {
/* 113 */     CachingConnectionFactoryConfigurer configurer = new CachingConnectionFactoryConfigurer(this.properties, connectionDetails);
/*     */     
/* 115 */     configurer.setConnectionNameStrategy((ConnectionNameStrategy)connectionNameStrategy.getIfUnique());
/* 116 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ConnectionFactory.class})
/*     */   CachingConnectionFactory rabbitConnectionFactory(RabbitConnectionFactoryBeanConfigurer rabbitConnectionFactoryBeanConfigurer, CachingConnectionFactoryConfigurer rabbitCachingConnectionFactoryConfigurer, ObjectProvider<ConnectionFactoryCustomizer> connectionFactoryCustomizers) throws Exception {
/* 125 */     RabbitConnectionFactoryBean connectionFactoryBean = new SslBundleRabbitConnectionFactoryBean();
/* 126 */     rabbitConnectionFactoryBeanConfigurer.configure(connectionFactoryBean);
/* 127 */     connectionFactoryBean.afterPropertiesSet();
/* 128 */     ConnectionFactory connectionFactory = (ConnectionFactory)connectionFactoryBean.getObject();
/* 129 */     connectionFactoryCustomizers.orderedStream()
/* 130 */       .forEach(customizer -> customizer.customize(connectionFactory));
/* 131 */     CachingConnectionFactory factory = new CachingConnectionFactory(connectionFactory);
/* 132 */     rabbitCachingConnectionFactoryConfigurer.configure(factory);
/* 133 */     return factory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAutoConfiguration$RabbitConnectionFactoryCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */