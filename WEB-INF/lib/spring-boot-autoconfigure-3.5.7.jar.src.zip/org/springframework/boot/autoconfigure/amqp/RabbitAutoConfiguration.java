/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import com.rabbitmq.client.Channel;
/*     */ import com.rabbitmq.client.ConnectionFactory;
/*     */ import com.rabbitmq.client.impl.CredentialsProvider;
/*     */ import com.rabbitmq.client.impl.CredentialsRefreshService;
/*     */ import org.springframework.amqp.core.AmqpAdmin;
/*     */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
/*     */ import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
/*     */ import org.springframework.amqp.rabbit.core.RabbitAdmin;
/*     */ import org.springframework.amqp.rabbit.core.RabbitMessagingTemplate;
/*     */ import org.springframework.amqp.rabbit.core.RabbitOperations;
/*     */ import org.springframework.amqp.rabbit.core.RabbitTemplate;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.ssl.SslBundles;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration
/*     */ @ConditionalOnClass({RabbitTemplate.class, Channel.class})
/*     */ @EnableConfigurationProperties({RabbitProperties.class})
/*     */ @Import({RabbitAnnotationDrivenConfiguration.class, RabbitStreamConfiguration.class})
/*     */ public class RabbitAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   protected static class RabbitConnectionFactoryCreator
/*     */   {
/*     */     private final RabbitProperties properties;
/*     */     
/*     */     protected RabbitConnectionFactoryCreator(RabbitProperties properties) {
/*  88 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RabbitConnectionDetails rabbitConnectionDetails(ObjectProvider<SslBundles> sslBundles) {
/*  94 */       return new PropertiesRabbitConnectionDetails(this.properties, (SslBundles)sslBundles.getIfAvailable());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     RabbitConnectionFactoryBeanConfigurer rabbitConnectionFactoryBeanConfigurer(ResourceLoader resourceLoader, RabbitConnectionDetails connectionDetails, ObjectProvider<CredentialsProvider> credentialsProvider, ObjectProvider<CredentialsRefreshService> credentialsRefreshService) {
/* 102 */       RabbitConnectionFactoryBeanConfigurer configurer = new RabbitConnectionFactoryBeanConfigurer(resourceLoader, this.properties, connectionDetails);
/*     */       
/* 104 */       configurer.setCredentialsProvider((CredentialsProvider)credentialsProvider.getIfUnique());
/* 105 */       configurer.setCredentialsRefreshService((CredentialsRefreshService)credentialsRefreshService.getIfUnique());
/* 106 */       return configurer;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     CachingConnectionFactoryConfigurer rabbitConnectionFactoryConfigurer(RabbitConnectionDetails connectionDetails, ObjectProvider<ConnectionNameStrategy> connectionNameStrategy) {
/* 113 */       CachingConnectionFactoryConfigurer configurer = new CachingConnectionFactoryConfigurer(this.properties, connectionDetails);
/*     */       
/* 115 */       configurer.setConnectionNameStrategy((ConnectionNameStrategy)connectionNameStrategy.getIfUnique());
/* 116 */       return configurer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({ConnectionFactory.class})
/*     */     CachingConnectionFactory rabbitConnectionFactory(RabbitConnectionFactoryBeanConfigurer rabbitConnectionFactoryBeanConfigurer, CachingConnectionFactoryConfigurer rabbitCachingConnectionFactoryConfigurer, ObjectProvider<ConnectionFactoryCustomizer> connectionFactoryCustomizers) throws Exception {
/* 125 */       RabbitConnectionFactoryBean connectionFactoryBean = new SslBundleRabbitConnectionFactoryBean();
/* 126 */       rabbitConnectionFactoryBeanConfigurer.configure(connectionFactoryBean);
/* 127 */       connectionFactoryBean.afterPropertiesSet();
/* 128 */       ConnectionFactory connectionFactory = (ConnectionFactory)connectionFactoryBean.getObject();
/* 129 */       connectionFactoryCustomizers.orderedStream()
/* 130 */         .forEach(customizer -> customizer.customize(connectionFactory));
/* 131 */       CachingConnectionFactory factory = new CachingConnectionFactory(connectionFactory);
/* 132 */       rabbitCachingConnectionFactoryConfigurer.configure(factory);
/* 133 */       return factory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @Import({RabbitConnectionFactoryCreator.class})
/*     */   protected static class RabbitTemplateConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public RabbitTemplateConfigurer rabbitTemplateConfigurer(RabbitProperties properties, ObjectProvider<MessageConverter> messageConverter, ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers) {
/* 147 */       RabbitTemplateConfigurer configurer = new RabbitTemplateConfigurer(properties);
/* 148 */       configurer.setMessageConverter((MessageConverter)messageConverter.getIfUnique());
/* 149 */       configurer.setRetryTemplateCustomizers(retryTemplateCustomizers.orderedStream().toList());
/* 150 */       return configurer;
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */     @ConditionalOnMissingBean({RabbitOperations.class})
/*     */     public RabbitTemplate rabbitTemplate(RabbitTemplateConfigurer configurer, ConnectionFactory connectionFactory, ObjectProvider<RabbitTemplateCustomizer> customizers) {
/* 158 */       RabbitTemplate template = new RabbitTemplate();
/* 159 */       configurer.configure(template, connectionFactory);
/* 160 */       customizers.orderedStream().forEach(customizer -> customizer.customize(template));
/* 161 */       return template;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */     @ConditionalOnBooleanProperty(name = {"spring.rabbitmq.dynamic"}, matchIfMissing = true)
/*     */     @ConditionalOnMissingBean
/*     */     public AmqpAdmin amqpAdmin(ConnectionFactory connectionFactory) {
/* 169 */       return (AmqpAdmin)new RabbitAdmin(connectionFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({RabbitMessagingTemplate.class})
/*     */   @ConditionalOnMissingBean({RabbitMessagingTemplate.class})
/*     */   @Import({RabbitTemplateConfiguration.class})
/*     */   protected static class RabbitMessagingTemplateConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnSingleCandidate(RabbitTemplate.class)
/*     */     public RabbitMessagingTemplate rabbitMessagingTemplate(RabbitTemplate rabbitTemplate) {
/* 183 */       return new RabbitMessagingTemplate(rabbitTemplate);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */