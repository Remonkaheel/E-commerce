/*    */ package org.springframework.boot.autoconfigure.amqp;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;
/*    */ import org.springframework.boot.ssl.SslBundle;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RabbitConnectionDetails
/*    */   extends ConnectionDetails
/*    */ {
/*    */   default String getUsername() {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getPassword() {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String getVirtualHost() {
/* 56 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   List<Address> getAddresses();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Address getFirstAddress() {
/* 72 */     List<Address> addresses = getAddresses();
/* 73 */     Assert.state(!addresses.isEmpty(), "Address list is empty");
/* 74 */     return addresses.get(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default SslBundle getSslBundle() {
/* 83 */     return null;
/*    */   }
/*    */   public static final class Address extends Record { private final String host; private final int port;
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #92	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;
/*    */     }
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #92	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;
/*    */     }
/* 92 */     public Address(String host, int port) { this.host = host; this.port = port; } public String host() { return this.host; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #92	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/boot/autoconfigure/amqp/RabbitConnectionDetails$Address;
/* 92 */       //   0	8	1	o	Ljava/lang/Object; } public int port() { return this.port; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */