/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.springframework.amqp.rabbit.annotation.EnableRabbit;
/*     */ import org.springframework.amqp.rabbit.config.ContainerCustomizer;
/*     */ import org.springframework.amqp.rabbit.config.DirectRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
/*     */ import org.springframework.amqp.rabbit.connection.ConnectionFactory;
/*     */ import org.springframework.amqp.rabbit.listener.DirectMessageListenerContainer;
/*     */ import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
/*     */ import org.springframework.amqp.rabbit.retry.MessageRecoverer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnThreading;
/*     */ import org.springframework.boot.autoconfigure.thread.Threading;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.task.VirtualThreadTaskExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({EnableRabbit.class})
/*     */ class RabbitAnnotationDrivenConfiguration
/*     */ {
/*     */   private final ObjectProvider<MessageConverter> messageConverter;
/*     */   private final ObjectProvider<MessageRecoverer> messageRecoverer;
/*     */   private final ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers;
/*     */   private final RabbitProperties properties;
/*     */   
/*     */   RabbitAnnotationDrivenConfiguration(ObjectProvider<MessageConverter> messageConverter, ObjectProvider<MessageRecoverer> messageRecoverer, ObjectProvider<RabbitRetryTemplateCustomizer> retryTemplateCustomizers, RabbitProperties properties) {
/*  61 */     this.messageConverter = messageConverter;
/*  62 */     this.messageRecoverer = messageRecoverer;
/*  63 */     this.retryTemplateCustomizers = retryTemplateCustomizers;
/*  64 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnThreading(Threading.PLATFORM)
/*     */   SimpleRabbitListenerContainerFactoryConfigurer simpleRabbitListenerContainerFactoryConfigurer() {
/*  71 */     return simpleListenerConfigurer();
/*     */   }
/*     */   
/*     */   @Bean(name = {"simpleRabbitListenerContainerFactoryConfigurer"})
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnThreading(Threading.VIRTUAL)
/*     */   SimpleRabbitListenerContainerFactoryConfigurer simpleRabbitListenerContainerFactoryConfigurerVirtualThreads() {
/*  78 */     SimpleRabbitListenerContainerFactoryConfigurer configurer = simpleListenerConfigurer();
/*  79 */     configurer.setTaskExecutor((Executor)new VirtualThreadTaskExecutor("rabbit-simple-"));
/*  80 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnProperty(name = {"spring.rabbitmq.listener.type"}, havingValue = "simple", matchIfMissing = true)
/*     */   SimpleRabbitListenerContainerFactory simpleRabbitListenerContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory, ObjectProvider<ContainerCustomizer<SimpleMessageListenerContainer>> simpleContainerCustomizer) {
/*  89 */     SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
/*  90 */     configurer.configure(factory, connectionFactory);
/*  91 */     Objects.requireNonNull(factory); simpleContainerCustomizer.ifUnique(factory::setContainerCustomizer);
/*  92 */     return factory;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnThreading(Threading.PLATFORM)
/*     */   DirectRabbitListenerContainerFactoryConfigurer directRabbitListenerContainerFactoryConfigurer() {
/*  99 */     return directListenerConfigurer();
/*     */   }
/*     */   
/*     */   @Bean(name = {"directRabbitListenerContainerFactoryConfigurer"})
/*     */   @ConditionalOnMissingBean
/*     */   @ConditionalOnThreading(Threading.VIRTUAL)
/*     */   DirectRabbitListenerContainerFactoryConfigurer directRabbitListenerContainerFactoryConfigurerVirtualThreads() {
/* 106 */     DirectRabbitListenerContainerFactoryConfigurer configurer = directListenerConfigurer();
/* 107 */     configurer.setTaskExecutor((Executor)new VirtualThreadTaskExecutor("rabbit-direct-"));
/* 108 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnProperty(name = {"spring.rabbitmq.listener.type"}, havingValue = "direct")
/*     */   DirectRabbitListenerContainerFactory directRabbitListenerContainerFactory(DirectRabbitListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory, ObjectProvider<ContainerCustomizer<DirectMessageListenerContainer>> directContainerCustomizer) {
/* 117 */     DirectRabbitListenerContainerFactory factory = new DirectRabbitListenerContainerFactory();
/* 118 */     configurer.configure(factory, connectionFactory);
/* 119 */     Objects.requireNonNull(factory); directContainerCustomizer.ifUnique(factory::setContainerCustomizer);
/* 120 */     return factory;
/*     */   }
/*     */   
/*     */   private SimpleRabbitListenerContainerFactoryConfigurer simpleListenerConfigurer() {
/* 124 */     SimpleRabbitListenerContainerFactoryConfigurer configurer = new SimpleRabbitListenerContainerFactoryConfigurer(this.properties);
/*     */     
/* 126 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/* 127 */     configurer.setMessageRecoverer((MessageRecoverer)this.messageRecoverer.getIfUnique());
/* 128 */     configurer.setRetryTemplateCustomizers(this.retryTemplateCustomizers.orderedStream().toList());
/* 129 */     return configurer;
/*     */   }
/*     */   
/*     */   private DirectRabbitListenerContainerFactoryConfigurer directListenerConfigurer() {
/* 133 */     DirectRabbitListenerContainerFactoryConfigurer configurer = new DirectRabbitListenerContainerFactoryConfigurer(this.properties);
/*     */     
/* 135 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/* 136 */     configurer.setMessageRecoverer((MessageRecoverer)this.messageRecoverer.getIfUnique());
/* 137 */     configurer.setRetryTemplateCustomizers(this.retryTemplateCustomizers.orderedStream().toList());
/* 138 */     return configurer;
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @EnableRabbit
/*     */   @ConditionalOnMissingBean(name = {"org.springframework.amqp.rabbit.config.internalRabbitListenerAnnotationProcessor"})
/*     */   static class EnableRabbitConfiguration {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitAnnotationDrivenConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */