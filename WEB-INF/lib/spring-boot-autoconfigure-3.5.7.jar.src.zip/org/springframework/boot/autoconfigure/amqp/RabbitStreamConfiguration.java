/*     */ package org.springframework.boot.autoconfigure.amqp;
/*     */ 
/*     */ import com.rabbitmq.stream.Environment;
/*     */ import com.rabbitmq.stream.EnvironmentBuilder;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.amqp.rabbit.config.ContainerCustomizer;
/*     */ import org.springframework.amqp.support.converter.MessageConverter;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.rabbit.stream.config.StreamRabbitListenerContainerFactory;
/*     */ import org.springframework.rabbit.stream.listener.ConsumerCustomizer;
/*     */ import org.springframework.rabbit.stream.listener.StreamListenerContainer;
/*     */ import org.springframework.rabbit.stream.producer.ProducerCustomizer;
/*     */ import org.springframework.rabbit.stream.producer.RabbitStreamOperations;
/*     */ import org.springframework.rabbit.stream.producer.RabbitStreamTemplate;
/*     */ import org.springframework.rabbit.stream.support.converter.StreamMessageConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({StreamRabbitListenerContainerFactory.class})
/*     */ class RabbitStreamConfiguration
/*     */ {
/*     */   @Bean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitListenerContainerFactory"})
/*     */   @ConditionalOnProperty(name = {"spring.rabbitmq.listener.type"}, havingValue = "stream")
/*     */   StreamRabbitListenerContainerFactory streamRabbitListenerContainerFactory(Environment rabbitStreamEnvironment, RabbitProperties properties, ObjectProvider<ConsumerCustomizer> consumerCustomizer, ObjectProvider<ContainerCustomizer<StreamListenerContainer>> containerCustomizer) {
/*  59 */     StreamRabbitListenerContainerFactory factory = new StreamRabbitListenerContainerFactory(rabbitStreamEnvironment);
/*     */     
/*  61 */     RabbitProperties.StreamContainer stream = properties.getListener().getStream();
/*  62 */     factory.setObservationEnabled(stream.isObservationEnabled());
/*  63 */     factory.setNativeListener(stream.isNativeListener());
/*  64 */     Objects.requireNonNull(factory); consumerCustomizer.ifUnique(factory::setConsumerCustomizer);
/*  65 */     Objects.requireNonNull(factory); containerCustomizer.ifUnique(factory::setContainerCustomizer);
/*  66 */     return factory;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean(name = {"rabbitStreamEnvironment"})
/*     */   @ConditionalOnMissingBean(name = {"rabbitStreamEnvironment"})
/*     */   Environment rabbitStreamEnvironment(RabbitProperties properties, RabbitConnectionDetails connectionDetails, ObjectProvider<EnvironmentBuilderCustomizer> customizers) {
/*  73 */     EnvironmentBuilder builder = configure(Environment.builder(), properties, connectionDetails);
/*  74 */     customizers.orderedStream().forEach(customizer -> customizer.customize(builder));
/*  75 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   RabbitStreamTemplateConfigurer rabbitStreamTemplateConfigurer(RabbitProperties properties, ObjectProvider<MessageConverter> messageConverter, ObjectProvider<StreamMessageConverter> streamMessageConverter, ObjectProvider<ProducerCustomizer> producerCustomizer) {
/*  84 */     RabbitStreamTemplateConfigurer configurer = new RabbitStreamTemplateConfigurer();
/*  85 */     configurer.setMessageConverter((MessageConverter)messageConverter.getIfUnique());
/*  86 */     configurer.setStreamMessageConverter((StreamMessageConverter)streamMessageConverter.getIfUnique());
/*  87 */     configurer.setProducerCustomizer((ProducerCustomizer)producerCustomizer.getIfUnique());
/*  88 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({RabbitStreamOperations.class})
/*     */   @ConditionalOnProperty(name = {"spring.rabbitmq.stream.name"})
/*     */   RabbitStreamTemplate rabbitStreamTemplate(Environment rabbitStreamEnvironment, RabbitProperties properties, RabbitStreamTemplateConfigurer configurer) {
/*  97 */     RabbitStreamTemplate template = new RabbitStreamTemplate(rabbitStreamEnvironment, properties.getStream().getName());
/*  98 */     configurer.configure(template);
/*  99 */     return template;
/*     */   }
/*     */ 
/*     */   
/*     */   static EnvironmentBuilder configure(EnvironmentBuilder builder, RabbitProperties properties, RabbitConnectionDetails connectionDetails) {
/* 104 */     return configure(builder, properties.getStream(), connectionDetails);
/*     */   }
/*     */ 
/*     */   
/*     */   private static EnvironmentBuilder configure(EnvironmentBuilder builder, RabbitProperties.Stream stream, RabbitConnectionDetails connectionDetails) {
/* 109 */     builder.lazyInitialization(true);
/* 110 */     PropertyMapper map = PropertyMapper.get();
/* 111 */     Objects.requireNonNull(builder); map.from(stream.getHost()).to(builder::host);
/* 112 */     Objects.requireNonNull(builder); map.from(Integer.valueOf(stream.getPort())).to(builder::port);
/*     */     
/* 114 */     Objects.requireNonNull(connectionDetails);
/*     */     
/* 116 */     Objects.requireNonNull(builder); map.from(stream.getVirtualHost()).as(withFallback(connectionDetails::getVirtualHost)).whenNonNull().to(builder::virtualHost);
/*     */     
/* 118 */     Objects.requireNonNull(connectionDetails);
/*     */     
/* 120 */     Objects.requireNonNull(builder); map.from(stream.getUsername()).as(withFallback(connectionDetails::getUsername)).whenNonNull().to(builder::username);
/*     */     
/* 122 */     Objects.requireNonNull(connectionDetails);
/*     */     
/* 124 */     Objects.requireNonNull(builder); map.from(stream.getPassword()).as(withFallback(connectionDetails::getPassword)).whenNonNull().to(builder::password);
/* 125 */     return builder;
/*     */   }
/*     */   
/*     */   private static Function<String, String> withFallback(Supplier<String> fallback) {
/* 129 */     return value -> (value != null) ? value : fallback.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitStreamConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */