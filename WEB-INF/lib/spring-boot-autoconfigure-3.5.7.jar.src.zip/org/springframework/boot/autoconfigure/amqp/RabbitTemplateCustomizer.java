package org.springframework.boot.autoconfigure.amqp;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

@FunctionalInterface
public interface RabbitTemplateCustomizer {
  void customize(RabbitTemplate paramRabbitTemplate);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\amqp\RabbitTemplateCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */