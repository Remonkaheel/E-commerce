package org.springframework.boot.autoconfigure.flyway;

import javax.sql.DataSource;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

@ConditionalOnBean({DataSource.class})
final class DataSourceBeanCondition {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration$FlywayDataSourceCondition$DataSourceBeanCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */