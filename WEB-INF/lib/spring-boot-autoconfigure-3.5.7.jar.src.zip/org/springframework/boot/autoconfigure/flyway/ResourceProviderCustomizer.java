package org.springframework.boot.autoconfigure.flyway;

import org.flywaydb.core.api.configuration.FluentConfiguration;

class ResourceProviderCustomizer {
  void customize(FluentConfiguration configuration) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\ResourceProviderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */