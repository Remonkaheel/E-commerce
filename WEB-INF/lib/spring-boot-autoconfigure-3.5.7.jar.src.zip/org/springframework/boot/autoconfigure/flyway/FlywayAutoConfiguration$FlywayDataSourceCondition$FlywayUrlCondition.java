package org.springframework.boot.autoconfigure.flyway;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@ConditionalOnProperty({"spring.flyway.url"})
final class FlywayUrlCondition {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration$FlywayDataSourceCondition$FlywayUrlCondition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */