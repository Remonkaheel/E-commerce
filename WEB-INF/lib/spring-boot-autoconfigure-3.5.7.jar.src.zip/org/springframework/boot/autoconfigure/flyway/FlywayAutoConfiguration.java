/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.time.Duration;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import javax.sql.DataSource;
/*     */ import org.flywaydb.core.Flyway;
/*     */ import org.flywaydb.core.api.MigrationVersion;
/*     */ import org.flywaydb.core.api.callback.Callback;
/*     */ import org.flywaydb.core.api.configuration.FluentConfiguration;
/*     */ import org.flywaydb.core.api.migration.JavaMigration;
/*     */ import org.flywaydb.core.extensibility.ConfigurationExtension;
/*     */ import org.flywaydb.database.oracle.OracleConfigurationExtension;
/*     */ import org.flywaydb.database.postgresql.PostgreSQLConfigurationExtension;
/*     */ import org.flywaydb.database.sqlserver.SQLServerConfigurationExtension;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcConnectionDetails;
/*     */ import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.boot.sql.init.dependency.DatabaseInitializationDependencyConfigurer;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.context.annotation.ImportRuntimeHints;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.MetaDataAccessException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoConfiguration(after = {DataSourceAutoConfiguration.class, JdbcTemplateAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ @ConditionalOnClass({Flyway.class})
/*     */ @Conditional({FlywayAutoConfiguration.FlywayDataSourceCondition.class})
/*     */ @ConditionalOnBooleanProperty(name = {"spring.flyway.enabled"}, matchIfMissing = true)
/*     */ @Import({DatabaseInitializationDependencyConfigurer.class})
/*     */ @ImportRuntimeHints({FlywayAutoConfiguration.FlywayAutoConfigurationRuntimeHints.class})
/*     */ public class FlywayAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConfigurationPropertiesBinding
/*     */   public static StringOrNumberToMigrationVersionConverter stringOrNumberMigrationVersionConverter() {
/* 117 */     return new StringOrNumberToMigrationVersionConverter();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public FlywaySchemaManagementProvider flywayDefaultDdlModeProvider(ObjectProvider<Flyway> flyways) {
/* 122 */     return new FlywaySchemaManagementProvider((Iterable<Flyway>)flyways);
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass({JdbcUtils.class})
/*     */   @ConditionalOnMissingBean({Flyway.class})
/*     */   @EnableConfigurationProperties({FlywayProperties.class})
/*     */   public static class FlywayConfiguration
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */     
/*     */     FlywayConfiguration(FlywayProperties properties) {
/* 134 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     ResourceProviderCustomizer resourceProviderCustomizer() {
/* 139 */       return new ResourceProviderCustomizer();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({FlywayConnectionDetails.class})
/*     */     FlywayAutoConfiguration.PropertiesFlywayConnectionDetails flywayConnectionDetails() {
/* 145 */       return new FlywayAutoConfiguration.PropertiesFlywayConnectionDetails(this.properties);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Bean
/*     */     Flyway flyway(FlywayConnectionDetails connectionDetails, ResourceLoader resourceLoader, ObjectProvider<DataSource> dataSource, @FlywayDataSource ObjectProvider<DataSource> flywayDataSource, ObjectProvider<FlywayConfigurationCustomizer> fluentConfigurationCustomizers, ObjectProvider<JavaMigration> javaMigrations, ObjectProvider<Callback> callbacks, ResourceProviderCustomizer resourceProviderCustomizer) {
/* 154 */       FluentConfiguration configuration = new FluentConfiguration(resourceLoader.getClassLoader());
/* 155 */       configureDataSource(configuration, (DataSource)flywayDataSource.getIfAvailable(), (DataSource)dataSource.getIfUnique(), connectionDetails);
/*     */       
/* 157 */       configureProperties(configuration, this.properties);
/* 158 */       configureCallbacks(configuration, callbacks.orderedStream().toList());
/* 159 */       configureJavaMigrations(configuration, javaMigrations.orderedStream().toList());
/* 160 */       fluentConfigurationCustomizers.orderedStream().forEach(customizer -> customizer.customize(configuration));
/* 161 */       resourceProviderCustomizer.customize(configuration);
/* 162 */       return configuration.load();
/*     */     }
/*     */ 
/*     */     
/*     */     private void configureDataSource(FluentConfiguration configuration, DataSource flywayDataSource, DataSource dataSource, FlywayConnectionDetails connectionDetails) {
/* 167 */       DataSource migrationDataSource = getMigrationDataSource(flywayDataSource, dataSource, connectionDetails);
/* 168 */       configuration.dataSource(migrationDataSource);
/*     */     }
/*     */ 
/*     */     
/*     */     private DataSource getMigrationDataSource(DataSource flywayDataSource, DataSource dataSource, FlywayConnectionDetails connectionDetails) {
/* 173 */       if (flywayDataSource != null) {
/* 174 */         return flywayDataSource;
/*     */       }
/* 176 */       String url = connectionDetails.getJdbcUrl();
/* 177 */       if (url != null) {
/* 178 */         DataSourceBuilder<?> builder = DataSourceBuilder.create().type(SimpleDriverDataSource.class);
/* 179 */         builder.url(url);
/* 180 */         applyConnectionDetails(connectionDetails, builder);
/* 181 */         return builder.build();
/*     */       } 
/* 183 */       String user = connectionDetails.getUsername();
/* 184 */       if (user != null && dataSource != null) {
/*     */         
/* 186 */         DataSourceBuilder<?> builder = DataSourceBuilder.derivedFrom(dataSource).type(SimpleDriverDataSource.class);
/* 187 */         applyConnectionDetails(connectionDetails, builder);
/* 188 */         return builder.build();
/*     */       } 
/* 190 */       Assert.state((dataSource != null), "Flyway migration DataSource missing");
/* 191 */       return dataSource;
/*     */     }
/*     */     
/*     */     private void applyConnectionDetails(FlywayConnectionDetails connectionDetails, DataSourceBuilder<?> builder) {
/* 195 */       builder.username(connectionDetails.getUsername());
/* 196 */       builder.password(connectionDetails.getPassword());
/* 197 */       String driverClassName = connectionDetails.getDriverClassName();
/* 198 */       if (StringUtils.hasText(driverClassName)) {
/* 199 */         builder.driverClassName(driverClassName);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void configureProperties(FluentConfiguration configuration, FlywayProperties properties) {
/* 215 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*     */ 
/*     */       
/* 218 */       String[] locations = (new FlywayAutoConfiguration.LocationResolver(configuration.getDataSource())).resolveLocations(properties.getLocations()).<String>toArray(new String[0]);
/* 219 */       configuration.locations(locations);
/* 220 */       map.from(Boolean.valueOf(properties.isFailOnMissingLocations()))
/* 221 */         .to(failOnMissingLocations -> configuration.failOnMissingLocations(failOnMissingLocations.booleanValue()));
/* 222 */       map.from(properties.getEncoding()).to(encoding -> configuration.encoding(encoding));
/* 223 */       map.from(Integer.valueOf(properties.getConnectRetries()))
/* 224 */         .to(connectRetries -> configuration.connectRetries(connectRetries.intValue()));
/* 225 */       map.from(properties.getConnectRetriesInterval())
/* 226 */         .as(Duration::getSeconds)
/* 227 */         .as(Long::intValue)
/* 228 */         .to(connectRetriesInterval -> configuration.connectRetriesInterval(connectRetriesInterval.intValue()));
/* 229 */       map.from(Integer.valueOf(properties.getLockRetryCount()))
/* 230 */         .to(lockRetryCount -> configuration.lockRetryCount(lockRetryCount.intValue()));
/* 231 */       map.from(properties.getDefaultSchema()).to(schema -> configuration.defaultSchema(schema));
/* 232 */       map.from(properties.getSchemas())
/* 233 */         .as(StringUtils::toStringArray)
/* 234 */         .to(schemas -> configuration.schemas(schemas));
/* 235 */       map.from(Boolean.valueOf(properties.isCreateSchemas())).to(createSchemas -> configuration.createSchemas(createSchemas.booleanValue()));
/* 236 */       map.from(properties.getTable()).to(table -> configuration.table(table));
/* 237 */       map.from(properties.getTablespace()).to(tablespace -> configuration.tablespace(tablespace));
/* 238 */       map.from(properties.getBaselineDescription())
/* 239 */         .to(baselineDescription -> configuration.baselineDescription(baselineDescription));
/* 240 */       map.from(properties.getBaselineVersion())
/* 241 */         .to(baselineVersion -> configuration.baselineVersion(baselineVersion));
/* 242 */       map.from(properties.getInstalledBy()).to(installedBy -> configuration.installedBy(installedBy));
/* 243 */       map.from(properties.getPlaceholders()).to(placeholders -> configuration.placeholders(placeholders));
/* 244 */       map.from(properties.getPlaceholderPrefix())
/* 245 */         .to(placeholderPrefix -> configuration.placeholderPrefix(placeholderPrefix));
/* 246 */       map.from(properties.getPlaceholderSuffix())
/* 247 */         .to(placeholderSuffix -> configuration.placeholderSuffix(placeholderSuffix));
/* 248 */       map.from(properties.getPlaceholderSeparator())
/* 249 */         .to(placeHolderSeparator -> configuration.placeholderSeparator(placeHolderSeparator));
/* 250 */       map.from(Boolean.valueOf(properties.isPlaceholderReplacement()))
/* 251 */         .to(placeholderReplacement -> configuration.placeholderReplacement(placeholderReplacement.booleanValue()));
/* 252 */       map.from(properties.getSqlMigrationPrefix())
/* 253 */         .to(sqlMigrationPrefix -> configuration.sqlMigrationPrefix(sqlMigrationPrefix));
/* 254 */       map.from(properties.getSqlMigrationSuffixes())
/* 255 */         .as(StringUtils::toStringArray)
/* 256 */         .to(sqlMigrationSuffixes -> configuration.sqlMigrationSuffixes(sqlMigrationSuffixes));
/* 257 */       map.from(properties.getSqlMigrationSeparator())
/* 258 */         .to(sqlMigrationSeparator -> configuration.sqlMigrationSeparator(sqlMigrationSeparator));
/* 259 */       map.from(properties.getRepeatableSqlMigrationPrefix())
/* 260 */         .to(repeatableSqlMigrationPrefix -> configuration.repeatableSqlMigrationPrefix(repeatableSqlMigrationPrefix));
/*     */       
/* 262 */       map.from(properties.getTarget()).to(target -> configuration.target(target));
/* 263 */       map.from(Boolean.valueOf(properties.isBaselineOnMigrate()))
/* 264 */         .to(baselineOnMigrate -> configuration.baselineOnMigrate(baselineOnMigrate.booleanValue()));
/* 265 */       map.from(Boolean.valueOf(properties.isCleanDisabled())).to(cleanDisabled -> configuration.cleanDisabled(cleanDisabled.booleanValue()));
/* 266 */       map.from(Boolean.valueOf(properties.isCleanOnValidationError()))
/* 267 */         .to(cleanOnValidationError -> configuration.cleanOnValidationError(cleanOnValidationError.booleanValue()));
/* 268 */       map.from(Boolean.valueOf(properties.isGroup())).to(group -> configuration.group(group.booleanValue()));
/* 269 */       map.from(Boolean.valueOf(properties.isMixed())).to(mixed -> configuration.mixed(mixed.booleanValue()));
/* 270 */       map.from(Boolean.valueOf(properties.isOutOfOrder())).to(outOfOrder -> configuration.outOfOrder(outOfOrder.booleanValue()));
/* 271 */       map.from(Boolean.valueOf(properties.isSkipDefaultCallbacks()))
/* 272 */         .to(skipDefaultCallbacks -> configuration.skipDefaultCallbacks(skipDefaultCallbacks.booleanValue()));
/* 273 */       map.from(Boolean.valueOf(properties.isSkipDefaultResolvers()))
/* 274 */         .to(skipDefaultResolvers -> configuration.skipDefaultResolvers(skipDefaultResolvers.booleanValue()));
/* 275 */       map.from(Boolean.valueOf(properties.isValidateMigrationNaming()))
/* 276 */         .to(validateMigrationNaming -> configuration.validateMigrationNaming(validateMigrationNaming.booleanValue()));
/* 277 */       map.from(Boolean.valueOf(properties.isValidateOnMigrate()))
/* 278 */         .to(validateOnMigrate -> configuration.validateOnMigrate(validateOnMigrate.booleanValue()));
/* 279 */       map.from(properties.getInitSqls())
/* 280 */         .whenNot(CollectionUtils::isEmpty)
/* 281 */         .as(initSqls -> StringUtils.collectionToDelimitedString(initSqls, "\n"))
/* 282 */         .to(initSql -> configuration.initSql(initSql));
/* 283 */       map.from(properties.getScriptPlaceholderPrefix())
/* 284 */         .to(prefix -> configuration.scriptPlaceholderPrefix(prefix));
/* 285 */       map.from(properties.getScriptPlaceholderSuffix())
/* 286 */         .to(suffix -> configuration.scriptPlaceholderSuffix(suffix));
/* 287 */       configureExecuteInTransaction(configuration, properties, map);
/* 288 */       Objects.requireNonNull(properties); map.from(properties::getLoggers).to(loggers -> configuration.loggers(loggers));
/* 289 */       Objects.requireNonNull(properties); map.from(properties::getCommunityDbSupportEnabled)
/* 290 */         .to(communityDbSupportEnabled -> configuration.communityDBSupportEnabled(communityDbSupportEnabled.booleanValue()));
/* 291 */       map.from(properties.getBatch()).to(batch -> configuration.batch(batch.booleanValue()));
/* 292 */       map.from(properties.getDryRunOutput()).to(dryRunOutput -> configuration.dryRunOutput(dryRunOutput));
/* 293 */       map.from(properties.getErrorOverrides())
/* 294 */         .to(errorOverrides -> configuration.errorOverrides(errorOverrides));
/* 295 */       map.from(properties.getStream()).to(stream -> configuration.stream(stream.booleanValue()));
/* 296 */       map.from(properties.getJdbcProperties())
/* 297 */         .whenNot(Map::isEmpty)
/* 298 */         .to(jdbcProperties -> configuration.jdbcProperties(jdbcProperties));
/* 299 */       map.from(properties.getKerberosConfigFile())
/* 300 */         .to(configFile -> configuration.kerberosConfigFile(configFile));
/* 301 */       map.from(properties.getOutputQueryResults())
/* 302 */         .to(outputQueryResults -> configuration.outputQueryResults(outputQueryResults.booleanValue()));
/* 303 */       map.from(properties.getSkipExecutingMigrations())
/* 304 */         .to(skipExecutingMigrations -> configuration.skipExecutingMigrations(skipExecutingMigrations.booleanValue()));
/* 305 */       map.from(properties.getIgnoreMigrationPatterns())
/* 306 */         .to(ignoreMigrationPatterns -> configuration.ignoreMigrationPatterns((String[])ignoreMigrationPatterns.toArray((Object[])new String[0])));
/*     */       
/* 308 */       map.from(properties.getDetectEncoding())
/* 309 */         .to(detectEncoding -> configuration.detectEncoding(detectEncoding.booleanValue()));
/*     */     }
/*     */ 
/*     */     
/*     */     private void configureExecuteInTransaction(FluentConfiguration configuration, FlywayProperties properties, PropertyMapper map) {
/*     */       try {
/* 315 */         Objects.requireNonNull(configuration); map.from(Boolean.valueOf(properties.isExecuteInTransaction())).to(configuration::executeInTransaction);
/*     */       }
/* 317 */       catch (NoSuchMethodError noSuchMethodError) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void configureCallbacks(FluentConfiguration configuration, List<Callback> callbacks) {
/* 323 */       if (!callbacks.isEmpty()) {
/* 324 */         configuration.callbacks(callbacks.<Callback>toArray(new Callback[0]));
/*     */       }
/*     */     }
/*     */     
/*     */     private void configureJavaMigrations(FluentConfiguration flyway, List<JavaMigration> migrations) {
/* 329 */       if (!migrations.isEmpty()) {
/* 330 */         flyway.javaMigrations(migrations.<JavaMigration>toArray(new JavaMigration[0]));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     public FlywayMigrationInitializer flywayInitializer(Flyway flyway, ObjectProvider<FlywayMigrationStrategy> migrationStrategy) {
/* 338 */       return new FlywayMigrationInitializer(flyway, (FlywayMigrationStrategy)migrationStrategy.getIfAvailable());
/*     */     }
/*     */     
/*     */     @ConditionalOnClass(name = {"org.flywaydb.database.sqlserver.SQLServerConfigurationExtension"})
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     static class SqlServerConfiguration
/*     */     {
/*     */       @Bean
/*     */       FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer sqlServerFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 347 */         return new FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer(properties);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     @ConditionalOnClass(name = {"org.flywaydb.database.oracle.OracleConfigurationExtension"})
/*     */     static class OracleConfiguration
/*     */     {
/*     */       @Bean
/*     */       FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer oracleFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 358 */         return new FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer(properties);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @ConditionalOnClass(name = {"org.flywaydb.database.postgresql.PostgreSQLConfigurationExtension"})
/*     */     @Configuration(proxyBeanMethods = false)
/*     */     static class PostgresqlConfiguration
/*     */     {
/*     */       @Bean
/*     */       FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer postgresqlFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 370 */         return new FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer(properties); } } } @ConditionalOnClass(name = {"org.flywaydb.database.sqlserver.SQLServerConfigurationExtension"}) @Configuration(proxyBeanMethods = false) static class SqlServerConfiguration { @Bean FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer sqlServerFlywayConfigurationCustomizer(FlywayProperties properties) { return new FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer(properties); } } @Configuration(proxyBeanMethods = false) @ConditionalOnClass(name = {"org.flywaydb.database.oracle.OracleConfigurationExtension"}) static class OracleConfiguration { @Bean FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer oracleFlywayConfigurationCustomizer(FlywayProperties properties) { return new FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer(properties); } } @ConditionalOnClass(name = {"org.flywaydb.database.postgresql.PostgreSQLConfigurationExtension"}) @Configuration(proxyBeanMethods = false) static class PostgresqlConfiguration { @Bean FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer postgresqlFlywayConfigurationCustomizer(FlywayProperties properties) { return new FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer(properties); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LocationResolver
/*     */   {
/*     */     private static final String VENDOR_PLACEHOLDER = "{vendor}";
/*     */     
/*     */     private final DataSource dataSource;
/*     */ 
/*     */     
/*     */     LocationResolver(DataSource dataSource) {
/* 384 */       this.dataSource = dataSource;
/*     */     }
/*     */     
/*     */     List<String> resolveLocations(List<String> locations) {
/* 388 */       if (usesVendorLocation(locations)) {
/* 389 */         DatabaseDriver databaseDriver = getDatabaseDriver();
/* 390 */         return replaceVendorLocations(locations, databaseDriver);
/*     */       } 
/* 392 */       return locations;
/*     */     }
/*     */     
/*     */     private List<String> replaceVendorLocations(List<String> locations, DatabaseDriver databaseDriver) {
/* 396 */       if (databaseDriver == DatabaseDriver.UNKNOWN) {
/* 397 */         return locations;
/*     */       }
/* 399 */       String vendor = databaseDriver.getId();
/* 400 */       return locations.stream().map(location -> location.replace("{vendor}", vendor)).toList();
/*     */     }
/*     */     
/*     */     private DatabaseDriver getDatabaseDriver() {
/*     */       try {
/* 405 */         String url = (String)JdbcUtils.extractDatabaseMetaData(this.dataSource, DatabaseMetaData::getURL);
/* 406 */         return DatabaseDriver.fromJdbcUrl(url);
/*     */       }
/* 408 */       catch (MetaDataAccessException ex) {
/* 409 */         throw new IllegalStateException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean usesVendorLocation(Collection<String> locations) {
/* 415 */       for (String location : locations) {
/* 416 */         if (location.contains("{vendor}")) {
/* 417 */           return true;
/*     */         }
/*     */       } 
/* 420 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class StringOrNumberToMigrationVersionConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private static final Set<GenericConverter.ConvertiblePair> CONVERTIBLE_TYPES;
/*     */ 
/*     */     
/*     */     static {
/* 433 */       Set<GenericConverter.ConvertiblePair> types = new HashSet<>(2);
/* 434 */       types.add(new GenericConverter.ConvertiblePair(String.class, MigrationVersion.class));
/* 435 */       types.add(new GenericConverter.ConvertiblePair(Number.class, MigrationVersion.class));
/* 436 */       CONVERTIBLE_TYPES = Collections.unmodifiableSet(types);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 441 */       return CONVERTIBLE_TYPES;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 446 */       String value = ObjectUtils.nullSafeToString(source);
/* 447 */       return MigrationVersion.fromVersion(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class FlywayDataSourceCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     FlywayDataSourceCondition() {
/* 455 */       super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*     */     }
/*     */     
/*     */     @ConditionalOnBean({DataSource.class})
/*     */     private static final class DataSourceBeanCondition {}
/*     */     
/*     */     @ConditionalOnBean({JdbcConnectionDetails.class})
/*     */     private static final class JdbcConnectionDetailsCondition {}
/*     */     
/*     */     @ConditionalOnProperty({"spring.flyway.url"})
/*     */     private static final class FlywayUrlCondition {}
/*     */   }
/*     */   
/*     */   @ConditionalOnBean({DataSource.class})
/*     */   private static final class DataSourceBeanCondition {}
/*     */   
/*     */   @ConditionalOnBean({JdbcConnectionDetails.class})
/*     */   private static final class JdbcConnectionDetailsCondition {}
/*     */   
/*     */   @ConditionalOnProperty({"spring.flyway.url"})
/*     */   private static final class FlywayUrlCondition {}
/*     */   
/*     */   static class FlywayAutoConfigurationRuntimeHints implements RuntimeHintsRegistrar {
/*     */     public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 479 */       hints.resources().registerPattern("db/migration/*");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PropertiesFlywayConnectionDetails
/*     */     implements FlywayConnectionDetails
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */ 
/*     */     
/*     */     PropertiesFlywayConnectionDetails(FlywayProperties properties) {
/* 492 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getUsername() {
/* 497 */       return this.properties.getUser();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPassword() {
/* 502 */       return this.properties.getPassword();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getJdbcUrl() {
/* 507 */       return this.properties.getUrl();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDriverClassName() {
/* 512 */       return this.properties.getDriverClassName();
/*     */     }
/*     */   }
/*     */   
/*     */   @Order(-2147483648)
/*     */   static final class OracleFlywayConfigurationCustomizer
/*     */     implements FlywayConfigurationCustomizer
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */     
/*     */     OracleFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 523 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(FluentConfiguration configuration) {
/* 528 */       FlywayAutoConfiguration.Extension<OracleConfigurationExtension> extension = new FlywayAutoConfiguration.Extension<>(configuration, OracleConfigurationExtension.class, "Oracle");
/*     */       
/* 530 */       FlywayProperties.Oracle properties = this.properties.getOracle();
/* 531 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 532 */       Objects.requireNonNull(properties); map.from(properties::getSqlplus).to(extension.via((ext, sqlplus) -> ext.setSqlplus(sqlplus)));
/* 533 */       Objects.requireNonNull(properties); map.from(properties::getSqlplusWarn)
/* 534 */         .to(extension.via((ext, sqlplusWarn) -> ext.setSqlplusWarn(sqlplusWarn)));
/* 535 */       Objects.requireNonNull(properties); map.from(properties::getWalletLocation)
/* 536 */         .to(extension.via((ext, walletLocation) -> ext.setWalletLocation(walletLocation)));
/* 537 */       Objects.requireNonNull(properties); map.from(properties::getKerberosCacheFile)
/* 538 */         .to(extension.via((ext, kerberosCacheFile) -> ext.setKerberosCacheFile(kerberosCacheFile)));
/*     */     }
/*     */   }
/*     */   
/*     */   @Order(-2147483648)
/*     */   static final class PostgresqlFlywayConfigurationCustomizer
/*     */     implements FlywayConfigurationCustomizer
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */     
/*     */     PostgresqlFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 549 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(FluentConfiguration configuration) {
/* 554 */       FlywayAutoConfiguration.Extension<PostgreSQLConfigurationExtension> extension = new FlywayAutoConfiguration.Extension<>(configuration, PostgreSQLConfigurationExtension.class, "PostgreSQL");
/*     */       
/* 556 */       FlywayProperties.Postgresql properties = this.properties.getPostgresql();
/* 557 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 558 */       Objects.requireNonNull(properties); map.from(properties::getTransactionalLock)
/* 559 */         .to(extension.via((ext, transactionalLock) -> ext.setTransactionalLock(transactionalLock.booleanValue())));
/*     */     }
/*     */   }
/*     */   
/*     */   @Order(-2147483648)
/*     */   static final class SqlServerFlywayConfigurationCustomizer
/*     */     implements FlywayConfigurationCustomizer
/*     */   {
/*     */     private final FlywayProperties properties;
/*     */     
/*     */     SqlServerFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 570 */       this.properties = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     public void customize(FluentConfiguration configuration) {
/* 575 */       FlywayAutoConfiguration.Extension<SQLServerConfigurationExtension> extension = new FlywayAutoConfiguration.Extension<>(configuration, SQLServerConfigurationExtension.class, "SQL Server");
/*     */       
/* 577 */       FlywayProperties.Sqlserver properties = this.properties.getSqlserver();
/* 578 */       PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/* 579 */       Objects.requireNonNull(properties); map.from(properties::getKerberosLoginFile).to(extension.via(this::setKerberosLoginFile));
/*     */     }
/*     */     
/*     */     private void setKerberosLoginFile(SQLServerConfigurationExtension configuration, String file) {
/* 583 */       configuration.getKerberos().getLogin().setFile(file);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Extension<E extends ConfigurationExtension>
/*     */   {
/*     */     private SingletonSupplier<E> extension;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Extension(FluentConfiguration configuration, Class<E> type, String name) {
/* 598 */       this.extension = SingletonSupplier.of(() -> {
/*     */             ConfigurationExtension configurationExtension = (ConfigurationExtension)configuration.getPluginRegister().getPlugin(type);
/*     */             Assert.state((configurationExtension != null), ());
/*     */             return configurationExtension;
/*     */           });
/*     */     }
/*     */     
/*     */     <T> Consumer<T> via(BiConsumer<E, T> action) {
/* 606 */       return value -> action.accept((ConfigurationExtension)this.extension.get(), value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */