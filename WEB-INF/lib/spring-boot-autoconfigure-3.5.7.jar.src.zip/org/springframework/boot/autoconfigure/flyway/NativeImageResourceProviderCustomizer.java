/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.flywaydb.core.api.configuration.Configuration;
/*    */ import org.flywaydb.core.api.configuration.FluentConfiguration;
/*    */ import org.flywaydb.core.api.migration.JavaMigration;
/*    */ import org.flywaydb.core.internal.scanner.LocationScannerCache;
/*    */ import org.flywaydb.core.internal.scanner.ResourceNameCache;
/*    */ import org.flywaydb.core.internal.scanner.Scanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NativeImageResourceProviderCustomizer
/*    */   extends ResourceProviderCustomizer
/*    */ {
/*    */   public void customize(FluentConfiguration configuration) {
/* 37 */     if (configuration.getResourceProvider() == null) {
/* 38 */       Scanner<JavaMigration> scanner = new Scanner(JavaMigration.class, false, new ResourceNameCache(), new LocationScannerCache(), (Configuration)configuration);
/*    */ 
/*    */ 
/*    */       
/* 42 */       NativeImageResourceProvider resourceProvider = new NativeImageResourceProvider(scanner, configuration.getClassLoader(), Arrays.asList(configuration.getLocations()), configuration.getEncoding(), configuration.isFailOnMissingLocations());
/* 43 */       configuration.resourceProvider(resourceProvider);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\NativeImageResourceProviderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */