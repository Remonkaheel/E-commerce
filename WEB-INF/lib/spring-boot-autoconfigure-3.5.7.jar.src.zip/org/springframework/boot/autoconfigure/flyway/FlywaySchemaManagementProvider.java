/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.stream.StreamSupport;
/*    */ import javax.sql.DataSource;
/*    */ import org.flywaydb.core.Flyway;
/*    */ import org.springframework.boot.jdbc.SchemaManagement;
/*    */ import org.springframework.boot.jdbc.SchemaManagementProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FlywaySchemaManagementProvider
/*    */   implements SchemaManagementProvider
/*    */ {
/*    */   private final Iterable<Flyway> flywayInstances;
/*    */   
/*    */   FlywaySchemaManagementProvider(Iterable<Flyway> flywayInstances) {
/* 39 */     this.flywayInstances = flywayInstances;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SchemaManagement getSchemaManagement(DataSource dataSource) {
/* 46 */     Objects.requireNonNull(dataSource); return StreamSupport.stream(this.flywayInstances.spliterator(), false).map(flyway -> flyway.getConfiguration().getDataSource()).filter(dataSource::equals)
/* 47 */       .findFirst()
/* 48 */       .map(managedDataSource -> SchemaManagement.MANAGED)
/* 49 */       .orElse(SchemaManagement.UNMANAGED);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywaySchemaManagementProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */