/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import javax.sql.DataSource;
/*     */ import org.flywaydb.core.Flyway;
/*     */ import org.flywaydb.core.api.callback.Callback;
/*     */ import org.flywaydb.core.api.configuration.FluentConfiguration;
/*     */ import org.flywaydb.core.api.migration.JavaMigration;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.PropertyMapper;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @ConditionalOnClass({JdbcUtils.class})
/*     */ @ConditionalOnMissingBean({Flyway.class})
/*     */ @EnableConfigurationProperties({FlywayProperties.class})
/*     */ public class FlywayConfiguration
/*     */ {
/*     */   private final FlywayProperties properties;
/*     */   
/*     */   FlywayConfiguration(FlywayProperties properties) {
/* 134 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   ResourceProviderCustomizer resourceProviderCustomizer() {
/* 139 */     return new ResourceProviderCustomizer();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({FlywayConnectionDetails.class})
/*     */   FlywayAutoConfiguration.PropertiesFlywayConnectionDetails flywayConnectionDetails() {
/* 145 */     return new FlywayAutoConfiguration.PropertiesFlywayConnectionDetails(this.properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   Flyway flyway(FlywayConnectionDetails connectionDetails, ResourceLoader resourceLoader, ObjectProvider<DataSource> dataSource, @FlywayDataSource ObjectProvider<DataSource> flywayDataSource, ObjectProvider<FlywayConfigurationCustomizer> fluentConfigurationCustomizers, ObjectProvider<JavaMigration> javaMigrations, ObjectProvider<Callback> callbacks, ResourceProviderCustomizer resourceProviderCustomizer) {
/* 154 */     FluentConfiguration configuration = new FluentConfiguration(resourceLoader.getClassLoader());
/* 155 */     configureDataSource(configuration, (DataSource)flywayDataSource.getIfAvailable(), (DataSource)dataSource.getIfUnique(), connectionDetails);
/*     */     
/* 157 */     configureProperties(configuration, this.properties);
/* 158 */     configureCallbacks(configuration, callbacks.orderedStream().toList());
/* 159 */     configureJavaMigrations(configuration, javaMigrations.orderedStream().toList());
/* 160 */     fluentConfigurationCustomizers.orderedStream().forEach(customizer -> customizer.customize(configuration));
/* 161 */     resourceProviderCustomizer.customize(configuration);
/* 162 */     return configuration.load();
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureDataSource(FluentConfiguration configuration, DataSource flywayDataSource, DataSource dataSource, FlywayConnectionDetails connectionDetails) {
/* 167 */     DataSource migrationDataSource = getMigrationDataSource(flywayDataSource, dataSource, connectionDetails);
/* 168 */     configuration.dataSource(migrationDataSource);
/*     */   }
/*     */ 
/*     */   
/*     */   private DataSource getMigrationDataSource(DataSource flywayDataSource, DataSource dataSource, FlywayConnectionDetails connectionDetails) {
/* 173 */     if (flywayDataSource != null) {
/* 174 */       return flywayDataSource;
/*     */     }
/* 176 */     String url = connectionDetails.getJdbcUrl();
/* 177 */     if (url != null) {
/* 178 */       DataSourceBuilder<?> builder = DataSourceBuilder.create().type(SimpleDriverDataSource.class);
/* 179 */       builder.url(url);
/* 180 */       applyConnectionDetails(connectionDetails, builder);
/* 181 */       return builder.build();
/*     */     } 
/* 183 */     String user = connectionDetails.getUsername();
/* 184 */     if (user != null && dataSource != null) {
/*     */       
/* 186 */       DataSourceBuilder<?> builder = DataSourceBuilder.derivedFrom(dataSource).type(SimpleDriverDataSource.class);
/* 187 */       applyConnectionDetails(connectionDetails, builder);
/* 188 */       return builder.build();
/*     */     } 
/* 190 */     Assert.state((dataSource != null), "Flyway migration DataSource missing");
/* 191 */     return dataSource;
/*     */   }
/*     */   
/*     */   private void applyConnectionDetails(FlywayConnectionDetails connectionDetails, DataSourceBuilder<?> builder) {
/* 195 */     builder.username(connectionDetails.getUsername());
/* 196 */     builder.password(connectionDetails.getPassword());
/* 197 */     String driverClassName = connectionDetails.getDriverClassName();
/* 198 */     if (StringUtils.hasText(driverClassName)) {
/* 199 */       builder.driverClassName(driverClassName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureProperties(FluentConfiguration configuration, FlywayProperties properties) {
/* 215 */     PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
/*     */ 
/*     */     
/* 218 */     String[] locations = (new FlywayAutoConfiguration.LocationResolver(configuration.getDataSource())).resolveLocations(properties.getLocations()).<String>toArray(new String[0]);
/* 219 */     configuration.locations(locations);
/* 220 */     map.from(Boolean.valueOf(properties.isFailOnMissingLocations()))
/* 221 */       .to(failOnMissingLocations -> configuration.failOnMissingLocations(failOnMissingLocations.booleanValue()));
/* 222 */     map.from(properties.getEncoding()).to(encoding -> configuration.encoding(encoding));
/* 223 */     map.from(Integer.valueOf(properties.getConnectRetries()))
/* 224 */       .to(connectRetries -> configuration.connectRetries(connectRetries.intValue()));
/* 225 */     map.from(properties.getConnectRetriesInterval())
/* 226 */       .as(Duration::getSeconds)
/* 227 */       .as(Long::intValue)
/* 228 */       .to(connectRetriesInterval -> configuration.connectRetriesInterval(connectRetriesInterval.intValue()));
/* 229 */     map.from(Integer.valueOf(properties.getLockRetryCount()))
/* 230 */       .to(lockRetryCount -> configuration.lockRetryCount(lockRetryCount.intValue()));
/* 231 */     map.from(properties.getDefaultSchema()).to(schema -> configuration.defaultSchema(schema));
/* 232 */     map.from(properties.getSchemas())
/* 233 */       .as(StringUtils::toStringArray)
/* 234 */       .to(schemas -> configuration.schemas(schemas));
/* 235 */     map.from(Boolean.valueOf(properties.isCreateSchemas())).to(createSchemas -> configuration.createSchemas(createSchemas.booleanValue()));
/* 236 */     map.from(properties.getTable()).to(table -> configuration.table(table));
/* 237 */     map.from(properties.getTablespace()).to(tablespace -> configuration.tablespace(tablespace));
/* 238 */     map.from(properties.getBaselineDescription())
/* 239 */       .to(baselineDescription -> configuration.baselineDescription(baselineDescription));
/* 240 */     map.from(properties.getBaselineVersion())
/* 241 */       .to(baselineVersion -> configuration.baselineVersion(baselineVersion));
/* 242 */     map.from(properties.getInstalledBy()).to(installedBy -> configuration.installedBy(installedBy));
/* 243 */     map.from(properties.getPlaceholders()).to(placeholders -> configuration.placeholders(placeholders));
/* 244 */     map.from(properties.getPlaceholderPrefix())
/* 245 */       .to(placeholderPrefix -> configuration.placeholderPrefix(placeholderPrefix));
/* 246 */     map.from(properties.getPlaceholderSuffix())
/* 247 */       .to(placeholderSuffix -> configuration.placeholderSuffix(placeholderSuffix));
/* 248 */     map.from(properties.getPlaceholderSeparator())
/* 249 */       .to(placeHolderSeparator -> configuration.placeholderSeparator(placeHolderSeparator));
/* 250 */     map.from(Boolean.valueOf(properties.isPlaceholderReplacement()))
/* 251 */       .to(placeholderReplacement -> configuration.placeholderReplacement(placeholderReplacement.booleanValue()));
/* 252 */     map.from(properties.getSqlMigrationPrefix())
/* 253 */       .to(sqlMigrationPrefix -> configuration.sqlMigrationPrefix(sqlMigrationPrefix));
/* 254 */     map.from(properties.getSqlMigrationSuffixes())
/* 255 */       .as(StringUtils::toStringArray)
/* 256 */       .to(sqlMigrationSuffixes -> configuration.sqlMigrationSuffixes(sqlMigrationSuffixes));
/* 257 */     map.from(properties.getSqlMigrationSeparator())
/* 258 */       .to(sqlMigrationSeparator -> configuration.sqlMigrationSeparator(sqlMigrationSeparator));
/* 259 */     map.from(properties.getRepeatableSqlMigrationPrefix())
/* 260 */       .to(repeatableSqlMigrationPrefix -> configuration.repeatableSqlMigrationPrefix(repeatableSqlMigrationPrefix));
/*     */     
/* 262 */     map.from(properties.getTarget()).to(target -> configuration.target(target));
/* 263 */     map.from(Boolean.valueOf(properties.isBaselineOnMigrate()))
/* 264 */       .to(baselineOnMigrate -> configuration.baselineOnMigrate(baselineOnMigrate.booleanValue()));
/* 265 */     map.from(Boolean.valueOf(properties.isCleanDisabled())).to(cleanDisabled -> configuration.cleanDisabled(cleanDisabled.booleanValue()));
/* 266 */     map.from(Boolean.valueOf(properties.isCleanOnValidationError()))
/* 267 */       .to(cleanOnValidationError -> configuration.cleanOnValidationError(cleanOnValidationError.booleanValue()));
/* 268 */     map.from(Boolean.valueOf(properties.isGroup())).to(group -> configuration.group(group.booleanValue()));
/* 269 */     map.from(Boolean.valueOf(properties.isMixed())).to(mixed -> configuration.mixed(mixed.booleanValue()));
/* 270 */     map.from(Boolean.valueOf(properties.isOutOfOrder())).to(outOfOrder -> configuration.outOfOrder(outOfOrder.booleanValue()));
/* 271 */     map.from(Boolean.valueOf(properties.isSkipDefaultCallbacks()))
/* 272 */       .to(skipDefaultCallbacks -> configuration.skipDefaultCallbacks(skipDefaultCallbacks.booleanValue()));
/* 273 */     map.from(Boolean.valueOf(properties.isSkipDefaultResolvers()))
/* 274 */       .to(skipDefaultResolvers -> configuration.skipDefaultResolvers(skipDefaultResolvers.booleanValue()));
/* 275 */     map.from(Boolean.valueOf(properties.isValidateMigrationNaming()))
/* 276 */       .to(validateMigrationNaming -> configuration.validateMigrationNaming(validateMigrationNaming.booleanValue()));
/* 277 */     map.from(Boolean.valueOf(properties.isValidateOnMigrate()))
/* 278 */       .to(validateOnMigrate -> configuration.validateOnMigrate(validateOnMigrate.booleanValue()));
/* 279 */     map.from(properties.getInitSqls())
/* 280 */       .whenNot(CollectionUtils::isEmpty)
/* 281 */       .as(initSqls -> StringUtils.collectionToDelimitedString(initSqls, "\n"))
/* 282 */       .to(initSql -> configuration.initSql(initSql));
/* 283 */     map.from(properties.getScriptPlaceholderPrefix())
/* 284 */       .to(prefix -> configuration.scriptPlaceholderPrefix(prefix));
/* 285 */     map.from(properties.getScriptPlaceholderSuffix())
/* 286 */       .to(suffix -> configuration.scriptPlaceholderSuffix(suffix));
/* 287 */     configureExecuteInTransaction(configuration, properties, map);
/* 288 */     Objects.requireNonNull(properties); map.from(properties::getLoggers).to(loggers -> configuration.loggers(loggers));
/* 289 */     Objects.requireNonNull(properties); map.from(properties::getCommunityDbSupportEnabled)
/* 290 */       .to(communityDbSupportEnabled -> configuration.communityDBSupportEnabled(communityDbSupportEnabled.booleanValue()));
/* 291 */     map.from(properties.getBatch()).to(batch -> configuration.batch(batch.booleanValue()));
/* 292 */     map.from(properties.getDryRunOutput()).to(dryRunOutput -> configuration.dryRunOutput(dryRunOutput));
/* 293 */     map.from(properties.getErrorOverrides())
/* 294 */       .to(errorOverrides -> configuration.errorOverrides(errorOverrides));
/* 295 */     map.from(properties.getStream()).to(stream -> configuration.stream(stream.booleanValue()));
/* 296 */     map.from(properties.getJdbcProperties())
/* 297 */       .whenNot(Map::isEmpty)
/* 298 */       .to(jdbcProperties -> configuration.jdbcProperties(jdbcProperties));
/* 299 */     map.from(properties.getKerberosConfigFile())
/* 300 */       .to(configFile -> configuration.kerberosConfigFile(configFile));
/* 301 */     map.from(properties.getOutputQueryResults())
/* 302 */       .to(outputQueryResults -> configuration.outputQueryResults(outputQueryResults.booleanValue()));
/* 303 */     map.from(properties.getSkipExecutingMigrations())
/* 304 */       .to(skipExecutingMigrations -> configuration.skipExecutingMigrations(skipExecutingMigrations.booleanValue()));
/* 305 */     map.from(properties.getIgnoreMigrationPatterns())
/* 306 */       .to(ignoreMigrationPatterns -> configuration.ignoreMigrationPatterns((String[])ignoreMigrationPatterns.toArray((Object[])new String[0])));
/*     */     
/* 308 */     map.from(properties.getDetectEncoding())
/* 309 */       .to(detectEncoding -> configuration.detectEncoding(detectEncoding.booleanValue()));
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureExecuteInTransaction(FluentConfiguration configuration, FlywayProperties properties, PropertyMapper map) {
/*     */     try {
/* 315 */       Objects.requireNonNull(configuration); map.from(Boolean.valueOf(properties.isExecuteInTransaction())).to(configuration::executeInTransaction);
/*     */     }
/* 317 */     catch (NoSuchMethodError noSuchMethodError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureCallbacks(FluentConfiguration configuration, List<Callback> callbacks) {
/* 323 */     if (!callbacks.isEmpty()) {
/* 324 */       configuration.callbacks(callbacks.<Callback>toArray(new Callback[0]));
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureJavaMigrations(FluentConfiguration flyway, List<JavaMigration> migrations) {
/* 329 */     if (!migrations.isEmpty()) {
/* 330 */       flyway.javaMigrations(migrations.<JavaMigration>toArray(new JavaMigration[0]));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public FlywayMigrationInitializer flywayInitializer(Flyway flyway, ObjectProvider<FlywayMigrationStrategy> migrationStrategy) {
/* 338 */     return new FlywayMigrationInitializer(flyway, (FlywayMigrationStrategy)migrationStrategy.getIfAvailable());
/*     */   }
/*     */   
/*     */   @ConditionalOnClass(name = {"org.flywaydb.database.sqlserver.SQLServerConfigurationExtension"})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class SqlServerConfiguration
/*     */   {
/*     */     @Bean
/*     */     FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer sqlServerFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 347 */       return new FlywayAutoConfiguration.SqlServerFlywayConfigurationCustomizer(properties);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   @ConditionalOnClass(name = {"org.flywaydb.database.oracle.OracleConfigurationExtension"})
/*     */   static class OracleConfiguration
/*     */   {
/*     */     @Bean
/*     */     FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer oracleFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 358 */       return new FlywayAutoConfiguration.OracleFlywayConfigurationCustomizer(properties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @ConditionalOnClass(name = {"org.flywaydb.database.postgresql.PostgreSQLConfigurationExtension"})
/*     */   @Configuration(proxyBeanMethods = false)
/*     */   static class PostgresqlConfiguration
/*     */   {
/*     */     @Bean
/*     */     FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer postgresqlFlywayConfigurationCustomizer(FlywayProperties properties) {
/* 370 */       return new FlywayAutoConfiguration.PostgresqlFlywayConfigurationCustomizer(properties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayAutoConfiguration$FlywayConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */