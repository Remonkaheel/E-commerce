/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.flyway")
/*     */ public class FlywayProperties
/*     */ {
/*     */   private boolean enabled = true;
/*     */   private boolean failOnMissingLocations;
/*  60 */   private List<String> locations = new ArrayList<>(Collections.singletonList("classpath:db/migration"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private Charset encoding = StandardCharsets.UTF_8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int connectRetries;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*  77 */   private Duration connectRetriesInterval = Duration.ofSeconds(120L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private int lockRetryCount = 50;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String defaultSchema;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private List<String> schemas = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean createSchemas = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private String table = "flyway_schema_history";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String tablespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private String baselineDescription = "<< Flyway Baseline >>";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private String baselineVersion = "1";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String installedBy;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private Map<String, String> placeholders = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   private String placeholderPrefix = "${";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private String placeholderSuffix = "}";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private String placeholderSeparator = ":";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean placeholderReplacement = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   private String sqlMigrationPrefix = "V";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   private List<String> sqlMigrationSuffixes = new ArrayList<>(Collections.singleton(".sql"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   private String sqlMigrationSeparator = "__";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   private String repeatableSqlMigrationPrefix = "R";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   private String target = "latest";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String user;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String driverClassName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   private List<String> initSqls = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean baselineOnMigrate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cleanDisabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cleanOnValidationError;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean group;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mixed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean outOfOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean skipDefaultCallbacks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean skipDefaultResolvers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateMigrationNaming = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateOnMigrate = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   private String scriptPlaceholderPrefix = "FP__";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   private String scriptPlaceholderSuffix = "__";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean executeInTransaction = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 275 */   private String[] loggers = new String[] { "slf4j" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean batch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File dryRunOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] errorOverrides;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean stream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   private Map<String, String> jdbcProperties = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String kerberosConfigFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean outputQueryResults;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean skipExecutingMigrations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 324 */   private List<String> ignoreMigrationPatterns = Collections.singletonList("*:future");
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean detectEncoding;
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean communityDbSupportEnabled;
/*     */ 
/*     */ 
/*     */   
/* 336 */   private final Oracle oracle = new Oracle();
/*     */   
/* 338 */   private final Postgresql postgresql = new Postgresql();
/*     */   
/* 340 */   private final Sqlserver sqlserver = new Sqlserver();
/*     */   
/*     */   public boolean isEnabled() {
/* 343 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 347 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isFailOnMissingLocations() {
/* 351 */     return this.failOnMissingLocations;
/*     */   }
/*     */   
/*     */   public void setFailOnMissingLocations(boolean failOnMissingLocations) {
/* 355 */     this.failOnMissingLocations = failOnMissingLocations;
/*     */   }
/*     */   
/*     */   public List<String> getLocations() {
/* 359 */     return this.locations;
/*     */   }
/*     */   
/*     */   public void setLocations(List<String> locations) {
/* 363 */     this.locations = locations;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 367 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 371 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public int getConnectRetries() {
/* 375 */     return this.connectRetries;
/*     */   }
/*     */   
/*     */   public void setConnectRetries(int connectRetries) {
/* 379 */     this.connectRetries = connectRetries;
/*     */   }
/*     */   
/*     */   public Duration getConnectRetriesInterval() {
/* 383 */     return this.connectRetriesInterval;
/*     */   }
/*     */   
/*     */   public void setConnectRetriesInterval(Duration connectRetriesInterval) {
/* 387 */     this.connectRetriesInterval = connectRetriesInterval;
/*     */   }
/*     */   
/*     */   public int getLockRetryCount() {
/* 391 */     return this.lockRetryCount;
/*     */   }
/*     */   
/*     */   public void setLockRetryCount(Integer lockRetryCount) {
/* 395 */     this.lockRetryCount = lockRetryCount.intValue();
/*     */   }
/*     */   
/*     */   public String getDefaultSchema() {
/* 399 */     return this.defaultSchema;
/*     */   }
/*     */   
/*     */   public void setDefaultSchema(String defaultSchema) {
/* 403 */     this.defaultSchema = defaultSchema;
/*     */   }
/*     */   
/*     */   public List<String> getSchemas() {
/* 407 */     return this.schemas;
/*     */   }
/*     */   
/*     */   public void setSchemas(List<String> schemas) {
/* 411 */     this.schemas = schemas;
/*     */   }
/*     */   
/*     */   public boolean isCreateSchemas() {
/* 415 */     return this.createSchemas;
/*     */   }
/*     */   
/*     */   public void setCreateSchemas(boolean createSchemas) {
/* 419 */     this.createSchemas = createSchemas;
/*     */   }
/*     */   
/*     */   public String getTable() {
/* 423 */     return this.table;
/*     */   }
/*     */   
/*     */   public void setTable(String table) {
/* 427 */     this.table = table;
/*     */   }
/*     */   
/*     */   public String getTablespace() {
/* 431 */     return this.tablespace;
/*     */   }
/*     */   
/*     */   public void setTablespace(String tablespace) {
/* 435 */     this.tablespace = tablespace;
/*     */   }
/*     */   
/*     */   public String getBaselineDescription() {
/* 439 */     return this.baselineDescription;
/*     */   }
/*     */   
/*     */   public void setBaselineDescription(String baselineDescription) {
/* 443 */     this.baselineDescription = baselineDescription;
/*     */   }
/*     */   
/*     */   public String getBaselineVersion() {
/* 447 */     return this.baselineVersion;
/*     */   }
/*     */   
/*     */   public void setBaselineVersion(String baselineVersion) {
/* 451 */     this.baselineVersion = baselineVersion;
/*     */   }
/*     */   
/*     */   public String getInstalledBy() {
/* 455 */     return this.installedBy;
/*     */   }
/*     */   
/*     */   public void setInstalledBy(String installedBy) {
/* 459 */     this.installedBy = installedBy;
/*     */   }
/*     */   
/*     */   public Map<String, String> getPlaceholders() {
/* 463 */     return this.placeholders;
/*     */   }
/*     */   
/*     */   public void setPlaceholders(Map<String, String> placeholders) {
/* 467 */     this.placeholders = placeholders;
/*     */   }
/*     */   
/*     */   public String getPlaceholderPrefix() {
/* 471 */     return this.placeholderPrefix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderPrefix(String placeholderPrefix) {
/* 475 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */   
/*     */   public String getPlaceholderSuffix() {
/* 479 */     return this.placeholderSuffix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderSuffix(String placeholderSuffix) {
/* 483 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */   
/*     */   public String getPlaceholderSeparator() {
/* 487 */     return this.placeholderSeparator;
/*     */   }
/*     */   
/*     */   public void setPlaceholderSeparator(String placeholderSeparator) {
/* 491 */     this.placeholderSeparator = placeholderSeparator;
/*     */   }
/*     */   
/*     */   public boolean isPlaceholderReplacement() {
/* 495 */     return this.placeholderReplacement;
/*     */   }
/*     */   
/*     */   public void setPlaceholderReplacement(boolean placeholderReplacement) {
/* 499 */     this.placeholderReplacement = placeholderReplacement;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationPrefix() {
/* 503 */     return this.sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationPrefix(String sqlMigrationPrefix) {
/* 507 */     this.sqlMigrationPrefix = sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public List<String> getSqlMigrationSuffixes() {
/* 511 */     return this.sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSuffixes(List<String> sqlMigrationSuffixes) {
/* 515 */     this.sqlMigrationSuffixes = sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationSeparator() {
/* 519 */     return this.sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSeparator(String sqlMigrationSeparator) {
/* 523 */     this.sqlMigrationSeparator = sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public String getRepeatableSqlMigrationPrefix() {
/* 527 */     return this.repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setRepeatableSqlMigrationPrefix(String repeatableSqlMigrationPrefix) {
/* 531 */     this.repeatableSqlMigrationPrefix = repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public String getTarget() {
/* 535 */     return this.target;
/*     */   }
/*     */   
/*     */   public void setTarget(String target) {
/* 539 */     this.target = target;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 543 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 547 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 551 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 555 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getDriverClassName() {
/* 559 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 563 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 567 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 571 */     this.url = url;
/*     */   }
/*     */   
/*     */   public List<String> getInitSqls() {
/* 575 */     return this.initSqls;
/*     */   }
/*     */   
/*     */   public void setInitSqls(List<String> initSqls) {
/* 579 */     this.initSqls = initSqls;
/*     */   }
/*     */   
/*     */   public boolean isBaselineOnMigrate() {
/* 583 */     return this.baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public void setBaselineOnMigrate(boolean baselineOnMigrate) {
/* 587 */     this.baselineOnMigrate = baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public boolean isCleanDisabled() {
/* 591 */     return this.cleanDisabled;
/*     */   }
/*     */   
/*     */   public void setCleanDisabled(boolean cleanDisabled) {
/* 595 */     this.cleanDisabled = cleanDisabled;
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   @DeprecatedConfigurationProperty(since = "3.4.0", reason = "Deprecated in Flyway 10.18 and removed in Flyway 11.0")
/*     */   public boolean isCleanOnValidationError() {
/* 601 */     return this.cleanOnValidationError;
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.4.0", forRemoval = true)
/*     */   public void setCleanOnValidationError(boolean cleanOnValidationError) {
/* 606 */     this.cleanOnValidationError = cleanOnValidationError;
/*     */   }
/*     */   
/*     */   public boolean isGroup() {
/* 610 */     return this.group;
/*     */   }
/*     */   
/*     */   public void setGroup(boolean group) {
/* 614 */     this.group = group;
/*     */   }
/*     */   
/*     */   public boolean isMixed() {
/* 618 */     return this.mixed;
/*     */   }
/*     */   
/*     */   public void setMixed(boolean mixed) {
/* 622 */     this.mixed = mixed;
/*     */   }
/*     */   
/*     */   public boolean isOutOfOrder() {
/* 626 */     return this.outOfOrder;
/*     */   }
/*     */   
/*     */   public void setOutOfOrder(boolean outOfOrder) {
/* 630 */     this.outOfOrder = outOfOrder;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultCallbacks() {
/* 634 */     return this.skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultCallbacks(boolean skipDefaultCallbacks) {
/* 638 */     this.skipDefaultCallbacks = skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultResolvers() {
/* 642 */     return this.skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultResolvers(boolean skipDefaultResolvers) {
/* 646 */     this.skipDefaultResolvers = skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public boolean isValidateMigrationNaming() {
/* 650 */     return this.validateMigrationNaming;
/*     */   }
/*     */   
/*     */   public void setValidateMigrationNaming(boolean validateMigrationNaming) {
/* 654 */     this.validateMigrationNaming = validateMigrationNaming;
/*     */   }
/*     */   
/*     */   public boolean isValidateOnMigrate() {
/* 658 */     return this.validateOnMigrate;
/*     */   }
/*     */   
/*     */   public void setValidateOnMigrate(boolean validateOnMigrate) {
/* 662 */     this.validateOnMigrate = validateOnMigrate;
/*     */   }
/*     */   
/*     */   public String getScriptPlaceholderPrefix() {
/* 666 */     return this.scriptPlaceholderPrefix;
/*     */   }
/*     */   
/*     */   public void setScriptPlaceholderPrefix(String scriptPlaceholderPrefix) {
/* 670 */     this.scriptPlaceholderPrefix = scriptPlaceholderPrefix;
/*     */   }
/*     */   
/*     */   public String getScriptPlaceholderSuffix() {
/* 674 */     return this.scriptPlaceholderSuffix;
/*     */   }
/*     */   
/*     */   public void setScriptPlaceholderSuffix(String scriptPlaceholderSuffix) {
/* 678 */     this.scriptPlaceholderSuffix = scriptPlaceholderSuffix;
/*     */   }
/*     */   
/*     */   public boolean isExecuteInTransaction() {
/* 682 */     return this.executeInTransaction;
/*     */   }
/*     */   
/*     */   public void setExecuteInTransaction(boolean executeInTransaction) {
/* 686 */     this.executeInTransaction = executeInTransaction;
/*     */   }
/*     */   
/*     */   public String[] getLoggers() {
/* 690 */     return this.loggers;
/*     */   }
/*     */   
/*     */   public void setLoggers(String[] loggers) {
/* 694 */     this.loggers = loggers;
/*     */   }
/*     */   
/*     */   public Boolean getBatch() {
/* 698 */     return this.batch;
/*     */   }
/*     */   
/*     */   public void setBatch(Boolean batch) {
/* 702 */     this.batch = batch;
/*     */   }
/*     */   
/*     */   public File getDryRunOutput() {
/* 706 */     return this.dryRunOutput;
/*     */   }
/*     */   
/*     */   public void setDryRunOutput(File dryRunOutput) {
/* 710 */     this.dryRunOutput = dryRunOutput;
/*     */   }
/*     */   
/*     */   public String[] getErrorOverrides() {
/* 714 */     return this.errorOverrides;
/*     */   }
/*     */   
/*     */   public void setErrorOverrides(String[] errorOverrides) {
/* 718 */     this.errorOverrides = errorOverrides;
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.flyway.oracle.sqlplus", since = "3.2.0")
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public Boolean getOracleSqlplus() {
/* 724 */     return getOracle().getSqlplus();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public void setOracleSqlplus(Boolean oracleSqlplus) {
/* 729 */     getOracle().setSqlplus(oracleSqlplus);
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.flyway.oracle.sqlplus-warn", since = "3.2.0")
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public Boolean getOracleSqlplusWarn() {
/* 735 */     return getOracle().getSqlplusWarn();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public void setOracleSqlplusWarn(Boolean oracleSqlplusWarn) {
/* 740 */     getOracle().setSqlplusWarn(oracleSqlplusWarn);
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.flyway.oracle.wallet-location", since = "3.2.0")
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public String getOracleWalletLocation() {
/* 746 */     return getOracle().getWalletLocation();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public void setOracleWalletLocation(String oracleWalletLocation) {
/* 751 */     getOracle().setWalletLocation(oracleWalletLocation);
/*     */   }
/*     */   
/*     */   public Boolean getStream() {
/* 755 */     return this.stream;
/*     */   }
/*     */   
/*     */   public void setStream(Boolean stream) {
/* 759 */     this.stream = stream;
/*     */   }
/*     */   
/*     */   public Map<String, String> getJdbcProperties() {
/* 763 */     return this.jdbcProperties;
/*     */   }
/*     */   
/*     */   public void setJdbcProperties(Map<String, String> jdbcProperties) {
/* 767 */     this.jdbcProperties = jdbcProperties;
/*     */   }
/*     */   
/*     */   public String getKerberosConfigFile() {
/* 771 */     return this.kerberosConfigFile;
/*     */   }
/*     */   
/*     */   public void setKerberosConfigFile(String kerberosConfigFile) {
/* 775 */     this.kerberosConfigFile = kerberosConfigFile;
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.flyway.oracle.kerberos-cache-file", since = "3.2.0")
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public String getOracleKerberosCacheFile() {
/* 781 */     return getOracle().getKerberosCacheFile();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public void setOracleKerberosCacheFile(String oracleKerberosCacheFile) {
/* 786 */     getOracle().setKerberosCacheFile(oracleKerberosCacheFile);
/*     */   }
/*     */   
/*     */   public Boolean getOutputQueryResults() {
/* 790 */     return this.outputQueryResults;
/*     */   }
/*     */   
/*     */   public void setOutputQueryResults(Boolean outputQueryResults) {
/* 794 */     this.outputQueryResults = outputQueryResults;
/*     */   }
/*     */   
/*     */   @DeprecatedConfigurationProperty(replacement = "spring.flyway.sqlserver.kerberos-login-file")
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public String getSqlServerKerberosLoginFile() {
/* 800 */     return getSqlserver().getKerberosLoginFile();
/*     */   }
/*     */   
/*     */   @Deprecated(since = "3.2.0", forRemoval = true)
/*     */   public void setSqlServerKerberosLoginFile(String sqlServerKerberosLoginFile) {
/* 805 */     getSqlserver().setKerberosLoginFile(sqlServerKerberosLoginFile);
/*     */   }
/*     */   
/*     */   public Boolean getSkipExecutingMigrations() {
/* 809 */     return this.skipExecutingMigrations;
/*     */   }
/*     */   
/*     */   public void setSkipExecutingMigrations(Boolean skipExecutingMigrations) {
/* 813 */     this.skipExecutingMigrations = skipExecutingMigrations;
/*     */   }
/*     */   
/*     */   public List<String> getIgnoreMigrationPatterns() {
/* 817 */     return this.ignoreMigrationPatterns;
/*     */   }
/*     */   
/*     */   public void setIgnoreMigrationPatterns(List<String> ignoreMigrationPatterns) {
/* 821 */     this.ignoreMigrationPatterns = ignoreMigrationPatterns;
/*     */   }
/*     */   
/*     */   public Boolean getDetectEncoding() {
/* 825 */     return this.detectEncoding;
/*     */   }
/*     */   
/*     */   public void setDetectEncoding(Boolean detectEncoding) {
/* 829 */     this.detectEncoding = detectEncoding;
/*     */   }
/*     */   
/*     */   public Boolean getCommunityDbSupportEnabled() {
/* 833 */     return this.communityDbSupportEnabled;
/*     */   }
/*     */   
/*     */   public void setCommunityDbSupportEnabled(Boolean communityDbSupportEnabled) {
/* 837 */     this.communityDbSupportEnabled = communityDbSupportEnabled;
/*     */   }
/*     */   
/*     */   public Oracle getOracle() {
/* 841 */     return this.oracle;
/*     */   }
/*     */   
/*     */   public Postgresql getPostgresql() {
/* 845 */     return this.postgresql;
/*     */   }
/*     */   
/*     */   public Sqlserver getSqlserver() {
/* 849 */     return this.sqlserver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Oracle
/*     */   {
/*     */     private Boolean sqlplus;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean sqlplusWarn;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String kerberosCacheFile;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String walletLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getSqlplus() {
/* 880 */       return this.sqlplus;
/*     */     }
/*     */     
/*     */     public void setSqlplus(Boolean sqlplus) {
/* 884 */       this.sqlplus = sqlplus;
/*     */     }
/*     */     
/*     */     public Boolean getSqlplusWarn() {
/* 888 */       return this.sqlplusWarn;
/*     */     }
/*     */     
/*     */     public void setSqlplusWarn(Boolean sqlplusWarn) {
/* 892 */       this.sqlplusWarn = sqlplusWarn;
/*     */     }
/*     */     
/*     */     public String getKerberosCacheFile() {
/* 896 */       return this.kerberosCacheFile;
/*     */     }
/*     */     
/*     */     public void setKerberosCacheFile(String kerberosCacheFile) {
/* 900 */       this.kerberosCacheFile = kerberosCacheFile;
/*     */     }
/*     */     
/*     */     public String getWalletLocation() {
/* 904 */       return this.walletLocation;
/*     */     }
/*     */     
/*     */     public void setWalletLocation(String walletLocation) {
/* 908 */       this.walletLocation = walletLocation;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Postgresql
/*     */   {
/*     */     private Boolean transactionalLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getTransactionalLock() {
/* 925 */       return this.transactionalLock;
/*     */     }
/*     */     
/*     */     public void setTransactionalLock(Boolean transactionalLock) {
/* 929 */       this.transactionalLock = transactionalLock;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Sqlserver
/*     */   {
/*     */     private String kerberosLoginFile;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKerberosLoginFile() {
/* 945 */       return this.kerberosLoginFile;
/*     */     }
/*     */     
/*     */     public void setKerberosLoginFile(String kerberosLoginFile) {
/* 949 */       this.kerberosLoginFile = kerberosLoginFile;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */