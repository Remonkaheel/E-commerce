package org.springframework.boot.autoconfigure.flyway;

import org.flywaydb.core.Flyway;

@FunctionalInterface
public interface FlywayMigrationStrategy {
  void migrate(Flyway paramFlyway);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */