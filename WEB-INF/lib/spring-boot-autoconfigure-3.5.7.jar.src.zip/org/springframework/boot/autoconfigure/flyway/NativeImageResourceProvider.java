/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Predicate;
/*     */ import org.flywaydb.core.api.FlywayException;
/*     */ import org.flywaydb.core.api.Location;
/*     */ import org.flywaydb.core.api.ResourceProvider;
/*     */ import org.flywaydb.core.api.resource.LoadableResource;
/*     */ import org.flywaydb.core.internal.resource.classpath.ClassPathResource;
/*     */ import org.flywaydb.core.internal.scanner.Scanner;
/*     */ import org.flywaydb.core.internal.util.StringUtils;
/*     */ import org.springframework.core.NativeDetector;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NativeImageResourceProvider
/*     */   implements ResourceProvider
/*     */ {
/*     */   private final Scanner<?> scanner;
/*     */   private final ClassLoader classLoader;
/*     */   private final Collection<Location> locations;
/*     */   private final Charset encoding;
/*     */   private final boolean failOnMissingLocations;
/*  61 */   private final List<LocatedResource> locatedResources = new ArrayList<>();
/*     */   
/*  63 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */   
/*     */   NativeImageResourceProvider(Scanner<?> scanner, ClassLoader classLoader, Collection<Location> locations, Charset encoding, boolean failOnMissingLocations) {
/*  69 */     this.scanner = scanner;
/*  70 */     this.classLoader = classLoader;
/*  71 */     this.locations = locations;
/*  72 */     this.encoding = encoding;
/*  73 */     this.failOnMissingLocations = failOnMissingLocations;
/*     */   }
/*     */ 
/*     */   
/*     */   public LoadableResource getResource(String name) {
/*  78 */     if (!NativeDetector.inNativeImage()) {
/*  79 */       return this.scanner.getResource(name);
/*     */     }
/*  81 */     LoadableResource resource = this.scanner.getResource(name);
/*  82 */     if (resource != null) {
/*  83 */       return resource;
/*     */     }
/*  85 */     if (this.classLoader.getResource(name) == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     return (LoadableResource)new ClassPathResource(null, name, this.classLoader, this.encoding);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<LoadableResource> getResources(String prefix, String[] suffixes) {
/*  93 */     if (!NativeDetector.inNativeImage()) {
/*  94 */       return this.scanner.getResources(prefix, suffixes);
/*     */     }
/*  96 */     ensureInitialized();
/*  97 */     Predicate<LocatedResource> matchesPrefixAndSuffixes = locatedResource -> StringUtils.startsAndEndsWith(locatedResource.resource.getFilename(), prefix, suffixes);
/*     */     
/*  99 */     List<LoadableResource> result = new ArrayList<>(this.scanner.getResources(prefix, suffixes));
/*     */ 
/*     */ 
/*     */     
/* 103 */     Objects.requireNonNull(result); this.locatedResources.stream().filter(matchesPrefixAndSuffixes).map(this::asClassPathResource).forEach(result::add);
/* 104 */     return result;
/*     */   }
/*     */   
/*     */   private ClassPathResource asClassPathResource(LocatedResource locatedResource) {
/* 108 */     Location location = locatedResource.location();
/* 109 */     String fileNameWithAbsolutePath = location.getPath() + "/" + location.getPath();
/* 110 */     return new ClassPathResource(location, fileNameWithAbsolutePath, this.classLoader, this.encoding);
/*     */   }
/*     */   
/*     */   private void ensureInitialized() {
/* 114 */     this.lock.lock();
/*     */     try {
/* 116 */       if (!this.initialized) {
/* 117 */         initialize();
/* 118 */         this.initialized = true;
/*     */       } 
/*     */     } finally {
/*     */       
/* 122 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 127 */     PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
/* 128 */     for (Location location : this.locations) {
/* 129 */       if (!location.isClassPath()) {
/*     */         continue;
/*     */       }
/* 132 */       Resource root = resolver.getResource(location.getDescriptor());
/* 133 */       if (!root.exists()) {
/* 134 */         if (this.failOnMissingLocations) {
/* 135 */           throw new FlywayException("Location " + location.getDescriptor() + " doesn't exist");
/*     */         }
/*     */         continue;
/*     */       } 
/* 139 */       Resource[] resources = getResources(resolver, location, root);
/* 140 */       for (Resource resource : resources) {
/* 141 */         this.locatedResources.add(new LocatedResource(resource, location));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Resource[] getResources(PathMatchingResourcePatternResolver resolver, Location location, Resource root) {
/*     */     try {
/* 148 */       return resolver.getResources(String.valueOf(root.getURI()) + "/*");
/*     */     }
/* 150 */     catch (IOException ex) {
/* 151 */       throw new UncheckedIOException("Failed to list resources for " + location.getDescriptor(), ex);
/*     */     } 
/*     */   }
/*     */   private static final class LocatedResource extends Record { private final Resource resource; private final Location location;
/* 155 */     private LocatedResource(Resource resource, Location location) { this.resource = resource; this.location = location; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 155 */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource; } public Resource resource() { return this.resource; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #155	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/boot/autoconfigure/flyway/NativeImageResourceProvider$LocatedResource;
/* 155 */       //   0	8	1	o	Ljava/lang/Object; } public Location location() { return this.location; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\NativeImageResourceProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */