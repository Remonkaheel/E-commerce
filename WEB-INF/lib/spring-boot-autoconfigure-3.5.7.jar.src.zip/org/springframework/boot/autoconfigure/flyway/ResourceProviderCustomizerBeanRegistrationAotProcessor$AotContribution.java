/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import javax.lang.model.element.Modifier;
/*    */ import org.springframework.aot.generate.GeneratedMethod;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ import org.springframework.javapoet.MethodSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AotContribution
/*    */   extends BeanRegistrationCodeFragmentsDecorator
/*    */ {
/*    */   private final RegisteredBean registeredBean;
/*    */   
/*    */   protected AotContribution(BeanRegistrationCodeFragments delegate, RegisteredBean registeredBean) {
/* 53 */     super(delegate);
/* 54 */     this.registeredBean = registeredBean;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 60 */     GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("getInstance", method -> {
/*    */           method.addJavadoc("Get the bean instance for '$L'.", new Object[] { this.registeredBean.getBeanName() });
/*    */           method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*    */           method.returns(NativeImageResourceProviderCustomizer.class);
/*    */           CodeBlock.Builder code = CodeBlock.builder();
/*    */           code.addStatement("return new $T()", new Object[] { NativeImageResourceProviderCustomizer.class });
/*    */           method.addCode(code.build());
/*    */         });
/* 68 */     return generatedMethod.toMethodReference().toCodeBlock();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\ResourceProviderCustomizerBeanRegistrationAotProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */