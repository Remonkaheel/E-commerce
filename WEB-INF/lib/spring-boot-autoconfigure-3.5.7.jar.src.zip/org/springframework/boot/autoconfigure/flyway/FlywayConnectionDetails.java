/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.service.connection.ConnectionDetails;
/*    */ import org.springframework.boot.jdbc.DatabaseDriver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FlywayConnectionDetails
/*    */   extends ConnectionDetails
/*    */ {
/*    */   String getUsername();
/*    */   
/*    */   String getPassword();
/*    */   
/*    */   String getJdbcUrl();
/*    */   
/*    */   default String getDriverClassName() {
/* 60 */     String jdbcUrl = getJdbcUrl();
/* 61 */     return (jdbcUrl != null) ? DatabaseDriver.fromJdbcUrl(jdbcUrl).getDriverClassName() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\flyway\FlywayConnectionDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */