/*    */ package org.springframework.boot.autoconfigure.admin;
/*    */ 
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.admin.SpringApplicationAdminMXBeanRegistrar;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.jmx.export.MBeanExporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration(after = {JmxAutoConfiguration.class})
/*    */ @ConditionalOnBooleanProperty({"spring.application.admin.enabled"})
/*    */ public class SpringApplicationAdminJmxAutoConfiguration
/*    */ {
/*    */   private static final String JMX_NAME_PROPERTY = "spring.application.admin.jmx-name";
/*    */   private static final String DEFAULT_JMX_NAME = "org.springframework.boot:type=Admin,name=SpringApplication";
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public SpringApplicationAdminMXBeanRegistrar springApplicationAdminRegistrar(ObjectProvider<MBeanExporter> mbeanExporters, Environment environment) throws MalformedObjectNameException {
/* 60 */     String jmxName = environment.getProperty("spring.application.admin.jmx-name", "org.springframework.boot:type=Admin,name=SpringApplication");
/* 61 */     if (mbeanExporters != null) {
/* 62 */       for (MBeanExporter mbeanExporter : mbeanExporters) {
/* 63 */         mbeanExporter.addExcludedBean(jmxName);
/*    */       }
/*    */     }
/* 66 */     return new SpringApplicationAdminMXBeanRegistrar(jmxName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\admin\SpringApplicationAdminJmxAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */