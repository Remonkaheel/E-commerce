/*    */ package org.springframework.boot.autoconfigure.dao;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration
/*    */ @ConditionalOnClass({PersistenceExceptionTranslationPostProcessor.class})
/*    */ public class PersistenceExceptionTranslationAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnBooleanProperty(name = {"spring.dao.exceptiontranslation.enabled"}, matchIfMissing = true)
/*    */   public static PersistenceExceptionTranslationPostProcessor persistenceExceptionTranslationPostProcessor(Environment environment) {
/* 46 */     PersistenceExceptionTranslationPostProcessor postProcessor = new PersistenceExceptionTranslationPostProcessor();
/* 47 */     boolean proxyTargetClass = ((Boolean)environment.getProperty("spring.aop.proxy-target-class", Boolean.class, Boolean.TRUE)).booleanValue();
/*    */     
/* 49 */     postProcessor.setProxyTargetClass(proxyTargetClass);
/* 50 */     return postProcessor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\dao\PersistenceExceptionTranslationAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */