/*    */ package org.springframework.boot.autoconfigure.codec;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties("spring.codec")
/*    */ @Deprecated(since = "3.5.0", forRemoval = true)
/*    */ public class CodecProperties
/*    */ {
/*    */   private boolean logRequestDetails;
/*    */   private DataSize maxInMemorySize;
/*    */   
/*    */   @DeprecatedConfigurationProperty(since = "3.5.0", replacement = "spring.http.codecs.log-request-details")
/*    */   public boolean isLogRequestDetails() {
/* 50 */     return this.logRequestDetails;
/*    */   }
/*    */   
/*    */   public void setLogRequestDetails(boolean logRequestDetails) {
/* 54 */     this.logRequestDetails = logRequestDetails;
/*    */   }
/*    */   
/*    */   @DeprecatedConfigurationProperty(since = "3.5.0", replacement = "spring.http.codecs.max-in-memory-size")
/*    */   public DataSize getMaxInMemorySize() {
/* 59 */     return this.maxInMemorySize;
/*    */   }
/*    */   
/*    */   public void setMaxInMemorySize(DataSize maxInMemorySize) {
/* 63 */     this.maxInMemorySize = maxInMemorySize;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\codec\CodecProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */