/*    */ package org.springframework.boot.autoconfigure.aop;
/*    */ 
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @ConditionalOnMissingClass({"org.aspectj.weaver.Advice"})
/*    */ @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, matchIfMissing = true)
/*    */ class ClassProxyingConfiguration
/*    */ {
/*    */   @Bean
/*    */   static BeanFactoryPostProcessor forceAutoProxyCreatorToUseClassProxying() {
/* 77 */     return beanFactory -> {
/*    */         if (beanFactory instanceof BeanDefinitionRegistry) {
/*    */           BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*    */           AopConfigUtils.registerAutoProxyCreatorIfNecessary(registry);
/*    */           AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/*    */         } 
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\aop\AopAutoConfiguration$ClassProxyingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */