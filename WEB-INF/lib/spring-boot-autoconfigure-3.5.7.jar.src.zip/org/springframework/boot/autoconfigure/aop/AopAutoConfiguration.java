/*    */ package org.springframework.boot.autoconfigure.aop;
/*    */ 
/*    */ import org.aspectj.weaver.Advice;
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.boot.autoconfigure.AutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.EnableAspectJAutoProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AutoConfiguration
/*    */ @ConditionalOnBooleanProperty(name = {"spring.aop.auto"}, matchIfMissing = true)
/*    */ public class AopAutoConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnClass({Advice.class})
/*    */   static class AspectJAutoProxyingConfiguration
/*    */   {
/*    */     @Configuration(proxyBeanMethods = false)
/*    */     @EnableAspectJAutoProxy(proxyTargetClass = false)
/*    */     @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, havingValue = false)
/*    */     static class JdkDynamicAutoProxyConfiguration {}
/*    */     
/*    */     @Configuration(proxyBeanMethods = false)
/*    */     @EnableAspectJAutoProxy(proxyTargetClass = true)
/*    */     @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, matchIfMissing = true)
/*    */     static class CglibAutoProxyConfiguration {}
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @EnableAspectJAutoProxy(proxyTargetClass = false)
/*    */   @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, havingValue = false)
/*    */   static class JdkDynamicAutoProxyConfiguration {}
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @EnableAspectJAutoProxy(proxyTargetClass = true)
/*    */   @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, matchIfMissing = true)
/*    */   static class CglibAutoProxyConfiguration {}
/*    */   
/*    */   @Configuration(proxyBeanMethods = false)
/*    */   @ConditionalOnMissingClass({"org.aspectj.weaver.Advice"})
/*    */   @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, matchIfMissing = true)
/*    */   static class ClassProxyingConfiguration
/*    */   {
/*    */     @Bean
/*    */     static BeanFactoryPostProcessor forceAutoProxyCreatorToUseClassProxying() {
/* 77 */       return beanFactory -> {
/*    */           if (beanFactory instanceof BeanDefinitionRegistry) {
/*    */             BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*    */             AopConfigUtils.registerAutoProxyCreatorIfNecessary(registry);
/*    */             AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/*    */           } 
/*    */         };
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\aop\AopAutoConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */