package org.springframework.boot.autoconfigure.aop;

import org.aspectj.weaver.Advice;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBooleanProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass({Advice.class})
class AspectJAutoProxyingConfiguration {
  @Configuration(proxyBeanMethods = false)
  @EnableAspectJAutoProxy(proxyTargetClass = false)
  @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, havingValue = false)
  static class JdkDynamicAutoProxyConfiguration {}
  
  @Configuration(proxyBeanMethods = false)
  @EnableAspectJAutoProxy(proxyTargetClass = true)
  @ConditionalOnBooleanProperty(name = {"spring.aop.proxy-target-class"}, matchIfMissing = true)
  static class CglibAutoProxyConfiguration {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\aop\AopAutoConfiguration$AspectJAutoProxyingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */