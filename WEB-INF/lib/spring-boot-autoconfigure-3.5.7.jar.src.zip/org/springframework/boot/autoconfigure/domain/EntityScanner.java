/*     */ package org.springframework.boot.autoconfigure.domain;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityScanner
/*     */ {
/*     */   private final ApplicationContext context;
/*     */   
/*     */   public EntityScanner(ApplicationContext context) {
/*  50 */     Assert.notNull(context, "'context' must not be null");
/*  51 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final Set<Class<?>> scan(Class<? extends Annotation>... annotationTypes) throws ClassNotFoundException {
/*  62 */     List<String> packages = getPackages();
/*  63 */     if (packages.isEmpty()) {
/*  64 */       return Collections.emptySet();
/*     */     }
/*  66 */     ClassPathScanningCandidateComponentProvider scanner = createClassPathScanningCandidateComponentProvider(this.context);
/*     */     
/*  68 */     for (Class<? extends Annotation> annotationType : annotationTypes) {
/*  69 */       scanner.addIncludeFilter((TypeFilter)new AnnotationTypeFilter(annotationType));
/*     */     }
/*  71 */     Set<Class<?>> entitySet = new HashSet<>();
/*  72 */     for (String basePackage : packages) {
/*  73 */       if (StringUtils.hasText(basePackage)) {
/*  74 */         for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/*  75 */           entitySet.add(ClassUtils.forName(candidate.getBeanClassName(), this.context.getClassLoader()));
/*     */         }
/*     */       }
/*     */     } 
/*  79 */     return entitySet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassPathScanningCandidateComponentProvider createClassPathScanningCandidateComponentProvider(ApplicationContext context) {
/*  92 */     ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
/*  93 */     scanner.setEnvironment(context.getEnvironment());
/*  94 */     scanner.setResourceLoader((ResourceLoader)context);
/*  95 */     return scanner;
/*     */   }
/*     */   
/*     */   private List<String> getPackages() {
/*  99 */     List<String> packages = EntityScanPackages.get((BeanFactory)this.context).getPackageNames();
/* 100 */     if (packages.isEmpty() && AutoConfigurationPackages.has((BeanFactory)this.context)) {
/* 101 */       packages = AutoConfigurationPackages.get((BeanFactory)this.context);
/*     */     }
/* 103 */     return packages;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\domain\EntityScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */