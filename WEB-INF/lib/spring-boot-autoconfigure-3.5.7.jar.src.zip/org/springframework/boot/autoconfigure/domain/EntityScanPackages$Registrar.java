/*     */ package org.springframework.boot.autoconfigure.domain;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Registrar
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   private final Environment environment;
/*     */   
/*     */   Registrar(Environment environment) {
/* 131 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 136 */     EntityScanPackages.register(registry, getPackagesToScan(metadata));
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/* 141 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(EntityScan.class.getName()));
/* 142 */     Set<String> packagesToScan = new LinkedHashSet<>();
/* 143 */     for (String basePackage : attributes.getStringArray("basePackages")) {
/* 144 */       String[] tokenized = StringUtils.tokenizeToStringArray(this.environment
/* 145 */           .resolvePlaceholders(basePackage), ",; \t\n");
/*     */       
/* 147 */       Collections.addAll(packagesToScan, tokenized);
/*     */     } 
/* 149 */     for (Class<?> basePackageClass : attributes.getClassArray("basePackageClasses")) {
/* 150 */       packagesToScan.add(this.environment.resolvePlaceholders(ClassUtils.getPackageName(basePackageClass)));
/*     */     }
/* 152 */     if (packagesToScan.isEmpty()) {
/* 153 */       String packageName = ClassUtils.getPackageName(metadata.getClassName());
/* 154 */       Assert.state(StringUtils.hasLength(packageName), "@EntityScan cannot be used with the default package");
/* 155 */       return Collections.singleton(packageName);
/*     */     } 
/* 157 */     return packagesToScan;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\domain\EntityScanPackages$Registrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */