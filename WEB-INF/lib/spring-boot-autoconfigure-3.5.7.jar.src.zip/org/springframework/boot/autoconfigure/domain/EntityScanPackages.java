/*     */ package org.springframework.boot.autoconfigure.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityScanPackages
/*     */ {
/*  52 */   private static final String BEAN = EntityScanPackages.class.getName();
/*     */   
/*  54 */   private static final EntityScanPackages NONE = new EntityScanPackages(new String[0]);
/*     */   
/*     */   private final List<String> packageNames;
/*     */   
/*     */   EntityScanPackages(String... packageNames) {
/*  59 */     List<String> packages = new ArrayList<>();
/*  60 */     for (String name : packageNames) {
/*  61 */       if (StringUtils.hasText(name)) {
/*  62 */         packages.add(name);
/*     */       }
/*     */     } 
/*  65 */     this.packageNames = Collections.unmodifiableList(packages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getPackageNames() {
/*  74 */     return this.packageNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityScanPackages get(BeanFactory beanFactory) {
/*     */     try {
/*  86 */       return (EntityScanPackages)beanFactory.getBean(BEAN, EntityScanPackages.class);
/*     */     }
/*  88 */     catch (NoSuchBeanDefinitionException ex) {
/*  89 */       return NONE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry, String... packageNames) {
/*  99 */     Assert.notNull(registry, "'registry' must not be null");
/* 100 */     Assert.notNull(packageNames, "'packageNames' must not be null");
/* 101 */     register(registry, Arrays.asList(packageNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(BeanDefinitionRegistry registry, Collection<String> packageNames) {
/* 110 */     Assert.notNull(registry, "'registry' must not be null");
/* 111 */     Assert.notNull(packageNames, "'packageNames' must not be null");
/* 112 */     if (registry.containsBeanDefinition(BEAN)) {
/*     */       
/* 114 */       EntityScanPackagesBeanDefinition beanDefinition = (EntityScanPackagesBeanDefinition)registry.getBeanDefinition(BEAN);
/* 115 */       beanDefinition.addPackageNames(packageNames);
/*     */     } else {
/*     */       
/* 118 */       registry.registerBeanDefinition(BEAN, (BeanDefinition)new EntityScanPackagesBeanDefinition(packageNames));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Registrar
/*     */     implements ImportBeanDefinitionRegistrar
/*     */   {
/*     */     private final Environment environment;
/*     */ 
/*     */     
/*     */     Registrar(Environment environment) {
/* 131 */       this.environment = environment;
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 136 */       EntityScanPackages.register(registry, getPackagesToScan(metadata));
/*     */     }
/*     */ 
/*     */     
/*     */     private Set<String> getPackagesToScan(AnnotationMetadata metadata) {
/* 141 */       AnnotationAttributes attributes = AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(EntityScan.class.getName()));
/* 142 */       Set<String> packagesToScan = new LinkedHashSet<>();
/* 143 */       for (String basePackage : attributes.getStringArray("basePackages")) {
/* 144 */         String[] tokenized = StringUtils.tokenizeToStringArray(this.environment
/* 145 */             .resolvePlaceholders(basePackage), ",; \t\n");
/*     */         
/* 147 */         Collections.addAll(packagesToScan, tokenized);
/*     */       } 
/* 149 */       for (Class<?> basePackageClass : attributes.getClassArray("basePackageClasses")) {
/* 150 */         packagesToScan.add(this.environment.resolvePlaceholders(ClassUtils.getPackageName(basePackageClass)));
/*     */       }
/* 152 */       if (packagesToScan.isEmpty()) {
/* 153 */         String packageName = ClassUtils.getPackageName(metadata.getClassName());
/* 154 */         Assert.state(StringUtils.hasLength(packageName), "@EntityScan cannot be used with the default package");
/* 155 */         return Collections.singleton(packageName);
/*     */       } 
/* 157 */       return packagesToScan;
/*     */     }
/*     */   }
/*     */   
/*     */   static class EntityScanPackagesBeanDefinition
/*     */     extends RootBeanDefinition
/*     */   {
/* 164 */     private final Set<String> packageNames = new LinkedHashSet<>();
/*     */     
/*     */     EntityScanPackagesBeanDefinition(Collection<String> packageNames) {
/* 167 */       setBeanClass(EntityScanPackages.class);
/* 168 */       setRole(2);
/* 169 */       addPackageNames(packageNames);
/*     */     }
/*     */     
/*     */     private void addPackageNames(Collection<String> additionalPackageNames) {
/* 173 */       this.packageNames.addAll(additionalPackageNames);
/* 174 */       getConstructorArgumentValues().addIndexedArgumentValue(0, StringUtils.toStringArray(this.packageNames));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-autoconfigure-3.5.7.jar!\org\springframework\boot\autoconfigure\domain\EntityScanPackages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */