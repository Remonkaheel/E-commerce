/*    */ package jakarta.xml.bind;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JAXBIntrospector
/*    */ {
/*    */   public abstract boolean isElement(Object paramObject);
/*    */   
/*    */   public abstract QName getElementName(Object paramObject);
/*    */   
/*    */   public static Object getValue(Object jaxbElement) {
/* 75 */     if (jaxbElement instanceof JAXBElement) {
/* 76 */       return ((JAXBElement)jaxbElement).getValue();
/*    */     }
/*    */ 
/*    */     
/* 80 */     return jaxbElement;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\JAXBIntrospector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */