package jakarta.xml.bind;

import java.util.Map;

public interface JAXBContextFactory {
  JAXBContext createContext(Class<?>[] paramArrayOfClass, Map<String, ?> paramMap) throws JAXBException;
  
  JAXBContext createContext(String paramString, ClassLoader paramClassLoader, Map<String, ?> paramMap) throws JAXBException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\JAXBContextFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */