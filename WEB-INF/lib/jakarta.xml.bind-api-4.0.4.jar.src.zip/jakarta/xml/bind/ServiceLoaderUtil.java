/*     */ package jakarta.xml.bind;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServiceLoaderUtil
/*     */ {
/*     */   private static final String OSGI_SERVICE_LOADER_CLASS_NAME = "org.glassfish.hk2.osgiresourcelocator.ServiceLoader";
/*     */   private static final String OSGI_SERVICE_LOADER_METHOD_NAME = "lookupProviderClasses";
/*     */   
/*     */   static <P, T extends Exception> P firstByServiceLoader(Class<P> spiClass, Logger logger, ExceptionHandler<T> handler) throws T {
/*     */     try {
/*  37 */       ServiceLoader<P> serviceLoader = ServiceLoader.load(spiClass);
/*     */       
/*  39 */       Iterator<P> iterator = serviceLoader.iterator(); if (iterator.hasNext()) { P impl = iterator.next();
/*  40 */         logger.log(Level.FINE, "ServiceProvider loading Facility used; returning object [{0}]", impl
/*  41 */             .getClass().getName());
/*     */         
/*  43 */         return impl; }
/*     */     
/*  45 */     } catch (Throwable t) {
/*  46 */       throw handler.createException(t, "Error while searching for service [" + spiClass.getName() + "]");
/*     */     } 
/*  48 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> T lookupUsingOSGiServiceLoader(String factoryId, Logger logger) {
/*     */     try {
/*  56 */       Class<? extends T> serviceClass = (Class)Class.forName(factoryId);
/*  57 */       Class<?> target = Class.forName("org.glassfish.hk2.osgiresourcelocator.ServiceLoader");
/*  58 */       Method m = target.getMethod("lookupProviderClasses", new Class[] { Class.class });
/*     */       
/*  60 */       Iterator<? extends T> iter = ((Iterable<? extends T>)m.invoke(null, new Object[] { serviceClass })).iterator();
/*  61 */       if (iter.hasNext()) {
/*  62 */         T next = iter.next();
/*  63 */         logger.log(Level.FINE, "Found implementation using OSGi facility; returning object [{0}].", next
/*  64 */             .getClass().getName());
/*  65 */         return next;
/*     */       } 
/*  67 */       return null;
/*     */     }
/*  69 */     catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|ClassNotFoundException|NoSuchMethodException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       logger.log(Level.FINE, "Unable to find from OSGi: [" + factoryId + "]", ex);
/*  75 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Iterable<T> lookupsUsingOSGiServiceLoader(String factoryId, Logger logger) {
/*     */     try {
/*  83 */       return 
/*  84 */         (Iterable<T>)Class.forName("org.glassfish.hk2.osgiresourcelocator.ServiceLoader")
/*  85 */         .getMethod("lookupProviderClasses", new Class[] { Class.class
/*  86 */           }).invoke(null, new Object[] { Class.forName(factoryId) });
/*     */     }
/*  88 */     catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|ClassNotFoundException|NoSuchMethodException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       logger.log(Level.FINE, ex, () -> "Unable to find from OSGi: [" + factoryId + "]");
/*  94 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void checkPackageAccess(String className) {
/* 100 */     SecurityManager s = System.getSecurityManager();
/* 101 */     if (s != null) {
/* 102 */       int i = className.lastIndexOf('.');
/* 103 */       if (i != -1) {
/* 104 */         s.checkPackageAccess(className.substring(0, i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static Class<?> nullSafeLoadClass(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 110 */     if (classLoader == null) {
/* 111 */       return Class.forName(className);
/*     */     }
/* 113 */     return classLoader.loadClass(className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Exception> Object newInstance(String className, String defaultImplClassName, ExceptionHandler<T> handler) throws T {
/*     */     try {
/* 124 */       return safeLoadClass(className, defaultImplClassName, contextClassLoader(handler)).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 125 */     } catch (ClassNotFoundException x) {
/* 126 */       throw handler.createException(x, "Provider " + className + " not found");
/* 127 */     } catch (Exception x) {
/* 128 */       throw handler.createException(x, "Provider " + className + " could not be instantiated: " + String.valueOf(x));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<?> safeLoadClass(String className, String defaultImplClassName, ClassLoader classLoader) throws ClassNotFoundException {
/*     */     try {
/* 137 */       checkPackageAccess(className);
/* 138 */     } catch (SecurityException se) {
/*     */       
/* 140 */       if (defaultImplClassName != null && defaultImplClassName.equals(className)) {
/* 141 */         return Class.forName(className);
/*     */       }
/*     */       
/* 144 */       throw se;
/*     */     } 
/* 146 */     return nullSafeLoadClass(className, classLoader);
/*     */   }
/*     */   
/*     */   static <T extends Exception> ClassLoader contextClassLoader(ExceptionHandler<T> exceptionHandler) throws T {
/*     */     try {
/* 151 */       return Thread.currentThread().getContextClassLoader();
/* 152 */     } catch (Exception x) {
/* 153 */       throw exceptionHandler.createException(x, x.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static abstract class ExceptionHandler<T extends Exception> {
/*     */     public abstract T createException(Throwable param1Throwable, String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\ServiceLoaderUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */