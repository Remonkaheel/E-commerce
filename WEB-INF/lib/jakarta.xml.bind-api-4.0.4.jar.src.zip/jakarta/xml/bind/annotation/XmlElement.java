package jakarta.xml.bind.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
public @interface XmlElement {
  String name() default "##default";
  
  boolean nillable() default false;
  
  boolean required() default false;
  
  String namespace() default "##default";
  
  String defaultValue() default "\000";
  
  Class<?> type() default DEFAULT.class;
  
  public static final class DEFAULT {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\annotation\XmlElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */