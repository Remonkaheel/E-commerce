package jakarta.xml.bind.annotation.adapters;

public abstract class XmlAdapter<ValueType, BoundType> {
  public abstract BoundType unmarshal(ValueType paramValueType) throws Exception;
  
  public abstract ValueType marshal(BoundType paramBoundType) throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\annotation\adapters\XmlAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */