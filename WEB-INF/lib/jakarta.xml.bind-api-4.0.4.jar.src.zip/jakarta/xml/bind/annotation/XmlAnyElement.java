package jakarta.xml.bind.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
public @interface XmlAnyElement {
  boolean lax() default false;
  
  Class<? extends DomHandler<?, ?>> value() default W3CDomHandler.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\annotation\XmlAnyElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */