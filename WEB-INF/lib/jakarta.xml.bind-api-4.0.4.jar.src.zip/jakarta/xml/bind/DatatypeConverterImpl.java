/*      */ package jakarta.xml.bind;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.TimeZone;
/*      */ import javax.xml.datatype.DatatypeConfigurationException;
/*      */ import javax.xml.datatype.DatatypeFactory;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DatatypeConverterImpl
/*      */   implements DatatypeConverterInterface
/*      */ {
/*   44 */   public static final DatatypeConverterInterface theInstance = new DatatypeConverterImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String parseString(String lexicalXSDString) {
/*   51 */     return lexicalXSDString;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigInteger parseInteger(String lexicalXSDInteger) {
/*   56 */     return _parseInteger(lexicalXSDInteger);
/*      */   }
/*      */   
/*      */   public static BigInteger _parseInteger(CharSequence s) {
/*   60 */     return new BigInteger(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */ 
/*      */   
/*      */   public String printInteger(BigInteger val) {
/*   65 */     return _printInteger(val);
/*      */   }
/*      */   
/*      */   public static String _printInteger(BigInteger val) {
/*   69 */     if (null == val) throw new IllegalArgumentException("val is null"); 
/*   70 */     return val.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public int parseInt(String s) {
/*   75 */     return _parseInt(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _parseInt(CharSequence s) {
/*   89 */     int len = s.length();
/*   90 */     int sign = 1;
/*      */     
/*   92 */     int r = 0;
/*      */     
/*   94 */     for (int i = 0; i < len; i++) {
/*   95 */       char ch = s.charAt(i);
/*   96 */       if (!WhiteSpaceProcessor.isWhiteSpace(ch))
/*      */       {
/*   98 */         if ('0' <= ch && ch <= '9') {
/*   99 */           r = r * 10 + ch - 48;
/*  100 */         } else if (ch == '-') {
/*  101 */           sign = -1;
/*  102 */         } else if (ch != '+') {
/*      */ 
/*      */           
/*  105 */           throw new NumberFormatException("Not a number: " + String.valueOf(s));
/*      */         } 
/*      */       }
/*      */     } 
/*  109 */     return r * sign;
/*      */   }
/*      */ 
/*      */   
/*      */   public long parseLong(String lexicalXSLong) {
/*  114 */     return _parseLong(lexicalXSLong);
/*      */   }
/*      */   
/*      */   public static long _parseLong(CharSequence s) {
/*  118 */     return Long.parseLong(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */ 
/*      */   
/*      */   public short parseShort(String lexicalXSDShort) {
/*  123 */     return _parseShort(lexicalXSDShort);
/*      */   }
/*      */   
/*      */   public static short _parseShort(CharSequence s) {
/*  127 */     return (short)_parseInt(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printShort(short val) {
/*  132 */     return _printShort(val);
/*      */   }
/*      */   
/*      */   public static String _printShort(short val) {
/*  136 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal parseDecimal(String content) {
/*  141 */     return _parseDecimal(content);
/*      */   }
/*      */   
/*      */   public static BigDecimal _parseDecimal(CharSequence content) {
/*  145 */     content = WhiteSpaceProcessor.trim(content);
/*      */     
/*  147 */     if (content.length() <= 0) {
/*  148 */       return null;
/*      */     }
/*      */     
/*  151 */     return new BigDecimal(content.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float parseFloat(String lexicalXSDFloat) {
/*  168 */     return _parseFloat(lexicalXSDFloat);
/*      */   }
/*      */   
/*      */   public static float _parseFloat(CharSequence _val) {
/*  172 */     String s = WhiteSpaceProcessor.trim(_val).toString();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  188 */     if (s.equals("NaN")) {
/*  189 */       return Float.NaN;
/*      */     }
/*  191 */     if (s.equals("INF")) {
/*  192 */       return Float.POSITIVE_INFINITY;
/*      */     }
/*  194 */     if (s.equals("-INF")) {
/*  195 */       return Float.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  198 */     if (s.isEmpty() || 
/*  199 */       !isDigitOrPeriodOrSign(s.charAt(0)) || 
/*  200 */       !isDigitOrPeriodOrSign(s.charAt(s.length() - 1))) {
/*  201 */       throw new NumberFormatException();
/*      */     }
/*      */ 
/*      */     
/*  205 */     return Float.parseFloat(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printFloat(float v) {
/*  210 */     return _printFloat(v);
/*      */   }
/*      */   
/*      */   public static String _printFloat(float v) {
/*  214 */     if (Float.isNaN(v)) {
/*  215 */       return "NaN";
/*      */     }
/*  217 */     if (v == Float.POSITIVE_INFINITY) {
/*  218 */       return "INF";
/*      */     }
/*  220 */     if (v == Float.NEGATIVE_INFINITY) {
/*  221 */       return "-INF";
/*      */     }
/*  223 */     return String.valueOf(v);
/*      */   }
/*      */ 
/*      */   
/*      */   public double parseDouble(String lexicalXSDDouble) {
/*  228 */     return _parseDouble(lexicalXSDDouble);
/*      */   }
/*      */   
/*      */   public static double _parseDouble(CharSequence _val) {
/*  232 */     String val = WhiteSpaceProcessor.trim(_val).toString();
/*      */     
/*  234 */     if (val.equals("NaN")) {
/*  235 */       return Double.NaN;
/*      */     }
/*  237 */     if (val.equals("INF")) {
/*  238 */       return Double.POSITIVE_INFINITY;
/*      */     }
/*  240 */     if (val.equals("-INF")) {
/*  241 */       return Double.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  244 */     if (val.isEmpty() || 
/*  245 */       !isDigitOrPeriodOrSign(val.charAt(0)) || 
/*  246 */       !isDigitOrPeriodOrSign(val.charAt(val.length() - 1))) {
/*  247 */       throw new NumberFormatException(val);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  252 */     return Double.parseDouble(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean parseBoolean(String lexicalXSDBoolean) {
/*  257 */     return _parseBoolean(lexicalXSDBoolean).booleanValue();
/*      */   } public static Boolean _parseBoolean(CharSequence literal) {
/*      */     char ch;
/*      */     String strTrue, strFalse;
/*  261 */     if (literal == null) {
/*  262 */       throw new IllegalArgumentException("String \"null\" is not valid boolean value.");
/*      */     }
/*      */     
/*  265 */     int i = 0;
/*  266 */     int len = literal.length();
/*      */     
/*  268 */     boolean value = false;
/*      */     
/*  270 */     if (literal.length() <= 0) {
/*  271 */       throw new IllegalArgumentException("String \"\" is not valid boolean value.");
/*      */     }
/*      */     
/*      */     do {
/*  275 */       ch = literal.charAt(i++);
/*  276 */     } while (WhiteSpaceProcessor.isWhiteSpace(ch) && i < len);
/*      */     
/*  278 */     int strIndex = 0;
/*      */     
/*  280 */     switch (ch) {
/*      */       case '1':
/*  282 */         value = true;
/*      */         break;
/*      */       case '0':
/*  285 */         value = false;
/*      */         break;
/*      */       case 't':
/*  288 */         strTrue = "rue";
/*      */         do {
/*  290 */           ch = literal.charAt(i++);
/*  291 */         } while (strTrue.charAt(strIndex++) == ch && i < len && strIndex < 3);
/*      */         
/*  293 */         if (strIndex == 3 && strTrue.charAt(strIndex - 1) == ch) {
/*  294 */           value = true; break;
/*      */         } 
/*  296 */         throw new IllegalArgumentException("String \"" + String.valueOf(literal) + "\" is not valid boolean value.");
/*      */ 
/*      */ 
/*      */       
/*      */       case 'f':
/*  301 */         strFalse = "alse";
/*      */         do {
/*  303 */           ch = literal.charAt(i++);
/*  304 */         } while (strFalse.charAt(strIndex++) == ch && i < len && strIndex < 4);
/*      */ 
/*      */         
/*  307 */         if (strIndex == 4 && strFalse.charAt(strIndex - 1) == ch) {
/*  308 */           value = false; break;
/*      */         } 
/*  310 */         throw new IllegalArgumentException("String \"" + String.valueOf(literal) + "\" is not valid boolean value.");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  316 */     while (i < len && WhiteSpaceProcessor.isWhiteSpace(literal.charAt(i))) {
/*  317 */       i++;
/*      */     }
/*      */     
/*  320 */     if (i == len) {
/*  321 */       return Boolean.valueOf(value);
/*      */     }
/*  323 */     throw new IllegalArgumentException("String \"" + String.valueOf(literal) + "\" is not valid boolean value.");
/*      */   }
/*      */ 
/*      */   
/*      */   public String printBoolean(boolean val) {
/*  328 */     return val ? "true" : "false";
/*      */   }
/*      */   
/*      */   public static String _printBoolean(boolean val) {
/*  332 */     return val ? "true" : "false";
/*      */   }
/*      */ 
/*      */   
/*      */   public byte parseByte(String lexicalXSDByte) {
/*  337 */     return _parseByte(lexicalXSDByte);
/*      */   }
/*      */   
/*      */   public static byte _parseByte(CharSequence literal) {
/*  341 */     return (byte)_parseInt(literal);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printByte(byte val) {
/*  346 */     return _printByte(val);
/*      */   }
/*      */   
/*      */   public static String _printByte(byte val) {
/*  350 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public QName parseQName(String lexicalXSDQName, NamespaceContext nsc) {
/*  355 */     return _parseQName(lexicalXSDQName, nsc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static QName _parseQName(CharSequence text, NamespaceContext nsc) {
/*      */     String uri, localPart, prefix;
/*  362 */     int length = text.length();
/*      */ 
/*      */     
/*  365 */     int start = 0;
/*  366 */     while (start < length && WhiteSpaceProcessor.isWhiteSpace(text.charAt(start))) {
/*  367 */       start++;
/*      */     }
/*      */     
/*  370 */     int end = length;
/*  371 */     while (end > start && WhiteSpaceProcessor.isWhiteSpace(text.charAt(end - 1))) {
/*  372 */       end--;
/*      */     }
/*      */     
/*  375 */     if (end == start) {
/*  376 */       throw new IllegalArgumentException("input is empty");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  385 */     int idx = start + 1;
/*  386 */     while (idx < end && text.charAt(idx) != ':') {
/*  387 */       idx++;
/*      */     }
/*      */     
/*  390 */     if (idx == end) {
/*  391 */       uri = nsc.getNamespaceURI("");
/*  392 */       localPart = text.subSequence(start, end).toString();
/*  393 */       prefix = "";
/*      */     } else {
/*      */       
/*  396 */       prefix = text.subSequence(start, idx).toString();
/*  397 */       localPart = text.subSequence(idx + 1, end).toString();
/*  398 */       uri = nsc.getNamespaceURI(prefix);
/*      */ 
/*      */       
/*  401 */       if (uri == null || uri.isEmpty())
/*      */       {
/*      */         
/*  404 */         throw new IllegalArgumentException("prefix " + prefix + " is not bound to a namespace");
/*      */       }
/*      */     } 
/*      */     
/*  408 */     return new QName(uri, localPart, prefix);
/*      */   }
/*      */ 
/*      */   
/*      */   public Calendar parseDateTime(String lexicalXSDDateTime) {
/*  413 */     return _parseDateTime(lexicalXSDDateTime);
/*      */   }
/*      */   
/*      */   public static GregorianCalendar _parseDateTime(CharSequence s) {
/*  417 */     String val = WhiteSpaceProcessor.trim(s).toString();
/*  418 */     return datatypeFactory.newXMLGregorianCalendar(val).toGregorianCalendar();
/*      */   }
/*      */ 
/*      */   
/*      */   public String printDateTime(Calendar val) {
/*  423 */     return _printDateTime(val);
/*      */   }
/*      */   
/*      */   public static String _printDateTime(Calendar val) {
/*  427 */     if (null == val) throw new IllegalArgumentException("val is null"); 
/*  428 */     return CalendarFormatter.doFormat("%Y-%M-%DT%h:%m:%s%z", val);
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] parseBase64Binary(String lexicalXSDBase64Binary) {
/*  433 */     return _parseBase64Binary(lexicalXSDBase64Binary);
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] parseHexBinary(String s) {
/*  438 */     int len = s.length();
/*      */ 
/*      */     
/*  441 */     if (len % 2 != 0) {
/*  442 */       throw new IllegalArgumentException("hexBinary needs to be even-length: " + s);
/*      */     }
/*      */     
/*  445 */     byte[] out = new byte[len / 2];
/*      */     
/*  447 */     for (int i = 0; i < len; i += 2) {
/*  448 */       int h = hexToBin(s.charAt(i));
/*  449 */       int l = hexToBin(s.charAt(i + 1));
/*  450 */       if (h == -1 || l == -1) {
/*  451 */         throw new IllegalArgumentException("contains illegal character for hexBinary: " + s);
/*      */       }
/*      */       
/*  454 */       out[i / 2] = (byte)(h * 16 + l);
/*      */     } 
/*      */     
/*  457 */     return out;
/*      */   }
/*      */   
/*      */   private static int hexToBin(char ch) {
/*  461 */     if ('0' <= ch && ch <= '9') {
/*  462 */       return ch - 48;
/*      */     }
/*  464 */     if ('A' <= ch && ch <= 'F') {
/*  465 */       return ch - 65 + 10;
/*      */     }
/*  467 */     if ('a' <= ch && ch <= 'f') {
/*  468 */       return ch - 97 + 10;
/*      */     }
/*  470 */     return -1;
/*      */   }
/*  472 */   private static final char[] hexCode = "0123456789ABCDEF".toCharArray();
/*      */ 
/*      */   
/*      */   public String printHexBinary(byte[] data) {
/*  476 */     if (null == data) throw new IllegalArgumentException("data is null"); 
/*  477 */     StringBuilder r = new StringBuilder(data.length * 2);
/*  478 */     for (byte b : data) {
/*  479 */       r.append(hexCode[b >> 4 & 0xF]);
/*  480 */       r.append(hexCode[b & 0xF]);
/*      */     } 
/*  482 */     return r.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public long parseUnsignedInt(String lexicalXSDUnsignedInt) {
/*  487 */     return _parseLong(lexicalXSDUnsignedInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printUnsignedInt(long val) {
/*  492 */     return _printLong(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public int parseUnsignedShort(String lexicalXSDUnsignedShort) {
/*  497 */     return _parseInt(lexicalXSDUnsignedShort);
/*      */   }
/*      */ 
/*      */   
/*      */   public Calendar parseTime(String lexicalXSDTime) {
/*  502 */     return datatypeFactory.newXMLGregorianCalendar(lexicalXSDTime).toGregorianCalendar();
/*      */   }
/*      */ 
/*      */   
/*      */   public String printTime(Calendar val) {
/*  507 */     if (null == val) throw new IllegalArgumentException("val is null"); 
/*  508 */     return CalendarFormatter.doFormat("%h:%m:%s%z", val);
/*      */   }
/*      */ 
/*      */   
/*      */   public Calendar parseDate(String lexicalXSDDate) {
/*  513 */     return datatypeFactory.newXMLGregorianCalendar(lexicalXSDDate).toGregorianCalendar();
/*      */   }
/*      */ 
/*      */   
/*      */   public String printDate(Calendar val) {
/*  518 */     return _printDate(val);
/*      */   }
/*      */   
/*      */   public static String _printDate(Calendar val) {
/*  522 */     if (null == val) throw new IllegalArgumentException("val is null"); 
/*  523 */     return CalendarFormatter.doFormat("%Y-%M-%D%z", val);
/*      */   }
/*      */ 
/*      */   
/*      */   public String parseAnySimpleType(String lexicalXSDAnySimpleType) {
/*  528 */     return lexicalXSDAnySimpleType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String printString(String val) {
/*  535 */     return val;
/*      */   }
/*      */ 
/*      */   
/*      */   public String printInt(int val) {
/*  540 */     return _printInt(val);
/*      */   }
/*      */   
/*      */   public static String _printInt(int val) {
/*  544 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printLong(long val) {
/*  549 */     return _printLong(val);
/*      */   }
/*      */   
/*      */   public static String _printLong(long val) {
/*  553 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printDecimal(BigDecimal val) {
/*  558 */     return _printDecimal(val);
/*      */   }
/*      */   
/*      */   public static String _printDecimal(BigDecimal val) {
/*  562 */     if (null == val) throw new IllegalArgumentException("val is null"); 
/*  563 */     return val.toPlainString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String printDouble(double v) {
/*  568 */     return _printDouble(v);
/*      */   }
/*      */   
/*      */   public static String _printDouble(double v) {
/*  572 */     if (Double.isNaN(v)) {
/*  573 */       return "NaN";
/*      */     }
/*  575 */     if (v == Double.POSITIVE_INFINITY) {
/*  576 */       return "INF";
/*      */     }
/*  578 */     if (v == Double.NEGATIVE_INFINITY) {
/*  579 */       return "-INF";
/*      */     }
/*  581 */     return String.valueOf(v);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printQName(QName val, NamespaceContext nsc) {
/*  586 */     return _printQName(val, nsc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _printQName(QName val, NamespaceContext nsc) {
/*  592 */     String qname, prefix = nsc.getPrefix(val.getNamespaceURI());
/*  593 */     String localPart = val.getLocalPart();
/*      */     
/*  595 */     if (prefix == null || prefix.isEmpty()) {
/*  596 */       qname = localPart;
/*      */     } else {
/*  598 */       qname = prefix + ":" + prefix;
/*      */     } 
/*      */     
/*  601 */     return qname;
/*      */   }
/*      */ 
/*      */   
/*      */   public String printBase64Binary(byte[] val) {
/*  606 */     return _printBase64Binary(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printUnsignedShort(int val) {
/*  611 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   public String printAnySimpleType(String val) {
/*  616 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String installHook(String s) {
/*  625 */     DatatypeConverter.setDatatypeConverter(theInstance);
/*  626 */     return s;
/*      */   }
/*      */   
/*  629 */   private static final byte[] decodeMap = initDecodeMap();
/*      */   private static final byte PADDING = 127;
/*      */   
/*      */   private static byte[] initDecodeMap() {
/*  633 */     byte[] map = new byte[128];
/*      */     int i;
/*  635 */     for (i = 0; i < 128; i++) {
/*  636 */       map[i] = -1;
/*      */     }
/*      */     
/*  639 */     for (i = 65; i <= 90; i++) {
/*  640 */       map[i] = (byte)(i - 65);
/*      */     }
/*  642 */     for (i = 97; i <= 122; i++) {
/*  643 */       map[i] = (byte)(i - 97 + 26);
/*      */     }
/*  645 */     for (i = 48; i <= 57; i++) {
/*  646 */       map[i] = (byte)(i - 48 + 52);
/*      */     }
/*  648 */     map[43] = 62;
/*  649 */     map[47] = 63;
/*  650 */     map[61] = Byte.MAX_VALUE;
/*      */     
/*  652 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int guessLength(String text) {
/*  676 */     int len = text.length();
/*      */ 
/*      */     
/*  679 */     int j = len - 1;
/*  680 */     while (j >= 0) {
/*  681 */       byte code = decodeMap[text.charAt(j)];
/*  682 */       if (code == Byte.MAX_VALUE) {
/*      */         j--; continue;
/*      */       } 
/*  685 */       if (code == -1)
/*      */       {
/*  687 */         return text.length() / 4 * 3;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  692 */     j++;
/*  693 */     int padSize = len - j;
/*  694 */     if (padSize > 2)
/*      */     {
/*  696 */       return text.length() / 4 * 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  701 */     return text.length() / 4 * 3 - padSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] _parseBase64Binary(String text) {
/*  714 */     if (null == text || text.length() % 4 != 0) {
/*  715 */       throw new IllegalArgumentException("base64 text invalid.");
/*      */     }
/*  717 */     int buflen = guessLength(text);
/*  718 */     byte[] out = new byte[buflen];
/*  719 */     int o = 0;
/*      */     
/*  721 */     int len = text.length();
/*      */ 
/*      */     
/*  724 */     byte[] quadruplet = new byte[4];
/*  725 */     int q = 0;
/*      */ 
/*      */     
/*  728 */     for (int i = 0; i < len; i++) {
/*  729 */       char ch = text.charAt(i);
/*  730 */       byte v = decodeMap[ch];
/*      */       
/*  732 */       if (v != -1) {
/*  733 */         quadruplet[q++] = v;
/*      */       }
/*      */       
/*  736 */       if (q == 4) {
/*      */ 
/*      */         
/*  739 */         out[o++] = (byte)(quadruplet[0] << 2 | quadruplet[1] >> 4);
/*  740 */         if (quadruplet[2] != Byte.MAX_VALUE) {
/*  741 */           out[o++] = (byte)(quadruplet[1] << 4 | quadruplet[2] >> 2);
/*      */         }
/*  743 */         if (quadruplet[3] != Byte.MAX_VALUE) {
/*  744 */           out[o++] = (byte)(quadruplet[2] << 6 | quadruplet[3]);
/*      */         }
/*  746 */         q = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  750 */     if (buflen == o)
/*      */     {
/*  752 */       return out;
/*      */     }
/*      */ 
/*      */     
/*  756 */     byte[] nb = new byte[o];
/*  757 */     System.arraycopy(out, 0, nb, 0, o);
/*  758 */     return nb;
/*      */   }
/*  760 */   private static final char[] encodeMap = initEncodeMap(); private static final DatatypeFactory datatypeFactory;
/*      */   
/*      */   private static char[] initEncodeMap() {
/*  763 */     char[] map = new char[64];
/*      */     int i;
/*  765 */     for (i = 0; i < 26; i++) {
/*  766 */       map[i] = (char)(65 + i);
/*      */     }
/*  768 */     for (i = 26; i < 52; i++) {
/*  769 */       map[i] = (char)(97 + i - 26);
/*      */     }
/*  771 */     for (i = 52; i < 62; i++) {
/*  772 */       map[i] = (char)(48 + i - 52);
/*      */     }
/*  774 */     map[62] = '+';
/*  775 */     map[63] = '/';
/*      */     
/*  777 */     return map;
/*      */   }
/*      */   
/*      */   public static char encode(int i) {
/*  781 */     return encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static byte encodeByte(int i) {
/*  785 */     return (byte)encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input) {
/*  789 */     if (null == input) throw new IllegalArgumentException("input is null"); 
/*  790 */     return _printBase64Binary(input, 0, input.length);
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input, int offset, int len) {
/*  794 */     char[] buf = new char[(len + 2) / 3 * 4];
/*  795 */     int ptr = _printBase64Binary(input, offset, len, buf, 0);
/*  796 */     assert ptr == buf.length;
/*  797 */     return new String(buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, char[] buf, int ptr) {
/*  811 */     int remaining = len;
/*      */     int i;
/*  813 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  814 */       buf[ptr++] = encode(input[i] >> 2);
/*  815 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  818 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  821 */       buf[ptr++] = encode(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  824 */     if (remaining == 1) {
/*  825 */       buf[ptr++] = encode(input[i] >> 2);
/*  826 */       buf[ptr++] = encode((input[i] & 0x3) << 4);
/*  827 */       buf[ptr++] = '=';
/*  828 */       buf[ptr++] = '=';
/*      */     } 
/*      */     
/*  831 */     if (remaining == 2) {
/*  832 */       buf[ptr++] = encode(input[i] >> 2);
/*  833 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */       
/*  835 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2);
/*  836 */       buf[ptr++] = '=';
/*      */     } 
/*  838 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, byte[] out, int ptr) {
/*  852 */     byte[] buf = out;
/*  853 */     int remaining = len;
/*      */     int i;
/*  855 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  856 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  857 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  860 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  863 */       buf[ptr++] = encodeByte(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  866 */     if (remaining == 1) {
/*  867 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  868 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4);
/*  869 */       buf[ptr++] = 61;
/*  870 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  873 */     if (remaining == 2) {
/*  874 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  875 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  878 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2);
/*  879 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  882 */     return ptr;
/*      */   }
/*      */   
/*      */   private static CharSequence removeOptionalPlus(CharSequence s) {
/*  886 */     int len = s.length();
/*      */     
/*  888 */     if (len <= 1 || s.charAt(0) != '+') {
/*  889 */       return s;
/*      */     }
/*      */     
/*  892 */     s = s.subSequence(1, len);
/*  893 */     char ch = s.charAt(0);
/*  894 */     if ('0' <= ch && ch <= '9') {
/*  895 */       return s;
/*      */     }
/*  897 */     if ('.' == ch) {
/*  898 */       return s;
/*      */     }
/*      */     
/*  901 */     throw new NumberFormatException();
/*      */   }
/*      */   
/*      */   private static boolean isDigitOrPeriodOrSign(char ch) {
/*  905 */     if ('0' <= ch && ch <= '9') {
/*  906 */       return true;
/*      */     }
/*  908 */     if (ch == '+' || ch == '-' || ch == '.') {
/*  909 */       return true;
/*      */     }
/*  911 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  917 */       datatypeFactory = DatatypeFactory.newInstance();
/*  918 */     } catch (DatatypeConfigurationException e) {
/*  919 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final class CalendarFormatter
/*      */   {
/*      */     public static String doFormat(String format, Calendar cal) throws IllegalArgumentException {
/*  926 */       int fidx = 0;
/*  927 */       int flen = format.length();
/*  928 */       StringBuilder buf = new StringBuilder();
/*      */       
/*  930 */       while (fidx < flen) {
/*  931 */         char fch = format.charAt(fidx++);
/*      */         
/*  933 */         if (fch != '%') {
/*  934 */           buf.append(fch);
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  939 */         switch (format.charAt(fidx++)) {
/*      */           case 'Y':
/*  941 */             formatYear(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'M':
/*  945 */             formatMonth(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'D':
/*  949 */             formatDays(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'h':
/*  953 */             formatHours(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'm':
/*  957 */             formatMinutes(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 's':
/*  961 */             formatSeconds(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'z':
/*  965 */             formatTimeZone(cal, buf);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */         
/*  970 */         throw new InternalError();
/*      */       } 
/*      */ 
/*      */       
/*  974 */       return buf.toString();
/*      */     }
/*      */     private static void formatYear(Calendar cal, StringBuilder buf) {
/*      */       String s;
/*  978 */       int year = cal.get(1);
/*      */ 
/*      */       
/*  981 */       if (year <= 0) {
/*      */         
/*  983 */         s = Integer.toString(1 - year);
/*      */       } else {
/*      */         
/*  986 */         s = Integer.toString(year);
/*      */       } 
/*      */       
/*  989 */       while (s.length() < 4) {
/*  990 */         s = "0" + s;
/*      */       }
/*  992 */       if (year <= 0) {
/*  993 */         s = "-" + s;
/*      */       }
/*      */       
/*  996 */       buf.append(s);
/*      */     }
/*      */     
/*      */     private static void formatMonth(Calendar cal, StringBuilder buf) {
/* 1000 */       formatTwoDigits(cal.get(2) + 1, buf);
/*      */     }
/*      */     
/*      */     private static void formatDays(Calendar cal, StringBuilder buf) {
/* 1004 */       formatTwoDigits(cal.get(5), buf);
/*      */     }
/*      */     
/*      */     private static void formatHours(Calendar cal, StringBuilder buf) {
/* 1008 */       formatTwoDigits(cal.get(11), buf);
/*      */     }
/*      */     
/*      */     private static void formatMinutes(Calendar cal, StringBuilder buf) {
/* 1012 */       formatTwoDigits(cal.get(12), buf);
/*      */     }
/*      */     
/*      */     private static void formatSeconds(Calendar cal, StringBuilder buf) {
/* 1016 */       formatTwoDigits(cal.get(13), buf);
/* 1017 */       if (cal.isSet(14)) {
/* 1018 */         int n = cal.get(14);
/* 1019 */         if (n != 0) {
/* 1020 */           String ms = Integer.toString(n);
/* 1021 */           while (ms.length() < 3) {
/* 1022 */             ms = "0" + ms;
/*      */           }
/* 1024 */           buf.append('.');
/* 1025 */           buf.append(ms);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private static void formatTimeZone(Calendar cal, StringBuilder buf) {
/* 1032 */       TimeZone tz = cal.getTimeZone();
/*      */       
/* 1034 */       if (tz == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1039 */       int offset = tz.getOffset(cal.getTime().getTime());
/*      */       
/* 1041 */       if (offset == 0) {
/* 1042 */         buf.append('Z');
/*      */         
/*      */         return;
/*      */       } 
/* 1046 */       if (offset >= 0) {
/* 1047 */         buf.append('+');
/*      */       } else {
/* 1049 */         buf.append('-');
/* 1050 */         offset *= -1;
/*      */       } 
/*      */       
/* 1053 */       offset /= 60000;
/*      */       
/* 1055 */       formatTwoDigits(offset / 60, buf);
/* 1056 */       buf.append(':');
/* 1057 */       formatTwoDigits(offset % 60, buf);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void formatTwoDigits(int n, StringBuilder buf) {
/* 1063 */       if (n < 10) {
/* 1064 */         buf.append('0');
/*      */       }
/* 1066 */       buf.append(n);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\DatatypeConverterImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */