package jakarta.xml.bind;

import java.io.IOException;
import javax.xml.transform.Result;

public abstract class SchemaOutputResolver {
  public abstract Result createOutput(String paramString1, String paramString2) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\SchemaOutputResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */