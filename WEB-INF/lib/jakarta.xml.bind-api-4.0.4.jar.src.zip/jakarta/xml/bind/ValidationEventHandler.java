package jakarta.xml.bind;

public interface ValidationEventHandler {
  boolean handleEvent(ValidationEvent paramValidationEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\ValidationEventHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */