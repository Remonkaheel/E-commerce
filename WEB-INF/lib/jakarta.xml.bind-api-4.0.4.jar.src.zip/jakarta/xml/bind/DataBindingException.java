/*    */ package jakarta.xml.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataBindingException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 4743686626270704879L;
/*    */   
/*    */   public DataBindingException(String message, Throwable cause) {
/* 29 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public DataBindingException(Throwable cause) {
/* 33 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\DataBindingException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */