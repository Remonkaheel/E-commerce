/*     */ package jakarta.xml.bind;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class WhiteSpaceProcessor
/*     */ {
/*     */   public static String replace(String text) {
/*  39 */     return replace(text).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence replace(CharSequence text) {
/*  46 */     int i = text.length() - 1;
/*     */ 
/*     */     
/*  49 */     while (i >= 0 && !isWhiteSpaceExceptSpace(text.charAt(i))) {
/*  50 */       i--;
/*     */     }
/*  52 */     if (i < 0)
/*     */     {
/*  54 */       return text;
/*     */     }
/*     */ 
/*     */     
/*  58 */     StringBuilder buf = new StringBuilder(text);
/*     */     
/*  60 */     buf.setCharAt(i--, ' ');
/*  61 */     for (; i >= 0; i--) {
/*  62 */       if (isWhiteSpaceExceptSpace(buf.charAt(i)))
/*  63 */         buf.setCharAt(i, ' '); 
/*     */     } 
/*  65 */     return new String(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence trim(CharSequence text) {
/*  73 */     int len = text.length();
/*  74 */     int start = 0;
/*     */     
/*  76 */     while (start < len && isWhiteSpace(text.charAt(start))) {
/*  77 */       start++;
/*     */     }
/*  79 */     int end = len - 1;
/*     */     
/*  81 */     while (end > start && isWhiteSpace(text.charAt(end))) {
/*  82 */       end--;
/*     */     }
/*  84 */     if (start == 0 && end == len - 1) {
/*  85 */       return text;
/*     */     }
/*  87 */     return text.subSequence(start, end + 1);
/*     */   }
/*     */   
/*     */   public static String collapse(String text) {
/*  91 */     return collapse(text).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence collapse(CharSequence text) {
/* 100 */     int len = text.length();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     int s = 0;
/* 106 */     while (s < len && 
/* 107 */       !isWhiteSpace(text.charAt(s)))
/*     */     {
/* 109 */       s++;
/*     */     }
/* 111 */     if (s == len)
/*     */     {
/* 113 */       return text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 118 */     StringBuilder result = new StringBuilder(len);
/*     */     
/* 120 */     if (s != 0) {
/* 121 */       for (int j = 0; j < s; j++)
/* 122 */         result.append(text.charAt(j)); 
/* 123 */       result.append(' ');
/*     */     } 
/*     */     
/* 126 */     boolean inStripMode = true;
/* 127 */     for (int i = s + 1; i < len; i++) {
/* 128 */       char ch = text.charAt(i);
/* 129 */       boolean b = isWhiteSpace(ch);
/* 130 */       if (!inStripMode || !b) {
/*     */ 
/*     */         
/* 133 */         inStripMode = b;
/* 134 */         if (inStripMode) {
/* 135 */           result.append(' ');
/*     */         } else {
/* 137 */           result.append(ch);
/*     */         } 
/*     */       } 
/*     */     } 
/* 141 */     len = result.length();
/* 142 */     if (len > 0 && result.charAt(len - 1) == ' ') {
/* 143 */       result.setLength(len - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isWhiteSpace(CharSequence s) {
/* 155 */     for (int i = s.length() - 1; i >= 0; i--) {
/* 156 */       if (!isWhiteSpace(s.charAt(i)))
/* 157 */         return false; 
/* 158 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isWhiteSpace(char ch) {
/* 165 */     if (ch > ' ') return false;
/*     */ 
/*     */     
/* 168 */     return (ch == '\t' || ch == '\n' || ch == '\r' || ch == ' ');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final boolean isWhiteSpaceExceptSpace(char ch) {
/* 178 */     if (ch >= ' ') return false;
/*     */ 
/*     */     
/* 181 */     return (ch == '\t' || ch == '\n' || ch == '\r');
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\WhiteSpaceProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */