/*     */ package jakarta.xml.bind;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JAXB
/*     */ {
/*     */   private static volatile WeakReference<Cache> cache;
/*     */   
/*     */   private static final class Cache
/*     */   {
/*     */     final Class<?> type;
/*     */     final JAXBContext context;
/*     */     
/*     */     public Cache(Class<?> type) throws JAXBException {
/*  95 */       this.type = type;
/*  96 */       this.context = JAXBContext.newInstance(new Class[] { type });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> JAXBContext getContext(Class<T> type) throws JAXBException {
/* 115 */     WeakReference<Cache> c = cache;
/* 116 */     if (c != null) {
/* 117 */       Cache cache = c.get();
/* 118 */       if (cache != null && cache.type == type) {
/* 119 */         return cache.context;
/*     */       }
/*     */     } 
/*     */     
/* 123 */     Cache d = new Cache(type);
/* 124 */     cache = new WeakReference<>(d);
/*     */     
/* 126 */     return d.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(File xml, Class<T> type) {
/*     */     try {
/* 137 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(new StreamSource(xml), type);
/* 138 */       return item.getValue();
/* 139 */     } catch (JAXBException e) {
/* 140 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(URL xml, Class<T> type) {
/*     */     try {
/* 152 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 153 */       return item.getValue();
/* 154 */     } catch (JAXBException|IOException e) {
/* 155 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(URI xml, Class<T> type) {
/*     */     try {
/* 168 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 169 */       return item.getValue();
/* 170 */     } catch (JAXBException|IOException e) {
/* 171 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(String xml, Class<T> type) {
/*     */     try {
/* 185 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 186 */       return item.getValue();
/* 187 */     } catch (JAXBException|IOException e) {
/* 188 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(InputStream xml, Class<T> type) {
/*     */     try {
/* 201 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 202 */       return item.getValue();
/* 203 */     } catch (JAXBException|IOException e) {
/* 204 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(Reader xml, Class<T> type) {
/*     */     try {
/* 218 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 219 */       return item.getValue();
/* 220 */     } catch (JAXBException|IOException e) {
/* 221 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T unmarshal(Source xml, Class<T> type) {
/*     */     try {
/* 233 */       JAXBElement<T> item = getContext(type).createUnmarshaller().unmarshal(toSource(xml), type);
/* 234 */       return item.getValue();
/* 235 */     } catch (JAXBException|IOException e) {
/* 236 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Source toSource(Object xml) throws IOException {
/* 247 */     if (xml == null) {
/* 248 */       throw new IllegalArgumentException("no XML is given");
/*     */     }
/* 250 */     if (xml instanceof String) {
/*     */       try {
/* 252 */         xml = new URI((String)xml);
/* 253 */       } catch (URISyntaxException e) {
/* 254 */         xml = new File((String)xml);
/*     */       } 
/*     */     }
/* 257 */     if (xml instanceof File) {
/* 258 */       File file = (File)xml;
/* 259 */       return new StreamSource(file);
/*     */     } 
/* 261 */     if (xml instanceof URI) {
/* 262 */       URI uri = (URI)xml;
/* 263 */       xml = uri.toURL();
/*     */     } 
/* 265 */     if (xml instanceof URL) {
/* 266 */       URL url = (URL)xml;
/* 267 */       return new StreamSource(url.toExternalForm());
/*     */     } 
/* 269 */     if (xml instanceof InputStream) {
/* 270 */       InputStream in = (InputStream)xml;
/* 271 */       return new StreamSource(in);
/*     */     } 
/* 273 */     if (xml instanceof Reader) {
/* 274 */       Reader r = (Reader)xml;
/* 275 */       return new StreamSource(r);
/*     */     } 
/* 277 */     if (xml instanceof Source) {
/* 278 */       return (Source)xml;
/*     */     }
/* 280 */     throw new IllegalArgumentException("I don't understand how to handle " + String.valueOf(xml.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, File xml) {
/* 304 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, URL xml) {
/* 331 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, URI xml) {
/* 355 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, String xml) {
/* 380 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, OutputStream xml) {
/* 404 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, Writer xml) {
/* 428 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshal(Object jaxbObject, Result xml) {
/* 451 */     _marshal(jaxbObject, xml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void _marshal(Object jaxbObject, Object xml) {
/*     */     try {
/*     */       JAXBContext context;
/* 533 */       if (jaxbObject instanceof JAXBElement) {
/* 534 */         context = getContext(((JAXBElement)jaxbObject).getDeclaredType());
/*     */       } else {
/* 536 */         Class<?> clazz = jaxbObject.getClass();
/* 537 */         XmlRootElement r = clazz.<XmlRootElement>getAnnotation(XmlRootElement.class);
/* 538 */         context = getContext(clazz);
/* 539 */         if (r == null)
/*     */         {
/* 541 */           jaxbObject = new JAXBElement(new QName(inferName(clazz)), clazz, jaxbObject);
/*     */         }
/*     */       } 
/*     */       
/* 545 */       Marshaller m = context.createMarshaller();
/* 546 */       m.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/* 547 */       m.marshal(jaxbObject, toResult(xml));
/* 548 */     } catch (JAXBException|IOException e) {
/* 549 */       throw new DataBindingException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String inferName(Class<?> clazz) {
/* 556 */     String simpleName = clazz.getSimpleName();
/* 557 */     if (simpleName.isEmpty()) {
/* 558 */       return simpleName;
/*     */     }
/* 560 */     if (simpleName.length() > 1 && Character.isUpperCase(simpleName.charAt(1)) && 
/* 561 */       Character.isUpperCase(simpleName.charAt(0))) {
/* 562 */       return simpleName;
/*     */     }
/* 564 */     char[] chars = simpleName.toCharArray();
/* 565 */     chars[0] = Character.toLowerCase(chars[0]);
/* 566 */     return new String(chars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Result toResult(Object xml) throws IOException {
/* 574 */     if (xml == null) {
/* 575 */       throw new IllegalArgumentException("no XML is given");
/*     */     }
/* 577 */     if (xml instanceof String) {
/*     */       try {
/* 579 */         xml = new URI((String)xml);
/* 580 */       } catch (URISyntaxException e) {
/* 581 */         xml = new File((String)xml);
/*     */       } 
/*     */     }
/* 584 */     if (xml instanceof File) {
/* 585 */       File file = (File)xml;
/* 586 */       return new StreamResult(file);
/*     */     } 
/* 588 */     if (xml instanceof URI) {
/* 589 */       URI uri = (URI)xml;
/* 590 */       xml = uri.toURL();
/*     */     } 
/* 592 */     if (xml instanceof URL) {
/* 593 */       URL url = (URL)xml;
/* 594 */       URLConnection con = url.openConnection();
/* 595 */       con.setDoOutput(true);
/* 596 */       con.setDoInput(false);
/* 597 */       con.connect();
/* 598 */       return new StreamResult(con.getOutputStream());
/*     */     } 
/* 600 */     if (xml instanceof OutputStream) {
/* 601 */       OutputStream os = (OutputStream)xml;
/* 602 */       return new StreamResult(os);
/*     */     } 
/* 604 */     if (xml instanceof Writer) {
/* 605 */       Writer w = (Writer)xml;
/* 606 */       return new StreamResult(w);
/*     */     } 
/* 608 */     if (xml instanceof Result) {
/* 609 */       return (Result)xml;
/*     */     }
/* 611 */     throw new IllegalArgumentException("I don't understand how to handle " + String.valueOf(xml.getClass()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\JAXB.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */