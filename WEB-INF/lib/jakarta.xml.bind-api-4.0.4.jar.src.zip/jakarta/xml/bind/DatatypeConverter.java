/*     */ package jakarta.xml.bind;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Calendar;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DatatypeConverter
/*     */ {
/*  79 */   private static volatile DatatypeConverterInterface theConverter = null;
/*     */   
/*  81 */   private static final JAXBPermission SET_DATATYPE_CONVERTER_PERMISSION = new JAXBPermission("setDatatypeConverter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDatatypeConverter(DatatypeConverterInterface converter) {
/* 110 */     if (converter == null)
/* 111 */       throw new IllegalArgumentException(
/* 112 */           Messages.format("DatatypeConverter.ConverterMustNotBeNull")); 
/* 113 */     if (theConverter == null) {
/* 114 */       SecurityManager sm = System.getSecurityManager();
/* 115 */       if (sm != null)
/* 116 */         sm.checkPermission(SET_DATATYPE_CONVERTER_PERMISSION); 
/* 117 */       theConverter = converter;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static synchronized void initConverter() {
/* 122 */     theConverter = new DatatypeConverterImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseString(String lexicalXSDString) {
/* 135 */     if (theConverter == null) initConverter(); 
/* 136 */     return theConverter.parseString(lexicalXSDString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger parseInteger(String lexicalXSDInteger) {
/* 150 */     if (theConverter == null) initConverter(); 
/* 151 */     return theConverter.parseInteger(lexicalXSDInteger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseInt(String lexicalXSDInt) {
/* 165 */     if (theConverter == null) initConverter(); 
/* 166 */     return theConverter.parseInt(lexicalXSDInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(String lexicalXSDLong) {
/* 180 */     if (theConverter == null) initConverter(); 
/* 181 */     return theConverter.parseLong(lexicalXSDLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short parseShort(String lexicalXSDShort) {
/* 195 */     if (theConverter == null) initConverter(); 
/* 196 */     return theConverter.parseShort(lexicalXSDShort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseDecimal(String lexicalXSDDecimal) {
/* 210 */     if (theConverter == null) initConverter(); 
/* 211 */     return theConverter.parseDecimal(lexicalXSDDecimal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(String lexicalXSDFloat) {
/* 225 */     if (theConverter == null) initConverter(); 
/* 226 */     return theConverter.parseFloat(lexicalXSDFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(String lexicalXSDDouble) {
/* 240 */     if (theConverter == null) initConverter(); 
/* 241 */     return theConverter.parseDouble(lexicalXSDDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean parseBoolean(String lexicalXSDBoolean) {
/* 255 */     if (theConverter == null) initConverter(); 
/* 256 */     return theConverter.parseBoolean(lexicalXSDBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte parseByte(String lexicalXSDByte) {
/* 270 */     if (theConverter == null) initConverter(); 
/* 271 */     return theConverter.parseByte(lexicalXSDByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName parseQName(String lexicalXSDQName, NamespaceContext nsc) {
/* 293 */     if (theConverter == null) initConverter(); 
/* 294 */     return theConverter.parseQName(lexicalXSDQName, nsc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseDateTime(String lexicalXSDDateTime) {
/* 308 */     if (theConverter == null) initConverter(); 
/* 309 */     return theConverter.parseDateTime(lexicalXSDDateTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] parseBase64Binary(String lexicalXSDBase64Binary) {
/* 323 */     if (theConverter == null) initConverter(); 
/* 324 */     return theConverter.parseBase64Binary(lexicalXSDBase64Binary);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] parseHexBinary(String lexicalXSDHexBinary) {
/* 338 */     if (theConverter == null) initConverter(); 
/* 339 */     return theConverter.parseHexBinary(lexicalXSDHexBinary);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseUnsignedInt(String lexicalXSDUnsignedInt) {
/* 353 */     if (theConverter == null) initConverter(); 
/* 354 */     return theConverter.parseUnsignedInt(lexicalXSDUnsignedInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseUnsignedShort(String lexicalXSDUnsignedShort) {
/* 368 */     if (theConverter == null) initConverter(); 
/* 369 */     return theConverter.parseUnsignedShort(lexicalXSDUnsignedShort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseTime(String lexicalXSDTime) {
/* 383 */     if (theConverter == null) initConverter(); 
/* 384 */     return theConverter.parseTime(lexicalXSDTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseDate(String lexicalXSDDate) {
/* 397 */     if (theConverter == null) initConverter(); 
/* 398 */     return theConverter.parseDate(lexicalXSDDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseAnySimpleType(String lexicalXSDAnySimpleType) {
/* 413 */     if (theConverter == null) initConverter(); 
/* 414 */     return theConverter.parseAnySimpleType(lexicalXSDAnySimpleType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printString(String val) {
/* 428 */     if (theConverter == null) initConverter(); 
/* 429 */     return theConverter.printString(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printInteger(BigInteger val) {
/* 442 */     if (theConverter == null) initConverter(); 
/* 443 */     return theConverter.printInteger(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printInt(int val) {
/* 455 */     if (theConverter == null) initConverter(); 
/* 456 */     return theConverter.printInt(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printLong(long val) {
/* 468 */     if (theConverter == null) initConverter(); 
/* 469 */     return theConverter.printLong(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printShort(short val) {
/* 481 */     if (theConverter == null) initConverter(); 
/* 482 */     return theConverter.printShort(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDecimal(BigDecimal val) {
/* 495 */     if (theConverter == null) initConverter(); 
/* 496 */     return theConverter.printDecimal(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printFloat(float val) {
/* 508 */     if (theConverter == null) initConverter(); 
/* 509 */     return theConverter.printFloat(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDouble(double val) {
/* 521 */     if (theConverter == null) initConverter(); 
/* 522 */     return theConverter.printDouble(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printBoolean(boolean val) {
/* 534 */     if (theConverter == null) initConverter(); 
/* 535 */     return theConverter.printBoolean(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printByte(byte val) {
/* 547 */     if (theConverter == null) initConverter(); 
/* 548 */     return theConverter.printByte(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printQName(QName val, NamespaceContext nsc) {
/* 565 */     if (theConverter == null) initConverter(); 
/* 566 */     return theConverter.printQName(val, nsc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDateTime(Calendar val) {
/* 579 */     if (theConverter == null) initConverter(); 
/* 580 */     return theConverter.printDateTime(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printBase64Binary(byte[] val) {
/* 593 */     if (theConverter == null) initConverter(); 
/* 594 */     return theConverter.printBase64Binary(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printHexBinary(byte[] val) {
/* 607 */     if (theConverter == null) initConverter(); 
/* 608 */     return theConverter.printHexBinary(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printUnsignedInt(long val) {
/* 620 */     if (theConverter == null) initConverter(); 
/* 621 */     return theConverter.printUnsignedInt(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printUnsignedShort(int val) {
/* 633 */     if (theConverter == null) initConverter(); 
/* 634 */     return theConverter.printUnsignedShort(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printTime(Calendar val) {
/* 647 */     if (theConverter == null) initConverter(); 
/* 648 */     return theConverter.printTime(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDate(Calendar val) {
/* 661 */     if (theConverter == null) initConverter(); 
/* 662 */     return theConverter.printDate(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printAnySimpleType(String val) {
/* 674 */     if (theConverter == null) initConverter(); 
/* 675 */     return theConverter.printAnySimpleType(val);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\DatatypeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */