/*     */ package jakarta.xml.bind.helpers;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import java.net.URL;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultValidationEventHandler
/*     */   implements ValidationEventHandler
/*     */ {
/*     */   public boolean handleEvent(ValidationEvent event) {
/*  48 */     if (event == null) {
/*  49 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*  53 */     String severity = null;
/*  54 */     boolean retVal = false;
/*  55 */     switch (event.getSeverity()) {
/*     */       case 0:
/*  57 */         severity = Messages.format("DefaultValidationEventHandler.Warning");
/*  58 */         retVal = true;
/*     */         break;
/*     */       case 1:
/*  61 */         severity = Messages.format("DefaultValidationEventHandler.Error");
/*  62 */         retVal = false;
/*     */         break;
/*     */       case 2:
/*  65 */         severity = Messages.format("DefaultValidationEventHandler.FatalError");
/*  66 */         retVal = false;
/*     */         break;
/*     */       
/*     */       default:
/*  70 */         assert false : Messages.format("DefaultValidationEventHandler.UnrecognizedSeverity", 
/*  71 */             Integer.valueOf(event.getSeverity()));
/*     */         break;
/*     */     } 
/*     */     
/*  75 */     String location = getLocation(event);
/*     */     
/*  77 */     System.out.println(
/*  78 */         Messages.format("DefaultValidationEventHandler.SeverityMessage", severity, event
/*     */           
/*  80 */           .getMessage(), location));
/*     */ 
/*     */ 
/*     */     
/*  84 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLocation(ValidationEvent event) {
/*  92 */     StringBuilder msg = new StringBuilder();
/*     */     
/*  94 */     ValidationEventLocator locator = event.getLocator();
/*     */     
/*  96 */     if (locator != null) {
/*     */       
/*  98 */       URL url = locator.getURL();
/*  99 */       Object obj = locator.getObject();
/* 100 */       Node node = locator.getNode();
/* 101 */       int line = locator.getLineNumber();
/*     */       
/* 103 */       if (url != null || line != -1) {
/* 104 */         msg.append("line ").append(line);
/* 105 */         if (url != null)
/* 106 */           msg.append(" of ").append(url); 
/* 107 */       } else if (obj != null) {
/* 108 */         msg.append(" obj: ").append(obj);
/* 109 */       } else if (node != null) {
/* 110 */         msg.append(" node: ").append(node);
/*     */       } 
/*     */     } else {
/* 113 */       msg.append(Messages.format("DefaultValidationEventHandler.LocationUnavailable"));
/*     */     } 
/*     */     
/* 116 */     return msg.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\helpers\DefaultValidationEventHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */