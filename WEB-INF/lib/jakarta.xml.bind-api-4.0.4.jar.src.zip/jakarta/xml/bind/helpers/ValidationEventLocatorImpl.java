/*     */ package jakarta.xml.bind.helpers;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.text.MessageFormat;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationEventLocatorImpl
/*     */   implements ValidationEventLocator
/*     */ {
/*     */   public ValidationEventLocatorImpl() {}
/*     */   
/*     */   public ValidationEventLocatorImpl(Locator loc) {
/*  60 */     if (loc == null) {
/*  61 */       throw new IllegalArgumentException(
/*  62 */           Messages.format("Shared.MustNotBeNull", "loc"));
/*     */     }
/*     */     
/*  65 */     this.url = toURL(loc.getSystemId());
/*  66 */     this.columnNumber = loc.getColumnNumber();
/*  67 */     this.lineNumber = loc.getLineNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventLocatorImpl(SAXParseException e) {
/*  83 */     if (e == null) {
/*  84 */       throw new IllegalArgumentException(
/*  85 */           Messages.format("Shared.MustNotBeNull", "e"));
/*     */     }
/*     */     
/*  88 */     this.url = toURL(e.getSystemId());
/*  89 */     this.columnNumber = e.getColumnNumber();
/*  90 */     this.lineNumber = e.getLineNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventLocatorImpl(Node _node) {
/* 104 */     if (_node == null) {
/* 105 */       throw new IllegalArgumentException(
/* 106 */           Messages.format("Shared.MustNotBeNull", "_node"));
/*     */     }
/*     */     
/* 109 */     this.node = _node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventLocatorImpl(Object _object) {
/* 123 */     if (_object == null) {
/* 124 */       throw new IllegalArgumentException(
/* 125 */           Messages.format("Shared.MustNotBeNull", "_object"));
/*     */     }
/*     */     
/* 128 */     this.object = _object;
/*     */   }
/*     */ 
/*     */   
/*     */   private static URL toURL(String systemId) {
/* 133 */     if (systemId == null || systemId.length() == 0) {
/* 134 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 138 */       return new URL(systemId);
/* 139 */     } catch (MalformedURLException e) {
/*     */ 
/*     */       
/* 142 */       return null;
/*     */     } 
/*     */   }
/*     */   
/* 146 */   private URL url = null;
/* 147 */   private int offset = -1;
/* 148 */   private int lineNumber = -1;
/* 149 */   private int columnNumber = -1;
/* 150 */   private Object object = null;
/* 151 */   private Node node = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getURL() {
/* 158 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(URL _url) {
/* 167 */     this.url = _url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 175 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOffset(int _offset) {
/* 184 */     this.offset = _offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 192 */     return this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineNumber(int _lineNumber) {
/* 201 */     this.lineNumber = _lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNumber() {
/* 209 */     return this.columnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnNumber(int _columnNumber) {
/* 218 */     this.columnNumber = _columnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject() {
/* 226 */     return this.object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObject(Object _object) {
/* 235 */     this.object = _object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode() {
/* 243 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(Node _node) {
/* 252 */     this.node = _node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 263 */     return MessageFormat.format("[node={0},object={1},url={2},line={3},col={4},offset={5}]", new Object[] {
/* 264 */           getNode(), 
/* 265 */           getObject(), 
/* 266 */           getURL(), 
/* 267 */           String.valueOf(getLineNumber()), 
/* 268 */           String.valueOf(getColumnNumber()), 
/* 269 */           String.valueOf(getOffset())
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\helpers\ValidationEventLocatorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */