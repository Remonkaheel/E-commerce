/*     */ package jakarta.xml.bind.helpers;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.attachment.AttachmentUnmarshaller;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUnmarshallerImpl
/*     */   implements Unmarshaller
/*     */ {
/*  63 */   private ValidationEventHandler eventHandler = new DefaultValidationEventHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private XMLReader reader = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private SAXParserFactory parserFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SAXParserFactory getSAXParserFactory() {
/*  79 */     if (null == this.parserFactory) {
/*  80 */       this.parserFactory = SAXParserFactory.newInstance();
/*  81 */       this.parserFactory.setNamespaceAware(true);
/*     */ 
/*     */ 
/*     */       
/*  85 */       this.parserFactory.setValidating(false);
/*     */     } 
/*  87 */     return this.parserFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLReader getXMLReader() throws JAXBException {
/*  99 */     if (this.reader == null) {
/*     */       try {
/* 101 */         this.reader = getSAXParserFactory().newSAXParser().getXMLReader();
/* 102 */       } catch (ParserConfigurationException|SAXException e) {
/* 103 */         throw new JAXBException(e);
/*     */       } 
/*     */     }
/* 106 */     return this.reader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(Source source) throws JAXBException {
/* 111 */     if (source == null) {
/* 112 */       throw new IllegalArgumentException(
/* 113 */           Messages.format("Shared.MustNotBeNull", "source"));
/*     */     }
/*     */     
/* 116 */     if (source instanceof SAXSource)
/* 117 */       return unmarshal((SAXSource)source); 
/* 118 */     if (source instanceof StreamSource)
/* 119 */       return unmarshal(streamSourceToInputSource((StreamSource)source)); 
/* 120 */     if (source instanceof DOMSource) {
/* 121 */       return unmarshal(((DOMSource)source).getNode());
/*     */     }
/*     */     
/* 124 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object unmarshal(SAXSource source) throws JAXBException {
/* 130 */     XMLReader r = source.getXMLReader();
/* 131 */     if (r == null) {
/* 132 */       r = getXMLReader();
/*     */     }
/* 134 */     return unmarshal(r, source.getInputSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object unmarshal(XMLReader paramXMLReader, InputSource paramInputSource) throws JAXBException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object unmarshal(InputSource source) throws JAXBException {
/* 147 */     if (source == null) {
/* 148 */       throw new IllegalArgumentException(
/* 149 */           Messages.format("Shared.MustNotBeNull", "source"));
/*     */     }
/*     */     
/* 152 */     return unmarshal(getXMLReader(), source);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object unmarshal(String url) throws JAXBException {
/* 157 */     return unmarshal(new InputSource(url));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object unmarshal(URL url) throws JAXBException {
/* 162 */     if (url == null) {
/* 163 */       throw new IllegalArgumentException(
/* 164 */           Messages.format("Shared.MustNotBeNull", "url"));
/*     */     }
/*     */     
/* 167 */     return unmarshal(url.toExternalForm());
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object unmarshal(File f) throws JAXBException {
/* 172 */     if (f == null) {
/* 173 */       throw new IllegalArgumentException(
/* 174 */           Messages.format("Shared.MustNotBeNull", "file"));
/*     */     }
/*     */     
/*     */     try {
/* 178 */       return unmarshal(new BufferedInputStream(new FileInputStream(f)));
/* 179 */     } catch (FileNotFoundException e) {
/* 180 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object unmarshal(InputStream is) throws JAXBException {
/* 188 */     if (is == null) {
/* 189 */       throw new IllegalArgumentException(
/* 190 */           Messages.format("Shared.MustNotBeNull", "is"));
/*     */     }
/*     */     
/* 193 */     InputSource isrc = new InputSource(is);
/* 194 */     return unmarshal(isrc);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object unmarshal(Reader reader) throws JAXBException {
/* 199 */     if (reader == null) {
/* 200 */       throw new IllegalArgumentException(
/* 201 */           Messages.format("Shared.MustNotBeNull", "reader"));
/*     */     }
/*     */     
/* 204 */     InputSource isrc = new InputSource(reader);
/* 205 */     return unmarshal(isrc);
/*     */   }
/*     */ 
/*     */   
/*     */   private static InputSource streamSourceToInputSource(StreamSource ss) {
/* 210 */     InputSource is = new InputSource();
/* 211 */     is.setSystemId(ss.getSystemId());
/* 212 */     is.setByteStream(ss.getInputStream());
/* 213 */     is.setCharacterStream(ss.getReader());
/*     */     
/* 215 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventHandler(ValidationEventHandler handler) throws JAXBException {
/* 237 */     if (handler == null) {
/* 238 */       this.eventHandler = new DefaultValidationEventHandler();
/*     */     } else {
/* 240 */       this.eventHandler = handler;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventHandler getEventHandler() throws JAXBException {
/* 256 */     return this.eventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnmarshalException createUnmarshalException(SAXException e) {
/* 281 */     Exception nested = e.getException();
/* 282 */     if (nested instanceof UnmarshalException) {
/* 283 */       return (UnmarshalException)nested;
/*     */     }
/* 285 */     if (nested instanceof RuntimeException)
/*     */     {
/*     */ 
/*     */       
/* 289 */       throw (RuntimeException)nested;
/*     */     }
/*     */ 
/*     */     
/* 293 */     if (nested != null) {
/* 294 */       return new UnmarshalException(nested);
/*     */     }
/* 296 */     return new UnmarshalException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 309 */     if (name == null) {
/* 310 */       throw new IllegalArgumentException(
/* 311 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */     
/* 314 */     throw new PropertyException(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 327 */     if (name == null) {
/* 328 */       throw new IllegalArgumentException(
/* 329 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */     
/* 332 */     throw new PropertyException(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLEventReader reader) throws JAXBException {
/* 338 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLStreamReader reader) throws JAXBException {
/* 344 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Node node, Class<T> expectedType) throws JAXBException {
/* 349 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Source source, Class<T> expectedType) throws JAXBException {
/* 354 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLStreamReader reader, Class<T> expectedType) throws JAXBException {
/* 359 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLEventReader reader, Class<T> expectedType) throws JAXBException {
/* 364 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSchema(Schema schema) {
/* 369 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/* 374 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> void setAdapter(A adapter) {
/* 380 */     if (adapter == null) {
/* 381 */       throw new IllegalArgumentException();
/*     */     }
/* 383 */     setAdapter(adapter.getClass(), adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> void setAdapter(Class<A> type, A adapter) {
/* 388 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> A getAdapter(Class<A> type) {
/* 393 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttachmentUnmarshaller(AttachmentUnmarshaller au) {
/* 398 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public AttachmentUnmarshaller getAttachmentUnmarshaller() {
/* 403 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListener(Unmarshaller.Listener listener) {
/* 408 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Unmarshaller.Listener getListener() {
/* 413 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\helpers\AbstractUnmarshallerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */