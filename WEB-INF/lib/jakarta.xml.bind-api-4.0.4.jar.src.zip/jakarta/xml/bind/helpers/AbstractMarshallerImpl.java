/*     */ package jakarta.xml.bind.helpers;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.attachment.AttachmentMarshaller;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMarshallerImpl
/*     */   implements Marshaller
/*     */ {
/*  55 */   private ValidationEventHandler eventHandler = new DefaultValidationEventHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private String encoding = "UTF-8";
/*     */ 
/*     */   
/*  65 */   private String schemaLocation = null;
/*     */ 
/*     */   
/*  68 */   private String noNSSchemaLocation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean formattedOutput = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fragment = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void marshal(Object obj, OutputStream os) throws JAXBException {
/*  85 */     checkNotNull(obj, "obj", os, "os");
/*  86 */     marshal(obj, new StreamResult(os));
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Object jaxbElement, File output) throws JAXBException {
/*  91 */     checkNotNull(jaxbElement, "jaxbElement", output, "output");
/*     */     try {
/*  93 */       OutputStream os = new BufferedOutputStream(new FileOutputStream(output)); 
/*  94 */       try { marshal(jaxbElement, new StreamResult(os));
/*  95 */         os.close(); } catch (Throwable throwable) { try { os.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/*  96 */     } catch (IOException e) {
/*  97 */       throw new JAXBException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void marshal(Object obj, Writer w) throws JAXBException {
/* 105 */     checkNotNull(obj, "obj", w, "writer");
/* 106 */     marshal(obj, new StreamResult(w));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void marshal(Object obj, ContentHandler handler) throws JAXBException {
/* 113 */     checkNotNull(obj, "obj", handler, "handler");
/* 114 */     marshal(obj, new SAXResult(handler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void marshal(Object obj, Node node) throws JAXBException {
/* 121 */     checkNotNull(obj, "obj", node, "node");
/* 122 */     marshal(obj, new DOMResult(node));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode(Object obj) throws JAXBException {
/* 135 */     checkNotNull(obj, "obj", Boolean.TRUE, "foo");
/*     */     
/* 137 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getEncoding() {
/* 146 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setEncoding(String encoding) {
/* 156 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSchemaLocation() {
/* 165 */     return this.schemaLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSchemaLocation(String location) {
/* 174 */     this.schemaLocation = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getNoNSSchemaLocation() {
/* 184 */     return this.noNSSchemaLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setNoNSSchemaLocation(String location) {
/* 193 */     this.noNSSchemaLocation = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFormattedOutput() {
/* 203 */     return this.formattedOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setFormattedOutput(boolean v) {
/* 212 */     this.formattedOutput = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFragment() {
/* 223 */     return this.fragment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setFragment(boolean v) {
/* 232 */     this.fragment = v;
/*     */   }
/*     */ 
/*     */   
/* 236 */   static String[] aliases = new String[] { "UTF-8", "UTF8", "UTF-16", "Unicode", "UTF-16BE", "UnicodeBigUnmarked", "UTF-16LE", "UnicodeLittleUnmarked", "US-ASCII", "ASCII", "TIS-620", "TIS620", "ISO-10646-UCS-2", "Unicode", "EBCDIC-CP-US", "cp037", "EBCDIC-CP-CA", "cp037", "EBCDIC-CP-NL", "cp037", "EBCDIC-CP-WT", "cp037", "EBCDIC-CP-DK", "cp277", "EBCDIC-CP-NO", "cp277", "EBCDIC-CP-FI", "cp278", "EBCDIC-CP-SE", "cp278", "EBCDIC-CP-IT", "cp280", "EBCDIC-CP-ES", "cp284", "EBCDIC-CP-GB", "cp285", "EBCDIC-CP-FR", "cp297", "EBCDIC-CP-AR1", "cp420", "EBCDIC-CP-HE", "cp424", "EBCDIC-CP-BE", "cp500", "EBCDIC-CP-CH", "cp500", "EBCDIC-CP-ROECE", "cp870", "EBCDIC-CP-YU", "cp870", "EBCDIC-CP-IS", "cp871", "EBCDIC-CP-AR2", "cp918" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getJavaEncoding(String encoding) throws UnsupportedEncodingException {
/*     */     try {
/* 288 */       "1".getBytes(encoding);
/* 289 */       return encoding;
/* 290 */     } catch (UnsupportedEncodingException e) {
/*     */       
/* 292 */       for (int i = 0; i < aliases.length; i += 2) {
/* 293 */         if (encoding.equals(aliases[i])) {
/* 294 */           "1".getBytes(aliases[i + 1]);
/* 295 */           return aliases[i + 1];
/*     */         } 
/*     */       } 
/*     */       
/* 299 */       throw new UnsupportedEncodingException(encoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 320 */     if (name == null) {
/* 321 */       throw new IllegalArgumentException(
/* 322 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */ 
/*     */     
/* 326 */     if ("jaxb.encoding".equals(name)) {
/* 327 */       checkString(name, value);
/* 328 */       setEncoding((String)value);
/*     */       return;
/*     */     } 
/* 331 */     if ("jaxb.formatted.output".equals(name)) {
/* 332 */       checkBoolean(name, value);
/* 333 */       setFormattedOutput(((Boolean)value).booleanValue());
/*     */       return;
/*     */     } 
/* 336 */     if ("jaxb.noNamespaceSchemaLocation".equals(name)) {
/* 337 */       checkString(name, value);
/* 338 */       setNoNSSchemaLocation((String)value);
/*     */       return;
/*     */     } 
/* 341 */     if ("jaxb.schemaLocation".equals(name)) {
/* 342 */       checkString(name, value);
/* 343 */       setSchemaLocation((String)value);
/*     */       return;
/*     */     } 
/* 346 */     if ("jaxb.fragment".equals(name)) {
/* 347 */       checkBoolean(name, value);
/* 348 */       setFragment(((Boolean)value).booleanValue());
/*     */       
/*     */       return;
/*     */     } 
/* 352 */     throw new PropertyException(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 365 */     if (name == null) {
/* 366 */       throw new IllegalArgumentException(
/* 367 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */ 
/*     */     
/* 371 */     if ("jaxb.encoding".equals(name))
/* 372 */       return getEncoding(); 
/* 373 */     if ("jaxb.formatted.output".equals(name))
/* 374 */       return isFormattedOutput() ? Boolean.TRUE : Boolean.FALSE; 
/* 375 */     if ("jaxb.noNamespaceSchemaLocation".equals(name))
/* 376 */       return getNoNSSchemaLocation(); 
/* 377 */     if ("jaxb.schemaLocation".equals(name))
/* 378 */       return getSchemaLocation(); 
/* 379 */     if ("jaxb.fragment".equals(name)) {
/* 380 */       return isFragment() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/* 382 */     throw new PropertyException(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventHandler getEventHandler() throws JAXBException {
/* 389 */     return this.eventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventHandler(ValidationEventHandler handler) throws JAXBException {
/* 399 */     if (handler == null) {
/* 400 */       this.eventHandler = new DefaultValidationEventHandler();
/*     */     } else {
/* 402 */       this.eventHandler = handler;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkBoolean(String name, Object value) throws PropertyException {
/* 413 */     if (!(value instanceof Boolean)) {
/* 414 */       throw new PropertyException(
/* 415 */           Messages.format("AbstractMarshallerImpl.MustBeBoolean", name));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkString(String name, Object value) throws PropertyException {
/* 422 */     if (!(value instanceof String)) {
/* 423 */       throw new PropertyException(
/* 424 */           Messages.format("AbstractMarshallerImpl.MustBeString", name));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkNotNull(Object o1, String o1Name, Object o2, String o2Name) {
/* 433 */     if (o1 == null) {
/* 434 */       throw new IllegalArgumentException(
/* 435 */           Messages.format("Shared.MustNotBeNull", o1Name));
/*     */     }
/* 437 */     if (o2 == null) {
/* 438 */       throw new IllegalArgumentException(
/* 439 */           Messages.format("Shared.MustNotBeNull", o2Name));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshal(Object obj, XMLEventWriter writer) throws JAXBException {
/* 447 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshal(Object obj, XMLStreamWriter writer) throws JAXBException {
/* 454 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSchema(Schema schema) {
/* 459 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/* 464 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> void setAdapter(A adapter) {
/* 470 */     if (adapter == null) {
/* 471 */       throw new IllegalArgumentException();
/*     */     }
/* 473 */     setAdapter(adapter.getClass(), adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> void setAdapter(Class<A> type, A adapter) {
/* 478 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends jakarta.xml.bind.annotation.adapters.XmlAdapter<?, ?>> A getAdapter(Class<A> type) {
/* 483 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttachmentMarshaller(AttachmentMarshaller am) {
/* 488 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public AttachmentMarshaller getAttachmentMarshaller() {
/* 493 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListener(Marshaller.Listener listener) {
/* 498 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Marshaller.Listener getListener() {
/* 503 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\helpers\AbstractMarshallerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */