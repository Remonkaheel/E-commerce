/*     */ package jakarta.xml.bind.helpers;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationEventImpl
/*     */   implements ValidationEvent
/*     */ {
/*     */   private int severity;
/*     */   private String message;
/*     */   private Throwable linkedException;
/*     */   private ValidationEventLocator locator;
/*     */   
/*     */   public ValidationEventImpl(int _severity, String _message, ValidationEventLocator _locator) {
/*  48 */     this(_severity, _message, _locator, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventImpl(int _severity, String _message, ValidationEventLocator _locator, Throwable _linkedException) {
/*  67 */     setSeverity(_severity);
/*  68 */     this.message = _message;
/*  69 */     this.locator = _locator;
/*  70 */     this.linkedException = _linkedException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeverity() {
/*  80 */     return this.severity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeverity(int _severity) {
/*  93 */     if (_severity != 0 && _severity != 1 && _severity != 2)
/*     */     {
/*     */       
/*  96 */       throw new IllegalArgumentException(
/*  97 */           Messages.format("ValidationEventImpl.IllegalSeverity"));
/*     */     }
/*     */     
/* 100 */     this.severity = _severity;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 105 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessage(String _message) {
/* 113 */     this.message = _message;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getLinkedException() {
/* 118 */     return this.linkedException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLinkedException(Throwable _linkedException) {
/* 126 */     this.linkedException = _linkedException;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValidationEventLocator getLocator() {
/* 131 */     return this.locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocator(ValidationEventLocator _locator) {
/* 139 */     this.locator = _locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     String s;
/* 151 */     switch (getSeverity()) { case 0:
/* 152 */         s = "WARNING"; break;
/* 153 */       case 1: s = "ERROR"; break;
/* 154 */       case 2: s = "FATAL_ERROR"; break;
/* 155 */       default: s = String.valueOf(getSeverity()); break; }
/*     */     
/* 157 */     return MessageFormat.format("[severity={0},message={1},locator={2}]", new Object[] { s, 
/*     */           
/* 159 */           getMessage(), 
/* 160 */           getLocator() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\helpers\ValidationEventImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */