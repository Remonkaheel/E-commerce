/*    */ package jakarta.xml.bind.util;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEvent;
/*    */ import jakarta.xml.bind.ValidationEventHandler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationEventCollector
/*    */   implements ValidationEventHandler
/*    */ {
/* 36 */   private final List<ValidationEvent> events = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ValidationEvent[] getEvents() {
/* 49 */     return this.events.<ValidationEvent>toArray(new ValidationEvent[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 56 */     this.events.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasEvents() {
/* 67 */     return !this.events.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleEvent(ValidationEvent event) {
/* 72 */     this.events.add(event);
/*    */     
/* 74 */     boolean retVal = true;
/* 75 */     switch (event.getSeverity())
/*    */     { case 0:
/*    */       case 1:
/* 78 */         retVal = true;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 90 */         return retVal;case 2: retVal = false; return retVal; }  _assert(false, Messages.format("ValidationEventCollector.UnrecognizedSeverity", Integer.valueOf(event.getSeverity()))); return retVal;
/*    */   }
/*    */   
/*    */   private static void _assert(boolean b, String msg) {
/* 94 */     if (!b)
/* 95 */       throw new InternalError(msg); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bin\\util\ValidationEventCollector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */