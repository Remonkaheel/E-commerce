/*    */ package jakarta.xml.bind;
/*    */ 
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GetPropertyAction
/*    */   implements PrivilegedAction<String>
/*    */ {
/*    */   private final String propertyName;
/*    */   
/*    */   public GetPropertyAction(String propertyName) {
/* 23 */     this.propertyName = propertyName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String run() {
/* 28 */     return System.getProperty(this.propertyName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\GetPropertyAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */