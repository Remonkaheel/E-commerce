/*    */ package jakarta.xml.bind;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ class Messages
/*    */ {
/*    */   static final String PROVIDER_NOT_FOUND = "ContextFinder.ProviderNotFound";
/*    */   static final String DEFAULT_PROVIDER_NOT_FOUND = "ContextFinder.DefaultProviderNotFound";
/*    */   static final String COULD_NOT_INSTANTIATE = "ContextFinder.CouldNotInstantiate";
/*    */   static final String CANT_FIND_PROPERTIES_FILE = "ContextFinder.CantFindPropertiesFile";
/*    */   static final String CANT_MIX_PROVIDERS = "ContextFinder.CantMixProviders";
/*    */   static final String MISSING_PROPERTY = "ContextFinder.MissingProperty";
/*    */   static final String NO_PACKAGE_IN_CONTEXTPATH = "ContextFinder.NoPackageInContextPath";
/*    */   static final String NAME_VALUE = "PropertyException.NameValue";
/*    */   static final String CONVERTER_MUST_NOT_BE_NULL = "DatatypeConverter.ConverterMustNotBeNull";
/*    */   static final String ILLEGAL_CAST = "JAXBContext.IllegalCast";
/*    */   static final String ERROR_LOAD_CLASS = "ContextFinder.ErrorLoadClass";
/*    */   static final String JAXB_CLASSES_NOT_OPEN = "JAXBClasses.notOpen";
/*    */   
/*    */   static String format(String property) {
/* 22 */     return format(property, (Object[])null);
/*    */   }
/*    */   
/*    */   static String format(String property, Object arg1) {
/* 26 */     return format(property, new Object[] { arg1 });
/*    */   }
/*    */   
/*    */   static String format(String property, Object arg1, Object arg2) {
/* 30 */     return format(property, new Object[] { arg1, arg2 });
/*    */   }
/*    */   
/*    */   static String format(String property, Object arg1, Object arg2, Object arg3) {
/* 34 */     return format(property, new Object[] { arg1, arg2, arg3 });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static String format(String property, Object[] args) {
/* 41 */     String text = ResourceBundle.getBundle(Messages.class.getName()).getString(property);
/* 42 */     return MessageFormat.format(text, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */