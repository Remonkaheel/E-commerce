package jakarta.xml.bind;

public interface ValidationEvent {
  public static final int WARNING = 0;
  
  public static final int ERROR = 1;
  
  public static final int FATAL_ERROR = 2;
  
  int getSeverity();
  
  String getMessage();
  
  Throwable getLinkedException();
  
  ValidationEventLocator getLocator();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\ValidationEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */