/*     */ package jakarta.xml.bind;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ModuleUtil
/*     */ {
/*  30 */   private static final Logger LOGGER = Logger.getLogger("jakarta.xml.bind");
/*     */   
/*     */   private static final boolean JPMS_SUPPORTED;
/*     */ 
/*     */   
/*     */   static {
/*  36 */     boolean b = false;
/*     */     try {
/*  38 */       JAXBContext.class.getModule();
/*  39 */       b = true;
/*  40 */     } catch (NoSuchMethodError nsme) {
/*     */       
/*  42 */       b = false;
/*     */     } 
/*  44 */     JPMS_SUPPORTED = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<?>[] getClassesFromContextPath(String contextPath, ClassLoader classLoader) throws JAXBException {
/*  52 */     List<Class<?>> classes = new ArrayList<>();
/*  53 */     if (contextPath == null || contextPath.isEmpty()) {
/*  54 */       return (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[0]);
/*     */     }
/*     */     
/*  57 */     String[] tokens = contextPath.split(":");
/*  58 */     for (String pkg : tokens) {
/*     */ 
/*     */       
/*     */       try {
/*  62 */         Class<?> o = classLoader.loadClass(pkg + ".ObjectFactory");
/*  63 */         classes.add(o);
/*     */       }
/*  65 */       catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */           
/*  71 */           Class<?> firstByJaxbIndex = findFirstByJaxbIndex(pkg, classLoader);
/*  72 */           if (firstByJaxbIndex != null) {
/*  73 */             classes.add(firstByJaxbIndex);
/*     */           }
/*  75 */         } catch (IOException e) {
/*  76 */           throw new JAXBException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*  80 */     if (LOGGER.isLoggable(Level.FINE)) {
/*  81 */       LOGGER.log(Level.FINE, "Resolved classes from context path: {0}", classes);
/*     */     }
/*  83 */     return (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<?> findFirstByJaxbIndex(String pkg, ClassLoader classLoader) throws IOException, JAXBException {
/*  90 */     String resource = pkg.replace('.', '/') + "/jaxb.index";
/*  91 */     InputStream resourceAsStream = classLoader.getResourceAsStream(resource);
/*     */     
/*  93 */     if (resourceAsStream == null) {
/*  94 */       return null;
/*     */     }
/*     */     
/*  97 */     BufferedReader in = new BufferedReader(new InputStreamReader(resourceAsStream, StandardCharsets.UTF_8)); 
/*  98 */     try { String className = in.readLine();
/*  99 */       while (className != null)
/* 100 */       { className = className.trim();
/* 101 */         if (className.startsWith("#") || className.isEmpty()) {
/* 102 */           className = in.readLine();
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 107 */         try { Class<?> clazz = classLoader.loadClass(pkg + "." + pkg);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 113 */           in.close(); return clazz; } catch (ClassNotFoundException e) { throw new JAXBException(Messages.format("ContextFinder.ErrorLoadClass", className, pkg), e); }  }  in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 114 */      return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void delegateAddOpensToImplModule(Class<?>[] classes, Class<?> factorySPI) throws JAXBException {
/* 127 */     if (JPMS_SUPPORTED) {
/* 128 */       Module implModule = factorySPI.getModule();
/*     */       
/* 130 */       Module jaxbModule = JAXBContext.class.getModule();
/*     */       
/* 132 */       if (!jaxbModule.isNamed()) {
/*     */         
/* 134 */         if (LOGGER.isLoggable(Level.FINE)) {
/* 135 */           LOGGER.log(Level.FINE, "Using jakarta.xml.bind-api on the class path.");
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 140 */       for (Class<?> cls : classes) {
/*     */         
/* 142 */         Class<?> jaxbClass = cls.isArray() ? cls.getComponentType() : cls;
/*     */         
/* 144 */         Module classModule = jaxbClass.getModule();
/* 145 */         String packageName = jaxbClass.getPackageName();
/*     */         
/* 147 */         if (classModule.isNamed() && !classModule.getName().equals("java.base")) {
/*     */ 
/*     */ 
/*     */           
/* 151 */           if (!classModule.isOpen(packageName, jaxbModule)) {
/* 152 */             throw new JAXBException(Messages.format("JAXBClasses.notOpen", packageName, jaxbClass
/* 153 */                   .getName(), classModule.getName()));
/*     */           }
/*     */           
/* 156 */           classModule.addOpens(packageName, implModule);
/* 157 */           if (LOGGER.isLoggable(Level.FINE)) {
/* 158 */             LOGGER.log(Level.FINE, "Propagating openness of package {0} in {1} to {2}.", (Object[])new String[] { packageName, classModule
/* 159 */                   .getName(), implModule.getName() });
/*     */           }
/*     */         } 
/*     */       } 
/* 163 */     } else if (LOGGER.isLoggable(Level.FINE)) {
/* 164 */       LOGGER.log(Level.FINE, "Using jakarta.xml.bind-api with no JPMS related APIs, such as Class::getModule.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\jakarta\xml\bind\ModuleUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */