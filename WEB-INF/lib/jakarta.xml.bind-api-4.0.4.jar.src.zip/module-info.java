module jakarta.xml.bind {
  requires java.base;
  requires transitive jakarta.activation;
  requires transitive java.xml;
  requires java.logging;
  
  exports jakarta.xml.bind;
  exports jakarta.xml.bind.annotation;
  exports jakarta.xml.bind.annotation.adapters;
  exports jakarta.xml.bind.attachment;
  exports jakarta.xml.bind.helpers;
  exports jakarta.xml.bind.util;
  
  uses jakarta.xml.bind.JAXBContextFactory;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.xml.bind-api-4.0.4.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */