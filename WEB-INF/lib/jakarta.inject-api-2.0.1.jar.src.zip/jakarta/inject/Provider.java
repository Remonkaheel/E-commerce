package jakarta.inject;

public interface Provider<T> {
  T get();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.inject-api-2.0.1.jar!\jakarta\inject\Provider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */