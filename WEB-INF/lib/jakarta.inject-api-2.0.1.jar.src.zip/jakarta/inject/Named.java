package jakarta.inject;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Qualifier
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Named {
  String value() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.inject-api-2.0.1.jar!\jakarta\inject\Named.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */