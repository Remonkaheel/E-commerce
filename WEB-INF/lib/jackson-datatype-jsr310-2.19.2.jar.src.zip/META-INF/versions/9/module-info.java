module com.fasterxml.jackson.datatype.jsr310 {
  requires com.fasterxml.jackson.annotation;
  requires com.fasterxml.jackson.core;
  requires com.fasterxml.jackson.databind;
  requires java.base;
  
  exports com.fasterxml.jackson.datatype.jsr310;
  exports com.fasterxml.jackson.datatype.jsr310.deser;
  exports com.fasterxml.jackson.datatype.jsr310.deser.key;
  exports com.fasterxml.jackson.datatype.jsr310.ser;
  exports com.fasterxml.jackson.datatype.jsr310.ser.key;
  
  opens com.fasterxml.jackson.datatype.jsr310.deser;
  opens com.fasterxml.jackson.datatype.jsr310.deser.key;
  opens com.fasterxml.jackson.datatype.jsr310.ser;
  opens com.fasterxml.jackson.datatype.jsr310.ser.key;
  
  provides com.fasterxml.jackson.databind.Module with com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */