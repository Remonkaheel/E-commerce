/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.ChronoField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeSerializer
/*     */   extends JSR310FormattedSerializerBase<LocalDateTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   public static final LocalDateTimeSerializer INSTANCE = new LocalDateTimeSerializer();
/*     */   
/*     */   protected LocalDateTimeSerializer() {
/*  44 */     this((DateTimeFormatter)null);
/*     */   }
/*     */   
/*     */   public LocalDateTimeSerializer(DateTimeFormatter f) {
/*  48 */     super(LocalDateTime.class, f);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateTimeSerializer(LocalDateTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter f) {
/*  53 */     super(base, useTimestamp, useNanoseconds, f, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<LocalDateTime> withFormat(Boolean useTimestamp, DateTimeFormatter f, JsonFormat.Shape shape) {
/*  58 */     return new LocalDateTimeSerializer(this, useTimestamp, this._useNanoseconds, f);
/*     */   }
/*     */   
/*     */   protected DateTimeFormatter _defaultFormatter() {
/*  62 */     return DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(LocalDateTime value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  69 */     if (useTimestamp(provider)) {
/*  70 */       g.writeStartArray();
/*  71 */       _serializeAsArrayContents(value, g, provider);
/*  72 */       g.writeEndArray();
/*     */     } else {
/*  74 */       DateTimeFormatter dtf = this._formatter;
/*  75 */       if (dtf == null) {
/*  76 */         dtf = _defaultFormatter();
/*     */       }
/*  78 */       g.writeString(value.format(dtf));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(LocalDateTime value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  86 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  87 */         .typeId(value, serializationShape(provider)));
/*     */     
/*  89 */     if (typeIdDef != null && typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  90 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  92 */       DateTimeFormatter dtf = this._formatter;
/*  93 */       if (dtf == null) {
/*  94 */         dtf = _defaultFormatter();
/*     */       }
/*  96 */       g.writeString(value.format(dtf));
/*     */     } 
/*  98 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void _serializeAsArrayContents(LocalDateTime value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 104 */     g.writeNumber(value.getYear());
/* 105 */     g.writeNumber(value.getMonthValue());
/* 106 */     g.writeNumber(value.getDayOfMonth());
/* 107 */     g.writeNumber(value.getHour());
/* 108 */     g.writeNumber(value.getMinute());
/* 109 */     int secs = value.getSecond();
/* 110 */     int nanos = value.getNano();
/* 111 */     if (secs > 0 || nanos > 0) {
/* 112 */       g.writeNumber(secs);
/* 113 */       if (nanos > 0) {
/* 114 */         if (useNanoseconds(provider)) {
/* 115 */           g.writeNumber(nanos);
/*     */         } else {
/* 117 */           g.writeNumber(value.get(ChronoField.MILLI_OF_SECOND));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 125 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 130 */     return new LocalDateTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\LocalDateTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */