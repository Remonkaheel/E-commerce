/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.ChronoField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeSerializer
/*     */   extends JSR310FormattedSerializerBase<OffsetTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   public static final OffsetTimeSerializer INSTANCE = new OffsetTimeSerializer();
/*     */   
/*     */   protected OffsetTimeSerializer() {
/*  44 */     super(OffsetTime.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected OffsetTimeSerializer(OffsetTimeSerializer base, Boolean useTimestamp, DateTimeFormatter dtf) {
/*  49 */     this(base, useTimestamp, (Boolean)null, dtf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected OffsetTimeSerializer(OffsetTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf) {
/*  54 */     super(base, useTimestamp, useNanoseconds, dtf, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected OffsetTimeSerializer withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/*  59 */     return new OffsetTimeSerializer(this, useTimestamp, dtf);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(OffsetTime time, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  65 */     if (useTimestamp(provider)) {
/*  66 */       g.writeStartArray();
/*  67 */       _serializeAsArrayContents(time, g, provider);
/*  68 */       g.writeEndArray();
/*     */     } else {
/*  70 */       String str = (this._formatter == null) ? time.toString() : time.format(this._formatter);
/*  71 */       g.writeString(str);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(OffsetTime value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  79 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  80 */         .typeId(value, serializationShape(provider)));
/*     */     
/*  82 */     if (typeIdDef != null && typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*     */       
/*  84 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  86 */       String str = (this._formatter == null) ? value.toString() : value.format(this._formatter);
/*  87 */       g.writeString(str);
/*     */     } 
/*  89 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void _serializeAsArrayContents(OffsetTime value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  95 */     g.writeNumber(value.getHour());
/*  96 */     g.writeNumber(value.getMinute());
/*  97 */     int secs = value.getSecond();
/*  98 */     int nanos = value.getNano();
/*  99 */     if (secs > 0 || nanos > 0) {
/* 100 */       g.writeNumber(secs);
/* 101 */       if (nanos > 0) {
/* 102 */         if (useNanoseconds(provider)) {
/* 103 */           g.writeNumber(nanos);
/*     */         } else {
/* 105 */           g.writeNumber(value.get(ChronoField.MILLI_OF_SECOND));
/*     */         } 
/*     */       }
/*     */     } 
/* 109 */     g.writeString(value.getOffset().toString());
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 114 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 119 */     return new OffsetTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\OffsetTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */