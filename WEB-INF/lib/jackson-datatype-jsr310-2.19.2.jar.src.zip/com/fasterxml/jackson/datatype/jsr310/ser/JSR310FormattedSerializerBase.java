/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.type.CollectionType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class JSR310FormattedSerializerBase<T>
/*     */   extends JSR310SerializerBase<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Boolean _useTimestamp;
/*     */   protected final Boolean _useNanoseconds;
/*     */   protected final DateTimeFormatter _formatter;
/*     */   protected final JsonFormat.Shape _shape;
/*     */   protected volatile transient JavaType _integerListType;
/*     */   
/*     */   protected JSR310FormattedSerializerBase(Class<T> supportedType) {
/*  79 */     this(supportedType, (DateTimeFormatter)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase(Class<T> supportedType, DateTimeFormatter formatter) {
/*  84 */     super(supportedType);
/*  85 */     this._useTimestamp = null;
/*  86 */     this._useNanoseconds = null;
/*  87 */     this._shape = null;
/*  88 */     this._formatter = formatter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase(JSR310FormattedSerializerBase<?> base, Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/*  94 */     this(base, useTimestamp, (Boolean)null, dtf, shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase(JSR310FormattedSerializerBase<?> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/* 101 */     super(base.handledType());
/* 102 */     this._useTimestamp = useTimestamp;
/* 103 */     this._useNanoseconds = useNanoseconds;
/* 104 */     this._formatter = dtf;
/* 105 */     this._shape = shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JSR310FormattedSerializerBase<?> withFormat(Boolean paramBoolean, DateTimeFormatter paramDateTimeFormatter, JsonFormat.Shape paramShape);
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId) {
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds) {
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
/* 132 */     JsonFormat.Value format = findFormatOverrides(prov, property, handledType());
/* 133 */     if (format != null) {
/* 134 */       Boolean useTimestamp = null;
/*     */ 
/*     */       
/* 137 */       JsonFormat.Shape shape = format.getShape();
/* 138 */       if (shape == JsonFormat.Shape.ARRAY || shape.isNumeric()) {
/* 139 */         useTimestamp = Boolean.TRUE;
/*     */       } else {
/* 141 */         useTimestamp = (shape == JsonFormat.Shape.STRING) ? Boolean.FALSE : null;
/*     */       } 
/* 143 */       DateTimeFormatter dtf = this._formatter;
/*     */ 
/*     */       
/* 146 */       if (format.hasPattern()) {
/* 147 */         dtf = _useDateTimeFormatter(prov, format);
/*     */       }
/* 149 */       JSR310FormattedSerializerBase<?> ser = this;
/* 150 */       if (shape != this._shape || useTimestamp != this._useTimestamp || dtf != this._formatter) {
/* 151 */         ser = ser.withFormat(useTimestamp, dtf, shape);
/*     */       }
/* 153 */       Boolean writeZoneId = format.getFeature(JsonFormat.Feature.WRITE_DATES_WITH_ZONE_ID);
/* 154 */       Boolean writeNanoseconds = format.getFeature(JsonFormat.Feature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
/* 155 */       if (writeZoneId != null || writeNanoseconds != null) {
/* 156 */         ser = ser.withFeatures(writeZoneId, writeNanoseconds);
/*     */       }
/* 158 */       return (JsonSerializer<?>)ser;
/*     */     } 
/* 160 */     return (JsonSerializer<?>)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 170 */     return (JsonNode)createSchemaNode(
/* 171 */         provider.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS) ? "array" : "string", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 178 */     if (useTimestamp(visitor.getProvider())) {
/* 179 */       _acceptTimestampVisitor(visitor, typeHint);
/*     */     } else {
/* 181 */       JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 182 */       if (v2 != null) {
/* 183 */         v2.format(JsonValueFormat.DATE_TIME);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 192 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(_integerListType(visitor.getProvider()));
/* 193 */     if (v2 != null)
/* 194 */       v2.itemsFormat(JsonFormatTypes.INTEGER); 
/*     */   }
/*     */   
/*     */   protected JavaType _integerListType(SerializerProvider prov) {
/*     */     CollectionType collectionType;
/* 199 */     JavaType t = this._integerListType;
/* 200 */     if (t == null) {
/*     */       
/* 202 */       collectionType = prov.getTypeFactory().constructCollectionType(List.class, Integer.class);
/* 203 */       this._integerListType = (JavaType)collectionType;
/*     */     } 
/* 205 */     return (JavaType)collectionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationFeature getTimestampsFeature() {
/* 219 */     return SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;
/*     */   }
/*     */   
/*     */   protected boolean useTimestamp(SerializerProvider ctxt) {
/* 223 */     if (this._useTimestamp != null) {
/* 224 */       return this._useTimestamp.booleanValue();
/*     */     }
/* 226 */     if (this._shape != null) {
/* 227 */       if (this._shape == JsonFormat.Shape.STRING) {
/* 228 */         return false;
/*     */       }
/* 230 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/* 231 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 235 */     return (this._formatter == null && useTimestampFromGlobalDefaults(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean useTimestampFromGlobalDefaults(SerializerProvider ctxt) {
/* 240 */     return (ctxt != null && ctxt
/* 241 */       .isEnabled(getTimestampsFeature()));
/*     */   }
/*     */   
/*     */   protected boolean _useTimestampExplicitOnly(SerializerProvider provider) {
/* 245 */     if (this._useTimestamp != null) {
/* 246 */       return this._useTimestamp.booleanValue();
/*     */     }
/* 248 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean useNanoseconds(SerializerProvider provider) {
/* 252 */     if (this._useNanoseconds != null) {
/* 253 */       return this._useNanoseconds.booleanValue();
/*     */     }
/* 255 */     if (this._shape != null) {
/* 256 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/* 257 */         return false;
/*     */       }
/* 259 */       if (this._shape == JsonFormat.Shape.NUMBER_FLOAT) {
/* 260 */         return true;
/*     */       }
/*     */     } 
/* 263 */     return (provider != null && provider
/* 264 */       .isEnabled(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS));
/*     */   }
/*     */ 
/*     */   
/*     */   protected DateTimeFormatter _useDateTimeFormatter(SerializerProvider prov, JsonFormat.Value format) {
/*     */     DateTimeFormatter dtf;
/* 270 */     String pattern = format.getPattern();
/* 271 */     Locale locale = format.hasLocale() ? format.getLocale() : prov.getLocale();
/* 272 */     if (locale == null) {
/* 273 */       dtf = DateTimeFormatter.ofPattern(pattern);
/*     */     } else {
/* 275 */       dtf = DateTimeFormatter.ofPattern(pattern, locale);
/*     */     } 
/*     */ 
/*     */     
/* 279 */     if (format.hasTimeZone()) {
/* 280 */       dtf = dtf.withZone(format.getTimeZone().toZoneId());
/*     */     }
/* 282 */     return dtf;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\JSR310FormattedSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */