/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.format.ResolverStyle;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JSR310DateTimeDeserializerBase<T>
/*     */   extends JSR310DeserializerBase<T>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   protected final DateTimeFormatter _formatter;
/*     */   protected final JsonFormat.Shape _shape;
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(Class<T> supportedType, DateTimeFormatter f) {
/*  42 */     super(supportedType);
/*  43 */     this._formatter = f;
/*  44 */     this._shape = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSR310DateTimeDeserializerBase(Class<T> supportedType, DateTimeFormatter f, Boolean leniency) {
/*  51 */     super(supportedType, leniency);
/*  52 */     this._formatter = f;
/*  53 */     this._shape = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, DateTimeFormatter f) {
/*  61 */     super(base);
/*  62 */     this._formatter = f;
/*  63 */     this._shape = base._shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, Boolean leniency) {
/*  71 */     super(base, leniency);
/*  72 */     this._formatter = base._formatter;
/*  73 */     this._shape = base._shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, JsonFormat.Shape shape) {
/*  81 */     super(base);
/*  82 */     this._formatter = base._formatter;
/*  83 */     this._shape = shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  93 */     super(base, leniency);
/*  94 */     this._formatter = formatter;
/*  95 */     this._shape = shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<T> withShape(JsonFormat.Shape shape) {
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 120 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/* 121 */     return (format == null) ? (JsonDeserializer<?>)this : (JsonDeserializer<?>)_withFormatOverrides(ctxt, property, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/* 138 */     JSR310DateTimeDeserializerBase<?> deser = this;
/*     */ 
/*     */     
/* 141 */     if (formatOverrides.hasLenient()) {
/* 142 */       Boolean leniency = formatOverrides.getLenient();
/* 143 */       if (leniency != null) {
/* 144 */         deser = deser.withLeniency(leniency);
/*     */       }
/*     */     } 
/* 147 */     if (formatOverrides.hasPattern()) {
/* 148 */       DateTimeFormatter df; String pattern = formatOverrides.getPattern();
/* 149 */       Locale locale = formatOverrides.hasLocale() ? formatOverrides.getLocale() : ctxt.getLocale();
/* 150 */       DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder();
/* 151 */       if (acceptCaseInsensitiveValues(ctxt, formatOverrides)) {
/* 152 */         builder.parseCaseInsensitive();
/*     */       }
/* 154 */       builder.appendPattern(pattern);
/*     */       
/* 156 */       if (locale == null) {
/* 157 */         df = builder.toFormatter();
/*     */       } else {
/* 159 */         df = builder.toFormatter(locale);
/*     */       } 
/*     */ 
/*     */       
/* 163 */       if (!deser.isLenient()) {
/* 164 */         df = df.withResolverStyle(ResolverStyle.STRICT);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 169 */       if (formatOverrides.hasTimeZone()) {
/* 170 */         df = df.withZone(formatOverrides.getTimeZone().toZoneId());
/*     */       }
/* 172 */       deser = deser.withDateFormat(df);
/*     */     } 
/*     */ 
/*     */     
/* 176 */     JsonFormat.Shape shape = formatOverrides.getShape();
/* 177 */     if (shape != null && shape != this._shape) {
/* 178 */       deser = deser.withShape(shape);
/*     */     }
/*     */ 
/*     */     
/* 182 */     return deser;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean acceptCaseInsensitiveValues(DeserializationContext ctxt, JsonFormat.Value format) {
/* 187 */     Boolean enabled = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_VALUES);
/* 188 */     if (enabled == null) {
/* 189 */       enabled = Boolean.valueOf(ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES));
/*     */     }
/* 191 */     return enabled.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _throwNoNumericTimestampNeedTimeZone(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 197 */     ctxt.reportInputMismatch(handledType(), "raw timestamp (%d) not allowed for `%s`: need additional information such as an offset or time-zone (see class Javadocs)", new Object[] { p
/*     */           
/* 199 */           .getNumberValue(), handledType().getName() });
/*     */   }
/*     */   
/*     */   protected abstract JSR310DateTimeDeserializerBase<T> withDateFormat(DateTimeFormatter paramDateTimeFormatter);
/*     */   
/*     */   protected abstract JSR310DateTimeDeserializerBase<T> withLeniency(Boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\JSR310DateTimeDeserializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */