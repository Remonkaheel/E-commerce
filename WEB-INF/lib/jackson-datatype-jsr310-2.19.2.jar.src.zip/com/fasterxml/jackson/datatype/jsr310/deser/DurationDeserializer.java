/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import com.fasterxml.jackson.datatype.jsr310.util.DurationUnitConverter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DurationDeserializer
/*     */   extends JSR310DeserializerBase<Duration>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  49 */   public static final DurationDeserializer INSTANCE = new DurationDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DurationUnitConverter _durationUnitConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _readTimestampsAsNanosOverride;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DurationDeserializer() {
/*  73 */     super(Duration.class);
/*  74 */     this._durationUnitConverter = null;
/*  75 */     this._readTimestampsAsNanosOverride = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationDeserializer(DurationDeserializer base, Boolean leniency) {
/*  82 */     super(base, leniency);
/*  83 */     this._durationUnitConverter = base._durationUnitConverter;
/*  84 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationDeserializer(DurationDeserializer base, DurationUnitConverter converter) {
/*  91 */     super(base, Boolean.valueOf(base._isLenient));
/*  92 */     this._durationUnitConverter = converter;
/*  93 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DurationDeserializer(DurationDeserializer base, Boolean leniency, DurationUnitConverter converter, Boolean readTimestampsAsNanosOverride) {
/* 103 */     super(base, leniency);
/* 104 */     this._durationUnitConverter = converter;
/* 105 */     this._readTimestampsAsNanosOverride = readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DurationDeserializer withLeniency(Boolean leniency) {
/* 110 */     return new DurationDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected DurationDeserializer withConverter(DurationUnitConverter converter) {
/* 114 */     return new DurationDeserializer(this, converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 121 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/* 122 */     DurationDeserializer deser = this;
/* 123 */     boolean leniency = this._isLenient;
/* 124 */     DurationUnitConverter unitConverter = this._durationUnitConverter;
/* 125 */     Boolean timestampsAsNanosOverride = this._readTimestampsAsNanosOverride;
/* 126 */     if (format != null) {
/* 127 */       if (format.hasLenient()) {
/* 128 */         leniency = format.getLenient().booleanValue();
/*     */       }
/* 130 */       if (format.hasPattern()) {
/* 131 */         String pattern = format.getPattern();
/* 132 */         unitConverter = DurationUnitConverter.from(pattern);
/* 133 */         if (unitConverter == null) {
/* 134 */           ctxt.reportBadDefinition(getValueType(ctxt), 
/* 135 */               String.format("Bad 'pattern' definition (\"%s\") for `Duration`: expected one of [%s]", new Object[] {
/*     */                   
/* 137 */                   pattern, DurationUnitConverter.descForAllowed()
/*     */                 }));
/*     */         }
/*     */       } 
/* 141 */       timestampsAsNanosOverride = format.getFeature(JsonFormat.Feature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */     } 
/* 143 */     if (leniency != this._isLenient || 
/* 144 */       !Objects.equals(unitConverter, this._durationUnitConverter) || 
/* 145 */       !Objects.equals(timestampsAsNanosOverride, this._readTimestampsAsNanosOverride)) {
/* 146 */       return (JsonDeserializer<?>)new DurationDeserializer(this, 
/* 147 */           Boolean.valueOf(leniency), unitConverter, timestampsAsNanosOverride);
/*     */     }
/* 149 */     return (JsonDeserializer<?>)deser;
/*     */   }
/*     */ 
/*     */   
/*     */   public Duration deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*     */     BigDecimal value;
/* 155 */     switch (parser.currentTokenId()) {
/*     */       
/*     */       case 8:
/* 158 */         value = parser.getDecimalValue();
/*     */         
/* 160 */         return (Duration)DecimalUtils.extractSecondsAndNanos(value, Duration::ofSeconds, false);
/*     */       case 7:
/* 162 */         return _fromTimestamp(context, parser.getLongValue());
/*     */       case 6:
/* 164 */         return _fromString(parser, context, parser.getText());
/*     */       
/*     */       case 1:
/* 167 */         return _fromString(parser, context, context
/* 168 */             .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */ 
/*     */       
/*     */       case 12:
/* 172 */         return (Duration)parser.getEmbeddedObject();
/*     */       
/*     */       case 3:
/* 175 */         return (Duration)_deserializeFromArray(parser, context);
/*     */     } 
/* 177 */     return (Duration)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT, JsonToken.VALUE_NUMBER_FLOAT });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Duration _fromString(JsonParser parser, DeserializationContext ctxt, String value0) throws IOException {
/* 184 */     String value = value0.trim();
/* 185 */     if (value.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 189 */       return _fromEmptyString(parser, ctxt, value);
/*     */     }
/*     */ 
/*     */     
/* 193 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS) && 
/* 194 */       _isValidTimestampString(value)) {
/* 195 */       return _fromTimestamp(ctxt, NumberInput.parseLong(value));
/*     */     }
/*     */     
/*     */     try {
/* 199 */       return Duration.parse(value);
/* 200 */     } catch (DateTimeException e) {
/* 201 */       return (Duration)_handleDateTimeException(ctxt, e, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Duration _fromTimestamp(DeserializationContext ctxt, long ts) {
/* 206 */     if (this._durationUnitConverter != null) {
/* 207 */       return this._durationUnitConverter.convert(ts);
/*     */     }
/*     */ 
/*     */     
/* 211 */     if (shouldReadTimestampsAsNanoseconds(ctxt)) {
/* 212 */       return Duration.ofSeconds(ts);
/*     */     }
/* 214 */     return Duration.ofMillis(ts);
/*     */   }
/*     */   
/*     */   protected boolean shouldReadTimestampsAsNanoseconds(DeserializationContext context) {
/* 218 */     return (this._readTimestampsAsNanosOverride != null) ? this._readTimestampsAsNanosOverride.booleanValue() : context
/* 219 */       .isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\DurationDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */