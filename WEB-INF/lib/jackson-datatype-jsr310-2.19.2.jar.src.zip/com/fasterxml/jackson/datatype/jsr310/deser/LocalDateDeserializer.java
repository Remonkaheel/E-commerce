/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.datatype.jsr310.JavaTimeFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalDate>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private static final boolean DEFAULT_USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING = JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING
/*  45 */     .enabledByDefault();
/*     */   
/*  47 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;
/*     */   
/*  49 */   public static final LocalDateDeserializer INSTANCE = new LocalDateDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _useTimeZoneForLenientDateParsing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer() {
/*  63 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalDateDeserializer(DateTimeFormatter dtf) {
/*  67 */     super(LocalDate.class, dtf);
/*  68 */     this._useTimeZoneForLenientDateParsing = DEFAULT_USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateDeserializer(LocalDateDeserializer base, DateTimeFormatter dtf) {
/*  75 */     super(base, dtf);
/*  76 */     this._useTimeZoneForLenientDateParsing = base._useTimeZoneForLenientDateParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, Boolean leniency) {
/*  83 */     super(base, leniency);
/*  84 */     this._useTimeZoneForLenientDateParsing = base._useTimeZoneForLenientDateParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, JsonFormat.Shape shape) {
/*  91 */     super(base, shape);
/*  92 */     this._useTimeZoneForLenientDateParsing = base._useTimeZoneForLenientDateParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, JacksonFeatureSet<JavaTimeFeature> features) {
/*  99 */     super(LocalDate.class, base._formatter);
/* 100 */     this._useTimeZoneForLenientDateParsing = features.isEnabled((JacksonFeature)JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer withDateFormat(DateTimeFormatter dtf) {
/* 105 */     return new LocalDateDeserializer(this, dtf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateDeserializer withLeniency(Boolean leniency) {
/* 110 */     return new LocalDateDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected LocalDateDeserializer withShape(JsonFormat.Shape shape) {
/* 114 */     return new LocalDateDeserializer(this, shape);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateDeserializer withFeatures(JacksonFeatureSet<JavaTimeFeature> features) {
/* 120 */     if (this._useTimeZoneForLenientDateParsing == features
/* 121 */       .isEnabled((JacksonFeature)JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING)) {
/* 122 */       return this;
/*     */     }
/* 124 */     return new LocalDateDeserializer(this, features);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDate deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 130 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/* 131 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/* 134 */     if (parser.isExpectedStartObjectToken()) {
/* 135 */       return _fromString(parser, context, context
/* 136 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/* 138 */     if (parser.isExpectedStartArrayToken()) {
/* 139 */       JsonToken t = parser.nextToken();
/* 140 */       if (t == JsonToken.END_ARRAY) {
/* 141 */         return null;
/*     */       }
/* 143 */       if (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS) && (t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT)) {
/*     */         
/* 145 */         LocalDate parsed = deserialize(parser, context);
/* 146 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 147 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 149 */         return parsed;
/*     */       } 
/* 151 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 152 */         int year = parser.getIntValue();
/* 153 */         int month = parser.nextIntValue(-1);
/* 154 */         int day = parser.nextIntValue(-1);
/*     */         
/* 156 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 157 */           throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */         }
/*     */         
/* 160 */         return LocalDate.of(year, month, day);
/*     */       } 
/* 162 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     } 
/*     */ 
/*     */     
/* 166 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 167 */       return (LocalDate)parser.getEmbeddedObject();
/*     */     }
/*     */     
/* 170 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 171 */       CoercionAction act = context.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.Integer);
/*     */       
/* 173 */       _checkCoercionFail(context, act, handledType(), Long.valueOf(parser.getLongValue()), "Integer value (" + parser
/* 174 */           .getLongValue() + ")");
/*     */ 
/*     */       
/* 177 */       if (this._shape == JsonFormat.Shape.NUMBER_INT || isLenient()) {
/* 178 */         return LocalDate.ofEpochDay(parser.getLongValue());
/*     */       }
/* 180 */       return _failForNotLenient(parser, context, JsonToken.VALUE_STRING);
/*     */     } 
/* 182 */     return (LocalDate)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDate _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 188 */     String string = string0.trim();
/* 189 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 193 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 198 */       DateTimeFormatter format = this._formatter;
/* 199 */       if (format == DEFAULT_FORMATTER)
/*     */       {
/* 201 */         if (string.length() > 10 && string.charAt(10) == 'T') {
/* 202 */           if (isLenient()) {
/* 203 */             if (string.endsWith("Z")) {
/* 204 */               if (this._useTimeZoneForLenientDateParsing) {
/* 205 */                 return Instant.parse(string).atZone(ctxt.getTimeZone().toZoneId()).toLocalDate();
/*     */               }
/* 207 */               return LocalDate.parse(string.substring(0, string.length() - 1), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */             } 
/*     */             
/* 210 */             return LocalDate.parse(string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */           } 
/* 212 */           JavaType t = getValueType(ctxt);
/* 213 */           return (LocalDate)ctxt.handleWeirdStringValue(t.getRawClass(), string, "Should not contain time component when 'strict' mode set for property or type (enable 'lenient' handling to allow)", new Object[0]);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 219 */       return LocalDate.parse(string, format);
/* 220 */     } catch (DateTimeException e) {
/* 221 */       return (LocalDate)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalDateDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */