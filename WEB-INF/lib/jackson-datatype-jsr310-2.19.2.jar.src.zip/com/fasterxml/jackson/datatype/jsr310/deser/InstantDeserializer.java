/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import com.fasterxml.jackson.datatype.jsr310.JavaTimeFeature;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstantDeserializer<T extends Temporal>
/*     */   extends JSR310DateTimeDeserializerBase<T>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  61 */   private static final boolean DEFAULT_NORMALIZE_ZONE_ID = JavaTimeFeature.NORMALIZE_DESERIALIZED_ZONE_ID.enabledByDefault();
/*  62 */   private static final boolean DEFAULT_ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS = JavaTimeFeature.ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS
/*  63 */     .enabledByDefault(); public static final InstantDeserializer<Instant> INSTANT; public static final InstantDeserializer<OffsetDateTime> OFFSET_DATE_TIME; public static final InstantDeserializer<ZonedDateTime> ZONED_DATE_TIME;
/*     */   protected final Function<FromIntegerArguments, T> fromMilliseconds;
/*     */   protected final Function<FromDecimalArguments, T> fromNanoseconds;
/*     */   protected final Function<TemporalAccessor, T> parsedToValue;
/*     */   protected final BiFunction<T, ZoneId, T> adjust;
/*     */   protected final boolean replaceZeroOffsetAsZ;
/*     */   protected final Boolean _adjustToContextTZOverride;
/*  70 */   protected static final Pattern ISO8601_COLONLESS_OFFSET_REGEX = Pattern.compile("[+-][0-9]{4}(?=\\[|$)"); protected final Boolean _readTimestampsAsNanosOverride;
/*     */   protected final boolean _normalizeZoneId;
/*     */   protected final boolean _alwaysAllowStringifiedDateTimestamps;
/*     */   
/*     */   private static OffsetDateTime decimalToOffsetDateTime(FromDecimalArguments args) {
/*  75 */     if (args.integer == OffsetDateTime.MIN.toEpochSecond() && args.fraction == OffsetDateTime.MIN.getNano()) {
/*  76 */       return OffsetDateTime.ofInstant(Instant.ofEpochSecond(OffsetDateTime.MIN.toEpochSecond(), OffsetDateTime.MIN.getNano()), OffsetDateTime.MIN.getOffset());
/*     */     }
/*     */     
/*  79 */     if (args.integer == OffsetDateTime.MAX.toEpochSecond() && args.fraction == OffsetDateTime.MAX.getNano()) {
/*  80 */       return OffsetDateTime.ofInstant(Instant.ofEpochSecond(OffsetDateTime.MAX.toEpochSecond(), OffsetDateTime.MAX.getNano()), OffsetDateTime.MAX.getOffset());
/*     */     }
/*  82 */     return OffsetDateTime.ofInstant(Instant.ofEpochSecond(args.integer, args.fraction), args.zoneId);
/*     */   }
/*     */   static {
/*  85 */     INSTANT = new InstantDeserializer((Class)Instant.class, DateTimeFormatter.ISO_INSTANT, Instant::from, a -> Instant.ofEpochMilli(a.value), a -> Instant.ofEpochSecond(a.integer, a.fraction), null, true, DEFAULT_NORMALIZE_ZONE_ID, DEFAULT_ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     OFFSET_DATE_TIME = new InstantDeserializer((Class)OffsetDateTime.class, DateTimeFormatter.ISO_OFFSET_DATE_TIME, OffsetDateTime::from, a -> OffsetDateTime.ofInstant(Instant.ofEpochMilli(a.value), a.zoneId), InstantDeserializer::decimalToOffsetDateTime, (d, z) -> 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 101 */         (d.isEqual(OffsetDateTime.MIN) || d.isEqual(OffsetDateTime.MAX)) ? d : d.withOffsetSameInstant(z.getRules().getOffset(d.toLocalDateTime())), true, DEFAULT_NORMALIZE_ZONE_ID, DEFAULT_ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     ZONED_DATE_TIME = new InstantDeserializer((Class)ZonedDateTime.class, DateTimeFormatter.ISO_ZONED_DATE_TIME, ZonedDateTime::from, a -> ZonedDateTime.ofInstant(Instant.ofEpochMilli(a.value), a.zoneId), a -> ZonedDateTime.ofInstant(Instant.ofEpochSecond(a.integer, a.fraction), a.zoneId), ZonedDateTime::withZoneSameInstant, false, DEFAULT_NORMALIZE_ZONE_ID, DEFAULT_ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(Class<T> supportedType, DateTimeFormatter formatter, Function<TemporalAccessor, T> parsedToValue, Function<FromIntegerArguments, T> fromMilliseconds, Function<FromDecimalArguments, T> fromNanoseconds, BiFunction<T, ZoneId, T> adjust, boolean replaceZeroOffsetAsZ, boolean normalizeZoneId, boolean readNumericStringsAsTimestamp) {
/* 185 */     super(supportedType, formatter);
/* 186 */     this.parsedToValue = parsedToValue;
/* 187 */     this.fromMilliseconds = fromMilliseconds;
/* 188 */     this.fromNanoseconds = fromNanoseconds;
/* 189 */     this.adjust = (adjust == null) ? ((d, z) -> d) : adjust;
/* 190 */     this.replaceZeroOffsetAsZ = replaceZeroOffsetAsZ;
/* 191 */     this._adjustToContextTZOverride = null;
/* 192 */     this._readTimestampsAsNanosOverride = null;
/* 193 */     this._normalizeZoneId = normalizeZoneId;
/* 194 */     this._alwaysAllowStringifiedDateTimestamps = readNumericStringsAsTimestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected InstantDeserializer(Class<T> supportedType, DateTimeFormatter formatter, Function<TemporalAccessor, T> parsedToValue, Function<FromIntegerArguments, T> fromMilliseconds, Function<FromDecimalArguments, T> fromNanoseconds, BiFunction<T, ZoneId, T> adjust, boolean replaceZeroOffsetAsZ) {
/* 210 */     this(supportedType, formatter, parsedToValue, fromMilliseconds, fromNanoseconds, adjust, replaceZeroOffsetAsZ, DEFAULT_NORMALIZE_ZONE_ID, DEFAULT_ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, DateTimeFormatter f) {
/* 218 */     super(base.handledType(), f);
/* 219 */     this.parsedToValue = base.parsedToValue;
/* 220 */     this.fromMilliseconds = base.fromMilliseconds;
/* 221 */     this.fromNanoseconds = base.fromNanoseconds;
/* 222 */     this.adjust = base.adjust;
/* 223 */     this.replaceZeroOffsetAsZ = (this._formatter == DateTimeFormatter.ISO_INSTANT);
/* 224 */     this._adjustToContextTZOverride = base._adjustToContextTZOverride;
/* 225 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/* 226 */     this._normalizeZoneId = base._normalizeZoneId;
/* 227 */     this._alwaysAllowStringifiedDateTimestamps = base._alwaysAllowStringifiedDateTimestamps;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, Boolean adjustToContextTimezoneOverride) {
/* 233 */     super(base.handledType(), base._formatter);
/* 234 */     this.parsedToValue = base.parsedToValue;
/* 235 */     this.fromMilliseconds = base.fromMilliseconds;
/* 236 */     this.fromNanoseconds = base.fromNanoseconds;
/* 237 */     this.adjust = base.adjust;
/* 238 */     this.replaceZeroOffsetAsZ = base.replaceZeroOffsetAsZ;
/* 239 */     this._adjustToContextTZOverride = adjustToContextTimezoneOverride;
/* 240 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/* 241 */     this._normalizeZoneId = base._normalizeZoneId;
/* 242 */     this._alwaysAllowStringifiedDateTimestamps = base._alwaysAllowStringifiedDateTimestamps;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, DateTimeFormatter f, Boolean leniency) {
/* 248 */     super(base.handledType(), f, leniency);
/* 249 */     this.parsedToValue = base.parsedToValue;
/* 250 */     this.fromMilliseconds = base.fromMilliseconds;
/* 251 */     this.fromNanoseconds = base.fromNanoseconds;
/* 252 */     this.adjust = base.adjust;
/* 253 */     this.replaceZeroOffsetAsZ = (this._formatter == DateTimeFormatter.ISO_INSTANT);
/* 254 */     this._adjustToContextTZOverride = base._adjustToContextTZOverride;
/* 255 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/* 256 */     this._normalizeZoneId = base._normalizeZoneId;
/* 257 */     this._alwaysAllowStringifiedDateTimestamps = base._alwaysAllowStringifiedDateTimestamps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape, Boolean adjustToContextTimezoneOverride, Boolean readTimestampsAsNanosOverride) {
/* 270 */     super(base, leniency, formatter, shape);
/* 271 */     this.parsedToValue = base.parsedToValue;
/* 272 */     this.fromMilliseconds = base.fromMilliseconds;
/* 273 */     this.fromNanoseconds = base.fromNanoseconds;
/* 274 */     this.adjust = base.adjust;
/* 275 */     this.replaceZeroOffsetAsZ = base.replaceZeroOffsetAsZ;
/* 276 */     this._adjustToContextTZOverride = adjustToContextTimezoneOverride;
/* 277 */     this._readTimestampsAsNanosOverride = readTimestampsAsNanosOverride;
/* 278 */     this._normalizeZoneId = base._normalizeZoneId;
/* 279 */     this._alwaysAllowStringifiedDateTimestamps = base._alwaysAllowStringifiedDateTimestamps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantDeserializer(InstantDeserializer<T> base, JacksonFeatureSet<JavaTimeFeature> features) {
/* 289 */     super(base.handledType(), base._formatter);
/* 290 */     this.parsedToValue = base.parsedToValue;
/* 291 */     this.fromMilliseconds = base.fromMilliseconds;
/* 292 */     this.fromNanoseconds = base.fromNanoseconds;
/* 293 */     this.adjust = base.adjust;
/* 294 */     this.replaceZeroOffsetAsZ = base.replaceZeroOffsetAsZ;
/* 295 */     this._adjustToContextTZOverride = base._adjustToContextTZOverride;
/* 296 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*     */     
/* 298 */     this._normalizeZoneId = features.isEnabled((JacksonFeature)JavaTimeFeature.NORMALIZE_DESERIALIZED_ZONE_ID);
/* 299 */     this._alwaysAllowStringifiedDateTimestamps = features.isEnabled((JacksonFeature)JavaTimeFeature.ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS);
/*     */   }
/*     */ 
/*     */   
/*     */   protected InstantDeserializer<T> withDateFormat(DateTimeFormatter dtf) {
/* 304 */     if (dtf == this._formatter) {
/* 305 */       return this;
/*     */     }
/* 307 */     return new InstantDeserializer(this, dtf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected InstantDeserializer<T> withLeniency(Boolean leniency) {
/* 312 */     return new InstantDeserializer(this, this._formatter, leniency);
/*     */   }
/*     */ 
/*     */   
/*     */   public InstantDeserializer<T> withFeatures(JacksonFeatureSet<JavaTimeFeature> features) {
/* 317 */     if (this._normalizeZoneId == features.isEnabled((JacksonFeature)JavaTimeFeature.NORMALIZE_DESERIALIZED_ZONE_ID) && this._alwaysAllowStringifiedDateTimestamps == features
/* 318 */       .isEnabled((JacksonFeature)JavaTimeFeature.ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS))
/*     */     {
/* 320 */       return this;
/*     */     }
/* 322 */     return new InstantDeserializer(this, features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/* 330 */     InstantDeserializer<T> deser = (InstantDeserializer)super._withFormatOverrides(ctxt, property, formatOverrides);
/*     */     
/* 332 */     Boolean adjustToContextTZOverride = formatOverrides.getFeature(JsonFormat.Feature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
/*     */     
/* 334 */     Boolean readTimestampsAsNanosOverride = formatOverrides.getFeature(JsonFormat.Feature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */     
/* 336 */     if (!Objects.equals(adjustToContextTZOverride, deser._adjustToContextTZOverride) || 
/* 337 */       !Objects.equals(readTimestampsAsNanosOverride, deser._readTimestampsAsNanosOverride)) {
/* 338 */       return new InstantDeserializer(deser, Boolean.valueOf(deser._isLenient), deser._formatter, deser._shape, adjustToContextTZOverride, readTimestampsAsNanosOverride);
/*     */     }
/*     */     
/* 341 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 350 */     switch (parser.currentTokenId()) {
/*     */       
/*     */       case 8:
/* 353 */         return _fromDecimal(context, parser.getDecimalValue());
/*     */       case 7:
/* 355 */         return _fromLong(context, parser.getLongValue());
/*     */       case 6:
/* 357 */         return _fromString(parser, context, parser.getText());
/*     */       
/*     */       case 1:
/* 360 */         return _fromString(parser, context, context
/* 361 */             .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */ 
/*     */       
/*     */       case 12:
/* 365 */         return (T)parser.getEmbeddedObject();
/*     */       
/*     */       case 3:
/* 368 */         return (T)_deserializeFromArray(parser, context);
/*     */     } 
/* 370 */     return (T)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT, JsonToken.VALUE_NUMBER_FLOAT });
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldAdjustToContextTimezone(DeserializationContext context) {
/* 375 */     return (this._adjustToContextTZOverride != null) ? this._adjustToContextTZOverride.booleanValue() : context
/* 376 */       .isEnabled(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
/*     */   }
/*     */   
/*     */   protected boolean shouldReadTimestampsAsNanoseconds(DeserializationContext context) {
/* 380 */     return (this._readTimestampsAsNanosOverride != null) ? this._readTimestampsAsNanosOverride.booleanValue() : context
/* 381 */       .isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _countPeriods(String str, boolean allowLeadingPlusSign) {
/* 387 */     int commas = 0;
/* 388 */     int i = 0;
/* 389 */     int ch = str.charAt(i);
/* 390 */     if (ch == 45 || (ch == 43 && allowLeadingPlusSign)) {
/* 391 */       i++;
/*     */     }
/* 393 */     for (int end = str.length(); i < end; i++) {
/* 394 */       ch = str.charAt(i);
/* 395 */       if (ch < 48 || ch > 57) {
/* 396 */         if (ch == 46) {
/* 397 */           commas++;
/*     */         } else {
/* 399 */           return -1;
/*     */         } 
/*     */       }
/*     */     } 
/* 403 */     return commas;
/*     */   }
/*     */ 
/*     */   
/*     */   protected T _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/*     */     Temporal temporal;
/* 409 */     String string = string0.trim();
/* 410 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 414 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/* 417 */     if (this._alwaysAllowStringifiedDateTimestamps || this._formatter == DateTimeFormatter.ISO_INSTANT || this._formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME || this._formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 423 */       int dots = _countPeriods(string, p.isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()));
/* 424 */       if (dots >= 0) {
/*     */         try {
/* 426 */           if (dots == 0) {
/* 427 */             return _fromLong(ctxt, NumberInput.parseLong(string));
/*     */           }
/* 429 */           if (dots == 1) {
/* 430 */             return _fromDecimal(ctxt, NumberInput.parseBigDecimal(string, false));
/*     */           }
/* 432 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 437 */       string = replaceZeroOffsetAsZIfNecessary(string);
/*     */     } 
/*     */ 
/*     */     
/* 441 */     if (this._formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME || this._formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 448 */       string = addInColonToOffsetIfMissing(string);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 453 */       TemporalAccessor acc = this._formatter.parse(string);
/* 454 */       temporal = (Temporal)this.parsedToValue.apply(acc);
/* 455 */       if (shouldAdjustToContextTimezone(ctxt)) {
/* 456 */         return this.adjust.apply((T)temporal, getZone(ctxt));
/*     */       }
/* 458 */     } catch (DateTimeException e) {
/* 459 */       temporal = (Temporal)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/* 461 */     return (T)temporal;
/*     */   }
/*     */ 
/*     */   
/*     */   protected T _fromLong(DeserializationContext context, long timestamp) {
/* 466 */     if (shouldReadTimestampsAsNanoseconds(context)) {
/* 467 */       return this.fromNanoseconds.apply(new FromDecimalArguments(timestamp, 0, 
/* 468 */             getZone(context)));
/*     */     }
/*     */     
/* 471 */     return this.fromMilliseconds.apply(new FromIntegerArguments(timestamp, 
/* 472 */           getZone(context)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected T _fromDecimal(DeserializationContext context, BigDecimal value) {
/* 478 */     FromDecimalArguments args = (FromDecimalArguments)DecimalUtils.extractSecondsAndNanos(value, (s, ns) -> new FromDecimalArguments(s.longValue(), ns.intValue(), getZone(context)), true);
/*     */ 
/*     */     
/* 481 */     return this.fromNanoseconds.apply(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ZoneId getZone(DeserializationContext context) {
/* 489 */     if (this._valueClass == Instant.class) {
/* 490 */       return null;
/*     */     }
/* 492 */     ZoneId zoneId = context.getTimeZone().toZoneId();
/* 493 */     return this._normalizeZoneId ? zoneId.normalized() : zoneId;
/*     */   }
/*     */ 
/*     */   
/*     */   private String replaceZeroOffsetAsZIfNecessary(String text) {
/* 498 */     if (this.replaceZeroOffsetAsZ) {
/* 499 */       return replaceZeroOffsetAsZ(text);
/*     */     }
/*     */     
/* 502 */     return text;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String replaceZeroOffsetAsZ(String text) {
/* 507 */     int plusIndex = text.lastIndexOf('+');
/* 508 */     if (plusIndex < 0) {
/* 509 */       return text;
/*     */     }
/* 511 */     int maybeOffsetIndex = plusIndex + 1;
/* 512 */     int remaining = text.length() - maybeOffsetIndex;
/* 513 */     switch (remaining) {
/*     */       case 2:
/* 515 */         return text.regionMatches(maybeOffsetIndex, "00", 0, remaining) ? (text
/* 516 */           .substring(0, plusIndex) + 'Z') : text;
/*     */       
/*     */       case 4:
/* 519 */         return text.regionMatches(maybeOffsetIndex, "0000", 0, remaining) ? (text
/* 520 */           .substring(0, plusIndex) + 'Z') : text;
/*     */       
/*     */       case 5:
/* 523 */         return text.regionMatches(maybeOffsetIndex, "00:00", 0, remaining) ? (text
/* 524 */           .substring(0, plusIndex) + 'Z') : text;
/*     */     } 
/*     */     
/* 527 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String addInColonToOffsetIfMissing(String text) {
/* 533 */     int timeIndex = text.indexOf('T');
/* 534 */     if (timeIndex < 0 || timeIndex > text.length() - 1) {
/* 535 */       return text;
/*     */     }
/*     */     
/* 538 */     int offsetIndex = text.indexOf('+', timeIndex + 1);
/* 539 */     if (offsetIndex < 0) {
/* 540 */       offsetIndex = text.indexOf('-', timeIndex + 1);
/*     */     }
/*     */     
/* 543 */     if (offsetIndex < 0 || offsetIndex > text.length() - 5) {
/* 544 */       return text;
/*     */     }
/*     */     
/* 547 */     int colonIndex = text.indexOf(':', offsetIndex);
/* 548 */     if (colonIndex == offsetIndex + 3) {
/* 549 */       return text;
/*     */     }
/*     */     
/* 552 */     if (Character.isDigit(text.charAt(offsetIndex + 1)) && 
/* 553 */       Character.isDigit(text.charAt(offsetIndex + 2)) && 
/* 554 */       Character.isDigit(text.charAt(offsetIndex + 3)) && 
/* 555 */       Character.isDigit(text.charAt(offsetIndex + 4))) {
/* 556 */       String match = text.substring(offsetIndex, offsetIndex + 5);
/* 557 */       return text.substring(0, offsetIndex) + match
/* 558 */         .substring(0, 3) + ':' + match.substring(3) + text
/* 559 */         .substring(offsetIndex + match.length());
/*     */     } 
/*     */ 
/*     */     
/* 563 */     Matcher matcher = ISO8601_COLONLESS_OFFSET_REGEX.matcher(text);
/* 564 */     if (matcher.find()) {
/* 565 */       String match = matcher.group(0);
/* 566 */       return matcher.replaceFirst(match.substring(0, 3) + ':' + match.substring(3));
/*     */     } 
/* 568 */     return text;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FromIntegerArguments
/*     */   {
/*     */     public final long value;
/*     */     public final ZoneId zoneId;
/*     */     
/*     */     FromIntegerArguments(long value, ZoneId zoneId) {
/* 578 */       this.value = value;
/* 579 */       this.zoneId = zoneId;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FromDecimalArguments
/*     */   {
/*     */     public final long integer;
/*     */     public final int fraction;
/*     */     public final ZoneId zoneId;
/*     */     
/*     */     FromDecimalArguments(long integer, int fraction, ZoneId zoneId) {
/* 591 */       this.integer = integer;
/* 592 */       this.fraction = fraction;
/* 593 */       this.zoneId = zoneId;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\InstantDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */