/*    */ package com.fasterxml.jackson.datatype.jsr310;
/*    */ 
/*    */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JavaTimeFeature
/*    */   implements JacksonFeature
/*    */ {
/* 20 */   NORMALIZE_DESERIALIZED_ZONE_ID(true),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING(false),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   ALWAYS_ALLOW_STRINGIFIED_DATE_TIMESTAMPS(false),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   ONE_BASED_MONTHS(false);
/*    */ 
/*    */   
/*    */   private final boolean _defaultState;
/*    */ 
/*    */   
/*    */   private final int _mask;
/*    */ 
/*    */ 
/*    */   
/*    */   JavaTimeFeature(boolean enabledByDefault) {
/* 65 */     this._defaultState = enabledByDefault;
/* 66 */     this._mask = 1 << ordinal();
/*    */   }
/*    */   
/*    */   public boolean enabledByDefault() {
/* 70 */     return this._defaultState;
/*    */   }
/*    */   public boolean enabledIn(int flags) {
/* 73 */     return ((flags & this._mask) != 0);
/*    */   }
/*    */   public int getMask() {
/* 76 */     return this._mask;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\JavaTimeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */