/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializationConfig;
/*    */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*    */ import java.time.Month;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaTimeSerializerModifier
/*    */   extends BeanSerializerModifier
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final boolean _oneBaseMonths;
/*    */   
/*    */   public JavaTimeSerializerModifier(boolean oneBaseMonths) {
/* 20 */     this._oneBaseMonths = oneBaseMonths;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonSerializer<?> modifyEnumSerializer(SerializationConfig config, JavaType valueType, BeanDescription beanDesc, JsonSerializer<?> serializer) {
/* 25 */     if (this._oneBaseMonths && valueType.hasRawClass(Month.class)) {
/* 26 */       return new OneBasedMonthSerializer(serializer);
/*    */     }
/* 28 */     return serializer;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\JavaTimeSerializerModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */