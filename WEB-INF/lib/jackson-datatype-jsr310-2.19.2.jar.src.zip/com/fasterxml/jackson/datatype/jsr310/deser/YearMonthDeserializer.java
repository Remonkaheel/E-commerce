/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.YearMonth;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YearMonthDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<YearMonth>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   public static final YearMonthDeserializer INSTANCE = new YearMonthDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public YearMonthDeserializer() {
/*  48 */     this(DateTimeFormatter.ofPattern("u-MM"));
/*     */   }
/*     */ 
/*     */   
/*     */   public YearMonthDeserializer(DateTimeFormatter formatter) {
/*  53 */     super(YearMonth.class, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected YearMonthDeserializer(YearMonthDeserializer base, Boolean leniency) {
/*  60 */     super(base, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public YearMonthDeserializer(YearMonthDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  70 */     super(base, leniency, formatter, shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected YearMonthDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  75 */     return new YearMonthDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected YearMonthDeserializer withLeniency(Boolean leniency) {
/*  80 */     return new YearMonthDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public YearMonth deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*  86 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  87 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  90 */     if (parser.isExpectedStartObjectToken()) {
/*  91 */       return _fromString(parser, context, context
/*  92 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/*  94 */     if (parser.isExpectedStartArrayToken()) {
/*  95 */       JsonToken t = parser.nextToken();
/*  96 */       if (t == JsonToken.END_ARRAY) {
/*  97 */         return null;
/*     */       }
/*  99 */       if ((t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT) && context
/* 100 */         .isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 101 */         YearMonth parsed = deserialize(parser, context);
/* 102 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 103 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 105 */         return parsed;
/*     */       } 
/* 107 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/* 108 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "years");
/*     */       }
/* 110 */       int year = parser.getIntValue();
/* 111 */       int month = parser.nextIntValue(-1);
/* 112 */       if (month == -1) {
/* 113 */         if (!parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 114 */           _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "months");
/*     */         }
/* 116 */         month = parser.getIntValue();
/*     */       } 
/* 118 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 119 */         throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */       }
/*     */       
/* 122 */       return YearMonth.of(year, month);
/*     */     } 
/* 124 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 125 */       return (YearMonth)parser.getEmbeddedObject();
/*     */     }
/* 127 */     return (YearMonth)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.START_ARRAY });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected YearMonth _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 134 */     String string = string0.trim();
/* 135 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 139 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 142 */       return YearMonth.parse(string, this._formatter);
/* 143 */     } catch (DateTimeException e) {
/* 144 */       return (YearMonth)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\YearMonthDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */