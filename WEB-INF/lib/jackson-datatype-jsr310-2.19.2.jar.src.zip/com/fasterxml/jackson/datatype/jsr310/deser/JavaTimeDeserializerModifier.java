/*    */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*    */ import java.time.Month;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaTimeDeserializerModifier
/*    */   extends BeanDeserializerModifier
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final boolean _oneBaseMonths;
/*    */   
/*    */   public JavaTimeDeserializerModifier(boolean oneBaseMonths) {
/* 20 */     this._oneBaseMonths = oneBaseMonths;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonDeserializer<?> modifyEnumDeserializer(DeserializationConfig config, JavaType type, BeanDescription beanDesc, JsonDeserializer<?> defaultDeserializer) {
/* 25 */     if (this._oneBaseMonths && type.hasRawClass(Month.class)) {
/* 26 */       return (JsonDeserializer<?>)new OneBasedMonthDeserializer(defaultDeserializer);
/*    */     }
/* 28 */     return defaultDeserializer;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\JavaTimeDeserializerModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */