/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_TIME;
/*     */   
/*  43 */   public static final LocalTimeDeserializer INSTANCE = new LocalTimeDeserializer();
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _readTimestampsAsNanosOverride;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalTimeDeserializer() {
/*  53 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalTimeDeserializer(DateTimeFormatter formatter) {
/*  57 */     super(LocalTime.class, formatter);
/*  58 */     this._readTimestampsAsNanosOverride = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalTimeDeserializer(LocalTimeDeserializer base, Boolean leniency) {
/*  65 */     super(base, leniency);
/*  66 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalTimeDeserializer(LocalTimeDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape, Boolean readTimestampsAsNanosOverride) {
/*  77 */     super(base, leniency, formatter, shape);
/*  78 */     this._readTimestampsAsNanosOverride = readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalTimeDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  83 */     return new LocalTimeDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape, this._readTimestampsAsNanosOverride);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalTimeDeserializer withLeniency(Boolean leniency) {
/*  88 */     return new LocalTimeDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/*  95 */     LocalTimeDeserializer deser = (LocalTimeDeserializer)super._withFormatOverrides(ctxt, property, formatOverrides);
/*  96 */     Boolean readTimestampsAsNanosOverride = formatOverrides.getFeature(JsonFormat.Feature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */     
/*  98 */     if (!Objects.equals(readTimestampsAsNanosOverride, deser._readTimestampsAsNanosOverride)) {
/*  99 */       return new LocalTimeDeserializer(deser, Boolean.valueOf(deser._isLenient), deser._formatter, deser._shape, readTimestampsAsNanosOverride);
/*     */     }
/*     */     
/* 102 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalTime deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 108 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/* 109 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/* 112 */     if (parser.isExpectedStartObjectToken()) {
/* 113 */       return _fromString(parser, context, context
/* 114 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/* 116 */     if (parser.isExpectedStartArrayToken()) {
/* 117 */       JsonToken t = parser.nextToken();
/* 118 */       if (t == JsonToken.END_ARRAY) {
/* 119 */         return null;
/*     */       }
/* 121 */       if (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS) && (t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT)) {
/*     */         
/* 123 */         LocalTime parsed = deserialize(parser, context);
/* 124 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 125 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 127 */         return parsed;
/*     */       } 
/* 129 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 130 */         LocalTime result; int hour = parser.getIntValue();
/*     */         
/* 132 */         parser.nextToken();
/* 133 */         int minute = parser.getIntValue();
/*     */ 
/*     */         
/* 136 */         t = parser.nextToken();
/* 137 */         if (t == JsonToken.END_ARRAY) {
/* 138 */           result = LocalTime.of(hour, minute);
/*     */         } else {
/* 140 */           int second = parser.getIntValue();
/* 141 */           t = parser.nextToken();
/* 142 */           if (t == JsonToken.END_ARRAY) {
/* 143 */             result = LocalTime.of(hour, minute, second);
/*     */           } else {
/* 145 */             int partialSecond = parser.getIntValue();
/* 146 */             if (partialSecond < 1000 && !shouldReadTimestampsAsNanoseconds(context))
/* 147 */               partialSecond *= 1000000; 
/* 148 */             t = parser.nextToken();
/* 149 */             if (t != JsonToken.END_ARRAY) {
/* 150 */               throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */             }
/*     */             
/* 153 */             result = LocalTime.of(hour, minute, second, partialSecond);
/*     */           } 
/*     */         } 
/* 156 */         return result;
/*     */       } 
/* 158 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     } 
/*     */ 
/*     */     
/* 162 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 163 */       return (LocalTime)parser.getEmbeddedObject();
/*     */     }
/* 165 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 166 */       _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */     }
/* 168 */     return (LocalTime)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */   
/*     */   protected boolean shouldReadTimestampsAsNanoseconds(DeserializationContext context) {
/* 172 */     return (this._readTimestampsAsNanosOverride != null) ? this._readTimestampsAsNanosOverride.booleanValue() : context
/* 173 */       .isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalTime _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 179 */     String string = string0.trim();
/* 180 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 184 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/* 186 */     DateTimeFormatter format = this._formatter;
/*     */     try {
/* 188 */       if (format == DEFAULT_FORMATTER && 
/* 189 */         string.contains("T")) {
/* 190 */         return LocalTime.parse(string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */       }
/*     */       
/* 193 */       return LocalTime.parse(string, format);
/* 194 */     } catch (DateTimeException e) {
/* 195 */       return (LocalTime)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */