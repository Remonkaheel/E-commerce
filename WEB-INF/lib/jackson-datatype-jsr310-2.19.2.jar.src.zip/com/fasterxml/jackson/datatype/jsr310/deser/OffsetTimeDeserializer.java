/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<OffsetTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   public static final OffsetTimeDeserializer INSTANCE = new OffsetTimeDeserializer();
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _readTimestampsAsNanosOverride;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OffsetTimeDeserializer() {
/*  49 */     this(DateTimeFormatter.ISO_OFFSET_TIME);
/*     */   }
/*     */   
/*     */   protected OffsetTimeDeserializer(DateTimeFormatter dtf) {
/*  53 */     super(OffsetTime.class, dtf);
/*  54 */     this._readTimestampsAsNanosOverride = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OffsetTimeDeserializer(OffsetTimeDeserializer base, Boolean leniency) {
/*  61 */     super(base, leniency);
/*  62 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OffsetTimeDeserializer(OffsetTimeDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape, Boolean readTimestampsAsNanosOverride) {
/*  73 */     super(base, leniency, formatter, shape);
/*  74 */     this._readTimestampsAsNanosOverride = readTimestampsAsNanosOverride;
/*     */   }
/*     */ 
/*     */   
/*     */   protected OffsetTimeDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  79 */     return new OffsetTimeDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape, this._readTimestampsAsNanosOverride);
/*     */   }
/*     */ 
/*     */   
/*     */   protected OffsetTimeDeserializer withLeniency(Boolean leniency) {
/*  84 */     return new OffsetTimeDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/*  91 */     OffsetTimeDeserializer deser = (OffsetTimeDeserializer)super._withFormatOverrides(ctxt, property, formatOverrides);
/*  92 */     Boolean readTimestampsAsNanosOverride = formatOverrides.getFeature(JsonFormat.Feature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */     
/*  94 */     if (!Objects.equals(readTimestampsAsNanosOverride, deser._readTimestampsAsNanosOverride)) {
/*  95 */       return new OffsetTimeDeserializer(deser, Boolean.valueOf(deser._isLenient), deser._formatter, deser._shape, readTimestampsAsNanosOverride);
/*     */     }
/*     */     
/*  98 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OffsetTime deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 104 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/* 105 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/* 108 */     if (parser.isExpectedStartObjectToken()) {
/* 109 */       return _fromString(parser, context, context
/* 110 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/* 112 */     if (!parser.isExpectedStartArrayToken()) {
/* 113 */       if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 114 */         return (OffsetTime)parser.getEmbeddedObject();
/*     */       }
/* 116 */       if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 117 */         _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */       }
/* 119 */       throw context.wrongTokenException(parser, handledType(), JsonToken.START_ARRAY, "Expected array or string.");
/*     */     } 
/*     */     
/* 122 */     JsonToken t = parser.nextToken();
/* 123 */     if (t != JsonToken.VALUE_NUMBER_INT) {
/* 124 */       if (t == JsonToken.END_ARRAY) {
/* 125 */         return null;
/*     */       }
/* 127 */       if ((t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT) && context
/* 128 */         .isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 129 */         OffsetTime parsed = deserialize(parser, context);
/* 130 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 131 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 133 */         return parsed;
/*     */       } 
/* 135 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     } 
/*     */ 
/*     */     
/* 139 */     int hour = parser.getIntValue();
/* 140 */     int minute = parser.nextIntValue(-1);
/* 141 */     if (minute == -1) {
/* 142 */       t = parser.getCurrentToken();
/* 143 */       if (t == JsonToken.END_ARRAY) {
/* 144 */         return null;
/*     */       }
/* 146 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/* 147 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "minutes");
/*     */       }
/* 149 */       minute = parser.getIntValue();
/*     */     } 
/* 151 */     int partialSecond = 0;
/* 152 */     int second = 0;
/* 153 */     if (parser.nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 154 */       second = parser.getIntValue();
/* 155 */       if (parser.nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 156 */         partialSecond = parser.getIntValue();
/* 157 */         if (partialSecond < 1000 && !shouldReadTimestampsAsNanoseconds(context)) {
/* 158 */           partialSecond *= 1000000;
/*     */         }
/* 160 */         parser.nextToken();
/*     */       } 
/*     */     } 
/* 163 */     if (parser.getCurrentToken() == JsonToken.VALUE_STRING) {
/* 164 */       OffsetTime result = OffsetTime.of(hour, minute, second, partialSecond, ZoneOffset.of(parser.getText()));
/* 165 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 166 */         _reportWrongToken(context, JsonToken.END_ARRAY, "timezone");
/*     */       }
/* 168 */       return result;
/*     */     } 
/* 170 */     throw context.wrongTokenException(parser, handledType(), JsonToken.VALUE_STRING, "Expected string for TimeZone after numeric values");
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldReadTimestampsAsNanoseconds(DeserializationContext context) {
/* 175 */     return (this._readTimestampsAsNanosOverride != null) ? this._readTimestampsAsNanosOverride.booleanValue() : context
/* 176 */       .isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected OffsetTime _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 182 */     String string = string0.trim();
/* 183 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 187 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 190 */       return OffsetTime.parse(string, this._formatter);
/* 191 */     } catch (DateTimeException e) {
/* 192 */       return (OffsetTime)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\OffsetTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */