/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Year;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YearDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<Year>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   public static final YearDeserializer INSTANCE = new YearDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public YearDeserializer() {
/*  47 */     this((DateTimeFormatter)null);
/*     */   }
/*     */   
/*     */   public YearDeserializer(DateTimeFormatter formatter) {
/*  51 */     super(Year.class, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected YearDeserializer(YearDeserializer base, Boolean leniency) {
/*  58 */     super(base, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public YearDeserializer(YearDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  68 */     super(base, leniency, formatter, shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected YearDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  73 */     return new YearDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected YearDeserializer withLeniency(Boolean leniency) {
/*  78 */     return new YearDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Year deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*  84 */     JsonToken t = parser.currentToken();
/*  85 */     if (t == JsonToken.VALUE_STRING) {
/*  86 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  89 */     if (t == JsonToken.START_OBJECT) {
/*  90 */       return _fromString(parser, context, context
/*  91 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/*  93 */     if (t == JsonToken.VALUE_NUMBER_INT) {
/*  94 */       return _fromNumber(context, parser.getIntValue());
/*     */     }
/*  96 */     if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/*  97 */       return (Year)parser.getEmbeddedObject();
/*     */     }
/*  99 */     if (parser.hasToken(JsonToken.START_ARRAY)) {
/* 100 */       return (Year)_deserializeFromArray(parser, context);
/*     */     }
/* 102 */     return (Year)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Year _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 108 */     String string = string0.trim();
/* 109 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 113 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/* 116 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS) && 
/* 117 */       _isValidTimestampString(string)) {
/* 118 */       return _fromNumber(ctxt, NumberInput.parseInt(string));
/*     */     }
/*     */     try {
/* 121 */       if (this._formatter == null) {
/* 122 */         return Year.parse(string);
/*     */       }
/* 124 */       return Year.parse(string, this._formatter);
/* 125 */     } catch (DateTimeException e) {
/* 126 */       return (Year)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Year _fromNumber(DeserializationContext ctxt, int value) {
/* 131 */     return Year.of(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\YearDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */