/*    */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.deser.std.DelegatingDeserializer;
/*    */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*    */ import java.io.IOException;
/*    */ import java.time.Month;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OneBasedMonthDeserializer
/*    */   extends DelegatingDeserializer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OneBasedMonthDeserializer(JsonDeserializer<?> defaultDeserializer) {
/* 20 */     super(defaultDeserializer);
/*    */   }
/*    */   public Object deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*    */     String monthSpec;
/*    */     int oneBasedMonthNumber;
/* 25 */     JsonToken token = parser.currentToken();
/* 26 */     switch (token) {
/*    */       case VALUE_NUMBER_INT:
/* 28 */         return _decodeMonth(parser.getIntValue(), parser);
/*    */       case VALUE_STRING:
/* 30 */         monthSpec = parser.getText();
/* 31 */         oneBasedMonthNumber = _decodeNumber(monthSpec);
/* 32 */         if (oneBasedMonthNumber >= 0) {
/* 33 */           return _decodeMonth(oneBasedMonthNumber, parser);
/*    */         }
/*    */         break;
/*    */     } 
/*    */     
/* 38 */     return getDelegatee().deserialize(parser, context);
/*    */   }
/*    */ 
/*    */   
/*    */   private int _decodeNumber(String text) {
/*    */     char c;
/*    */     boolean cValid;
/*    */     char c1, c2;
/*    */     boolean c12valid;
/* 47 */     switch (text.length())
/*    */     { case 1:
/* 49 */         c = text.charAt(0);
/* 50 */         cValid = ('0' <= c && c <= '9');
/* 51 */         numValue = cValid ? (c - 48) : -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 62 */         return numValue;case 2: c1 = text.charAt(0); c2 = text.charAt(1); c12valid = ('0' <= c1 && c1 <= '9' && '0' <= c2 && c2 <= '9'); numValue = c12valid ? (10 * (c1 - 48) + c2 - 48) : -1; return numValue; }  int numValue = -1; return numValue;
/*    */   }
/*    */   
/*    */   private Month _decodeMonth(int oneBasedMonthNumber, JsonParser parser) throws InvalidFormatException {
/* 66 */     if (Month.JANUARY.getValue() <= oneBasedMonthNumber && oneBasedMonthNumber <= Month.DECEMBER.getValue()) {
/* 67 */       return Month.of(oneBasedMonthNumber);
/*    */     }
/* 69 */     throw new InvalidFormatException(parser, "Month number " + oneBasedMonthNumber + " not allowed for 1-based Month.", Integer.valueOf(oneBasedMonthNumber), Integer.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JsonDeserializer<?> newDelegatingInstance(JsonDeserializer<?> newDelegatee) {
/* 74 */     return (JsonDeserializer<?>)new OneBasedMonthDeserializer(newDelegatee);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\OneBasedMonthDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */