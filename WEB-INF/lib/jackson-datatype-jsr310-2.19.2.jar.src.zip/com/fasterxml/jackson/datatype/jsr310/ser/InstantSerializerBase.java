/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonNumberFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.function.ToIntFunction;
/*     */ import java.util.function.ToLongFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InstantSerializerBase<T extends Temporal>
/*     */   extends JSR310FormattedSerializerBase<T>
/*     */ {
/*     */   private final DateTimeFormatter defaultFormat;
/*     */   private final ToLongFunction<T> getEpochMillis;
/*     */   private final ToLongFunction<T> getEpochSeconds;
/*     */   private final ToIntFunction<T> getNanoseconds;
/*     */   
/*     */   protected InstantSerializerBase(Class<T> supportedType, ToLongFunction<T> getEpochMillis, ToLongFunction<T> getEpochSeconds, ToIntFunction<T> getNanoseconds, DateTimeFormatter defaultFormat) {
/*  64 */     super(supportedType, null);
/*  65 */     this.defaultFormat = defaultFormat;
/*  66 */     this.getEpochMillis = getEpochMillis;
/*  67 */     this.getEpochSeconds = getEpochSeconds;
/*  68 */     this.getNanoseconds = getNanoseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, DateTimeFormatter dtf) {
/*  74 */     this(base, useTimestamp, base._useNanoseconds, dtf);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf) {
/*  80 */     this(base, useTimestamp, useNanoseconds, dtf, base._shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf, JsonFormat.Shape shape) {
/*  88 */     super(base, useTimestamp, useNanoseconds, dtf, shape);
/*  89 */     this.defaultFormat = base.defaultFormat;
/*  90 */     this.getEpochMillis = base.getEpochMillis;
/*  91 */     this.getEpochSeconds = base.getEpochSeconds;
/*  92 */     this.getNanoseconds = base.getNanoseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(T value, JsonGenerator generator, SerializerProvider provider) throws IOException {
/* 103 */     if (useTimestamp(provider)) {
/* 104 */       if (useNanoseconds(provider)) {
/* 105 */         generator.writeNumber(DecimalUtils.toBigDecimal(this.getEpochSeconds
/* 106 */               .applyAsLong(value), this.getNanoseconds.applyAsInt(value)));
/*     */         
/*     */         return;
/*     */       } 
/* 110 */       generator.writeNumber(this.getEpochMillis.applyAsLong(value));
/*     */       
/*     */       return;
/*     */     } 
/* 114 */     generator.writeString(formatValue(value, provider));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 122 */     if (useNanoseconds(visitor.getProvider())) {
/* 123 */       JsonNumberFormatVisitor v2 = visitor.expectNumberFormat(typeHint);
/* 124 */       if (v2 != null) {
/* 125 */         v2.numberType(JsonParser.NumberType.BIG_DECIMAL);
/*     */       }
/*     */     } else {
/* 128 */       JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 129 */       if (v2 != null) {
/* 130 */         v2.numberType(JsonParser.NumberType.LONG);
/* 131 */         v2.format(JsonValueFormat.UTC_MILLISEC);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider) {
/* 138 */     if (useTimestamp(provider)) {
/* 139 */       if (useNanoseconds(provider)) {
/* 140 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       }
/* 142 */       return JsonToken.VALUE_NUMBER_INT;
/*     */     } 
/* 144 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String formatValue(T value, SerializerProvider provider) {
/* 150 */     DateTimeFormatter formatter = (this._formatter == null) ? this.defaultFormat : this._formatter;
/* 151 */     if (formatter != null) {
/* 152 */       if (formatter.getZone() == null)
/*     */       {
/*     */         
/* 155 */         if (provider.getConfig().hasExplicitTimeZone() && provider.isEnabled(SerializationFeature.WRITE_DATES_WITH_CONTEXT_TIME_ZONE)) {
/* 156 */           formatter = formatter.withZone(provider.getTimeZone().toZoneId());
/*     */         }
/*     */       }
/* 159 */       return formatter.format((TemporalAccessor)value);
/*     */     } 
/*     */     
/* 162 */     return value.toString();
/*     */   }
/*     */   
/*     */   protected abstract JSR310FormattedSerializerBase<?> withFormat(Boolean paramBoolean, DateTimeFormatter paramDateTimeFormatter, JsonFormat.Shape paramShape);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\InstantSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */