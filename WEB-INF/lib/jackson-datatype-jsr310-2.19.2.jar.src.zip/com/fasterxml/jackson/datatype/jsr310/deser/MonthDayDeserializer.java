/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.MonthDay;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonthDayDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<MonthDay>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  21 */   public static final MonthDayDeserializer INSTANCE = new MonthDayDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MonthDayDeserializer() {
/*  30 */     this((DateTimeFormatter)null);
/*     */   }
/*     */   
/*     */   public MonthDayDeserializer(DateTimeFormatter formatter) {
/*  34 */     super(MonthDay.class, formatter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MonthDayDeserializer(MonthDayDeserializer base, Boolean leniency) {
/*  41 */     super(base, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MonthDayDeserializer(MonthDayDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape) {
/*  51 */     super(base, leniency, formatter, shape);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MonthDayDeserializer withLeniency(Boolean leniency) {
/*  56 */     return new MonthDayDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MonthDayDeserializer withDateFormat(DateTimeFormatter dtf) {
/*  61 */     return new MonthDayDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MonthDay deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/*  67 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  68 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  71 */     if (parser.isExpectedStartObjectToken()) {
/*  72 */       return _fromString(parser, context, context
/*  73 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/*  75 */     if (parser.isExpectedStartArrayToken()) {
/*  76 */       JsonToken t = parser.nextToken();
/*  77 */       if (t == JsonToken.END_ARRAY) {
/*  78 */         return null;
/*     */       }
/*  80 */       if ((t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT) && context
/*  81 */         .isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  82 */         MonthDay parsed = deserialize(parser, context);
/*  83 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  84 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/*  86 */         return parsed;
/*     */       } 
/*  88 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/*  89 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "month");
/*     */       }
/*  91 */       int month = parser.getIntValue();
/*  92 */       int day = parser.nextIntValue(-1);
/*  93 */       if (day == -1) {
/*  94 */         if (!parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/*  95 */           _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "day");
/*     */         }
/*  97 */         day = parser.getIntValue();
/*     */       } 
/*  99 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 100 */         throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */       }
/*     */       
/* 103 */       return MonthDay.of(month, day);
/*     */     } 
/* 105 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 106 */       return (MonthDay)parser.getEmbeddedObject();
/*     */     }
/* 108 */     return (MonthDay)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.START_ARRAY });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MonthDay _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 115 */     String string = string0.trim();
/* 116 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 120 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 123 */       if (this._formatter == null) {
/* 124 */         return MonthDay.parse(string);
/*     */       }
/* 126 */       return MonthDay.parse(string, this._formatter);
/* 127 */     } catch (DateTimeException e) {
/* 128 */       return (MonthDay)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\MonthDayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */