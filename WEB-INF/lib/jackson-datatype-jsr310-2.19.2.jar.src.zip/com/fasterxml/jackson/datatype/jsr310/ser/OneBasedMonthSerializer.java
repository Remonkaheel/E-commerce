/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializationFeature;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ import java.time.Month;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OneBasedMonthSerializer
/*    */   extends JsonSerializer<Month>
/*    */ {
/*    */   private final JsonSerializer<Object> _defaultSerializer;
/*    */   
/*    */   public OneBasedMonthSerializer(JsonSerializer<?> defaultSerializer) {
/* 20 */     this._defaultSerializer = (JsonSerializer)defaultSerializer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Month value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 30 */     if (ctxt.isEnabled(SerializationFeature.WRITE_ENUMS_USING_INDEX)) {
/* 31 */       gen.writeNumber(value.ordinal() + 1);
/*    */       return;
/*    */     } 
/* 34 */     this._defaultSerializer.serialize(value, gen, ctxt);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\OneBasedMonthSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */