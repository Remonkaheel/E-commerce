/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*     */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*     */ import com.fasterxml.jackson.databind.deser.KeyDeserializers;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClassResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.module.SimpleDeserializers;
/*     */ import com.fasterxml.jackson.databind.module.SimpleKeyDeserializers;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import com.fasterxml.jackson.databind.module.SimpleSerializers;
/*     */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToEmptyObjectSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.DurationDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.InstantDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.JSR310StringParsableDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.JavaTimeDeserializerModifier;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.MonthDayDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.OffsetTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearMonthDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.DurationKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.InstantKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.MonthDayKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.PeriodKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearMonthKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneIdKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneOffsetKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZonedDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.DurationSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.JavaTimeSerializerModifier;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.MonthDaySerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearMonthSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZoneIdSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.key.ZonedDateTimeKeySerializer;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Period;
/*     */ import java.time.Year;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.temporal.TemporalAdjuster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaTimeModule
/*     */   extends SimpleModule
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private JacksonFeatureSet<JavaTimeFeature> _features;
/*     */   
/*     */   public JavaTimeModule() {
/* 105 */     super(PackageVersion.VERSION);
/* 106 */     this._features = JacksonFeatureSet.fromDefaults((JacksonFeature[])JavaTimeFeature.values());
/*     */   }
/*     */   
/*     */   public JavaTimeModule enable(JavaTimeFeature f) {
/* 110 */     this._features = this._features.with(f);
/* 111 */     return this;
/*     */   }
/*     */   
/*     */   public JavaTimeModule disable(JavaTimeFeature f) {
/* 115 */     this._features = this._features.without(f);
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupModule(Module.SetupContext context) {
/* 121 */     super.setupModule(context);
/*     */     
/* 123 */     SimpleDeserializers desers = new SimpleDeserializers();
/*     */     
/* 125 */     desers.addDeserializer(Instant.class, (JsonDeserializer)InstantDeserializer.INSTANT
/* 126 */         .withFeatures(this._features));
/* 127 */     desers.addDeserializer(OffsetDateTime.class, (JsonDeserializer)InstantDeserializer.OFFSET_DATE_TIME
/* 128 */         .withFeatures(this._features));
/* 129 */     desers.addDeserializer(ZonedDateTime.class, (JsonDeserializer)InstantDeserializer.ZONED_DATE_TIME
/* 130 */         .withFeatures(this._features));
/*     */ 
/*     */     
/* 133 */     desers.addDeserializer(Duration.class, (JsonDeserializer)DurationDeserializer.INSTANCE);
/* 134 */     desers.addDeserializer(LocalDateTime.class, (JsonDeserializer)LocalDateTimeDeserializer.INSTANCE.withFeatures(this._features));
/* 135 */     desers.addDeserializer(LocalDate.class, (JsonDeserializer)LocalDateDeserializer.INSTANCE.withFeatures(this._features));
/* 136 */     desers.addDeserializer(LocalTime.class, (JsonDeserializer)LocalTimeDeserializer.INSTANCE);
/* 137 */     desers.addDeserializer(MonthDay.class, (JsonDeserializer)MonthDayDeserializer.INSTANCE);
/* 138 */     desers.addDeserializer(OffsetTime.class, (JsonDeserializer)OffsetTimeDeserializer.INSTANCE);
/* 139 */     desers.addDeserializer(Period.class, JSR310StringParsableDeserializer.PERIOD);
/* 140 */     desers.addDeserializer(Year.class, (JsonDeserializer)YearDeserializer.INSTANCE);
/* 141 */     desers.addDeserializer(YearMonth.class, (JsonDeserializer)YearMonthDeserializer.INSTANCE);
/* 142 */     desers.addDeserializer(ZoneId.class, JSR310StringParsableDeserializer.ZONE_ID);
/* 143 */     desers.addDeserializer(ZoneOffset.class, JSR310StringParsableDeserializer.ZONE_OFFSET);
/*     */     
/* 145 */     context.addDeserializers((Deserializers)desers);
/*     */     
/* 147 */     boolean oneBasedMonthEnabled = this._features.isEnabled(JavaTimeFeature.ONE_BASED_MONTHS);
/*     */     
/* 149 */     context.addBeanDeserializerModifier((BeanDeserializerModifier)new JavaTimeDeserializerModifier(oneBasedMonthEnabled));
/* 150 */     context.addBeanSerializerModifier((BeanSerializerModifier)new JavaTimeSerializerModifier(oneBasedMonthEnabled));
/*     */ 
/*     */     
/* 153 */     if (this._deserializers != null) {
/* 154 */       context.addDeserializers((Deserializers)this._deserializers);
/*     */     }
/*     */     
/* 157 */     JavaTimeSerializers sers = new JavaTimeSerializers();
/*     */     
/* 159 */     sers.addSerializer(Duration.class, (JsonSerializer)DurationSerializer.INSTANCE);
/* 160 */     sers.addSerializer(Instant.class, (JsonSerializer)InstantSerializer.INSTANCE);
/* 161 */     sers.addSerializer(LocalDateTime.class, (JsonSerializer)LocalDateTimeSerializer.INSTANCE);
/* 162 */     sers.addSerializer(LocalDate.class, (JsonSerializer)LocalDateSerializer.INSTANCE);
/* 163 */     sers.addSerializer(LocalTime.class, (JsonSerializer)LocalTimeSerializer.INSTANCE);
/* 164 */     sers.addSerializer(MonthDay.class, (JsonSerializer)MonthDaySerializer.INSTANCE);
/* 165 */     sers.addSerializer(OffsetDateTime.class, (JsonSerializer)OffsetDateTimeSerializer.INSTANCE);
/* 166 */     sers.addSerializer(OffsetTime.class, (JsonSerializer)OffsetTimeSerializer.INSTANCE);
/* 167 */     sers.addSerializer(Period.class, (JsonSerializer)new ToStringSerializer(Period.class));
/* 168 */     sers.addSerializer(Year.class, (JsonSerializer)YearSerializer.INSTANCE);
/* 169 */     sers.addSerializer(YearMonth.class, (JsonSerializer)YearMonthSerializer.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     sers.addSerializer(ZonedDateTime.class, (JsonSerializer)ZonedDateTimeSerializer.INSTANCE);
/*     */ 
/*     */ 
/*     */     
/* 180 */     sers.addSerializer(ZoneId.class, (JsonSerializer)new ZoneIdSerializer());
/* 181 */     sers.addSerializer(ZoneOffset.class, (JsonSerializer)new ToStringSerializer(ZoneOffset.class));
/*     */     
/* 183 */     context.addSerializers((Serializers)sers);
/*     */ 
/*     */     
/* 186 */     if (this._serializers != null) {
/* 187 */       context.addSerializers((Serializers)this._serializers);
/*     */     }
/*     */ 
/*     */     
/* 191 */     SimpleSerializers keySers = new SimpleSerializers();
/* 192 */     keySers.addSerializer(ZonedDateTime.class, (JsonSerializer)ZonedDateTimeKeySerializer.INSTANCE);
/* 193 */     context.addKeySerializers((Serializers)keySers);
/*     */ 
/*     */     
/* 196 */     if (this._keySerializers != null) {
/* 197 */       context.addKeySerializers((Serializers)this._keySerializers);
/*     */     }
/*     */ 
/*     */     
/* 201 */     SimpleKeyDeserializers keyDesers = new SimpleKeyDeserializers();
/* 202 */     keyDesers.addDeserializer(Duration.class, (KeyDeserializer)DurationKeyDeserializer.INSTANCE);
/* 203 */     keyDesers.addDeserializer(Instant.class, (KeyDeserializer)InstantKeyDeserializer.INSTANCE);
/* 204 */     keyDesers.addDeserializer(LocalDateTime.class, (KeyDeserializer)LocalDateTimeKeyDeserializer.INSTANCE);
/* 205 */     keyDesers.addDeserializer(LocalDate.class, (KeyDeserializer)LocalDateKeyDeserializer.INSTANCE);
/* 206 */     keyDesers.addDeserializer(LocalTime.class, (KeyDeserializer)LocalTimeKeyDeserializer.INSTANCE);
/* 207 */     keyDesers.addDeserializer(MonthDay.class, (KeyDeserializer)MonthDayKeyDeserializer.INSTANCE);
/* 208 */     keyDesers.addDeserializer(OffsetDateTime.class, (KeyDeserializer)OffsetDateTimeKeyDeserializer.INSTANCE);
/* 209 */     keyDesers.addDeserializer(OffsetTime.class, (KeyDeserializer)OffsetTimeKeyDeserializer.INSTANCE);
/* 210 */     keyDesers.addDeserializer(Period.class, (KeyDeserializer)PeriodKeyDeserializer.INSTANCE);
/* 211 */     keyDesers.addDeserializer(Year.class, (KeyDeserializer)YearKeyDeserializer.INSTANCE);
/* 212 */     keyDesers.addDeserializer(YearMonth.class, (KeyDeserializer)YearMonthKeyDeserializer.INSTANCE);
/* 213 */     keyDesers.addDeserializer(ZonedDateTime.class, (KeyDeserializer)ZonedDateTimeKeyDeserializer.INSTANCE);
/* 214 */     keyDesers.addDeserializer(ZoneId.class, (KeyDeserializer)ZoneIdKeyDeserializer.INSTANCE);
/* 215 */     keyDesers.addDeserializer(ZoneOffset.class, (KeyDeserializer)ZoneOffsetKeyDeserializer.INSTANCE);
/*     */     
/* 217 */     context.addKeyDeserializers((KeyDeserializers)keyDesers);
/*     */ 
/*     */     
/* 220 */     if (this._keyDeserializers != null) {
/* 221 */       context.addKeyDeserializers((KeyDeserializers)this._keyDeserializers);
/*     */     }
/*     */     
/* 224 */     context.addValueInstantiators((ValueInstantiators)new ValueInstantiators.Base()
/*     */         {
/*     */           
/*     */           public ValueInstantiator findValueInstantiator(DeserializationConfig config, BeanDescription beanDesc, ValueInstantiator defaultInstantiator)
/*     */           {
/* 229 */             JavaType type = beanDesc.getType();
/* 230 */             Class<?> raw = type.getRawClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 236 */             if (ZoneId.class.isAssignableFrom(raw))
/*     */             {
/* 238 */               if (defaultInstantiator instanceof StdValueInstantiator) {
/* 239 */                 AnnotatedClass ac; StdValueInstantiator inst = (StdValueInstantiator)defaultInstantiator;
/*     */ 
/*     */                 
/* 242 */                 if (raw == ZoneId.class) {
/* 243 */                   ac = beanDesc.getClassInfo();
/*     */                 }
/*     */                 else {
/*     */                   
/* 247 */                   ac = AnnotatedClassResolver.resolve((MapperConfig)config, config
/* 248 */                       .constructType(ZoneId.class), (ClassIntrospector.MixInResolver)config);
/*     */                 } 
/* 250 */                 if (!inst.canCreateFromString()) {
/* 251 */                   AnnotatedMethod factory = JavaTimeModule.this._findFactory(ac, "of", new Class[] { String.class });
/* 252 */                   if (factory != null) {
/* 253 */                     inst.configureFromStringCreator((AnnotatedWithParams)factory);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/* 260 */             return defaultInstantiator;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod _findFactory(AnnotatedClass cls, String name, Class<?>... argTypes) {
/* 267 */     int argCount = argTypes.length;
/* 268 */     for (AnnotatedMethod method : cls.getFactoryMethods()) {
/* 269 */       if (!name.equals(method.getName()) || method
/* 270 */         .getParameterCount() != argCount) {
/*     */         continue;
/*     */       }
/* 273 */       for (int i = 0; i < argCount; i++) {
/* 274 */         Class<?> argType = method.getParameter(i).getRawType();
/* 275 */         if (!argType.isAssignableFrom(argTypes[i]));
/*     */       } 
/*     */ 
/*     */       
/* 279 */       return method;
/*     */     } 
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class JavaTimeSerializers
/*     */     extends SimpleSerializers
/*     */   {
/*     */     public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) {
/* 296 */       JsonSerializer<?> ser = super.findSerializer(config, type, beanDesc);
/* 297 */       if (ser == null)
/*     */       {
/*     */ 
/*     */         
/* 301 */         if (type.isTypeOrSubTypeOf(TemporalAdjuster.class) && type
/* 302 */           .getRawClass().isSynthetic()) {
/* 303 */           return (JsonSerializer<?>)new ToEmptyObjectSerializer(type);
/*     */         }
/*     */       }
/* 306 */       return ser;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\JavaTimeModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */