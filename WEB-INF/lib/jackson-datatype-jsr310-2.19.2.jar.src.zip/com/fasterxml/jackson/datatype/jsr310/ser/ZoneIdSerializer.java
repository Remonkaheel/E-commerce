/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializerBase;
/*    */ import java.io.IOException;
/*    */ import java.time.ZoneId;
/*    */ 
/*    */ public class ZoneIdSerializer
/*    */   extends ToStringSerializerBase
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ZoneIdSerializer() {
/* 18 */     super(ZoneId.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeWithType(Object value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 25 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 26 */         .typeId(value, ZoneId.class, JsonToken.VALUE_STRING));
/* 27 */     serialize(value, g, provider);
/* 28 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*    */   }
/*    */ 
/*    */   
/*    */   public String valueToString(Object value) {
/* 33 */     return value.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\ser\ZoneIdSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */