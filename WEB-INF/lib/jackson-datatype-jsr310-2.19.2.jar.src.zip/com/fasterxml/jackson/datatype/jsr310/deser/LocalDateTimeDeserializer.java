/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.JavaTimeFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalDateTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  49 */   private static final boolean DEFAULT_USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING = JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING
/*  50 */     .enabledByDefault();
/*     */   
/*  52 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */   
/*  54 */   public static final LocalDateTimeDeserializer INSTANCE = new LocalDateTimeDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _readTimestampsAsNanosOverride;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _useTimeZoneForLenientDateParsing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer() {
/*  75 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalDateTimeDeserializer(DateTimeFormatter formatter) {
/*  79 */     super(LocalDateTime.class, formatter);
/*  80 */     this._readTimestampsAsNanosOverride = null;
/*  81 */     this._useTimeZoneForLenientDateParsing = DEFAULT_USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer(LocalDateTimeDeserializer base, Boolean leniency) {
/*  88 */     super(base, leniency);
/*  89 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/*  90 */     this._useTimeZoneForLenientDateParsing = base._useTimeZoneForLenientDateParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer(LocalDateTimeDeserializer base, Boolean leniency, DateTimeFormatter formatter, JsonFormat.Shape shape, Boolean readTimestampsAsNanosOverride) {
/* 101 */     super(base, leniency, formatter, shape);
/* 102 */     this._readTimestampsAsNanosOverride = readTimestampsAsNanosOverride;
/* 103 */     this._useTimeZoneForLenientDateParsing = base._useTimeZoneForLenientDateParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer(LocalDateTimeDeserializer base, JacksonFeatureSet<JavaTimeFeature> features) {
/* 110 */     super(LocalDateTime.class, base._formatter);
/* 111 */     this._readTimestampsAsNanosOverride = base._readTimestampsAsNanosOverride;
/* 112 */     this._useTimeZoneForLenientDateParsing = features.isEnabled((JacksonFeature)JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer withDateFormat(DateTimeFormatter dtf) {
/* 117 */     return new LocalDateTimeDeserializer(this, Boolean.valueOf(this._isLenient), dtf, this._shape, this._readTimestampsAsNanosOverride);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalDateTimeDeserializer withLeniency(Boolean leniency) {
/* 122 */     return new LocalDateTimeDeserializer(this, leniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides) {
/* 129 */     LocalDateTimeDeserializer deser = (LocalDateTimeDeserializer)super._withFormatOverrides(ctxt, property, formatOverrides);
/* 130 */     Boolean readTimestampsAsNanosOverride = formatOverrides.getFeature(JsonFormat.Feature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */     
/* 132 */     if (!Objects.equals(readTimestampsAsNanosOverride, deser._readTimestampsAsNanosOverride)) {
/* 133 */       return new LocalDateTimeDeserializer(deser, Boolean.valueOf(deser._isLenient), deser._formatter, deser._shape, readTimestampsAsNanosOverride);
/*     */     }
/*     */     
/* 136 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTimeDeserializer withFeatures(JacksonFeatureSet<JavaTimeFeature> features) {
/* 143 */     if (this._useTimeZoneForLenientDateParsing == features
/* 144 */       .isEnabled((JacksonFeature)JavaTimeFeature.USE_TIME_ZONE_FOR_LENIENT_DATE_PARSING)) {
/* 145 */       return this;
/*     */     }
/* 147 */     return new LocalDateTimeDeserializer(this, features);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTime deserialize(JsonParser parser, DeserializationContext context) throws IOException {
/* 153 */     if (parser.hasTokenId(6)) {
/* 154 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/* 157 */     if (parser.isExpectedStartObjectToken()) {
/* 158 */       return _fromString(parser, context, context
/* 159 */           .extractScalarFromObject(parser, (JsonDeserializer)this, handledType()));
/*     */     }
/* 161 */     if (parser.isExpectedStartArrayToken()) {
/* 162 */       JsonToken t = parser.nextToken();
/* 163 */       if (t == JsonToken.END_ARRAY) {
/* 164 */         return null;
/*     */       }
/* 166 */       if ((t == JsonToken.VALUE_STRING || t == JsonToken.VALUE_EMBEDDED_OBJECT) && context
/* 167 */         .isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 168 */         LocalDateTime parsed = deserialize(parser, context);
/* 169 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 170 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 172 */         return parsed;
/*     */       } 
/* 174 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*     */         LocalDateTime result;
/*     */         
/* 177 */         int year = parser.getIntValue();
/* 178 */         int month = parser.nextIntValue(-1);
/* 179 */         int day = parser.nextIntValue(-1);
/* 180 */         int hour = parser.nextIntValue(-1);
/* 181 */         int minute = parser.nextIntValue(-1);
/*     */         
/* 183 */         t = parser.nextToken();
/* 184 */         if (t == JsonToken.END_ARRAY) {
/* 185 */           result = LocalDateTime.of(year, month, day, hour, minute);
/*     */         } else {
/* 187 */           int second = parser.getIntValue();
/* 188 */           t = parser.nextToken();
/* 189 */           if (t == JsonToken.END_ARRAY) {
/* 190 */             result = LocalDateTime.of(year, month, day, hour, minute, second);
/*     */           } else {
/* 192 */             int partialSecond = parser.getIntValue();
/* 193 */             if (partialSecond < 1000 && !shouldReadTimestampsAsNanoseconds(context))
/* 194 */               partialSecond *= 1000000; 
/* 195 */             if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 196 */               throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */             }
/*     */             
/* 199 */             result = LocalDateTime.of(year, month, day, hour, minute, second, partialSecond);
/*     */           } 
/*     */         } 
/* 202 */         return result;
/*     */       } 
/* 204 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     } 
/*     */ 
/*     */     
/* 208 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 209 */       return (LocalDateTime)parser.getEmbeddedObject();
/*     */     }
/* 211 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 212 */       _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */     }
/* 214 */     return (LocalDateTime)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */   
/*     */   protected boolean shouldReadTimestampsAsNanoseconds(DeserializationContext context) {
/* 218 */     return (this._readTimestampsAsNanosOverride != null) ? this._readTimestampsAsNanosOverride.booleanValue() : context
/* 219 */       .isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalDateTime _fromString(JsonParser p, DeserializationContext ctxt, String string0) throws IOException {
/* 225 */     String string = string0.trim();
/* 226 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */       
/* 230 */       return _fromEmptyString(p, ctxt, string);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 235 */       if (this._formatter == DEFAULT_FORMATTER)
/*     */       {
/*     */         
/* 238 */         if (string.length() > 10 && string.charAt(10) == 'T' && 
/* 239 */           string.endsWith("Z")) {
/* 240 */           if (isLenient()) {
/* 241 */             if (this._useTimeZoneForLenientDateParsing) {
/* 242 */               return Instant.parse(string).atZone(ctxt.getTimeZone().toZoneId()).toLocalDateTime();
/*     */             }
/* 244 */             return LocalDateTime.parse(string.substring(0, string.length() - 1), this._formatter);
/*     */           } 
/*     */           
/* 247 */           JavaType t = getValueType(ctxt);
/* 248 */           return (LocalDateTime)ctxt.handleWeirdStringValue(t.getRawClass(), string, "Should not contain offset when 'strict' mode set for property or type (enable 'lenient' handling to allow)", new Object[0]);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       return LocalDateTime.parse(string, this._formatter);
/* 256 */     } catch (DateTimeException e) {
/* 257 */       return (LocalDateTime)_handleDateTimeException(ctxt, e, string);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalDateTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */