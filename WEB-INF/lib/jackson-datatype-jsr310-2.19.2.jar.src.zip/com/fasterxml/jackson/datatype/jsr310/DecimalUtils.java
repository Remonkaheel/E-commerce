/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.Instant;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecimalUtils
/*     */ {
/*     */   public static String toDecimal(long seconds, int nanoseconds) {
/*  39 */     StringBuilder sb = (new StringBuilder(20)).append(seconds).append('.');
/*     */ 
/*     */     
/*  42 */     if (nanoseconds == 0L) {
/*     */ 
/*     */       
/*  45 */       if (seconds == 0L) {
/*  46 */         return "0.0";
/*     */       }
/*     */ 
/*     */       
/*  50 */       sb.append("000000000");
/*     */     } else {
/*  52 */       StringBuilder nanoSB = new StringBuilder(9);
/*  53 */       nanoSB.append(nanoseconds);
/*     */       
/*  55 */       int nanosLen = nanoSB.length();
/*  56 */       int prepZeroes = 9 - nanosLen;
/*  57 */       while (prepZeroes > 0) {
/*  58 */         prepZeroes--;
/*  59 */         sb.append('0');
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       sb.append(nanoSB);
/*     */     } 
/*  76 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal toBigDecimal(long seconds, int nanoseconds) {
/*  87 */     if (nanoseconds == 0L) {
/*     */ 
/*     */       
/*  90 */       if (seconds == 0L) {
/*  91 */         return BigDecimal.ZERO.setScale(1);
/*     */       }
/*  93 */       return BigDecimal.valueOf(seconds).setScale(9);
/*     */     } 
/*  95 */     return NumberInput.parseBigDecimal(toDecimal(seconds, nanoseconds), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T extractSecondsAndNanos(BigDecimal seconds, BiFunction<Long, Integer, T> convert) {
/* 109 */     return extractSecondsAndNanos(seconds, convert, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T extractSecondsAndNanos(BigDecimal seconds, BiFunction<Long, Integer, T> convert, boolean negativeAdjustment) {
/*     */     long secondsOnly;
/*     */     int nanosOnly;
/* 126 */     BigDecimal nanoseconds = seconds.scaleByPowerOfTen(9);
/* 127 */     if (nanoseconds.precision() - nanoseconds.scale() <= 0) {
/*     */ 
/*     */       
/* 130 */       secondsOnly = (nanosOnly = 0);
/*     */     }
/* 132 */     else if (seconds.scale() < -63) {
/*     */ 
/*     */       
/* 135 */       secondsOnly = (nanosOnly = 0);
/*     */     }
/*     */     else {
/*     */       
/* 139 */       secondsOnly = seconds.longValue();
/* 140 */       nanosOnly = nanoseconds.subtract(BigDecimal.valueOf(secondsOnly).scaleByPowerOfTen(9)).intValue();
/*     */       
/* 142 */       if (secondsOnly < 0L && secondsOnly > Instant.MIN.getEpochSecond())
/*     */       {
/* 144 */         if (negativeAdjustment)
/*     */         {
/* 146 */           nanosOnly = Math.abs(nanosOnly);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 151 */     return convert.apply(Long.valueOf(secondsOnly), Integer.valueOf(nanosOnly));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\DecimalUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */