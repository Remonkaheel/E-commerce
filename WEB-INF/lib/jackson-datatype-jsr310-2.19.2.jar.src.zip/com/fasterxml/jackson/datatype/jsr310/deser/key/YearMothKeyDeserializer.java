/*   */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*   */ 
/*   */ 
/*   */ 
/*   */ @Deprecated
/*   */ public class YearMothKeyDeserializer
/*   */   extends YearMonthKeyDeserializer
/*   */ {
/* 9 */   public static final YearMothKeyDeserializer INSTANCE = new YearMothKeyDeserializer();
/*   */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jsr310-2.19.2.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearMothKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */