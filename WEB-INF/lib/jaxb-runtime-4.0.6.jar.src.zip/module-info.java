module org.glassfish.jaxb.runtime {
  requires java.base;
  requires transitive jakarta.xml.bind;
  requires java.desktop;
  requires java.logging;
  requires transitive jakarta.activation;
  requires transitive java.xml;
  requires transitive org.glassfish.jaxb.core;
  requires com.sun.xml.fastinfoset;
  requires org.jvnet.staxex;
  
  exports org.glassfish.jaxb.runtime;
  exports org.glassfish.jaxb.runtime.api;
  exports org.glassfish.jaxb.runtime.marshaller;
  exports org.glassfish.jaxb.runtime.unmarshaller;
  exports org.glassfish.jaxb.runtime.util;
  exports org.glassfish.jaxb.runtime.v2;
  exports org.glassfish.jaxb.runtime.v2.model.annotation;
  exports org.glassfish.jaxb.runtime.v2.model.impl;
  exports org.glassfish.jaxb.runtime.v2.model.runtime;
  exports org.glassfish.jaxb.runtime.v2.runtime;
  exports org.glassfish.jaxb.runtime.v2.runtime.reflect;
  exports org.glassfish.jaxb.runtime.v2.runtime.output;
  exports org.glassfish.jaxb.runtime.v2.runtime.property;
  exports org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
  exports org.glassfish.jaxb.runtime.v2.schemagen;
  exports org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;
  exports org.glassfish.jaxb.runtime.v2.util;
  
  opens org.glassfish.jaxb.runtime.v2.runtime.reflect.opt to jakarta.xml.bind;
  opens org.glassfish.jaxb.runtime.v2.schemagen to jakarta.xml.bind;
  opens org.glassfish.jaxb.runtime.v2.schemagen.xmlschema to jakarta.xml.bind;
  
  provides jakarta.xml.bind.JAXBContextFactory with org.glassfish.jaxb.runtime.v2.JAXBContextFactory;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */