/*     */ package org.glassfish.jaxb.runtime.util;
/*     */ 
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributesImpl
/*     */   implements Attributes
/*     */ {
/*     */   int length;
/*     */   String[] data;
/*     */   
/*     */   public AttributesImpl() {
/*  68 */     this.length = 0;
/*  69 */     this.data = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributesImpl(Attributes atts) {
/*  83 */     setAttributes(atts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 101 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getURI(int index) {
/* 115 */     if (index >= 0 && index < this.length) {
/* 116 */       return this.data[index * 5];
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalName(int index) {
/* 133 */     if (index >= 0 && index < this.length) {
/* 134 */       return this.data[index * 5 + 1];
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQName(int index) {
/* 151 */     if (index >= 0 && index < this.length) {
/* 152 */       return this.data[index * 5 + 2];
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(int index) {
/* 169 */     if (index >= 0 && index < this.length) {
/* 170 */       return this.data[index * 5 + 3];
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(int index) {
/* 186 */     if (index >= 0 && index < this.length) {
/* 187 */       return this.data[index * 5 + 4];
/*     */     }
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(String uri, String localName) {
/* 209 */     int max = this.length * 5;
/* 210 */     for (int i = 0; i < max; i += 5) {
/* 211 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 212 */         return i / 5;
/*     */       }
/*     */     } 
/* 215 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndexFast(String uri, String localName) {
/* 222 */     for (int i = (this.length - 1) * 5; i >= 0; i -= 5) {
/*     */       
/* 224 */       if (this.data[i + 1] == localName && this.data[i] == uri) {
/* 225 */         return i / 5;
/*     */       }
/*     */     } 
/* 228 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(String qName) {
/* 241 */     int max = this.length * 5;
/* 242 */     for (int i = 0; i < max; i += 5) {
/* 243 */       if (this.data[i + 2].equals(qName)) {
/* 244 */         return i / 5;
/*     */       }
/*     */     } 
/* 247 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(String uri, String localName) {
/* 263 */     int max = this.length * 5;
/* 264 */     for (int i = 0; i < max; i += 5) {
/* 265 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 266 */         return this.data[i + 3];
/*     */       }
/*     */     } 
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(String qName) {
/* 283 */     int max = this.length * 5;
/* 284 */     for (int i = 0; i < max; i += 5) {
/* 285 */       if (this.data[i + 2].equals(qName)) {
/* 286 */         return this.data[i + 3];
/*     */       }
/*     */     } 
/* 289 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(String uri, String localName) {
/* 305 */     int max = this.length * 5;
/* 306 */     for (int i = 0; i < max; i += 5) {
/* 307 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 308 */         return this.data[i + 4];
/*     */       }
/*     */     } 
/* 311 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(String qName) {
/* 325 */     int max = this.length * 5;
/* 326 */     for (int i = 0; i < max; i += 5) {
/* 327 */       if (this.data[i + 2].equals(qName)) {
/* 328 */         return this.data[i + 4];
/*     */       }
/*     */     } 
/* 331 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 350 */     if (this.data != null)
/* 351 */       for (int i = 0; i < this.length * 5; i++) {
/* 352 */         this.data[i] = null;
/*     */       } 
/* 354 */     this.length = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Attributes atts) {
/* 368 */     clear();
/* 369 */     this.length = atts.getLength();
/* 370 */     if (this.length > 0) {
/* 371 */       this.data = new String[this.length * 5];
/* 372 */       for (int i = 0; i < this.length; i++) {
/* 373 */         this.data[i * 5] = atts.getURI(i);
/* 374 */         this.data[i * 5 + 1] = atts.getLocalName(i);
/* 375 */         this.data[i * 5 + 2] = atts.getQName(i);
/* 376 */         this.data[i * 5 + 3] = atts.getType(i);
/* 377 */         this.data[i * 5 + 4] = atts.getValue(i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(String uri, String localName, String qName, String type, String value) {
/* 403 */     ensureCapacity(this.length + 1);
/* 404 */     this.data[this.length * 5] = uri;
/* 405 */     this.data[this.length * 5 + 1] = localName;
/* 406 */     this.data[this.length * 5 + 2] = qName;
/* 407 */     this.data[this.length * 5 + 3] = type;
/* 408 */     this.data[this.length * 5 + 4] = value;
/* 409 */     this.length++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(int index, String uri, String localName, String qName, String type, String value) {
/* 437 */     if (index >= 0 && index < this.length) {
/* 438 */       this.data[index * 5] = uri;
/* 439 */       this.data[index * 5 + 1] = localName;
/* 440 */       this.data[index * 5 + 2] = qName;
/* 441 */       this.data[index * 5 + 3] = type;
/* 442 */       this.data[index * 5 + 4] = value;
/*     */     } else {
/* 444 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(int index) {
/* 459 */     if (index >= 0 && index < this.length) {
/* 460 */       if (index < this.length - 1) {
/* 461 */         System.arraycopy(this.data, (index + 1) * 5, this.data, index * 5, (this.length - index - 1) * 5);
/*     */       }
/*     */       
/* 464 */       index = (this.length - 1) * 5;
/* 465 */       this.data[index++] = null;
/* 466 */       this.data[index++] = null;
/* 467 */       this.data[index++] = null;
/* 468 */       this.data[index++] = null;
/* 469 */       this.data[index] = null;
/* 470 */       this.length--;
/*     */     } else {
/* 472 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURI(int index, String uri) {
/* 489 */     if (index >= 0 && index < this.length) {
/* 490 */       this.data[index * 5] = uri;
/*     */     } else {
/* 492 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalName(int index, String localName) {
/* 509 */     if (index >= 0 && index < this.length) {
/* 510 */       this.data[index * 5 + 1] = localName;
/*     */     } else {
/* 512 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQName(int index, String qName) {
/* 529 */     if (index >= 0 && index < this.length) {
/* 530 */       this.data[index * 5 + 2] = qName;
/*     */     } else {
/* 532 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(int index, String type) {
/* 548 */     if (index >= 0 && index < this.length) {
/* 549 */       this.data[index * 5 + 3] = type;
/*     */     } else {
/* 551 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int index, String value) {
/* 567 */     if (index >= 0 && index < this.length) {
/* 568 */       this.data[index * 5 + 4] = value;
/*     */     } else {
/* 570 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity(int n) {
/*     */     int max;
/* 588 */     if (n <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 592 */     if (this.data == null || this.data.length == 0) {
/* 593 */       max = 25;
/*     */     } else {
/* 595 */       if (this.data.length >= n * 5) {
/*     */         return;
/*     */       }
/*     */       
/* 599 */       max = this.data.length;
/*     */     } 
/* 601 */     while (max < n * 5) {
/* 602 */       max *= 2;
/*     */     }
/*     */     
/* 605 */     String[] newData = new String[max];
/* 606 */     if (this.length > 0) {
/* 607 */       System.arraycopy(this.data, 0, newData, 0, this.length * 5);
/*     */     }
/* 609 */     this.data = newData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void badIndex(int index) throws ArrayIndexOutOfBoundsException {
/* 622 */     String msg = "Attempt to modify attribute at illegal index: " + index;
/*     */     
/* 624 */     throw new ArrayIndexOutOfBoundsException(msg);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtim\\util\AttributesImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */