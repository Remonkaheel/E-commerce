/*    */ package org.glassfish.jaxb.runtime.util;
/*    */ 
/*    */ import jakarta.xml.bind.helpers.ValidationEventLocatorImpl;
/*    */ import org.glassfish.jaxb.runtime.ValidationEventLocatorEx;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationEventLocatorExImpl
/*    */   extends ValidationEventLocatorImpl
/*    */   implements ValidationEventLocatorEx
/*    */ {
/*    */   private final String fieldName;
/*    */   
/*    */   public ValidationEventLocatorExImpl(Object target, String fieldName) {
/* 28 */     super(target);
/* 29 */     this.fieldName = fieldName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFieldName() {
/* 34 */     return this.fieldName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     StringBuilder buf = new StringBuilder();
/* 43 */     buf.append("[url=");
/* 44 */     buf.append(getURL());
/* 45 */     buf.append(",line=");
/* 46 */     buf.append(getLineNumber());
/* 47 */     buf.append(",column=");
/* 48 */     buf.append(getColumnNumber());
/* 49 */     buf.append(",node=");
/* 50 */     buf.append(getNode());
/* 51 */     buf.append(",object=");
/* 52 */     buf.append(getObject());
/* 53 */     buf.append(",field=");
/* 54 */     buf.append(getFieldName());
/* 55 */     buf.append("]");
/*    */     
/* 57 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtim\\util\ValidationEventLocatorExImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */