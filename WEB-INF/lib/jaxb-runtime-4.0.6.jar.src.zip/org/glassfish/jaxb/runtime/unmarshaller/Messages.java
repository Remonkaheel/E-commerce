/*    */ package org.glassfish.jaxb.runtime.unmarshaller;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Messages
/*    */ {
/*    */   public static final String UNEXPECTED_ENTER_ELEMENT = "ContentHandlerEx.UnexpectedEnterElement";
/*    */   public static final String UNEXPECTED_LEAVE_ELEMENT = "ContentHandlerEx.UnexpectedLeaveElement";
/*    */   public static final String UNEXPECTED_ENTER_ATTRIBUTE = "ContentHandlerEx.UnexpectedEnterAttribute";
/*    */   public static final String UNEXPECTED_LEAVE_ATTRIBUTE = "ContentHandlerEx.UnexpectedLeaveAttribute";
/*    */   public static final String UNEXPECTED_TEXT = "ContentHandlerEx.UnexpectedText";
/*    */   public static final String UNEXPECTED_LEAVE_CHILD = "ContentHandlerEx.UnexpectedLeaveChild";
/*    */   public static final String UNEXPECTED_ROOT_ELEMENT = "SAXUnmarshallerHandlerImpl.UnexpectedRootElement";
/*    */   public static final String UNDEFINED_PREFIX = "Util.UndefinedPrefix";
/*    */   public static final String NULL_READER = "Unmarshaller.NullReader";
/*    */   public static final String ILLEGAL_READER_STATE = "Unmarshaller.IllegalReaderState";
/*    */   
/*    */   public static String format(String property) {
/* 29 */     return format(property, (Object[])null);
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1) {
/* 33 */     return format(property, new Object[] { arg1 });
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1, Object arg2) {
/* 37 */     return format(property, new Object[] { arg1, arg2 });
/*    */   }
/*    */   
/*    */   public static String format(String property, Object arg1, Object arg2, Object arg3) {
/* 41 */     return format(property, new Object[] { arg1, arg2, arg3 });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String format(String property, Object[] args) {
/* 48 */     String text = ResourceBundle.getBundle(Messages.class.getName()).getString(property);
/* 49 */     return MessageFormat.format(text, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtim\\unmarshaller\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */