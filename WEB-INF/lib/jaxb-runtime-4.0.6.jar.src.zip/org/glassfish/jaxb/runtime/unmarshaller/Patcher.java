package org.glassfish.jaxb.runtime.unmarshaller;

import org.xml.sax.SAXException;

public interface Patcher {
  void run() throws SAXException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtim\\unmarshaller\Patcher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */