package org.glassfish.jaxb.runtime;

import jakarta.xml.bind.JAXBException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;

public interface AccessorFactory {
  Accessor createFieldAccessor(Class paramClass, Field paramField, boolean paramBoolean) throws JAXBException;
  
  Accessor createPropertyAccessor(Class paramClass, Method paramMethod1, Method paramMethod2) throws JAXBException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\AccessorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */