/*    */ package org.glassfish.jaxb.runtime;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessorFactoryImpl
/*    */   implements InternalAccessorFactory
/*    */ {
/* 20 */   private static AccessorFactoryImpl instance = new AccessorFactoryImpl();
/*    */ 
/*    */   
/*    */   public static AccessorFactoryImpl getInstance() {
/* 24 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Accessor createFieldAccessor(Class bean, Field field, boolean readOnly) {
/* 37 */     return readOnly ? 
/* 38 */       (Accessor)new Accessor.ReadOnlyFieldReflection(field) : 
/* 39 */       (Accessor)new Accessor.FieldReflection(field);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Accessor createFieldAccessor(Class bean, Field field, boolean readOnly, boolean supressWarning) {
/* 53 */     return readOnly ? 
/* 54 */       (Accessor)new Accessor.ReadOnlyFieldReflection(field, supressWarning) : 
/* 55 */       (Accessor)new Accessor.FieldReflection(field, supressWarning);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Accessor createPropertyAccessor(Class bean, Method getter, Method setter) {
/* 68 */     if (getter == null) {
/* 69 */       return (Accessor)new Accessor.SetterOnlyReflection(setter);
/*    */     }
/* 71 */     if (setter == null) {
/* 72 */       return (Accessor)new Accessor.GetterOnlyReflection(getter);
/*    */     }
/* 74 */     return (Accessor)new Accessor.GetterSetterReflection(getter, setter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\AccessorFactoryImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */