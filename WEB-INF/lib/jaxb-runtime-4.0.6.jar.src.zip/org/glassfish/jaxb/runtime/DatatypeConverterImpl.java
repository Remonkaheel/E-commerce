/*      */ package org.glassfish.jaxb.runtime;
/*      */ 
/*      */ import jakarta.xml.bind.DatatypeConverterInterface;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.WeakHashMap;
/*      */ import javax.xml.datatype.DatatypeConfigurationException;
/*      */ import javax.xml.datatype.DatatypeFactory;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.stream.XMLStreamWriter;
/*      */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Deprecated
/*      */ public final class DatatypeConverterImpl
/*      */   implements DatatypeConverterInterface
/*      */ {
/*      */   @Deprecated
/*   50 */   public static final DatatypeConverterInterface theInstance = new DatatypeConverterImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger _parseInteger(CharSequence s) {
/*   57 */     return new BigInteger(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */   
/*      */   public static String _printInteger(BigInteger val) {
/*   61 */     return val.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _parseInt(CharSequence s) {
/*   75 */     int len = s.length();
/*   76 */     int sign = 1;
/*      */     
/*   78 */     int r = 0;
/*      */     
/*   80 */     for (int i = 0; i < len; i++) {
/*   81 */       char ch = s.charAt(i);
/*   82 */       if (!WhiteSpaceProcessor.isWhiteSpace(ch))
/*      */       {
/*   84 */         if ('0' <= ch && ch <= '9') {
/*   85 */           r = r * 10 + ch - 48;
/*   86 */         } else if (ch == '-') {
/*   87 */           sign = -1;
/*   88 */         } else if (ch != '+') {
/*      */ 
/*      */           
/*   91 */           throw new NumberFormatException("Not a number: " + s);
/*      */         } 
/*      */       }
/*      */     } 
/*   95 */     return r * sign;
/*      */   }
/*      */   
/*      */   public static long _parseLong(CharSequence s) {
/*   99 */     return Long.parseLong(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */   
/*      */   public static short _parseShort(CharSequence s) {
/*  103 */     return (short)_parseInt(s);
/*      */   }
/*      */   
/*      */   public static String _printShort(short val) {
/*  107 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public static BigDecimal _parseDecimal(CharSequence content) {
/*  111 */     content = WhiteSpaceProcessor.trim(content);
/*      */     
/*  113 */     if (content.length() <= 0) {
/*  114 */       return null;
/*      */     }
/*      */     
/*  117 */     return new BigDecimal(content.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float _parseFloat(CharSequence _val) {
/*  133 */     String s = WhiteSpaceProcessor.trim(_val).toString();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  149 */     if (s.equals("NaN")) {
/*  150 */       return Float.NaN;
/*      */     }
/*  152 */     if (s.equals("INF")) {
/*  153 */       return Float.POSITIVE_INFINITY;
/*      */     }
/*  155 */     if (s.equals("-INF")) {
/*  156 */       return Float.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  159 */     if (s.length() == 0 || 
/*  160 */       !isDigitOrPeriodOrSign(s.charAt(0)) || 
/*  161 */       !isDigitOrPeriodOrSign(s.charAt(s.length() - 1))) {
/*  162 */       throw new NumberFormatException();
/*      */     }
/*      */ 
/*      */     
/*  166 */     return Float.parseFloat(s);
/*      */   }
/*      */   
/*      */   public static String _printFloat(float v) {
/*  170 */     if (Float.isNaN(v)) {
/*  171 */       return "NaN";
/*      */     }
/*  173 */     if (v == Float.POSITIVE_INFINITY) {
/*  174 */       return "INF";
/*      */     }
/*  176 */     if (v == Float.NEGATIVE_INFINITY) {
/*  177 */       return "-INF";
/*      */     }
/*  179 */     return String.valueOf(v);
/*      */   }
/*      */   
/*      */   public static double _parseDouble(CharSequence _val) {
/*  183 */     String val = WhiteSpaceProcessor.trim(_val).toString();
/*      */     
/*  185 */     if (val.equals("NaN")) {
/*  186 */       return Double.NaN;
/*      */     }
/*  188 */     if (val.equals("INF")) {
/*  189 */       return Double.POSITIVE_INFINITY;
/*      */     }
/*  191 */     if (val.equals("-INF")) {
/*  192 */       return Double.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  195 */     if (val.length() == 0 || 
/*  196 */       !isDigitOrPeriodOrSign(val.charAt(0)) || 
/*  197 */       !isDigitOrPeriodOrSign(val.charAt(val.length() - 1))) {
/*  198 */       throw new NumberFormatException(val);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  203 */     return Double.parseDouble(val);
/*      */   } public static Boolean _parseBoolean(CharSequence literal) {
/*      */     char ch;
/*      */     String strTrue, strFalse;
/*  207 */     if (literal == null) {
/*  208 */       return null;
/*      */     }
/*      */     
/*  211 */     int i = 0;
/*  212 */     int len = literal.length();
/*      */     
/*  214 */     boolean value = false;
/*      */     
/*  216 */     if (len <= 0) {
/*  217 */       return null;
/*      */     }
/*      */     
/*      */     do {
/*  221 */       ch = literal.charAt(i++);
/*  222 */     } while (WhiteSpaceProcessor.isWhiteSpace(ch) && i < len);
/*      */     
/*  224 */     int strIndex = 0;
/*      */     
/*  226 */     switch (ch) {
/*      */       case '1':
/*  228 */         value = true;
/*      */         break;
/*      */       case '0':
/*  231 */         value = false;
/*      */         break;
/*      */       case 't':
/*  234 */         strTrue = "rue";
/*      */         do {
/*  236 */           ch = literal.charAt(i++);
/*  237 */         } while (strTrue.charAt(strIndex++) == ch && i < len && strIndex < 3);
/*      */         
/*  239 */         if (strIndex == 3 && strTrue.charAt(strIndex - 1) == ch) {
/*  240 */           value = true; break;
/*      */         } 
/*  242 */         return null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'f':
/*  248 */         strFalse = "alse";
/*      */         do {
/*  250 */           ch = literal.charAt(i++);
/*  251 */         } while (strFalse.charAt(strIndex++) == ch && i < len && strIndex < 4);
/*      */ 
/*      */         
/*  254 */         if (strIndex == 4 && strFalse.charAt(strIndex - 1) == ch) {
/*  255 */           value = false; break;
/*      */         } 
/*  257 */         return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  264 */     if (i < len) {
/*  265 */       while (i < len && WhiteSpaceProcessor.isWhiteSpace(literal.charAt(i))) {
/*  266 */         i++;
/*      */       }
/*      */     }
/*      */     
/*  270 */     if (i == len) {
/*  271 */       return Boolean.valueOf(value);
/*      */     }
/*  273 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _printBoolean(boolean val) {
/*  279 */     return val ? "true" : "false";
/*      */   }
/*      */   
/*      */   public static byte _parseByte(CharSequence literal) {
/*  283 */     return (byte)_parseInt(literal);
/*      */   }
/*      */   
/*      */   public static String _printByte(byte val) {
/*  287 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static QName _parseQName(CharSequence text, NamespaceContext nsc) {
/*      */     String uri, localPart, prefix;
/*  294 */     int length = text.length();
/*      */ 
/*      */     
/*  297 */     int start = 0;
/*  298 */     while (start < length && WhiteSpaceProcessor.isWhiteSpace(text.charAt(start))) {
/*  299 */       start++;
/*      */     }
/*      */     
/*  302 */     int end = length;
/*  303 */     while (end > start && WhiteSpaceProcessor.isWhiteSpace(text.charAt(end - 1))) {
/*  304 */       end--;
/*      */     }
/*      */     
/*  307 */     if (end == start) {
/*  308 */       throw new IllegalArgumentException("input is empty");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  317 */     int idx = start + 1;
/*  318 */     while (idx < end && text.charAt(idx) != ':') {
/*  319 */       idx++;
/*      */     }
/*      */     
/*  322 */     if (idx == end) {
/*  323 */       uri = nsc.getNamespaceURI("");
/*  324 */       localPart = text.subSequence(start, end).toString();
/*  325 */       prefix = "";
/*      */     } else {
/*      */       
/*  328 */       prefix = text.subSequence(start, idx).toString();
/*  329 */       localPart = text.subSequence(idx + 1, end).toString();
/*  330 */       uri = nsc.getNamespaceURI(prefix);
/*      */ 
/*      */       
/*  333 */       if (uri == null || uri.length() == 0)
/*      */       {
/*      */         
/*  336 */         throw new IllegalArgumentException("prefix " + prefix + " is not bound to a namespace");
/*      */       }
/*      */     } 
/*      */     
/*  340 */     return new QName(uri, localPart, prefix);
/*      */   }
/*      */   
/*      */   public static GregorianCalendar _parseDateTime(CharSequence s) {
/*  344 */     String val = WhiteSpaceProcessor.trim(s).toString();
/*  345 */     return getDatatypeFactory().newXMLGregorianCalendar(val).toGregorianCalendar();
/*      */   }
/*      */   
/*      */   public static String _printDateTime(Calendar val) {
/*  349 */     return CalendarFormatter.doFormat("%Y-%M-%DT%h:%m:%s%z", val);
/*      */   }
/*      */   
/*      */   public static String _printDate(Calendar val) {
/*  353 */     return CalendarFormatter.doFormat("%Y-%M-%D%z", val);
/*      */   }
/*      */   
/*      */   public static String _printInt(int val) {
/*  357 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public static String _printLong(long val) {
/*  361 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public static String _printDecimal(BigDecimal val) {
/*  365 */     return val.toPlainString();
/*      */   }
/*      */   
/*      */   public static String _printDouble(double v) {
/*  369 */     if (Double.isNaN(v)) {
/*  370 */       return "NaN";
/*      */     }
/*  372 */     if (v == Double.POSITIVE_INFINITY) {
/*  373 */       return "INF";
/*      */     }
/*  375 */     if (v == Double.NEGATIVE_INFINITY) {
/*  376 */       return "-INF";
/*      */     }
/*  378 */     return String.valueOf(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _printQName(QName val, NamespaceContext nsc) {
/*  384 */     String qname, prefix = nsc.getPrefix(val.getNamespaceURI());
/*  385 */     String localPart = val.getLocalPart();
/*      */     
/*  387 */     if (prefix == null || prefix.length() == 0) {
/*  388 */       qname = localPart;
/*      */     } else {
/*  390 */       qname = prefix + ":" + prefix;
/*      */     } 
/*      */     
/*  393 */     return qname;
/*      */   }
/*      */ 
/*      */   
/*  397 */   private static final byte[] decodeMap = initDecodeMap();
/*      */   private static final byte PADDING = 127;
/*      */   
/*      */   private static byte[] initDecodeMap() {
/*  401 */     byte[] map = new byte[128];
/*      */     int i;
/*  403 */     for (i = 0; i < 128; i++) {
/*  404 */       map[i] = -1;
/*      */     }
/*      */     
/*  407 */     for (i = 65; i <= 90; i++) {
/*  408 */       map[i] = (byte)(i - 65);
/*      */     }
/*  410 */     for (i = 97; i <= 122; i++) {
/*  411 */       map[i] = (byte)(i - 97 + 26);
/*      */     }
/*  413 */     for (i = 48; i <= 57; i++) {
/*  414 */       map[i] = (byte)(i - 48 + 52);
/*      */     }
/*  416 */     map[43] = 62;
/*  417 */     map[47] = 63;
/*  418 */     map[61] = Byte.MAX_VALUE;
/*      */     
/*  420 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int guessLength(String text) {
/*  444 */     int len = text.length();
/*      */ 
/*      */     
/*  447 */     int j = len - 1;
/*  448 */     while (j >= 0) {
/*  449 */       byte code = decodeMap[text.charAt(j)];
/*  450 */       if (code == Byte.MAX_VALUE) {
/*      */         j--; continue;
/*      */       } 
/*  453 */       if (code == -1)
/*      */       {
/*  455 */         return text.length() / 4 * 3;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  460 */     j++;
/*  461 */     int padSize = len - j;
/*  462 */     if (padSize > 2)
/*      */     {
/*  464 */       return text.length() / 4 * 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  469 */     return text.length() / 4 * 3 - padSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] _parseBase64Binary(String text) {
/*  482 */     int buflen = guessLength(text);
/*  483 */     byte[] out = new byte[buflen];
/*  484 */     int o = 0;
/*      */     
/*  486 */     int len = text.length();
/*      */ 
/*      */     
/*  489 */     byte[] quadruplet = new byte[4];
/*  490 */     int q = 0;
/*      */ 
/*      */     
/*  493 */     for (int i = 0; i < len; i++) {
/*  494 */       char ch = text.charAt(i);
/*  495 */       byte v = decodeMap[ch];
/*      */       
/*  497 */       if (v != -1) {
/*  498 */         quadruplet[q++] = v;
/*      */       }
/*      */       
/*  501 */       if (q == 4) {
/*      */         
/*  503 */         out[o++] = (byte)(quadruplet[0] << 2 | quadruplet[1] >> 4);
/*  504 */         if (quadruplet[2] != Byte.MAX_VALUE) {
/*  505 */           out[o++] = (byte)(quadruplet[1] << 4 | quadruplet[2] >> 2);
/*      */         }
/*  507 */         if (quadruplet[3] != Byte.MAX_VALUE) {
/*  508 */           out[o++] = (byte)(quadruplet[2] << 6 | quadruplet[3]);
/*      */         }
/*  510 */         q = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  514 */     if (buflen == o)
/*      */     {
/*  516 */       return out;
/*      */     }
/*      */ 
/*      */     
/*  520 */     byte[] nb = new byte[o];
/*  521 */     System.arraycopy(out, 0, nb, 0, o);
/*  522 */     return nb;
/*      */   }
/*  524 */   private static final char[] encodeMap = initEncodeMap();
/*      */   
/*      */   private static char[] initEncodeMap() {
/*  527 */     char[] map = new char[64];
/*      */     int i;
/*  529 */     for (i = 0; i < 26; i++) {
/*  530 */       map[i] = (char)(65 + i);
/*      */     }
/*  532 */     for (i = 26; i < 52; i++) {
/*  533 */       map[i] = (char)(97 + i - 26);
/*      */     }
/*  535 */     for (i = 52; i < 62; i++) {
/*  536 */       map[i] = (char)(48 + i - 52);
/*      */     }
/*  538 */     map[62] = '+';
/*  539 */     map[63] = '/';
/*      */     
/*  541 */     return map;
/*      */   }
/*      */   
/*      */   public static char encode(int i) {
/*  545 */     return encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static byte encodeByte(int i) {
/*  549 */     return (byte)encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input) {
/*  553 */     return _printBase64Binary(input, 0, input.length);
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input, int offset, int len) {
/*  557 */     char[] buf = new char[(len + 2) / 3 * 4];
/*  558 */     int ptr = _printBase64Binary(input, offset, len, buf, 0);
/*  559 */     assert ptr == buf.length;
/*  560 */     return new String(buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, char[] buf, int ptr) {
/*  574 */     int remaining = len;
/*      */     int i;
/*  576 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  577 */       buf[ptr++] = encode(input[i] >> 2);
/*  578 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  581 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  584 */       buf[ptr++] = encode(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  587 */     if (remaining == 1) {
/*  588 */       buf[ptr++] = encode(input[i] >> 2);
/*  589 */       buf[ptr++] = encode((input[i] & 0x3) << 4);
/*  590 */       buf[ptr++] = '=';
/*  591 */       buf[ptr++] = '=';
/*      */     } 
/*      */     
/*  594 */     if (remaining == 2) {
/*  595 */       buf[ptr++] = encode(input[i] >> 2);
/*  596 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */       
/*  598 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2);
/*  599 */       buf[ptr++] = '=';
/*      */     } 
/*  601 */     return ptr;
/*      */   }
/*      */   
/*      */   public static void _printBase64Binary(byte[] input, int offset, int len, XMLStreamWriter output) throws XMLStreamException {
/*  605 */     int remaining = len;
/*      */     
/*  607 */     char[] buf = new char[4];
/*      */     int i;
/*  609 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  610 */       buf[0] = encode(input[i] >> 2);
/*  611 */       buf[1] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  614 */       buf[2] = encode((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  617 */       buf[3] = encode(input[i + 2] & 0x3F);
/*  618 */       output.writeCharacters(buf, 0, 4);
/*      */     } 
/*      */     
/*  621 */     if (remaining == 1) {
/*  622 */       buf[0] = encode(input[i] >> 2);
/*  623 */       buf[1] = encode((input[i] & 0x3) << 4);
/*  624 */       buf[2] = '=';
/*  625 */       buf[3] = '=';
/*  626 */       output.writeCharacters(buf, 0, 4);
/*      */     } 
/*      */     
/*  629 */     if (remaining == 2) {
/*  630 */       buf[0] = encode(input[i] >> 2);
/*  631 */       buf[1] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */       
/*  633 */       buf[2] = encode((input[i + 1] & 0xF) << 2);
/*  634 */       buf[3] = '=';
/*  635 */       output.writeCharacters(buf, 0, 4);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, byte[] out, int ptr) {
/*  650 */     byte[] buf = out;
/*  651 */     int remaining = len;
/*      */     int i;
/*  653 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  654 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  655 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  658 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  661 */       buf[ptr++] = encodeByte(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  664 */     if (remaining == 1) {
/*  665 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  666 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4);
/*  667 */       buf[ptr++] = 61;
/*  668 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  671 */     if (remaining == 2) {
/*  672 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  673 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  676 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2);
/*  677 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  680 */     return ptr;
/*      */   }
/*      */   
/*      */   private static CharSequence removeOptionalPlus(CharSequence s) {
/*  684 */     int len = s.length();
/*      */     
/*  686 */     if (len <= 1 || s.charAt(0) != '+') {
/*  687 */       return s;
/*      */     }
/*      */     
/*  690 */     s = s.subSequence(1, len);
/*  691 */     char ch = s.charAt(0);
/*  692 */     if ('0' <= ch && ch <= '9') {
/*  693 */       return s;
/*      */     }
/*  695 */     if ('.' == ch) {
/*  696 */       return s;
/*      */     }
/*      */     
/*  699 */     throw new NumberFormatException();
/*      */   }
/*      */   
/*      */   private static boolean isDigitOrPeriodOrSign(char ch) {
/*  703 */     if ('0' <= ch && ch <= '9') {
/*  704 */       return true;
/*      */     }
/*  706 */     return (ch == '+' || ch == '-' || ch == '.');
/*      */   }
/*      */   
/*  709 */   private static final Map<ClassLoader, DatatypeFactory> DF_CACHE = Collections.synchronizedMap(new WeakHashMap<>());
/*      */   
/*      */   public static DatatypeFactory getDatatypeFactory() {
/*  712 */     ClassLoader tccl = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/*  715 */             return Thread.currentThread().getContextClassLoader();
/*      */           }
/*      */         });
/*  718 */     DatatypeFactory df = DF_CACHE.get(tccl);
/*  719 */     if (df == null) {
/*  720 */       synchronized (DatatypeConverterImpl.class) {
/*  721 */         df = DF_CACHE.get(tccl);
/*  722 */         if (df == null) {
/*      */           try {
/*  724 */             df = DatatypeFactory.newInstance();
/*  725 */           } catch (DatatypeConfigurationException e) {
/*  726 */             throw new Error(Messages.FAILED_TO_INITIALE_DATATYPE_FACTORY.format(new Object[0]), e);
/*      */           } 
/*  728 */           DF_CACHE.put(tccl, df);
/*      */         } 
/*      */       } 
/*      */     }
/*  732 */     return df;
/*      */   }
/*      */   
/*      */   private static final class CalendarFormatter
/*      */   {
/*      */     public static String doFormat(String format, Calendar cal) throws IllegalArgumentException {
/*  738 */       int fidx = 0;
/*  739 */       int flen = format.length();
/*  740 */       StringBuilder buf = new StringBuilder();
/*      */       
/*  742 */       while (fidx < flen) {
/*  743 */         char fch = format.charAt(fidx++);
/*      */         
/*  745 */         if (fch != '%') {
/*  746 */           buf.append(fch);
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  751 */         switch (format.charAt(fidx++)) {
/*      */           case 'Y':
/*  753 */             formatYear(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'M':
/*  757 */             formatMonth(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'D':
/*  761 */             formatDays(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'h':
/*  765 */             formatHours(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'm':
/*  769 */             formatMinutes(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 's':
/*  773 */             formatSeconds(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'z':
/*  777 */             formatTimeZone(cal, buf);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */         
/*  782 */         throw new InternalError();
/*      */       } 
/*      */ 
/*      */       
/*  786 */       return buf.toString();
/*      */     }
/*      */     private static void formatYear(Calendar cal, StringBuilder buf) {
/*      */       String s;
/*  790 */       int year = cal.get(1);
/*      */ 
/*      */       
/*  793 */       if (year <= 0) {
/*      */         
/*  795 */         s = Integer.toString(1 - year);
/*      */       } else {
/*      */         
/*  798 */         s = Integer.toString(year);
/*      */       } 
/*      */       
/*  801 */       while (s.length() < 4) {
/*  802 */         s = "0" + s;
/*      */       }
/*  804 */       if (year <= 0) {
/*  805 */         s = "-" + s;
/*      */       }
/*      */       
/*  808 */       buf.append(s);
/*      */     }
/*      */     
/*      */     private static void formatMonth(Calendar cal, StringBuilder buf) {
/*  812 */       formatTwoDigits(cal.get(2) + 1, buf);
/*      */     }
/*      */     
/*      */     private static void formatDays(Calendar cal, StringBuilder buf) {
/*  816 */       formatTwoDigits(cal.get(5), buf);
/*      */     }
/*      */     
/*      */     private static void formatHours(Calendar cal, StringBuilder buf) {
/*  820 */       formatTwoDigits(cal.get(11), buf);
/*      */     }
/*      */     
/*      */     private static void formatMinutes(Calendar cal, StringBuilder buf) {
/*  824 */       formatTwoDigits(cal.get(12), buf);
/*      */     }
/*      */     
/*      */     private static void formatSeconds(Calendar cal, StringBuilder buf) {
/*  828 */       formatTwoDigits(cal.get(13), buf);
/*  829 */       if (cal.isSet(14)) {
/*  830 */         int n = cal.get(14);
/*  831 */         if (n != 0) {
/*  832 */           StringBuilder ms = new StringBuilder(Integer.toString(n));
/*  833 */           while (ms.length() < 3) {
/*  834 */             ms.insert(0, '0');
/*      */           }
/*  836 */           buf.append('.');
/*  837 */           buf.append(ms);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private static void formatTimeZone(Calendar cal, StringBuilder buf) {
/*  844 */       TimeZone tz = cal.getTimeZone();
/*      */       
/*  846 */       if (tz == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  851 */       int offset = tz.getOffset(cal.getTime().getTime());
/*      */       
/*  853 */       if (offset == 0) {
/*  854 */         buf.append('Z');
/*      */         
/*      */         return;
/*      */       } 
/*  858 */       if (offset >= 0) {
/*  859 */         buf.append('+');
/*      */       } else {
/*  861 */         buf.append('-');
/*  862 */         offset *= -1;
/*      */       } 
/*      */       
/*  865 */       offset /= 60000;
/*      */       
/*  867 */       formatTwoDigits(offset / 60, buf);
/*  868 */       buf.append(':');
/*  869 */       formatTwoDigits(offset % 60, buf);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void formatTwoDigits(int n, StringBuilder buf) {
/*  875 */       if (n < 10) {
/*  876 */         buf.append('0');
/*      */       }
/*  878 */       buf.append(n);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String parseString(String lexicalXSDString) {
/*  887 */     return lexicalXSDString;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigInteger parseInteger(String lexicalXSDInteger) {
/*  893 */     return _parseInteger(lexicalXSDInteger);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printInteger(BigInteger val) {
/*  899 */     return _printInteger(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int parseInt(String s) {
/*  905 */     return _parseInt(s);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public long parseLong(String lexicalXSLong) {
/*  911 */     return _parseLong(lexicalXSLong);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public short parseShort(String lexicalXSDShort) {
/*  917 */     return _parseShort(lexicalXSDShort);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printShort(short val) {
/*  923 */     return _printShort(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal parseDecimal(String content) {
/*  929 */     return _parseDecimal(content);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public float parseFloat(String lexicalXSDFloat) {
/*  935 */     return _parseFloat(lexicalXSDFloat);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printFloat(float v) {
/*  941 */     return _printFloat(v);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public double parseDouble(String lexicalXSDDouble) {
/*  947 */     return _parseDouble(lexicalXSDDouble);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean parseBoolean(String lexicalXSDBoolean) {
/*  953 */     Boolean b = _parseBoolean(lexicalXSDBoolean);
/*  954 */     return (b != null && b.booleanValue());
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printBoolean(boolean val) {
/*  960 */     return val ? "true" : "false";
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public byte parseByte(String lexicalXSDByte) {
/*  966 */     return _parseByte(lexicalXSDByte);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printByte(byte val) {
/*  972 */     return _printByte(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public QName parseQName(String lexicalXSDQName, NamespaceContext nsc) {
/*  978 */     return _parseQName(lexicalXSDQName, nsc);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Calendar parseDateTime(String lexicalXSDDateTime) {
/*  984 */     return _parseDateTime(lexicalXSDDateTime);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printDateTime(Calendar val) {
/*  990 */     return _printDateTime(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public byte[] parseBase64Binary(String lexicalXSDBase64Binary) {
/*  996 */     return _parseBase64Binary(lexicalXSDBase64Binary);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public byte[] parseHexBinary(String s) {
/* 1002 */     int len = s.length();
/*      */ 
/*      */     
/* 1005 */     if (len % 2 != 0) {
/* 1006 */       throw new IllegalArgumentException("hexBinary needs to be even-length: " + s);
/*      */     }
/*      */     
/* 1009 */     byte[] out = new byte[len / 2];
/*      */     
/* 1011 */     for (int i = 0; i < len; i += 2) {
/* 1012 */       int h = hexToBin(s.charAt(i));
/* 1013 */       int l = hexToBin(s.charAt(i + 1));
/* 1014 */       if (h == -1 || l == -1) {
/* 1015 */         throw new IllegalArgumentException("contains illegal character for hexBinary: " + s);
/*      */       }
/*      */       
/* 1018 */       out[i / 2] = (byte)(h * 16 + l);
/*      */     } 
/*      */     
/* 1021 */     return out;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   private static int hexToBin(char ch) {
/* 1026 */     if ('0' <= ch && ch <= '9') {
/* 1027 */       return ch - 48;
/*      */     }
/* 1029 */     if ('A' <= ch && ch <= 'F') {
/* 1030 */       return ch - 65 + 10;
/*      */     }
/* 1032 */     if ('a' <= ch && ch <= 'f') {
/* 1033 */       return ch - 97 + 10;
/*      */     }
/* 1035 */     return -1;
/*      */   }
/*      */   
/*      */   @Deprecated
/* 1039 */   private static final char[] hexCode = "0123456789ABCDEF".toCharArray();
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printHexBinary(byte[] data) {
/* 1044 */     StringBuilder r = new StringBuilder(data.length * 2);
/* 1045 */     for (byte b : data) {
/* 1046 */       r.append(hexCode[b >> 4 & 0xF]);
/* 1047 */       r.append(hexCode[b & 0xF]);
/*      */     } 
/* 1049 */     return r.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public long parseUnsignedInt(String lexicalXSDUnsignedInt) {
/* 1055 */     return _parseLong(lexicalXSDUnsignedInt);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printUnsignedInt(long val) {
/* 1061 */     return _printLong(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int parseUnsignedShort(String lexicalXSDUnsignedShort) {
/* 1067 */     return _parseInt(lexicalXSDUnsignedShort);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Calendar parseTime(String lexicalXSDTime) {
/* 1073 */     return getDatatypeFactory().newXMLGregorianCalendar(lexicalXSDTime).toGregorianCalendar();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printTime(Calendar val) {
/* 1079 */     return CalendarFormatter.doFormat("%h:%m:%s%z", val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Calendar parseDate(String lexicalXSDDate) {
/* 1085 */     return getDatatypeFactory().newXMLGregorianCalendar(lexicalXSDDate).toGregorianCalendar();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printDate(Calendar val) {
/* 1091 */     return _printDate(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String parseAnySimpleType(String lexicalXSDAnySimpleType) {
/* 1097 */     return lexicalXSDAnySimpleType;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printString(String val) {
/* 1103 */     return val;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printInt(int val) {
/* 1109 */     return _printInt(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printLong(long val) {
/* 1115 */     return _printLong(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printDecimal(BigDecimal val) {
/* 1121 */     return _printDecimal(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printDouble(double v) {
/* 1127 */     return _printDouble(v);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printQName(QName val, NamespaceContext nsc) {
/* 1133 */     return _printQName(val, nsc);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printBase64Binary(byte[] val) {
/* 1139 */     return _printBase64Binary(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printUnsignedShort(int val) {
/* 1145 */     return String.valueOf(val);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String printAnySimpleType(String val) {
/* 1151 */     return val;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\DatatypeConverterImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */