/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodLocatable<M>
/*    */   implements Locatable
/*    */ {
/*    */   private final Locatable upstream;
/*    */   private final M method;
/*    */   private final Navigator<?, ?, ?, M> nav;
/*    */   
/*    */   public MethodLocatable(Locatable upstream, M method, Navigator<?, ?, ?, M> nav) {
/* 28 */     this.upstream = upstream;
/* 29 */     this.method = method;
/* 30 */     this.nav = nav;
/*    */   }
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 35 */     return this.upstream;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 40 */     return this.nav.getMethodLocation(this.method);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\MethodLocatable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */