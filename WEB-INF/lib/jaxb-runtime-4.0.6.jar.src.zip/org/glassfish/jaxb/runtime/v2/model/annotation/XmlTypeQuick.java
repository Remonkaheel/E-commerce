/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlTypeQuick
/*    */   extends Quick
/*    */   implements XmlType
/*    */ {
/*    */   private final XmlType core;
/*    */   
/*    */   public XmlTypeQuick(Locatable upstream, XmlType core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlTypeQuick(upstream, (XmlType)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlType> annotationType() {
/* 47 */     return XmlType.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class factoryClass() {
/* 52 */     return this.core.factoryClass();
/*    */   }
/*    */ 
/*    */   
/*    */   public String factoryMethod() {
/* 57 */     return this.core.factoryMethod();
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 62 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 67 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] propOrder() {
/* 72 */     return this.core.propOrder();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlTypeQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */