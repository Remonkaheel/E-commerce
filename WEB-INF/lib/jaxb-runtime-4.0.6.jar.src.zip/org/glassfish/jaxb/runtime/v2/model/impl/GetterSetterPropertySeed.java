/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.beans.Introspector;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GetterSetterPropertySeed<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   implements PropertySeed<TypeT, ClassDeclT, FieldT, MethodT>
/*    */ {
/*    */   protected final MethodT getter;
/*    */   protected final MethodT setter;
/*    */   private ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> parent;
/*    */   
/*    */   GetterSetterPropertySeed(ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> parent, MethodT getter, MethodT setter) {
/* 34 */     this.parent = parent;
/* 35 */     this.getter = getter;
/* 36 */     this.setter = setter;
/*    */     
/* 38 */     if (getter == null && setter == null) {
/* 39 */       throw new IllegalArgumentException();
/*    */     }
/*    */   }
/*    */   
/*    */   public TypeT getRawType() {
/* 44 */     if (this.getter != null) {
/* 45 */       return (TypeT)this.parent.nav().getReturnType(this.getter);
/*    */     }
/* 47 */     return (TypeT)this.parent.nav().getMethodParameters(this.setter)[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public <A extends Annotation> A readAnnotation(Class<A> annotation) {
/* 52 */     return (A)this.parent.reader().getMethodAnnotation(annotation, this.getter, this.setter, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasAnnotation(Class<? extends Annotation> annotationType) {
/* 57 */     return this.parent.reader().hasMethodAnnotation(annotationType, getName(), this.getter, this.setter, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 62 */     if (this.getter != null) {
/* 63 */       return getName(this.getter);
/*    */     }
/* 65 */     return getName(this.setter);
/*    */   }
/*    */   
/*    */   private String getName(MethodT m) {
/* 69 */     String seed = this.parent.nav().getMethodName(m);
/* 70 */     String lseed = seed.toLowerCase();
/* 71 */     if (lseed.startsWith("get") || lseed.startsWith("set"))
/* 72 */       return camelize(seed.substring(3)); 
/* 73 */     if (lseed.startsWith("is"))
/* 74 */       return camelize(seed.substring(2)); 
/* 75 */     return seed;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String camelize(String s) {
/* 80 */     return Introspector.decapitalize(s);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 88 */     return this.parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 93 */     if (this.getter != null) {
/* 94 */       return this.parent.nav().getMethodLocation(this.getter);
/*    */     }
/* 96 */     return this.parent.nav().getMethodLocation(this.setter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\GetterSetterPropertySeed.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */