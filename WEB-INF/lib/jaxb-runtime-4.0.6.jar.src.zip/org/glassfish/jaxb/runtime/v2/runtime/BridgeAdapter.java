/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.MarshalException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.glassfish.jaxb.runtime.api.TypeReference;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallerImpl;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BridgeAdapter<OnWire, InMemory>
/*     */   extends InternalBridge<InMemory>
/*     */ {
/*     */   private final InternalBridge<OnWire> core;
/*     */   private final Class<? extends XmlAdapter<OnWire, InMemory>> adapter;
/*     */   
/*     */   public BridgeAdapter(InternalBridge<OnWire> core, Class<? extends XmlAdapter<OnWire, InMemory>> adapter) {
/*  43 */     super(core.getContext());
/*  44 */     this.core = core;
/*  45 */     this.adapter = adapter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller m, InMemory inMemory, XMLStreamWriter output) throws JAXBException {
/*  50 */     this.core.marshal(m, adaptM(m, inMemory), output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller m, InMemory inMemory, OutputStream output, NamespaceContext nsc) throws JAXBException {
/*  55 */     this.core.marshal(m, adaptM(m, inMemory), output, nsc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller m, InMemory inMemory, Node output) throws JAXBException {
/*  60 */     this.core.marshal(m, adaptM(m, inMemory), output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller context, InMemory inMemory, ContentHandler contentHandler) throws JAXBException {
/*  65 */     this.core.marshal(context, adaptM(context, inMemory), contentHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller context, InMemory inMemory, Result result) throws JAXBException {
/*  70 */     this.core.marshal(context, adaptM(context, inMemory), result);
/*     */   }
/*     */   
/*     */   private OnWire adaptM(Marshaller m, InMemory v) throws JAXBException {
/*  74 */     XMLSerializer serializer = ((MarshallerImpl)m).serializer;
/*  75 */     serializer.pushCoordinator();
/*     */     try {
/*  77 */       return _adaptM(serializer, v);
/*     */     } finally {
/*  79 */       serializer.popCoordinator();
/*     */     } 
/*     */   }
/*     */   
/*     */   private OnWire _adaptM(XMLSerializer serializer, InMemory v) throws MarshalException {
/*  84 */     XmlAdapter<OnWire, InMemory> a = serializer.getAdapter((Class)this.adapter);
/*     */     try {
/*  86 */       return (OnWire)a.marshal(v);
/*  87 */     } catch (Exception e) {
/*  88 */       serializer.handleError(e, v, (String)null);
/*  89 */       throw new MarshalException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public InMemory unmarshal(Unmarshaller u, XMLStreamReader in) throws JAXBException {
/*  96 */     return adaptU(u, (OnWire)this.core.unmarshal(u, in));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public InMemory unmarshal(Unmarshaller u, Source in) throws JAXBException {
/* 101 */     return adaptU(u, (OnWire)this.core.unmarshal(u, in));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public InMemory unmarshal(Unmarshaller u, InputStream in) throws JAXBException {
/* 106 */     return adaptU(u, (OnWire)this.core.unmarshal(u, in));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public InMemory unmarshal(Unmarshaller u, Node n) throws JAXBException {
/* 111 */     return adaptU(u, (OnWire)this.core.unmarshal(u, n));
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference getTypeReference() {
/* 116 */     return this.core.getTypeReference();
/*     */   }
/*     */   @NotNull
/*     */   private InMemory adaptU(Unmarshaller _u, OnWire v) throws JAXBException {
/* 120 */     UnmarshallerImpl u = (UnmarshallerImpl)_u;
/* 121 */     XmlAdapter<OnWire, InMemory> a = u.coordinator.getAdapter(this.adapter);
/* 122 */     u.coordinator.pushCoordinator();
/*     */     try {
/* 124 */       return (InMemory)a.unmarshal(v);
/* 125 */     } catch (Exception e) {
/* 126 */       throw new UnmarshalException(e);
/*     */     } finally {
/* 128 */       u.coordinator.popCoordinator();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void marshal(InMemory o, XMLSerializer out) throws IOException, SAXException, XMLStreamException {
/*     */     try {
/* 135 */       this.core.marshal(_adaptM(XMLSerializer.getInstance(), o), out);
/* 136 */     } catch (MarshalException marshalException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\BridgeAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */