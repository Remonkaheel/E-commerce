/*      */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*      */ 
/*      */ import com.sun.istack.NotNull;
/*      */ import com.sun.istack.Nullable;
/*      */ import com.sun.istack.SAXParseException2;
/*      */ import jakarta.xml.bind.JAXBElement;
/*      */ import jakarta.xml.bind.UnmarshalException;
/*      */ import jakarta.xml.bind.ValidationEvent;
/*      */ import jakarta.xml.bind.ValidationEventHandler;
/*      */ import jakarta.xml.bind.ValidationEventLocator;
/*      */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.glassfish.jaxb.core.unmarshaller.InfosetScanner;
/*      */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*      */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*      */ import org.glassfish.jaxb.runtime.IDResolver;
/*      */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*      */ import org.glassfish.jaxb.runtime.api.ClassResolver;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.AssociationMap;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.Coordinator;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.helpers.LocatorImpl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class UnmarshallingContext
/*      */   extends Coordinator
/*      */   implements NamespaceContext, ValidationEventHandler, ErrorHandler, XmlVisitor, XmlVisitor.TextPredictor
/*      */ {
/*   54 */   private static final Logger logger = Logger.getLogger(UnmarshallingContext.class.getName());
/*      */ 
/*      */ 
/*      */   
/*      */   private final State root;
/*      */ 
/*      */   
/*      */   private State current;
/*      */ 
/*      */   
/*      */   private static final LocatorEx DUMMY_INSTANCE;
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*   69 */     LocatorImpl loc = new LocatorImpl();
/*   70 */     loc.setPublicId(null);
/*   71 */     loc.setSystemId(null);
/*   72 */     loc.setLineNumber(-1);
/*   73 */     loc.setColumnNumber(-1);
/*   74 */     DUMMY_INSTANCE = new LocatorExWrapper(loc);
/*      */   }
/*      */   @NotNull
/*   77 */   private LocatorEx locator = DUMMY_INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object result;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JaxBeanInfo expectedType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IDResolver idResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isUnmarshalInProgress = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean aborted = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final UnmarshallerImpl parent;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final AssociationMap assoc;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInplaceMode;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InfosetScanner scanner;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object currentElement;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NamespaceContext environmentNamespaceContext;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ClassResolver classResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ClassLoader classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static volatile int errorsCounter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<Class, Factory> factories;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Patcher[] patchers;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int patchersLen;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] nsBind;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int nsLen;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Scope[] scopes;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int scopeTop;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class State
/*      */   {
/*      */     private Loader loader;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Receiver receiver;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Intercepter intercepter;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object target;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object backup;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int numNsDecl;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String elementDefaultValue;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private State prev;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private State next;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean nil = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean mixed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UnmarshallingContext getContext() {
/*  249 */       return UnmarshallingContext.this;
/*      */     }
/*      */ 
/*      */     
/*      */     private State(State prev) {
/*  254 */       this.prev = prev;
/*  255 */       if (prev != null) {
/*  256 */         prev.next = this;
/*  257 */         if (prev.mixed)
/*  258 */           this.mixed = true; 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void push() {
/*  263 */       if (UnmarshallingContext.logger.isLoggable(Level.FINEST)) {
/*  264 */         UnmarshallingContext.logger.log(Level.FINEST, "State.push");
/*      */       }
/*  266 */       if (this.next == null) {
/*  267 */         assert UnmarshallingContext.this.current == this;
/*  268 */         this.next = new State(this);
/*      */       } 
/*  270 */       this.nil = false;
/*  271 */       State n = this.next;
/*  272 */       n.numNsDecl = UnmarshallingContext.this.nsLen;
/*  273 */       UnmarshallingContext.this.current = n;
/*      */     }
/*      */     
/*      */     private void pop() {
/*  277 */       if (UnmarshallingContext.logger.isLoggable(Level.FINEST)) {
/*  278 */         UnmarshallingContext.logger.log(Level.FINEST, "State.pop");
/*      */       }
/*  280 */       assert this.prev != null;
/*  281 */       this.loader = null;
/*  282 */       this.nil = false;
/*  283 */       this.mixed = this.prev.mixed;
/*  284 */       this.receiver = null;
/*  285 */       this.intercepter = null;
/*  286 */       this.elementDefaultValue = null;
/*  287 */       this.target = null;
/*  288 */       UnmarshallingContext.this.current = this.prev;
/*  289 */       this.next = null;
/*      */     }
/*      */     
/*      */     public boolean isMixed() {
/*  293 */       return this.mixed;
/*      */     }
/*      */     
/*      */     public Object getTarget() {
/*  297 */       return this.target;
/*      */     }
/*      */     
/*      */     public void setLoader(Loader loader) {
/*  301 */       if (loader instanceof StructureLoader)
/*  302 */         this.mixed = !((StructureLoader)loader).getBeanInfo().hasElementOnlyContentModel(); 
/*  303 */       this.loader = loader;
/*      */     }
/*      */     
/*      */     public void setReceiver(Receiver receiver) {
/*  307 */       this.receiver = receiver;
/*      */     }
/*      */     
/*      */     public State getPrev() {
/*  311 */       return this.prev;
/*      */     }
/*      */     
/*      */     public void setIntercepter(Intercepter intercepter) {
/*  315 */       this.intercepter = intercepter;
/*      */     }
/*      */     
/*      */     public void setBackup(Object backup) {
/*  319 */       this.backup = backup;
/*      */     }
/*      */     
/*      */     public void setTarget(Object target) {
/*  323 */       this.target = target;
/*      */     }
/*      */     
/*      */     public Object getBackup() {
/*  327 */       return this.backup;
/*      */     }
/*      */     
/*      */     public boolean isNil() {
/*  331 */       return this.nil;
/*      */     }
/*      */     
/*      */     public void setNil(boolean nil) {
/*  335 */       this.nil = nil;
/*      */     }
/*      */     
/*      */     public Loader getLoader() {
/*  339 */       return this.loader;
/*      */     }
/*      */     
/*      */     public String getElementDefaultValue() {
/*  343 */       return this.elementDefaultValue;
/*      */     }
/*      */     
/*      */     public void setElementDefaultValue(String elementDefaultValue) {
/*  347 */       this.elementDefaultValue = elementDefaultValue;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Factory
/*      */   {
/*      */     private final Object factorInstance;
/*      */     
/*      */     private final Method method;
/*      */     
/*      */     public Factory(Object factorInstance, Method method) {
/*  359 */       this.factorInstance = factorInstance;
/*  360 */       this.method = method;
/*      */     }
/*      */     
/*      */     public Object createInstance() throws SAXException {
/*      */       try {
/*  365 */         return this.method.invoke(this.factorInstance, new Object[0]);
/*  366 */       } catch (ReflectiveOperationException e) {
/*  367 */         UnmarshallingContext.getInstance().handleError(e, false);
/*      */         
/*  369 */         return null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset(InfosetScanner scanner, boolean isInplaceMode, JaxBeanInfo expectedType, IDResolver idResolver) {
/*  389 */     this.scanner = scanner;
/*  390 */     this.isInplaceMode = isInplaceMode;
/*  391 */     this.expectedType = expectedType;
/*  392 */     this.idResolver = idResolver;
/*      */   }
/*      */   
/*      */   public JAXBContextImpl getJAXBContext() {
/*  396 */     return this.parent.context;
/*      */   }
/*      */   
/*      */   public State getCurrentState() {
/*  400 */     return this.current;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Loader selectRootLoader(State state, TagName tag) throws SAXException {
/*      */     try {
/*  412 */       Loader l = getJAXBContext().selectRootLoader(state, tag);
/*  413 */       if (l != null) return l;
/*      */       
/*  415 */       if (this.classResolver != null) {
/*  416 */         Class<?> clazz = this.classResolver.resolveElementName(tag.uri, tag.local);
/*  417 */         if (clazz != null) {
/*  418 */           JAXBContextImpl enhanced = getJAXBContext().createAugmented(clazz);
/*  419 */           JaxBeanInfo<?> bi = enhanced.getBeanInfo(clazz);
/*  420 */           return bi.getLoader(enhanced, true);
/*      */         } 
/*      */       } 
/*  423 */     } catch (RuntimeException e) {
/*  424 */       throw e;
/*  425 */     } catch (Exception e) {
/*  426 */       handleError(e);
/*      */     } 
/*      */     
/*  429 */     return null;
/*      */   }
/*      */   public void setFactories(Object factoryInstances) { this.factories.clear(); if (factoryInstances == null) return;  if (factoryInstances instanceof Object[]) { for (Object factory : (Object[])factoryInstances) addFactory(factory);  } else { addFactory(factoryInstances); }  }
/*      */   private void addFactory(Object factory) { for (Method m : factory.getClass().getMethods()) { if (m.getName().startsWith("create")) if (m.getParameterCount() <= 0) { Class<?> type = m.getReturnType(); this.factories.put(type, new Factory(factory, m)); }   }  }
/*  433 */   public void startDocument(LocatorEx locator, NamespaceContext nsContext) throws SAXException { if (locator != null) this.locator = locator;  this.environmentNamespaceContext = nsContext; this.result = null; this.current = this.root; this.patchersLen = 0; this.aborted = false; this.isUnmarshalInProgress = true; this.nsLen = 0; if (this.expectedType != null) { this.root.loader = EXPECTED_TYPE_ROOT_LOADER; } else { this.root.loader = DEFAULT_ROOT_LOADER; }  this.idResolver.startDocument(this); } public void startElement(TagName tagName) throws SAXException { pushCoordinator(); try { _startElement(tagName); } finally { popCoordinator(); }  } private void _startElement(TagName tagName) throws SAXException { if (this.assoc != null) this.currentElement = this.scanner.getCurrentElement();  Loader h = this.current.loader; this.current.push(); h.childElement(this.current, tagName); assert this.current.loader != null; this.current.loader.startElement(this.current, tagName); } public void clearStates() { State last = this.current;
/*  434 */     for (; last.next != null; last = last.next);
/*  435 */     while (last.prev != null) {
/*  436 */       last.loader = null;
/*  437 */       last.nil = false;
/*  438 */       last.receiver = null;
/*  439 */       last.intercepter = null;
/*  440 */       last.elementDefaultValue = null;
/*  441 */       last.target = null;
/*  442 */       last = last.prev;
/*  443 */       last.next.prev = null;
/*  444 */       last.next = null;
/*      */     } 
/*  446 */     this.current = last; }
/*      */   public void text(CharSequence pcdata) throws SAXException { pushCoordinator(); try { if (this.current.elementDefaultValue != null && pcdata.length() == 0) pcdata = this.current.elementDefaultValue;  this.current.loader.text(this.current, pcdata); } finally { popCoordinator(); }  }
/*      */   public void endElement(TagName tagName) throws SAXException { pushCoordinator(); try { State child = this.current; child.loader.leaveElement(child, tagName); Object target = child.target; Receiver recv = child.receiver; Intercepter intercepter = child.intercepter; child.pop(); if (intercepter != null)
/*      */         target = intercepter.intercept(this.current, target);  if (recv != null)
/*      */         recv.receive(this.current, target);  } finally { popCoordinator(); }  }
/*      */   public void endDocument() throws SAXException { runPatchers(); this.idResolver.endDocument(); this.isUnmarshalInProgress = false; this.currentElement = null; this.locator = DUMMY_INSTANCE; this.environmentNamespaceContext = null; assert this.root == this.current; }
/*  452 */   @Deprecated public boolean expectText() { return this.current.loader.expectText; } public UnmarshallingContext(UnmarshallerImpl _parent, AssociationMap assoc) { this.factories = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  761 */     this.patchers = null;
/*  762 */     this.patchersLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  846 */     this.nsBind = new String[16];
/*  847 */     this.nsLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  988 */     this.scopes = new Scope[16];
/*      */ 
/*      */ 
/*      */     
/*  992 */     this.scopeTop = 0; this.parent = _parent; this.assoc = assoc; this.root = this.current = new State(null); errorsCounter = _parent.context.maxErrorsCount; } @Deprecated public XmlVisitor.TextPredictor getPredictor() { return this; }
/*      */   public UnmarshallingContext getContext() { return this; }
/*      */   public Object getResult() throws UnmarshalException { if (this.isUnmarshalInProgress)
/*      */       throw new IllegalStateException();  if (!this.aborted)
/*      */       return this.result;  throw new UnmarshalException((String)null); }
/*      */   void clearResult() { if (this.isUnmarshalInProgress)
/*      */       throw new IllegalStateException();  this.result = null; }
/*      */   public Object createInstance(Class<?> clazz) throws SAXException { if (!this.factories.isEmpty()) { Factory factory = this.factories.get(clazz); if (factory != null)
/*      */         return factory.createInstance();  }  return ClassFactory.create(clazz); }
/*      */   public Object createInstance(JaxBeanInfo beanInfo) throws SAXException { if (!this.factories.isEmpty()) { Factory factory = this.factories.get(beanInfo.jaxbType); if (factory != null)
/*      */         return factory.createInstance();  }  try { return beanInfo.createInstance(this); } catch (ReflectiveOperationException e) { Loader.reportError("Unable to create an instance of " + beanInfo.jaxbType.getName(), e, false); return null; }  }
/*      */   public void handleEvent(ValidationEvent event, boolean canRecover) throws SAXException { ValidationEventHandler eventHandler = this.parent.getEventHandler(); boolean recover = eventHandler.handleEvent(event); if (!recover)
/*      */       this.aborted = true;  if (!canRecover || !recover)
/*      */       throw new SAXParseException2(event.getMessage(), this.locator, new UnmarshalException(event.getMessage(), event.getLinkedException()));  }
/*      */   public boolean handleEvent(ValidationEvent event) { try { boolean recover = this.parent.getEventHandler().handleEvent(event); if (!recover)
/*      */         this.aborted = true;  return recover; } catch (RuntimeException re) { return false; }
/*      */      }
/*      */   public void handleError(Exception e) throws SAXException { handleError(e, true); }
/* 1010 */   public void startScope(int frameSize) { this.scopeTop += frameSize;
/*      */ 
/*      */     
/* 1013 */     if (this.scopeTop >= this.scopes.length) {
/* 1014 */       Scope[] s = new Scope[Math.max(this.scopeTop + 1, this.scopes.length * 2)];
/* 1015 */       System.arraycopy(this.scopes, 0, s, 0, this.scopes.length);
/* 1016 */       for (int i = this.scopes.length; i < s.length; i++)
/* 1017 */         s[i] = new Scope<>(this); 
/* 1018 */       this.scopes = s;
/*      */     }  } public void handleError(Exception e, boolean canRecover) throws SAXException { handleEvent((ValidationEvent)new ValidationEventImpl(1, e.getMessage(), this.locator.getLocation(), e), canRecover); }
/*      */   public void handleError(String msg) { handleEvent((ValidationEvent)new ValidationEventImpl(1, msg, this.locator.getLocation())); }
/*      */   protected ValidationEventLocator getLocation() { return this.locator.getLocation(); }
/*      */   public LocatorEx getLocator() { return this.locator; }
/*      */   public void errorUnresolvedIDREF(Object bean, String idref, LocatorEx loc) throws SAXException { handleEvent((ValidationEvent)new ValidationEventImpl(1, Messages.UNRESOLVED_IDREF.format(new Object[] { idref }, ), loc.getLocation()), true); }
/*      */   public void addPatcher(Patcher job) { if (this.patchers == null)
/*      */       this.patchers = new Patcher[32];  if (this.patchers.length == this.patchersLen) { Patcher[] buf = new Patcher[this.patchersLen * 2]; System.arraycopy(this.patchers, 0, buf, 0, this.patchersLen); this.patchers = buf; }
/*      */      this.patchers[this.patchersLen++] = job; }
/*      */   private void runPatchers() throws SAXException { if (this.patchers != null)
/*      */       for (int i = 0; i < this.patchersLen; i++) { this.patchers[i].run(); this.patchers[i] = null; }
/*      */         }
/*      */   public String addToIdTable(String id) throws SAXException { Object o = this.current.target; if (o == null)
/*      */       o = this.current.prev.target;  this.idResolver.bind(id, o); return id; }
/*      */   public Callable getObjectFromId(String id, Class targetType) throws SAXException { return this.idResolver.resolve(id, targetType); }
/*      */   public void endScope(int frameSize) throws SAXException { 
/* 1034 */     try { for (; frameSize > 0; frameSize--, this.scopeTop--) {
/* 1035 */         Scope scope = this.scopes[this.scopeTop];
/* 1036 */         if (scope != null)
/* 1037 */           scope.finish(); 
/*      */       }  }
/* 1039 */     catch (AccessorException e)
/* 1040 */     { handleError((Exception)e);
/*      */ 
/*      */ 
/*      */       
/* 1044 */       for (; frameSize > 0; frameSize--)
/* 1045 */         this.scopes[this.scopeTop--] = new Scope<>(this);  }  } public void startPrefixMapping(String prefix, String uri) { if (this.nsBind.length == this.nsLen) { String[] n = new String[this.nsLen * 2]; System.arraycopy(this.nsBind, 0, n, 0, this.nsLen); this.nsBind = n; }  this.nsBind[this.nsLen++] = prefix; this.nsBind[this.nsLen++] = uri; }
/*      */   public void endPrefixMapping(String prefix) { this.nsLen -= 2; }
/*      */   private String resolveNamespacePrefix(String prefix) { if (prefix.equals("xml")) return "http://www.w3.org/XML/1998/namespace";  for (int i = this.nsLen - 2; i >= 0; i -= 2) { if (prefix.equals(this.nsBind[i])) return this.nsBind[i + 1];  }  if (this.environmentNamespaceContext != null) return this.environmentNamespaceContext.getNamespaceURI(prefix.intern());  if (prefix.equals("")) return "";  return null; }
/*      */   public String[] getNewlyDeclaredPrefixes() { return getPrefixList(this.current.prev.numNsDecl); }
/*      */   public String[] getAllDeclaredPrefixes() { return getPrefixList(0); }
/*      */   private String[] getPrefixList(int startIndex) { int size = (this.current.numNsDecl - startIndex) / 2; String[] r = new String[size]; for (int i = 0; i < r.length; i++) r[i] = this.nsBind[startIndex + i * 2];  return r; }
/*      */   public Iterator<String> getPrefixes(String uri) { return Collections.<String>unmodifiableList(getAllPrefixesInList(uri)).iterator(); }
/*      */   private List<String> getAllPrefixesInList(String uri) { List<String> a = new ArrayList<>(); if (uri == null) throw new IllegalArgumentException();  if (uri.equals("http://www.w3.org/XML/1998/namespace")) { a.add("xml"); return a; }  if (uri.equals("http://www.w3.org/2000/xmlns/")) { a.add("xmlns"); return a; }  for (int i = this.nsLen - 2; i >= 0; i -= 2) { if (uri.equals(this.nsBind[i + 1]) && getNamespaceURI(this.nsBind[i]).equals(this.nsBind[i + 1])) a.add(this.nsBind[i]);  }  return a; }
/*      */   public String getPrefix(String uri) { if (uri == null) throw new IllegalArgumentException();  if (uri.equals("http://www.w3.org/XML/1998/namespace")) return "xml";  if (uri.equals("http://www.w3.org/2000/xmlns/")) return "xmlns";  for (int i = this.nsLen - 2; i >= 0; i -= 2) { if (uri.equals(this.nsBind[i + 1]) && getNamespaceURI(this.nsBind[i]).equals(this.nsBind[i + 1]))
/*      */         return this.nsBind[i];  }  if (this.environmentNamespaceContext != null)
/*      */       return this.environmentNamespaceContext.getPrefix(uri);  return null; }
/*      */   public String getNamespaceURI(String prefix) { if (prefix == null)
/*      */       throw new IllegalArgumentException();  if (prefix.equals("xmlns"))
/*      */       return "http://www.w3.org/2000/xmlns/";  return resolveNamespacePrefix(prefix); }
/* 1059 */   public Scope getScope(int offset) { int position = this.scopeTop - offset;
/* 1060 */     Scope<Object, Object, Object, Object> scope = this.scopes[position];
/* 1061 */     if (scope == null) {
/* 1062 */       scope = new Scope<>(this);
/* 1063 */       this.scopes[position] = scope;
/*      */     } 
/* 1065 */     return scope; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1076 */   private static final Loader DEFAULT_ROOT_LOADER = new DefaultRootLoader();
/* 1077 */   private static final Loader EXPECTED_TYPE_ROOT_LOADER = new ExpectedTypeRootLoader();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class DefaultRootLoader
/*      */     extends Loader
/*      */     implements Receiver
/*      */   {
/*      */     public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 1090 */       Loader loader = state.getContext().selectRootLoader(state, ea);
/* 1091 */       if (loader != null) {
/* 1092 */         state.loader = loader;
/* 1093 */         state.receiver = this;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1099 */       JaxBeanInfo beanInfo = XsiTypeLoader.parseXsiType(state, ea, null);
/* 1100 */       if (beanInfo == null) {
/*      */         
/* 1102 */         reportUnexpectedChildElement(ea, false);
/*      */         
/*      */         return;
/*      */       } 
/* 1106 */       state.loader = beanInfo.getLoader(null, false);
/* 1107 */       state.prev.backup = new JAXBElement(ea.createQName(), Object.class, null);
/* 1108 */       state.receiver = this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<QName> getExpectedChildElements() {
/* 1113 */       return UnmarshallingContext.getInstance().getJAXBContext().getValidRootNames();
/*      */     }
/*      */ 
/*      */     
/*      */     public void receive(UnmarshallingContext.State state, Object o) {
/* 1118 */       if (state.backup != null) {
/* 1119 */         ((JAXBElement)state.backup).setValue(o);
/* 1120 */         o = state.backup;
/*      */       } 
/* 1122 */       if (state.nil) {
/* 1123 */         ((JAXBElement)o).setNil(true);
/*      */       }
/* 1125 */       (state.getContext()).result = o;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ExpectedTypeRootLoader
/*      */     extends Loader
/*      */     implements Receiver
/*      */   {
/*      */     public void childElement(UnmarshallingContext.State state, TagName ea) {
/* 1140 */       UnmarshallingContext context = state.getContext();
/*      */ 
/*      */       
/* 1143 */       QName qn = new QName(ea.uri, ea.local);
/* 1144 */       state.prev.target = new JAXBElement(qn, context.expectedType.jaxbType, null, null);
/* 1145 */       state.receiver = this;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1150 */       state.loader = new XsiNilLoader(context.expectedType.getLoader(null, true));
/*      */     }
/*      */ 
/*      */     
/*      */     public void receive(UnmarshallingContext.State state, Object o) {
/* 1155 */       JAXBElement e = (JAXBElement)state.target;
/* 1156 */       e.setValue(o);
/* 1157 */       state.getContext().recordOuterPeer(e);
/* 1158 */       (state.getContext()).result = e;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordInnerPeer(Object innerPeer) {
/* 1173 */     if (this.assoc != null) {
/* 1174 */       this.assoc.addInner(this.currentElement, innerPeer);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getInnerPeer() {
/* 1185 */     if (this.assoc != null && this.isInplaceMode) {
/* 1186 */       return this.assoc.getInnerPeer(this.currentElement);
/*      */     }
/* 1188 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordOuterPeer(Object outerPeer) {
/* 1199 */     if (this.assoc != null) {
/* 1200 */       this.assoc.addOuter(this.currentElement, outerPeer);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOuterPeer() {
/* 1211 */     if (this.assoc != null && this.isInplaceMode) {
/* 1212 */       return this.assoc.getOuterPeer(this.currentElement);
/*      */     }
/* 1214 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getXMIMEContentType() {
/* 1233 */     Object t = this.current.target;
/* 1234 */     if (t == null) return null; 
/* 1235 */     return getJAXBContext().getXMIMEContentType(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static UnmarshallingContext getInstance() {
/* 1243 */     return (UnmarshallingContext)Coordinator._getInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<QName> getCurrentExpectedElements() {
/* 1252 */     pushCoordinator();
/*      */     try {
/* 1254 */       State s = getCurrentState();
/* 1255 */       Loader l = s.loader;
/* 1256 */       return (l != null) ? l.getExpectedChildElements() : null;
/*      */     } finally {
/* 1258 */       popCoordinator();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<QName> getCurrentExpectedAttributes() {
/* 1268 */     pushCoordinator();
/*      */     try {
/* 1270 */       State s = getCurrentState();
/* 1271 */       Loader l = s.loader;
/* 1272 */       return (l != null) ? l.getExpectedAttributes() : null;
/*      */     } finally {
/* 1274 */       popCoordinator();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StructureLoader getStructureLoader() {
/* 1284 */     if (this.current.loader instanceof StructureLoader) {
/* 1285 */       return (StructureLoader)this.current.loader;
/*      */     }
/* 1287 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldErrorBeReported() throws SAXException {
/* 1302 */     if (logger.isLoggable(Level.FINEST)) {
/* 1303 */       return true;
/*      */     }
/* 1305 */     if (errorsCounter >= 0) {
/* 1306 */       errorsCounter--;
/* 1307 */       if (errorsCounter == 0)
/* 1308 */         handleEvent((ValidationEvent)new ValidationEventImpl(0, Messages.ERRORS_LIMIT_EXCEEDED.format(new Object[0]), 
/* 1309 */               getLocator().getLocation(), null), true); 
/*      */     } 
/* 1311 */     return (errorsCounter >= 0);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\UnmarshallingContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */