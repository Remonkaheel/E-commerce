/*     */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Util
/*     */ {
/*     */   public static String escapeURI(String s) {
/*  32 */     StringBuilder sb = new StringBuilder();
/*  33 */     for (int i = 0; i < s.length(); i++) {
/*  34 */       char c = s.charAt(i);
/*  35 */       if (Character.isSpaceChar(c)) {
/*  36 */         sb.append("%20");
/*     */       } else {
/*  38 */         sb.append(c);
/*     */       } 
/*     */     } 
/*  41 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getParentUriPath(String uriPath) {
/*  51 */     int idx = uriPath.lastIndexOf('/');
/*     */     
/*  53 */     if (uriPath.endsWith("/")) {
/*  54 */       uriPath = uriPath.substring(0, idx);
/*  55 */       idx = uriPath.lastIndexOf('/');
/*     */     } 
/*     */     
/*  58 */     return uriPath.substring(0, idx) + "/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String normalizeUriPath(String uriPath) {
/*  75 */     if (uriPath.endsWith("/")) {
/*  76 */       return uriPath;
/*     */     }
/*     */ 
/*     */     
/*  80 */     int idx = uriPath.lastIndexOf('/');
/*  81 */     return uriPath.substring(0, idx + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsIgnoreCase(String s, String t) {
/*  93 */     if (s == t) return true; 
/*  94 */     if (s != null && t != null) {
/*  95 */       return s.equalsIgnoreCase(t);
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equal(String s, String t) {
/* 109 */     if (s == t) return true; 
/* 110 */     if (s != null && t != null) {
/* 111 */       return s.equals(t);
/*     */     }
/* 113 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\Util.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */