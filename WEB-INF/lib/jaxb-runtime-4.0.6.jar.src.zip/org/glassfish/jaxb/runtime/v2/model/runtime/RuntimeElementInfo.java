package org.glassfish.jaxb.runtime.v2.model.runtime;

import jakarta.xml.bind.JAXBElement;
import java.lang.reflect.Type;
import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
import org.glassfish.jaxb.core.v2.model.core.NonElement;

public interface RuntimeElementInfo extends ElementInfo<Type, Class>, RuntimeElement {
  RuntimeClassInfo getScope();
  
  RuntimeElementPropertyInfo getProperty();
  
  Class<? extends JAXBElement> getType();
  
  RuntimeNonElement getContentType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeElementInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */