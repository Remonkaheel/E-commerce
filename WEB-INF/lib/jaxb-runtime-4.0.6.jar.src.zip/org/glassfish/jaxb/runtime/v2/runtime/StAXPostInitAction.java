/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import javax.xml.namespace.NamespaceContext;
/*    */ import javax.xml.stream.XMLEventWriter;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StAXPostInitAction
/*    */   implements Runnable
/*    */ {
/*    */   private final XMLStreamWriter xsw;
/*    */   private final XMLEventWriter xew;
/*    */   private final NamespaceContext nsc;
/*    */   private final XMLSerializer serializer;
/*    */   
/*    */   StAXPostInitAction(XMLStreamWriter xsw, XMLSerializer serializer) {
/* 35 */     this.xsw = xsw;
/* 36 */     this.xew = null;
/* 37 */     this.nsc = null;
/* 38 */     this.serializer = serializer;
/*    */   }
/*    */   
/*    */   StAXPostInitAction(XMLEventWriter xew, XMLSerializer serializer) {
/* 42 */     this.xsw = null;
/* 43 */     this.xew = xew;
/* 44 */     this.nsc = null;
/* 45 */     this.serializer = serializer;
/*    */   }
/*    */   
/*    */   StAXPostInitAction(NamespaceContext nsc, XMLSerializer serializer) {
/* 49 */     this.xsw = null;
/* 50 */     this.xew = null;
/* 51 */     this.nsc = nsc;
/* 52 */     this.serializer = serializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 57 */     NamespaceContext ns = this.nsc;
/* 58 */     if (this.xsw != null) ns = this.xsw.getNamespaceContext(); 
/* 59 */     if (this.xew != null) ns = this.xew.getNamespaceContext();
/*    */ 
/*    */ 
/*    */     
/* 63 */     if (ns == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 69 */     for (String nsUri : this.serializer.grammar.nameList.namespaceURIs) {
/* 70 */       String p = ns.getPrefix(nsUri);
/* 71 */       if (p != null)
/* 72 */         this.serializer.addInscopeBinding(nsUri, p); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\StAXPostInitAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */