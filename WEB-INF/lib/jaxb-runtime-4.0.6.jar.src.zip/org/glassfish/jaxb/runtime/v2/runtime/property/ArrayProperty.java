/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Lister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ArrayProperty<BeanT, ListT, ItemT>
/*    */   extends PropertyImpl<BeanT>
/*    */ {
/*    */   protected final Accessor<BeanT, ListT> acc;
/*    */   protected final Lister<BeanT, ListT, ItemT, Object> lister;
/*    */   
/*    */   protected ArrayProperty(JAXBContextImpl context, RuntimePropertyInfo prop) {
/* 32 */     super(context, prop);
/*    */     
/* 34 */     assert prop.isCollection();
/* 35 */     this.lister = Lister.create((Type)Utils.REFLECTION_NAVIGATOR
/* 36 */         .erasure(prop.getRawType()), prop.id(), prop.getAdapter());
/* 37 */     assert this.lister != null;
/* 38 */     this.acc = prop.getAccessor().optimize(context);
/* 39 */     assert this.acc != null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o) throws AccessorException {
/* 44 */     this.lister.reset(o, this.acc);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getIdValue(BeanT bean) {
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */