/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlSchemaType;
/*    */ import jakarta.xml.bind.annotation.XmlSchemaTypes;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlSchemaTypesQuick
/*    */   extends Quick
/*    */   implements XmlSchemaTypes
/*    */ {
/*    */   private final XmlSchemaTypes core;
/*    */   
/*    */   public XmlSchemaTypesQuick(Locatable upstream, XmlSchemaTypes core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlSchemaTypesQuick(upstream, (XmlSchemaTypes)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlSchemaTypes> annotationType() {
/* 48 */     return XmlSchemaTypes.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlSchemaType[] value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlSchemaTypesQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */