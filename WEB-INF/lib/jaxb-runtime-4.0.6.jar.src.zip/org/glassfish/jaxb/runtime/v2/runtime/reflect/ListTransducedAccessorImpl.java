/*     */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ListTransducedAccessorImpl<BeanT, ListT, ItemT, PackT>
/*     */   extends DefaultTransducedAccessor<BeanT>
/*     */ {
/*     */   private final Transducer<ItemT> xducer;
/*     */   private final Lister<BeanT, ListT, ItemT, PackT> lister;
/*     */   private final Accessor<BeanT, ListT> acc;
/*     */   
/*     */   public ListTransducedAccessorImpl(Transducer<ItemT> xducer, Accessor<BeanT, ListT> acc, Lister<BeanT, ListT, ItemT, PackT> lister) {
/*  40 */     this.xducer = xducer;
/*  41 */     this.lister = lister;
/*  42 */     this.acc = acc;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useNamespace() {
/*  47 */     return this.xducer.useNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(BeanT bean, XMLSerializer w) throws AccessorException, SAXException {
/*  52 */     ListT list = this.acc.get(bean);
/*     */     
/*  54 */     if (list != null) {
/*  55 */       ListIterator<ItemT> itr = this.lister.iterator(list, w);
/*     */       
/*  57 */       while (itr.hasNext()) {
/*     */         try {
/*  59 */           ItemT item = itr.next();
/*  60 */           if (item != null) {
/*  61 */             this.xducer.declareNamespace(item, w);
/*     */           }
/*  63 */         } catch (JAXBException e) {
/*  64 */           w.reportError(null, (Throwable)e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String print(BeanT o) throws AccessorException, SAXException {
/*  75 */     ListT list = this.acc.get(o);
/*     */     
/*  77 */     if (list == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     StringBuilder buf = new StringBuilder();
/*  81 */     XMLSerializer w = XMLSerializer.getInstance();
/*  82 */     ListIterator<ItemT> itr = this.lister.iterator(list, w);
/*     */     
/*  84 */     while (itr.hasNext()) {
/*     */       try {
/*  86 */         ItemT item = itr.next();
/*  87 */         if (item != null) {
/*  88 */           if (buf.length() > 0) buf.append(' '); 
/*  89 */           buf.append(this.xducer.print(item));
/*     */         } 
/*  91 */       } catch (JAXBException e) {
/*  92 */         w.reportError(null, (Throwable)e);
/*     */       } 
/*     */     } 
/*  95 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private void processValue(BeanT bean, CharSequence s) throws AccessorException, SAXException {
/*  99 */     PackT pack = this.lister.startPacking(bean, this.acc);
/*     */     
/* 101 */     int idx = 0;
/* 102 */     int len = s.length();
/*     */     
/*     */     while (true) {
/* 105 */       int p = idx;
/* 106 */       while (p < len && !WhiteSpaceProcessor.isWhiteSpace(s.charAt(p))) {
/* 107 */         p++;
/*     */       }
/* 109 */       CharSequence token = s.subSequence(idx, p);
/* 110 */       if (!token.equals("")) {
/* 111 */         this.lister.addToPack(pack, (ItemT)this.xducer.parse(token));
/*     */       }
/* 113 */       if (p == len)
/*     */         break; 
/* 115 */       while (p < len && WhiteSpaceProcessor.isWhiteSpace(s.charAt(p)))
/* 116 */         p++; 
/* 117 */       if (p == len)
/*     */         break; 
/* 119 */       idx = p;
/*     */     } 
/*     */     
/* 122 */     this.lister.endPacking(pack, bean, this.acc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(BeanT bean, CharSequence lexical) throws AccessorException, SAXException {
/* 127 */     processValue(bean, lexical);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasValue(BeanT bean) throws AccessorException {
/* 132 */     return (this.acc.get(bean) != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\ListTransducedAccessorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */