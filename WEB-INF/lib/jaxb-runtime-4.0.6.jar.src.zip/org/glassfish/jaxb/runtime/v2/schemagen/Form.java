/*    */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*    */ 
/*    */ import com.sun.xml.txw2.TypedXmlWriter;
/*    */ import jakarta.xml.bind.annotation.XmlNsForm;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.LocalAttribute;
/*    */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.LocalElement;
/*    */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Schema;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum Form
/*    */ {
/* 27 */   QUALIFIED(XmlNsForm.QUALIFIED, true)
/*    */   {
/*    */     void declare(String attName, Schema schema) {
/* 30 */       schema._attribute(attName, "qualified");
/*    */     }
/*    */   },
/* 33 */   UNQUALIFIED(XmlNsForm.UNQUALIFIED, false)
/*    */   {
/*    */     
/*    */     void declare(String attName, Schema schema)
/*    */     {
/* 38 */       schema._attribute(attName, "unqualified");
/*    */     }
/*    */   },
/* 41 */   UNSET(XmlNsForm.UNSET, false)
/*    */   {
/*    */     void declare(String attName, Schema schema) {}
/*    */   };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final XmlNsForm xnf;
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isEffectivelyQualified;
/*    */ 
/*    */ 
/*    */   
/*    */   Form(XmlNsForm xnf, boolean effectivelyQualified) {
/* 58 */     this.xnf = xnf;
/* 59 */     this.isEffectivelyQualified = effectivelyQualified;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   abstract void declare(String paramString, Schema paramSchema);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeForm(LocalElement e, QName tagName) {
/* 72 */     _writeForm((TypedXmlWriter)e, tagName);
/*    */   }
/*    */   
/*    */   public void writeForm(LocalAttribute a, QName tagName) {
/* 76 */     _writeForm((TypedXmlWriter)a, tagName);
/*    */   }
/*    */   
/*    */   private void _writeForm(TypedXmlWriter e, QName tagName) {
/* 80 */     boolean qualified = (tagName.getNamespaceURI().length() > 0);
/*    */     
/* 82 */     if (qualified && this != QUALIFIED) {
/* 83 */       e._attribute("form", "qualified");
/*    */     }
/* 85 */     else if (!qualified && this == QUALIFIED) {
/* 86 */       e._attribute("form", "unqualified");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Form get(XmlNsForm xnf) {
/* 93 */     for (Form v : values()) {
/* 94 */       if (v.xnf == xnf)
/* 95 */         return v; 
/*    */     } 
/* 97 */     throw new IllegalArgumentException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\Form.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */