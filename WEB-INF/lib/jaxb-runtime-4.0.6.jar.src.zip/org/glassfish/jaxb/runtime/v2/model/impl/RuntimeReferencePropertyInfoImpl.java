/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeReferencePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuntimeReferencePropertyInfoImpl
/*    */   extends ReferencePropertyInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeReferencePropertyInfo
/*    */ {
/*    */   private final Accessor acc;
/*    */   
/*    */   public RuntimeReferencePropertyInfoImpl(RuntimeClassInfoImpl classInfo, PropertySeed<Type, Class<?>, Field, Method> seed) {
/* 31 */     super(classInfo, seed);
/* 32 */     Accessor rawAcc = ((RuntimeClassInfoImpl.RuntimePropertySeed)seed).getAccessor();
/* 33 */     if (getAdapter() != null && !isCollection())
/*    */     {
/*    */       
/* 36 */       rawAcc = rawAcc.adapt(getAdapter()); } 
/* 37 */     this.acc = rawAcc;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<? extends RuntimeElement> getElements() {
/* 42 */     return (Set)super.getElements();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<? extends RuntimeElement> ref() {
/* 47 */     return (Set)super.ref();
/*    */   }
/*    */ 
/*    */   
/*    */   public Accessor getAccessor() {
/* 52 */     return this.acc;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean elementOnlyContent() {
/* 57 */     return !isMixed();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeReferencePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */