/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import jakarta.activation.MimeType;
/*    */ import jakarta.activation.MimeTypeParseException;
/*    */ import jakarta.xml.bind.annotation.XmlMimeType;
/*    */ import jakarta.xml.bind.annotation.XmlSchemaType;
/*    */ import jakarta.xml.bind.annotation.XmlSchemaTypes;
/*    */ import java.lang.annotation.Annotation;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationSource;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Util
/*    */ {
/*    */   static <T, C, F, M> QName calcSchemaType(AnnotationReader<T, C, F, M> reader, AnnotationSource primarySource, C enclosingClass, T individualType, Locatable src) {
/* 35 */     XmlSchemaType xst = (XmlSchemaType)primarySource.readAnnotation(XmlSchemaType.class);
/* 36 */     if (xst != null) {
/* 37 */       return new QName(xst.namespace(), xst.name());
/*    */     }
/*    */ 
/*    */     
/* 41 */     XmlSchemaTypes xsts = (XmlSchemaTypes)reader.getPackageAnnotation(XmlSchemaTypes.class, enclosingClass, src);
/* 42 */     XmlSchemaType[] values = null;
/* 43 */     if (xsts != null) {
/* 44 */       values = xsts.value();
/*    */     } else {
/* 46 */       xst = (XmlSchemaType)reader.getPackageAnnotation(XmlSchemaType.class, enclosingClass, src);
/* 47 */       if (xst != null) {
/* 48 */         values = new XmlSchemaType[1];
/* 49 */         values[0] = xst;
/*    */       } 
/*    */     } 
/* 52 */     if (values != null) {
/* 53 */       for (XmlSchemaType item : values) {
/* 54 */         if (reader.getClassValue((Annotation)item, "type").equals(individualType)) {
/* 55 */           return new QName(item.namespace(), item.name());
/*    */         }
/*    */       } 
/*    */     }
/*    */     
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static MimeType calcExpectedMediaType(AnnotationSource primarySource, ModelBuilder builder) {
/* 65 */     XmlMimeType xmt = (XmlMimeType)primarySource.readAnnotation(XmlMimeType.class);
/* 66 */     if (xmt == null) {
/* 67 */       return null;
/*    */     }
/*    */     try {
/* 70 */       return new MimeType(xmt.value());
/* 71 */     } catch (MimeTypeParseException e) {
/* 72 */       builder.reportError(new IllegalAnnotationException(Messages.ILLEGAL_MIME_TYPE
/* 73 */             .format(new Object[] { xmt.value(), e.getMessage() }, ), (Annotation)xmt));
/*    */ 
/*    */       
/* 76 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\Util.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */