package org.glassfish.jaxb.runtime.v2.runtime;

import com.sun.istack.NotNull;
import java.io.IOException;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import org.glassfish.jaxb.runtime.api.AccessorException;
import org.xml.sax.SAXException;

public interface Transducer<ValueT> {
  boolean useNamespace();
  
  void declareNamespace(ValueT paramValueT, XMLSerializer paramXMLSerializer) throws AccessorException;
  
  @NotNull
  CharSequence print(@NotNull ValueT paramValueT) throws AccessorException;
  
  ValueT parse(CharSequence paramCharSequence) throws AccessorException, SAXException;
  
  void writeText(XMLSerializer paramXMLSerializer, ValueT paramValueT, String paramString) throws IOException, SAXException, XMLStreamException, AccessorException;
  
  void writeLeafElement(XMLSerializer paramXMLSerializer, Name paramName, @NotNull ValueT paramValueT, String paramString) throws IOException, SAXException, XMLStreamException, AccessorException;
  
  QName getTypeName(@NotNull ValueT paramValueT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\Transducer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */