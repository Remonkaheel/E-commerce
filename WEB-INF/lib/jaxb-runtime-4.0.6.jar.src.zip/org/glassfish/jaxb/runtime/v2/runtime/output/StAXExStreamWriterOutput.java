/*    */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*    */ 
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*    */ import org.glassfish.jaxb.core.marshaller.NoEscapeHandler;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Base64Data;
/*    */ import org.jvnet.staxex.XMLStreamWriterEx;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StAXExStreamWriterOutput
/*    */   extends XMLStreamWriterOutput
/*    */ {
/*    */   private final XMLStreamWriterEx out;
/*    */   
/*    */   public StAXExStreamWriterOutput(XMLStreamWriterEx out) {
/* 28 */     super((XMLStreamWriter)out, (CharacterEscapeHandler)NoEscapeHandler.theInstance);
/* 29 */     this.out = out;
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(Pcdata value, boolean needsSeparatingWhitespace) throws XMLStreamException {
/* 34 */     if (needsSeparatingWhitespace) {
/* 35 */       this.out.writeCharacters(" ");
/*    */     }
/*    */     
/* 38 */     if (!(value instanceof Base64Data)) {
/* 39 */       this.out.writeCharacters(value.toString());
/*    */     } else {
/* 41 */       Base64Data v = (Base64Data)value;
/* 42 */       this.out.writeBinary(v.getDataHandler());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\StAXExStreamWriterOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */