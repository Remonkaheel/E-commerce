/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlNs;
/*    */ import jakarta.xml.bind.annotation.XmlNsForm;
/*    */ import jakarta.xml.bind.annotation.XmlSchema;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlSchemaQuick
/*    */   extends Quick
/*    */   implements XmlSchema
/*    */ {
/*    */   private final XmlSchema core;
/*    */   
/*    */   public XmlSchemaQuick(Locatable upstream, XmlSchema core) {
/* 33 */     super(upstream);
/* 34 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 39 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 44 */     return new XmlSchemaQuick(upstream, (XmlSchema)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlSchema> annotationType() {
/* 49 */     return XmlSchema.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlNsForm attributeFormDefault() {
/* 54 */     return this.core.attributeFormDefault();
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlNsForm elementFormDefault() {
/* 59 */     return this.core.elementFormDefault();
/*    */   }
/*    */ 
/*    */   
/*    */   public String location() {
/* 64 */     return this.core.location();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 69 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlNs[] xmlns() {
/* 74 */     return this.core.xmlns();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlSchemaQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */