/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XsiNilLoader
/*     */   extends ProxyLoader
/*     */ {
/*     */   private final Loader defaultLoader;
/*     */   
/*     */   public XsiNilLoader(Loader defaultLoader) {
/*  34 */     this.defaultLoader = defaultLoader;
/*  35 */     assert defaultLoader != null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Loader selectLoader(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  41 */     int idx = ea.atts.getIndex("http://www.w3.org/2001/XMLSchema-instance", "nil");
/*     */     
/*  43 */     if (idx != -1) {
/*  44 */       Boolean b = DatatypeConverterImpl._parseBoolean(ea.atts.getValue(idx));
/*     */       
/*  46 */       if (b != null && b.booleanValue()) {
/*  47 */         onNil(state);
/*  48 */         boolean hasOtherAttributes = (ea.atts.getLength() - 1 > 0);
/*     */         
/*  50 */         if (!hasOtherAttributes || !(state.getPrev().getTarget() instanceof jakarta.xml.bind.JAXBElement)) {
/*  51 */           return Discarder.INSTANCE;
/*     */         }
/*     */       } 
/*     */     } 
/*  55 */     return this.defaultLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedChildElements() {
/*  60 */     return this.defaultLoader.getExpectedChildElements();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedAttributes() {
/*  65 */     return this.defaultLoader.getExpectedAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onNil(UnmarshallingContext.State state) throws SAXException {}
/*     */   
/*     */   public static final class Single
/*     */     extends XsiNilLoader
/*     */   {
/*     */     private final Accessor acc;
/*     */     
/*     */     public Single(Loader l, Accessor acc) {
/*  77 */       super(l);
/*  78 */       this.acc = acc;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onNil(UnmarshallingContext.State state) throws SAXException {
/*     */       try {
/*  84 */         this.acc.set(state.getPrev().getTarget(), null);
/*  85 */         state.getPrev().setNil(true);
/*  86 */       } catch (AccessorException e) {
/*  87 */         handleGenericException((Exception)e, true);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class Array
/*     */     extends XsiNilLoader {
/*     */     public Array(Loader core) {
/*  95 */       super(core);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void onNil(UnmarshallingContext.State state) {
/* 101 */       state.setTarget(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\XsiNilLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */