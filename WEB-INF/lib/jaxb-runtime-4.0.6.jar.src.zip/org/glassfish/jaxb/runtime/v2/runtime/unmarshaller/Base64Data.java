/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import com.sun.istack.Nullable;
/*     */ import jakarta.activation.DataHandler;
/*     */ import jakarta.activation.DataSource;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.Pcdata;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.UTF8XmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.util.ByteArrayOutputStreamEx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64Data
/*     */   extends Pcdata
/*     */ {
/*     */   private DataHandler dataHandler;
/*     */   private byte[] data;
/*     */   private int dataLen;
/*     */   @Nullable
/*     */   private String mimeType;
/*     */   
/*     */   public void set(byte[] data, int len, @Nullable String mimeType) {
/*  77 */     this.data = data;
/*  78 */     this.dataLen = len;
/*  79 */     this.dataHandler = null;
/*  80 */     this.mimeType = mimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(byte[] data, @Nullable String mimeType) {
/*  90 */     set(data, data.length, mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(DataHandler data) {
/*  97 */     assert data != null;
/*  98 */     this.dataHandler = data;
/*  99 */     this.data = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler getDataHandler() {
/* 106 */     if (this.dataHandler == null) {
/* 107 */       this.dataHandler = new DataHandler(new DataSource()
/*     */           {
/*     */             public String getContentType()
/*     */             {
/* 111 */               return Base64Data.this.getMimeType();
/*     */             }
/*     */ 
/*     */             
/*     */             public InputStream getInputStream() {
/* 116 */               return new ByteArrayInputStream(Base64Data.this.data, 0, Base64Data.this.dataLen);
/*     */             }
/*     */ 
/*     */             
/*     */             public String getName() {
/* 121 */               return null;
/*     */             }
/*     */ 
/*     */             
/*     */             public OutputStream getOutputStream() {
/* 126 */               throw new UnsupportedOperationException();
/*     */             }
/*     */           });
/*     */     }
/*     */     
/* 131 */     return this.dataHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getExact() {
/* 138 */     get();
/* 139 */     if (this.dataLen != this.data.length) {
/* 140 */       byte[] buf = new byte[this.dataLen];
/* 141 */       System.arraycopy(this.data, 0, buf, 0, this.dataLen);
/* 142 */       this.data = buf;
/*     */     } 
/* 144 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 151 */     if (this.dataHandler != null) {
/* 152 */       return this.dataHandler.getInputStream();
/*     */     }
/* 154 */     return new ByteArrayInputStream(this.data, 0, this.dataLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasData() {
/* 163 */     return (this.data != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] get() {
/* 170 */     if (this.data == null) {
/*     */       try {
/* 172 */         ByteArrayOutputStreamEx baos = new ByteArrayOutputStreamEx(1024);
/* 173 */         InputStream is = this.dataHandler.getDataSource().getInputStream();
/* 174 */         baos.readFrom(is);
/* 175 */         is.close();
/* 176 */         this.data = baos.getBuffer();
/* 177 */         this.dataLen = baos.size();
/* 178 */       } catch (IOException e) {
/*     */         
/* 180 */         this.dataLen = 0;
/*     */       } 
/*     */     }
/* 183 */     return this.data;
/*     */   }
/*     */   
/*     */   public int getDataLen() {
/* 187 */     return this.dataLen;
/*     */   }
/*     */   
/*     */   public String getMimeType() {
/* 191 */     if (this.mimeType == null) {
/* 192 */       return "application/octet-stream";
/*     */     }
/* 194 */     return this.mimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 205 */     get();
/* 206 */     return (this.dataLen + 2) / 3 * 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*     */     byte b1;
/* 220 */     int offset = index % 4;
/* 221 */     int base = index / 4 * 3;
/*     */ 
/*     */ 
/*     */     
/* 225 */     switch (offset) {
/*     */       case 0:
/* 227 */         return DatatypeConverterImpl.encode(this.data[base] >> 2);
/*     */       case 1:
/* 229 */         if (base + 1 < this.dataLen) {
/* 230 */           b1 = this.data[base + 1];
/*     */         } else {
/* 232 */           b1 = 0;
/*     */         } 
/* 234 */         return DatatypeConverterImpl.encode((this.data[base] & 0x3) << 4 | b1 >> 4 & 0xF);
/*     */ 
/*     */       
/*     */       case 2:
/* 238 */         if (base + 1 < this.dataLen) {
/* 239 */           byte b2; b1 = this.data[base + 1];
/* 240 */           if (base + 2 < this.dataLen) {
/* 241 */             b2 = this.data[base + 2];
/*     */           } else {
/* 243 */             b2 = 0;
/*     */           } 
/*     */           
/* 246 */           return DatatypeConverterImpl.encode((b1 & 0xF) << 2 | b2 >> 6 & 0x3);
/*     */         } 
/*     */ 
/*     */         
/* 250 */         return '=';
/*     */       
/*     */       case 3:
/* 253 */         if (base + 2 < this.dataLen) {
/* 254 */           return DatatypeConverterImpl.encode(this.data[base + 2] & 0x3F);
/*     */         }
/* 256 */         return '=';
/*     */     } 
/*     */ 
/*     */     
/* 260 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 270 */     StringBuilder buf = new StringBuilder();
/* 271 */     get();
/* 272 */     for (int i = start; i < end; i++) {
/* 273 */       buf.append(charAt(i));
/*     */     }
/* 275 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 284 */     get();
/* 285 */     return DatatypeConverterImpl._printBase64Binary(this.data, 0, this.dataLen);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(char[] buf, int start) {
/* 291 */     get();
/* 292 */     DatatypeConverterImpl._printBase64Binary(this.data, 0, this.dataLen, buf, start);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(UTF8XmlOutput output) throws IOException {
/* 298 */     get();
/* 299 */     output.text(this.data, this.dataLen);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(XMLStreamWriter output) throws IOException, XMLStreamException {
/* 304 */     get();
/* 305 */     DatatypeConverterImpl._printBase64Binary(this.data, 0, this.dataLen, output);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Base64Data.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */