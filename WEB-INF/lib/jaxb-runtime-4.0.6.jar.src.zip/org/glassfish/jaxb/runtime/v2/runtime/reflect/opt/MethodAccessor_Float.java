/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Float<B>
/*    */   extends Accessor<B, Float>
/*    */ {
/*    */   public MethodAccessor_Float() {
/* 27 */     super(Float.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Float get(B bean) {
/* 32 */     return Float.valueOf(((Bean)bean).get_float());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Float value) {
/* 37 */     ((Bean)bean).set_float((value == null) ? 0.0F : value.floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Float.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */