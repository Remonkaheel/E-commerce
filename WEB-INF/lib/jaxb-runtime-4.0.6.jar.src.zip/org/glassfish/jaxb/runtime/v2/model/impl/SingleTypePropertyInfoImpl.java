/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SingleTypePropertyInfoImpl<T, C, F, M>
/*     */   extends PropertyInfoImpl<T, C, F, M>
/*     */ {
/*     */   private NonElement<T, C> type;
/*     */   private final Accessor acc;
/*     */   private Transducer xducer;
/*     */   
/*     */   public SingleTypePropertyInfoImpl(ClassInfoImpl<T, C, F, M> classInfo, PropertySeed<T, C, F, M> seed) {
/*  44 */     super(classInfo, seed);
/*  45 */     if (this instanceof RuntimePropertyInfo) {
/*  46 */       Accessor rawAcc = ((RuntimeClassInfoImpl.RuntimePropertySeed)seed).getAccessor();
/*  47 */       if (getAdapter() != null && !isCollection())
/*     */       {
/*     */         
/*  50 */         rawAcc = rawAcc.adapt(((RuntimePropertyInfo)this).getAdapter()); } 
/*  51 */       this.acc = rawAcc;
/*     */     } else {
/*  53 */       this.acc = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<? extends NonElement<T, C>> ref() {
/*  58 */     return Collections.singletonList(getTarget());
/*     */   }
/*     */   
/*     */   public NonElement<T, C> getTarget() {
/*  62 */     if (this.type == null) {
/*  63 */       assert this.parent.builder != null : "this method must be called during the build stage";
/*  64 */       this.type = this.parent.builder.getTypeInfo(getIndividualType(), this);
/*     */     } 
/*  66 */     return this.type;
/*     */   }
/*     */   
/*     */   public PropertyInfo<T, C> getSource() {
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void link() {
/*  75 */     super.link();
/*     */     
/*  77 */     if (!NonElement.ANYTYPE_NAME.equals(this.type.getTypeName()) && !this.type.isSimpleType() && id() != ID.IDREF) {
/*  78 */       this.parent.builder.reportError(new IllegalAnnotationException(Messages.SIMPLE_TYPE_IS_REQUIRED
/*  79 */             .format(new Object[0]), this.seed));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  84 */     if (!isCollection() && this.seed.hasAnnotation(XmlList.class)) {
/*  85 */       this.parent.builder.reportError(new IllegalAnnotationException(Messages.XMLLIST_ON_SINGLE_PROPERTY
/*  86 */             .format(new Object[0]), this));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Accessor getAccessor() {
/* 105 */     return this.acc;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transducer getTransducer() {
/* 110 */     if (this.xducer == null) {
/* 111 */       this.xducer = RuntimeModelBuilder.createTransducer((RuntimeNonElementRef)this);
/* 112 */       if (this.xducer == null)
/*     */       {
/*     */         
/* 115 */         this.xducer = RuntimeBuiltinLeafInfoImpl.STRING;
/*     */       }
/*     */     } 
/* 118 */     return this.xducer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\SingleTypePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */