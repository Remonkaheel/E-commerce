/*    */ package org.glassfish.jaxb.runtime.v2.util;
/*    */ 
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FatalAdapter
/*    */   implements ErrorHandler
/*    */ {
/*    */   private final ErrorHandler core;
/*    */   
/*    */   public FatalAdapter(ErrorHandler handler) {
/* 26 */     this.core = handler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void warning(SAXParseException exception) throws SAXException {
/* 31 */     this.core.warning(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   public void error(SAXParseException exception) throws SAXException {
/* 36 */     this.core.fatalError(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   public void fatalError(SAXParseException exception) throws SAXException {
/* 41 */     this.core.fatalError(exception);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\FatalAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */