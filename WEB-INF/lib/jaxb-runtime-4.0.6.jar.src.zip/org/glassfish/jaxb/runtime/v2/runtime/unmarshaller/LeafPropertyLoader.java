/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeafPropertyLoader
/*    */   extends Loader
/*    */ {
/*    */   private final TransducedAccessor xacc;
/*    */   
/*    */   public LeafPropertyLoader(TransducedAccessor xacc) {
/* 28 */     super(true);
/* 29 */     this.xacc = xacc;
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/*    */     try {
/* 35 */       this.xacc.parse(state.getPrev().getTarget(), text);
/* 36 */     } catch (AccessorException e) {
/* 37 */       handleGenericException((Exception)e, true);
/* 38 */     } catch (RuntimeException e) {
/* 39 */       handleParseConversionException(state, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\LeafPropertyLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */