/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLocatable<C>
/*    */   implements Locatable
/*    */ {
/*    */   private final Locatable upstream;
/*    */   private final C clazz;
/*    */   private final Navigator<?, C, ?, ?> nav;
/*    */   
/*    */   public ClassLocatable(Locatable upstream, C clazz, Navigator<?, C, ?, ?> nav) {
/* 28 */     this.upstream = upstream;
/* 29 */     this.clazz = clazz;
/* 30 */     this.nav = nav;
/*    */   }
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 35 */     return this.upstream;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 40 */     return this.nav.getClassLocation(this.clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\ClassLocatable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */