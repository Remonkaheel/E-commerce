/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLEventWriterOutput
/*     */   extends XmlOutputAbstractImpl
/*     */ {
/*     */   private final XMLEventWriter out;
/*     */   private final XMLEventFactory ef;
/*     */   private final Characters sp;
/*     */   
/*     */   public XMLEventWriterOutput(XMLEventWriter out) {
/*  36 */     this.out = out;
/*  37 */     this.ef = XMLEventFactory.newInstance();
/*  38 */     this.sp = this.ef.createCharacters(" ");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/*  44 */     super.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*  45 */     if (!fragment) {
/*  46 */       this.out.add(this.ef.createStartDocument());
/*     */     }
/*     */   }
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/*  51 */     if (!fragment) {
/*  52 */       this.out.add(this.ef.createEndDocument());
/*  53 */       this.out.flush();
/*     */     } 
/*  55 */     super.endDocument(fragment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) throws IOException, XMLStreamException {
/*  60 */     this.out.add(this.ef
/*  61 */         .createStartElement(this.nsContext
/*  62 */           .getPrefix(prefix), this.nsContext
/*  63 */           .getNamespaceURI(prefix), localName));
/*     */ 
/*     */     
/*  66 */     NamespaceContextImpl.Element nse = this.nsContext.getCurrent();
/*  67 */     if (nse.count() > 0) {
/*  68 */       for (int i = nse.count() - 1; i >= 0; i--) {
/*  69 */         String uri = nse.getNsUri(i);
/*  70 */         if (uri.length() != 0 || nse.getBase() != 1)
/*     */         {
/*  72 */           this.out.add(this.ef.createNamespace(nse.getPrefix(i), uri));
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) throws IOException, XMLStreamException {
/*     */     Attribute att;
/*  80 */     if (prefix == -1) {
/*  81 */       att = this.ef.createAttribute(localName, value);
/*     */     } else {
/*  83 */       att = this.ef.createAttribute(this.nsContext
/*  84 */           .getPrefix(prefix), this.nsContext
/*  85 */           .getNamespaceURI(prefix), localName, value);
/*     */     } 
/*     */     
/*  88 */     this.out.add(att);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endStartTag() throws IOException, SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws IOException, SAXException, XMLStreamException {
/*  98 */     this.out.add(this.ef
/*  99 */         .createEndElement(this.nsContext
/* 100 */           .getPrefix(prefix), this.nsContext
/* 101 */           .getNamespaceURI(prefix), localName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(String value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 107 */     if (needsSeparatingWhitespace)
/* 108 */       this.out.add(this.sp); 
/* 109 */     this.out.add(this.ef.createCharacters(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 114 */     text(value.toString(), needsSeparatingWhitespace);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\XMLEventWriterOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */