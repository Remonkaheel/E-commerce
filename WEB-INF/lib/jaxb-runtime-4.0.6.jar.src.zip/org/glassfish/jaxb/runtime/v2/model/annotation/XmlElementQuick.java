/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElement;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementQuick
/*    */   extends Quick
/*    */   implements XmlElement
/*    */ {
/*    */   private final XmlElement core;
/*    */   
/*    */   public XmlElementQuick(Locatable upstream, XmlElement core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlElementQuick(upstream, (XmlElement)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElement> annotationType() {
/* 47 */     return XmlElement.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String defaultValue() {
/* 52 */     return this.core.defaultValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 57 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 62 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean nillable() {
/* 67 */     return this.core.nillable();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean required() {
/* 72 */     return this.core.required();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class type() {
/* 77 */     return this.core.type();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */