package org.glassfish.jaxb.runtime.v2.runtime.output;

import java.io.IOException;
import javax.xml.stream.XMLStreamException;
import org.glassfish.jaxb.runtime.v2.runtime.Name;
import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
import org.xml.sax.SAXException;

public interface XmlOutput {
  void startDocument(XMLSerializer paramXMLSerializer, boolean paramBoolean, int[] paramArrayOfint, NamespaceContextImpl paramNamespaceContextImpl) throws IOException, SAXException, XMLStreamException;
  
  void endDocument(boolean paramBoolean) throws IOException, SAXException, XMLStreamException;
  
  void beginStartTag(Name paramName) throws IOException, XMLStreamException;
  
  void beginStartTag(int paramInt, String paramString) throws IOException, XMLStreamException;
  
  void attribute(Name paramName, String paramString) throws IOException, XMLStreamException;
  
  void attribute(int paramInt, String paramString1, String paramString2) throws IOException, XMLStreamException;
  
  void endStartTag() throws IOException, SAXException;
  
  void endTag(Name paramName) throws IOException, SAXException, XMLStreamException;
  
  void endTag(int paramInt, String paramString) throws IOException, SAXException, XMLStreamException;
  
  void text(String paramString, boolean paramBoolean) throws IOException, SAXException, XMLStreamException;
  
  void text(Pcdata paramPcdata, boolean paramBoolean) throws IOException, SAXException, XMLStreamException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\XmlOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */