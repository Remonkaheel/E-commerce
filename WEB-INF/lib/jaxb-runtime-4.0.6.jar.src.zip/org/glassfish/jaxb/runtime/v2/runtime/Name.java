/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Name
/*    */   implements Comparable<Name>
/*    */ {
/*    */   public final String nsUri;
/*    */   public final String localName;
/*    */   public final short nsUriIndex;
/*    */   public final short localNameIndex;
/*    */   public final short qNameIndex;
/*    */   public final boolean isAttribute;
/*    */   
/*    */   Name(int qNameIndex, int nsUriIndex, String nsUri, int localIndex, String localName, boolean isAttribute) {
/* 55 */     this.qNameIndex = (short)qNameIndex;
/* 56 */     this.nsUri = nsUri;
/* 57 */     this.localName = localName;
/* 58 */     this.nsUriIndex = (short)nsUriIndex;
/* 59 */     this.localNameIndex = (short)localIndex;
/* 60 */     this.isAttribute = isAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "{" + this.nsUri + "}" + this.localName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QName toQName() {
/* 72 */     return new QName(this.nsUri, this.localName);
/*    */   }
/*    */   
/*    */   public boolean equals(String nsUri, String localName) {
/* 76 */     return (localName.equals(this.localName) && nsUri.equals(this.nsUri));
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(Name that) {
/* 81 */     int r = this.nsUri.compareTo(that.nsUri);
/* 82 */     if (r != 0) return r; 
/* 83 */     return this.localName.compareTo(that.localName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\Name.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */