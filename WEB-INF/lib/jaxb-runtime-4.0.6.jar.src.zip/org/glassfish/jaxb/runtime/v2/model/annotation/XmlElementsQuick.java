/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElement;
/*    */ import jakarta.xml.bind.annotation.XmlElements;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementsQuick
/*    */   extends Quick
/*    */   implements XmlElements
/*    */ {
/*    */   private final XmlElements core;
/*    */   
/*    */   public XmlElementsQuick(Locatable upstream, XmlElements core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlElementsQuick(upstream, (XmlElements)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElements> annotationType() {
/* 48 */     return XmlElements.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlElement[] value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementsQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */