/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Encoded
/*     */ {
/*     */   public byte[] buf;
/*     */   public int len;
/*     */   
/*     */   public Encoded() {}
/*     */   
/*     */   public Encoded(String text) {
/*  30 */     set(text);
/*     */   }
/*     */   
/*     */   public void ensureSize(int size) {
/*  34 */     if (this.buf == null || this.buf.length < size)
/*  35 */       this.buf = new byte[size]; 
/*     */   }
/*     */   
/*     */   public void set(String text) {
/*  39 */     int length = text.length();
/*     */     
/*  41 */     ensureSize(length * 3 + 1);
/*     */     
/*  43 */     int ptr = 0;
/*     */     
/*  45 */     for (int i = 0; i < length; i++) {
/*  46 */       char chr = text.charAt(i);
/*  47 */       if (chr > '')
/*  48 */       { if (chr > '߿')
/*  49 */         { if ('?' <= chr && chr <= '?')
/*     */           
/*  51 */           { int uc = ((chr & 0x3FF) << 10 | text.charAt(++i) & 0x3FF) + 65536;
/*     */             
/*  53 */             this.buf[ptr++] = (byte)(0xF0 | uc >> 18);
/*  54 */             this.buf[ptr++] = (byte)(0x80 | uc >> 12 & 0x3F);
/*  55 */             this.buf[ptr++] = (byte)(0x80 | uc >> 6 & 0x3F);
/*  56 */             this.buf[ptr++] = (byte)(128 + (uc & 0x3F)); }
/*     */           else
/*     */           
/*  59 */           { this.buf[ptr++] = (byte)(224 + (chr >> 12));
/*  60 */             this.buf[ptr++] = (byte)(128 + (chr >> 6 & 0x3F));
/*     */ 
/*     */ 
/*     */             
/*  64 */             this.buf[ptr++] = (byte)(128 + (chr & 0x3F)); }  } else { this.buf[ptr++] = (byte)(192 + (chr >> 6)); this.buf[ptr++] = (byte)(128 + (chr & 0x3F)); }
/*     */          }
/*  66 */       else { this.buf[ptr++] = (byte)chr; }
/*     */     
/*     */     } 
/*     */     
/*  70 */     this.len = ptr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscape(String text, boolean isAttribute) {
/*  81 */     int length = text.length();
/*  82 */     ensureSize(length * 6 + 1);
/*     */     
/*  84 */     int ptr = 0;
/*     */     
/*  86 */     for (int i = 0; i < length; i++) {
/*  87 */       char chr = text.charAt(i);
/*     */       
/*  89 */       int ptr1 = ptr;
/*  90 */       if (chr > '') {
/*  91 */         if (chr > '߿')
/*  92 */         { if ('?' <= chr && chr <= '?')
/*     */           
/*  94 */           { int uc = ((chr & 0x3FF) << 10 | text.charAt(++i) & 0x3FF) + 65536;
/*     */             
/*  96 */             this.buf[ptr++] = (byte)(0xF0 | uc >> 18);
/*  97 */             this.buf[ptr++] = (byte)(0x80 | uc >> 12 & 0x3F);
/*  98 */             this.buf[ptr++] = (byte)(0x80 | uc >> 6 & 0x3F);
/*  99 */             this.buf[ptr++] = (byte)(128 + (uc & 0x3F)); }
/*     */           else
/*     */           
/* 102 */           { this.buf[ptr1++] = (byte)(224 + (chr >> 12));
/* 103 */             this.buf[ptr1++] = (byte)(128 + (chr >> 6 & 0x3F));
/*     */ 
/*     */ 
/*     */             
/* 107 */             this.buf[ptr1++] = (byte)(128 + (chr & 0x3F)); }  } else { this.buf[ptr1++] = (byte)(192 + (chr >> 6)); this.buf[ptr1++] = (byte)(128 + (chr & 0x3F)); }
/*     */       
/*     */       } else {
/*     */         byte[] ent;
/* 111 */         if ((ent = attributeEntities[chr]) != null)
/*     */         
/*     */         { 
/*     */ 
/*     */           
/* 116 */           if (isAttribute || entities[chr] != null) {
/* 117 */             ptr1 = writeEntity(ent, ptr1);
/*     */           } else {
/* 119 */             this.buf[ptr1++] = (byte)chr;
/*     */           }  }
/* 121 */         else { this.buf[ptr1++] = (byte)chr; }
/*     */         
/* 123 */         ptr = ptr1;
/*     */       } 
/* 125 */     }  this.len = ptr;
/*     */   }
/*     */   
/*     */   private int writeEntity(byte[] entity, int ptr) {
/* 129 */     System.arraycopy(entity, 0, this.buf, ptr, entity.length);
/* 130 */     return ptr + entity.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(UTF8XmlOutput out) throws IOException {
/* 137 */     out.write(this.buf, 0, this.len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(char b) {
/* 145 */     this.buf[this.len++] = (byte)b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compact() {
/* 153 */     byte[] b = new byte[this.len];
/* 154 */     System.arraycopy(this.buf, 0, b, 0, this.len);
/* 155 */     this.buf = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private static final byte[][] entities = new byte[128][];
/* 165 */   private static final byte[][] attributeEntities = new byte[128][];
/*     */   
/*     */   static {
/* 168 */     add('&', "&amp;", false);
/* 169 */     add('<', "&lt;", false);
/* 170 */     add('>', "&gt;", false);
/* 171 */     add('"', "&quot;", true);
/* 172 */     add('\t', "&#x9;", true);
/* 173 */     add('\r', "&#xD;", false);
/* 174 */     add('\n', "&#xA;", true);
/*     */   }
/*     */   
/*     */   private static void add(char c, String s, boolean attOnly) {
/* 178 */     byte[] image = UTF8XmlOutput.toBytes(s);
/* 179 */     attributeEntities[c] = image;
/* 180 */     if (!attOnly)
/* 181 */       entities[c] = image; 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\Encoded.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */