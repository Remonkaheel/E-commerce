/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Integer<B>
/*    */   extends Accessor<B, Integer>
/*    */ {
/*    */   public MethodAccessor_Integer() {
/* 27 */     super(Integer.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer get(B bean) {
/* 32 */     return Integer.valueOf(((Bean)bean).get_int());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Integer value) {
/* 37 */     ((Bean)bean).set_int((value == null) ? 0 : value.intValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Integer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */