package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Type;
import java.util.Set;
import org.glassfish.jaxb.core.v2.model.core.ReferencePropertyInfo;

public interface RuntimeReferencePropertyInfo extends ReferencePropertyInfo<Type, Class>, RuntimePropertyInfo {
  Set<? extends RuntimeElement> getElements();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeReferencePropertyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */