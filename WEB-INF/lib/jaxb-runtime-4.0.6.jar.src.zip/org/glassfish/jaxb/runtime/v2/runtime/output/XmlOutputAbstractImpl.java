/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XmlOutputAbstractImpl
/*     */   implements XmlOutput
/*     */ {
/*     */   protected int[] nsUriIndex2prefixIndex;
/*     */   protected NamespaceContextImpl nsContext;
/*     */   protected XMLSerializer serializer;
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/*  50 */     this.nsUriIndex2prefixIndex = nsUriIndex2prefixIndex;
/*  51 */     this.nsContext = nsContext;
/*  52 */     this.serializer = serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/*  63 */     this.serializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginStartTag(Name name) throws IOException, XMLStreamException {
/*  78 */     beginStartTag(this.nsUriIndex2prefixIndex[name.nsUriIndex], name.localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void beginStartTag(int paramInt, String paramString) throws IOException, XMLStreamException;
/*     */ 
/*     */   
/*     */   public void attribute(Name name, String value) throws IOException, XMLStreamException {
/*  86 */     short idx = name.nsUriIndex;
/*  87 */     if (idx == -1) {
/*  88 */       attribute(-1, name.localName, value);
/*     */     } else {
/*  90 */       attribute(this.nsUriIndex2prefixIndex[idx], name.localName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void attribute(int paramInt, String paramString1, String paramString2) throws IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void endStartTag() throws IOException, SAXException;
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag(Name name) throws IOException, SAXException, XMLStreamException {
/* 105 */     endTag(this.nsUriIndex2prefixIndex[name.nsUriIndex], name.localName);
/*     */   }
/*     */   
/*     */   public abstract void endTag(int paramInt, String paramString) throws IOException, SAXException, XMLStreamException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\XmlOutputAbstractImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */