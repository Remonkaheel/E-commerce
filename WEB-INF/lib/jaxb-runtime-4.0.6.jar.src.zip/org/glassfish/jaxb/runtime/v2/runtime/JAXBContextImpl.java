/*      */ package org.glassfish.jaxb.runtime.v2.runtime;
/*      */ 
/*      */ import com.sun.istack.NotNull;
/*      */ import com.sun.istack.Pool;
/*      */ import com.sun.xml.txw2.output.ResultFactory;
/*      */ import jakarta.xml.bind.Binder;
/*      */ import jakarta.xml.bind.JAXBElement;
/*      */ import jakarta.xml.bind.JAXBException;
/*      */ import jakarta.xml.bind.JAXBIntrospector;
/*      */ import jakarta.xml.bind.Marshaller;
/*      */ import jakarta.xml.bind.SchemaOutputResolver;
/*      */ import jakarta.xml.bind.Unmarshaller;
/*      */ import jakarta.xml.bind.annotation.XmlAttachmentRef;
/*      */ import jakarta.xml.bind.annotation.XmlList;
/*      */ import jakarta.xml.bind.annotation.XmlNs;
/*      */ import jakarta.xml.bind.annotation.XmlSchema;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*      */ import java.io.IOException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.FactoryConfigurationError;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Result;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerConfigurationException;
/*      */ import javax.xml.transform.sax.SAXTransformerFactory;
/*      */ import javax.xml.transform.sax.TransformerHandler;
/*      */ import org.glassfish.jaxb.core.api.ErrorListener;
/*      */ import org.glassfish.jaxb.core.unmarshaller.DOMScanner;
/*      */ import org.glassfish.jaxb.core.unmarshaller.InfosetScanner;
/*      */ import org.glassfish.jaxb.core.util.Which;
/*      */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*      */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*      */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*      */ import org.glassfish.jaxb.core.v2.model.core.Ref;
/*      */ import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;
/*      */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*      */ import org.glassfish.jaxb.core.v2.runtime.RuntimeUtil;
/*      */ import org.glassfish.jaxb.core.v2.util.EditDistance;
/*      */ import org.glassfish.jaxb.core.v2.util.XmlFactory;
/*      */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*      */ import org.glassfish.jaxb.runtime.api.Bridge;
/*      */ import org.glassfish.jaxb.runtime.api.CompositeStructure;
/*      */ import org.glassfish.jaxb.runtime.api.JAXBRIContext;
/*      */ import org.glassfish.jaxb.runtime.api.RawAccessor;
/*      */ import org.glassfish.jaxb.runtime.api.TypeReference;
/*      */ import org.glassfish.jaxb.runtime.v2.model.annotation.RuntimeAnnotationReader;
/*      */ import org.glassfish.jaxb.runtime.v2.model.annotation.RuntimeInlineAnnotationReader;
/*      */ import org.glassfish.jaxb.runtime.v2.model.impl.RuntimeBuiltinLeafInfoImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.model.impl.RuntimeModelBuilder;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeArrayInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeBuiltinLeafInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeClassInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeEnumLeafInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeLeafInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfoSet;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.Encoded;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.property.AttributeProperty;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.property.Property;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TagName;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallerImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.XmlSchemaGenerator;
/*      */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Node;
/*      */ import org.xml.sax.SAXParseException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JAXBContextImpl
/*      */   extends JAXBRIContext
/*      */ {
/*      */   private final Map<TypeReference, Bridge> bridges;
/*      */   private static DocumentBuilder db;
/*      */   private final QNameMap<JaxBeanInfo> rootMap;
/*      */   private final HashMap<QName, JaxBeanInfo> typeMap;
/*      */   private final Map<Class, JaxBeanInfo> beanInfoMap;
/*      */   protected Map<RuntimeTypeInfo, JaxBeanInfo> beanInfos;
/*      */   private final Map<Class, Map<QName, ElementBeanInfoImpl>> elements;
/*      */   public final Pool<Marshaller> marshallerPool;
/*      */   public final Pool<Unmarshaller> unmarshallerPool;
/*      */   public NameBuilder nameBuilder;
/*      */   public final NameList nameList;
/*      */   private final String defaultNsUri;
/*      */   private final Class[] classes;
/*      */   protected final boolean c14nSupport;
/*      */   public final boolean xmlAccessorFactorySupport;
/*      */   public final boolean allNillable;
/*      */   public final boolean retainPropertyInfo;
/*      */   public final boolean supressAccessorWarnings;
/*      */   public final boolean improvedXsiTypeHandling;
/*      */   public final boolean disableSecurityProcessing;
/*      */   private WeakReference<RuntimeTypeInfoSet> typeInfoSetCache;
/*      */   @NotNull
/*      */   private RuntimeAnnotationReader annotationReader;
/*      */   private boolean hasSwaRef;
/*      */   @NotNull
/*      */   private final Map<Class, Class> subclassReplacements;
/*      */   public final boolean fastBoot;
/*      */   private Set<XmlNs> xmlNsSet;
/*      */   public Boolean backupWithParentNamespace;
/*      */   public final int maxErrorsCount;
/*      */   private Encoded[] utf8nameTable;
/*      */   
/*      */   public Set<XmlNs> getXmlNsSet() {
/*  226 */     return this.xmlNsSet;
/*      */   } private JAXBContextImpl(JAXBContextBuilder builder) throws JAXBException { boolean fastB; this.bridges = new LinkedHashMap<>(); this.rootMap = new QNameMap(); this.typeMap = new HashMap<>(); this.beanInfoMap = (Map)new LinkedHashMap<>(); this.beanInfos = new LinkedHashMap<>(); this.elements = (Map)new LinkedHashMap<>(); this.marshallerPool = (Pool<Marshaller>)new Pool.Impl<Marshaller>() { @NotNull protected Marshaller create() { return (Marshaller)JAXBContextImpl.this.createMarshaller(); } }
/*      */       ; this.unmarshallerPool = (Pool<Unmarshaller>)new Pool.Impl<Unmarshaller>() { @NotNull protected Unmarshaller create() { return (Unmarshaller)JAXBContextImpl.this.createUnmarshaller(); } }; this.nameBuilder = new NameBuilder();
/*      */     this.xmlNsSet = null;
/*      */     this.backupWithParentNamespace = null;
/*  231 */     this.defaultNsUri = builder.defaultNsUri;
/*  232 */     this.retainPropertyInfo = builder.retainPropertyInfo;
/*  233 */     this.annotationReader = builder.annotationReader;
/*  234 */     this.subclassReplacements = builder.subclassReplacements;
/*  235 */     this.c14nSupport = builder.c14nSupport;
/*  236 */     this.classes = builder.classes;
/*  237 */     this.xmlAccessorFactorySupport = builder.xmlAccessorFactorySupport;
/*  238 */     this.allNillable = builder.allNillable;
/*  239 */     this.supressAccessorWarnings = builder.supressAccessorWarnings;
/*  240 */     this.improvedXsiTypeHandling = builder.improvedXsiTypeHandling;
/*  241 */     this.disableSecurityProcessing = builder.disableSecurityProcessing;
/*  242 */     this.backupWithParentNamespace = builder.backupWithParentNamespace;
/*  243 */     this.maxErrorsCount = builder.maxErrorsCount;
/*      */     
/*  245 */     Collection<TypeReference> typeRefs = builder.typeRefs;
/*      */ 
/*      */     
/*      */     try {
/*  249 */       fastB = Boolean.getBoolean(JAXBContextImpl.class.getName() + ".fastBoot");
/*  250 */     } catch (SecurityException e) {
/*  251 */       fastB = false;
/*      */     } 
/*  253 */     this.fastBoot = fastB;
/*      */     
/*  255 */     RuntimeTypeInfoSet typeSet = getTypeInfoSet();
/*      */ 
/*      */     
/*  258 */     this.elements.put(null, new LinkedHashMap<>());
/*      */ 
/*      */     
/*  261 */     for (RuntimeBuiltinLeafInfo leaf : RuntimeBuiltinLeafInfoImpl.builtinBeanInfos) {
/*  262 */       LeafBeanInfoImpl<?> bi = new LeafBeanInfoImpl(this, (RuntimeLeafInfo)leaf);
/*  263 */       this.beanInfoMap.put(leaf.getClazz(), bi);
/*  264 */       for (QName t : bi.getTypeNames()) {
/*  265 */         this.typeMap.put(t, bi);
/*      */       }
/*      */     } 
/*  268 */     for (RuntimeEnumLeafInfo e : typeSet.enums().values()) {
/*  269 */       JaxBeanInfo<?> bi = getOrCreate(e);
/*  270 */       for (QName qn : bi.getTypeNames())
/*  271 */         this.typeMap.put(qn, bi); 
/*  272 */       if (e.isElement()) {
/*  273 */         this.rootMap.put(e.getElementName(), bi);
/*      */       }
/*      */     } 
/*  276 */     for (RuntimeArrayInfo a : typeSet.arrays().values()) {
/*  277 */       JaxBeanInfo<?> ai = getOrCreate(a);
/*  278 */       for (QName qn : ai.getTypeNames()) {
/*  279 */         this.typeMap.put(qn, ai);
/*      */       }
/*      */     } 
/*  282 */     for (Map.Entry<Class<?>, ? extends RuntimeClassInfo> e : (Iterable<Map.Entry<Class<?>, ? extends RuntimeClassInfo>>)typeSet.beans().entrySet()) {
/*  283 */       ClassBeanInfoImpl<?> bi = getOrCreate(e.getValue());
/*      */       
/*  285 */       XmlSchema xs = (XmlSchema)this.annotationReader.getPackageAnnotation(XmlSchema.class, e.getKey(), null);
/*  286 */       if (xs != null && 
/*  287 */         xs.xmlns() != null && (xs.xmlns()).length > 0) {
/*  288 */         if (this.xmlNsSet == null)
/*  289 */           this.xmlNsSet = new HashSet<>(); 
/*  290 */         this.xmlNsSet.addAll(Arrays.asList(xs.xmlns()));
/*      */       } 
/*      */ 
/*      */       
/*  294 */       if (bi.isElement()) {
/*  295 */         this.rootMap.put(((RuntimeClassInfo)e.getValue()).getElementName(), bi);
/*      */       }
/*  297 */       for (QName qn : bi.getTypeNames()) {
/*  298 */         this.typeMap.put(qn, bi);
/*      */       }
/*      */     } 
/*      */     
/*  302 */     for (RuntimeElementInfo n : typeSet.getAllElements()) {
/*  303 */       ElementBeanInfoImpl bi = getOrCreate(n);
/*  304 */       if (n.getScope() == null) {
/*  305 */         this.rootMap.put(n.getElementName(), bi);
/*      */       }
/*  307 */       RuntimeClassInfo scope = n.getScope();
/*  308 */       Class scopeClazz = (scope == null) ? null : (Class)scope.getClazz();
/*  309 */       Map<QName, ElementBeanInfoImpl> m = this.elements.computeIfAbsent(scopeClazz, k -> new LinkedHashMap<>());
/*  310 */       m.put(n.getElementName(), bi);
/*      */     } 
/*      */ 
/*      */     
/*  314 */     this.beanInfoMap.put(JAXBElement.class, new ElementBeanInfoImpl(this));
/*      */     
/*  316 */     this.beanInfoMap.put(CompositeStructure.class, new CompositeStructureBeanInfo(this));
/*      */     
/*  318 */     getOrCreate((RuntimeTypeInfo)typeSet.getAnyTypeInfo());
/*      */ 
/*      */     
/*  321 */     for (JaxBeanInfo bi : this.beanInfos.values()) {
/*  322 */       bi.link(this);
/*      */     }
/*      */     
/*  325 */     for (Map.Entry<Class<?>, Class<?>> e : (Iterable<Map.Entry<Class<?>, Class<?>>>)RuntimeUtil.primitiveToBox.entrySet()) {
/*  326 */       this.beanInfoMap.put(e.getKey(), this.beanInfoMap.get(e.getValue()));
/*      */     }
/*      */     
/*  329 */     Navigator<Type, Class<?>, Field, Method> nav = typeSet.getNavigator();
/*      */     
/*  331 */     for (TypeReference tr : typeRefs) {
/*  332 */       InternalBridge<?> bridge; XmlJavaTypeAdapter xjta = (XmlJavaTypeAdapter)tr.get(XmlJavaTypeAdapter.class);
/*  333 */       Adapter<Type, Class<?>> a = null;
/*  334 */       XmlList xl = (XmlList)tr.get(XmlList.class);
/*      */ 
/*      */       
/*  337 */       Class<?> erasedType = (Class)nav.erasure(tr.type);
/*      */       
/*  339 */       if (xjta != null) {
/*  340 */         a = new Adapter(xjta.value(), nav);
/*      */       }
/*  342 */       if (tr.get(XmlAttachmentRef.class) != null) {
/*  343 */         a = new Adapter(SwaRefAdapter.class, nav);
/*  344 */         this.hasSwaRef = true;
/*      */       } 
/*      */       
/*  347 */       if (a != null) {
/*  348 */         erasedType = (Class)nav.erasure(a.defaultType);
/*      */       }
/*      */       
/*  351 */       Name name = this.nameBuilder.createElementName(tr.tagName);
/*      */ 
/*      */       
/*  354 */       if (xl == null) {
/*  355 */         bridge = new BridgeImpl(this, name, getBeanInfo(erasedType, true), tr);
/*      */       } else {
/*  357 */         bridge = new BridgeImpl(this, name, new ValueListBeanInfoImpl(this, erasedType), tr);
/*      */       } 
/*  359 */       if (a != null) {
/*  360 */         bridge = new BridgeAdapter<>(bridge, (Class<? extends XmlAdapter<?, ?>>)a.adapterType);
/*      */       }
/*  362 */       this.bridges.put(tr, bridge);
/*      */     } 
/*      */     
/*  365 */     this.nameList = this.nameBuilder.conclude();
/*      */     
/*  367 */     for (JaxBeanInfo bi : this.beanInfos.values()) {
/*  368 */       bi.wrapUp();
/*      */     }
/*      */     
/*  371 */     this.nameBuilder = null;
/*  372 */     this.beanInfos = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasSwaRef() {
/*  380 */     return this.hasSwaRef;
/*      */   }
/*      */ 
/*      */   
/*      */   public RuntimeTypeInfoSet getRuntimeTypeInfoSet() {
/*      */     try {
/*  386 */       return getTypeInfoSet();
/*  387 */     } catch (IllegalAnnotationsException e) {
/*      */       
/*  389 */       throw new AssertionError(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RuntimeTypeInfoSet getTypeInfoSet() throws IllegalAnnotationsException {
/*  399 */     if (this.typeInfoSetCache != null) {
/*  400 */       RuntimeTypeInfoSet runtimeTypeInfoSet = this.typeInfoSetCache.get();
/*  401 */       if (runtimeTypeInfoSet != null) {
/*  402 */         return runtimeTypeInfoSet;
/*      */       }
/*      */     } 
/*  405 */     RuntimeModelBuilder builder = new RuntimeModelBuilder(this, this.annotationReader, this.subclassReplacements, this.defaultNsUri);
/*      */     
/*  407 */     IllegalAnnotationsException.Builder errorHandler = new IllegalAnnotationsException.Builder();
/*  408 */     builder.setErrorHandler(errorHandler);
/*      */     
/*  410 */     for (Class<CompositeStructure> c : this.classes) {
/*  411 */       if (c != CompositeStructure.class)
/*      */       {
/*      */ 
/*      */         
/*  415 */         builder.getTypeInfo(new Ref(c));
/*      */       }
/*      */     } 
/*  418 */     this.hasSwaRef |= builder.hasSwaRef;
/*  419 */     RuntimeTypeInfoSet r = builder.link();
/*      */     
/*  421 */     errorHandler.check();
/*  422 */     assert r != null : "if no error was reported, the link must be a success";
/*      */     
/*  424 */     this.typeInfoSetCache = new WeakReference<>(r);
/*      */     
/*  426 */     return r;
/*      */   }
/*      */ 
/*      */   
/*      */   public ElementBeanInfoImpl getElement(Class scope, QName name) {
/*  431 */     Map<QName, ElementBeanInfoImpl> m = this.elements.get(scope);
/*  432 */     if (m != null) {
/*  433 */       ElementBeanInfoImpl bi = m.get(name);
/*  434 */       if (bi != null)
/*  435 */         return bi; 
/*      */     } 
/*  437 */     m = this.elements.get(null);
/*  438 */     return m.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ElementBeanInfoImpl getOrCreate(RuntimeElementInfo rei) {
/*  446 */     JaxBeanInfo bi = this.beanInfos.get(rei);
/*  447 */     if (bi != null) return (ElementBeanInfoImpl)bi;
/*      */ 
/*      */     
/*  450 */     return new ElementBeanInfoImpl(this, rei);
/*      */   }
/*      */   
/*      */   protected JaxBeanInfo getOrCreate(RuntimeEnumLeafInfo eli) {
/*  454 */     JaxBeanInfo bi = this.beanInfos.get(eli);
/*  455 */     if (bi != null) return bi; 
/*  456 */     bi = new LeafBeanInfoImpl(this, (RuntimeLeafInfo)eli);
/*  457 */     this.beanInfoMap.put(bi.jaxbType, bi);
/*  458 */     return bi;
/*      */   }
/*      */   
/*      */   protected ClassBeanInfoImpl getOrCreate(RuntimeClassInfo ci) {
/*  462 */     ClassBeanInfoImpl bi = (ClassBeanInfoImpl)this.beanInfos.get(ci);
/*  463 */     if (bi != null) return bi; 
/*  464 */     bi = new ClassBeanInfoImpl(this, ci);
/*  465 */     this.beanInfoMap.put(bi.jaxbType, bi);
/*  466 */     return bi;
/*      */   }
/*      */   
/*      */   protected JaxBeanInfo getOrCreate(RuntimeArrayInfo ai) {
/*  470 */     JaxBeanInfo abi = this.beanInfos.get(ai);
/*  471 */     if (abi != null) return abi;
/*      */     
/*  473 */     abi = new ArrayBeanInfoImpl(this, ai);
/*      */     
/*  475 */     this.beanInfoMap.put(ai.getType(), abi);
/*  476 */     return abi;
/*      */   }
/*      */   
/*      */   public JaxBeanInfo getOrCreate(RuntimeTypeInfo e) {
/*  480 */     if (e instanceof RuntimeElementInfo)
/*  481 */       return getOrCreate((RuntimeElementInfo)e); 
/*  482 */     if (e instanceof RuntimeClassInfo)
/*  483 */       return getOrCreate((RuntimeClassInfo)e); 
/*  484 */     if (e instanceof RuntimeLeafInfo) {
/*  485 */       JaxBeanInfo bi = this.beanInfos.get(e);
/*  486 */       assert bi != null;
/*  487 */       return bi;
/*      */     } 
/*  489 */     if (e instanceof RuntimeArrayInfo)
/*  490 */       return getOrCreate((RuntimeArrayInfo)e); 
/*  491 */     if (e.getType() == Object.class) {
/*      */       
/*  493 */       JaxBeanInfo bi = this.beanInfoMap.get(Object.class);
/*  494 */       if (bi == null) {
/*  495 */         bi = new AnyTypeBeanInfo(this, e);
/*  496 */         this.beanInfoMap.put(Object.class, bi);
/*      */       } 
/*  498 */       return bi;
/*      */     } 
/*      */     
/*  501 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxBeanInfo getBeanInfo(Object o) {
/*  516 */     for (Class<?> c = o.getClass(); c != Object.class; c = c.getSuperclass()) {
/*  517 */       JaxBeanInfo bi = this.beanInfoMap.get(c);
/*  518 */       if (bi != null) return bi; 
/*      */     } 
/*  520 */     if (o instanceof org.w3c.dom.Element)
/*  521 */       return this.beanInfoMap.get(Object.class); 
/*  522 */     for (Class<?> clazz : o.getClass().getInterfaces()) {
/*  523 */       JaxBeanInfo bi = this.beanInfoMap.get(clazz);
/*  524 */       if (bi != null) return bi; 
/*      */     } 
/*  526 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxBeanInfo getBeanInfo(Object o, boolean fatal) throws JAXBException {
/*  538 */     JaxBeanInfo bi = getBeanInfo(o);
/*  539 */     if (bi != null) return bi; 
/*  540 */     if (fatal) {
/*  541 */       if (o instanceof Document)
/*  542 */         throw new JAXBException(Messages.ELEMENT_NEEDED_BUT_FOUND_DOCUMENT.format(new Object[] { o.getClass() })); 
/*  543 */       throw new JAXBException(Messages.UNKNOWN_CLASS.format(new Object[] { o.getClass() }));
/*      */     } 
/*  545 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> JaxBeanInfo<T> getBeanInfo(Class<T> clazz) {
/*  559 */     return this.beanInfoMap.get(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> JaxBeanInfo<T> getBeanInfo(Class<T> clazz, boolean fatal) throws JAXBException {
/*  571 */     JaxBeanInfo<T> bi = getBeanInfo(clazz);
/*  572 */     if (bi != null) return bi; 
/*  573 */     if (fatal)
/*  574 */       throw new JAXBException(clazz.getName() + " is not known to this context"); 
/*  575 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Loader selectRootLoader(UnmarshallingContext.State state, TagName tag) {
/*  586 */     JaxBeanInfo beanInfo = (JaxBeanInfo)this.rootMap.get(tag.uri, tag.local);
/*  587 */     if (beanInfo == null) {
/*  588 */       return null;
/*      */     }
/*  590 */     return beanInfo.getLoader(this, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxBeanInfo getGlobalType(QName name) {
/*  602 */     return this.typeMap.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNearestTypeName(QName name) {
/*  613 */     String[] all = new String[this.typeMap.size()];
/*  614 */     int i = 0;
/*  615 */     for (QName qn : this.typeMap.keySet()) {
/*  616 */       if (qn.getLocalPart().equals(name.getLocalPart()))
/*  617 */         return qn.toString(); 
/*  618 */       all[i++] = qn.toString();
/*      */     } 
/*      */     
/*  621 */     String nearest = EditDistance.findNearest(name.toString(), all);
/*      */     
/*  623 */     if (EditDistance.editDistance(nearest, name.toString()) > 10) {
/*  624 */       return null;
/*      */     }
/*  626 */     return nearest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<QName> getValidRootNames() {
/*  634 */     Set<QName> r = new TreeSet<>(QNAME_COMPARATOR);
/*  635 */     for (QNameMap.Entry e : this.rootMap.entrySet()) {
/*  636 */       r.add(e.createQName());
/*      */     }
/*  638 */     return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Encoded[] getUTF8NameTable() {
/*  647 */     if (this.utf8nameTable == null) {
/*  648 */       Encoded[] x = new Encoded[this.nameList.localNames.length];
/*  649 */       for (int i = 0; i < x.length; i++) {
/*  650 */         Encoded e = new Encoded(this.nameList.localNames[i]);
/*  651 */         e.compact();
/*  652 */         x[i] = e;
/*      */       } 
/*  654 */       this.utf8nameTable = x;
/*      */     } 
/*  656 */     return this.utf8nameTable;
/*      */   }
/*      */   
/*      */   public int getNumberOfLocalNames() {
/*  660 */     return this.nameList.localNames.length;
/*      */   }
/*      */   
/*      */   public int getNumberOfElementNames() {
/*  664 */     return this.nameList.numberOfElementNames;
/*      */   }
/*      */   
/*      */   public int getNumberOfAttributeNames() {
/*  668 */     return this.nameList.numberOfAttributeNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Transformer createTransformer(boolean disableSecureProcessing) {
/*      */     try {
/*  676 */       SAXTransformerFactory tf = (SAXTransformerFactory)XmlFactory.createTransformerFactory(disableSecureProcessing);
/*  677 */       return tf.newTransformer();
/*  678 */     } catch (TransformerConfigurationException e) {
/*  679 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TransformerHandler createTransformerHandler(boolean disableSecureProcessing) {
/*      */     try {
/*  688 */       SAXTransformerFactory tf = (SAXTransformerFactory)XmlFactory.createTransformerFactory(disableSecureProcessing);
/*  689 */       return tf.newTransformerHandler();
/*  690 */     } catch (TransformerConfigurationException e) {
/*  691 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Document createDom(boolean disableSecurityProcessing) {
/*  699 */     synchronized (JAXBContextImpl.class) {
/*  700 */       if (db == null) {
/*      */         try {
/*  702 */           DocumentBuilderFactory dbf = XmlFactory.createDocumentBuilderFactory(disableSecurityProcessing);
/*  703 */           db = dbf.newDocumentBuilder();
/*  704 */         } catch (ParserConfigurationException e) {
/*      */           
/*  706 */           throw new FactoryConfigurationError(e);
/*      */         } 
/*      */       }
/*  709 */       return db.newDocument();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MarshallerImpl createMarshaller() {
/*  715 */     return new MarshallerImpl(this, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public UnmarshallerImpl createUnmarshaller() {
/*  720 */     return new UnmarshallerImpl(this, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public JAXBIntrospector createJAXBIntrospector() {
/*  725 */     return new JAXBIntrospector()
/*      */       {
/*      */         public boolean isElement(Object object) {
/*  728 */           return (getElementName(object) != null);
/*      */         }
/*      */ 
/*      */         
/*      */         public QName getElementName(Object jaxbElement) {
/*      */           try {
/*  734 */             return JAXBContextImpl.this.getElementName(jaxbElement);
/*  735 */           } catch (JAXBException e) {
/*  736 */             return null;
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   private NonElement<Type, Class> getXmlType(RuntimeTypeInfoSet tis, TypeReference tr) {
/*  743 */     if (tr == null) {
/*  744 */       throw new IllegalArgumentException();
/*      */     }
/*  746 */     XmlJavaTypeAdapter xjta = (XmlJavaTypeAdapter)tr.get(XmlJavaTypeAdapter.class);
/*  747 */     XmlList xl = (XmlList)tr.get(XmlList.class);
/*      */     
/*  749 */     Ref<Type, Class<?>> ref = new Ref((AnnotationReader)this.annotationReader, tis.getNavigator(), tr.type, xjta, xl);
/*      */     
/*  751 */     return tis.getTypeInfo(ref);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateEpisode(Result output) {
/*  756 */     if (output == null)
/*  757 */       throw new IllegalArgumentException(); 
/*  758 */     createSchemaGenerator().writeEpisodeFile(ResultFactory.createSerializer(output));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSchema(SchemaOutputResolver outputResolver) throws IOException {
/*  764 */     if (outputResolver == null) {
/*  765 */       throw new IOException(Messages.NULL_OUTPUT_RESOLVER.format(new Object[0]));
/*      */     }
/*  767 */     final SAXParseException[] e = new SAXParseException[1];
/*  768 */     final SAXParseException[] w = new SAXParseException[1];
/*      */     
/*  770 */     createSchemaGenerator().write(outputResolver, new ErrorListener()
/*      */         {
/*      */           public void error(SAXParseException exception) {
/*  773 */             e[0] = exception;
/*      */           }
/*      */ 
/*      */           
/*      */           public void fatalError(SAXParseException exception) {
/*  778 */             e[0] = exception;
/*      */           }
/*      */ 
/*      */           
/*      */           public void warning(SAXParseException exception) {
/*  783 */             w[0] = exception;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void info(SAXParseException exception) {}
/*      */         });
/*  790 */     if (e[0] != null) {
/*  791 */       throw new IOException(Messages.FAILED_TO_GENERATE_SCHEMA.format(new Object[0]), e[0]);
/*      */     }
/*  793 */     if (w[0] != null) {
/*  794 */       throw new IOException(Messages.ERROR_PROCESSING_SCHEMA.format(new Object[0]), w[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private XmlSchemaGenerator<Type, Class, Field, Method> createSchemaGenerator() {
/*      */     RuntimeTypeInfoSet tis;
/*      */     try {
/*  801 */       tis = getTypeInfoSet();
/*  802 */     } catch (IllegalAnnotationsException e) {
/*      */       
/*  804 */       throw new AssertionError(e);
/*      */     } 
/*      */ 
/*      */     
/*  808 */     XmlSchemaGenerator<Type, Class<?>, Field, Method> xsdgen = new XmlSchemaGenerator(tis.getNavigator(), (TypeInfoSet)tis);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  813 */     Set<QName> rootTagNames = new HashSet<>();
/*  814 */     for (RuntimeElementInfo ei : tis.getAllElements()) {
/*  815 */       rootTagNames.add(ei.getElementName());
/*      */     }
/*  817 */     for (RuntimeClassInfo ci : tis.beans().values()) {
/*  818 */       if (ci.isElement()) {
/*  819 */         rootTagNames.add(ci.asElement().getElementName());
/*      */       }
/*      */     } 
/*  822 */     for (TypeReference tr : this.bridges.keySet()) {
/*  823 */       if (rootTagNames.contains(tr.tagName)) {
/*      */         continue;
/*      */       }
/*  826 */       if (tr.type == void.class || tr.type == Void.class) {
/*  827 */         xsdgen.add(tr.tagName, false, null); continue;
/*      */       } 
/*  829 */       if (tr.type == CompositeStructure.class) {
/*      */         continue;
/*      */       }
/*  832 */       NonElement<Type, Class<?>> typeInfo = getXmlType(tis, tr);
/*  833 */       xsdgen.add(tr.tagName, !tis.getNavigator().isPrimitive(tr.type), typeInfo);
/*      */     } 
/*      */     
/*  836 */     return xsdgen;
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getTypeName(TypeReference tr) {
/*      */     try {
/*  842 */       NonElement<Type, Class<?>> xt = getXmlType(getTypeInfoSet(), tr);
/*  843 */       if (xt == null) throw new IllegalArgumentException(); 
/*  844 */       return xt.getTypeName();
/*  845 */     } catch (IllegalAnnotationsException e) {
/*      */       
/*  847 */       throw new AssertionError(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Binder<T> createBinder(Class<T> domType) {
/*  853 */     if (domType == Node.class) {
/*  854 */       return (Binder)createBinder();
/*      */     }
/*  856 */     return super.createBinder(domType);
/*      */   }
/*      */ 
/*      */   
/*      */   public Binder<Node> createBinder() {
/*  861 */     return new BinderImpl<>(this, (InfosetScanner<Node>)new DOMScanner());
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getElementName(Object o) throws JAXBException {
/*  866 */     JaxBeanInfo<Object> bi = getBeanInfo(o, true);
/*  867 */     if (!bi.isElement())
/*  868 */       return null; 
/*  869 */     return new QName(bi.getElementNamespaceURI(o), bi.getElementLocalName(o));
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getElementName(Class<?> o) throws JAXBException {
/*  874 */     JaxBeanInfo<?> bi = getBeanInfo(o, true);
/*  875 */     if (!bi.isElement())
/*  876 */       return null; 
/*  877 */     return new QName(bi.getElementNamespaceURI(o), bi.getElementLocalName(o));
/*      */   }
/*      */ 
/*      */   
/*      */   public Bridge createBridge(TypeReference ref) {
/*  882 */     return this.bridges.get(ref);
/*      */   }
/*      */ 
/*      */   
/*      */   public RawAccessor getElementPropertyAccessor(Class<?> wrapperBean, String nsUri, String localName) throws JAXBException {
/*  887 */     JaxBeanInfo<?> bi = getBeanInfo(wrapperBean, true);
/*  888 */     if (!(bi instanceof ClassBeanInfoImpl)) {
/*  889 */       throw new JAXBException("" + wrapperBean + " is not a bean");
/*      */     }
/*  891 */     for (ClassBeanInfoImpl cb = (ClassBeanInfoImpl)bi; cb != null; cb = cb.superClazz) {
/*  892 */       for (Property p : cb.properties) {
/*  893 */         final Accessor acc = p.getElementPropertyAccessor(nsUri, localName);
/*  894 */         if (acc != null)
/*  895 */           return new RawAccessor()
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Object get(Object bean) throws AccessorException
/*      */               {
/*  903 */                 return acc.getUnadapted(bean);
/*      */               }
/*      */ 
/*      */               
/*      */               public void set(Object bean, Object value) throws AccessorException {
/*  908 */                 acc.setUnadapted(bean, value);
/*      */               }
/*      */             }; 
/*      */       } 
/*      */     } 
/*  913 */     throw new JAXBException("" + new QName(nsUri, localName) + " is not a valid property on " + new QName(nsUri, localName));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> getKnownNamespaceURIs() {
/*  918 */     return Arrays.asList(this.nameList.namespaceURIs);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBuildId() {
/*  923 */     Package pkg = getClass().getPackage();
/*  924 */     if (pkg == null) return null; 
/*  925 */     return pkg.getImplementationVersion();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  930 */     StringBuilder buf = new StringBuilder(Which.which(getClass()) + " Build-Id: " + Which.which(getClass()));
/*  931 */     buf.append("\nClasses known to this context:\n");
/*      */     
/*  933 */     Set<String> names = new TreeSet<>();
/*      */     
/*  935 */     for (Class key : this.beanInfoMap.keySet()) {
/*  936 */       names.add(key.getName());
/*      */     }
/*  938 */     for (String name : names) {
/*  939 */       buf.append("  ").append(name).append('\n');
/*      */     }
/*  941 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getXMIMEContentType(Object o) {
/*  949 */     JaxBeanInfo bi = getBeanInfo(o);
/*  950 */     if (!(bi instanceof ClassBeanInfoImpl)) {
/*  951 */       return null;
/*      */     }
/*  953 */     ClassBeanInfoImpl cb = (ClassBeanInfoImpl)bi;
/*  954 */     for (Property p : cb.properties) {
/*  955 */       if (p instanceof AttributeProperty) {
/*  956 */         AttributeProperty ap = (AttributeProperty)p;
/*  957 */         if (ap.attName.equals("http://www.w3.org/2005/05/xmlmime", "contentType"))
/*      */           try {
/*  959 */             return (String)ap.xacc.print(o);
/*  960 */           } catch (AccessorException|ClassCastException|org.xml.sax.SAXException e) {
/*  961 */             return null;
/*      */           }  
/*      */       } 
/*      */     } 
/*  965 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JAXBContextImpl createAugmented(Class<?> clazz) throws JAXBException {
/*  972 */     Class[] newList = new Class[this.classes.length + 1];
/*  973 */     System.arraycopy(this.classes, 0, newList, 0, this.classes.length);
/*  974 */     newList[this.classes.length] = clazz;
/*      */     
/*  976 */     JAXBContextBuilder builder = new JAXBContextBuilder(this);
/*  977 */     builder.setClasses(newList);
/*  978 */     return builder.build();
/*      */   }
/*      */   
/*  981 */   private static final Comparator<QName> QNAME_COMPARATOR = new Comparator<QName>()
/*      */     {
/*      */       public int compare(QName lhs, QName rhs) {
/*  984 */         int r = lhs.getLocalPart().compareTo(rhs.getLocalPart());
/*  985 */         if (r != 0) return r;
/*      */         
/*  987 */         return lhs.getNamespaceURI().compareTo(rhs.getNamespaceURI());
/*      */       }
/*      */     };
/*      */   
/*      */   public static class JAXBContextBuilder
/*      */   {
/*      */     private boolean retainPropertyInfo = false;
/*      */     private boolean supressAccessorWarnings = false;
/*  995 */     private String defaultNsUri = ""; @NotNull
/*  996 */     private RuntimeAnnotationReader annotationReader = (RuntimeAnnotationReader)new RuntimeInlineAnnotationReader(); @NotNull
/*  997 */     private Map<Class, Class> subclassReplacements = Collections.emptyMap();
/*      */     private boolean c14nSupport = false;
/*      */     private Class[] classes;
/*      */     private Collection<TypeReference> typeRefs;
/*      */     private boolean xmlAccessorFactorySupport = false;
/*      */     private boolean allNillable;
/*      */     private boolean improvedXsiTypeHandling = true;
/*      */     private boolean disableSecurityProcessing = true;
/* 1005 */     private Boolean backupWithParentNamespace = null;
/*      */     private int maxErrorsCount;
/*      */     
/*      */     public JAXBContextBuilder() {}
/*      */     
/*      */     public JAXBContextBuilder(JAXBContextImpl baseImpl) {
/* 1011 */       this.supressAccessorWarnings = baseImpl.supressAccessorWarnings;
/* 1012 */       this.retainPropertyInfo = baseImpl.retainPropertyInfo;
/* 1013 */       this.defaultNsUri = baseImpl.defaultNsUri;
/* 1014 */       this.annotationReader = baseImpl.annotationReader;
/* 1015 */       this.subclassReplacements = baseImpl.subclassReplacements;
/* 1016 */       this.c14nSupport = baseImpl.c14nSupport;
/* 1017 */       this.classes = baseImpl.classes;
/* 1018 */       this.typeRefs = baseImpl.bridges.keySet();
/* 1019 */       this.xmlAccessorFactorySupport = baseImpl.xmlAccessorFactorySupport;
/* 1020 */       this.allNillable = baseImpl.allNillable;
/* 1021 */       this.disableSecurityProcessing = baseImpl.disableSecurityProcessing;
/* 1022 */       this.backupWithParentNamespace = baseImpl.backupWithParentNamespace;
/* 1023 */       this.maxErrorsCount = baseImpl.maxErrorsCount;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setRetainPropertyInfo(boolean val) {
/* 1027 */       this.retainPropertyInfo = val;
/* 1028 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setSupressAccessorWarnings(boolean val) {
/* 1032 */       this.supressAccessorWarnings = val;
/* 1033 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setC14NSupport(boolean val) {
/* 1037 */       this.c14nSupport = val;
/* 1038 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setXmlAccessorFactorySupport(boolean val) {
/* 1042 */       this.xmlAccessorFactorySupport = val;
/* 1043 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setDefaultNsUri(String val) {
/* 1047 */       this.defaultNsUri = val;
/* 1048 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setAllNillable(boolean val) {
/* 1052 */       this.allNillable = val;
/* 1053 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setClasses(Class[] val) {
/* 1057 */       this.classes = val;
/* 1058 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setAnnotationReader(RuntimeAnnotationReader val) {
/* 1062 */       this.annotationReader = val;
/* 1063 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setSubclassReplacements(Map<Class<?>, Class<?>> val) {
/* 1067 */       this.subclassReplacements = val;
/* 1068 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setTypeRefs(Collection<TypeReference> val) {
/* 1072 */       this.typeRefs = val;
/* 1073 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setImprovedXsiTypeHandling(boolean val) {
/* 1077 */       this.improvedXsiTypeHandling = val;
/* 1078 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setDisableSecurityProcessing(boolean val) {
/* 1082 */       this.disableSecurityProcessing = val;
/* 1083 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setBackupWithParentNamespace(Boolean backupWithParentNamespace) {
/* 1087 */       this.backupWithParentNamespace = backupWithParentNamespace;
/* 1088 */       return this;
/*      */     }
/*      */     
/*      */     public JAXBContextBuilder setMaxErrorsCount(int maxErrorsCount) {
/* 1092 */       this.maxErrorsCount = maxErrorsCount;
/* 1093 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public JAXBContextImpl build() throws JAXBException {
/* 1099 */       if (this.defaultNsUri == null) {
/* 1100 */         this.defaultNsUri = "";
/*      */       }
/*      */       
/* 1103 */       if (this.subclassReplacements == null) {
/* 1104 */         this.subclassReplacements = Collections.emptyMap();
/*      */       }
/*      */       
/* 1107 */       if (this.annotationReader == null) {
/* 1108 */         this.annotationReader = (RuntimeAnnotationReader)new RuntimeInlineAnnotationReader();
/*      */       }
/*      */       
/* 1111 */       if (this.typeRefs == null) {
/* 1112 */         this.typeRefs = Collections.emptyList();
/*      */       }
/*      */       
/* 1115 */       return new JAXBContextImpl(this);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\JAXBContextImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */