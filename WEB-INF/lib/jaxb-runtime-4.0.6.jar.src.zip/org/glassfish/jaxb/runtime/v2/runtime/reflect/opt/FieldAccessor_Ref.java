/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldAccessor_Ref<B>
/*    */   extends Accessor<B, Ref>
/*    */ {
/*    */   public FieldAccessor_Ref() {
/* 22 */     super(Ref.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Ref get(B bean) {
/* 27 */     return ((Bean)bean).f_ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Ref value) {
/* 32 */     ((Bean)bean).f_ref = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\FieldAccessor_Ref.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */