/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArrayElementLeafProperty<BeanT, ListT, ItemT>
/*    */   extends ArrayElementProperty<BeanT, ListT, ItemT>
/*    */ {
/*    */   private final Transducer<ItemT> xducer;
/*    */   
/*    */   public ArrayElementLeafProperty(JAXBContextImpl p, RuntimeElementPropertyInfo prop) {
/* 38 */     super(p, prop);
/*    */ 
/*    */     
/* 41 */     assert prop.getTypes().size() == 1;
/*    */ 
/*    */     
/* 44 */     this.xducer = ((RuntimeTypeRef)prop.getTypes().get(0)).getTransducer();
/* 45 */     assert this.xducer != null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void serializeItem(JaxBeanInfo bi, ItemT item, XMLSerializer w) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 50 */     this.xducer.declareNamespace(item, w);
/* 51 */     w.endNamespaceDecls(item);
/* 52 */     w.endAttributes();
/*    */ 
/*    */     
/* 55 */     this.xducer.writeText(w, item, this.fieldName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayElementLeafProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */