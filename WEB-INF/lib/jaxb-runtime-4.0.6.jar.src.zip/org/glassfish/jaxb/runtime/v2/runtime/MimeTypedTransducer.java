/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import jakarta.activation.MimeType;
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MimeTypedTransducer<V>
/*    */   extends FilterTransducer<V>
/*    */ {
/*    */   private final MimeType expectedMimeType;
/*    */   
/*    */   public MimeTypedTransducer(Transducer<V> core, MimeType expectedMimeType) {
/* 35 */     super(core);
/* 36 */     this.expectedMimeType = expectedMimeType;
/*    */   }
/*    */ 
/*    */   
/*    */   public CharSequence print(V o) throws AccessorException {
/* 41 */     XMLSerializer w = XMLSerializer.getInstance();
/* 42 */     MimeType old = w.setExpectedMimeType(this.expectedMimeType);
/*    */     try {
/* 44 */       return this.core.print(o);
/*    */     } finally {
/* 46 */       w.setExpectedMimeType(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeText(XMLSerializer w, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 52 */     MimeType old = w.setExpectedMimeType(this.expectedMimeType);
/*    */     try {
/* 54 */       this.core.writeText(w, o, fieldName);
/*    */     } finally {
/* 56 */       w.setExpectedMimeType(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeLeafElement(XMLSerializer w, Name tagName, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 62 */     MimeType old = w.setExpectedMimeType(this.expectedMimeType);
/*    */     try {
/* 64 */       this.core.writeLeafElement(w, tagName, o, fieldName);
/*    */     } finally {
/* 66 */       w.setExpectedMimeType(old);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\MimeTypedTransducer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */