/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullSafeAccessor<B, V, P>
/*    */   extends Accessor<B, V>
/*    */ {
/*    */   private final Accessor<B, V> core;
/*    */   private final Lister<B, V, ?, P> lister;
/*    */   
/*    */   public NullSafeAccessor(Accessor<B, V> core, Lister<B, V, ?, P> lister) {
/* 29 */     super(core.getValueType());
/* 30 */     this.core = core;
/* 31 */     this.lister = lister;
/*    */   }
/*    */ 
/*    */   
/*    */   public V get(B bean) throws AccessorException {
/* 36 */     V v = this.core.get(bean);
/* 37 */     if (v == null) {
/*    */       
/* 39 */       P pack = this.lister.startPacking(bean, this.core);
/* 40 */       this.lister.endPacking(pack, bean, this.core);
/* 41 */       v = this.core.get(bean);
/*    */     } 
/* 43 */     return v;
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, V value) throws AccessorException {
/* 48 */     this.core.set(bean, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\NullSafeAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */