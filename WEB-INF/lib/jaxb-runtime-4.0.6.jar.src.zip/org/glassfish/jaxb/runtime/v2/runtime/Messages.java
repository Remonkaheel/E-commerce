/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum Messages
/*    */ {
/* 20 */   ILLEGAL_PARAMETER,
/* 21 */   UNABLE_TO_FIND_CONVERSION_METHOD,
/* 22 */   MISSING_ID,
/* 23 */   UNRECOGNIZED_ELEMENT_NAME,
/* 24 */   TYPE_MISMATCH,
/* 25 */   MISSING_OBJECT,
/* 26 */   NOT_IDENTIFIABLE,
/* 27 */   DANGLING_IDREF,
/* 28 */   NULL_OUTPUT_RESOLVER,
/* 29 */   UNABLE_TO_MARSHAL_NON_ELEMENT,
/* 30 */   UNABLE_TO_MARSHAL_UNBOUND_CLASS,
/* 31 */   UNSUPPORTED_PROPERTY,
/* 32 */   NULL_PROPERTY_NAME,
/* 33 */   MUST_BE_X,
/* 34 */   NOT_MARSHALLABLE,
/* 35 */   UNSUPPORTED_RESULT,
/* 36 */   UNSUPPORTED_ENCODING,
/* 37 */   SUBSTITUTED_BY_ANONYMOUS_TYPE,
/* 38 */   CYCLE_IN_MARSHALLER,
/* 39 */   UNABLE_TO_DISCOVER_EVENTHANDLER,
/* 40 */   ELEMENT_NEEDED_BUT_FOUND_DOCUMENT,
/* 41 */   UNKNOWN_CLASS,
/* 42 */   FAILED_TO_GENERATE_SCHEMA,
/* 43 */   ERROR_PROCESSING_SCHEMA,
/* 44 */   ILLEGAL_CONTENT;
/*    */   
/*    */   static {
/* 47 */     rb = ResourceBundle.getBundle(Messages.class.getName());
/*    */   }
/*    */   private static final ResourceBundle rb;
/*    */   public String toString() {
/* 51 */     return format(new Object[0]);
/*    */   }
/*    */   
/*    */   public String format(Object... args) {
/* 55 */     return MessageFormat.format(rb.getString(name()), args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */