/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerLong<BeanT>
/*    */   extends Lister<BeanT, long[], Long, PrimitiveArrayListerLong.LongArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     Lister.primitiveArrayListers.put(long.class, new PrimitiveArrayListerLong());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Long> iterator(final long[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Long>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Long next() {
/* 47 */           return Long.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public LongArrayPack startPacking(BeanT current, Accessor<BeanT, long[]> acc) {
/* 54 */     return new LongArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(LongArrayPack objects, Long o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(LongArrayPack pack, BeanT bean, Accessor<BeanT, long[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, long[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new long[0]);
/*    */   }
/*    */   
/*    */   static final class LongArrayPack {
/* 73 */     long[] buf = new long[16];
/*    */     int size;
/*    */     
/*    */     void add(Long b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         long[] nb = new long[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.longValue(); 
/*    */     }
/*    */     
/*    */     long[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       long[] r = new long[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerLong.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */