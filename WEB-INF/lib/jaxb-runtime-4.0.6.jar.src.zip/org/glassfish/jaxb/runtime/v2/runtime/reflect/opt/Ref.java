package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;

final class Ref {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\Ref.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */