/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeMapPropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuntimeMapPropertyInfoImpl
/*    */   extends MapPropertyInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeMapPropertyInfo
/*    */ {
/*    */   private final Accessor acc;
/*    */   
/*    */   RuntimeMapPropertyInfoImpl(RuntimeClassInfoImpl classInfo, PropertySeed<Type, Class<?>, Field, Method> seed) {
/* 30 */     super(classInfo, seed);
/* 31 */     this.acc = ((RuntimeClassInfoImpl.RuntimePropertySeed)seed).getAccessor();
/*    */   }
/*    */ 
/*    */   
/*    */   public Accessor getAccessor() {
/* 36 */     return this.acc;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean elementOnlyContent() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getKeyType() {
/* 46 */     return (RuntimeNonElement)super.getKeyType();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getValueType() {
/* 51 */     return (RuntimeNonElement)super.getValueType();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<? extends RuntimeTypeInfo> ref() {
/* 57 */     return (List)super.ref();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeMapPropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */