/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.DomHandler;
/*    */ import javax.xml.transform.Result;
/*    */ import org.glassfish.jaxb.core.v2.model.core.WildcardMode;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WildcardLoader
/*    */   extends ProxyLoader
/*    */ {
/*    */   private final DomLoader dom;
/*    */   private final WildcardMode mode;
/*    */   
/*    */   public WildcardLoader(DomHandler<?, Result> dom, WildcardMode mode) {
/* 35 */     this.dom = new DomLoader<>(dom);
/* 36 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Loader selectLoader(UnmarshallingContext.State state, TagName tag) throws SAXException {
/* 41 */     UnmarshallingContext context = state.getContext();
/*    */     
/* 43 */     if (this.mode.allowTypedObject) {
/* 44 */       Loader l = context.selectRootLoader(state, tag);
/* 45 */       if (l != null)
/* 46 */         return l; 
/*    */     } 
/* 48 */     if (this.mode.allowDom) {
/* 49 */       return this.dom;
/*    */     }
/*    */     
/* 52 */     return Discarder.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\WildcardLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */