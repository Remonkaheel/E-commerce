/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InterningXmlVisitor
/*     */   implements XmlVisitor
/*     */ {
/*     */   private final XmlVisitor next;
/*  27 */   private final AttributesImpl attributes = new AttributesImpl();
/*     */   
/*     */   public InterningXmlVisitor(XmlVisitor next) {
/*  30 */     this.next = next;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument(LocatorEx locator, NamespaceContext nsContext) throws SAXException {
/*  35 */     this.next.startDocument(locator, nsContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {
/*  40 */     this.next.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(TagName tagName) throws SAXException {
/*  45 */     this.attributes.setAttributes(tagName.atts);
/*  46 */     tagName.atts = this.attributes;
/*  47 */     tagName.uri = intern(tagName.uri);
/*  48 */     tagName.local = intern(tagName.local);
/*  49 */     this.next.startElement(tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(TagName tagName) throws SAXException {
/*  54 */     tagName.uri = intern(tagName.uri);
/*  55 */     tagName.local = intern(tagName.local);
/*  56 */     this.next.endElement(tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String nsUri) throws SAXException {
/*  61 */     this.next.startPrefixMapping(intern(prefix), intern(nsUri));
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/*  66 */     this.next.endPrefixMapping(intern(prefix));
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(CharSequence pcdata) throws SAXException {
/*  71 */     this.next.text(pcdata);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnmarshallingContext getContext() {
/*  76 */     return this.next.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlVisitor.TextPredictor getPredictor() {
/*  81 */     return this.next.getPredictor();
/*     */   }
/*     */   
/*     */   private static class AttributesImpl implements Attributes {
/*     */     private Attributes core;
/*     */     
/*     */     void setAttributes(Attributes att) {
/*  88 */       this.core = att;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIndex(String qName) {
/*  93 */       return this.core.getIndex(qName);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIndex(String uri, String localName) {
/*  98 */       return this.core.getIndex(uri, localName);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLength() {
/* 103 */       return this.core.getLength();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocalName(int index) {
/* 108 */       return InterningXmlVisitor.intern(this.core.getLocalName(index));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getQName(int index) {
/* 113 */       return InterningXmlVisitor.intern(this.core.getQName(index));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getType(int index) {
/* 118 */       return InterningXmlVisitor.intern(this.core.getType(index));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getType(String qName) {
/* 123 */       return InterningXmlVisitor.intern(this.core.getType(qName));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getType(String uri, String localName) {
/* 128 */       return InterningXmlVisitor.intern(this.core.getType(uri, localName));
/*     */     }
/*     */ 
/*     */     
/*     */     public String getURI(int index) {
/* 133 */       return InterningXmlVisitor.intern(this.core.getURI(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue(int index) {
/* 143 */       return this.core.getValue(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue(String qName) {
/* 148 */       return this.core.getValue(qName);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue(String uri, String localName) {
/* 153 */       return this.core.getValue(uri, localName);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String intern(String s) {
/* 158 */     if (s == null) return null; 
/* 159 */     return s.intern();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\InterningXmlVisitor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */