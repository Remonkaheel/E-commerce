package org.glassfish.jaxb.runtime.v2.util;

public class StackRecorder extends Throwable {
  private static final long serialVersionUID = 1296878485146023581L;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\StackRecorder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */