/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*    */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StructureLoaderBuilder
/*    */ {
/* 49 */   public static final QName TEXT_HANDLER = new QName("\000", "text");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public static final QName CATCH_ALL = new QName("\000", "catchAll");
/*    */   
/*    */   void buildChildElementUnmarshallers(UnmarshallerChain paramUnmarshallerChain, QNameMap<ChildLoader> paramQNameMap);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\StructureLoaderBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */