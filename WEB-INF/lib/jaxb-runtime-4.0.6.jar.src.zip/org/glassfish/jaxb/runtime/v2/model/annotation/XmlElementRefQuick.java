/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementRef;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementRefQuick
/*    */   extends Quick
/*    */   implements XmlElementRef
/*    */ {
/*    */   private final XmlElementRef core;
/*    */   
/*    */   public XmlElementRefQuick(Locatable upstream, XmlElementRef core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlElementRefQuick(upstream, (XmlElementRef)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElementRef> annotationType() {
/* 47 */     return XmlElementRef.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 52 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 57 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean required() {
/* 62 */     return this.core.required();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class type() {
/* 67 */     return this.core.type();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementRefQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */