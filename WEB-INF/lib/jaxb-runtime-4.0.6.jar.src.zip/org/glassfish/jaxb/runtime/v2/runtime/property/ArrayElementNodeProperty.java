/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArrayElementNodeProperty<BeanT, ListT, ItemT>
/*    */   extends ArrayElementProperty<BeanT, ListT, ItemT>
/*    */ {
/*    */   public ArrayElementNodeProperty(JAXBContextImpl p, RuntimeElementPropertyInfo prop) {
/* 30 */     super(p, prop);
/*    */   }
/*    */ 
/*    */   
/*    */   public void serializeItem(JaxBeanInfo expected, ItemT item, XMLSerializer w) throws SAXException, IOException, XMLStreamException {
/* 35 */     if (item == null) {
/* 36 */       w.writeXsiNilTrue();
/*    */     } else {
/* 38 */       w.childAsXsiType(item, this.fieldName, expected, false);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayElementNodeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */