/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeValuePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ValuePropertyLoader;
/*    */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ValueProperty<BeanT>
/*    */   extends PropertyImpl<BeanT>
/*    */ {
/*    */   private final TransducedAccessor<BeanT> xacc;
/*    */   private final Accessor<BeanT, ?> acc;
/*    */   
/*    */   public ValueProperty(JAXBContextImpl context, RuntimeValuePropertyInfo prop) {
/* 48 */     super(context, (RuntimePropertyInfo)prop);
/* 49 */     this.xacc = TransducedAccessor.get(context, (RuntimeNonElementRef)prop);
/* 50 */     this.acc = prop.getAccessor();
/*    */   }
/*    */ 
/*    */   
/*    */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 55 */     if (this.xacc.hasValue(o)) {
/* 56 */       this.xacc.writeText(w, o, this.fieldName);
/*    */     }
/*    */   }
/*    */   
/*    */   public void serializeURIs(BeanT o, XMLSerializer w) throws SAXException, AccessorException {
/* 61 */     this.xacc.declareNamespace(o, w);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasSerializeURIAction() {
/* 66 */     return this.xacc.useNamespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public void buildChildElementUnmarshallers(UnmarshallerChain chainElem, QNameMap<ChildLoader> handlers) {
/* 71 */     handlers.put(TEXT_HANDLER, new ChildLoader((Loader)new ValuePropertyLoader(this.xacc), null));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PropertyKind getKind() {
/* 77 */     return PropertyKind.VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o) throws AccessorException {
/* 82 */     this.acc.set(o, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getIdValue(BeanT bean) throws AccessorException, SAXException {
/* 87 */     return this.xacc.print(bean).toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ValueProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */