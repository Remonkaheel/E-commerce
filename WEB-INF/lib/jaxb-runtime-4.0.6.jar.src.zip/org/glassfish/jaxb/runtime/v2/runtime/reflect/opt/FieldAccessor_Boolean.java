/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldAccessor_Boolean<B>
/*    */   extends Accessor<B, Boolean>
/*    */ {
/*    */   public FieldAccessor_Boolean() {
/* 27 */     super(Boolean.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean get(B bean) {
/* 32 */     return Boolean.valueOf(((Bean)bean).f_boolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Boolean value) {
/* 37 */     ((Bean)bean).f_boolean = (value == null) ? false : value.booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\FieldAccessor_Boolean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */