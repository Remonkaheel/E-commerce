/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.DefaultValueLoaderDecorator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.LeafPropertyLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.LeafPropertyXsiLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiNilLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleElementLeafProperty<BeanT>
/*     */   extends PropertyImpl<BeanT>
/*     */ {
/*     */   private final Name tagName;
/*     */   private final boolean nillable;
/*     */   private final Accessor acc;
/*     */   private final String defaultValue;
/*     */   private final TransducedAccessor<BeanT> xacc;
/*     */   private final boolean improvedXsiTypeHandling;
/*     */   private final boolean idRef;
/*     */   
/*     */   public SingleElementLeafProperty(JAXBContextImpl context, RuntimeElementPropertyInfo prop) {
/*  48 */     super(context, (RuntimePropertyInfo)prop);
/*  49 */     RuntimeTypeRef ref = prop.getTypes().get(0);
/*  50 */     this.tagName = context.nameBuilder.createElementName(ref.getTagName());
/*  51 */     assert this.tagName != null;
/*  52 */     this.nillable = ref.isNillable();
/*  53 */     this.defaultValue = ref.getDefaultValue();
/*  54 */     this.acc = prop.getAccessor().optimize(context);
/*     */     
/*  56 */     this.xacc = TransducedAccessor.get(context, (RuntimeNonElementRef)ref);
/*  57 */     assert this.xacc != null;
/*     */     
/*  59 */     this.improvedXsiTypeHandling = context.improvedXsiTypeHandling;
/*  60 */     this.idRef = (ref.getSource().id() == ID.IDREF);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(BeanT o) throws AccessorException {
/*  65 */     this.acc.set(o, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdValue(BeanT bean) throws AccessorException, SAXException {
/*  70 */     return this.xacc.print(bean).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/*  75 */     boolean hasValue = this.xacc.hasValue(o);
/*     */     
/*  77 */     Object obj = null;
/*     */     
/*     */     try {
/*  80 */       obj = this.acc.getUnadapted(o);
/*  81 */     } catch (AccessorException accessorException) {}
/*     */ 
/*     */ 
/*     */     
/*  85 */     Class valueType = this.acc.getValueType();
/*     */ 
/*     */     
/*  88 */     if (xsiTypeNeeded(o, w, obj, valueType)) {
/*  89 */       w.startElement(this.tagName, outerPeer);
/*  90 */       w.childAsXsiType(obj, this.fieldName, w.grammar.getBeanInfo(valueType), false);
/*  91 */       w.endElement();
/*     */     }
/*  93 */     else if (hasValue) {
/*  94 */       this.xacc.writeLeafElement(w, this.tagName, o, this.fieldName);
/*  95 */     } else if (this.nillable) {
/*  96 */       w.startElement(this.tagName, null);
/*  97 */       w.writeXsiNilTrue();
/*  98 */       w.endElement();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean xsiTypeNeeded(BeanT bean, XMLSerializer w, Object value, Class valueTypeClass) {
/* 107 */     if (!this.improvedXsiTypeHandling)
/* 108 */       return false; 
/* 109 */     if (this.acc.isAdapted())
/* 110 */       return false; 
/* 111 */     if (value == null)
/* 112 */       return false; 
/* 113 */     if (value.getClass().equals(valueTypeClass))
/* 114 */       return false; 
/* 115 */     if (this.idRef)
/* 116 */       return false; 
/* 117 */     if (valueTypeClass.isPrimitive())
/* 118 */       return false; 
/* 119 */     return (this.acc.isValueTypeAbstractable() || isNillableAbstract(bean, w.grammar, value, valueTypeClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isNillableAbstract(BeanT bean, JAXBContextImpl context, Object value, Class<Object> valueTypeClass) {
/* 126 */     if (!this.nillable)
/* 127 */       return false; 
/* 128 */     if (valueTypeClass != Object.class)
/* 129 */       return false; 
/* 130 */     if (bean.getClass() != JAXBElement.class)
/* 131 */       return false; 
/* 132 */     JAXBElement jaxbElement = (JAXBElement)bean;
/* 133 */     Class<?> valueClass = value.getClass();
/* 134 */     Class declaredTypeClass = jaxbElement.getDeclaredType();
/* 135 */     if (declaredTypeClass.equals(valueClass))
/* 136 */       return false; 
/* 137 */     if (!declaredTypeClass.isAssignableFrom(valueClass))
/* 138 */       return false; 
/* 139 */     if (!Modifier.isAbstract(declaredTypeClass.getModifiers()))
/* 140 */       return false; 
/* 141 */     return this.acc.isAbstractable(declaredTypeClass);
/*     */   } public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) {
/*     */     DefaultValueLoaderDecorator defaultValueLoaderDecorator;
/*     */     XsiNilLoader.Single single;
/*     */     LeafPropertyXsiLoader leafPropertyXsiLoader;
/* 146 */     LeafPropertyLoader leafPropertyLoader = new LeafPropertyLoader(this.xacc);
/* 147 */     if (this.defaultValue != null)
/* 148 */       defaultValueLoaderDecorator = new DefaultValueLoaderDecorator((Loader)leafPropertyLoader, this.defaultValue); 
/* 149 */     if (this.nillable || chain.context.allNillable) {
/* 150 */       single = new XsiNilLoader.Single((Loader)defaultValueLoaderDecorator, this.acc);
/*     */     }
/*     */     
/* 153 */     if (this.improvedXsiTypeHandling) {
/* 154 */       leafPropertyXsiLoader = new LeafPropertyXsiLoader((Loader)single, this.xacc, this.acc);
/*     */     }
/* 156 */     handlers.put(this.tagName, new ChildLoader((Loader)leafPropertyXsiLoader, null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/* 162 */     return PropertyKind.ELEMENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 167 */     if (this.tagName.equals(nsUri, localName)) {
/* 168 */       return this.acc;
/*     */     }
/* 170 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\SingleElementLeafProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */