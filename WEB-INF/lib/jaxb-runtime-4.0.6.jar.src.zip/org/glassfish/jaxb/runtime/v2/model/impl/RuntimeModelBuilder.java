/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import com.sun.istack.Nullable;
/*     */ import jakarta.activation.MimeType;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ArrayInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.EnumLeafInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.RegistryInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.annotation.RuntimeAnnotationReader;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfoSet;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.FilterTransducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.InlineBinaryTransducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.MimeTypedTransducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.SchemaTypeTransducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeModelBuilder
/*     */   extends ModelBuilder<Type, Class, Field, Method>
/*     */ {
/*     */   @Nullable
/*     */   public final JAXBContextImpl context;
/*     */   
/*     */   public RuntimeModelBuilder(JAXBContextImpl context, RuntimeAnnotationReader annotationReader, Map<Class<?>, Class<?>> subclassReplacements, String defaultNamespaceRemap) {
/*  61 */     super((AnnotationReader<Type, Class, Field, Method>)annotationReader, Utils.REFLECTION_NAVIGATOR, subclassReplacements, defaultNamespaceRemap);
/*  62 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeNonElement getClassInfo(Class clazz, Locatable upstream) {
/*  67 */     return (RuntimeNonElement)super.getClassInfo(clazz, upstream);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeNonElement getClassInfo(Class clazz, boolean searchForSuperClass, Locatable upstream) {
/*  72 */     return (RuntimeNonElement)super.getClassInfo(clazz, searchForSuperClass, upstream);
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumLeafInfo<Type, Class> createEnumLeafInfo(Class<Enum> clazz, Locatable upstream) {
/*  77 */     return new RuntimeEnumLeafInfoImpl<>(this, upstream, clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClassInfo<Type, Class> createClassInfo(Class clazz, Locatable upstream) {
/*  82 */     return new RuntimeClassInfoImpl(this, upstream, clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementInfo<Type, Class> createElementInfo(RegistryInfo<Type, Class<?>> registryInfo, Method method) throws IllegalAnnotationException {
/*  87 */     return new RuntimeElementInfoImpl(this, registryInfo, method);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayInfo<Type, Class> createArrayInfo(Locatable upstream, Type arrayType) {
/*  92 */     return new RuntimeArrayInfoImpl(this, upstream, (Class)arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeInfoSet<Type, Class, Field, Method> createTypeInfoSet() {
/*  97 */     return new RuntimeTypeInfoSetImpl(this.reader);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeTypeInfoSet link() {
/* 102 */     return (RuntimeTypeInfoSet)super.link();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <V> Transducer<V> createTransducer(RuntimeNonElementRef ref) {
/*     */     IDTransducerImpl<V> iDTransducerImpl;
/*     */     MimeTypedTransducer mimeTypedTransducer;
/*     */     InlineBinaryTransducer inlineBinaryTransducer;
/*     */     SchemaTypeTransducer schemaTypeTransducer;
/* 115 */     Transducer<V> t = ref.getTarget().getTransducer();
/* 116 */     RuntimePropertyInfo src = ref.getSource();
/* 117 */     ID id = src.id();
/*     */     
/* 119 */     if (id == ID.IDREF) {
/* 120 */       return (Transducer)RuntimeBuiltinLeafInfoImpl.STRING;
/*     */     }
/* 122 */     if (id == ID.ID) {
/* 123 */       iDTransducerImpl = new IDTransducerImpl<>(t);
/*     */     }
/* 125 */     MimeType emt = src.getExpectedMimeType();
/* 126 */     if (emt != null) {
/* 127 */       mimeTypedTransducer = new MimeTypedTransducer((Transducer)iDTransducerImpl, emt);
/*     */     }
/* 129 */     if (src.inlineBinaryData()) {
/* 130 */       inlineBinaryTransducer = new InlineBinaryTransducer((Transducer)mimeTypedTransducer);
/*     */     }
/* 132 */     if (src.getSchemaType() != null) {
/* 133 */       if (src.getSchemaType().equals(createXSSimpleType())) {
/* 134 */         return (Transducer)RuntimeBuiltinLeafInfoImpl.STRING;
/*     */       }
/* 136 */       schemaTypeTransducer = new SchemaTypeTransducer((Transducer)inlineBinaryTransducer, src.getSchemaType());
/*     */     } 
/*     */     
/* 139 */     return (Transducer<V>)schemaTypeTransducer;
/*     */   }
/*     */   
/*     */   private static QName createXSSimpleType() {
/* 143 */     return new QName("http://www.w3.org/2001/XMLSchema", "anySimpleType");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class IDTransducerImpl<ValueT>
/*     */     extends FilterTransducer<ValueT>
/*     */   {
/*     */     public IDTransducerImpl(Transducer<ValueT> core) {
/* 154 */       super(core);
/*     */     }
/*     */ 
/*     */     
/*     */     public ValueT parse(CharSequence lexical) throws AccessorException, SAXException {
/* 159 */       String value = WhiteSpaceProcessor.trim(lexical).toString();
/* 160 */       UnmarshallingContext.getInstance().addToIdTable(value);
/* 161 */       return (ValueT)this.core.parse(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeModelBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */