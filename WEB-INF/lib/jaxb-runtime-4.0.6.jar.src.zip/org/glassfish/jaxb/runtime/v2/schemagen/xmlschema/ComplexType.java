package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;

@XmlElement("complexType")
public interface ComplexType extends TypedXmlWriter, Annotated, ComplexTypeModel {
  @XmlAttribute("final")
  ComplexType _final(String paramString);
  
  @XmlAttribute("final")
  ComplexType _final(String[] paramArrayOfString);
  
  @XmlAttribute
  ComplexType block(String paramString);
  
  @XmlAttribute
  ComplexType block(String[] paramArrayOfString);
  
  @XmlAttribute("abstract")
  ComplexType _abstract(boolean paramBoolean);
  
  @XmlAttribute
  ComplexType name(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\ComplexType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */