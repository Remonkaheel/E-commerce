/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DefaultTransducedAccessor<T>
/*    */   extends TransducedAccessor<T>
/*    */ {
/*    */   public void writeLeafElement(XMLSerializer w, Name tagName, T o, String fieldName) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 44 */     w.leafElement(tagName, print(o), fieldName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeText(XMLSerializer w, T o, String fieldName) throws AccessorException, SAXException, IOException, XMLStreamException {
/* 49 */     w.text(print(o), fieldName);
/*    */   }
/*    */   
/*    */   public abstract String print(T paramT) throws AccessorException, SAXException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\DefaultTransducedAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */