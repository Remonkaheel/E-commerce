/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import jakarta.activation.MimeType;
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.XmlAttachmentRef;
/*     */ import jakarta.xml.bind.annotation.XmlElementDecl;
/*     */ import jakarta.xml.bind.annotation.XmlID;
/*     */ import jakarta.xml.bind.annotation.XmlIDREF;
/*     */ import jakarta.xml.bind.annotation.XmlInlineBinaryData;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.TODO;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationSource;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeRef;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.SwaRefAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElementInfoImpl<T, C, F, M>
/*     */   extends TypeInfoImpl<T, C, F, M>
/*     */   implements ElementInfo<T, C>
/*     */ {
/*     */   private final QName tagName;
/*     */   private final NonElement<T, C> contentType;
/*     */   private final T tOfJAXBElementT;
/*     */   private final T elementType;
/*     */   private final ClassInfo<T, C> scope;
/*     */   private final XmlElementDecl anno;
/*     */   private ElementInfoImpl<T, C, F, M> substitutionHead;
/*     */   private FinalArrayList<ElementInfoImpl<T, C, F, M>> substitutionMembers;
/*     */   private final M method;
/*     */   private final Adapter<T, C> adapter;
/*     */   private final boolean isCollection;
/*     */   private final ID id;
/*     */   private final PropertyImpl property;
/*     */   private final MimeType expectedMimeType;
/*     */   private final boolean inlineBinary;
/*     */   private final QName schemaType;
/*     */   
/*     */   protected class PropertyImpl
/*     */     implements ElementPropertyInfo<T, C>, TypeRef<T, C>, AnnotationSource
/*     */   {
/*     */     public NonElement<T, C> getTarget() {
/*  98 */       return ElementInfoImpl.this.contentType;
/*     */     }
/*     */     
/*     */     public QName getTagName() {
/* 102 */       return ElementInfoImpl.this.tagName;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<? extends TypeRef<T, C>> getTypes() {
/* 107 */       return Collections.singletonList(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<? extends NonElement<T, C>> ref() {
/* 112 */       return Collections.singletonList(ElementInfoImpl.this.contentType);
/*     */     }
/*     */ 
/*     */     
/*     */     public QName getXmlName() {
/* 117 */       return ElementInfoImpl.this.tagName;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCollectionRequired() {
/* 122 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCollectionNillable() {
/* 127 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNillable() {
/* 132 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDefaultValue() {
/* 137 */       String v = ElementInfoImpl.this.anno.defaultValue();
/* 138 */       if (v.equals("\000")) {
/* 139 */         return null;
/*     */       }
/* 141 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public ElementInfoImpl<T, C, F, M> parent() {
/* 146 */       return ElementInfoImpl.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 151 */       return "value";
/*     */     }
/*     */ 
/*     */     
/*     */     public String displayName() {
/* 156 */       return "JAXBElement#value";
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCollection() {
/* 161 */       return ElementInfoImpl.this.isCollection;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isValueList() {
/* 169 */       return ElementInfoImpl.this.isCollection;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRequired() {
/* 174 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public PropertyKind kind() {
/* 179 */       return PropertyKind.ELEMENT;
/*     */     }
/*     */ 
/*     */     
/*     */     public Adapter<T, C> getAdapter() {
/* 184 */       return ElementInfoImpl.this.adapter;
/*     */     }
/*     */ 
/*     */     
/*     */     public ID id() {
/* 189 */       return ElementInfoImpl.this.id;
/*     */     }
/*     */ 
/*     */     
/*     */     public MimeType getExpectedMimeType() {
/* 194 */       return ElementInfoImpl.this.expectedMimeType;
/*     */     }
/*     */ 
/*     */     
/*     */     public QName getSchemaType() {
/* 199 */       return ElementInfoImpl.this.schemaType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean inlineBinaryData() {
/* 204 */       return ElementInfoImpl.this.inlineBinary;
/*     */     }
/*     */ 
/*     */     
/*     */     public PropertyInfo<T, C> getSource() {
/* 209 */       return (PropertyInfo<T, C>)this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <A extends Annotation> A readAnnotation(Class<A> annotationType) {
/* 219 */       return (A)ElementInfoImpl.this.reader().getMethodAnnotation(annotationType, ElementInfoImpl.this.method, ElementInfoImpl.this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasAnnotation(Class<? extends Annotation> annotationType) {
/* 224 */       return ElementInfoImpl.this.reader().hasMethodAnnotation(annotationType, ElementInfoImpl.this.method);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementInfoImpl(ModelBuilder<T, C, F, M> builder, RegistryInfoImpl<T, C, F, M> registry, M m) throws IllegalAnnotationException {
/* 234 */     super(builder, registry);
/*     */     
/* 236 */     this.method = m;
/* 237 */     this.anno = (XmlElementDecl)reader().getMethodAnnotation(XmlElementDecl.class, m, this);
/* 238 */     assert this.anno != null;
/* 239 */     assert this.anno instanceof org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */     
/* 241 */     this.elementType = (T)nav().getReturnType(m);
/* 242 */     T baseClass = (T)nav().getBaseClass(this.elementType, nav().asDecl(JAXBElement.class));
/* 243 */     if (baseClass == null) {
/* 244 */       throw new IllegalAnnotationException(Messages.XML_ELEMENT_MAPPING_ON_NON_IXMLELEMENT_METHOD
/* 245 */           .format(new Object[] { nav().getMethodName(m) }, ), this.anno);
/*     */     }
/*     */     
/* 248 */     this.tagName = parseElementName(this.anno);
/* 249 */     T[] methodParams = (T[])nav().getMethodParameters(m);
/*     */ 
/*     */     
/* 252 */     Adapter<T, C> a = null;
/* 253 */     if (methodParams.length > 0) {
/* 254 */       XmlJavaTypeAdapter adapter = (XmlJavaTypeAdapter)reader().getMethodAnnotation(XmlJavaTypeAdapter.class, m, this);
/* 255 */       if (adapter != null) {
/* 256 */         a = new Adapter(adapter, reader(), nav());
/*     */       } else {
/* 258 */         XmlAttachmentRef xsa = (XmlAttachmentRef)reader().getMethodAnnotation(XmlAttachmentRef.class, m, this);
/* 259 */         if (xsa != null) {
/* 260 */           TODO.prototype("in Annotation Processing swaRefAdapter isn't avaialble, so this returns null");
/* 261 */           a = new Adapter(this.owner.nav.asDecl(SwaRefAdapter.class), this.owner.nav);
/*     */         } 
/*     */       } 
/*     */     } 
/* 265 */     this.adapter = a;
/*     */ 
/*     */     
/* 268 */     this
/*     */       
/* 270 */       .tOfJAXBElementT = (methodParams.length > 0) ? methodParams[0] : (T)nav().getTypeArgument(baseClass, 0);
/*     */     
/* 272 */     if (this.adapter == null) {
/* 273 */       T list = (T)nav().getBaseClass(this.tOfJAXBElementT, nav().asDecl(List.class));
/* 274 */       if (list == null) {
/* 275 */         this.isCollection = false;
/* 276 */         this.contentType = builder.getTypeInfo(this.tOfJAXBElementT, this);
/*     */       } else {
/* 278 */         this.isCollection = true;
/* 279 */         this.contentType = builder.getTypeInfo((T)nav().getTypeArgument(list, 0), this);
/*     */       } 
/*     */     } else {
/*     */       
/* 283 */       this.contentType = builder.getTypeInfo((T)this.adapter.defaultType, this);
/* 284 */       this.isCollection = false;
/*     */     } 
/*     */ 
/*     */     
/* 288 */     T s = (T)reader().getClassValue((Annotation)this.anno, "scope");
/* 289 */     if (nav().isSameType(s, nav().ref(XmlElementDecl.GLOBAL.class))) {
/* 290 */       this.scope = null;
/*     */     } else {
/*     */       
/* 293 */       NonElement<T, C> scp = builder.getClassInfo((C)nav().asDecl(s), this);
/* 294 */       if (!(scp instanceof ClassInfo)) {
/* 295 */         throw new IllegalAnnotationException(Messages.SCOPE_IS_NOT_COMPLEXTYPE
/* 296 */             .format(new Object[] { nav().getTypeName(s) }, ), this.anno);
/*     */       }
/*     */       
/* 299 */       this.scope = (ClassInfo<T, C>)scp;
/*     */     } 
/*     */     
/* 302 */     this.id = calcId();
/*     */     
/* 304 */     this.property = createPropertyImpl();
/*     */     
/* 306 */     this.expectedMimeType = Util.calcExpectedMediaType(this.property, builder);
/* 307 */     this.inlineBinary = reader().hasMethodAnnotation(XmlInlineBinaryData.class, this.method);
/* 308 */     this.schemaType = Util.calcSchemaType(reader(), this.property, registry.registryClass, 
/* 309 */         getContentInMemoryType(), this);
/*     */   }
/*     */   
/*     */   final QName parseElementName(XmlElementDecl e) {
/* 313 */     String local = e.name();
/* 314 */     String nsUri = e.namespace();
/* 315 */     if (nsUri.equals("##default")) {
/*     */       
/* 317 */       XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, 
/* 318 */           nav().getDeclaringClassForMethod(this.method), this);
/* 319 */       if (xs != null) {
/* 320 */         nsUri = xs.namespace();
/*     */       } else {
/* 322 */         nsUri = this.builder.defaultNsUri;
/*     */       } 
/*     */     } 
/*     */     
/* 326 */     return new QName(nsUri.intern(), local.intern());
/*     */   }
/*     */   
/*     */   protected PropertyImpl createPropertyImpl() {
/* 330 */     return new PropertyImpl();
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementPropertyInfo<T, C> getProperty() {
/* 335 */     return this.property;
/*     */   }
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getContentType() {
/* 340 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getContentInMemoryType() {
/* 345 */     if (this.adapter == null) {
/* 346 */       return this.tOfJAXBElementT;
/*     */     }
/* 348 */     return (T)this.adapter.customType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getElementName() {
/* 354 */     return this.tagName;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getType() {
/* 359 */     return this.elementType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final boolean canBeReferencedByIDREF() {
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private ID calcId() {
/* 376 */     if (reader().hasMethodAnnotation(XmlID.class, this.method)) {
/* 377 */       return ID.ID;
/*     */     }
/* 379 */     if (reader().hasMethodAnnotation(XmlIDREF.class, this.method)) {
/* 380 */       return ID.IDREF;
/*     */     }
/* 382 */     return ID.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassInfo<T, C> getScope() {
/* 388 */     return this.scope;
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementInfo<T, C> getSubstitutionHead() {
/* 393 */     return this.substitutionHead;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<? extends ElementInfoImpl<T, C, F, M>> getSubstitutionMembers() {
/* 398 */     if (this.substitutionMembers == null) {
/* 399 */       return Collections.emptyList();
/*     */     }
/* 401 */     return (Collection<? extends ElementInfoImpl<T, C, F, M>>)this.substitutionMembers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void link() {
/* 410 */     if (this.anno.substitutionHeadName().length() != 0)
/*     */     
/* 412 */     { QName name = new QName(this.anno.substitutionHeadNamespace(), this.anno.substitutionHeadName());
/* 413 */       this.substitutionHead = this.owner.getElementInfo((C)null, name);
/* 414 */       if (this.substitutionHead == null) {
/* 415 */         this.builder.reportError(new IllegalAnnotationException(Messages.NON_EXISTENT_ELEMENT_MAPPING
/* 416 */               .format(new Object[] {
/* 417 */                   name.getNamespaceURI(), name.getLocalPart()
/*     */                 }, ), (Annotation)this.anno));
/*     */       } else {
/* 420 */         this.substitutionHead.addSubstitutionMember(this);
/*     */       }  }
/* 422 */     else { this.substitutionHead = null; }
/* 423 */      super.link();
/*     */   }
/*     */   
/*     */   private void addSubstitutionMember(ElementInfoImpl<T, C, F, M> child) {
/* 427 */     if (this.substitutionMembers == null)
/* 428 */       this.substitutionMembers = new FinalArrayList(); 
/* 429 */     this.substitutionMembers.add(child);
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 434 */     return nav().getMethodLocation(this.method);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ElementInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */