/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.DomHandler;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DomLoader<ResultT extends Result>
/*     */   extends Loader
/*     */ {
/*     */   private final DomHandler<?, ResultT> dom;
/*     */   
/*     */   private final class State
/*     */   {
/*  37 */     private TransformerHandler handler = null;
/*     */ 
/*     */     
/*     */     private final ResultT result;
/*     */ 
/*     */     
/*  43 */     int depth = 1;
/*     */     
/*     */     public State(UnmarshallingContext context) throws SAXException {
/*  46 */       this.handler = JAXBContextImpl.createTransformerHandler((context.getJAXBContext()).disableSecurityProcessing);
/*  47 */       this.result = (ResultT)DomLoader.this.dom.createUnmarshaller(context);
/*     */       
/*  49 */       this.handler.setResult((Result)this.result);
/*     */ 
/*     */       
/*     */       try {
/*  53 */         this.handler.setDocumentLocator((Locator)context.getLocator());
/*  54 */         this.handler.startDocument();
/*  55 */         declarePrefixes(context, context.getAllDeclaredPrefixes());
/*  56 */       } catch (SAXException e) {
/*  57 */         context.handleError(e);
/*  58 */         throw e;
/*     */       } 
/*     */     }
/*     */     
/*     */     public Object getElement() {
/*  63 */       return DomLoader.this.dom.getElement((Result)this.result);
/*     */     }
/*     */     
/*     */     private void declarePrefixes(UnmarshallingContext context, String[] prefixes) throws SAXException {
/*  67 */       for (int i = prefixes.length - 1; i >= 0; i--) {
/*  68 */         String nsUri = context.getNamespaceURI(prefixes[i]);
/*  69 */         if (nsUri == null) throw new IllegalStateException("prefix '" + prefixes[i] + "' isn't bound"); 
/*  70 */         this.handler.startPrefixMapping(prefixes[i], nsUri);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void undeclarePrefixes(String[] prefixes) throws SAXException {
/*  75 */       for (int i = prefixes.length - 1; i >= 0; i--)
/*  76 */         this.handler.endPrefixMapping(prefixes[i]); 
/*     */     }
/*     */   }
/*     */   
/*     */   public DomLoader(DomHandler<?, ResultT> dom) {
/*  81 */     super(true);
/*  82 */     this.dom = dom;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  87 */     UnmarshallingContext context = state.getContext();
/*  88 */     if (state.getTarget() == null) {
/*  89 */       state.setTarget(new State(context));
/*     */     }
/*  91 */     State s = (State)state.getTarget();
/*     */     try {
/*  93 */       s.declarePrefixes(context, context.getNewlyDeclaredPrefixes());
/*  94 */       s.handler.startElement(ea.uri, ea.local, ea.getQname(), ea.atts);
/*  95 */     } catch (SAXException e) {
/*  96 */       context.handleError(e);
/*  97 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 103 */     state.setLoader(this);
/* 104 */     State s = (State)state.getPrev().getTarget();
/* 105 */     s.depth++;
/* 106 */     state.setTarget(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/* 111 */     if (text.length() == 0)
/*     */       return; 
/*     */     try {
/* 114 */       State s = (State)state.getTarget();
/* 115 */       s.handler.characters(text.toString().toCharArray(), 0, text.length());
/* 116 */     } catch (SAXException e) {
/* 117 */       state.getContext().handleError(e);
/* 118 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void leaveElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 124 */     State s = (State)state.getTarget();
/* 125 */     UnmarshallingContext context = state.getContext();
/*     */     
/*     */     try {
/* 128 */       s.handler.endElement(ea.uri, ea.local, ea.getQname());
/* 129 */       s.undeclarePrefixes(context.getNewlyDeclaredPrefixes());
/* 130 */     } catch (SAXException e) {
/* 131 */       context.handleError(e);
/* 132 */       throw e;
/*     */     } 
/*     */     
/* 135 */     if (--s.depth == 0) {
/*     */       
/*     */       try {
/* 138 */         s.undeclarePrefixes(context.getAllDeclaredPrefixes());
/* 139 */         s.handler.endDocument();
/* 140 */       } catch (SAXException e) {
/* 141 */         context.handleError(e);
/* 142 */         throw e;
/*     */       } 
/*     */ 
/*     */       
/* 146 */       state.setTarget(s.getElement());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\DomLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */