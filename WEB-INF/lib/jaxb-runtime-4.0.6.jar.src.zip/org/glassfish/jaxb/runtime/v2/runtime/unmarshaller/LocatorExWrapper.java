/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEventLocator;
/*    */ import jakarta.xml.bind.helpers.ValidationEventLocatorImpl;
/*    */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*    */ import org.xml.sax.Locator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LocatorExWrapper
/*    */   implements LocatorEx
/*    */ {
/*    */   private final Locator locator;
/*    */   
/*    */   public LocatorExWrapper(Locator locator) {
/* 27 */     this.locator = locator;
/*    */   }
/*    */ 
/*    */   
/*    */   public ValidationEventLocator getLocation() {
/* 32 */     return (ValidationEventLocator)new ValidationEventLocatorImpl(this.locator);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPublicId() {
/* 37 */     return this.locator.getPublicId();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSystemId() {
/* 42 */     return this.locator.getSystemId();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 47 */     return this.locator.getLineNumber();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getColumnNumber() {
/* 52 */     return this.locator.getColumnNumber();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\LocatorExWrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */