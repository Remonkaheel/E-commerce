/*     */ package org.glassfish.jaxb.runtime.v2;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.core.v2.Messages;
/*     */ import org.glassfish.jaxb.runtime.api.JAXBRIContext;
/*     */ import org.glassfish.jaxb.runtime.api.TypeReference;
/*     */ import org.glassfish.jaxb.runtime.v2.model.annotation.RuntimeAnnotationReader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.util.TypeCast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextFactory
/*     */ {
/*     */   public static final String USE_JAXB_PROPERTIES = "_useJAXBProperties";
/*     */   
/*     */   public static JAXBContext createContext(Class[] classes, Map<String, Object> properties) throws JAXBException {
/*     */     Map<Class<?>, Class<?>> subclassReplacements;
/*  52 */     MUtils.open(classes);
/*     */     
/*  54 */     if (properties == null) {
/*  55 */       properties = Collections.emptyMap();
/*     */     } else {
/*  57 */       properties = new HashMap<>(properties);
/*     */     } 
/*  59 */     String defaultNsUri = getPropertyValue(properties, "org.glassfish.jaxb.defaultNamespaceRemap", String.class);
/*     */     
/*  61 */     Boolean c14nSupport = getPropertyValue(properties, "org.glassfish.jaxb.c14n", Boolean.class);
/*  62 */     if (c14nSupport == null) {
/*  63 */       c14nSupport = Boolean.valueOf(false);
/*     */     }
/*  65 */     Boolean disablesecurityProcessing = getPropertyValue(properties, "org.glassfish.jaxb.disableXmlSecurity", Boolean.class);
/*  66 */     if (disablesecurityProcessing == null) {
/*  67 */       disablesecurityProcessing = Boolean.valueOf(false);
/*     */     }
/*  69 */     Boolean allNillable = getPropertyValue(properties, "org.glassfish.jaxb.treatEverythingNillable", Boolean.class);
/*  70 */     if (allNillable == null) {
/*  71 */       allNillable = Boolean.valueOf(false);
/*     */     }
/*  73 */     Boolean retainPropertyInfo = getPropertyValue(properties, "retainReferenceToInfo", Boolean.class);
/*  74 */     if (retainPropertyInfo == null) {
/*  75 */       retainPropertyInfo = Boolean.valueOf(false);
/*     */     }
/*  77 */     Boolean supressAccessorWarnings = getPropertyValue(properties, "supressAccessorWarnings", Boolean.class);
/*  78 */     if (supressAccessorWarnings == null) {
/*  79 */       supressAccessorWarnings = Boolean.valueOf(false);
/*     */     }
/*  81 */     Boolean improvedXsiTypeHandling = getPropertyValue(properties, "org.glassfish.jaxb.improvedXsiTypeHandling", Boolean.class);
/*  82 */     if (improvedXsiTypeHandling == null) {
/*  83 */       String improvedXsiSystemProperty = Utils.getSystemProperty("org.glassfish.jaxb.improvedXsiTypeHandling");
/*  84 */       if (improvedXsiSystemProperty == null) {
/*  85 */         improvedXsiTypeHandling = Boolean.valueOf(true);
/*     */       } else {
/*  87 */         improvedXsiTypeHandling = Boolean.valueOf(improvedXsiSystemProperty);
/*     */       } 
/*     */     } 
/*     */     
/*  91 */     Boolean xmlAccessorFactorySupport = getPropertyValue(properties, "org.glassfish.jaxb.XmlAccessorFactory", Boolean.class);
/*     */     
/*  93 */     if (xmlAccessorFactorySupport == null) {
/*  94 */       xmlAccessorFactorySupport = Boolean.valueOf(false);
/*  95 */       Utils.getClassLogger().log(Level.FINE, "Property org.glassfish.jaxb.XmlAccessorFactoryis not active.  Using JAXB's implementation");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 100 */     Boolean backupWithParentNamespace = getPropertyValue(properties, "org.glassfish.jaxb.backupWithParentNamespace", Boolean.class);
/*     */     
/* 102 */     RuntimeAnnotationReader ar = getPropertyValue(properties, JAXBRIContext.ANNOTATION_READER, RuntimeAnnotationReader.class);
/*     */     
/* 104 */     Collection<TypeReference> tr = getPropertyValue(properties, "org.glassfish.jaxb.typeReferences", (Class)Collection.class);
/* 105 */     if (tr == null) {
/* 106 */       tr = Collections.emptyList();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 111 */       subclassReplacements = TypeCast.checkedCast(
/* 112 */           getPropertyValue(properties, "org.glassfish.jaxb.subclassReplacements", Map.class), Class.class, Class.class);
/* 113 */     } catch (ClassCastException e) {
/* 114 */       throw new JAXBException(Messages.INVALID_TYPE_IN_MAP.format(new Object[0]), e);
/*     */     } 
/*     */     
/* 117 */     Integer maxErrorsCount = getPropertyValue(properties, "org.glassfish.jaxb.maxErrorsCount", Integer.class);
/* 118 */     if (maxErrorsCount == null) {
/* 119 */       maxErrorsCount = Integer.valueOf(10);
/* 120 */     } else if (maxErrorsCount.intValue() < 0) {
/*     */       
/* 122 */       maxErrorsCount = Integer.valueOf(2147483647);
/*     */     } 
/*     */     
/* 125 */     if (!properties.isEmpty()) {
/* 126 */       throw new JAXBException(Messages.UNSUPPORTED_PROPERTY.format(new Object[] { properties.keySet().iterator().next() }));
/*     */     }
/*     */     
/* 129 */     JAXBContextImpl.JAXBContextBuilder builder = new JAXBContextImpl.JAXBContextBuilder();
/* 130 */     builder.setClasses(classes);
/* 131 */     builder.setTypeRefs(tr);
/* 132 */     builder.setSubclassReplacements(subclassReplacements);
/* 133 */     builder.setDefaultNsUri(defaultNsUri);
/* 134 */     builder.setC14NSupport(c14nSupport.booleanValue());
/* 135 */     builder.setAnnotationReader(ar);
/* 136 */     builder.setXmlAccessorFactorySupport(xmlAccessorFactorySupport.booleanValue());
/* 137 */     builder.setAllNillable(allNillable.booleanValue());
/* 138 */     builder.setRetainPropertyInfo(retainPropertyInfo.booleanValue());
/* 139 */     builder.setSupressAccessorWarnings(supressAccessorWarnings.booleanValue());
/* 140 */     builder.setImprovedXsiTypeHandling(improvedXsiTypeHandling.booleanValue());
/* 141 */     builder.setDisableSecurityProcessing(disablesecurityProcessing.booleanValue());
/* 142 */     builder.setBackupWithParentNamespace(backupWithParentNamespace);
/* 143 */     builder.setMaxErrorsCount(maxErrorsCount.intValue());
/* 144 */     return (JAXBContext)builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T getPropertyValue(Map<String, Object> properties, String keyName, Class<T> type) throws JAXBException {
/* 151 */     Object o = properties.get(keyName);
/* 152 */     if (o == null) return null;
/*     */     
/* 154 */     properties.remove(keyName);
/* 155 */     if (!type.isInstance(o)) {
/* 156 */       throw new JAXBException(Messages.INVALID_PROPERTY_VALUE.format(new Object[] { keyName, o }));
/*     */     }
/* 158 */     return type.cast(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JAXBRIContext createContext(Class[] classes, Collection<TypeReference> typeRefs, Map<Class<?>, Class<?>> subclassReplacements, String defaultNsUri, boolean c14nSupport, RuntimeAnnotationReader ar, boolean xmlAccessorFactorySupport, boolean allNillable, boolean retainPropertyInfo) throws JAXBException {
/* 171 */     return createContext(classes, typeRefs, subclassReplacements, defaultNsUri, c14nSupport, ar, xmlAccessorFactorySupport, allNillable, retainPropertyInfo, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JAXBRIContext createContext(Class[] classes, Collection<TypeReference> typeRefs, Map<Class<?>, Class<?>> subclassReplacements, String defaultNsUri, boolean c14nSupport, RuntimeAnnotationReader ar, boolean xmlAccessorFactorySupport, boolean allNillable, boolean retainPropertyInfo, boolean improvedXsiTypeHandling) throws JAXBException {
/* 185 */     MUtils.open(classes);
/*     */     
/* 187 */     JAXBContextImpl.JAXBContextBuilder builder = new JAXBContextImpl.JAXBContextBuilder();
/* 188 */     builder.setClasses(classes);
/* 189 */     builder.setTypeRefs(typeRefs);
/* 190 */     builder.setSubclassReplacements(subclassReplacements);
/* 191 */     builder.setDefaultNsUri(defaultNsUri);
/* 192 */     builder.setC14NSupport(c14nSupport);
/* 193 */     builder.setAnnotationReader(ar);
/* 194 */     builder.setXmlAccessorFactorySupport(xmlAccessorFactorySupport);
/* 195 */     builder.setAllNillable(allNillable);
/* 196 */     builder.setRetainPropertyInfo(retainPropertyInfo);
/* 197 */     builder.setImprovedXsiTypeHandling(improvedXsiTypeHandling);
/* 198 */     return (JAXBRIContext)builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JAXBContext createContext(String contextPath, ClassLoader classLoader, Map<String, Object> properties) throws JAXBException {
/* 206 */     FinalArrayList<Class<?>> classes = new FinalArrayList();
/* 207 */     StringTokenizer tokens = new StringTokenizer(contextPath, ":");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     while (tokens.hasMoreTokens()) {
/* 215 */       List<Class<?>> indexedClasses; boolean foundJaxbIndex = false, foundObjectFactory = foundJaxbIndex;
/* 216 */       String pkg = tokens.nextToken();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 221 */         Class<?> o = classLoader.loadClass(pkg + ".ObjectFactory");
/* 222 */         classes.add(o);
/* 223 */         foundObjectFactory = true;
/* 224 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 230 */         indexedClasses = loadIndexedClasses(pkg, classLoader);
/* 231 */       } catch (IOException e) {
/*     */         
/* 233 */         throw new JAXBException(e);
/*     */       } 
/* 235 */       if (indexedClasses != null) {
/* 236 */         classes.addAll(indexedClasses);
/* 237 */         foundJaxbIndex = true;
/*     */       } 
/*     */       
/* 240 */       if (!foundObjectFactory && !foundJaxbIndex) {
/* 241 */         throw new JAXBException(Messages.BROKEN_CONTEXTPATH.format(new Object[] { pkg }));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 246 */     return createContext((Class[])classes.toArray((Object[])new Class[0]), properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Class> loadIndexedClasses(String pkg, ClassLoader classLoader) throws IOException, JAXBException {
/* 259 */     String resource = pkg.replace('.', '/') + "/jaxb.index";
/* 260 */     InputStream resourceAsStream = classLoader.getResourceAsStream(resource);
/*     */     
/* 262 */     if (resourceAsStream == null) {
/* 263 */       return null;
/*     */     }
/*     */     
/* 266 */     BufferedReader in = new BufferedReader(new InputStreamReader(resourceAsStream, StandardCharsets.UTF_8)); try {
/* 267 */       FinalArrayList<Class<?>> classes = new FinalArrayList();
/* 268 */       String className = in.readLine();
/* 269 */       while (className != null) {
/* 270 */         className = className.trim();
/* 271 */         if (className.startsWith("#") || className.length() == 0) {
/* 272 */           className = in.readLine();
/*     */           
/*     */           continue;
/*     */         } 
/* 276 */         if (className.endsWith(".class")) {
/* 277 */           throw new JAXBException(Messages.ILLEGAL_ENTRY.format(new Object[] { className }));
/*     */         }
/*     */         
/*     */         try {
/* 281 */           classes.add(classLoader.loadClass(pkg + "." + pkg));
/* 282 */         } catch (ClassNotFoundException e) {
/* 283 */           throw new JAXBException(Messages.ERROR_LOADING_CLASS.format(new Object[] { className, resource }, ), e);
/*     */         } 
/*     */         
/* 286 */         className = in.readLine();
/*     */       } 
/* 288 */       FinalArrayList<Class<?>> finalArrayList1 = classes;
/* 289 */       in.close();
/*     */       return (List)finalArrayList1;
/*     */     } catch (Throwable throwable) {
/*     */       try {
/*     */         in.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       } 
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\ContextFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */