/*     */ package org.glassfish.jaxb.runtime.v2.util;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class QNameMap<V>
/*     */ {
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*  43 */   transient Entry<V>[] table = (Entry<V>[])new Entry[16];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int threshold;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private Set<Entry<V>> entrySet = null;
/*     */   
/*     */   public QNameMap() {
/*  70 */     this.threshold = 12;
/*  71 */     this.table = (Entry<V>[])new Entry[16];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String namespaceUri, String localname, V value) {
/*  87 */     assert localname != null;
/*  88 */     assert namespaceUri != null;
/*     */     
/*  90 */     assert localname == localname.intern();
/*  91 */     assert namespaceUri == namespaceUri.intern();
/*     */     
/*  93 */     int hash = hash(localname);
/*  94 */     int i = indexFor(hash, this.table.length);
/*     */     
/*  96 */     for (Entry<V> e = this.table[i]; e != null; e = e.next) {
/*  97 */       if (e.hash == hash && localname == e.localName && namespaceUri == e.nsUri) {
/*  98 */         e.value = value;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 103 */     addEntry(hash, namespaceUri, localname, value, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(QName name, V value) {
/* 108 */     put(name.getNamespaceURI(), name.getLocalPart(), value);
/*     */   }
/*     */   
/*     */   public void put(Name name, V value) {
/* 112 */     put(name.nsUri, name.localName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(String nsUri, String localPart) {
/* 126 */     Entry<V> e = getEntry(nsUri, localPart);
/* 127 */     if (e == null) return null; 
/* 128 */     return e.value;
/*     */   }
/*     */   
/*     */   public V get(QName name) {
/* 132 */     return get(name.getNamespaceURI(), name.getLocalPart());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 141 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameMap<V> putAll(QNameMap<? extends V> map) {
/* 153 */     int numKeysToBeAdded = map.size();
/* 154 */     if (numKeysToBeAdded == 0) {
/* 155 */       return this;
/*     */     }
/*     */     
/* 158 */     if (numKeysToBeAdded > this.threshold) {
/* 159 */       int targetCapacity = numKeysToBeAdded;
/* 160 */       if (targetCapacity > 1073741824)
/* 161 */         targetCapacity = 1073741824; 
/* 162 */       int newCapacity = this.table.length;
/* 163 */       while (newCapacity < targetCapacity)
/* 164 */         newCapacity <<= 1; 
/* 165 */       if (newCapacity > this.table.length) {
/* 166 */         resize(newCapacity);
/*     */       }
/*     */     } 
/* 169 */     for (Entry<? extends V> e : map.entrySet())
/* 170 */       put(e.nsUri, e.localName, e.getValue()); 
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int hash(String x) {
/* 180 */     int h = x.hashCode();
/*     */     
/* 182 */     h += h << 9 ^ 0xFFFFFFFF;
/* 183 */     h ^= h >>> 14;
/* 184 */     h += h << 4;
/* 185 */     h ^= h >>> 10;
/* 186 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int indexFor(int h, int length) {
/* 193 */     return h & length - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEntry(int hash, String nsUri, String localName, V value, int bucketIndex) {
/* 203 */     Entry<V> e = this.table[bucketIndex];
/* 204 */     this.table[bucketIndex] = new Entry<>(hash, nsUri, localName, value, e);
/* 205 */     if (this.size++ >= this.threshold) {
/* 206 */       resize(2 * this.table.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resize(int newCapacity) {
/* 216 */     Entry<V>[] oldTable = this.table;
/* 217 */     int oldCapacity = oldTable.length;
/* 218 */     if (oldCapacity == 1073741824) {
/* 219 */       this.threshold = Integer.MAX_VALUE;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 224 */     Entry[] arrayOfEntry = new Entry[newCapacity];
/* 225 */     transfer((Entry<V>[])arrayOfEntry);
/* 226 */     this.table = (Entry<V>[])arrayOfEntry;
/* 227 */     this.threshold = newCapacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void transfer(Entry<V>[] newTable) {
/* 234 */     Entry<V>[] src = this.table;
/* 235 */     int newCapacity = newTable.length;
/* 236 */     for (int j = 0; j < src.length; j++) {
/* 237 */       Entry<V> e = src[j];
/* 238 */       if (e != null) {
/* 239 */         src[j] = null;
/*     */         do {
/* 241 */           Entry<V> next = e.next;
/* 242 */           int i = indexFor(e.hash, newCapacity);
/* 243 */           e.next = newTable[i];
/* 244 */           newTable[i] = e;
/* 245 */           e = next;
/* 246 */         } while (e != null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Entry<V> getOne() {
/* 259 */     for (Entry<V> e : this.table) {
/* 260 */       if (e != null)
/* 261 */         return e; 
/*     */     } 
/* 263 */     return null;
/*     */   }
/*     */   
/*     */   public Collection<QName> keySet() {
/* 267 */     Set<QName> r = new HashSet<>();
/* 268 */     for (Entry<V> e : entrySet()) {
/* 269 */       r.add(e.createQName());
/*     */     }
/* 271 */     return r;
/*     */   }
/*     */   
/*     */   private abstract class HashIterator<E> implements Iterator<E> {
/*     */     QNameMap.Entry<V> next;
/*     */     int index;
/*     */     
/*     */     HashIterator() {
/* 279 */       QNameMap.Entry[] arrayOfEntry = QNameMap.this.table;
/* 280 */       int i = arrayOfEntry.length;
/* 281 */       QNameMap.Entry<V> n = null;
/* 282 */       if (QNameMap.this.size != 0) {
/* 283 */         while (i > 0 && (n = arrayOfEntry[--i]) == null);
/*     */       }
/* 285 */       this.next = n;
/* 286 */       this.index = i;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 291 */       return (this.next != null);
/*     */     }
/*     */     
/*     */     QNameMap.Entry<V> nextEntry() {
/* 295 */       QNameMap.Entry<V> e = this.next;
/* 296 */       if (e == null) {
/* 297 */         throw new NoSuchElementException();
/*     */       }
/* 299 */       QNameMap.Entry<V> n = e.next;
/* 300 */       QNameMap.Entry[] arrayOfEntry = QNameMap.this.table;
/* 301 */       int i = this.index;
/* 302 */       while (n == null && i > 0)
/* 303 */         n = arrayOfEntry[--i]; 
/* 304 */       this.index = i;
/* 305 */       this.next = n;
/* 306 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 311 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean containsKey(String nsUri, String localName) {
/* 316 */     return (getEntry(nsUri, localName) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 324 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Entry<V>
/*     */   {
/*     */     public final String nsUri;
/*     */     
/*     */     public final String localName;
/*     */     
/*     */     V value;
/*     */     
/*     */     final int hash;
/*     */     
/*     */     Entry<V> next;
/*     */ 
/*     */     
/*     */     Entry(int h, String nsUri, String localName, V v, Entry<V> n) {
/* 343 */       this.value = v;
/* 344 */       this.next = n;
/* 345 */       this.nsUri = nsUri;
/* 346 */       this.localName = localName;
/* 347 */       this.hash = h;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public QName createQName() {
/* 354 */       return new QName(this.nsUri, this.localName);
/*     */     }
/*     */     
/*     */     public V getValue() {
/* 358 */       return this.value;
/*     */     }
/*     */     
/*     */     public V setValue(V newValue) {
/* 362 */       V oldValue = this.value;
/* 363 */       this.value = newValue;
/* 364 */       return oldValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 369 */       if (!(o instanceof Entry))
/* 370 */         return false; 
/* 371 */       Entry e = (Entry)o;
/* 372 */       String k1 = this.nsUri;
/* 373 */       String k2 = e.nsUri;
/* 374 */       String k3 = this.localName;
/* 375 */       String k4 = e.localName;
/* 376 */       if (k1 == k2 || (k1 != null && k1.equals(k2) && 
/* 377 */         Objects.equals(k3, k4))) {
/* 378 */         Object v1 = getValue();
/* 379 */         Object v2 = e.getValue();
/* 380 */         return Objects.equals(v1, v2);
/*     */       } 
/* 382 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 387 */       return this.localName.hashCode() ^ (
/* 388 */         (this.value == null) ? 0 : this.value.hashCode());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 393 */       return "\"" + this.nsUri + "\",\"" + this.localName + "\"=" + getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<Entry<V>> entrySet() {
/* 398 */     Set<Entry<V>> es = this.entrySet;
/* 399 */     return (es != null) ? es : (this.entrySet = new EntrySet());
/*     */   }
/*     */   
/*     */   private Iterator<Entry<V>> newEntryIterator() {
/* 403 */     return new EntryIterator();
/*     */   }
/*     */   
/*     */   private class EntryIterator
/*     */     extends HashIterator<Entry<V>> {
/*     */     public QNameMap.Entry<V> next() {
/* 409 */       return nextEntry();
/*     */     }
/*     */   }
/*     */   
/*     */   private class EntrySet extends AbstractSet<Entry<V>> {
/*     */     public Iterator<QNameMap.Entry<V>> iterator() {
/* 415 */       return QNameMap.this.newEntryIterator();
/*     */     }
/*     */     
/*     */     public boolean contains(Object o) {
/* 419 */       if (!(o instanceof QNameMap.Entry))
/* 420 */         return false; 
/* 421 */       QNameMap.Entry<V> e = (QNameMap.Entry<V>)o;
/* 422 */       QNameMap.Entry<V> candidate = QNameMap.this.getEntry(e.nsUri, e.localName);
/* 423 */       return (candidate != null && candidate.equals(e));
/*     */     }
/*     */     
/*     */     public boolean remove(Object o) {
/* 427 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public int size() {
/* 431 */       return QNameMap.this.size;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Entry<V> getEntry(String nsUri, String localName) {
/* 437 */     assert nsUri == nsUri.intern();
/* 438 */     assert localName == localName.intern();
/*     */     
/* 440 */     int hash = hash(localName);
/* 441 */     int i = indexFor(hash, this.table.length);
/* 442 */     Entry<V> e = this.table[i];
/* 443 */     while (e != null && (localName != e.localName || nsUri != e.nsUri))
/* 444 */       e = e.next; 
/* 445 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 450 */     StringBuilder buf = new StringBuilder();
/* 451 */     buf.append('{');
/*     */     
/* 453 */     for (Entry<V> e : entrySet()) {
/* 454 */       if (buf.length() > 1)
/* 455 */         buf.append(','); 
/* 456 */       buf.append('[');
/* 457 */       buf.append(e);
/* 458 */       buf.append(']');
/*     */     } 
/*     */     
/* 461 */     buf.append('}');
/* 462 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\QNameMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */