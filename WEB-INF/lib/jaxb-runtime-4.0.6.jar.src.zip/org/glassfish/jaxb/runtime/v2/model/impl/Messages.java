/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum Messages
/*    */ {
/* 21 */   ID_MUST_BE_STRING,
/*    */   
/* 23 */   MUTUALLY_EXCLUSIVE_ANNOTATIONS,
/* 24 */   DUPLICATE_ANNOTATIONS,
/* 25 */   NO_DEFAULT_CONSTRUCTOR,
/* 26 */   CANT_HANDLE_INTERFACE,
/* 27 */   CANT_HANDLE_INNER_CLASS,
/* 28 */   ANNOTATION_ON_WRONG_METHOD,
/* 29 */   GETTER_SETTER_INCOMPATIBLE_TYPE,
/* 30 */   DUPLICATE_ENTRY_IN_PROP_ORDER,
/* 31 */   DUPLICATE_PROPERTIES,
/*    */   
/* 33 */   XML_ELEMENT_MAPPING_ON_NON_IXMLELEMENT_METHOD,
/* 34 */   SCOPE_IS_NOT_COMPLEXTYPE,
/* 35 */   CONFLICTING_XML_ELEMENT_MAPPING,
/*    */   
/* 37 */   REFERENCE_TO_NON_ELEMENT,
/*    */   
/* 39 */   NON_EXISTENT_ELEMENT_MAPPING,
/*    */   
/* 41 */   TWO_ATTRIBUTE_WILDCARDS,
/* 42 */   SUPER_CLASS_HAS_WILDCARD,
/* 43 */   INVALID_ATTRIBUTE_WILDCARD_TYPE,
/* 44 */   PROPERTY_MISSING_FROM_ORDER,
/* 45 */   PROPERTY_ORDER_CONTAINS_UNUSED_ENTRY,
/*    */   
/* 47 */   INVALID_XML_ENUM_VALUE,
/* 48 */   NO_IMAGE_WRITER,
/*    */   
/* 50 */   ILLEGAL_MIME_TYPE,
/* 51 */   ILLEGAL_ANNOTATION,
/*    */   
/* 53 */   MULTIPLE_VALUE_PROPERTY,
/* 54 */   ELEMENT_AND_VALUE_PROPERTY,
/* 55 */   CONFLICTING_XML_TYPE_MAPPING,
/* 56 */   XMLVALUE_IN_DERIVED_TYPE,
/* 57 */   SIMPLE_TYPE_IS_REQUIRED,
/* 58 */   PROPERTY_COLLISION,
/* 59 */   INVALID_IDREF,
/* 60 */   INVALID_XML_ELEMENT_REF,
/* 61 */   NO_XML_ELEMENT_DECL,
/* 62 */   XML_ELEMENT_WRAPPER_ON_NON_COLLECTION,
/*    */   
/* 64 */   ANNOTATION_NOT_ALLOWED,
/* 65 */   XMLLIST_NEEDS_SIMPLETYPE,
/* 66 */   XMLLIST_ON_SINGLE_PROPERTY,
/* 67 */   NO_FACTORY_METHOD,
/* 68 */   FACTORY_CLASS_NEEDS_FACTORY_METHOD,
/*    */   
/* 70 */   MISSING_JAXB_PROPERTIES,
/* 71 */   TRANSIENT_FIELD_NOT_BINDABLE,
/* 72 */   THERE_MUST_BE_VALUE_IN_XMLVALUE,
/* 73 */   UNMATCHABLE_ADAPTER,
/* 74 */   ANONYMOUS_ARRAY_ITEM,
/*    */   
/* 76 */   ACCESSORFACTORY_INSTANTIATION_EXCEPTION,
/* 77 */   ACCESSORFACTORY_ACCESS_EXCEPTION,
/* 78 */   CUSTOM_ACCESSORFACTORY_PROPERTY_ERROR,
/* 79 */   CUSTOM_ACCESSORFACTORY_FIELD_ERROR,
/* 80 */   XMLGREGORIANCALENDAR_INVALID,
/* 81 */   XMLGREGORIANCALENDAR_SEC,
/* 82 */   XMLGREGORIANCALENDAR_MIN,
/* 83 */   XMLGREGORIANCALENDAR_HR,
/* 84 */   XMLGREGORIANCALENDAR_DAY,
/* 85 */   XMLGREGORIANCALENDAR_MONTH,
/* 86 */   XMLGREGORIANCALENDAR_YEAR,
/* 87 */   XMLGREGORIANCALENDAR_TIMEZONE;
/*    */   
/*    */   static {
/* 90 */     rb = ResourceBundle.getBundle(Messages.class.getName());
/*    */   }
/*    */   private static final ResourceBundle rb;
/*    */   public String toString() {
/* 94 */     return format(new Object[0]);
/*    */   }
/*    */   
/*    */   public String format(Object... args) {
/* 98 */     return MessageFormat.format(rb.getString(name()), args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */