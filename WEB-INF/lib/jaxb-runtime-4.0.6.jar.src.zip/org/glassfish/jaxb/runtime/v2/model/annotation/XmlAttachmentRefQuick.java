/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAttachmentRef;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlAttachmentRefQuick
/*    */   extends Quick
/*    */   implements XmlAttachmentRef
/*    */ {
/*    */   private final XmlAttachmentRef core;
/*    */   
/*    */   public XmlAttachmentRefQuick(Locatable upstream, XmlAttachmentRef core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlAttachmentRefQuick(upstream, (XmlAttachmentRef)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlAttachmentRef> annotationType() {
/* 47 */     return XmlAttachmentRef.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlAttachmentRefQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */