/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class PropertyImpl<BeanT>
/*    */   implements Property<BeanT>
/*    */ {
/*    */   protected final String fieldName;
/* 31 */   private RuntimePropertyInfo propertyInfo = null;
/*    */   private boolean hiddenByOverride = false;
/*    */   
/*    */   public PropertyImpl(JAXBContextImpl context, RuntimePropertyInfo prop) {
/* 35 */     this.fieldName = prop.getName();
/* 36 */     if (context.retainPropertyInfo) {
/* 37 */       this.propertyInfo = prop;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimePropertyInfo getInfo() {
/* 43 */     return this.propertyInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeURIs(BeanT o, XMLSerializer w) throws SAXException, AccessorException {}
/*    */ 
/*    */   
/*    */   public boolean hasSerializeURIAction() {
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void wrapUp() {}
/*    */ 
/*    */   
/*    */   public boolean isHiddenByOverride() {
/* 70 */     return this.hiddenByOverride;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setHiddenByOverride(boolean hidden) {
/* 75 */     this.hiddenByOverride = hidden;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFieldName() {
/* 80 */     return this.fieldName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\PropertyImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */