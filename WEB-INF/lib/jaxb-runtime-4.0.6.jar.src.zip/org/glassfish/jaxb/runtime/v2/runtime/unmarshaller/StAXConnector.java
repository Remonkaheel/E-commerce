/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEventLocator;
/*    */ import jakarta.xml.bind.helpers.ValidationEventLocatorImpl;
/*    */ import javax.xml.namespace.NamespaceContext;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*    */ import org.xml.sax.Locator;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class StAXConnector
/*    */ {
/*    */   protected final XmlVisitor visitor;
/*    */   protected final UnmarshallingContext context;
/*    */   protected final XmlVisitor.TextPredictor predictor;
/*    */   
/*    */   private final class TagNameImpl
/*    */     extends TagName
/*    */   {
/*    */     public String getQname() {
/* 38 */       return StAXConnector.this.getCurrentQName();
/*    */     }
/*    */   }
/*    */   
/* 42 */   protected final TagName tagName = new TagNameImpl();
/*    */   
/*    */   protected StAXConnector(XmlVisitor visitor) {
/* 45 */     this.visitor = visitor;
/* 46 */     this.context = visitor.getContext();
/* 47 */     this.predictor = visitor.getPredictor();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void bridge() throws XMLStreamException;
/*    */ 
/*    */   
/*    */   protected abstract Location getCurrentLocation();
/*    */ 
/*    */   
/*    */   protected abstract String getCurrentQName();
/*    */ 
/*    */   
/*    */   protected final void handleStartDocument(NamespaceContext nsc) throws SAXException {
/* 62 */     this.visitor.startDocument(new LocatorEx()
/*    */         {
/*    */           public ValidationEventLocator getLocation() {
/* 65 */             return (ValidationEventLocator)new ValidationEventLocatorImpl((Locator)this);
/*    */           }
/*    */           
/*    */           public int getColumnNumber() {
/* 69 */             return StAXConnector.this.getCurrentLocation().getColumnNumber();
/*    */           }
/*    */           
/*    */           public int getLineNumber() {
/* 73 */             return StAXConnector.this.getCurrentLocation().getLineNumber();
/*    */           }
/*    */           
/*    */           public String getPublicId() {
/* 77 */             return StAXConnector.this.getCurrentLocation().getPublicId();
/*    */           }
/*    */           
/*    */           public String getSystemId() {
/* 81 */             return StAXConnector.this.getCurrentLocation().getSystemId();
/*    */           }
/*    */         },  nsc);
/*    */   }
/*    */   
/*    */   protected final void handleEndDocument() throws SAXException {
/* 87 */     this.visitor.endDocument();
/*    */   }
/*    */   
/*    */   protected static String fixNull(String s) {
/* 91 */     if (s == null) return ""; 
/* 92 */     return s;
/*    */   }
/*    */   
/*    */   protected final String getQName(String prefix, String localName) {
/* 96 */     if (prefix == null || prefix.length() == 0) {
/* 97 */       return localName;
/*    */     }
/* 99 */     return prefix + ":" + prefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\StAXConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */