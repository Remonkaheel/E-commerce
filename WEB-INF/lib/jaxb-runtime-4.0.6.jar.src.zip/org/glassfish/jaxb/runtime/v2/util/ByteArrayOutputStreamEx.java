/*    */ package org.glassfish.jaxb.runtime.v2.util;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Base64Data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ByteArrayOutputStreamEx
/*    */   extends ByteArrayOutputStream
/*    */ {
/*    */   public ByteArrayOutputStreamEx() {}
/*    */   
/*    */   public ByteArrayOutputStreamEx(int size) {
/* 27 */     super(size);
/*    */   }
/*    */   
/*    */   public void set(Base64Data dt, String mimeType) {
/* 31 */     dt.set(this.buf, this.count, mimeType);
/*    */   }
/*    */   
/*    */   public byte[] getBuffer() {
/* 35 */     return this.buf;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readFrom(InputStream is) throws IOException {
/*    */     while (true) {
/* 43 */       if (this.count == this.buf.length) {
/*    */         
/* 45 */         byte[] data = new byte[this.buf.length * 2];
/* 46 */         System.arraycopy(this.buf, 0, data, 0, this.buf.length);
/* 47 */         this.buf = data;
/*    */       } 
/*    */       
/* 50 */       int sz = is.read(this.buf, this.count, this.buf.length - this.count);
/* 51 */       if (sz < 0)
/* 52 */         return;  this.count += sz;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\ByteArrayOutputStreamEx.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */