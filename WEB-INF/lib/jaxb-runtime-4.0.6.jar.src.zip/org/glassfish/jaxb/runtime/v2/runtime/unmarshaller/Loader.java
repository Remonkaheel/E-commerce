/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Loader
/*     */ {
/*     */   protected boolean expectText;
/*     */   
/*     */   protected Loader(boolean expectText) {
/*  32 */     this.expectText = expectText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Loader() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  73 */     reportUnexpectedChildElement(ea, true);
/*  74 */     state.setLoader(Discarder.INSTANCE);
/*  75 */     state.setReceiver(null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void reportUnexpectedChildElement(TagName ea, boolean canRecover) throws SAXException {
/*  80 */     if (canRecover) {
/*     */ 
/*     */ 
/*     */       
/*  84 */       UnmarshallingContext context = UnmarshallingContext.getInstance();
/*  85 */       if (!context.parent.hasEventHandler() || 
/*  86 */         !context.shouldErrorBeReported())
/*     */         return; 
/*     */     } 
/*  89 */     if (ea.uri != ea.uri.intern() || ea.local != ea.local.intern()) {
/*  90 */       reportError(Messages.UNINTERNED_STRINGS.format(new Object[0]), canRecover);
/*     */     } else {
/*  92 */       reportError(Messages.UNEXPECTED_ELEMENT.format(new Object[] { ea.uri, ea.local, computeExpectedElements() }, ), canRecover);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedChildElements() {
/*  99 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedAttributes() {
/* 106 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/* 118 */     text = text.toString().replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
/* 119 */     reportError(Messages.UNEXPECTED_TEXT.format(new Object[] { text }, ), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean expectText() {
/* 127 */     return this.expectText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void leaveElement(UnmarshallingContext.State state, TagName ea) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String computeExpectedElements() {
/* 157 */     StringBuilder r = new StringBuilder();
/*     */     
/* 159 */     for (QName n : getExpectedChildElements()) {
/* 160 */       if (r.length() != 0) r.append(','); 
/* 161 */       r.append("<{").append(n.getNamespaceURI()).append('}').append(n.getLocalPart()).append('>');
/*     */     } 
/* 163 */     if (r.length() == 0) {
/* 164 */       return "(none)";
/*     */     }
/*     */     
/* 167 */     return r.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void fireBeforeUnmarshal(JaxBeanInfo beanInfo, Object child, UnmarshallingContext.State state) throws SAXException {
/* 177 */     if (beanInfo.lookForLifecycleMethods()) {
/* 178 */       UnmarshallingContext context = state.getContext();
/* 179 */       Unmarshaller.Listener listener = context.parent.getListener();
/* 180 */       if (beanInfo.hasBeforeUnmarshalMethod()) {
/* 181 */         beanInfo.invokeBeforeUnmarshalMethod(context.parent, child, state.getPrev().getTarget());
/*     */       }
/* 183 */       if (listener != null) {
/* 184 */         listener.beforeUnmarshal(child, state.getPrev().getTarget());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void fireAfterUnmarshal(JaxBeanInfo beanInfo, Object child, UnmarshallingContext.State state) throws SAXException {
/* 197 */     if (beanInfo.lookForLifecycleMethods()) {
/* 198 */       UnmarshallingContext context = state.getContext();
/* 199 */       Unmarshaller.Listener listener = context.parent.getListener();
/* 200 */       if (beanInfo.hasAfterUnmarshalMethod()) {
/* 201 */         beanInfo.invokeAfterUnmarshalMethod(context.parent, child, state.getTarget());
/*     */       }
/* 203 */       if (listener != null) {
/* 204 */         listener.afterUnmarshal(child, state.getTarget());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void handleGenericException(Exception e) throws SAXException {
/* 213 */     handleGenericException(e, false);
/*     */   }
/*     */   
/*     */   public static void handleGenericException(Exception e, boolean canRecover) throws SAXException {
/* 217 */     reportError(e.getMessage(), e, canRecover);
/*     */   }
/*     */   
/*     */   public static void handleGenericError(Error e) throws SAXException {
/* 221 */     reportError(e.getMessage(), false);
/*     */   }
/*     */   
/*     */   protected static void reportError(String msg, boolean canRecover) throws SAXException {
/* 225 */     reportError(msg, null, canRecover);
/*     */   }
/*     */   
/*     */   public static void reportError(String msg, Exception nested, boolean canRecover) throws SAXException {
/* 229 */     UnmarshallingContext context = UnmarshallingContext.getInstance();
/* 230 */     context.handleEvent((ValidationEvent)new ValidationEventImpl(
/* 231 */           canRecover ? 1 : 2, msg, context
/*     */           
/* 233 */           .getLocator().getLocation(), nested), canRecover);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void handleParseConversionException(UnmarshallingContext.State state, Exception e) throws SAXException {
/* 243 */     state.getContext().handleError(e);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Loader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */