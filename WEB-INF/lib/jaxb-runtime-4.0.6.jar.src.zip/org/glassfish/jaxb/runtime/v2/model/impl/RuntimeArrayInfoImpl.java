/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeArrayInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeArrayInfoImpl
/*    */   extends ArrayInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeArrayInfo
/*    */ {
/*    */   RuntimeArrayInfoImpl(RuntimeModelBuilder builder, Locatable upstream, Class arrayType) {
/* 27 */     super(builder, upstream, arrayType);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getType() {
/* 32 */     return (Class)super.getType();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getItemType() {
/* 37 */     return (RuntimeNonElement)super.getItemType();
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> Transducer<V> getTransducer() {
/* 42 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeArrayInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */