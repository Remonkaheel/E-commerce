package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Type;
import org.glassfish.jaxb.core.v2.model.core.Element;

public interface RuntimeElement extends Element<Type, Class>, RuntimeTypeInfo {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */