/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ValueListBeanInfoImpl
/*     */   extends JaxBeanInfo
/*     */ {
/*     */   private final Class itemType;
/*     */   private final Transducer xducer;
/*     */   private final Loader loader;
/*     */   
/*     */   public ValueListBeanInfoImpl(JAXBContextImpl owner, Class<BeanT> arrayType) throws JAXBException {
/*  39 */     super(owner, null, arrayType, false, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.loader = new Loader(true)
/*     */       {
/*     */         public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/*  48 */           FinalArrayList finalArrayList = new FinalArrayList();
/*     */           
/*  50 */           int idx = 0;
/*  51 */           int len = text.length();
/*     */           
/*     */           while (true) {
/*  54 */             int p = idx;
/*  55 */             while (p < len && !WhiteSpaceProcessor.isWhiteSpace(text.charAt(p))) {
/*  56 */               p++;
/*     */             }
/*  58 */             CharSequence token = text.subSequence(idx, p);
/*  59 */             if (!token.equals("")) {
/*     */               try {
/*  61 */                 finalArrayList.add(ValueListBeanInfoImpl.this.xducer.parse(token));
/*  62 */               } catch (AccessorException e) {
/*  63 */                 handleGenericException((Exception)e, true);
/*     */                 continue;
/*     */               } 
/*     */             }
/*  67 */             if (p == len)
/*     */               break; 
/*  69 */             while (p < len && WhiteSpaceProcessor.isWhiteSpace(text.charAt(p)))
/*  70 */               p++; 
/*  71 */             if (p == len)
/*     */               break; 
/*  73 */             idx = p;
/*     */           } 
/*     */           
/*  76 */           state.setTarget(ValueListBeanInfoImpl.this.toArray((List)finalArrayList)); }
/*     */       };
/*     */     this.itemType = this.jaxbType.getComponentType();
/*     */     this.xducer = owner.getBeanInfo(arrayType.getComponentType(), true).getTransducer();
/*     */     assert this.xducer != null; } private Object toArray(List list) {
/*  81 */     int len = list.size();
/*  82 */     Object array = Array.newInstance(this.itemType, len);
/*  83 */     for (int i = 0; i < len; i++)
/*  84 */       Array.set(array, i, list.get(i)); 
/*  85 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(Object array, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/*  90 */     int len = Array.getLength(array);
/*  91 */     for (int i = 0; i < len; i++) {
/*  92 */       Object item = Array.get(array, i);
/*     */       try {
/*  94 */         this.xducer.writeText(target, item, "arrayItem");
/*  95 */       } catch (AccessorException e) {
/*  96 */         target.reportError("arrayItem", (Throwable)e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeURIs(Object array, XMLSerializer target) throws SAXException {
/* 103 */     if (this.xducer.useNamespace()) {
/* 104 */       int len = Array.getLength(array);
/* 105 */       for (int i = 0; i < len; i++) {
/* 106 */         Object item = Array.get(array, i);
/*     */         try {
/* 108 */           this.xducer.declareNamespace(item, target);
/* 109 */         } catch (AccessorException e) {
/* 110 */           target.reportError("arrayItem", (Throwable)e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementNamespaceURI(Object array) {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementLocalName(Object array) {
/* 123 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object createInstance(UnmarshallingContext context) {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reset(Object array, UnmarshallingContext context) {
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId(Object array, XMLSerializer target) {
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAttributes(Object array, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeRoot(Object array, XMLSerializer target) throws SAXException {
/* 148 */     target.reportError((ValidationEvent)new ValidationEventImpl(1, Messages.UNABLE_TO_MARSHAL_NON_ELEMENT
/*     */ 
/*     */           
/* 151 */           .format(new Object[] { array.getClass().getName() }, ), null, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transducer getTransducer() {
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 164 */     return this.loader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\ValueListBeanInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */