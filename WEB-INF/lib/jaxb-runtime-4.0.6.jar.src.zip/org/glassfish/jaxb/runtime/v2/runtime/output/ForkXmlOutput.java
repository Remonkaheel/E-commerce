/*    */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ForkXmlOutput
/*    */   extends XmlOutputAbstractImpl
/*    */ {
/*    */   private final XmlOutput lhs;
/*    */   private final XmlOutput rhs;
/*    */   
/*    */   public ForkXmlOutput(XmlOutput lhs, XmlOutput rhs) {
/* 29 */     this.lhs = lhs;
/* 30 */     this.rhs = rhs;
/*    */   }
/*    */ 
/*    */   
/*    */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/* 35 */     this.lhs.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/* 36 */     this.rhs.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/* 41 */     this.lhs.endDocument(fragment);
/* 42 */     this.rhs.endDocument(fragment);
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginStartTag(Name name) throws IOException, XMLStreamException {
/* 47 */     this.lhs.beginStartTag(name);
/* 48 */     this.rhs.beginStartTag(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void attribute(Name name, String value) throws IOException, XMLStreamException {
/* 53 */     this.lhs.attribute(name, value);
/* 54 */     this.rhs.attribute(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endTag(Name name) throws IOException, SAXException, XMLStreamException {
/* 59 */     this.lhs.endTag(name);
/* 60 */     this.rhs.endTag(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginStartTag(int prefix, String localName) throws IOException, XMLStreamException {
/* 65 */     this.lhs.beginStartTag(prefix, localName);
/* 66 */     this.rhs.beginStartTag(prefix, localName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void attribute(int prefix, String localName, String value) throws IOException, XMLStreamException {
/* 71 */     this.lhs.attribute(prefix, localName, value);
/* 72 */     this.rhs.attribute(prefix, localName, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endStartTag() throws IOException, SAXException {
/* 77 */     this.lhs.endStartTag();
/* 78 */     this.rhs.endStartTag();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endTag(int prefix, String localName) throws IOException, SAXException, XMLStreamException {
/* 83 */     this.lhs.endTag(prefix, localName);
/* 84 */     this.rhs.endTag(prefix, localName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(String value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 89 */     this.lhs.text(value, needsSeparatingWhitespace);
/* 90 */     this.rhs.text(value, needsSeparatingWhitespace);
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(Pcdata value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 95 */     this.lhs.text(value, needsSeparatingWhitespace);
/* 96 */     this.rhs.text(value, needsSeparatingWhitespace);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\ForkXmlOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */