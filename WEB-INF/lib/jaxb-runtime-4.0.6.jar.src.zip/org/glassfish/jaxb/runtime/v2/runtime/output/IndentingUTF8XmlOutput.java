/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndentingUTF8XmlOutput
/*     */   extends UTF8XmlOutput
/*     */ {
/*     */   private final Encoded indent8;
/*     */   private final int unitLen;
/*  45 */   private int depth = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean seenText = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndentingUTF8XmlOutput(OutputStream out, String indentStr, Encoded[] localNames, CharacterEscapeHandler escapeHandler) {
/*  56 */     super(out, localNames, escapeHandler);
/*     */     
/*  58 */     if (indentStr != null) {
/*  59 */       Encoded e = new Encoded(indentStr);
/*  60 */       this.indent8 = new Encoded();
/*  61 */       this.indent8.ensureSize(e.len * 8);
/*  62 */       this.unitLen = e.len;
/*  63 */       for (int i = 0; i < 8; i++)
/*  64 */         System.arraycopy(e.buf, 0, this.indent8.buf, this.unitLen * i, this.unitLen); 
/*     */     } else {
/*  66 */       this.indent8 = null;
/*  67 */       this.unitLen = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) throws IOException {
/*  73 */     indentStartTag();
/*  74 */     super.beginStartTag(prefix, localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(Name name) throws IOException {
/*  79 */     indentStartTag();
/*  80 */     super.beginStartTag(name);
/*     */   }
/*     */   
/*     */   private void indentStartTag() throws IOException {
/*  84 */     closeStartTag();
/*  85 */     if (!this.seenText)
/*  86 */       printIndent(); 
/*  87 */     this.depth++;
/*  88 */     this.seenText = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(Name name) throws IOException {
/*  93 */     indentEndTag();
/*  94 */     super.endTag(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws IOException {
/*  99 */     indentEndTag();
/* 100 */     super.endTag(prefix, localName);
/*     */   }
/*     */   
/*     */   private void indentEndTag() throws IOException {
/* 104 */     this.depth--;
/* 105 */     if (!this.closeStartTagPending && !this.seenText)
/* 106 */       printIndent(); 
/* 107 */     this.seenText = false;
/*     */   }
/*     */   
/*     */   private void printIndent() throws IOException {
/* 111 */     write(10);
/* 112 */     int i = this.depth & 0x7;
/*     */     
/* 114 */     write(this.indent8.buf, 0, i * this.unitLen);
/*     */     
/* 116 */     i = this.depth >> 3;
/*     */     
/* 118 */     for (; i > 0; i--) {
/* 119 */       this.indent8.write(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void text(String value, boolean needSP) throws IOException {
/* 124 */     this.seenText = true;
/* 125 */     super.text(value, needSP);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needSP) throws IOException {
/* 130 */     this.seenText = true;
/* 131 */     super.text(value, needSP);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/* 136 */     write(10);
/* 137 */     super.endDocument(fragment);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\IndentingUTF8XmlOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */