/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeTypeRefImpl
/*    */   extends TypeRefImpl<Type, Class>
/*    */   implements RuntimeTypeRef
/*    */ {
/*    */   public RuntimeTypeRefImpl(RuntimeElementPropertyInfoImpl elementPropertyInfo, QName elementName, Type type, boolean isNillable, String defaultValue) {
/* 27 */     super(elementPropertyInfo, elementName, type, isNillable, defaultValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getTarget() {
/* 32 */     return (RuntimeNonElement)super.getTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public Transducer getTransducer() {
/* 37 */     return RuntimeModelBuilder.createTransducer((RuntimeNonElementRef)this);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimePropertyInfo getSource() {
/* 42 */     return (RuntimePropertyInfo)this.owner;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeTypeRefImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */