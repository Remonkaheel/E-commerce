/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlJavaTypeAdapterQuick
/*    */   extends Quick
/*    */   implements XmlJavaTypeAdapter
/*    */ {
/*    */   private final XmlJavaTypeAdapter core;
/*    */   
/*    */   public XmlJavaTypeAdapterQuick(Locatable upstream, XmlJavaTypeAdapter core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlJavaTypeAdapterQuick(upstream, (XmlJavaTypeAdapter)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlJavaTypeAdapter> annotationType() {
/* 47 */     return XmlJavaTypeAdapter.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class type() {
/* 52 */     return this.core.type();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class value() {
/* 57 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlJavaTypeAdapterQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */