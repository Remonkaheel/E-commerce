/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.annotation.DomHandler;
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.WildcardMode;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElement;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeReferencePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.ListIterator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.WildcardLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArrayReferenceNodeProperty<BeanT, ListT, ItemT>
/*     */   extends ArrayERProperty<BeanT, ListT, ItemT>
/*     */ {
/*  40 */   private final QNameMap<JaxBeanInfo> expectedElements = new QNameMap();
/*     */   
/*     */   private final boolean isMixed;
/*     */   
/*     */   private final DomHandler domHandler;
/*     */   private final WildcardMode wcMode;
/*     */   
/*     */   public ArrayReferenceNodeProperty(JAXBContextImpl p, RuntimeReferencePropertyInfo prop) {
/*  48 */     super(p, (RuntimePropertyInfo)prop, prop.getXmlName(), prop.isCollectionNillable());
/*     */     
/*  50 */     for (RuntimeElement e : prop.getElements()) {
/*  51 */       JaxBeanInfo bi = p.getOrCreate((RuntimeTypeInfo)e);
/*  52 */       this.expectedElements.put(e.getElementName().getNamespaceURI(), e.getElementName().getLocalPart(), bi);
/*     */     } 
/*     */     
/*  55 */     this.isMixed = prop.isMixed();
/*     */     
/*  57 */     if (prop.getWildcard() != null) {
/*  58 */       this.domHandler = (DomHandler)ClassFactory.create((Class)prop.getDOMHandler());
/*  59 */       this.wcMode = prop.getWildcard();
/*     */     } else {
/*  61 */       this.domHandler = null;
/*  62 */       this.wcMode = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void serializeListBody(BeanT o, XMLSerializer w, ListT list) throws IOException, XMLStreamException, SAXException {
/*  68 */     ListIterator<ItemT> itr = this.lister.iterator(list, w);
/*     */     
/*  70 */     while (itr.hasNext()) {
/*     */       try {
/*  72 */         ItemT item = (ItemT)itr.next();
/*  73 */         if (item != null) {
/*  74 */           if (this.isMixed && item.getClass() == String.class) {
/*  75 */             w.text((String)item, null); continue;
/*     */           } 
/*  77 */           JaxBeanInfo bi = w.grammar.getBeanInfo(item, true);
/*  78 */           if (bi.jaxbType == Object.class && this.domHandler != null) {
/*     */ 
/*     */             
/*  81 */             w.writeDom(item, this.domHandler, o, this.fieldName); continue;
/*     */           } 
/*  83 */           bi.serializeRoot(item, w);
/*     */         }
/*     */       
/*  86 */       } catch (JAXBException e) {
/*  87 */         w.reportError(this.fieldName, (Throwable)e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createBodyUnmarshaller(UnmarshallerChain chain, QNameMap<ChildLoader> loaders) {
/*  95 */     int offset = chain.allocateOffset();
/*     */     
/*  97 */     Receiver recv = new ArrayERProperty.ReceiverImpl(this, offset);
/*     */     
/*  99 */     for (QNameMap.Entry<JaxBeanInfo> n : (Iterable<QNameMap.Entry<JaxBeanInfo>>)this.expectedElements.entrySet()) {
/* 100 */       JaxBeanInfo beanInfo = (JaxBeanInfo)n.getValue();
/* 101 */       loaders.put(n.nsUri, n.localName, new ChildLoader(beanInfo.getLoader(chain.context, true), recv));
/*     */     } 
/*     */     
/* 104 */     if (this.isMixed)
/*     */     {
/* 106 */       loaders.put(TEXT_HANDLER, new ChildLoader(new MixedTextLoader(recv), null));
/*     */     }
/*     */ 
/*     */     
/* 110 */     if (this.domHandler != null) {
/* 111 */       loaders.put(CATCH_ALL, new ChildLoader((Loader)new WildcardLoader(this.domHandler, this.wcMode), recv));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class MixedTextLoader
/*     */     extends Loader
/*     */   {
/*     */     private final Receiver recv;
/*     */     
/*     */     public MixedTextLoader(Receiver recv) {
/* 121 */       super(true);
/* 122 */       this.recv = recv;
/*     */     }
/*     */ 
/*     */     
/*     */     public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/* 127 */       if (text.length() != 0) {
/* 128 */         this.recv.receive(state, text.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/* 135 */     return PropertyKind.REFERENCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 141 */     if (this.wrapperTagName != null) {
/* 142 */       if (this.wrapperTagName.equals(nsUri, localName)) {
/* 143 */         return this.acc;
/*     */       }
/* 145 */     } else if (this.expectedElements.containsKey(nsUri, localName)) {
/* 146 */       return this.acc;
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayReferenceNodeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */