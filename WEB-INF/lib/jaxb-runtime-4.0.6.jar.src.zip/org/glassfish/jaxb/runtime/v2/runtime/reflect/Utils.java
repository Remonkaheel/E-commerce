/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Utils
/*    */ {
/* 34 */   private static final Logger LOGGER = Logger.getLogger(Utils.class.getName());
/*    */ 
/*    */   
/*    */   static final Navigator<Type, Class, Field, Method> REFLECTION_NAVIGATOR;
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     try {
/* 43 */       final Class<?> refNav = Class.forName("org.glassfish.jaxb.core.v2.model.nav.ReflectionNavigator");
/*    */ 
/*    */       
/* 46 */       Method getInstance = AccessController.<Method>doPrivileged(new PrivilegedAction<Method>()
/*    */           {
/*    */             public Method run()
/*    */             {
/*    */               try {
/* 51 */                 Method getInstance = refNav.getDeclaredMethod("getInstance", new Class[0]);
/* 52 */                 getInstance.setAccessible(true);
/* 53 */                 return getInstance;
/* 54 */               } catch (NoSuchMethodException e) {
/* 55 */                 throw new IllegalStateException("ReflectionNavigator.getInstance can't be found");
/*    */               } 
/*    */             }
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 62 */       REFLECTION_NAVIGATOR = (Navigator<Type, Class, Field, Method>)getInstance.invoke(null, new Object[0]);
/* 63 */     } catch (ClassNotFoundException e) {
/* 64 */       throw new IllegalStateException("Can't find ReflectionNavigator class");
/* 65 */     } catch (InvocationTargetException e) {
/* 66 */       throw new IllegalStateException("ReflectionNavigator.getInstance throws the exception");
/* 67 */     } catch (IllegalAccessException e) {
/* 68 */       throw new IllegalStateException("ReflectionNavigator.getInstance method is inaccessible");
/* 69 */     } catch (SecurityException e) {
/* 70 */       LOGGER.log(Level.FINE, "Unable to access ReflectionNavigator.getInstance", e);
/* 71 */       throw e;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\Utils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */