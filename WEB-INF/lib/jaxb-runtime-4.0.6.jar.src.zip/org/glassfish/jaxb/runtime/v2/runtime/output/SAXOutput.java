/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.util.AttributesImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.LocatorImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXOutput
/*     */   extends XmlOutputAbstractImpl
/*     */ {
/*     */   protected final ContentHandler out;
/*     */   private String elementNsUri;
/*     */   private String elementLocalName;
/*     */   private String elementQName;
/*     */   private char[] buf;
/*     */   private final AttributesImpl atts;
/*     */   
/*     */   public SAXOutput(ContentHandler out) {
/*  37 */     this.buf = new char[256];
/*     */     
/*  39 */     this.atts = new AttributesImpl();
/*     */     this.out = out;
/*     */     out.setDocumentLocator(new LocatorImpl());
/*     */   }
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws SAXException, IOException, XMLStreamException {
/*  45 */     super.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*  46 */     if (!fragment) {
/*  47 */       this.out.startDocument();
/*     */     }
/*     */   }
/*     */   
/*     */   public void endDocument(boolean fragment) throws SAXException, IOException, XMLStreamException {
/*  52 */     if (!fragment)
/*  53 */       this.out.endDocument(); 
/*  54 */     super.endDocument(fragment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) {
/*  59 */     this.elementNsUri = this.nsContext.getNamespaceURI(prefix);
/*  60 */     this.elementLocalName = localName;
/*  61 */     this.elementQName = getQName(prefix, localName);
/*  62 */     this.atts.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) {
/*     */     String qname, nsUri;
/*  69 */     if (prefix == -1) {
/*  70 */       nsUri = "";
/*  71 */       qname = localName;
/*     */     } else {
/*  73 */       nsUri = this.nsContext.getNamespaceURI(prefix);
/*  74 */       String p = this.nsContext.getPrefix(prefix);
/*  75 */       if (p.length() == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  80 */         qname = localName;
/*     */       } else {
/*  82 */         qname = p + ":" + p;
/*     */       } 
/*  84 */     }  this.atts.addAttribute(nsUri, localName, qname, "CDATA", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag() throws SAXException {
/*  89 */     NamespaceContextImpl.Element ns = this.nsContext.getCurrent();
/*  90 */     if (ns != null) {
/*  91 */       int sz = ns.count();
/*  92 */       for (int i = 0; i < sz; i++) {
/*  93 */         String p = ns.getPrefix(i);
/*  94 */         String uri = ns.getNsUri(i);
/*  95 */         if (uri.length() != 0 || ns.getBase() != 1)
/*     */         {
/*  97 */           this.out.startPrefixMapping(p, uri); } 
/*     */       } 
/*     */     } 
/* 100 */     this.out.startElement(this.elementNsUri, this.elementLocalName, this.elementQName, (Attributes)this.atts);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws SAXException {
/* 105 */     this.out.endElement(this.nsContext
/* 106 */         .getNamespaceURI(prefix), localName, 
/*     */         
/* 108 */         getQName(prefix, localName));
/*     */ 
/*     */     
/* 111 */     NamespaceContextImpl.Element ns = this.nsContext.getCurrent();
/* 112 */     if (ns != null) {
/* 113 */       int sz = ns.count();
/* 114 */       for (int i = sz - 1; i >= 0; i--) {
/* 115 */         String p = ns.getPrefix(i);
/* 116 */         String uri = ns.getNsUri(i);
/* 117 */         if (uri.length() != 0 || ns.getBase() != 1)
/*     */         {
/* 119 */           this.out.endPrefixMapping(p);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getQName(int prefix, String localName) {
/* 126 */     String qname, p = this.nsContext.getPrefix(prefix);
/* 127 */     if (p.length() == 0) {
/* 128 */       qname = localName;
/*     */     } else {
/* 130 */       qname = p + ":" + p;
/* 131 */     }  return qname;
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(String value, boolean needsSP) throws IOException, SAXException, XMLStreamException {
/* 136 */     int vlen = value.length();
/* 137 */     if (this.buf.length <= vlen) {
/* 138 */       this.buf = new char[Math.max(this.buf.length * 2, vlen + 1)];
/*     */     }
/* 140 */     if (needsSP) {
/* 141 */       value.getChars(0, vlen, this.buf, 1);
/* 142 */       this.buf[0] = ' ';
/*     */     } else {
/* 144 */       value.getChars(0, vlen, this.buf, 0);
/*     */     } 
/* 146 */     this.out.characters(this.buf, 0, vlen + (needsSP ? 1 : 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needsSP) throws IOException, SAXException, XMLStreamException {
/* 151 */     int vlen = value.length();
/* 152 */     if (this.buf.length <= vlen) {
/* 153 */       this.buf = new char[Math.max(this.buf.length * 2, vlen + 1)];
/*     */     }
/* 155 */     if (needsSP) {
/* 156 */       value.writeTo(this.buf, 1);
/* 157 */       this.buf[0] = ' ';
/*     */     } else {
/* 159 */       value.writeTo(this.buf, 0);
/*     */     } 
/* 161 */     this.out.characters(this.buf, 0, vlen + (needsSP ? 1 : 0));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\SAXOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */