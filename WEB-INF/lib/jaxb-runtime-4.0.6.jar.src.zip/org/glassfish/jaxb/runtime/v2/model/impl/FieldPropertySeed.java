/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FieldPropertySeed<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   implements PropertySeed<TypeT, ClassDeclT, FieldT, MethodT>
/*    */ {
/*    */   protected final FieldT field;
/*    */   private ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> parent;
/*    */   
/*    */   FieldPropertySeed(ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> classInfo, FieldT field) {
/* 29 */     this.parent = classInfo;
/* 30 */     this.field = field;
/*    */   }
/*    */ 
/*    */   
/*    */   public <A extends Annotation> A readAnnotation(Class<A> a) {
/* 35 */     return (A)this.parent.reader().getFieldAnnotation(a, this.field, this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasAnnotation(Class<? extends Annotation> annotationType) {
/* 40 */     return this.parent.reader().hasFieldAnnotation(annotationType, this.field);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 47 */     return this.parent.nav().getFieldName(this.field);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeT getRawType() {
/* 52 */     return (TypeT)this.parent.nav().getFieldType(this.field);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 60 */     return this.parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 65 */     return this.parent.nav().getFieldLocation(this.field);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\FieldPropertySeed.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */