/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAnyElement;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlAnyElementQuick
/*    */   extends Quick
/*    */   implements XmlAnyElement
/*    */ {
/*    */   private final XmlAnyElement core;
/*    */   
/*    */   public XmlAnyElementQuick(Locatable upstream, XmlAnyElement core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlAnyElementQuick(upstream, (XmlAnyElement)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlAnyElement> annotationType() {
/* 47 */     return XmlAnyElement.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean lax() {
/* 52 */     return this.core.lax();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class value() {
/* 57 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlAnyElementQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */