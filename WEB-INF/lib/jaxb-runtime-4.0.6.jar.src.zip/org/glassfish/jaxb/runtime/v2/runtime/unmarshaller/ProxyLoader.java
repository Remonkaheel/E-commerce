/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ProxyLoader
/*    */   extends Loader
/*    */ {
/*    */   public ProxyLoader() {
/* 23 */     super(false);
/*    */   }
/*    */ 
/*    */   
/*    */   public final void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 28 */     Loader loader = selectLoader(state, ea);
/* 29 */     state.setLoader(loader);
/* 30 */     loader.startElement(state, ea);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Loader selectLoader(UnmarshallingContext.State paramState, TagName paramTagName) throws SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void leaveElement(UnmarshallingContext.State state, TagName ea) {
/* 44 */     throw new IllegalStateException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\ProxyLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */