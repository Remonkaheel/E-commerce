/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerFloat<BeanT>
/*    */   extends Lister<BeanT, float[], Float, PrimitiveArrayListerFloat.FloatArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     Lister.primitiveArrayListers.put(float.class, new PrimitiveArrayListerFloat());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Float> iterator(final float[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Float>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Float next() {
/* 47 */           return Float.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public FloatArrayPack startPacking(BeanT current, Accessor<BeanT, float[]> acc) {
/* 54 */     return new FloatArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(FloatArrayPack objects, Float o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(FloatArrayPack pack, BeanT bean, Accessor<BeanT, float[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, float[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new float[0]);
/*    */   }
/*    */   
/*    */   static final class FloatArrayPack {
/* 73 */     float[] buf = new float[16];
/*    */     int size;
/*    */     
/*    */     void add(Float b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         float[] nb = new float[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.floatValue(); 
/*    */     }
/*    */     
/*    */     float[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       float[] r = new float[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerFloat.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */