/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapters;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlJavaTypeAdaptersQuick
/*    */   extends Quick
/*    */   implements XmlJavaTypeAdapters
/*    */ {
/*    */   private final XmlJavaTypeAdapters core;
/*    */   
/*    */   public XmlJavaTypeAdaptersQuick(Locatable upstream, XmlJavaTypeAdapters core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlJavaTypeAdaptersQuick(upstream, (XmlJavaTypeAdapters)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlJavaTypeAdapters> annotationType() {
/* 48 */     return XmlJavaTypeAdapters.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlJavaTypeAdapter[] value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlJavaTypeAdaptersQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */