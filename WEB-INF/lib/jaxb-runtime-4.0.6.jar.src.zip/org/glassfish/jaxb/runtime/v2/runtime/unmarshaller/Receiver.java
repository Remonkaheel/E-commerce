package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;

import org.xml.sax.SAXException;

public interface Receiver {
  void receive(UnmarshallingContext.State paramState, Object paramObject) throws SAXException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Receiver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */