/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Quick
/*    */   implements Annotation, Locatable, Location
/*    */ {
/*    */   private final Locatable upstream;
/*    */   
/*    */   protected Quick(Locatable upstream) {
/* 31 */     this.upstream = upstream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Annotation getAnnotation();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract Quick newInstance(Locatable paramLocatable, Annotation paramAnnotation);
/*    */ 
/*    */ 
/*    */   
/*    */   public final Location getLocation() {
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Locatable getUpstream() {
/* 52 */     return this.upstream;
/*    */   }
/*    */ 
/*    */   
/*    */   public final String toString() {
/* 57 */     return getAnnotation().toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\Quick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */