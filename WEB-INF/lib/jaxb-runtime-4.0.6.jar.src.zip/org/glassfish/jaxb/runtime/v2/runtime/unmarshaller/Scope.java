/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Lister;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Scope<BeanT, PropT, ItemT, PackT>
/*     */ {
/*     */   public final UnmarshallingContext context;
/*     */   private BeanT bean;
/*     */   private Accessor<BeanT, PropT> acc;
/*     */   private PackT pack;
/*     */   private Lister<BeanT, PropT, ItemT, PackT> lister;
/*     */   
/*     */   Scope(UnmarshallingContext context) {
/*  36 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasStarted() {
/*  43 */     return (this.bean != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  50 */     if (this.bean == null) {
/*     */       
/*  52 */       assert clean();
/*     */       
/*     */       return;
/*     */     } 
/*  56 */     this.bean = null;
/*  57 */     this.acc = null;
/*  58 */     this.pack = null;
/*  59 */     this.lister = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finish() throws AccessorException {
/*  67 */     if (hasStarted()) {
/*  68 */       this.lister.endPacking(this.pack, this.bean, this.acc);
/*  69 */       reset();
/*     */     } 
/*  71 */     assert clean();
/*     */   }
/*     */   
/*     */   private boolean clean() {
/*  75 */     return (this.bean == null && this.acc == null && this.pack == null && this.lister == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Accessor<BeanT, PropT> acc, Lister<BeanT, PropT, ItemT, PackT> lister, ItemT value) throws SAXException {
/*     */     try {
/*  83 */       if (!hasStarted()) {
/*  84 */         this.bean = (BeanT)this.context.getCurrentState().getTarget();
/*  85 */         this.acc = acc;
/*  86 */         this.lister = lister;
/*  87 */         this.pack = (PackT)lister.startPacking(this.bean, acc);
/*     */       } 
/*     */       
/*  90 */       lister.addToPack(this.pack, value);
/*  91 */     } catch (AccessorException e) {
/*  92 */       Loader.handleGenericException((Exception)e, true);
/*     */       
/*  94 */       this.lister = Lister.getErrorInstance();
/*  95 */       this.acc = Accessor.getErrorInstance();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(Accessor<BeanT, PropT> acc, Lister<BeanT, PropT, ItemT, PackT> lister) throws SAXException {
/*     */     try {
/* 107 */       if (!hasStarted()) {
/* 108 */         this.bean = (BeanT)this.context.getCurrentState().getTarget();
/* 109 */         this.acc = acc;
/* 110 */         this.lister = lister;
/* 111 */         this.pack = (PackT)lister.startPacking(this.bean, acc);
/*     */       } 
/* 113 */     } catch (AccessorException e) {
/* 114 */       Loader.handleGenericException((Exception)e, true);
/*     */       
/* 116 */       this.lister = Lister.getErrorInstance();
/* 117 */       this.acc = Accessor.getErrorInstance();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Scope.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */