/*      */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*      */ import com.sun.xml.txw2.TxwException;
/*      */ import com.sun.xml.txw2.TypedXmlWriter;
/*      */ import jakarta.activation.MimeType;
/*      */ import jakarta.xml.bind.SchemaOutputResolver;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.logging.Level;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.transform.Result;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.glassfish.jaxb.core.api.ErrorListener;
/*      */ import org.glassfish.jaxb.core.v2.TODO;
/*      */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ArrayInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.AttributePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.EnumLeafInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*      */ import org.glassfish.jaxb.core.v2.model.core.MapPropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*      */ import org.glassfish.jaxb.core.v2.model.core.NonElementRef;
/*      */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ReferencePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;
/*      */ import org.glassfish.jaxb.core.v2.model.core.TypeRef;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ValuePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.WildcardMode;
/*      */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*      */ import org.glassfish.jaxb.core.v2.schemagen.episode.Bindings;
/*      */ import org.glassfish.jaxb.runtime.v2.model.impl.ClassInfoImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Any;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.AttrDecls;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.AttributeType;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ComplexExtension;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ComplexType;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ComplexTypeHost;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ContentModelContainer;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ExplicitGroup;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Import;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.List;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.LocalAttribute;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.LocalElement;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Occurs;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Schema;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.SimpleExtension;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.SimpleRestriction;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.SimpleType;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.SimpleTypeHost;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.TopLevelAttribute;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.TopLevelElement;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.TypeDefParticle;
/*      */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.TypeHost;
/*      */ import org.glassfish.jaxb.runtime.v2.util.CollisionCheckStack;
/*      */ 
/*      */ public final class XmlSchemaGenerator<T, C, F, M> {
/*   72 */   private static final Logger logger = Utils.getClassLogger();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   private final Map<String, Namespace> namespaces = new TreeMap<>(NAMESPACE_COMPARATOR);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ErrorListener errorListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private Navigator<T, C, F, M> navigator;
/*      */ 
/*      */ 
/*      */   
/*      */   private final TypeInfoSet<T, C, F, M> types;
/*      */ 
/*      */ 
/*      */   
/*      */   private final NonElement<T, C> stringType;
/*      */ 
/*      */ 
/*      */   
/*      */   private final NonElement<T, C> anyType;
/*      */ 
/*      */ 
/*      */   
/*  108 */   private final CollisionCheckStack<ClassInfo<T, C>> collisionChecker = new CollisionCheckStack();
/*      */   
/*      */   public XmlSchemaGenerator(Navigator<T, C, F, M> navigator, TypeInfoSet<T, C, F, M> types) {
/*  111 */     this.navigator = navigator;
/*  112 */     this.types = types;
/*      */     
/*  114 */     this.stringType = types.getTypeInfo(navigator.ref(String.class));
/*  115 */     this.anyType = types.getAnyTypeInfo();
/*      */ 
/*      */     
/*  118 */     for (ClassInfo<T, C> ci : (Iterable<ClassInfo<T, C>>)types.beans().values())
/*  119 */       add(ci); 
/*  120 */     for (ElementInfo<T, C> ei1 : (Iterable<ElementInfo<T, C>>)types.getElementMappings(null).values())
/*  121 */       add(ei1); 
/*  122 */     for (EnumLeafInfo<T, C> ei : (Iterable<EnumLeafInfo<T, C>>)types.enums().values())
/*  123 */       add(ei); 
/*  124 */     for (ArrayInfo<T, C> a : (Iterable<ArrayInfo<T, C>>)types.arrays().values())
/*  125 */       add(a); 
/*      */   }
/*      */   
/*      */   private Namespace getNamespace(String uri) {
/*  129 */     Namespace n = this.namespaces.get(uri);
/*  130 */     if (n == null)
/*  131 */       this.namespaces.put(uri, n = new Namespace(this, uri)); 
/*  132 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(ClassInfo<T, C> clazz) {
/*  144 */     assert clazz != null;
/*      */     
/*  146 */     String nsUri = null;
/*      */     
/*  148 */     if (clazz.getClazz() == this.navigator.asDecl(CompositeStructure.class)) {
/*      */       return;
/*      */     }
/*  151 */     if (clazz.isElement()) {
/*      */       
/*  153 */       nsUri = clazz.getElementName().getNamespaceURI();
/*  154 */       Namespace ns = getNamespace(nsUri);
/*  155 */       ns.classes.add(clazz);
/*  156 */       ns.addDependencyTo(clazz.getTypeName());
/*      */ 
/*      */       
/*  159 */       add(clazz.getElementName(), false, (NonElement<T, C>)clazz);
/*      */     } 
/*      */     
/*  162 */     QName tn = clazz.getTypeName();
/*  163 */     if (tn != null) {
/*  164 */       nsUri = tn.getNamespaceURI();
/*      */     
/*      */     }
/*  167 */     else if (nsUri == null) {
/*      */       return;
/*      */     } 
/*      */     
/*  171 */     Namespace n = getNamespace(nsUri);
/*  172 */     n.classes.add(clazz);
/*      */ 
/*      */     
/*  175 */     for (PropertyInfo<T, C> p : (Iterable<PropertyInfo<T, C>>)clazz.getProperties()) {
/*  176 */       n.processForeignNamespaces(p, 1);
/*  177 */       if (p instanceof AttributePropertyInfo) {
/*  178 */         AttributePropertyInfo<T, C> ap = (AttributePropertyInfo<T, C>)p;
/*  179 */         String aUri = ap.getXmlName().getNamespaceURI();
/*  180 */         if (aUri.length() > 0) {
/*      */           
/*  182 */           getNamespace(aUri).addGlobalAttribute(ap);
/*  183 */           n.addDependencyTo(ap.getXmlName());
/*      */         } 
/*      */       } 
/*  186 */       if (p instanceof ElementPropertyInfo) {
/*  187 */         ElementPropertyInfo<T, C> ep = (ElementPropertyInfo<T, C>)p;
/*  188 */         for (TypeRef<T, C> tref : (Iterable<TypeRef<T, C>>)ep.getTypes()) {
/*  189 */           String eUri = tref.getTagName().getNamespaceURI();
/*  190 */           if (eUri.length() > 0 && !eUri.equals(n.uri)) {
/*  191 */             getNamespace(eUri).addGlobalElement(tref);
/*  192 */             n.addDependencyTo(tref.getTagName());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  197 */       if (generateSwaRefAdapter(p)) {
/*  198 */         n.useSwaRef = true;
/*      */       }
/*  200 */       MimeType mimeType = p.getExpectedMimeType();
/*  201 */       if (mimeType != null) {
/*  202 */         n.useMimeNs = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  208 */     ClassInfo<T, C> bc = clazz.getBaseClass();
/*  209 */     if (bc != null) {
/*  210 */       add(bc);
/*  211 */       n.addDependencyTo(bc.getTypeName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(ElementInfo<T, C> elem) {
/*      */     ElementInfo ei;
/*  219 */     assert elem != null;
/*      */ 
/*      */     
/*  222 */     boolean nillable = false;
/*      */     
/*  224 */     QName name = elem.getElementName();
/*  225 */     Namespace n = getNamespace(name.getNamespaceURI());
/*      */ 
/*      */     
/*  228 */     if (elem.getScope() != null) {
/*  229 */       ei = this.types.getElementInfo(elem.getScope().getClazz(), name);
/*      */     } else {
/*  231 */       ei = this.types.getElementInfo(null, name);
/*      */     } 
/*      */     
/*  234 */     XmlElement xmlElem = (XmlElement)ei.getProperty().readAnnotation(XmlElement.class);
/*      */     
/*  236 */     if (xmlElem == null) {
/*  237 */       nillable = false;
/*      */     } else {
/*  239 */       nillable = xmlElem.nillable();
/*      */     } 
/*      */     
/*  242 */     Objects.requireNonNull(n); n.elementDecls.put(name.getLocalPart(), new Namespace.ElementWithType(nillable, elem.getContentType()));
/*      */ 
/*      */     
/*  245 */     n.processForeignNamespaces((PropertyInfo<T, C>)elem.getProperty(), 1);
/*      */   }
/*      */   
/*      */   public void add(EnumLeafInfo<T, C> envm) {
/*  249 */     assert envm != null;
/*      */     
/*  251 */     String nsUri = null;
/*      */     
/*  253 */     if (envm.isElement()) {
/*      */       
/*  255 */       nsUri = envm.getElementName().getNamespaceURI();
/*  256 */       Namespace ns = getNamespace(nsUri);
/*  257 */       ns.enums.add(envm);
/*  258 */       ns.addDependencyTo(envm.getTypeName());
/*      */ 
/*      */       
/*  261 */       add(envm.getElementName(), false, (NonElement<T, C>)envm);
/*      */     } 
/*      */     
/*  264 */     QName typeName = envm.getTypeName();
/*  265 */     if (typeName != null) {
/*  266 */       nsUri = typeName.getNamespaceURI();
/*      */     }
/*  268 */     else if (nsUri == null) {
/*      */       return;
/*      */     } 
/*      */     
/*  272 */     Namespace n = getNamespace(nsUri);
/*  273 */     n.enums.add(envm);
/*      */ 
/*      */     
/*  276 */     n.addDependencyTo(envm.getBaseType().getTypeName());
/*      */   }
/*      */   
/*      */   public void add(ArrayInfo<T, C> a) {
/*  280 */     assert a != null;
/*      */     
/*  282 */     String namespaceURI = a.getTypeName().getNamespaceURI();
/*  283 */     Namespace n = getNamespace(namespaceURI);
/*  284 */     n.arrays.add(a);
/*      */ 
/*      */     
/*  287 */     n.addDependencyTo(a.getItemType().getTypeName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(QName tagName, boolean isNillable, NonElement<T, C> type) {
/*  301 */     if (type != null && type.getType() == this.navigator.ref(CompositeStructure.class)) {
/*      */       return;
/*      */     }
/*      */     
/*  305 */     Namespace n = getNamespace(tagName.getNamespaceURI());
/*  306 */     Objects.requireNonNull(n); n.elementDecls.put(tagName.getLocalPart(), new Namespace.ElementWithType(isNillable, type));
/*      */ 
/*      */     
/*  309 */     if (type != null) {
/*  310 */       n.addDependencyTo(type.getTypeName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEpisodeFile(XmlSerializer out) {
/*  317 */     Bindings root = (Bindings)TXW.create(Bindings.class, out);
/*      */     
/*  319 */     if (this.namespaces.containsKey(""))
/*  320 */       root._namespace("https://jakarta.ee/xml/ns/jaxb", "jaxb"); 
/*  321 */     root.version("2.1");
/*      */ 
/*      */ 
/*      */     
/*  325 */     for (Map.Entry<String, Namespace> e : this.namespaces.entrySet()) {
/*  326 */       String prefix; Bindings group = root.bindings();
/*      */ 
/*      */       
/*  329 */       String tns = e.getKey();
/*  330 */       if (!tns.equals("")) {
/*  331 */         group._namespace(tns, "tns");
/*  332 */         prefix = "tns:";
/*      */       } else {
/*  334 */         prefix = "";
/*      */       } 
/*      */       
/*  337 */       group.scd("x-schema::" + (tns.equals("") ? "" : "tns"));
/*  338 */       group.schemaBindings().map(false);
/*      */       
/*  340 */       for (ClassInfo<T, C> ci : ((Namespace)e.getValue()).classes) {
/*  341 */         if (ci.getTypeName() == null)
/*      */           continue; 
/*  343 */         if (ci.getTypeName().getNamespaceURI().equals(tns)) {
/*  344 */           Bindings child = group.bindings();
/*  345 */           child.scd("~" + prefix + ci.getTypeName().getLocalPart());
/*  346 */           child.klass().ref(ci.getName());
/*      */         } 
/*      */         
/*  349 */         if (ci.isElement() && ci.getElementName().getNamespaceURI().equals(tns)) {
/*  350 */           Bindings child = group.bindings();
/*  351 */           child.scd(prefix + prefix);
/*  352 */           child.klass().ref(ci.getName());
/*      */         } 
/*      */       } 
/*      */       
/*  356 */       for (EnumLeafInfo<T, C> en : ((Namespace)e.getValue()).enums) {
/*  357 */         if (en.getTypeName() == null)
/*      */           continue; 
/*  359 */         Bindings child = group.bindings();
/*  360 */         child.scd("~" + prefix + en.getTypeName().getLocalPart());
/*  361 */         child.klass().ref(this.navigator.getClassName(en.getClazz()));
/*      */       } 
/*      */       
/*  364 */       group.commit(true);
/*      */     } 
/*      */     
/*  367 */     root.commit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(SchemaOutputResolver resolver, ErrorListener errorListener) throws IOException {
/*  374 */     if (resolver == null) {
/*  375 */       throw new IllegalArgumentException();
/*      */     }
/*  377 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/*  379 */       logger.log(Level.FINE, "Writing XML Schema for " + this, (Throwable)new StackRecorder());
/*      */     }
/*      */ 
/*      */     
/*  383 */     resolver = new FoolProofResolver(resolver);
/*  384 */     this.errorListener = errorListener;
/*      */     
/*  386 */     Map<String, String> schemaLocations = this.types.getSchemaLocations();
/*      */     
/*  388 */     Map<Namespace, Result> out = new HashMap<>();
/*  389 */     Map<Namespace, String> systemIds = new HashMap<>();
/*      */ 
/*      */ 
/*      */     
/*  393 */     this.namespaces.remove("http://www.w3.org/2001/XMLSchema");
/*      */ 
/*      */ 
/*      */     
/*  397 */     for (Namespace n : this.namespaces.values()) {
/*  398 */       String schemaLocation = schemaLocations.get(n.uri);
/*  399 */       if (schemaLocation != null) {
/*  400 */         systemIds.put(n, schemaLocation); continue;
/*      */       } 
/*  402 */       Result output = resolver.createOutput(n.uri, "schema" + out.size() + 1 + ".xsd");
/*  403 */       if (output != null) {
/*  404 */         out.put(n, output);
/*  405 */         systemIds.put(n, output.getSystemId());
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  411 */     for (Map.Entry<Namespace, Result> e : out.entrySet()) {
/*  412 */       Result result = e.getValue();
/*  413 */       ((Namespace)e.getKey()).writeTo(result, systemIds);
/*  414 */       if (result instanceof StreamResult) {
/*  415 */         OutputStream outputStream = ((StreamResult)result).getOutputStream();
/*  416 */         if (outputStream != null) {
/*  417 */           outputStream.close(); continue;
/*      */         } 
/*  419 */         Writer writer = ((StreamResult)result).getWriter();
/*  420 */         if (writer != null) writer.close();
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class Namespace
/*      */   {
/*      */     @NotNull
/*      */     final String uri;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Set<Namespace> depends;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean selfReference;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Set<ClassInfo<T, C>> classes;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Set<EnumLeafInfo<T, C>> enums;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Set<ArrayInfo<T, C>> arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MultiMap<String, AttributePropertyInfo<T, C>> attributeDecls;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MultiMap<String, ElementDeclaration> elementDecls;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Form attributeFormDefault;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Form elementFormDefault;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean useSwaRef;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean useMimeNs;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Namespace(XmlSchemaGenerator this$0, String uri) {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: aload_1
/*      */       //   2: putfield this$0 : Lorg/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator;
/*      */       //   5: aload_0
/*      */       //   6: invokespecial <init> : ()V
/*      */       //   9: aload_0
/*      */       //   10: new java/util/LinkedHashSet
/*      */       //   13: dup
/*      */       //   14: invokespecial <init> : ()V
/*      */       //   17: putfield depends : Ljava/util/Set;
/*      */       //   20: aload_0
/*      */       //   21: new java/util/LinkedHashSet
/*      */       //   24: dup
/*      */       //   25: invokespecial <init> : ()V
/*      */       //   28: putfield classes : Ljava/util/Set;
/*      */       //   31: aload_0
/*      */       //   32: new java/util/LinkedHashSet
/*      */       //   35: dup
/*      */       //   36: invokespecial <init> : ()V
/*      */       //   39: putfield enums : Ljava/util/Set;
/*      */       //   42: aload_0
/*      */       //   43: new java/util/LinkedHashSet
/*      */       //   46: dup
/*      */       //   47: invokespecial <init> : ()V
/*      */       //   50: putfield arrays : Ljava/util/Set;
/*      */       //   53: aload_0
/*      */       //   54: new org/glassfish/jaxb/runtime/v2/schemagen/MultiMap
/*      */       //   57: dup
/*      */       //   58: aconst_null
/*      */       //   59: invokespecial <init> : (Ljava/lang/Object;)V
/*      */       //   62: putfield attributeDecls : Lorg/glassfish/jaxb/runtime/v2/schemagen/MultiMap;
/*      */       //   65: aload_0
/*      */       //   66: new org/glassfish/jaxb/runtime/v2/schemagen/MultiMap
/*      */       //   69: dup
/*      */       //   70: new org/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator$Namespace$ElementWithType
/*      */       //   73: dup
/*      */       //   74: aload_0
/*      */       //   75: iconst_1
/*      */       //   76: aload_0
/*      */       //   77: getfield this$0 : Lorg/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator;
/*      */       //   80: getfield anyType : Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*      */       //   83: invokespecial <init> : (Lorg/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator$Namespace;ZLorg/glassfish/jaxb/core/v2/model/core/NonElement;)V
/*      */       //   86: invokespecial <init> : (Ljava/lang/Object;)V
/*      */       //   89: putfield elementDecls : Lorg/glassfish/jaxb/runtime/v2/schemagen/MultiMap;
/*      */       //   92: aload_0
/*      */       //   93: aload_2
/*      */       //   94: putfield uri : Ljava/lang/String;
/*      */       //   97: getstatic org/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator$Namespace.$assertionsDisabled : Z
/*      */       //   100: ifne -> 124
/*      */       //   103: aload_1
/*      */       //   104: getfield namespaces : Ljava/util/Map;
/*      */       //   107: aload_2
/*      */       //   108: invokeinterface containsKey : (Ljava/lang/Object;)Z
/*      */       //   113: ifeq -> 124
/*      */       //   116: new java/lang/AssertionError
/*      */       //   119: dup
/*      */       //   120: invokespecial <init> : ()V
/*      */       //   123: athrow
/*      */       //   124: aload_1
/*      */       //   125: getfield namespaces : Ljava/util/Map;
/*      */       //   128: aload_2
/*      */       //   129: aload_0
/*      */       //   130: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */       //   135: pop
/*      */       //   136: return
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #485	-> 0
/*      */       //   #437	-> 9
/*      */       //   #447	-> 20
/*      */       //   #452	-> 31
/*      */       //   #457	-> 42
/*      */       //   #462	-> 53
/*      */       //   #467	-> 65
/*      */       //   #486	-> 92
/*      */       //   #487	-> 97
/*      */       //   #488	-> 124
/*      */       //   #489	-> 136
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	137	0	this	Lorg/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator$Namespace;
/*      */       //   0	137	2	uri	Ljava/lang/String;
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	137	0	this	Lorg/glassfish/jaxb/runtime/v2/schemagen/XmlSchemaGenerator<TT;TC;TF;TM;>.Namespace;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void processForeignNamespaces(PropertyInfo<T, C> p, int processingDepth) {
/*  500 */       for (TypeInfo<T, C> t : (Iterable<TypeInfo<T, C>>)p.ref()) {
/*  501 */         if (t instanceof ClassInfo && processingDepth > 0) {
/*  502 */           List<PropertyInfo> l = ((ClassInfo)t).getProperties();
/*  503 */           for (PropertyInfo<T, C> subp : l) {
/*  504 */             processForeignNamespaces(subp, --processingDepth);
/*      */           }
/*      */         } 
/*  507 */         if (t instanceof Element) {
/*  508 */           addDependencyTo(((Element)t).getElementName());
/*      */         }
/*  510 */         if (t instanceof NonElement) {
/*  511 */           addDependencyTo(((NonElement)t).getTypeName());
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void addDependencyTo(@Nullable QName qname) {
/*  520 */       if (qname == null) {
/*      */         return;
/*      */       }
/*      */       
/*  524 */       String nsUri = qname.getNamespaceURI();
/*      */       
/*  526 */       if ("http://www.w3.org/2001/XMLSchema".equals(nsUri)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  531 */       if (nsUri.equals(this.uri)) {
/*  532 */         this.selfReference = true;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  537 */       this.depends.add(this.this$0.getNamespace(nsUri));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeTo(Result result, Map<Namespace, String> systemIds) throws IOException {
/*      */       try {
/*  548 */         Schema schema = (Schema)TXW.create(Schema.class, ResultFactory.createSerializer(result));
/*      */ 
/*      */         
/*  551 */         Map<String, String> xmlNs = this.this$0.types.getXmlNs(this.uri);
/*      */         
/*  553 */         for (Map.Entry<String, String> e : xmlNs.entrySet()) {
/*  554 */           schema._namespace(e.getValue(), e.getKey());
/*      */         }
/*      */         
/*  557 */         if (this.useSwaRef) {
/*  558 */           schema._namespace("http://ws-i.org/profiles/basic/1.1/xsd", "swaRef");
/*      */         }
/*  560 */         if (this.useMimeNs) {
/*  561 */           schema._namespace("http://www.w3.org/2005/05/xmlmime", "xmime");
/*      */         }
/*  563 */         this.attributeFormDefault = Form.get(this.this$0.types.getAttributeFormDefault(this.uri));
/*  564 */         this.attributeFormDefault.declare("attributeFormDefault", schema);
/*      */         
/*  566 */         this.elementFormDefault = Form.get(this.this$0.types.getElementFormDefault(this.uri));
/*      */         
/*  568 */         this.elementFormDefault.declare("elementFormDefault", schema);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  573 */         if (!xmlNs.containsValue("http://www.w3.org/2001/XMLSchema") && 
/*  574 */           !xmlNs.containsKey("xs"))
/*  575 */           schema._namespace("http://www.w3.org/2001/XMLSchema", "xs"); 
/*  576 */         schema.version("1.0");
/*      */         
/*  578 */         if (this.uri.length() != 0) {
/*  579 */           schema.targetNamespace(this.uri);
/*      */         }
/*      */ 
/*      */         
/*  583 */         for (Namespace ns : this.depends) {
/*  584 */           schema._namespace(ns.uri);
/*      */         }
/*      */         
/*  587 */         if (this.selfReference && this.uri.length() != 0)
/*      */         {
/*      */           
/*  590 */           schema._namespace(this.uri, "tns");
/*      */         }
/*      */         
/*  593 */         schema._pcdata("\n");
/*      */ 
/*      */         
/*  596 */         for (Namespace n : this.depends) {
/*  597 */           Import imp = schema._import();
/*  598 */           if (n.uri.length() != 0)
/*  599 */             imp.namespace(n.uri); 
/*  600 */           String refSystemId = systemIds.get(n);
/*  601 */           if (refSystemId != null && !refSystemId.equals(""))
/*      */           {
/*  603 */             imp.schemaLocation(XmlSchemaGenerator.relativize(refSystemId, result.getSystemId()));
/*      */           }
/*  605 */           schema._pcdata("\n");
/*      */         } 
/*  607 */         if (this.useSwaRef) {
/*  608 */           schema._import().namespace("http://ws-i.org/profiles/basic/1.1/xsd").schemaLocation("http://ws-i.org/profiles/basic/1.1/swaref.xsd");
/*      */         }
/*  610 */         if (this.useMimeNs) {
/*  611 */           schema._import().namespace("http://www.w3.org/2005/05/xmlmime").schemaLocation("https://www.w3.org/2005/05/xmlmime");
/*      */         }
/*      */ 
/*      */         
/*  615 */         for (Map.Entry<String, ElementDeclaration> e : this.elementDecls.entrySet()) {
/*  616 */           ((ElementDeclaration)e.getValue()).writeTo(e.getKey(), schema);
/*  617 */           schema._pcdata("\n");
/*      */         } 
/*  619 */         for (ClassInfo<T, C> c : this.classes) {
/*  620 */           if (c.getTypeName() == null) {
/*      */             continue;
/*      */           }
/*      */           
/*  624 */           if (this.uri.equals(c.getTypeName().getNamespaceURI()))
/*  625 */             writeClass(c, (TypeHost)schema); 
/*  626 */           schema._pcdata("\n");
/*      */         } 
/*  628 */         for (EnumLeafInfo<T, C> e : this.enums) {
/*  629 */           if (e.getTypeName() == null) {
/*      */             continue;
/*      */           }
/*      */           
/*  633 */           if (this.uri.equals(e.getTypeName().getNamespaceURI()))
/*  634 */             writeEnum(e, (SimpleTypeHost)schema); 
/*  635 */           schema._pcdata("\n");
/*      */         } 
/*  637 */         for (ArrayInfo<T, C> a : this.arrays) {
/*  638 */           writeArray(a, schema);
/*  639 */           schema._pcdata("\n");
/*      */         } 
/*  641 */         for (Map.Entry<String, AttributePropertyInfo<T, C>> e : this.attributeDecls.entrySet()) {
/*  642 */           TopLevelAttribute a = schema.attribute();
/*  643 */           a.name(e.getKey());
/*  644 */           if (e.getValue() == null) {
/*  645 */             writeTypeRef((TypeHost)a, this.this$0.stringType, "type");
/*      */           } else {
/*  647 */             writeAttributeTypeRef(e.getValue(), (AttributeType)a);
/*  648 */           }  schema._pcdata("\n");
/*      */         } 
/*      */ 
/*      */         
/*  652 */         schema.commit();
/*  653 */       } catch (TxwException e) {
/*  654 */         XmlSchemaGenerator.logger.log(Level.INFO, e.getMessage(), (Throwable)e);
/*  655 */         throw new IOException(e.getMessage());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeTypeRef(TypeHost th, NonElementRef<T, C> typeRef, String refAttName) {
/*  672 */       switch (typeRef.getSource().id()) {
/*      */         case LAX:
/*  674 */           th._attribute(refAttName, new QName("http://www.w3.org/2001/XMLSchema", "ID"));
/*      */           return;
/*      */         case SKIP:
/*  677 */           th._attribute(refAttName, new QName("http://www.w3.org/2001/XMLSchema", "IDREF"));
/*      */           return;
/*      */         
/*      */         case STRICT:
/*      */           break;
/*      */         default:
/*  683 */           throw new IllegalStateException();
/*      */       } 
/*      */ 
/*      */       
/*  687 */       MimeType mimeType = typeRef.getSource().getExpectedMimeType();
/*  688 */       if (mimeType != null) {
/*  689 */         th._attribute(new QName("http://www.w3.org/2005/05/xmlmime", "expectedContentTypes", "xmime"), mimeType.toString());
/*      */       }
/*      */ 
/*      */       
/*  693 */       if (this.this$0.generateSwaRefAdapter(typeRef)) {
/*  694 */         th._attribute(refAttName, new QName("http://ws-i.org/profiles/basic/1.1/xsd", "swaRef", "ref"));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  699 */       if (typeRef.getSource().getSchemaType() != null) {
/*  700 */         th._attribute(refAttName, typeRef.getSource().getSchemaType());
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  705 */       writeTypeRef(th, typeRef.getTarget(), refAttName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeTypeRef(TypeHost th, NonElement<T, C> type, String refAttName) {
/*  721 */       if (type.getTypeName() == null) {
/*  722 */         th.block();
/*  723 */         if (type instanceof ClassInfo) {
/*  724 */           if (this.this$0.collisionChecker.push(type)) {
/*  725 */             this.this$0.errorListener.warning(new SAXParseException(Messages.ANONYMOUS_TYPE_CYCLE
/*  726 */                   .format(new Object[] { this.this$0.collisionChecker.getCycleString() }, ), null));
/*      */           }
/*      */           else {
/*      */             
/*  730 */             writeClass((ClassInfo<T, C>)type, th);
/*      */           } 
/*  732 */           this.this$0.collisionChecker.pop();
/*      */         } else {
/*  734 */           writeEnum((EnumLeafInfo<T, C>)type, (SimpleTypeHost)th);
/*      */         } 
/*      */       } else {
/*  737 */         th._attribute(refAttName, type.getTypeName());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeArray(ArrayInfo<T, C> a, Schema schema) {
/*  745 */       ComplexType ct = schema.complexType().name(a.getTypeName().getLocalPart());
/*  746 */       ct._final("#all");
/*  747 */       LocalElement le = ct.sequence().element().name("item");
/*  748 */       le.type(a.getItemType().getTypeName());
/*  749 */       le.minOccurs(0).maxOccurs("unbounded");
/*  750 */       le.nillable(true);
/*  751 */       ct.commit();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeEnum(EnumLeafInfo<T, C> e, SimpleTypeHost th) {
/*  758 */       SimpleType st = th.simpleType();
/*  759 */       writeName((NonElement<T, C>)e, (TypedXmlWriter)st);
/*      */       
/*  761 */       SimpleRestriction simpleRestriction = st.restriction();
/*  762 */       writeTypeRef((TypeHost)simpleRestriction, e.getBaseType(), "base");
/*      */       
/*  764 */       for (EnumConstant c : e.getConstants()) {
/*  765 */         simpleRestriction.enumeration().value(c.getLexicalValue());
/*      */       }
/*  767 */       st.commit();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeClass(ClassInfo<T, C> c, TypeHost parent) {
/*      */       ComplexExtension complexExtension1, complexExtension2;
/*  778 */       if (containsValueProp(c)) {
/*  779 */         if (c.getProperties().size() == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  785 */           ValuePropertyInfo<T, C> vp = c.getProperties().get(0);
/*  786 */           SimpleType st = ((SimpleTypeHost)parent).simpleType();
/*  787 */           writeName((NonElement<T, C>)c, (TypedXmlWriter)st);
/*  788 */           if (vp.isCollection()) {
/*  789 */             writeTypeRef((TypeHost)st.list(), vp.getTarget(), "itemType");
/*      */           } else {
/*  791 */             writeTypeRef((TypeHost)st.restriction(), vp.getTarget(), "base");
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  807 */         ComplexType complexType = ((ComplexTypeHost)parent).complexType();
/*  808 */         writeName((NonElement<T, C>)c, (TypedXmlWriter)complexType);
/*  809 */         if (c.isFinal()) {
/*  810 */           complexType._final("extension restriction");
/*      */         }
/*  812 */         SimpleExtension se = complexType.simpleContent().extension();
/*  813 */         se.block();
/*  814 */         for (PropertyInfo<T, C> p : (Iterable<PropertyInfo<T, C>>)c.getProperties()) {
/*  815 */           ValuePropertyInfo vp; switch (p.kind()) {
/*      */             case LAX:
/*  817 */               handleAttributeProp((AttributePropertyInfo<T, C>)p, (AttrDecls)se);
/*      */               continue;
/*      */             case SKIP:
/*  820 */               TODO.checkSpec("what if vp.isCollection() == true?");
/*  821 */               vp = (ValuePropertyInfo)p;
/*  822 */               se.base(vp.getTarget().getTypeName());
/*      */               continue;
/*      */           } 
/*      */ 
/*      */           
/*      */           assert false;
/*  828 */           throw new IllegalStateException();
/*      */         } 
/*      */         
/*  831 */         se.commit();
/*      */         
/*  833 */         TODO.schemaGenerator("figure out what to do if bc != null");
/*  834 */         TODO.checkSpec("handle sec 8.9.5.2, bullet #4");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  844 */       ComplexType ct = ((ComplexTypeHost)parent).complexType();
/*  845 */       writeName((NonElement<T, C>)c, (TypedXmlWriter)ct);
/*  846 */       if (c.isFinal())
/*  847 */         ct._final("extension restriction"); 
/*  848 */       if (c.isAbstract()) {
/*  849 */         ct._abstract(true);
/*      */       }
/*      */       
/*  852 */       ComplexType complexType1 = ct;
/*  853 */       ComplexType complexType2 = ct;
/*      */ 
/*      */       
/*  856 */       ClassInfo<T, C> bc = c.getBaseClass();
/*  857 */       if (bc != null) {
/*  858 */         if (bc.hasValueProperty()) {
/*      */           
/*  860 */           SimpleExtension se = ct.simpleContent().extension();
/*  861 */           SimpleExtension simpleExtension1 = se;
/*  862 */           complexType2 = null;
/*  863 */           se.base(bc.getTypeName());
/*      */         } else {
/*  865 */           ComplexExtension ce = ct.complexContent().extension();
/*  866 */           complexExtension1 = ce;
/*  867 */           complexExtension2 = ce;
/*      */           
/*  869 */           ce.base(bc.getTypeName());
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  874 */       if (complexExtension2 != null) {
/*      */         
/*  876 */         ArrayList<Tree> children = new ArrayList<>();
/*  877 */         for (PropertyInfo<T, C> p : (Iterable<PropertyInfo<T, C>>)c.getProperties()) {
/*      */           
/*  879 */           if (p instanceof ReferencePropertyInfo && ((ReferencePropertyInfo)p).isMixed()) {
/*  880 */             ct.mixed(true);
/*      */           }
/*  882 */           Tree t = buildPropertyContentModel(p);
/*  883 */           if (t != null) {
/*  884 */             children.add(t);
/*      */           }
/*      */         } 
/*  887 */         Tree top = Tree.makeGroup(c.isOrdered() ? GroupKind.SEQUENCE : GroupKind.ALL, children);
/*      */ 
/*      */         
/*  890 */         top.write((TypeDefParticle)complexExtension2);
/*      */       } 
/*      */ 
/*      */       
/*  894 */       for (PropertyInfo<T, C> p : (Iterable<PropertyInfo<T, C>>)c.getProperties()) {
/*  895 */         if (p instanceof AttributePropertyInfo) {
/*  896 */           handleAttributeProp((AttributePropertyInfo<T, C>)p, (AttrDecls)complexExtension1);
/*      */         }
/*      */       } 
/*  899 */       if (c.hasAttributeWildcard()) {
/*  900 */         complexExtension1.anyAttribute().namespace("##other").processContents("skip");
/*      */       }
/*  902 */       ct.commit();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeName(NonElement<T, C> c, TypedXmlWriter xw) {
/*  909 */       QName tn = c.getTypeName();
/*  910 */       if (tn != null)
/*  911 */         xw._attribute("name", tn.getLocalPart()); 
/*      */     }
/*      */     
/*      */     private boolean containsValueProp(ClassInfo<T, C> c) {
/*  915 */       for (PropertyInfo p : c.getProperties()) {
/*  916 */         if (p instanceof ValuePropertyInfo) return true; 
/*      */       } 
/*  918 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tree buildPropertyContentModel(PropertyInfo<T, C> p) {
/*  925 */       switch (p.kind()) {
/*      */         case STRICT:
/*  927 */           return handleElementProp((ElementPropertyInfo<T, C>)p);
/*      */         
/*      */         case LAX:
/*  930 */           return null;
/*      */         case null:
/*  932 */           return handleReferenceProp((ReferencePropertyInfo<T, C>)p);
/*      */         case null:
/*  934 */           return handleMapProp((MapPropertyInfo<T, C>)p);
/*      */         
/*      */         case SKIP:
/*      */           assert false;
/*  938 */           throw new IllegalStateException();
/*      */       } 
/*      */       assert false;
/*  941 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tree handleElementProp(final ElementPropertyInfo<T, C> ep) {
/*  955 */       if (ep.isValueList()) {
/*  956 */         return new Tree.Term()
/*      */           {
/*      */             protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/*  959 */               TypeRef<T, C> t = ep.getTypes().get(0);
/*  960 */               LocalElement e = parent.element();
/*  961 */               e.block();
/*  962 */               QName tn = t.getTagName();
/*  963 */               e.name(tn.getLocalPart());
/*  964 */               List lst = e.simpleType().list();
/*  965 */               XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)lst, (NonElementRef<T, C>)t, "itemType");
/*  966 */               XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, tn);
/*  967 */               writeOccurs((Occurs)e, (isOptional || !ep.isRequired()), repeated);
/*      */             }
/*      */           };
/*      */       }
/*      */       
/*  972 */       ArrayList<Tree> children = new ArrayList<>();
/*  973 */       for (TypeRef<T, C> t : (Iterable<TypeRef<T, C>>)ep.getTypes()) {
/*  974 */         children.add(new Tree.Term()
/*      */             {
/*      */               protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/*  977 */                 LocalElement e = parent.element();
/*      */                 
/*  979 */                 QName tn = t.getTagName();
/*      */                 
/*  981 */                 PropertyInfo propInfo = t.getSource();
/*  982 */                 TypeInfo parentInfo = (propInfo == null) ? null : propInfo.parent();
/*      */                 
/*  984 */                 if (XmlSchemaGenerator.Namespace.this.canBeDirectElementRef(t, tn, parentInfo))
/*  985 */                 { if (!t.getTarget().isSimpleType() && t.getTarget() instanceof ClassInfo && XmlSchemaGenerator.this.collisionChecker.findDuplicate(t.getTarget())) {
/*  986 */                     e.ref(new QName(XmlSchemaGenerator.Namespace.this.uri, tn.getLocalPart()));
/*      */                   } else {
/*      */                     
/*  989 */                     QName elemName = null;
/*  990 */                     if (t.getTarget() instanceof Element) {
/*  991 */                       Element te = (Element)t.getTarget();
/*  992 */                       elemName = te.getElementName();
/*      */                     } 
/*      */                     
/*  995 */                     Collection<TypeInfo> refs = propInfo.ref();
/*  996 */                     if (refs != null && !refs.isEmpty() && elemName != null)
/*  997 */                     { ClassInfoImpl cImpl = null;
/*  998 */                       for (TypeInfo ref : refs) {
/*  999 */                         if ((ref == null || ref instanceof ClassInfoImpl) && 
/* 1000 */                           elemName.equals(((ClassInfoImpl)ref).getElementName())) {
/* 1001 */                           cImpl = (ClassInfoImpl)ref;
/*      */                           
/*      */                           break;
/*      */                         } 
/*      */                       } 
/* 1006 */                       if (cImpl != null) {
/* 1007 */                         if (tn.getNamespaceURI() != null && tn.getNamespaceURI().trim().length() != 0) {
/* 1008 */                           e.ref(new QName(tn.getNamespaceURI(), tn.getLocalPart()));
/*      */                         } else {
/* 1010 */                           e.ref(new QName(cImpl.getElementName().getNamespaceURI(), tn.getLocalPart()));
/*      */                         } 
/*      */                       } else {
/* 1013 */                         e.ref(new QName("", tn.getLocalPart()));
/*      */                       }  }
/* 1015 */                     else { e.ref(tn); }
/*      */                   
/*      */                   }  }
/* 1018 */                 else { e.name(tn.getLocalPart());
/* 1019 */                   XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)e, (NonElementRef<T, C>)t, "type");
/* 1020 */                   XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, tn); }
/*      */ 
/*      */                 
/* 1023 */                 if (t.isNillable()) {
/* 1024 */                   e.nillable(true);
/*      */                 }
/* 1026 */                 if (t.getDefaultValue() != null)
/* 1027 */                   e._default(t.getDefaultValue()); 
/* 1028 */                 writeOccurs((Occurs)e, isOptional, repeated);
/*      */               }
/*      */             });
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1035 */       final Tree choice = Tree.makeGroup(GroupKind.CHOICE, children).makeOptional(!ep.isRequired()).makeRepeated(ep.isCollection());
/*      */ 
/*      */       
/* 1038 */       final QName ename = ep.getXmlName();
/* 1039 */       if (ename != null) {
/* 1040 */         return new Tree.Term()
/*      */           {
/*      */             protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 1043 */               LocalElement e = parent.element();
/* 1044 */               if (ename.getNamespaceURI().length() > 0 && 
/* 1045 */                 !ename.getNamespaceURI().equals(XmlSchemaGenerator.Namespace.this.uri)) {
/*      */ 
/*      */                 
/* 1048 */                 e.ref(new QName(ename.getNamespaceURI(), ename.getLocalPart()));
/*      */                 
/*      */                 return;
/*      */               } 
/* 1052 */               e.name(ename.getLocalPart());
/* 1053 */               XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename);
/*      */               
/* 1055 */               if (ep.isCollectionNillable()) {
/* 1056 */                 e.nillable(true);
/*      */               }
/* 1058 */               writeOccurs((Occurs)e, !ep.isCollectionRequired(), repeated);
/*      */               
/* 1060 */               ComplexType p = e.complexType();
/* 1061 */               choice.write((TypeDefParticle)p);
/*      */             }
/*      */           };
/*      */       }
/* 1065 */       return choice;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean canBeDirectElementRef(TypeRef<T, C> t, QName tn, TypeInfo parentInfo) {
/* 1077 */       Element te = null;
/* 1078 */       ClassInfo ci = null;
/* 1079 */       QName targetTagName = null;
/*      */       
/* 1081 */       if (t.isNillable() || t.getDefaultValue() != null)
/*      */       {
/* 1083 */         return false;
/*      */       }
/*      */       
/* 1086 */       if (t.getTarget() instanceof Element) {
/* 1087 */         te = (Element)t.getTarget();
/* 1088 */         targetTagName = te.getElementName();
/* 1089 */         if (te instanceof ClassInfo) {
/* 1090 */           ci = (ClassInfo)te;
/*      */         }
/*      */       } 
/*      */       
/* 1094 */       String nsUri = tn.getNamespaceURI();
/* 1095 */       if (!nsUri.equals(this.uri) && nsUri.length() > 0 && (!(parentInfo instanceof ClassInfo) || ((ClassInfo)parentInfo).getTypeName() != null)) {
/* 1096 */         return true;
/*      */       }
/*      */       
/* 1099 */       if (ci != null && targetTagName != null && te.getScope() == null && targetTagName.getNamespaceURI() == null && 
/* 1100 */         targetTagName.equals(tn)) {
/* 1101 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1106 */       if (te != null) {
/* 1107 */         return (targetTagName != null && targetTagName.equals(tn));
/*      */       }
/*      */       
/* 1110 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void handleAttributeProp(AttributePropertyInfo<T, C> ap, AttrDecls attr) {
/* 1143 */       LocalAttribute localAttribute = attr.attribute();
/*      */       
/* 1145 */       String attrURI = ap.getXmlName().getNamespaceURI();
/* 1146 */       if (attrURI.equals("")) {
/* 1147 */         localAttribute.name(ap.getXmlName().getLocalPart());
/*      */         
/* 1149 */         writeAttributeTypeRef(ap, (AttributeType)localAttribute);
/*      */         
/* 1151 */         this.attributeFormDefault.writeForm(localAttribute, ap.getXmlName());
/*      */       } else {
/* 1153 */         localAttribute.ref(ap.getXmlName());
/*      */       } 
/*      */       
/* 1156 */       if (ap.isRequired())
/*      */       {
/* 1158 */         localAttribute.use("required");
/*      */       }
/*      */     }
/*      */     
/*      */     private void writeAttributeTypeRef(AttributePropertyInfo<T, C> ap, AttributeType a) {
/* 1163 */       if (ap.isCollection()) {
/* 1164 */         writeTypeRef((TypeHost)a.simpleType().list(), (NonElementRef<T, C>)ap, "itemType");
/*      */       } else {
/* 1166 */         writeTypeRef((TypeHost)a, (NonElementRef<T, C>)ap, "type");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tree handleReferenceProp(final ReferencePropertyInfo<T, C> rp) {
/* 1178 */       ArrayList<Tree> children = new ArrayList<>();
/*      */       
/* 1180 */       for (Element<T, C> e : (Iterable<Element<T, C>>)rp.getElements()) {
/* 1181 */         children.add(new Tree.Term()
/*      */             {
/*      */               protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 1184 */                 LocalElement eref = parent.element();
/*      */                 
/* 1186 */                 boolean local = false;
/*      */                 
/* 1188 */                 QName en = e.getElementName();
/* 1189 */                 if (e.getScope() != null) {
/*      */                   
/* 1191 */                   boolean qualified = en.getNamespaceURI().equals(XmlSchemaGenerator.Namespace.this.uri);
/* 1192 */                   boolean unqualified = en.getNamespaceURI().equals("");
/* 1193 */                   if (qualified || unqualified) {
/*      */ 
/*      */ 
/*      */                     
/* 1197 */                     if (unqualified) {
/* 1198 */                       if (XmlSchemaGenerator.Namespace.this.elementFormDefault.isEffectivelyQualified) {
/* 1199 */                         eref.form("unqualified");
/*      */                       }
/* 1201 */                     } else if (!XmlSchemaGenerator.Namespace.this.elementFormDefault.isEffectivelyQualified) {
/* 1202 */                       eref.form("qualified");
/*      */                     } 
/*      */                     
/* 1205 */                     local = true;
/* 1206 */                     eref.name(en.getLocalPart());
/*      */ 
/*      */                     
/* 1209 */                     if (e instanceof ClassInfo) {
/* 1210 */                       XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)eref, (NonElement<T, C>)e, "type");
/*      */                     } else {
/* 1212 */                       XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)eref, ((ElementInfo)e).getContentType(), "type");
/*      */                     } 
/*      */                   } 
/*      */                 } 
/* 1216 */                 if (!local)
/* 1217 */                   eref.ref(en); 
/* 1218 */                 writeOccurs((Occurs)eref, isOptional, repeated);
/*      */               }
/*      */             });
/*      */       } 
/*      */       
/* 1223 */       final WildcardMode wc = rp.getWildcard();
/* 1224 */       if (wc != null) {
/* 1225 */         children.add(new Tree.Term()
/*      */             {
/*      */               protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 1228 */                 Any any = parent.any();
/* 1229 */                 String pcmode = XmlSchemaGenerator.getProcessContentsModeName(wc);
/* 1230 */                 if (pcmode != null) any.processContents(pcmode); 
/* 1231 */                 any.namespace("##other");
/* 1232 */                 writeOccurs((Occurs)any, isOptional, repeated);
/*      */               }
/*      */             });
/*      */       }
/*      */ 
/*      */       
/* 1238 */       final Tree choice = Tree.makeGroup(GroupKind.CHOICE, children).makeRepeated(rp.isCollection()).makeOptional(!rp.isRequired());
/*      */       
/* 1240 */       final QName ename = rp.getXmlName();
/*      */       
/* 1242 */       if (ename != null) {
/* 1243 */         return new Tree.Term()
/*      */           {
/*      */             protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 1246 */               LocalElement e = parent.element().name(ename.getLocalPart());
/* 1247 */               XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename);
/* 1248 */               if (rp.isCollectionNillable())
/* 1249 */                 e.nillable(true); 
/* 1250 */               writeOccurs((Occurs)e, true, repeated);
/*      */               
/* 1252 */               ComplexType p = e.complexType();
/* 1253 */               choice.write((TypeDefParticle)p);
/*      */             }
/*      */           };
/*      */       }
/* 1257 */       return choice;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tree handleMapProp(final MapPropertyInfo<T, C> mp) {
/* 1268 */       return new Tree.Term()
/*      */         {
/*      */           protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 1271 */             QName ename = mp.getXmlName();
/*      */             
/* 1273 */             LocalElement e = parent.element();
/* 1274 */             XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename);
/* 1275 */             if (mp.isCollectionNillable()) {
/* 1276 */               e.nillable(true);
/*      */             }
/* 1278 */             e = e.name(ename.getLocalPart());
/* 1279 */             writeOccurs((Occurs)e, isOptional, repeated);
/* 1280 */             ComplexType p = e.complexType();
/*      */ 
/*      */ 
/*      */             
/* 1284 */             e = p.sequence().element();
/* 1285 */             e.name("entry").minOccurs(0).maxOccurs("unbounded");
/*      */             
/* 1287 */             ExplicitGroup seq = e.complexType().sequence();
/* 1288 */             XmlSchemaGenerator.Namespace.this.writeKeyOrValue(seq, "key", mp.getKeyType());
/* 1289 */             XmlSchemaGenerator.Namespace.this.writeKeyOrValue(seq, "value", mp.getValueType());
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*      */     private void writeKeyOrValue(ExplicitGroup seq, String tagName, NonElement<T, C> typeRef) {
/* 1295 */       LocalElement key = seq.element().name(tagName);
/* 1296 */       key.minOccurs(0);
/* 1297 */       writeTypeRef((TypeHost)key, typeRef, "type");
/*      */     }
/*      */     
/*      */     public void addGlobalAttribute(AttributePropertyInfo<T, C> ap) {
/* 1301 */       this.attributeDecls.put(ap.getXmlName().getLocalPart(), ap);
/* 1302 */       addDependencyTo(ap.getTarget().getTypeName());
/*      */     }
/*      */     
/*      */     public void addGlobalElement(TypeRef<T, C> tref) {
/* 1306 */       this.elementDecls.put(tref.getTagName().getLocalPart(), new ElementWithType(false, tref.getTarget()));
/* 1307 */       addDependencyTo(tref.getTarget().getTypeName());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1312 */       StringBuilder buf = new StringBuilder();
/* 1313 */       buf.append("[classes=").append(this.classes);
/* 1314 */       buf.append(",elementDecls=").append(this.elementDecls);
/* 1315 */       buf.append(",enums=").append(this.enums);
/* 1316 */       buf.append("]");
/* 1317 */       return buf.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract class ElementDeclaration
/*      */     {
/*      */       public abstract boolean equals(Object param2Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public abstract int hashCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public abstract void writeTo(String param2String, Schema param2Schema);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     class ElementWithType
/*      */       extends ElementDeclaration
/*      */     {
/*      */       private final boolean nillable;
/*      */ 
/*      */ 
/*      */       
/*      */       private final NonElement<T, C> type;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ElementWithType(boolean nillable, NonElement<T, C> type) {
/* 1358 */         this.type = type;
/* 1359 */         this.nillable = nillable;
/*      */       }
/*      */ 
/*      */       
/*      */       public void writeTo(String localName, Schema schema) {
/* 1364 */         TopLevelElement e = schema.element().name(localName);
/* 1365 */         if (this.nillable)
/* 1366 */           e.nillable(true); 
/* 1367 */         if (this.type != null) {
/* 1368 */           XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)e, this.type, "type");
/*      */         } else {
/* 1370 */           e.complexType();
/*      */         } 
/* 1372 */         e.commit();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(Object o) {
/* 1377 */         if (this == o) return true; 
/* 1378 */         if (o == null || getClass() != o.getClass()) return false;
/*      */         
/* 1380 */         ElementWithType that = (ElementWithType)o;
/* 1381 */         return this.type.equals(that.type);
/*      */       }
/*      */       
/*      */       public int hashCode()
/*      */       {
/* 1386 */         return this.type.hashCode(); } } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { TypeRef<T, C> t = ep.getTypes().get(0); LocalElement e = parent.element(); e.block(); QName tn = t.getTagName(); e.name(tn.getLocalPart()); List lst = e.simpleType().list(); XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)lst, (NonElementRef<T, C>)t, "itemType"); XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, tn); writeOccurs((Occurs)e, (isOptional || !ep.isRequired()), repeated); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { LocalElement e = parent.element(); QName tn = t.getTagName(); PropertyInfo propInfo = t.getSource(); TypeInfo parentInfo = (propInfo == null) ? null : propInfo.parent(); if (XmlSchemaGenerator.Namespace.this.canBeDirectElementRef(t, tn, parentInfo)) { if (!t.getTarget().isSimpleType() && t.getTarget() instanceof ClassInfo && XmlSchemaGenerator.this.collisionChecker.findDuplicate(t.getTarget())) { e.ref(new QName(XmlSchemaGenerator.Namespace.this.uri, tn.getLocalPart())); } else { QName elemName = null; if (t.getTarget() instanceof Element) { Element te = (Element)t.getTarget(); elemName = te.getElementName(); }  Collection<TypeInfo> refs = propInfo.ref(); if (refs != null && !refs.isEmpty() && elemName != null) { ClassInfoImpl cImpl = null; for (TypeInfo ref : refs) { if ((ref == null || ref instanceof ClassInfoImpl) && elemName.equals(((ClassInfoImpl)ref).getElementName())) { cImpl = (ClassInfoImpl)ref; break; }  }  if (cImpl != null) { if (tn.getNamespaceURI() != null && tn.getNamespaceURI().trim().length() != 0) { e.ref(new QName(tn.getNamespaceURI(), tn.getLocalPart())); } else { e.ref(new QName(cImpl.getElementName().getNamespaceURI(), tn.getLocalPart())); }  } else { e.ref(new QName("", tn.getLocalPart())); }  } else { e.ref(tn); }  }  } else { e.name(tn.getLocalPart()); XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)e, (NonElementRef<T, C>)t, "type"); XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, tn); }  if (t.isNillable()) e.nillable(true);  if (t.getDefaultValue() != null) e._default(t.getDefaultValue());  writeOccurs((Occurs)e, isOptional, repeated); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { LocalElement e = parent.element(); if (ename.getNamespaceURI().length() > 0 && !ename.getNamespaceURI().equals(XmlSchemaGenerator.Namespace.this.uri)) { e.ref(new QName(ename.getNamespaceURI(), ename.getLocalPart())); return; }  e.name(ename.getLocalPart()); XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename); if (ep.isCollectionNillable()) e.nillable(true);  writeOccurs((Occurs)e, !ep.isCollectionRequired(), repeated); ComplexType p = e.complexType(); choice.write((TypeDefParticle)p); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { LocalElement eref = parent.element(); boolean local = false; QName en = e.getElementName(); if (e.getScope() != null) { boolean qualified = en.getNamespaceURI().equals(XmlSchemaGenerator.Namespace.this.uri); boolean unqualified = en.getNamespaceURI().equals(""); if (qualified || unqualified) { if (unqualified) { if (XmlSchemaGenerator.Namespace.this.elementFormDefault.isEffectivelyQualified) eref.form("unqualified");  } else if (!XmlSchemaGenerator.Namespace.this.elementFormDefault.isEffectivelyQualified) { eref.form("qualified"); }  local = true; eref.name(en.getLocalPart()); if (e instanceof ClassInfo) { XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)eref, (NonElement<T, C>)e, "type"); } else { XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)eref, ((ElementInfo)e).getContentType(), "type"); }  }  }  if (!local) eref.ref(en);  writeOccurs((Occurs)eref, isOptional, repeated); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { Any any = parent.any(); String pcmode = XmlSchemaGenerator.getProcessContentsModeName(wc); if (pcmode != null) any.processContents(pcmode);  any.namespace("##other"); writeOccurs((Occurs)any, isOptional, repeated); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { LocalElement e = parent.element().name(ename.getLocalPart()); XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename); if (rp.isCollectionNillable()) e.nillable(true);  writeOccurs((Occurs)e, true, repeated); ComplexType p = e.complexType(); choice.write((TypeDefParticle)p); } } class null extends Tree.Term { protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) { QName ename = mp.getXmlName(); LocalElement e = parent.element(); XmlSchemaGenerator.Namespace.this.elementFormDefault.writeForm(e, ename); if (mp.isCollectionNillable()) e.nillable(true);  e = e.name(ename.getLocalPart()); writeOccurs((Occurs)e, isOptional, repeated); ComplexType p = e.complexType(); e = p.sequence().element(); e.name("entry").minOccurs(0).maxOccurs("unbounded"); ExplicitGroup seq = e.complexType().sequence(); XmlSchemaGenerator.Namespace.this.writeKeyOrValue(seq, "key", mp.getKeyType()); XmlSchemaGenerator.Namespace.this.writeKeyOrValue(seq, "value", mp.getValueType()); } } abstract class ElementDeclaration { public abstract boolean equals(Object param1Object); public abstract int hashCode(); public abstract void writeTo(String param1String, Schema param1Schema); } class ElementWithType extends Namespace.ElementDeclaration { private final boolean nillable; public int hashCode() { return this.type.hashCode(); }
/*      */     private final NonElement<T, C> type;
/*      */     public ElementWithType(boolean nillable, NonElement<T, C> type) { this.type = type; this.nillable = nillable; } public void writeTo(String localName, Schema schema) { TopLevelElement e = schema.element().name(localName); if (this.nillable)
/*      */         e.nillable(true);  if (this.type != null) { XmlSchemaGenerator.Namespace.this.writeTypeRef((TypeHost)e, this.type, "type"); }
/*      */       else
/*      */       { e.complexType(); }
/*      */        e.commit(); } public boolean equals(Object o) { if (this == o)
/*      */         return true;  if (o == null || getClass() != o.getClass())
/*      */         return false;  ElementWithType that = (ElementWithType)o; return this.type.equals(that.type); } }
/* 1395 */    private boolean generateSwaRefAdapter(NonElementRef<T, C> typeRef) { return generateSwaRefAdapter(typeRef.getSource()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean generateSwaRefAdapter(PropertyInfo<T, C> prop) {
/* 1402 */     Adapter<T, C> adapter = prop.getAdapter();
/* 1403 */     if (adapter == null) return false; 
/* 1404 */     Object o = this.navigator.asDecl(SwaRefAdapter.class);
/* 1405 */     if (o == null) return false; 
/* 1406 */     return o.equals(adapter.adapterType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1414 */     StringBuilder buf = new StringBuilder();
/* 1415 */     for (Namespace ns : this.namespaces.values()) {
/* 1416 */       if (buf.length() > 0) buf.append(','); 
/* 1417 */       buf.append(ns.uri).append('=').append(ns);
/*      */     } 
/* 1419 */     return super.toString() + "[" + super.toString() + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getProcessContentsModeName(WildcardMode wc) {
/* 1428 */     switch (wc) {
/*      */       case LAX:
/*      */       case SKIP:
/* 1431 */         return wc.name().toLowerCase();
/*      */       case STRICT:
/* 1433 */         return null;
/*      */     } 
/* 1435 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String relativize(String uri, String baseUri) {
/*      */     try {
/* 1458 */       assert uri != null;
/*      */       
/* 1460 */       if (baseUri == null) return uri;
/*      */       
/* 1462 */       URI theUri = new URI(Util.escapeURI(uri));
/* 1463 */       URI theBaseUri = new URI(Util.escapeURI(baseUri));
/*      */       
/* 1465 */       if (theUri.isOpaque() || theBaseUri.isOpaque()) {
/* 1466 */         return uri;
/*      */       }
/* 1468 */       if (!Util.equalsIgnoreCase(theUri.getScheme(), theBaseUri.getScheme()) || 
/* 1469 */         !Util.equal(theUri.getAuthority(), theBaseUri.getAuthority())) {
/* 1470 */         return uri;
/*      */       }
/* 1472 */       String uriPath = theUri.getPath();
/* 1473 */       String basePath = theBaseUri.getPath();
/*      */ 
/*      */       
/* 1476 */       if (!basePath.endsWith("/")) {
/* 1477 */         basePath = Util.normalizeUriPath(basePath);
/*      */       }
/*      */       
/* 1480 */       if (uriPath.equals(basePath)) {
/* 1481 */         return ".";
/*      */       }
/* 1483 */       String relPath = calculateRelativePath(uriPath, basePath, fixNull(theUri.getScheme()).equals("file"));
/*      */       
/* 1485 */       if (relPath == null)
/* 1486 */         return uri; 
/* 1487 */       StringBuilder relUri = new StringBuilder();
/* 1488 */       relUri.append(relPath);
/* 1489 */       if (theUri.getQuery() != null)
/* 1490 */         relUri.append('?').append(theUri.getQuery()); 
/* 1491 */       if (theUri.getFragment() != null) {
/* 1492 */         relUri.append('#').append(theUri.getFragment());
/*      */       }
/* 1494 */       return relUri.toString();
/* 1495 */     } catch (URISyntaxException e) {
/* 1496 */       throw new InternalError("Error escaping one of these uris:\n\t" + uri + "\n\t" + baseUri);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String fixNull(String s) {
/* 1501 */     if (s == null) return ""; 
/* 1502 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String calculateRelativePath(String uri, String base, boolean fileUrl) {
/* 1508 */     boolean onWindows = (File.pathSeparatorChar == ';');
/*      */     
/* 1510 */     if (base == null) {
/* 1511 */       return null;
/*      */     }
/* 1513 */     if ((fileUrl && onWindows && startsWithIgnoreCase(uri, base)) || uri.startsWith(base)) {
/* 1514 */       return uri.substring(base.length());
/*      */     }
/* 1516 */     return "../" + calculateRelativePath(uri, Util.getParentUriPath(base), fileUrl);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean startsWithIgnoreCase(String s, String t) {
/* 1521 */     return s.toUpperCase().startsWith(t.toUpperCase());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1528 */   private static final Comparator<String> NAMESPACE_COMPARATOR = new Comparator<String>()
/*      */     {
/*      */       public int compare(String lhs, String rhs) {
/* 1531 */         return -lhs.compareTo(rhs);
/*      */       }
/*      */     };
/*      */   
/*      */   private static final String newline = "\n";
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\XmlSchemaGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */