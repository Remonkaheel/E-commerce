/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEvent;
/*    */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.CompositeStructure;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeStructureBeanInfo
/*    */   extends JaxBeanInfo<CompositeStructure>
/*    */ {
/*    */   public CompositeStructureBeanInfo(JAXBContextImpl context) {
/* 29 */     super(context, null, CompositeStructure.class, false, true, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getElementNamespaceURI(CompositeStructure o) {
/* 34 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getElementLocalName(CompositeStructure o) {
/* 39 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public CompositeStructure createInstance(UnmarshallingContext context) throws IllegalAccessException, InvocationTargetException, InstantiationException, SAXException {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean reset(CompositeStructure o, UnmarshallingContext context) throws SAXException {
/* 49 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId(CompositeStructure o, XMLSerializer target) throws SAXException {
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 60 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void serializeRoot(CompositeStructure o, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 65 */     target.reportError((ValidationEvent)new ValidationEventImpl(1, Messages.UNABLE_TO_MARSHAL_NON_ELEMENT
/*    */ 
/*    */           
/* 68 */           .format(new Object[] { o.getClass().getName() }, ), null, null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeURIs(CompositeStructure o, XMLSerializer target) throws SAXException {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeAttributes(CompositeStructure o, XMLSerializer target) throws SAXException, IOException, XMLStreamException {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeBody(CompositeStructure o, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 85 */     int len = o.bridges.length;
/* 86 */     for (int i = 0; i < len; i++) {
/* 87 */       Object value = o.values[i];
/* 88 */       InternalBridge<Object> bi = (InternalBridge)o.bridges[i];
/* 89 */       bi.marshal(value, target);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Transducer<CompositeStructure> getTransducer() {
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\CompositeStructureBeanInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */