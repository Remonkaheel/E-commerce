package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Type;
import org.glassfish.jaxb.core.v2.model.core.NonElement;
import org.glassfish.jaxb.core.v2.model.core.NonElementRef;
import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
import org.glassfish.jaxb.runtime.v2.runtime.Transducer;

public interface RuntimeNonElementRef extends NonElementRef<Type, Class> {
  RuntimeNonElement getTarget();
  
  RuntimePropertyInfo getSource();
  
  <V> Transducer<V> getTransducer();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeNonElementRef.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */