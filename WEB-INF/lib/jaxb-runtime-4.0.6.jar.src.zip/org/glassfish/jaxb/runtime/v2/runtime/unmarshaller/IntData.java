/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.output.Pcdata;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.output.UTF8XmlOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntData
/*    */   extends Pcdata
/*    */ {
/*    */   private int data;
/*    */   private int length;
/*    */   
/*    */   public void reset(int i) {
/* 43 */     this.data = i;
/* 44 */     if (i == Integer.MIN_VALUE) {
/* 45 */       this.length = 11;
/*    */     } else {
/* 47 */       this.length = (i < 0) ? (stringSizeOfInt(-i) + 1) : stringSizeOfInt(i);
/*    */     } 
/*    */   }
/* 50 */   private static final int[] sizeTable = new int[] { 9, 99, 999, 9999, 20229, 999999, 9999999, 99999999, 202299999, Integer.MAX_VALUE };
/*    */ 
/*    */ 
/*    */   
/*    */   private static int stringSizeOfInt(int x) {
/* 55 */     for (int i = 0;; i++) {
/* 56 */       if (x <= sizeTable[i])
/* 57 */         return i + 1; 
/*    */     } 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return String.valueOf(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int length() {
/* 68 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public char charAt(int index) {
/* 73 */     return toString().charAt(index);
/*    */   }
/*    */ 
/*    */   
/*    */   public CharSequence subSequence(int start, int end) {
/* 78 */     return toString().substring(start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeTo(UTF8XmlOutput output) throws IOException {
/* 83 */     output.text(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\IntData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */