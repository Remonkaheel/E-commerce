/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Byte<B>
/*    */   extends Accessor<B, Byte>
/*    */ {
/*    */   public MethodAccessor_Byte() {
/* 25 */     super(Byte.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Byte get(B bean) {
/* 30 */     return Byte.valueOf(((Bean)bean).get_byte());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Byte value) {
/* 35 */     ((Bean)bean).set_byte((value == null) ? 0 : value.byteValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Byte.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */