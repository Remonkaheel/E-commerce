/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementDecl;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementDeclQuick
/*    */   extends Quick
/*    */   implements XmlElementDecl
/*    */ {
/*    */   private final XmlElementDecl core;
/*    */   
/*    */   public XmlElementDeclQuick(Locatable upstream, XmlElementDecl core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlElementDeclQuick(upstream, (XmlElementDecl)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElementDecl> annotationType() {
/* 47 */     return XmlElementDecl.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String defaultValue() {
/* 52 */     return this.core.defaultValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 57 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 62 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class scope() {
/* 67 */     return this.core.scope();
/*    */   }
/*    */ 
/*    */   
/*    */   public String substitutionHeadName() {
/* 72 */     return this.core.substitutionHeadName();
/*    */   }
/*    */ 
/*    */   
/*    */   public String substitutionHeadNamespace() {
/* 77 */     return this.core.substitutionHeadNamespace();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementDeclQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */