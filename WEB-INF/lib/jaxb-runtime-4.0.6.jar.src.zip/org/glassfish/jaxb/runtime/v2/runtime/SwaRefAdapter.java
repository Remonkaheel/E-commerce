/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import jakarta.activation.DataHandler;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import jakarta.xml.bind.attachment.AttachmentMarshaller;
/*    */ import jakarta.xml.bind.attachment.AttachmentUnmarshaller;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SwaRefAdapter
/*    */   extends XmlAdapter<String, DataHandler>
/*    */ {
/*    */   public DataHandler unmarshal(String cid) {
/* 45 */     AttachmentUnmarshaller au = (UnmarshallingContext.getInstance()).parent.getAttachmentUnmarshaller();
/*    */     
/* 47 */     return au.getAttachmentAsDataHandler(cid);
/*    */   }
/*    */ 
/*    */   
/*    */   public String marshal(DataHandler data) {
/* 52 */     if (data == null) return null; 
/* 53 */     AttachmentMarshaller am = (XMLSerializer.getInstance()).attachmentMarshaller;
/*    */     
/* 55 */     return am.addSwaRefAttachment(data);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\SwaRefAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */