package org.glassfish.jaxb.runtime.v2.runtime;

import com.sun.istack.NotNull;
import javax.xml.namespace.NamespaceContext;

public interface NamespaceContext2 extends NamespaceContext {
  String declareNamespace(String paramString1, String paramString2, boolean paramBoolean);
  
  int force(@NotNull String paramString1, @NotNull String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\NamespaceContext2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */