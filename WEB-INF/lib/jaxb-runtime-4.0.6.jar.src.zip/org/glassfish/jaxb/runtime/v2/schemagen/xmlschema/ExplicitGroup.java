package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;

public interface ExplicitGroup extends TypedXmlWriter, Annotated, NestedParticle, Occurs {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\ExplicitGroup.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */