/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.NamedNodeMap;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DomPostInitAction
/*    */   implements Runnable
/*    */ {
/*    */   private final Node node;
/*    */   private final XMLSerializer serializer;
/*    */   
/*    */   DomPostInitAction(Node node, XMLSerializer serializer) {
/* 35 */     this.node = node;
/* 36 */     this.serializer = serializer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 42 */     Set<String> declaredPrefixes = new HashSet<>();
/* 43 */     for (Node n = this.node; n != null && n.getNodeType() == 1; n = n.getParentNode()) {
/* 44 */       NamedNodeMap atts = n.getAttributes();
/* 45 */       if (atts != null)
/* 46 */         for (int i = 0; i < atts.getLength(); i++) {
/* 47 */           Attr a = (Attr)atts.item(i);
/* 48 */           String nsUri = a.getNamespaceURI();
/* 49 */           if (nsUri != null && nsUri.equals("http://www.w3.org/2000/xmlns/")) {
/*    */             
/* 51 */             String prefix = a.getLocalName();
/* 52 */             if (prefix != null) {
/*    */               
/* 54 */               if (prefix.equals("xmlns")) {
/* 55 */                 prefix = "";
/*    */               }
/* 57 */               String value = a.getValue();
/* 58 */               if (value != null)
/*    */               {
/* 60 */                 if (declaredPrefixes.add(prefix))
/* 61 */                   this.serializer.addInscopeBinding(value, prefix); 
/*    */               }
/*    */             } 
/*    */           } 
/*    */         }  
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\DomPostInitAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */