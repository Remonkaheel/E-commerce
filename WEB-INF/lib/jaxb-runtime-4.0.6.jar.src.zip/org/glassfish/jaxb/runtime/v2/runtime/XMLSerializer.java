/*      */ package org.glassfish.jaxb.runtime.v2.runtime;
/*      */ 
/*      */ import com.sun.istack.SAXException2;
/*      */ import jakarta.activation.MimeType;
/*      */ import jakarta.xml.bind.DatatypeConverter;
/*      */ import jakarta.xml.bind.JAXBException;
/*      */ import jakarta.xml.bind.Marshaller;
/*      */ import jakarta.xml.bind.ValidationEvent;
/*      */ import jakarta.xml.bind.ValidationEventHandler;
/*      */ import jakarta.xml.bind.ValidationEventLocator;
/*      */ import jakarta.xml.bind.annotation.DomHandler;
/*      */ import jakarta.xml.bind.annotation.XmlNs;
/*      */ import jakarta.xml.bind.attachment.AttachmentMarshaller;
/*      */ import jakarta.xml.bind.helpers.NotIdentifiableEventImpl;
/*      */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*      */ import jakarta.xml.bind.helpers.ValidationEventLocatorImpl;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.sax.SAXResult;
/*      */ import org.glassfish.jaxb.runtime.CycleRecoverable;
/*      */ import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;
/*      */ import org.glassfish.jaxb.runtime.util.ValidationEventLocatorExImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.MTOMXmlOutput;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.NamespaceContextImpl;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.Pcdata;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.XmlOutput;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.property.Property;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Base64Data;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.IntData;
/*      */ import org.glassfish.jaxb.runtime.v2.util.CollisionCheckStack;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class XMLSerializer
/*      */   extends Coordinator
/*      */ {
/*      */   public final JAXBContextImpl grammar;
/*      */   private XmlOutput out;
/*      */   public final NameList nameList;
/*      */   public final int[] knownUri2prefixIndexMap;
/*      */   private final NamespaceContextImpl nsContext;
/*      */   private NamespaceContextImpl.Element nse;
/*  112 */   ThreadLocal<Property> currentProperty = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean textHasAlreadyPrinted = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean seenRoot = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private final MarshallerImpl marshaller;
/*      */ 
/*      */ 
/*      */   
/*  129 */   private final Set<Object> idReferencedObjects = new HashSet();
/*      */ 
/*      */   
/*  132 */   private final Set<Object> objectsWithId = new HashSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private final CollisionCheckStack<Object> cycleDetectionStack = new CollisionCheckStack();
/*      */ 
/*      */ 
/*      */   
/*      */   private String schemaLocation;
/*      */ 
/*      */   
/*      */   private String noNsSchemaLocation;
/*      */ 
/*      */   
/*      */   private Transformer identityTransformer;
/*      */ 
/*      */   
/*      */   private ContentHandlerAdaptor contentHandlerAdapter;
/*      */ 
/*      */   
/*      */   private boolean fragment;
/*      */ 
/*      */   
/*      */   private Base64Data base64Data;
/*      */ 
/*      */   
/*  160 */   private final IntData intData = new IntData();
/*      */   public AttachmentMarshaller attachmentMarshaller;
/*      */   private MimeType expectedMimeType;
/*      */   
/*      */   XMLSerializer(MarshallerImpl _owner) {
/*  165 */     this.marshaller = _owner;
/*  166 */     this.grammar = this.marshaller.context;
/*  167 */     this.nsContext = new NamespaceContextImpl(this);
/*  168 */     this.nameList = this.marshaller.context.nameList;
/*  169 */     this.knownUri2prefixIndexMap = new int[this.nameList.namespaceURIs.length];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean inlineBinaryFlag;
/*      */   
/*      */   private QName schemaType;
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Base64Data getCachedBase64DataInstance() {
/*  181 */     return new Base64Data();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getIdFromObject(Object identifiableObject) throws SAXException, JAXBException {
/*  188 */     return this.grammar.getBeanInfo(identifiableObject, true).getId(identifiableObject, this);
/*      */   }
/*      */   
/*      */   private void handleMissingObjectError(String fieldName) throws SAXException, IOException, XMLStreamException {
/*  192 */     reportMissingObjectError(fieldName);
/*      */ 
/*      */     
/*  195 */     endNamespaceDecls((Object)null);
/*  196 */     endAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportError(ValidationEvent ve) throws SAXException {
/*      */     ValidationEventHandler handler;
/*      */     try {
/*  204 */       handler = this.marshaller.getEventHandler();
/*  205 */     } catch (JAXBException e) {
/*  206 */       throw new SAXException2(e);
/*      */     } 
/*      */     
/*  209 */     if (!handler.handleEvent(ve)) {
/*  210 */       if (ve.getLinkedException() instanceof Exception) {
/*  211 */         throw new SAXException2((Exception)ve.getLinkedException());
/*      */       }
/*  213 */       throw new SAXException2(ve.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportError(String fieldName, Throwable t) throws SAXException {
/*  225 */     ValidationEventImpl validationEventImpl = new ValidationEventImpl(1, t.getMessage(), getCurrentLocation(fieldName), t);
/*  226 */     reportError((ValidationEvent)validationEventImpl);
/*      */   }
/*      */   
/*      */   public void startElement(Name tagName, Object outerPeer) {
/*  230 */     startElement();
/*  231 */     this.nse.setTagName(tagName, outerPeer);
/*      */   }
/*      */   
/*      */   public void startElement(String nsUri, String localName, String preferredPrefix, Object outerPeer) {
/*  235 */     startElement();
/*  236 */     int idx = this.nsContext.declareNsUri(nsUri, preferredPrefix, false);
/*  237 */     this.nse.setTagName(idx, localName, outerPeer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void startElementForce(String nsUri, String localName, String forcedPrefix, Object outerPeer) {
/*  245 */     startElement();
/*  246 */     int idx = this.nsContext.force(nsUri, forcedPrefix);
/*  247 */     this.nse.setTagName(idx, localName, outerPeer);
/*      */   }
/*      */   
/*      */   public void endNamespaceDecls(Object innerPeer) throws IOException, XMLStreamException {
/*  251 */     this.nsContext.collectionMode = false;
/*  252 */     this.nse.startElement(this.out, innerPeer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endAttributes() throws SAXException, IOException, XMLStreamException {
/*  260 */     if (!this.seenRoot) {
/*  261 */       this.seenRoot = true;
/*  262 */       if (this.schemaLocation != null || this.noNsSchemaLocation != null) {
/*  263 */         int p = this.nsContext.getPrefixIndex("http://www.w3.org/2001/XMLSchema-instance");
/*  264 */         if (this.schemaLocation != null)
/*  265 */           this.out.attribute(p, "schemaLocation", this.schemaLocation); 
/*  266 */         if (this.noNsSchemaLocation != null) {
/*  267 */           this.out.attribute(p, "noNamespaceSchemaLocation", this.noNsSchemaLocation);
/*      */         }
/*      */       } 
/*      */     } 
/*  271 */     this.out.endStartTag();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endElement() throws SAXException, IOException, XMLStreamException {
/*  279 */     this.nse.endElement(this.out);
/*  280 */     this.nse = this.nse.pop();
/*  281 */     this.textHasAlreadyPrinted = false;
/*      */   }
/*      */   
/*      */   public void leafElement(Name tagName, String data, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  285 */     if (this.seenRoot) {
/*  286 */       this.textHasAlreadyPrinted = false;
/*  287 */       this.nse = this.nse.push();
/*  288 */       this.out.beginStartTag(tagName);
/*  289 */       this.out.endStartTag();
/*  290 */       if (data != null)
/*      */         try {
/*  292 */           this.out.text(data, false);
/*  293 */         } catch (IllegalArgumentException e) {
/*  294 */           throw new IllegalArgumentException(Messages.ILLEGAL_CONTENT.format(new Object[] { fieldName, e.getMessage() }));
/*      */         }  
/*  296 */       this.out.endTag(tagName);
/*  297 */       this.nse = this.nse.pop();
/*      */     }
/*      */     else {
/*      */       
/*  301 */       startElement(tagName, (Object)null);
/*  302 */       endNamespaceDecls((Object)null);
/*  303 */       endAttributes();
/*      */       try {
/*  305 */         this.out.text(data, false);
/*  306 */       } catch (IllegalArgumentException e) {
/*  307 */         throw new IllegalArgumentException(Messages.ILLEGAL_CONTENT.format(new Object[] { fieldName, e.getMessage() }));
/*      */       } 
/*  309 */       endElement();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void leafElement(Name tagName, Pcdata data, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  314 */     if (this.seenRoot) {
/*  315 */       this.textHasAlreadyPrinted = false;
/*  316 */       this.nse = this.nse.push();
/*  317 */       this.out.beginStartTag(tagName);
/*  318 */       this.out.endStartTag();
/*  319 */       if (data != null)
/*  320 */         this.out.text(data, false); 
/*  321 */       this.out.endTag(tagName);
/*  322 */       this.nse = this.nse.pop();
/*      */     }
/*      */     else {
/*      */       
/*  326 */       startElement(tagName, (Object)null);
/*  327 */       endNamespaceDecls((Object)null);
/*  328 */       endAttributes();
/*  329 */       this.out.text(data, false);
/*  330 */       endElement();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void leafElement(Name tagName, int data, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  335 */     this.intData.reset(data);
/*  336 */     leafElement(tagName, (Pcdata)this.intData, fieldName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void text(String text, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  365 */     if (text == null) {
/*  366 */       reportMissingObjectError(fieldName);
/*      */       
/*      */       return;
/*      */     } 
/*  370 */     this.out.text(text, this.textHasAlreadyPrinted);
/*  371 */     this.textHasAlreadyPrinted = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void text(Pcdata text, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  380 */     if (text == null) {
/*  381 */       reportMissingObjectError(fieldName);
/*      */       
/*      */       return;
/*      */     } 
/*  385 */     this.out.text(text, this.textHasAlreadyPrinted);
/*  386 */     this.textHasAlreadyPrinted = true;
/*      */   }
/*      */   
/*      */   public void attribute(String uri, String local, String value) throws SAXException {
/*      */     int prefix;
/*  391 */     if (uri.length() == 0) {
/*      */       
/*  393 */       prefix = -1;
/*      */     } else {
/*  395 */       prefix = this.nsContext.getPrefixIndex(uri);
/*      */     } 
/*      */     
/*      */     try {
/*  399 */       this.out.attribute(prefix, local, value);
/*  400 */     } catch (IOException|XMLStreamException e) {
/*  401 */       throw new SAXException2(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void attribute(Name name, CharSequence value) throws IOException, XMLStreamException {
/*  408 */     this.out.attribute(name, value.toString());
/*      */   }
/*      */   
/*      */   public NamespaceContext2 getNamespaceContext() {
/*  412 */     return (NamespaceContext2)this.nsContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public String onID(Object owner, String value) {
/*  417 */     this.objectsWithId.add(owner);
/*  418 */     return value;
/*      */   }
/*      */   
/*      */   public String onIDREF(Object obj) throws SAXException {
/*      */     String id;
/*      */     try {
/*  424 */       id = getIdFromObject(obj);
/*  425 */     } catch (JAXBException e) {
/*  426 */       reportError((String)null, (Throwable)e);
/*  427 */       return null;
/*      */     } 
/*  429 */     this.idReferencedObjects.add(obj);
/*  430 */     if (id == null) {
/*  431 */       reportError((ValidationEvent)new NotIdentifiableEventImpl(1, Messages.NOT_IDENTIFIABLE
/*      */             
/*  433 */             .format(new Object[0]), (ValidationEventLocator)new ValidationEventLocatorImpl(obj)));
/*      */     }
/*      */     
/*  436 */     return id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void childAsRoot(Object obj) throws JAXBException, IOException, SAXException, XMLStreamException {
/*  444 */     JaxBeanInfo<Object> beanInfo = this.grammar.getBeanInfo(obj, true);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  449 */     this.cycleDetectionStack.pushNocheck(obj);
/*      */     
/*  451 */     boolean lookForLifecycleMethods = beanInfo.lookForLifecycleMethods();
/*  452 */     if (lookForLifecycleMethods) {
/*  453 */       fireBeforeMarshalEvents(beanInfo, obj);
/*      */     }
/*      */     
/*  456 */     beanInfo.serializeRoot(obj, this);
/*      */     
/*  458 */     if (lookForLifecycleMethods) {
/*  459 */       fireAfterMarshalEvents(beanInfo, obj);
/*      */     }
/*      */     
/*  462 */     this.cycleDetectionStack.pop();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object pushObject(Object obj, String fieldName) throws SAXException {
/*  478 */     if (!this.cycleDetectionStack.push(obj)) {
/*  479 */       return obj;
/*      */     }
/*      */     
/*  482 */     if (obj instanceof CycleRecoverable) {
/*  483 */       obj = ((CycleRecoverable)obj).onCycleDetected(new CycleRecoverable.Context()
/*      */           {
/*      */             public Marshaller getMarshaller() {
/*  486 */               return (Marshaller)XMLSerializer.this.marshaller;
/*      */             }
/*      */           });
/*  489 */       if (obj != null) {
/*      */ 
/*      */ 
/*      */         
/*  493 */         this.cycleDetectionStack.pop();
/*  494 */         return pushObject(obj, fieldName);
/*      */       } 
/*  496 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  500 */     reportError((ValidationEvent)new ValidationEventImpl(1, Messages.CYCLE_IN_MARSHALLER
/*      */           
/*  502 */           .format(new Object[] { this.cycleDetectionStack.getCycleString()
/*  503 */             }, ), getCurrentLocation(fieldName), null));
/*      */     
/*  505 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void childAsSoleContent(Object child, String fieldName) throws SAXException, IOException, XMLStreamException {
/*  524 */     if (child == null) {
/*  525 */       handleMissingObjectError(fieldName);
/*      */     } else {
/*  527 */       JaxBeanInfo<Object> beanInfo; child = pushObject(child, fieldName);
/*  528 */       if (child == null) {
/*      */         
/*  530 */         endNamespaceDecls((Object)null);
/*  531 */         endAttributes();
/*  532 */         this.cycleDetectionStack.pop();
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  537 */         beanInfo = this.grammar.getBeanInfo(child, true);
/*  538 */       } catch (JAXBException e) {
/*  539 */         reportError(fieldName, (Throwable)e);
/*      */         
/*  541 */         endNamespaceDecls((Object)null);
/*  542 */         endAttributes();
/*  543 */         this.cycleDetectionStack.pop();
/*      */         
/*      */         return;
/*      */       } 
/*  547 */       boolean lookForLifecycleMethods = beanInfo.lookForLifecycleMethods();
/*  548 */       if (lookForLifecycleMethods) {
/*  549 */         fireBeforeMarshalEvents(beanInfo, child);
/*      */       }
/*      */       
/*  552 */       beanInfo.serializeURIs(child, this);
/*  553 */       endNamespaceDecls(child);
/*  554 */       beanInfo.serializeAttributes(child, this);
/*  555 */       endAttributes();
/*  556 */       beanInfo.serializeBody(child, this);
/*      */       
/*  558 */       if (lookForLifecycleMethods) {
/*  559 */         fireAfterMarshalEvents(beanInfo, child);
/*      */       }
/*      */       
/*  562 */       this.cycleDetectionStack.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void childAsXsiType(Object child, String fieldName, JaxBeanInfo<Object> expected, boolean nillable) throws SAXException, IOException, XMLStreamException {
/*  591 */     if (child == null) {
/*  592 */       handleMissingObjectError(fieldName);
/*      */     } else {
/*  594 */       child = pushObject(child, fieldName);
/*  595 */       if (child == null) {
/*  596 */         endNamespaceDecls((Object)null);
/*  597 */         endAttributes();
/*      */         
/*      */         return;
/*      */       } 
/*  601 */       boolean asExpected = (child.getClass() == expected.jaxbType);
/*  602 */       JaxBeanInfo<Object> actual = expected;
/*  603 */       QName actualTypeName = null;
/*      */       
/*  605 */       if (asExpected && actual.lookForLifecycleMethods()) {
/*  606 */         fireBeforeMarshalEvents(actual, child);
/*      */       }
/*      */       
/*  609 */       if (!asExpected) {
/*      */         try {
/*  611 */           actual = this.grammar.getBeanInfo(child, true);
/*  612 */           if (actual.lookForLifecycleMethods()) {
/*  613 */             fireBeforeMarshalEvents(actual, child);
/*      */           }
/*  615 */         } catch (JAXBException e) {
/*  616 */           reportError(fieldName, (Throwable)e);
/*  617 */           endNamespaceDecls((Object)null);
/*  618 */           endAttributes();
/*      */           return;
/*      */         } 
/*  621 */         if (actual == expected) {
/*  622 */           asExpected = true;
/*      */         } else {
/*  624 */           actualTypeName = actual.getTypeName(child);
/*  625 */           if (actualTypeName == null) {
/*  626 */             reportError((ValidationEvent)new ValidationEventImpl(1, Messages.SUBSTITUTED_BY_ANONYMOUS_TYPE
/*      */                   
/*  628 */                   .format(new Object[] {
/*  629 */                       expected.jaxbType.getName(), child
/*  630 */                       .getClass().getName(), actual.jaxbType
/*  631 */                       .getName()
/*  632 */                     }, ), getCurrentLocation(fieldName)));
/*      */           } else {
/*      */             
/*  635 */             getNamespaceContext().declareNamespace("http://www.w3.org/2001/XMLSchema-instance", "xsi", true);
/*  636 */             getNamespaceContext().declareNamespace(actualTypeName.getNamespaceURI(), null, false);
/*      */           } 
/*      */         } 
/*      */       } 
/*  640 */       actual.serializeURIs(child, this);
/*      */       
/*  642 */       if (nillable) {
/*  643 */         getNamespaceContext().declareNamespace("http://www.w3.org/2001/XMLSchema-instance", "xsi", true);
/*      */       }
/*      */       
/*  646 */       endNamespaceDecls(child);
/*  647 */       if (!asExpected) {
/*  648 */         attribute("http://www.w3.org/2001/XMLSchema-instance", "type", 
/*  649 */             DatatypeConverter.printQName(actualTypeName, getNamespaceContext()));
/*      */       }
/*      */       
/*  652 */       actual.serializeAttributes(child, this);
/*  653 */       boolean nilDefined = actual.isNilIncluded();
/*  654 */       if (nillable && !nilDefined) {
/*  655 */         attribute("http://www.w3.org/2001/XMLSchema-instance", "nil", "true");
/*      */       }
/*      */       
/*  658 */       endAttributes();
/*  659 */       actual.serializeBody(child, this);
/*      */       
/*  661 */       if (actual.lookForLifecycleMethods()) {
/*  662 */         fireAfterMarshalEvents(actual, child);
/*      */       }
/*      */       
/*  665 */       this.cycleDetectionStack.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireAfterMarshalEvents(JaxBeanInfo beanInfo, Object currentTarget) {
/*  678 */     if (beanInfo.hasAfterMarshalMethod()) {
/*  679 */       Method m = (beanInfo.getLifecycleMethods()).afterMarshal;
/*  680 */       fireMarshalEvent(currentTarget, m);
/*      */     } 
/*      */ 
/*      */     
/*  684 */     Marshaller.Listener externalListener = this.marshaller.getListener();
/*  685 */     if (externalListener != null) {
/*  686 */       externalListener.afterMarshal(currentTarget);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireBeforeMarshalEvents(JaxBeanInfo beanInfo, Object currentTarget) {
/*  700 */     if (beanInfo.hasBeforeMarshalMethod()) {
/*  701 */       Method m = (beanInfo.getLifecycleMethods()).beforeMarshal;
/*  702 */       fireMarshalEvent(currentTarget, m);
/*      */     } 
/*      */ 
/*      */     
/*  706 */     Marshaller.Listener externalListener = this.marshaller.getListener();
/*  707 */     if (externalListener != null) {
/*  708 */       externalListener.beforeMarshal(currentTarget);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fireMarshalEvent(Object target, Method m) {
/*      */     try {
/*  714 */       m.invoke(target, new Object[] { this.marshaller });
/*  715 */     } catch (Exception e) {
/*      */       
/*  717 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void attWildcardAsURIs(Map<QName, String> attributes, String fieldName) {
/*  722 */     if (attributes == null)
/*  723 */       return;  for (Map.Entry<QName, String> e : attributes.entrySet()) {
/*  724 */       QName n = e.getKey();
/*  725 */       String nsUri = n.getNamespaceURI();
/*  726 */       if (nsUri.length() > 0) {
/*  727 */         String p = n.getPrefix();
/*  728 */         if (p.length() == 0) p = null; 
/*  729 */         this.nsContext.declareNsUri(nsUri, p, true);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void attWildcardAsAttributes(Map<QName, String> attributes, String fieldName) throws SAXException {
/*  735 */     if (attributes == null)
/*  736 */       return;  for (Map.Entry<QName, String> e : attributes.entrySet()) {
/*  737 */       QName n = e.getKey();
/*  738 */       attribute(n.getNamespaceURI(), n.getLocalPart(), e.getValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeXsiNilTrue() throws SAXException, IOException, XMLStreamException {
/*  753 */     getNamespaceContext().declareNamespace("http://www.w3.org/2001/XMLSchema-instance", "xsi", true);
/*  754 */     endNamespaceDecls((Object)null);
/*  755 */     attribute("http://www.w3.org/2001/XMLSchema-instance", "nil", "true");
/*  756 */     endAttributes();
/*      */   }
/*      */   
/*      */   public <E> void writeDom(E element, DomHandler<E, ?> domHandler, Object parentBean, String fieldName) throws SAXException {
/*  760 */     Source source = domHandler.marshal(element, this);
/*  761 */     if (this.contentHandlerAdapter == null)
/*  762 */       this.contentHandlerAdapter = new ContentHandlerAdaptor(this); 
/*      */     try {
/*  764 */       getIdentityTransformer().transform(source, new SAXResult(this.contentHandlerAdapter));
/*  765 */     } catch (TransformerException e) {
/*  766 */       reportError(fieldName, e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public Transformer getIdentityTransformer() {
/*  771 */     if (this.identityTransformer == null)
/*  772 */       this.identityTransformer = JAXBContextImpl.createTransformer(this.grammar.disableSecurityProcessing); 
/*  773 */     return this.identityTransformer;
/*      */   }
/*      */   
/*      */   public void setPrefixMapper(NamespacePrefixMapper prefixMapper) {
/*  777 */     this.nsContext.setPrefixMapper(prefixMapper);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void startDocument(XmlOutput out, boolean fragment, String schemaLocation, String noNsSchemaLocation) throws IOException, SAXException, XMLStreamException {
/*      */     MTOMXmlOutput mTOMXmlOutput;
/*  789 */     pushCoordinator();
/*  790 */     this.nsContext.reset();
/*  791 */     this.nse = this.nsContext.getCurrent();
/*  792 */     if (this.attachmentMarshaller != null && this.attachmentMarshaller.isXOPPackage())
/*  793 */       mTOMXmlOutput = new MTOMXmlOutput(out); 
/*  794 */     this.out = (XmlOutput)mTOMXmlOutput;
/*  795 */     this.objectsWithId.clear();
/*  796 */     this.idReferencedObjects.clear();
/*  797 */     this.textHasAlreadyPrinted = false;
/*  798 */     this.seenRoot = false;
/*  799 */     this.schemaLocation = schemaLocation;
/*  800 */     this.noNsSchemaLocation = noNsSchemaLocation;
/*  801 */     this.fragment = fragment;
/*  802 */     this.inlineBinaryFlag = false;
/*  803 */     this.expectedMimeType = null;
/*  804 */     this.cycleDetectionStack.reset();
/*      */     
/*  806 */     mTOMXmlOutput.startDocument(this, fragment, this.knownUri2prefixIndexMap, this.nsContext);
/*      */   }
/*      */   
/*      */   public void endDocument() throws IOException, SAXException, XMLStreamException {
/*  810 */     this.out.endDocument(this.fragment);
/*      */   }
/*      */   
/*      */   public void close() {
/*  814 */     this.out = null;
/*  815 */     clearCurrentProperty();
/*  816 */     popCoordinator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addInscopeBinding(String nsUri, String prefix) {
/*  829 */     this.nsContext.put(nsUri, prefix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getXMIMEContentType() {
/*  843 */     String v = this.grammar.getXMIMEContentType(this.cycleDetectionStack.peek());
/*  844 */     if (v != null) return v;
/*      */ 
/*      */     
/*  847 */     if (this.expectedMimeType != null) {
/*  848 */       return this.expectedMimeType.toString();
/*      */     }
/*  850 */     return null;
/*      */   }
/*      */   
/*      */   private void startElement() {
/*  854 */     this.nse = this.nse.push();
/*      */     
/*  856 */     if (!this.seenRoot) {
/*      */       
/*  858 */       if (this.grammar.getXmlNsSet() != null) {
/*  859 */         for (XmlNs xmlNs : this.grammar.getXmlNsSet()) {
/*  860 */           this.nsContext.declareNsUri(xmlNs
/*  861 */               .namespaceURI(), 
/*  862 */               (xmlNs.prefix() == null) ? "" : xmlNs.prefix(), 
/*  863 */               (xmlNs.prefix() != null));
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*  868 */       String[] knownUris = this.nameList.namespaceURIs;
/*  869 */       for (int i = 0; i < knownUris.length; i++) {
/*  870 */         this.knownUri2prefixIndexMap[i] = this.nsContext.declareNsUri(knownUris[i], null, this.nameList.nsUriCannotBeDefaulted[i]);
/*      */       }
/*      */ 
/*      */       
/*  874 */       String[] uris = this.nsContext.getPrefixMapper().getPreDeclaredNamespaceUris();
/*  875 */       if (uris != null)
/*  876 */         for (String uri : uris) {
/*  877 */           if (uri != null) {
/*  878 */             this.nsContext.declareNsUri(uri, null, false);
/*      */           }
/*      */         }  
/*  881 */       String[] pairs = this.nsContext.getPrefixMapper().getPreDeclaredNamespaceUris2();
/*  882 */       if (pairs != null) {
/*  883 */         for (int j = 0; j < pairs.length; j += 2) {
/*  884 */           String prefix = pairs[j];
/*  885 */           String nsUri = pairs[j + 1];
/*  886 */           if (prefix != null && nsUri != null)
/*      */           {
/*      */ 
/*      */             
/*  890 */             this.nsContext.put(nsUri, prefix);
/*      */           }
/*      */         } 
/*      */       }
/*  894 */       if (this.schemaLocation != null || this.noNsSchemaLocation != null) {
/*  895 */         this.nsContext.declareNsUri("http://www.w3.org/2001/XMLSchema-instance", "xsi", true);
/*      */       }
/*      */     } 
/*      */     
/*  899 */     this.nsContext.collectionMode = true;
/*  900 */     this.textHasAlreadyPrinted = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MimeType setExpectedMimeType(MimeType expectedMimeType) {
/*  910 */     MimeType old = this.expectedMimeType;
/*  911 */     this.expectedMimeType = expectedMimeType;
/*  912 */     return old;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setInlineBinaryFlag(boolean value) {
/*  921 */     boolean old = this.inlineBinaryFlag;
/*  922 */     this.inlineBinaryFlag = value;
/*  923 */     return old;
/*      */   }
/*      */   
/*      */   public boolean getInlineBinaryFlag() {
/*  927 */     return this.inlineBinaryFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QName setSchemaType(QName st) {
/*  942 */     QName old = this.schemaType;
/*  943 */     this.schemaType = st;
/*  944 */     return old;
/*      */   }
/*      */   
/*      */   public QName getSchemaType() {
/*  948 */     return this.schemaType;
/*      */   }
/*      */   
/*      */   public void setObjectIdentityCycleDetection(boolean val) {
/*  952 */     this.cycleDetectionStack.setUseIdentity(val);
/*      */   }
/*      */   public boolean getObjectIdentityCycleDetection() {
/*  955 */     return this.cycleDetectionStack.getUseIdentity();
/*      */   }
/*      */ 
/*      */   
/*      */   void reconcileID() throws SAXException {
/*  960 */     this.idReferencedObjects.removeAll(this.objectsWithId);
/*      */     
/*  962 */     for (Object idObj : this.idReferencedObjects) {
/*      */       try {
/*  964 */         String id = getIdFromObject(idObj);
/*  965 */         reportError((ValidationEvent)new NotIdentifiableEventImpl(1, Messages.DANGLING_IDREF
/*      */               
/*  967 */               .format(new Object[] { id }, ), (ValidationEventLocator)new ValidationEventLocatorImpl(idObj)));
/*      */       }
/*  969 */       catch (JAXBException jAXBException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  975 */     this.idReferencedObjects.clear();
/*  976 */     this.objectsWithId.clear();
/*      */   }
/*      */   
/*      */   public boolean handleError(Exception e) {
/*  980 */     return handleError(e, this.cycleDetectionStack.peek(), (String)null);
/*      */   }
/*      */   
/*      */   public boolean handleError(Exception e, Object source, String fieldName) {
/*  984 */     return handleEvent((ValidationEvent)new ValidationEventImpl(1, e
/*      */ 
/*      */           
/*  987 */           .getMessage(), (ValidationEventLocator)new ValidationEventLocatorExImpl(source, fieldName), e));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean handleEvent(ValidationEvent event) {
/*      */     try {
/*  995 */       return this.marshaller.getEventHandler().handleEvent(event);
/*  996 */     } catch (JAXBException e) {
/*      */       
/*  998 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void reportMissingObjectError(String fieldName) throws SAXException {
/* 1003 */     reportError((ValidationEvent)new ValidationEventImpl(1, Messages.MISSING_OBJECT
/*      */           
/* 1005 */           .format(new Object[] { fieldName
/* 1006 */             }, ), getCurrentLocation(fieldName), new NullPointerException()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void errorMissingId(Object obj) throws SAXException {
/* 1014 */     reportError((ValidationEvent)new ValidationEventImpl(1, Messages.MISSING_ID
/*      */           
/* 1016 */           .format(new Object[] { obj }, ), (ValidationEventLocator)new ValidationEventLocatorImpl(obj)));
/*      */   }
/*      */ 
/*      */   
/*      */   public ValidationEventLocator getCurrentLocation(String fieldName) {
/* 1021 */     return (ValidationEventLocator)new ValidationEventLocatorExImpl(this.cycleDetectionStack.peek(), fieldName);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ValidationEventLocator getLocation() {
/* 1026 */     return getCurrentLocation((String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Property getCurrentProperty() {
/* 1034 */     return this.currentProperty.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCurrentProperty() {
/* 1041 */     if (this.currentProperty != null) {
/* 1042 */       this.currentProperty.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XMLSerializer getInstance() {
/* 1051 */     return (XMLSerializer)_getInstance();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\XMLSerializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */