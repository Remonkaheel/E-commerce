/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaTypeTransducer<V>
/*    */   extends FilterTransducer<V>
/*    */ {
/*    */   private final QName schemaType;
/*    */   
/*    */   public SchemaTypeTransducer(Transducer<V> core, QName schemaType) {
/* 37 */     super(core);
/* 38 */     this.schemaType = schemaType;
/*    */   }
/*    */ 
/*    */   
/*    */   public CharSequence print(V o) throws AccessorException {
/* 43 */     XMLSerializer w = XMLSerializer.getInstance();
/* 44 */     QName old = w.setSchemaType(this.schemaType);
/*    */     try {
/* 46 */       return this.core.print(o);
/*    */     } finally {
/* 48 */       w.setSchemaType(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeText(XMLSerializer w, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 54 */     QName old = w.setSchemaType(this.schemaType);
/*    */     try {
/* 56 */       this.core.writeText(w, o, fieldName);
/*    */     } finally {
/* 58 */       w.setSchemaType(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeLeafElement(XMLSerializer w, Name tagName, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 64 */     QName old = w.setSchemaType(this.schemaType);
/*    */     try {
/* 66 */       this.core.writeLeafElement(w, tagName, o, fieldName);
/*    */     } finally {
/* 68 */       w.setSchemaType(old);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\SchemaTypeTransducer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */