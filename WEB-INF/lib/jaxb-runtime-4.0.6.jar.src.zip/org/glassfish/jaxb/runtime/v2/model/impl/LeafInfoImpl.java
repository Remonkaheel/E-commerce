/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.LeafInfo;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class LeafInfoImpl<TypeT, ClassDeclT>
/*    */   implements LeafInfo<TypeT, ClassDeclT>, Location
/*    */ {
/*    */   private final TypeT type;
/*    */   private final QName typeName;
/*    */   
/*    */   protected LeafInfoImpl(TypeT type, QName typeName) {
/* 30 */     assert type != null;
/*    */     
/* 32 */     this.type = type;
/* 33 */     this.typeName = typeName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeT getType() {
/* 41 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final boolean canBeReferencedByIDREF() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getTypeName() {
/* 58 */     return this.typeName;
/*    */   }
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSimpleType() {
/* 76 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return this.type.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\LeafInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */