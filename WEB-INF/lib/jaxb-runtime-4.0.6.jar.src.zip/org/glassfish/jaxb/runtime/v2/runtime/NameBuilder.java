/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameBuilder
/*     */ {
/*  33 */   private Map<String, Integer> uriIndexMap = new HashMap<>();
/*  34 */   private Set<String> nonDefaultableNsUris = new HashSet<>();
/*  35 */   private Map<String, Integer> localNameIndexMap = new HashMap<>();
/*  36 */   private QNameMap<Integer> elementQNameIndexMap = new QNameMap();
/*  37 */   private QNameMap<Integer> attributeQNameIndexMap = new QNameMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name createElementName(QName name) {
/*  45 */     return createElementName(name.getNamespaceURI(), name.getLocalPart());
/*     */   }
/*     */   
/*     */   public Name createElementName(String nsUri, String localName) {
/*  49 */     return createName(nsUri, localName, false, this.elementQNameIndexMap);
/*     */   }
/*     */   
/*     */   public Name createAttributeName(QName name) {
/*  53 */     return createAttributeName(name.getNamespaceURI(), name.getLocalPart());
/*     */   }
/*     */   
/*     */   public Name createAttributeName(String nsUri, String localName) {
/*  57 */     assert nsUri.intern() == nsUri;
/*  58 */     assert localName.intern() == localName;
/*     */     
/*  60 */     if (nsUri.length() == 0) {
/*  61 */       return new Name(
/*  62 */           allocIndex(this.attributeQNameIndexMap, "", localName), -1, nsUri, 
/*     */ 
/*     */           
/*  65 */           allocIndex(this.localNameIndexMap, localName), localName, true);
/*     */     }
/*     */ 
/*     */     
/*  69 */     this.nonDefaultableNsUris.add(nsUri);
/*  70 */     return createName(nsUri, localName, true, this.attributeQNameIndexMap);
/*     */   }
/*     */ 
/*     */   
/*     */   private Name createName(String nsUri, String localName, boolean isAttribute, QNameMap<Integer> map) {
/*  75 */     assert nsUri.intern() == nsUri;
/*  76 */     assert localName.intern() == localName;
/*     */     
/*  78 */     return new Name(
/*  79 */         allocIndex(map, nsUri, localName), 
/*  80 */         allocIndex(this.uriIndexMap, nsUri), nsUri, 
/*     */         
/*  82 */         allocIndex(this.localNameIndexMap, localName), localName, isAttribute);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int allocIndex(Map<String, Integer> map, String str) {
/*  88 */     Integer i = map.get(str);
/*  89 */     if (i == null) {
/*  90 */       i = Integer.valueOf(map.size());
/*  91 */       map.put(str, i);
/*     */     } 
/*  93 */     return i.intValue();
/*     */   }
/*     */   
/*     */   private int allocIndex(QNameMap<Integer> map, String nsUri, String localName) {
/*  97 */     Integer i = (Integer)map.get(nsUri, localName);
/*  98 */     if (i == null) {
/*  99 */       i = Integer.valueOf(map.size());
/* 100 */       map.put(nsUri, localName, i);
/*     */     } 
/* 102 */     return i.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameList conclude() {
/* 109 */     boolean[] nsUriCannotBeDefaulted = new boolean[this.uriIndexMap.size()];
/* 110 */     for (Map.Entry<String, Integer> e : this.uriIndexMap.entrySet()) {
/* 111 */       nsUriCannotBeDefaulted[((Integer)e.getValue()).intValue()] = this.nonDefaultableNsUris.contains(e.getKey());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     NameList r = new NameList(list(this.uriIndexMap), nsUriCannotBeDefaulted, list(this.localNameIndexMap), this.elementQNameIndexMap.size(), this.attributeQNameIndexMap.size());
/*     */     
/* 121 */     this.uriIndexMap = null;
/* 122 */     this.localNameIndexMap = null;
/* 123 */     return r;
/*     */   }
/*     */   
/*     */   private String[] list(Map<String, Integer> map) {
/* 127 */     String[] r = new String[map.size()];
/* 128 */     for (Map.Entry<String, Integer> e : map.entrySet())
/* 129 */       r[((Integer)e.getValue()).intValue()] = e.getKey(); 
/* 130 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\NameBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */