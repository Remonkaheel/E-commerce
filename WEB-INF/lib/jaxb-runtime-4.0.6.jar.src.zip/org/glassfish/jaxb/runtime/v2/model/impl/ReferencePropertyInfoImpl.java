/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.XmlAnyElement;
/*     */ import jakarta.xml.bind.annotation.XmlElementRef;
/*     */ import jakarta.xml.bind.annotation.XmlElementRefs;
/*     */ import jakarta.xml.bind.annotation.XmlMixed;
/*     */ import jakarta.xml.bind.annotation.XmlNsForm;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ReferencePropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.WildcardMode;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReferencePropertyInfoImpl<T, C, F, M>
/*     */   extends ERPropertyInfoImpl<T, C, F, M>
/*     */   implements ReferencePropertyInfo<T, C>, DummyPropertyInfo<T, C, F, M>
/*     */ {
/*     */   private Set<Element<T, C>> types;
/*  39 */   private Set<ReferencePropertyInfoImpl<T, C, F, M>> subTypes = new LinkedHashSet<>();
/*     */ 
/*     */   
/*     */   private final boolean isMixed;
/*     */ 
/*     */   
/*     */   private final WildcardMode wildcard;
/*     */ 
/*     */   
/*     */   private final C domHandler;
/*     */ 
/*     */   
/*     */   private Boolean isRequired;
/*     */ 
/*     */   
/*     */   public ReferencePropertyInfoImpl(ClassInfoImpl<T, C, F, M> classInfo, PropertySeed<T, C, F, M> seed) {
/*  55 */     super(classInfo, seed);
/*     */     
/*  57 */     this.isMixed = (seed.readAnnotation(XmlMixed.class) != null);
/*     */     
/*  59 */     XmlAnyElement xae = (XmlAnyElement)seed.readAnnotation(XmlAnyElement.class);
/*  60 */     if (xae == null) {
/*  61 */       this.wildcard = null;
/*  62 */       this.domHandler = null;
/*     */     } else {
/*  64 */       this.wildcard = xae.lax() ? WildcardMode.LAX : WildcardMode.SKIP;
/*  65 */       this.domHandler = (C)nav().asDecl(reader().getClassValue((Annotation)xae, "value"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<? extends Element<T, C>> ref() {
/*  71 */     return getElements();
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKind kind() {
/*  76 */     return PropertyKind.REFERENCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<? extends Element<T, C>> getElements() {
/*  81 */     if (this.types == null)
/*  82 */       calcTypes(false); 
/*  83 */     assert this.types != null;
/*  84 */     return this.types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calcTypes(boolean last) {
/*     */     XmlElementRef[] ann;
/*  95 */     this.types = new LinkedHashSet<>();
/*  96 */     XmlElementRefs refs = (XmlElementRefs)this.seed.readAnnotation(XmlElementRefs.class);
/*  97 */     XmlElementRef ref = (XmlElementRef)this.seed.readAnnotation(XmlElementRef.class);
/*     */     
/*  99 */     if (refs != null && ref != null) {
/* 100 */       this.parent.builder.reportError(new IllegalAnnotationException(Messages.MUTUALLY_EXCLUSIVE_ANNOTATIONS
/* 101 */             .format(new Object[] {
/* 102 */                 nav().getClassName(this.parent.getClazz()) + "#" + nav().getClassName(this.parent.getClazz()), ref
/* 103 */                 .annotationType().getName(), refs.annotationType().getName()
/*     */               }, ), (Annotation)ref, (Annotation)refs));
/*     */     }
/*     */     
/* 107 */     if (refs != null) {
/* 108 */       ann = refs.value();
/*     */     }
/* 110 */     else if (ref != null) {
/* 111 */       ann = new XmlElementRef[] { ref };
/*     */     } else {
/* 113 */       ann = null;
/*     */     } 
/*     */     
/* 116 */     this.isRequired = Boolean.valueOf(!isCollection());
/*     */     
/* 118 */     if (ann != null) {
/* 119 */       Navigator<T, C, F, M> nav = nav();
/* 120 */       AnnotationReader<T, C, F, M> reader = reader();
/*     */       
/* 122 */       T defaultType = (T)nav.ref(XmlElementRef.DEFAULT.class);
/* 123 */       C je = (C)nav.asDecl(JAXBElement.class);
/*     */       
/* 125 */       for (XmlElementRef r : ann) {
/*     */         boolean _yield;
/* 127 */         T type = (T)reader.getClassValue((Annotation)r, "type");
/* 128 */         if (nav().isSameType(type, defaultType))
/* 129 */           type = (T)nav.erasure(getIndividualType()); 
/* 130 */         if (nav.getBaseClass(type, je) != null) {
/* 131 */           _yield = addGenericElement(r);
/*     */         } else {
/* 133 */           _yield = addAllSubtypes(type);
/*     */         } 
/*     */ 
/*     */         
/* 137 */         if (this.isRequired.booleanValue() && !isRequired(r)) {
/* 138 */           this.isRequired = Boolean.valueOf(false);
/*     */         }
/* 140 */         if (last && !_yield) {
/*     */ 
/*     */           
/* 143 */           if (nav().isSameType(type, nav.ref(JAXBElement.class))) {
/*     */             
/* 145 */             this.parent.builder.reportError(new IllegalAnnotationException(Messages.NO_XML_ELEMENT_DECL
/* 146 */                   .format(new Object[] {
/* 147 */                       getEffectiveNamespaceFor(r), r.name()
/*     */                     }, ), this));
/*     */           } else {
/*     */             
/* 151 */             this.parent.builder.reportError(new IllegalAnnotationException(Messages.INVALID_XML_ELEMENT_REF
/* 152 */                   .format(new Object[] { type }, ), this));
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     for (ReferencePropertyInfoImpl<T, C, F, M> info : this.subTypes) {
/* 165 */       PropertySeed<T, C, F, M> sd = info.seed;
/* 166 */       refs = (XmlElementRefs)sd.readAnnotation(XmlElementRefs.class);
/* 167 */       ref = (XmlElementRef)sd.readAnnotation(XmlElementRef.class);
/*     */       
/* 169 */       if (refs != null && ref != null) {
/* 170 */         this.parent.builder.reportError(new IllegalAnnotationException(Messages.MUTUALLY_EXCLUSIVE_ANNOTATIONS
/* 171 */               .format(new Object[] {
/* 172 */                   nav().getClassName(this.parent.getClazz()) + "#" + nav().getClassName(this.parent.getClazz()), ref
/* 173 */                   .annotationType().getName(), refs.annotationType().getName()
/*     */                 }, ), (Annotation)ref, (Annotation)refs));
/*     */       }
/*     */       
/* 177 */       if (refs != null) {
/* 178 */         ann = refs.value();
/*     */       }
/* 180 */       else if (ref != null) {
/* 181 */         ann = new XmlElementRef[] { ref };
/*     */       } else {
/* 183 */         ann = null;
/*     */       } 
/*     */ 
/*     */       
/* 187 */       if (ann != null) {
/* 188 */         Navigator<T, C, F, M> nav = nav();
/* 189 */         AnnotationReader<T, C, F, M> reader = reader();
/*     */         
/* 191 */         T defaultType = (T)nav.ref(XmlElementRef.DEFAULT.class);
/* 192 */         C je = (C)nav.asDecl(JAXBElement.class);
/*     */         
/* 194 */         for (XmlElementRef r : ann) {
/*     */           boolean _yield;
/* 196 */           T type = (T)reader.getClassValue((Annotation)r, "type");
/* 197 */           if (nav().isSameType(type, defaultType)) {
/* 198 */             type = (T)nav.erasure(getIndividualType());
/*     */           }
/* 200 */           if (nav.getBaseClass(type, je) != null) {
/* 201 */             _yield = addGenericElement(r, info);
/*     */           } else {
/*     */             
/* 204 */             _yield = addAllSubtypes(type);
/*     */           } 
/*     */           
/* 207 */           if (last && !_yield) {
/*     */ 
/*     */             
/* 210 */             if (nav().isSameType(type, nav.ref(JAXBElement.class))) {
/*     */               
/* 212 */               this.parent.builder.reportError(new IllegalAnnotationException(Messages.NO_XML_ELEMENT_DECL
/* 213 */                     .format(new Object[] {
/* 214 */                         getEffectiveNamespaceFor(r), r.name()
/*     */                       }, ), this));
/*     */             } else {
/*     */               
/* 218 */               this.parent.builder.reportError(new IllegalAnnotationException(Messages.INVALID_XML_ELEMENT_REF
/* 219 */                     .format(new Object[0]), this));
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     this.types = Collections.unmodifiableSet(this.types);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 237 */     if (this.isRequired == null)
/* 238 */       calcTypes(false); 
/* 239 */     return this.isRequired.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean is2_2 = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRequired(XmlElementRef ref) {
/* 254 */     if (!is2_2) return true;
/*     */     
/*     */     try {
/* 257 */       return ref.required();
/* 258 */     } catch (LinkageError e) {
/* 259 */       is2_2 = false;
/* 260 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean addGenericElement(XmlElementRef r) {
/* 269 */     String nsUri = getEffectiveNamespaceFor(r);
/*     */     
/* 271 */     return addGenericElement(this.parent.owner.getElementInfo(this.parent.getClazz(), new QName(nsUri, r.name())));
/*     */   }
/*     */   
/*     */   private boolean addGenericElement(XmlElementRef r, ReferencePropertyInfoImpl<T, C, F, M> info) {
/* 275 */     String nsUri = info.getEffectiveNamespaceFor(r);
/* 276 */     ElementInfo<T, C, F, M> ei = (ElementInfo<T, C, F, M>)this.parent.owner.getElementInfo(info.parent.getClazz(), new QName(nsUri, r.name()));
/* 277 */     this.types.add(ei);
/* 278 */     return true;
/*     */   }
/*     */   
/*     */   private String getEffectiveNamespaceFor(XmlElementRef r) {
/* 282 */     String nsUri = r.namespace();
/*     */     
/* 284 */     XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, this.parent.getClazz(), this);
/* 285 */     if (xs != null && xs.attributeFormDefault() == XmlNsForm.QUALIFIED)
/*     */     {
/*     */       
/* 288 */       if (nsUri.length() == 0) {
/* 289 */         nsUri = this.parent.builder.defaultNsUri;
/*     */       }
/*     */     }
/* 292 */     return nsUri;
/*     */   }
/*     */   
/*     */   private boolean addGenericElement(ElementInfo<T, C> ei) {
/* 296 */     if (ei == null)
/* 297 */       return false; 
/* 298 */     this.types.add(ei);
/* 299 */     for (ElementInfo<T, C> subst : (Iterable<ElementInfo<T, C>>)ei.getSubstitutionMembers())
/* 300 */       addGenericElement(subst); 
/* 301 */     return true;
/*     */   }
/*     */   
/*     */   private boolean addAllSubtypes(T type) {
/* 305 */     Navigator<T, C, F, M> nav = nav();
/*     */ 
/*     */     
/* 308 */     NonElement<T, C> t = this.parent.builder.getClassInfo((C)nav.asDecl(type), this);
/* 309 */     if (!(t instanceof ClassInfo))
/*     */     {
/* 311 */       return false;
/*     */     }
/* 313 */     boolean result = false;
/*     */     
/* 315 */     ClassInfo<T, C> c = (ClassInfo<T, C>)t;
/* 316 */     if (c.isElement()) {
/* 317 */       this.types.add(c.asElement());
/* 318 */       result = true;
/*     */     } 
/*     */ 
/*     */     
/* 322 */     for (ClassInfo<T, C> ci : (Iterable<ClassInfo<T, C>>)this.parent.owner.beans().values()) {
/* 323 */       if (ci.isElement() && nav.isSubClassOf(ci.getType(), type)) {
/* 324 */         this.types.add(ci.asElement());
/* 325 */         result = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 330 */     for (ElementInfo<T, C> ei : (Iterable<ElementInfo<T, C>>)this.parent.owner.getElementMappings(null).values()) {
/* 331 */       if (nav.isSubClassOf(ei.getType(), type)) {
/* 332 */         this.types.add(ei);
/* 333 */         result = true;
/*     */       } 
/*     */     } 
/*     */     
/* 337 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void link() {
/* 343 */     super.link();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 348 */     calcTypes(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addType(PropertyInfo<T, C> info) {
/* 356 */     this.subTypes.add((ReferencePropertyInfoImpl)info);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isMixed() {
/* 361 */     return this.isMixed;
/*     */   }
/*     */ 
/*     */   
/*     */   public final WildcardMode getWildcard() {
/* 366 */     return this.wildcard;
/*     */   }
/*     */ 
/*     */   
/*     */   public final C getDOMHandler() {
/* 371 */     return this.domHandler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ReferencePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */