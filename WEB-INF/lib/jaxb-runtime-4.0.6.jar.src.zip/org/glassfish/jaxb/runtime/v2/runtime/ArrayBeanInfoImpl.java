/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeArrayInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TagName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ArrayBeanInfoImpl
/*     */   extends JaxBeanInfo
/*     */ {
/*     */   private final Class itemType;
/*     */   private final JaxBeanInfo itemBeanInfo;
/*     */   private Loader loader;
/*     */   
/*     */   public ArrayBeanInfoImpl(JAXBContextImpl owner, RuntimeArrayInfo rai) {
/*  44 */     super(owner, (RuntimeTypeInfo)rai, rai.getType(), rai.getTypeName(), false, true, false);
/*  45 */     this.itemType = this.jaxbType.getComponentType();
/*  46 */     this.itemBeanInfo = owner.getOrCreate((RuntimeTypeInfo)rai.getItemType());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void link(JAXBContextImpl grammar) {
/*  51 */     getLoader(grammar, false);
/*  52 */     super.link(grammar);
/*     */   }
/*     */   
/*     */   private final class ArrayLoader extends Loader implements Receiver {
/*     */     public ArrayLoader(JAXBContextImpl owner) {
/*  57 */       super(false);
/*  58 */       this.itemLoader = ArrayBeanInfoImpl.this.itemBeanInfo.getLoader(owner, true);
/*     */     }
/*     */ 
/*     */     
/*     */     private final Loader itemLoader;
/*     */     
/*     */     public void startElement(UnmarshallingContext.State state, TagName ea) {
/*  65 */       state.setTarget(new ArrayList());
/*     */     }
/*     */ 
/*     */     
/*     */     public void leaveElement(UnmarshallingContext.State state, TagName ea) {
/*  70 */       state.setTarget(ArrayBeanInfoImpl.this.toArray((List)state.getTarget()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  75 */       if (ea.matches("", "item")) {
/*  76 */         state.setLoader(this.itemLoader);
/*  77 */         state.setReceiver(this);
/*     */       } else {
/*  79 */         super.childElement(state, ea);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<QName> getExpectedChildElements() {
/*  85 */       return Collections.singleton(new QName("", "item"));
/*     */     }
/*     */ 
/*     */     
/*     */     public void receive(UnmarshallingContext.State state, Object o) {
/*  90 */       ((List<Object>)state.getTarget()).add(o);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object toArray(List list) {
/*  95 */     int len = list.size();
/*  96 */     Object array = Array.newInstance(this.itemType, len);
/*  97 */     for (int i = 0; i < len; i++)
/*  98 */       Array.set(array, i, list.get(i)); 
/*  99 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(Object array, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 104 */     int len = Array.getLength(array);
/* 105 */     for (int i = 0; i < len; i++) {
/* 106 */       Object item = Array.get(array, i);
/*     */       
/* 108 */       target.startElement("", "item", null, null);
/* 109 */       if (item == null) {
/* 110 */         target.writeXsiNilTrue();
/*     */       } else {
/* 112 */         target.childAsXsiType(item, "arrayItem", this.itemBeanInfo, false);
/*     */       } 
/* 114 */       target.endElement();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementNamespaceURI(Object array) {
/* 120 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementLocalName(Object array) {
/* 125 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createInstance(UnmarshallingContext context) {
/* 131 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reset(Object array, UnmarshallingContext context) {
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId(Object array, XMLSerializer target) {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAttributes(Object array, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeRoot(Object array, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 151 */     target.reportError((ValidationEvent)new ValidationEventImpl(1, Messages.UNABLE_TO_MARSHAL_NON_ELEMENT
/*     */ 
/*     */           
/* 154 */           .format(new Object[] { array.getClass().getName() }, ), null, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeURIs(Object array, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transducer getTransducer() {
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 171 */     if (this.loader == null) {
/* 172 */       this.loader = new ArrayLoader(context);
/*     */     }
/*     */     
/* 175 */     return this.loader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\ArrayBeanInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */