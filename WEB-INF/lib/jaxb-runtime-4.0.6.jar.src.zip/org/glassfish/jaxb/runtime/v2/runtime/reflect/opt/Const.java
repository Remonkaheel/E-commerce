package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;

public final class Const {
  public static final byte default_value_byte = 0;
  
  public static final boolean default_value_boolean = false;
  
  public static final char default_value_char = '\000';
  
  public static final float default_value_float = 0.0F;
  
  public static final double default_value_double = 0.0D;
  
  public static final int default_value_int = 0;
  
  public static final long default_value_long = 0L;
  
  public static final short default_value_short = 0;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\Const.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */