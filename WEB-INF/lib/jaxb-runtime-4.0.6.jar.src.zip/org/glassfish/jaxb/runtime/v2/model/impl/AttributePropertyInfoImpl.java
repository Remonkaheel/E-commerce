/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlNsForm;
/*    */ import jakarta.xml.bind.annotation.XmlSchema;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.api.impl.NameConverter;
/*    */ import org.glassfish.jaxb.core.v2.model.core.AttributePropertyInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AttributePropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   extends SingleTypePropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   implements AttributePropertyInfo<TypeT, ClassDeclT>
/*    */ {
/*    */   private final QName xmlName;
/*    */   private final boolean isRequired;
/*    */   
/*    */   AttributePropertyInfoImpl(ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> parent, PropertySeed<TypeT, ClassDeclT, FieldT, MethodT> seed) {
/* 33 */     super(parent, seed);
/* 34 */     XmlAttribute att = (XmlAttribute)seed.readAnnotation(XmlAttribute.class);
/* 35 */     assert att != null;
/*    */     
/* 37 */     if (att.required())
/* 38 */     { this.isRequired = true; }
/* 39 */     else { this.isRequired = nav().isPrimitive(getIndividualType()); }
/*    */     
/* 41 */     this.xmlName = calcXmlName(att);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private QName calcXmlName(XmlAttribute att) {
/* 48 */     String uri = att.namespace();
/* 49 */     String local = att.name();
/*    */ 
/*    */     
/* 52 */     if (local.equals("##default"))
/* 53 */       local = NameConverter.standard.toVariableName(getName()); 
/* 54 */     if (uri.equals("##default")) {
/* 55 */       XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, this.parent.getClazz(), this);
/*    */ 
/*    */       
/* 58 */       if (xs != null) {
/* 59 */         switch (xs.attributeFormDefault()) {
/*    */           case QUALIFIED:
/* 61 */             uri = this.parent.getTypeName().getNamespaceURI();
/* 62 */             if (uri.length() == 0)
/* 63 */               uri = this.parent.builder.defaultNsUri; 
/*    */             break;
/*    */           case UNQUALIFIED:
/*    */           case UNSET:
/* 67 */             uri = ""; break;
/*    */         } 
/*    */       } else {
/* 70 */         uri = "";
/*    */       } 
/*    */     } 
/* 73 */     return new QName(uri.intern(), local.intern());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRequired() {
/* 78 */     return this.isRequired;
/*    */   }
/*    */ 
/*    */   
/*    */   public final QName getXmlName() {
/* 83 */     return this.xmlName;
/*    */   }
/*    */ 
/*    */   
/*    */   public final PropertyKind kind() {
/* 88 */     return PropertyKind.ATTRIBUTE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\AttributePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */