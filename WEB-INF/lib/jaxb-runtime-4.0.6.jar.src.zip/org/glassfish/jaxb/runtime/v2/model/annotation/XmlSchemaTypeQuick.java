/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlSchemaType;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlSchemaTypeQuick
/*    */   extends Quick
/*    */   implements XmlSchemaType
/*    */ {
/*    */   private final XmlSchemaType core;
/*    */   
/*    */   public XmlSchemaTypeQuick(Locatable upstream, XmlSchemaType core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlSchemaTypeQuick(upstream, (XmlSchemaType)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlSchemaType> annotationType() {
/* 47 */     return XmlSchemaType.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 52 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 57 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class type() {
/* 62 */     return this.core.type();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlSchemaTypeQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */