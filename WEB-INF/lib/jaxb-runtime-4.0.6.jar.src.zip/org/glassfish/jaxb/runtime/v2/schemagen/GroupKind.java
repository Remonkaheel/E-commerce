/*    */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ContentModelContainer;
/*    */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Particle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum GroupKind
/*    */ {
/* 22 */   ALL("all"), SEQUENCE("sequence"), CHOICE("choice");
/*    */   
/*    */   private final String name;
/*    */   
/*    */   GroupKind(String name) {
/* 27 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Particle write(ContentModelContainer parent) {
/* 34 */     return (Particle)parent._element(this.name, Particle.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\GroupKind.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */