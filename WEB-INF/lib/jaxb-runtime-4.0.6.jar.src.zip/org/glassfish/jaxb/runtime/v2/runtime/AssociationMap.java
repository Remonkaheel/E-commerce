/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AssociationMap<XmlNode>
/*     */ {
/*     */   public static final class Entry<XmlNode>
/*     */   {
/*     */     private XmlNode element;
/*     */     private Object inner;
/*     */     private Object outer;
/*     */     
/*     */     public XmlNode element() {
/*  41 */       return this.element;
/*     */     }
/*     */     public Object inner() {
/*  44 */       return this.inner;
/*     */     }
/*     */     public Object outer() {
/*  47 */       return this.outer;
/*     */     }
/*     */   }
/*     */   
/*  51 */   private final Map<XmlNode, Entry<XmlNode>> byElement = new IdentityHashMap<>();
/*  52 */   private final Map<Object, Entry<XmlNode>> byPeer = new IdentityHashMap<>();
/*  53 */   private final Set<XmlNode> usedNodes = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInner(XmlNode element, Object inner) {
/*  62 */     Entry<XmlNode> e = this.byElement.get(element);
/*  63 */     if (e != null) {
/*  64 */       if (e.inner != null)
/*  65 */         this.byPeer.remove(e.inner); 
/*  66 */       e.inner = inner;
/*     */     } else {
/*  68 */       e = new Entry<>();
/*  69 */       e.element = element;
/*  70 */       e.inner = inner;
/*     */     } 
/*     */     
/*  73 */     this.byElement.put(element, e);
/*     */     
/*  75 */     Entry<XmlNode> old = this.byPeer.put(inner, e);
/*  76 */     if (old != null) {
/*  77 */       if (old.outer != null)
/*  78 */         this.byPeer.remove(old.outer); 
/*  79 */       if (old.element != null) {
/*  80 */         this.byElement.remove(old.element);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addOuter(XmlNode element, Object outer) {
/*  86 */     Entry<XmlNode> e = this.byElement.get(element);
/*  87 */     if (e != null) {
/*  88 */       if (e.outer != null)
/*  89 */         this.byPeer.remove(e.outer); 
/*     */     } else {
/*  91 */       e = new Entry<>();
/*  92 */       e.element = element;
/*     */     } 
/*  94 */     e.outer = outer;
/*     */     
/*  96 */     this.byElement.put(element, e);
/*     */     
/*  98 */     Entry<XmlNode> old = this.byPeer.put(outer, e);
/*  99 */     if (old != null) {
/* 100 */       old.outer = null;
/*     */       
/* 102 */       if (old.inner == null)
/*     */       {
/* 104 */         this.byElement.remove(old.element); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addUsed(XmlNode n) {
/* 109 */     this.usedNodes.add(n);
/*     */   }
/*     */   
/*     */   public Entry<XmlNode> byElement(Object e) {
/* 113 */     return this.byElement.get(e);
/*     */   }
/*     */   
/*     */   public Entry<XmlNode> byPeer(Object o) {
/* 117 */     return this.byPeer.get(o);
/*     */   }
/*     */   
/*     */   public Object getInnerPeer(XmlNode element) {
/* 121 */     Entry<XmlNode> e = byElement(element);
/* 122 */     if (e == null) return null; 
/* 123 */     return e.inner;
/*     */   }
/*     */   
/*     */   public Object getOuterPeer(XmlNode element) {
/* 127 */     Entry<XmlNode> e = byElement(element);
/* 128 */     if (e == null) return null; 
/* 129 */     return e.outer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\AssociationMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */