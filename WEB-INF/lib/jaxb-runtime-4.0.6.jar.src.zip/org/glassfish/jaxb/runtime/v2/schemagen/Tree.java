/*     */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.ContentModelContainer;
/*     */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Occurs;
/*     */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.Particle;
/*     */ import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.TypeDefParticle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Tree
/*     */ {
/*     */   Tree makeOptional(boolean really) {
/*  41 */     return really ? new Optional(this) : this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Tree makeRepeated(boolean really) {
/*  52 */     return really ? new Repeated(this) : this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Tree makeGroup(GroupKind kind, List<Tree> children) {
/*  60 */     if (children.size() == 1) {
/*  61 */       return children.get(0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     List<Tree> normalizedChildren = new ArrayList<>(children.size());
/*  68 */     for (Tree t : children) {
/*  69 */       if (t instanceof Group) {
/*  70 */         Group g = (Group)t;
/*  71 */         if (g.kind == kind) {
/*  72 */           normalizedChildren.addAll(Arrays.asList(g.children));
/*     */           continue;
/*     */         } 
/*     */       } 
/*  76 */       normalizedChildren.add(t);
/*     */     } 
/*     */     
/*  79 */     return new Group(kind, normalizedChildren.<Tree>toArray(new Tree[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean isNullable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canBeTopLevel() {
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void write(ContentModelContainer paramContentModelContainer, boolean paramBoolean1, boolean paramBoolean2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write(TypeDefParticle ct) {
/* 107 */     if (canBeTopLevel()) {
/* 108 */       write((ContentModelContainer)ct._cast(ContentModelContainer.class), false, false);
/*     */     } else {
/*     */       
/* 111 */       (new Group(GroupKind.SEQUENCE, new Tree[] { this })).write(ct);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void writeOccurs(Occurs o, boolean isOptional, boolean repeated) {
/* 118 */     if (isOptional)
/* 119 */       o.minOccurs(0); 
/* 120 */     if (repeated) {
/* 121 */       o.maxOccurs("unbounded");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static abstract class Term
/*     */     extends Tree
/*     */   {
/*     */     boolean isNullable() {
/* 130 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Optional
/*     */     extends Tree
/*     */   {
/*     */     private final Tree body;
/*     */     
/*     */     private Optional(Tree body) {
/* 141 */       this.body = body;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isNullable() {
/* 146 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     Tree makeOptional(boolean really) {
/* 151 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 156 */       this.body.write(parent, true, repeated);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Repeated
/*     */     extends Tree
/*     */   {
/*     */     private final Tree body;
/*     */     
/*     */     private Repeated(Tree body) {
/* 167 */       this.body = body;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isNullable() {
/* 172 */       return this.body.isNullable();
/*     */     }
/*     */ 
/*     */     
/*     */     Tree makeRepeated(boolean really) {
/* 177 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 182 */       this.body.write(parent, isOptional, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Group
/*     */     extends Tree
/*     */   {
/*     */     private final GroupKind kind;
/*     */     private final Tree[] children;
/*     */     
/*     */     private Group(GroupKind kind, Tree... children) {
/* 194 */       this.kind = kind;
/* 195 */       this.children = children;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean canBeTopLevel() {
/* 200 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isNullable() {
/* 205 */       if (this.kind == GroupKind.CHOICE) {
/* 206 */         for (Tree t : this.children) {
/* 207 */           if (t.isNullable())
/* 208 */             return true; 
/*     */         } 
/* 210 */         return false;
/*     */       } 
/* 212 */       for (Tree t : this.children) {
/* 213 */         if (!t.isNullable())
/* 214 */           return false; 
/*     */       } 
/* 216 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void write(ContentModelContainer parent, boolean isOptional, boolean repeated) {
/* 222 */       Particle c = this.kind.write(parent);
/* 223 */       writeOccurs((Occurs)c, isOptional, repeated);
/*     */       
/* 225 */       for (Tree child : this.children)
/* 226 */         child.write((ContentModelContainer)c, false, false); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\Tree.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */