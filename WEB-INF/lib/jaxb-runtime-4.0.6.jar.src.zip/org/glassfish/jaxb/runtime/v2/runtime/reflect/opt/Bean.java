/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Bean
/*    */ {
/*    */   public boolean f_boolean;
/*    */   public char f_char;
/*    */   public byte f_byte;
/*    */   public short f_short;
/*    */   int f_int;
/*    */   public long f_long;
/*    */   public float f_float;
/*    */   public double f_double;
/*    */   public Ref f_ref;
/*    */   
/*    */   public boolean get_boolean() {
/* 38 */     throw new UnsupportedOperationException(); } public void set_boolean(boolean b) {
/* 39 */     throw new UnsupportedOperationException();
/*    */   }
/* 41 */   public char get_char() { throw new UnsupportedOperationException(); } public void set_char(char b) {
/* 42 */     throw new UnsupportedOperationException();
/*    */   }
/* 44 */   public byte get_byte() { throw new UnsupportedOperationException(); } public void set_byte(byte b) {
/* 45 */     throw new UnsupportedOperationException();
/*    */   }
/* 47 */   public short get_short() { throw new UnsupportedOperationException(); } public void set_short(short b) {
/* 48 */     throw new UnsupportedOperationException();
/*    */   }
/* 50 */   public int get_int() { throw new UnsupportedOperationException(); } public void set_int(int b) {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/* 53 */   public long get_long() { throw new UnsupportedOperationException(); } public void set_long(long b) {
/* 54 */     throw new UnsupportedOperationException();
/*    */   }
/* 56 */   public float get_float() { throw new UnsupportedOperationException(); } public void set_float(float b) {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/* 59 */   public double get_double() { throw new UnsupportedOperationException(); } public void set_double(double b) {
/* 60 */     throw new UnsupportedOperationException();
/*    */   }
/* 62 */   public Ref get_ref() { throw new UnsupportedOperationException(); } public void set_ref(Ref r) {
/* 63 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\Bean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */