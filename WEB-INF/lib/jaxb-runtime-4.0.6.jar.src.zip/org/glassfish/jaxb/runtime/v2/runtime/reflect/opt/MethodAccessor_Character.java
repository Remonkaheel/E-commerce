/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Character<B>
/*    */   extends Accessor<B, Character>
/*    */ {
/*    */   public MethodAccessor_Character() {
/* 27 */     super(Character.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Character get(B bean) {
/* 32 */     return Character.valueOf(((Bean)bean).get_char());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Character value) {
/* 37 */     ((Bean)bean).set_char((value == null) ? Character.MIN_VALUE : value.charValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Character.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */