package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;

@XmlElement("complexContent")
public interface ComplexContent extends TypedXmlWriter, Annotated {
  @XmlElement
  ComplexExtension extension();
  
  @XmlElement
  ComplexRestriction restriction();
  
  @XmlAttribute
  ComplexContent mixed(boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\ComplexContent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */