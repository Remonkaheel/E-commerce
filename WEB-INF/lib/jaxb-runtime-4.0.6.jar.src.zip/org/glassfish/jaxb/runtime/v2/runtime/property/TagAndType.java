/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TagAndType
/*    */ {
/*    */   final Name tagName;
/*    */   final JaxBeanInfo beanInfo;
/*    */   
/*    */   TagAndType(Name tagName, JaxBeanInfo beanInfo) {
/* 27 */     this.tagName = tagName;
/* 28 */     this.beanInfo = beanInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\TagAndType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */