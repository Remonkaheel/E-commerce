/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.util.HashMap;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Coordinator
/*     */   implements ErrorHandler, ValidationEventHandler
/*     */ {
/*  50 */   private final HashMap<Class<? extends XmlAdapter>, XmlAdapter> adapters = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final XmlAdapter putAdapter(Class<? extends XmlAdapter> c, XmlAdapter a) {
/*  59 */     if (a == null) {
/*  60 */       return this.adapters.remove(c);
/*     */     }
/*  62 */     return this.adapters.put(c, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends XmlAdapter> T getAdapter(Class<T> key) {
/*  72 */     XmlAdapter xmlAdapter = (XmlAdapter)key.cast(this.adapters.get(key));
/*  73 */     if (xmlAdapter == null) {
/*  74 */       xmlAdapter = (XmlAdapter)ClassFactory.create(key);
/*  75 */       putAdapter(key, xmlAdapter);
/*     */     } 
/*  77 */     return (T)xmlAdapter;
/*     */   }
/*     */   
/*     */   public <T extends XmlAdapter> boolean containsAdapter(Class<T> type) {
/*  81 */     return this.adapters.containsKey(type);
/*     */   }
/*     */ 
/*     */   
/*  85 */   private static final ThreadLocal<Coordinator> activeTable = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Coordinator old;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void pushCoordinator() {
/*  96 */     this.old = activeTable.get();
/*  97 */     activeTable.set(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void popCoordinator() {
/* 104 */     if (this.old != null) {
/* 105 */       activeTable.set(this.old);
/*     */     } else {
/* 107 */       activeTable.remove();
/* 108 */     }  this.old = null;
/*     */   }
/*     */   
/*     */   public static Coordinator _getInstance() {
/* 112 */     return activeTable.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ValidationEventLocator getLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void error(SAXParseException exception) throws SAXException {
/* 127 */     propagateEvent(1, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void warning(SAXParseException exception) throws SAXException {
/* 132 */     propagateEvent(0, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void fatalError(SAXParseException exception) throws SAXException {
/* 137 */     propagateEvent(2, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void propagateEvent(int severity, SAXParseException saxException) throws SAXException {
/* 144 */     ValidationEventImpl ve = new ValidationEventImpl(severity, saxException.getMessage(), getLocation());
/*     */     
/* 146 */     Exception e = saxException.getException();
/* 147 */     if (e != null) {
/* 148 */       ve.setLinkedException(e);
/*     */     } else {
/* 150 */       ve.setLinkedException(saxException);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 155 */     boolean result = handleEvent((ValidationEvent)ve);
/* 156 */     if (!result)
/*     */     {
/*     */       
/* 159 */       throw saxException;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\Coordinator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */