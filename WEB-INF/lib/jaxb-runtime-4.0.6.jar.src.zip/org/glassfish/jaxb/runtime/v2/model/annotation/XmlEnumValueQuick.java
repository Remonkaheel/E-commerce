/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlEnumValueQuick
/*    */   extends Quick
/*    */   implements XmlEnumValue
/*    */ {
/*    */   private final XmlEnumValue core;
/*    */   
/*    */   public XmlEnumValueQuick(Locatable upstream, XmlEnumValue core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlEnumValueQuick(upstream, (XmlEnumValue)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlEnumValue> annotationType() {
/* 47 */     return XmlEnumValue.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String value() {
/* 52 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlEnumValueQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */