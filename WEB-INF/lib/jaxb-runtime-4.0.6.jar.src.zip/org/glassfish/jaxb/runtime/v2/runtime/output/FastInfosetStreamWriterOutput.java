/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import com.sun.xml.fastinfoset.stax.StAXDocumentSerializer;
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.NoEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Base64Data;
/*     */ import org.jvnet.fastinfoset.VocabularyApplicationData;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FastInfosetStreamWriterOutput
/*     */   extends XMLStreamWriterOutput
/*     */ {
/*     */   private final StAXDocumentSerializer fiout;
/*     */   private final Encoded[] localNames;
/*     */   private final TablesPerJAXBContext tables;
/*     */   
/*     */   static final class TablesPerJAXBContext
/*     */   {
/*     */     final int[] elementIndexes;
/*     */     final int[] elementIndexPrefixes;
/*     */     final int[] attributeIndexes;
/*     */     final int[] localNameIndexes;
/*     */     int indexOffset;
/*     */     int maxIndex;
/*     */     boolean requiresClear;
/*     */     
/*     */     TablesPerJAXBContext(JAXBContextImpl context, int initialIndexOffset) {
/*  95 */       this.elementIndexes = new int[context.getNumberOfElementNames()];
/*  96 */       this.elementIndexPrefixes = new int[context.getNumberOfElementNames()];
/*  97 */       this.attributeIndexes = new int[context.getNumberOfAttributeNames()];
/*  98 */       this.localNameIndexes = new int[context.getNumberOfLocalNames()];
/*     */       
/* 100 */       this.indexOffset = 1;
/* 101 */       this.maxIndex = initialIndexOffset + this.elementIndexes.length + this.attributeIndexes.length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void requireClearTables() {
/* 108 */       this.requiresClear = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clearOrResetTables(int intialIndexOffset) {
/* 118 */       if (this.requiresClear) {
/* 119 */         this.requiresClear = false;
/*     */ 
/*     */         
/* 122 */         this.indexOffset += this.maxIndex;
/*     */         
/* 124 */         this.maxIndex = intialIndexOffset + this.elementIndexes.length + this.attributeIndexes.length;
/*     */ 
/*     */         
/* 127 */         if (this.indexOffset + this.maxIndex < 0) {
/* 128 */           clearAll();
/*     */         }
/*     */       } else {
/*     */         
/* 132 */         this.maxIndex = intialIndexOffset + this.elementIndexes.length + this.attributeIndexes.length;
/*     */ 
/*     */         
/* 135 */         if (this.indexOffset + this.maxIndex < 0) {
/* 136 */           resetAll();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void clearAll() {
/* 142 */       clear(this.elementIndexes);
/* 143 */       clear(this.attributeIndexes);
/* 144 */       clear(this.localNameIndexes);
/* 145 */       this.indexOffset = 1;
/*     */     }
/*     */     
/*     */     private void clear(int[] array) {
/* 149 */       Arrays.fill(array, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void incrementMaxIndexValue() {
/* 159 */       this.maxIndex++;
/*     */ 
/*     */       
/* 162 */       if (this.indexOffset + this.maxIndex < 0) {
/* 163 */         resetAll();
/*     */       }
/*     */     }
/*     */     
/*     */     private void resetAll() {
/* 168 */       clear(this.elementIndexes);
/* 169 */       clear(this.attributeIndexes);
/* 170 */       clear(this.localNameIndexes);
/* 171 */       this.indexOffset = 1;
/*     */     }
/*     */     
/*     */     private void reset(int[] array) {
/* 175 */       for (int i = 0; i < array.length; i++) {
/* 176 */         if (array[i] > this.indexOffset) {
/* 177 */           array[i] = array[i] - this.indexOffset + 1;
/*     */         } else {
/* 179 */           array[i] = 0;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AppData
/*     */     implements VocabularyApplicationData
/*     */   {
/* 193 */     final Map<JAXBContext, FastInfosetStreamWriterOutput.TablesPerJAXBContext> contexts = new WeakHashMap<>();
/*     */     
/* 195 */     final Collection<FastInfosetStreamWriterOutput.TablesPerJAXBContext> collectionOfContexts = this.contexts.values();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/* 202 */       for (FastInfosetStreamWriterOutput.TablesPerJAXBContext c : this.collectionOfContexts) {
/* 203 */         c.requireClearTables();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public FastInfosetStreamWriterOutput(StAXDocumentSerializer out, JAXBContextImpl context) {
/* 209 */     super((XMLStreamWriter)out, (CharacterEscapeHandler)NoEscapeHandler.theInstance);
/*     */     
/* 211 */     this.fiout = out;
/* 212 */     this.localNames = context.getUTF8NameTable();
/*     */     
/* 214 */     VocabularyApplicationData vocabAppData = this.fiout.getVocabularyApplicationData();
/* 215 */     AppData appData = null;
/* 216 */     if (!(vocabAppData instanceof AppData)) {
/* 217 */       appData = new AppData();
/* 218 */       this.fiout.setVocabularyApplicationData(appData);
/*     */     } else {
/* 220 */       appData = (AppData)vocabAppData;
/*     */     } 
/*     */     
/* 223 */     TablesPerJAXBContext tablesPerContext = appData.contexts.get(context);
/* 224 */     if (tablesPerContext != null) {
/* 225 */       this.tables = tablesPerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 230 */       this.tables.clearOrResetTables(out.getLocalNameIndex());
/*     */     } else {
/* 232 */       this.tables = new TablesPerJAXBContext(context, out.getLocalNameIndex());
/* 233 */       appData.contexts.put(context, this.tables);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/* 241 */     super.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*     */     
/* 243 */     if (fragment) {
/* 244 */       this.fiout.initiateLowLevelWriting();
/*     */     }
/*     */   }
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/* 249 */     super.endDocument(fragment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(Name name) throws IOException {
/* 254 */     this.fiout.writeLowLevelTerminationAndMark();
/*     */     
/* 256 */     if (this.nsContext.getCurrent().count() == 0) {
/* 257 */       int qNameIndex = this.tables.elementIndexes[name.qNameIndex] - this.tables.indexOffset;
/* 258 */       int prefixIndex = this.nsUriIndex2prefixIndex[name.nsUriIndex];
/*     */       
/* 260 */       if (qNameIndex >= 0 && this.tables.elementIndexPrefixes[name.qNameIndex] == prefixIndex) {
/*     */         
/* 262 */         this.fiout.writeLowLevelStartElementIndexed(0, qNameIndex);
/*     */       } else {
/* 264 */         this.tables.elementIndexes[name.qNameIndex] = this.fiout.getNextElementIndex() + this.tables.indexOffset;
/* 265 */         this.tables.elementIndexPrefixes[name.qNameIndex] = prefixIndex;
/* 266 */         writeLiteral(60, name, this.nsContext
/*     */             
/* 268 */             .getPrefix(prefixIndex), this.nsContext
/* 269 */             .getNamespaceURI(prefixIndex));
/*     */       } 
/*     */     } else {
/* 272 */       beginStartTagWithNamespaces(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void beginStartTagWithNamespaces(Name name) throws IOException {
/* 277 */     NamespaceContextImpl.Element nse = this.nsContext.getCurrent();
/*     */     
/* 279 */     this.fiout.writeLowLevelStartNamespaces();
/* 280 */     for (int i = nse.count() - 1; i >= 0; i--) {
/* 281 */       String uri = nse.getNsUri(i);
/* 282 */       if (uri.length() != 0 || nse.getBase() != 1)
/*     */       {
/* 284 */         this.fiout.writeLowLevelNamespace(nse.getPrefix(i), uri); } 
/*     */     } 
/* 286 */     this.fiout.writeLowLevelEndNamespaces();
/*     */     
/* 288 */     int qNameIndex = this.tables.elementIndexes[name.qNameIndex] - this.tables.indexOffset;
/* 289 */     int prefixIndex = this.nsUriIndex2prefixIndex[name.nsUriIndex];
/*     */     
/* 291 */     if (qNameIndex >= 0 && this.tables.elementIndexPrefixes[name.qNameIndex] == prefixIndex) {
/*     */       
/* 293 */       this.fiout.writeLowLevelStartElementIndexed(0, qNameIndex);
/*     */     } else {
/* 295 */       this.tables.elementIndexes[name.qNameIndex] = this.fiout.getNextElementIndex() + this.tables.indexOffset;
/* 296 */       this.tables.elementIndexPrefixes[name.qNameIndex] = prefixIndex;
/* 297 */       writeLiteral(60, name, this.nsContext
/*     */           
/* 299 */           .getPrefix(prefixIndex), this.nsContext
/* 300 */           .getNamespaceURI(prefixIndex));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void attribute(Name name, String value) throws IOException {
/* 306 */     this.fiout.writeLowLevelStartAttributes();
/*     */     
/* 308 */     int qNameIndex = this.tables.attributeIndexes[name.qNameIndex] - this.tables.indexOffset;
/* 309 */     if (qNameIndex >= 0) {
/* 310 */       this.fiout.writeLowLevelAttributeIndexed(qNameIndex);
/*     */     } else {
/* 312 */       this.tables.attributeIndexes[name.qNameIndex] = this.fiout.getNextAttributeIndex() + this.tables.indexOffset;
/*     */       
/* 314 */       int namespaceURIId = name.nsUriIndex;
/* 315 */       if (namespaceURIId == -1) {
/* 316 */         writeLiteral(120, name, "", "");
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 321 */         int prefix = this.nsUriIndex2prefixIndex[namespaceURIId];
/* 322 */         writeLiteral(120, name, this.nsContext
/*     */             
/* 324 */             .getPrefix(prefix), this.nsContext
/* 325 */             .getNamespaceURI(prefix));
/*     */       } 
/*     */     } 
/*     */     
/* 329 */     this.fiout.writeLowLevelAttributeValue(value);
/*     */   }
/*     */   
/*     */   private void writeLiteral(int type, Name name, String prefix, String namespaceURI) throws IOException {
/* 333 */     int localNameIndex = this.tables.localNameIndexes[name.localNameIndex] - this.tables.indexOffset;
/*     */     
/* 335 */     if (localNameIndex < 0) {
/* 336 */       this.tables.localNameIndexes[name.localNameIndex] = this.fiout.getNextLocalNameIndex() + this.tables.indexOffset;
/*     */       
/* 338 */       this.fiout.writeLowLevelStartNameLiteral(type, prefix, (this.localNames[name.localNameIndex]).buf, namespaceURI);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 344 */       this.fiout.writeLowLevelStartNameLiteral(type, prefix, localNameIndex, namespaceURI);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endStartTag() throws IOException {
/* 354 */     this.fiout.writeLowLevelEndStartElement();
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(Name name) throws IOException {
/* 359 */     this.fiout.writeLowLevelEndElement();
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws IOException {
/* 364 */     this.fiout.writeLowLevelEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needsSeparatingWhitespace) throws IOException {
/* 370 */     if (needsSeparatingWhitespace) {
/* 371 */       this.fiout.writeLowLevelText(" ");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 376 */     if (!(value instanceof Base64Data)) {
/* 377 */       int len = value.length();
/* 378 */       if (len < this.buf.length) {
/* 379 */         value.writeTo(this.buf, 0);
/* 380 */         this.fiout.writeLowLevelText(this.buf, len);
/*     */       } else {
/* 382 */         this.fiout.writeLowLevelText(value.toString());
/*     */       } 
/*     */     } else {
/* 385 */       Base64Data dataValue = (Base64Data)value;
/*     */       
/* 387 */       this.fiout.writeLowLevelOctets(dataValue.get(), dataValue.getDataLen());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(String value, boolean needsSeparatingWhitespace) throws IOException {
/* 394 */     if (needsSeparatingWhitespace) {
/* 395 */       this.fiout.writeLowLevelText(" ");
/*     */     }
/* 397 */     this.fiout.writeLowLevelText(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) throws IOException {
/* 403 */     this.fiout.writeLowLevelTerminationAndMark();
/*     */     
/* 405 */     int type = 0;
/* 406 */     if (this.nsContext.getCurrent().count() > 0) {
/* 407 */       NamespaceContextImpl.Element nse = this.nsContext.getCurrent();
/*     */       
/* 409 */       this.fiout.writeLowLevelStartNamespaces();
/* 410 */       for (int i = nse.count() - 1; i >= 0; i--) {
/* 411 */         String uri = nse.getNsUri(i);
/* 412 */         if (uri.length() != 0 || nse.getBase() != 1)
/*     */         {
/* 414 */           this.fiout.writeLowLevelNamespace(nse.getPrefix(i), uri); } 
/*     */       } 
/* 416 */       this.fiout.writeLowLevelEndNamespaces();
/*     */       
/* 418 */       type = 0;
/*     */     } 
/*     */     
/* 421 */     boolean isIndexed = this.fiout.writeLowLevelStartElement(type, this.nsContext
/*     */         
/* 423 */         .getPrefix(prefix), localName, this.nsContext
/*     */         
/* 425 */         .getNamespaceURI(prefix));
/*     */     
/* 427 */     if (!isIndexed)
/* 428 */       this.tables.incrementMaxIndexValue(); 
/*     */   }
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) throws IOException {
/*     */     boolean isIndexed;
/* 433 */     this.fiout.writeLowLevelStartAttributes();
/*     */ 
/*     */     
/* 436 */     if (prefix == -1) {
/* 437 */       isIndexed = this.fiout.writeLowLevelAttribute("", "", localName);
/*     */     } else {
/* 439 */       isIndexed = this.fiout.writeLowLevelAttribute(this.nsContext
/* 440 */           .getPrefix(prefix), this.nsContext
/* 441 */           .getNamespaceURI(prefix), localName);
/*     */     } 
/*     */     
/* 444 */     if (!isIndexed) {
/* 445 */       this.tables.incrementMaxIndexValue();
/*     */     }
/* 447 */     this.fiout.writeLowLevelAttributeValue(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\FastInfosetStreamWriterOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */