/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class C14nXmlOutput
/*     */   extends UTF8XmlOutput
/*     */ {
/*     */   private StaticAttribute[] staticAttributes;
/*     */   private int len;
/*     */   private int[] nsBuf;
/*     */   private final FinalArrayList<DynamicAttribute> otherAttributes;
/*     */   private final boolean namedAttributesAreOrdered;
/*     */   
/*     */   public C14nXmlOutput(OutputStream out, Encoded[] localNames, boolean namedAttributesAreOrdered, CharacterEscapeHandler escapeHandler) {
/*  30 */     super(out, localNames, escapeHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  42 */     this.staticAttributes = new StaticAttribute[8];
/*  43 */     this.len = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     this.nsBuf = new int[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.otherAttributes = new FinalArrayList();
/*     */     this.namedAttributesAreOrdered = namedAttributesAreOrdered;
/*     */     for (int i = 0; i < this.staticAttributes.length; i++) {
/*     */       this.staticAttributes[i] = new StaticAttribute();
/*     */     }
/*     */   }
/*     */   
/*     */   final class StaticAttribute
/*     */     implements Comparable<StaticAttribute>
/*     */   {
/*     */     Name name;
/*     */     String value;
/*     */     
/*     */     public void set(Name name, String value) {
/*  70 */       this.name = name;
/*  71 */       this.value = value;
/*     */     }
/*     */     
/*     */     void write() throws IOException {
/*  75 */       C14nXmlOutput.this.attribute(this.name, this.value);
/*     */     }
/*     */     
/*     */     C14nXmlOutput.DynamicAttribute toDynamicAttribute() {
/*  79 */       int prefix, nsUriIndex = this.name.nsUriIndex;
/*     */       
/*  81 */       if (nsUriIndex == -1) {
/*  82 */         prefix = -1;
/*     */       } else {
/*  84 */         prefix = C14nXmlOutput.this.nsUriIndex2prefixIndex[nsUriIndex];
/*  85 */       }  return new C14nXmlOutput.DynamicAttribute(prefix, this.name.localName, this.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(StaticAttribute that) {
/*  91 */       return this.name.compareTo(that.name);
/*     */     }
/*     */   }
/*     */   
/*     */   final class DynamicAttribute
/*     */     implements Comparable<DynamicAttribute> {
/*     */     final int prefix;
/*     */     final String localName;
/*     */     final String value;
/*     */     
/*     */     public DynamicAttribute(int prefix, String localName, String value) {
/* 102 */       this.prefix = prefix;
/* 103 */       this.localName = localName;
/* 104 */       this.value = value;
/*     */     }
/*     */     
/*     */     private String getURI() {
/* 108 */       if (this.prefix == -1) return ""; 
/* 109 */       return C14nXmlOutput.this.nsContext.getNamespaceURI(this.prefix);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(DynamicAttribute that) {
/* 114 */       int r = getURI().compareTo(that.getURI());
/* 115 */       if (r != 0) return r; 
/* 116 */       return this.localName.compareTo(that.localName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void attribute(Name name, String value) throws IOException {
/* 122 */     if (this.staticAttributes.length == this.len) {
/*     */       
/* 124 */       int newLen = this.len * 2;
/* 125 */       StaticAttribute[] newbuf = new StaticAttribute[newLen];
/* 126 */       System.arraycopy(this.staticAttributes, 0, newbuf, 0, this.len);
/* 127 */       for (int i = this.len; i < newLen; i++) {
/* 128 */         newbuf[i] = new StaticAttribute();
/*     */       }
/* 130 */       this.staticAttributes = newbuf;
/*     */     } 
/*     */     
/* 133 */     this.staticAttributes[this.len++].set(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) throws IOException {
/* 138 */     this.otherAttributes.add(new DynamicAttribute(prefix, localName, value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag() throws IOException {
/* 143 */     if (this.otherAttributes.isEmpty()) {
/* 144 */       if (this.len != 0)
/*     */       {
/*     */         
/* 147 */         if (!this.namedAttributesAreOrdered) {
/* 148 */           Arrays.sort((Object[])this.staticAttributes, 0, this.len);
/*     */         }
/* 150 */         for (int i = 0; i < this.len; i++)
/* 151 */           this.staticAttributes[i].write(); 
/* 152 */         this.len = 0;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 158 */       for (int i = 0; i < this.len; i++)
/* 159 */         this.otherAttributes.add(this.staticAttributes[i].toDynamicAttribute()); 
/* 160 */       this.len = 0;
/* 161 */       Collections.sort((List<DynamicAttribute>)this.otherAttributes);
/*     */ 
/*     */       
/* 164 */       int size = this.otherAttributes.size();
/* 165 */       for (int j = 0; j < size; j++) {
/* 166 */         DynamicAttribute a = (DynamicAttribute)this.otherAttributes.get(j);
/* 167 */         super.attribute(a.prefix, a.localName, a.value);
/*     */       } 
/* 169 */       this.otherAttributes.clear();
/*     */     } 
/* 171 */     super.endStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNsDecls(int base) throws IOException {
/* 179 */     int count = this.nsContext.getCurrent().count();
/*     */     
/* 181 */     if (count == 0) {
/*     */       return;
/*     */     }
/* 184 */     if (count > this.nsBuf.length)
/* 185 */       this.nsBuf = new int[count]; 
/*     */     int i;
/* 187 */     for (i = count - 1; i >= 0; i--) {
/* 188 */       this.nsBuf[i] = base + i;
/*     */     }
/*     */ 
/*     */     
/* 192 */     for (i = 0; i < count; i++) {
/* 193 */       for (int j = i + 1; j < count; j++) {
/* 194 */         String p = this.nsContext.getPrefix(this.nsBuf[i]);
/* 195 */         String q = this.nsContext.getPrefix(this.nsBuf[j]);
/* 196 */         if (p.compareTo(q) > 0) {
/*     */           
/* 198 */           int t = this.nsBuf[j];
/* 199 */           this.nsBuf[j] = this.nsBuf[i];
/* 200 */           this.nsBuf[i] = t;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 206 */     for (i = 0; i < count; i++)
/* 207 */       writeNsDecl(this.nsBuf[i]); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\C14nXmlOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */