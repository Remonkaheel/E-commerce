package org.glassfish.jaxb.runtime.v2.runtime;

public interface AttributeAccessor<BeanT> {
  boolean isNilIncluded();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\AttributeAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */