/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*    */ import java.lang.annotation.Annotation;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ERPropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   extends PropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */ {
/*    */   private final QName xmlName;
/*    */   private final boolean wrapperNillable;
/*    */   private final boolean wrapperRequired;
/*    */   
/*    */   public ERPropertyInfoImpl(ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> classInfo, PropertySeed<TypeT, ClassDeclT, FieldT, MethodT> propertySeed) {
/* 27 */     super(classInfo, propertySeed);
/*    */     
/* 29 */     XmlElementWrapper e = (XmlElementWrapper)this.seed.readAnnotation(XmlElementWrapper.class);
/*    */     
/* 31 */     boolean nil = false;
/* 32 */     boolean required = false;
/* 33 */     if (!isCollection()) {
/* 34 */       this.xmlName = null;
/* 35 */       if (e != null) {
/* 36 */         classInfo.builder.reportError(new IllegalAnnotationException(Messages.XML_ELEMENT_WRAPPER_ON_NON_COLLECTION
/* 37 */               .format(new Object[] {
/* 38 */                   nav().getClassName(this.parent.getClazz()) + "." + nav().getClassName(this.parent.getClazz())
/*    */                 }, ), (Annotation)e));
/*    */       }
/*    */     }
/* 42 */     else if (e != null) {
/* 43 */       this.xmlName = calcXmlName(e);
/* 44 */       nil = e.nillable();
/* 45 */       required = e.required();
/*    */     } else {
/* 47 */       this.xmlName = null;
/*    */     } 
/*    */     
/* 50 */     this.wrapperNillable = nil;
/* 51 */     this.wrapperRequired = required;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final QName getXmlName() {
/* 70 */     return this.xmlName;
/*    */   }
/*    */   
/*    */   public final boolean isCollectionNillable() {
/* 74 */     return this.wrapperNillable;
/*    */   }
/*    */   
/*    */   public final boolean isCollectionRequired() {
/* 78 */     return this.wrapperRequired;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ERPropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */