package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import javax.xml.namespace.QName;

public interface Element extends TypedXmlWriter, Annotated, ComplexTypeHost, FixedOrDefault, SimpleTypeHost {
  @XmlAttribute
  Element type(QName paramQName);
  
  @XmlAttribute
  Element block(String paramString);
  
  @XmlAttribute
  Element block(String[] paramArrayOfString);
  
  @XmlAttribute
  Element nillable(boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\Element.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */