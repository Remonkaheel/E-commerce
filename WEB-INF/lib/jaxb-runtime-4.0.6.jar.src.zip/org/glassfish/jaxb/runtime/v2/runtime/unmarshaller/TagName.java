/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TagName
/*     */ {
/*     */   public String uri;
/*     */   public String local;
/*     */   public Attributes atts;
/*     */   
/*     */   public final boolean matches(String nsUri, String local) {
/*  69 */     return (this.uri == nsUri && this.local == local);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean matches(Name name) {
/*  76 */     return (this.local == name.localName && this.uri == name.nsUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  91 */     return "{" + this.uri + "}" + this.local;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getQname();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 107 */     String qname = getQname();
/* 108 */     int idx = qname.indexOf(':');
/* 109 */     if (idx < 0) return ""; 
/* 110 */     return qname.substring(0, idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName createQName() {
/* 117 */     return new QName(this.uri, this.local, getPrefix());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\TagName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */