/*    */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MultiMap<K extends Comparable<K>, V>
/*    */   extends TreeMap<K, V>
/*    */ {
/*    */   private static final long serialVersionUID = 236563410947519673L;
/*    */   private final V many;
/*    */   
/*    */   public MultiMap(V many) {
/* 32 */     this.many = many;
/*    */   }
/*    */ 
/*    */   
/*    */   public V put(K key, V value) {
/* 37 */     V old = super.put(key, value);
/* 38 */     if (old != null && !old.equals(value))
/*    */     {
/* 40 */       super.put(key, this.many);
/*    */     }
/* 42 */     return old;
/*    */   }
/*    */ 
/*    */   
/*    */   public void putAll(Map<? extends K, ? extends V> map) {
/* 47 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\MultiMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */