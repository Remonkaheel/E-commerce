/*     */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocatableAnnotation
/*     */   implements InvocationHandler, Locatable, Location
/*     */ {
/*     */   private final Annotation core;
/*     */   private final Locatable upstream;
/*     */   
/*     */   public static <A extends Annotation> A create(A annotation, Locatable parentSourcePos) {
/*  37 */     if (annotation == null) return null; 
/*  38 */     Class<? extends Annotation> type = annotation.annotationType();
/*  39 */     if (quicks.containsKey(type))
/*     */     {
/*  41 */       return (A)((Quick)quicks.get(type)).newInstance(parentSourcePos, (Annotation)annotation);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  46 */     ClassLoader cl = SecureLoader.getClassClassLoader(LocatableAnnotation.class);
/*     */     
/*     */     try {
/*  49 */       Class<?> loadableT = Class.forName(type.getName(), false, cl);
/*  50 */       if (loadableT != type) {
/*  51 */         return annotation;
/*     */       }
/*  53 */       return (A)Proxy.newProxyInstance(cl, new Class[] { type, Locatable.class }, new LocatableAnnotation((Annotation)annotation, parentSourcePos));
/*     */     
/*     */     }
/*  56 */     catch (ClassNotFoundException e) {
/*     */       
/*  58 */       return annotation;
/*  59 */     } catch (IllegalArgumentException e) {
/*     */ 
/*     */       
/*  62 */       return annotation;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   LocatableAnnotation(Annotation core, Locatable upstream) {
/*  68 */     this.core = core;
/*  69 */     this.upstream = upstream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Locatable getUpstream() {
/*  74 */     return this.upstream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     try {
/*  85 */       if (method.getDeclaringClass() == Locatable.class)
/*  86 */         return method.invoke(this, args); 
/*  87 */       if (Modifier.isStatic(method.getModifiers()))
/*     */       {
/*     */ 
/*     */         
/*  91 */         throw new IllegalArgumentException();
/*     */       }
/*  93 */       return method.invoke(this.core, args);
/*  94 */     } catch (InvocationTargetException e) {
/*  95 */       if (e.getTargetException() != null)
/*  96 */         throw e.getTargetException(); 
/*  97 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return this.core.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static final Map<Class, Quick> quicks = (Map)new HashMap<>();
/*     */   
/*     */   static {
/* 113 */     for (Quick q : Init.getAll())
/* 114 */       quicks.put(q.annotationType(), q); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\LocatableAnnotation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */