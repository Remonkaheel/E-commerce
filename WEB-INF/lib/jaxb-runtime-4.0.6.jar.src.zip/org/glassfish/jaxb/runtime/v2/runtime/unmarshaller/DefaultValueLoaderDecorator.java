/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultValueLoaderDecorator
/*    */   extends Loader
/*    */ {
/*    */   private final Loader l;
/*    */   private final String defaultValue;
/*    */   
/*    */   public DefaultValueLoaderDecorator(Loader l, String defaultValue) {
/* 25 */     this.l = l;
/* 26 */     this.defaultValue = defaultValue;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 32 */     if (state.getElementDefaultValue() == null) {
/* 33 */       state.setElementDefaultValue(this.defaultValue);
/*    */     }
/* 35 */     state.setLoader(this.l);
/* 36 */     this.l.startElement(state, ea);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\DefaultValueLoaderDecorator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */