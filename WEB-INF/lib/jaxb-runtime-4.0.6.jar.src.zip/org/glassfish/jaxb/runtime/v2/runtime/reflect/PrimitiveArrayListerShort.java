/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerShort<BeanT>
/*    */   extends Lister<BeanT, short[], Short, PrimitiveArrayListerShort.ShortArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     Lister.primitiveArrayListers.put(short.class, new PrimitiveArrayListerShort());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Short> iterator(final short[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Short>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Short next() {
/* 47 */           return Short.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public ShortArrayPack startPacking(BeanT current, Accessor<BeanT, short[]> acc) {
/* 54 */     return new ShortArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(ShortArrayPack objects, Short o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(ShortArrayPack pack, BeanT bean, Accessor<BeanT, short[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, short[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new short[0]);
/*    */   }
/*    */   
/*    */   static final class ShortArrayPack {
/* 73 */     short[] buf = new short[16];
/*    */     int size;
/*    */     
/*    */     void add(Short b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         short[] nb = new short[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.shortValue(); 
/*    */     }
/*    */     
/*    */     short[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       short[] r = new short[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerShort.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */