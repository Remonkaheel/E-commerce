/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.Pcdata;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.UTF8XmlOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IntArrayData
/*     */   extends Pcdata
/*     */ {
/*     */   private int[] data;
/*     */   private int start;
/*     */   private int len;
/*     */   private StringBuilder literal;
/*     */   
/*     */   public IntArrayData(int[] data, int start, int len) {
/*  45 */     set(data, start, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntArrayData() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int[] data, int start, int len) {
/*  61 */     this.data = data;
/*  62 */     this.start = start;
/*  63 */     this.len = len;
/*  64 */     this.literal = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  69 */     return getLiteral().length();
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*  74 */     return getLiteral().charAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/*  79 */     return getLiteral().subSequence(start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringBuilder getLiteral() {
/*  86 */     if (this.literal != null) return this.literal;
/*     */     
/*  88 */     this.literal = new StringBuilder();
/*  89 */     int p = this.start;
/*  90 */     for (int i = this.len; i > 0; i--) {
/*  91 */       if (this.literal.length() > 0) this.literal.append(' '); 
/*  92 */       this.literal.append(this.data[p++]);
/*     */     } 
/*     */     
/*  95 */     return this.literal;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     return this.literal.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(UTF8XmlOutput output) throws IOException {
/* 105 */     int p = this.start;
/* 106 */     for (int i = this.len; i > 0; i--) {
/* 107 */       if (i != this.len)
/* 108 */         output.write(32); 
/* 109 */       output.text(this.data[p++]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\IntArrayData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */