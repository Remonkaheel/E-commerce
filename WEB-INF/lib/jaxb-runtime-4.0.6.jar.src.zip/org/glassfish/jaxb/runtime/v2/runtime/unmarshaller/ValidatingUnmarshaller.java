/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.validation.Schema;
/*     */ import javax.xml.validation.ValidatorHandler;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.glassfish.jaxb.runtime.v2.util.FatalAdapter;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ValidatingUnmarshaller
/*     */   implements XmlVisitor, XmlVisitor.TextPredictor
/*     */ {
/*     */   private final XmlVisitor next;
/*     */   private final ValidatorHandler validator;
/*  30 */   private NamespaceContext nsContext = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private final XmlVisitor.TextPredictor predictor;
/*     */ 
/*     */   
/*  37 */   private char[] buf = new char[256];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidatingUnmarshaller(Schema schema, XmlVisitor next) {
/*  43 */     this.validator = schema.newValidatorHandler();
/*  44 */     this.next = next;
/*  45 */     this.predictor = next.getPredictor();
/*     */ 
/*     */     
/*  48 */     this.validator.setErrorHandler((ErrorHandler)new FatalAdapter(getContext()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument(LocatorEx locator, NamespaceContext nsContext) throws SAXException {
/*  53 */     this.nsContext = nsContext;
/*  54 */     this.validator.setDocumentLocator((Locator)locator);
/*  55 */     this.validator.startDocument();
/*  56 */     this.next.startDocument(locator, nsContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {
/*  61 */     this.nsContext = null;
/*  62 */     this.validator.endDocument();
/*  63 */     this.next.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(TagName tagName) throws SAXException {
/*  68 */     if (this.nsContext != null) {
/*  69 */       String tagNamePrefix = tagName.getPrefix().intern();
/*  70 */       if (tagNamePrefix != "") {
/*  71 */         this.validator.startPrefixMapping(tagNamePrefix, this.nsContext.getNamespaceURI(tagNamePrefix));
/*     */       }
/*     */     } 
/*  74 */     this.validator.startElement(tagName.uri, tagName.local, tagName.getQname(), tagName.atts);
/*  75 */     this.next.startElement(tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(TagName tagName) throws SAXException {
/*  80 */     this.validator.endElement(tagName.uri, tagName.local, tagName.getQname());
/*  81 */     this.next.endElement(tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String nsUri) throws SAXException {
/*  86 */     this.validator.startPrefixMapping(prefix, nsUri);
/*  87 */     this.next.startPrefixMapping(prefix, nsUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/*  92 */     this.validator.endPrefixMapping(prefix);
/*  93 */     this.next.endPrefixMapping(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(CharSequence pcdata) throws SAXException {
/*  98 */     int len = pcdata.length();
/*  99 */     if (this.buf.length < len) {
/* 100 */       this.buf = new char[len];
/*     */     }
/* 102 */     for (int i = 0; i < len; i++) {
/* 103 */       this.buf[i] = pcdata.charAt(i);
/*     */     }
/* 105 */     this.validator.characters(this.buf, 0, len);
/* 106 */     if (this.predictor.expectText()) {
/* 107 */       this.next.text(pcdata);
/*     */     }
/*     */   }
/*     */   
/*     */   public UnmarshallingContext getContext() {
/* 112 */     return this.next.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlVisitor.TextPredictor getPredictor() {
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean expectText() {
/* 127 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\ValidatingUnmarshaller.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */