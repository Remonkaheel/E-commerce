/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import com.sun.istack.Nullable;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.NamespaceContext2;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NamespaceContextImpl
/*     */   implements NamespaceContext2
/*     */ {
/*     */   private final XMLSerializer owner;
/*  40 */   private String[] prefixes = new String[4];
/*  41 */   private String[] nsUris = new String[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element current;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Element top;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private NamespacePrefixMapper prefixMapper = defaultNamespacePrefixMapper;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean collectionMode;
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContextImpl(XMLSerializer owner) {
/*  95 */     this.owner = owner;
/*     */     
/*  97 */     this.current = this.top = new Element(this, null);
/*     */     
/*  99 */     put("http://www.w3.org/XML/1998/namespace", "xml");
/*     */   }
/*     */   
/*     */   public void setPrefixMapper(NamespacePrefixMapper mapper) {
/* 103 */     if (mapper == null)
/* 104 */       mapper = defaultNamespacePrefixMapper; 
/* 105 */     this.prefixMapper = mapper;
/*     */   }
/*     */   
/*     */   public NamespacePrefixMapper getPrefixMapper() {
/* 109 */     return this.prefixMapper;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 113 */     this.current = this.top;
/* 114 */     this.size = 1;
/* 115 */     this.collectionMode = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int declareNsUri(String uri, String preferedPrefix, boolean requirePrefix) {
/* 123 */     preferedPrefix = this.prefixMapper.getPreferredPrefix(uri, preferedPrefix, requirePrefix);
/*     */     
/* 125 */     if (uri.length() == 0) {
/* 126 */       for (int j = this.size - 1; j >= 0; j--) {
/* 127 */         if (this.nsUris[j].length() == 0)
/* 128 */           return j; 
/* 129 */         if (this.prefixes[j].length() == 0) {
/*     */ 
/*     */           
/* 132 */           assert this.current.defaultPrefixIndex == -1 && this.current.oldDefaultNamespaceUriIndex == -1;
/*     */           
/* 134 */           String oldUri = this.nsUris[j];
/* 135 */           String[] knownURIs = this.owner.nameList.namespaceURIs;
/*     */           
/* 137 */           if (this.current.baseIndex <= j) {
/*     */ 
/*     */             
/* 140 */             this.nsUris[j] = "";
/*     */             
/* 142 */             int subst = put(oldUri, null);
/*     */ 
/*     */             
/* 145 */             for (int m = knownURIs.length - 1; m >= 0; m--) {
/* 146 */               if (knownURIs[m].equals(oldUri)) {
/* 147 */                 this.owner.knownUri2prefixIndexMap[m] = subst;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 151 */             if (this.current.elementLocalName != null) {
/* 152 */               this.current.setTagName(subst, this.current.elementLocalName, this.current.getOuterPeer());
/*     */             }
/* 154 */             return j;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 159 */           for (int k = knownURIs.length - 1; k >= 0; k--) {
/* 160 */             if (knownURIs[k].equals(oldUri)) {
/* 161 */               this.current.defaultPrefixIndex = j;
/* 162 */               this.current.oldDefaultNamespaceUriIndex = k;
/*     */ 
/*     */ 
/*     */               
/* 166 */               this.owner.knownUri2prefixIndexMap[k] = this.size;
/*     */               break;
/*     */             } 
/*     */           } 
/* 170 */           if (this.current.elementLocalName != null) {
/* 171 */             this.current.setTagName(this.size, this.current.elementLocalName, this.current.getOuterPeer());
/*     */           }
/*     */           
/* 174 */           put(this.nsUris[j], null);
/* 175 */           return put("", "");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 181 */       return put("", "");
/*     */     } 
/*     */     
/* 184 */     for (int i = this.size - 1; i >= 0; i--) {
/* 185 */       String p = this.prefixes[i];
/* 186 */       if (this.nsUris[i].equals(uri) && (
/* 187 */         !requirePrefix || p.length() > 0)) {
/* 188 */         return i;
/*     */       }
/*     */       
/* 191 */       if (p.equals(preferedPrefix))
/*     */       {
/* 193 */         preferedPrefix = null;
/*     */       }
/*     */     } 
/*     */     
/* 197 */     if (preferedPrefix == null && requirePrefix)
/*     */     {
/*     */       
/* 200 */       preferedPrefix = makeUniquePrefix();
/*     */     }
/*     */ 
/*     */     
/* 204 */     return put(uri, preferedPrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int force(@NotNull String uri, @NotNull String prefix) {
/* 212 */     for (int i = this.size - 1; i >= 0; i--) {
/* 213 */       if (this.prefixes[i].equals(prefix)) {
/* 214 */         if (this.nsUris[i].equals(uri)) {
/* 215 */           return i;
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     return put(uri, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int put(@NotNull String uri, @Nullable String prefix) {
/* 238 */     if (this.size == this.nsUris.length) {
/*     */       
/* 240 */       String[] u = new String[this.nsUris.length * 2];
/* 241 */       String[] p = new String[this.prefixes.length * 2];
/* 242 */       System.arraycopy(this.nsUris, 0, u, 0, this.nsUris.length);
/* 243 */       System.arraycopy(this.prefixes, 0, p, 0, this.prefixes.length);
/* 244 */       this.nsUris = u;
/* 245 */       this.prefixes = p;
/*     */     } 
/* 247 */     if (prefix == null) {
/* 248 */       if (this.size == 1) {
/* 249 */         prefix = "";
/*     */       } else {
/*     */         
/* 252 */         prefix = makeUniquePrefix();
/*     */       } 
/*     */     }
/* 255 */     this.nsUris[this.size] = uri;
/* 256 */     this.prefixes[this.size] = prefix;
/*     */     
/* 258 */     return this.size++;
/*     */   }
/*     */ 
/*     */   
/*     */   private String makeUniquePrefix() {
/* 263 */     String prefix = (new StringBuilder(5)).append("ns").append(this.size).toString();
/* 264 */     while (getNamespaceURI(prefix) != null) {
/* 265 */       prefix = prefix + "_";
/*     */     }
/* 267 */     return prefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getCurrent() {
/* 272 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefixIndex(String uri) {
/* 280 */     for (int i = this.size - 1; i >= 0; i--) {
/* 281 */       if (this.nsUris[i].equals(uri))
/* 282 */         return i; 
/*     */     } 
/* 284 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix(int prefixIndex) {
/* 293 */     return this.prefixes[prefixIndex];
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(int prefixIndex) {
/* 297 */     return this.nsUris[prefixIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 308 */     for (int i = this.size - 1; i >= 0; i--) {
/* 309 */       if (this.prefixes[i].equals(prefix))
/* 310 */         return this.nsUris[i]; 
/* 311 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix(String uri) {
/* 320 */     if (this.collectionMode) {
/* 321 */       return declareNamespace(uri, null, false);
/*     */     }
/* 323 */     for (int i = this.size - 1; i >= 0; i--) {
/* 324 */       if (this.nsUris[i].equals(uri))
/* 325 */         return this.prefixes[i]; 
/* 326 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String> getPrefixes(String uri) {
/* 332 */     String prefix = getPrefix(uri);
/* 333 */     if (prefix == null) {
/* 334 */       return Collections.emptyIterator();
/*     */     }
/* 336 */     return Collections.<String>singleton(uri).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String declareNamespace(String namespaceUri, String preferedPrefix, boolean requirePrefix) {
/* 341 */     int idx = declareNsUri(namespaceUri, preferedPrefix, requirePrefix);
/* 342 */     return getPrefix(idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int count() {
/* 349 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Element
/*     */   {
/*     */     public final NamespaceContextImpl context;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Element prev;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Element next;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int oldDefaultNamespaceUriIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int defaultPrefixIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int baseIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int depth;
/*     */ 
/*     */ 
/*     */     
/*     */     private int elementNamePrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     private String elementLocalName;
/*     */ 
/*     */ 
/*     */     
/*     */     private Name elementName;
/*     */ 
/*     */ 
/*     */     
/*     */     private Object outerPeer;
/*     */ 
/*     */ 
/*     */     
/*     */     private Object innerPeer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Element(NamespaceContextImpl context, Element prev) {
/* 414 */       this.context = context;
/* 415 */       this.prev = prev;
/* 416 */       this.depth = (prev == null) ? 0 : (prev.depth + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRootElement() {
/* 424 */       return (this.depth == 1);
/*     */     }
/*     */     
/*     */     public Element push() {
/* 428 */       if (this.next == null)
/* 429 */         this.next = new Element(this.context, this); 
/* 430 */       this.next.onPushed();
/* 431 */       return this.next;
/*     */     }
/*     */     
/*     */     public Element pop() {
/* 435 */       if (this.oldDefaultNamespaceUriIndex >= 0)
/*     */       {
/* 437 */         this.context.owner.knownUri2prefixIndexMap[this.oldDefaultNamespaceUriIndex] = this.defaultPrefixIndex;
/*     */       }
/* 439 */       this.context.size = this.baseIndex;
/* 440 */       this.context.current = this.prev;
/*     */       
/* 442 */       this.outerPeer = this.innerPeer = null;
/* 443 */       return this.prev;
/*     */     }
/*     */     
/*     */     private void onPushed() {
/* 447 */       this.oldDefaultNamespaceUriIndex = this.defaultPrefixIndex = -1;
/* 448 */       this.baseIndex = this.context.size;
/* 449 */       this.context.current = this;
/*     */     }
/*     */     
/*     */     public void setTagName(int prefix, String localName, Object outerPeer) {
/* 453 */       assert localName != null;
/* 454 */       this.elementNamePrefix = prefix;
/* 455 */       this.elementLocalName = localName;
/* 456 */       this.elementName = null;
/* 457 */       this.outerPeer = outerPeer;
/*     */     }
/*     */     
/*     */     public void setTagName(Name tagName, Object outerPeer) {
/* 461 */       assert tagName != null;
/* 462 */       this.elementName = tagName;
/* 463 */       this.outerPeer = outerPeer;
/*     */     }
/*     */     
/*     */     public void startElement(XmlOutput out, Object innerPeer) throws IOException, XMLStreamException {
/* 467 */       this.innerPeer = innerPeer;
/* 468 */       if (this.elementName != null) {
/* 469 */         out.beginStartTag(this.elementName);
/*     */       } else {
/* 471 */         out.beginStartTag(this.elementNamePrefix, this.elementLocalName);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void endElement(XmlOutput out) throws IOException, SAXException, XMLStreamException {
/* 476 */       if (this.elementName != null) {
/* 477 */         out.endTag(this.elementName);
/* 478 */         this.elementName = null;
/*     */       } else {
/* 480 */         out.endTag(this.elementNamePrefix, this.elementLocalName);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int count() {
/* 488 */       return this.context.size - this.baseIndex;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPrefix(int idx) {
/* 498 */       return this.context.prefixes[this.baseIndex + idx];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getNsUri(int idx) {
/* 508 */       return this.context.nsUris[this.baseIndex + idx];
/*     */     }
/*     */     
/*     */     public int getBase() {
/* 512 */       return this.baseIndex;
/*     */     }
/*     */     
/*     */     public Object getOuterPeer() {
/* 516 */       return this.outerPeer;
/*     */     }
/*     */     
/*     */     public Object getInnerPeer() {
/* 520 */       return this.innerPeer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Element getParent() {
/* 527 */       return this.prev;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 536 */   private static final NamespacePrefixMapper defaultNamespacePrefixMapper = new NamespacePrefixMapper()
/*     */     {
/*     */       public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
/* 539 */         if ("http://www.w3.org/2001/XMLSchema-instance".equals(namespaceUri))
/* 540 */           return "xsi"; 
/* 541 */         if ("http://www.w3.org/2001/XMLSchema".equals(namespaceUri))
/* 542 */           return "xs"; 
/* 543 */         if (namespaceUri.equals("http://www.w3.org/2005/05/xmlmime"))
/* 544 */           return "xmime"; 
/* 545 */         return suggestion;
/*     */       }
/*     */     };
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\NamespaceContextImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */