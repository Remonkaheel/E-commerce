package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Type;
import javax.xml.namespace.QName;
import org.glassfish.jaxb.core.v2.model.core.LeafInfo;
import org.glassfish.jaxb.runtime.v2.runtime.Transducer;

public interface RuntimeLeafInfo extends LeafInfo<Type, Class>, RuntimeNonElement {
  <V> Transducer<V> getTransducer();
  
  Class getClazz();
  
  QName[] getTypeNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeLeafInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */