/*     */ package org.glassfish.jaxb.runtime.v2.util;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollisionCheckStack<E>
/*     */   extends AbstractList<E>
/*     */ {
/*     */   private Object[] data;
/*     */   private int[] next;
/*  39 */   private int size = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean latestPushResult = false;
/*     */ 
/*     */   
/*     */   private boolean useIdentity = true;
/*     */ 
/*     */   
/*     */   private final int[] initialHash;
/*     */ 
/*     */ 
/*     */   
/*     */   public CollisionCheckStack() {
/*  54 */     this.initialHash = new int[17];
/*  55 */     this.data = new Object[16];
/*  56 */     this.next = new int[16];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseIdentity(boolean useIdentity) {
/*  64 */     this.useIdentity = useIdentity;
/*     */   }
/*     */   
/*     */   public boolean getUseIdentity() {
/*  68 */     return this.useIdentity;
/*     */   }
/*     */   
/*     */   public boolean getLatestPushResult() {
/*  72 */     return this.latestPushResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean push(E o) {
/*  82 */     if (this.data.length == this.size) {
/*  83 */       expandCapacity();
/*     */     }
/*  85 */     this.data[this.size] = o;
/*  86 */     int hash = hash(o);
/*  87 */     boolean r = findDuplicate(o, hash);
/*  88 */     this.next[this.size] = this.initialHash[hash];
/*  89 */     this.initialHash[hash] = this.size + 1;
/*  90 */     this.size++;
/*  91 */     this.latestPushResult = r;
/*  92 */     return this.latestPushResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushNocheck(E o) {
/* 100 */     if (this.data.length == this.size)
/* 101 */       expandCapacity(); 
/* 102 */     this.data[this.size] = o;
/* 103 */     this.next[this.size] = -1;
/* 104 */     this.size++;
/*     */   }
/*     */   
/*     */   public boolean findDuplicate(E o) {
/* 108 */     int hash = hash(o);
/* 109 */     return findDuplicate(o, hash);
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int index) {
/* 114 */     return (E)this.data[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 119 */     return this.size;
/*     */   }
/*     */   
/*     */   private int hash(Object o) {
/* 123 */     return ((this.useIdentity ? System.identityHashCode(o) : o.hashCode()) & Integer.MAX_VALUE) % this.initialHash.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E pop() {
/* 130 */     this.size--;
/* 131 */     Object o = this.data[this.size];
/* 132 */     this.data[this.size] = null;
/* 133 */     int n = this.next[this.size];
/* 134 */     if (n >= 0) {
/*     */ 
/*     */       
/* 137 */       int hash = hash(o);
/* 138 */       assert this.initialHash[hash] == this.size + 1;
/* 139 */       this.initialHash[hash] = n;
/*     */     } 
/* 141 */     return (E)o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E peek() {
/* 148 */     return (E)this.data[this.size - 1];
/*     */   }
/*     */   
/*     */   private boolean findDuplicate(E o, int hash) {
/* 152 */     int p = this.initialHash[hash];
/* 153 */     while (p != 0) {
/* 154 */       p--;
/* 155 */       Object existing = this.data[p];
/* 156 */       if (this.useIdentity)
/* 157 */       { if (existing == o) return true;
/*     */          }
/* 159 */       else if (o.equals(existing)) { return true; }
/*     */       
/* 161 */       p = this.next[p];
/*     */     } 
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   private void expandCapacity() {
/* 167 */     int oldSize = this.data.length;
/* 168 */     int newSize = oldSize * 2;
/* 169 */     Object[] d = new Object[newSize];
/* 170 */     int[] n = new int[newSize];
/*     */     
/* 172 */     System.arraycopy(this.data, 0, d, 0, oldSize);
/* 173 */     System.arraycopy(this.next, 0, n, 0, oldSize);
/*     */     
/* 175 */     this.data = d;
/* 176 */     this.next = n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 183 */     if (this.size > 0) {
/* 184 */       this.size = 0;
/* 185 */       Arrays.fill(this.initialHash, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCycleString() {
/*     */     Object x;
/* 193 */     StringBuilder sb = new StringBuilder();
/* 194 */     int i = size() - 1;
/* 195 */     E obj = get(i);
/* 196 */     sb.append(obj);
/*     */     
/*     */     do {
/* 199 */       sb.append(" -> ");
/* 200 */       x = get(--i);
/* 201 */       sb.append(x);
/* 202 */     } while (obj != x);
/*     */     
/* 204 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\CollisionCheckStack.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */