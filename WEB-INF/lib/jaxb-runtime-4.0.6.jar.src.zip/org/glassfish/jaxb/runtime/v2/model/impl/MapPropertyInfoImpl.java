/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.core.MapPropertyInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*    */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MapPropertyInfoImpl<T, C, F, M>
/*    */   extends PropertyInfoImpl<T, C, F, M>
/*    */   implements MapPropertyInfo<T, C>
/*    */ {
/*    */   private final QName xmlName;
/*    */   private boolean nil;
/*    */   private final T keyType;
/*    */   private final T valueType;
/*    */   private NonElement<T, C> keyTypeInfo;
/*    */   private NonElement<T, C> valueTypeInfo;
/*    */   
/*    */   public MapPropertyInfoImpl(ClassInfoImpl<T, C, F, M> ci, PropertySeed<T, C, F, M> seed) {
/* 40 */     super(ci, seed);
/*    */     
/* 42 */     XmlElementWrapper xe = (XmlElementWrapper)seed.readAnnotation(XmlElementWrapper.class);
/* 43 */     this.xmlName = calcXmlName(xe);
/* 44 */     this.nil = (xe != null && xe.nillable());
/*    */     
/* 46 */     T raw = getRawType();
/* 47 */     T bt = (T)nav().getBaseClass(raw, nav().asDecl(Map.class));
/* 48 */     assert bt != null;
/*    */     
/* 50 */     if (nav().isParameterizedType(bt)) {
/* 51 */       this.keyType = (T)nav().getTypeArgument(bt, 0);
/* 52 */       this.valueType = (T)nav().getTypeArgument(bt, 1);
/*    */     } else {
/* 54 */       this.keyType = this.valueType = (T)nav().ref(Object.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<? extends TypeInfo<T, C>> ref() {
/* 60 */     return (Collection)Arrays.asList((Object[])new NonElement[] { getKeyType(), getValueType() });
/*    */   }
/*    */ 
/*    */   
/*    */   public final PropertyKind kind() {
/* 65 */     return PropertyKind.MAP;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getXmlName() {
/* 70 */     return this.xmlName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCollectionNillable() {
/* 75 */     return this.nil;
/*    */   }
/*    */ 
/*    */   
/*    */   public NonElement<T, C> getKeyType() {
/* 80 */     if (this.keyTypeInfo == null)
/* 81 */       this.keyTypeInfo = getTarget(this.keyType); 
/* 82 */     return this.keyTypeInfo;
/*    */   }
/*    */ 
/*    */   
/*    */   public NonElement<T, C> getValueType() {
/* 87 */     if (this.valueTypeInfo == null)
/* 88 */       this.valueTypeInfo = getTarget(this.valueType); 
/* 89 */     return this.valueTypeInfo;
/*    */   }
/*    */   
/*    */   public NonElement<T, C> getTarget(T type) {
/* 93 */     assert this.parent.builder != null : "this method must be called during the build stage";
/* 94 */     return this.parent.builder.getTypeInfo(type, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\MapPropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */