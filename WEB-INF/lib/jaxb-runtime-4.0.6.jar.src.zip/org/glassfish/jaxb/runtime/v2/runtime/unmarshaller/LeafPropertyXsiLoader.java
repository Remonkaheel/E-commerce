/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.ClassBeanInfoImpl;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LeafPropertyXsiLoader
/*    */   extends Loader
/*    */ {
/*    */   private final Loader defaultLoader;
/*    */   private final TransducedAccessor xacc;
/*    */   private final Accessor acc;
/*    */   
/*    */   public LeafPropertyXsiLoader(Loader defaultLoader, TransducedAccessor xacc, Accessor acc) {
/* 32 */     this.defaultLoader = defaultLoader;
/* 33 */     this.expectText = true;
/* 34 */     this.xacc = xacc;
/* 35 */     this.acc = acc;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 41 */     Loader loader = selectLoader(state, ea);
/* 42 */     state.setLoader(loader);
/* 43 */     loader.startElement(state, ea);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Loader selectLoader(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 49 */     UnmarshallingContext context = state.getContext();
/* 50 */     JaxBeanInfo beanInfo = null;
/*    */ 
/*    */     
/* 53 */     Attributes atts = ea.atts;
/* 54 */     int idx = atts.getIndex("http://www.w3.org/2001/XMLSchema-instance", "type");
/*    */     
/* 56 */     if (idx >= 0) {
/* 57 */       ClassBeanInfoImpl cbii; String value = atts.getValue(idx);
/*    */       
/* 59 */       QName type = DatatypeConverterImpl._parseQName(value, context);
/*    */       
/* 61 */       if (type == null) {
/* 62 */         return this.defaultLoader;
/*    */       }
/* 64 */       beanInfo = context.getJAXBContext().getGlobalType(type);
/* 65 */       if (beanInfo == null) {
/* 66 */         return this.defaultLoader;
/*    */       }
/*    */       try {
/* 69 */         cbii = (ClassBeanInfoImpl)beanInfo;
/* 70 */       } catch (ClassCastException cce) {
/* 71 */         return this.defaultLoader;
/*    */       } 
/*    */       
/* 74 */       if (null == cbii.getTransducer()) {
/* 75 */         return this.defaultLoader;
/*    */       }
/*    */       
/* 78 */       return new LeafPropertyLoader((TransducedAccessor)new TransducedAccessor.CompositeTransducedAccessorImpl(state
/*    */             
/* 80 */             .getContext().getJAXBContext(), cbii
/* 81 */             .getTransducer(), this.acc));
/*    */     } 
/*    */ 
/*    */     
/* 85 */     return this.defaultLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<QName> getExpectedChildElements() {
/* 90 */     return this.defaultLoader.getExpectedChildElements();
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<QName> getExpectedAttributes() {
/* 95 */     return this.defaultLoader.getExpectedAttributes();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\LeafPropertyXsiLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */