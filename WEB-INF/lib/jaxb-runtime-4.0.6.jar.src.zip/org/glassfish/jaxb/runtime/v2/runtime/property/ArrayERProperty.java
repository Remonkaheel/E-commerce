/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Lister;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TagName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiNilLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ArrayERProperty<BeanT, ListT, ItemT>
/*     */   extends ArrayProperty<BeanT, ListT, ItemT>
/*     */ {
/*     */   protected final Name wrapperTagName;
/*     */   protected final boolean isWrapperNillable;
/*     */   
/*     */   protected ArrayERProperty(JAXBContextImpl grammar, RuntimePropertyInfo prop, QName tagName, boolean isWrapperNillable) {
/*  50 */     super(grammar, prop);
/*  51 */     if (tagName == null) {
/*  52 */       this.wrapperTagName = null;
/*     */     } else {
/*  54 */       this.wrapperTagName = grammar.nameBuilder.createElementName(tagName);
/*  55 */     }  this.isWrapperNillable = isWrapperNillable;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ItemsLoader
/*     */     extends Loader
/*     */   {
/*     */     private final Accessor acc;
/*     */     private final Lister lister;
/*     */     private final QNameMap<ChildLoader> children;
/*     */     
/*     */     public ItemsLoader(Accessor acc, Lister lister, QNameMap<ChildLoader> children) {
/*  67 */       super(false);
/*  68 */       this.acc = acc;
/*  69 */       this.lister = lister;
/*  70 */       this.children = children;
/*     */     }
/*     */ 
/*     */     
/*     */     public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  75 */       UnmarshallingContext context = state.getContext();
/*  76 */       context.startScope(1);
/*     */       
/*  78 */       state.setTarget(state.getPrev().getTarget());
/*     */ 
/*     */       
/*  81 */       context.getScope(0).start(this.acc, this.lister);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  88 */       ChildLoader child = (ChildLoader)this.children.get(ea.uri, ea.local);
/*  89 */       if (child == null) {
/*  90 */         child = (ChildLoader)this.children.get(StructureLoaderBuilder.CATCH_ALL);
/*     */       }
/*  92 */       if (child == null) {
/*  93 */         super.childElement(state, ea);
/*     */         return;
/*     */       } 
/*  96 */       state.setLoader(child.loader);
/*  97 */       state.setReceiver(child.receiver);
/*     */     }
/*     */ 
/*     */     
/*     */     public void leaveElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 102 */       state.getContext().endScope(1);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<QName> getExpectedChildElements() {
/* 107 */       return this.children.keySet();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 113 */     ListT list = (ListT)this.acc.get(o);
/*     */     
/* 115 */     if (list != null) {
/* 116 */       if (this.wrapperTagName != null) {
/* 117 */         w.startElement(this.wrapperTagName, null);
/* 118 */         w.endNamespaceDecls(list);
/* 119 */         w.endAttributes();
/*     */       } 
/*     */       
/* 122 */       serializeListBody(o, w, list);
/*     */       
/* 124 */       if (this.wrapperTagName != null) {
/* 125 */         w.endElement();
/*     */       }
/*     */     }
/* 128 */     else if (this.isWrapperNillable) {
/* 129 */       w.startElement(this.wrapperTagName, null);
/* 130 */       w.writeXsiNilTrue();
/* 131 */       w.endElement();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void serializeListBody(BeanT paramBeanT, XMLSerializer paramXMLSerializer, ListT paramListT) throws IOException, XMLStreamException, SAXException, AccessorException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void createBodyUnmarshaller(UnmarshallerChain paramUnmarshallerChain, QNameMap<ChildLoader> paramQNameMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> loaders) {
/* 153 */     if (this.wrapperTagName != null) {
/* 154 */       XsiNilLoader xsiNilLoader; UnmarshallerChain c = new UnmarshallerChain(chain.context);
/* 155 */       QNameMap<ChildLoader> m = new QNameMap();
/* 156 */       createBodyUnmarshaller(c, m);
/* 157 */       Loader loader = new ItemsLoader(this.acc, this.lister, m);
/* 158 */       if (this.isWrapperNillable || chain.context.allNillable)
/* 159 */         xsiNilLoader = new XsiNilLoader(loader); 
/* 160 */       loaders.put(this.wrapperTagName, new ChildLoader((Loader)xsiNilLoader, null));
/*     */     } else {
/* 162 */       createBodyUnmarshaller(chain, loaders);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final class ReceiverImpl
/*     */     implements Receiver
/*     */   {
/*     */     private final int offset;
/*     */     
/*     */     protected ReceiverImpl(int offset) {
/* 173 */       this.offset = offset;
/*     */     }
/*     */ 
/*     */     
/*     */     public void receive(UnmarshallingContext.State state, Object o) throws SAXException {
/* 178 */       state.getContext().getScope(this.offset).add(ArrayERProperty.this.acc, ArrayERProperty.this.lister, o);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayERProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */