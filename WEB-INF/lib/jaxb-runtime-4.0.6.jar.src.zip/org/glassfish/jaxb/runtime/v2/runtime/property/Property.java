package org.glassfish.jaxb.runtime.v2.runtime.property;

import java.io.IOException;
import javax.xml.stream.XMLStreamException;
import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
import org.glassfish.jaxb.runtime.api.AccessorException;
import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
import org.xml.sax.SAXException;

public interface Property<BeanT> extends StructureLoaderBuilder {
  void reset(BeanT paramBeanT) throws AccessorException;
  
  void serializeBody(BeanT paramBeanT, XMLSerializer paramXMLSerializer, Object paramObject) throws SAXException, AccessorException, IOException, XMLStreamException;
  
  void serializeURIs(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException, AccessorException;
  
  boolean hasSerializeURIAction();
  
  String getIdValue(BeanT paramBeanT) throws AccessorException, SAXException;
  
  PropertyKind getKind();
  
  Accessor getElementPropertyAccessor(String paramString1, String paramString2);
  
  void wrapUp();
  
  RuntimePropertyInfo getInfo();
  
  boolean isHiddenByOverride();
  
  void setHiddenByOverride(boolean paramBoolean);
  
  String getFieldName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\Property.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */