/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import org.glassfish.jaxb.core.v2.model.core.EnumConstant;
/*    */ import org.glassfish.jaxb.core.v2.model.core.EnumLeafInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EnumConstantImpl<T, C, F, M>
/*    */   implements EnumConstant<T, C>
/*    */ {
/*    */   protected final String lexical;
/*    */   protected final EnumLeafInfoImpl<T, C, F, M> owner;
/*    */   protected final String name;
/*    */   protected final EnumConstantImpl<T, C, F, M> next;
/*    */   
/*    */   public EnumConstantImpl(EnumLeafInfoImpl<T, C, F, M> owner, String name, String lexical, EnumConstantImpl<T, C, F, M> next) {
/* 30 */     this.lexical = lexical;
/* 31 */     this.owner = owner;
/* 32 */     this.name = name;
/* 33 */     this.next = next;
/*    */   }
/*    */ 
/*    */   
/*    */   public EnumLeafInfo<T, C> getEnclosingClass() {
/* 38 */     return this.owner;
/*    */   }
/*    */ 
/*    */   
/*    */   public final String getLexicalValue() {
/* 43 */     return this.lexical;
/*    */   }
/*    */ 
/*    */   
/*    */   public final String getName() {
/* 48 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\EnumConstantImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */