package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;
import javax.xml.namespace.QName;

@XmlElement("restriction")
public interface ComplexRestriction extends TypedXmlWriter, Annotated, AttrDecls, TypeDefParticle {
  @XmlAttribute
  ComplexRestriction base(QName paramQName);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\ComplexRestriction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */