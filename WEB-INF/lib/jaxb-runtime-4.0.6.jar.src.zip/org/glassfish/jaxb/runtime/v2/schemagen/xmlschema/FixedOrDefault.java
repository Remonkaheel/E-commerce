package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;

public interface FixedOrDefault extends TypedXmlWriter {
  @XmlAttribute("default")
  FixedOrDefault _default(String paramString);
  
  @XmlAttribute
  FixedOrDefault fixed(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\FixedOrDefault.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */