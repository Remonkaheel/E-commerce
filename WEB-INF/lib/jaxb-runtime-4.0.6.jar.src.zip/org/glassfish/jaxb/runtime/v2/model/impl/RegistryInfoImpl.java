/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlElementDecl;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.RegistryInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ import org.glassfish.jaxb.runtime.v2.model.annotation.MethodLocatable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RegistryInfoImpl<T, C, F, M>
/*     */   implements Locatable, RegistryInfo<T, C>
/*     */ {
/*     */   final C registryClass;
/*     */   private final Locatable upstream;
/*     */   private final Navigator<T, C, F, M> nav;
/*  43 */   private final Set<TypeInfo<T, C>> references = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RegistryInfoImpl(ModelBuilder<T, C, F, M> builder, Locatable upstream, C registryClass) {
/*  49 */     this.nav = builder.nav;
/*  50 */     this.registryClass = registryClass;
/*  51 */     this.upstream = upstream;
/*  52 */     builder.registries.put(getPackageName(), this);
/*     */     
/*  54 */     if (this.nav.getDeclaredField(registryClass, "_useJAXBProperties") != null) {
/*     */ 
/*     */       
/*  57 */       builder.reportError(new IllegalAnnotationException(Messages.MISSING_JAXB_PROPERTIES
/*  58 */             .format(new Object[] { getPackageName() }, ), this));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  65 */     for (M m : this.nav.getDeclaredMethods(registryClass)) {
/*  66 */       ElementInfoImpl<T, C, F, M> ei; XmlElementDecl em = (XmlElementDecl)builder.reader.getMethodAnnotation(XmlElementDecl.class, m, this);
/*     */ 
/*     */       
/*  69 */       if (em == null) {
/*  70 */         if (this.nav.getMethodName(m).startsWith("create"))
/*     */         {
/*  72 */           this.references.add((TypeInfo<T, C>)builder
/*  73 */               .getTypeInfo((T)this.nav.getReturnType(m), (Locatable)new MethodLocatable(this, m, this.nav)));
/*     */         }
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/*  82 */         ei = (ElementInfoImpl)builder.createElementInfo(this, m);
/*  83 */       } catch (IllegalAnnotationException e) {
/*  84 */         builder.reportError(e);
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  90 */       builder.typeInfoSet.add(ei, builder);
/*  91 */       this.references.add(ei);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Locatable getUpstream() {
/*  97 */     return this.upstream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 102 */     return this.nav.getClassLocation(this.registryClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<TypeInfo<T, C>> getReferences() {
/* 107 */     return this.references;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/* 114 */     return this.nav.getPackageName(this.registryClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public C getClazz() {
/* 119 */     return this.registryClass;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RegistryInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */