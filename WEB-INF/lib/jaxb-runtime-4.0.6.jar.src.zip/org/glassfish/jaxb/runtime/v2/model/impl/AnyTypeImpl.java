/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnyTypeImpl<T, C>
/*    */   implements NonElement<T, C>
/*    */ {
/*    */   private final T type;
/*    */   private final Navigator<T, C, ?, ?> nav;
/*    */   
/*    */   public AnyTypeImpl(Navigator<T, C, ?, ?> nav) {
/* 33 */     this.type = (T)nav.ref(Object.class);
/* 34 */     this.nav = nav;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getTypeName() {
/* 39 */     return ANYTYPE_NAME;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getType() {
/* 44 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public Locatable getUpstream() {
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSimpleType() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 59 */     return this.nav.getClassLocation(this.nav.asDecl(Object.class));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final boolean canBeReferencedByIDREF() {
/* 71 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\AnyTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */