/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.XmlRegistry;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ArrayInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.EnumLeafInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ErrorHandler;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Ref;
/*     */ import org.glassfish.jaxb.core.v2.model.core.RegistryInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;
/*     */ import org.glassfish.jaxb.core.v2.model.impl.ModelBuilderI;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelBuilder<T, C, F, M>
/*     */   implements ModelBuilderI<T, C, F, M>
/*     */ {
/*  74 */   private final Map<QName, TypeInfo> typeNames = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   final Map<String, RegistryInfoImpl<T, C, F, M>> registries = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private final ErrorHandler proxyErrorHandler = new ErrorHandler()
/*     */     {
/*     */       public void error(IllegalAnnotationException e) {
/* 115 */         ModelBuilder.this.reportError(e);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelBuilder(AnnotationReader<T, C, F, M> reader, Navigator<T, C, F, M> navigator, Map<C, C> subclassReplacements, String defaultNamespaceRemap) {
/* 126 */     this.reader = reader;
/* 127 */     this.nav = navigator;
/* 128 */     this.subclassReplacements = subclassReplacements;
/* 129 */     if (defaultNamespaceRemap == null)
/* 130 */       defaultNamespaceRemap = ""; 
/* 131 */     this.defaultNsUri = defaultNamespaceRemap;
/* 132 */     reader.setErrorHandler(this.proxyErrorHandler);
/* 133 */     this.typeInfoSet = (TypeInfoSetImpl<T, C, F, M>)createTypeInfoSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private static final Logger logger = Logger.getLogger(ModelBuilder.class.getName());
/*     */   final TypeInfoSetImpl<T, C, F, M> typeInfoSet;
/*     */   
/*     */   protected TypeInfoSet<T, C, F, M> createTypeInfoSet() {
/* 144 */     return new TypeInfoSetImpl<>(this.nav, this.reader, BuiltinLeafInfoImpl.createLeaves(this.nav));
/*     */   }
/*     */   public final AnnotationReader<T, C, F, M> reader;
/*     */   public final Navigator<T, C, F, M> nav;
/*     */   public final String defaultNsUri;
/*     */   private final Map<C, C> subclassReplacements;
/*     */   private ErrorHandler errorHandler;
/*     */   private boolean hadError;
/*     */   public boolean hasSwaRef;
/*     */   private boolean linked;
/*     */   
/*     */   public NonElement<T, C> getClassInfo(C clazz, Locatable upstream) {
/* 156 */     return getClassInfo(clazz, false, upstream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getClassInfo(C clazz, boolean searchForSuperClass, Locatable upstream) {
/*     */     // Byte code:
/*     */     //   0: getstatic org/glassfish/jaxb/runtime/v2/model/impl/ModelBuilder.$assertionsDisabled : Z
/*     */     //   3: ifne -> 18
/*     */     //   6: aload_1
/*     */     //   7: ifnonnull -> 18
/*     */     //   10: new java/lang/AssertionError
/*     */     //   13: dup
/*     */     //   14: invokespecial <init> : ()V
/*     */     //   17: athrow
/*     */     //   18: aload_0
/*     */     //   19: getfield typeInfoSet : Lorg/glassfish/jaxb/runtime/v2/model/impl/TypeInfoSetImpl;
/*     */     //   22: aload_1
/*     */     //   23: invokevirtual getClassInfo : (Ljava/lang/Object;)Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*     */     //   26: astore #4
/*     */     //   28: aload #4
/*     */     //   30: ifnull -> 36
/*     */     //   33: aload #4
/*     */     //   35: areturn
/*     */     //   36: aload_0
/*     */     //   37: getfield nav : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   40: aload_1
/*     */     //   41: invokeinterface isEnum : (Ljava/lang/Object;)Z
/*     */     //   46: ifeq -> 82
/*     */     //   49: aload_0
/*     */     //   50: aload_1
/*     */     //   51: aload_3
/*     */     //   52: invokevirtual createEnumLeafInfo : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Lorg/glassfish/jaxb/core/v2/model/core/EnumLeafInfo;
/*     */     //   55: checkcast org/glassfish/jaxb/runtime/v2/model/impl/EnumLeafInfoImpl
/*     */     //   58: astore #5
/*     */     //   60: aload_0
/*     */     //   61: getfield typeInfoSet : Lorg/glassfish/jaxb/runtime/v2/model/impl/TypeInfoSetImpl;
/*     */     //   64: aload #5
/*     */     //   66: invokevirtual add : (Lorg/glassfish/jaxb/runtime/v2/model/impl/EnumLeafInfoImpl;)V
/*     */     //   69: aload #5
/*     */     //   71: astore #4
/*     */     //   73: aload_0
/*     */     //   74: aload #4
/*     */     //   76: invokevirtual addTypeName : (Lorg/glassfish/jaxb/core/v2/model/core/NonElement;)V
/*     */     //   79: goto -> 373
/*     */     //   82: aload_0
/*     */     //   83: getfield subclassReplacements : Ljava/util/Map;
/*     */     //   86: aload_1
/*     */     //   87: invokeinterface containsKey : (Ljava/lang/Object;)Z
/*     */     //   92: istore #5
/*     */     //   94: iload #5
/*     */     //   96: ifeq -> 123
/*     */     //   99: iload_2
/*     */     //   100: ifne -> 123
/*     */     //   103: aload_0
/*     */     //   104: aload_0
/*     */     //   105: getfield subclassReplacements : Ljava/util/Map;
/*     */     //   108: aload_1
/*     */     //   109: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   114: aload_3
/*     */     //   115: invokevirtual getClassInfo : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*     */     //   118: astore #4
/*     */     //   120: goto -> 373
/*     */     //   123: aload_0
/*     */     //   124: getfield reader : Lorg/glassfish/jaxb/core/v2/model/annotation/AnnotationReader;
/*     */     //   127: aload_1
/*     */     //   128: ldc jakarta/xml/bind/annotation/XmlTransient
/*     */     //   130: invokeinterface hasClassAnnotation : (Ljava/lang/Object;Ljava/lang/Class;)Z
/*     */     //   135: ifne -> 143
/*     */     //   138: iload #5
/*     */     //   140: ifeq -> 176
/*     */     //   143: aload_0
/*     */     //   144: aload_0
/*     */     //   145: getfield nav : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   148: aload_1
/*     */     //   149: invokeinterface getSuperClass : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   154: iload_2
/*     */     //   155: new org/glassfish/jaxb/runtime/v2/model/annotation/ClassLocatable
/*     */     //   158: dup
/*     */     //   159: aload_3
/*     */     //   160: aload_1
/*     */     //   161: aload_0
/*     */     //   162: getfield nav : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   165: invokespecial <init> : (Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;)V
/*     */     //   168: invokevirtual getClassInfo : (Ljava/lang/Object;ZLorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*     */     //   171: astore #4
/*     */     //   173: goto -> 373
/*     */     //   176: aload_0
/*     */     //   177: aload_1
/*     */     //   178: aload_3
/*     */     //   179: invokevirtual createClassInfo : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Lorg/glassfish/jaxb/core/v2/model/core/ClassInfo;
/*     */     //   182: checkcast org/glassfish/jaxb/runtime/v2/model/impl/ClassInfoImpl
/*     */     //   185: astore #6
/*     */     //   187: aload_0
/*     */     //   188: getfield typeInfoSet : Lorg/glassfish/jaxb/runtime/v2/model/impl/TypeInfoSetImpl;
/*     */     //   191: aload #6
/*     */     //   193: invokevirtual add : (Lorg/glassfish/jaxb/runtime/v2/model/impl/ClassInfoImpl;)V
/*     */     //   196: aload #6
/*     */     //   198: invokevirtual getProperties : ()Ljava/util/List;
/*     */     //   201: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   206: astore #7
/*     */     //   208: aload #7
/*     */     //   210: invokeinterface hasNext : ()Z
/*     */     //   215: ifeq -> 357
/*     */     //   218: aload #7
/*     */     //   220: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   225: checkcast org/glassfish/jaxb/core/v2/model/core/PropertyInfo
/*     */     //   228: astore #8
/*     */     //   230: aload #8
/*     */     //   232: invokeinterface kind : ()Lorg/glassfish/jaxb/core/v2/model/core/PropertyKind;
/*     */     //   237: getstatic org/glassfish/jaxb/core/v2/model/core/PropertyKind.REFERENCE : Lorg/glassfish/jaxb/core/v2/model/core/PropertyKind;
/*     */     //   240: if_acmpne -> 315
/*     */     //   243: aload_0
/*     */     //   244: aload_1
/*     */     //   245: aload #8
/*     */     //   247: checkcast org/glassfish/jaxb/core/v2/model/annotation/Locatable
/*     */     //   250: invokevirtual addToRegistry : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)V
/*     */     //   253: aload_0
/*     */     //   254: aload #8
/*     */     //   256: invokevirtual getParametrizedTypes : (Lorg/glassfish/jaxb/core/v2/model/core/PropertyInfo;)[Ljava/lang/Class;
/*     */     //   259: astore #9
/*     */     //   261: aload #9
/*     */     //   263: ifnull -> 315
/*     */     //   266: aload #9
/*     */     //   268: astore #10
/*     */     //   270: aload #10
/*     */     //   272: arraylength
/*     */     //   273: istore #11
/*     */     //   275: iconst_0
/*     */     //   276: istore #12
/*     */     //   278: iload #12
/*     */     //   280: iload #11
/*     */     //   282: if_icmpge -> 315
/*     */     //   285: aload #10
/*     */     //   287: iload #12
/*     */     //   289: aaload
/*     */     //   290: astore #13
/*     */     //   292: aload #13
/*     */     //   294: aload_1
/*     */     //   295: if_acmpeq -> 309
/*     */     //   298: aload_0
/*     */     //   299: aload #13
/*     */     //   301: aload #8
/*     */     //   303: checkcast org/glassfish/jaxb/core/v2/model/annotation/Locatable
/*     */     //   306: invokevirtual addToRegistry : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)V
/*     */     //   309: iinc #12, 1
/*     */     //   312: goto -> 278
/*     */     //   315: aload #8
/*     */     //   317: invokeinterface ref : ()Ljava/util/Collection;
/*     */     //   322: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   327: astore #9
/*     */     //   329: aload #9
/*     */     //   331: invokeinterface hasNext : ()Z
/*     */     //   336: ifeq -> 354
/*     */     //   339: aload #9
/*     */     //   341: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   346: checkcast org/glassfish/jaxb/core/v2/model/core/TypeInfo
/*     */     //   349: astore #10
/*     */     //   351: goto -> 329
/*     */     //   354: goto -> 208
/*     */     //   357: aload #6
/*     */     //   359: invokevirtual getBaseClass : ()Lorg/glassfish/jaxb/runtime/v2/model/impl/ClassInfoImpl;
/*     */     //   362: pop
/*     */     //   363: aload #6
/*     */     //   365: astore #4
/*     */     //   367: aload_0
/*     */     //   368: aload #4
/*     */     //   370: invokevirtual addTypeName : (Lorg/glassfish/jaxb/core/v2/model/core/NonElement;)V
/*     */     //   373: aload_0
/*     */     //   374: getfield reader : Lorg/glassfish/jaxb/core/v2/model/annotation/AnnotationReader;
/*     */     //   377: ldc jakarta/xml/bind/annotation/XmlSeeAlso
/*     */     //   379: aload_1
/*     */     //   380: aload_3
/*     */     //   381: invokeinterface getClassAnnotation : (Ljava/lang/Class;Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Ljava/lang/annotation/Annotation;
/*     */     //   386: checkcast jakarta/xml/bind/annotation/XmlSeeAlso
/*     */     //   389: astore #5
/*     */     //   391: aload #5
/*     */     //   393: ifnull -> 451
/*     */     //   396: aload_0
/*     */     //   397: getfield reader : Lorg/glassfish/jaxb/core/v2/model/annotation/AnnotationReader;
/*     */     //   400: aload #5
/*     */     //   402: ldc 'value'
/*     */     //   404: invokeinterface getClassArrayValue : (Ljava/lang/annotation/Annotation;Ljava/lang/String;)[Ljava/lang/Object;
/*     */     //   409: astore #6
/*     */     //   411: aload #6
/*     */     //   413: arraylength
/*     */     //   414: istore #7
/*     */     //   416: iconst_0
/*     */     //   417: istore #8
/*     */     //   419: iload #8
/*     */     //   421: iload #7
/*     */     //   423: if_icmpge -> 451
/*     */     //   426: aload #6
/*     */     //   428: iload #8
/*     */     //   430: aaload
/*     */     //   431: astore #9
/*     */     //   433: aload_0
/*     */     //   434: aload #9
/*     */     //   436: aload #5
/*     */     //   438: checkcast org/glassfish/jaxb/core/v2/model/annotation/Locatable
/*     */     //   441: invokevirtual getTypeInfo : (Ljava/lang/Object;Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;)Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*     */     //   444: pop
/*     */     //   445: iinc #8, 1
/*     */     //   448: goto -> 419
/*     */     //   451: aload #4
/*     */     //   453: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #165	-> 0
/*     */     //   #166	-> 18
/*     */     //   #167	-> 28
/*     */     //   #168	-> 33
/*     */     //   #170	-> 36
/*     */     //   #171	-> 49
/*     */     //   #172	-> 60
/*     */     //   #173	-> 69
/*     */     //   #174	-> 73
/*     */     //   #175	-> 79
/*     */     //   #176	-> 82
/*     */     //   #177	-> 94
/*     */     //   #179	-> 103
/*     */     //   #181	-> 123
/*     */     //   #183	-> 143
/*     */     //   #186	-> 176
/*     */     //   #187	-> 187
/*     */     //   #190	-> 196
/*     */     //   #191	-> 230
/*     */     //   #193	-> 243
/*     */     //   #194	-> 253
/*     */     //   #195	-> 261
/*     */     //   #196	-> 266
/*     */     //   #197	-> 292
/*     */     //   #198	-> 298
/*     */     //   #196	-> 309
/*     */     //   #204	-> 315
/*     */     //   #205	-> 351
/*     */     //   #206	-> 354
/*     */     //   #207	-> 357
/*     */     //   #209	-> 363
/*     */     //   #210	-> 367
/*     */     //   #216	-> 373
/*     */     //   #217	-> 391
/*     */     //   #218	-> 396
/*     */     //   #219	-> 433
/*     */     //   #218	-> 445
/*     */     //   #224	-> 451
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   60	19	5	li	Lorg/glassfish/jaxb/runtime/v2/model/impl/EnumLeafInfoImpl;
/*     */     //   292	17	13	prmzdClass	Ljava/lang/Class;
/*     */     //   261	54	9	prmzdClasses	[Ljava/lang/Class;
/*     */     //   230	124	8	p	Lorg/glassfish/jaxb/core/v2/model/core/PropertyInfo;
/*     */     //   187	186	6	ci	Lorg/glassfish/jaxb/runtime/v2/model/impl/ClassInfoImpl;
/*     */     //   94	279	5	isReplaced	Z
/*     */     //   433	12	9	t	Ljava/lang/Object;
/*     */     //   0	454	0	this	Lorg/glassfish/jaxb/runtime/v2/model/impl/ModelBuilder;
/*     */     //   0	454	1	clazz	Ljava/lang/Object;
/*     */     //   0	454	2	searchForSuperClass	Z
/*     */     //   0	454	3	upstream	Lorg/glassfish/jaxb/core/v2/model/annotation/Locatable;
/*     */     //   28	426	4	r	Lorg/glassfish/jaxb/core/v2/model/core/NonElement;
/*     */     //   391	63	5	sa	Ljakarta/xml/bind/annotation/XmlSeeAlso;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   60	19	5	li	Lorg/glassfish/jaxb/runtime/v2/model/impl/EnumLeafInfoImpl<TT;TC;TF;TM;>;
/*     */     //   230	124	8	p	Lorg/glassfish/jaxb/core/v2/model/core/PropertyInfo<TT;TC;>;
/*     */     //   187	186	6	ci	Lorg/glassfish/jaxb/runtime/v2/model/impl/ClassInfoImpl<TT;TC;TF;TM;>;
/*     */     //   433	12	9	t	TT;
/*     */     //   0	454	0	this	Lorg/glassfish/jaxb/runtime/v2/model/impl/ModelBuilder<TT;TC;TF;TM;>;
/*     */     //   0	454	1	clazz	TC;
/*     */     //   28	426	4	r	Lorg/glassfish/jaxb/core/v2/model/core/NonElement<TT;TC;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addToRegistry(C clazz, Locatable p) {
/* 233 */     String pkg = this.nav.getPackageName(clazz);
/* 234 */     if (!this.registries.containsKey(pkg)) {
/*     */       
/* 236 */       C c = (C)this.nav.loadObjectFactory(clazz, pkg);
/* 237 */       if (c != null) {
/* 238 */         addRegistry(c, p);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class[] getParametrizedTypes(PropertyInfo p) {
/*     */     try {
/* 249 */       Type pType = ((RuntimePropertyInfo)p).getIndividualType();
/* 250 */       if (pType instanceof ParameterizedType) {
/* 251 */         ParameterizedType prmzdType = (ParameterizedType)pType;
/* 252 */         if (prmzdType.getRawType() == JAXBElement.class) {
/* 253 */           Type[] actualTypes = prmzdType.getActualTypeArguments();
/* 254 */           Class[] result = new Class[actualTypes.length];
/* 255 */           for (int i = 0; i < actualTypes.length; i++) {
/* 256 */             result[i] = (Class)actualTypes[i];
/*     */           }
/* 258 */           return result;
/*     */         } 
/*     */       } 
/* 261 */     } catch (Exception e) {
/* 262 */       logger.log(Level.FINE, "Error in ModelBuilder.getParametrizedTypes. " + e.getMessage());
/*     */     } 
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addTypeName(NonElement<T, C> r) {
/* 271 */     QName t = r.getTypeName();
/* 272 */     if (t == null)
/*     */       return; 
/* 274 */     TypeInfo old = (TypeInfo)this.typeNames.put(t, r);
/* 275 */     if (old != null)
/*     */     {
/* 277 */       reportError(new IllegalAnnotationException(Messages.CONFLICTING_XML_TYPE_MAPPING
/* 278 */             .format(new Object[] { r.getTypeName() }, ), (Locatable)old, (Locatable)r));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getTypeInfo(T t, Locatable upstream) {
/* 291 */     NonElement<T, C> r = this.typeInfoSet.getTypeInfo(t);
/* 292 */     if (r != null) return r;
/*     */     
/* 294 */     if (this.nav.isArray(t)) {
/* 295 */       ArrayInfoImpl<T, C, F, M> ai = (ArrayInfoImpl)createArrayInfo(upstream, t);
/* 296 */       addTypeName((NonElement)ai);
/* 297 */       this.typeInfoSet.add(ai);
/* 298 */       return (NonElement)ai;
/*     */     } 
/*     */     
/* 301 */     C c = (C)this.nav.asDecl(t);
/* 302 */     assert c != null : t.toString() + " must be a leaf, but we failed to recognize it.";
/* 303 */     return getClassInfo(c, upstream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getTypeInfo(Ref<T, C> ref) {
/* 311 */     assert !ref.valueList;
/* 312 */     C c = (C)this.nav.asDecl(ref.type);
/* 313 */     if (c != null && this.reader.getClassAnnotation(XmlRegistry.class, c, null) != null) {
/* 314 */       if (!this.registries.containsKey(this.nav.getPackageName(c)))
/* 315 */         addRegistry(c, null); 
/* 316 */       return null;
/*     */     } 
/* 318 */     return getTypeInfo((T)ref.type, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumLeafInfo<T, C> createEnumLeafInfo(C clazz, Locatable upstream) {
/* 323 */     return new EnumLeafInfoImpl<>(this, upstream, clazz, (T)this.nav.use(clazz));
/*     */   }
/*     */   
/*     */   protected ClassInfo<T, C> createClassInfo(C clazz, Locatable upstream) {
/* 327 */     return new ClassInfoImpl<>(this, upstream, clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ElementInfo<T, C> createElementInfo(RegistryInfo<T, C> registryInfo, M m) throws IllegalAnnotationException {
/* 332 */     return new ElementInfoImpl<>(this, (RegistryInfoImpl)registryInfo, m);
/*     */   }
/*     */   
/*     */   protected ArrayInfo<T, C> createArrayInfo(Locatable upstream, T arrayType) {
/* 336 */     return new ArrayInfoImpl<>(this, upstream, arrayType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegistryInfo<T, C> addRegistry(C registryClass, Locatable upstream) {
/* 345 */     return new RegistryInfoImpl<>(this, upstream, registryClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegistryInfo<T, C> getRegistry(String packageName) {
/* 357 */     return this.registries.get(packageName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInfoSet<T, C, F, M> link() {
/* 375 */     assert !this.linked;
/* 376 */     this.linked = true;
/*     */     
/* 378 */     for (ElementInfoImpl<T, C, F, M> ei : this.typeInfoSet.getAllElements()) {
/* 379 */       ei.link();
/*     */     }
/* 381 */     for (ClassInfoImpl ci : this.typeInfoSet.beans().values()) {
/* 382 */       ci.link();
/*     */     }
/* 384 */     for (EnumLeafInfoImpl li : this.typeInfoSet.enums().values()) {
/* 385 */       li.link();
/*     */     }
/* 387 */     if (this.hadError) {
/* 388 */       return null;
/*     */     }
/* 390 */     return this.typeInfoSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorHandler(ErrorHandler errorHandler) {
/* 406 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */   public final void reportError(IllegalAnnotationException e) {
/* 410 */     this.hadError = true;
/* 411 */     if (this.errorHandler != null)
/* 412 */       this.errorHandler.error(e); 
/*     */   }
/*     */   
/*     */   public boolean isReplaced(C sc) {
/* 416 */     return this.subclassReplacements.containsKey(sc);
/*     */   }
/*     */ 
/*     */   
/*     */   public Navigator<T, C, F, M> getNavigator() {
/* 421 */     return this.nav;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationReader<T, C, F, M> getReader() {
/* 426 */     return this.reader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ModelBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */