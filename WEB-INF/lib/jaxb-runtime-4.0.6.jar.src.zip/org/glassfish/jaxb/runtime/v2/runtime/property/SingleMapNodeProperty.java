/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeMapPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TagName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleMapNodeProperty<BeanT, ValueT extends Map>
/*     */   extends PropertyImpl<BeanT>
/*     */ {
/*     */   private final Accessor<BeanT, ValueT> acc;
/*     */   private final Name tagName;
/*     */   private final Name entryTag;
/*     */   private final Name keyTag;
/*     */   private final Name valueTag;
/*     */   private final boolean nillable;
/*     */   private JaxBeanInfo keyBeanInfo;
/*     */   private JaxBeanInfo valueBeanInfo;
/*     */   private final Class<? extends ValueT> mapImplClass;
/*     */   
/*     */   public SingleMapNodeProperty(JAXBContextImpl context, RuntimeMapPropertyInfo prop) {
/*  61 */     super(context, (RuntimePropertyInfo)prop);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.itemsLoader = new Loader(false)
/*     */       {
/* 119 */         private ThreadLocal<SingleMapNodeProperty.Stack<BeanT>> target = new ThreadLocal<>();
/* 120 */         private ThreadLocal<SingleMapNodeProperty.Stack<ValueT>> map = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */         
/*     */         public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*     */           try {
/* 126 */             BeanT target = (BeanT)state.getPrev().getTarget();
/* 127 */             Map map = (Map)SingleMapNodeProperty.this.acc.get(target);
/* 128 */             if (map == null) {
/* 129 */               map = (Map)ClassFactory.create(SingleMapNodeProperty.this.mapImplClass);
/*     */             } else {
/* 131 */               map.clear();
/*     */             } 
/* 133 */             SingleMapNodeProperty.Stack.push(this.target, target);
/* 134 */             SingleMapNodeProperty.Stack.push(this.map, (ValueT)map);
/* 135 */             state.setTarget(map);
/* 136 */           } catch (AccessorException e) {
/*     */             
/* 138 */             handleGenericException((Exception)e, true);
/* 139 */             state.setTarget(new HashMap<>());
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void leaveElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 145 */           super.leaveElement(state, ea);
/*     */           try {
/* 147 */             SingleMapNodeProperty.this.acc.set(SingleMapNodeProperty.Stack.pop(this.target), SingleMapNodeProperty.Stack.<Map>pop(this.map));
/* 148 */           } catch (AccessorException ex) {
/* 149 */             handleGenericException((Exception)ex, true);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 155 */           if (ea.matches(SingleMapNodeProperty.this.entryTag)) {
/* 156 */             state.setLoader(SingleMapNodeProperty.this.entryLoader);
/*     */           } else {
/* 158 */             super.childElement(state, ea);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public Collection<QName> getExpectedChildElements() {
/* 164 */           return Collections.singleton(SingleMapNodeProperty.this.entryTag.toQName());
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     this.entryLoader = new Loader(false)
/*     */       {
/*     */         public void startElement(UnmarshallingContext.State state, TagName ea) {
/* 176 */           state.setTarget(new Object[2]);
/*     */         }
/*     */ 
/*     */         
/*     */         public void leaveElement(UnmarshallingContext.State state, TagName ea) {
/* 181 */           Object[] keyValue = (Object[])state.getTarget();
/* 182 */           Map<Object, Object> map = (Map)state.getPrev().getTarget();
/* 183 */           map.put(keyValue[0], keyValue[1]);
/*     */         }
/*     */ 
/*     */         
/*     */         public void childElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 188 */           if (ea.matches(SingleMapNodeProperty.this.keyTag)) {
/* 189 */             state.setLoader(SingleMapNodeProperty.this.keyLoader);
/* 190 */             state.setReceiver(SingleMapNodeProperty.keyReceiver);
/*     */             return;
/*     */           } 
/* 193 */           if (ea.matches(SingleMapNodeProperty.this.valueTag)) {
/* 194 */             state.setLoader(SingleMapNodeProperty.this.valueLoader);
/* 195 */             state.setReceiver(SingleMapNodeProperty.valueReceiver);
/*     */             return;
/*     */           } 
/* 198 */           super.childElement(state, ea);
/*     */         }
/*     */         
/*     */         public Collection<QName> getExpectedChildElements()
/*     */         {
/* 203 */           return Arrays.asList(new QName[] { this.this$0.keyTag.toQName(), this.this$0.valueTag.toQName() }); }
/*     */       }; this.acc = prop.getAccessor().optimize(context); this.tagName = context.nameBuilder.createElementName(prop.getXmlName()); this.entryTag = context.nameBuilder.createElementName("", "entry"); this.keyTag = context.nameBuilder.createElementName("", "key"); this.valueTag = context.nameBuilder.createElementName("", "value"); this.nillable = prop.isCollectionNillable(); this.keyBeanInfo = context.getOrCreate((RuntimeTypeInfo)prop.getKeyType()); this.valueBeanInfo = context.getOrCreate((RuntimeTypeInfo)prop.getValueType()); Class<ValueT> sig = (Class<ValueT>)Utils.REFLECTION_NAVIGATOR.erasure(prop.getRawType());
/*     */     this.mapImplClass = ClassFactory.inferImplClass(sig, knownImplClasses);
/*     */   } private static final Class[] knownImplClasses = new Class[] { HashMap.class, TreeMap.class, LinkedHashMap.class }; private Loader keyLoader; private Loader valueLoader; private final Loader itemsLoader; private final Loader entryLoader; public void reset(BeanT bean) throws AccessorException { this.acc.set(bean, null); } public String getIdValue(BeanT bean) { return null; } public PropertyKind getKind() { return PropertyKind.MAP; } public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) { this.keyLoader = this.keyBeanInfo.getLoader(chain.context, true);
/*     */     this.valueLoader = this.valueBeanInfo.getLoader(chain.context, true);
/*     */     handlers.put(this.tagName, new ChildLoader(this.itemsLoader, null)); } private static final class ReceiverImpl implements Receiver
/*     */   {
/* 210 */     public ReceiverImpl(int index) { this.index = index; }
/*     */     
/*     */     private final int index;
/*     */     public void receive(UnmarshallingContext.State state, Object o) {
/* 214 */       ((Object[])state.getTarget())[this.index] = o;
/*     */     }
/*     */   }
/*     */   
/* 218 */   private static final Receiver keyReceiver = new ReceiverImpl(0);
/* 219 */   private static final Receiver valueReceiver = new ReceiverImpl(1);
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 223 */     Map map = (Map)this.acc.get(o);
/* 224 */     if (map != null) {
/* 225 */       bareStartTag(w, this.tagName, map);
/* 226 */       for (Map.Entry e : map.entrySet()) {
/* 227 */         bareStartTag(w, this.entryTag, null);
/*     */         
/* 229 */         Object key = e.getKey();
/* 230 */         if (key != null) {
/* 231 */           w.startElement(this.keyTag, key);
/* 232 */           w.childAsXsiType(key, this.fieldName, this.keyBeanInfo, false);
/* 233 */           w.endElement();
/*     */         } 
/*     */         
/* 236 */         Object value = e.getValue();
/* 237 */         if (value != null) {
/* 238 */           w.startElement(this.valueTag, value);
/* 239 */           w.childAsXsiType(value, this.fieldName, this.valueBeanInfo, false);
/* 240 */           w.endElement();
/*     */         } 
/*     */         
/* 243 */         w.endElement();
/*     */       } 
/* 245 */       w.endElement();
/*     */     }
/* 247 */     else if (this.nillable) {
/* 248 */       w.startElement(this.tagName, null);
/* 249 */       w.writeXsiNilTrue();
/* 250 */       w.endElement();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void bareStartTag(XMLSerializer w, Name tagName, Object peer) throws IOException, XMLStreamException, SAXException {
/* 255 */     w.startElement(tagName, peer);
/* 256 */     w.endNamespaceDecls(peer);
/* 257 */     w.endAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 262 */     if (this.tagName.equals(nsUri, localName))
/* 263 */       return this.acc; 
/* 264 */     return null;
/*     */   }
/*     */   
/*     */   private static final class Stack<T> {
/*     */     private Stack<T> parent;
/*     */     private T value;
/*     */     
/*     */     private Stack(Stack<T> parent, T value) {
/* 272 */       this.parent = parent;
/* 273 */       this.value = value;
/*     */     }
/*     */     
/*     */     private Stack(T value) {
/* 277 */       this.value = value;
/*     */     }
/*     */     
/*     */     private static <T> void push(ThreadLocal<Stack<T>> holder, T value) {
/* 281 */       Stack<T> parent = holder.get();
/* 282 */       if (parent == null) {
/* 283 */         holder.set(new Stack<>(value));
/*     */       } else {
/* 285 */         holder.set(new Stack<>(parent, value));
/*     */       } 
/*     */     }
/*     */     private static <T> T pop(ThreadLocal<Stack<T>> holder) {
/* 289 */       Stack<T> current = holder.get();
/* 290 */       if (current.parent == null) {
/* 291 */         holder.remove();
/*     */       } else {
/* 293 */         holder.set(current.parent);
/* 294 */       }  return current.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\SingleMapNodeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */