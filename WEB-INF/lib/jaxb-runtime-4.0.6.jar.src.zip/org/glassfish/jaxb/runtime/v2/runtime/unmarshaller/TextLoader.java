/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextLoader
/*    */   extends Loader
/*    */ {
/*    */   private final Transducer xducer;
/*    */   
/*    */   public TextLoader(Transducer xducer) {
/* 32 */     super(true);
/* 33 */     this.xducer = xducer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/*    */     try {
/* 39 */       state.setTarget(this.xducer.parse(text));
/* 40 */     } catch (AccessorException e) {
/* 41 */       handleGenericException((Exception)e, true);
/* 42 */     } catch (RuntimeException e) {
/* 43 */       handleParseConversionException(state, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\TextLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */