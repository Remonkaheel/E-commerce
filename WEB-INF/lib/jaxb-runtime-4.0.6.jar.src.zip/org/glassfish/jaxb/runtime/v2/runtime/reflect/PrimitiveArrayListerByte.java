/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerByte<BeanT>
/*    */   extends Lister<BeanT, byte[], Byte, PrimitiveArrayListerByte.ByteArrayPack>
/*    */ {
/*    */   static void register() {
/* 29 */     primitiveArrayListers.put(byte.class, new PrimitiveArrayListerByte());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Byte> iterator(final byte[] objects, XMLSerializer context) {
/* 34 */     return new ListIterator<Byte>() {
/* 35 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 39 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Byte next() {
/* 44 */           return Byte.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteArrayPack startPacking(BeanT current, Accessor<BeanT, byte[]> acc) {
/* 51 */     return new ByteArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(ByteArrayPack objects, Byte o) {
/* 56 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(ByteArrayPack pack, BeanT bean, Accessor<BeanT, byte[]> acc) throws AccessorException {
/* 61 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, byte[]> acc) throws AccessorException {
/* 66 */     acc.set(o, new byte[0]);
/*    */   }
/*    */   
/*    */   static final class ByteArrayPack {
/* 70 */     byte[] buf = new byte[16];
/*    */     int size;
/*    */     
/*    */     void add(Byte b) {
/* 74 */       if (this.buf.length == this.size) {
/*    */         
/* 76 */         byte[] nb = new byte[this.buf.length * 2];
/* 77 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 78 */         this.buf = nb;
/*    */       } 
/* 80 */       if (b != null)
/* 81 */         this.buf[this.size++] = b.byteValue(); 
/*    */     }
/*    */     
/*    */     byte[] build() {
/* 85 */       if (this.buf.length == this.size)
/*    */       {
/* 87 */         return this.buf;
/*    */       }
/* 89 */       byte[] r = new byte[this.size];
/* 90 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 91 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerByte.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */