/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeEnumConstantImpl
/*    */   extends EnumConstantImpl<Type, Class, Field, Method>
/*    */ {
/*    */   public RuntimeEnumConstantImpl(RuntimeEnumLeafInfoImpl<Type, Class, Field, Method> owner, String name, String lexical, EnumConstantImpl<Type, Class<?>, Field, Method> next) {
/* 24 */     super(owner, name, lexical, next);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeEnumConstantImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */