/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAnyAttribute;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlAnyAttributeQuick
/*    */   extends Quick
/*    */   implements XmlAnyAttribute
/*    */ {
/*    */   private final XmlAnyAttribute core;
/*    */   
/*    */   public XmlAnyAttributeQuick(Locatable upstream, XmlAnyAttribute core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlAnyAttributeQuick(upstream, (XmlAnyAttribute)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlAnyAttribute> annotationType() {
/* 47 */     return XmlAnyAttribute.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlAnyAttributeQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */