/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlEnum;
/*     */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*     */ import jakarta.xml.bind.annotation.XmlSchemaType;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*     */ import org.glassfish.jaxb.core.v2.model.core.EnumLeafInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EnumLeafInfoImpl<T, C, F, M>
/*     */   extends TypeInfoImpl<T, C, F, M>
/*     */   implements EnumLeafInfo<T, C>, Element<T, C>, Iterable<EnumConstantImpl<T, C, F, M>>
/*     */ {
/*     */   final C clazz;
/*     */   NonElement<T, C> baseType;
/*     */   private final T type;
/*     */   private final QName typeName;
/*     */   private EnumConstantImpl<T, C, F, M> firstConstant;
/*     */   private QName elementName;
/*     */   protected boolean tokenStringType;
/*     */   
/*     */   public EnumLeafInfoImpl(ModelBuilder<T, C, F, M> builder, Locatable upstream, C clazz, T type) {
/*  71 */     super(builder, upstream);
/*  72 */     this.clazz = clazz;
/*  73 */     this.type = type;
/*     */     
/*  75 */     this.elementName = parseElementName(clazz);
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.typeName = parseTypeName(clazz);
/*     */ 
/*     */ 
/*     */     
/*  83 */     XmlEnum xe = (XmlEnum)builder.reader.getClassAnnotation(XmlEnum.class, clazz, this);
/*  84 */     if (xe != null) {
/*  85 */       T base = (T)builder.reader.getClassValue((Annotation)xe, "value");
/*  86 */       this.baseType = builder.getTypeInfo(base, this);
/*     */     } else {
/*  88 */       this.baseType = builder.getTypeInfo((T)builder.nav.ref(String.class), this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void calcConstants() {
/*  96 */     EnumConstantImpl<T, C, F, M> last = null;
/*     */ 
/*     */     
/*  99 */     Collection<? extends F> fields = nav().getDeclaredFields(this.clazz);
/* 100 */     for (F f : fields) {
/* 101 */       if (nav().isSameType(nav().getFieldType(f), nav().ref(String.class))) {
/* 102 */         XmlSchemaType schemaTypeAnnotation = (XmlSchemaType)this.builder.reader.getFieldAnnotation(XmlSchemaType.class, f, this);
/* 103 */         if (schemaTypeAnnotation != null && 
/* 104 */           "token".equals(schemaTypeAnnotation.name())) {
/* 105 */           this.tokenStringType = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 111 */     F[] constants = (F[])nav().getEnumConstants(this.clazz);
/* 112 */     for (int i = constants.length - 1; i >= 0; i--) {
/* 113 */       String literal; F constant = constants[i];
/* 114 */       String name = nav().getFieldName(constant);
/* 115 */       XmlEnumValue xev = (XmlEnumValue)this.builder.reader.getFieldAnnotation(XmlEnumValue.class, constant, this);
/*     */ 
/*     */       
/* 118 */       if (xev == null) { literal = name; }
/* 119 */       else { literal = xev.value(); }
/*     */       
/* 121 */       last = createEnumConstant(name, literal, constant, last);
/*     */     } 
/* 123 */     this.firstConstant = last;
/*     */   }
/*     */   
/*     */   protected EnumConstantImpl<T, C, F, M> createEnumConstant(String name, String literal, F constant, EnumConstantImpl<T, C, F, M> last) {
/* 127 */     return new EnumConstantImpl<>(this, name, literal, last);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getType() {
/* 133 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToken() {
/* 141 */     return this.tokenStringType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final boolean canBeReferencedByIDREF() {
/* 153 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public QName getTypeName() {
/* 158 */     return this.typeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public C getClazz() {
/* 163 */     return this.clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getBaseType() {
/* 168 */     return this.baseType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSimpleType() {
/* 173 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 178 */     return nav().getClassLocation(this.clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<? extends EnumConstantImpl<T, C, F, M>> getConstants() {
/* 183 */     if (this.firstConstant == null)
/* 184 */       calcConstants(); 
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void link() {
/* 191 */     getConstants();
/* 192 */     super.link();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Element<T, C> getSubstitutionHead() {
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public QName getElementName() {
/* 208 */     return this.elementName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isElement() {
/* 213 */     return (this.elementName != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element<T, C> asElement() {
/* 218 */     if (isElement()) {
/* 219 */       return this;
/*     */     }
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ClassInfo<T, C> getScope() {
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<EnumConstantImpl<T, C, F, M>> iterator() {
/* 239 */     return new Iterator<EnumConstantImpl<T, C, F, M>>() {
/* 240 */         private EnumConstantImpl<T, C, F, M> next = EnumLeafInfoImpl.this.firstConstant;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 244 */           return (this.next != null);
/*     */         }
/*     */ 
/*     */         
/*     */         public EnumConstantImpl<T, C, F, M> next() {
/* 249 */           EnumConstantImpl<T, C, F, M> r = this.next;
/* 250 */           this.next = this.next.next;
/* 251 */           return r;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 256 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\EnumLeafInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */