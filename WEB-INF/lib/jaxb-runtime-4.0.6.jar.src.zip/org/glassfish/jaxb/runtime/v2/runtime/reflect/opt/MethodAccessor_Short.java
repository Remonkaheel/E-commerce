/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Short<B>
/*    */   extends Accessor<B, Short>
/*    */ {
/*    */   public MethodAccessor_Short() {
/* 27 */     super(Short.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Short get(B bean) {
/* 32 */     return Short.valueOf(((Bean)bean).get_short());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Short value) {
/* 37 */     ((Bean)bean).set_short((value == null) ? 0 : value.shortValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Short.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */