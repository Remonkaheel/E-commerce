/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValuePropertyLoader
/*    */   extends Loader
/*    */ {
/*    */   private final TransducedAccessor xacc;
/*    */   
/*    */   public ValuePropertyLoader(TransducedAccessor xacc) {
/* 29 */     super(true);
/* 30 */     this.xacc = xacc;
/*    */   }
/*    */ 
/*    */   
/*    */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/*    */     try {
/* 36 */       this.xacc.parse(state.getTarget(), text);
/* 37 */     } catch (AccessorException e) {
/* 38 */       handleGenericException((Exception)e, true);
/* 39 */     } catch (RuntimeException e) {
/* 40 */       if (state.getPrev() != null) {
/* 41 */         if (!(state.getPrev().getTarget() instanceof jakarta.xml.bind.JAXBElement)) {
/* 42 */           handleParseConversionException(state, e);
/*    */         
/*    */         }
/*    */       }
/*    */       else {
/*    */         
/* 48 */         handleParseConversionException(state, e);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\ValuePropertyLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */