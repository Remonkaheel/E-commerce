/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeAnyTypeImpl
/*    */   extends AnyTypeImpl<Type, Class>
/*    */   implements RuntimeNonElement
/*    */ {
/*    */   private RuntimeAnyTypeImpl() {
/* 23 */     super(Utils.REFLECTION_NAVIGATOR);
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> Transducer<V> getTransducer() {
/* 28 */     return null;
/*    */   }
/*    */   
/* 31 */   static final RuntimeNonElement theInstance = new RuntimeAnyTypeImpl();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeAnyTypeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */