/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NameList
/*    */ {
/*    */   public final String[] namespaceURIs;
/*    */   public final boolean[] nsUriCannotBeDefaulted;
/*    */   public final String[] localNames;
/*    */   public final int numberOfElementNames;
/*    */   public final int numberOfAttributeNames;
/*    */   
/*    */   public NameList(String[] namespaceURIs, boolean[] nsUriCannotBeDefaulted, String[] localNames, int numberElementNames, int numberAttributeNames) {
/* 52 */     this.namespaceURIs = namespaceURIs;
/* 53 */     this.nsUriCannotBeDefaulted = nsUriCannotBeDefaulted;
/* 54 */     this.localNames = localNames;
/* 55 */     this.numberOfElementNames = numberElementNames;
/* 56 */     this.numberOfAttributeNames = numberAttributeNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\NameList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */