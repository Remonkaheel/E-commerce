/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.Bridge;
/*    */ import org.glassfish.jaxb.runtime.api.JAXBRIContext;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class InternalBridge<T>
/*    */   extends Bridge<T>
/*    */ {
/*    */   protected InternalBridge(JAXBContextImpl context) {
/* 25 */     super(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public JAXBContextImpl getContext() {
/* 30 */     return this.context;
/*    */   }
/*    */   
/*    */   abstract void marshal(T paramT, XMLSerializer paramXMLSerializer) throws IOException, SAXException, XMLStreamException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\InternalBridge.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */