/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import com.sun.istack.NotNull;
/*    */ import java.io.IOException;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InlineBinaryTransducer<V>
/*    */   extends FilterTransducer<V>
/*    */ {
/*    */   public InlineBinaryTransducer(Transducer<V> core) {
/* 27 */     super(core);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public CharSequence print(@NotNull V o) throws AccessorException {
/* 32 */     XMLSerializer w = XMLSerializer.getInstance();
/* 33 */     boolean old = w.setInlineBinaryFlag(true);
/*    */     try {
/* 35 */       return this.core.print(o);
/*    */     } finally {
/* 37 */       w.setInlineBinaryFlag(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeText(XMLSerializer w, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 43 */     boolean old = w.setInlineBinaryFlag(true);
/*    */     try {
/* 45 */       this.core.writeText(w, o, fieldName);
/*    */     } finally {
/* 47 */       w.setInlineBinaryFlag(old);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeLeafElement(XMLSerializer w, Name tagName, V o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 53 */     boolean old = w.setInlineBinaryFlag(true);
/*    */     try {
/* 55 */       this.core.writeLeafElement(w, tagName, o, fieldName);
/*    */     } finally {
/* 57 */       w.setInlineBinaryFlag(old);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\InlineBinaryTransducer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */