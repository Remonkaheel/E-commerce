/*     */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import com.sun.istack.Nullable;
/*     */ import com.sun.istack.SAXException2;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.impl.RuntimeModelBuilder;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Patcher;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransducedAccessor<BeanT>
/*     */ {
/*     */   public boolean useNamespace() {
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareNamespace(BeanT o, XMLSerializer w) throws AccessorException, SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract CharSequence print(@NotNull BeanT paramBeanT) throws AccessorException, SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void parse(BeanT paramBeanT, CharSequence paramCharSequence) throws AccessorException, SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean hasValue(BeanT paramBeanT) throws AccessorException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> TransducedAccessor<T> get(JAXBContextImpl context, RuntimeNonElementRef ref) {
/* 128 */     Transducer<?> xducer = RuntimeModelBuilder.createTransducer(ref);
/* 129 */     RuntimePropertyInfo prop = ref.getSource();
/*     */     
/* 131 */     if (prop.isCollection()) {
/* 132 */       return new ListTransducedAccessorImpl<>(xducer, prop.getAccessor(), 
/* 133 */           Lister.create((Type)Utils.REFLECTION_NAVIGATOR.erasure(prop.getRawType()), prop.id(), prop.getAdapter()));
/*     */     }
/*     */     
/* 136 */     if (prop.id() == ID.IDREF) {
/* 137 */       return new IDREFTransducedAccessorImpl<>(prop.getAccessor());
/*     */     }
/* 139 */     if (xducer.useNamespace()) {
/* 140 */       return new CompositeContextDependentTransducedAccessorImpl<>(context, xducer, prop.getAccessor());
/*     */     }
/* 142 */     return new CompositeTransducedAccessorImpl<>(context, xducer, prop.getAccessor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void writeLeafElement(XMLSerializer paramXMLSerializer, Name paramName, BeanT paramBeanT, String paramString) throws SAXException, AccessorException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void writeText(XMLSerializer paramXMLSerializer, BeanT paramBeanT, String paramString) throws AccessorException, SAXException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CompositeContextDependentTransducedAccessorImpl<BeanT, ValueT>
/*     */     extends CompositeTransducedAccessorImpl<BeanT, ValueT>
/*     */   {
/*     */     public CompositeContextDependentTransducedAccessorImpl(JAXBContextImpl context, Transducer<ValueT> xducer, Accessor<BeanT, ValueT> acc) {
/* 164 */       super(context, xducer, acc);
/* 165 */       assert xducer.useNamespace();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean useNamespace() {
/* 170 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void declareNamespace(BeanT bean, XMLSerializer w) throws AccessorException {
/* 175 */       ValueT o = this.acc.get(bean);
/* 176 */       if (o != null) {
/* 177 */         this.xducer.declareNamespace(o, w);
/*     */       }
/*     */     }
/*     */     
/*     */     public void writeLeafElement(XMLSerializer w, Name tagName, BeanT o, String fieldName) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 182 */       w.startElement(tagName, null);
/* 183 */       declareNamespace(o, w);
/* 184 */       w.endNamespaceDecls(null);
/* 185 */       w.endAttributes();
/* 186 */       this.xducer.writeText(w, this.acc.get(o), fieldName);
/* 187 */       w.endElement();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class CompositeTransducedAccessorImpl<BeanT, ValueT>
/*     */     extends TransducedAccessor<BeanT>
/*     */   {
/*     */     protected final Transducer<ValueT> xducer;
/*     */     
/*     */     protected final Accessor<BeanT, ValueT> acc;
/*     */ 
/*     */     
/*     */     public CompositeTransducedAccessorImpl(JAXBContextImpl context, Transducer<ValueT> xducer, Accessor<BeanT, ValueT> acc) {
/* 201 */       this.xducer = xducer;
/* 202 */       this.acc = acc.optimize(context);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence print(BeanT bean) throws AccessorException {
/* 207 */       ValueT o = this.acc.get(bean);
/* 208 */       if (o == null) return null; 
/* 209 */       return this.xducer.print(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public void parse(BeanT bean, CharSequence lexical) throws AccessorException, SAXException {
/* 214 */       this.acc.set(bean, (ValueT)this.xducer.parse(lexical));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasValue(BeanT bean) throws AccessorException {
/* 219 */       return (this.acc.getUnadapted(bean) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeLeafElement(XMLSerializer w, Name tagName, BeanT o, String fieldName) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 224 */       this.xducer.writeLeafElement(w, tagName, this.acc.get(o), fieldName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeText(XMLSerializer w, BeanT o, String fieldName) throws AccessorException, SAXException, IOException, XMLStreamException {
/* 229 */       this.xducer.writeText(w, this.acc.get(o), fieldName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class IDREFTransducedAccessorImpl<BeanT, TargetT>
/*     */     extends DefaultTransducedAccessor<BeanT>
/*     */   {
/*     */     private final Accessor<BeanT, TargetT> acc;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class<TargetT> targetType;
/*     */ 
/*     */ 
/*     */     
/*     */     public IDREFTransducedAccessorImpl(Accessor<BeanT, TargetT> acc) {
/* 248 */       this.acc = acc;
/* 249 */       this.targetType = acc.getValueType();
/*     */     }
/*     */ 
/*     */     
/*     */     public String print(BeanT bean) throws AccessorException, SAXException {
/* 254 */       TargetT target = this.acc.get(bean);
/* 255 */       if (target == null) return null;
/*     */       
/* 257 */       XMLSerializer w = XMLSerializer.getInstance();
/*     */       try {
/* 259 */         String id = w.grammar.getBeanInfo(target, true).getId(target, w);
/* 260 */         if (id == null)
/* 261 */           w.errorMissingId(target); 
/* 262 */         return id;
/* 263 */       } catch (JAXBException e) {
/* 264 */         w.reportError(null, (Throwable)e);
/* 265 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void assign(BeanT bean, TargetT t, UnmarshallingContext context) throws AccessorException {
/* 270 */       if (!this.targetType.isInstance(t)) {
/* 271 */         context.handleError(Messages.UNASSIGNABLE_TYPE.format(new Object[] { this.targetType, t.getClass() }));
/*     */       } else {
/* 273 */         this.acc.set(bean, t);
/*     */       } 
/*     */     }
/*     */     public void parse(final BeanT bean, CharSequence lexical) throws AccessorException, SAXException {
/*     */       TargetT t;
/* 278 */       final String idref = WhiteSpaceProcessor.trim(lexical).toString();
/* 279 */       final UnmarshallingContext context = UnmarshallingContext.getInstance();
/*     */       
/* 281 */       final Callable<TargetT> callable = context.getObjectFromId(idref, this.acc.valueType);
/* 282 */       if (callable == null) {
/*     */         
/* 284 */         context.errorUnresolvedIDREF(bean, idref, context.getLocator());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 290 */         t = callable.call();
/* 291 */       } catch (SAXException|RuntimeException e) {
/* 292 */         throw e;
/* 293 */       } catch (Exception e) {
/* 294 */         throw new SAXException2(e);
/*     */       } 
/* 296 */       if (t != null) {
/* 297 */         assign(bean, t, context);
/*     */       } else {
/*     */         
/* 300 */         final LocatorEx.Snapshot loc = new LocatorEx.Snapshot(context.getLocator());
/* 301 */         context.addPatcher(new Patcher()
/*     */             {
/*     */               public void run() throws SAXException {
/*     */                 try {
/* 305 */                   TargetT t = callable.call();
/* 306 */                   if (t == null) {
/* 307 */                     context.errorUnresolvedIDREF(bean, idref, loc);
/*     */                   } else {
/* 309 */                     TransducedAccessor.IDREFTransducedAccessorImpl.this.assign(bean, t, context);
/*     */                   } 
/* 311 */                 } catch (AccessorException e) {
/* 312 */                   context.handleError((Exception)e);
/* 313 */                 } catch (SAXException|RuntimeException e) {
/* 314 */                   throw e;
/* 315 */                 } catch (Exception e) {
/* 316 */                   throw new SAXException2(e);
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasValue(BeanT bean) throws AccessorException {
/* 325 */       return (this.acc.get(bean) != null);
/*     */     }
/*     */   }
/*     */   
/*     */   class null implements Patcher {
/*     */     public void run() throws SAXException {
/*     */       try {
/*     */         TargetT t = callable.call();
/*     */         if (t == null) {
/*     */           context.errorUnresolvedIDREF(bean, idref, loc);
/*     */         } else {
/*     */           TransducedAccessor.IDREFTransducedAccessorImpl.this.assign(bean, t, context);
/*     */         } 
/*     */       } catch (AccessorException e) {
/*     */         context.handleError((Exception)e);
/*     */       } catch (SAXException|RuntimeException e) {
/*     */         throw e;
/*     */       } catch (Exception e) {
/*     */         throw new SAXException2(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\TransducedAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */