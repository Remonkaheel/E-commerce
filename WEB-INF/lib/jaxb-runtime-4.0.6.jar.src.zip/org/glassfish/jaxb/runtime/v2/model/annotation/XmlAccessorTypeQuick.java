/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlAccessorTypeQuick
/*    */   extends Quick
/*    */   implements XmlAccessorType
/*    */ {
/*    */   private final XmlAccessorType core;
/*    */   
/*    */   public XmlAccessorTypeQuick(Locatable upstream, XmlAccessorType core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlAccessorTypeQuick(upstream, (XmlAccessorType)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlAccessorType> annotationType() {
/* 48 */     return XmlAccessorType.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlAccessType value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlAccessorTypeQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */