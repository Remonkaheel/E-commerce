/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuntimeElementPropertyInfoImpl
/*    */   extends ElementPropertyInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeElementPropertyInfo
/*    */ {
/*    */   private final Accessor acc;
/*    */   
/*    */   RuntimeElementPropertyInfoImpl(RuntimeClassInfoImpl classInfo, PropertySeed<Type, Class<?>, Field, Method> seed) {
/* 32 */     super(classInfo, seed);
/* 33 */     Accessor rawAcc = ((RuntimeClassInfoImpl.RuntimePropertySeed)seed).getAccessor();
/* 34 */     if (getAdapter() != null && !isCollection())
/*    */     {
/*    */       
/* 37 */       rawAcc = rawAcc.adapt(getAdapter()); } 
/* 38 */     this.acc = rawAcc;
/*    */   }
/*    */ 
/*    */   
/*    */   public Accessor getAccessor() {
/* 43 */     return this.acc;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean elementOnlyContent() {
/* 48 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends RuntimeTypeInfo> ref() {
/* 53 */     return (List)super.ref();
/*    */   }
/*    */ 
/*    */   
/*    */   protected RuntimeTypeRefImpl createTypeRef(QName name, Type type, boolean isNillable, String defaultValue) {
/* 58 */     return new RuntimeTypeRefImpl(this, name, type, isNillable, defaultValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<RuntimeTypeRefImpl> getTypes() {
/* 63 */     return (List)super.getTypes();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeElementPropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */