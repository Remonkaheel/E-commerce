/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlList;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElementPropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*     */   extends ERPropertyInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*     */   implements ElementPropertyInfo<TypeT, ClassDeclT>
/*     */ {
/*     */   private List<TypeRefImpl<TypeT, ClassDeclT>> types;
/*     */   
/*  41 */   private final List<TypeInfo<TypeT, ClassDeclT>> ref = new AbstractList<TypeInfo<TypeT, ClassDeclT>>()
/*     */     {
/*     */       public TypeInfo<TypeT, ClassDeclT> get(int index) {
/*  44 */         return (TypeInfo<TypeT, ClassDeclT>)((TypeRefImpl)ElementPropertyInfoImpl.this.getTypes().get(index)).getTarget();
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/*  49 */         return ElementPropertyInfoImpl.this.getTypes().size();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean isRequired;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isValueList;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ElementPropertyInfoImpl(ClassInfoImpl<TypeT, ClassDeclT, FieldT, MethodT> parent, PropertySeed<TypeT, ClassDeclT, FieldT, MethodT> propertySeed) {
/*  67 */     super(parent, propertySeed);
/*     */     
/*  69 */     this.isValueList = this.seed.hasAnnotation(XmlList.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeRefImpl<TypeT, ClassDeclT>> getTypes() {
/*  75 */     if (this.types == null) {
/*  76 */       this.types = (List<TypeRefImpl<TypeT, ClassDeclT>>)new FinalArrayList();
/*  77 */       XmlElement[] ann = null;
/*     */       
/*  79 */       XmlElement xe = (XmlElement)this.seed.readAnnotation(XmlElement.class);
/*  80 */       XmlElements xes = (XmlElements)this.seed.readAnnotation(XmlElements.class);
/*     */       
/*  82 */       if (xe != null && xes != null) {
/*  83 */         this.parent.builder.reportError(new IllegalAnnotationException(Messages.MUTUALLY_EXCLUSIVE_ANNOTATIONS
/*  84 */               .format(new Object[] {
/*  85 */                   nav().getClassName(this.parent.getClazz()) + "#" + nav().getClassName(this.parent.getClazz()), xe
/*  86 */                   .annotationType().getName(), xes.annotationType().getName()
/*     */                 }, ), (Annotation)xe, (Annotation)xes));
/*     */       }
/*     */       
/*  90 */       this.isRequired = Boolean.valueOf(true);
/*     */       
/*  92 */       if (xe != null) {
/*  93 */         ann = new XmlElement[] { xe };
/*     */       }
/*  95 */       else if (xes != null) {
/*  96 */         ann = xes.value();
/*     */       } 
/*  98 */       if (ann == null) {
/*     */         
/* 100 */         TypeT t = getIndividualType();
/* 101 */         if (!nav().isPrimitive(t) || isCollection()) {
/* 102 */           this.isRequired = Boolean.valueOf(false);
/*     */         }
/* 104 */         this.types.add(createTypeRef(calcXmlName((XmlElement)null), t, isCollection(), (String)null));
/*     */       } else {
/* 106 */         for (XmlElement item : ann) {
/*     */           
/* 108 */           QName name = calcXmlName(item);
/* 109 */           TypeT type = (TypeT)reader().getClassValue((Annotation)item, "type");
/* 110 */           if (nav().isSameType(type, nav().ref(XmlElement.DEFAULT.class)))
/* 111 */             type = getIndividualType(); 
/* 112 */           if ((!nav().isPrimitive(type) || isCollection()) && !item.required())
/* 113 */             this.isRequired = Boolean.valueOf(false); 
/* 114 */           this.types.add(createTypeRef(name, type, item.nillable(), getDefaultValue(item.defaultValue())));
/*     */         } 
/*     */       } 
/* 117 */       this.types = Collections.unmodifiableList(this.types);
/* 118 */       assert !this.types.contains(null);
/*     */     } 
/* 120 */     return this.types;
/*     */   }
/*     */   
/*     */   private String getDefaultValue(String value) {
/* 124 */     if (value.equals("\000")) {
/* 125 */       return null;
/*     */     }
/* 127 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeRefImpl<TypeT, ClassDeclT> createTypeRef(QName name, TypeT type, boolean isNillable, String defaultValue) {
/* 134 */     return new TypeRefImpl<>(this, name, type, isNillable, defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueList() {
/* 139 */     return this.isValueList;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 144 */     if (this.isRequired == null)
/* 145 */       getTypes(); 
/* 146 */     return this.isRequired.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeInfo<TypeT, ClassDeclT>> ref() {
/* 151 */     return this.ref;
/*     */   }
/*     */ 
/*     */   
/*     */   public final PropertyKind kind() {
/* 156 */     return PropertyKind.ELEMENT;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void link() {
/* 161 */     super.link();
/* 162 */     for (TypeRefImpl<TypeT, ClassDeclT> ref : getTypes()) {
/* 163 */       ref.link();
/*     */     }
/*     */     
/* 166 */     if (isValueList()) {
/*     */ 
/*     */       
/* 169 */       if (id() != ID.IDREF)
/*     */       {
/*     */ 
/*     */         
/* 173 */         for (TypeRefImpl<TypeT, ClassDeclT> ref : this.types) {
/* 174 */           if (!ref.getTarget().isSimpleType()) {
/* 175 */             this.parent.builder.reportError(new IllegalAnnotationException(Messages.XMLLIST_NEEDS_SIMPLETYPE
/* 176 */                   .format(new Object[] {
/* 177 */                       nav().getTypeName(ref.getTarget().getType())
/*     */                     }, ), this));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 183 */       if (!isCollection())
/* 184 */         this.parent.builder.reportError(new IllegalAnnotationException(Messages.XMLLIST_ON_SINGLE_PROPERTY
/* 185 */               .format(new Object[0]), this)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ElementPropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */