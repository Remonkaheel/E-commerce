/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeValuePropertyInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeValuePropertyInfoImpl
/*    */   extends ValuePropertyInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeValuePropertyInfo
/*    */ {
/*    */   RuntimeValuePropertyInfoImpl(RuntimeClassInfoImpl classInfo, PropertySeed<Type, Class<?>, Field, Method> seed) {
/* 29 */     super(classInfo, seed);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean elementOnlyContent() {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimePropertyInfo getSource() {
/* 39 */     return (RuntimePropertyInfo)super.getSource();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getTarget() {
/* 44 */     return (RuntimeNonElement)super.getTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends RuntimeNonElement> ref() {
/* 49 */     return (List)super.ref();
/*    */   }
/*    */ 
/*    */   
/*    */   public void link() {
/* 54 */     getTransducer();
/* 55 */     super.link();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeValuePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */