/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.AccessorFactory;
/*     */ import org.glassfish.jaxb.runtime.AccessorFactoryImpl;
/*     */ import org.glassfish.jaxb.runtime.XmlAccessorFactory;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeClassInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeValuePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ class RuntimeClassInfoImpl extends ClassInfoImpl<Type, Class, Field, Method> implements RuntimeClassInfo, RuntimeElement {
/*     */   private Accessor<?, Locator> xmlLocationAccessor;
/*     */   private AccessorFactory accessorFactory;
/*     */   private boolean supressAccessorWarnings = false;
/*     */   private Accessor<?, Map<QName, String>> attributeWildcardAccessor;
/*     */   private boolean computedTransducer;
/*     */   private Transducer xducer;
/*     */   
/*     */   protected AccessorFactory createAccessorFactory(Class clazz) {
/*     */     AccessorFactoryImpl accessorFactoryImpl;
/*     */     AccessorFactory accFactory = null;
/*     */     JAXBContextImpl context = ((RuntimeModelBuilder)this.builder).context;
/*     */     if (context != null) {
/*     */       this.supressAccessorWarnings = context.supressAccessorWarnings;
/*     */       if (context.xmlAccessorFactorySupport) {
/*     */         XmlAccessorFactory factoryAnn = findXmlAccessorFactoryAnnotation(clazz);
/*     */         if (factoryAnn != null)
/*     */           try {
/*     */             accFactory = factoryAnn.value().getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */           } catch (InstantiationException|NoSuchMethodException|java.lang.reflect.InvocationTargetException e) {
/*     */             this.builder.reportError(new IllegalAnnotationException(Messages.ACCESSORFACTORY_INSTANTIATION_EXCEPTION.format(new Object[] { factoryAnn.getClass().getName(), nav().getClassName(clazz) }, ), this));
/*     */           } catch (IllegalAccessException e) {
/*     */             this.builder.reportError(new IllegalAnnotationException(Messages.ACCESSORFACTORY_ACCESS_EXCEPTION.format(new Object[] { factoryAnn.getClass().getName(), nav().getClassName(clazz) }, ), this));
/*     */           }  
/*     */       } 
/*     */     } 
/*     */     if (accFactory == null)
/*     */       accessorFactoryImpl = AccessorFactoryImpl.getInstance(); 
/*     */     return (AccessorFactory)accessorFactoryImpl;
/*     */   }
/*     */   
/*     */   protected XmlAccessorFactory findXmlAccessorFactoryAnnotation(Class clazz) {
/*     */     XmlAccessorFactory factoryAnn = (XmlAccessorFactory)reader().getClassAnnotation(XmlAccessorFactory.class, clazz, this);
/*     */     if (factoryAnn == null)
/*     */       factoryAnn = (XmlAccessorFactory)reader().getPackageAnnotation(XmlAccessorFactory.class, clazz, this); 
/*     */     return factoryAnn;
/*     */   }
/*     */   
/*     */   public Method getFactoryMethod() {
/*     */     return super.getFactoryMethod();
/*     */   }
/*     */   
/*  72 */   public RuntimeClassInfoImpl(RuntimeModelBuilder modelBuilder, Locatable upstream, Class clazz) { super(modelBuilder, upstream, clazz);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     this.computedTransducer = false;
/* 190 */     this.xducer = null;
/*     */     this.accessorFactory = createAccessorFactory(clazz); } public final RuntimeClassInfoImpl getBaseClass() { return (RuntimeClassInfoImpl)super.getBaseClass(); }
/*     */   protected ReferencePropertyInfo<Type, Class> createReferenceProperty(PropertySeed<Type, Class<?>, Field, Method> seed) { return new RuntimeReferencePropertyInfoImpl(this, seed); }
/*     */   protected AttributePropertyInfo<Type, Class> createAttributeProperty(PropertySeed<Type, Class<?>, Field, Method> seed) { return new RuntimeAttributePropertyInfoImpl(this, seed); }
/* 194 */   public Transducer getTransducer() { if (!this.computedTransducer) {
/* 195 */       this.computedTransducer = true;
/* 196 */       this.xducer = calcTransducer();
/*     */     } 
/* 198 */     return this.xducer; } protected ValuePropertyInfo<Type, Class> createValueProperty(PropertySeed<Type, Class<?>, Field, Method> seed) {
/*     */     return new RuntimeValuePropertyInfoImpl(this, seed);
/*     */   } protected ElementPropertyInfo<Type, Class> createElementProperty(PropertySeed<Type, Class<?>, Field, Method> seed) {
/*     */     return new RuntimeElementPropertyInfoImpl(this, seed);
/*     */   } protected MapPropertyInfo<Type, Class> createMapProperty(PropertySeed<Type, Class<?>, Field, Method> seed) {
/*     */     return new RuntimeMapPropertyInfoImpl(this, seed);
/*     */   }
/* 205 */   private Transducer calcTransducer() { RuntimeValuePropertyInfo valuep = null;
/* 206 */     if (hasAttributeWildcard())
/* 207 */       return null; 
/* 208 */     for (RuntimeClassInfoImpl ci = this; ci != null; ci = ci.getBaseClass()) {
/* 209 */       for (RuntimePropertyInfo pi : ci.getProperties()) {
/* 210 */         if (pi.kind() == PropertyKind.VALUE) {
/* 211 */           valuep = (RuntimeValuePropertyInfo)pi;
/*     */           continue;
/*     */         } 
/* 214 */         return null;
/*     */       } 
/*     */     } 
/* 217 */     if (valuep == null)
/* 218 */       return null; 
/* 219 */     if (!valuep.getTarget().isSimpleType()) {
/* 220 */       return null;
/*     */     }
/* 222 */     return new TransducerImpl(getClazz(), TransducedAccessor.get(((RuntimeModelBuilder)this.builder).context, (RuntimeNonElementRef)valuep)); }
/*     */   
/*     */   public List<? extends RuntimePropertyInfo> getProperties() {
/*     */     return (List)super.getProperties();
/*     */   }
/*     */   public RuntimePropertyInfo getProperty(String name) {
/*     */     return (RuntimePropertyInfo)super.getProperty(name);
/*     */   }
/* 230 */   private Accessor<?, Map<QName, String>> createAttributeWildcardAccessor() { assert this.attributeWildcard != null;
/* 231 */     return ((RuntimePropertySeed)this.attributeWildcard).getAccessor(); }
/*     */   public void link() { getTransducer(); super.link(); }
/*     */   public <B> Accessor<B, Map<QName, String>> getAttributeWildcard() { for (RuntimeClassInfoImpl c = this; c != null; c = c.getBaseClass()) { if (c.attributeWildcard != null) { if (c.attributeWildcardAccessor == null)
/*     */           c.attributeWildcardAccessor = c.createAttributeWildcardAccessor();  return (Accessor)c.attributeWildcardAccessor; }
/*     */        }
/* 236 */      return null; } protected RuntimePropertySeed createFieldSeed(Field field) { Accessor acc; boolean readOnly = Modifier.isStatic(field.getModifiers());
/*     */     
/*     */     try {
/* 239 */       if (this.supressAccessorWarnings) {
/* 240 */         acc = ((InternalAccessorFactory)this.accessorFactory).createFieldAccessor(this.clazz, field, readOnly, this.supressAccessorWarnings);
/*     */       } else {
/* 242 */         acc = this.accessorFactory.createFieldAccessor(this.clazz, field, readOnly);
/*     */       } 
/* 244 */     } catch (JAXBException e) {
/* 245 */       this.builder.reportError(new IllegalAnnotationException(Messages.CUSTOM_ACCESSORFACTORY_FIELD_ERROR
/* 246 */             .format(new Object[] {
/* 247 */                 nav().getClassName(this.clazz), e.toString() }, ), this));
/* 248 */       acc = Accessor.getErrorInstance();
/*     */     } 
/* 250 */     return new RuntimePropertySeed(super.createFieldSeed(field), acc); }
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimePropertySeed createAccessorSeed(Method getter, Method setter) {
/*     */     Accessor acc;
/*     */     try {
/* 257 */       acc = this.accessorFactory.createPropertyAccessor(this.clazz, getter, setter);
/* 258 */     } catch (JAXBException e) {
/* 259 */       this.builder.reportError(new IllegalAnnotationException(Messages.CUSTOM_ACCESSORFACTORY_PROPERTY_ERROR
/* 260 */             .format(new Object[] {
/* 261 */                 nav().getClassName(this.clazz), e.toString() }, ), this));
/* 262 */       acc = Accessor.getErrorInstance();
/*     */     } 
/* 264 */     return new RuntimePropertySeed(super.createAccessorSeed(getter, setter), acc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkFieldXmlLocation(Field f) {
/* 270 */     if (reader().hasFieldAnnotation(XmlLocation.class, f))
/*     */     {
/*     */       
/* 273 */       this.xmlLocationAccessor = (Accessor<?, Locator>)new Accessor.FieldReflection(f);
/*     */     }
/*     */   }
/*     */   
/*     */   public Accessor<?, Locator> getLocatorField() {
/* 278 */     return this.xmlLocationAccessor;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RuntimePropertySeed
/*     */     implements PropertySeed<Type, Class, Field, Method>
/*     */   {
/*     */     private final Accessor acc;
/*     */     
/*     */     private final PropertySeed<Type, Class, Field, Method> core;
/*     */     
/*     */     public RuntimePropertySeed(PropertySeed<Type, Class<?>, Field, Method> core, Accessor acc) {
/* 290 */       this.core = core;
/* 291 */       this.acc = acc;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 296 */       return this.core.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public <A extends Annotation> A readAnnotation(Class<A> annotationType) {
/* 301 */       return (A)this.core.readAnnotation(annotationType);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasAnnotation(Class<? extends Annotation> annotationType) {
/* 306 */       return this.core.hasAnnotation(annotationType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getRawType() {
/* 311 */       return this.core.getRawType();
/*     */     }
/*     */ 
/*     */     
/*     */     public Location getLocation() {
/* 316 */       return this.core.getLocation();
/*     */     }
/*     */ 
/*     */     
/*     */     public Locatable getUpstream() {
/* 321 */       return this.core.getUpstream();
/*     */     }
/*     */     
/*     */     public Accessor getAccessor() {
/* 325 */       return this.acc;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class TransducerImpl<BeanT>
/*     */     implements Transducer<BeanT>
/*     */   {
/*     */     private final TransducedAccessor<BeanT> xacc;
/*     */ 
/*     */     
/*     */     private final Class<BeanT> ownerClass;
/*     */ 
/*     */     
/*     */     public TransducerImpl(Class<BeanT> ownerClass, TransducedAccessor<BeanT> xacc) {
/* 341 */       this.xacc = xacc;
/* 342 */       this.ownerClass = ownerClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean useNamespace() {
/* 347 */       return this.xacc.useNamespace();
/*     */     }
/*     */ 
/*     */     
/*     */     public void declareNamespace(BeanT bean, XMLSerializer w) throws AccessorException {
/*     */       try {
/* 353 */         this.xacc.declareNamespace(bean, w);
/* 354 */       } catch (SAXException e) {
/* 355 */         throw new AccessorException(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public CharSequence print(BeanT o) throws AccessorException {
/*     */       try {
/* 362 */         CharSequence value = this.xacc.print(o);
/* 363 */         if (value == null)
/* 364 */           throw new AccessorException(Messages.THERE_MUST_BE_VALUE_IN_XMLVALUE.format(new Object[] { o })); 
/* 365 */         return value;
/* 366 */       } catch (SAXException e) {
/* 367 */         throw new AccessorException(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public BeanT parse(CharSequence lexical) throws AccessorException, SAXException {
/*     */       BeanT inst;
/* 373 */       UnmarshallingContext ctxt = UnmarshallingContext.getInstance();
/*     */       
/* 375 */       if (ctxt != null) {
/* 376 */         inst = (BeanT)ctxt.createInstance(this.ownerClass);
/*     */       }
/*     */       else {
/*     */         
/* 380 */         inst = (BeanT)ClassFactory.create(this.ownerClass);
/*     */       } 
/* 382 */       this.xacc.parse(inst, lexical);
/* 383 */       return inst;
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeText(XMLSerializer w, BeanT o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 388 */       if (!this.xacc.hasValue(o))
/* 389 */         throw new AccessorException(Messages.THERE_MUST_BE_VALUE_IN_XMLVALUE.format(new Object[] { o })); 
/* 390 */       this.xacc.writeText(w, o, fieldName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeLeafElement(XMLSerializer w, Name tagName, BeanT o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 395 */       if (!this.xacc.hasValue(o))
/* 396 */         throw new AccessorException(Messages.THERE_MUST_BE_VALUE_IN_XMLVALUE.format(new Object[] { o })); 
/* 397 */       this.xacc.writeLeafElement(w, tagName, o, fieldName);
/*     */     }
/*     */ 
/*     */     
/*     */     public QName getTypeName(BeanT instance) {
/* 402 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeClassInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */