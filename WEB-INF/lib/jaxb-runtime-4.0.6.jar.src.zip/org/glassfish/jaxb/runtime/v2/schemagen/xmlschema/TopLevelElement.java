package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;
import javax.xml.namespace.QName;

@XmlElement("element")
public interface TopLevelElement extends TypedXmlWriter, Element {
  @XmlAttribute("final")
  TopLevelElement _final(String paramString);
  
  @XmlAttribute("final")
  TopLevelElement _final(String[] paramArrayOfString);
  
  @XmlAttribute("abstract")
  TopLevelElement _abstract(boolean paramBoolean);
  
  @XmlAttribute
  TopLevelElement substitutionGroup(QName paramQName);
  
  @XmlAttribute
  TopLevelElement name(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\TopLevelElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */