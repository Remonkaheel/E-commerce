/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.MarshalException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import jakarta.xml.bind.attachment.AttachmentMarshaller;
/*     */ import jakarta.xml.bind.helpers.AbstractMarshallerImpl;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.Flushable;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLEventWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.validation.Schema;
/*     */ import javax.xml.validation.ValidatorHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.DataWriter;
/*     */ import org.glassfish.jaxb.core.marshaller.DumbEscapeHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.MinimumEscapeHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.SAX2DOMEx;
/*     */ import org.glassfish.jaxb.core.marshaller.XMLWriter;
/*     */ import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;
/*     */ import org.glassfish.jaxb.runtime.marshaller.NioEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.C14nXmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.Encoded;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.ForkXmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.IndentingUTF8XmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.NamespaceContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.SAXOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.UTF8XmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.XMLEventWriterOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.XmlOutput;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.XMLFilterImpl;
/*     */ 
/*     */ public final class MarshallerImpl extends AbstractMarshallerImpl implements ValidationEventHandler {
/*  56 */   private static final Logger LOGGER = Logger.getLogger(MarshallerImpl.class.getName());
/*     */ 
/*     */   
/*  59 */   private String indent = "    ";
/*     */ 
/*     */   
/*  62 */   private NamespacePrefixMapper prefixMapper = null;
/*     */ 
/*     */   
/*  65 */   private CharacterEscapeHandler escapeHandler = null;
/*     */ 
/*     */   
/*  68 */   private String header = null;
/*     */ 
/*     */ 
/*     */   
/*     */   final JAXBContextImpl context;
/*     */ 
/*     */   
/*     */   protected final XMLSerializer serializer;
/*     */ 
/*     */   
/*     */   private Schema schema;
/*     */ 
/*     */   
/*  81 */   private Marshaller.Listener externalListener = null;
/*     */   
/*     */   private boolean c14nSupport;
/*     */   private Flushable toBeFlushed;
/*     */   private Closeable toBeClosed;
/*     */   protected static final String INDENT_STRING = "org.glassfish.jaxb.indentString";
/*     */   protected static final String PREFIX_MAPPER = "org.glassfish.jaxb.namespacePrefixMapper";
/*     */   protected static final String ENCODING_HANDLER = "org.glassfish.jaxb.characterEscapeHandler";
/*     */   protected static final String ENCODING_HANDLER2 = "org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler";
/*     */   protected static final String XMLDECLARATION = "org.glassfish.jaxb.xmlDeclaration";
/*     */   protected static final String XML_HEADERS = "org.glassfish.jaxb.xmlHeaders";
/*     */   protected static final String C14N = "org.glassfish.jaxb.c14n";
/*     */   protected static final String OBJECT_IDENTITY_CYCLE_DETECTION = "org.glassfish.jaxb.objectIdentitityCycleDetection";
/*     */   
/*     */   public MarshallerImpl(JAXBContextImpl c, AssociationMap assoc) {
/*  96 */     this.context = c;
/*  97 */     this.serializer = new XMLSerializer(this);
/*  98 */     this.c14nSupport = this.context.c14nSupport;
/*     */     
/*     */     try {
/* 101 */       setEventHandler(this);
/* 102 */     } catch (JAXBException e) {
/* 103 */       throw new AssertionError(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public JAXBContextImpl getContext() {
/* 108 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void marshal(Object obj, OutputStream out, NamespaceContext inscopeNamespace) throws JAXBException {
/* 118 */     write(obj, createWriter(out), new StAXPostInitAction(inscopeNamespace, this.serializer));
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Object obj, XMLStreamWriter writer) throws JAXBException {
/* 123 */     write(obj, XMLStreamWriterOutput.create(writer, this.context, this.escapeHandler), new StAXPostInitAction(writer, this.serializer));
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Object obj, XMLEventWriter writer) throws JAXBException {
/* 128 */     write(obj, (XmlOutput)new XMLEventWriterOutput(writer), new StAXPostInitAction(writer, this.serializer));
/*     */   }
/*     */   
/*     */   public void marshal(Object obj, XmlOutput output) throws JAXBException {
/* 132 */     write(obj, output, (Runnable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlOutput createXmlOutput(Result result) throws JAXBException {
/* 139 */     if (result instanceof SAXResult) {
/* 140 */       return (XmlOutput)new SAXOutput(((SAXResult)result).getHandler());
/*     */     }
/* 142 */     if (result instanceof DOMResult) {
/* 143 */       Node node = ((DOMResult)result).getNode();
/*     */       
/* 145 */       if (node == null) {
/* 146 */         Document doc = JAXBContextImpl.createDom((getContext()).disableSecurityProcessing);
/* 147 */         ((DOMResult)result).setNode(doc);
/* 148 */         return (XmlOutput)new SAXOutput((ContentHandler)new SAX2DOMEx(doc));
/*     */       } 
/* 150 */       return (XmlOutput)new SAXOutput((ContentHandler)new SAX2DOMEx(node));
/*     */     } 
/*     */     
/* 153 */     if (result instanceof StreamResult) {
/* 154 */       StreamResult sr = (StreamResult)result;
/*     */       
/* 156 */       if (sr.getWriter() != null)
/* 157 */         return createWriter(sr.getWriter()); 
/* 158 */       if (sr.getOutputStream() != null)
/* 159 */         return createWriter(sr.getOutputStream()); 
/* 160 */       if (sr.getSystemId() != null) {
/* 161 */         String fileURL = sr.getSystemId();
/*     */         
/*     */         try {
/* 164 */           fileURL = (new URI(fileURL)).getPath();
/* 165 */         } catch (URISyntaxException uRISyntaxException) {}
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 170 */           FileOutputStream fos = new FileOutputStream(fileURL);
/* 171 */           assert this.toBeClosed == null;
/* 172 */           this.toBeClosed = fos;
/* 173 */           return createWriter(fos);
/* 174 */         } catch (IOException e) {
/* 175 */           throw new MarshalException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 181 */     throw new MarshalException(Messages.UNSUPPORTED_RESULT.format(new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Runnable createPostInitAction(Result result) {
/* 188 */     if (result instanceof DOMResult) {
/* 189 */       Node node = ((DOMResult)result).getNode();
/* 190 */       return new DomPostInitAction(node, this.serializer);
/*     */     } 
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Object target, Result result) throws JAXBException {
/* 197 */     write(target, createXmlOutput(result), createPostInitAction(result));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> void write(Name rootTagName, JaxBeanInfo<T> bi, T obj, XmlOutput out, Runnable postInitAction) throws JAXBException {
/*     */     try {
/*     */       try {
/* 207 */         prewrite(out, true, postInitAction);
/* 208 */         this.serializer.startElement(rootTagName, (Object)null);
/* 209 */         if (bi.jaxbType == Void.class || bi.jaxbType == void.class) {
/*     */           
/* 211 */           this.serializer.endNamespaceDecls((Object)null);
/* 212 */           this.serializer.endAttributes();
/*     */         }
/* 214 */         else if (obj == null) {
/* 215 */           this.serializer.writeXsiNilTrue();
/*     */         } else {
/* 217 */           this.serializer.childAsXsiType(obj, "root", bi, false);
/*     */         } 
/* 219 */         this.serializer.endElement();
/* 220 */         postwrite();
/* 221 */       } catch (SAXException|XMLStreamException|IOException e) {
/* 222 */         throw new MarshalException(e);
/*     */       } finally {
/* 224 */         this.serializer.close();
/*     */       } 
/*     */     } finally {
/* 227 */       cleanUp();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void write(Object obj, XmlOutput out, Runnable postInitAction) throws JAXBException {
/*     */     try {
/*     */       ForkXmlOutput forkXmlOutput;
/* 236 */       if (obj == null) {
/* 237 */         throw new IllegalArgumentException(Messages.NOT_MARSHALLABLE.format(new Object[0]));
/*     */       }
/* 239 */       if (this.schema != null) {
/*     */         
/* 241 */         ValidatorHandler validator = this.schema.newValidatorHandler();
/* 242 */         validator.setErrorHandler((ErrorHandler)new FatalAdapter(this.serializer));
/*     */         
/* 244 */         XMLFilterImpl f = new XMLFilterImpl()
/*     */           {
/*     */             public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 247 */               super.startPrefixMapping(prefix.intern(), uri.intern());
/*     */             }
/*     */           };
/* 250 */         f.setContentHandler(validator);
/* 251 */         forkXmlOutput = new ForkXmlOutput((XmlOutput)new SAXOutput(f)
/*     */             {
/*     */               public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws SAXException, IOException, XMLStreamException {
/* 254 */                 super.startDocument(serializer, false, nsUriIndex2prefixIndex, nsContext);
/*     */               }
/*     */               
/*     */               public void endDocument(boolean fragment) throws SAXException, IOException, XMLStreamException {
/* 258 */                 super.endDocument(false);
/*     */               }
/*     */             }out);
/*     */       } 
/*     */       
/*     */       try {
/* 264 */         prewrite((XmlOutput)forkXmlOutput, isFragment(), postInitAction);
/* 265 */         this.serializer.childAsRoot(obj);
/* 266 */         postwrite();
/* 267 */       } catch (SAXException|XMLStreamException|IOException e) {
/* 268 */         throw new MarshalException(e);
/*     */       } finally {
/* 270 */         this.serializer.close();
/*     */       } 
/*     */     } finally {
/* 273 */       cleanUp();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanUp() {
/* 278 */     if (this.toBeFlushed != null)
/*     */       try {
/* 280 */         this.toBeFlushed.flush();
/* 281 */       } catch (IOException e) {
/*     */         
/* 283 */         LOGGER.log(Level.SEVERE, e.getMessage(), e);
/*     */       }  
/* 285 */     if (this.toBeClosed != null)
/*     */       try {
/* 287 */         this.toBeClosed.close();
/* 288 */       } catch (IOException e) {
/*     */         
/* 290 */         LOGGER.log(Level.SEVERE, e.getMessage(), e);
/*     */       }  
/* 292 */     this.toBeFlushed = null;
/* 293 */     this.toBeClosed = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void prewrite(XmlOutput out, boolean fragment, Runnable postInitAction) throws IOException, SAXException, XMLStreamException {
/* 299 */     this.serializer.startDocument(out, fragment, getSchemaLocation(), getNoNSSchemaLocation());
/* 300 */     if (postInitAction != null) postInitAction.run(); 
/* 301 */     if (this.prefixMapper != null) {
/*     */       
/* 303 */       String[] decls = this.prefixMapper.getContextualNamespaceDecls();
/* 304 */       if (decls != null)
/* 305 */         for (int i = 0; i < decls.length; i += 2) {
/* 306 */           String prefix = decls[i];
/* 307 */           String nsUri = decls[i + 1];
/* 308 */           if (nsUri != null && prefix != null) {
/* 309 */             this.serializer.addInscopeBinding(nsUri, prefix);
/*     */           }
/*     */         }  
/*     */     } 
/* 313 */     this.serializer.setPrefixMapper(this.prefixMapper);
/*     */   }
/*     */   
/*     */   private void postwrite() throws IOException, SAXException, XMLStreamException {
/* 317 */     this.serializer.endDocument();
/* 318 */     this.serializer.reconcileID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CharacterEscapeHandler getEscapeHandler() {
/* 328 */     return this.escapeHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharacterEscapeHandler createEscapeHandler(String encoding) {
/* 338 */     if (this.escapeHandler != null)
/*     */     {
/* 340 */       return this.escapeHandler;
/*     */     }
/* 342 */     if (encoding.startsWith("UTF"))
/*     */     {
/*     */       
/* 345 */       return MinimumEscapeHandler.theInstance;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 350 */       return (CharacterEscapeHandler)new NioEscapeHandler(getJavaEncoding(encoding));
/* 351 */     } catch (Throwable e) {
/*     */       
/* 353 */       return DumbEscapeHandler.theInstance;
/*     */     } 
/*     */   }
/*     */   
/*     */   public XmlOutput createWriter(Writer w, String encoding) {
/*     */     XMLWriter xw;
/* 359 */     if (!(w instanceof BufferedWriter)) {
/* 360 */       w = new BufferedWriter(w);
/*     */     }
/* 362 */     assert this.toBeFlushed == null;
/* 363 */     this.toBeFlushed = w;
/*     */     
/* 365 */     CharacterEscapeHandler ceh = createEscapeHandler(encoding);
/*     */ 
/*     */     
/* 368 */     if (isFormattedOutput()) {
/* 369 */       DataWriter d = new DataWriter(w, encoding, ceh);
/* 370 */       d.setIndentStep(this.indent);
/* 371 */       DataWriter dataWriter1 = d;
/*     */     } else {
/* 373 */       xw = new XMLWriter(w, encoding, ceh);
/*     */     } 
/* 375 */     xw.setXmlDecl(!isFragment());
/* 376 */     xw.setHeader(this.header);
/* 377 */     return (XmlOutput)new SAXOutput((ContentHandler)xw);
/*     */   }
/*     */   
/*     */   public XmlOutput createWriter(Writer w) {
/* 381 */     return createWriter(w, getEncoding());
/*     */   }
/*     */   
/*     */   public XmlOutput createWriter(OutputStream os) throws JAXBException {
/* 385 */     return createWriter(os, getEncoding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlOutput createWriter(OutputStream os, String encoding) throws JAXBException {
/* 393 */     if (encoding.equals("UTF-8")) {
/* 394 */       UTF8XmlOutput out; Encoded[] table = this.context.getUTF8NameTable();
/*     */       
/* 396 */       CharacterEscapeHandler ceh = createEscapeHandler(encoding);
/* 397 */       if (isFormattedOutput()) {
/* 398 */         IndentingUTF8XmlOutput indentingUTF8XmlOutput = new IndentingUTF8XmlOutput(os, this.indent, table, ceh);
/*     */       }
/* 400 */       else if (this.c14nSupport) {
/* 401 */         C14nXmlOutput c14nXmlOutput = new C14nXmlOutput(os, table, this.context.c14nSupport, ceh);
/*     */       } else {
/* 403 */         out = new UTF8XmlOutput(os, table, ceh);
/*     */       } 
/* 405 */       if (this.header != null)
/* 406 */         out.setHeader(this.header); 
/* 407 */       return (XmlOutput)out;
/*     */     } 
/*     */     
/*     */     try {
/* 411 */       return createWriter(new OutputStreamWriter(os, 
/* 412 */             getJavaEncoding(encoding)), encoding);
/*     */     }
/* 414 */     catch (UnsupportedEncodingException e) {
/* 415 */       throw new MarshalException(Messages.UNSUPPORTED_ENCODING
/* 416 */           .format(new Object[] { encoding }, ), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 424 */     if ("org.glassfish.jaxb.indentString".equals(name))
/* 425 */       return this.indent; 
/* 426 */     if ("org.glassfish.jaxb.characterEscapeHandler".equals(name) || "org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler".equals(name))
/* 427 */       return this.escapeHandler; 
/* 428 */     if ("org.glassfish.jaxb.namespacePrefixMapper".equals(name))
/* 429 */       return this.prefixMapper; 
/* 430 */     if ("org.glassfish.jaxb.xmlDeclaration".equals(name))
/* 431 */       return Boolean.valueOf(!isFragment()); 
/* 432 */     if ("org.glassfish.jaxb.xmlHeaders".equals(name))
/* 433 */       return this.header; 
/* 434 */     if ("org.glassfish.jaxb.c14n".equals(name))
/* 435 */       return Boolean.valueOf(this.c14nSupport); 
/* 436 */     if ("org.glassfish.jaxb.objectIdentitityCycleDetection".equals(name)) {
/* 437 */       return Boolean.valueOf(this.serializer.getObjectIdentityCycleDetection());
/*     */     }
/* 439 */     return super.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 444 */     if ("org.glassfish.jaxb.indentString".equals(name)) {
/* 445 */       checkString(name, value);
/* 446 */       this.indent = (String)value;
/*     */       return;
/*     */     } 
/* 449 */     if ("org.glassfish.jaxb.characterEscapeHandler".equals(name) || "org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler".equals(name)) {
/* 450 */       if (!(value instanceof CharacterEscapeHandler))
/* 451 */         throw new PropertyException(Messages.MUST_BE_X
/* 452 */             .format(new Object[] {
/*     */                 
/* 454 */                 name, CharacterEscapeHandler.class.getName(), value
/* 455 */                 .getClass().getName() })); 
/* 456 */       this.escapeHandler = (CharacterEscapeHandler)value;
/*     */       return;
/*     */     } 
/* 459 */     if ("org.glassfish.jaxb.namespacePrefixMapper".equals(name)) {
/* 460 */       if (!(value instanceof NamespacePrefixMapper))
/* 461 */         throw new PropertyException(Messages.MUST_BE_X
/* 462 */             .format(new Object[] {
/*     */                 
/* 464 */                 name, NamespacePrefixMapper.class.getName(), value
/* 465 */                 .getClass().getName() })); 
/* 466 */       this.prefixMapper = (NamespacePrefixMapper)value;
/*     */       return;
/*     */     } 
/* 469 */     if ("org.glassfish.jaxb.xmlDeclaration".equals(name)) {
/* 470 */       checkBoolean(name, value);
/*     */ 
/*     */       
/* 473 */       super.setProperty("jaxb.fragment", Boolean.valueOf(!((Boolean)value).booleanValue()));
/*     */       return;
/*     */     } 
/* 476 */     if ("org.glassfish.jaxb.xmlHeaders".equals(name)) {
/* 477 */       checkString(name, value);
/* 478 */       this.header = (String)value;
/*     */       return;
/*     */     } 
/* 481 */     if ("org.glassfish.jaxb.c14n".equals(name)) {
/* 482 */       checkBoolean(name, value);
/* 483 */       this.c14nSupport = ((Boolean)value).booleanValue();
/*     */       return;
/*     */     } 
/* 486 */     if ("org.glassfish.jaxb.objectIdentitityCycleDetection".equals(name)) {
/* 487 */       checkBoolean(name, value);
/* 488 */       this.serializer.setObjectIdentityCycleDetection(((Boolean)value).booleanValue());
/*     */       
/*     */       return;
/*     */     } 
/* 492 */     super.setProperty(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkBoolean(String name, Object value) throws PropertyException {
/* 499 */     if (!(value instanceof Boolean)) {
/* 500 */       throw new PropertyException(Messages.MUST_BE_X
/* 501 */           .format(new Object[] {
/*     */               
/* 503 */               name, Boolean.class.getName(), value
/* 504 */               .getClass().getName()
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkString(String name, Object value) throws PropertyException {
/* 511 */     if (!(value instanceof String))
/* 512 */       throw new PropertyException(Messages.MUST_BE_X
/* 513 */           .format(new Object[] {
/*     */               
/* 515 */               name, String.class.getName(), value
/* 516 */               .getClass().getName()
/*     */             })); 
/*     */   }
/*     */   
/*     */   public <A extends XmlAdapter<?, ?>> void setAdapter(Class<A> type, A adapter) {
/* 521 */     if (type == null)
/* 522 */       throw new IllegalArgumentException(); 
/* 523 */     this.serializer.putAdapter(type, (XmlAdapter)adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends XmlAdapter<?, ?>> A getAdapter(Class<A> type) {
/* 528 */     if (type == null)
/* 529 */       throw new IllegalArgumentException(); 
/* 530 */     if (this.serializer.containsAdapter(type))
/*     */     {
/* 532 */       return this.serializer.getAdapter(type);
/*     */     }
/* 534 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttachmentMarshaller(AttachmentMarshaller am) {
/* 539 */     this.serializer.attachmentMarshaller = am;
/*     */   }
/*     */ 
/*     */   
/*     */   public AttachmentMarshaller getAttachmentMarshaller() {
/* 544 */     return this.serializer.attachmentMarshaller;
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/* 549 */     return this.schema;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSchema(Schema s) {
/* 554 */     this.schema = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleEvent(ValidationEvent event) {
/* 563 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Marshaller.Listener getListener() {
/* 568 */     return this.externalListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListener(Marshaller.Listener listener) {
/* 573 */     this.externalListener = listener;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\MarshallerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */