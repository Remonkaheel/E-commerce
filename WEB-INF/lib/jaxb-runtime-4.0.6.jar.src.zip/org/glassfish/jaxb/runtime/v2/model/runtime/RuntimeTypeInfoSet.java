package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Map;
import javax.xml.namespace.QName;
import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
import org.glassfish.jaxb.core.v2.model.core.NonElement;
import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;

public interface RuntimeTypeInfoSet extends TypeInfoSet<Type, Class, Field, Method> {
  Map<Class, ? extends RuntimeArrayInfo> arrays();
  
  Map<Class, ? extends RuntimeClassInfo> beans();
  
  Map<Type, ? extends RuntimeBuiltinLeafInfo> builtins();
  
  Map<Class, ? extends RuntimeEnumLeafInfo> enums();
  
  RuntimeNonElement getTypeInfo(Type paramType);
  
  RuntimeNonElement getAnyTypeInfo();
  
  RuntimeNonElement getClassInfo(Class paramClass);
  
  RuntimeElementInfo getElementInfo(Class paramClass, QName paramQName);
  
  Map<QName, ? extends RuntimeElementInfo> getElementMappings(Class paramClass);
  
  Iterable<? extends RuntimeElementInfo> getAllElements();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeTypeInfoSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */