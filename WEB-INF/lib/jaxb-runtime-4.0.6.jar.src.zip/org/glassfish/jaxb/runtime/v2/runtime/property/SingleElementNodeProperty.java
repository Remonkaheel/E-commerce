/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeRef;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.DefaultValueLoaderDecorator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiNilLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleElementNodeProperty<BeanT, ValueT>
/*     */   extends PropertyImpl<BeanT>
/*     */ {
/*     */   private final Accessor<BeanT, ValueT> acc;
/*     */   private final boolean nillable;
/*     */   private final QName[] acceptedElements;
/*  51 */   private final Map<Class, TagAndType> typeNames = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   private RuntimeElementPropertyInfo prop;
/*     */ 
/*     */   
/*     */   private final Name nullTagName;
/*     */ 
/*     */   
/*     */   public SingleElementNodeProperty(JAXBContextImpl context, RuntimeElementPropertyInfo prop) {
/*  61 */     super(context, (RuntimePropertyInfo)prop);
/*  62 */     this.acc = prop.getAccessor().optimize(context);
/*  63 */     this.prop = prop;
/*     */     
/*  65 */     QName nt = null;
/*  66 */     boolean nil = false;
/*     */     
/*  68 */     this.acceptedElements = new QName[prop.getTypes().size()];
/*  69 */     for (int i = 0; i < this.acceptedElements.length; i++) {
/*  70 */       this.acceptedElements[i] = ((RuntimeTypeRef)prop.getTypes().get(i)).getTagName();
/*     */     }
/*  72 */     for (RuntimeTypeRef e : prop.getTypes()) {
/*  73 */       JaxBeanInfo beanInfo = context.getOrCreate((RuntimeTypeInfo)e.getTarget());
/*  74 */       if (nt == null) nt = e.getTagName(); 
/*  75 */       this.typeNames.put(beanInfo.jaxbType, new TagAndType(context.nameBuilder
/*  76 */             .createElementName(e.getTagName()), beanInfo));
/*  77 */       nil |= e.isNillable();
/*     */     } 
/*     */     
/*  80 */     this.nullTagName = context.nameBuilder.createElementName(nt);
/*     */     
/*  82 */     this.nillable = nil;
/*     */   }
/*     */ 
/*     */   
/*     */   public void wrapUp() {
/*  87 */     super.wrapUp();
/*  88 */     this.prop = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(BeanT bean) throws AccessorException {
/*  93 */     this.acc.set(bean, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdValue(BeanT beanT) {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/* 103 */     ValueT v = (ValueT)this.acc.get(o);
/* 104 */     if (v != null) {
/* 105 */       Class<?> vtype = v.getClass();
/* 106 */       TagAndType tt = this.typeNames.get(vtype);
/*     */       
/* 108 */       if (tt == null) {
/* 109 */         for (Map.Entry<Class<?>, TagAndType> e : this.typeNames.entrySet()) {
/* 110 */           if (((Class)e.getKey()).isAssignableFrom(vtype)) {
/* 111 */             tt = e.getValue();
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 117 */       boolean addNilDecl = (o instanceof JAXBElement && ((JAXBElement)o).isNil());
/* 118 */       if (tt == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 124 */         w.startElement(((TagAndType)this.typeNames.values().iterator().next()).tagName, null);
/* 125 */         w.childAsXsiType(v, this.fieldName, w.grammar.getBeanInfo(Object.class), (addNilDecl && this.nillable));
/*     */       } else {
/* 127 */         w.startElement(tt.tagName, null);
/* 128 */         w.childAsXsiType(v, this.fieldName, tt.beanInfo, (addNilDecl && this.nillable));
/*     */       } 
/* 130 */       w.endElement();
/* 131 */     } else if (this.nillable) {
/* 132 */       w.startElement(this.nullTagName, null);
/* 133 */       w.writeXsiNilTrue();
/* 134 */       w.endElement();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) {
/* 140 */     JAXBContextImpl context = chain.context;
/*     */     
/* 142 */     for (TypeRef<Type, Class<?>> e : (Iterable<TypeRef<Type, Class<?>>>)this.prop.getTypes()) {
/* 143 */       DefaultValueLoaderDecorator defaultValueLoaderDecorator; XsiNilLoader.Single single; JaxBeanInfo bi = context.getOrCreate((RuntimeTypeInfo)e.getTarget());
/*     */ 
/*     */       
/* 146 */       Loader l = bi.getLoader(context, !Modifier.isFinal(bi.jaxbType.getModifiers()));
/* 147 */       if (e.getDefaultValue() != null)
/* 148 */         defaultValueLoaderDecorator = new DefaultValueLoaderDecorator(l, e.getDefaultValue()); 
/* 149 */       if (this.nillable || chain.context.allNillable)
/* 150 */         single = new XsiNilLoader.Single((Loader)defaultValueLoaderDecorator, this.acc); 
/* 151 */       handlers.put(e.getTagName(), new ChildLoader((Loader)single, (Receiver)this.acc));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/* 157 */     return PropertyKind.ELEMENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 162 */     for (QName n : this.acceptedElements) {
/* 163 */       if (n.getNamespaceURI().equals(nsUri) && n.getLocalPart().equals(localName))
/* 164 */         return this.acc; 
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\SingleElementNodeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */