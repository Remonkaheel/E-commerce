/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementRef;
/*    */ import jakarta.xml.bind.annotation.XmlElementRefs;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementRefsQuick
/*    */   extends Quick
/*    */   implements XmlElementRefs
/*    */ {
/*    */   private final XmlElementRefs core;
/*    */   
/*    */   public XmlElementRefsQuick(Locatable upstream, XmlElementRefs core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlElementRefsQuick(upstream, (XmlElementRefs)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElementRefs> annotationType() {
/* 48 */     return XmlElementRefs.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlElementRef[] value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementRefsQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */