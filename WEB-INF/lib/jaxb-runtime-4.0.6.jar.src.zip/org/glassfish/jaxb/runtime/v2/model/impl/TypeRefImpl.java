/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.TypeRef;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TypeRefImpl<TypeT, ClassDeclT>
/*    */   implements TypeRef<TypeT, ClassDeclT>
/*    */ {
/*    */   private final QName elementName;
/*    */   private final TypeT type;
/*    */   protected final ElementPropertyInfoImpl<TypeT, ClassDeclT, ?, ?> owner;
/*    */   private NonElement<TypeT, ClassDeclT> ref;
/*    */   private final boolean isNillable;
/*    */   private String defaultValue;
/*    */   
/*    */   public TypeRefImpl(ElementPropertyInfoImpl<TypeT, ClassDeclT, ?, ?> owner, QName elementName, TypeT type, boolean isNillable, String defaultValue) {
/* 31 */     this.owner = owner;
/* 32 */     this.elementName = elementName;
/* 33 */     this.type = type;
/* 34 */     this.isNillable = isNillable;
/* 35 */     this.defaultValue = defaultValue;
/* 36 */     assert owner != null;
/* 37 */     assert elementName != null;
/* 38 */     assert type != null;
/*    */   }
/*    */ 
/*    */   
/*    */   public NonElement<TypeT, ClassDeclT> getTarget() {
/* 43 */     if (this.ref == null)
/* 44 */       calcRef(); 
/* 45 */     return this.ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getTagName() {
/* 50 */     return this.elementName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNillable() {
/* 55 */     return this.isNillable;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDefaultValue() {
/* 60 */     return this.defaultValue;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void link() {
/* 65 */     calcRef();
/*    */   }
/*    */ 
/*    */   
/*    */   private void calcRef() {
/* 70 */     this.ref = this.owner.parent.builder.getTypeInfo(this.type, this.owner);
/* 71 */     assert this.ref != null;
/*    */   }
/*    */ 
/*    */   
/*    */   public PropertyInfo<TypeT, ClassDeclT> getSource() {
/* 76 */     return this.owner;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\TypeRefImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */