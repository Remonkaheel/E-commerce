/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.DefaultTransducedAccessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TransducedAccessor_method_Byte<T>
/*    */   extends DefaultTransducedAccessor<T>
/*    */ {
/*    */   public String print(T o) {
/* 31 */     return DatatypeConverterImpl._printByte(((Bean)o).get_byte());
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(T o, CharSequence lexical) {
/* 36 */     ((Bean)o).set_byte(DatatypeConverterImpl._parseByte(lexical));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasValue(T o) {
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\TransducedAccessor_method_Byte.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */