/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEventHandler;
/*    */ import java.util.HashMap;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.glassfish.jaxb.runtime.IDResolver;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultIDResolver
/*    */   extends IDResolver
/*    */ {
/* 27 */   private HashMap<String, Object> idmap = null;
/*    */ 
/*    */   
/*    */   public void startDocument(ValidationEventHandler eventHandler) throws SAXException {
/* 31 */     if (this.idmap != null) {
/* 32 */       this.idmap.clear();
/*    */     }
/*    */   }
/*    */   
/*    */   public void bind(String id, Object obj) {
/* 37 */     if (this.idmap == null) this.idmap = new HashMap<>(); 
/* 38 */     this.idmap.put(id, obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public Callable resolve(final String id, Class targetType) {
/* 43 */     return new Callable()
/*    */       {
/*    */         public Object call() throws Exception {
/* 46 */           if (DefaultIDResolver.this.idmap == null) return null; 
/* 47 */           return DefaultIDResolver.this.idmap.get(id);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\DefaultIDResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */