/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.DefaultTransducedAccessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TransducedAccessor_method_Long<T>
/*    */   extends DefaultTransducedAccessor<T>
/*    */ {
/*    */   public String print(T o) {
/* 33 */     return DatatypeConverterImpl._printLong(((Bean)o).get_long());
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(T o, CharSequence lexical) {
/* 38 */     ((Bean)o).set_long(DatatypeConverterImpl._parseLong(lexical));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasValue(T o) {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\TransducedAccessor_method_Long.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */