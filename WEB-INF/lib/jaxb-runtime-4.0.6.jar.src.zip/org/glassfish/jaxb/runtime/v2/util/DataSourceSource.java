/*     */ package org.glassfish.jaxb.runtime.v2.util;
/*     */ 
/*     */ import jakarta.activation.DataHandler;
/*     */ import jakarta.activation.DataSource;
/*     */ import jakarta.activation.MimeType;
/*     */ import jakarta.activation.MimeTypeParseException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataSourceSource
/*     */   extends StreamSource
/*     */ {
/*     */   private final DataSource source;
/*     */   private final String charset;
/*     */   private Reader r;
/*     */   private InputStream is;
/*     */   
/*     */   public DataSourceSource(DataHandler dh) throws MimeTypeParseException {
/*  54 */     this(dh.getDataSource());
/*     */   }
/*     */   
/*     */   public DataSourceSource(DataSource source) throws MimeTypeParseException {
/*  58 */     this.source = source;
/*     */     
/*  60 */     String ct = source.getContentType();
/*  61 */     if (ct == null) {
/*  62 */       this.charset = null;
/*     */     } else {
/*  64 */       MimeType mimeType = new MimeType(ct);
/*  65 */       this.charset = mimeType.getParameter("charset");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReader(Reader reader) {
/*  71 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream inputStream) {
/*  76 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getReader() {
/*     */     try {
/*  82 */       if (this.charset == null) return null; 
/*  83 */       if (this.r == null)
/*  84 */         this.r = new InputStreamReader(this.source.getInputStream(), this.charset); 
/*  85 */       return this.r;
/*  86 */     } catch (IOException e) {
/*     */       
/*  88 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/*     */     try {
/*  95 */       if (this.charset != null) return null; 
/*  96 */       if (this.is == null)
/*  97 */         this.is = this.source.getInputStream(); 
/*  98 */       return this.is;
/*  99 */     } catch (IOException e) {
/*     */       
/* 101 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataSource getDataSource() {
/* 106 */     return this.source;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\DataSourceSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */