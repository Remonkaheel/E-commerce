/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StAXEventConnector
/*     */   extends StAXConnector
/*     */ {
/*     */   private final XMLEventReader staxEventReader;
/*     */   private XMLEvent event;
/*  45 */   private final AttributesImpl attrs = new AttributesImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private final StringBuilder buffer = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean seenText;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StAXEventConnector(XMLEventReader staxCore, XmlVisitor visitor) {
/*  65 */     super(visitor);
/*  66 */     this.staxEventReader = staxCore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bridge() throws XMLStreamException {
/*     */     try {
/*  74 */       int depth = 0;
/*     */       
/*  76 */       this.event = this.staxEventReader.peek();
/*     */       
/*  78 */       if (!this.event.isStartDocument() && !this.event.isStartElement()) {
/*  79 */         throw new IllegalStateException();
/*     */       }
/*     */       
/*     */       do {
/*  83 */         this.event = this.staxEventReader.nextEvent();
/*  84 */       } while (!this.event.isStartElement());
/*     */       
/*  86 */       handleStartDocument(this.event.asStartElement().getNamespaceContext());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/*  93 */         switch (this.event.getEventType()) {
/*     */           case 1:
/*  95 */             handleStartElement(this.event.asStartElement());
/*  96 */             depth++;
/*     */             break;
/*     */           case 2:
/*  99 */             depth--;
/* 100 */             handleEndElement(this.event.asEndElement());
/* 101 */             if (depth == 0)
/*     */               break;  break;
/*     */           case 4:
/*     */           case 6:
/*     */           case 12:
/* 106 */             handleCharacters(this.event.asCharacters());
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/* 111 */         this.event = this.staxEventReader.nextEvent();
/*     */       } 
/*     */       
/* 114 */       handleEndDocument();
/* 115 */       this.event = null;
/* 116 */     } catch (SAXException e) {
/* 117 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Location getCurrentLocation() {
/* 123 */     return this.event.getLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getCurrentQName() {
/*     */     QName qName;
/* 129 */     if (this.event.isEndElement()) {
/* 130 */       qName = this.event.asEndElement().getName();
/*     */     } else {
/* 132 */       qName = this.event.asStartElement().getName();
/* 133 */     }  return getQName(qName.getPrefix(), qName.getLocalPart());
/*     */   }
/*     */   
/*     */   private void handleCharacters(Characters event) throws SAXException, XMLStreamException {
/*     */     XMLEvent next;
/* 138 */     if (!this.predictor.expectText()) {
/*     */       return;
/*     */     }
/* 141 */     this.seenText = true;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 146 */       next = this.staxEventReader.peek();
/* 147 */       if (!isIgnorable(next))
/*     */         break; 
/* 149 */       this.staxEventReader.nextEvent();
/*     */     } 
/*     */     
/* 152 */     if (isTag(next)) {
/*     */       
/* 154 */       this.visitor.text(event.getData());
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 160 */     this.buffer.append(event.getData());
/*     */ 
/*     */     
/*     */     while (true) {
/* 164 */       next = this.staxEventReader.peek();
/* 165 */       if (!isIgnorable(next)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 170 */         if (isTag(next)) {
/*     */           
/* 172 */           this.visitor.text(this.buffer);
/* 173 */           this.buffer.setLength(0);
/*     */           
/*     */           return;
/*     */         } 
/* 177 */         this.buffer.append(next.asCharacters().getData());
/* 178 */         this.staxEventReader.nextEvent();
/*     */         continue;
/*     */       } 
/*     */       this.staxEventReader.nextEvent();
/*     */     }  } private boolean isTag(XMLEvent event) {
/* 183 */     int eventType = event.getEventType();
/* 184 */     return (eventType == 1 || eventType == 2);
/*     */   }
/*     */   
/*     */   private boolean isIgnorable(XMLEvent event) {
/* 188 */     int eventType = event.getEventType();
/* 189 */     return (eventType == 5 || eventType == 3);
/*     */   }
/*     */   
/*     */   private void handleEndElement(EndElement event) throws SAXException {
/* 193 */     if (!this.seenText && this.predictor.expectText()) {
/* 194 */       this.visitor.text("");
/*     */     }
/*     */ 
/*     */     
/* 198 */     QName qName = event.getName();
/* 199 */     this.tagName.uri = fixNull(qName.getNamespaceURI());
/* 200 */     this.tagName.local = qName.getLocalPart();
/* 201 */     this.visitor.endElement(this.tagName);
/*     */ 
/*     */     
/* 204 */     for (Iterator<Namespace> i = event.getNamespaces(); i.hasNext(); ) {
/* 205 */       String prefix = fixNull(((Namespace)i.next()).getPrefix());
/* 206 */       this.visitor.endPrefixMapping(prefix);
/*     */     } 
/*     */     
/* 209 */     this.seenText = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleStartElement(StartElement event) throws SAXException {
/* 214 */     for (Iterator<Namespace> i = event.getNamespaces(); i.hasNext(); ) {
/* 215 */       Namespace ns = i.next();
/* 216 */       this.visitor.startPrefixMapping(
/* 217 */           fixNull(ns.getPrefix()), 
/* 218 */           fixNull(ns.getNamespaceURI()));
/*     */     } 
/*     */ 
/*     */     
/* 222 */     QName qName = event.getName();
/* 223 */     this.tagName.uri = fixNull(qName.getNamespaceURI());
/* 224 */     String localName = qName.getLocalPart();
/* 225 */     this.tagName.uri = fixNull(qName.getNamespaceURI());
/* 226 */     this.tagName.local = localName;
/* 227 */     this.tagName.atts = getAttributes(event);
/* 228 */     this.visitor.startElement(this.tagName);
/*     */     
/* 230 */     this.seenText = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Attributes getAttributes(StartElement event) {
/* 241 */     this.attrs.clear();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     for (Iterator<Attribute> i = event.getAttributes(); i.hasNext(); ) {
/* 249 */       String qName; Attribute staxAttr = i.next();
/*     */       
/* 251 */       QName name = staxAttr.getName();
/* 252 */       String uri = fixNull(name.getNamespaceURI());
/* 253 */       String localName = name.getLocalPart();
/* 254 */       String prefix = name.getPrefix();
/*     */       
/* 256 */       if (prefix == null || prefix.length() == 0) {
/* 257 */         qName = localName;
/*     */       } else {
/* 259 */         qName = prefix + ":" + prefix;
/* 260 */       }  String type = staxAttr.getDTDType();
/* 261 */       String value = staxAttr.getValue();
/*     */       
/* 263 */       this.attrs.addAttribute(uri, localName, qName, type, value);
/*     */     } 
/*     */     
/* 266 */     return this.attrs;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\StAXEventConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */