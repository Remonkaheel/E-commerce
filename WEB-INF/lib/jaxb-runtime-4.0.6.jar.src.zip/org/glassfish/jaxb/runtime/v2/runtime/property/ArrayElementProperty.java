/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeRef;
/*     */ import org.glassfish.jaxb.core.v2.runtime.RuntimeUtil;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.ListIterator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Lister;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.NullSafeAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.DefaultValueLoaderDecorator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TextLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiNilLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ArrayElementProperty<BeanT, ListT, ItemT>
/*     */   extends ArrayERProperty<BeanT, ListT, ItemT>
/*     */ {
/*  43 */   private final Map<Class, TagAndType> typeMap = (Map)new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  47 */   private Map<TypeRef<Type, Class>, JaxBeanInfo> refs = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected RuntimeElementPropertyInfo prop;
/*     */ 
/*     */   
/*     */   private final Name nillableTagName;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArrayElementProperty(JAXBContextImpl grammar, RuntimeElementPropertyInfo prop) {
/*  59 */     super(grammar, (RuntimePropertyInfo)prop, prop.getXmlName(), prop.isCollectionNillable());
/*  60 */     this.prop = prop;
/*     */     
/*  62 */     List<? extends RuntimeTypeRef> types = prop.getTypes();
/*     */     
/*  64 */     Name n = null;
/*     */     
/*  66 */     for (RuntimeTypeRef typeRef : types) {
/*  67 */       Class type = (Class)typeRef.getTarget().getType();
/*  68 */       if (type.isPrimitive()) {
/*  69 */         type = (Class)RuntimeUtil.primitiveToBox.get(type);
/*     */       }
/*  71 */       JaxBeanInfo beanInfo = grammar.getOrCreate((RuntimeTypeInfo)typeRef.getTarget());
/*     */       
/*  73 */       TagAndType tt = new TagAndType(grammar.nameBuilder.createElementName(typeRef.getTagName()), beanInfo);
/*     */       
/*  75 */       this.typeMap.put(type, tt);
/*  76 */       this.refs.put(typeRef, beanInfo);
/*  77 */       if (typeRef.isNillable() && n == null) {
/*  78 */         n = tt.tagName;
/*     */       }
/*     */     } 
/*  81 */     this.nillableTagName = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void wrapUp() {
/*  86 */     super.wrapUp();
/*  87 */     this.refs = null;
/*  88 */     this.prop = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void serializeListBody(BeanT beanT, XMLSerializer w, ListT list) throws IOException, XMLStreamException, SAXException, AccessorException {
/*  93 */     ListIterator<ItemT> itr = this.lister.iterator(list, w);
/*     */     
/*  95 */     boolean isIdref = itr instanceof Lister.IDREFSIterator;
/*     */     
/*  97 */     while (itr.hasNext()) {
/*     */       try {
/*  99 */         ItemT item = (ItemT)itr.next();
/* 100 */         if (item != null) {
/* 101 */           Class<?> itemType = item.getClass();
/* 102 */           if (isIdref)
/*     */           {
/*     */             
/* 105 */             itemType = ((Lister.IDREFSIterator)itr).last().getClass();
/*     */           }
/*     */           
/* 108 */           TagAndType tt = this.typeMap.get(itemType);
/* 109 */           while (tt == null && itemType != null) {
/*     */             
/* 111 */             itemType = itemType.getSuperclass();
/* 112 */             tt = this.typeMap.get(itemType);
/*     */           } 
/*     */           
/* 115 */           if (tt == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 128 */             w.startElement(((TagAndType)this.typeMap.values().iterator().next()).tagName, null);
/* 129 */             w.childAsXsiType(item, this.fieldName, w.grammar.getBeanInfo(Object.class), false);
/*     */           } else {
/* 131 */             w.startElement(tt.tagName, null);
/* 132 */             serializeItem(tt.beanInfo, item, w);
/*     */           } 
/*     */           
/* 135 */           w.endElement(); continue;
/*     */         } 
/* 137 */         if (this.nillableTagName != null) {
/* 138 */           w.startElement(this.nillableTagName, null);
/* 139 */           w.writeXsiNilTrue();
/* 140 */           w.endElement();
/*     */         }
/*     */       
/* 143 */       } catch (JAXBException e) {
/* 144 */         w.reportError(this.fieldName, (Throwable)e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void serializeItem(JaxBeanInfo paramJaxBeanInfo, ItemT paramItemT, XMLSerializer paramXMLSerializer) throws SAXException, AccessorException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createBodyUnmarshaller(UnmarshallerChain chain, QNameMap<ChildLoader> loaders) {
/* 161 */     int offset = chain.allocateOffset();
/* 162 */     Receiver recv = new ArrayERProperty.ReceiverImpl(this, offset);
/*     */     
/* 164 */     for (RuntimeTypeRef typeRef : this.prop.getTypes()) {
/*     */       XsiNilLoader.Array array; DefaultValueLoaderDecorator defaultValueLoaderDecorator;
/* 166 */       Name tagName = chain.context.nameBuilder.createElementName(typeRef.getTagName());
/* 167 */       Loader item = createItemUnmarshaller(chain, typeRef);
/*     */       
/* 169 */       if (typeRef.isNillable() || chain.context.allNillable)
/* 170 */         array = new XsiNilLoader.Array(item); 
/* 171 */       if (typeRef.getDefaultValue() != null) {
/* 172 */         defaultValueLoaderDecorator = new DefaultValueLoaderDecorator((Loader)array, typeRef.getDefaultValue());
/*     */       }
/* 174 */       loaders.put(tagName, new ChildLoader((Loader)defaultValueLoaderDecorator, recv));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final PropertyKind getKind() {
/* 180 */     return PropertyKind.ELEMENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Loader createItemUnmarshaller(UnmarshallerChain chain, RuntimeTypeRef typeRef) {
/* 195 */     if (PropertyFactory.isLeaf(typeRef.getSource())) {
/* 196 */       Transducer xducer = typeRef.getTransducer();
/* 197 */       return (Loader)new TextLoader(xducer);
/*     */     } 
/* 199 */     return ((JaxBeanInfo)this.refs.get(typeRef)).getLoader(chain.context, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 205 */     if (this.wrapperTagName != null) {
/* 206 */       if (this.wrapperTagName.equals(nsUri, localName))
/* 207 */         return this.acc; 
/*     */     } else {
/* 209 */       for (TagAndType tt : this.typeMap.values()) {
/* 210 */         if (tt.tagName.equals(nsUri, localName))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 215 */           return (Accessor)new NullSafeAccessor(this.acc, this.lister); } 
/*     */       } 
/*     */     } 
/* 218 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ArrayElementProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */