/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlRootElement;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlRootElementQuick
/*    */   extends Quick
/*    */   implements XmlRootElement
/*    */ {
/*    */   private final XmlRootElement core;
/*    */   
/*    */   public XmlRootElementQuick(Locatable upstream, XmlRootElement core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlRootElementQuick(upstream, (XmlRootElement)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlRootElement> annotationType() {
/* 47 */     return XmlRootElement.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 52 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 57 */     return this.core.namespace();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlRootElementQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */