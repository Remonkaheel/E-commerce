/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlIDREF;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlIDREFQuick
/*    */   extends Quick
/*    */   implements XmlIDREF
/*    */ {
/*    */   private final XmlIDREF core;
/*    */   
/*    */   public XmlIDREFQuick(Locatable upstream, XmlIDREF core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlIDREFQuick(upstream, (XmlIDREF)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlIDREF> annotationType() {
/* 47 */     return XmlIDREF.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlIDREFQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */