package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;

public interface Wildcard extends TypedXmlWriter, Annotated {
  @XmlAttribute
  Wildcard processContents(String paramString);
  
  @XmlAttribute
  Wildcard namespace(String paramString);
  
  @XmlAttribute
  Wildcard namespace(String[] paramArrayOfString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\Wildcard.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */