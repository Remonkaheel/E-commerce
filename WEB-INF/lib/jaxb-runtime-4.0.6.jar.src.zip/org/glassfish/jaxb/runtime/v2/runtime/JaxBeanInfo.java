/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallerImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JaxBeanInfo<BeanT>
/*     */ {
/*     */   protected boolean isNilIncluded = false;
/*     */   protected short flag;
/*     */   private static final short FLAG_IS_ELEMENT = 1;
/*     */   private static final short FLAG_IS_IMMUTABLE = 2;
/*     */   private static final short FLAG_HAS_ELEMENT_ONLY_CONTENTMODEL = 4;
/*     */   private static final short FLAG_HAS_BEFORE_UNMARSHAL_METHOD = 8;
/*     */   private static final short FLAG_HAS_AFTER_UNMARSHAL_METHOD = 16;
/*     */   private static final short FLAG_HAS_BEFORE_MARSHAL_METHOD = 32;
/*     */   private static final short FLAG_HAS_AFTER_MARSHAL_METHOD = 64;
/*     */   private static final short FLAG_HAS_LIFECYCLE_EVENTS = 128;
/*     */   private LifecycleMethods lcm;
/*     */   public final Class<BeanT> jaxbType;
/*     */   private final Object typeName;
/*     */   
/*     */   protected JaxBeanInfo(JAXBContextImpl grammar, RuntimeTypeInfo rti, Class<BeanT> jaxbType, QName[] typeNames, boolean isElement, boolean isImmutable, boolean hasLifecycleEvents) {
/*  70 */     this(grammar, rti, jaxbType, typeNames, isElement, isImmutable, hasLifecycleEvents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JaxBeanInfo(JAXBContextImpl grammar, RuntimeTypeInfo rti, Class<BeanT> jaxbType, QName typeName, boolean isElement, boolean isImmutable, boolean hasLifecycleEvents) {
/*  77 */     this(grammar, rti, jaxbType, typeName, isElement, isImmutable, hasLifecycleEvents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JaxBeanInfo(JAXBContextImpl grammar, RuntimeTypeInfo rti, Class<BeanT> jaxbType, boolean isElement, boolean isImmutable, boolean hasLifecycleEvents) {
/*  84 */     this(grammar, rti, jaxbType, (Object)null, isElement, isImmutable, hasLifecycleEvents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JaxBeanInfo(JAXBContextImpl grammar, RuntimeTypeInfo rti, Class<BeanT> jaxbType, Object typeName, boolean isElement, boolean isImmutable, boolean hasLifecycleEvents) {
/* 112 */     this.lcm = null;
/*     */     grammar.beanInfos.put(rti, this);
/*     */     this.jaxbType = jaxbType;
/*     */     this.typeName = typeName;
/*     */     this.flag = (short)((isElement ? 1 : 0) | (isImmutable ? 2 : 0) | (hasLifecycleEvents ? 128 : 0));
/*     */   } public final boolean hasBeforeUnmarshalMethod() {
/* 118 */     return ((this.flag & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAfterUnmarshalMethod() {
/* 125 */     return ((this.flag & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasBeforeMarshalMethod() {
/* 132 */     return ((this.flag & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasAfterMarshalMethod() {
/* 139 */     return ((this.flag & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isElement() {
/* 162 */     return ((this.flag & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isImmutable() {
/* 173 */     return ((this.flag & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasElementOnlyContentModel() {
/* 183 */     return ((this.flag & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void hasElementOnlyContentModel(boolean value) {
/* 193 */     if (value) {
/* 194 */       this.flag = (short)(this.flag | 0x4);
/*     */     } else {
/* 196 */       this.flag = (short)(this.flag & 0xFFFFFFFB);
/*     */     } 
/*     */   }
/*     */   public boolean isNilIncluded() {
/* 200 */     return this.isNilIncluded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean lookForLifecycleMethods() {
/* 211 */     return ((this.flag & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getElementNamespaceURI(BeanT paramBeanT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getElementLocalName(BeanT paramBeanT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<QName> getTypeNames() {
/* 259 */     if (this.typeName == null) return Collections.emptyList(); 
/* 260 */     if (this.typeName instanceof QName) return Collections.singletonList((QName)this.typeName); 
/* 261 */     return Arrays.asList((QName[])this.typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getTypeName(@NotNull BeanT instance) {
/* 273 */     if (this.typeName == null) return null; 
/* 274 */     if (this.typeName instanceof QName) return (QName)this.typeName; 
/* 275 */     return ((QName[])this.typeName)[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BeanT createInstance(UnmarshallingContext paramUnmarshallingContext) throws IllegalAccessException, InvocationTargetException, InstantiationException, SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean reset(BeanT paramBeanT, UnmarshallingContext paramUnmarshallingContext) throws SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getId(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeBody(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeAttributes(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeRoot(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException, IOException, XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeURIs(BeanT paramBeanT, XMLSerializer paramXMLSerializer) throws SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Loader getLoader(JAXBContextImpl paramJAXBContextImpl, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Transducer<BeanT> getTransducer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void link(JAXBContextImpl grammar) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void wrapUp() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 398 */   private static final Class[] unmarshalEventParams = new Class[] { Unmarshaller.class, Object.class };
/* 399 */   private static Class[] marshalEventParams = new Class[] { Marshaller.class };
/*     */   
/*     */   private Method[] getDeclaredMethods(final Class<BeanT> c) {
/* 402 */     return AccessController.<Method[]>doPrivileged((PrivilegedAction)new PrivilegedAction<Method[]>()
/*     */         {
/*     */           public Method[] run() {
/* 405 */             return c.getDeclaredMethods();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setLifecycleFlags() {
/*     */     try {
/* 417 */       Class<BeanT> jt = this.jaxbType;
/*     */       
/* 419 */       if (this.lcm == null) {
/* 420 */         this.lcm = new LifecycleMethods();
/*     */       }
/*     */       
/* 423 */       while (jt != null) {
/* 424 */         for (Method m : getDeclaredMethods(jt)) {
/* 425 */           String name = m.getName();
/*     */           
/* 427 */           if (this.lcm.beforeUnmarshal == null && 
/* 428 */             name.equals("beforeUnmarshal") && 
/* 429 */             match(m, unmarshalEventParams)) {
/* 430 */             cacheLifecycleMethod(m, (short)8);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 435 */           if (this.lcm.afterUnmarshal == null && 
/* 436 */             name.equals("afterUnmarshal") && 
/* 437 */             match(m, unmarshalEventParams)) {
/* 438 */             cacheLifecycleMethod(m, (short)16);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 443 */           if (this.lcm.beforeMarshal == null && 
/* 444 */             name.equals("beforeMarshal") && 
/* 445 */             match(m, marshalEventParams)) {
/* 446 */             cacheLifecycleMethod(m, (short)32);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 451 */           if (this.lcm.afterMarshal == null && 
/* 452 */             name.equals("afterMarshal") && 
/* 453 */             match(m, marshalEventParams)) {
/* 454 */             cacheLifecycleMethod(m, (short)64);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 459 */         jt = (Class)jt.getSuperclass();
/*     */       } 
/* 461 */     } catch (SecurityException e) {
/*     */       
/* 463 */       logger.log(Level.WARNING, Messages.UNABLE_TO_DISCOVER_EVENTHANDLER.format(new Object[] { this.jaxbType
/* 464 */               .getName(), e }, ), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean match(Method m, Class[] params) {
/* 469 */     return Arrays.equals((Object[])m.getParameterTypes(), (Object[])params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cacheLifecycleMethod(Method m, short lifecycleFlag) {
/* 482 */     if (this.lcm == null) {
/* 483 */       this.lcm = new LifecycleMethods();
/*     */     }
/*     */ 
/*     */     
/* 487 */     m.setAccessible(true);
/*     */     
/* 489 */     this.flag = (short)(this.flag | lifecycleFlag);
/*     */     
/* 491 */     switch (lifecycleFlag) {
/*     */       case 8:
/* 493 */         this.lcm.beforeUnmarshal = m;
/*     */         break;
/*     */       case 16:
/* 496 */         this.lcm.afterUnmarshal = m;
/*     */         break;
/*     */       case 32:
/* 499 */         this.lcm.beforeMarshal = m;
/*     */         break;
/*     */       case 64:
/* 502 */         this.lcm.afterMarshal = m;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final LifecycleMethods getLifecycleMethods() {
/* 513 */     return this.lcm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void invokeBeforeUnmarshalMethod(UnmarshallerImpl unm, Object child, Object parent) throws SAXException {
/* 520 */     Method m = (getLifecycleMethods()).beforeUnmarshal;
/* 521 */     invokeUnmarshallCallback(m, child, unm, parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void invokeAfterUnmarshalMethod(UnmarshallerImpl unm, Object child, Object parent) throws SAXException {
/* 528 */     Method m = (getLifecycleMethods()).afterUnmarshal;
/* 529 */     invokeUnmarshallCallback(m, child, unm, parent);
/*     */   }
/*     */   
/*     */   private void invokeUnmarshallCallback(Method m, Object child, UnmarshallerImpl unm, Object parent) throws SAXException {
/*     */     try {
/* 534 */       m.invoke(child, new Object[] { unm, parent });
/* 535 */     } catch (IllegalAccessException|InvocationTargetException e) {
/* 536 */       UnmarshallingContext.getInstance().handleError(e, false);
/*     */     } 
/*     */   }
/*     */   
/* 540 */   private static final Logger logger = Utils.getClassLogger();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\JaxBeanInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */