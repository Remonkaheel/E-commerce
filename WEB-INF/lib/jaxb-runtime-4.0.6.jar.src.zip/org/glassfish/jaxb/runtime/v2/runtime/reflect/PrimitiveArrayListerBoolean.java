/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerBoolean<BeanT>
/*    */   extends Lister<BeanT, boolean[], Boolean, PrimitiveArrayListerBoolean.BooleanArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     Lister.primitiveArrayListers.put(boolean.class, new PrimitiveArrayListerBoolean());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Boolean> iterator(final boolean[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Boolean>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Boolean next() {
/* 47 */           return Boolean.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public BooleanArrayPack startPacking(BeanT current, Accessor<BeanT, boolean[]> acc) {
/* 54 */     return new BooleanArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(BooleanArrayPack objects, Boolean o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(BooleanArrayPack pack, BeanT bean, Accessor<BeanT, boolean[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, boolean[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new boolean[0]);
/*    */   }
/*    */   
/*    */   static final class BooleanArrayPack {
/* 73 */     boolean[] buf = new boolean[16];
/*    */     int size;
/*    */     
/*    */     void add(Boolean b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         boolean[] nb = new boolean[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.booleanValue(); 
/*    */     }
/*    */     
/*    */     boolean[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       boolean[] r = new boolean[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerBoolean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */