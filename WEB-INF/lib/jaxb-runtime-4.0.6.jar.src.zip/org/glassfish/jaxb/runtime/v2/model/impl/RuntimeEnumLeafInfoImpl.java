/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.annotation.FieldLocatable;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeEnumLeafInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RuntimeEnumLeafInfoImpl<T extends Enum<T>, B>
/*     */   extends EnumLeafInfoImpl<Type, Class, Field, Method>
/*     */   implements RuntimeEnumLeafInfo, Transducer<T>
/*     */ {
/*     */   private final Transducer<B> baseXducer;
/*     */   
/*     */   public Transducer<T> getTransducer() {
/*  42 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private final Map<B, T> parseMap = new HashMap<>();
/*     */   private final Map<T, B> printMap;
/*     */   
/*     */   RuntimeEnumLeafInfoImpl(RuntimeModelBuilder builder, Locatable upstream, Class<T> enumType) {
/*  55 */     super(builder, upstream, enumType, enumType);
/*  56 */     this.printMap = new EnumMap<>(enumType);
/*     */     
/*  58 */     this.baseXducer = ((RuntimeNonElement)this.baseType).getTransducer();
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeEnumConstantImpl createEnumConstant(String name, String literal, Field constant, EnumConstantImpl<Type, Class<?>, Field, Method> last) {
/*     */     Enum enum_;
/*     */     try {
/*     */       try {
/*  66 */         constant.setAccessible(true);
/*  67 */       } catch (SecurityException securityException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       enum_ = (Enum)constant.get(null);
/*  73 */     } catch (IllegalAccessException e) {
/*     */       
/*  75 */       throw new IllegalAccessError(e.getMessage());
/*     */     } 
/*     */     
/*  78 */     B b = null;
/*     */     try {
/*  80 */       b = (B)this.baseXducer.parse(literal);
/*  81 */     } catch (Exception e) {
/*  82 */       this.builder.reportError(new IllegalAnnotationException(Messages.INVALID_XML_ENUM_VALUE
/*  83 */             .format(new Object[] { literal, ((Type)this.baseType.getType()).toString() }, ), e, (Locatable)new FieldLocatable(this, constant, 
/*  84 */               nav())));
/*     */     } 
/*     */     
/*  87 */     this.parseMap.put(b, (T)enum_);
/*  88 */     this.printMap.put((T)enum_, b);
/*     */     
/*  90 */     return new RuntimeEnumConstantImpl(this, name, literal, last);
/*     */   }
/*     */ 
/*     */   
/*     */   public QName[] getTypeNames() {
/*  95 */     return new QName[] { getTypeName() };
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getClazz() {
/* 100 */     return this.clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useNamespace() {
/* 105 */     return this.baseXducer.useNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public void declareNamespace(T t, XMLSerializer w) throws AccessorException {
/* 110 */     this.baseXducer.declareNamespace(this.printMap.get(t), w);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence print(T t) throws AccessorException {
/* 115 */     return this.baseXducer.print(this.printMap.get(t));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T parse(CharSequence lexical) throws AccessorException, SAXException {
/*     */     String str;
/* 122 */     B b = (B)this.baseXducer.parse(lexical);
/*     */     
/* 124 */     if (this.tokenStringType) {
/* 125 */       str = ((String)b).trim();
/*     */     }
/*     */     
/* 128 */     return this.parseMap.get(str);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeText(XMLSerializer w, T t, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 133 */     this.baseXducer.writeText(w, this.printMap.get(t), fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeLeafElement(XMLSerializer w, Name tagName, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 138 */     this.baseXducer.writeLeafElement(w, tagName, this.printMap.get(o), fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public QName getTypeName(T instance) {
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeEnumLeafInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */