/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.annotation.DomHandler;
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.core.v2.model.core.WildcardMode;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElement;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeReferencePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.ElementBeanInfoImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.WildcardLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleReferenceNodeProperty<BeanT, ValueT>
/*     */   extends PropertyImpl<BeanT>
/*     */ {
/*     */   private final Accessor<BeanT, ValueT> acc;
/*  42 */   private final QNameMap<JaxBeanInfo> expectedElements = new QNameMap();
/*     */   
/*     */   private final DomHandler domHandler;
/*     */   private final WildcardMode wcMode;
/*     */   
/*     */   public SingleReferenceNodeProperty(JAXBContextImpl context, RuntimeReferencePropertyInfo prop) {
/*  48 */     super(context, (RuntimePropertyInfo)prop);
/*  49 */     this.acc = prop.getAccessor().optimize(context);
/*     */     
/*  51 */     for (RuntimeElement e : prop.getElements()) {
/*  52 */       this.expectedElements.put(e.getElementName(), context.getOrCreate((RuntimeTypeInfo)e));
/*     */     }
/*     */     
/*  55 */     if (prop.getWildcard() != null) {
/*  56 */       this.domHandler = (DomHandler)ClassFactory.create((Class)prop.getDOMHandler());
/*  57 */       this.wcMode = prop.getWildcard();
/*     */     } else {
/*  59 */       this.domHandler = null;
/*  60 */       this.wcMode = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(BeanT bean) throws AccessorException {
/*  66 */     this.acc.set(bean, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdValue(BeanT beanT) {
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/*  76 */     ValueT v = (ValueT)this.acc.get(o);
/*  77 */     if (v != null) {
/*     */       try {
/*  79 */         JaxBeanInfo bi = w.grammar.getBeanInfo(v, true);
/*  80 */         if (bi.jaxbType == Object.class && this.domHandler != null)
/*     */         
/*     */         { 
/*  83 */           w.writeDom(v, this.domHandler, o, this.fieldName); }
/*     */         else
/*  85 */         { bi.serializeRoot(v, w); } 
/*  86 */       } catch (JAXBException e) {
/*  87 */         w.reportError(this.fieldName, (Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) {
/*  95 */     for (QNameMap.Entry<JaxBeanInfo> n : (Iterable<QNameMap.Entry<JaxBeanInfo>>)this.expectedElements.entrySet()) {
/*  96 */       handlers.put(n.nsUri, n.localName, new ChildLoader(((JaxBeanInfo)n.getValue()).getLoader(chain.context, true), (Receiver)this.acc));
/*     */     }
/*  98 */     if (this.domHandler != null) {
/*  99 */       handlers.put(CATCH_ALL, new ChildLoader((Loader)new WildcardLoader(this.domHandler, this.wcMode), (Receiver)this.acc));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/* 105 */     return PropertyKind.REFERENCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 110 */     JaxBeanInfo bi = (JaxBeanInfo)this.expectedElements.get(nsUri, localName);
/* 111 */     if (bi != null) {
/* 112 */       if (bi instanceof ElementBeanInfoImpl) {
/* 113 */         final ElementBeanInfoImpl ebi = (ElementBeanInfoImpl)bi;
/*     */         
/* 115 */         return new Accessor<BeanT, Object>(ebi.expectedType)
/*     */           {
/*     */             public Object get(BeanT bean) throws AccessorException {
/* 118 */               ValueT r = (ValueT)SingleReferenceNodeProperty.this.acc.get(bean);
/* 119 */               if (r instanceof JAXBElement) {
/* 120 */                 return ((JAXBElement)r).getValue();
/*     */               }
/*     */               
/* 123 */               return r;
/*     */             }
/*     */ 
/*     */             
/*     */             public void set(BeanT bean, Object value) throws AccessorException {
/* 128 */               if (value != null) {
/*     */                 try {
/* 130 */                   value = ebi.createInstanceFromValue(value);
/* 131 */                 } catch (ReflectiveOperationException e) {
/* 132 */                   throw new AccessorException(e);
/*     */                 } 
/*     */               }
/* 135 */               SingleReferenceNodeProperty.this.acc.set(bean, value);
/*     */             }
/*     */           };
/*     */       } 
/*     */       
/* 140 */       return this.acc;
/*     */     } 
/*     */     
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\SingleReferenceNodeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */