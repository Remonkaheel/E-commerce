/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import com.sun.istack.NotNull;
/*    */ import java.io.IOException;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FilterTransducer<T>
/*    */   implements Transducer<T>
/*    */ {
/*    */   protected final Transducer<T> core;
/*    */   
/*    */   protected FilterTransducer(Transducer<T> core) {
/* 30 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean useNamespace() {
/* 35 */     return this.core.useNamespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public void declareNamespace(T o, XMLSerializer w) throws AccessorException {
/* 40 */     this.core.declareNamespace(o, w);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public CharSequence print(@NotNull T o) throws AccessorException {
/* 45 */     return this.core.print(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public T parse(CharSequence lexical) throws AccessorException, SAXException {
/* 50 */     return this.core.parse(lexical);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeText(XMLSerializer w, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 55 */     this.core.writeText(w, o, fieldName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeLeafElement(XMLSerializer w, Name tagName, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/* 60 */     this.core.writeLeafElement(w, tagName, o, fieldName);
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getTypeName(T instance) {
/* 65 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\FilterTransducer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */