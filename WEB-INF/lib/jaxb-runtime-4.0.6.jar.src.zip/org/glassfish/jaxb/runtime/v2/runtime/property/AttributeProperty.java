/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeAttributePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttributeProperty<BeanT>
/*     */   extends PropertyImpl<BeanT>
/*     */   implements Comparable<AttributeProperty>
/*     */ {
/*     */   public final Name attName;
/*     */   public final TransducedAccessor<BeanT> xacc;
/*     */   private final Accessor acc;
/*     */   
/*     */   public AttributeProperty(JAXBContextImpl context, RuntimeAttributePropertyInfo prop) {
/*  57 */     super(context, (RuntimePropertyInfo)prop);
/*  58 */     this.attName = context.nameBuilder.createAttributeName(prop.getXmlName());
/*  59 */     this.xacc = TransducedAccessor.get(context, (RuntimeNonElementRef)prop);
/*  60 */     this.acc = prop.getAccessor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAttributes(BeanT o, XMLSerializer w) throws SAXException, AccessorException, IOException, XMLStreamException {
/*  69 */     CharSequence value = this.xacc.print(o);
/*  70 */     if (value != null) {
/*  71 */       w.attribute(this.attName, value.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public void serializeURIs(BeanT o, XMLSerializer w) throws AccessorException, SAXException {
/*  76 */     this.xacc.declareNamespace(o, w);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSerializeURIAction() {
/*  81 */     return this.xacc.useNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildChildElementUnmarshallers(UnmarshallerChain chainElem, QNameMap<ChildLoader> handlers) {
/*  86 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/*  92 */     return PropertyKind.ATTRIBUTE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(BeanT o) throws AccessorException {
/*  97 */     this.acc.set(o, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdValue(BeanT bean) throws AccessorException, SAXException {
/* 102 */     return this.xacc.print(bean).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(AttributeProperty that) {
/* 107 */     return this.attName.compareTo(that.attName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\AttributeProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */