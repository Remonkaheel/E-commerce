/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.RegistryInfo;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeClassInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElementRef;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RuntimeElementInfoImpl
/*     */   extends ElementInfoImpl<Type, Class, Field, Method>
/*     */   implements RuntimeElementInfo
/*     */ {
/*     */   private final Class<? extends XmlAdapter> adapterType;
/*     */   
/*     */   public RuntimeElementInfoImpl(RuntimeModelBuilder modelBuilder, RegistryInfo registry, Method method) throws IllegalAnnotationException {
/*  37 */     super(modelBuilder, (RegistryInfoImpl<Type, Class, Field, Method>)registry, method);
/*     */     
/*  39 */     Adapter<Type, Class<?>> a = getProperty().getAdapter();
/*     */     
/*  41 */     if (a != null) {
/*  42 */       this.adapterType = (Class<? extends XmlAdapter>)a.adapterType;
/*     */     } else {
/*  44 */       this.adapterType = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ElementInfoImpl<Type, Class, Field, Method>.PropertyImpl createPropertyImpl() {
/*  49 */     return new RuntimePropertyImpl();
/*     */   }
/*     */   
/*     */   class RuntimePropertyImpl
/*     */     extends ElementInfoImpl<Type, Class, Field, Method>.PropertyImpl
/*     */     implements RuntimeElementPropertyInfo, RuntimeTypeRef {
/*     */     public Accessor getAccessor() {
/*  56 */       if (RuntimeElementInfoImpl.this.adapterType == null) {
/*  57 */         return Accessor.JAXB_ELEMENT_VALUE;
/*     */       }
/*  59 */       return Accessor.JAXB_ELEMENT_VALUE.adapt(
/*  60 */           (Class)(getAdapter()).defaultType, RuntimeElementInfoImpl.this.adapterType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getRawType() {
/*  65 */       return Collection.class;
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getIndividualType() {
/*  70 */       return (Type)RuntimeElementInfoImpl.this.getContentType().getType();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean elementOnlyContent() {
/*  76 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<? extends RuntimeTypeRef> getTypes() {
/*  81 */       return Collections.singletonList(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends RuntimeNonElement> ref() {
/*  87 */       return (List)super.ref();
/*     */     }
/*     */ 
/*     */     
/*     */     public RuntimeNonElement getTarget() {
/*  92 */       return (RuntimeNonElement)super.getTarget();
/*     */     }
/*     */ 
/*     */     
/*     */     public RuntimePropertyInfo getSource() {
/*  97 */       return (RuntimePropertyInfo)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public <V> Transducer<V> getTransducer() {
/* 102 */       return RuntimeModelBuilder.createTransducer((RuntimeNonElementRef)this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeElementPropertyInfo getProperty() {
/* 113 */     return (RuntimeElementPropertyInfo)super.getProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends JAXBElement> getType() {
/* 120 */     return (Class<? extends JAXBElement>)Utils.REFLECTION_NAVIGATOR.erasure(super.getType());
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeClassInfo getScope() {
/* 125 */     return (RuntimeClassInfo)super.getScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeNonElement getContentType() {
/* 130 */     return (RuntimeNonElement)super.getContentType();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeElementInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */