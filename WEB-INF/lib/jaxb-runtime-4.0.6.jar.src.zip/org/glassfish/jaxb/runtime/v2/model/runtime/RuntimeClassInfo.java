package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
import org.xml.sax.Locator;

public interface RuntimeClassInfo extends ClassInfo<Type, Class>, RuntimeNonElement {
  RuntimeClassInfo getBaseClass();
  
  List<? extends RuntimePropertyInfo> getProperties();
  
  RuntimePropertyInfo getProperty(String paramString);
  
  Method getFactoryMethod();
  
  <BeanT> Accessor<BeanT, Map<QName, String>> getAttributeWildcard();
  
  <BeanT> Accessor<BeanT, Locator> getLocatorField();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeClassInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */