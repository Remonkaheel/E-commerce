/*    */ package org.glassfish.jaxb.runtime.v2.schemagen;
/*    */ 
/*    */ import jakarta.xml.bind.SchemaOutputResolver;
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Logger;
/*    */ import javax.xml.transform.Result;
/*    */ import org.glassfish.jaxb.core.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FoolProofResolver
/*    */   extends SchemaOutputResolver
/*    */ {
/* 29 */   private static final Logger logger = Utils.getClassLogger();
/*    */   private final SchemaOutputResolver resolver;
/*    */   
/*    */   public FoolProofResolver(SchemaOutputResolver resolver) {
/* 33 */     assert resolver != null;
/* 34 */     this.resolver = resolver;
/*    */   }
/*    */ 
/*    */   
/*    */   public Result createOutput(String namespaceUri, String suggestedFileName) throws IOException {
/* 39 */     logger.entering(getClass().getName(), "createOutput", new Object[] { namespaceUri, suggestedFileName });
/* 40 */     Result r = this.resolver.createOutput(namespaceUri, suggestedFileName);
/* 41 */     if (r != null) {
/* 42 */       String sysId = r.getSystemId();
/* 43 */       logger.finer("system ID = " + sysId);
/* 44 */       if (sysId == null)
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 53 */         throw new AssertionError("system ID cannot be null"); } 
/*    */     } 
/* 55 */     logger.exiting(getClass().getName(), "createOutput", r);
/* 56 */     return r;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\FoolProofResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */