/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum Messages
/*    */ {
/*    */   private static final ResourceBundle rb;
/* 20 */   UNRESOLVED_IDREF,
/* 21 */   UNEXPECTED_ELEMENT,
/* 22 */   UNEXPECTED_TEXT,
/* 23 */   NOT_A_QNAME,
/* 24 */   UNRECOGNIZED_TYPE_NAME,
/* 25 */   UNRECOGNIZED_TYPE_NAME_MAYBE,
/* 26 */   UNABLE_TO_CREATE_MAP,
/* 27 */   UNINTERNED_STRINGS,
/* 28 */   ERRORS_LIMIT_EXCEEDED;
/*    */   
/*    */   static {
/* 31 */     rb = ResourceBundle.getBundle(Messages.class.getName());
/*    */   }
/*    */   public String toString() {
/* 34 */     return format(new Object[0]);
/*    */   }
/*    */   
/*    */   public String format(Object... args) {
/* 38 */     return MessageFormat.format(rb.getString(name()), args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Messages.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */