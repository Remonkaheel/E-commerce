/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StAXStreamConnector
/*     */   extends StAXConnector
/*     */ {
/*     */   private final XMLStreamReader staxStreamReader;
/*     */   
/*     */   public static StAXConnector create(XMLStreamReader reader, XmlVisitor visitor) {
/*  45 */     Class<?> readerClass = reader.getClass();
/*  46 */     if (FI_STAX_READER_CLASS != null && FI_STAX_READER_CLASS.isAssignableFrom(readerClass) && FI_CONNECTOR_CTOR != null) {
/*     */       try {
/*  48 */         return FI_CONNECTOR_CTOR.newInstance(new Object[] { reader, visitor });
/*  49 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  54 */     boolean isZephyr = readerClass.getName().equals("com.sun.xml.stream.XMLReaderImpl");
/*  55 */     if (!getBoolProp(reader, "org.codehaus.stax2.internNames") || 
/*  56 */       !getBoolProp(reader, "org.codehaus.stax2.internNsUris"))
/*     */     {
/*     */       
/*  59 */       if (!isZephyr)
/*     */       {
/*     */         
/*  62 */         if (!checkImplementaionNameOfSjsxp(reader))
/*     */         {
/*     */           
/*  65 */           visitor = new InterningXmlVisitor(visitor); }  } 
/*     */     }
/*  67 */     if (STAX_EX_READER_CLASS != null && STAX_EX_READER_CLASS.isAssignableFrom(readerClass)) {
/*     */       try {
/*  69 */         return STAX_EX_CONNECTOR_CTOR.newInstance(new Object[] { reader, visitor });
/*  70 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/*  74 */     return new StAXStreamConnector(reader, visitor);
/*     */   }
/*     */   
/*     */   private static boolean checkImplementaionNameOfSjsxp(XMLStreamReader reader) {
/*     */     try {
/*  79 */       Object name = reader.getProperty("http://java.sun.com/xml/stream/properties/implementation-name");
/*  80 */       return (name != null && name.equals("sjsxp"));
/*  81 */     } catch (Exception e) {
/*     */ 
/*     */       
/*  84 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean getBoolProp(XMLStreamReader r, String n) {
/*     */     try {
/*  90 */       Object o = r.getProperty(n);
/*  91 */       if (o instanceof Boolean) return ((Boolean)o).booleanValue(); 
/*  92 */       return false;
/*  93 */     } catch (Exception e) {
/*     */ 
/*     */       
/*  96 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   protected final StringBuilder buffer = new StringBuilder();
/*     */ 
/*     */   
/*     */   protected boolean textReported = false;
/*     */   
/*     */   private final Attributes attributes;
/*     */ 
/*     */   
/*     */   protected StAXStreamConnector(XMLStreamReader staxStreamReader, XmlVisitor visitor) {
/* 117 */     super(visitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.attributes = new Attributes()
/*     */       {
/*     */         public int getLength() {
/* 226 */           return StAXStreamConnector.this.staxStreamReader.getAttributeCount();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getURI(int index) {
/* 231 */           String uri = StAXStreamConnector.this.staxStreamReader.getAttributeNamespace(index);
/* 232 */           if (uri == null) return ""; 
/* 233 */           return uri;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getLocalName(int index) {
/* 238 */           return StAXStreamConnector.this.staxStreamReader.getAttributeLocalName(index);
/*     */         }
/*     */ 
/*     */         
/*     */         public String getQName(int index) {
/* 243 */           String prefix = StAXStreamConnector.this.staxStreamReader.getAttributePrefix(index);
/* 244 */           if (prefix == null || prefix.length() == 0) {
/* 245 */             return getLocalName(index);
/*     */           }
/* 247 */           return prefix + ":" + prefix;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getType(int index) {
/* 252 */           return StAXStreamConnector.this.staxStreamReader.getAttributeType(index);
/*     */         }
/*     */ 
/*     */         
/*     */         public String getValue(int index) {
/* 257 */           return StAXStreamConnector.this.staxStreamReader.getAttributeValue(index);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getIndex(String uri, String localName) {
/* 262 */           for (int i = getLength() - 1; i >= 0; i--) {
/* 263 */             if (localName.equals(getLocalName(i)) && uri.equals(getURI(i)))
/* 264 */               return i; 
/* 265 */           }  return -1;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getIndex(String qName) {
/* 272 */           for (int i = getLength() - 1; i >= 0; i--) {
/* 273 */             if (qName.equals(getQName(i)))
/* 274 */               return i; 
/*     */           } 
/* 276 */           return -1;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getType(String uri, String localName) {
/* 281 */           int index = getIndex(uri, localName);
/* 282 */           if (index < 0) return null; 
/* 283 */           return getType(index);
/*     */         }
/*     */ 
/*     */         
/*     */         public String getType(String qName) {
/* 288 */           int index = getIndex(qName);
/* 289 */           if (index < 0) return null; 
/* 290 */           return getType(index);
/*     */         }
/*     */ 
/*     */         
/*     */         public String getValue(String uri, String localName) {
/* 295 */           int index = getIndex(uri, localName);
/* 296 */           if (index < 0) return null; 
/* 297 */           return getValue(index);
/*     */         }
/*     */         
/*     */         public String getValue(String qName)
/*     */         {
/* 302 */           int index = getIndex(qName);
/* 303 */           if (index < 0) return null; 
/* 304 */           return getValue(index); }
/*     */       }; this.staxStreamReader = staxStreamReader;
/*     */   } public void bridge() throws XMLStreamException { try { int depth = 0; int event = this.staxStreamReader.getEventType(); if (event == 7) while (!this.staxStreamReader.isStartElement())
/*     */           event = this.staxStreamReader.next();   if (event != 1)
/*     */         throw new IllegalStateException("The current event is not START_ELEMENT\n but " + event);  handleStartDocument(this.staxStreamReader.getNamespaceContext()); while (true) { switch (event) { case 1: handleStartElement(); depth++; break;case 2: depth--; handleEndElement(); if (depth == 0)
/* 309 */               break;  break;case 4: case 6: case 12: handleCharacters(); break; }  event = this.staxStreamReader.next(); }  this.staxStreamReader.next(); handleEndDocument(); } catch (SAXException e) { throw new XMLStreamException(e); }  } protected Location getCurrentLocation() { return this.staxStreamReader.getLocation(); } protected void handleCharacters() throws XMLStreamException, SAXException { if (this.predictor.expectText())
/* 310 */       this.buffer.append(this.staxStreamReader
/* 311 */           .getTextCharacters(), this.staxStreamReader
/* 312 */           .getTextStart(), this.staxStreamReader
/* 313 */           .getTextLength());  }
/*     */   protected String getCurrentQName() { return getQName(this.staxStreamReader.getPrefix(), this.staxStreamReader.getLocalName()); }
/*     */   private void handleEndElement() throws SAXException { processText(false); this.tagName.uri = fixNull(this.staxStreamReader.getNamespaceURI()); this.tagName.local = this.staxStreamReader.getLocalName(); this.visitor.endElement(this.tagName); int nsCount = this.staxStreamReader.getNamespaceCount(); for (int i = nsCount - 1; i >= 0; i--) this.visitor.endPrefixMapping(fixNull(this.staxStreamReader.getNamespacePrefix(i)));  }
/*     */   private void handleStartElement() throws SAXException { processText(true); int nsCount = this.staxStreamReader.getNamespaceCount(); for (int i = 0; i < nsCount; i++)
/* 317 */       this.visitor.startPrefixMapping(fixNull(this.staxStreamReader.getNamespacePrefix(i)), fixNull(this.staxStreamReader.getNamespaceURI(i)));  this.tagName.uri = fixNull(this.staxStreamReader.getNamespaceURI()); this.tagName.local = this.staxStreamReader.getLocalName(); this.tagName.atts = this.attributes; this.visitor.startElement(this.tagName); } private void processText(boolean ignorable) throws SAXException { if (this.predictor.expectText() && (!ignorable || !WhiteSpaceProcessor.isWhiteSpace(this.buffer) || this.context.getCurrentState().isMixed())) {
/* 318 */       if (this.textReported) {
/* 319 */         this.textReported = false;
/*     */       } else {
/* 321 */         this.visitor.text(this.buffer);
/*     */       } 
/*     */     }
/* 324 */     this.buffer.setLength(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   private static final Class FI_STAX_READER_CLASS = initFIStAXReaderClass();
/* 333 */   private static final Constructor<? extends StAXConnector> FI_CONNECTOR_CTOR = initFastInfosetConnectorClass();
/*     */   
/*     */   private static Class initFIStAXReaderClass() {
/*     */     try {
/* 337 */       Class<?> fisr = Class.forName("org.jvnet.fastinfoset.stax.FastInfosetStreamReader");
/* 338 */       Class<?> sdp = Class.forName("com.sun.xml.fastinfoset.stax.StAXDocumentParser");
/*     */       
/* 340 */       if (fisr.isAssignableFrom(sdp)) {
/* 341 */         return sdp;
/*     */       }
/* 343 */       return null;
/* 344 */     } catch (Throwable e) {
/* 345 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Constructor<? extends StAXConnector> initFastInfosetConnectorClass() {
/*     */     try {
/* 351 */       if (FI_STAX_READER_CLASS == null) {
/* 352 */         return null;
/*     */       }
/* 354 */       Class<?> c = Class.forName("org.glassfish.jaxb.core.v2.runtime.unmarshaller.FastInfosetConnector");
/*     */       
/* 356 */       return (Constructor)c.getConstructor(new Class[] { FI_STAX_READER_CLASS, XmlVisitor.class });
/* 357 */     } catch (Throwable e) {
/* 358 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 365 */   private static final Class STAX_EX_READER_CLASS = initStAXExReader();
/* 366 */   private static final Constructor<? extends StAXConnector> STAX_EX_CONNECTOR_CTOR = initStAXExConnector();
/*     */   
/*     */   private static Class initStAXExReader() {
/*     */     try {
/* 370 */       return Class.forName("org.jvnet.staxex.XMLStreamReaderEx");
/* 371 */     } catch (Throwable e) {
/* 372 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Constructor<? extends StAXConnector> initStAXExConnector() {
/*     */     try {
/* 378 */       Class<?> c = Class.forName("org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.StAXExConnector");
/* 379 */       return (Constructor)c.getConstructor(new Class[] { STAX_EX_READER_CLASS, XmlVisitor.class });
/* 380 */     } catch (Throwable e) {
/* 381 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\StAXStreamConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */