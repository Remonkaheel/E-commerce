/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Init
/*    */ {
/*    */   static Quick[] getAll() {
/* 19 */     return new Quick[] { new XmlAccessorOrderQuick(null, null), new XmlAccessorTypeQuick(null, null), new XmlAnyAttributeQuick(null, null), new XmlAnyElementQuick(null, null), new XmlAttachmentRefQuick(null, null), new XmlAttributeQuick(null, null), new XmlElementQuick(null, null), new XmlElementDeclQuick(null, null), new XmlElementRefQuick(null, null), new XmlElementRefsQuick(null, null), new XmlElementWrapperQuick(null, null), new XmlElementsQuick(null, null), new XmlEnumQuick(null, null), new XmlEnumValueQuick(null, null), new XmlIDQuick(null, null), new XmlIDREFQuick(null, null), new XmlInlineBinaryDataQuick(null, null), new XmlListQuick(null, null), new XmlMimeTypeQuick(null, null), new XmlMixedQuick(null, null), new XmlNsQuick(null, null), new XmlRegistryQuick(null, null), new XmlRootElementQuick(null, null), new XmlSchemaQuick(null, null), new XmlSchemaTypeQuick(null, null), new XmlSchemaTypesQuick(null, null), new XmlSeeAlsoQuick(null, null), new XmlTransientQuick(null, null), new XmlTypeQuick(null, null), new XmlValueQuick(null, null), new XmlJavaTypeAdapterQuick(null, null), new XmlJavaTypeAdaptersQuick(null, null) };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\Init.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */