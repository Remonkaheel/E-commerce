/*    */ package org.glassfish.jaxb.runtime.v2;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MUtils
/*    */ {
/* 20 */   private static final Logger LOGGER = Logger.getLogger("org.glassfish.jaxb.runtime");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void open(Class[] classes) throws JAXBException {
/* 31 */     Module coreModule = ClassFactory.class.getModule();
/* 32 */     Module rtModule = JAXBContextFactory.class.getModule();
/*    */     
/* 34 */     if (rtModule == coreModule || !rtModule.isNamed()) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 39 */     for (Class<?> cls : classes) {
/*    */       
/* 41 */       Class<?> jaxbClass = cls.isArray() ? cls.getComponentType() : cls;
/*    */       
/* 43 */       Module classModule = jaxbClass.getModule();
/*    */       
/* 45 */       if (classModule.isNamed() && !"java.base".equals(classModule.getName())) {
/*    */ 
/*    */         
/* 48 */         String packageName = jaxbClass.getPackageName();
/*    */         
/* 50 */         if (classModule.isOpen(packageName, rtModule)) {
/* 51 */           classModule.addOpens(packageName, coreModule);
/* 52 */           if (LOGGER.isLoggable(Level.FINE)) {
/* 53 */             LOGGER.log(Level.FINE, "Openning package {0} in {1} to {2}.", (Object[])new String[] { packageName, classModule
/* 54 */                   .getName(), coreModule.getName() });
/*    */           }
/*    */         } else {
/*    */           
/* 58 */           throw new JAXBException(MessageFormat.format("Package {0} with class {1} defined in a module {2} must be open to at least {3} module.", new Object[] { packageName, jaxbClass
/* 59 */                   .getName(), classModule.getName(), rtModule.getName() }));
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\MUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */