/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import com.sun.istack.Nullable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XsiTypeLoader
/*     */   extends Loader
/*     */ {
/*     */   private final JaxBeanInfo defaultBeanInfo;
/*     */   
/*     */   public XsiTypeLoader(JaxBeanInfo defaultBeanInfo) {
/*  38 */     super(true);
/*  39 */     this.defaultBeanInfo = defaultBeanInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/*  44 */     JaxBeanInfo beanInfo = parseXsiType(state, ea, this.defaultBeanInfo);
/*  45 */     if (beanInfo == null) {
/*  46 */       beanInfo = this.defaultBeanInfo;
/*     */     }
/*  48 */     Loader loader = beanInfo.getLoader(null, false);
/*  49 */     state.setLoader(loader);
/*  50 */     loader.startElement(state, ea);
/*     */   }
/*     */ 
/*     */   
/*     */   static JaxBeanInfo parseXsiType(UnmarshallingContext.State state, TagName ea, @Nullable JaxBeanInfo defaultBeanInfo) throws SAXException {
/*  55 */     UnmarshallingContext context = state.getContext();
/*  56 */     JaxBeanInfo beanInfo = null;
/*     */ 
/*     */     
/*  59 */     Attributes atts = ea.atts;
/*  60 */     int idx = atts.getIndex("http://www.w3.org/2001/XMLSchema-instance", "type");
/*     */     
/*  62 */     if (idx >= 0) {
/*     */ 
/*     */       
/*  65 */       String value = atts.getValue(idx);
/*     */       
/*  67 */       QName type = DatatypeConverterImpl._parseQName(value, context);
/*  68 */       if (type == null) {
/*  69 */         reportError(Messages.NOT_A_QNAME.format(new Object[] { value }, ), true);
/*     */       } else {
/*  71 */         if (defaultBeanInfo != null && defaultBeanInfo.getTypeNames().contains(type))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  78 */           return defaultBeanInfo;
/*     */         }
/*  80 */         beanInfo = context.getJAXBContext().getGlobalType(type);
/*  81 */         if (beanInfo == null && 
/*  82 */           context.parent.hasEventHandler() && context
/*  83 */           .shouldErrorBeReported()) {
/*  84 */           String nearest = context.getJAXBContext().getNearestTypeName(type);
/*  85 */           if (nearest != null) {
/*  86 */             reportError(Messages.UNRECOGNIZED_TYPE_NAME_MAYBE.format(new Object[] { type, nearest }, ), true);
/*     */           } else {
/*  88 */             reportError(Messages.UNRECOGNIZED_TYPE_NAME.format(new Object[] { type }, ), true);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return beanInfo;
/*     */   }
/*     */   
/* 104 */   static final QName XsiTypeQNAME = new QName("http://www.w3.org/2001/XMLSchema-instance", "type");
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedAttributes() {
/* 108 */     Collection<QName> expAttrs = new HashSet<>(super.getExpectedAttributes());
/* 109 */     expAttrs.add(XsiTypeQNAME);
/* 110 */     return Collections.unmodifiableCollection(expAttrs);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\XsiTypeLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */