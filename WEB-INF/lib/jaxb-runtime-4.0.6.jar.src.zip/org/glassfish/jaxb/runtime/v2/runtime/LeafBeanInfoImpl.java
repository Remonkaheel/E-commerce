/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeLeafInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TextLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiTypeLoader;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LeafBeanInfoImpl<BeanT>
/*     */   extends JaxBeanInfo<BeanT>
/*     */ {
/*     */   private final Loader loader;
/*     */   private final Loader loaderWithSubst;
/*     */   private final Transducer<BeanT> xducer;
/*     */   private final Name tagName;
/*     */   
/*     */   public LeafBeanInfoImpl(JAXBContextImpl grammar, RuntimeLeafInfo li) {
/*  53 */     super(grammar, (RuntimeTypeInfo)li, li.getClazz(), li.getTypeNames(), li.isElement(), true, false);
/*     */     
/*  55 */     this.xducer = li.getTransducer();
/*  56 */     this.loader = (Loader)new TextLoader(this.xducer);
/*  57 */     this.loaderWithSubst = (Loader)new XsiTypeLoader(this);
/*     */     
/*  59 */     if (isElement()) {
/*  60 */       this.tagName = grammar.nameBuilder.createElementName(li.getElementName());
/*     */     } else {
/*  62 */       this.tagName = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public QName getTypeName(BeanT instance) {
/*  67 */     QName tn = this.xducer.getTypeName(instance);
/*  68 */     if (tn != null) return tn;
/*     */     
/*  70 */     return super.getTypeName(instance);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementNamespaceURI(BeanT t) {
/*  75 */     return this.tagName.nsUri;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementLocalName(BeanT t) {
/*  80 */     return this.tagName.localName;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanT createInstance(UnmarshallingContext context) {
/*  85 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reset(BeanT bean, UnmarshallingContext context) {
/*  90 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId(BeanT bean, XMLSerializer target) {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT bean, XMLSerializer w) throws SAXException, IOException, XMLStreamException {
/*     */     try {
/* 104 */       this.xducer.writeText(w, bean, null);
/* 105 */     } catch (AccessorException e) {
/* 106 */       w.reportError(null, (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAttributes(BeanT bean, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeRoot(BeanT bean, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 117 */     if (this.tagName == null) {
/* 118 */       target.reportError((ValidationEvent)new ValidationEventImpl(1, Messages.UNABLE_TO_MARSHAL_NON_ELEMENT
/*     */ 
/*     */             
/* 121 */             .format(new Object[] { bean.getClass().getName() }, ), null, null));
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 126 */       target.startElement(this.tagName, bean);
/* 127 */       target.childAsSoleContent(bean, null);
/* 128 */       target.endElement();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeURIs(BeanT bean, XMLSerializer target) throws SAXException {
/* 136 */     if (this.xducer.useNamespace()) {
/*     */       try {
/* 138 */         this.xducer.declareNamespace(bean, target);
/* 139 */       } catch (AccessorException e) {
/* 140 */         target.reportError(null, (Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 147 */     if (typeSubstitutionCapable) {
/* 148 */       return this.loaderWithSubst;
/*     */     }
/* 150 */     return this.loader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transducer<BeanT> getTransducer() {
/* 155 */     return this.xducer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\LeafBeanInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */