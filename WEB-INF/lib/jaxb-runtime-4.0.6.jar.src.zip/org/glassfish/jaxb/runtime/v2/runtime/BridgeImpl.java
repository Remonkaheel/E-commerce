/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.glassfish.jaxb.core.marshaller.SAX2DOMEx;
/*     */ import org.glassfish.jaxb.runtime.api.TypeReference;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.SAXOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.XMLStreamWriterOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.XmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallerImpl;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BridgeImpl<T>
/*     */   extends InternalBridge<T>
/*     */ {
/*     */   private final Name tagName;
/*     */   private final JaxBeanInfo<T> bi;
/*     */   private final TypeReference typeRef;
/*     */   
/*     */   public BridgeImpl(JAXBContextImpl context, Name tagName, JaxBeanInfo<T> bi, TypeReference typeRef) {
/*  54 */     super(context);
/*  55 */     this.tagName = tagName;
/*  56 */     this.bi = bi;
/*  57 */     this.typeRef = typeRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller _m, T t, XMLStreamWriter output) throws JAXBException {
/*  62 */     MarshallerImpl m = (MarshallerImpl)_m;
/*  63 */     m.write(this.tagName, this.bi, t, XMLStreamWriterOutput.create(output, this.context, m.getEscapeHandler()), new StAXPostInitAction(output, m.serializer));
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller _m, T t, OutputStream output, NamespaceContext nsContext) throws JAXBException {
/*  68 */     MarshallerImpl m = (MarshallerImpl)_m;
/*     */     
/*  70 */     Runnable pia = null;
/*  71 */     if (nsContext != null) {
/*  72 */       pia = new StAXPostInitAction(nsContext, m.serializer);
/*     */     }
/*  74 */     m.write(this.tagName, this.bi, t, m.createWriter(output), pia);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller _m, T t, Node output) throws JAXBException {
/*  79 */     MarshallerImpl m = (MarshallerImpl)_m;
/*  80 */     m.write(this.tagName, this.bi, t, (XmlOutput)new SAXOutput((ContentHandler)new SAX2DOMEx(output)), new DomPostInitAction(output, m.serializer));
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller _m, T t, ContentHandler contentHandler) throws JAXBException {
/*  85 */     MarshallerImpl m = (MarshallerImpl)_m;
/*  86 */     m.write(this.tagName, this.bi, t, (XmlOutput)new SAXOutput(contentHandler), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Marshaller _m, T t, Result result) throws JAXBException {
/*  91 */     MarshallerImpl m = (MarshallerImpl)_m;
/*  92 */     m.write(this.tagName, this.bi, t, m.createXmlOutput(result), m.createPostInitAction(result));
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public T unmarshal(Unmarshaller _u, XMLStreamReader in) throws JAXBException {
/*  98 */     UnmarshallerImpl u = (UnmarshallerImpl)_u;
/*  99 */     return (T)((JAXBElement)u.unmarshal0(in, this.bi)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public T unmarshal(Unmarshaller _u, Source in) throws JAXBException {
/* 105 */     UnmarshallerImpl u = (UnmarshallerImpl)_u;
/* 106 */     return (T)((JAXBElement)u.unmarshal0(in, this.bi)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public T unmarshal(Unmarshaller _u, InputStream in) throws JAXBException {
/* 112 */     UnmarshallerImpl u = (UnmarshallerImpl)_u;
/* 113 */     return (T)((JAXBElement)u.unmarshal0(in, this.bi)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public T unmarshal(Unmarshaller _u, Node n) throws JAXBException {
/* 119 */     UnmarshallerImpl u = (UnmarshallerImpl)_u;
/* 120 */     return (T)((JAXBElement)u.unmarshal0(n, this.bi)).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference getTypeReference() {
/* 125 */     return this.typeRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(T value, XMLSerializer out) throws IOException, SAXException, XMLStreamException {
/* 130 */     out.startElement(this.tagName, null);
/* 131 */     if (value == null) {
/* 132 */       out.writeXsiNilTrue();
/*     */     } else {
/* 134 */       out.childAsXsiType(value, null, this.bi, false);
/*     */     } 
/* 136 */     out.endElement();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\BridgeImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */