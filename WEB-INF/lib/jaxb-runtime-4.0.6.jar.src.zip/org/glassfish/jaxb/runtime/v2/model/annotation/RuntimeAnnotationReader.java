package org.glassfish.jaxb.runtime.v2.model.annotation;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;

public interface RuntimeAnnotationReader extends AnnotationReader<Type, Class, Field, Method> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\RuntimeAnnotationReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */