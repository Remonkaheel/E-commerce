/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.UnmarshalException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.UnmarshallerHandler;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import jakarta.xml.bind.attachment.AttachmentUnmarshaller;
/*     */ import jakarta.xml.bind.helpers.AbstractUnmarshallerImpl;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.glassfish.jaxb.core.unmarshaller.DOMScanner;
/*     */ import org.glassfish.jaxb.core.unmarshaller.InfosetScanner;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.glassfish.jaxb.core.v2.util.XmlFactory;
/*     */ import org.glassfish.jaxb.runtime.IDResolver;
/*     */ import org.glassfish.jaxb.runtime.api.ClassResolver;
/*     */ import org.glassfish.jaxb.runtime.unmarshaller.Messages;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.AssociationMap;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnmarshallerImpl
/*     */   extends AbstractUnmarshallerImpl
/*     */   implements ValidationEventHandler, Closeable
/*     */ {
/*     */   protected final JAXBContextImpl context;
/*     */   private Schema schema;
/*     */   public final UnmarshallingContext coordinator;
/*     */   private Unmarshaller.Listener externalListener;
/*     */   private AttachmentUnmarshaller attachmentUnmarshaller;
/*  80 */   private IDResolver idResolver = new DefaultIDResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLReader reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmarshallerHandler getUnmarshallerHandler() {
/*  95 */     return getUnmarshallerHandler(true, null);
/*     */   }
/*     */   public UnmarshallerImpl(JAXBContextImpl context, AssociationMap assoc) {
/*  98 */     this.reader = null;
/*     */     this.context = context;
/*     */     this.coordinator = new UnmarshallingContext(this, assoc);
/*     */     try {
/*     */       setEventHandler(this);
/*     */     } catch (JAXBException e) {
/*     */       throw new AssertionError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLReader getXMLReader() throws JAXBException {
/* 113 */     if (this.reader == null) {
/*     */       try {
/* 115 */         SAXParserFactory parserFactory = XmlFactory.createParserFactory(this.context.disableSecurityProcessing);
/*     */ 
/*     */ 
/*     */         
/* 119 */         parserFactory.setValidating(false);
/* 120 */         this.reader = parserFactory.newSAXParser().getXMLReader();
/* 121 */       } catch (ParserConfigurationException|SAXException e) {
/* 122 */         throw new JAXBException(e);
/*     */       } 
/*     */     }
/* 125 */     return this.reader;
/*     */   }
/*     */   
/*     */   private SAXConnector getUnmarshallerHandler(boolean intern, JaxBeanInfo expectedType) {
/* 129 */     XmlVisitor h = createUnmarshallerHandler((InfosetScanner)null, false, expectedType);
/* 130 */     if (intern) {
/* 131 */       h = new InterningXmlVisitor(h);
/*     */     }
/* 133 */     return new SAXConnector(h, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlVisitor createUnmarshallerHandler(InfosetScanner scanner, boolean inplace, JaxBeanInfo expectedType) {
/* 151 */     this.coordinator.reset(scanner, inplace, expectedType, this.idResolver);
/* 152 */     XmlVisitor unmarshaller = this.coordinator;
/*     */ 
/*     */     
/* 155 */     if (this.schema != null) {
/* 156 */       unmarshaller = new ValidatingUnmarshaller(this.schema, unmarshaller);
/*     */     }
/*     */     
/* 159 */     if (this.attachmentUnmarshaller != null && this.attachmentUnmarshaller.isXOPPackage()) {
/* 160 */       unmarshaller = new MTOMDecorator(this, unmarshaller, this.attachmentUnmarshaller);
/*     */     }
/*     */     
/* 163 */     return unmarshaller;
/*     */   }
/*     */   
/* 166 */   private static final DefaultHandler dummyHandler = new DefaultHandler();
/*     */   public static final String FACTORY = "org.glassfish.jaxb.core.ObjectFactory";
/*     */   
/*     */   public static boolean needsInterning(XMLReader reader) {
/*     */     try {
/* 171 */       reader.setFeature("http://xml.org/sax/features/string-interning", true);
/* 172 */     } catch (SAXException sAXException) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 177 */       if (reader.getFeature("http://xml.org/sax/features/string-interning")) {
/* 178 */         return false;
/*     */       }
/* 180 */     } catch (SAXException sAXException) {}
/*     */ 
/*     */ 
/*     */     
/* 184 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object unmarshal(XMLReader reader, InputSource source) throws JAXBException {
/* 189 */     return unmarshal0(reader, source, (JaxBeanInfo)null);
/*     */   }
/*     */   
/*     */   protected <T> JAXBElement<T> unmarshal(XMLReader reader, InputSource source, Class<T> expectedType) throws JAXBException {
/* 193 */     if (expectedType == null) {
/* 194 */       throw new IllegalArgumentException();
/*     */     }
/* 196 */     return (JAXBElement<T>)unmarshal0(reader, source, getBeanInfo(expectedType));
/*     */   }
/*     */ 
/*     */   
/*     */   private Object unmarshal0(XMLReader reader, InputSource source, JaxBeanInfo expectedType) throws JAXBException {
/* 201 */     SAXConnector connector = getUnmarshallerHandler(needsInterning(reader), expectedType);
/*     */     
/* 203 */     reader.setContentHandler((ContentHandler)connector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     reader.setErrorHandler(this.coordinator);
/*     */     
/*     */     try {
/* 218 */       reader.parse(source);
/* 219 */     } catch (IOException e) {
/* 220 */       this.coordinator.clearStates();
/* 221 */       throw new UnmarshalException(e);
/* 222 */     } catch (SAXException e) {
/* 223 */       this.coordinator.clearStates();
/* 224 */       throw createUnmarshalException(e);
/*     */     } 
/*     */     
/* 227 */     Object result = connector.getResult();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     reader.setContentHandler(dummyHandler);
/* 233 */     reader.setErrorHandler(dummyHandler);
/*     */     
/* 235 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Source source, Class<T> expectedType) throws JAXBException {
/* 240 */     if (source instanceof SAXSource) {
/* 241 */       SAXSource ss = (SAXSource)source;
/*     */       
/* 243 */       XMLReader locReader = ss.getXMLReader();
/* 244 */       if (locReader == null) {
/* 245 */         locReader = getXMLReader();
/*     */       }
/*     */       
/* 248 */       return unmarshal(locReader, ss.getInputSource(), expectedType);
/*     */     } 
/* 250 */     if (source instanceof StreamSource) {
/* 251 */       return unmarshal(getXMLReader(), streamSourceToInputSource((StreamSource)source), expectedType);
/*     */     }
/* 253 */     if (source instanceof DOMSource) {
/* 254 */       return unmarshal(((DOMSource)source).getNode(), expectedType);
/*     */     }
/*     */ 
/*     */     
/* 258 */     throw new IllegalArgumentException();
/*     */   }
/*     */   
/*     */   public Object unmarshal0(Source source, JaxBeanInfo expectedType) throws JAXBException {
/* 262 */     if (source instanceof SAXSource) {
/* 263 */       SAXSource ss = (SAXSource)source;
/*     */       
/* 265 */       XMLReader locReader = ss.getXMLReader();
/* 266 */       if (locReader == null) {
/* 267 */         locReader = getXMLReader();
/*     */       }
/*     */       
/* 270 */       return unmarshal0(locReader, ss.getInputSource(), expectedType);
/*     */     } 
/* 272 */     if (source instanceof StreamSource) {
/* 273 */       return unmarshal0(getXMLReader(), streamSourceToInputSource((StreamSource)source), expectedType);
/*     */     }
/* 275 */     if (source instanceof DOMSource) {
/* 276 */       return unmarshal0(((DOMSource)source).getNode(), expectedType);
/*     */     }
/*     */ 
/*     */     
/* 280 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventHandler getEventHandler() {
/*     */     try {
/* 287 */       return super.getEventHandler();
/* 288 */     } catch (JAXBException e) {
/*     */       
/* 290 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasEventHandler() {
/* 300 */     return (getEventHandler() != this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Node node, Class<T> expectedType) throws JAXBException {
/* 305 */     if (expectedType == null) {
/* 306 */       throw new IllegalArgumentException();
/*     */     }
/* 308 */     return (JAXBElement<T>)unmarshal0(node, getBeanInfo(expectedType));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(Node node) throws JAXBException {
/* 313 */     return unmarshal0(node, (JaxBeanInfo)null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object unmarshal(SAXSource source) throws JAXBException {
/* 319 */     return unmarshal(source);
/*     */   }
/*     */   
/*     */   public Object unmarshal0(Node node, JaxBeanInfo expectedType) throws JAXBException {
/*     */     try {
/* 324 */       DOMScanner scanner = new DOMScanner();
/*     */       
/* 326 */       InterningXmlVisitor handler = new InterningXmlVisitor(createUnmarshallerHandler((InfosetScanner)null, false, expectedType));
/* 327 */       scanner.setContentHandler((ContentHandler)new SAXConnector(handler, (LocatorEx)scanner));
/*     */       
/* 329 */       if (node.getNodeType() == 1) {
/* 330 */         scanner.scan((Element)node);
/* 331 */       } else if (node.getNodeType() == 9) {
/* 332 */         scanner.scan((Document)node);
/*     */       } else {
/* 334 */         throw new IllegalArgumentException("Unexpected node type: " + node);
/*     */       } 
/*     */       
/* 337 */       Object retVal = handler.getContext().getResult();
/* 338 */       handler.getContext().clearResult();
/* 339 */       return retVal;
/* 340 */     } catch (SAXException e) {
/* 341 */       throw createUnmarshalException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLStreamReader reader) throws JAXBException {
/* 347 */     return unmarshal0(reader, (JaxBeanInfo)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLStreamReader reader, Class<T> expectedType) throws JAXBException {
/* 352 */     if (expectedType == null) {
/* 353 */       throw new IllegalArgumentException();
/*     */     }
/* 355 */     return (JAXBElement<T>)unmarshal0(reader, getBeanInfo(expectedType));
/*     */   }
/*     */   
/*     */   public Object unmarshal0(XMLStreamReader reader, JaxBeanInfo expectedType) throws JAXBException {
/* 359 */     if (reader == null) {
/* 360 */       throw new IllegalArgumentException(
/* 361 */           Messages.format("Unmarshaller.NullReader"));
/*     */     }
/*     */     
/* 364 */     int eventType = reader.getEventType();
/* 365 */     if (eventType != 1 && eventType != 7)
/*     */     {
/*     */       
/* 368 */       throw new IllegalStateException(
/* 369 */           Messages.format("Unmarshaller.IllegalReaderState", Integer.valueOf(eventType)));
/*     */     }
/*     */     
/* 372 */     XmlVisitor h = createUnmarshallerHandler((InfosetScanner)null, false, expectedType);
/* 373 */     StAXConnector connector = StAXStreamConnector.create(reader, h);
/*     */     
/*     */     try {
/* 376 */       connector.bridge();
/* 377 */     } catch (XMLStreamException e) {
/* 378 */       throw handleStreamException(e);
/*     */     } 
/*     */     
/* 381 */     Object retVal = h.getContext().getResult();
/* 382 */     h.getContext().clearResult();
/* 383 */     return retVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLEventReader reader, Class<T> expectedType) throws JAXBException {
/* 388 */     if (expectedType == null) {
/* 389 */       throw new IllegalArgumentException();
/*     */     }
/* 391 */     return (JAXBElement<T>)unmarshal0(reader, getBeanInfo(expectedType));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLEventReader reader) throws JAXBException {
/* 396 */     return unmarshal0(reader, (JaxBeanInfo)null);
/*     */   }
/*     */   
/*     */   private Object unmarshal0(XMLEventReader reader, JaxBeanInfo expectedType) throws JAXBException {
/* 400 */     if (reader == null) {
/* 401 */       throw new IllegalArgumentException(
/* 402 */           Messages.format("Unmarshaller.NullReader"));
/*     */     }
/*     */     
/*     */     try {
/* 406 */       XMLEvent event = reader.peek();
/*     */       
/* 408 */       if (!event.isStartElement() && !event.isStartDocument())
/*     */       {
/* 410 */         throw new IllegalStateException(
/* 411 */             Messages.format("Unmarshaller.IllegalReaderState", 
/* 412 */               Integer.valueOf(event.getEventType())));
/*     */       }
/*     */ 
/*     */       
/* 416 */       boolean isZephyr = reader.getClass().getName().equals("com.sun.xml.stream.XMLReaderImpl");
/* 417 */       XmlVisitor h = createUnmarshallerHandler((InfosetScanner)null, false, expectedType);
/* 418 */       if (!isZephyr) {
/* 419 */         h = new InterningXmlVisitor(h);
/*     */       }
/* 421 */       (new StAXEventConnector(reader, h)).bridge();
/* 422 */       return h.getContext().getResult();
/* 423 */     } catch (XMLStreamException e) {
/* 424 */       throw handleStreamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object unmarshal0(InputStream input, JaxBeanInfo expectedType) throws JAXBException {
/* 429 */     return unmarshal0(getXMLReader(), new InputSource(input), expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JAXBException handleStreamException(XMLStreamException e) {
/* 439 */     Throwable ne = e.getNestedException();
/* 440 */     if (ne instanceof JAXBException) {
/* 441 */       return (JAXBException)ne;
/*     */     }
/* 443 */     if (ne instanceof SAXException) {
/* 444 */       return (JAXBException)new UnmarshalException(ne);
/*     */     }
/* 446 */     return (JAXBException)new UnmarshalException(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 451 */     if (name.equals(IDResolver.class.getName())) {
/* 452 */       return this.idResolver;
/*     */     }
/* 454 */     return super.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 459 */     if (name.equals("org.glassfish.jaxb.core.ObjectFactory")) {
/* 460 */       this.coordinator.setFactories(value);
/*     */       return;
/*     */     } 
/* 463 */     if (name.equals(IDResolver.class.getName())) {
/* 464 */       this.idResolver = (IDResolver)value;
/*     */       return;
/*     */     } 
/* 467 */     if (name.equals(ClassResolver.class.getName())) {
/* 468 */       this.coordinator.classResolver = (ClassResolver)value;
/*     */       return;
/*     */     } 
/* 471 */     if (name.equals(ClassLoader.class.getName())) {
/* 472 */       this.coordinator.classLoader = (ClassLoader)value;
/*     */       return;
/*     */     } 
/* 475 */     super.setProperty(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(Schema schema) {
/* 482 */     this.schema = schema;
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/* 487 */     return this.schema;
/*     */   }
/*     */ 
/*     */   
/*     */   public AttachmentUnmarshaller getAttachmentUnmarshaller() {
/* 492 */     return this.attachmentUnmarshaller;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttachmentUnmarshaller(AttachmentUnmarshaller au) {
/* 497 */     this.attachmentUnmarshaller = au;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isValidating() {
/* 505 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setValidating(boolean validating) {
/* 513 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends XmlAdapter<?, ?>> void setAdapter(Class<A> type, A adapter) {
/* 518 */     if (type == null) {
/* 519 */       throw new IllegalArgumentException();
/*     */     }
/* 521 */     this.coordinator.putAdapter(type, (XmlAdapter)adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends XmlAdapter<?, ?>> A getAdapter(Class<A> type) {
/* 526 */     if (type == null) {
/* 527 */       throw new IllegalArgumentException();
/*     */     }
/* 529 */     if (this.coordinator.containsAdapter(type)) {
/* 530 */       return (A)this.coordinator.getAdapter(type);
/*     */     }
/* 532 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmarshalException createUnmarshalException(SAXException e) {
/* 539 */     return super.createUnmarshalException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleEvent(ValidationEvent event) {
/* 548 */     return (event.getSeverity() != 2);
/*     */   }
/*     */   
/*     */   private static InputSource streamSourceToInputSource(StreamSource ss) {
/* 552 */     InputSource is = new InputSource();
/* 553 */     is.setSystemId(ss.getSystemId());
/* 554 */     is.setByteStream(ss.getInputStream());
/* 555 */     is.setCharacterStream(ss.getReader());
/*     */     
/* 557 */     return is;
/*     */   }
/*     */   
/*     */   public <T> JaxBeanInfo<T> getBeanInfo(Class<T> clazz) throws JAXBException {
/* 561 */     return this.context.getBeanInfo(clazz, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Unmarshaller.Listener getListener() {
/* 566 */     return this.externalListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListener(Unmarshaller.Listener listener) {
/* 571 */     this.externalListener = listener;
/*     */   }
/*     */   
/*     */   public UnmarshallingContext getContext() {
/* 575 */     return this.coordinator;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\UnmarshallerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */