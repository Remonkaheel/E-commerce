/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.BuiltinLeafInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*    */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltinLeafInfoImpl<TypeT, ClassDeclT>
/*    */   extends LeafInfoImpl<TypeT, ClassDeclT>
/*    */   implements BuiltinLeafInfo<TypeT, ClassDeclT>
/*    */ {
/*    */   private final QName[] typeNames;
/*    */   
/*    */   protected BuiltinLeafInfoImpl(TypeT type, QName... typeNames) {
/* 33 */     super(type, (typeNames.length > 0) ? typeNames[0] : null);
/* 34 */     this.typeNames = typeNames;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final QName[] getTypeNames() {
/* 44 */     return this.typeNames;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final boolean isElement() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final QName getElementName() {
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final Element<TypeT, ClassDeclT> asElement() {
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <TypeT, ClassDeclT> Map<TypeT, BuiltinLeafInfoImpl<TypeT, ClassDeclT>> createLeaves(Navigator<TypeT, ClassDeclT, ?, ?> nav) {
/* 81 */     Map<TypeT, BuiltinLeafInfoImpl<TypeT, ClassDeclT>> leaves = new HashMap<>();
/*    */     
/* 83 */     for (RuntimeBuiltinLeafInfoImpl<?> leaf : RuntimeBuiltinLeafInfoImpl.builtinBeanInfos) {
/* 84 */       TypeT t = (TypeT)nav.ref(leaf.getClazz());
/* 85 */       leaves.put(t, new BuiltinLeafInfoImpl<>(t, leaf.getTypeNames()));
/*    */     } 
/*    */     
/* 88 */     return leaves;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\BuiltinLeafInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */