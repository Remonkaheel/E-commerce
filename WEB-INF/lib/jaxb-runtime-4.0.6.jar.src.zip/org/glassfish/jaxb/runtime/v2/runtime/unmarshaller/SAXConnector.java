/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.UnmarshallerHandler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SAXConnector
/*     */   implements UnmarshallerHandler
/*     */ {
/*     */   private LocatorEx loc;
/*  34 */   private static final Logger logger = Utils.getClassLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private final StringBuilder buffer = new StringBuilder();
/*     */   private final XmlVisitor next;
/*     */   private final UnmarshallingContext context;
/*     */   private final XmlVisitor.TextPredictor predictor;
/*     */   
/*     */   private static final class TagNameImpl
/*     */     extends TagName {
/*     */     String qname;
/*     */     
/*     */     public String getQname() {
/*  50 */       return this.qname;
/*     */     }
/*     */   }
/*     */   
/*  54 */   private final TagNameImpl tagName = new TagNameImpl();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SAXConnector(XmlVisitor next, LocatorEx externalLocator) {
/*  63 */     this.next = next;
/*  64 */     this.context = next.getContext();
/*  65 */     this.predictor = next.getPredictor();
/*  66 */     this.loc = externalLocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getResult() throws JAXBException, IllegalStateException {
/*  71 */     return this.context.getResult();
/*     */   }
/*     */   
/*     */   public UnmarshallingContext getContext() {
/*  75 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {
/*  80 */     if (this.loc != null) {
/*     */       return;
/*     */     }
/*  83 */     this.loc = new LocatorExWrapper(locator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() throws SAXException {
/*  88 */     if (logger.isLoggable(Level.FINER)) {
/*  89 */       logger.log(Level.FINER, "SAXConnector.startDocument");
/*     */     }
/*  91 */     this.next.startDocument(this.loc, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {
/*  96 */     if (logger.isLoggable(Level.FINER)) {
/*  97 */       logger.log(Level.FINER, "SAXConnector.endDocument");
/*     */     }
/*  99 */     this.next.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 104 */     if (logger.isLoggable(Level.FINER)) {
/* 105 */       logger.log(Level.FINER, "SAXConnector.startPrefixMapping: {0}:{1}", new Object[] { prefix, uri });
/*     */     }
/* 107 */     this.next.startPrefixMapping(prefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/* 112 */     if (logger.isLoggable(Level.FINER)) {
/* 113 */       logger.log(Level.FINER, "SAXConnector.endPrefixMapping: {0}", new Object[] { prefix });
/*     */     }
/* 115 */     this.next.endPrefixMapping(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String local, String qname, Attributes atts) throws SAXException {
/* 120 */     if (logger.isLoggable(Level.FINER)) {
/* 121 */       logger.log(Level.FINER, "SAXConnector.startElement: {0}:{1}:{2}, attrs: {3}", new Object[] { uri, local, qname, atts });
/*     */     }
/*     */     
/* 124 */     if (uri == null || uri.length() == 0)
/* 125 */       uri = ""; 
/* 126 */     if (local == null || local.length() == 0)
/* 127 */       local = qname; 
/* 128 */     if (qname == null || qname.length() == 0) {
/* 129 */       qname = local;
/*     */     }
/* 131 */     processText(!this.context.getCurrentState().isMixed());
/*     */     
/* 133 */     this.tagName.uri = uri;
/* 134 */     this.tagName.local = local;
/* 135 */     this.tagName.qname = qname;
/* 136 */     this.tagName.atts = atts;
/* 137 */     this.next.startElement(this.tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 142 */     if (logger.isLoggable(Level.FINER)) {
/* 143 */       logger.log(Level.FINER, "SAXConnector.endElement: {0}:{1}:{2}", new Object[] { uri, localName, qName });
/*     */     }
/* 145 */     processText(false);
/* 146 */     this.tagName.uri = uri;
/* 147 */     this.tagName.local = localName;
/* 148 */     this.tagName.qname = qName;
/* 149 */     this.next.endElement(this.tagName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] buf, int start, int len) {
/* 155 */     if (logger.isLoggable(Level.FINEST)) {
/* 156 */       logger.log(Level.FINEST, "SAXConnector.characters: {0}", buf);
/*     */     }
/* 158 */     if (this.predictor.expectText()) {
/* 159 */       this.buffer.append(buf, start, len);
/*     */     }
/*     */   }
/*     */   
/*     */   public void ignorableWhitespace(char[] buf, int start, int len) {
/* 164 */     if (logger.isLoggable(Level.FINEST)) {
/* 165 */       logger.log(Level.FINEST, "SAXConnector.ignorableWhitespace: {0}", buf);
/*     */     }
/* 167 */     characters(buf, start, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void processText(boolean ignorable) throws SAXException {
/* 181 */     if (this.predictor.expectText() && (!ignorable || !WhiteSpaceProcessor.isWhiteSpace(this.buffer)))
/* 182 */       this.next.text(this.buffer); 
/* 183 */     this.buffer.setLength(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\SAXConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */