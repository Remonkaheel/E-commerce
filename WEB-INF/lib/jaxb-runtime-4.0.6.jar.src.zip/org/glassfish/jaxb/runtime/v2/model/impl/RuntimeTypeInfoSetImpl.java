/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*    */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfoSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RuntimeTypeInfoSetImpl
/*    */   extends TypeInfoSetImpl<Type, Class, Field, Method>
/*    */   implements RuntimeTypeInfoSet
/*    */ {
/*    */   public RuntimeTypeInfoSetImpl(AnnotationReader<Type, Class<?>, Field, Method> reader) {
/* 31 */     super(Utils.REFLECTION_NAVIGATOR, reader, (Map)RuntimeBuiltinLeafInfoImpl.LEAVES);
/*    */   }
/*    */ 
/*    */   
/*    */   protected RuntimeNonElement createAnyType() {
/* 36 */     return RuntimeAnyTypeImpl.theInstance;
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getTypeInfo(Type type) {
/* 41 */     return (RuntimeNonElement)super.getTypeInfo(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getAnyTypeInfo() {
/* 46 */     return (RuntimeNonElement)super.getAnyTypeInfo();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getClassInfo(Class clazz) {
/* 51 */     return (RuntimeNonElement)super.getClassInfo(clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Class, RuntimeClassInfoImpl> beans() {
/* 56 */     return (Map)super.beans();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Type, RuntimeBuiltinLeafInfoImpl<?>> builtins() {
/* 61 */     return (Map)super.builtins();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Class, RuntimeEnumLeafInfoImpl<?, ?>> enums() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: invokespecial enums : ()Ljava/util/Map;
/*    */     //   4: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #66	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	5	0	this	Lorg/glassfish/jaxb/runtime/v2/model/impl/RuntimeTypeInfoSetImpl;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Class, RuntimeArrayInfoImpl> arrays() {
/* 71 */     return (Map)super.arrays();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeElementInfoImpl getElementInfo(Class scope, QName name) {
/* 76 */     return (RuntimeElementInfoImpl)super.getElementInfo(scope, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<QName, RuntimeElementInfoImpl> getElementMappings(Class scope) {
/* 81 */     return (Map)super.getElementMappings(scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterable<RuntimeElementInfoImpl> getAllElements() {
/* 86 */     return (Iterable)super.getAllElements();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeTypeInfoSetImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */