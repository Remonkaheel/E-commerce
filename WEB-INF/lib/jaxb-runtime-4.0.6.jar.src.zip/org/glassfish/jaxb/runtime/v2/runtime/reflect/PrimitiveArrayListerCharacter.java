/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerCharacter<BeanT>
/*    */   extends Lister<BeanT, char[], Character, PrimitiveArrayListerCharacter.CharacterArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     primitiveArrayListers.put(char.class, new PrimitiveArrayListerCharacter());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Character> iterator(final char[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Character>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Character next() {
/* 47 */           return Character.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public CharacterArrayPack startPacking(BeanT current, Accessor<BeanT, char[]> acc) {
/* 54 */     return new CharacterArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(CharacterArrayPack objects, Character o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(CharacterArrayPack pack, BeanT bean, Accessor<BeanT, char[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, char[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new char[0]);
/*    */   }
/*    */   
/*    */   static final class CharacterArrayPack {
/* 73 */     char[] buf = new char[16];
/*    */     int size;
/*    */     
/*    */     void add(Character b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         char[] nb = new char[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.charValue(); 
/*    */     }
/*    */     
/*    */     char[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       char[] r = new char[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerCharacter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */