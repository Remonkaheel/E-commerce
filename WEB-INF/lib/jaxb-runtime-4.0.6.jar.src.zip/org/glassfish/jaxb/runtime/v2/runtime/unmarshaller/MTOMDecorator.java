/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import jakarta.activation.DataHandler;
/*     */ import jakarta.xml.bind.attachment.AttachmentUnmarshaller;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MTOMDecorator
/*     */   implements XmlVisitor
/*     */ {
/*     */   private final XmlVisitor next;
/*     */   private final AttachmentUnmarshaller au;
/*     */   private UnmarshallerImpl parent;
/*  35 */   private final Base64Data base64data = new Base64Data();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inXopInclude;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean followXop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MTOMDecorator(UnmarshallerImpl parent, XmlVisitor next, AttachmentUnmarshaller au) {
/*  53 */     this.parent = parent;
/*  54 */     this.next = next;
/*  55 */     this.au = au;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument(LocatorEx loc, NamespaceContext nsContext) throws SAXException {
/*  60 */     this.next.startDocument(loc, nsContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {
/*  65 */     this.next.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(TagName tagName) throws SAXException {
/*  70 */     if (tagName.local.equals("Include") && tagName.uri.equals("http://www.w3.org/2004/08/xop/include")) {
/*     */       
/*  72 */       String href = tagName.atts.getValue("href");
/*  73 */       DataHandler attachment = this.au.getAttachmentAsDataHandler(href);
/*  74 */       if (attachment == null)
/*     */       {
/*  76 */         this.parent.getEventHandler().handleEvent(null);
/*     */       }
/*     */       
/*  79 */       this.base64data.set(attachment);
/*  80 */       this.next.text((CharSequence)this.base64data);
/*  81 */       this.inXopInclude = true;
/*  82 */       this.followXop = true;
/*     */     } else {
/*  84 */       this.next.startElement(tagName);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endElement(TagName tagName) throws SAXException {
/*  89 */     if (this.inXopInclude) {
/*     */       
/*  91 */       this.inXopInclude = false;
/*  92 */       this.followXop = true;
/*     */       return;
/*     */     } 
/*  95 */     this.next.endElement(tagName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String nsUri) throws SAXException {
/* 100 */     this.next.startPrefixMapping(prefix, nsUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/* 105 */     this.next.endPrefixMapping(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(CharSequence pcdata) throws SAXException {
/* 110 */     if (!this.followXop) {
/* 111 */       this.next.text(pcdata);
/*     */     } else {
/* 113 */       this.followXop = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public UnmarshallingContext getContext() {
/* 118 */     return this.next.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlVisitor.TextPredictor getPredictor() {
/* 123 */     return this.next.getPredictor();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\MTOMDecorator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */