/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlNs;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlNsQuick
/*    */   extends Quick
/*    */   implements XmlNs
/*    */ {
/*    */   private final XmlNs core;
/*    */   
/*    */   public XmlNsQuick(Locatable upstream, XmlNs core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlNsQuick(upstream, (XmlNs)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlNs> annotationType() {
/* 47 */     return XmlNs.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespaceURI() {
/* 52 */     return this.core.namespaceURI();
/*    */   }
/*    */ 
/*    */   
/*    */   public String prefix() {
/* 57 */     return this.core.prefix();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlNsQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */