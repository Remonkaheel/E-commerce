/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodAccessor_Double<B>
/*    */   extends Accessor<B, Double>
/*    */ {
/*    */   public MethodAccessor_Double() {
/* 27 */     super(Double.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Double get(B bean) {
/* 32 */     return Double.valueOf(((Bean)bean).get_double());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Double value) {
/* 37 */     ((Bean)bean).set_double((value == null) ? 0.0D : value.doubleValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\MethodAccessor_Double.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */