/*    */ package org.glassfish.jaxb.runtime.v2.runtime;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.glassfish.jaxb.core.v2.model.core.ErrorHandler;
/*    */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalAnnotationsException
/*    */   extends JAXBException
/*    */ {
/*    */   private final transient List<IllegalAnnotationException> errors;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalAnnotationsException(List<IllegalAnnotationException> errors) {
/* 38 */     super("" + errors.size() + " counts of IllegalAnnotationExceptions");
/* 39 */     assert !errors.isEmpty() : "there must be at least one error";
/* 40 */     this.errors = Collections.unmodifiableList(new ArrayList<>(errors));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     StringBuilder sb = new StringBuilder(super.toString());
/* 46 */     sb.append('\n');
/*    */     
/* 48 */     for (IllegalAnnotationException error : this.errors) {
/* 49 */       sb.append(error.toString()).append('\n');
/*    */     }
/* 51 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<IllegalAnnotationException> getErrors() {
/* 62 */     return this.errors;
/*    */   }
/*    */   
/*    */   public static class Builder implements ErrorHandler {
/* 66 */     private final List<IllegalAnnotationException> list = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void error(IllegalAnnotationException e) {
/* 74 */       this.list.add(e);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void check() throws IllegalAnnotationsException {
/* 81 */       if (this.list.isEmpty())
/*    */         return; 
/* 83 */       throw new IllegalAnnotationsException(this.list);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\IllegalAnnotationsException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */