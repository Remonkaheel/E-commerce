/*    */ package org.glassfish.jaxb.runtime.v2;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBContext;
/*    */ import jakarta.xml.bind.JAXBContextFactory;
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JAXBContextFactory
/*    */   implements JAXBContextFactory
/*    */ {
/*    */   public JAXBContext createContext(Class<?>[] classesToBeBound, Map<String, ?> properties) throws JAXBException {
/* 44 */     return ContextFactory.createContext(classesToBeBound, (Map)properties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JAXBContext createContext(String contextPath, ClassLoader classLoader, Map<String, ?> properties) throws JAXBException {
/* 58 */     return ContextFactory.createContext(contextPath, classLoader, (Map)properties);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\JAXBContextFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */