package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;

public interface Occurs extends TypedXmlWriter {
  @XmlAttribute
  Occurs minOccurs(int paramInt);
  
  @XmlAttribute
  Occurs maxOccurs(String paramString);
  
  @XmlAttribute
  Occurs maxOccurs(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\Occurs.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */