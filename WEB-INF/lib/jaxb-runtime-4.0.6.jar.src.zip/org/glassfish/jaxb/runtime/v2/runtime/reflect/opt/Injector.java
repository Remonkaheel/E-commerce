/*     */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Injector
/*     */ {
/*  46 */   private static final ReentrantReadWriteLock irwl = new ReentrantReadWriteLock();
/*  47 */   private static final Lock ir = irwl.readLock();
/*  48 */   private static final Lock iw = irwl.writeLock();
/*  49 */   private static final Map<ClassLoader, WeakReference<Injector>> injectors = new WeakHashMap<>();
/*     */   
/*  51 */   private static final Logger logger = Logger.getLogger(Injector.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class inject(ClassLoader cl, String className, byte[] image) {
/*  59 */     Injector injector = get(cl);
/*  60 */     if (injector != null) {
/*  61 */       return injector.inject(className, image);
/*     */     }
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class find(ClassLoader cl, String className) {
/*  71 */     Injector injector = get(cl);
/*  72 */     if (injector != null) {
/*  73 */       return injector.find(className);
/*     */     }
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Injector get(ClassLoader cl) {
/*     */     WeakReference<Injector> wr;
/*  86 */     Injector injector = null;
/*     */     
/*  88 */     ir.lock();
/*     */     try {
/*  90 */       wr = injectors.get(cl);
/*     */     } finally {
/*  92 */       ir.unlock();
/*     */     } 
/*  94 */     if (wr != null) {
/*  95 */       injector = wr.get();
/*     */     }
/*  97 */     if (injector == null) {
/*     */       try {
/*  99 */         wr = new WeakReference<>(injector = new Injector(cl));
/* 100 */         iw.lock();
/*     */         try {
/* 102 */           if (!injectors.containsKey(cl)) {
/* 103 */             injectors.put(cl, wr);
/*     */           }
/*     */         } finally {
/* 106 */           iw.unlock();
/*     */         } 
/* 108 */       } catch (SecurityException e) {
/* 109 */         logger.log(Level.FINE, "Unable to set up a back-door for the injector", e);
/* 110 */         return null;
/*     */       } 
/*     */     }
/* 113 */     return injector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 118 */   private final Map<String, Class> classes = (Map)new HashMap<>();
/* 119 */   private final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
/* 120 */   private final Lock r = this.rwl.readLock();
/* 121 */   private final Lock w = this.rwl.writeLock();
/*     */   
/*     */   private final ClassLoader parent;
/*     */   
/*     */   private final boolean loadable;
/*     */   
/*     */   private static Method defineClass;
/*     */   
/*     */   private static Method resolveClass;
/*     */   private static Method findLoadedClass;
/*     */   private static Object U;
/*     */   
/*     */   static {
/*     */     try {
/* 135 */       Method[] m = AccessController.<Method[]>doPrivileged((PrivilegedAction)new PrivilegedAction<Method[]>()
/*     */           {
/*     */             public Method[] run()
/*     */             {
/* 139 */               return new Method[] {
/* 140 */                   Injector.getMethod(ClassLoader.class, "defineClass", new Class[] { String.class, byte[].class, int.class, int.class
/* 141 */                     }), Injector.getMethod(ClassLoader.class, "resolveClass", new Class[] { Class.class
/* 142 */                     }), Injector.getMethod(ClassLoader.class, "findLoadedClass", new Class[] { String.class })
/*     */                 };
/*     */             }
/*     */           });
/*     */       
/* 147 */       defineClass = m[0];
/* 148 */       resolveClass = m[1];
/* 149 */       findLoadedClass = m[2];
/* 150 */     } catch (Throwable t) {
/*     */       try {
/* 152 */         U = AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */             {
/*     */               public Object run() throws Exception {
/* 155 */                 Class u = Injector.classForNames(new String[] { "sun.misc.Unsafe", "jdk.internal.misc.Unsafe" });
/* 156 */                 Field theUnsafe = u.getDeclaredField("theUnsafe");
/* 157 */                 theUnsafe.setAccessible(true);
/* 158 */                 return theUnsafe.get(null);
/*     */               }
/*     */             });
/* 161 */         defineClass = AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */             {
/*     */               public Method run() throws Exception {
/*     */                 try {
/* 165 */                   return Injector.U.getClass().getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 }
/* 172 */                 catch (NoSuchMethodException|SecurityException ex) {
/* 173 */                   throw ex;
/*     */                 } 
/*     */               }
/*     */             });
/* 177 */       } catch (SecurityException|java.security.PrivilegedActionException ex) {
/* 178 */         Logger.getLogger(Injector.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class classForNames(String... names) throws ClassNotFoundException {
/* 184 */     for (String name : names) {
/*     */       try {
/* 186 */         return Class.forName(name);
/* 187 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */ 
/*     */     
/* 191 */     throw new ClassNotFoundException(
/* 192 */         String.format("No class found for supplied FQDNs %s", new Object[] {
/* 193 */             Arrays.toString(names) }));
/*     */   }
/*     */   
/*     */   private static Method getMethod(Class<?> c, String methodname, Class<?>... params) {
/*     */     try {
/* 198 */       Method m = c.getDeclaredMethod(methodname, params);
/* 199 */       m.setAccessible(true);
/* 200 */       return m;
/* 201 */     } catch (NoSuchMethodException e) {
/* 202 */       throw new NoSuchMethodError(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private Injector(ClassLoader parent) {
/* 207 */     this.parent = parent;
/* 208 */     assert parent != null;
/*     */     
/* 210 */     boolean loadableCheck = false;
/*     */     
/*     */     try {
/* 213 */       loadableCheck = (parent.loadClass(Accessor.class.getName()) == Accessor.class);
/* 214 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */     
/* 218 */     this.loadable = loadableCheck;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class inject(String className, byte[] image) {
/* 223 */     if (!this.loadable)
/*     */     {
/* 225 */       return null;
/*     */     }
/*     */     
/* 228 */     boolean wlocked = false;
/* 229 */     boolean rlocked = false;
/*     */     
/*     */     try {
/* 232 */       this.r.lock();
/* 233 */       rlocked = true;
/*     */       
/* 235 */       Class c = this.classes.get(className);
/*     */ 
/*     */ 
/*     */       
/* 239 */       this.r.unlock();
/* 240 */       rlocked = false;
/*     */ 
/*     */       
/* 243 */       if (c == null && findLoadedClass != null) {
/*     */         
/*     */         try {
/* 246 */           c = (Class)findLoadedClass.invoke(this.parent, new Object[] { className.replace('/', '.') });
/* 247 */         } catch (IllegalArgumentException|IllegalAccessException e) {
/* 248 */           logger.log(Level.FINE, "Unable to find " + className, e);
/* 249 */         } catch (InvocationTargetException e) {
/* 250 */           Throwable t = e.getTargetException();
/* 251 */           logger.log(Level.FINE, "Unable to find " + className, t);
/*     */         } 
/*     */         
/* 254 */         if (c != null) {
/*     */           
/* 256 */           this.w.lock();
/* 257 */           wlocked = true;
/*     */           
/* 259 */           this.classes.put(className, c);
/*     */           
/* 261 */           this.w.unlock();
/* 262 */           wlocked = false;
/*     */           
/* 264 */           return c;
/*     */         } 
/*     */       } 
/*     */       
/* 268 */       if (c == null) {
/*     */         
/* 270 */         this.r.lock();
/* 271 */         rlocked = true;
/*     */         
/* 273 */         c = this.classes.get(className);
/*     */ 
/*     */ 
/*     */         
/* 277 */         this.r.unlock();
/* 278 */         rlocked = false;
/*     */         
/* 280 */         if (c == null) {
/*     */ 
/*     */           
/*     */           try {
/* 284 */             if (resolveClass != null) {
/* 285 */               c = (Class)defineClass.invoke(this.parent, new Object[] { className.replace('/', '.'), image, Integer.valueOf(0), Integer.valueOf(image.length) });
/* 286 */               resolveClass.invoke(this.parent, new Object[] { c });
/*     */             } else {
/* 288 */               c = (Class)defineClass.invoke(U, new Object[] { className.replace('/', '.'), image, Integer.valueOf(0), Integer.valueOf(image.length), this.parent, Injector.class.getProtectionDomain() });
/*     */             } 
/* 290 */           } catch (IllegalAccessException|LinkageError|SecurityException e) {
/* 291 */             logger.log(Level.FINE, "Unable to inject " + className, e);
/* 292 */             return null;
/* 293 */           } catch (InvocationTargetException e) {
/* 294 */             Throwable t = e.getTargetException();
/* 295 */             if (t instanceof LinkageError) {
/* 296 */               logger.log(Level.FINE, "duplicate class definition bug occured? Please report this : " + className, t);
/*     */             } else {
/* 298 */               logger.log(Level.FINE, "Unable to inject " + className, t);
/*     */             } 
/* 300 */             return null;
/*     */           } 
/*     */           
/* 303 */           this.w.lock();
/* 304 */           wlocked = true;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 309 */           if (!this.classes.containsKey(className)) {
/* 310 */             this.classes.put(className, c);
/*     */           }
/*     */           
/* 313 */           this.w.unlock();
/* 314 */           wlocked = false;
/*     */         } 
/*     */       } 
/* 317 */       return c;
/*     */     } finally {
/* 319 */       if (rlocked) {
/* 320 */         this.r.unlock();
/*     */       }
/* 322 */       if (wlocked) {
/* 323 */         this.w.unlock();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class find(String className) {
/* 329 */     this.r.lock();
/*     */     try {
/* 331 */       return this.classes.get(className);
/*     */     } finally {
/* 333 */       this.r.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\Injector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */