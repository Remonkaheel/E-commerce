/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Discarder
/*    */   extends Loader
/*    */ {
/* 24 */   public static final Loader INSTANCE = new Discarder();
/*    */   
/*    */   private Discarder() {
/* 27 */     super(false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void childElement(UnmarshallingContext.State state, TagName ea) {
/* 32 */     state.setTarget(null);
/*    */     
/* 34 */     state.setLoader(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\Discarder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */