/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.api.impl.NameConverter;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TypeInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*     */   implements TypeInfo<TypeT, ClassDeclT>, Locatable
/*     */ {
/*     */   private final Locatable upstream;
/*     */   protected final TypeInfoSetImpl<TypeT, ClassDeclT, FieldT, MethodT> owner;
/*     */   protected ModelBuilder<TypeT, ClassDeclT, FieldT, MethodT> builder;
/*     */   
/*     */   protected TypeInfoImpl(ModelBuilder<TypeT, ClassDeclT, FieldT, MethodT> builder, Locatable upstream) {
/*  55 */     this.builder = builder;
/*  56 */     this.owner = builder.typeInfoSet;
/*  57 */     this.upstream = upstream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Locatable getUpstream() {
/*  62 */     return this.upstream;
/*     */   }
/*     */   
/*     */   void link() {
/*  66 */     this.builder = null;
/*     */   }
/*     */   
/*     */   protected final Navigator<TypeT, ClassDeclT, FieldT, MethodT> nav() {
/*  70 */     return this.owner.nav;
/*     */   }
/*     */   
/*     */   protected final AnnotationReader<TypeT, ClassDeclT, FieldT, MethodT> reader() {
/*  74 */     return this.owner.reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final QName parseElementName(ClassDeclT clazz) {
/*  85 */     XmlRootElement e = (XmlRootElement)reader().getClassAnnotation(XmlRootElement.class, clazz, this);
/*  86 */     if (e == null) {
/*  87 */       return null;
/*     */     }
/*  89 */     String local = e.name();
/*  90 */     if (local.equals("##default"))
/*     */     {
/*  92 */       local = NameConverter.standard.toVariableName(nav().getClassShortName(clazz));
/*     */     }
/*  94 */     String nsUri = e.namespace();
/*  95 */     if (nsUri.equals("##default")) {
/*     */       
/*  97 */       XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, clazz, this);
/*  98 */       if (xs != null) {
/*  99 */         nsUri = xs.namespace();
/*     */       } else {
/* 101 */         nsUri = this.builder.defaultNsUri;
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     return new QName(nsUri.intern(), local.intern());
/*     */   }
/*     */   
/*     */   protected final QName parseTypeName(ClassDeclT clazz) {
/* 109 */     return parseTypeName(clazz, (XmlType)reader().getClassAnnotation(XmlType.class, clazz, this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final QName parseTypeName(ClassDeclT clazz, XmlType t) {
/* 124 */     String nsUri = "##default";
/* 125 */     String local = "##default";
/* 126 */     if (t != null) {
/* 127 */       nsUri = t.namespace();
/* 128 */       local = t.name();
/*     */     } 
/*     */     
/* 131 */     if (local.length() == 0) {
/* 132 */       return null;
/*     */     }
/*     */     
/* 135 */     if (local.equals("##default"))
/*     */     {
/* 137 */       local = NameConverter.standard.toVariableName(nav().getClassShortName(clazz));
/*     */     }
/* 139 */     if (nsUri.equals("##default")) {
/*     */       
/* 141 */       XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, clazz, this);
/* 142 */       if (xs != null) {
/* 143 */         nsUri = xs.namespace();
/*     */       } else {
/* 145 */         nsUri = this.builder.defaultNsUri;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     return new QName(nsUri.intern(), local.intern());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\TypeInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */