/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.ArrayInfo;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.util.ArrayInfoUtil;
/*    */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*    */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArrayInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   extends TypeInfoImpl<TypeT, ClassDeclT, FieldT, MethodT>
/*    */   implements ArrayInfo<TypeT, ClassDeclT>, Location
/*    */ {
/*    */   private final NonElement<TypeT, ClassDeclT> itemType;
/*    */   private final QName typeName;
/*    */   private final TypeT arrayType;
/*    */   
/*    */   public ArrayInfoImpl(ModelBuilder<TypeT, ClassDeclT, FieldT, MethodT> builder, Locatable upstream, TypeT arrayType) {
/* 44 */     super(builder, upstream);
/* 45 */     this.arrayType = arrayType;
/* 46 */     TypeT componentType = (TypeT)nav().getComponentType(arrayType);
/* 47 */     this.itemType = builder.getTypeInfo(componentType, this);
/*    */     
/* 49 */     QName n = this.itemType.getTypeName();
/* 50 */     if (n == null) {
/* 51 */       builder.reportError(new IllegalAnnotationException(Messages.ANONYMOUS_ARRAY_ITEM.format(new Object[] {
/* 52 */                 nav().getTypeName(componentType) }, ), this));
/* 53 */       n = new QName("#dummy");
/*    */     } 
/* 55 */     this.typeName = ArrayInfoUtil.calcArrayTypeName(n);
/*    */   }
/*    */ 
/*    */   
/*    */   public NonElement<TypeT, ClassDeclT> getItemType() {
/* 60 */     return this.itemType;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getTypeName() {
/* 65 */     return this.typeName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSimpleType() {
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeT getType() {
/* 75 */     return this.arrayType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final boolean canBeReferencedByIDREF() {
/* 87 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 92 */     return this;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 96 */     return nav().getTypeName(this.arrayType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ArrayInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */