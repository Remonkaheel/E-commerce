/*     */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*     */ 
/*     */ import com.sun.istack.SAXException2;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import java.util.TreeSet;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.glassfish.jaxb.core.v2.TODO;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.runtime.unmarshaller.LocatorEx;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Patcher;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Lister<BeanT, PropT, ItemT, PackT>
/*     */ {
/*     */   public static <BeanT, PropT, ItemT, PackT> Lister<BeanT, PropT, ItemT, PackT> create(Type fieldType, ID idness, Adapter<Type, Class<?>> adapter) {
/*     */     // Byte code:
/*     */     //   0: getstatic org/glassfish/jaxb/runtime/v2/runtime/reflect/Utils.REFLECTION_NAVIGATOR : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   3: aload_0
/*     */     //   4: invokeinterface erasure : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   9: checkcast java/lang/Class
/*     */     //   12: astore_3
/*     */     //   13: aload_3
/*     */     //   14: invokevirtual isArray : ()Z
/*     */     //   17: ifeq -> 36
/*     */     //   20: aload_3
/*     */     //   21: invokevirtual getComponentType : ()Ljava/lang/Class;
/*     */     //   24: astore #4
/*     */     //   26: aload #4
/*     */     //   28: invokestatic getArrayLister : (Ljava/lang/Class;)Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;
/*     */     //   31: astore #5
/*     */     //   33: goto -> 119
/*     */     //   36: ldc java/util/Collection
/*     */     //   38: aload_3
/*     */     //   39: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   42: ifeq -> 117
/*     */     //   45: getstatic org/glassfish/jaxb/runtime/v2/runtime/reflect/Utils.REFLECTION_NAVIGATOR : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   48: aload_0
/*     */     //   49: ldc java/util/Collection
/*     */     //   51: invokeinterface getBaseClass : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   56: checkcast java/lang/reflect/Type
/*     */     //   59: astore #6
/*     */     //   61: aload #6
/*     */     //   63: instanceof java/lang/reflect/ParameterizedType
/*     */     //   66: ifeq -> 97
/*     */     //   69: getstatic org/glassfish/jaxb/runtime/v2/runtime/reflect/Utils.REFLECTION_NAVIGATOR : Lorg/glassfish/jaxb/core/v2/model/nav/Navigator;
/*     */     //   72: aload #6
/*     */     //   74: checkcast java/lang/reflect/ParameterizedType
/*     */     //   77: invokeinterface getActualTypeArguments : ()[Ljava/lang/reflect/Type;
/*     */     //   82: iconst_0
/*     */     //   83: aaload
/*     */     //   84: invokeinterface erasure : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   89: checkcast java/lang/Class
/*     */     //   92: astore #4
/*     */     //   94: goto -> 101
/*     */     //   97: ldc java/lang/Object
/*     */     //   99: astore #4
/*     */     //   101: new org/glassfish/jaxb/runtime/v2/runtime/reflect/Lister$CollectionLister
/*     */     //   104: dup
/*     */     //   105: aload_3
/*     */     //   106: invokestatic getImplClass : (Ljava/lang/Class;)Ljava/lang/Class;
/*     */     //   109: invokespecial <init> : (Ljava/lang/Class;)V
/*     */     //   112: astore #5
/*     */     //   114: goto -> 119
/*     */     //   117: aconst_null
/*     */     //   118: areturn
/*     */     //   119: aload_1
/*     */     //   120: getstatic org/glassfish/jaxb/core/v2/model/core/ID.IDREF : Lorg/glassfish/jaxb/core/v2/model/core/ID;
/*     */     //   123: if_acmpne -> 139
/*     */     //   126: new org/glassfish/jaxb/runtime/v2/runtime/reflect/Lister$IDREFS
/*     */     //   129: dup
/*     */     //   130: aload #5
/*     */     //   132: aload #4
/*     */     //   134: invokespecial <init> : (Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;Ljava/lang/Class;)V
/*     */     //   137: astore #5
/*     */     //   139: aload_2
/*     */     //   140: ifnull -> 161
/*     */     //   143: new org/glassfish/jaxb/runtime/v2/runtime/reflect/AdaptedLister
/*     */     //   146: dup
/*     */     //   147: aload #5
/*     */     //   149: aload_2
/*     */     //   150: getfield adapterType : Ljava/lang/Object;
/*     */     //   153: checkcast java/lang/Class
/*     */     //   156: invokespecial <init> : (Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;Ljava/lang/Class;)V
/*     */     //   159: astore #5
/*     */     //   161: aload #5
/*     */     //   163: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #90	-> 0
/*     */     //   #94	-> 13
/*     */     //   #95	-> 20
/*     */     //   #96	-> 26
/*     */     //   #98	-> 36
/*     */     //   #99	-> 45
/*     */     //   #100	-> 61
/*     */     //   #101	-> 69
/*     */     //   #103	-> 97
/*     */     //   #104	-> 101
/*     */     //   #105	-> 114
/*     */     //   #106	-> 117
/*     */     //   #108	-> 119
/*     */     //   #109	-> 126
/*     */     //   #111	-> 139
/*     */     //   #112	-> 143
/*     */     //   #114	-> 161
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   26	10	4	itemType	Ljava/lang/Class;
/*     */     //   33	3	5	l	Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;
/*     */     //   94	3	4	itemType	Ljava/lang/Class;
/*     */     //   61	53	6	bt	Ljava/lang/reflect/Type;
/*     */     //   101	16	4	itemType	Ljava/lang/Class;
/*     */     //   114	3	5	l	Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;
/*     */     //   0	164	0	fieldType	Ljava/lang/reflect/Type;
/*     */     //   0	164	1	idness	Lorg/glassfish/jaxb/core/v2/model/core/ID;
/*     */     //   0	164	2	adapter	Lorg/glassfish/jaxb/core/v2/model/core/Adapter;
/*     */     //   13	151	3	rawType	Ljava/lang/Class;
/*     */     //   119	45	4	itemType	Ljava/lang/Class;
/*     */     //   119	45	5	l	Lorg/glassfish/jaxb/runtime/v2/runtime/reflect/Lister;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	164	2	adapter	Lorg/glassfish/jaxb/core/v2/model/core/Adapter<Ljava/lang/reflect/Type;Ljava/lang/Class;>;
/*     */   }
/*     */   
/*     */   private static Class getImplClass(Class<?> fieldType) {
/* 118 */     return ClassFactory.inferImplClass(fieldType, COLLECTION_IMPL_CLASSES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private static final Map<Class, WeakReference<Lister>> arrayListerCache = Collections.synchronizedMap(new WeakHashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Lister getArrayLister(Class<?> componentType) {
/* 131 */     Lister<Object, Object> l = null;
/* 132 */     if (componentType.isPrimitive()) {
/* 133 */       l = primitiveArrayListers.get(componentType);
/*     */     } else {
/* 135 */       WeakReference<Lister> wr = arrayListerCache.get(componentType);
/* 136 */       if (wr != null)
/* 137 */         l = wr.get(); 
/* 138 */       if (l == null) {
/* 139 */         l = (Lister<Object, Object>)new ArrayLister<>(componentType);
/* 140 */         arrayListerCache.put(componentType, new WeakReference<>(l));
/*     */       } 
/*     */     } 
/* 143 */     assert l != null;
/* 144 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ArrayLister<BeanT, ItemT>
/*     */     extends Lister<BeanT, ItemT[], ItemT, Pack<ItemT>>
/*     */   {
/*     */     private final Class<ItemT> itemType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayLister(Class<ItemT> itemType) {
/* 159 */       this.itemType = itemType;
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<ItemT> iterator(final ItemT[] objects, XMLSerializer context) {
/* 164 */       return new ListIterator<ItemT>() {
/* 165 */           int idx = 0;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 169 */             return (this.idx < objects.length);
/*     */           }
/*     */ 
/*     */           
/*     */           public ItemT next() {
/* 174 */             return (ItemT)objects[this.idx++];
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public Lister.Pack<ItemT> startPacking(BeanT current, Accessor<BeanT, ItemT[]> acc) {
/* 181 */       return new Lister.Pack<>(this.itemType);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addToPack(Lister.Pack<ItemT> objects, ItemT o) {
/* 186 */       objects.add(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public void endPacking(Lister.Pack<ItemT> pack, BeanT bean, Accessor<BeanT, ItemT[]> acc) throws AccessorException {
/* 191 */       acc.set(bean, pack.build());
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset(BeanT o, Accessor<BeanT, ItemT[]> acc) throws AccessorException {
/* 196 */       acc.set(o, (ItemT[])Array.newInstance(this.itemType, 0));
/*     */     } } class null implements ListIterator<ItemT> { int idx = 0;
/*     */     public boolean hasNext() {
/*     */       return (this.idx < objects.length);
/*     */     }
/*     */     public ItemT next() {
/*     */       return (ItemT)objects[this.idx++];
/*     */     } }
/*     */   public static final class Pack<ItemT> extends ArrayList<ItemT> { private static final long serialVersionUID = 8543908122652908717L; private final Class<ItemT> itemType;
/*     */     public Pack(Class<ItemT> itemType) {
/* 206 */       this.itemType = itemType;
/*     */     }
/*     */     
/*     */     public ItemT[] build() {
/* 210 */       return toArray((ItemT[])Array.newInstance(this.itemType, size()));
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   static final Map<Class, Lister> primitiveArrayListers = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   static {
/* 221 */     PrimitiveArrayListerBoolean.register();
/* 222 */     PrimitiveArrayListerByte.register();
/* 223 */     PrimitiveArrayListerCharacter.register();
/* 224 */     PrimitiveArrayListerDouble.register();
/* 225 */     PrimitiveArrayListerFloat.register();
/* 226 */     PrimitiveArrayListerInteger.register();
/* 227 */     PrimitiveArrayListerLong.register();
/* 228 */     PrimitiveArrayListerShort.register();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class CollectionLister<BeanT, T extends Collection>
/*     */     extends Lister<BeanT, T, Object, T>
/*     */   {
/*     */     private final Class<? extends T> implClass;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CollectionLister(Class<? extends T> implClass) {
/* 243 */       this.implClass = implClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<Object> iterator(T collection, XMLSerializer context) {
/* 248 */       final Iterator<?> itr = collection.iterator();
/* 249 */       return new ListIterator()
/*     */         {
/*     */           public boolean hasNext() {
/* 252 */             return itr.hasNext();
/*     */           }
/*     */           
/*     */           public Object next() {
/* 256 */             return itr.next();
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public T startPacking(BeanT bean, Accessor<BeanT, T> acc) throws AccessorException {
/* 263 */       Collection collection = (Collection)acc.get(bean);
/* 264 */       if (collection == null) {
/* 265 */         collection = (Collection)ClassFactory.create(this.implClass);
/* 266 */         if (!acc.isAdapted())
/* 267 */           acc.set(bean, (T)collection); 
/*     */       } 
/* 269 */       collection.clear();
/* 270 */       return (T)collection;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addToPack(T collection, Object o) {
/* 275 */       collection.add(o);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void endPacking(T collection, BeanT bean, Accessor<BeanT, T> acc) throws AccessorException {
/*     */       try {
/* 289 */         if (acc.isAdapted()) {
/* 290 */           acc.set(bean, collection);
/*     */         }
/* 292 */       } catch (AccessorException ae) {
/* 293 */         if (acc.isAdapted()) throw ae;
/*     */       
/*     */       } 
/*     */     }
/*     */     
/*     */     public void reset(BeanT bean, Accessor<BeanT, T> acc) throws AccessorException {
/* 299 */       Collection collection = (Collection)acc.get(bean);
/* 300 */       if (collection == null) {
/*     */         return;
/*     */       }
/* 303 */       collection.clear();
/*     */     } }
/*     */   
/*     */   class null implements ListIterator<Object> { public boolean hasNext() {
/*     */       return itr.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/*     */       return itr.next();
/*     */     } }
/*     */   
/*     */   private static final class IDREFS<BeanT, PropT> extends Lister<BeanT, PropT, String, IDREFS<BeanT, PropT>.Pack> { private final Lister<BeanT, PropT, Object, Object> core;
/*     */     private final Class itemType;
/*     */     
/*     */     public IDREFS(Lister<BeanT, PropT, Object, Object> core, Class itemType) {
/* 318 */       this.core = core;
/* 319 */       this.itemType = itemType;
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<String> iterator(PropT prop, XMLSerializer context) {
/* 324 */       ListIterator i = this.core.iterator(prop, context);
/*     */       
/* 326 */       return new Lister.IDREFSIterator(i, context);
/*     */     }
/*     */ 
/*     */     
/*     */     public Pack startPacking(BeanT bean, Accessor<BeanT, PropT> acc) {
/* 331 */       return new Pack(bean, acc);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addToPack(Pack pack, String item) {
/* 336 */       pack.add(item);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void endPacking(Pack pack, BeanT bean, Accessor<BeanT, PropT> acc) {}
/*     */ 
/*     */     
/*     */     public void reset(BeanT bean, Accessor<BeanT, PropT> acc) throws AccessorException {
/* 345 */       this.core.reset(bean, acc);
/*     */     }
/*     */ 
/*     */     
/*     */     private class Pack
/*     */       implements Patcher
/*     */     {
/*     */       private final BeanT bean;
/* 353 */       private final List<String> idrefs = new ArrayList<>();
/*     */       private final UnmarshallingContext context;
/*     */       private final Accessor<BeanT, PropT> acc;
/*     */       private final LocatorEx location;
/*     */       
/*     */       public Pack(BeanT bean, Accessor<BeanT, PropT> acc) {
/* 359 */         this.bean = bean;
/* 360 */         this.acc = acc;
/* 361 */         this.context = UnmarshallingContext.getInstance();
/* 362 */         this.location = (LocatorEx)new LocatorEx.Snapshot(this.context.getLocator());
/* 363 */         this.context.addPatcher(this);
/*     */       }
/*     */       
/*     */       public void add(String item) {
/* 367 */         this.idrefs.add(item);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void run() throws SAXException
/*     */       {
/*     */         
/* 376 */         try { Object pack = Lister.IDREFS.this.core.startPacking(this.bean, this.acc);
/*     */           
/* 378 */           for (String id : this.idrefs) {
/* 379 */             Object t; Callable callable = this.context.getObjectFromId(id, Lister.IDREFS.this.itemType);
/*     */ 
/*     */             
/*     */             try {
/* 383 */               t = (callable != null) ? callable.call() : null;
/* 384 */             } catch (SAXException e) {
/* 385 */               throw e;
/* 386 */             } catch (Exception e) {
/* 387 */               throw new SAXException2(e);
/*     */             } 
/*     */             
/* 390 */             if (t == null) {
/* 391 */               this.context.errorUnresolvedIDREF(this.bean, id, this.location); continue;
/*     */             } 
/* 393 */             TODO.prototype();
/* 394 */             Lister.IDREFS.this.core.addToPack(pack, t);
/*     */           } 
/*     */ 
/*     */           
/* 398 */           Lister.IDREFS.this.core.endPacking(pack, this.bean, this.acc); }
/* 399 */         catch (AccessorException e)
/* 400 */         { this.context.handleError((Exception)e); }  } } } private class Pack implements Patcher { private final BeanT bean; public void run() throws SAXException { try { Object pack = this.this$0.core.startPacking(this.bean, this.acc); for (String id : this.idrefs) { Object t; Callable callable = this.context.getObjectFromId(id, this.this$0.itemType); try { t = (callable != null) ? callable.call() : null; } catch (SAXException e) { throw e; } catch (Exception e) { throw new SAXException2(e); }  if (t == null) { this.context.errorUnresolvedIDREF(this.bean, id, this.location); continue; }  TODO.prototype(); this.this$0.core.addToPack(pack, t); }  this.this$0.core.endPacking(pack, this.bean, this.acc); } catch (AccessorException e) { this.context.handleError((Exception)e); }
/*     */        }
/*     */     
/*     */     private final List<String> idrefs = new ArrayList<>(); private final UnmarshallingContext context; private final Accessor<BeanT, PropT> acc; private final LocatorEx location;
/*     */     public Pack(BeanT bean, Accessor<BeanT, PropT> acc) {
/*     */       this.bean = bean;
/*     */       this.acc = acc;
/*     */       this.context = UnmarshallingContext.getInstance();
/*     */       this.location = (LocatorEx)new LocatorEx.Snapshot(this.context.getLocator());
/*     */       this.context.addPatcher(this);
/*     */     }
/*     */     public void add(String item) {
/*     */       this.idrefs.add(item);
/*     */     } }
/*     */   public static final class IDREFSIterator implements ListIterator<String> { private final ListIterator i;
/*     */     private final XMLSerializer context;
/*     */     private Object last;
/*     */     
/*     */     private IDREFSIterator(ListIterator i, XMLSerializer context) {
/* 419 */       this.i = i;
/* 420 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 425 */       return this.i.hasNext();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object last() {
/* 432 */       return this.last;
/*     */     }
/*     */ 
/*     */     
/*     */     public String next() throws SAXException, JAXBException {
/* 437 */       this.last = this.i.next();
/* 438 */       String id = this.context.grammar.getBeanInfo(this.last, true).getId(this.last, this.context);
/* 439 */       if (id == null) {
/* 440 */         this.context.errorMissingId(this.last);
/*     */       }
/* 442 */       return id;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A, B, C, D> Lister<A, B, C, D> getErrorInstance() {
/* 451 */     return ERROR;
/*     */   }
/*     */   
/* 454 */   public static final Lister ERROR = new Lister()
/*     */     {
/*     */       public ListIterator iterator(Object o, XMLSerializer context) {
/* 457 */         return Lister.EMPTY_ITERATOR;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object startPacking(Object o, Accessor accessor) {
/* 462 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void addToPack(Object o, Object o1) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void endPacking(Object o, Object o1, Accessor accessor) {}
/*     */ 
/*     */       
/*     */       public void reset(Object o, Accessor accessor) {}
/*     */     };
/*     */ 
/*     */   
/* 478 */   private static final ListIterator EMPTY_ITERATOR = new ListIterator()
/*     */     {
/*     */       public boolean hasNext() {
/* 481 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object next() {
/* 486 */         throw new IllegalStateException();
/*     */       }
/*     */     };
/*     */   
/* 490 */   private static final Class[] COLLECTION_IMPL_CLASSES = new Class[] { ArrayList.class, LinkedList.class, HashSet.class, TreeSet.class, Stack.class };
/*     */   
/*     */   public abstract ListIterator<ItemT> iterator(PropT paramPropT, XMLSerializer paramXMLSerializer);
/*     */   
/*     */   public abstract PackT startPacking(BeanT paramBeanT, Accessor<BeanT, PropT> paramAccessor) throws AccessorException;
/*     */   
/*     */   public abstract void addToPack(PackT paramPackT, ItemT paramItemT) throws AccessorException;
/*     */   
/*     */   public abstract void endPacking(PackT paramPackT, BeanT paramBeanT, Accessor<BeanT, PropT> paramAccessor) throws AccessorException;
/*     */   
/*     */   public abstract void reset(BeanT paramBeanT, Accessor<BeanT, PropT> paramAccessor) throws AccessorException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\Lister.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */