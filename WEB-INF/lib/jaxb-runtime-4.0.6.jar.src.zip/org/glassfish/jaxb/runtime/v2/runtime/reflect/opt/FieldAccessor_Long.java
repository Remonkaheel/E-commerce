/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldAccessor_Long<B>
/*    */   extends Accessor<B, Long>
/*    */ {
/*    */   public FieldAccessor_Long() {
/* 27 */     super(Long.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Long get(B bean) {
/* 32 */     return Long.valueOf(((Bean)bean).f_long);
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(B bean, Long value) {
/* 37 */     ((Bean)bean).f_long = (value == null) ? 0L : value.longValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\FieldAccessor_Long.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */