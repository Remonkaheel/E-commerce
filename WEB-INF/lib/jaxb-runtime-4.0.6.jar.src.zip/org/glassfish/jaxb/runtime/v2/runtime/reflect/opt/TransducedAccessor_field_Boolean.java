/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect.opt;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.DefaultTransducedAccessor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TransducedAccessor_field_Boolean<T>
/*    */   extends DefaultTransducedAccessor<T>
/*    */ {
/*    */   public String print(T o) {
/* 31 */     return DatatypeConverterImpl._printBoolean(((Bean)o).f_boolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public void parse(T o, CharSequence lexical) {
/* 36 */     Boolean b = DatatypeConverterImpl._parseBoolean(lexical);
/*    */     
/* 38 */     if (b != null) {
/* 39 */       ((Bean)o).f_boolean = b.booleanValue();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasValue(Object o) {
/* 44 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\opt\TransducedAccessor_field_Boolean.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */